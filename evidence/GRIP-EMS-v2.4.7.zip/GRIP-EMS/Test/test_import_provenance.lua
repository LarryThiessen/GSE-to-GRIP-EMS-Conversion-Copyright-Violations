-- GRIP-EMS: Headless test for import-provenance resolution
--
-- Created:    2026-07-30
-- Updated:    2026-08-17
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
--
-- Standalone (Lua 5.1) test for the provenance rail in Import/ImportPreview.lua:
-- BuildSeqDataFromGRIP1's authorship chain and AttachProvenance's preview-side
-- inference. Loads the REAL modules via loadfile + setfenv into a sandbox,
-- including Engine/Identity.lua, so the verdict assertions run against the real
-- VerifySequence rather than a restatement of it.
--
-- BuildSeqDataFromGRIP1 and AttachProvenance are both file-locals in
-- ImportPreview.lua and cannot be called directly. Both are driven the public
-- way: build a native COLLECTION payload, LI.Preview it (AttachProvenance runs
-- on every preview entry), then LI.CommitSelected it (the collection arm hands
-- entry.seqObj straight to BuildSeqDataFromGRIP1).
--
-- A payload converted from a legacy format carries that format's version stamp
-- but no authorship block. The stamp is the origin record, so the commit rail
-- reads it and resolves the same provenance family the raw legacy rail already
-- stamps in LI.ProcessSequence -- and the preview rail reads it too, so the
-- badge resolves before commit rather than only after it.
--
-- Run from the EMS root:  lua Test/test_import_provenance.lua
-- Exit code 0 = all passed, 1 = at least one failure.
--
-- Cases:
--   P1  converted shape (author + stamp, no authorship block) commits
--       provenanceSource "gse-legacy" with originalAuthor taken from author
--   P1c an explicit inbound provenanceSource wins over the arm's default,
--       and the verdict for it is still "unknown"
--   P1b the same commit appends one "imported-from-gse" modifier entry
--   P2  converted shape with author ABSENT resolves the placeholder byline
--   P2b converted shape with author "" resolves the placeholder byline too
--       (the empty string is truthy in Lua -- a plain `or` cannot catch it)
--   P3  native shape (authorship block, no stamp) still resolves "no-provenance"
--   P4  AttachProvenance exposes "gse-legacy" on the PREVIEW entry, pre-commit
--   P4b AttachProvenance leaves an unstamped payload's source empty
--   P5  neither authorship block nor stamp: provenance stays nil for the
--       Core.lua repair pass, unchanged from today
--   P6  no verdict moves: the real VerifySequence returns "unknown" for the
--       converted commit and for the native commit alike

local ADDON_NAME = "GRIP-EMS"

-- ---------------------------------------------------------------------------
-- Minimal assertion + runner harness.
-- ---------------------------------------------------------------------------

local tests = {}

local function test(name, fn)
    tests[#tests + 1] = { name = name, fn = fn }
end

local function assertEqual(expected, actual, label)
    if expected ~= actual then
        error((label or "value") .. ": expected " .. tostring(expected) .. ", got " .. tostring(actual), 2)
    end
end

local function assertTrue(cond, label)
    if not cond then
        error((label or "condition") .. " failed", 2)
    end
end

-- ---------------------------------------------------------------------------
-- Sandbox. Unknown globals resolve to nil (not to a permissive stub) so a read
-- the loaded modules make unguarded raises by name instead of passing silently.
-- ---------------------------------------------------------------------------

local WOW_GLOBALS = {
    -- BuildSeqDataFromGRIP1 reads select(3, UnitClass("player")) for classID.
    UnitClass = function()
        return "Mage", "MAGE", 8
    end,
    -- Identity:GetCurrent reads all three UNGUARDED. No BattleTag = the
    -- name-realm branch, which is the realistic headless answer.
    BNGetInfo = function()
        return nil, nil
    end,
    GetRealmName = function()
        return "Hyjal"
    end,
    UnitName = function()
        return "Sataana"
    end,
    GetLocale = function()
        return "enUS"
    end,
    -- Identity.lua registers a PLAYER_LOGIN frame at file scope. The event
    -- never fires headless, so the handler body is out of scope here.
    CreateFrame = function()
        return {
            RegisterEvent = function() end,
            SetScript = function() end,
        }
    end,
    wipe = function(t)
        for k in pairs(t) do
            t[k] = nil
        end
        return t
    end,
}

local env = setmetatable({}, {
    __index = function(_, k)
        local v = rawget(_G, k)
        if v ~= nil then
            return v
        end
        return WOW_GLOBALS[k]
    end,
})
env._G = env
env.strlower = string.lower
env.strsplit = function(sep, str)
    local out = {}
    for piece in tostring(str):gmatch("([^" .. sep .. "]*)") do
        out[#out + 1] = piece
    end
    return unpack(out)
end
env.time = function()
    return 0
end
env.GetTime = function()
    return 0
end

-- Locale: unlisted keys echo back, so every string.format over a warning key
-- resolves without erroring. No case asserts on rendered text.
local LOCALE = setmetatable({}, {
    __index = function(_, k)
        return k
    end,
})
env.LibStub = function(major)
    if major == "AceLocale-3.0" then
        return {
            GetLocale = function()
                return LOCALE
            end,
        }
    end
    -- Identity probes LibStub("LibHash-1.0", true); absent = the djb2 fallback,
    -- which is a real live path (installs missing the library) and is pure Lua.
    return nil
end

-- ---------------------------------------------------------------------------
-- GRIPEMS stub table. Only the surfaces the preview + commit rails call.
-- ---------------------------------------------------------------------------

local GRIPEMS = {
    Debug = function() end,
    Engine = {
        sequences = {},
        ActivateSequence = function(self, name, seqData)
            self.sequences[name] = { data = seqData }
        end,
        GetActiveVersion = function(_, seqData)
            if not seqData or type(seqData.versions) ~= "table" then
                return nil
            end
            return seqData.versions[seqData.defaultVersion or 1] or seqData.versions[1]
        end,
    },
    VariableStore = {
        Get = function() end,
        GetAll = function()
            return {}
        end,
    },
    -- Inert by design: this file asserts on provenance fields, not on cast
    -- text, so locale normalisation and token recovery are pass-throughs.
    SpellCache = {
        ready = true,
        RecoverHandleTokensInText = function(_, text)
            return text
        end,
        TranslateMacrotext = function(_, text)
            return text
        end,
        NormalizeVersionLocale = function() end,
    },
    Serialization = {},
}

-- Registry-backed Serialization stub, same shape as the sibling harnesses:
-- Encode parks the table and returns "<prefix>#<index>", Decode resolves it.
local REGISTRY = {}

GRIPEMS.Serialization = {
    Encode = function(tbl, prefix)
        REGISTRY[#REGISTRY + 1] = tbl
        return true, prefix .. "#" .. tostring(#REGISTRY)
    end,
    Decode = function(str)
        local prefix = GRIPEMS.Defaults and GRIPEMS.Defaults.GRIP1_PREFIX
        if not prefix or str:sub(1, #prefix) ~= prefix then
            return false, "Unknown format"
        end
        local idx = tonumber(str:sub(#prefix + 2))
        local tbl = idx and REGISTRY[idx]
        if not tbl then
            return false, "Decode failed"
        end
        return true, tbl, "GRIP1"
    end,
    DetectFormat = function(str)
        local prefix = GRIPEMS.Defaults and GRIPEMS.Defaults.GRIP1_PREFIX
        if prefix and str:sub(1, #prefix) == prefix then
            return "GRIP1"
        end
        return nil
    end,
}

-- ---------------------------------------------------------------------------
-- Load the REAL modules into the sandbox, in TOC order.
-- ---------------------------------------------------------------------------

local function loadModule(candidates)
    for _, path in ipairs(candidates) do
        -- loadfile is dev-harness file I/O, intentionally outside the addon WoW std.
        -- selene: allow(undefined_variable)
        local chunk = loadfile(path)
        if chunk then
            setfenv(chunk, env)
            chunk(ADDON_NAME, GRIPEMS)
            return true
        end
    end
    return false
end

local MODULES = {
    { "Data/Defaults.lua", "../Data/Defaults.lua", "GRIP/EMS/Data/Defaults.lua" },
    { "Engine/Identity.lua", "../Engine/Identity.lua", "GRIP/EMS/Engine/Identity.lua" },
    { "Engine/MacroSyntax.lua", "../Engine/MacroSyntax.lua", "GRIP/EMS/Engine/MacroSyntax.lua" },
    { "Engine/ActionCompiler.lua", "../Engine/ActionCompiler.lua", "GRIP/EMS/Engine/ActionCompiler.lua" },
    { "Import/LegacyImport.lua", "../Import/LegacyImport.lua", "GRIP/EMS/Import/LegacyImport.lua" },
    -- Defines LI.Preview's native helpers and LI.CommitSelected ON the
    -- LegacyImport table, so it must load after LegacyImport.
    { "Import/ImportPreview.lua", "../Import/ImportPreview.lua", "GRIP/EMS/Import/ImportPreview.lua" },
}
for _, candidates in ipairs(MODULES) do
    assertTrue(loadModule(candidates), "could not locate " .. candidates[1] .. " (run from the EMS root)")
end

local D = GRIPEMS.Defaults
local LI = GRIPEMS.LegacyImport
local S = GRIPEMS.Serialization
local Identity = GRIPEMS.Identity
assertTrue(D ~= nil, "Defaults loaded")
assertTrue(LI ~= nil, "LegacyImport loaded")
assertTrue(Identity ~= nil, "Identity loaded")
assertTrue(type(LI.Preview) == "function", "LI.Preview defined")
assertTrue(type(LI.CommitSelected) == "function", "LI.CommitSelected defined")
assertTrue(type(Identity.VerifySequence) == "function", "Identity:VerifySequence defined")

-- ---------------------------------------------------------------------------
-- Fixtures + the preview/commit driver.
-- ---------------------------------------------------------------------------

local STEP = "/cast Alpha"

-- The version stamp a converted payload carries forward from its source format.
local SOURCE_STAMP = 3
local PLACEHOLDER_BYLINE = "Unknown (legacy import)"

--- Build a one-sequence native COLLECTION payload around a sequence body.
local function makePayload(name, seq)
    seq.versions = seq.versions or { { stepFunction = D.STEP_SEQUENTIAL, steps = { STEP } } }
    seq.defaultVersion = seq.defaultVersion or 1
    return {
        format = "GRIP-EMS",
        version = D.GRIP_FORMAT_VERSION,
        type = "COLLECTION",
        sequences = { [name] = seq },
        variables = {},
    }
end

--- Encode + preview a one-sequence payload. Returns the preview result.
local function previewOf(name, seq)
    local ok, encoded = S.Encode(makePayload(name, seq), D.GRIP1_PREFIX)
    assertTrue(ok, "encode failed for " .. name)
    local preview = LI.Preview(encoded)
    assertTrue(preview.ok, "preview failed for " .. name .. ": " .. tostring(preview.error))
    assertEqual(1, #preview.sequences, "one preview entry for " .. name)
    assertTrue(preview.sequences[1].isCollection, "entry routes through the collection arm")
    return preview
end

--- Preview then commit, and hand back the committed seqData.
local function commitOf(name, seq)
    GRIPEMS.Engine.sequences[name] = nil
    local preview = previewOf(name, seq)
    local ok, success, results = pcall(LI.CommitSelected, preview, {
        sequences = { { selected = true, action = "import" } },
        variables = {},
    })
    assertTrue(ok, "CommitSelected raised for " .. name .. ": " .. tostring(success))
    assertTrue(success ~= false, "CommitSelected reported failure for " .. name .. ": " .. tostring(results))
    local stored = GRIPEMS.Engine.sequences[name]
    assertTrue(stored and stored.data, "nothing committed for " .. name)
    return stored.data
end

-- ---------------------------------------------------------------------------
-- Cases.
-- ---------------------------------------------------------------------------

test("P1: a converted payload commits the legacy-import family, byline from author", function()
    local committed = commitOf("P1Seq", {
        author = "Wenlo",
        gseVersion = SOURCE_STAMP,
        -- No originalAuthor and no provenanceSource: exactly what a converted
        -- payload carries. Before the stamp was read, this reached commit with
        -- provenance nil and was stamped no-provenance on the next load.
    })
    assertEqual("gse-legacy", committed.provenanceSource, "provenanceSource resolved from the source stamp")
    assertEqual("Wenlo", committed.originalAuthor, "originalAuthor taken from the payload author")
    assertEqual("", committed.originalAuthorIdentity, "no identity is synthesized")
    assertEqual("", committed.originalAuthorRealm, "no realm is synthesized")
    assertEqual(nil, committed.originalAuthorBattleTag, "no BattleTag is ever carried inbound")
    assertEqual(0, committed.originalCreatedAt, "no creation time is synthesized")
    assertEqual("", committed.originalSignature, "the sequence stays UNSIGNED")
    assertEqual("public", committed.privacyMode, "privacy defaults to public")
    assertEqual("ALG_V0_DJB2", committed.signatureAlgorithm, "signature algorithm stamped")
end)

test("P1c: an explicit inbound provenance value survives the converted arm", function()
    local committed = commitOf("P1cSeq", {
        author = "Wenlo",
        gseVersion = SOURCE_STAMP,
        -- "offline-fallback" on purpose. It is already in the VerifySequence
        -- whitelist, so this case cannot turn a verdict red, and neither
        -- default on this rail can synthesize it, so the assertion cannot pass
        -- by accident the way "gse-legacy" or "no-provenance" could.
        provenanceSource = "offline-fallback",
    })
    assertEqual("offline-fallback", committed.provenanceSource, "the inbound value wins over the arm's default")
    assertEqual("Wenlo", committed.originalAuthor, "the byline still resolves from the source stamp")
    assertEqual("", committed.originalSignature, "the sequence stays UNSIGNED")
    assertEqual("unknown", Identity:VerifySequence(committed), "verdict is still unknown for the inbound value")
end)

test("P1b: the converted commit appends exactly one import-from-source chain entry", function()
    local committed = commitOf("P1bSeq", { author = "Wenlo", gseVersion = SOURCE_STAMP })
    assertEqual("table", type(committed.modifierChain), "modifier chain is a table")
    assertEqual(1, #committed.modifierChain, "exactly one chain entry")
    assertEqual("imported-from-gse", committed.modifierChain[1].kind, "chain entry kind matches the legacy rail")
    assertEqual("Sataana", committed.modifierChain[1].name, "the importer is the chain entry")
end)

test("P2: a converted payload with NO author resolves the placeholder byline", function()
    local committed = commitOf("P2Seq", { gseVersion = SOURCE_STAMP })
    assertEqual("gse-legacy", committed.provenanceSource, "provenanceSource still resolves")
    assertEqual(PLACEHOLDER_BYLINE, committed.originalAuthor, "placeholder byline, not an empty string")
end)

test("P2b: a converted payload with an EMPTY author resolves the placeholder byline", function()
    -- The motivating difference from the LI.ProcessSequence twin. seqData.author
    -- is normalized to "" by BuildSeqDataFromGRIP1, and "" is TRUTHY in Lua, so
    -- the twin's plain `or` fallback could never fire on this rail. Reverting
    -- the `~= ""` test to a plain `or` turns this case red and P2 green.
    local committed = commitOf("P2bSeq", { author = "", gseVersion = SOURCE_STAMP })
    assertEqual("gse-legacy", committed.provenanceSource, "provenanceSource still resolves")
    assertEqual(PLACEHOLDER_BYLINE, committed.originalAuthor, "placeholder byline, not an empty string")
end)

test("P3: a native payload with an authorship block still resolves no-provenance", function()
    local committed = commitOf("P3Seq", {
        author = "Wenlo",
        originalAuthor = "Someone",
        originalAuthorIdentity = "deadbeef",
        -- No gseVersion and no provenanceSource: the unattributed native case,
        -- which must read exactly as it did before the stamp was consulted.
    })
    assertEqual("no-provenance", committed.provenanceSource, "unstamped native payloads are unchanged")
    assertEqual("Someone", committed.originalAuthor, "the inbound authorship block wins")
    assertEqual("deadbeef", committed.originalAuthorIdentity, "the inbound identity is carried")
    assertEqual(1, #committed.modifierChain, "one chain entry")
    assertEqual("imported", committed.modifierChain[1].kind, "the native chain entry kind is unchanged")
end)

test("P4: AttachProvenance resolves the badge on the PREVIEW entry, before any commit", function()
    local preview = previewOf("P4Seq", { author = "Wenlo", gseVersion = SOURCE_STAMP })
    local prov = preview.sequences[1].provenance
    assertTrue(prov ~= nil, "preview entry carries a provenance block")
    assertEqual("gse-legacy", prov.provenanceSource, "the preview tooltip's source line resolves pre-commit")
    assertEqual("Wenlo", prov.originalAuthor, "the byline the source line formats resolves pre-commit")
    -- Nothing was committed: the badge comes from the wire object alone.
    assertEqual(nil, GRIPEMS.Engine.sequences["P4Seq"], "no sequence was committed by the preview")
    -- The verification state reads seqObj.originalAuthor directly rather than
    -- the prov table, so an authorless converted payload still greys out.
    assertEqual("unknown", prov.verificationState, "verification state is untouched by the inference")
end)

test("P4b: AttachProvenance leaves an UNSTAMPED payload's source empty", function()
    local preview = previewOf("P4bSeq", { author = "Wenlo" })
    local prov = preview.sequences[1].provenance
    assertEqual("", prov.provenanceSource, "no stamp, no inferred source")
    assertEqual("", prov.originalAuthor, "a plain author is never promoted to original author")
end)

test("P5: neither block nor stamp leaves provenance nil for the repair pass", function()
    local committed = commitOf("P5Seq", { author = "Wenlo" })
    assertEqual(nil, committed.provenanceSource, "no provenance is written at commit time")
    assertEqual(nil, committed.originalAuthor, "no byline is synthesized")
    assertEqual(nil, committed.modifierChain, "no chain is started")
end)

test("P6: no verdict moves -- both committed families verify as unknown", function()
    local converted = commitOf("P6Seq", { author = "Wenlo", gseVersion = SOURCE_STAMP })
    local native = commitOf("P6NativeSeq", { author = "Wenlo", originalAuthor = "Someone" })
    -- Both are UNSIGNED (originalSignature ""), and VerifySequence whitelists
    -- gse-legacy alongside no-provenance in that branch. The modifier chain is
    -- not consulted there, so appending to it cannot move either verdict.
    assertEqual("", converted.originalSignature, "converted commit is unsigned")
    assertEqual("", native.originalSignature, "native commit is unsigned")
    assertEqual("unknown", Identity:VerifySequence(converted), "converted verdict unchanged")
    assertEqual("unknown", Identity:VerifySequence(native), "native verdict unchanged")
end)

-- ---------------------------------------------------------------------------
-- Run.
-- ---------------------------------------------------------------------------

local passed = 0
local failed = 0
for _, t in ipairs(tests) do
    local ok, err = pcall(t.fn)
    if ok then
        passed = passed + 1
        print("PASS  " .. t.name)
    else
        failed = failed + 1
        print("FAIL  " .. t.name .. " -- " .. tostring(err))
    end
end
print(string.format("RESULT %d passed, %d failed", passed, failed))
os.exit(failed > 0 and 1 or 0)
