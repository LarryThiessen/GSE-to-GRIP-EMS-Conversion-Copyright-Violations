-- GRIP-EMS: Headless test for SEQUENCE_STEP_ADVANCED numSteps domain agreement
--
-- Created:    2026-07-11
-- Updated:    2026-07-28
-- Patch: 12.0.7 Midnight (Retail LIVE)
--
-- Guards STEPADV-NUMSTEPS-EXPANDED-MISMATCH. The secure click body cycles the
-- button "step" attribute over the EXPANDED step array (BuildExecuteString emits
-- numSteps = #compiledSteps), but Engine:UpdateButtonIcon used to fire the event
-- with #ver.steps -- the AUTHORED count. For every expanding step function
-- (Priority, ReversePriority, plugin expanders) the two disagree: a 4-step
-- Priority sequence expands to 10, so the button cycles step 1..10 while the
-- event reported numSteps = 4 (the TrackerHUD "7/4" display).
--
-- The fix caches the compiled length on the button at compile time
-- (btn._numExecSteps = #compiledSteps) and fires that, falling back to
-- #ver.steps only when the field is absent (a button compiled before the field
-- existed). This test drives the REAL Engine:UpdateButtonIcon fire path and the
-- REAL Engine:BuildExecutionOrder / GetActiveVersionStepList expansion path and
-- asserts the two domains agree.
--
-- Scope note: this exercises the CONSUMER of the cache (Engine:UpdateButtonIcon,
-- edit 6) and the read accessor the docs pair it with. The five producer sites
-- that set btn._numExecSteps = #compiledSteps (ActivateSequence base + variant,
-- RecompileSequence base + variant, TempoAdvisor hold mode) are trivial one-line
-- assignments verified against the compiled-length invariant proven here: for a
-- non-overflowing sequence #compiledSteps == #BuildExecutionOrder(steps, sf), so
-- the value they cache is exactly the value asserted below.
--
-- Loads the REAL modules (Engine/StepFunctions.lua + Engine/Engine.lua) via
-- loadfile + setfenv into a no-op stub sandbox, the same technique as
-- test_legacy_import_parity.lua. No secure frames are created; the fire path is
-- pure Lua and safe headless.
--
-- Run from the EMS root:  lua Test/test_stepadv_numsteps_domain.lua
-- Exit code 0 = all passed, 1 = at least one failure.
--
-- Cases:
--   P1  Priority 4-step expands to 10 (BuildExecutionOrder == the accessor array)
--   P2  Priority fire reports the EXPANDED 10 when the button carries the cache
--   P3  Priority fire with NO cache expands rather than reporting the compiled 4
--   P4  #GetSequenceSteps(name) == fired numSteps == 10 (docs/api/data.md pairing)
--   P5  a DORMANT sequence (button = nil) reports the execution count via GetSequenceList
--   S1  Sequential 4-step stays 4 across expand, fire, and accessor (no regression)
--   R1  ReversePriority 4-step expands to 10 and fires 10 (second expander covered)
--   X3  no-cache text AND count both sit in the execution domain (cached == uncached)
--   X4  ReversePriority no-cache text returns the EXPANDED order[1], not authored steps[1]
--   X5  cached and no-cache GetExecStepText agree for every step (regression net)
--   G1  GetActiveVersion resolves a SCALAR versions to nil and never indexes it
--       (the only case in SET A driving that head check against the REAL Engine)
--   E1  UpdateSequenceData (the SAVE path) survives every versions shape and
--       hands only a real version to the locale normaliser  -- Engine.lua:2724
--   E2  HealLocaleSteps walks a store holding a malformed entry and still heals
--       its well-formed neighbour                            -- Engine.lua:2983
--   E3  HealOverrideSteps does the same on the talent-change path
--                                                            -- Engine.lua:3068
--   E4  DuplicateSequence copies every versions shape and really deep-copies a
--       real one                                             -- Engine.lua:3201
--       (Engine.lua:1407 is the fifth guard and stays SOURCE-ONLY: it is a
--       look-alike protected by GetActiveVersion's own head check. See the
--       measured note at the head of the E-cases.)
--   T1  the four step-entry shape gates absorb a number, a boolean and a
--       string on CompileSteps, BuildExecutionOrder, SimulateSteps and
--       BuildExecuteString -- Engine.lua:155, :254, :307, :459 pre-15t
--
-- NOTE ON THE Engine.lua NUMBERS IN THIS FILE. Every citation below has been
-- SWEPT to the CURRENT tree at 15u and checked against the line's own text.
-- The pre-15t value is kept in parentheses only where the surrounding prose
-- quotes a pre-15t run.
--
-- 15t recorded the shift as "everything below the first guard moved down by
-- exactly 56 lines". THAT IS WRONG, and it is worth the space because the
-- wrong version was written into this file and into a commit body. The four
-- guards created FOUR bands, and the diff's own hunk headers say so:
--     old 159..250  ->  +23      @@ -152,7 +152,30 @@
--     old 258..303  ->  +37      @@ -251,7 +274,21 @@
--     old 311..455  ->  +41      @@ -304,7 +341,11 @@
--     old 463..end  ->  +56      @@ -456,7 +497,22 @@
-- Checked against line text: old :162 is now :185, old :217 is now :240, old
-- :263 is now :300, old :463 is now :519. (Those four "now" values are in the
-- 15t tree; 15u shifted them again -- see the next block.)
--
-- HOW THE ONE-BAND CLAIM SURVIVED ITS OWN EVIDENCE. Six spot-checks were
-- offered for it -- :641, :2735, :2738, :1538, :2153, :2811 -- and every one
-- of them is above old :462, so every one lands in the +56 band. The sample
-- was drawn entirely from the bucket it confirmed. A spot-check has to span
-- the boundaries of the thing it is testing or it tests nothing.
--
-- And the file used to contradict itself: the guard heads are listed above at
-- the T1 case as pre-15t :155, :254, :307, :459, and applying a flat +56 to
-- those gives 211, 310, 363, 515 while the correct values are 178, 291, 348,
-- 515. Three of the four disagree.
--
-- AND 15u SHIFTED IT AGAIN, so this note states its OWN bands rather than
-- leaving the next pass to guess. 15u added four comment blocks to
-- Engine.lua (+68 / -22, net +46). From git diff's own hunk headers:
--     15t-tree 1..49       ->  +0     @@ -49,0 +50,14 @@
--     15t-tree 50..286     ->  +14    @@ -280,7 +294,10 @@
--     15t-tree 287..290    ->  +17    @@ -288,3 +305,8 @@   (interior to the
--                                     rewritten comment; no citation lands here)
--     15t-tree 291..514    ->  +22    @@ -503,12 +525,28 @@
--     15t-tree 515..1277   ->  +38    @@ -1277,0 +1316,8 @@
--     15t-tree 1278..end   ->  +46
-- So the four 15t guard heads are now Engine.lua:192, :313, :370 and :553.
-- FIVE bands this time, not four and not one: git split the BuildExecutionOrder
-- rewrite into two hunks because one "--" line inside it happened to survive.
-- Every Engine.lua number in this file is post-15u and was READ at the line it
-- names. None of them was produced by adding an offset to an older number.

local ADDON_NAME = "GRIP-EMS"

-- ---------------------------------------------------------------------------
-- Minimal assertion + runner harness.
-- ---------------------------------------------------------------------------

local tests = {}

local function test(name, fn)
    tests[#tests + 1] = { name = name, fn = fn }
end

local function assertEqual(expected, actual, label)
    if expected ~= actual then
        error((label or "value") .. ": expected " .. tostring(expected) .. ", got " .. tostring(actual), 2)
    end
end

local function assertTrue(cond, label)
    if not cond then
        error((label or "condition") .. " failed", 2)
    end
end

-- ---------------------------------------------------------------------------
-- Sandbox: a self-referential no-op stub backs every unknown global so the real
-- modules load without a WoW client. Real stdlib falls through to _G.
-- ---------------------------------------------------------------------------

local stub = {}
setmetatable(stub, {
    __index = function()
        return stub
    end,
    __call = function()
        return stub
    end,
})

local env = setmetatable({}, {
    __index = function(_, k)
        local v = rawget(_G, k)
        if v ~= nil then
            return v
        end
        return stub
    end,
})
env._G = env

-- AceLocale stand-in: every key echoes back so any L["KEY"] format is inert.
local LOCALE = setmetatable({}, {
    __index = function(_, k)
        return k
    end,
})
env.LibStub = function()
    return {
        GetLocale = function()
            return LOCALE
        end,
    }
end

-- ---------------------------------------------------------------------------
-- GRIPEMS control table. Fire captures the SEQUENCE_STEP_ADVANCED payload;
-- OOCQueue.IsRestricted() returns true so UpdateButtonIcon skips the icon branch
-- (which needs MacroManager / SpellCache) and reaches the unconditional fire.
-- ---------------------------------------------------------------------------

local lastFire = {}

local GRIPEMS = {
    version = "headless",
    Print = function() end,
    Debug = function() end,
    Defaults = {
        STEP_SEQUENTIAL = "Sequential",
        STEP_RANDOM = "Random",
        STEP_PRIORITY = "Priority",
        STEP_REVERSE_PRIORITY = "ReversePriority",
        ATTR_TYPE_MACRO = "macro",
        MAX_MACROTEXT_LENGTH = 255,
        MAX_SAB_MACROTEXT_LENGTH = 255,
        CONTEXT_NONE = "none",
    },
    OOCQueue = {
        IsRestricted = function()
            return true
        end,
        -- RecompileSequence queues doRecompile here; run it synchronously so the
        -- test observes the cache-set outcome in-line.
        Add = function(_, fn)
            fn()
        end,
    },
    MacroManager = {
        UpdateIcon = function() end,
        UpdateStubBody = function() end,
    },
    KeybindManager = {},
    -- Engine.lua registers a corrupt-sequence popup at module scope (Popup:Define);
    -- the fire path never shows it, so a no-op definer is enough to load the file.
    Popup = {
        Define = function() end,
        Show = function() end,
    },
}

function GRIPEMS:Fire(event, seqName, step, numSteps)
    if event == "SEQUENCE_STEP_ADVANCED" then
        lastFire.seqName = seqName
        lastFire.step = step
        lastFire.numSteps = numSteps
        lastFire.count = (lastFire.count or 0) + 1
    end
end

-- ---------------------------------------------------------------------------
-- Load the REAL modules into the sandbox. StepFunctions first: Engine captures
-- GRIPEMS.StepFunctions as a file-scope upvalue at load, so it must exist first.
-- ---------------------------------------------------------------------------

local function loadModule(candidates)
    for _, path in ipairs(candidates) do
        -- loadfile is dev-harness file I/O, intentionally outside the addon WoW std.
        -- selene: allow(undefined_variable)
        local chunk = loadfile(path)
        if chunk then
            setfenv(chunk, env)
            chunk(ADDON_NAME, GRIPEMS)
            return true
        end
    end
    return false
end

assert(
    loadModule({
        "Engine/StepFunctions.lua",
        "../Engine/StepFunctions.lua",
        "GRIP/EMS/Engine/StepFunctions.lua",
    }),
    "could not locate Engine/StepFunctions.lua (run from the EMS root)"
)
assert(
    loadModule({
        "Engine/Engine.lua",
        "../Engine/Engine.lua",
        "GRIP/EMS/Engine/Engine.lua",
    }),
    "could not locate Engine/Engine.lua (run from the EMS root)"
)

local Engine = GRIPEMS.Engine
local SF = GRIPEMS.StepFunctions
assert(Engine ~= nil, "Engine loaded")
assert(SF ~= nil, "StepFunctions loaded")
assert(type(Engine.BuildExecutionOrder) == "function", "BuildExecutionOrder defined")
assert(type(Engine.UpdateButtonIcon) == "function", "UpdateButtonIcon defined")
assert(type(Engine.GetActiveVersionStepList) == "function", "GetActiveVersionStepList defined")
Engine.sequences = {}

-- ---------------------------------------------------------------------------
-- Fixtures + helpers.
-- ---------------------------------------------------------------------------

-- A four-step authored sequence in the versioned format GetActiveVersion reads.
local function makeSequence(stepFunction)
    return {
        versions = {
            {
                steps = { "/cast Alpha", "/cast Bravo", "/cast Charlie", "/cast Delta" },
                stepFunction = stepFunction,
                compiledLabels = { "Alpha", "Bravo", "Charlie", "Delta" },
                keyPress = "",
                keyRelease = "",
            },
        },
        defaultVersion = 1,
    }
end

-- Mirrors Core/PublicAPI.lua impl.GetSequenceSteps(name): resolve the registered
-- entry, then delegate to Engine:GetActiveVersionStepList (the expanded array).
local function apiGetSequenceSteps(name)
    local entry = Engine.sequences[name]
    if not entry then
        return nil
    end
    return Engine:GetActiveVersionStepList(entry.data)
end

-- Register a sequence, build a fake button (no secure frame -- the fire path is
-- pure Lua), and drive the REAL Engine:UpdateButtonIcon. numExecSteps stands in
-- for the compile-time cache the producer sites set; pass nil to test the
-- fallback. Returns the captured numSteps.
local function driveFire(name, seqData, numExecSteps)
    Engine.sequences[name] = { data = seqData }
    local btn = {
        seqName = name,
        seqData = seqData,
        _numExecSteps = numExecSteps,
        _attrs = { step = 1 },
    }
    function btn:GetAttribute(key)
        return self._attrs[key]
    end
    lastFire.count = 0
    lastFire.numSteps = nil
    Engine:UpdateButtonIcon(btn)
    assertEqual(1, lastFire.count, "exactly one SEQUENCE_STEP_ADVANCED fired for " .. name)
    return lastFire.numSteps
end

-- ---------------------------------------------------------------------------
-- Cases.
-- ---------------------------------------------------------------------------

test("P1: a 4-step Priority sequence expands to 10 (BuildExecutionOrder)", function()
    local seq = makeSequence("Priority")
    local ver = seq.versions[1]
    local execOrder = Engine:BuildExecutionOrder(ver.steps, ver.stepFunction)
    assertEqual(10, #execOrder, "Priority 4-step expands to a 10-entry execution order")
    assertEqual(4, #ver.steps, "the authored count is still 4 (the old, wrong denominator)")
end)

test("P2: Priority fire reports the EXPANDED 10 when the button carries the cache", function()
    local seq = makeSequence("Priority")
    local expanded = #Engine:BuildExecutionOrder(seq.versions[1].steps, "Priority")
    -- The producer sites cache exactly this: btn._numExecSteps = #compiledSteps.
    local fired = driveFire("P2_Priority", seq, expanded)
    assertEqual(10, fired, "fired numSteps is the expanded 10, NOT the authored 4")
end)

test("P3: Priority with NO cache expands rather than reporting the compiled 4", function()
    local seq = makeSequence("Priority")
    -- No _numExecSteps cache (a dormant sequence, or a button whose Execute has not yet
    -- succeeded): the no-cache path expands ver.steps through BuildExecutionOrder instead
    -- of degrading to the compiled #ver.steps, so it stays in the execution domain. Still
    -- never nil and never a Lua error. Passing nil for numExecSteps exercises the fallback.
    local fired = driveFire("P3_PriorityNoCache", seq, nil)
    assertEqual(10, fired, "no-cache path expands through BuildExecutionOrder to the execution 10, not the compiled 4")
end)

test("P4: #GetSequenceSteps(name) == fired numSteps == 10 for Priority", function()
    local seq = makeSequence("Priority")
    local expanded = #Engine:BuildExecutionOrder(seq.versions[1].steps, "Priority")
    local fired = driveFire("P4_Priority", seq, expanded)
    local steps = apiGetSequenceSteps("P4_Priority")
    assertEqual(10, #steps, "GetSequenceSteps returns the 10-entry expanded array")
    assertEqual(#steps, fired, "the accessor length and the fired denominator agree")
end)

test("P5: a DORMANT sequence (button = nil) reports the execution count", function()
    local seq = makeSequence("Priority")
    Engine.sequences["P5_Dormant"] = { button = nil, data = seq }
    local list = Engine:GetSequenceList()
    local entry
    for i = 1, #list do
        if list[i].name == "P5_Dormant" then
            entry = list[i]
        end
    end
    assert(entry ~= nil, "the dormant sequence appears in GetSequenceList")
    local steps = apiGetSequenceSteps("P5_Dormant")
    assertEqual(10, #steps, "GetSequenceSteps expands to 10 for a dormant Priority")
    assertEqual(10, entry.stepCount, "stepCount is the execution 10, not the compiled 4")
    assertEqual(#steps, entry.stepCount, "stepCount == #GetSequenceSteps (docs/api/data.md contract)")
end)

test("S1: Sequential 4-step stays 4 across expand, fire, and accessor (no regression)", function()
    local seq = makeSequence("Sequential")
    local expanded = #Engine:BuildExecutionOrder(seq.versions[1].steps, "Sequential")
    assertEqual(4, expanded, "Sequential does not expand: authored == expanded == 4")
    local fired = driveFire("S1_Sequential", seq, expanded)
    assertEqual(4, fired, "Sequential fires 4 (expanded == authored, the fix is a no-op here)")
    local steps = apiGetSequenceSteps("S1_Sequential")
    assertEqual(4, #steps, "GetSequenceSteps returns 4 for the non-expanding path")
    assertEqual(#steps, fired, "accessor length and fired denominator agree at 4")
end)

test("R1: ReversePriority 4-step expands to 10 and fires 10 (second expander)", function()
    local seq = makeSequence("ReversePriority")
    local expanded = #Engine:BuildExecutionOrder(seq.versions[1].steps, "ReversePriority")
    assertEqual(10, expanded, "ReversePriority 4-step also expands to 10")
    local fired = driveFire("R1_ReversePriority", seq, expanded)
    assertEqual(10, fired, "ReversePriority fires the expanded 10")
    assertEqual(#apiGetSequenceSteps("R1_ReversePriority"), fired, "accessor length and fired denominator agree")
end)

-- ---------------------------------------------------------------------------
-- Phase 2: _numExecSteps is written ONLY after a successful Execute, so the
-- cache always describes what is actually live in the button's restricted env.
-- These cases drive the REAL Engine:RecompileSequence -- its queued doRecompile
-- runs synchronously through the OOCQueue.Add stub -- and force the three
-- Execute outcomes via test-injected Engine.DeferIfBraced and btn.Execute:
--   D0  success -> the cache is UPDATED to the new compiled count
--   D1  defer   -> Execute is skipped, the cache RETAINS its prior value
--   D2  failure -> Execute fails, the cache RETAINS its prior value
-- D0 is the non-vacuity control: it proves the harness actually reaches the
-- cache-set, so the D1/D2 "unchanged" assertions describe a path that ran.
-- ---------------------------------------------------------------------------

-- A failed base Execute in RecompileSequence auto-recovers via Deactivate +
-- Activate; stub both to counters so D2 does not re-enter the heavy activation
-- path headless, and so the test can confirm the failure branch was taken.
local recovery = { deactivate = 0, activate = 0 }
function Engine:DeactivateSequence()
    recovery.deactivate = recovery.deactivate + 1
end
function Engine:ActivateSequence()
    recovery.activate = recovery.activate + 1
end

-- Register a Priority 4-step sequence (doRecompile expands it to 10) with a
-- button whose prior cache is a distinct sentinel (7), so "updated to 10" and
-- "retained at 7" are both distinguishable from the authored count (4).
local function makeRecompileEntry(priorCache, failExecute, stepFunction)
    local seqData = makeSequence(stepFunction or "Priority")
    local btn = {
        seqName = "RC_Seq",
        seqData = seqData,
        _numExecSteps = priorCache,
        _failExecute = failExecute,
        _attrs = { step = 1 },
    }
    function btn:GetAttribute(key)
        return self._attrs[key]
    end
    function btn:SetAttribute(key, value)
        self._attrs[key] = value
    end
    function btn:Execute()
        if self._failExecute then
            error("simulated restricted-env Execute failure")
        end
    end
    Engine.sequences["RC_Seq"] = { data = seqData, button = btn }
    return btn
end

-- Fire the event from an EXISTING button (reads its current _numExecSteps).
local function fireExistingButton(btn)
    lastFire.count = 0
    lastFire.numSteps = nil
    Engine:UpdateButtonIcon(btn)
    assertEqual(1, lastFire.count, "exactly one SEQUENCE_STEP_ADVANCED fired for " .. tostring(btn.seqName))
    return lastFire.numSteps
end

test("D0 (control): a successful recompile UPDATES the cache to the new compiled count", function()
    local btn = makeRecompileEntry(7, false)
    recovery.activate = 0
    Engine.DeferIfBraced = function()
        return false
    end
    Engine:RecompileSequence("RC_Seq")
    assertEqual(10, btn._numExecSteps, "success writes #compiledSteps (Priority 4 -> 10), replacing the prior 7")
    assertEqual(0, recovery.activate, "a successful Execute does not trigger auto-recovery")
    assertEqual(10, fireExistingButton(btn), "the fired numSteps is the freshly loaded 10")
end)

test("D1 (defer): a deferred recompile RETAINS the prior cache (Execute never ran)", function()
    local btn = makeRecompileEntry(7, false)
    Engine.DeferIfBraced = function()
        return true
    end
    Engine:RecompileSequence("RC_Seq")
    assertEqual(7, btn._numExecSteps, "defer leaves the prior 7: the new 10 was never loaded into the restricted env")
    assertEqual(7, fireExistingButton(btn), "fired numSteps still describes the live (old) steps, not the deferred 10")
end)

test("D2 (failure): a failed Execute RETAINS the prior cache", function()
    local btn = makeRecompileEntry(7, true)
    recovery.activate = 0
    Engine.DeferIfBraced = function()
        return false
    end
    Engine:RecompileSequence("RC_Seq")
    assertEqual(7, btn._numExecSteps, "a failed Execute leaves the prior 7, never the count we failed to load")
    assertTrue(recovery.activate >= 1, "the failed Execute reached the auto-recovery path (confirms Execute failed)")
    assertEqual(7, fireExistingButton(btn), "fired numSteps still describes the live (old) steps")
end)

-- ---------------------------------------------------------------------------
-- Phase 3: the button "step" attribute indexes the EXPANDED execution array, so
-- the icon/counter consumers must read it through Engine:GetExecStepText /
-- GetExecStepCount rather than ver.steps[step] / #ver.steps. These cases drive
-- the real RecompileSequence to populate btn._execSteps, then assert the helpers.
-- X1 step-3 (-> B, not C) and step-4 (-> A, not D) are the non-vacuity controls:
-- they fail against authored indexing, and X3 shows authored indexing gives C/D.
-- ---------------------------------------------------------------------------

test("X1 (Priority): the button 'step' indexes the EXPANDED array [A,A,B,A,B,C,A,B,C,D]", function()
    local btn = makeRecompileEntry(7, false, "Priority")
    Engine.DeferIfBraced = function()
        return false
    end
    Engine:RecompileSequence("RC_Seq")
    assertEqual(10, #btn._execSteps, "Priority 4-step caches a 10-entry expanded array")
    local ver = Engine:GetActiveVersion(btn.seqData)
    -- Authored [A,B,C,D] -> [A, A,B, A,B,C, A,B,C,D]; A=/cast Alpha .. D=/cast Delta.
    assertEqual("/cast Alpha", Engine:GetExecStepText(btn, 1, ver), "step 1 -> A")
    assertEqual("/cast Bravo", Engine:GetExecStepText(btn, 3, ver), "step 3 -> B, not the old C")
    assertEqual("/cast Alpha", Engine:GetExecStepText(btn, 4, ver), "step 4 -> A, not the old D")
    assertEqual("/cast Alpha", Engine:GetExecStepText(btn, 7, ver), "step 7 -> A (old: out-of-range)")
    assertEqual("/cast Delta", Engine:GetExecStepText(btn, 10, ver), "step 10 -> D (old: out-of-range)")
    assertEqual(10, Engine:GetExecStepCount(btn, ver), "denominator is the expanded 10")
end)

test("X2 (Sequential control): expanded == authored, GetExecStepText(k) == authored[k]", function()
    local btn = makeRecompileEntry(99, false, "Sequential")
    Engine.DeferIfBraced = function()
        return false
    end
    Engine:RecompileSequence("RC_Seq")
    assertEqual(4, #btn._execSteps, "Sequential does not expand: 4 authored -> 4 compiled")
    local ver = Engine:GetActiveVersion(btn.seqData)
    assertEqual("/cast Alpha", Engine:GetExecStepText(btn, 1, ver), "k=1")
    assertEqual("/cast Bravo", Engine:GetExecStepText(btn, 2, ver), "k=2")
    assertEqual("/cast Charlie", Engine:GetExecStepText(btn, 3, ver), "k=3")
    assertEqual("/cast Delta", Engine:GetExecStepText(btn, 4, ver), "k=4")
    assertEqual(4, Engine:GetExecStepCount(btn, ver), "count == 4 (no expansion regression)")
end)

test("X3 (fallback control): no-cache text AND count both sit in the execution domain", function()
    local seqData = makeSequence("Priority")
    local ver = Engine:GetActiveVersion(seqData)
    local bareBtn = {}
    -- No _execSteps -> the no-cache branch expands ver.steps through BuildExecutionOrder,
    -- so it returns the SAME text the cached branch returns (see X5). Priority [A,B,C,D]
    -- expands to [A,A,B,A,B,C,A,B,C,D], so order[3]=B (not authored C) and order[7]=A.
    assertEqual("/cast Alpha", Engine:GetExecStepText(bareBtn, 1, ver), "step 1 -> order[1]=A (== steps[1] here)")
    assertEqual("/cast Bravo", Engine:GetExecStepText(bareBtn, 3, ver), "step 3 -> order[3]=B (same as cached X1)")
    assertEqual("/cast Alpha", Engine:GetExecStepText(bareBtn, 7, ver), "step 7 -> order[7]=A (now in-range)")
    -- Both accessors now live in the execution domain: the count expands too, matching
    -- #GetSequenceSteps for a dormant sequence.
    assertEqual(
        10,
        Engine:GetExecStepCount(bareBtn, ver),
        "no-cache count expands via BuildExecutionOrder to the execution 10, not the compiled 4"
    )
    assertEqual(nil, Engine:GetExecStepText(bareBtn, 3, nil), "no ver, no cache -> nil")
    assertEqual(0, Engine:GetExecStepCount(nil, nil), "no btn, no ver -> 0")
end)

test("X4 (ReversePriority no-cache): text fallback returns the EXPANDED order[1], not authored steps[1]", function()
    local seqData = makeSequence("ReversePriority")
    local ver = Engine:GetActiveVersion(seqData)
    local order = Engine:BuildExecutionOrder(ver.steps, ver.stepFunction)
    local bareBtn = {}
    assertEqual("/cast Delta", order[1], "ReversePriority expands to [D,C,D,B,C,D,A,B,C,D]")
    assertEqual(
        "/cast Delta",
        Engine:GetExecStepText(bareBtn, 1, ver),
        "no-cache step 1 returns the execution order[1] (Delta), NOT authored steps[1] (Alpha)"
    )
    assertEqual(10, Engine:GetExecStepCount(bareBtn, ver), "no-cache count is the expanded 10")
end)

test("X5 (domain agreement): cached and no-cache GetExecStepText return the same text for every step", function()
    Engine.DeferIfBraced = function()
        return false
    end
    -- Priority: a cached button (real compiled _execSteps, built like X1) vs a bare button.
    local btn = makeRecompileEntry(7, false, "Priority")
    Engine:RecompileSequence("RC_Seq")
    local ver = Engine:GetActiveVersion(btn.seqData)
    local order = Engine:BuildExecutionOrder(ver.steps, ver.stepFunction)
    local bareBtn = {}
    for k = 1, #order do
        assertEqual(
            Engine:GetExecStepText(btn, k, ver),
            Engine:GetExecStepText(bareBtn, k, ver),
            "Priority step " .. k .. ": cached and no-cache agree"
        )
    end
    -- ReversePriority: the expander whose order[1] is the LAST authored step.
    local rpBtn = makeRecompileEntry(7, false, "ReversePriority")
    Engine:RecompileSequence("RC_Seq")
    local rpVer = Engine:GetActiveVersion(rpBtn.seqData)
    local rpOrder = Engine:BuildExecutionOrder(rpVer.steps, rpVer.stepFunction)
    local rpBare = {}
    for k = 1, #rpOrder do
        assertEqual(
            Engine:GetExecStepText(rpBtn, k, rpVer),
            Engine:GetExecStepText(rpBare, k, rpVer),
            "ReversePriority step " .. k .. ": cached and no-cache agree"
        )
    end
end)

-- ---------------------------------------------------------------------------
-- Phase 4: the accessibility "speak step on advance" label + "of Y" denominator
-- must live in the EXPANDED domain. RecompileSequence now caches an expanded
-- labels array (btn._execLabels) that Engine:GetExecStepLabel reads. These cases
-- drive the real compile and assert the label at each expanded position; L1's
-- step-3 (-> Bravo) and step-4 (-> Alpha) fail against authored indexing, which
-- L2 shows yields Charlie/Delta.
-- ---------------------------------------------------------------------------

test("L1 (Priority): the spoken label follows the EXPANDED array, and 'of Y' is expanded", function()
    local btn = makeRecompileEntry(7, false, "Priority")
    Engine.DeferIfBraced = function()
        return false
    end
    Engine:RecompileSequence("RC_Seq")
    assertEqual(10, #btn._execLabels, "Priority 4 labels expand to 10 aligned entries")
    assertEqual("Alpha", Engine:GetExecStepLabel(btn, 1), "step 1 label -> Alpha")
    assertEqual("Bravo", Engine:GetExecStepLabel(btn, 3), "step 3 label -> Bravo, not the old Charlie")
    assertEqual("Alpha", Engine:GetExecStepLabel(btn, 4), "step 4 label -> Alpha, not the old Delta")
    assertEqual("Delta", Engine:GetExecStepLabel(btn, 10), "step 10 label -> Delta")
    local ver = Engine:GetActiveVersion(btn.seqData)
    assertEqual(10, Engine:GetExecStepCount(btn, ver), "'of Y' is the expanded 10 (was 4 -> 'Step 7 of 4')")
end)

test("L2 (Sequential control): labels are 1:1 with the authored steps (no regression)", function()
    local btn = makeRecompileEntry(99, false, "Sequential")
    Engine.DeferIfBraced = function()
        return false
    end
    Engine:RecompileSequence("RC_Seq")
    assertEqual(4, #btn._execLabels, "Sequential does not expand labels")
    assertEqual("Alpha", Engine:GetExecStepLabel(btn, 1), "k=1")
    assertEqual("Charlie", Engine:GetExecStepLabel(btn, 3), "k=3 identity (authored indexing IS correct here)")
    assertEqual("Delta", Engine:GetExecStepLabel(btn, 4), "k=4")
end)

test("L3 (fallback): no _execLabels -> nil (generic 'Step X of Y'), never a wrong label", function()
    local bareBtn = {}
    assertEqual(nil, Engine:GetExecStepLabel(bareBtn, 3), "no cache -> nil, never an authored-domain label")
    assertEqual(nil, Engine:BuildExecLabels(nil, "Priority", 4), "nil labels -> nil")
    assertEqual(nil, Engine:BuildExecLabels({ "", "", "", "" }, "Priority", 4), "all-empty labels -> nil")
    -- A registered plugin expander reorders by macrotext CONTENT, so its label mapping
    -- cannot be recovered -> nil (the handler then speaks the generic "Step X of Y").
    SF:RegisterStepFunction("l3plugin", {
        id = "l3plugin",
        name = "L3 Plugin",
        Expand = function(_, texts)
            return texts
        end,
    })
    assertEqual(nil, Engine:BuildExecLabels({ "A", "B" }, "l3plugin", 2), "plugin expander -> nil (unrecoverable)")
end)

-- ---------------------------------------------------------------------------
-- Pass 15b: the versions-shape head check on Engine:GetActiveVersion. This file
-- loads the REAL Engine/Engine.lua, which is why the case lives here: the
-- malformed-entry suite (Test/test_malformed_entry_guards.lua) drives
-- GE.BuildExportList through an Engine STUB, so its W24 rows cannot pin the
-- real function no matter how many shapes they run.
-- ---------------------------------------------------------------------------

test("G1 (versions shape): GetActiveVersion resolves a scalar versions to nil and never indexes it", function()
    -- Corrupt data (bad import, hand-edited SavedVariables) can leave a scalar
    -- in seqData.versions. This function is the single indirection point for
    -- version access and INDEXES that field at four sites; the head check at
    -- what was Engine.lua:621 in the PRE-FIX tree -- that number is a frozen
    -- quote from the pre-fix run and is deliberately NOT swept; the check now
    -- lives at Engine.lua:735 -- was bare truthiness, so all four ran against a
    -- non-table.
    -- Measured before the fix: "attempt to index field 'versions' (a number
    -- value)" / "(a boolean value)" at the default resolution. A string is the
    -- tolerant shape -- it indexes to nil through the string metatable -- so a
    -- length check would not model this field either.
    --
    -- Blast radius, and why a nil answer matters rather than merely not
    -- raising: GE.BuildExportList (Import/ExportPreview.lua:43) resolves the
    -- active version for EVERY stored sequence, so one corrupt entry failed the
    -- whole export dialog before its own row was reached.
    for _, shape in ipairs({ 42, true, "text" }) do
        local seqData = { name = "G1Seq", defaultVersion = 1, versions = shape }
        local ok, ver = pcall(Engine.GetActiveVersion, Engine, seqData)
        assertTrue(ok, "GetActiveVersion raised on versions=" .. type(shape) .. ": " .. tostring(ver))
        assertEqual(nil, ver, "a scalar versions resolves to no active version for " .. type(shape))
    end

    -- The PIN read at Engine.lua:744 indexes the same field two guards earlier
    -- than the default resolution, so a pinned sequence took the raise first.
    -- The head check covers it by construction; this row proves that.
    local okPin, verPin = pcall(Engine.GetActiveVersion, Engine, { versions = 42, pinnedVersion = 1 })
    assertTrue(okPin, "GetActiveVersion raised on a PINNED scalar versions: " .. tostring(verPin))
    assertEqual(nil, verPin, "a pinned scalar versions still resolves to nil")

    -- ABSENT must keep working unchanged: nil is the answer this function
    -- already gave for a missing versions field, so no caller sees a new shape.
    assertEqual(nil, Engine:GetActiveVersion({ name = "G1Seq" }), "an absent versions still resolves to nil")
    assertEqual(nil, Engine:GetActiveVersion(nil), "a nil seqData still resolves to nil")

    -- CONTROL on a non-zero observable: a real versions table must still
    -- resolve, and resolve to the RIGHT version, so the nils above are not what
    -- this function returns for everything.
    local seqData = makeSequence("Sequential")
    local verC = Engine:GetActiveVersion(seqData)
    assertTrue(verC ~= nil, "the control resolves an active version")
    assertEqual(4, #verC.steps, "the control resolved the version carrying all four steps")

    -- CONTROL-FALSIFY: defaultVersion drives the choice, so a two-version
    -- sequence pointing at version 2 must return version 2 and not version 1.
    local twoVer = {
        name = "G1Two",
        defaultVersion = 2,
        versions = {
            { steps = { "/cast Alpha" }, stepFunction = "Sequential" },
            { steps = { "/cast Bravo", "/cast Charlie" }, stepFunction = "Sequential" },
        },
    }
    local verF = Engine:GetActiveVersion(twoVer)
    assertEqual(2, #verF.steps, "control-falsify: defaultVersion 2 resolves the SECOND version")
    assertEqual("/cast Bravo", verF.steps[1], "control-falsify: and it is really version 2's step list")
end)

-- ---------------------------------------------------------------------------
-- Pass 15j: the FIVE .versions guards in Engine/Engine.lua.
--
-- WHY THEY LIVE HERE, and it is exactly the reason G1's note above gives: THIS
-- file loads the REAL Engine/Engine.lua. Test/test_malformed_entry_guards.lua
-- never does -- every .versions read it resolves goes through an Engine STUB,
-- so no fixture there can pin a real Engine function no matter how many shapes
-- it runs. W26's note in that file recorded these five as a "probable next
-- candidate" with an explicit instruction to MEASURE first rather than assume
-- that "the module is loaded" means "the guard is reachable". Measured:
--
--   :2724  Engine:UpdateSequenceData   REACHABLE  -> E1
--   :2983  Engine:HealLocaleSteps      REACHABLE  -> E2
--   :3068  Engine:HealOverrideSteps    REACHABLE  -> E3
--   :3201  Engine:DuplicateSequence    REACHABLE  -> E4
--   :1407  Engine:ActivateSequence     NOT FALSIFIABLE -- stays SOURCE-ONLY
--
-- :1407 IS A LOOK-ALIKE, the same class W26 records for GRIPExport :1120 and
-- ImportPreview :515, and it is left source-only rather than given a fixture
-- that would be green for the wrong reason. The line reads
--     if resolvedVer and type(sequenceData.versions) == "table" then
-- and resolvedVer is Engine:GetActiveVersion(sequenceData), assigned two lines
-- above at :1405. That function's own head check (Engine.lua:735, pinned by G1)
-- already returns nil for EVERY non-table versions, so the FIRST operand is
-- false in precisely the cases where the second one would matter. Reverting the
-- type() test alone therefore changes no observable -- measured green on
-- 2026-07-28, the whole file still 20 passed / 0 failed. A second and
-- independent reason: this file replaces Engine.ActivateSequence with the
-- counter stub at line 363 (D2's auto-recovery path needs it), so no case here
-- reaches :1407 at all. Both would have to be undone, and undoing them would
-- still leave the guard unfalsifiable.
--
-- E1 to E4 each drive the PUBLIC entry point with versions = nil, 5, true,
-- 'abc', {} and a real one-version table, and each asserts the observable the
-- function is FOR. A case that only asserted "did not raise" would pass while
-- the function silently did nothing, so every row also pins what the walk
-- actually did: which version table reached the locale normaliser (E1), the
-- healed step text and advanced stepsLocale on the well-formed NEIGHBOUR in the
-- same store (E2, E3), and the copied version array handed to activation (E4).
--
-- STUB AUDIT, in the form the guards harness keeps at
-- Test/test_malformed_entry_guards.lua:96. It lives here because these stubs
-- live here: they are installed and REMOVED inside the cases that need them, so
-- no case above this point ever observes one.
--
--   GRIPEMS.SpellCache  ready = true. NormalizeVersionLocale COUNTS its calls
--                       and records the version table it was handed;
--                       TranslateMacrotext returns "HEALED:" or "OVERRIDE:"
--                       (chosen by opts.useOverrides) prefixed to its input and
--                       mode; TagSteps returns "TAG:" prefixed to each step.
--                       LIVE: the real spell-tag translator and locale
--                       normaliser, resolving names against the spell cache.
--                       DIFFERS in BEHAVIOUR -- no real spell name is ever
--                       resolved -- so no case below asserts on a translation
--                       being CORRECT, only on WHICH versions the walk visited
--                       and that it wrote back. It does not mask the guards
--                       E1/E2/E3 pin: all three walks dereference
--                       seqData.versions BEFORE any SpellCache method is
--                       called, so reverting the guard still raises first.
--   env.GRIP_EMS_CHAR   a real { sequences = {...} } table for E2 and E3,
--                       rawset into the sandbox env and rawset back to nil
--                       after. LIVE: the per-character SavedVariables table.
--                       MATCHES in SHAPE. Required, not cosmetic: without it
--                       env.__index hands back the catch-all stub, which is
--                       TRUTHY, so Engine.lua:2973 / :3058 pass their own
--                       "not GRIP_EMS_CHAR.sequences" guard and then walk
--                       pairs(stub) -- which is EMPTY. That is the inert-stub
--                       failure mode this block exists to prevent: green, and
--                       nothing ran.
--   env.GetLocale       "enUS", for E2 only. LIVE: the client locale string.
--                       MATCHES in type. Also required rather than cosmetic:
--                       HealLocaleSteps ends in
--                       string.format("... from %s.", currentLocale) and Lua
--                       5.1's %s raises on the catch-all stub table.
--   D.CopyVersion       for E4: a shallow copy with a fresh steps array,
--                       mirroring the container-copy contract of the real
--                       Data/Defaults.lua:3989. LIVE: the real function, which
--                       also deep-copies actions, resetModifiers, taggedSteps,
--                       stepLabels, compiledLabels and variantOverrides.
--                       DIFFERS -- E4 asserts only that the copy is a DIFFERENT
--                       table carrying the same steps, which both satisfy.
--
-- RUNNING TOTAL for the forty-five .versions guards the 15c-15e arc shipped,
-- restated here so it is not only in the guards file:
--   TWENTY of forty-five behaviourally proven -- sixteen from
--   Test/test_malformed_entry_guards.lua (W27 to W31) plus the four E-cases
--   below. TWENTY-FIVE source-only, split seven / eighteen: seven whose module
--   a harness loads but which are unfalsifiable or out of reach for a measured
--   reason (RepairAnalyzer :397, :404, :439; GRIPExport :1120;
--   ImportPreview :515 and :1331; Engine :1407), and eighteen in files no
--   harness loads (Core/Core.lua x3, Core/PublicAPI.lua x1,
--   Data/SpellCache.lua x3, and eleven across the five UI files).
-- The full per-guard tally stays in the note at the head of W26 in the guards
-- file; do not keep a second copy of it here.
-- ---------------------------------------------------------------------------

-- nil cannot be an ipairs element, so the shapes are carried as ROWS and read
-- off .value -- an absent key yields nil, which IS the first shape. An empty
-- TABLE is the sixth row for the same reason W27 carries it: it is not a shape
-- confusion, it is the other half of what these walks must tolerate.
local ENGINE_SHAPES = {
    { label = "nil" },
    { label = "number", value = 5 },
    { label = "boolean", value = true },
    { label = "string", value = "abc" },
    { label = "empty table", value = {} },
}

--- Install the counting SpellCache stub described in the STUB AUDIT above and
--- return the record it writes into. Paired with removeSpellCache().
local function installSpellCache()
    local seen = { normalize = 0, versions = {} }
    GRIPEMS.SpellCache = {
        ready = true,
        NormalizeVersionLocale = function(_, version)
            seen.normalize = seen.normalize + 1
            seen.versions[seen.normalize] = version
        end,
        TranslateMacrotext = function(_, text, mode, opts)
            local prefix = (opts and opts.useOverrides) and "OVERRIDE:" or "HEALED:"
            return prefix .. tostring(text) .. ":" .. tostring(mode)
        end,
        TagSteps = function(_, steps)
            local out = {}
            for i, s in ipairs(steps or {}) do
                out[i] = "TAG:" .. tostring(s)
            end
            return out
        end,
    }
    return seen
end

local function removeSpellCache()
    GRIPEMS.SpellCache = nil
end

-- A button of the shape RecompileSequence and the in-place attribute refresh
-- expect. Same construction as makeRecompileEntry above, without registering.
local function makeBareButton(name)
    local btn = { seqName = name, _attrs = { step = 1 } }
    function btn:GetAttribute(key)
        return self._attrs[key]
    end
    function btn:SetAttribute(key, value)
        self._attrs[key] = value
    end
    function btn:Execute() end
    return btn
end

test("E1 (Engine.lua:2724): UpdateSequenceData saves every versions shape and normalizes only real ones", function()
    -- THE HIGHEST-VALUE OF THE FIVE. This is the SAVE path: the editor, the
    -- quick persists, the version bar and set-default all land here, so a raise
    -- on the locale re-tag walk loses the user's edit rather than merely
    -- degrading a display. The walk sits at :2724, ahead of every branch that
    -- decides between an in-place update and a full rebuild.
    for _, row in ipairs(ENGINE_SHAPES) do
        local seen = installSpellCache()
        local name = "E1_" .. row.label
        local btn = makeBareButton(name)
        Engine.sequences[name] = { data = { name = name, defaultVersion = 1, versions = {} }, button = btn }
        local seqData = { name = name, defaultVersion = 1, versions = row.value }
        local ok, err = pcall(Engine.UpdateSequenceData, Engine, name, seqData)
        -- Restore BEFORE asserting: the runner pcalls each case, so a failing
        -- assertion aborts this one and a leaked SpellCache would then be
        -- observed by every case after it.
        removeSpellCache()
        local tag = " for versions=" .. row.label
        assertTrue(ok, "UpdateSequenceData raised" .. tag .. ": " .. tostring(err))
        -- NOT merely "it returned". The save LANDED.
        assertTrue(Engine.sequences[name].data == seqData, "the new seqData was stored in place" .. tag)
        assertTrue(seqData.updatedAt ~= nil, "the save stamped updatedAt" .. tag)
        assertEqual(0, seen.normalize, "no version reached the locale normaliser" .. tag)
    end

    -- CONTROL: a REAL one-version table must reach the normaliser exactly once,
    -- and be the SAME table -- so the zeroes above are not what this walk
    -- reports for everything.
    local name = "E1_control"
    local btn = makeBareButton(name)
    Engine.sequences[name] = { data = { name = name, defaultVersion = 1, versions = {} }, button = btn }
    local seqData = makeSequence("Sequential")
    seqData.name = name
    local seen = installSpellCache()
    local before = recovery.activate
    local ok, err = pcall(Engine.UpdateSequenceData, Engine, name, seqData)
    local count, first = seen.normalize, seen.versions[1]
    removeSpellCache()
    assertTrue(ok, "UpdateSequenceData raised on the well-formed control: " .. tostring(err))
    assertEqual(1, count, "the one real version reached the locale normaliser exactly once")
    assertTrue(first == seqData.versions[1], "and it was THAT version table, not a copy")
    -- CONTROL-FALSIFY on a second, independent observable: 0 authored steps ->
    -- 4 is a step-count change, so the save must take the full-rebuild branch.
    assertTrue(recovery.activate > before, "the step-count change drove the full rebuild")
end)

test("E2 (Engine.lua:2983): HealLocaleSteps walks a store holding every versions shape", function()
    -- Fired on SPELL_CACHE_REFRESHED after a client locale change, over EVERY
    -- stored sequence with no pcall between them -- so before the guard a single
    -- corrupt entry took the whole heal down and every well-formed sequence in
    -- the store silently kept its stale-locale steps.
    for _, row in ipairs(ENGINE_SHAPES) do
        local seen = installSpellCache()
        rawset(env, "GetLocale", function()
            return "enUS"
        end)
        local good = {
            name = "E2Good",
            defaultVersion = 1,
            versions = {
                {
                    stepFunction = "Sequential",
                    steps = { "/cast Alpha" },
                    taggedSteps = { "T1" },
                    stepsLocale = "deDE",
                },
            },
        }
        rawset(env, "GRIP_EMS_CHAR", {
            sequences = {
                E2Bad = { name = "E2Bad", defaultVersion = 1, versions = row.value },
                E2Good = good,
            },
        })
        local ok, err = pcall(Engine.HealLocaleSteps, Engine)
        rawset(env, "GRIP_EMS_CHAR", nil)
        rawset(env, "GetLocale", nil)
        removeSpellCache()
        local tag = " for versions=" .. row.label
        assertTrue(ok, "HealLocaleSteps raised" .. tag .. ": " .. tostring(err))
        assertEqual(0, seen.normalize, "this path does not use the normaliser" .. tag)
        local ver = good.versions[1]
        -- THE OBSERVABLE: the NEIGHBOUR in the same store was really healed.
        assertEqual("HEALED:T1:toNames", ver.steps[1], "the neighbour's step was healed from its tag" .. tag)
        assertEqual("enUS", ver.stepsLocale, "the neighbour's stepsLocale advanced to the client locale" .. tag)
        assertEqual("/cast Alpha", (ver.stepsOriginal or {})[1], "the pre-heal author text was preserved" .. tag)
        assertEqual("TAG:HEALED:T1:toNames", (ver.taggedSteps or {})[1], "the neighbour was re-tagged" .. tag)
    end

    -- CONTROL-FALSIFY: a version ALREADY in the client locale must not be
    -- touched, so the rows above cannot be passing through a walk that heals
    -- unconditionally.
    installSpellCache()
    rawset(env, "GetLocale", function()
        return "enUS"
    end)
    local fresh = {
        name = "E2Fresh",
        defaultVersion = 1,
        versions = {
            { stepFunction = "Sequential", steps = { "/cast Alpha" }, taggedSteps = { "T1" }, stepsLocale = "enUS" },
        },
    }
    rawset(env, "GRIP_EMS_CHAR", { sequences = { E2Fresh = fresh } })
    local okF, errF = pcall(Engine.HealLocaleSteps, Engine)
    rawset(env, "GRIP_EMS_CHAR", nil)
    rawset(env, "GetLocale", nil)
    removeSpellCache()
    assertTrue(okF, "the falsify control raised: " .. tostring(errF))
    assertEqual("/cast Alpha", fresh.versions[1].steps[1], "control-falsify: an in-locale version is left alone")
    assertEqual(nil, fresh.versions[1].stepsOriginal, "control-falsify: and no original was snapshotted")
end)

test("E3 (Engine.lua:3068): HealOverrideSteps walks a store holding every versions shape", function()
    -- Fired on PLAYER_SPECIALIZATION_CHANGED / TRAIT_CONFIG_UPDATED, same
    -- whole-store shape as E2: one corrupt entry used to cost every other
    -- sequence its talent-override re-translation.
    for _, row in ipairs(ENGINE_SHAPES) do
        local seen = installSpellCache()
        local good = {
            name = "E3Good",
            defaultVersion = 1,
            versions = {
                { stepFunction = "Sequential", steps = { "/cast Alpha" }, taggedSteps = { "T1" } },
            },
        }
        rawset(env, "GRIP_EMS_CHAR", {
            sequences = {
                E3Bad = { name = "E3Bad", defaultVersion = 1, versions = row.value },
                E3Good = good,
            },
        })
        local ok, err = pcall(Engine.HealOverrideSteps, Engine)
        rawset(env, "GRIP_EMS_CHAR", nil)
        removeSpellCache()
        local tag = " for versions=" .. row.label
        assertTrue(ok, "HealOverrideSteps raised" .. tag .. ": " .. tostring(err))
        assertEqual(0, seen.normalize, "this path does not use the normaliser" .. tag)
        -- THE OBSERVABLE: the neighbour's step really was re-translated, and
        -- through the OVERRIDE arm (opts.useOverrides), not the plain one.
        assertEqual(
            "OVERRIDE:T1:toNames",
            good.versions[1].steps[1],
            "the neighbour's step was re-translated with overrides applied" .. tag
        )
    end

    -- CONTROL-FALSIFY: a version with NO taggedSteps carries nothing to
    -- re-translate and must come back untouched.
    installSpellCache()
    local plain = {
        name = "E3Plain",
        defaultVersion = 1,
        versions = { { stepFunction = "Sequential", steps = { "/cast Alpha" } } },
    }
    rawset(env, "GRIP_EMS_CHAR", { sequences = { E3Plain = plain } })
    local okF, errF = pcall(Engine.HealOverrideSteps, Engine)
    rawset(env, "GRIP_EMS_CHAR", nil)
    removeSpellCache()
    assertTrue(okF, "the falsify control raised: " .. tostring(errF))
    assertEqual("/cast Alpha", plain.versions[1].steps[1], "control-falsify: an untagged version is left alone")
end)

test("E4 (Engine.lua:3201): DuplicateSequence copies every versions shape without raising", function()
    -- The deep-copy loop that builds the duplicate's version array. Everything
    -- is restored in one place at the bottom, including on failure, because
    -- both overrides installed here are read by cases OTHER than this one.
    local D = GRIPEMS.Defaults
    local savedActivate = Engine.ActivateSequence
    local savedCopy = D.CopyVersion
    local captured = {}

    D.CopyVersion = function(ver)
        if type(ver) ~= "table" then
            return {}
        end
        local copy = {}
        for k, v in pairs(ver) do
            copy[k] = v
        end
        if type(ver.steps) == "table" then
            copy.steps = {}
            for i, s in ipairs(ver.steps) do
                copy.steps[i] = s
            end
        end
        return copy
    end
    -- ActivateSequence is the counter stub from line 363 by this point, and it
    -- discards its arguments -- so the duplicate would be unobservable. Swap in
    -- a capturing stub of the same class for the length of this case.
    Engine.ActivateSequence = function(_, activateName, activateData)
        captured.name = activateName
        captured.data = activateData
    end

    local function run()
        for _, row in ipairs(ENGINE_SHAPES) do
            local src, dst = "E4Src_" .. row.label, "E4Dst_" .. row.label
            Engine.sequences[src] = { data = { name = src, defaultVersion = 1, versions = row.value } }
            captured.name, captured.data = nil, nil
            local ok, res = pcall(Engine.DuplicateSequence, Engine, src, dst)
            local tag = " for versions=" .. row.label
            assertTrue(ok, "DuplicateSequence raised" .. tag .. ": " .. tostring(res))
            assertEqual(true, res, "the duplicate reported success" .. tag)
            -- NOT merely "it returned". The copy reached activation, under the
            -- new name, carrying a versions TABLE whatever the source held.
            assertEqual(dst, captured.name, "the duplicate was activated under the new name" .. tag)
            assertEqual("table", type(captured.data.versions), "the duplicate carries a versions table" .. tag)
            assertEqual(0, #captured.data.versions, "no version was copyable from a malformed source" .. tag)
        end

        -- CONTROL: a REAL one-version source must be copied, so the empty
        -- arrays above are not what this function produces for everything.
        local src, dst = "E4Src_control", "E4Dst_control"
        Engine.sequences[src] = makeSequence("Sequential")
        Engine.sequences[src] = { data = Engine.sequences[src] }
        captured.name, captured.data = nil, nil
        local ok, res = pcall(Engine.DuplicateSequence, Engine, src, dst)
        assertTrue(ok, "DuplicateSequence raised on the well-formed control: " .. tostring(res))
        assertEqual(1, #captured.data.versions, "the control copied exactly one version")
        assertEqual(4, #captured.data.versions[1].steps, "and that version carries all four steps")
        assertEqual("/cast Alpha", captured.data.versions[1].steps[1], "with the source's step text")
        -- CONTROL-FALSIFY: a duplicate that ALIASED the source would satisfy
        -- every assertion above, and would be the forgery-adjacent bug this
        -- loop exists to avoid.
        local srcVer = Engine.sequences[src].data.versions[1]
        assertTrue(captured.data.versions[1] ~= srcVer, "control-falsify: the copy is a NEW table, not the source's")
        assertTrue(captured.data.versions[1].steps ~= srcVer.steps, "control-falsify: and so is its steps array")
    end

    local okAll, errAll = pcall(run)
    Engine.ActivateSequence = savedActivate
    D.CopyVersion = savedCopy
    if not okAll then
        error(errAll, 0)
    end
end)

-- ---------------------------------------------------------------------------
-- Pass 15t: the FOUR step-entry truthiness gates in Engine/Engine.lua.
--
-- WHY THE CASE LIVES HERE. Same reason G1 and E1-E4 give: this file loads the
-- REAL Engine/Engine.lua. Test/test_malformed_entry_guards.lua explicitly never
-- does -- see its own note at :216 -- so a fixture there could not drive these
-- four no matter how many shapes it ran.
--
-- WHY ONE OF THE FOUR WAS NEVER ON ANY LIST. Engine:CompileSteps opened with
-- "if not steps then". That line carries no "#", no field name and no length
-- operator, so every one of the census's nine shapes -- BARE_NOTLEN, BARE_LEN,
-- BARE_PAREN and the field-keyed family -- is structurally blind to it. The
-- other three were in the eight-item .steps residue and were left as NOT FIXED.
--
-- MEASURED at 914109d, one pcall per shape against the real Engine.lua, before
-- any guard landed:
--   CompileSteps(5) / (true)          :162  length of local 'steps'
--   CompileSteps("abc")               :163  bad argument #1 to 'ipairs'
--   BuildExecutionOrder(5) / (true)   :254  length of local 'steps'
--   BuildExecutionOrder("abc")        :263  bad argument #1 to 'ipairs'
--   SimulateSteps(5) / (true)         :307  length of local 'steps'
--   SimulateSteps("abc")              :263  via BuildExecutionOrder
--   BuildExecuteString(5) / (true)    :459  length of local 'compiledSteps'
--   BuildExecuteString("abc")         :463  bad argument #1 to 'ipairs'
-- THREE shapes raise per entry point, not two. The string is why the fix is a
-- type test and not a tightened truthiness test: "#" on a string is legal and
-- returns its byte length, so a string sails past any length test and dies at
-- the ipairs one line later.
--
-- ONE MEASURED ASYMMETRY, recorded because it changes what a single-guard
-- revert proves. The string row for SimulateSteps raised at 914109d only
-- because BuildExecutionOrder was unguarded too. With EDIT 5 alone reverted the
-- upstream guard absorbs the string and SimulateSteps("abc") returns cleanly --
-- so that revert reddens on the number and boolean rows and NOT on the string.
-- The other three entry points own all three of their shapes outright.
--
-- The rows assert the RETURN SHAPE, not merely the absence of a raise: a guard
-- that returned nil would satisfy a pcall-only case. The TABLE CONTROL at the
-- bottom is what stops all of it passing against a head that returned early
-- unconditionally, and the nil row pins the one shape the old truthiness gates
-- already absorbed as unchanged.
-- ---------------------------------------------------------------------------

local ENTRY_SHAPES = {
    { label = "number", value = 5 },
    { label = "boolean", value = true },
    { label = "string", value = "abc" },
}

local EMPTY_EXEC_STRING = "steps = newtable()\nnumSteps = 0\n"

test("T1 (step-entry shapes): the four Engine step entry points absorb every scalar", function()
    for _, row in ipairs(ENTRY_SHAPES) do
        local tag = " for steps=" .. row.label

        -- CompileSteps -- the site no census pattern could see.
        local csOk, csRes = pcall(Engine.CompileSteps, Engine, row.value, "", "")
        assertTrue(csOk, "CompileSteps raised" .. tag .. ": " .. tostring(csRes))
        assertEqual("table", type(csRes), "CompileSteps returns a table" .. tag)
        assertEqual(0, #csRes, "CompileSteps compiles zero steps" .. tag)

        -- BuildExecutionOrder -- both returns are pinned, not just the first.
        local beoOk, beoOrder, beoRandom = pcall(Engine.BuildExecutionOrder, Engine, row.value, "Sequential")
        assertTrue(beoOk, "BuildExecutionOrder raised" .. tag .. ": " .. tostring(beoOrder))
        assertEqual("table", type(beoOrder), "BuildExecutionOrder returns a table" .. tag)
        assertEqual(0, #beoOrder, "BuildExecutionOrder returns an empty order" .. tag)
        assertEqual(false, beoRandom, "BuildExecutionOrder still reports isRandom = false" .. tag)

        -- SimulateSteps -- the icon-strip preview path.
        local simOk, simRes = pcall(Engine.SimulateSteps, Engine, row.value, "Sequential", 5)
        assertTrue(simOk, "SimulateSteps raised" .. tag .. ": " .. tostring(simRes))
        assertEqual("table", type(simRes), "SimulateSteps returns a table" .. tag)
        assertEqual(0, #simRes, "SimulateSteps simulates zero steps" .. tag)

        -- BuildExecuteString -- the restricted-env payload builder.
        local besOk, besRes = pcall(Engine.BuildExecuteString, Engine, row.value)
        assertTrue(besOk, "BuildExecuteString raised" .. tag .. ": " .. tostring(besRes))
        assertEqual("string", type(besRes), "BuildExecuteString returns a string" .. tag)
        assertEqual(EMPTY_EXEC_STRING, besRes, "BuildExecuteString returns the empty-steps payload" .. tag)
    end

    -- NIL, pinned as UNCHANGED. The old truthiness gates already absorbed it,
    -- so no caller may see a new shape because the test tightened.
    local nilOk, nilRes = pcall(Engine.CompileSteps, Engine, nil, "", "")
    assertTrue(nilOk, "CompileSteps raised for steps=nil: " .. tostring(nilRes))
    assertEqual("table", type(nilRes), "CompileSteps still returns a table for steps=nil")
    assertEqual(0, #nilRes, "CompileSteps still compiles zero steps for steps=nil")

    -- TABLE CONTROL, LAST and able to fail. Without it every row above is
    -- satisfied by a head that returned early unconditionally.
    local ctlSteps = { "/cast Alpha" }
    local ctlCompiled = Engine:CompileSteps(ctlSteps, "", "")
    assertEqual(1, #ctlCompiled, "control: CompileSteps compiles the one authored step")
    assertEqual("/cast Alpha", ctlCompiled[1].macrotext, "control: and carries its macrotext")

    local ctlOrder, ctlRandom = Engine:BuildExecutionOrder(ctlSteps, "Sequential")
    assertEqual(1, #ctlOrder, "control: BuildExecutionOrder returns a non-empty order")
    assertEqual("/cast Alpha", ctlOrder[1], "control: and it is the resolved step text")
    assertEqual(false, ctlRandom, "control: Sequential is not random")

    local ctlSim = Engine:SimulateSteps(ctlSteps, "Sequential", 5)
    assertEqual(5, #ctlSim, "control: SimulateSteps returns one entry per simulated keypress")

    local ctlExec = Engine:BuildExecuteString(ctlCompiled)
    assertTrue(ctlExec ~= EMPTY_EXEC_STRING, "control: BuildExecuteString does not return the empty payload")
    assertTrue(ctlExec:find("numSteps = 1", 1, true) ~= nil, "control: and it reports the one compiled step")
end)

-- ---------------------------------------------------------------------------
-- Run.
-- ---------------------------------------------------------------------------

local passed = 0
local failed = 0
for _, t in ipairs(tests) do
    local ok, err = pcall(t.fn)
    if ok then
        passed = passed + 1
        print("PASS  " .. t.name)
    else
        failed = failed + 1
        print("FAIL  " .. t.name .. " -- " .. tostring(err))
    end
end
print(string.format("RESULT %d passed, %d failed", passed, failed))
os.exit(failed > 0 and 1 or 0)
