-- GRIP-EMS: English Locale (Default)
-- All user-facing strings. L["key"] = true means display text equals the key.

local L = LibStub("AceLocale-3.0"):NewLocale("GRIP-EMS", "enUS", true)
if not L then
    return
end

-- General
L["GRIP - Enhanced Macro Sequencer"] = true

-- Slash command help
L["GEMS_HELP_HEADER"] = "Available commands:"
L["GEMS_HELP_NONE"] = "  /gems - Open main window (or show help if UI not loaded)"
L["GEMS_HELP_HELP"] = "  /gems help - This help message"
L["GEMS_HELP_CREATE"] = "  /gems create [name] - Create a test sequence (default: TestSeq)"
L["GEMS_HELP_DELETE"] = "  /gems delete <name> - Delete a sequence and its macro stub"
L["GEMS_HELP_LIST"] = "  /gems list - List all active sequences"
L["GEMS_HELP_TEST"] = "  /gems test <name> - Advance step manually (debug)"
L["GEMS_HELP_RESET"] = "  /gems reset <name> - Reset sequence to step 1"
L["GEMS_HELP_DEBUG"] = "  /gems debug - Toggle debug mode"
L["GEMS_HELP_STATUS"] = "  /gems status - Show engine status"
L["GEMS_HELP_TESTLOCALE"] = "  /gems testlocale - Run locale translation round-trip test"
L["GEMS_HELP_TESTSPELLID"] = "  /gems testspellid - Run spell ID resolution tests"

-- Slash command responses
L["GEMS_VERSION"] = "|cFF00CC66GRIP|r - Enhanced Macro Sequencer |cFFAAAAAAv%s|r"
L["GEMS_DEBUG_ENABLED"] = "Debug mode |cFF00FF00enabled|r."
L["GEMS_DEBUG_DISABLED"] = "Debug mode |cFFFF4444disabled|r."
L["GEMS_UNKNOWN_CMD"] = "Unknown command '%s'. Type /gems help for available commands."

-- Sequence creation/deletion
L["GEMS_CREATED"] = "Sequence |cFF00FF00'%s'|r created with %d steps (%s)."
L["GEMS_DELETED"] = "Sequence |cFF00FF00'%s'|r deleted."
L["GEMS_ALREADY_EXISTS"] = "Sequence '%s' already exists. Delete it first with /gems delete %s"
L["GEMS_NOT_FOUND"] = "Sequence '%s' not found."
L["GEMS_DELETE_NEED_NAME"] = "Usage: /gems delete <name>"

-- Sequence list
L["GEMS_LIST_HEADER"] = "Active sequences (%d):"
L["GEMS_LIST_ENTRY"] = "  |cFF00FF00%s|r - %d steps, step %d/%d (%s)"
L["GEMS_LIST_EMPTY"] = "No active sequences. Use /gems create to make one."

-- Sequence test/reset
L["GEMS_TEST_NEED_NAME"] = "Usage: /gems test <name>"
L["GEMS_TEST_ADVANCED"] = "|cFF00FF00%s|r: advanced to step %d/%d."
L["GEMS_RESET_NEED_NAME"] = "Usage: /gems reset <name>"
L["GEMS_RESET_DONE"] = "|cFF00FF00%s|r: reset to step 1."

-- Status
L["GEMS_STATUS_HEADER"] = "--- GRIP-EMS Status ---"
L["GEMS_STATUS_SEQUENCES"] = "Active sequences: %d"
L["GEMS_STATUS_MACROS"] = "Macro slots: %d/%d per-character used"
L["GEMS_STATUS_KEYDOWN"] = "ActionButtonUseKeyDown: %s (buttons override: true)"
L["GEMS_STATUS_SQW"] = "SpellQueueWindow: %s ms"
L["GEMS_STATUS_OOC"] = "OOC queue: %d pending"

-- Step function descriptions
L["GEMS_STEPFUNC_SEQUENTIAL_DESC"] = "Cycles through steps in order: 1, 2, 3, ..., N, 1, ..."
L["GEMS_STEPFUNC_RANDOM_DESC"] = "Picks a random step each press"
L["GEMS_STEPFUNC_PRIORITY_DESC"] = "Pre-expanded priority: higher steps appear more often (weighted round-robin)"
L["GEMS_STEPFUNC_REVERSEPRIORITY_DESC"] =
    "Inverted priority: later steps (bottom of list) fire more often than earlier ones"

-- Validation errors
L["GEMS_STEP_TOO_LONG"] = "Step %d exceeds macrotext limit (%d chars, max %d)."
L["GEMS_STEP_NIL"] = "Step %d is nil."
L["GEMS_ERR_NO_NAME"] = "Sequence name is required."

-- Macro manager
L["GEMS_ERR_NO_MACRO_SLOTS"] = "No available macro slots (%d/%d per-character macros used)."
L["GEMS_ERR_MACRO_CREATE_FAILED"] = "Failed to create macro stub for sequence '%s'."
L["GEMS_MACRO_CREATED"] = "Macro stub '%s' created (slot %d)."
L["GEMS_MACROS_SCANNED"] = "Reclaimed %d existing GRIP-EMS macro stubs."
L["GEMS_WARN_KP_LINES_TRIMMED"] = "keyPress: %d of %d lines fit in macro stub (255-char limit)"
L["GEMS_WARN_KR_LINES_TRIMMED"] = "keyRelease: %d of %d lines fit in macro stub (255-char limit)"
L["GEMS_WARN_KP_STEP_OVERFLOW"] = "keyPress: fits in %d/%d steps (%d steps run without keyPress due to 255-char limit)"
L["GEMS_KP_STATUS_ALL_FIT"] = "Fits in all %d steps"
L["GEMS_KP_STATUS_PARTIAL"] = "Fits in %d/%d steps (255-char limit)"
L["GEMS_KP_STATUS_NONE"] = "Too long for any step (0/%d)"

-- OOC Queue
L["GEMS_OOC_QUEUED"] = "Operation queued for out-of-combat processing."
L["GEMS_OOC_PROCESSED"] = "Processed %d queued operations."
L["GEMS_OOC_REPLACED"] = "OOC Queue: replaced %s for %s"
L["GEMS_OOC_PRIORITY_PROCESSED"] = "OOC Queue: processed %d items (priority order)"

-- Keybind manager
L["GEMS_HELP_BIND"] = "  /gems bind <name> <key> - Bind a key to fire a sequence (e.g. CTRL-F12)"
L["GEMS_HELP_UNBIND"] = "  /gems unbind <name> - Remove keybinding from a sequence"
L["GEMS_HELP_BINDS"] = "  /gems binds - List all keybindings for current spec"
L["GEMS_BIND_SUCCESS"] = "Bound |cFF00FF00'%s'|r to |cFFFFFF00%s|r. Press the key to fire the sequence."
L["GEMS_BIND_NEED_ARGS"] = "Usage: /gems bind <name> <key> (e.g. /gems bind TestSeq CTRL-F12)"
L["GEMS_UNBIND_SUCCESS"] = "Unbound |cFF00FF00'%s'|r."
L["GEMS_UNBIND_NO_BIND"] = "Sequence '%s' has no keybinding."
L["GEMS_UNBIND_NEED_NAME"] = "Usage: /gems unbind <name>"
L["GEMS_BINDS_HEADER"] = "Keybindings (spec %d):"
L["GEMS_BINDS_ENTRY"] = "  |cFFFFFF00%s|r -> |cFF00FF00%s|r"
L["GEMS_BINDS_EMPTY"] = "No keybindings set. Use /gems bind <name> <key>."
L["GEMS_KEYBINDS_LOADED"] = "Loaded %d keybindings for spec %d."
L["GEMS_STATUS_KEYBINDS"] = "Keybindings: %d for current spec"

-- Import/Export
L["GEMS_HELP_IMPORT"] = "  /gems import - Open import window (paste export strings)"
L["GEMS_HELP_EXPORT"] = "  /gems export <name> - Export a sequence as GRIP string"
L["GEMS_IMPORT_ENTRY"] = "  - '%s' (%d steps)"
L["GEMS_IMPORT_FAILED"] = "Import failed: %s"
L["GEMS_IMPORT_WARNING"] = "Warning: %s"
L["GEMS_IMPORT_USAGE"] = "Usage: /gems import (opens paste window for export strings)"
L["GEMS_EXPORT_USAGE"] = "Usage: /gems export <name>"
L["GEMS_EXPORT_RESULT"] = "Export: %s"
L["GEMS_EXPORT_FAILED"] = "Export failed: %s"
L["GEMS_IMPORT_PASTE_INSTRUCTIONS"] = "Paste an export string below, then click Import."
L["GEMS_IMPORT_PASTE_LABEL"] = "Export String"
L["GEMS_IMPORT_CLEAR"] = "Clear"
L["GEMS_IMPORT_SHORT_STRING"] = "Hint: Use /gems import (no args) to open the paste window for long strings."
L["GEMS_IMPORT_USE_FRAME"] =
    "Tip: The string may have been truncated. Use |cFFFFFF00/gems import|r to open the paste window."
L["GEMS_IMPORT_UNKNOWN_FORMAT"] = "Unknown import format"
L["GEMS_IMPORT_ACTION_SKIPPED"] = "Skipped action: %s"
L["GEMS_IMPORT_EMBED_SKIPPED"] = "Embedded sequence '%s' skipped (not available)"
L["GEMS_IMPORT_PAUSE_CONVERTED"] = "Pause converted to %d empty step(s)"
L["GEMS_IMPORT_INTERVAL_PRESERVED"] = "Preserved %d interleave action(s)"
L["GEMS_ACTION_INTERLEAVE_EVERY"] = "Every:"
L["GEMS_ACTION_INTERLEAVE_STEPS"] = "steps"

-- UI strings (Phase 3)
L["GEMS_HELP_OPEN"] = "  /gems open - Open/close the main window"
L["GEMS_UI_TITLE"] = "GRIP-EMS"
L["GEMS_UI_SELECT_SEQUENCE"] = "Select a sequence to edit"
L["GEMS_UI_SEQUENCE_LIST_PLACEHOLDER"] = "Sequence list loading..."
L["GEMS_UI_NO_SEQUENCES"] = "No sequences found. Create one or import."
L["GEMS_UI_RESIZE"] = "Resize"
L["GEMS_UI_RESIZE_DESC"] = "Drag to resize the window"
L["GEMS_UI_MINIMAP_LEFT"] = "Left-click: Open/Close"
L["GEMS_UI_MINIMAP_RIGHT"] = "Right-click: Quick menu"
L["GEMS_UI_MINIMAP_RIGHTCLICK_SOON"] = "Right-click quick menu coming soon."
L["GEMS_UI_MINIMAP_OOC_QUEUE"] = "OOC Queue"
L["GEMS_UI_MINIMAP_OOC_PENDING"] = "%d pending"
L["GEMS_UI_MINIMAP_PARTY_USERS"] = "Party Users"
L["GEMS_UI_MINIMAP_PARTY_NONE"] = "none detected"

-- UI strings (Phase 3A-2): Search
L["GEMS_UI_SEARCH"] = "Search..."
L["GEMS_UI_SEARCH_DESC"] = "Filter sequences by name"

-- UI strings (Phase 3A-2): Buttons
L["GEMS_UI_NEW"] = "New"
L["GEMS_UI_NEW_DESC"] = "Create a new sequence"
L["GEMS_UI_IMPORT_BTN"] = "Import"
L["GEMS_UI_IMPORT_BTN_DESC"] = "Import a sequence from an export string"

-- UI strings (Phase 3A-2): Context menu
L["GEMS_UI_DUPLICATE"] = "Duplicate"
L["GEMS_UI_DELETE"] = "Delete"
L["GEMS_UI_EXPORT_CTX"] = "Export"
L["GEMS_UI_RENAME"] = "Rename"
L["GEMS_UI_REPAIR"] = "Repair"
L["GEMS_UI_REPAIR_ALL"] = "Fix All"

-- Repair module strings
L["GEMS_REPAIR_USAGE"] = "Usage: /gems repair <name> (or select a sequence first)"
L["GEMS_REPAIR_NOT_LOADED"] = "Repair module not loaded"
L["GEMS_REPAIR_SEQ_NOT_FOUND"] = "Sequence not found: %s"
L["GEMS_REPAIR_NONE"] = "No issues found (health: %d)"
L["GEMS_REPAIR_ALL_HEALTHY"] = "All sequences healthy!"
L["GEMS_REPAIR_IMPORT_ISSUES"] = "Imported %s. %d issues detected -- use /gems repair %s to review."
L["GEMS_REPAIR_EXPORT_WARN"] =
    "%d issues found across selected sequences. Recipients may see broken behavior. Export anyway?"
L["GEMS_REPAIR_EXPORT_ACCEPT"] = "Export Anyway"
L["GEMS_REPAIR_SEND_WARN"] = "%d issues found. Recipients may see broken behavior. Send anyway?"
L["GEMS_REPAIR_SEND_ACCEPT"] = "Send Anyway"

-- UI strings (Phase 3A-2): Editor header
L["GEMS_UI_SEQ_ICON"] = "Icon"
L["GEMS_UI_STEP_FUNCTION"] = "Step Function"
L["GEMS_UI_RESET_COMBAT"] = "Reset on Combat End"
L["GEMS_UI_RESET_COMBAT_DESC"] = "Reset step counter when combat ends"
L["GEMS_UI_RESET_TARGET"] = "Reset on Target Change"
L["GEMS_UI_RESET_TARGET_DESC"] = "Reset step counter when target changes (out of combat only)"
L["GEMS_UI_RESET_GEAR"] = "Gear Change"
L["GEMS_UI_RESET_GEAR_DESC"] = "Reset step counter when equipment changes (out of combat only)"
L["GEMS_UI_RESET_SPEC"] = "Spec Change"
L["GEMS_UI_RESET_SPEC_DESC"] = "Reset step counter when specialization changes"
L["GEMS_UI_RESET_TIMER"] = "Timer (sec)"
L["GEMS_UI_RESET_TIMER_DESC"] = "Reset step counter after this many seconds of inactivity (0 = disabled)"
L["GEMS_UI_KEYPRESS"] = "KeyPress"
L["GEMS_UI_KEYPRESS_DESC"] =
    "Commands that run on key-down, before each step fires (e.g. /stopmacro [channeling]). Combined into each step's macrotext when the total fits within 255 characters. Steps that exceed the limit run without KeyPress -- check the Preview tab to see which steps fit."
L["GEMS_UI_KEYRELEASE"] = "KeyRelease"
L["GEMS_UI_KEYRELEASE_DESC"] =
    "Commands that run on key-up, after each step fires. Combined into each step's macrotext when the total fits within 255 characters. Steps that exceed the limit run without KeyRelease -- check the Preview tab to see which steps fit."

-- UI strings: Metadata section
L["GEMS_EDITOR_METADATA"] = "Metadata"
L["GEMS_EDITOR_METADATA_AUTHOR"] = "Author"
L["GEMS_EDITOR_METADATA_DESCRIPTION"] = "Description"
L["GEMS_EDITOR_METADATA_HELP"] = "Help Text"
L["GEMS_EDITOR_METADATA_HELPLINK"] = "Help Link"
L["GEMS_EDITOR_METADATA_CLASS"] = "Class"
L["GEMS_EDITOR_METADATA_SPEC"] = "Spec"
L["GEMS_EDITOR_METADATA_CREATED"] = "Created"
L["GEMS_EDITOR_METADATA_UPDATED"] = "Updated"

-- UI strings: Dependencies section
L["GEMS_DEPS_HEADER"] = "Dependencies"
L["GEMS_DEPS_VARIABLES"] = "Variables"
L["GEMS_DEPS_SEQUENCES"] = "Sequences"
L["GEMS_DEPS_EMBEDDED_BY"] = "Embedded By"
L["GEMS_DEPS_NONE"] = "(none)"
L["GEMS_DEPS_NOT_EMBEDDED"] = "Not embedded by any sequence"

-- UI strings (Phase 3A-2): Tabs
L["GEMS_UI_TAB_STEPS"] = "Steps"
L["GEMS_UI_TAB_KEYBIND"] = "Keybind"
L["GEMS_UI_TAB_VARIABLES"] = "Variables"
L["GEMS_UI_TAB_RAW"] = "Raw"
L["GEMS_UI_TAB_COMING_SOON"] = "Coming soon"

-- UI strings (Phase 3A-2): Step list
L["GEMS_UI_STEP_NUM"] = "#%d"
L["GEMS_UI_NO_STEPS"] = "No steps defined."
L["GEMS_UI_ADD_STEP_HINT"] = "No steps. Click '+ Add' to create one."

-- UI strings (Phase 3A-2): Dialogs
L["GEMS_UI_NEW_SEQ_DESC"] = "Enter a name for the new sequence:"
L["GEMS_UI_DELETE_CONFIRM"] = "Are you sure you want to delete '%s'? This cannot be undone."
L["GEMS_UI_DUP_DESC"] = "Enter a name for the duplicate:"
L["GEMS_UI_RENAME_DESC"] = "Enter the new name:"
L["GEMS_UI_NAME_EXISTS"] = "A sequence named '%s' already exists."
L["GEMS_UI_NAME_EMPTY"] = "Sequence name cannot be empty."

-- UI strings (Phase 3A-2): Status text in rows
L["GEMS_UI_ROW_SUBTITLE"] = "%s | %d steps"

-- UI strings (Phase 3A-2): Sort
L["GEMS_UI_SORT_ALPHA"] = "A-Z"
L["GEMS_UI_SORT_CLASS"] = "Class"
L["GEMS_UI_SORT_UPDATED"] = "Recent"
L["GEMS_UI_SORT_ALPHA_TIP"] = "Alphabetical"
L["GEMS_UI_SORT_CLASS_TIP"] = "By Class"
L["GEMS_UI_SORT_UPDATED_TIP"] = "Recently Updated"
L["GEMS_UI_SORT_HINT"] = "Sort"
L["GEMS_UI_SORT_CYCLE"] = "Click to cycle sort mode"

-- Spell validation (v1.1.0)
L["GEMS_SPELL_WARN_BANNER"] = "%d spell(s) may be invalid in this sequence"
L["GEMS_SPELL_VALIDATE_SUMMARY"] = "%d sequence(s) checked: %d clean, %d with warnings"
L["GEMS_SPELL_VALIDATE_CLEAN"] = "All sequences validated -- no issues found"
L["GEMS_SPELL_VALIDATE_SEQ"] = "  %s: %d unknown, %d talent-gated"
L["GEMS_SPELL_STATUS_LABEL"] = "%d spell(s) may be invalid"
L["GEMS_SPELL_INFO_LABEL"] = "%d known but unlearned"
L["GEMS_IMPORT_FREEFORM_WARN"] =
    "'%s': %d step(s) contain raw macro commands that cannot be auto-translated across locales"
L["GEMS_IMPORT_FREEFORM_LABEL"] = "%d freeform"
L["GEMS_IMPORT_ICON_AUTO"] = "(auto-detected)"
L["GEMS_IMPORT_PICK_AUTO"] = "[auto]"
L["GEMS_IMPORT_PICK_VAR_DEPS"] = "Uses %d vars"
L["GEMS_SPELL_TOOLTIP_UNKNOWN"] = "Not found: %s"
L["GEMS_SPELL_TOOLTIP_KNOWN"] = "Not in spellbook: %s"
L["GEMS_SPELL_TOOLTIP_COSMETIC"] = "|cff888888#showtooltip: %s|r"

-- Rotation Preview (v1.1.0)
L["GEMS_PLUGIN_LOADED"] = "Plugin sequences loaded for: %s"
L["GEMS_PLUGIN_NOT_FOUND"] = "Plugin not registered: %s"
L["GEMS_PLUGIN_REGISTERED"] = "Plugin registered: %s v%s (%d sequences)"
L["GEMS_PLUGIN_SKIP_EXISTS"] = "Plugin %s: skipping '%s' (user version exists)"

L["GEMS_PREVIEW_ICONS"] = "Icons"
L["GEMS_PREVIEW_TEXT"] = "Text"
L["GEMS_PREVIEW_TOGGLE_TIP"] = "Switch preview mode"
L["GEMS_PREVIEW_RANDOM_HINT"] = "Random -- any of these may execute"
L["GEMS_PREVIEW_STEP_TOOLTIP"] = "Step %d: %s"
L["GEMS_PREVIEW_SPELL_TOOLTIP"] = "Spell: %s"
L["GEMS_PREVIEW_COMPILED"] = "Compiled"
L["GEMS_PREVIEW_COMPILED_TIP"] = "Show compiled macrotext per step (what WoW executes)"
L["GEMS_PREVIEW_KP_FIT"] = "%d/%d steps fit keyPress+keyRelease"
L["GEMS_PREVIEW_KP_DROPPED"] = "Steps in red had keyPress/keyRelease dropped (overflow)"
L["GEMS_PREVIEW_COPY"] = "Copy"
L["GEMS_PREVIEW_COPY_TIP"] = "Copy rotation preview to clipboard"

-- UI strings (Phase 3A-2): Editor misc
L["GEMS_UI_ICON_HINT"] = "Click to change icon"
L["GEMS_UI_DUPLICATE_FAILED"] = "Duplicate failed."
L["GEMS_UI_COPY_SUFFIX"] = "_copy"

-- UI strings (Phase 3A-2): Step function labels
L["GEMS_UI_SF_SEQUENTIAL"] = "Sequential"
L["GEMS_UI_SF_RANDOM"] = "Random"
L["GEMS_UI_SF_PRIORITY"] = "Priority"
L["GEMS_UI_SF_REVERSEPRIORITY"] = "Rev. Priority"

-- UI strings (Phase 3B-1): Step editor
L["GEMS_UI_ADD_STEP"] = "+ Add"
L["GEMS_UI_ADD_STEP_DESC"] = "Add a new empty step after the selected step"
L["GEMS_UI_DUP_STEP"] = "Dup"
L["GEMS_UI_DUP_STEP_DESC"] = "Duplicate the selected step"
L["GEMS_UI_MOVE_UP"] = "Up"
L["GEMS_UI_MOVE_UP_DESC"] = "Move the selected step up"
L["GEMS_UI_MOVE_DOWN"] = "Down"
L["GEMS_UI_MOVE_DOWN_DESC"] = "Move the selected step down"
L["GEMS_UI_DEL_STEP"] = "Del"
L["GEMS_UI_DEL_STEP_DESC"] = "Delete the selected step"
L["GEMS_UI_STEP_HEADER"] = "Step %d:"
L["GEMS_UI_SELECT_STEP"] = "Select a step to edit"
L["GEMS_UI_DELETE_STEP_CONFIRM"] = "Delete step %d? This cannot be undone."
L["GEMS_UI_CTX_DUP_STEP"] = "Duplicate Step"
L["GEMS_UI_CTX_MOVE_UP"] = "Move Up"
L["GEMS_UI_CTX_MOVE_DOWN"] = "Move Down"
L["GEMS_UI_CTX_DELETE_STEP"] = "Delete Step"
L["GEMS_UI_DRAG_HANDLE_DESC"] = "Drag to reorder"
L["GEMS_UI_EXPORT_BTN_EDITOR"] = "Export"
L["GEMS_UI_EXPORT_BTN_EDITOR_DESC"] = "Export this sequence as a GRIP string"
L["GEMS_UI_NAME_TOOLTIP"] = "Sequence Name"
L["GEMS_UI_NAME_EDIT_HINT"] = "Click to rename. Press Enter to confirm, Escape to cancel."
L["GEMS_UI_SAVE_PROMPT"] = "Save changes to '%s'?"
L["GEMS_UI_SAVE"] = "Save"
L["GEMS_UI_SAVE_BTN_DESC"] = "Save changes to this sequence"
L["GEMS_UI_DISCARD"] = "Discard"
L["GEMS_UI_DISCARD_BTN_DESC"] = "Discard changes and revert to last saved state"
L["GEMS_UI_SAVE_COMBAT"] = "Unavailable in combat"

-- Version bar (UX-4)
L["GEMS_VERSION_OF"] = "Version %d of %d"
L["GEMS_VERSION_LABEL"] = "Version %d"
L["GEMS_VERSION_DEFAULT_SUFFIX"] = " (Default)"
L["GEMS_VERSION_DEFAULT_MARKER"] = " (*)"
L["GEMS_VERSION_TOOLTIP_TITLE"] = "Version"
L["GEMS_VERSION_TOOLTIP_DESC"] = "Select which version to edit"
L["GEMS_VERSION_ADD_TITLE"] = "Add Version"
L["GEMS_VERSION_ADD_DESC"] = "Create a new empty version"
L["GEMS_VERSION_DUP_TITLE"] = "Duplicate Version"
L["GEMS_VERSION_DUP_DESC"] = "Copy current version to a new version"
L["GEMS_VERSION_DEL_TITLE"] = "Delete Version"
L["GEMS_VERSION_DEL_DESC"] = "Remove current version"
L["GEMS_VERSION_DEFAULT_TITLE"] = "Set Default"
L["GEMS_VERSION_DEFAULT_DESC"] = "Make current version the default for execution"

-- Phase 3B-2: Keybind tab
L["GEMS_UI_CURRENT_KEYBIND"] = "Current Keybind"
L["GEMS_UI_KEYBIND_DISPLAY_NONE"] = "None"
L["GEMS_UI_SET_KEYBIND"] = "Set Keybind"
L["GEMS_UI_CHANGE_KEYBIND"] = "Change"
L["GEMS_UI_CLEAR_KEYBIND"] = "Clear"
L["GEMS_UI_PRESS_KEY"] = "Press a key..."
L["GEMS_UI_KEYBIND_HINT"] =
    "Keybinds are per-spec override bindings stored in your GRIP-EMS profile. They do not modify your WoW keybind settings."
L["GEMS_UI_CAPTURE_COMBAT"] = "Cannot capture keybinds during combat."
L["GEMS_UI_SPEC_KEYBINDS"] = "Keybinds by Spec"
L["GEMS_UI_CURRENT_SPEC"] = "(current)"
L["GEMS_UI_LOADOUT_COMING_SOON"] = "Per-talent-loadout keybinds: coming soon"
L["GEMS_UI_CAPTURE_ESC_HINT"] = "(Press ESC to cancel)"
L["GEMS_UI_KEYBIND_CONFLICT"] = "%s was bound to '%s' and has been reassigned."
L["GEMS_UI_KEYBIND_CP_CONFLICT"] = "%s is bound to '%s' in ConsolePort. It will be overridden during active sequences."
L["GEMS_UI_GAMEPAD_HINT"] = "Controller detected -- gamepad buttons supported in capture"

-- Phase 3B-2: Macros tab
L["GEMS_UI_TAB_MACROS"] = "Macros"
L["GEMS_UI_MACRO_STUB_SECTION"] = "Macro Stub"
L["GEMS_UI_STUB_INFO"] = "%s (slot %d)"
L["GEMS_UI_STUB_NONE"] = "No macro stub"
L["GEMS_UI_SLOTS_USED"] = "%d/%d per-character macro slots used"
L["GEMS_UI_REFRESH_STUBS"] = "Refresh"
L["GEMS_UI_REFRESH_STUBS_DESC"] = "Re-scan for existing GRIP-EMS macro stubs"
L["GEMS_UI_CLEAN_ORPHANS"] = "Clean Orphans"
L["GEMS_UI_CLEAN_ORPHANS_DESC"] = "Delete macro stubs for sequences that no longer exist"
L["GEMS_UI_CLEAN_CONFIRM"] = "Delete %d orphan macro stub(s)? This cannot be undone."
L["GEMS_UI_ORPHANS_CLEANED"] = "Cleaned %d orphan macro stub(s)."
L["GEMS_UI_NO_ORPHANS"] = "No orphan stubs found."
L["GEMS_UI_STUB_LIST_HEADER"] = "All Stubs (%d)"
L["GEMS_UI_NO_STUBS"] = "No macro stubs found."
L["GEMS_UI_STUBS_MORE"] = "%d more stub(s) not shown"

-- Phase 3B-2: Priority preview

-- Phase 3C-1: Spell autocomplete

-- Phase 3C-2: Icon picker
L["GEMS_UI_ICON_PICKER_TITLE"] = "Choose Icon"
L["GEMS_UI_AUTO_DETECT"] = "Auto-Detect"
L["GEMS_UI_AUTO_DETECT_DESC"] = "Automatically detect icon from the first /cast spell"

-- Context version selection (T2-1)
L["GEMS_CONTEXT_CHANGED"] = "Context changed: %s"
L["GEMS_CONTEXT_NONE_LABEL"] = "None"
L["GEMS_CONTEXT_RELOAD"] = "Context switch reloaded %d sequence(s)"

-- Context tab (T2-1b)
L["GEMS_UI_TAB_CONTEXT"] = "Context"
L["GEMS_CONTEXT_DEFAULT_LABEL"] = "Default Version: %d"
L["GEMS_CONTEXT_CURRENT_INFO"] = "Current Context: %s"
L["GEMS_CONTEXT_VIEWING"] = "Assignments for Version %d"
L["GEMS_CONTEXT_NO_VERSIONS"] = "Add a second version to configure context overrides."
L["GEMS_CONTEXT_HINT"] =
    "Check the content types where this version should be active. Unchecked contexts fall back to broader categories (e.g. Mythic+ falls back to Dungeon, then Default)."
L["GEMS_CONTEXT_CONFLICT_MSG"] = "%s is currently assigned to Version %d.\nReassign to Version %d?"
L["GEMS_CONTEXT_ASSIGNED_OTHER"] = "(Version %d)"
L["GEMS_CONTEXT_GROUP_RAIDS"] = "Raids"
L["GEMS_CONTEXT_GROUP_DUNGEONS"] = "Dungeons"
L["GEMS_CONTEXT_GROUP_PVP"] = "PvP"
L["GEMS_CONTEXT_GROUP_ARENA_MAPS"] = "Arena Maps"
L["GEMS_CONTEXT_GROUP_BG_MAPS"] = "Battleground Maps"
L["GEMS_CONTEXT_GROUP_OTHER"] = "Other"
L["GEMS_CONTEXT_WRONG_VERSION"] = "%s is assigned to Version %d. Switch to that version to modify it."

-- Context group buttons and fallback chain (v1.2.0 S19)
L["GEMS_CONTEXT_SELECT_ALL"] = "All"
L["GEMS_CONTEXT_CLEAR_ALL"] = "None"
L["GEMS_CONTEXT_FALLBACK_NONE"] = "No active context -- Default Version %d"
L["GEMS_CONTEXT_FALLBACK_MATCH"] = " (v%d)"
L["GEMS_CONTEXT_FALLBACK_DEFAULT"] = "Default"
L["GEMS_CONTEXT_FALLBACK_SEP"] = " > "
L["GEMS_SETTINGS_CONTEXT_HEADER"] = "Context Detection"
L["GEMS_SETTINGS_CONTEXT_DESC"] = "Configure how the addon detects content type for automatic version switching."
L["GEMS_SETTINGS_MPLUS_MID"] = "Mythic+ Mid Tier"
L["GEMS_SETTINGS_MPLUS_MID_DESC"] = "Key level where Mythic+ context switches from Low to Mid tier."
L["GEMS_SETTINGS_MPLUS_HIGH"] = "Mythic+ High Tier"
L["GEMS_SETTINGS_MPLUS_HIGH_DESC"] = "Key level where Mythic+ context switches from Mid to High tier."
L["GEMS_SETTINGS_DELVES_HIGH"] = "Delves High Tier"
L["GEMS_SETTINGS_DELVES_HIGH_DESC"] = "Delve tier where context switches from Low to High."

-- Context migration (T2-3)

-- Phase 2B: Migration
L["GEMS_HELP_MIGRATE"] = "  /gems migrate - Migrate sequences from another sequencer"
L["GEMS_UI_MIGRATE_BTN"] = "Migrate"
L["GEMS_UI_MIGRATE_BTN_DESC"] = "Import all sequences from another sequencer"
L["GEMS_MIGRATE_NO_SOURCE"] = "No compatible sequencer found for migration."
L["GEMS_MIGRATE_SOURCE_DISABLED"] =
    "A compatible sequencer was found but is disabled. Enable it in the AddOns list and /reload to migrate."
L["GEMS_MIGRATE_FAILED"] = "Migration failed: %s"
L["GEMS_MIGRATE_CONFIRM"] =
    "Migrate all sequences from your previous sequencer?\n\nFound %d sequences. Existing sequences with the same name will be skipped."
L["GEMS_DELETE_COMBAT"] = "Cannot delete sequences during combat."
L["GEMS_MIGRATE_COMBAT"] = "Cannot migrate during combat. Try again after combat."
L["GEMS_MIGRATE_EMPTY"] = "No sequences found in source library."
L["GEMS_MIGRATE_SKIPPED"] = "%s (already exists, skipped)"
L["GEMS_MIGRATE_KEYBINDS"] = "Keybinds: %d migrated, %d skipped, %d conflicts"
L["GEMS_MIGRATE_AO_WARNING"] =
    "%d action bar overrides found but not migrated. EMS uses keybind overrides. Rebind these sequences via /gems bind."

-- Phase 2C: Export frame
L["GEMS_EXPORT_FRAME_LABEL"] = "Exported: %s"
L["GEMS_EXPORT_FRAME_HINT"] = "Press Ctrl+C to copy, then paste into another player's import window."

-- Phase 3C-3: Variable system
L["GEMS_VAR_EVAL_ERROR"] = "Variable '%s' evaluation failed: %s"
L["GEMS_VAR_INVALID_NAME"] = "Variable name must be alphanumeric (a-z, 0-9, underscore)"
L["GEMS_VAR_NAME_TOO_LONG"] = "Variable name exceeds %d characters"
L["GEMS_VAR_FUNC_TOO_LONG"] = "Variable function exceeds %d characters"
L["GEMS_VAR_NAME_EMPTY"] = "Variable name cannot be empty"
L["GEMS_VAR_NAME_EXISTS"] = "Variable '%s' already exists"
L["GEMS_VAR_DELETED"] = "Variable '%s' deleted"
L["GEMS_VAR_SAVED"] = "Variable '%s' saved"
L["GEMS_VAR_IMPORT_PAUSE"] = "Pause with variable converted to comment"
L["GEMS_VAR_IMPORT_SKIPPED"] = "Skipped %d variable(s) (already exist)."
L["GEMS_VAR_RECOMPILE"] = "Recompiling '%s' (variable changed)"

-- Phase 3C-3b: Variables Tab UI
L["GEMS_VAR_TAB_EMPTY"] = "No variables defined. Click New to create one."
L["GEMS_VAR_NEW"] = "New Variable"
L["GEMS_VAR_NAME_LABEL"] = "Name"
L["GEMS_VAR_FUNC_LABEL"] = "Function Body"
L["GEMS_VAR_FUNC_PLACEHOLDER"] = "return GetHaste() > 20"
L["GEMS_VAR_EVENTS_LABEL"] = "Events (comma-separated)"
L["GEMS_VAR_EVENTS_PLACEHOLDER"] = "SPELL_CAST_SUCCESS, UNIT_AURA"
L["GEMS_VAR_COMMENTS_LABEL"] = "Comments"
L["GEMS_VAR_DISABLED_LABEL"] = "Disabled"
L["GEMS_VAR_SAVE"] = "Save"
L["GEMS_VAR_TEST"] = "Test"
L["GEMS_VAR_TEST_RESULT"] = "Variable '%s' = %s"
L["GEMS_VAR_TEST_ERROR"] = "Variable '%s' error: %s"
L["GEMS_VAR_VALID"] = "Valid"
L["GEMS_VAR_INVALID"] = "Error: %s"
L["GEMS_VAR_USED_BY"] = "Used by: %s"
L["GEMS_VAR_NOT_USED"] = "Not referenced by any sequence"
L["GEMS_VAR_DELETE_CONFIRM"] = "Delete variable '%s'?"
L["GEMS_VAR_DELETE_REFS_WARN"] = "This variable is used by %d sequence(s). Delete anyway?"
L["GEMS_VAR_RENAME"] = "Rename Variable"
L["GEMS_VAR_EVENTS_BROWSE"] = "Browse Events"
L["GEMS_VAR_NEW_DESC"] = "Create a new variable"
L["GEMS_VAR_SAVE_DESC"] = "Save changes to this variable"
L["GEMS_VAR_TEST_DESC"] = "Evaluate the function and show the result"
L["GEMS_VAR_DELETE_DESC"] = "Delete this variable permanently"
L["GEMS_VAR_EVENTS_BROWSE_TIP"] = "Click to browse available events"
L["GEMS_VAR_EVENTS_ENABLED_DESC"] =
    "When unchecked, event triggers for this variable are paused. The event list is preserved."
L["GEMS_VAR_LOCALE_WARN"] = "Variable evaluates to spell name '%s'. For locale safety, use: %s"
L["GEMS_VAR_FUNC_HELP"] =
    "For locale-safe variables, use C_Spell.GetSpellName(spellID) instead of hardcoded spell name strings. Example: C_Spell.GetSpellName(133) instead of 'Fireball'."

-- Raw tab
L["GEMS_RAW_TITLE"] = "Raw Data"
L["GEMS_RAW_EDIT"] = "Edit"
L["GEMS_RAW_APPLY"] = "Apply"
L["GEMS_RAW_CANCEL"] = "Cancel"
L["GEMS_RAW_INVALID"] = "Invalid: %s"
L["GEMS_RAW_MISSING_FIELD"] = "Missing required field: %s"
L["GEMS_RAW_APPLIED"] = "Changes applied"
L["GEMS_RAW_NAME_IGNORED"] = "Name change ignored. Use Rename from context menu."
L["GEMS_RAW_NO_SEQUENCE"] = "No sequence selected"
L["GEMS_RAW_READONLY_HINT"] = "Click Edit to modify. Changes are validated before applying."
L["GEMS_RAW_CANCEL_DESC"] = "Close without applying changes"
L["GEMS_RAW_EDIT_DESC"] = "Parse and apply the Lua table as sequence data"

-- Step action bar (Save + hint)
L["GEMS_STEP_SAVE"] = "Save"
L["GEMS_STEP_SAVE_DESC"] = "Save all step changes to the sequence"
L["GEMS_STEP_UNSAVED_HINT"] = "Unsaved changes"

-- Engine debug
L["GEMS_SEQ_ACTIVATED"] = "Sequence '%s' activated (%d steps)."
L["GEMS_SEQ_DEACTIVATED"] = "Sequence '%s' deactivated."
L["GEMS_STEP_RESET"] = "Sequence '%s' step reset to 1."
L["GEMS_STEP_ADVANCED"] = "Sequence '%s' step advanced to %d/%d."
L["GEMS_COMBAT_RESET"] = "Sequence '%s' reset (combat drop)."
L["GEMS_TARGET_RESET"] = "Sequence '%s' reset (target change)."
L["GEMS_GEAR_RESET"] = "%s: reset on gear change (was step %d, slot %d)."
L["GEMS_SPEC_RESET"] = "%s: reset on spec change (was step %d)."
L["GEMS_RESTORED"] = "Restored %d saved sequence(s)."
L["GEMS_KEYBINDS_SUSPENDED"] = "Keybinds suspended: %s"
L["GEMS_KEYBINDS_RESTORED"] = "Keybinds restored: %s"

-- Settings panel (T1-1 + T1-7)
L["GEMS_HELP_SETTINGS"] = "  /gems settings|config|options - Open settings panel"
L["GEMS_SETTINGS_HEADER_DESC"] = "Configure GRIP - Enhanced Macro Sequencer behavior and display."
L["GEMS_SETTINGS_GENERAL"] = "General"
L["GEMS_SETTINGS_OOC_DELAY"] = "OOC Queue Delay (sec)"
L["GEMS_SETTINGS_OOC_DELAY_DESC"] =
    "Seconds between out-of-combat queue polls. Lower = faster processing of queued operations after combat. Changes take effect after /reload. Default: 7s."
L["GEMS_SETTINGS_RESET_OOC"] = "Reset on Combat End (default)"
L["GEMS_SETTINGS_RESET_OOC_DESC"] =
    "Default value for 'Reset on Combat End' when creating new sequences. Existing sequences are not affected."
L["GEMS_SETTINGS_UI"] = "Display"
L["GEMS_SETTINGS_HIDE_LOGIN"] = "Hide Login Message"
L["GEMS_SETTINGS_HIDE_LOGIN_DESC"] = "Suppress the 'GRIP-EMS vX.X' message on login."
L["GEMS_SETTINGS_DEBUG"] = "Debug Mode"
L["GEMS_SETTINGS_DEBUG_DESC"] = "Show debug messages in chat. Also toggleable via /gems debug."
L["GEMS_SETTINGS_INFO"] = "Info"
L["GEMS_SETTINGS_VERSION_INFO"] = "GRIP-EMS v%s | %d active sequence(s)"

-- About info (T1-5)
L["GEMS_ABOUT_AUTHOR"] = "Author: Sataana (MrSataana)"
L["GEMS_ABOUT_LINKS"] =
    "Guide: jesperlive.github.io/grip-ems-guide/\nCurseForge: curseforge.com/wow/addons/grip-enhanced-macro-sequencer\nWago: addons.wago.io/addons/qGZODqNd\nWoWInterface: wowinterface.com/downloads/info27081"
L["GEMS_ABOUT_KEYBINDS"] = "Active keybinds: %d"
L["GEMS_ABOUT_OOC_QUEUE"] = "OOC queue: %d pending"
L["GEMS_ABOUT_SOURCE_STATUS"] = "Migration source: %s"
L["GEMS_ABOUT_MACRO_SLOTS"] = "Macro slots: %d / %d per-character"
L["GEMS_UI_ACTIVE_SEQUENCES_LABEL"] = "Active sequences"
L["GEMS_UI_CONTEXT_LABEL"] = "Context"
L["GEMS_LOGIN_ACTIVE"] = "|cFF888888  %d active sequence(s)|r"
L["GEMS_UI_SETTINGS_BTN"] = "Settings"
L["GEMS_UI_SETTINGS_BTN_DESC"] = "Open GRIP-EMS settings panel"

-- Migration report (T1-9)
L["GEMS_REPORT_HEADER_MIGRATE"] = "--- GRIP-EMS Migration Report ---"
L["GEMS_REPORT_HEADER_IMPORT"] = "--- GRIP-EMS Import Report ---"
L["GEMS_REPORT_IMPORTED"] = "Imported: %d sequence(s), %d variable(s)"
L["GEMS_REPORT_DORMANT"] = "  (%d stored for other classes, activated on login)"
L["GEMS_REPORT_SKIPPED"] = "Skipped: %d (already exist)"
L["GEMS_REPORT_SEQ_ENTRY"] = "  + %s (%d steps, %s)"
L["GEMS_REPORT_LIMITATIONS"] = "Known limitations:"
L["GEMS_REPORT_VERSIONS_DROPPED"] = "  - %d extra version(s) not imported (only default version supported)"
L["GEMS_REPORT_PAUSES_CONVERTED"] = "  - %d pause action(s) converted to %d empty step(s)"
L["GEMS_REPORT_EMBEDS_SKIPPED"] = "  - %d embedded sequence ref(s) skipped (not yet supported)"
L["GEMS_REPORT_TRUNCATED"] = "  - %d step(s) exceeded 255 chars and were truncated"
L["GEMS_REPORT_TIP_VERIFY"] = "Tip: Open each migrated sequence and verify steps look correct."
L["GEMS_REPORT_TIP_VERSIONS"] = "Use /gems to open the editor and configure context version overrides."

-- Guide (T1-10)
L["GEMS_GUIDE_TITLE"] = "GRIP-EMS Interactive Guide"
L["GEMS_GUIDE_PATH"] = "Copy this URL and open it in your browser:"
L["GEMS_GUIDE_TIP"] = "Local file: Interface/AddOns/GRIP-EMS/Guide/GRIP-EMS_Guide.html"
L["GEMS_GUIDE_URL"] = "https://jesperlive.github.io/grip-ems-guide/"
L["GEMS_GUIDE_CLICK"] = "|cff4ecca3|HGRIPEMSguide|h[Click here to open GRIP-EMS Guide]|h|r"
L["GEMS_HELP_GUIDE"] = "  /gems guide - GRIP-EMS Interactive Guide"

-- Import preview (T2-4)
L["GEMS_IMPORT_PREVIEW_TITLE"] = "Import Preview"
L["GEMS_IMPORT_PREVIEW_SEQ_HEADER"] = "Sequences (%d)"
L["GEMS_IMPORT_PREVIEW_VAR_HEADER"] = "Variables (%d)"
L["GEMS_IMPORT_PREVIEW_NEW"] = "New"
L["GEMS_IMPORT_PREVIEW_EXISTS"] = "Exists"
L["GEMS_IMPORT_PREVIEW_IDENTICAL"] = "Identical"
L["GEMS_IMPORT_PREVIEW_DIFFERENT"] = "Different"
L["GEMS_IMPORT_PREVIEW_IMPORT_SELECTED"] = "Import Selected (%d)"
L["GEMS_IMPORT_PREVIEW_CANCEL"] = "Cancel"
L["GEMS_IMPORT_PREVIEW_SELECT_ALL"] = "Select All"
L["GEMS_IMPORT_PREVIEW_DESELECT_ALL"] = "Deselect All"
L["GEMS_IMPORT_PREVIEW_EMPTY"] = "No sequences or variables found in this string."
L["GEMS_IMPORT_PREVIEW_DESC"] = "Parse the pasted text and show importable sequences"
L["GEMS_IMPORT_CLEAR_DESC"] = "Clear the paste box"
L["GEMS_IMPORT_SELECT_ALL_DESC"] = "Select all sequences for import"
L["GEMS_IMPORT_DESELECT_ALL_DESC"] = "Deselect all sequences"
L["GEMS_IMPORT_CANCEL_DESC"] = "Return to paste stage"
L["GEMS_IMPORT_COMMIT_DESC"] = "Import the selected sequences"
L["GEMS_IMPORT_PREVIEW_SUMMARY"] = "Imported %d sequence(s), %d variable(s)"
L["GEMS_IMPORT_PREVIEW_BTN"] = "Preview"
L["GEMS_IMPORT_PREVIEW_HEADER"] = "%d sequences, %d variables"
L["GEMS_IMPORT_PREVIEW_NEW_COUNT"] = "%d new"
L["GEMS_IMPORT_PREVIEW_EXISTING_COUNT"] = "%d existing"
L["GEMS_IMPORT_PREVIEW_INFO"] = "%d versions, %d steps"
L["GEMS_IMPORT_PREVIEW_ACTION_SKIP"] = "Skip"
L["GEMS_IMPORT_PREVIEW_ACTION_REPLACE"] = "Replace"
L["GEMS_IMPORT_PREVIEW_ACTION_RENAME"] = "Rename"

-- Advanced Export (T2-12)
L["GEMS_EXPORT_PICK_TITLE"] = "Export Sequences"
L["GEMS_EXPORT_PICK_HEADER"] = "%d sequences, %d variables available"
L["GEMS_EXPORT_PICK_SEQ_HEADER"] = "Sequences (%d)"
L["GEMS_EXPORT_PICK_VAR_HEADER"] = "Variables (%d)"
L["GEMS_EXPORT_PICK_INFO"] = "%d versions, %d steps"
L["GEMS_EXPORT_PICK_VAR_DEPS"] = "(+%d vars)"
L["GEMS_EXPORT_PICK_USED_BY"] = "used by: %s"
L["GEMS_EXPORT_PICK_AUTO"] = "auto"
L["GEMS_EXPORT_PICK_SELECT_ALL"] = "Select All"
L["GEMS_EXPORT_PICK_DESELECT_ALL"] = "Deselect All"
L["GEMS_EXPORT_PICK_EXPORT_SELECTED"] = "Export Selected (%d)"
L["GEMS_EXPORT_PICK_BACK"] = "Back"
L["GEMS_EXPORT_PICK_DISPLAY_HEADER"] = "Exported %d sequences, %d variables"
L["GEMS_EXPORT_PICK_EMBEDDED_WARN"] = "%s uses %s (not selected)"
L["GEMS_EXPORT_PICK_LOCALE_WARN"] = "Variables with locale-dependent spell names may not work in other game languages"
L["GEMS_EXPORT_COPY_TEXT"] = "Copy as Text"
L["GEMS_EXPORT_COPY_TEXT_DESC"] = "Copy a readable summary to clipboard"
L["GEMS_EXPORT_META_TITLE"] = "Export Metadata"
L["GEMS_EXPORT_META_SUBTITLE"] = "Review and customize before exporting %d sequences"
L["GEMS_EXPORT_META_NAME"] = "Collection Name"
L["GEMS_EXPORT_META_AUTHOR"] = "Author"
L["GEMS_EXPORT_META_DESC"] = "Description"
L["GEMS_EXPORT_META_URL"] = "URL / Link"
L["GEMS_EXPORT_META_TALENT"] = "Talent Loadout"
L["GEMS_EXPORT_META_INCLUDE_AUTHOR"] = "Include author"
L["GEMS_EXPORT_META_INCLUDE_DESC"] = "Include description"
L["GEMS_EXPORT_META_INCLUDE_TALENT"] = "Include talent string"
L["GEMS_EXPORT_META_INCLUDE_URL"] = "Include URL"
L["GEMS_EXPORT_META_GENERATE"] = "Generate Export String"
L["GEMS_EXPORT_META_BACK"] = "Back to Selection"
L["GEMS_IMPORT_COLLECTION_HEADER"] = "Collection: %s by %s"
L["GEMS_UI_EXPORT_MULTI"] = "Export Multiple..."
L["GEMS_HELP_EXPORTALL"] = "  /gems exportall - Open multi-select export window"
L["GEMS_EXPORT_GENERATE_DESC"] = "Generate the export string from selected sequences"
L["GEMS_EXPORT_COPY_DESC"] = "Copy the export string to clipboard"
L["GEMS_EXPORT_SELECT_ALL_DESC"] = "Select all sequences for export"
L["GEMS_EXPORT_DESELECT_ALL_DESC"] = "Deselect all sequences"
L["GEMS_EXPORT_BACK_DESC"] = "Return to selection"
L["GEMS_EXPORT_CLOSE_DESC"] = "Close export window"

-- Transmission (T2-9)
L["GEMS_HELP_SEND"] = "  /gems send <name> <player> - Send a sequence to another player"
L["GEMS_HELP_ACCEPT"] = "  /gems accept - Accept the most recent incoming sequence"
L["GEMS_HELP_VALIDATE"] = "  /gems validate - Validate all sequences for stale/invalid spells"
L["GEMS_SEND_USAGE"] = "Usage: /gems send <name> <player>"
L["GEMS_SEND_SUCCESS"] = "Sent '%s' to %s"
L["GEMS_SEND_FAILED"] = "Send failed: %s"
L["GEMS_SEND_DISABLED"] = "P2P sharing is disabled in settings."
L["GEMS_SEND_NO_SEQ"] = "No sequence named '%s' found."
L["GEMS_RECEIVE_ANNOUNCE"] = "Received sequence from %s. Opening import..."
L["GEMS_RECEIVE_AUTO"] = "Auto-imported '%s' from %s (friend)."
L["GEMS_REQUEST_SENT"] = "Requesting '%s' from %s..."
L["GEMS_REQUEST_FULFILLED"] = "Sent '%s' to %s (requested)."
L["GEMS_VERSION_ANNOUNCE"] = "GRIP-EMS user detected: %s (v%s)"
L["GEMS_ACCEPT_USAGE"] = "No pending sequences to accept."
L["GEMS_UI_SEND_PLAYER"] = "Send to Player"
L["GEMS_UI_SEND_BTN"] = "Send"
L["GEMS_UI_SEND_BTN_DESC"] = "Send this sequence to another player"
L["GEMS_SEND_DIALOG_TEXT"] = "Send '%s' to:"
L["GEMS_SEND_DIALOG_ACCEPT"] = "Send"
L["GEMS_SEND_DIALOG_KNOWN"] = "Known users:"
L["GEMS_META_SENT"] = "Metadata sync request sent for '%s'."
L["GEMS_META_NEWER"] = "Newer version of '%s' available from %s, requesting..."
L["GEMS_META_CURRENT"] = "Local '%s' is up to date (remote from %s)."
L["GEMS_SPELLCACHE_SENT"] = "Spell cache broadcast sent to group."
L["GEMS_SPELLCACHE_MERGED"] = "Merged %d spell cache entries from %s."
L["GEMS_P2P_ENABLED"] = "Enable P2P Sharing"
L["GEMS_P2P_ENABLED_DESC"] = "Allow sending and receiving sequences with other GRIP-EMS users."
L["GEMS_P2P_AUTO_FRIENDS"] = "Auto-Accept from Friends"
L["GEMS_P2P_AUTO_FRIENDS_DESC"] = "Automatically import sequences received from friends without prompting."
L["GEMS_P2P_ANNOUNCE"] = "Announce Received"
L["GEMS_P2P_ANNOUNCE_DESC"] = "Print a chat message when receiving a sequence from another player."
L["GEMS_IMPORT_FROM"] = "Import from %s"

-- Block list (T2-9)
L["GEMS_BLOCK_ADDED"] = "Blocked %s from P2P transmission."
L["GEMS_BLOCK_REMOVED"] = "Unblocked %s."
L["GEMS_BLOCK_NOT_FOUND"] = "%s is not blocked."
L["GEMS_BLOCK_LIST_EMPTY"] = "No players blocked."
L["GEMS_BLOCK_LIST_HEADER"] = "Blocked players:"
L["GEMS_SETTINGS_BLOCKED_PLAYERS"] = "Blocked Players"
L["GEMS_SETTINGS_BLOCKED_PLAYERS_DESC"] = "Players on this list cannot send you sequences."
L["GEMS_HELP_BLOCK"] = "  /gems block <player> - Block a player from P2P transmission"
L["GEMS_HELP_UNBLOCK"] = "  /gems unblock <player> - Unblock a player"
L["GEMS_HELP_BLOCKLIST"] = "  /gems blocklist - List all blocked players"

-- Tracker HUD (T2-7)
L["GEMS_TRACKER_TOGGLE"] = "Tracker HUD %s."
L["GEMS_TRACKER_LOCKED"] = "Tracker locked."
L["GEMS_TRACKER_UNLOCKED"] = "Tracker unlocked."
L["GEMS_TRACKER_HEADER"] = "Tracker HUD"
L["GEMS_TRACKER_ICONSIZE_DESC"] = "Set the size of each sequence icon (pixels)"
L["GEMS_TRACKER_ORIENTATION_DESC"] = "Stack icons horizontally or vertically"
L["GEMS_TRACKER_SHOWNAME_DESC"] = "Show sequence name below each icon"
L["GEMS_TRACKER_SHOWMODS_DESC"] = "Show active modifier keys (Alt/Shift/Ctrl)"
L["GEMS_TRACKER_LOCK_DESC"] = "Lock the tracker frame position"
L["GEMS_TRACKER_SHOWMODE_DESC"] = "Choose when to show the Tracker HUD"
L["GEMS_TRACKER_MODE_ALWAYS"] = "Always"
L["GEMS_TRACKER_MODE_COMBAT"] = "In Combat"
L["GEMS_TRACKER_MODE_TARGET"] = "Has Target"
L["GEMS_TRACKER_MODE_NEVER"] = "Never"
L["GEMS_TRACKER_SCALE_DESC"] = "Scale the Tracker HUD frame"
L["GEMS_TRACKER_PREVIEW_HINT"] = "Preview shows current state. Combat variables may differ."
L["GEMS_HELP_TRACKER"] = "  /gems tracker [lock] - Toggle tracker HUD"

-- Debug window (T1-6)
L["GEMS_HELP_DEBUGWINDOW"] = "  /gems debugwindow - Toggle debug message window"
L["GEMS_DEBUG_WINDOW_TITLE"] = "GRIP-EMS Debug"
L["GEMS_DEBUG_CLEAR"] = "Clear"
L["GEMS_DEBUG_COPY"] = "Copy"
L["GEMS_DEBUG_COPY_HINT"] = "Use /gems export or Ctrl+C from the export frame to copy debug output."
L["GEMS_UI_WHATSNEW_DISMISS"] = "Don't show again"
L["GEMS_WHATSNEW_DISMISS_DESC"] = "Don't show this again for this version"
L["GEMS_DEBUG_CLOSE_DESC"] = "Close debug window"
L["GEMS_DEBUG_CLEAR_DESC"] = "Clear all debug messages"
L["GEMS_DEBUG_COPY_DESC"] = "Copy all messages to clipboard"

-- Locale Phase 2e
L["GEMS_HELP_REVALIDATE"] = "  /gems revalidate - Force re-tag all sequences with spell IDs"

-- Click rate (v1.2.0 S01)
L["GEMS_SETTINGS_CLICK_RATE"] = "Click Rate (ms)"
L["GEMS_SETTINGS_CLICK_RATE_DESC"] =
    "Minimum milliseconds between key presses. Lower = faster sequencing. Default: 250ms."
L["GEMS_SETTINGS_CHAR_OVERRIDES"] = "Character Overrides"
L["GEMS_SETTINGS_CHAR_CLICK_RATE"] = "Per-Character Click Rate (ms)"
L["GEMS_SETTINGS_CHAR_CLICK_RATE_DESC"] =
    "Override click rate for this character only. Set to 0 to use the global value."
L["GEMS_STATUS_CLICK_RATE"] = "Click Rate: %dms (effective)"

-- Macro reset modifiers (v1.2.0 S01)
L["GEMS_SETTINGS_MACRO_RESET"] = "Macro Reset"
L["GEMS_RESET_MOD_DESC"] = "Reset step counter to 1 when this modifier is held during a key press."
L["GEMS_UI_RESET_MODS_HEADER"] = "Reset Modifier Overrides"
L["GEMS_UI_RESET_MODS_ENABLE"] = "Use per-sequence overrides"
L["GEMS_UI_RESET_MODS_GLOBAL"] = "(using global settings)"
L["GEMS_RESET_MOD_LEFTBUTTON"] = "Left Click"
L["GEMS_RESET_MOD_RIGHTBUTTON"] = "Right Click"
L["GEMS_RESET_MOD_MIDDLEBUTTON"] = "Middle Click"
L["GEMS_RESET_MOD_BUTTON4"] = "Mouse Button 4"
L["GEMS_RESET_MOD_BUTTON5"] = "Mouse Button 5"
L["GEMS_RESET_MOD_LEFTALT"] = "Left Alt"
L["GEMS_RESET_MOD_RIGHTALT"] = "Right Alt"
L["GEMS_RESET_MOD_ALT"] = "Any Alt"
L["GEMS_RESET_MOD_LEFTCONTROL"] = "Left Control"
L["GEMS_RESET_MOD_RIGHTCONTROL"] = "Right Control"
L["GEMS_RESET_MOD_CONTROL"] = "Any Control"
L["GEMS_RESET_MOD_LEFTSHIFT"] = "Left Shift"
L["GEMS_RESET_MOD_RIGHTSHIFT"] = "Right Shift"
L["GEMS_RESET_MOD_SHIFT"] = "Any Shift"
L["GEMS_RESET_MOD_ANYMOD"] = "Any Modifier"
L["GEMS_RESET_MOD_MOUSE_HEADER"] = "Mouse Buttons"
L["GEMS_RESET_MOD_ALT_HEADER"] = "Alt Keys"
L["GEMS_RESET_MOD_CONTROL_HEADER"] = "Control Keys"
L["GEMS_RESET_MOD_SHIFT_HEADER"] = "Shift Keys"
L["GEMS_RESET_MOD_ANY_HEADER"] = "Combination"

-- Corrupt sequence recovery
L["GEMS_CORRUPT_TITLE"] = "Corrupt Sequence Detected"
L["GEMS_CORRUPT_TEXT"] = "The sequence '%s' could not be loaded.\n\nError: %s\n\nChoose an action:"
L["GEMS_CORRUPT_DELETE"] = "Delete"
L["GEMS_CORRUPT_SKIP"] = "Skip"
L["GEMS_CORRUPT_EXPORT"] = "Export Raw"
L["GEMS_CORRUPT_SUMMARY"] = "Corrupt sequences: %d deleted, %d skipped, %d exported"
L["GEMS_CORRUPT_NONE"] = "No corrupt sequences found."

-- Execution Tracer (v1.2.0 S03-B)
L["GEMS_TRACE_CAST"] = "[Trace] %s (ID: %d)%s"
L["GEMS_TRACE_STARTED"] = "Execution tracing started"
L["GEMS_TRACE_STOPPED"] = "Execution tracing stopped"

-- CVar health (v1.2.0 S01)
L["GEMS_SETTINGS_CVAR_HEALTH"] = "CVar Health"
L["GEMS_SETTINGS_CVAR_DESC"] =
    "Game variables across 13 categories (212 CVars). Green = optimal, yellow = suboptimal, red = critical, grey = informational."
L["GEMS_SETTINGS_CVAR_AUTOFIX"] = "Auto-Fix CVars on Login"
L["GEMS_SETTINGS_CVAR_AUTOFIX_DESC"] = "Automatically set recommended CVar values when you log in."
L["GEMS_SETTINGS_CVAR_FIX"] = "Fix"

-- CVar Dashboard UI strings
L["GEMS_CVAR_FIX_ALL"] = "Fix All"
L["GEMS_CVAR_FIX_ALL_CRITICAL"] = "Fix All Critical"
L["GEMS_CVAR_FIX_ALL_SECTION"] = "Fix All in Section"
L["GEMS_CVAR_AUTOFIX_ENTRY"] = "Auto-fix on login"
L["GEMS_CVAR_AUTOFIX_COUNT"] = "GEMS: Auto-fixed %d CVars on login."
L["GEMS_CVAR_HEALTH_SCORE"] = "CVar Health: %d/100"
L["GEMS_CVAR_SECURE_TAG"] = " (secure)"
L["GEMS_CVAR_COMBAT_DISABLED"] = "Cannot change secure CVars in combat."
L["GEMS_CVAR_INFORMATIONAL"] = " (informational)"
L["GEMS_CVAR_YOUR_CHOICE"] = "(your choice)"
L["GEMS_CVAR_WILL_CHANGE"] = "Will change from %s to %s."
L["GEMS_CVAR_SET_VALUE"] = "Set Value"

-- CVar Section Headers
L["GEMS_CVAR_SECTION_MACRO"] = "Macro Sequencing"
L["GEMS_CVAR_SECTION_COMBAT"] = "Combat & Targeting"
L["GEMS_CVAR_SECTION_NAMEPLATES"] = "Nameplates"
L["GEMS_CVAR_SECTION_RAIDING"] = "Raiding"
L["GEMS_CVAR_SECTION_DUNGEON"] = "Dungeons & M+"
L["GEMS_CVAR_SECTION_SOLO"] = "Solo Play & Open World"
L["GEMS_CVAR_SECTION_UI"] = "UI & Quality of Life"
L["GEMS_CVAR_SECTION_FPS"] = "FPS & Performance"
L["GEMS_CVAR_SECTION_VISUAL"] = "Visual Quality"
L["GEMS_CVAR_SECTION_SOUND"] = "Sound"
L["GEMS_CVAR_SECTION_FCT"] = "Floating Combat Text"
L["GEMS_CVAR_SECTION_ACCESS"] = "Accessibility"
L["GEMS_CVAR_SECTION_DRAGON"] = "Dragonriding & Advanced Flying"

-- CVar Section: Macro Sequencing
L["GEMS_CVAR_MACRO_KEYDOWN"] = "Key Down Casting"
L["GEMS_CVAR_MACRO_KEYDOWN_DESC"] =
    "Fire abilities on key press, not release. If 0, every macro keypress has 50-100ms extra delay. Mandatory for sequencing."
L["GEMS_CVAR_MACRO_KEYHELD"] = "Hold to Cast"
L["GEMS_CVAR_MACRO_KEYHELD_DESC"] =
    "Press-and-hold auto-repeats the ability. Only works with native Blizzard ActionButton frames, not addon-created buttons. Hold Mode manages this CVar automatically when active. Preference-based, not a blanket recommendation. Informational."
L["GEMS_CVAR_MACRO_SPELLQUEUE"] = "Spell Queue Window"
L["GEMS_CVAR_MACRO_SPELLQUEUE_DESC"] =
    "Milliseconds before GCD ends that the next spell can be queued. 400ms is optimal for most players."
L["GEMS_CVAR_MACRO_LOCKBARS"] = "Lock Action Bars"
L["GEMS_CVAR_MACRO_LOCKBARS_DESC"] = "Prevents accidental drag-off of macro stubs from action bars during combat."
L["GEMS_CVAR_MACRO_MULTIBARS"] = "Multi Action Bars"
L["GEMS_CVAR_MACRO_MULTIBARS_DESC"] =
    "Bitfield for additional action bars (0=none, 15=all). More bars = more room for macro stubs. Informational."
L["GEMS_CVAR_MACRO_AUTOPUSH"] = "Auto Push Spells"
L["GEMS_CVAR_MACRO_AUTOPUSH_DESC"] =
    "Auto-places new spells on bars. Recommend OFF -- new spells from leveling push macro stubs off the bar."
L["GEMS_CVAR_MACRO_SELFCAST"] = "Auto Self Cast"
L["GEMS_CVAR_MACRO_SELFCAST_DESC"] =
    "Auto-cast beneficial spells on self when no valid target. Important for macro steps with self-heals."
L["GEMS_CVAR_MACRO_AUTOSTAND"] = "Auto Stand"
L["GEMS_CVAR_MACRO_AUTOSTAND_DESC"] =
    "Auto-stand when casting. Without this, macro sequences fail silently while sitting."
L["GEMS_CVAR_MACRO_AUTOUNSHIFT"] = "Auto Unshift"
L["GEMS_CVAR_MACRO_AUTOUNSHIFT_DESC"] =
    "Auto-leave shapeshift/stealth when casting incompatible spells. Without this, Druid/Rogue macro steps fail silently."
L["GEMS_CVAR_MACRO_STOPATTACK"] = "Stop Attack on Switch"
L["GEMS_CVAR_MACRO_STOPATTACK_DESC"] =
    "Keep auto-attacking when switching targets. If 1, target-switching mid-sequence stops melee auto-attacks."
L["GEMS_CVAR_MACRO_ICONRATE"] = "Icon Update Rate"
L["GEMS_CVAR_MACRO_ICONRATE_DESC"] =
    "How often action bar icons refresh (seconds). 0.05 = 20 updates/sec, smoother than default 0.1."
L["GEMS_CVAR_MACRO_CDCOUNT"] = "Cooldown Countdown"
L["GEMS_CVAR_MACRO_CDCOUNT_DESC"] =
    "Show numeric cooldown timers on action buttons. Critical for seeing exact remaining cooldown on the sequence button."
L["GEMS_CVAR_MACRO_SECTOGGLE"] = "Secure Ability Toggle"
L["GEMS_CVAR_MACRO_SECTOGGLE_DESC"] =
    "Prevents double-click toggling abilities off. Protects against rapid keypresses deactivating toggle abilities."
L["GEMS_CVAR_MACRO_EMPTAP"] = "Empower Tap Controls"
L["GEMS_CVAR_MACRO_EMPTAP_DESC"] =
    "Tap-tap vs hold-release for empowered spells (Evoker). Hold-release works better with sequences."
L["GEMS_CVAR_MACRO_EMPHOLD"] = "Empower Hold Stage"
L["GEMS_CVAR_MACRO_EMPHOLD_DESC"] =
    "Percentage of first empower stage required before auto-release [0.0-1.0]. Evoker-specific."
L["GEMS_CVAR_MACRO_HELDPOLL"] = "Held Spell Poll Time"
L["GEMS_CVAR_MACRO_HELDPOLL_DESC"] =
    "Milliseconds between retry attempts when held-spell casting fails. Lower = faster retry, more responsive."
L["GEMS_CVAR_MACRO_PRECAST"] = "Preemptive Cast"
L["GEMS_CVAR_MACRO_PRECAST_DESC"] =
    "Preemptive cast visual triggering based on spell release timing. Undocumented visual feature."

-- CVar Section: Combat & Targeting
L["GEMS_CVAR_COMBAT_SOFTENEMY"] = "Soft Target Enemy"
L["GEMS_CVAR_COMBAT_SOFTENEMY_DESC"] =
    "When soft targeting activates for enemies. 0=off, 1=gamepad, 2=KBM, 3=always. Recommend 3 for auto-acquire."
L["GEMS_CVAR_COMBAT_SOFTARC"] = "Soft Target Arc"
L["GEMS_CVAR_COMBAT_SOFTARC_DESC"] =
    "Directional constraint for enemy soft target. 0=must face directly, 1=front arc, 2=anywhere."
L["GEMS_CVAR_COMBAT_SOFTRANGE"] = "Soft Target Range"
L["GEMS_CVAR_COMBAT_SOFTRANGE_DESC"] =
    "Max range for soft target enemy detection (yards). 45yd covers most ranged abilities."
L["GEMS_CVAR_COMBAT_SOFTFORCE"] = "Soft Target Force"
L["GEMS_CVAR_COMBAT_SOFTFORCE_DESC"] =
    "Auto-hardlock soft target. Without this, soft targeting shows the target but spells fire at nothing."
L["GEMS_CVAR_COMBAT_SOFTFRIEND"] = "Soft Target Friend"
L["GEMS_CVAR_COMBAT_SOFTFRIEND_DESC"] =
    "Soft targeting for friendlies. 0=off. Healers may want 3 (always). DPS should leave at 0."
L["GEMS_CVAR_COMBAT_SOFTLOCKED"] = "Soft With Locked"
L["GEMS_CVAR_COMBAT_SOFTLOCKED_DESC"] =
    "Allow soft target while having a hard-locked target. 2=always allows soft target preview."
L["GEMS_CVAR_COMBAT_SOFTMATCH"] = "Soft Match Locked"
L["GEMS_CVAR_COMBAT_SOFTMATCH_DESC"] =
    "Match soft target to locked target. Keeps the soft target indicator synced with your actual target."
L["GEMS_CVAR_COMBAT_TABNEW"] = "New Tab Targeting"
L["GEMS_CVAR_COMBAT_TABNEW_DESC"] =
    "Use modern (7.2+) tab-targeting algorithm. Prioritizes enemies in front of you and in combat."
L["GEMS_CVAR_COMBAT_COMBATLOCK"] = "Combat Target Lock"
L["GEMS_CVAR_COMBAT_COMBATLOCK_DESC"] =
    "Lock tab-target to in-combat enemies. Prevents jumping to distant mobs not yet pulled."
L["GEMS_CVAR_COMBAT_LOCKRELAX"] = "Lock Relaxation"
L["GEMS_CVAR_COMBAT_LOCKRELAX_DESC"] = "Smart relaxation of combat lock when no in-combat targets are available."
L["GEMS_CVAR_COMBAT_PVPPRIO"] = "PvP Target Priority"
L["GEMS_CVAR_COMBAT_PVPPRIO_DESC"] = "In PvP, prioritize players and important PvP targets. 1=players first."
L["GEMS_CVAR_COMBAT_ATTACKER"] = "Target Attacker"
L["GEMS_CVAR_COMBAT_ATTACKER_DESC"] = "Auto-target enemies that attack you. Essential for solo play where mobs aggro."
L["GEMS_CVAR_COMBAT_AUTOENEMY"] = "Auto Target Enemy"
L["GEMS_CVAR_COMBAT_AUTOENEMY_DESC"] =
    "Auto-target nearest enemy when casting offensive spells with no target. Ensures macros fire."
L["GEMS_CVAR_COMBAT_DESELECT"] = "Deselect on Click"
L["GEMS_CVAR_COMBAT_DESELECT_DESC"] =
    "Clear target when clicking terrain. If 1, clicking ground mid-fight drops your target."
L["GEMS_CVAR_COMBAT_LEFTCLICK"] = "Interact Left Click"
L["GEMS_CVAR_COMBAT_LEFTCLICK_DESC"] = "Left-click interacts with NPCs. Standard behavior most players expect."
L["GEMS_CVAR_COMBAT_HIGHLIGHT"] = "Combat Highlight"
L["GEMS_CVAR_COMBAT_HIGHLIGHT_DESC"] =
    "Next-spell-to-cast highlight. Competes visually with sequence tracking. Recommend OFF."
L["GEMS_CVAR_COMBAT_PROCS"] = "Proc Overlays"
L["GEMS_CVAR_COMBAT_PROCS_DESC"] =
    "Show proc/spell alert overlays (glowing borders). Important for seeing procs that affect macro priority."
L["GEMS_CVAR_COMBAT_PROCOPACITY"] = "Proc Overlay Opacity"
L["GEMS_CVAR_COMBAT_PROCOPACITY_DESC"] =
    "Opacity of spell alert overlays. Default 0.65 is good. Increase to 0.8-1.0 if hard to see."
L["GEMS_CVAR_COMBAT_LOC"] = "Loss of Control"
L["GEMS_CVAR_COMBAT_LOC_DESC"] =
    "Show loss-of-control banner when stunned/silenced. Helps understand why a macro sequence appears stuck."
L["GEMS_CVAR_COMBAT_MOUSEOVER"] = "Mouseover Casting"
L["GEMS_CVAR_COMBAT_MOUSEOVER_DESC"] =
    "Cast on unit under cursor without targeting. Huge for healers. Informational, not auto-fix."
L["GEMS_CVAR_COMBAT_FRIENDARC"] = "Friend Soft Arc"
L["GEMS_CVAR_COMBAT_FRIENDARC_DESC"] =
    "Directional constraint for friendly soft target. Mirrors SoftTargetEnemyArc. Only if SoftTargetFriend is on."
L["GEMS_CVAR_COMBAT_FRIENDRANGE"] = "Friend Soft Range"
L["GEMS_CVAR_COMBAT_FRIENDRANGE_DESC"] = "Max range for soft target friend detection. 45yd covers all healing spells."

-- CVar Section: Nameplates
L["GEMS_CVAR_NAMEPLATES_SHOWALL"] = "Show All Nameplates"
L["GEMS_CVAR_NAMEPLATES_SHOWALL_DESC"] =
    "Show ALL nameplates (enemies, friendly NPCs, pets). Master toggle. Most combat players want this on."
L["GEMS_CVAR_NAMEPLATES_SHOWENEMY"] = "Show Enemy Nameplates"
L["GEMS_CVAR_NAMEPLATES_SHOWENEMY_DESC"] = "Show enemy nameplates. Must be on for any combat awareness."
L["GEMS_CVAR_NAMEPLATES_SHOWSELF"] = "Show Self Nameplate"
L["GEMS_CVAR_NAMEPLATES_SHOWSELF_DESC"] =
    "Show personal resource display (health/mana bar under your character). Many players don't know this exists."
L["GEMS_CVAR_NAMEPLATES_MAXDIST"] = "Max Distance"
L["GEMS_CVAR_NAMEPLATES_MAXDIST_DESC"] =
    "Max nameplate render distance. 60yd is the cap and default. Lower values save GPU but lose awareness."
L["GEMS_CVAR_NAMEPLATES_PLAYERDIST"] = "Player Max Distance"
L["GEMS_CVAR_NAMEPLATES_PLAYERDIST_DESC"] =
    "Max distance for player nameplates specifically. Keep equal to nameplateMaxDistance."
L["GEMS_CVAR_NAMEPLATES_MINALPHA"] = "Min Opacity"
L["GEMS_CVAR_NAMEPLATES_MINALPHA_DESC"] =
    "Minimum opacity for distant nameplates. Default 0.6 makes far nameplates hard to see. 0.8 is better."
L["GEMS_CVAR_NAMEPLATES_MAXALPHA"] = "Max Opacity"
L["GEMS_CVAR_NAMEPLATES_MAXALPHA_DESC"] =
    "Maximum opacity for nearby nameplates. 1.0 = fully opaque. No reason to lower."
L["GEMS_CVAR_NAMEPLATES_MINSCALE"] = "Min Scale"
L["GEMS_CVAR_NAMEPLATES_MINSCALE_DESC"] =
    "Minimum scale for distant nameplates. Lower values make far nameplates too small to read."
L["GEMS_CVAR_NAMEPLATES_MAXSCALE"] = "Max Scale"
L["GEMS_CVAR_NAMEPLATES_MAXSCALE_DESC"] = "Maximum scale for nearby nameplates."
L["GEMS_CVAR_NAMEPLATES_SELSCALE"] = "Selected Scale"
L["GEMS_CVAR_NAMEPLATES_SELSCALE_DESC"] =
    "Scale multiplier for your current target's nameplate. Default 1.2 makes the target visually distinct."
L["GEMS_CVAR_NAMEPLATES_OCCLUDED"] = "Occluded Opacity"
L["GEMS_CVAR_NAMEPLATES_OCCLUDED_DESC"] =
    "Opacity for nameplates behind walls/objects. Default 0.4 is nearly invisible. 0.6 keeps them readable."
L["GEMS_CVAR_NAMEPLATES_OVERLAPH"] = "Horizontal Overlap"
L["GEMS_CVAR_NAMEPLATES_OVERLAPH_DESC"] =
    "Horizontal stacking overlap. Lower = more spread. 0.8 is the default stacking behavior."
L["GEMS_CVAR_NAMEPLATES_OVERLAPV"] = "Vertical Overlap"
L["GEMS_CVAR_NAMEPLATES_OVERLAPV_DESC"] =
    "Vertical stacking overlap. Controls how nameplates stack vertically in AoE packs."
L["GEMS_CVAR_NAMEPLATES_CASTBARS"] = "Nameplate Cast Bars"
L["GEMS_CVAR_NAMEPLATES_CASTBARS_DESC"] = "Show cast bars on nameplates. Essential for interrupting."
L["GEMS_CVAR_NAMEPLATES_CLASSCOLOR"] = "Class Color Bars"
L["GEMS_CVAR_NAMEPLATES_CLASSCOLOR_DESC"] =
    "Color enemy nameplate health bars by class. Important for PvP target identification."
L["GEMS_CVAR_NAMEPLATES_DEBUFFS"] = "Friendly Debuffs"
L["GEMS_CVAR_NAMEPLATES_DEBUFFS_DESC"] = "Show debuffs on friendly nameplates. Useful for healers and dispellers."
L["GEMS_CVAR_NAMEPLATES_MINIONS"] = "Enemy Minions"
L["GEMS_CVAR_NAMEPLATES_MINIONS_DESC"] =
    "Show minion nameplates. Off by default to reduce clutter. Enable in M+ if minion health matters."
L["GEMS_CVAR_NAMEPLATES_MINUS"] = "Trivial Enemies"
L["GEMS_CVAR_NAMEPLATES_MINUS_DESC"] =
    "Show nameplates for trivial (minus) enemies. Useful in open world for seeing all mobs."
L["GEMS_CVAR_NAMEPLATES_TOTEMS"] = "Enemy Totems"
L["GEMS_CVAR_NAMEPLATES_TOTEMS_DESC"] = "Show enemy totem nameplates. Important in PvP -- totems are kill targets."
L["GEMS_CVAR_NAMEPLATES_FRIENDLY"] = "Friendly Players"
L["GEMS_CVAR_NAMEPLATES_FRIENDLY_DESC"] =
    "Show friendly player nameplates. Off in PvE to reduce clutter. On in PvP for awareness."
L["GEMS_CVAR_NAMEPLATES_AURASCALE"] = "Aura Icon Scale"
L["GEMS_CVAR_NAMEPLATES_AURASCALE_DESC"] =
    "Scale multiplier for buff/debuff icons on nameplates. 1.2 makes DoT tracking easier at a glance."
L["GEMS_CVAR_NAMEPLATES_NAMEONLY"] = "Name Only Friendly"
L["GEMS_CVAR_NAMEPLATES_NAMEONLY_DESC"] =
    "Strip friendly nameplates to name-only (no health bar). Reduces visual noise in raids."
L["GEMS_CVAR_NAMEPLATES_ATBASE"] = "Position at Base"
L["GEMS_CVAR_NAMEPLATES_ATBASE_DESC"] =
    "Position non-target nameplates at base of character instead of overhead. 0=overhead (standard)."
L["GEMS_CVAR_NAMEPLATES_OFFSCREEN"] = "Show Offscreen"
L["GEMS_CVAR_NAMEPLATES_OFFSCREEN_DESC"] = "Show nameplates for off-screen targets. Can be useful but also cluttery."
L["GEMS_CVAR_NAMEPLATES_RADIAL"] = "Radial Position"
L["GEMS_CVAR_NAMEPLATES_RADIAL_DESC"] = "Show target nameplate radially around screen edge when off-screen. 0=off."
L["GEMS_CVAR_NAMEPLATES_SOFTNP"] = "Soft Target Nameplate"
L["GEMS_CVAR_NAMEPLATES_SOFTNP_DESC"] = "Always show nameplate for soft-targeted enemy."
L["GEMS_CVAR_NAMEPLATES_SOFTSIZE"] = "Soft Target Size"
L["GEMS_CVAR_NAMEPLATES_SOFTSIZE_DESC"] =
    "Size of the soft target indicator on nameplates. Default 19 can be hard to see. 25 is better."
L["GEMS_CVAR_NAMEPLATES_DEBUFFPAD"] = "Debuff Padding"
L["GEMS_CVAR_NAMEPLATES_DEBUFFPAD_DESC"] = "Padding between debuff list and health bar. 0 = compact."
L["GEMS_CVAR_NAMEPLATES_MOTION"] = "Stacking Behavior"
L["GEMS_CVAR_NAMEPLATES_MOTION_DESC"] =
    "Nameplate stacking. 0=overlapping, 1=stacking (vertical column), 2=spreading (default fan-out)."
L["GEMS_CVAR_NAMEPLATES_MOTIONSPD"] = "Stacking Speed"
L["GEMS_CVAR_NAMEPLATES_MOTIONSPD_DESC"] =
    "Animation speed for nameplates moving into stacked/spread positions. Higher = faster snapping."

-- CVar Section: Raiding
L["GEMS_CVAR_RAIDING_COMBATLOG"] = "Advanced Combat Logging"
L["GEMS_CVAR_RAIDING_COMBATLOG_DESC"] =
    "Enable advanced combat logging (CLEU extra data). Required for accurate Warcraft Logs analysis."
L["GEMS_CVAR_RAIDING_THREATWARN"] = "Threat Warning"
L["GEMS_CVAR_RAIDING_THREATWARN_DESC"] = "Threat warning display. 0=off, 1=dungeons, 2=party, 3=always."
L["GEMS_CVAR_RAIDING_THREATNUM"] = "Numeric Threat"
L["GEMS_CVAR_RAIDING_THREATNUM_DESC"] =
    "Show numeric threat values on target/focus frames. Useful for tanks and threat-conscious DPS."
L["GEMS_CVAR_RAIDING_THREATSOUND"] = "Threat Sounds"
L["GEMS_CVAR_RAIDING_THREATSOUND_DESC"] = "Play sounds on threat transitions (aggro gain/loss)."
L["GEMS_CVAR_RAIDING_THREATTEXT"] = "Threat World Text"
L["GEMS_CVAR_RAIDING_THREATTEXT_DESC"] = "Show threat floaters in combat (the aggro text)."
L["GEMS_CVAR_RAIDING_TIMELINE"] = "Encounter Timeline"
L["GEMS_CVAR_RAIDING_TIMELINE_DESC"] = "Enable the boss encounter timeline. Shows upcoming boss abilities."
L["GEMS_CVAR_RAIDING_TIMEROLE"] = "Timeline Role Filter"
L["GEMS_CVAR_RAIDING_TIMEROLE_DESC"] =
    "Hide encounter timeline events irrelevant to your role. Reduces noise for DPS/healers."
L["GEMS_CVAR_RAIDING_WARNINGS"] = "Encounter Warnings"
L["GEMS_CVAR_RAIDING_WARNINGS_DESC"] = "Show encounter warning messages (boss ability alerts)."
L["GEMS_CVAR_RAIDING_WARNHIDE"] = "Hide Non-Target Warns"
L["GEMS_CVAR_RAIDING_WARNHIDE_DESC"] =
    "Hide boss warnings not targeting you. 0=show all (safer). 1=less noise for experienced raiders."
L["GEMS_CVAR_RAIDING_AGGRO"] = "Aggro Highlight"
L["GEMS_CVAR_RAIDING_AGGRO_DESC"] = "Highlight raid frames when that player has aggro."
L["GEMS_CVAR_RAIDING_RDEBUFFS"] = "Raid Frame Debuffs"
L["GEMS_CVAR_RAIDING_RDEBUFFS_DESC"] = "Show debuffs on raid frames. Essential for healers and dispellers."
L["GEMS_CVAR_RAIDING_HEALPRED"] = "Incoming Heals"
L["GEMS_CVAR_RAIDING_HEALPRED_DESC"] = "Show incoming heal predictions on raid frames."
L["GEMS_CVAR_RAIDING_POWERBARS"] = "Raid Power Bars"
L["GEMS_CVAR_RAIDING_POWERBARS_DESC"] = "Show mana/rage/energy bars on raid frames. Off by default to save space."
L["GEMS_CVAR_RAIDING_RCLASSCOLOR"] = "Raid Class Colors"
L["GEMS_CVAR_RAIDING_RCLASSCOLOR_DESC"] =
    "Color raid frame health bars by class. Makes it easier to identify players at a glance."
L["GEMS_CVAR_RAIDING_DISPONLY"] = "Dispellable Only"
L["GEMS_CVAR_RAIDING_DISPONLY_DESC"] = "Filter to only show debuffs you can dispel. 0=show all."
L["GEMS_CVAR_RAIDING_ROLEDEBUFF"] = "Role Debuff Size"
L["GEMS_CVAR_RAIDING_ROLEDEBUFF_DESC"] =
    "Show role-relevant debuffs at larger size. Tank debuffs bigger for tanks, healer debuffs for healers."
L["GEMS_CVAR_RAIDING_BIGDEF"] = "Center Big Defensives"
L["GEMS_CVAR_RAIDING_BIGDEF_DESC"] =
    "Show big defensive cooldowns (Ironbark, Pain Suppression) centered on the raid frame."
L["GEMS_CVAR_RAIDING_DISPTYPE"] = "Dispel Indicator"
L["GEMS_CVAR_RAIDING_DISPTYPE_DESC"] = "Dispel indicator style. 0=none, 1=icon, 2=icon+highlight."
L["GEMS_CVAR_RAIDING_HEALTHTEXT"] = "Health Text Mode"
L["GEMS_CVAR_RAIDING_HEALTHTEXT_DESC"] =
    "Health text display mode. none, health, losthealth, or perc. Preference-based."
L["GEMS_CVAR_RAIDING_SORTMODE"] = "Raid Sort Mode"
L["GEMS_CVAR_RAIDING_SORTMODE_DESC"] = "Raid frame sort mode. role (tanks/healers/DPS), group, or alphabetical."
L["GEMS_CVAR_RAIDING_KEEPGRP"] = "Keep Groups Together"
L["GEMS_CVAR_RAIDING_KEEPGRP_DESC"] = "Keep raid groups visually separated. 0=intermix, 1=group blocks."
L["GEMS_CVAR_RAIDING_TANKASSIST"] = "Tank and Assist"
L["GEMS_CVAR_RAIDING_TANKASSIST_DESC"] = "Show main tank and main assist units in raid frames."
L["GEMS_CVAR_RAIDING_FINDSELF"] = "Find Yourself"
L["GEMS_CVAR_RAIDING_FINDSELF_DESC"] = "Highlight your own character in raid frames."
L["GEMS_CVAR_RAIDING_CASTBUFFS"] = "Castable Buffs"
L["GEMS_CVAR_RAIDING_CASTBUFFS_DESC"] = "Show only buffs you can cast (raid only). 0=show all."
L["GEMS_CVAR_RAIDING_DISPDEBUFFS"] = "Show Dispel Debuffs"
L["GEMS_CVAR_RAIDING_DISPDEBUFFS_DESC"] = "Show only debuffs you can dispel (raid only)."
L["GEMS_CVAR_RAIDING_RAIDSETTINGS"] = "Raid Graphics Settings"
L["GEMS_CVAR_RAIDING_RAIDSETTINGS_DESC"] =
    "Enable separate graphics settings for raids. Biggest single raid FPS improvement. Many players miss this."
L["GEMS_CVAR_RAIDING_NOFILTER"] = "No Buff/Debuff Filter"
L["GEMS_CVAR_RAIDING_NOFILTER_DESC"] =
    "Disable ALL buff/debuff filtering on target frame. 0=normal filtering. 1=see everything."
L["GEMS_CVAR_RAIDING_SPELLCLUTTER"] = "Spell Visual Clutter"
L["GEMS_CVAR_RAIDING_SPELLCLUTTER_DESC"] =
    "Spell visual density. 1=essential only, 2=reduced, 3=some, 4=everything. Lower = cleaner raids."
L["GEMS_CVAR_RAIDING_MYSPELLS"] = "Emphasize My Spells"
L["GEMS_CVAR_RAIDING_MYSPELLS_DESC"] =
    "Tone down other players' spell effects while keeping yours at full. Essential in 20-man raids."
L["GEMS_CVAR_RAIDING_COMBATWARN"] = "Combat Warnings"
L["GEMS_CVAR_RAIDING_COMBATWARN_DESC"] = "Master toggle for combat warning UI (boss timeline + warnings)."

-- CVar Section: Dungeons & M+
L["GEMS_CVAR_DUNGEON_DPSRESET"] = "DPS Meter Reset"
L["GEMS_CVAR_DUNGEON_DPSRESET_DESC"] =
    "Auto-reset damage meter on new instance entry. Clean data per dungeon without manual reset."
L["GEMS_CVAR_DUNGEON_ENTRANCE"] = "Dungeon Entrances"
L["GEMS_CVAR_DUNGEON_ENTRANCE_DESC"] = "Show dungeon entrance icons on the world map."
L["GEMS_CVAR_DUNGEON_CLUTTER"] = "Unit Clutter Filter"
L["GEMS_CVAR_DUNGEON_CLUTTER_DESC"] = "Limit unit clutter (NPC stacking reduction) to instances only."
L["GEMS_CVAR_DUNGEON_ENEMYCAST"] = "Enemy Cast Bars"
L["GEMS_CVAR_DUNGEON_ENEMYCAST_DESC"] = "Show enemy cast bars on arena frames. Also affects M+ party awareness."
L["GEMS_CVAR_DUNGEON_LOGTIME"] = "Log Retention Time"
L["GEMS_CVAR_DUNGEON_LOGTIME_DESC"] =
    "Seconds to keep combat log entries. 300s default. Increase to 600 for long M+ pulls."
L["GEMS_CVAR_DUNGEON_LOGFILE"] = "Unique Log Filenames"
L["GEMS_CVAR_DUNGEON_LOGFILE_DESC"] = "Use timestamped combat log filenames. Prevents overwriting previous logs."
L["GEMS_CVAR_DUNGEON_DIMINISH"] = "CC Diminishing Returns"
L["GEMS_CVAR_DUNGEON_DIMINISH_DESC"] = "Show crowd control diminishing returns on enemy frames."

-- CVar Section: Solo Play & Open World
L["GEMS_CVAR_SOLO_AUTOLOOT"] = "Auto Loot"
L["GEMS_CVAR_SOLO_AUTOLOOT_DESC"] =
    "Auto-loot items. Default OFF means clicking each item individually. Almost every player wants this ON."
L["GEMS_CVAR_SOLO_LOOTRATE"] = "Loot Speed"
L["GEMS_CVAR_SOLO_LOOTRATE_DESC"] =
    "Milliseconds between auto-loot ticks. Default 150ms feels sluggish. 50ms loots almost instantly."
L["GEMS_CVAR_SOLO_LOOTMOUSE"] = "Loot at Cursor"
L["GEMS_CVAR_SOLO_LOOTMOUSE_DESC"] = "Open loot window at mouse cursor. Saves mouse travel."
L["GEMS_CVAR_SOLO_AELOOT"] = "AoE Looting"
L["GEMS_CVAR_SOLO_AELOOT_DESC"] =
    "Disable area-of-effect looting. 0=AoE loot enabled (loot all nearby corpses at once)."
L["GEMS_CVAR_SOLO_DISMOUNT"] = "Auto Dismount"
L["GEMS_CVAR_SOLO_DISMOUNT_DESC"] = "Auto-dismount when casting."
L["GEMS_CVAR_SOLO_DISMOUNTFLY"] = "Dismount While Flying"
L["GEMS_CVAR_SOLO_DISMOUNTFLY_DESC"] = "Auto-dismount while flying (you will fall). Default OFF is sane."
L["GEMS_CVAR_SOLO_TOT"] = "Target of Target"
L["GEMS_CVAR_SOLO_TOT_DESC"] = "Show target-of-target frame. Essential for tanks (see what the boss targets) and DPS."
L["GEMS_CVAR_SOLO_TCASTBAR"] = "Target Cast Bar"
L["GEMS_CVAR_SOLO_TCASTBAR_DESC"] = "Show your target's cast bar. Essential for interrupting."
L["GEMS_CVAR_SOLO_QUESTWATCH"] = "Auto Quest Watch"
L["GEMS_CVAR_SOLO_QUESTWATCH_DESC"] = "Auto-track quests in the objective tracker when obtained."
L["GEMS_CVAR_SOLO_QUESTPOI"] = "Quest POI on Map"
L["GEMS_CVAR_SOLO_QUESTPOI_DESC"] = "Show quest points of interest on the world map."
L["GEMS_CVAR_SOLO_PARTYPETS"] = "Show Party Pets"
L["GEMS_CVAR_SOLO_PARTYPETS_DESC"] = "Show pet frames in party UI. Off by default to save screen space."
L["GEMS_CVAR_SOLO_INTERACT"] = "Soft Interact"
L["GEMS_CVAR_SOLO_INTERACT_DESC"] =
    "Soft targeting for interactive objects. 0=off, 1=gamepad, 3=always. Huge QoL for questing."
L["GEMS_CVAR_SOLO_INTERARC"] = "Interact Arc"
L["GEMS_CVAR_SOLO_INTERARC_DESC"] =
    "Directional constraint for interact soft target. 0=must face directly, 1=front arc, 2=anywhere."
L["GEMS_CVAR_SOLO_INTERRANGE"] = "Interact Range"
L["GEMS_CVAR_SOLO_INTERRANGE_DESC"] = "Max range for soft interact detection (yards). 10 is the default and cap."
L["GEMS_CVAR_SOLO_INTERICON"] = "Interact Icon"
L["GEMS_CVAR_SOLO_INTERICON_DESC"] = "Show icon indicator for soft interact targets. Keep on for visual feedback."
L["GEMS_CVAR_SOLO_AUTOINTER"] = "Auto Move to Interact"
L["GEMS_CVAR_SOLO_AUTOINTER_DESC"] = "Auto-move to interact target. Can be disorienting in combat areas. Informational."
L["GEMS_CVAR_SOLO_QUESTITEMS"] = "Quest Item Interact"
L["GEMS_CVAR_SOLO_QUESTITEMS_DESC"] =
    "Allow quest item use as an interaction. Enables using quest items directly from soft-interact."

-- CVar Section: UI & Quality of Life
L["GEMS_CVAR_UI_TUTORIALS"] = "Tutorial Popups"
L["GEMS_CVAR_UI_TUTORIALS_DESC"] =
    "Display tutorial popups. Experienced players should disable -- tutorials interrupt gameplay."
L["GEMS_CVAR_UI_NPE"] = "New Player Tutorials"
L["GEMS_CVAR_UI_NPE_DESC"] = "Display New Player Experience tutorials. Disable for experienced players."
L["GEMS_CVAR_UI_LOADTIPS"] = "Loading Screen Tips"
L["GEMS_CVAR_UI_LOADTIPS_DESC"] = "Show tips on loading screens. Low-cost, occasionally useful."
L["GEMS_CVAR_UI_COMPARE"] = "Compare Items"
L["GEMS_CVAR_UI_COMPARE_DESC"] = "Always show item comparison tooltips when hovering gear."
L["GEMS_CVAR_UI_TOOLTIPS"] = "Detailed Tooltips"
L["GEMS_CVAR_UI_TOOLTIPS_DESC"] = "Show verbose/detailed tooltips with stats."
L["GEMS_CVAR_UI_TRANSMOG"] = "Missing Transmog Source"
L["GEMS_CVAR_UI_TRANSMOG_DESC"] = "Show if you are missing a transmog appearance source. Hidden gem for collectors."
L["GEMS_CVAR_UI_SSFORMAT"] = "Screenshot Format"
L["GEMS_CVAR_UI_SSFORMAT_DESC"] = "Screenshot file format. TGA is lossless, JPEG saves disk space but looks worse."
L["GEMS_CVAR_UI_SSQUALITY"] = "Screenshot Quality"
L["GEMS_CVAR_UI_SSQUALITY_DESC"] = "JPEG quality (1-10). Default 3 is very low. If using JPEG, use 10."
L["GEMS_CVAR_UI_ZOOM"] = "Camera Zoom Distance"
L["GEMS_CVAR_UI_ZOOM_DESC"] =
    "Max camera zoom-out multiplier. Default 1.9 feels close. 2.6 gives more battlefield awareness."
L["GEMS_CVAR_UI_EDGEFLASH"] = "Screen Edge Flash"
L["GEMS_CVAR_UI_EDGEFLASH_DESC"] = "Red flash at screen edges while in combat with map open. Safety reminder."
L["GEMS_CVAR_UI_BUBBLES"] = "Chat Bubbles"
L["GEMS_CVAR_UI_BUBBLES_DESC"] = "Show in-game speech bubbles."
L["GEMS_CVAR_UI_BIGNUMS"] = "Break Up Numbers"
L["GEMS_CVAR_UI_BIGNUMS_DESC"] = "Use commas in large numbers (1,000,000 vs 1000000)."
L["GEMS_CVAR_UI_BUFFDUR"] = "Buff Durations"
L["GEMS_CVAR_UI_BUFFDUR_DESC"] = "Show remaining duration on buff icons."
L["GEMS_CVAR_UI_COMBOPT"] = "Combo Point Location"
L["GEMS_CVAR_UI_COMBOPT_DESC"] = "Combo point display. 1=on target frame, 2=on self (below personal resource display)."
L["GEMS_CVAR_UI_FSTACK"] = "Frame Stack Debug"
L["GEMS_CVAR_UI_FSTACK_DESC"] =
    "Enable frame stack tooltip (developer tool). Shows frame names on hover. Useful for debugging."
L["GEMS_CVAR_UI_RAWMOUSE"] = "Raw Mouse Input"
L["GEMS_CVAR_UI_RAWMOUSE_DESC"] = "Raw mouse input bypass. Deprecated/broken as of 2024 patches. Informational only."
L["GEMS_CVAR_UI_TAINT"] = "Taint Log"
L["GEMS_CVAR_UI_TAINT_DESC"] =
    "Taint debugging log. 0=off, 1=log to file, 2=log+chat. Addon developers set to 1 for debugging."
L["GEMS_CVAR_UI_BAGS"] = "Combined Bags"
L["GEMS_CVAR_UI_BAGS_DESC"] =
    "Display all bags as one combined inventory view. Added in Dragonflight. Much cleaner management."
L["GEMS_CVAR_UI_ROTATEMM"] = "Rotate Minimap"
L["GEMS_CVAR_UI_ROTATEMM_DESC"] =
    "Rotate minimap to match player facing direction instead of fixed north-up. Preference-based."

-- CVar Section: FPS & Performance
L["GEMS_CVAR_FPS_MAXFPS"] = "Max FPS"
L["GEMS_CVAR_FPS_MAXFPS_DESC"] = "FPS cap. Should match your monitor's refresh rate. Going higher wastes GPU."
L["GEMS_CVAR_FPS_BGFPS"] = "Background FPS"
L["GEMS_CVAR_FPS_BGFPS_DESC"] =
    "Background FPS cap (game not focused). 30 saves power/heat. Lower to 8 for maximum savings."
L["GEMS_CVAR_FPS_LOADFPS"] = "Loading Screen FPS"
L["GEMS_CVAR_FPS_LOADFPS_DESC"] = "Loading screen FPS cap. Low is fine -- no gameplay during loads."
L["GEMS_CVAR_FPS_USEMAXFPS"] = "Enable FPS Cap"
L["GEMS_CVAR_FPS_USEMAXFPS_DESC"] = "Enable the FPS cap. Default OFF means uncapped FPS (wastes GPU, causes heat)."
L["GEMS_CVAR_FPS_VSYNC"] = "Vertical Sync"
L["GEMS_CVAR_FPS_VSYNC_DESC"] =
    "Prevents screen tearing but adds input lag. For competitive play, disable and use FPS cap instead."
L["GEMS_CVAR_FPS_TARGETFPS"] = "Target FPS"
L["GEMS_CVAR_FPS_TARGETFPS_DESC"] = "Target FPS for dynamic quality scaling. Game auto-lowers settings to hit this."
L["GEMS_CVAR_FPS_USETARGET"] = "Use Target FPS"
L["GEMS_CVAR_FPS_USETARGET_DESC"] =
    "Enable target FPS system. Can cause jarring quality fluctuations. Prefer static settings."
L["GEMS_CVAR_FPS_LATENCY"] = "GPU Frame Latency"
L["GEMS_CVAR_FPS_LATENCY_DESC"] =
    "Max frames CPU can queue ahead of GPU. Default 3 = ~50ms lag at 60fps. 1 = ~16ms, worth it for macros."
L["GEMS_CVAR_FPS_RSCALE"] = "Render Scale"
L["GEMS_CVAR_FPS_RSCALE_DESC"] =
    "Render resolution multiplier. 1.0 = native. Below 1.0 = blurry but faster. Above 1.0 = supersampling."
L["GEMS_CVAR_FPS_DYNSCALE"] = "Dynamic Render Scale"
L["GEMS_CVAR_FPS_DYNSCALE_DESC"] =
    "Auto-lower render scale when GPU-bound. Beta feature -- can cause hitching. Leave off unless needed."
L["GEMS_CVAR_FPS_LOWLAT"] = "Low Latency Mode"
L["GEMS_CVAR_FPS_LOWLAT_DESC"] =
    "Low latency rendering. 0=none, 2=Reflex (NVIDIA), 4=XeLL (Intel). AMD users leave at 0."
L["GEMS_CVAR_FPS_MULTITHREAD"] = "Multi-Thread Rendering"
L["GEMS_CVAR_FPS_MULTITHREAD_DESC"] =
    "Multi-threaded rendering. Disabling significantly reduces framerate. Never set to 0."
L["GEMS_CVAR_FPS_SPELLCLUTTER"] = "Spell Visual Density"
L["GEMS_CVAR_FPS_SPELLCLUTTER_DESC"] =
    "Global spell visual density. 1=essential only, 4=everything. Lower = max FPS gain."
L["GEMS_CVAR_FPS_PARTICLES"] = "Particle Density"
L["GEMS_CVAR_FPS_PARTICLES_DESC"] =
    "Particle effect density (percentage). Reducing to 50 improves FPS in particle-heavy fights."
L["GEMS_CVAR_FPS_WEATHER"] = "Weather Density"
L["GEMS_CVAR_FPS_WEATHER_DESC"] = "Weather effect density. Reducing removes rain/snow particles."
L["GEMS_CVAR_FPS_ANIMLOD"] = "Animation Frame Skip"
L["GEMS_CVAR_FPS_ANIMLOD_DESC"] = "Skip animation frames for distant characters. Saves CPU with no visible impact."
L["GEMS_CVAR_FPS_VFXDENSITY"] = "VFX Density Filter"
L["GEMS_CVAR_FPS_VFXDENSITY_DESC"] =
    "Alternative spell visual density control. Works alongside spellClutter as a second-pass filter."

-- CVar Section: Visual Quality
L["GEMS_CVAR_VISUAL_QUALITY"] = "Graphics Quality"
L["GEMS_CVAR_VISUAL_QUALITY_DESC"] =
    "Master graphics quality preset (1-10). Changes all sub-settings at once. Informational."
L["GEMS_CVAR_VISUAL_SHADOWS"] = "Shadow Quality"
L["GEMS_CVAR_VISUAL_SHADOWS_DESC"] =
    "Shadow quality (1-5). Shadows are GPU-expensive. Lowering to 1-2 gives significant FPS gains."
L["GEMS_CVAR_VISUAL_SSAO"] = "Ambient Occlusion"
L["GEMS_CVAR_VISUAL_SSAO_DESC"] =
    "Screen-space ambient occlusion quality. Adds depth to shadows. 0=off (fastest), 4=highest."
L["GEMS_CVAR_VISUAL_VIEWDIST"] = "View Distance"
L["GEMS_CVAR_VISUAL_VIEWDIST_DESC"] =
    "View distance (1-10). Lowering to 5 saves GPU with little visual impact in instanced content."
L["GEMS_CVAR_VISUAL_GROUND"] = "Ground Clutter"
L["GEMS_CVAR_VISUAL_GROUND_DESC"] =
    "Grass/ground detail density (1-10). Pure cosmetic -- lowering has zero gameplay impact and saves FPS."
L["GEMS_CVAR_VISUAL_TEXRES"] = "Texture Resolution"
L["GEMS_CVAR_VISUAL_TEXRES_DESC"] = "Texture resolution quality (1-3). Affects VRAM usage. Lower if VRAM-limited."
L["GEMS_CVAR_VISUAL_LIQUID"] = "Water Quality"
L["GEMS_CVAR_VISUAL_LIQUID_DESC"] = "Water rendering quality. Lower = less reflective water, better FPS near water."
L["GEMS_CVAR_VISUAL_PROJTEX"] = "Projected Textures"
L["GEMS_CVAR_VISUAL_PROJTEX_DESC"] =
    "Spell ground effects (Healing Rain, Consecration). MUST be on -- without it, boss mechanics are invisible."
L["GEMS_CVAR_VISUAL_OUTLINE"] = "Outline Mode"
L["GEMS_CVAR_VISUAL_OUTLINE_DESC"] = "Character/NPC outline mode. 0=none, 1=thin, 2=normal. Helps with visibility."
L["GEMS_CVAR_VISUAL_AA"] = "Anti-Aliasing"
L["GEMS_CVAR_VISUAL_AA_DESC"] =
    "Anti-aliasing mode. 0=none, 1=FXAA low, 2=FXAA high, 3=CMAA. CMAA is best quality-to-cost ratio."
L["GEMS_CVAR_VISUAL_GLOW"] = "Glow Effect"
L["GEMS_CVAR_VISUAL_GLOW_DESC"] = "Full-screen glow effect. Subtle but adds atmosphere."
L["GEMS_CVAR_VISUAL_DEATH"] = "Death Effect"
L["GEMS_CVAR_VISUAL_DEATH_DESC"] = "Death desaturation effect. Greyscale when dead."
L["GEMS_CVAR_VISUAL_SHARPEN"] = "Sharpening Pass"
L["GEMS_CVAR_VISUAL_SHARPEN_DESC"] =
    "Enable sharpening even without FSR upscaling. Makes image crisper at native resolution. Hidden CVar."
L["GEMS_CVAR_VISUAL_SHARPNESS"] = "Sharpening Strength"
L["GEMS_CVAR_VISUAL_SHARPNESS_DESC"] =
    "Sharpening strength [0.0-2.0]. Only active when ResampleAlwaysSharpen=1 or FSR is enabled."
L["GEMS_CVAR_VISUAL_FARCLIP"] = "Far Clip Plane"
L["GEMS_CVAR_VISUAL_FARCLIP_DESC"] =
    "Max render distance in world units. Lower = less distant geometry = better FPS. 800 is sufficient."

-- CVar Section: Sound
L["GEMS_CVAR_SOUND_MASTER"] = "Master Sound Toggle"
L["GEMS_CVAR_SOUND_MASTER_DESC"] = "Master sound toggle. Must be on for any audio."
L["GEMS_CVAR_SOUND_MASTERVOL"] = "Master Volume"
L["GEMS_CVAR_SOUND_MASTERVOL_DESC"] = "Master volume (0.0-1.0). 0.8 gives headroom for Discord/Spotify alongside WoW."
L["GEMS_CVAR_SOUND_SFX"] = "SFX Volume"
L["GEMS_CVAR_SOUND_SFX_DESC"] = "Sound effects volume. Keep at 1.0 for combat audio cues."
L["GEMS_CVAR_SOUND_MUSIC"] = "Music Volume"
L["GEMS_CVAR_SOUND_MUSIC_DESC"] = "Music volume. Lower during raids/dungeons to hear boss ability audio cues."
L["GEMS_CVAR_SOUND_AMBIENCE"] = "Ambience Volume"
L["GEMS_CVAR_SOUND_AMBIENCE_DESC"] =
    "Ambient sound volume. Lower in raids -- ambient noise can mask important combat audio."
L["GEMS_CVAR_SOUND_DIALOG"] = "Dialog Volume"
L["GEMS_CVAR_SOUND_DIALOG_DESC"] = "Voice/dialog volume (boss VO, quest narration)."
L["GEMS_CVAR_SOUND_BGAUDIO"] = "Background Audio"
L["GEMS_CVAR_SOUND_BGAUDIO_DESC"] =
    "Play sound when WoW is in background. Important for queue pops and ready checks while alt-tabbed."
L["GEMS_CVAR_SOUND_ENCWARN"] = "Encounter Warning Sounds"
L["GEMS_CVAR_SOUND_ENCWARN_DESC"] = "Play sounds for encounter/boss warnings."
L["GEMS_CVAR_SOUND_ENCVOL"] = "Encounter Warning Volume"
L["GEMS_CVAR_SOUND_ENCVOL_DESC"] = "Volume for encounter warning sounds (0.0-1.0)."
L["GEMS_CVAR_SOUND_ERRSPEECH"] = "Error Speech"
L["GEMS_CVAR_SOUND_ERRSPEECH_DESC"] =
    "Error voice (not enough mana, etc). Disable -- macro sequences hitting cooldowns trigger this rapidly."
L["GEMS_CVAR_SOUND_GAMEPLAY"] = "Gameplay SFX"
L["GEMS_CVAR_SOUND_GAMEPLAY_DESC"] = "Enable gameplay-specific sound effects."

-- CVar Section: Floating Combat Text
L["GEMS_CVAR_FCT_ENABLE"] = "Floating Combat Text"
L["GEMS_CVAR_FCT_ENABLE_DESC"] =
    "Master toggle for floating combat text. Off by default! Enable to see damage/healing numbers."
L["GEMS_CVAR_FCT_DAMAGE"] = "Damage Numbers"
L["GEMS_CVAR_FCT_DAMAGE_DESC"] = "Show damage numbers on hostile targets."
L["GEMS_CVAR_FCT_AUTOS"] = "Auto-Attack Numbers"
L["GEMS_CVAR_FCT_AUTOS_DESC"] = "Show ALL auto-attack numbers (not just crits/procs)."
L["GEMS_CVAR_FCT_HEALING"] = "Healing Numbers"
L["GEMS_CVAR_FCT_HEALING_DESC"] = "Show healing numbers on targets."
L["GEMS_CVAR_FCT_ABSSELF"] = "Self Absorbs"
L["GEMS_CVAR_FCT_ABSSELF_DESC"] = "Show shield/absorb amounts applied to yourself."
L["GEMS_CVAR_FCT_ABSTARGET"] = "Target Absorbs"
L["GEMS_CVAR_FCT_ABSTARGET_DESC"] = "Show shield/absorb amounts applied to your target."
L["GEMS_CVAR_FCT_PERIODIC"] = "Periodic Damage"
L["GEMS_CVAR_FCT_PERIODIC_DESC"] = "Show DoT/HoT tick numbers."
L["GEMS_CVAR_FCT_DODGEMISS"] = "Dodge/Parry/Miss"
L["GEMS_CVAR_FCT_DODGEMISS_DESC"] = "Show dodge/parry/miss text. Useful for seeing when abilities are avoided."
L["GEMS_CVAR_FCT_LOWRES"] = "Low Resource Warning"
L["GEMS_CVAR_FCT_LOWRES_DESC"] = "Show low mana/health warnings."
L["GEMS_CVAR_FCT_FLOATMODE"] = "Float Direction"
L["GEMS_CVAR_FCT_FLOATMODE_DESC"] = "Float direction. 1=up, 2=down, 3=arc. 1 (up) is standard."
L["GEMS_CVAR_FCT_DIRSCALE"] = "Directional Scale"
L["GEMS_CVAR_FCT_DIRSCALE_DESC"] = "Directional damage number movement scale. 0=no directional movement. 1.0=default."
L["GEMS_CVAR_FCT_PETMELEE"] = "Pet Melee Damage"
L["GEMS_CVAR_FCT_PETMELEE_DESC"] =
    "Show pet melee damage numbers. Important for pet-class macros (BM Hunter, Demo Warlock)."
L["GEMS_CVAR_FCT_PETSPELL"] = "Pet Spell Damage"
L["GEMS_CVAR_FCT_PETSPELL_DESC"] = "Show pet spell damage numbers."
L["GEMS_CVAR_FCT_REACTIVES"] = "Reactive Procs"
L["GEMS_CVAR_FCT_REACTIVES_DESC"] =
    "Show reactive ability procs (Overpower, Revenge). Helps spot procs macro sequences should react to."
L["GEMS_CVAR_FCT_ENERGY"] = "Energy Gains"
L["GEMS_CVAR_FCT_ENERGY_DESC"] = "Show energy/rage/mana gain numbers. Off by default -- can be very spammy."
L["GEMS_CVAR_FCT_AURAS"] = "Buff/Debuff Text"
L["GEMS_CVAR_FCT_AURAS_DESC"] = "Show buff/debuff application text. Off by default -- very spammy in group content."
L["GEMS_CVAR_FCT_HEALERS"] = "Healer Names"
L["GEMS_CVAR_FCT_HEALERS_DESC"] = "Show name of healer who healed you."

-- CVar Section: Accessibility
L["GEMS_CVAR_ACCESS_COLORBLIND"] = "Colorblind Mode"
L["GEMS_CVAR_ACCESS_COLORBLIND_DESC"] =
    "Colorblind mode. 0=off, 1=Protanopia, 2=Deuteranopia, 3=Tritanopia. Informational."
L["GEMS_CVAR_ACCESS_CENTERED"] = "Keep Centered"
L["GEMS_CVAR_ACCESS_CENTERED_DESC"] =
    "Keep character head at screen center as a motion reference point. Reduces motion sickness."
L["GEMS_CVAR_ACCESS_REDUCEMOVE"] = "Reduce Movement"
L["GEMS_CVAR_ACCESS_REDUCEMOVE_DESC"] =
    "Reduce camera movement without player input. Helps with motion sickness but can feel unresponsive."
L["GEMS_CVAR_ACCESS_FOCAL"] = "Focal Circle"
L["GEMS_CVAR_ACCESS_FOCAL_DESC"] = "Show a focal circle when mounted. Reduces motion sickness during fast movement."
L["GEMS_CVAR_ACCESS_TEXTCONTRAST"] = "Quest Text Contrast"
L["GEMS_CVAR_ACCESS_TEXTCONTRAST_DESC"] = "Increase text contrast in quest UIs. Helps with readability."
L["GEMS_CVAR_ACCESS_CAA"] = "Combat Audio Alerts"
L["GEMS_CVAR_ACCESS_CAA_DESC"] =
    "Audio cues for combat events (health thresholds, ability readiness). Useful for visually impaired players."

-- CVar Section: Dragonriding & Advanced Flying
L["GEMS_CVAR_DRAGON_DYNFOV"] = "Dynamic FOV"
L["GEMS_CVAR_DRAGON_DYNFOV_DESC"] =
    "Dynamic field-of-view based on gliding speed. Creates a sense of speed. Disable if motion sickness."
L["GEMS_CVAR_DRAGON_MAXPITCH"] = "Max Pitch Rate"
L["GEMS_CVAR_DRAGON_MAXPITCH_DESC"] =
    "Maximum pitch rate for keyboard dragonriding. Default 5 can feel sluggish. 6-7 is more responsive."
L["GEMS_CVAR_DRAGON_MAXTURN"] = "Max Turn Rate"
L["GEMS_CVAR_DRAGON_MAXTURN_DESC"] =
    "Maximum turn rate for keyboard dragonriding. Default 8 can feel slow. 10 improves maneuverability."
L["GEMS_CVAR_DRAGON_MINPITCH"] = "Min Pitch Rate"
L["GEMS_CVAR_DRAGON_MINPITCH_DESC"] =
    "Minimum pitch rate. Affects fine-grained pitch control. Slightly higher gives more precise control."
L["GEMS_CVAR_DRAGON_PITCHCTRL"] = "Pitch Control Mode"
L["GEMS_CVAR_DRAGON_PITCHCTRL_DESC"] =
    "How forward/back inputs affect pitch. 3=toggle. Most comfortable for keyboard players."

-- Comparison Frame (v1.2.0 S04-B)
L["GEMS_IMPORT_COMPARE"] = "Compare"
L["GEMS_UI_COMPARE_WITH"] = "Compare with..."
L["GEMS_COMPARE_TITLE"] = "Sequence Comparison"
L["GEMS_COMPARE_LEFT_LABEL"] = "Existing"
L["GEMS_COMPARE_RIGHT_LABEL"] = "Incoming"
L["GEMS_COMPARE_STEPS"] = "%d steps"
L["GEMS_COMPARE_NO_STEPS"] = "No steps"
L["GEMS_COMPARE_CLOSE_DESC"] = "Close comparison view"

-- Sequence autocomplete (v1.2.0 S07b)
L["GEMS_AUTOCOMPLETE_SEQUENCES"] = "Sequences"
L["GEMS_AUTOCOMPLETE_CLICK_INSERT"] = "/click GRIPEMS_%s"

-- Popup Editor (v1.2.0 S07a)
L["GEMS_UI_OPEN_NEW_WINDOW"] = "Open in New Window"
L["GEMS_UI_POPUP_TITLE"] = "GRIP-EMS Editor"
L["GEMS_UI_POPUP_CLOSE_DIRTY"] = "This editor has unsaved changes.\nSave before closing?"
L["GEMS_UI_POPUP_MAX_REACHED"] = "Maximum editor windows reached (%d)."

-- Editor Colours (v1.2.0 S08a)
L["GEMS_SETTINGS_EDITOR_COLOURS"] = "Editor Colours"
L["GEMS_SETTINGS_SYNTAX_COMMAND"] = "Slash Commands"
L["GEMS_SETTINGS_SYNTAX_COMMAND_DESC"] = "Colour for /cast, /use, /click, etc."
L["GEMS_SETTINGS_SYNTAX_CONDITIONAL"] = "Conditionals"
L["GEMS_SETTINGS_SYNTAX_CONDITIONAL_DESC"] = "Colour for [mod:shift], [talent:X], etc."
L["GEMS_SETTINGS_SYNTAX_VARIABLE"] = "Variables"
L["GEMS_SETTINGS_SYNTAX_VARIABLE_DESC"] = "Colour for ~variable~ references."
L["GEMS_SETTINGS_SYNTAX_COMMENT"] = "Comments"
L["GEMS_SETTINGS_SYNTAX_COMMENT_DESC"] = "Colour for -- comment lines."
L["GEMS_SETTINGS_SYNTAX_RESET"] = "Reset Conditions"
L["GEMS_SETTINGS_SYNTAX_RESET_DESC"] = "Colour for reset=target/combat/5."
L["GEMS_SETTINGS_SYNTAX_NUMBER"] = "Numbers"
L["GEMS_SETTINGS_SYNTAX_NUMBER_DESC"] = "Colour for numeric values."

-- Floating Menu (v1.2.0 S09a)
L["GEMS_FLOATING_HEADER"] = "Floating Menu"
L["GEMS_FLOATING_SHOW_DESC"] = "Show the floating quick-access menu bar"
L["GEMS_FLOATING_DIRECTION_DESC"] = "Direction buttons expand from the anchor"
L["GEMS_FLOATING_LOCK_DESC"] = "Lock the floating menu position"
L["GEMS_FLOATING_SCALE_DESC"] = "Scale the floating menu frame"
L["GEMS_FLOATING_LOCKED"] = "Floating menu locked."
L["GEMS_FLOATING_UNLOCKED"] = "Floating menu unlocked."
L["GEMS_FLOATING_BTN_SEQUENCES"] = "Sequences"
L["GEMS_FLOATING_BTN_IMPORT"] = "Import"
L["GEMS_FLOATING_BTN_EXPORT"] = "Export"
L["GEMS_FLOATING_BTN_VARIABLES"] = "Variables"
L["GEMS_FLOATING_BTN_TRACKER"] = "Tracker"
L["GEMS_FLOATING_BTN_OPTIONS"] = "Options"
L["GEMS_FLOATING_BTN_COLLAPSE"] = "Collapse"
L["GEMS_FLOATING_BTN_EXPAND"] = "Expand"
L["GEMS_FLOATING_BTN_CLOSE"] = "Close"
L["GEMS_FLOATING_DIR_UP"] = "Up"
L["GEMS_FLOATING_DIR_DOWN"] = "Down"
L["GEMS_FLOATING_DIR_LEFT"] = "Left"
L["GEMS_FLOATING_DIR_RIGHT"] = "Right"
L["GEMS_HELP_MENU"] = "  /gems menu - Toggle floating menu bar"

-- Support tab (v1.2.0 S10-B)
L["GEMS_SETTINGS_SUPPORT"] = "Support"
L["GEMS_SUPPORT_CREDITS"] = "Created by Sataana (MrSataana / JesperLive)"
L["GEMS_SUPPORT_DISCORD"] = "Discord: discord.gg/grip-ems"
L["GEMS_SUPPORT_SYSTEM_HEADER"] = "System Info"
L["GEMS_SUPPORT_CREDITS_HEADER"] = "Credits"
L["GEMS_SUPPORT_DISCORD_HEADER"] = "Community"
L["GEMS_HELP_COMPRESS"] = "  /gems compress <name> - Encode sequence (dev)"
L["GEMS_HELP_DECOMPRESS"] = "  /gems decompress <string> - Decode string (dev)"

-- Remote Browser (v1.2.0 S13b)
L["GEMS_UI_REMOTE_BROWSER_TITLE"] = "Remote Macro Browser"
L["GEMS_UI_REMOTE_PLAYERS_HEADER"] = "Players with EMS"
L["GEMS_UI_REMOTE_REFRESH"] = "Refresh"
L["GEMS_UI_REMOTE_SEQUENCES_FROM"] = "Sequences from %s"
L["GEMS_UI_REMOTE_WAITING"] = "Waiting for response..."
L["GEMS_UI_REMOTE_NO_PLAYERS"] = "No EMS users detected. Join a group to discover players."
L["GEMS_UI_REMOTE_NO_SEQUENCES"] = "No sequences available from this player."
L["GEMS_UI_REMOTE_IMPORT"] = "Import"
L["GEMS_UI_REMOTE_REQUEST_SENT"] = "Requested %s from %s"
L["GEMS_UI_REMOTE_LIST_RECEIVED"] = "Received sequence list from %s (%d sequences)"
L["GEMS_HELP_BROWSE"] = "  /gems browse - Open remote sequence browser"
L["GEMS_BROWSE_REFRESH_DESC"] = "Refresh the list of party members and their sequences"
L["GEMS_BROWSE_IMPORT_DESC"] = "Import this sequence to your library"
L["GEMS_BROWSE_CLOSE_DESC"] = "Close the browser"

-- Recorder
L["GEMS_UI_RECORD"] = "Record"
L["GEMS_UI_RECORDING"] = "Recording..."
L["GEMS_UI_RECORDING_COUNT"] = "Recording (%d)"
L["GEMS_RECORDER_MAX_REACHED"] = "Recording stopped: maximum step limit reached."
L["GEMS_RECORDER_STOPPED"] = "Recording stopped: %d spells captured."
L["GEMS_RECORDER_CREATE_CONFIRM"] = "Recording captured %d spells. Create a new sequence from this recording?"
L["GEMS_RECORDER_CREATE_YES"] = "Create Sequence"
L["GEMS_RECORDER_CREATE_NO"] = "Discard"
L["GEMS_RECORDER_EMPTY"] = "No spells were recorded."
L["GEMS_SETTINGS_RECORDER_HEADER"] = "Recorder"
L["GEMS_SETTINGS_RECORDER_DEDUP"] = "Deduplicate consecutive identical casts"
L["GEMS_SETTINGS_RECORDER_DEDUP_DESC"] =
    "When enabled, consecutive casts of the same spell are collapsed into a single step."

-- Spell Cache Viewer (v1.2.0 S16)
L["GEMS_SPELLCACHE_TITLE"] = "Spell Cache"
L["GEMS_SPELLCACHE_TAB_SPELLS"] = "Spells"
L["GEMS_SPELLCACHE_TAB_ITEMS"] = "Items"
L["GEMS_SPELLCACHE_TAB_TOYS"] = "Toys"
L["GEMS_SPELLCACHE_SEARCH"] = "Search..."
L["GEMS_SPELLCACHE_REFRESH"] = "Refresh"
L["GEMS_SPELLCACHE_CLEAR_OVERRIDES"] = "Clear Overrides"
L["GEMS_SPELLCACHE_CLEAR_CONFIRM"] = "Remove all spell name overrides? This cannot be undone."
L["GEMS_SPELLCACHE_SHOWING"] = "Showing %d of %d"
L["GEMS_SPELLCACHE_SCANNING"] = "Scanning..."
L["GEMS_SPELLCACHE_NOT_AVAILABLE"] = "Spell Cache viewer not available."
L["GEMS_SPELLCACHE_OVERRIDE_CLEARED"] = "Spell name overrides cleared."
L["GEMS_HELP_SPELLCACHE"] = "|cFF00CC66/gems spellcache|r -- Open spell cache viewer"
L["GEMS_HELP_MAPINFO"] = "|cFF00CC66/gems mapinfo|r -- Show current map/instance IDs"

-- Inline string localization (v1.2.0 S22-D)
L["GEMS_UI_STUB_PREVIEW"] = "Macro Stub Preview"
L["GEMS_UI_EMPTY_HINT"] = "Import or create a sequence to get started"
L["GEMS_UI_KEYBIND_TOOLTIP"] = "Keybind: %s"

-- Vehicle / Pet Battle Keybinds (v1.2.0 S23)
L["GEMS_VEHICLE_KEYBINDS_HEADER"] = "Vehicle / Override Bar Keybinds"
L["GEMS_PET_BATTLE_KEYBINDS_HEADER"] = "Pet Battle Keybinds"
L["GEMS_VEHICLE_SLOT"] = "Slot %d"
L["GEMS_VEHICLE_KEYBINDS_APPLIED"] = "Vehicle keybinds applied: %d binding(s)"
L["GEMS_VEHICLE_KEYBINDS_CLEARED"] = "Vehicle keybinds cleared"
L["GEMS_PET_BATTLE_KEYBINDS_APPLIED"] = "Pet battle keybinds applied: %d binding(s)"
L["GEMS_PET_BATTLE_KEYBINDS_CLEARED"] = "Pet battle keybinds cleared"
L["GEMS_PET_BATTLE_ABILITY"] = "Ability %d"
L["GEMS_PET_BATTLE_SWAP"] = "Swap Pet"
L["GEMS_PET_BATTLE_PASS"] = "Pass Turn"
L["GEMS_PET_BATTLE_FORFEIT"] = "Forfeit"
L["GEMS_BAR_INTEGRATION_HEADER"] = "Action Bar Integration"
L["GEMS_BAR_INTEGRATION_DESC"] = "Show sequence icons on action bar buttons"
L["GEMS_BAR_INTEGRATION_TRACKED"] = "Bar integration: %d buttons tracked (%s)"
L["GEMS_UI_NOT_BOUND"] = "Not bound"

-- Feature: Click Rate Diagnostics (/gems diag)
L["GEMS_DIAG_HEADER"] = "--- Execution Diagnostics ---"
L["GEMS_DIAG_CPS"] = "Real-time CPS: %.1f"
L["GEMS_DIAG_CONFIGURED"] = "Configured click rate: %dms (effective)"
L["GEMS_DIAG_TOTAL"] = "Total casts tracked: %d"
L["GEMS_DIAG_TRACER"] = "Tracer: %s"
L["GEMS_DIAG_TRACER_ON"] = "active"
L["GEMS_DIAG_TRACER_OFF"] = "inactive"
L["GEMS_DIAG_TOP_SPELLS"] = "Top spells:"
L["GEMS_DIAG_SPELL_ROW"] = "  %d. %s (ID: %d) -- %d casts"
L["GEMS_DIAG_NO_DATA"] = "No cast data yet. Use a sequence first."
L["GEMS_HELP_DIAG"] = "Show execution diagnostics (CPS, top spells)"
L["GEMS_HELP_MEMCHECK"] = "Memory diagnostics (GC, table sizes, heap)"
L["GEMS_HELP_PERF"] = "Performance profiling (OnUpdate, frames, timings)"
L["GEMS_HELP_MONITOR"] = "300-frame continuous profiler (hooks key functions)"

-- Feature: Optimal MS Advisor (/gems msadvisor)
L["GEMS_MSADVISOR_HEADER"] = "--- MS Advisor%s ---"
L["GEMS_MSADVISOR_GCD"] = "Base GCD: %dms (%.1f%% haste)"
L["GEMS_MSADVISOR_LAG"] = "World latency: %dms"
L["GEMS_MSADVISOR_SQW"] = "Spell Queue Window: %dms"
L["GEMS_MSADVISOR_RECOMMEND"] = "Recommended click rate: %dms"
L["GEMS_MSADVISOR_CURRENT"] = "Current configured: %dms"
L["GEMS_MSADVISOR_DELTA"] = "Delta: %+dms (%s)"
L["GEMS_MSADVISOR_FASTER"] = "you could click faster"
L["GEMS_MSADVISOR_SLOWER"] = "you are clicking faster than GCD allows"
L["GEMS_MSADVISOR_GOOD"] = "well-matched"
L["GEMS_MSADVISOR_ROTATION"] = "Sequence '%s': %d steps, full rotation ~%dms"
L["GEMS_MSADVISOR_NOT_FOUND"] = "Sequence '%s' not found."
L["GEMS_HELP_MSADVISOR"] = "Recommend optimal click rate based on haste"

-- Feature: Dormant Sequence Lazy Loading
L["GEMS_DORMANT_LOADED"] = "  %d sequence(s) registered as dormant (different class)"
L["GEMS_DORMANT_LABEL"] = "(dormant)"
L["GEMS_HELP_LOADCLASS"] = "Activate dormant sequences for a class ID"
L["GEMS_HELP_REPAIR"] = "/gems repair <name> -- Analyze and repair a sequence"
L["GEMS_HELP_REPAIRALL"] = "/gems repairall -- Analyze and repair all sequences"
L["GEMS_HELP_RESETUI"] = "/gems resetui -- Reset window to default size and position"
L["GEMS_RESETUI_DONE"] = "UI reset to default size and position."
L["GEMS_LOADCLASS_ALREADY"] = "Class %d sequences are already loaded."
L["GEMS_LOADCLASS_DONE"] = "Activated %d dormant sequence(s) for class %d."
L["GEMS_LOADCLASS_USAGE"] = "Usage: /gems loadclass <classID> (1=Warrior, 2=Paladin, ...)"
L["GEMS_UI_ACTIVATE"] = "Activate"

-- Feature: Raw Macrotext Import
L["GEMS_RAWIMPORT_DETECTED"] = "Raw macro text detected. Parsing %d lines..."
L["GEMS_RAWIMPORT_RESULT"] = "Parsed %d steps from raw macro text."
L["GEMS_RAWIMPORT_NAME"] = "Imported Macro"
L["GEMS_RAWIMPORT_NO_SPELLS"] = "No castable lines found in pasted text."

-- Feature: Step Spell Picker
L["GEMS_SPELLPICKER_TITLE"] = "Spell Picker"
L["GEMS_SPELLPICKER_SEARCH"] = "Search spells..."
L["GEMS_SPELLPICKER_ALL"] = "All"
L["GEMS_SPELLPICKER_CLASS"] = "Class"
L["GEMS_SPELLPICKER_PET"] = "Pet Abilities"
L["GEMS_SPELLPICKER_ITEMS"] = "Items"
L["GEMS_SPELLPICKER_GEAR"] = "Gear"
L["GEMS_SPELLPICKER_CONSUMABLES"] = "Consumables"
L["GEMS_SPELLPICKER_TOYS"] = "Toys"
L["GEMS_SPELLPICKER_SPEC"] = "Spec"
L["GEMS_SPELLPICKER_RACE"] = "Race"
L["GEMS_SPELLPICKER_GENERAL"] = "General"
L["GEMS_SPELLPICKER_PROF"] = "Prof"
L["GEMS_SPELLPICKER_OTHER"] = "Other"
L["GEMS_SPELLPICKER_MOUNTS"] = "Mounts"
L["GEMS_SPELLPICKER_COMPANIONS"] = "Companions"
L["GEMS_SPELLPICKER_CONDITIONALS"] = "Conditionals"
L["GEMS_SPELLPICKER_CUSTOM"] = "Custom:"
L["GEMS_SPELLPICKER_INSERT"] = "Insert"
L["GEMS_SPELLPICKER_NO_RESULTS"] = "No matching spells"
L["GEMS_SPELLPICKER_FAVORITES"] = "Favorites"
L["GEMS_SPELLPICKER_WARBANK_NOTE"] = "Warbank items only visible at a banker"
L["GEMS_HELP_SPELLPICKER"] = "Spell picker available via icon button on each step"

-- Feature: Gear-Aware Variables
L["GEMS_GEAR_VAR_HEADER"] = "Gear variables (auto-detected use-effects):"
L["GEMS_GEAR_VAR_ROW"] = "  ~%s~ = %s"
L["GEMS_GEAR_VAR_NONE"] = "No equipped use-effects detected."
L["GEMS_GEAR_VAR_UPDATED"] = "Gear variables updated (%d use-effects detected)."

-- Feature: CVar Profiles & Context-Aware Switching (Phase 2)
L["GEMS_CVAR_PROFILE_GENERAL"] = "General (Default)"
L["GEMS_CVAR_PROFILE_RAID"] = "Raid"
L["GEMS_CVAR_PROFILE_RAID_DESC"] = "Optimized for raid encounters: tighter plate range, stacking nameplate motion"
L["GEMS_CVAR_PROFILE_MPLUS"] = "Mythic+"
L["GEMS_CVAR_PROFILE_MPLUS_DESC"] = "Optimized for Mythic+ dungeons: enemy minion plates, tighter range"
L["GEMS_CVAR_PROFILE_SOLO"] = "Solo / Open World"
L["GEMS_CVAR_PROFILE_SOLO_DESC"] = "Optimized for solo content: full visuals, wider interact arc, plates off"
L["GEMS_CVAR_PROFILE_PVP"] = "PvP"
L["GEMS_CVAR_PROFILE_PVP_DESC"] = "Optimized for PvP: friendly plates on, enemy minions, stacking motion"
L["GEMS_CVAR_PROFILE_ACTIVE"] = "Active Profile: %s"
L["GEMS_CVAR_PROFILE_SELECT"] = "Select Profile"
L["GEMS_CVAR_PROFILE_AUTO"] = "Auto (context-aware)"
L["GEMS_CVAR_PROFILE_AUTOSWITCH"] = "Auto-switch by context"
L["GEMS_CVAR_PROFILE_AUTOSWITCH_DESC"] =
    "Automatically switch CVar profile when entering raids, dungeons, PvP, or open world"
L["GEMS_CVAR_PROFILE_MANAGE"] = "Manage Profiles..."
L["GEMS_CVAR_PROFILE_CREATE"] = "Create Profile"
L["GEMS_CVAR_PROFILE_CREATE_NAME"] = "Profile Name:"
L["GEMS_CVAR_PROFILE_CLONE_FROM"] = "Clone From:"
L["GEMS_CVAR_PROFILE_DELETE"] = "Delete Profile"
L["GEMS_CVAR_PROFILE_DELETE_CONFIRM"] = 'Delete custom profile "%s"? This cannot be undone.'
L["GEMS_CVAR_PROFILE_OVERRIDE"] = "Profile Override"
L["GEMS_CVAR_PROFILE_OVERRIDE_NONE"] = "No override (use General)"
L["GEMS_CVAR_PROFILE_ADD_OVERRIDE"] = "Add Override..."
L["GEMS_CVAR_PROFILE_SWITCHED"] = "CVar profile switched to: %s"
L["GEMS_CVAR_PROFILE_QUEUED"] = "%d secure CVars queued (applied out of combat)"
L["GEMS_CVAR_CHANGES_DETECTED"] = "%d CVars changed since last session"
L["GEMS_CVAR_CHANGES_DISMISS"] = "Dismiss"
L["GEMS_CVAR_CHANGES_FIX_ALL"] = "Fix All Changed"
L["GEMS_CVAR_CHANGES_CAUSE_PATCH"] = "Likely: game patch reset"
L["GEMS_CVAR_CHANGES_CAUSE_ADDON"] = "Likely: changed by addon/UI"
L["GEMS_CVAR_CHANGES_CAUSE_AUTOFIX"] = "Auto-fixed by EMS"
L["GEMS_CVAR_CHANGES_CAUSE_UNKNOWN"] = "Changed since last session"
L["GEMS_CVAR_PROFILE_NOT_FOUND"] = "Unknown profile: %s"
L["GEMS_CVAR_AUTO_TOGGLED"] = "CVar auto-switch: %s"
L["GEMS_CVAR_NO_CHANGES"] = "No CVar changes detected since last session"
L["GEMS_CVAR_PROFILE_RENAME"] = "Rename"
L["GEMS_CVAR_PROFILE_OVERRIDES"] = "Overrides (%d)"
L["GEMS_CVAR_PROFILE_NO_OVERRIDES"] = "No overrides"
L["GEMS_CVAR_MAP_HEADER"] = "Context Profile Map"
L["GEMS_CVAR_MAP_DESC"] = "Choose which CVar profile applies for each context"
L["GEMS_CVAR_MAP_DEFAULT"] = "Default (%s)"
L["GEMS_CVAR_MAP_NONE"] = "General (no profile)"

-- SQW Optimizer
L["GEMS_SQW_OPTIMIZER"] = "Dynamic SQW Optimizer"
L["GEMS_SQW_OPTIMIZER_DESC"] = "Automatically adjusts SpellQueueWindow based on network latency"
L["GEMS_SQW_BUFFER"] = "Safety Buffer (ms)"
L["GEMS_SQW_BUFFER_DESC"] = "Higher = fewer gaps, lower = more responsive. 100ms recommended."
L["GEMS_SQW_LIVE"] = "SQW: %dms (latency: %dms + buffer: %dms)"
L["GEMS_SQW_ADVISORY"] = "Recommended click rate: %dms"
L["GEMS_SQW_ADVISORY_DETAIL"] = "GCD: %dms, SQW: %dms, Latency: %dms"
L["GEMS_SQW_ADVISORY_DELTA"] = "Your setting: %dms (%dms %s than optimal)"
L["GEMS_SQW_MANAGED"] = "Managed by SQW Optimizer"
L["GEMS_SQW_ENABLED"] = "SQW Optimizer enabled"
L["GEMS_SQW_DISABLED"] = "SQW Optimizer disabled (SQW reverted to %d)"
L["GEMS_SQW_STATUS"] = "SQW: %dms | Latency: %dms | Buffer: %dms | Advisory: %dms"
L["GEMS_SQW_BUFFER_SET"] = "SQW buffer set to %dms"
L["GEMS_SQW_BUFFER_RANGE"] = "Buffer must be between 50 and 200"
L["GEMS_SQW_SLOWER"] = "slower"
L["GEMS_SQW_FASTER"] = "faster"

-- Faster, Slower (TempoAdvisor)
L["FS_CMD_HELP"] = "Usage: /gems fs [name] - Analyze sequence click rate"
L["FS_STATUS_HEADER"] = "Faster, Slower"
L["FS_COMPLEXITY_RELAXED"] = "Relaxed"
L["FS_COMPLEXITY_STANDARD"] = "Standard"
L["FS_COMPLEXITY_DEMANDING"] = "Demanding"
L["FS_COMPLEXITY_INTENSE"] = "Intense"
L["FS_CONFIDENCE_ESTIMATED"] = "Estimated"
L["FS_CONFIDENCE_PRECISE"] = "Precise"
L["FS_CONFIDENCE_CALIBRATED"] = "Calibrated"
L["FS_UNKNOWN_SPELLS"] = "%d unknown spells - using generic estimate"
L["FS_RECOMMENDED"] = "Recommended: %d ms (%d/sec)"
L["FS_COMPLEXITY"] = "Complexity: %s"
L["FS_NO_SEQUENCE"] = "No active sequence"
L["FS_NO_STEPS"] = "No steps to analyze"
L["FS_ANALYZING"] = "Analyzing %s..."
L["FS_DEBUG_ON"] = "Faster, Slower debug enabled"
L["FS_DEBUG_OFF"] = "Faster, Slower debug disabled"

-- Faster, Slower Phase 2: Settings + Auto-Set
L["FS_AUTO_SET"] = "Auto-adjust click rate per sequence"
L["FS_AUTO_SET_DESC"] = "When enabled, click rate automatically adjusts when you activate a sequence"
L["FS_SPARKLINE"] = "Show CPS sparkline"
L["FS_ALERT_ENABLED"] = "Enable mismatch alerts"
L["FS_ALERT_VISUAL"] = "Visual alerts"
L["FS_ALERT_AUDIO"] = "Audio alerts"
L["FS_ALERT_SOUND_SLOW"] = "Slow alert sound"
L["FS_ALERT_SOUND_FAST"] = "Fast alert sound"
L["FS_ALERT_CHANNEL"] = "Audio channel"
L["FS_ALERT_TEST"] = "Test"
L["FS_ALERT_SLOW"] = "Slow threshold"
L["FS_ALERT_FAST"] = "Fast threshold"
L["FS_AUTO_LABEL"] = "Auto: %dms (%s)"
L["FS_MANUAL_OVERRIDE"] = "Manual Override"
L["FS_CLEAR_OVERRIDE"] = "Clear Override"
L["FS_OVERRIDE_SET"] = "Manual override set to %dms for %s"
L["FS_OVERRIDE_CLEARED"] = "Override cleared for %s"
L["FS_RATE_WILL_UPDATE"] = "Click rate will update when leaving combat"
L["FS_OVERLAY_TITLE"] = "Faster, Slower"
L["FS_OVERLAY_LOCKED"] = "Overlay locked"
L["FS_OVERLAY_UNLOCKED"] = "Overlay unlocked"
L["FS_OVERLAY_SHOWN"] = "Show click rate overlay"
L["FS_LDB_NO_SEQ"] = "-- /sec"
L["FS_LDB_SPAM"] = "%.1f/sec . %dms"
L["FS_LDB_HOLD"] = "Hold . %dms"
L["FS_ALERT_TOO_SLOW"] = "Clicking too slow!"
L["FS_ALERT_TOO_FAST"] = "Clicking too fast"
L["FS_HOLD_AUTOTUNED"] = "Auto-tuned . poll %dms"
L["FS_HOLD_CONFLICT"] = "Hold Mode: conflict detected with %s (both managing hold-to-cast)"
L["FS_HOLD_ACTIVATED"] = "Hold Mode activated for %s"
L["FS_HOLD_DEACTIVATED"] = "Hold Mode deactivated"
L["FS_HOLD_NO_BUTTON"] = "Hold Mode: native button not found"
L["FS_HOLD_NO_KEYBIND"] = "Hold Mode: No keybind assigned for '%s' -- assign one in the Keybind tab first."
L["FS_HOLD_ENABLED"] = "Enable Hold Mode"
L["FS_HOLD_ENABLED_DESC"] = "Hold your key instead of spamming. EMS borrows a native action button and auto-tunes the repeat rate."
L["FS_HOLD_SLOT"] = "Native button slot"
L["FS_HOLD_SLOT_DESC"] = "Which native action bar button to borrow (default: MultiBar7Button12 -- Bar 7, Slot 12). Leave this slot empty on your action bars."
L["FS_HOLD_POLL_MIN"] = "Minimum poll rate (ms)"
L["FS_HOLD_POLL_MIN_DESC"] = "Floor for UseKeyHeldSpellErrorPollTime CVar. Lower = more responsive but may cause missed inputs."
L["FS_HOLD_NOTE"] = "Hold Mode borrows an unused native button for key-held repeat. Enable per-sequence in the Sequence Editor metadata section."
L["FS_HOLD_TOGGLED_ON"] = "Hold Mode enabled for %s"
L["FS_HOLD_TOGGLED_OFF"] = "Hold Mode disabled for %s"
L["FS_HOLD_SEQ_TOGGLE"] = "Hold Mode"
L["FS_HOLD_SEQ_TOGGLE_DESC"] = "Use hold-to-cast instead of spam clicking for this sequence. Requires Hold Mode enabled in Faster/Slower settings."
L["FS_TEMPO_JUST_RIGHT"] = "Just Right"
L["FS_TEMPO_FASTER"] = "Faster"
L["FS_TEMPO_FASTER_URGENT"] = "Faster!"
L["FS_ALERT_DISABLED"] = "Mismatch alerts disabled"
L["FS_ADJUSTED"] = "Adjusted recommendation based on your play data"
L["FS_WASTED_CLICKS"] = "%d of %d clicks/sec wasted"
