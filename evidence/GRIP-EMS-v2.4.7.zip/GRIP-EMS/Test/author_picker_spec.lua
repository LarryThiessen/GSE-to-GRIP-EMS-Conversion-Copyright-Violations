-- GRIP-EMS: Test spec for v2.1.6 Author Picker (Identity module)
--
-- Created:    2026-05-22
-- Updated:    2026-08-17
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
--
-- Registers tests under category "identity" covering the v2.1.6 author
-- picker additions to Engine/Identity.lua: GetAuthorOptions,
-- GetDefaultAuthorChoice, RegisterCurrentCharacter, and the
-- chosenDisplayName parameter on StampOriginal. Tests that mutate the
-- shared GRIP_EMS_DB.config fields (pseudonym, characterRoster) snapshot
-- + restore the original values so the suite is safe to run repeatedly
-- without poisoning the user's roster.

local ADDON_NAME, GRIPEMS = ...

local TS = GRIPEMS.TestSuite
if not TS then
    return
end

local Identity = GRIPEMS.Identity
if not Identity then
    return
end

-- ---------------------------------------------------------------------------
-- Sandbox helpers
-- ---------------------------------------------------------------------------

local function _SnapshotConfig()
    GRIP_EMS_DB = GRIP_EMS_DB or {}
    GRIP_EMS_DB.config = GRIP_EMS_DB.config or {}
    local cfg = GRIP_EMS_DB.config
    return {
        pseudonym = cfg.pseudonym,
        characterRoster = cfg.characterRoster,
        privacyDefault = cfg.privacyDefault,
    }
end

local function _RestoreConfig(snapshot)
    local cfg = GRIP_EMS_DB and GRIP_EMS_DB.config
    if not cfg then
        return
    end
    cfg.pseudonym = snapshot.pseudonym
    cfg.characterRoster = snapshot.characterRoster
    cfg.privacyDefault = snapshot.privacyDefault
end

-- ---------------------------------------------------------------------------
-- GetDefaultAuthorChoice
-- ---------------------------------------------------------------------------

TS:Register(
    "Identity.GetDefaultAuthorChoice: pseudonymous + configured pseudonym returns pseudonym",
    "identity",
    function(self)
        local snap = _SnapshotConfig()
        GRIP_EMS_DB.config.pseudonym = "TestDoom"
        local choice = Identity:GetDefaultAuthorChoice("pseudonymous")
        _RestoreConfig(snap)
        if choice == "TestDoom" then
            self:Pass()
        else
            self:Fail("expected 'TestDoom', got '" .. tostring(choice) .. "'")
        end
    end
)

TS:Register(
    "Identity.GetDefaultAuthorChoice: pseudonymous + empty pseudonym falls back to current char",
    "identity",
    function(self)
        local snap = _SnapshotConfig()
        GRIP_EMS_DB.config.pseudonym = ""
        local choice = Identity:GetDefaultAuthorChoice("pseudonymous")
        local me = Identity:GetCurrent()
        _RestoreConfig(snap)
        if choice == (me and me.displayName) then
            self:Pass()
        else
            self:Fail("expected current displayName, got '" .. tostring(choice) .. "'")
        end
    end
)

TS:Register(
    "Identity.GetDefaultAuthorChoice: public mode returns current char even with pseudonym set",
    "identity",
    function(self)
        local snap = _SnapshotConfig()
        GRIP_EMS_DB.config.pseudonym = "TestDoom"
        local choice = Identity:GetDefaultAuthorChoice("public")
        local me = Identity:GetCurrent()
        _RestoreConfig(snap)
        if choice == (me and me.displayName) then
            self:Pass()
        else
            self:Fail("expected current displayName, got '" .. tostring(choice) .. "'")
        end
    end
)

-- ---------------------------------------------------------------------------
-- GetAuthorOptions
-- ---------------------------------------------------------------------------

TS:Register("Identity.GetAuthorOptions: pseudonym appears first when configured", "identity", function(self)
    local snap = _SnapshotConfig()
    GRIP_EMS_DB.config.pseudonym = "TestDoom"
    local opts = Identity:GetAuthorOptions()
    _RestoreConfig(snap)
    if opts[1] and opts[1].kind == "pseudonym" and opts[1].value == "TestDoom" then
        self:Pass()
    else
        self:Fail("expected first option pseudonym 'TestDoom', got " .. tostring(opts[1] and opts[1].value))
    end
end)

TS:Register("Identity.GetAuthorOptions: omits pseudonym when empty", "identity", function(self)
    local snap = _SnapshotConfig()
    GRIP_EMS_DB.config.pseudonym = ""
    local opts = Identity:GetAuthorOptions()
    _RestoreConfig(snap)
    for _, opt in ipairs(opts) do
        if opt.kind == "pseudonym" then
            self:Fail("pseudonym entry present when config.pseudonym is empty")
            return
        end
    end
    self:Pass()
end)

TS:Register("Identity.GetAuthorOptions: current character entry has kind='current'", "identity", function(self)
    local snap = _SnapshotConfig()
    GRIP_EMS_DB.config.pseudonym = ""
    local opts = Identity:GetAuthorOptions()
    _RestoreConfig(snap)
    local me = Identity:GetCurrent()
    for _, opt in ipairs(opts) do
        if opt.value == (me and me.displayName) and opt.kind == "current" then
            self:Pass()
            return
        end
    end
    self:Fail("did not find current-character option matching me.displayName")
end)

TS:Register("Identity.GetAuthorOptions: dedupes when pseudonym matches current char name", "identity", function(self)
    local me = Identity:GetCurrent()
    if not me or not me.displayName or me.displayName == "" then
        self:Skip("no current displayName")
        return
    end
    local snap = _SnapshotConfig()
    GRIP_EMS_DB.config.pseudonym = me.displayName
    local opts = Identity:GetAuthorOptions()
    _RestoreConfig(snap)
    local matches = 0
    for _, opt in ipairs(opts) do
        if opt.value == me.displayName then
            matches = matches + 1
        end
    end
    if matches == 1 then
        self:Pass()
    else
        self:Fail("expected 1 entry for shared name, got " .. matches)
    end
end)

-- ---------------------------------------------------------------------------
-- RegisterCurrentCharacter
-- ---------------------------------------------------------------------------

TS:Register("Identity.RegisterCurrentCharacter: adds current character to empty roster", "identity", function(self)
    local snap = _SnapshotConfig()
    GRIP_EMS_DB.config.characterRoster = {}
    Identity:RegisterCurrentCharacter()
    local me = Identity:GetCurrent()
    local found = false
    for _, entry in ipairs(GRIP_EMS_DB.config.characterRoster) do
        if entry.name == (me and me.displayName) and entry.realm == (me and me.realm) then
            found = true
            break
        end
    end
    _RestoreConfig(snap)
    if found then
        self:Pass()
    else
        self:Fail("did not find current character in roster after Register")
    end
end)

TS:Register(
    "Identity.RegisterCurrentCharacter: dedupes by (name,realm) and refreshes lastSeen",
    "identity",
    function(self)
        local snap = _SnapshotConfig()
        local me = Identity:GetCurrent()
        if not me or not me.displayName or me.displayName == "" then
            _RestoreConfig(snap)
            self:Skip("no current displayName")
            return
        end
        GRIP_EMS_DB.config.characterRoster = {
            { name = me.displayName, realm = me.realm, lastSeen = 0 },
        }
        Identity:RegisterCurrentCharacter()
        local roster = GRIP_EMS_DB.config.characterRoster
        local count = #roster
        local lastSeen = roster[1] and roster[1].lastSeen
        _RestoreConfig(snap)
        if count == 1 and (lastSeen or 0) > 0 then
            self:Pass()
        else
            self:Fail(
                string.format(
                    "expected 1 entry with refreshed lastSeen, got count=%d lastSeen=%s",
                    count,
                    tostring(lastSeen)
                )
            )
        end
    end
)

-- ---------------------------------------------------------------------------
-- StampOriginal with chosenDisplayName
-- ---------------------------------------------------------------------------

TS:Register("Identity.StampOriginal: chosenDisplayName lands in originalAuthor", "identity", function(self)
    local snap = _SnapshotConfig()
    GRIP_EMS_DB.config.pseudonym = "TestDoom"
    local seq = {}
    Identity:StampOriginal(seq, "TestDoom")
    _RestoreConfig(snap)
    if seq.originalAuthor == "TestDoom" then
        self:Pass()
    else
        self:Fail("expected originalAuthor='TestDoom', got '" .. tostring(seq.originalAuthor) .. "'")
    end
end)

TS:Register("Identity.StampOriginal: identityHash always derives from me.identityHash", "identity", function(self)
    local seq = {}
    Identity:StampOriginal(seq, "TestDoom")
    local me = Identity:GetCurrent()
    if seq.originalAuthorIdentity == (me and me.identityHash) then
        self:Pass()
    else
        self:Fail("originalAuthorIdentity did not match current identity hash")
    end
end)

TS:Register("Identity.StampOriginal: nil chosenDisplayName falls back to me.displayName", "identity", function(self)
    local snap = _SnapshotConfig()
    GRIP_EMS_DB.config.pseudonym = nil
    local seq = {}
    Identity:StampOriginal(seq, nil)
    _RestoreConfig(snap)
    local me = Identity:GetCurrent()
    if seq.originalAuthor == (me and me.displayName) then
        self:Pass()
    else
        self:Fail("expected originalAuthor=me.displayName, got '" .. tostring(seq.originalAuthor) .. "'")
    end
end)

TS:Register("Identity.StampOriginal: signature locks the chosen displayName", "identity", function(self)
    local seq = {}
    Identity:StampOriginal(seq, "TestDoom")
    local sigBefore = seq.originalSignature
    seq.originalAuthor = "Imposter"
    local recomputed = Identity:SignSequence(seq)
    if sigBefore and sigBefore ~= "" and sigBefore ~= recomputed then
        self:Pass()
    else
        self:Fail("signature did not change after originalAuthor mutation -- chosen name not locked in")
    end
end)

TS:Register("Identity.StampOriginal: modifierChain[1] uses chosen displayName", "identity", function(self)
    local snap = _SnapshotConfig()
    GRIP_EMS_DB.config.pseudonym = "TestDoom"
    local seq = {}
    Identity:StampOriginal(seq, "TestDoom")
    _RestoreConfig(snap)
    local entry = seq.modifierChain and seq.modifierChain[1]
    if entry and entry.kind == "created" and entry.name == "TestDoom" then
        self:Pass()
    else
        self:Fail("modifierChain[1] missing or did not match chosen displayName")
    end
end)

-- ---------------------------------------------------------------------------
-- Phase 1.5: validation + fork default + alt-realm + roster-alt option
-- ---------------------------------------------------------------------------

TS:Register("Identity.IsValidAuthorChoice: rejects names not in GetAuthorOptions", "identity", function(self)
    local snap = _SnapshotConfig()
    GRIP_EMS_DB.config.pseudonym = "TestDoom"
    local ok = Identity:IsValidAuthorChoice("_TS_UnknownChar_xyz123")
    _RestoreConfig(snap)
    if ok == false then
        self:Pass()
    else
        self:Fail("expected false for unknown name '_TS_UnknownChar_xyz123'")
    end
end)

TS:Register("Identity.IsValidAuthorChoice: accepts the configured pseudonym", "identity", function(self)
    local snap = _SnapshotConfig()
    GRIP_EMS_DB.config.pseudonym = "TestDoom"
    local ok = Identity:IsValidAuthorChoice("TestDoom")
    _RestoreConfig(snap)
    if ok == true then
        self:Pass()
    else
        self:Fail("expected true for configured pseudonym")
    end
end)

TS:Register(
    "Identity.StampOriginal: invalid chosenDisplayName falls back to privacy-mode default",
    "identity",
    function(self)
        local snap = _SnapshotConfig()
        GRIP_EMS_DB.config.pseudonym = "TestDoom"
        local seq = { privacyMode = "pseudonymous" }
        Identity:StampOriginal(seq, "_TS_UnknownChar_xyz123") -- not in GetAuthorOptions
        _RestoreConfig(snap)
        if seq.originalAuthor == "TestDoom" then
            self:Pass()
        else
            self:Fail("expected fallback to pseudonym 'TestDoom', got '" .. tostring(seq.originalAuthor) .. "'")
        end
    end
)

TS:Register(
    "Identity.StampOriginal: nil chosenDisplayName + explicit pseudonymous privacyMode stamps pseudonym",
    "identity",
    function(self)
        local snap = _SnapshotConfig()
        GRIP_EMS_DB.config.pseudonym = "TestDoom"
        local seq = { privacyMode = "pseudonymous" }
        Identity:StampOriginal(seq, nil)
        _RestoreConfig(snap)
        if seq.originalAuthor == "TestDoom" then
            self:Pass()
        else
            self:Fail(
                "expected pseudonym 'TestDoom' (fork path with pseudonymous default), got '"
                    .. tostring(seq.originalAuthor)
                    .. "'"
            )
        end
    end
)

TS:Register(
    "Identity.StampOriginal: nil privacyMode reads config.privacyDefault (true fork-integration path)",
    "identity",
    function(self)
        local snap = _SnapshotConfig()
        GRIP_EMS_DB.config.pseudonym = "TestDoom"
        GRIP_EMS_DB.config.privacyDefault = "pseudonymous"
        local seq = {} -- NO privacyMode field -- matches DuplicateSequence newData shape
        Identity:StampOriginal(seq, nil)
        _RestoreConfig(snap)
        if seq.originalAuthor == "TestDoom" then
            self:Pass()
        else
            self:Fail(
                "expected pseudonym 'TestDoom' (fork integration: nil privacyMode + config.privacyDefault=pseudonymous), got '"
                    .. tostring(seq.originalAuthor)
                    .. "'"
            )
        end
    end
)

TS:Register("Identity.GetAuthorOptions: alt characters from roster appear as kind='alt'", "identity", function(self)
    local snap = _SnapshotConfig()
    GRIP_EMS_DB.config.pseudonym = ""
    GRIP_EMS_DB.config.characterRoster = {
        { name = "AltOne", realm = "RealmA", lastSeen = 100 },
        { name = "AltTwo", realm = "RealmB", lastSeen = 200 },
    }
    local opts = Identity:GetAuthorOptions()
    _RestoreConfig(snap)
    local sawAltOne, sawAltTwo = false, false
    for _, opt in ipairs(opts) do
        if opt.kind == "alt" and opt.value == "AltOne" and opt.realm == "RealmA" then
            sawAltOne = true
        end
        if opt.kind == "alt" and opt.value == "AltTwo" and opt.realm == "RealmB" then
            sawAltTwo = true
        end
    end
    if sawAltOne and sawAltTwo then
        self:Pass()
    else
        self:Fail(string.format("missing alt entries: AltOne=%s AltTwo=%s", tostring(sawAltOne), tostring(sawAltTwo)))
    end
end)
