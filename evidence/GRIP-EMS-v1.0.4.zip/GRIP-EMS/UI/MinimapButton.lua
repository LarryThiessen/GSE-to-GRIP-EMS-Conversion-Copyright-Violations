-- GRIP-EMS: Minimap Button
-- LibDataBroker launcher + LibDBIcon minimap button registration

local ADDON_NAME, GRIPEMS = ...
local UI = GRIPEMS.UI
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS")

local LDB = LibStub("LibDataBroker-1.1", true)
local LDBIcon = LibStub("LibDBIcon-1.0", true)

if not LDB or not LDBIcon then
    GRIPEMS:Debug("LibDataBroker or LibDBIcon not found, minimap button disabled.")
    return
end

---------------------------------------------------------------------------
-- Broker object
---------------------------------------------------------------------------
local broker = LDB:NewDataObject("GRIP-EMS", {
    type = "launcher",
    text = "GRIP-EMS",
    icon = "Interface\\Icons\\Ability_Rogue_MasterOfSubtlety",
    OnClick = function(self, button)
        if button == "LeftButton" then
            UI:ToggleMainFrame()
        elseif button == "RightButton" then
            GRIPEMS:Print("Right-click menu coming in Phase 3B")
        end
    end,
    OnTooltipShow = function(tooltip)
        if not tooltip then return end
        tooltip:AddDoubleLine(
            "|cFF00CC66GRIP|r-EMS",
            "v" .. (GRIPEMS.version or "dev"),
            1, 1, 1,  0.6, 0.6, 0.6
        )
        tooltip:AddLine(" ")
        -- Active sequences
        local count = 0
        if GRIPEMS.Engine and GRIPEMS.Engine.GetActiveCount then
            count = GRIPEMS.Engine:GetActiveCount()
        end
        tooltip:AddDoubleLine(
            L["GEMS_UI_ACTIVE_SEQUENCES_LABEL"],
            tostring(count),
            0.8, 0.8, 0.8,  0, 0.8, 0.4
        )
        -- Active context
        if GRIPEMS.Engine and GRIPEMS.Engine.currentContext then
            tooltip:AddDoubleLine(
                L["GEMS_UI_CONTEXT_LABEL"],
                GRIPEMS.Engine.currentContext or "none",
                0.8, 0.8, 0.8,  0, 0.8, 0.4
            )
        end
        tooltip:AddLine(" ")
        tooltip:AddLine(L["GEMS_UI_MINIMAP_LEFT"], 0.5, 0.5, 0.5)
        tooltip:AddLine(L["GEMS_UI_MINIMAP_RIGHT"], 0.5, 0.5, 0.5)
    end,
})

---------------------------------------------------------------------------
-- Registration (called from Core.lua ADDON_LOADED)
---------------------------------------------------------------------------

--- Initialize the minimap button using LibDBIcon.
--- Uses GRIP_EMS_DB.minimapButton for hide/show persistence.
function UI:InitMinimapButton()
    if not GRIP_EMS_DB then return end
    if not GRIP_EMS_DB.minimapButton then
        GRIP_EMS_DB.minimapButton = { hide = false }
    end
    LDBIcon:Register("GRIP-EMS", broker, GRIP_EMS_DB.minimapButton)
end
