-- GRIP-EMS: Step List View
-- Editable step list with ScrollBox, action buttons, and per-step EditBox

local ADDON_NAME, GRIPEMS = ...
local UI = GRIPEMS.UI
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS")

-- Upvalue accessor for Defaults
local function D()
    return GRIPEMS.Defaults
end

GRIPEMS.StepListView = {}
local SLV = GRIPEMS.StepListView

-- Runtime state
SLV.workingSteps = {}
SLV.originalSteps = {}
SLV.selectedIndex = nil
SLV._lastLineCount = 0
SLV._refreshRowTimer = nil
SLV.keyPressLen = 0
SLV.keyReleaseLen = 0

-- Tree mode state (v1.2.0 S14-B)
SLV.treeMode = false
SLV.workingActions = nil
SLV._originalActionsSerialized = nil
SLV.hasActions = false

-- Debug: when true, RefreshCurrentRow is skipped (flicker diagnostic)
local debugSkipRowRefresh = false

---------------------------------------------------------------------------
-- Tab-press autocomplete helpers
---------------------------------------------------------------------------

--- Extract the word under the cursor from an EditBox.
--- Walks back from cursor to the nearest word boundary (space, newline, or
--- start of string). "/" and "#" are NOT boundaries (macro command prefixes).
--- @param editBox EditBox The EditBox to read
--- @return string word The extracted word
--- @return number wordStart Start position of the word (1-based)
--- @return number cursorPos Cursor position
local function extractWordUnderCursor(editBox)
    local text = editBox:GetText() or ""
    local cursorPos = editBox:GetCursorPosition()
    local wordStart = cursorPos
    while wordStart > 0 do
        local ch = text:sub(wordStart, wordStart)
        if ch == " " or ch == "\n" then
            wordStart = wordStart + 1
            break
        end
        wordStart = wordStart - 1
    end
    if wordStart <= 0 then
        wordStart = 1
    end
    local word = text:sub(wordStart, cursorPos)
    return word, wordStart, cursorPos
end

--- Handle Tab keypress in a step EditBox: attempt spell autocomplete.
--- Falls back to ClearFocus if no matches or spell cache unavailable.
--- @param editBox EditBox The EditBox that received the Tab press
local function handleTabAutocomplete(editBox)
    -- If dropdown is already shown, dismiss it and defocus
    if SLV.autocompleteDropdown and SLV.autocompleteDropdown:IsShown() then
        SLV.autocompleteDropdown:Hide()
        editBox:ClearFocus()
        return
    end

    local SC = GRIPEMS.SpellCache
    if not SC or not SC.ready then
        editBox:ClearFocus()
        return
    end

    local word, wordStart, cursorPos = extractWordUnderCursor(editBox)

    -- Variable autocomplete: check if character before wordStart is "~"
    local text = editBox:GetText() or ""
    local charBefore = (wordStart > 1) and text:sub(wordStart - 1, wordStart - 1) or ""
    local isVarComplete = (charBefore == "~")
    -- Also trigger if word itself starts with ~ (cursor right after ~)
    if not isVarComplete and word:sub(1, 1) == "~" then
        isVarComplete = true
        -- Strip the leading ~ from the word; adjust wordStart to include it
        word = word:sub(2)
        -- wordStart already includes the ~ position
    end

    if isVarComplete then
        local VS = GRIPEMS.VariableStore
        if not VS then
            editBox:ClearFocus()
            return
        end
        local store = VS:GetAll()
        local varMatches = {}
        local prefix = word:lower()
        for varName in pairs(store) do
            if prefix == "" or varName:lower():sub(1, #prefix) == prefix then
                varMatches[#varMatches + 1] = { name = varName }
            end
        end
        table.sort(varMatches, function(a, b)
            return a.name < b.name
        end)
        if #varMatches > D().AUTOCOMPLETE_MAX_RESULTS then
            local trimmed = {}
            for i = 1, D().AUTOCOMPLETE_MAX_RESULTS do
                trimmed[i] = varMatches[i]
            end
            varMatches = trimmed
        end
        if #varMatches == 0 then
            editBox:ClearFocus()
            return
        end
        -- For variable autocomplete, the replacement range starts at the ~
        local tildeStart = charBefore == "~" and (wordStart - 1) or wordStart
        SLV:ShowVarAutocompleteMenu(editBox, varMatches, tildeStart, cursorPos)
        return
    end

    local firstChar = word:sub(1, 1)
    local isCommand = (firstChar == "/" or firstChar == "#")
    local minChars = isCommand and D().AUTOCOMPLETE_MIN_CHARS or D().AUTOCOMPLETE_MIN_SPELL_CHARS
    if #word < minChars then
        editBox:ClearFocus()
        return
    end

    -- Dual-path: macro commands (starts with / or #) or spell names
    local matches
    if isCommand then
        matches = SC:MacroCommandSearch(word, D().AUTOCOMPLETE_MAX_RESULTS)
    else
        matches = SC:PrefixSearch(word, D().AUTOCOMPLETE_MAX_RESULTS)
    end
    if #matches == 0 then
        -- Fallback: sequence name autocomplete
        if #word >= D().AUTOCOMPLETE_MIN_SEQ_CHARS then
            local seqMatches = SLV:SearchSequenceNames(word)
            if #seqMatches > 0 then
                SLV:ShowSeqAutocompleteMenu(editBox, seqMatches, wordStart, cursorPos)
                return
            end
        end
        editBox:ClearFocus()
        return
    end

    -- Show autocomplete popup
    SLV:ShowAutocompleteMenu(editBox, matches, wordStart, cursorPos)
end

---------------------------------------------------------------------------
-- Initialization
---------------------------------------------------------------------------

--- Build the editable step list inside the given parent frame (tab content area).
--- @param parentFrame Frame The content area that hosts the step list
function SLV:Init(parentFrame)
    if not parentFrame then
        return
    end
    local C = UI.Colors

    SLV.container = parentFrame

    ---------------------------------------------------------------------------
    -- Edit area (bottom section: header line + EditBox)
    ---------------------------------------------------------------------------
    local editArea = CreateFrame("Frame", nil, parentFrame)
    editArea:SetHeight(D().STEP_EDIT_HEIGHT_MAX + 20)
    editArea:SetPoint("BOTTOMLEFT", parentFrame, "BOTTOMLEFT", 4, 4)
    editArea:SetPoint("BOTTOMRIGHT", parentFrame, "BOTTOMRIGHT", -4, 4)
    editArea:Hide()
    SLV.editArea = editArea

    -- Step header: "Step N:" left-aligned, char count right-aligned
    local editHeader = editArea:CreateFontString(nil, "OVERLAY")
    UI:SetFont(editHeader, 11)
    editHeader:SetPoint("TOPLEFT", editArea, "TOPLEFT", 2, 0)
    editHeader:SetText("")
    editHeader:SetTextColor(C.textSecondary:GetRGBA())
    SLV.editHeader = editHeader

    local editCharCount = editArea:CreateFontString(nil, "OVERLAY")
    UI:SetFont(editCharCount, 10)
    editCharCount:SetPoint("TOPRIGHT", editArea, "TOPRIGHT", -2, 0)
    editCharCount:SetText("")
    editCharCount:SetTextColor(C.textSuccess:GetRGBA())
    SLV.editCharCount = editCharCount

    -- Interleave controls row (shown only for ACTION nodes in outline mode)
    local ilRow = CreateFrame("Frame", nil, editArea)
    ilRow:SetHeight(22)
    ilRow:SetPoint("TOPLEFT", editHeader, "BOTTOMLEFT", 0, -2)
    ilRow:SetPoint("RIGHT", editArea, "RIGHT", -2, 0)
    ilRow:Hide()
    SLV.ilRow = ilRow

    local ilLbl = ilRow:CreateFontString(nil, "OVERLAY")
    UI:SetFont(ilLbl, 10)
    ilLbl:SetPoint("LEFT", ilRow, "LEFT", 0, 0)
    ilLbl:SetText(L["GEMS_ACTION_INTERLEAVE_EVERY"])
    ilLbl:SetTextColor(C.textSecondary:GetRGBA())
    SLV.ilLabel = ilLbl

    local ilCheck = CreateFrame("CheckButton", nil, ilRow, "UICheckButtonTemplate")
    ilCheck:SetSize(20, 20)
    ilCheck:SetPoint("LEFT", ilLbl, "RIGHT", 4, 0)
    SLV.ilCheck = ilCheck

    local fontPath = GameFontNormal:GetFont()
    local ivBox = CreateFrame("EditBox", nil, ilRow, "BackdropTemplate")
    ivBox:SetSize(36, 20)
    ivBox:SetPoint("LEFT", ilCheck, "RIGHT", 4, 0)
    ivBox:SetAutoFocus(false)
    ivBox:SetNumeric(true)
    ivBox:SetMaxLetters(2)
    UI:ApplyBackdrop(ivBox, UI.Backdrops.panel, C.bgInput, C.border)
    ivBox:SetTextInsets(4, 4, 2, 2)
    ivBox:SetFont(fontPath, 10, "")
    ivBox:SetTextColor(C.textPrimary:GetRGBA())
    ivBox:Hide()
    SLV.ilSpinner = ivBox

    local stepsLbl = ilRow:CreateFontString(nil, "OVERLAY")
    UI:SetFont(stepsLbl, 10)
    stepsLbl:SetPoint("LEFT", ivBox, "RIGHT", 4, 0)
    stepsLbl:SetText(L["GEMS_ACTION_INTERLEAVE_STEPS"])
    stepsLbl:SetTextColor(C.textSecondary:GetRGBA())
    SLV.ilStepsLabel = stepsLbl

    -- EditBox
    local editBox = CreateFrame("EditBox", nil, editArea, "BackdropTemplate")
    editBox:SetPoint("TOPLEFT", editHeader, "BOTTOMLEFT", 0, -4)
    editBox:SetPoint("RIGHT", editArea, "RIGHT", -22, 0)
    editBox:SetHeight(D().STEP_EDIT_HEIGHT_MIN)
    editBox:SetMultiLine(true)
    editBox:SetAutoFocus(false)
    UI:ApplyBackdrop(editBox, UI.Backdrops.panel, C.bgInput, C.border)
    editBox:SetTextInsets(6, 6, 4, 4)

    -- Spell Picker button (icon button to the right of EditBox)
    local spellPickerBtn = CreateFrame("Button", nil, editArea)
    spellPickerBtn:SetSize(16, 16)
    spellPickerBtn:SetPoint("LEFT", editBox, "RIGHT", 3, 0)
    spellPickerBtn:SetNormalTexture("Interface\\Icons\\INV_Misc_Book_09")
    spellPickerBtn:SetScript("OnClick", function(self)
        local SPicker = GRIPEMS.SpellPicker
        if SPicker then
            SPicker:Toggle(editBox, self)
        end
    end)
    spellPickerBtn:SetScript("OnEnter", function(self)
        UI:ShowTooltip(self, L["GEMS_SPELLPICKER_TITLE"], L["GEMS_SPELLPICKER_INSERT"])
    end)
    spellPickerBtn:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)
    SLV.spellPickerBtn = spellPickerBtn

    editBox:SetFont(fontPath, 11, "")
    editBox:SetTextColor(C.textPrimary:GetRGBA())

    editBox:SetScript("OnTextChanged", function(self, userInput)
        if not userInput then
            return
        end
        if not SLV.selectedIndex then
            return
        end
        local text = self:GetText() or ""
        local idx = SLV.selectedIndex
        SLV.workingSteps[idx] = text

        -- Undo snapshot: capture original text on first change
        if SLV._undoTextSnapshot == nil and not SLV._suppressUndo then
            SLV._undoTextSnapshot = SLV._preEditText or ""
            SLV._undoTextSnapshotIdx = idx
        end

        -- Update char count display
        SLV:UpdateEditCharCount(#text)

        -- Set dirty flag on editor
        local SE = GRIPEMS.SequenceEditor
        if SE then
            SE.isDirty = true
            SE:UpdateSaveButtons()
        end

        -- Auto-height: only call SetHeight when hard newline count changes
        local numLines = select(2, text:gsub("\n", "")) + 1
        if numLines ~= SLV._lastLineCount then
            SLV._lastLineCount = numLines
            local lineHeight = 14
            local desiredH =
                math.max(D().STEP_EDIT_HEIGHT_MIN, math.min(D().STEP_EDIT_HEIGHT_MAX, numLines * lineHeight + 8))
            self:SetHeight(desiredH)
        end

        -- Refresh scroll row (lightweight, no DataProvider rebuild)
        SLV:DebouncedRefreshCurrentRow()

        -- Live-filter autocomplete if dropdown is visible
        SLV:RefreshAutocomplete(self)
    end)
    editBox:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
    end)
    editBox:SetScript("OnTabPressed", function(self)
        handleTabAutocomplete(self)
    end)
    editBox:SetScript("OnEditFocusGained", function(self)
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
        -- Capture pre-edit text for undo snapshot
        if SLV.selectedIndex and SLV.workingSteps then
            SLV._preEditText = SLV.workingSteps[SLV.selectedIndex]
        end
    end)
    editBox:SetScript("OnEditFocusLost", function(self)
        self:SetBackdropBorderColor(C.border:GetRGBA())
        -- Flush debounced undo entry for text editing
        SLV:FlushTextUndoSnapshot()
    end)
    SLV.editBox = editBox

    -- Syntax highlighting hook
    local SH = GRIPEMS.SyntaxHighlight
    if SH then
        SH:HookEditBox(SLV.editBox, "macro")
    end

    -- Unsaved changes hint (below editBox, subtle yellow)
    local unsavedHint = editArea:CreateFontString(nil, "OVERLAY")
    UI:SetFont(unsavedHint, 9)
    unsavedHint:SetPoint("BOTTOMLEFT", editArea, "BOTTOMLEFT", 4, 0)
    unsavedHint:SetText(L["GEMS_STEP_UNSAVED_HINT"])
    unsavedHint:SetTextColor(C.textWarning:GetRGBA())
    unsavedHint:SetAlpha(0.8)
    unsavedHint:Hide()
    SLV.unsavedHint = unsavedHint

    ---------------------------------------------------------------------------
    -- Action button bar (above edit area)
    ---------------------------------------------------------------------------
    local actionBar = CreateFrame("Frame", nil, parentFrame)
    actionBar:SetHeight(D().STEP_ACTION_BAR_HEIGHT)
    actionBar:SetPoint("BOTTOMLEFT", editArea, "TOPLEFT", 0, 4)
    actionBar:SetPoint("BOTTOMRIGHT", editArea, "TOPRIGHT", 0, 4)
    SLV.actionBar = actionBar

    -- Build action buttons
    local btnDefs = {
        {
            key = "add",
            label = L["GEMS_UI_ADD_STEP"],
            desc = L["GEMS_UI_ADD_STEP_DESC"],
            fn = function(self)
                SLV:_showAddMenu(self or SLV.actionButtons["add"], false)
            end,
        },
        {
            key = "dup",
            label = L["GEMS_UI_DUP_STEP"],
            desc = L["GEMS_UI_DUP_STEP_DESC"],
            fn = function()
                if SLV.hasActions and SLV.workingActions then
                    local ni = (SLV._editingContext and SLV._editingContext.nodeIndex)
                        or (SLV._detailOpen and SLV._detailNodeIndex)
                    if ni and SLV.workingActions[ni] then
                        local DD = GRIPEMS.Defaults
                        local copy = DD.DeepCopyActions({ SLV.workingActions[ni] })[1]
                        table.insert(SLV.workingActions, ni + 1, copy)
                        SLV:_markDirty()
                        SLV:RefreshAll()
                        return
                    end
                end
                SLV:DuplicateStep()
            end,
        },
        {
            key = "up",
            label = L["GEMS_UI_MOVE_UP"],
            desc = L["GEMS_UI_MOVE_UP_DESC"],
            fn = function()
                if SLV.hasActions and SLV.workingActions then
                    local ni = (SLV._editingContext and SLV._editingContext.nodeIndex)
                        or (SLV._detailOpen and SLV._detailNodeIndex)
                    if ni and ni > 1 then
                        SLV.workingActions[ni], SLV.workingActions[ni - 1] =
                            SLV.workingActions[ni - 1], SLV.workingActions[ni]
                        if SLV._editingContext then
                            SLV._editingContext.nodeIndex = ni - 1
                        end
                        if SLV._detailOpen and SLV._detailNodeIndex == ni then
                            SLV._detailNodeIndex = ni - 1
                        end
                        SLV:_markDirty()
                        SLV:RefreshAll()
                        return
                    end
                end
                SLV:MoveStepUp()
            end,
        },
        {
            key = "down",
            label = L["GEMS_UI_MOVE_DOWN"],
            desc = L["GEMS_UI_MOVE_DOWN_DESC"],
            fn = function()
                if SLV.hasActions and SLV.workingActions then
                    local ni = (SLV._editingContext and SLV._editingContext.nodeIndex)
                        or (SLV._detailOpen and SLV._detailNodeIndex)
                    if ni and ni < #SLV.workingActions then
                        SLV.workingActions[ni], SLV.workingActions[ni + 1] =
                            SLV.workingActions[ni + 1], SLV.workingActions[ni]
                        if SLV._editingContext then
                            SLV._editingContext.nodeIndex = ni + 1
                        end
                        if SLV._detailOpen and SLV._detailNodeIndex == ni then
                            SLV._detailNodeIndex = ni + 1
                        end
                        SLV:_markDirty()
                        SLV:RefreshAll()
                        return
                    end
                end
                SLV:MoveStepDown()
            end,
        },
        {
            key = "del",
            label = L["GEMS_UI_DEL_STEP"],
            desc = L["GEMS_UI_DEL_STEP_DESC"],
            fn = function()
                if SLV.hasActions and SLV.workingActions then
                    local ni = (SLV._editingContext and SLV._editingContext.nodeIndex)
                        or (SLV._detailOpen and SLV._detailNodeIndex)
                    if ni and SLV.workingActions[ni] then
                        table.remove(SLV.workingActions, ni)
                        if SLV._detailOpen and SLV._detailNodeIndex then
                            if SLV._detailNodeIndex == ni then
                                SLV:CloseDetailPane()
                            elseif SLV._detailNodeIndex > ni then
                                SLV._detailNodeIndex = SLV._detailNodeIndex - 1
                            end
                        end
                        SLV._editingContext = nil
                        SLV.selectedIndex = nil
                        SLV:_markDirty()
                        SLV:RefreshAll()
                        return
                    end
                end
                SLV:DeleteStep()
            end,
        },
    }
    SLV.actionButtons = {}
    local prevBtn
    for _, def in ipairs(btnDefs) do
        local btn = UI:CreateButton(actionBar, def.label, D().STEP_BUTTON_WIDTH, D().STEP_BUTTON_HEIGHT)
        if prevBtn then
            btn:SetPoint("LEFT", prevBtn, "RIGHT", 4, 0)
        else
            btn:SetPoint("LEFT", actionBar, "LEFT", 0, 0)
        end

        btn:SetScript("OnClick", def.fn)
        btn:SetScript("OnEnter", function(self)
            self:SetBackdropColor(C.bgRowHover:GetRGBA())
            self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
            UI:ShowTooltip(self, def.label, def.desc)
        end)
        btn:SetScript("OnLeave", function(self)
            SLV:UpdateButtonStates()
            UI:HideTooltip()
        end)

        SLV.actionButtons[def.key] = btn
        prevBtn = btn
    end

    -- Save button (right-aligned, shown only when dirty)
    local saveBtn = UI:CreateButton(actionBar, L["GEMS_STEP_SAVE"], 60, D().STEP_BUTTON_HEIGHT)
    saveBtn:SetPoint("RIGHT", actionBar, "RIGHT", 0, 0)
    saveBtn:SetBackdropColor(C.bgSave:GetRGBA())
    saveBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.bgSaveHover:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
        UI:ShowTooltip(self, L["GEMS_STEP_SAVE"], L["GEMS_STEP_SAVE_DESC"])
    end)
    saveBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgSave:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
        UI:HideTooltip()
    end)
    saveBtn:SetScript("OnClick", function()
        local SE = GRIPEMS.SequenceEditor
        if SE then
            SE:SaveSequence()
        end
    end)
    saveBtn:Hide()
    SLV.saveBtn = saveBtn

    ---------------------------------------------------------------------------
    -- ScrollBox (top section, above action bar)
    ---------------------------------------------------------------------------
    local scrollBox = CreateFrame("Frame", nil, parentFrame, "WowScrollBoxList")
    scrollBox:SetPoint("TOPLEFT", parentFrame, "TOPLEFT", 4, -4)
    scrollBox:SetPoint("RIGHT", parentFrame, "RIGHT", -18, 0)
    scrollBox:SetPoint("BOTTOM", actionBar, "TOP", 0, 4)
    SLV.scrollBox = scrollBox

    local scrollBar = CreateFrame("EventFrame", nil, parentFrame, "MinimalScrollBar")
    scrollBar:SetPoint("TOPLEFT", scrollBox, "TOPRIGHT", 2, 0)
    scrollBar:SetPoint("BOTTOMLEFT", scrollBox, "BOTTOMRIGHT", 2, 0)
    SLV.scrollBar = scrollBar

    local scrollView = CreateScrollBoxListLinearView()
    scrollView:SetElementExtent(D().STEP_ROW_HEIGHT)
    SLV.scrollView = scrollView

    scrollView:SetElementInitializer("Button", function(button, data)
        SLV:InitRow(button, data)
    end)

    ScrollUtil.InitScrollBoxListWithScrollBar(scrollBox, scrollBar, scrollView)

    local dp = CreateDataProvider()
    scrollBox:SetDataProvider(dp)
    SLV.dataProvider = dp

    ---------------------------------------------------------------------------
    -- Drag-to-reorder infrastructure (ghost frame, indicator, state)
    ---------------------------------------------------------------------------
    local dragGhost = CreateFrame("Frame", "GRIPEMS_DragGhost", UIParent, "BackdropTemplate")
    dragGhost:SetFrameStrata("TOOLTIP")
    UI:ApplyBackdrop(dragGhost, UI.Backdrops.panel, C.bgRowSelected, C.borderFocus)
    dragGhost:SetSize(scrollBox:GetWidth(), D().STEP_ROW_HEIGHT)

    dragGhost.ghostNum = dragGhost:CreateFontString(nil, "OVERLAY")
    UI:SetFont(dragGhost.ghostNum, 10)
    dragGhost.ghostNum:SetPoint("LEFT", dragGhost, "LEFT", 4, 0)
    dragGhost.ghostNum:SetWidth(30)
    dragGhost.ghostNum:SetJustifyH("LEFT")
    dragGhost.ghostNum:SetTextColor(C.textSecondary:GetRGBA())

    dragGhost.ghostText = dragGhost:CreateFontString(nil, "OVERLAY")
    UI:SetFont(dragGhost.ghostText, 11)
    dragGhost.ghostText:SetPoint("LEFT", dragGhost.ghostNum, "RIGHT", 4, 0)
    dragGhost.ghostText:SetPoint("RIGHT", dragGhost, "RIGHT", -4, 0)
    dragGhost.ghostText:SetJustifyH("LEFT")
    dragGhost.ghostText:SetWordWrap(false)
    dragGhost.ghostText:SetTextColor(C.textPrimary:GetRGBA())

    dragGhost:Hide()
    SLV.dragGhost = dragGhost

    local dragIndicator = CreateFrame("Frame", nil, parentFrame)
    dragIndicator:SetHeight(2)
    dragIndicator:SetFrameLevel(scrollBox:GetFrameLevel() + 10)
    local indicatorTex = dragIndicator:CreateTexture(nil, "OVERLAY")
    indicatorTex:SetAllPoints()
    indicatorTex:SetColorTexture(C.borderFocus:GetRGBA())
    dragIndicator:Hide()
    SLV.dragIndicator = dragIndicator

    SLV._dragSourceIndex = nil
    SLV._isDragging = false

    ---------------------------------------------------------------------------
    -- Empty / placeholder labels
    ---------------------------------------------------------------------------
    local emptyIcon = parentFrame:CreateTexture(nil, "OVERLAY")
    emptyIcon:SetSize(32, 32)
    emptyIcon:SetPoint("CENTER", scrollBox, "CENTER", 0, 24)
    emptyIcon:SetTexture(134400)
    emptyIcon:SetAlpha(0.3)
    SLV.emptyIcon = emptyIcon

    local emptyLabel = parentFrame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(emptyLabel, 11)
    emptyLabel:SetPoint("CENTER", scrollBox, "CENTER", 0, -4)
    emptyLabel:SetText(L["GEMS_UI_NO_STEPS"])
    emptyLabel:SetTextColor(C.textMuted:GetRGBA())
    SLV.emptyLabel = emptyLabel

    local hintLabel = parentFrame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(hintLabel, 9)
    hintLabel:SetPoint("TOP", emptyLabel, "BOTTOM", 0, -4)
    hintLabel:SetText(L["GEMS_UI_ADD_STEP_HINT"])
    hintLabel:SetTextColor(C.textMuted:GetRGBA())
    hintLabel:SetWidth(220)
    hintLabel:SetJustifyH("CENTER")
    SLV.hintLabel = hintLabel

    -- Placeholder for when no step is selected
    local selectLabel = parentFrame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(selectLabel, 10)
    selectLabel:SetPoint("CENTER", editArea, "CENTER", 0, 0)
    selectLabel:SetText(L["GEMS_UI_SELECT_STEP"])
    selectLabel:SetTextColor(C.textMuted:GetRGBA())
    selectLabel:Hide()
    SLV.selectLabel = selectLabel
end

---------------------------------------------------------------------------
-- Row initializer
---------------------------------------------------------------------------

--- Initialize or refresh a step row. ScrollBox reuses frames.
--- Handles both "step" rows (flat steps) and "node" rows (badge rows).
--- @param button Button The reusable row frame
--- @param data table { rowType, index, text, charCount } or { rowType, nodeType, ... }
function SLV:InitRow(button, data)
    local C = UI.Colors
    local defaults = D()

    -- Node badge rows
    if data.rowType == "node" then
        button:SetHeight(defaults.NODE_BADGE_HEIGHT)

        -- One-time init for BackdropTemplate
        if not button.SetBackdrop then
            Mixin(button, BackdropTemplateMixin)
        end
        button:SetBackdrop(UI.Backdrops.panelNoBorder)
        button:EnableMouse(true)
        button:RegisterForClicks("LeftButtonUp", "RightButtonUp")

        -- Hide step-specific elements if they exist
        if button.stepNum then
            button.stepNum:Hide()
        end
        if button.stepText then
            button.stepText:Hide()
        end
        if button.charCount then
            button.charCount:Hide()
        end
        if button.modBadge then
            button.modBadge:Hide()
        end

        -- Lazy-create drag handle (shared with step rows)
        if not button.dragHandle then
            button.dragHandle = CreateFrame("Frame", nil, button)
            button.dragHandle:SetSize(defaults.STEP_DRAG_HANDLE_WIDTH, defaults.NODE_BADGE_HEIGHT)
            button.dragHandle:SetPoint("LEFT", button, "LEFT", 2, 0)
            for lineIdx = 1, 3 do
                local line = button.dragHandle:CreateTexture(nil, "ARTWORK")
                line:SetSize(8, 1)
                line:SetColorTexture(C.textMuted:GetRGBA())
                line:SetPoint("CENTER", button.dragHandle, "CENTER", 0, (lineIdx - 2) * 3)
            end
            button.dragHandle:EnableMouse(true)
            button.dragHandle:RegisterForDrag("LeftButton")
        end
        button.dragHandle:SetHeight(defaults.NODE_BADGE_HEIGHT)
        button.dragHandle:Show()

        -- Lazy-create node badge elements
        if not button._nodeIcon then
            local iconFrame = CreateFrame("Frame", nil, button, "BackdropTemplate")
            iconFrame:SetSize(18, 18)
            iconFrame:SetPoint("LEFT", button, "LEFT", 6 + defaults.STEP_DRAG_HANDLE_WIDTH, 0)
            local iconLabel = iconFrame:CreateFontString(nil, "OVERLAY")
            UI:SetFont(iconLabel, 11, "OUTLINE")
            iconLabel:SetPoint("CENTER")
            button._nodeIcon = iconFrame
            button._nodeIconLabel = iconLabel
        end
        -- Re-anchor icon after drag handle
        button._nodeIcon:ClearAllPoints()
        button._nodeIcon:SetPoint("LEFT", button.dragHandle, "RIGHT", 2, 0)

        if not button._nodeNameLabel then
            local nameFs = button:CreateFontString(nil, "OVERLAY")
            UI:SetFont(nameFs, 12)
            nameFs:SetPoint("LEFT", button._nodeIcon, "RIGHT", 6, 0)
            nameFs:SetJustifyH("LEFT")
            nameFs:SetWordWrap(false)
            button._nodeNameLabel = nameFs
        end
        if not button._nodeSummaryLabel then
            local sumFs = button:CreateFontString(nil, "OVERLAY")
            UI:SetFont(sumFs, 11)
            sumFs:SetPoint("LEFT", button._nodeNameLabel, "RIGHT", 8, 0)
            sumFs:SetPoint("RIGHT", button, "RIGHT", -24, 0)
            sumFs:SetJustifyH("LEFT")
            sumFs:SetWordWrap(false)
            button._nodeSummaryLabel = sumFs
        end
        if not button._nodeChevron then
            local chev = button:CreateFontString(nil, "OVERLAY")
            UI:SetFont(chev, 12)
            chev:SetPoint("RIGHT", button, "RIGHT", -6, 0)
            chev:SetText(">")
            button._nodeChevron = chev
        end

        -- Show node elements
        button._nodeIcon:Show()
        button._nodeIconLabel:Show()
        button._nodeNameLabel:Show()
        button._nodeSummaryLabel:Show()
        button._nodeChevron:Show()

        -- Populate node badge
        local iconInfo = defaults.NODE_ICONS[data.nodeType] or defaults.NODE_ICONS["loop"]
        local iconColor = iconInfo.color
        UI:ApplyBackdrop(
            button._nodeIcon,
            UI.Backdrops.panel,
            CreateColor(iconColor[1], iconColor[2], iconColor[3], 0.3),
            CreateColor(iconColor[1], iconColor[2], iconColor[3], 0.6)
        )
        button._nodeIconLabel:SetText(iconInfo.symbol)
        button._nodeIconLabel:SetTextColor(iconColor[1], iconColor[2], iconColor[3], 1)

        local displayName = data.nodeName or ""
        if displayName == "" then
            displayName = iconInfo.label
        end
        button._nodeNameLabel:SetText(displayName)
        button._nodeNameLabel:SetTextColor(C.textPrimary:GetRGBA())

        button._nodeSummaryLabel:SetText(data.nodeSummary or "")
        button._nodeSummaryLabel:SetTextColor(C.textSecondary:GetRGBA())

        button._nodeChevron:SetTextColor(C.textMuted:GetRGBA())

        -- Selection state for node badges
        local isSelected = (SLV._detailOpen and SLV._detailNodeIndex == data.nodeIndex)
        if isSelected then
            button:SetBackdropColor(C.bgRowSelected:GetRGBA())
        else
            button:SetBackdropColor(C.bgPanel:GetRGBA())
        end

        button._stepData = data

        -- Hover
        button:SetScript("OnEnter", function(self)
            if not isSelected then
                self:SetBackdropColor(C.bgRowHover:GetRGBA())
            end
        end)
        button:SetScript("OnLeave", function(self)
            if not isSelected then
                self:SetBackdropColor(C.bgPanel:GetRGBA())
            end
        end)

        -- Click: left = open detail pane, right = context menu
        button:SetScript("OnClick", function(self, mouseButton)
            if mouseButton == "RightButton" then
                SLV:ShowNodeContextMenu(self, data)
            else
                SLV:OpenDetailPane(data.nodeIndex)
            end
        end)

        -- Drag scripts for outline reorder
        button.dragHandle:SetScript("OnEnter", function()
            if button:GetScript("OnEnter") then
                button:GetScript("OnEnter")(button)
            end
        end)
        button.dragHandle:SetScript("OnLeave", function()
            if button:GetScript("OnLeave") then
                button:GetScript("OnLeave")(button)
            end
        end)
        button.dragHandle:SetScript("OnDragStart", function()
            SLV:_beginOutlineDrag(button, data)
        end)
        button.dragHandle:SetScript("OnDragStop", function()
            SLV:_endOutlineDrag(button)
        end)
        button.dragHandle:SetScript("OnMouseUp", function(_, mouseButton)
            if not SLV._isDragging then
                button:GetScript("OnClick")(button, mouseButton)
            end
        end)

        return
    end

    -- Step rows (rowType == "step" or nil for backward compat)
    button:SetHeight(defaults.STEP_ROW_HEIGHT)

    -- Create child elements once
    if not button._gripInit then
        if not button.SetBackdrop then
            Mixin(button, BackdropTemplateMixin)
        end

        button:SetBackdrop(UI.Backdrops.panelNoBorder)
        button:EnableMouse(true)
        button:RegisterForClicks("LeftButtonUp", "RightButtonUp")

        -- Drag handle (grip icon: three horizontal lines)
        button.dragHandle = CreateFrame("Frame", nil, button)
        button.dragHandle:SetSize(D().STEP_DRAG_HANDLE_WIDTH, D().STEP_ROW_HEIGHT)
        button.dragHandle:SetPoint("LEFT", button, "LEFT", 2, 0)
        for lineIdx = 1, 3 do
            local line = button.dragHandle:CreateTexture(nil, "ARTWORK")
            line:SetSize(8, 1)
            line:SetColorTexture(C.textMuted:GetRGBA())
            line:SetPoint("CENTER", button.dragHandle, "CENTER", 0, (lineIdx - 2) * 3)
        end

        -- Step number (anchored to drag handle)
        button.stepNum = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(button.stepNum, 10)
        button.stepNum:SetPoint("LEFT", button.dragHandle, "RIGHT", 2, 0)
        button.stepNum:SetWidth(30)
        button.stepNum:SetJustifyH("LEFT")

        -- Step text
        button.stepText = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(button.stepText, 11)
        button.stepText:SetPoint("LEFT", button.stepNum, "RIGHT", 4, 0)
        button.stepText:SetPoint("RIGHT", button, "RIGHT", -55, 0)
        button.stepText:SetJustifyH("LEFT")
        button.stepText:SetWordWrap(false)

        -- Mod badge (between step text and char count)
        button.modBadge = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(button.modBadge, 9)
        button.modBadge:SetPoint("RIGHT", button, "RIGHT", -55, 0)
        button.modBadge:SetJustifyH("RIGHT")
        button.modBadge:SetTextColor(C.keybindGold:GetRGBA())
        button.modBadge:Hide()

        -- Char count
        button.charCount = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(button.charCount, 10)
        button.charCount:SetPoint("RIGHT", button, "RIGHT", -4, 0)
        button.charCount:SetJustifyH("RIGHT")

        -- Drag handle: mouse and drag registration (one-time setup)
        button.dragHandle:EnableMouse(true)
        button.dragHandle:RegisterForDrag("LeftButton")

        button._gripInit = true
    end

    -- Hide node badge elements if this frame was previously used for a node row
    if button._nodeIcon then
        button._nodeIcon:Hide()
    end
    if button._nodeIconLabel then
        button._nodeIconLabel:Hide()
    end
    if button._nodeNameLabel then
        button._nodeNameLabel:Hide()
    end
    if button._nodeSummaryLabel then
        button._nodeSummaryLabel:Hide()
    end
    if button._nodeChevron then
        button._nodeChevron:Hide()
    end

    -- Show step-specific elements
    if button.dragHandle then
        button.dragHandle:Show()
    end
    if button.stepNum then
        button.stepNum:Show()
    end
    if button.stepText then
        button.stepText:Show()
    end
    if button.charCount then
        button.charCount:Show()
    end

    -- Drag handle: data-dependent scripts (re-bound each InitRow call)
    button.dragHandle:SetScript("OnEnter", function()
        button:GetScript("OnEnter")(button)
    end)
    button.dragHandle:SetScript("OnLeave", function()
        button:GetScript("OnLeave")(button)
    end)
    button.dragHandle:SetScript("OnDragStart", function()
        SLV:_beginOutlineDrag(button, data)
    end)
    button.dragHandle:SetScript("OnDragStop", function()
        SLV:_endOutlineDrag(button)
    end)

    -- Click-through: non-drag clicks on handle pass to row for selection
    button.dragHandle:SetScript("OnMouseUp", function(_, mouseButton)
        if not SLV._isDragging then
            button:GetScript("OnClick")(button, mouseButton)
        end
    end)

    -- Populate
    button.stepNum:SetText(string.format(L["GEMS_UI_STEP_NUM"], data.index or 0))
    button.stepNum:SetTextColor(C.textSecondary:GetRGBA())

    -- Spell validation: color step number by validity
    local SV = GRIPEMS.SpellValidator
    local SC = GRIPEMS.SpellCache
    if SC and SC.ready and SV and data.text and data.text ~= "" then
        local stepResult = SV:ValidateStep(data.text)
        local hasUnknown, hasKnown = false, false
        for _, spell in ipairs(stepResult.spells) do
            if spell.status == D().SPELL_STATUS_UNKNOWN then
                hasUnknown = true
            elseif spell.status == D().SPELL_STATUS_KNOWN then
                hasKnown = true
            end
        end
        if hasUnknown then
            button.stepNum:SetTextColor(C.textError:GetRGBA())
        elseif hasKnown then
            button.stepNum:SetTextColor(C.textWarning:GetRGBA())
        end
    end

    local displayText = data.text or ""
    local firstLine = displayText:match("^([^\n]*)") or displayText
    local SH = GRIPEMS.SyntaxHighlight
    if SH then
        firstLine = SH:ColorizeString(firstLine)
    end
    button.stepText:SetText(firstLine)
    button.stepText:SetTextColor(C.textPrimary:GetRGBA())

    -- Mod pattern badge
    if button.modBadge then
        local rawText = data.text or ""
        local mods = {}
        for mod in rawText:gmatch("%[mod:(%w+)") do
            mods[#mods + 1] = strupper(mod)
        end
        if #mods > 0 then
            local badgeText
            if #mods == 1 then
                badgeText = mods[1]
            elseif #mods == 2 then
                badgeText = mods[1] .. "+" .. mods[2]
            else
                badgeText = mods[1] .. "+" .. mods[2] .. "..."
            end
            button.modBadge:SetText(badgeText)
            button.modBadge:Show()
            -- Shrink step text right anchor to make room for badge
            button.stepText:SetPoint("RIGHT", button.modBadge, "LEFT", -4, 0)
        else
            button.modBadge:Hide()
            button.stepText:SetPoint("RIGHT", button, "RIGHT", -55, 0)
        end
    end

    local count = data.charCount or 0
    local kpCost = (SLV.keyPressLen or 0) > 0 and (SLV.keyPressLen + 1) or 0
    local krCost = (SLV.keyReleaseLen or 0) > 0 and (SLV.keyReleaseLen + 1) or 0
    local displayCount = count
    if kpCost > 0 or krCost > 0 then
        displayCount = count + kpCost + krCost
    end
    button.charCount:SetText(string.format("%d/%d", displayCount, defaults.CHAR_COUNT_DANGER))

    -- Color the char count based on thresholds (using effective cost)
    if displayCount >= defaults.CHAR_COUNT_DANGER then
        button.charCount:SetTextColor(C.textError:GetRGBA())
    elseif displayCount > defaults.CHAR_COUNT_WARNING then
        button.charCount:SetTextColor(C.textWarning:GetRGBA())
    else
        button.charCount:SetTextColor(C.textSuccess:GetRGBA())
    end

    -- Selection state
    local isSelected = (data.index == SLV.selectedIndex)
    if isSelected then
        button:SetBackdropColor(C.bgRowSelected:GetRGBA())
    elseif data.index and data.index % 2 == 0 then
        button:SetBackdropColor(C.bgPanel:GetRGBA())
    else
        button:SetBackdropColor(C.bgMain:GetRGBA())
    end

    -- Store data ref
    button._stepData = data

    -- Tooltip: native spell tooltip when possible, otherwise text fallback
    button:SetScript("OnEnter", function(self)
        if not isSelected then
            self:SetBackdropColor(C.bgRowHover:GetRGBA())
        end
        if not data.text or data.text == "" then
            return
        end

        -- Try to find a primary spell for native tooltip
        local nativeShown = false
        if SC and SC.ready and SV then
            local extracted = SV:ExtractAllSpells(data.text)
            if extracted and #extracted > 0 then
                local primaryName = extracted[1].name
                if primaryName and primaryName ~= "" then
                    -- Check if it is an item (starts with item: or recognized by cache)
                    local itemID = primaryName:match("^item:(%d+)")
                    if itemID then
                        if C_TooltipInfo and C_TooltipInfo.GetItemByID then
                            local info = C_TooltipInfo.GetItemByID(tonumber(itemID))
                            if info then
                                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                                GameTooltip:ProcessInfo(info)
                                nativeShown = true
                            end
                        else
                            -- Fallback for pre-11.0 (safety)
                            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                            GameTooltip:SetItemByID(tonumber(itemID))
                            nativeShown = true
                        end
                    else
                        local spellID = SC:GetSpellID(primaryName)
                        if spellID then
                            if C_TooltipInfo and C_TooltipInfo.GetSpellByID then
                                local info = C_TooltipInfo.GetSpellByID(spellID)
                                if info then
                                    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                                    GameTooltip:ProcessInfo(info)
                                    nativeShown = true
                                end
                            else
                                -- Fallback for pre-11.0 (safety)
                                GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
                                GameTooltip:SetSpellByID(spellID)
                                nativeShown = true
                            end
                        end
                    end
                end
            end

            -- Add keybind hint if native tooltip shown
            if nativeShown then
                local SE = GRIPEMS.SequenceEditor
                local KM = GRIPEMS.KeybindManager
                if SE and SE.currentSequence and KM then
                    local keyText = KM:GetKeybind(SE.currentSequence)
                    if keyText then
                        GameTooltip:AddLine(" ")
                        GameTooltip:AddLine(string.format(L["GEMS_UI_KEYBIND_TOOLTIP"], keyText), 1, 0.82, 0, true)
                    end
                end
            end

            -- Add validation warning lines
            local stepResult = SV:ValidateStep(data.text)
            local issues = {}
            for _, spell in ipairs(stepResult.spells) do
                if spell.status == D().SPELL_STATUS_UNKNOWN then
                    issues[#issues + 1] = string.format(L["GEMS_SPELL_TOOLTIP_UNKNOWN"], spell.name)
                elseif spell.status == D().SPELL_STATUS_KNOWN then
                    issues[#issues + 1] = string.format(L["GEMS_SPELL_TOOLTIP_KNOWN"], spell.name)
                end
            end
            if nativeShown and #issues > 0 then
                GameTooltip:AddLine(" ")
                for _, issue in ipairs(issues) do
                    GameTooltip:AddLine(issue, 1, 0.27, 0.27, true)
                end
                GameTooltip:Show()
            elseif not nativeShown then
                local tooltipBody = data.text
                if #issues > 0 then
                    tooltipBody = data.text .. "\n\n" .. table.concat(issues, "\n")
                end
                UI:ShowTooltip(self, string.format(L["GEMS_UI_STEP_NUM"], data.index or 0), tooltipBody)
            else
                GameTooltip:Show()
            end
        else
            UI:ShowTooltip(self, string.format(L["GEMS_UI_STEP_NUM"], data.index or 0), data.text)
        end
    end)
    button:SetScript("OnLeave", function(self)
        if not isSelected then
            if data.index and data.index % 2 == 0 then
                self:SetBackdropColor(C.bgPanel:GetRGBA())
            else
                self:SetBackdropColor(C.bgMain:GetRGBA())
            end
        end
        UI:HideTooltip()
    end)

    -- Click: select step or show context menu
    button:SetScript("OnClick", function(self, mouseButton)
        if mouseButton == "RightButton" then
            SLV:ShowContextMenu(self, data)
        else
            SLV.selectedIndex = data.index
            SLV._lastLineCount = 0
            -- In outline mode, set editing context for action nodes
            if SLV.hasActions and data.nodeIndex then
                SLV._editingContext = {
                    source = "outline",
                    nodeIndex = data.nodeIndex,
                    label = string.format(L["GEMS_UI_STEP_HEADER"], data.index),
                }
            else
                SLV._editingContext = nil
            end
            if SLV.hasActions and SLV._detailOpen then
                SLV._detailOpen = false
                SLV._detailNavStack = nil
                SLV._detailNode = nil
                SLV._detailNodeIndex = nil
                SLV._detailSelectedChild = nil
                if SLV._detailContainer then
                    SLV._detailContainer:Hide()
                end
            end
            SLV:RefreshAll()
        end
    end)
end

---------------------------------------------------------------------------
-- Context menu for step rows
---------------------------------------------------------------------------

--- Show a right-click context menu for a step row.
--- @param button Button The row frame (menu anchor)
--- @param data table Row data { index, text, charCount }
function SLV:ShowContextMenu(button, data)
    if not data or not data.index then
        return
    end

    MenuUtil.CreateContextMenu(button, function(ownerRegion, rootDescription)
        rootDescription:CreateButton(L["GEMS_UI_CTX_DUP_STEP"], function()
            if SLV.hasActions and SLV.workingActions and data.nodeIndex then
                local DD = GRIPEMS.Defaults
                local src = SLV.workingActions[data.nodeIndex]
                if src then
                    local copy = DD.DeepCopyActions({ src })[1]
                    table.insert(SLV.workingActions, data.nodeIndex + 1, copy)
                    SLV:_markDirty()
                    SLV:RefreshAll()
                end
            else
                SLV.selectedIndex = data.index
                SLV:DuplicateStep()
            end
        end)

        local moveUpBtn = rootDescription:CreateButton(L["GEMS_UI_CTX_MOVE_UP"], function()
            if SLV.hasActions and SLV.workingActions and data.nodeIndex then
                local ni = data.nodeIndex
                if ni > 1 then
                    SLV.workingActions[ni], SLV.workingActions[ni - 1] =
                        SLV.workingActions[ni - 1], SLV.workingActions[ni]
                    SLV:_markDirty()
                    SLV:RefreshAll()
                end
            else
                SLV.selectedIndex = data.index
                SLV:MoveStepUp()
            end
        end)
        moveUpBtn:SetEnabled(data.nodeIndex and data.nodeIndex > 1 or data.index > 1)

        local moveDownBtn = rootDescription:CreateButton(L["GEMS_UI_CTX_MOVE_DOWN"], function()
            if SLV.hasActions and SLV.workingActions and data.nodeIndex then
                local ni = data.nodeIndex
                if ni < #SLV.workingActions then
                    SLV.workingActions[ni], SLV.workingActions[ni + 1] =
                        SLV.workingActions[ni + 1], SLV.workingActions[ni]
                    SLV:_markDirty()
                    SLV:RefreshAll()
                end
            else
                SLV.selectedIndex = data.index
                SLV:MoveStepDown()
            end
        end)
        moveDownBtn:SetEnabled(
            (SLV.hasActions and SLV.workingActions and data.nodeIndex and data.nodeIndex < #SLV.workingActions)
                or (not SLV.hasActions and data.index < #SLV.workingSteps)
        )

        rootDescription:CreateDivider()

        rootDescription:CreateButton("|cFFFF4444" .. L["GEMS_UI_CTX_DELETE_STEP"] .. "|r", function()
            if SLV.hasActions and SLV.workingActions and data.nodeIndex then
                local ni = data.nodeIndex
                table.remove(SLV.workingActions, ni)
                if SLV._detailOpen and SLV._detailNodeIndex then
                    if SLV._detailNodeIndex == ni then
                        SLV:CloseDetailPane()
                    elseif SLV._detailNodeIndex > ni then
                        SLV._detailNodeIndex = SLV._detailNodeIndex - 1
                    end
                end
                SLV:_markDirty()
                SLV:RefreshAll()
            else
                SLV.selectedIndex = data.index
                SLV:DeleteStep()
            end
        end)
    end)
end

--- Right-click context menu for node badge rows in the outline view.
--- Provides duplicate, move up/down, and delete operations on action nodes.
--- @param button Button The row frame that was right-clicked
--- @param data table Row data with nodeIndex field
function SLV:ShowNodeContextMenu(button, data)
    if not data or not data.nodeIndex then
        return
    end
    local idx = data.nodeIndex
    MenuUtil.CreateContextMenu(button, function(ownerRegion, rootDescription)
        rootDescription:CreateButton(L["GEMS_UI_CTX_DUP_STEP"], function()
            if SLV.workingActions and SLV.workingActions[idx] then
                local DD = GRIPEMS.Defaults
                local copy = DD.DeepCopyActions({ SLV.workingActions[idx] })
                table.insert(SLV.workingActions, idx + 1, copy[1])
                SLV:_markDirty()
                SLV:RefreshAll()
            end
        end)

        local moveUpBtn = rootDescription:CreateButton(L["GEMS_UI_CTX_MOVE_UP"], function()
            if SLV.workingActions and idx > 1 then
                SLV.workingActions[idx], SLV.workingActions[idx - 1] =
                    SLV.workingActions[idx - 1], SLV.workingActions[idx]
                SLV:_markDirty()
                SLV:RefreshAll()
            end
        end)
        moveUpBtn:SetEnabled(idx > 1)

        local moveDownBtn = rootDescription:CreateButton(L["GEMS_UI_CTX_MOVE_DOWN"], function()
            if SLV.workingActions and idx < #SLV.workingActions then
                SLV.workingActions[idx], SLV.workingActions[idx + 1] =
                    SLV.workingActions[idx + 1], SLV.workingActions[idx]
                SLV:_markDirty()
                SLV:RefreshAll()
            end
        end)
        moveDownBtn:SetEnabled(SLV.workingActions and idx < #SLV.workingActions)

        rootDescription:CreateDivider()

        rootDescription:CreateButton("|cFFFF4444" .. L["GEMS_UI_CTX_DELETE_STEP"] .. "|r", function()
            if SLV.workingActions and SLV.workingActions[idx] then
                table.remove(SLV.workingActions, idx)
                if SLV._detailOpen and SLV._detailNodeIndex == idx then
                    SLV:CloseDetailPane()
                elseif SLV._detailOpen and SLV._detailNodeIndex > idx then
                    SLV._detailNodeIndex = SLV._detailNodeIndex - 1
                end
                SLV:_markDirty()
                SLV:RefreshAll()
            end
        end)
    end)
end

---------------------------------------------------------------------------
-- Autocomplete menu
---------------------------------------------------------------------------

--- Show an autocomplete dropdown anchored below the EditBox.
--- Uses a create-once reusable frame with pooled button rows.
--- @param editBox EditBox The EditBox to anchor the dropdown to
--- @param matches table Array of { name, spellID, iconID } entries
--- @param wordStart number Start position of the word being completed
--- @param cursorPos number Cursor position when Tab was pressed
function SLV:ShowAutocompleteMenu(editBox, matches, wordStart, cursorPos)
    if not editBox or not matches or #matches == 0 then
        return
    end

    local C = UI.Colors
    local ROW_HEIGHT = 22

    -- Lazy-init: create the dropdown frame once
    local dropdown = SLV.autocompleteDropdown
    if not dropdown then
        dropdown = CreateFrame("Frame", "GRIPEMS_AutocompleteDropdown", UIParent, "BackdropTemplate")
        dropdown:SetFrameStrata("DIALOG")
        UI:ApplyBackdrop(dropdown, UI.Backdrops.panel, C.bgPanel, C.border)
        dropdown:SetClampedToScreen(true)
        dropdown:EnableKeyboard(true)
        dropdown:SetScript("OnKeyDown", function(self, key)
            if key == "ESCAPE" then
                self:Hide()
                self:SetPropagateKeyboardInput(false)
            else
                self:SetPropagateKeyboardInput(true)
            end
        end)
        dropdown._rows = {}
        SLV.autocompleteDropdown = dropdown
    end

    -- Hide all existing rows first
    for _, row in ipairs(dropdown._rows) do
        row:Hide()
    end

    -- Size the dropdown
    local ddWidth = math.max(editBox:GetWidth(), 200)
    dropdown:SetSize(ddWidth, #matches * ROW_HEIGHT)
    dropdown:ClearAllPoints()
    dropdown:SetPoint("TOPLEFT", editBox, "BOTTOMLEFT", 0, -2)

    -- Create or reuse button rows
    for i, match in ipairs(matches) do
        local row = dropdown._rows[i]
        if not row then
            row = CreateFrame("Button", nil, dropdown, "BackdropTemplate")
            row:SetBackdrop(UI.Backdrops.panelNoBorder)
            row:SetBackdropColor(0, 0, 0, 0)

            -- Icon texture
            row.icon = row:CreateTexture(nil, "ARTWORK")
            row.icon:SetSize(16, 16)
            row.icon:SetPoint("LEFT", row, "LEFT", 4, 0)

            -- Label
            row.label = row:CreateFontString(nil, "OVERLAY")
            UI:SetFont(row.label, 12)
            row.label:SetTextColor(C.textPrimary:GetRGBA())

            -- Hover highlight
            row:SetScript("OnEnter", function(self)
                self:SetBackdropColor(C.bgRowHover:GetRGBA())
            end)
            row:SetScript("OnLeave", function(self)
                self:SetBackdropColor(0, 0, 0, 0)
            end)

            dropdown._rows[i] = row
        end

        row:SetSize(ddWidth, ROW_HEIGHT)
        row:ClearAllPoints()
        row:SetPoint("TOPLEFT", dropdown, "TOPLEFT", 0, -((i - 1) * ROW_HEIGHT))

        -- Icon: show if match has iconID, hide otherwise
        if match.iconID then
            row.icon:SetTexture(match.iconID)
            row.icon:Show()
            row.label:SetPoint("LEFT", row.icon, "RIGHT", 4, 0)
        else
            row.icon:Hide()
            row.label:ClearAllPoints()
            row.label:SetPoint("LEFT", row, "LEFT", 4, 0)
        end
        row.label:SetText(match.name)

        -- OnClick: do text replacement, hide dropdown
        row:SetScript("OnClick", function()
            local text = editBox:GetText() or ""
            local SH = GRIPEMS.SyntaxHighlight
            if SH then
                text = SH:Strip(text)
            end
            local before = text:sub(1, wordStart - 1)
            local after = text:sub(cursorPos + 1)
            local insertion = match.name
            -- Macro commands get trailing space for convenience
            local firstCh = insertion:sub(1, 1)
            if (firstCh == "/" or firstCh == "#") and after == "" then
                insertion = insertion .. " "
            end
            local newText = before .. insertion .. after
            editBox._shBusy = true
            editBox:SetText(newText)
            editBox:SetCursorPosition(wordStart - 1 + #insertion)
            editBox._shBusy = false

            -- Update working copy and dirty state
            local idx = SLV.selectedIndex
            if idx then
                SLV.workingSteps[idx] = newText
                SLV:UpdateEditCharCount(#newText)
                local SE = GRIPEMS.SequenceEditor
                if SE then
                    SE.isDirty = true
                    SE:UpdateSaveButtons()
                end
                SLV:RefreshCurrentRow()
            end

            dropdown:Hide()
        end)

        row:Show()
    end

    dropdown:Show()
end

---------------------------------------------------------------------------
-- Variable autocomplete menu
---------------------------------------------------------------------------

--- Show a variable autocomplete dropdown (no icons, inserts ~name~).
--- Reuses the same dropdown frame as spell autocomplete.
--- @param editBox EditBox The EditBox to anchor the dropdown to
--- @param matches table Array of { name = string } entries
--- @param tildeStart number Position of the leading ~ (1-based)
--- @param cursorPos number Cursor position when Tab was pressed
function SLV:ShowVarAutocompleteMenu(editBox, matches, tildeStart, cursorPos)
    if not editBox or not matches or #matches == 0 then
        return
    end

    local C = UI.Colors
    local ROW_HEIGHT = 22

    -- Lazy-init: reuse the same dropdown frame
    local dropdown = SLV.autocompleteDropdown
    if not dropdown then
        dropdown = CreateFrame("Frame", "GRIPEMS_AutocompleteDropdown", UIParent, "BackdropTemplate")
        dropdown:SetFrameStrata("DIALOG")
        UI:ApplyBackdrop(dropdown, UI.Backdrops.panel, C.bgPanel, C.border)
        dropdown:SetClampedToScreen(true)
        dropdown:EnableKeyboard(true)
        dropdown:SetScript("OnKeyDown", function(self, key)
            if key == "ESCAPE" then
                self:Hide()
                self:SetPropagateKeyboardInput(false)
            else
                self:SetPropagateKeyboardInput(true)
            end
        end)
        dropdown._rows = {}
        SLV.autocompleteDropdown = dropdown
    end

    -- Hide all existing rows
    for _, row in ipairs(dropdown._rows) do
        row:Hide()
    end

    -- Size the dropdown
    local ddWidth = math.max(editBox:GetWidth(), 200)
    dropdown:SetSize(ddWidth, #matches * ROW_HEIGHT)
    dropdown:ClearAllPoints()
    dropdown:SetPoint("TOPLEFT", editBox, "BOTTOMLEFT", 0, -2)

    for i, match in ipairs(matches) do
        local row = dropdown._rows[i]
        if not row then
            row = CreateFrame("Button", nil, dropdown, "BackdropTemplate")
            row:SetBackdrop(UI.Backdrops.panelNoBorder)
            row:SetBackdropColor(0, 0, 0, 0)

            row.icon = row:CreateTexture(nil, "ARTWORK")
            row.icon:SetSize(16, 16)
            row.icon:SetPoint("LEFT", row, "LEFT", 4, 0)

            row.label = row:CreateFontString(nil, "OVERLAY")
            UI:SetFont(row.label, 12)
            row.label:SetTextColor(C.textPrimary:GetRGBA())

            row:SetScript("OnEnter", function(self)
                self:SetBackdropColor(C.bgRowHover:GetRGBA())
            end)
            row:SetScript("OnLeave", function(self)
                self:SetBackdropColor(0, 0, 0, 0)
            end)

            dropdown._rows[i] = row
        end

        row:SetSize(ddWidth, ROW_HEIGHT)
        row:ClearAllPoints()
        row:SetPoint("TOPLEFT", dropdown, "TOPLEFT", 0, -((i - 1) * ROW_HEIGHT))

        -- No icon for variable autocomplete
        row.icon:Hide()
        row.label:ClearAllPoints()
        row.label:SetPoint("LEFT", row, "LEFT", 4, 0)
        row.label:SetText("~" .. match.name .. "~")

        -- OnClick: replace from tildeStart to cursorPos with ~name~
        row:SetScript("OnClick", function()
            local text = editBox:GetText() or ""
            local SH = GRIPEMS.SyntaxHighlight
            if SH then
                text = SH:Strip(text)
            end
            local before = text:sub(1, tildeStart - 1)
            local after = text:sub(cursorPos + 1)
            local insertion = "~" .. match.name .. "~"
            local newText = before .. insertion .. after
            editBox._shBusy = true
            editBox:SetText(newText)
            editBox:SetCursorPosition(tildeStart - 1 + #insertion)
            editBox._shBusy = false

            -- Update working copy and dirty state
            local idx = SLV.selectedIndex
            if idx then
                SLV.workingSteps[idx] = newText
                SLV:UpdateEditCharCount(#newText)
                local SE = GRIPEMS.SequenceEditor
                if SE then
                    SE.isDirty = true
                    SE:UpdateSaveButtons()
                end
                SLV:RefreshCurrentRow()
            end

            dropdown:Hide()
        end)

        row:Show()
    end

    dropdown:Show()
end

---------------------------------------------------------------------------
-- Sequence name autocomplete (fallback when spell/command has 0 matches)
---------------------------------------------------------------------------

--- Search Engine.sequences for names starting with prefix (case-insensitive).
--- @param prefix string The prefix to match against sequence names
--- @return table Array of { name = string } sorted alphabetically
function SLV:SearchSequenceNames(prefix)
    local Engine = GRIPEMS.Engine
    if not Engine or not Engine.sequences then
        return {}
    end
    local results = {}
    local lowerPrefix = prefix:lower()
    for seqName in pairs(Engine.sequences) do
        if seqName:lower():sub(1, #lowerPrefix) == lowerPrefix then
            results[#results + 1] = { name = seqName }
        end
    end
    table.sort(results, function(a, b)
        return a.name < b.name
    end)
    if #results > D().AUTOCOMPLETE_MAX_RESULTS then
        local trimmed = {}
        for i = 1, D().AUTOCOMPLETE_MAX_RESULTS do
            trimmed[i] = results[i]
        end
        results = trimmed
    end
    return results
end

--- Show a sequence name autocomplete dropdown with section header.
--- Inserts "/click GRIPEMS_<name>" replacing the typed word.
--- @param editBox EditBox The EditBox to anchor the dropdown to
--- @param matches table Array of { name = string } entries
--- @param wordStart number Start position of the word being replaced (1-based)
--- @param cursorPos number Cursor position when Tab was pressed
function SLV:ShowSeqAutocompleteMenu(editBox, matches, wordStart, cursorPos)
    if not editBox or not matches or #matches == 0 then
        return
    end

    local C = UI.Colors
    local ROW_HEIGHT = 22

    -- Lazy-init: reuse the same dropdown frame
    local dropdown = SLV.autocompleteDropdown
    if not dropdown then
        dropdown = CreateFrame("Frame", "GRIPEMS_AutocompleteDropdown", UIParent, "BackdropTemplate")
        dropdown:SetFrameStrata("DIALOG")
        UI:ApplyBackdrop(dropdown, UI.Backdrops.panel, C.bgPanel, C.border)
        dropdown:SetClampedToScreen(true)
        dropdown:EnableKeyboard(true)
        dropdown:SetScript("OnKeyDown", function(self, key)
            if key == "ESCAPE" then
                self:Hide()
                self:SetPropagateKeyboardInput(false)
            else
                self:SetPropagateKeyboardInput(true)
            end
        end)
        dropdown._rows = {}
        SLV.autocompleteDropdown = dropdown
    end

    -- Hide all existing rows
    for _, row in ipairs(dropdown._rows) do
        row:Hide()
    end

    -- Total rows = 1 header + N matches
    local totalRows = 1 + #matches
    local ddWidth = math.max(editBox:GetWidth(), 200)
    dropdown:SetSize(ddWidth, totalRows * ROW_HEIGHT)
    dropdown:ClearAllPoints()
    dropdown:SetPoint("TOPLEFT", editBox, "BOTTOMLEFT", 0, -2)

    -- Row 1: non-clickable section header
    local headerRow = dropdown._rows[1]
    if not headerRow then
        headerRow = CreateFrame("Button", nil, dropdown, "BackdropTemplate")
        headerRow:SetBackdrop(UI.Backdrops.panelNoBorder)
        headerRow:SetBackdropColor(0, 0, 0, 0)

        headerRow.icon = headerRow:CreateTexture(nil, "ARTWORK")
        headerRow.icon:SetSize(16, 16)
        headerRow.icon:SetPoint("LEFT", headerRow, "LEFT", 4, 0)

        headerRow.label = headerRow:CreateFontString(nil, "OVERLAY")
        UI:SetFont(headerRow.label, 12)
        headerRow.label:SetTextColor(C.textPrimary:GetRGBA())

        headerRow:SetScript("OnEnter", function(self)
            self:SetBackdropColor(0, 0, 0, 0)
        end)
        headerRow:SetScript("OnLeave", function(self)
            self:SetBackdropColor(0, 0, 0, 0)
        end)

        dropdown._rows[1] = headerRow
    end
    headerRow:SetSize(ddWidth, ROW_HEIGHT)
    headerRow:ClearAllPoints()
    headerRow:SetPoint("TOPLEFT", dropdown, "TOPLEFT", 0, 0)
    headerRow.icon:Hide()
    headerRow.label:ClearAllPoints()
    headerRow.label:SetPoint("LEFT", headerRow, "LEFT", 4, 0)
    headerRow.label:SetText(L["GEMS_AUTOCOMPLETE_SEQUENCES"])
    headerRow.label:SetTextColor(C.textSecondary:GetRGBA())
    headerRow:SetScript("OnClick", nil)
    headerRow:EnableMouse(false)
    headerRow:Show()

    -- Rows 2..N+1: clickable sequence entries
    for i, match in ipairs(matches) do
        local rowIdx = i + 1
        local row = dropdown._rows[rowIdx]
        if not row then
            row = CreateFrame("Button", nil, dropdown, "BackdropTemplate")
            row:SetBackdrop(UI.Backdrops.panelNoBorder)
            row:SetBackdropColor(0, 0, 0, 0)

            row.icon = row:CreateTexture(nil, "ARTWORK")
            row.icon:SetSize(16, 16)
            row.icon:SetPoint("LEFT", row, "LEFT", 4, 0)

            row.label = row:CreateFontString(nil, "OVERLAY")
            UI:SetFont(row.label, 12)
            row.label:SetTextColor(C.textPrimary:GetRGBA())

            row:SetScript("OnEnter", function(self)
                self:SetBackdropColor(C.bgRowHover:GetRGBA())
            end)
            row:SetScript("OnLeave", function(self)
                self:SetBackdropColor(0, 0, 0, 0)
            end)

            dropdown._rows[rowIdx] = row
        end

        row:EnableMouse(true)
        row:SetSize(ddWidth, ROW_HEIGHT)
        row:ClearAllPoints()
        row:SetPoint("TOPLEFT", dropdown, "TOPLEFT", 0, -((rowIdx - 1) * ROW_HEIGHT))

        -- Macro scroll icon
        row.icon:SetTexture(D().AUTOCOMPLETE_SEQ_ICON)
        row.icon:Show()
        row.label:ClearAllPoints()
        row.label:SetPoint("LEFT", row.icon, "RIGHT", 4, 0)
        row.label:SetTextColor(C.textPrimary:GetRGBA())
        row.label:SetText(match.name)

        -- OnClick: replace word with /click GRIPEMS_<name>
        row:SetScript("OnClick", function()
            local text = editBox:GetText() or ""
            local SH = GRIPEMS.SyntaxHighlight
            if SH then
                text = SH:Strip(text)
            end
            local before = text:sub(1, wordStart - 1)
            local after = text:sub(cursorPos + 1)
            local insertion = format(L["GEMS_AUTOCOMPLETE_CLICK_INSERT"], match.name)
            local newText = before .. insertion .. after
            editBox._shBusy = true
            editBox:SetText(newText)
            editBox:SetCursorPosition(wordStart - 1 + #insertion)
            editBox._shBusy = false

            -- Update working copy and dirty state
            local idx = SLV.selectedIndex
            if idx then
                SLV.workingSteps[idx] = newText
                SLV:UpdateEditCharCount(#newText)
                local SE = GRIPEMS.SequenceEditor
                if SE then
                    SE.isDirty = true
                    SE:UpdateSaveButtons()
                end
                SLV:RefreshCurrentRow()
            end

            dropdown:Hide()
        end)

        row:Show()
    end

    dropdown:Show()
end

---------------------------------------------------------------------------
-- Live-filter autocomplete (called from OnTextChanged)
---------------------------------------------------------------------------

--- Re-filter the autocomplete dropdown while the user types.
--- Called from OnTextChanged when the dropdown is already visible.
--- Hides the dropdown if the word shrinks below min chars or no matches.
--- @param editBox EditBox The EditBox being edited
function SLV:RefreshAutocomplete(editBox)
    if not SLV.autocompleteDropdown or not SLV.autocompleteDropdown:IsShown() then
        return
    end

    local SC = GRIPEMS.SpellCache
    if not SC or not SC.ready then
        SLV.autocompleteDropdown:Hide()
        return
    end

    local word, wordStart, cursorPos = extractWordUnderCursor(editBox)
    local firstChar = word:sub(1, 1)
    local isCommand = (firstChar == "/" or firstChar == "#")
    local minChars = isCommand and D().AUTOCOMPLETE_MIN_CHARS or D().AUTOCOMPLETE_MIN_SPELL_CHARS

    if #word < minChars then
        SLV.autocompleteDropdown:Hide()
        return
    end

    local matches
    if isCommand then
        matches = SC:MacroCommandSearch(word, D().AUTOCOMPLETE_MAX_RESULTS)
    else
        matches = SC:PrefixSearch(word, D().AUTOCOMPLETE_MAX_RESULTS)
    end

    if #matches == 0 then
        SLV.autocompleteDropdown:Hide()
        return
    end

    -- Re-populate the dropdown with updated matches
    SLV:ShowAutocompleteMenu(editBox, matches, wordStart, cursorPos)
end

---------------------------------------------------------------------------
-- Data flow methods
---------------------------------------------------------------------------

--- Load an array of step strings into the step list.
--- Deep-copies into workingSteps and originalSteps.
--- Optional second parameter enables tree mode when actions are present.
--- @param steps table|nil Array of macro text strings
--- @param actions table|nil Array of action tree nodes (v1.2.0 S14-B)
function SLV:LoadSteps(steps, actions)
    if not SLV.scrollView then
        return
    end

    local US = GRIPEMS.UndoStack
    if US then
        US:Clear()
    end

    SLV.workingSteps = {}
    SLV.originalSteps = {}
    SLV.selectedIndex = nil
    SLV._lastLineCount = 0
    SLV._undoTextSnapshot = nil
    SLV._undoTextSnapshotIdx = nil
    SLV._preEditText = nil

    -- Reset detail pane state before loading
    SLV._detailOpen = false
    SLV._detailNavStack = nil
    SLV._detailNode = nil
    SLV._detailNodeIndex = nil
    SLV._detailSelectedChild = nil
    SLV._detailSelectedBranch = nil
    SLV._editingContext = nil
    if SLV._detailContainer then
        SLV._detailContainer:Hide()
    end

    if steps then
        for i, step in ipairs(steps) do
            SLV.workingSteps[i] = step
            SLV.originalSteps[i] = step
        end
    end

    -- Actions render in outline + detail pane mode.
    SLV.treeMode = false
    if actions and #actions > 0 then
        SLV.hasActions = true
        SLV.workingActions = D().DeepCopyActions(actions)
        SLV._originalActionsSerialized = SLV:_serializeActions(actions)
    else
        SLV.hasActions = false
        SLV.workingActions = nil
        SLV._originalActionsSerialized = nil
    end

    SLV:RefreshAll()
end

--- Return the current edited steps array (always flat).
--- @return table workingSteps
function SLV:GetWorkingSteps()
    return SLV.workingSteps
end

--- Return the current working actions array (nil if flat mode).
--- @return table|nil workingActions
function SLV:GetWorkingActions()
    return SLV.workingActions
end

--- Compare working steps/actions against original to detect changes.
--- @return boolean hasChanges
function SLV:HasChanges()
    -- Migration detection: if original was flat but working copy is now actions
    if SLV.hasActions and not SLV._originalActionsSerialized then
        return true
    end
    if #SLV.workingSteps ~= #SLV.originalSteps then
        return true
    end
    for i = 1, #SLV.workingSteps do
        if SLV.workingSteps[i] ~= SLV.originalSteps[i] then
            return true
        end
    end
    if SLV.hasActions and SLV.workingActions then
        local cur = SLV:_serializeActions(SLV.workingActions)
        if cur ~= SLV._originalActionsSerialized then
            return true
        end
    end
    return false
end

--- Serialize an actions array to a string for comparison.
--- Simple recursive key-sorted serialization.
--- @param actions table Action node array
--- @return string Serialized string
function SLV:_serializeActions(actions)
    if not actions then
        return ""
    end
    local parts = {}
    for _, node in ipairs(actions) do
        parts[#parts + 1] = SLV:_serializeNode(node)
    end
    return table.concat(parts, "|")
end

--- Serialize a single action node to a string.
--- @param node table Action node
--- @return string Serialized string
function SLV:_serializeNode(node)
    if not node or not node.type then
        return ""
    end
    local parts = { node.type }
    if node.name and node.name ~= "" then
        parts[#parts + 1] = "n=" .. node.name
    end
    if node.macro then
        parts[#parts + 1] = node.macro
    end
    if node["repeat"] then
        parts[#parts + 1] = "r=" .. tostring(node["repeat"])
    end
    if node.stepFunction then
        parts[#parts + 1] = "sf=" .. node.stepFunction
    end
    if node.variable then
        parts[#parts + 1] = "v=" .. node.variable
    end
    if node.sequence then
        parts[#parts + 1] = "s=" .. node.sequence
    end
    if node.clicks then
        parts[#parts + 1] = "c=" .. tostring(node.clicks)
    end
    if node.ms then
        parts[#parts + 1] = "ms=" .. tostring(node.ms)
    end
    if node.gcd then
        parts[#parts + 1] = "gcd=" .. tostring(node.gcd)
    end
    if node.children then
        if node.type == D().ACTION_TYPE_IF then
            parts[#parts + 1] = "t{" .. SLV:_serializeActions(node.children[1] or {}) .. "}"
            parts[#parts + 1] = "f{" .. SLV:_serializeActions(node.children[2] or {}) .. "}"
        else
            parts[#parts + 1] = "ch{" .. SLV:_serializeActions(node.children) .. "}"
        end
    end
    return table.concat(parts, ";")
end

--- Rebuild DataProvider, update button states, update edit area.
function SLV:RefreshAll()
    if SLV.autocompleteDropdown then
        SLV.autocompleteDropdown:Hide()
    end
    if not SLV.scrollView then
        return
    end

    -- Outline + Detail pane mode (replaces S30-BUG-03 split-pane)
    local defaults = D()
    if SLV.hasActions and SLV.workingActions then
        -- Build outline from top-level actions
        local dp = CreateDataProvider()
        local stepCounter = 0
        for i, node in ipairs(SLV.workingActions) do
            if node.type == defaults.ACTION_TYPE_ACTION then
                stepCounter = stepCounter + 1
                dp:Insert({
                    rowType = "step",
                    index = stepCounter,
                    text = node.macro or "",
                    charCount = #(node.macro or ""),
                    nodeIndex = i,
                })
            else
                dp:Insert({
                    rowType = "node",
                    nodeType = node.type,
                    nodeName = node.name or "",
                    nodeSummary = defaults.NodeSummary(node),
                    nodeIndex = i,
                    node = node,
                })
            end
        end
        SLV.scrollBox:SetDataProvider(dp)
        SLV.dataProvider = dp

        if stepCounter > 0 or #SLV.workingActions > 0 then
            if SLV.emptyIcon then
                SLV.emptyIcon:Hide()
            end
            if SLV.emptyLabel then
                SLV.emptyLabel:Hide()
            end
            if SLV.hintLabel then
                SLV.hintLabel:Hide()
            end
        else
            if SLV.emptyIcon then
                SLV.emptyIcon:Show()
            end
            if SLV.emptyLabel then
                SLV.emptyLabel:Show()
            end
            if SLV.hintLabel then
                SLV.hintLabel:Show()
            end
        end

        -- Full-width scrollBox (no split pane) unless detail pane is open
        if SLV._detailOpen then
            local containerWidth = SLV.container:GetWidth()
            local halfWidth = math.floor((containerWidth - 30) / 2)
            SLV.scrollBox:ClearAllPoints()
            SLV.scrollBox:SetPoint("TOPLEFT", SLV.container, "TOPLEFT", 4, -4)
            SLV.scrollBox:SetPoint("BOTTOM", SLV.actionBar, "TOP", 0, 4)
            SLV.scrollBox:SetWidth(halfWidth)
            SLV.scrollBar:ClearAllPoints()
            SLV.scrollBar:SetPoint("TOPLEFT", SLV.scrollBox, "TOPRIGHT", 2, 0)
            SLV.scrollBar:SetPoint("BOTTOMLEFT", SLV.scrollBox, "BOTTOMRIGHT", 2, 0)
        else
            SLV.scrollBox:ClearAllPoints()
            SLV.scrollBox:SetPoint("TOPLEFT", SLV.container, "TOPLEFT", 4, -4)
            SLV.scrollBox:SetPoint("RIGHT", SLV.container, "RIGHT", -18, 0)
            SLV.scrollBox:SetPoint("BOTTOM", SLV.actionBar, "TOP", 0, 4)
            SLV.scrollBar:ClearAllPoints()
            SLV.scrollBar:SetPoint("TOPLEFT", SLV.scrollBox, "TOPRIGHT", 2, 0)
            SLV.scrollBar:SetPoint("BOTTOMLEFT", SLV.scrollBox, "BOTTOMRIGHT", 2, 0)
        end

        -- If detail pane is open, re-render it
        if SLV._detailOpen and SLV._detailNodeIndex then
            SLV:_renderDetailPane()
        end
    else
        -- Flat mode (no actions): UNCHANGED behavior
        local dp = CreateDataProvider()
        if #SLV.workingSteps > 0 then
            for i, step in ipairs(SLV.workingSteps) do
                dp:Insert({
                    rowType = "step",
                    index = i,
                    text = step,
                    charCount = #step,
                })
            end
            if SLV.emptyIcon then
                SLV.emptyIcon:Hide()
            end
            if SLV.emptyLabel then
                SLV.emptyLabel:Hide()
            end
            if SLV.hintLabel then
                SLV.hintLabel:Hide()
            end
        else
            if SLV.emptyIcon then
                SLV.emptyIcon:Show()
            end
            if SLV.emptyLabel then
                SLV.emptyLabel:Show()
            end
            if SLV.hintLabel then
                SLV.hintLabel:Show()
            end
        end
        SLV.scrollBox:SetDataProvider(dp)
        SLV.dataProvider = dp

        -- Full width flat mode (original anchors)
        SLV.scrollBox:ClearAllPoints()
        SLV.scrollBox:SetPoint("TOPLEFT", SLV.container, "TOPLEFT", 4, -4)
        SLV.scrollBox:SetPoint("RIGHT", SLV.container, "RIGHT", -18, 0)
        SLV.scrollBox:SetPoint("BOTTOM", SLV.actionBar, "TOP", 0, 4)
        SLV.scrollBar:ClearAllPoints()
        SLV.scrollBar:SetPoint("TOPLEFT", SLV.scrollBox, "TOPRIGHT", 2, 0)
        SLV.scrollBar:SetPoint("BOTTOMLEFT", SLV.scrollBox, "BOTTOMRIGHT", 2, 0)
    end

    -- Show flat mode UI elements
    if SLV.scrollBox then
        SLV.scrollBox:Show()
    end
    if SLV.scrollBar then
        SLV.scrollBar:Show()
    end

    -- Update action button states
    SLV:UpdateButtonStates()

    -- Update edit area
    SLV:UpdateEditArea()
end

---------------------------------------------------------------------------
-- Detail Pane (Outline + Detail pattern)
---------------------------------------------------------------------------

--- Lazy-create the detail pane container and its sub-frames.
--- Idempotent: creates once, reuses on subsequent calls.
function SLV:_ensureDetailPane()
    if SLV._detailContainer then
        return
    end

    local C = UI.Colors

    -- Main container (anchored to right half of SLV.container)
    local container = CreateFrame("Frame", nil, SLV.container, "BackdropTemplate")
    UI:ApplyBackdrop(container, UI.Backdrops.panel, C.bgMain, C.border)
    container:Hide()
    SLV._detailContainer = container

    -- Header: breadcrumb + close button
    local header = CreateFrame("Frame", nil, container)
    header:SetHeight(24)
    header:SetPoint("TOPLEFT", container, "TOPLEFT", 0, 0)
    header:SetPoint("TOPRIGHT", container, "TOPRIGHT", 0, 0)
    SLV._detailHeader = header

    local closeBtn = UI:CreateButton(header, "X", 22, 20)
    closeBtn:SetPoint("TOPRIGHT", header, "TOPRIGHT", -2, -2)
    closeBtn:SetScript("OnClick", function()
        SLV:CloseDetailPane()
    end)
    SLV._detailCloseBtn = closeBtn

    -- Breadcrumb container
    local breadcrumb = CreateFrame("Frame", nil, header)
    breadcrumb:SetPoint("TOPLEFT", header, "TOPLEFT", 4, -2)
    breadcrumb:SetPoint("RIGHT", closeBtn, "LEFT", -4, 0)
    breadcrumb:SetHeight(20)
    SLV._detailBreadcrumb = breadcrumb

    -- Settings bar (below header)
    local settings = CreateFrame("Frame", nil, container)
    settings:SetHeight(30)
    settings:SetPoint("TOPLEFT", header, "BOTTOMLEFT", 0, 0)
    settings:SetPoint("TOPRIGHT", header, "BOTTOMRIGHT", 0, 0)
    SLV._detailSettings = settings

    -- ScrollPanel for children list
    local scrollFrame, scrollChild = UI:CreateScrollPanel(container, 400)
    scrollFrame:SetPoint("TOPLEFT", settings, "BOTTOMLEFT", 2, -2)
    scrollFrame:SetPoint("BOTTOMRIGHT", container, "BOTTOMRIGHT", -4, 32)
    scrollFrame:SetScript("OnSizeChanged", function(self)
        local w = self:GetWidth() - 20
        if w > 0 then
            scrollChild:SetWidth(w)
        end
    end)
    SLV._detailScrollFrame = scrollFrame
    SLV._detailScrollChild = scrollChild

    -- Bottom toolbar
    local toolbar = CreateFrame("Frame", nil, container)
    toolbar:SetHeight(28)
    toolbar:SetPoint("BOTTOMLEFT", container, "BOTTOMLEFT", 0, 2)
    toolbar:SetPoint("BOTTOMRIGHT", container, "BOTTOMRIGHT", 0, 2)
    SLV._detailToolbar = toolbar

    local addBtn = UI:CreateButton(toolbar, "+ Add", 50, 22)
    addBtn:SetPoint("LEFT", toolbar, "LEFT", 4, 0)
    addBtn:SetScript("OnClick", function(self)
        SLV:_showAddMenu(self, true)
    end)

    local dupBtn = UI:CreateButton(toolbar, "Dup", 40, 22)
    dupBtn:SetPoint("LEFT", addBtn, "RIGHT", 2, 0)
    dupBtn:SetScript("OnClick", function()
        SLV:_detailDupChild()
    end)

    local upBtn = UI:CreateButton(toolbar, "Up", 32, 22)
    upBtn:SetPoint("LEFT", dupBtn, "RIGHT", 2, 0)
    upBtn:SetScript("OnClick", function()
        SLV:_detailMoveChild(-1)
    end)

    local downBtn = UI:CreateButton(toolbar, "Down", 42, 22)
    downBtn:SetPoint("LEFT", upBtn, "RIGHT", 2, 0)
    downBtn:SetScript("OnClick", function()
        SLV:_detailMoveChild(1)
    end)

    local delBtn = UI:CreateButton(toolbar, "Del", 36, 22)
    delBtn:SetPoint("LEFT", downBtn, "RIGHT", 2, 0)
    delBtn:SetScript("OnClick", function()
        SLV:_detailDeleteChild()
    end)

    SLV._detailToolbarButtons = {
        add = addBtn,
        dup = dupBtn,
        up = upBtn,
        down = downBtn,
        del = delBtn,
    }
end

--- Open the detail pane for a node at the given index in workingActions.
--- @param nodeIndex number Index in SLV.workingActions
function SLV:OpenDetailPane(nodeIndex)
    if not SLV.workingActions or not SLV.workingActions[nodeIndex] then
        return
    end

    SLV._detailOpen = true
    SLV._detailNavStack = {}
    SLV._detailNodeIndex = nodeIndex
    SLV._detailNode = SLV.workingActions[nodeIndex]
    SLV._detailSelectedChild = nil
    SLV._editingContext = nil
    SLV.selectedIndex = nil

    SLV:_ensureDetailPane()

    -- Shrink outline scrollBox to left half
    local containerWidth = SLV.container:GetWidth()
    local halfWidth = math.floor((containerWidth - 30) / 2)
    SLV.scrollBox:ClearAllPoints()
    SLV.scrollBox:SetPoint("TOPLEFT", SLV.container, "TOPLEFT", 4, -4)
    SLV.scrollBox:SetPoint("BOTTOM", SLV.actionBar, "TOP", 0, 4)
    SLV.scrollBox:SetWidth(halfWidth)
    SLV.scrollBar:ClearAllPoints()
    SLV.scrollBar:SetPoint("TOPLEFT", SLV.scrollBox, "TOPRIGHT", 2, 0)
    SLV.scrollBar:SetPoint("BOTTOMLEFT", SLV.scrollBox, "BOTTOMRIGHT", 2, 0)

    -- Show and anchor detail pane
    SLV._detailContainer:ClearAllPoints()
    SLV._detailContainer:SetPoint("TOPLEFT", SLV.container, "TOPLEFT", halfWidth + 18, -4)
    SLV._detailContainer:SetPoint("BOTTOMRIGHT", SLV.actionBar, "TOPRIGHT", -4, 4)
    SLV._detailContainer:Show()

    -- Refresh outline to highlight selected badge
    SLV:RefreshAll()
    SLV:UpdateButtonStates()
end

--- Close the detail pane and restore full-width outline.
function SLV:CloseDetailPane()
    SLV._detailOpen = false
    SLV._detailNavStack = nil
    SLV._detailNode = nil
    SLV._detailNodeIndex = nil
    SLV._detailSelectedChild = nil
    SLV._editingContext = nil

    if SLV._detailContainer then
        SLV._detailContainer:Hide()
    end

    -- Restore full-width outline
    SLV:RefreshAll()
end

--- Drill into a child node within the detail pane.
--- Pushes current node onto the nav stack and renders the child.
--- @param childIndex number Index in current detail node children
--- @param branchIndex number|nil For If nodes: 1=true, 2=false
function SLV:DrillIntoNode(childIndex, branchIndex)
    if not SLV._detailNode then
        return
    end

    -- Push current state
    SLV._detailNavStack = SLV._detailNavStack or {}
    SLV._detailNavStack[#SLV._detailNavStack + 1] = {
        node = SLV._detailNode,
        selectedChild = SLV._detailSelectedChild,
    }

    -- Navigate to child
    local children
    if branchIndex then
        children = SLV._detailNode.children and SLV._detailNode.children[branchIndex]
    else
        children = SLV._detailNode.children
    end
    if children and children[childIndex] then
        SLV._detailNode = children[childIndex]
    end
    SLV._detailSelectedChild = nil
    SLV._editingContext = nil

    SLV:_renderDetailPane()
end

--- Navigate to a breadcrumb level in the detail pane.
--- @param stackIndex number Index in the nav stack (0 = root detail node)
function SLV:NavigateBreadcrumb(stackIndex)
    if not SLV._detailNavStack then
        return
    end

    if stackIndex == 0 then
        -- Go back to root detail node
        if #SLV._detailNavStack > 0 then
            SLV._detailNode = SLV._detailNavStack[1].node
        end
        SLV._detailNavStack = {}
    else
        -- Pop to the given level
        local target = SLV._detailNavStack[stackIndex]
        if target then
            SLV._detailNode = target.node
            -- Trim stack
            local newStack = {}
            for i = 1, stackIndex - 1 do
                newStack[i] = SLV._detailNavStack[i]
            end
            SLV._detailNavStack = newStack
        end
    end
    SLV._detailSelectedChild = nil
    SLV._editingContext = nil

    SLV:_renderDetailPane()
end

--- Render (or re-render) the current detail pane contents.
--- Called on open, drill-down, breadcrumb nav, and child mutations.
function SLV:_renderDetailPane()
    if not SLV._detailContainer or not SLV._detailNode then
        return
    end

    local C = UI.Colors
    local defaults = D()
    local node = SLV._detailNode

    -- HEADER: breadcrumb
    local bc = SLV._detailBreadcrumb
    -- Clear old breadcrumb children
    for _, child in ipairs({ bc:GetChildren() }) do
        child:Hide()
        child:SetParent(nil)
    end
    for _, region in ipairs({ bc:GetRegions() }) do
        region:Hide()
    end

    -- Build breadcrumb segments
    local segments = {}
    local navStack = SLV._detailNavStack or {}
    -- Root node label
    local rootNode = navStack[1] and navStack[1].node or node
    local rootInfo = defaults.NODE_ICONS[rootNode.type] or { label = "Node" }
    local rootName = rootNode.name and rootNode.name ~= "" and rootNode.name or rootInfo.label
    segments[1] = rootName

    for i = 2, #navStack do
        local stackNode = navStack[i].node
        local info = defaults.NODE_ICONS[stackNode.type] or { label = "Node" }
        local name = stackNode.name and stackNode.name ~= "" and stackNode.name or info.label
        segments[#segments + 1] = name
    end
    -- Current node (if we have drilled deeper)
    if #navStack > 0 then
        local curInfo = defaults.NODE_ICONS[node.type] or { label = "Node" }
        local curName = node.name and node.name ~= "" and node.name or curInfo.label
        segments[#segments + 1] = curName
    end

    -- Build the list of segment indices to display, with truncation at depth 5+
    local totalSegs = #segments
    local displayIndices = {}
    if totalSegs <= 4 then
        -- Show all segments
        for si = 1, totalSegs do
            displayIndices[#displayIndices + 1] = si
        end
    else
        -- Truncate: [Root] > ... > [Parent] > [Current]
        displayIndices[1] = 1 -- root
        displayIndices[2] = 0 -- 0 = ellipsis placeholder
        displayIndices[3] = totalSegs - 1 -- parent
        displayIndices[4] = totalSegs -- current
    end

    -- Helper: render a ">" separator
    local prevAnchor = bc
    local prevPoint = "LEFT"
    local function addSep()
        local sep = bc:CreateFontString(nil, "OVERLAY")
        UI:SetFont(sep, 10)
        sep:SetPoint("LEFT", prevAnchor, prevPoint == "LEFT" and "LEFT" or "RIGHT", 2, 0)
        sep:SetText(">")
        sep:SetTextColor(C.textMuted:GetRGBA())
        prevAnchor = sep
        prevPoint = "RIGHT"
    end

    -- Helper: render a clickable breadcrumb segment
    local function addNavSegment(text, stackIdx)
        local navBtn = CreateFrame("Button", nil, bc)
        navBtn:SetHeight(18)
        local navLbl = navBtn:CreateFontString(nil, "OVERLAY")
        UI:SetFont(navLbl, 10)
        navLbl:SetPoint("LEFT")
        navLbl:SetText(text)
        navLbl:SetTextColor(C.gripGreen:GetRGBA())
        navBtn:SetWidth(navLbl:GetStringWidth() + 4)
        navBtn:SetPoint("LEFT", prevAnchor, prevPoint == "LEFT" and "LEFT" or "RIGHT", 4, 0)
        navBtn:SetScript("OnClick", function()
            SLV:NavigateBreadcrumb(stackIdx)
        end)
        navBtn:SetScript("OnEnter", function()
            navLbl:SetTextColor(1, 1, 1, 1)
        end)
        navBtn:SetScript("OnLeave", function()
            navLbl:SetTextColor(C.gripGreen:GetRGBA())
        end)
        prevAnchor = navBtn
        prevPoint = "RIGHT"
    end

    for di, si in ipairs(displayIndices) do
        if di > 1 then
            addSep()
        end

        if si == 0 then
            -- Ellipsis: click navigates to the first hidden level (navStack index 2)
            addNavSegment("...", 2)
        elseif si == totalSegs then
            -- Current node (last segment): non-clickable, white text
            local lbl = bc:CreateFontString(nil, "OVERLAY")
            UI:SetFont(lbl, 10)
            lbl:SetPoint("LEFT", prevAnchor, prevPoint == "LEFT" and "LEFT" or "RIGHT", 4, 0)
            lbl:SetText(segments[si])
            lbl:SetTextColor(C.textPrimary:GetRGBA())
            prevAnchor = lbl
            prevPoint = "RIGHT"
        else
            -- Clickable intermediate segment
            addNavSegment(segments[si], si - 1)
        end
    end

    -- SETTINGS BAR: node-type-specific controls
    local settings = SLV._detailSettings
    -- Clear old settings children
    for _, child in ipairs({ settings:GetChildren() }) do
        child:Hide()
        child:SetParent(nil)
    end
    for _, region in ipairs({ settings:GetRegions() }) do
        region:Hide()
    end

    SLV:_renderDetailSettings(settings, node)

    -- CHILDREN LIST: render in scroll panel
    local scrollChild = SLV._detailScrollChild
    -- Clear old children
    for _, child in ipairs({ scrollChild:GetChildren() }) do
        child:Hide()
        child:SetParent(nil)
    end
    for _, region in ipairs({ scrollChild:GetRegions() }) do
        region:Hide()
    end

    local yOffset = 0
    local nodeType = node.type

    if nodeType == defaults.ACTION_TYPE_IF then
        -- If node: two branches
        yOffset = SLV:_renderDetailBranch(scrollChild, "True:", node.children and node.children[1] or {}, 1, yOffset)
        yOffset = SLV:_renderDetailBranch(scrollChild, "False:", node.children and node.children[2] or {}, 2, yOffset)
    else
        -- Loop, Embed, Pause: single children array
        local children = node.children or {}
        for i, child in ipairs(children) do
            yOffset = SLV:_renderDetailChildRow(scrollChild, child, i, nil, yOffset)
        end
    end

    scrollChild:SetHeight(math.abs(yOffset) + 10)
end

--- Render settings controls for a specific node type.
--- @param parent Frame The settings bar frame
--- @param node table The current detail node
function SLV:_renderDetailSettings(parent, node)
    local C = UI.Colors
    local defaults = D()
    local xOff = 4

    -- Name EditBox (all structural types)
    local nameLbl = parent:CreateFontString(nil, "OVERLAY")
    UI:SetFont(nameLbl, 10)
    nameLbl:SetPoint("LEFT", parent, "LEFT", xOff, 0)
    nameLbl:SetText("Name:")
    nameLbl:SetTextColor(C.textSecondary:GetRGBA())

    local nameBox = CreateFrame("EditBox", nil, parent, "BackdropTemplate")
    nameBox:SetSize(80, 20)
    nameBox:SetPoint("LEFT", nameLbl, "RIGHT", 4, 0)
    nameBox:SetAutoFocus(false)
    nameBox:SetMaxBytes(32)
    UI:ApplyBackdrop(nameBox, UI.Backdrops.panel, C.bgInput, C.border)
    nameBox:SetTextInsets(4, 4, 2, 2)
    local fontPath = GameFontNormal:GetFont()
    nameBox:SetFont(fontPath, 10, "")
    nameBox:SetTextColor(C.textPrimary:GetRGBA())
    nameBox:SetText(node.name or "")
    nameBox:SetScript("OnTextChanged", function(self, userInput)
        if not userInput then
            return
        end
        node.name = self:GetText() or ""
        SLV:_markDirty()
    end)
    nameBox:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
    end)
    SLV._detailNameEditBox = nameBox

    xOff = 4 + nameLbl:GetStringWidth() + 4 + 84

    local nodeType = node.type

    if nodeType == defaults.ACTION_TYPE_LOOP then
        -- Repeat
        local rLbl = parent:CreateFontString(nil, "OVERLAY")
        UI:SetFont(rLbl, 10)
        rLbl:SetPoint("LEFT", parent, "LEFT", xOff, 0)
        rLbl:SetText("Repeat:")
        rLbl:SetTextColor(C.textSecondary:GetRGBA())

        local rBox = CreateFrame("EditBox", nil, parent, "BackdropTemplate")
        rBox:SetSize(36, 20)
        rBox:SetPoint("LEFT", rLbl, "RIGHT", 4, 0)
        rBox:SetAutoFocus(false)
        rBox:SetNumeric(true)
        rBox:SetMaxLetters(3)
        UI:ApplyBackdrop(rBox, UI.Backdrops.panel, C.bgInput, C.border)
        rBox:SetTextInsets(4, 4, 2, 2)
        rBox:SetFont(fontPath, 10, "")
        rBox:SetTextColor(C.textPrimary:GetRGBA())
        rBox:SetText(tostring(node["repeat"] or defaults.ACTION_LOOP_DEFAULT_REPEAT))
        rBox:SetScript("OnTextChanged", function(self, userInput)
            if not userInput then
                return
            end
            local val = tonumber(self:GetText()) or defaults.ACTION_LOOP_DEFAULT_REPEAT
            if val < 1 then
                val = 1
            end
            if val > defaults.ACTION_LOOP_MAX_REPEAT then
                val = defaults.ACTION_LOOP_MAX_REPEAT
            end
            node["repeat"] = val
            SLV:_markDirty()
        end)
        rBox:SetScript("OnEscapePressed", function(self)
            self:ClearFocus()
        end)

        -- Step function dropdown
        local sfLbl = parent:CreateFontString(nil, "OVERLAY")
        UI:SetFont(sfLbl, 10)
        sfLbl:SetPoint("LEFT", rBox, "RIGHT", 8, 0)
        sfLbl:SetText("SF:")
        sfLbl:SetTextColor(C.textSecondary:GetRGBA())

        local sfNames = {
            defaults.STEP_SEQUENTIAL,
            defaults.STEP_PRIORITY,
            defaults.STEP_REVERSE_PRIORITY,
            defaults.STEP_RANDOM,
        }
        local sfBtn = UI:CreateButton(parent, node.stepFunction or defaults.STEP_SEQUENTIAL, 80, 20)
        sfBtn:SetPoint("LEFT", sfLbl, "RIGHT", 4, 0)
        sfBtn:SetScript("OnClick", function(self)
            MenuUtil.CreateContextMenu(self, function(_, rootDescription)
                for _, sfName in ipairs(sfNames) do
                    rootDescription:CreateButton(sfName, function()
                        node.stepFunction = sfName
                        self.label:SetText(sfName)
                        SLV:_markDirty()
                    end)
                end
            end)
        end)
    elseif nodeType == defaults.ACTION_TYPE_PAUSE then
        -- Mode dropdown
        local modes = { "clicks", "ms", "gcd" }
        local modeLabels = { clicks = "Clicks", ms = "MS", gcd = "GCD" }
        local currentMode = "clicks"
        if node.ms then
            currentMode = "ms"
        elseif node.gcd then
            currentMode = "gcd"
        end

        local modeBtn = UI:CreateButton(parent, modeLabels[currentMode], 50, 20)
        modeBtn:SetPoint("LEFT", parent, "LEFT", xOff, 0)
        modeBtn:SetScript("OnClick", function(self)
            MenuUtil.CreateContextMenu(self, function(_, rootDescription)
                for _, mode in ipairs(modes) do
                    rootDescription:CreateButton(modeLabels[mode], function()
                        node.clicks = nil
                        node.ms = nil
                        node.gcd = nil
                        if mode == "clicks" then
                            node.clicks = 1
                        elseif mode == "ms" then
                            node.ms = 250
                        elseif mode == "gcd" then
                            node.gcd = 1
                        end
                        self.label:SetText(modeLabels[mode])
                        SLV:_markDirty()
                        SLV:_renderDetailPane()
                    end)
                end
            end)
        end)

        -- Value box
        local val = node.clicks or node.ms or node.gcd or 1
        local valBox = CreateFrame("EditBox", nil, parent, "BackdropTemplate")
        valBox:SetSize(50, 20)
        valBox:SetPoint("LEFT", modeBtn, "RIGHT", 4, 0)
        valBox:SetAutoFocus(false)
        valBox:SetNumeric(true)
        valBox:SetMaxLetters(5)
        UI:ApplyBackdrop(valBox, UI.Backdrops.panel, C.bgInput, C.border)
        valBox:SetTextInsets(4, 4, 2, 2)
        valBox:SetFont(fontPath, 10, "")
        valBox:SetTextColor(C.textPrimary:GetRGBA())
        valBox:SetText(tostring(val))
        valBox:SetScript("OnTextChanged", function(self, userInput)
            if not userInput then
                return
            end
            local v = tonumber(self:GetText()) or 1
            if v < 1 then
                v = 1
            end
            if node.clicks then
                node.clicks = v
            elseif node.ms then
                node.ms = v
            elseif node.gcd then
                node.gcd = v
            end
            SLV:_markDirty()
        end)
        valBox:SetScript("OnEscapePressed", function(self)
            self:ClearFocus()
        end)
    elseif nodeType == defaults.ACTION_TYPE_IF then
        -- Condition EditBox
        local condLbl = parent:CreateFontString(nil, "OVERLAY")
        UI:SetFont(condLbl, 10)
        condLbl:SetPoint("LEFT", parent, "LEFT", xOff, 0)
        condLbl:SetText("Cond:")
        condLbl:SetTextColor(C.textSecondary:GetRGBA())

        local condBox = CreateFrame("EditBox", nil, parent, "BackdropTemplate")
        condBox:SetSize(120, 20)
        condBox:SetPoint("LEFT", condLbl, "RIGHT", 4, 0)
        condBox:SetAutoFocus(false)
        condBox:SetMaxBytes(255)
        UI:ApplyBackdrop(condBox, UI.Backdrops.panel, C.bgInput, C.border)
        condBox:SetTextInsets(4, 4, 2, 2)
        condBox:SetFont(fontPath, 10, "")
        condBox:SetTextColor(C.textPrimary:GetRGBA())
        condBox:SetText(node.variable or "")
        condBox:SetScript("OnTextChanged", function(self, userInput)
            if not userInput then
                return
            end
            node.variable = self:GetText() or ""
            SLV:_markDirty()
        end)
        condBox:SetScript("OnEscapePressed", function(self)
            self:ClearFocus()
        end)
    elseif nodeType == defaults.ACTION_TYPE_EMBED then
        -- Sequence dropdown
        local seqLbl = parent:CreateFontString(nil, "OVERLAY")
        UI:SetFont(seqLbl, 10)
        seqLbl:SetPoint("LEFT", parent, "LEFT", xOff, 0)
        seqLbl:SetText("Seq:")
        seqLbl:SetTextColor(C.textSecondary:GetRGBA())

        local seqBtn = UI:CreateButton(parent, node.sequence or "(select)", 120, 20)
        seqBtn:SetPoint("LEFT", seqLbl, "RIGHT", 4, 0)
        seqBtn:SetScript("OnClick", function(self)
            local Engine = GRIPEMS.Engine
            if not Engine or not Engine.sequences then
                return
            end
            MenuUtil.CreateContextMenu(self, function(_, rootDescription)
                local names = {}
                for seqName in pairs(Engine.sequences) do
                    names[#names + 1] = seqName
                end
                table.sort(names)
                for _, seqName in ipairs(names) do
                    rootDescription:CreateButton(seqName, function()
                        node.sequence = seqName
                        self.label:SetText(seqName)
                        SLV:_markDirty()
                    end)
                end
            end)
        end)
    elseif nodeType == defaults.ACTION_TYPE_ACTION then
        -- DEAD CODE: ACTION nodes use step rows, not detail pane badges.
        -- Interleave controls are in the edit area (UpdateEditArea outline context).
        local ilLbl = parent:CreateFontString(nil, "OVERLAY")
        UI:SetFont(ilLbl, 10)
        ilLbl:SetPoint("LEFT", parent, "LEFT", xOff, 0)
        ilLbl:SetText(L["GEMS_ACTION_INTERLEAVE_EVERY"])
        ilLbl:SetTextColor(C.textSecondary:GetRGBA())

        local hasInterval = node.interval and node.interval >= defaults.ACTION_INTERLEAVE_MIN
        local ilCheck = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
        ilCheck:SetSize(20, 20)
        ilCheck:SetPoint("LEFT", ilLbl, "RIGHT", 4, 0)
        ilCheck:SetChecked(hasInterval)
        ilCheck:SetScript("OnClick", function(self)
            if self:GetChecked() then
                node.interval = defaults.ACTION_INTERLEAVE_DEFAULT
            else
                node.interval = nil
            end
            SLV:_markDirty()
            SLV:_renderDetailPane()
        end)

        if hasInterval then
            local ivBox = CreateFrame("EditBox", nil, parent, "BackdropTemplate")
            ivBox:SetSize(36, 20)
            ivBox:SetPoint("LEFT", ilCheck, "RIGHT", 4, 0)
            ivBox:SetAutoFocus(false)
            ivBox:SetNumeric(true)
            ivBox:SetMaxLetters(2)
            UI:ApplyBackdrop(ivBox, UI.Backdrops.panel, C.bgInput, C.border)
            ivBox:SetTextInsets(4, 4, 2, 2)
            ivBox:SetFont(fontPath, 10, "")
            ivBox:SetTextColor(C.textPrimary:GetRGBA())
            ivBox:SetText(tostring(node.interval))
            ivBox:SetScript("OnTextChanged", function(self, userInput)
                if not userInput then
                    return
                end
                local val = tonumber(self:GetText()) or defaults.ACTION_INTERLEAVE_DEFAULT
                if val < defaults.ACTION_INTERLEAVE_MIN then
                    val = defaults.ACTION_INTERLEAVE_MIN
                end
                if val > defaults.ACTION_INTERLEAVE_MAX then
                    val = defaults.ACTION_INTERLEAVE_MAX
                end
                node.interval = val
                SLV:_markDirty()
            end)
            ivBox:SetScript("OnEscapePressed", function(self)
                self:ClearFocus()
            end)

            local stepsLbl = parent:CreateFontString(nil, "OVERLAY")
            UI:SetFont(stepsLbl, 10)
            stepsLbl:SetPoint("LEFT", ivBox, "RIGHT", 4, 0)
            stepsLbl:SetText(L["GEMS_ACTION_INTERLEAVE_STEPS"])
            stepsLbl:SetTextColor(C.textSecondary:GetRGBA())
        end
    end
end

--- Render a branch section label + its children in the detail pane.
--- Used for If node true/false branches.
--- @param scrollChild Frame The scroll child to render into
--- @param label string Section label ("True:" or "False:")
--- @param children table Array of child nodes
--- @param branchIndex number 1=true, 2=false
--- @param yOffset number Current Y offset
--- @return number yOffset Updated Y offset
function SLV:_renderDetailBranch(scrollChild, label, children, branchIndex, yOffset)
    local C = UI.Colors

    -- Section label
    local lbl = CreateFrame("Frame", nil, scrollChild)
    lbl:SetHeight(18)
    lbl:SetPoint("TOPLEFT", scrollChild, "TOPLEFT", 0, yOffset)
    lbl:SetPoint("RIGHT", scrollChild, "RIGHT", 0, 0)
    local fs = lbl:CreateFontString(nil, "OVERLAY")
    UI:SetFont(fs, 10)
    fs:SetPoint("LEFT", lbl, "LEFT", 4, 0)
    fs:SetText(label)
    if branchIndex == 1 then
        fs:SetTextColor(C.textSuccess:GetRGBA())
    else
        fs:SetTextColor(C.textError:GetRGBA())
    end
    yOffset = yOffset - 18

    for i, child in ipairs(children) do
        yOffset = SLV:_renderDetailChildRow(scrollChild, child, i, branchIndex, yOffset)
    end

    return yOffset
end

--- Render a single child row in the detail pane.
--- Action children = step row (text + charcount, clickable for EditBox).
--- Structural children = badge row (icon, name, summary, chevron, clickable for drill-down).
--- @param scrollChild Frame Parent scroll child
--- @param child table Child node
--- @param childIndex number Index in children array
--- @param branchIndex number|nil For If nodes: 1=true, 2=false
--- @param yOffset number Current Y offset
--- @return number yOffset Updated Y offset
function SLV:_renderDetailChildRow(scrollChild, child, childIndex, branchIndex, yOffset)
    local C = UI.Colors
    local defaults = D()

    local row = CreateFrame("Button", nil, scrollChild, "BackdropTemplate")
    row:SetHeight(defaults.NODE_BADGE_HEIGHT)
    row:SetPoint("TOPLEFT", scrollChild, "TOPLEFT", 0, yOffset)
    row:SetPoint("RIGHT", scrollChild, "RIGHT", 0, 0)
    if not row.SetBackdrop then
        Mixin(row, BackdropTemplateMixin)
    end
    row:EnableMouse(true)
    row:RegisterForClicks("LeftButtonUp")

    -- Drag handle for detail pane reorder
    local dh = CreateFrame("Frame", nil, row)
    dh:SetSize(defaults.STEP_DRAG_HANDLE_WIDTH, defaults.NODE_BADGE_HEIGHT)
    dh:SetPoint("LEFT", row, "LEFT", 2, 0)
    for li = 1, 3 do
        local line = dh:CreateTexture(nil, "ARTWORK")
        line:SetSize(8, 1)
        line:SetColorTexture(C.textMuted:GetRGBA())
        line:SetPoint("CENTER", dh, "CENTER", 0, (li - 2) * 3)
    end
    dh:EnableMouse(true)
    dh:RegisterForDrag("LeftButton")
    dh:SetScript("OnDragStart", function()
        SLV:_beginDetailDrag(row, childIndex, branchIndex)
    end)
    dh:SetScript("OnDragStop", function()
        SLV:_endDetailDrag(row)
    end)
    dh:SetScript("OnMouseUp", function(_, mouseButton)
        if not SLV._isDragging and row:GetScript("OnClick") then
            row:GetScript("OnClick")(row, mouseButton)
        end
    end)

    local leftAnchorOffset = 4 + defaults.STEP_DRAG_HANDLE_WIDTH

    if child.type == defaults.ACTION_TYPE_ACTION then
        -- Step row in detail pane
        row:SetBackdrop(UI.Backdrops.panelNoBorder)
        local isSelected = (
            SLV._detailSelectedChild == childIndex
            and (not branchIndex or SLV._detailSelectedBranch == branchIndex)
        )
        if isSelected then
            row:SetBackdropColor(C.bgRowSelected:GetRGBA())
        else
            row:SetBackdropColor(C.bgMain:GetRGBA())
        end

        local stepText = row:CreateFontString(nil, "OVERLAY")
        UI:SetFont(stepText, 11)
        stepText:SetPoint("LEFT", row, "LEFT", leftAnchorOffset, 0)
        stepText:SetPoint("RIGHT", row, "RIGHT", -50, 0)
        stepText:SetJustifyH("LEFT")
        stepText:SetWordWrap(false)
        local macro = child.macro or ""
        local firstLine = macro:match("^([^\n]*)") or macro
        if child.interval and child.interval >= defaults.ACTION_INTERLEAVE_MIN then
            stepText:SetText(firstLine .. "  [IL:" .. child.interval .. "]")
        else
            stepText:SetText(firstLine)
        end
        stepText:SetTextColor(C.textPrimary:GetRGBA())

        local charFs = row:CreateFontString(nil, "OVERLAY")
        UI:SetFont(charFs, 9)
        charFs:SetPoint("RIGHT", row, "RIGHT", -4, 0)
        local cc = #macro
        charFs:SetText(string.format("%d/%d", cc, defaults.CHAR_COUNT_DANGER))
        if cc >= defaults.CHAR_COUNT_DANGER then
            charFs:SetTextColor(C.textError:GetRGBA())
        elseif cc > defaults.CHAR_COUNT_WARNING then
            charFs:SetTextColor(C.textWarning:GetRGBA())
        else
            charFs:SetTextColor(C.textSuccess:GetRGBA())
        end

        row:SetScript("OnEnter", function(self)
            if not isSelected then
                self:SetBackdropColor(C.bgRowHover:GetRGBA())
            end
        end)
        row:SetScript("OnLeave", function(self)
            if not isSelected then
                self:SetBackdropColor(C.bgMain:GetRGBA())
            end
        end)

        row:SetScript("OnClick", function()
            SLV._detailSelectedChild = childIndex
            SLV._detailSelectedBranch = branchIndex
            -- Build breadcrumb path label for EditBox
            local navStack = SLV._detailNavStack or {}
            local pathParts = {}
            for _, entry in ipairs(navStack) do
                local info = defaults.NODE_ICONS[entry.node.type] or { label = "Node" }
                local n = entry.node.name and entry.node.name ~= "" and entry.node.name or info.label
                pathParts[#pathParts + 1] = n
            end
            local curInfo = defaults.NODE_ICONS[SLV._detailNode.type] or { label = "Node" }
            local curName = SLV._detailNode.name and SLV._detailNode.name ~= "" and SLV._detailNode.name
                or curInfo.label
            pathParts[#pathParts + 1] = curName
            local pathStr = table.concat(pathParts, " > ")
            local label = pathStr .. " > Action " .. childIndex .. ":"

            SLV._editingContext = {
                source = "detail",
                childIndex = childIndex,
                branchIndex = branchIndex,
                label = label,
            }
            SLV:UpdateEditArea()
            SLV:_renderDetailPane()
        end)
    else
        -- Badge row for structural child (drill-down)
        row:SetBackdrop(UI.Backdrops.panelNoBorder)
        local isSelected = (
            SLV._detailSelectedChild == childIndex
            and (not branchIndex or SLV._detailSelectedBranch == branchIndex)
        )
        if isSelected then
            row:SetBackdropColor(C.bgRowSelected:GetRGBA())
        else
            row:SetBackdropColor(C.bgPanel:GetRGBA())
        end

        local iconInfo = defaults.NODE_ICONS[child.type] or defaults.NODE_ICONS["loop"]
        local iconColor = iconInfo.color

        local iconFrame = CreateFrame("Frame", nil, row, "BackdropTemplate")
        iconFrame:SetSize(18, 18)
        iconFrame:SetPoint("LEFT", row, "LEFT", leftAnchorOffset, 0)
        UI:ApplyBackdrop(
            iconFrame,
            UI.Backdrops.panel,
            CreateColor(iconColor[1], iconColor[2], iconColor[3], 0.3),
            CreateColor(iconColor[1], iconColor[2], iconColor[3], 0.6)
        )
        local iconLabel = iconFrame:CreateFontString(nil, "OVERLAY")
        UI:SetFont(iconLabel, 11, "OUTLINE")
        iconLabel:SetPoint("CENTER")
        iconLabel:SetText(iconInfo.symbol)
        iconLabel:SetTextColor(iconColor[1], iconColor[2], iconColor[3], 1)

        local nameFs = row:CreateFontString(nil, "OVERLAY")
        UI:SetFont(nameFs, 12)
        nameFs:SetPoint("LEFT", iconFrame, "RIGHT", 6, 0)
        nameFs:SetJustifyH("LEFT")
        local dispName = child.name and child.name ~= "" and child.name or iconInfo.label
        nameFs:SetText(dispName)
        nameFs:SetTextColor(C.textPrimary:GetRGBA())

        local sumFs = row:CreateFontString(nil, "OVERLAY")
        UI:SetFont(sumFs, 11)
        sumFs:SetPoint("LEFT", nameFs, "RIGHT", 8, 0)
        sumFs:SetPoint("RIGHT", row, "RIGHT", -24, 0)
        sumFs:SetJustifyH("LEFT")
        sumFs:SetWordWrap(false)
        sumFs:SetText(defaults.NodeSummary(child))
        sumFs:SetTextColor(C.textSecondary:GetRGBA())

        local chev = row:CreateFontString(nil, "OVERLAY")
        UI:SetFont(chev, 12)
        chev:SetPoint("RIGHT", row, "RIGHT", -6, 0)
        chev:SetText(">")
        chev:SetTextColor(C.textMuted:GetRGBA())

        row:SetScript("OnEnter", function(self)
            if not isSelected then
                self:SetBackdropColor(C.bgRowHover:GetRGBA())
            end
        end)
        row:SetScript("OnLeave", function(self)
            if not isSelected then
                self:SetBackdropColor(C.bgPanel:GetRGBA())
            end
        end)

        row:RegisterForClicks("LeftButtonUp")
        row:SetScript("OnClick", function()
            local wasSelected = (
                SLV._detailSelectedChild == childIndex
                and (not branchIndex or SLV._detailSelectedBranch == branchIndex)
            )
            if wasSelected then
                SLV:DrillIntoNode(childIndex, branchIndex)
            else
                SLV._detailSelectedChild = childIndex
                SLV._detailSelectedBranch = branchIndex
                SLV._editingContext = nil
                SLV:_renderDetailPane()
            end
        end)
    end

    return yOffset - defaults.NODE_BADGE_HEIGHT
end

--- Mark the sequence as dirty (detail pane edits).
function SLV:_markDirty()
    local SE = GRIPEMS.SequenceEditor
    if SE then
        SE.isDirty = true
        SE:UpdateSaveButtons()
    end
end

---------------------------------------------------------------------------
-- Outline drag-to-reorder (shared by step rows and node badge rows)
---------------------------------------------------------------------------

--- Begin a drag operation in the outline scrollBox.
--- Works for both flat mode (workingSteps) and outline mode (workingActions).
--- @param button Frame The row frame being dragged
--- @param data table The DataProvider item data for this row
function SLV:_beginOutlineDrag(button, data)
    if not data then
        return
    end

    -- Determine item count and source index based on mode
    local itemCount, srcIdx
    if SLV.hasActions and SLV.workingActions then
        itemCount = #SLV.workingActions
        srcIdx = data.nodeIndex
    else
        itemCount = #SLV.workingSteps
        srcIdx = data.index
    end

    if not srcIdx or itemCount <= 1 then
        return
    end

    SLV._dragSourceIndex = srcIdx
    SLV._isDragging = true
    SLV._dragMode = SLV.hasActions and "outline" or "flat"

    -- Hide autocomplete if open
    if SLV.autocompleteDropdown and SLV.autocompleteDropdown:IsShown() then
        SLV.autocompleteDropdown:Hide()
    end

    -- Configure ghost frame
    local ghost = SLV.dragGhost
    ghost:SetWidth(SLV.scrollBox:GetWidth())
    if data.rowType == "node" then
        local defaults = D()
        local iconInfo = defaults.NODE_ICONS[data.nodeType] or { label = "Node", symbol = "?" }
        ghost.ghostNum:SetText("[" .. iconInfo.symbol .. "]")
        ghost.ghostText:SetText(data.nodeName ~= "" and data.nodeName or iconInfo.label)
    else
        ghost.ghostNum:SetText(button.stepNum and button.stepNum:GetText() or "")
        ghost.ghostText:SetText(button.stepText and button.stepText:GetText() or "")
    end
    ghost:ClearAllPoints()
    ghost:SetAlpha(0.7)
    ghost:Show()

    -- Dim source row
    button:SetAlpha(0.3)

    -- Show drag indicator with fade-in
    SLV.dragIndicator:SetAlpha(0)
    SLV.dragIndicator:Show()
    local fadeElapsed = 0
    SLV.dragIndicator:SetScript("OnUpdate", function(self, dt)
        fadeElapsed = fadeElapsed + dt
        local alpha = math.min(fadeElapsed / 0.1, 1)
        self:SetAlpha(alpha)
        if alpha >= 1 then
            self:SetScript("OnUpdate", nil)
        end
    end)

    -- OnUpdate: track cursor, position ghost and indicator
    ghost:SetScript("OnUpdate", function()
        if not SLV._isDragging then
            ghost:SetScript("OnUpdate", nil)
            return
        end
        local scale = UIParent:GetEffectiveScale()
        local cursorX, cursorY = GetCursorPosition()
        cursorX = cursorX / scale
        cursorY = cursorY / scale
        ghost:ClearAllPoints()
        ghost:SetPoint("CENTER", UIParent, "BOTTOMLEFT", cursorX, cursorY)

        -- Auto-scroll when cursor is near ScrollBox edges
        local sbTopEdge = SLV.scrollBox:GetTop()
        local sbBottomEdge = SLV.scrollBox:GetBottom()
        if sbTopEdge and sbBottomEdge then
            local edgeZone = D().DRAG_SCROLL_EDGE_ZONE
            if cursorY > (sbTopEdge - edgeZone) then
                local pct = SLV.scrollBox:GetScrollPercentage()
                if pct and pct > 0 then
                    SLV.scrollBox:SetScrollPercentage(math.max(0, pct - D().DRAG_SCROLL_INCREMENT))
                end
            elseif cursorY < (sbBottomEdge + edgeZone) then
                local pct = SLV.scrollBox:GetScrollPercentage()
                if pct and pct < 1 then
                    SLV.scrollBox:SetScrollPercentage(math.min(1, pct + D().DRAG_SCROLL_INCREMENT))
                end
            end
        end

        -- Calculate target position from cursor Y
        local sbTop = SLV.scrollBox:GetTop()
        if not sbTop then
            return
        end
        local rowH = D().STEP_ROW_HEIGHT
        local relativeY = sbTop - cursorY
        local targetIdx = math.floor(relativeY / rowH) + 1
        targetIdx = math.max(1, math.min(itemCount + 1, targetIdx))
        SLV._dragTargetIndex = targetIdx

        -- Position insertion indicator between rows
        local indicator = SLV.dragIndicator
        local anchorFrame, anchorPoint
        -- In outline mode, match by nodeIndex; in flat mode, match by index
        local matchKey = SLV._dragMode == "outline" and "nodeIndex" or "index"
        for _, frame in pairs({ SLV.scrollBox:GetChildren() }) do
            if frame._stepData then
                local frameIdx = frame._stepData[matchKey]
                if targetIdx <= itemCount and frameIdx == targetIdx then
                    anchorFrame = frame
                    anchorPoint = "TOPLEFT"
                    break
                elseif targetIdx > itemCount and frameIdx == itemCount then
                    anchorFrame = frame
                    anchorPoint = "BOTTOMLEFT"
                    break
                end
            end
        end
        if anchorFrame then
            indicator:ClearAllPoints()
            if anchorPoint == "TOPLEFT" then
                indicator:SetPoint("BOTTOMLEFT", anchorFrame, "TOPLEFT", 0, 0)
                indicator:SetPoint("BOTTOMRIGHT", anchorFrame, "TOPRIGHT", 0, 0)
            else
                indicator:SetPoint("TOPLEFT", anchorFrame, "BOTTOMLEFT", 0, 0)
                indicator:SetPoint("TOPRIGHT", anchorFrame, "BOTTOMRIGHT", 0, 0)
            end
            indicator:Show()
        else
            indicator:Hide()
        end
    end)
end

--- End a drag operation in the outline scrollBox. Performs the reorder.
--- @param button Frame The row frame that initiated the drag
function SLV:_endOutlineDrag(button)
    SLV._isDragging = false
    SLV.dragIndicator:Hide()

    local ghost = SLV.dragGhost
    ghost:SetScript("OnUpdate", nil)

    local src = SLV._dragSourceIndex
    local dst = SLV._dragTargetIndex
    local mode = SLV._dragMode or "flat"
    SLV._dragSourceIndex = nil
    SLV._dragTargetIndex = nil
    SLV._dragMode = nil

    local itemArray = mode == "outline" and SLV.workingActions or SLV.workingSteps
    local itemCount = itemArray and #itemArray or 0

    -- Clamp dst for cancel detection
    local clampedDst = dst
    if dst and src then
        clampedDst = math.max(1, math.min(itemCount, dst))
    end
    local isCancel = (not src or not dst or src == clampedDst)

    if isCancel then
        -- Snap-back animation
        if src then
            local startX, startY = ghost:GetCenter()
            local targetFrame
            local matchKey = mode == "outline" and "nodeIndex" or "index"
            for _, frame in pairs({ SLV.scrollBox:GetChildren() }) do
                if frame._stepData and frame._stepData[matchKey] == src then
                    targetFrame = frame
                    break
                end
            end
            if targetFrame and startX and startY then
                local targetX, targetY = targetFrame:GetCenter()
                if targetX and targetY then
                    local elapsed = 0
                    local duration = 0.15
                    ghost:SetScript("OnUpdate", function(_, dt)
                        elapsed = elapsed + dt
                        local t = math.min(elapsed / duration, 1)
                        t = 1 - (1 - t) * (1 - t)
                        local cx = startX + (targetX - startX) * t
                        local cy = startY + (targetY - startY) * t
                        ghost:ClearAllPoints()
                        ghost:SetPoint("CENTER", UIParent, "BOTTOMLEFT", cx, cy)
                        ghost:SetAlpha(0.7 * (1 - t))
                        if elapsed >= duration then
                            ghost:SetScript("OnUpdate", nil)
                            ghost:Hide()
                            ghost:SetAlpha(0.7)
                        end
                    end)
                    button:SetAlpha(1.0)
                    return
                end
            end
        end
        ghost:Hide()
        button:SetAlpha(1.0)
        return
    end

    -- Success path: perform reorder
    ghost:Hide()
    button:SetAlpha(1.0)

    dst = clampedDst
    local item = table.remove(itemArray, src)
    local insertAt = dst
    if dst > src then
        insertAt = dst - 1
    end
    table.insert(itemArray, insertAt, item)

    if mode == "flat" then
        SLV.selectedIndex = insertAt
    end

    -- Undo
    if not SLV._suppressUndo then
        local US = GRIPEMS.UndoStack
        if US then
            local fromSrc = src
            local toAt = insertAt
            local undoMode = mode
            US:Push(function()
                local arr = undoMode == "outline" and SLV.workingActions or SLV.workingSteps
                if arr then
                    local s = table.remove(arr, toAt)
                    local restoreAt = fromSrc
                    if fromSrc > toAt then
                        restoreAt = fromSrc
                    end
                    table.insert(arr, restoreAt, s)
                    if undoMode == "flat" then
                        SLV.selectedIndex = restoreAt
                    end
                end
                SLV:_markDirty()
                SLV:RefreshAll()
            end, function()
                local arr = undoMode == "outline" and SLV.workingActions or SLV.workingSteps
                if arr then
                    local s = table.remove(arr, fromSrc)
                    local redoAt = toAt
                    if toAt > fromSrc then
                        redoAt = toAt
                    end
                    table.insert(arr, redoAt, s)
                    if undoMode == "flat" then
                        SLV.selectedIndex = redoAt
                    end
                end
                SLV:_markDirty()
                SLV:RefreshAll()
            end, "Reorder " .. (undoMode == "outline" and "action" or "step"))
        end
    end

    SLV:_markDirty()
    SLV:RefreshAll()
end

---------------------------------------------------------------------------
-- Detail pane drag-to-reorder
---------------------------------------------------------------------------

--- Begin a drag in the detail pane children list.
--- @param row Frame The child row frame
--- @param childIndex number Index of the child in the children array
--- @param branchIndex number|nil For If nodes: 1=true, 2=false
function SLV:_beginDetailDrag(row, childIndex, branchIndex)
    if not SLV._detailNode then
        return
    end
    local defaults = D()
    local node = SLV._detailNode
    local children
    if node.type == defaults.ACTION_TYPE_IF and branchIndex then
        children = node.children and node.children[branchIndex]
    else
        children = node.children
    end
    if not children or #children <= 1 then
        return
    end

    SLV._detailDragSrc = childIndex
    SLV._detailDragBranch = branchIndex
    SLV._detailDragChildren = children
    SLV._isDragging = true

    -- Ghost
    local ghost = SLV.dragGhost
    ghost:SetWidth(SLV._detailScrollFrame and SLV._detailScrollFrame:GetWidth() or 200)
    local child = children[childIndex]
    if child and child.type == defaults.ACTION_TYPE_ACTION then
        ghost.ghostNum:SetText(tostring(childIndex))
        ghost.ghostText:SetText((child.macro or ""):match("^([^\n]*)") or "")
    else
        local iconInfo = defaults.NODE_ICONS[child and child.type or "loop"] or { symbol = "?", label = "Node" }
        ghost.ghostNum:SetText("[" .. iconInfo.symbol .. "]")
        ghost.ghostText:SetText(child and child.name ~= "" and child.name or iconInfo.label)
    end
    ghost:ClearAllPoints()
    ghost:SetAlpha(0.7)
    ghost:Show()
    row:SetAlpha(0.3)

    ghost:SetScript("OnUpdate", function()
        if not SLV._isDragging then
            ghost:SetScript("OnUpdate", nil)
            return
        end
        local scale = UIParent:GetEffectiveScale()
        local cursorX, cursorY = GetCursorPosition()
        cursorX = cursorX / scale
        cursorY = cursorY / scale
        ghost:ClearAllPoints()
        ghost:SetPoint("CENTER", UIParent, "BOTTOMLEFT", cursorX, cursorY)

        -- Calculate target from cursor position relative to detail scroll child
        if SLV._detailScrollChild then
            local scrollTop = SLV._detailScrollChild:GetTop()
            if scrollTop then
                local rowH = defaults.NODE_BADGE_HEIGHT
                local relY = scrollTop - cursorY
                local target = math.floor(relY / rowH) + 1
                target = math.max(1, math.min(#children + 1, target))
                SLV._detailDragTarget = target
            end
        end
    end)
end

--- End a drag in the detail pane. Performs the reorder.
--- @param row Frame The child row that was dragged
function SLV:_endDetailDrag(row)
    SLV._isDragging = false
    local ghost = SLV.dragGhost
    ghost:SetScript("OnUpdate", nil)
    ghost:Hide()
    row:SetAlpha(1.0)

    local src = SLV._detailDragSrc
    local dst = SLV._detailDragTarget
    local children = SLV._detailDragChildren
    SLV._detailDragSrc = nil
    SLV._detailDragTarget = nil
    SLV._detailDragBranch = nil
    SLV._detailDragChildren = nil

    if not src or not dst or not children then
        return
    end
    local clampedDst = math.max(1, math.min(#children, dst))
    if src == clampedDst then
        return
    end

    local item = table.remove(children, src)
    local insertAt = clampedDst
    if clampedDst > src then
        insertAt = clampedDst - 1
    end
    table.insert(children, insertAt, item)

    SLV:_markDirty()
    SLV:_renderDetailPane()
    SLV:RefreshAll()
end

--- Migrate a flat sequence (workingSteps) to action tree format.
--- Each existing step string becomes an ACTION_TYPE_ACTION node.
--- Called when the first structural node is inserted into a flat sequence.
--- One-way within the editing session; discard restores original flat steps.
--- @return table workingActions The newly created actions array
function SLV:_migrateToActions()
    local defaults = D()
    local actions = {}
    for _, step in ipairs(SLV.workingSteps) do
        actions[#actions + 1] = {
            type = defaults.ACTION_TYPE_ACTION,
            macro = step,
        }
    end

    -- Snapshot for undo
    local savedSteps = {}
    for i, s in ipairs(SLV.workingSteps) do
        savedSteps[i] = s
    end
    local savedHasActions = SLV.hasActions
    local savedTreeMode = SLV.treeMode

    SLV.workingActions = actions
    SLV.hasActions = true
    SLV.treeMode = true
    SLV.workingSteps = {}
    SLV.selectedIndex = nil
    SLV._editingContext = nil

    -- Push undo for the migration
    local US = GRIPEMS.UndoStack
    if US and not SLV._suppressUndo then
        US:Push(function()
            -- Undo: restore flat steps
            SLV.workingActions = nil
            SLV.hasActions = savedHasActions
            SLV.treeMode = savedTreeMode
            SLV.workingSteps = savedSteps
            SLV.selectedIndex = nil
            SLV._editingContext = nil
            SLV:_markDirty()
            SLV:RefreshAll()
        end, function()
            -- Redo: re-migrate
            SLV:_migrateToActions()
            SLV:_markDirty()
            SLV:RefreshAll()
        end, "Migrate to actions")
    end

    SLV:_markDirty()
    return SLV.workingActions
end

--- Show the + Add dropdown menu for creating new nodes.
--- Used by both the detail pane toolbar and outline actionBar.
--- @param anchor Frame The button to anchor the menu to
--- @param isDetailPane boolean True if called from detail pane, false if from outline
function SLV:_showAddMenu(anchor, isDetailPane)
    local defaults = D()
    MenuUtil.CreateContextMenu(anchor, function(_, rootDescription)
        rootDescription:CreateButton("Step", function()
            if isDetailPane then
                SLV:_detailAddChild(defaults.ACTION_TYPE_ACTION)
            else
                -- Outline: flat vs actions
                if SLV.hasActions then
                    SLV:AddAction(defaults.ACTION_TYPE_ACTION)
                else
                    SLV:AddStep()
                end
            end
        end)

        rootDescription:CreateDivider()

        local structTypes = {
            { key = defaults.ACTION_TYPE_LOOP, icon = "L", label = "Loop" },
            { key = defaults.ACTION_TYPE_PAUSE, icon = "P", label = "Pause" },
            { key = defaults.ACTION_TYPE_IF, icon = "?", label = "If" },
            { key = defaults.ACTION_TYPE_EMBED, icon = "E", label = "Embed" },
        }
        for _, def in ipairs(structTypes) do
            rootDescription:CreateButton("[" .. def.icon .. "] " .. def.label, function()
                if isDetailPane then
                    SLV:_detailAddChild(def.key)
                else
                    -- Outline: migrate if flat, then insert
                    if not SLV.hasActions then
                        SLV:_migrateToActions()
                    end
                    SLV:AddAction(def.key)
                    -- Auto-open detail pane for the new node and focus name
                    local newIdx = SLV.workingActions and #SLV.workingActions or 0
                    if newIdx > 0 then
                        SLV:OpenDetailPane(newIdx)
                        C_Timer.After(0, function()
                            if SLV._detailNameEditBox then
                                SLV._detailNameEditBox:SetFocus()
                            end
                        end)
                    end
                end
            end)
        end
    end)
end

--- Detail pane toolbar: add a new child of the given type to the current node.
--- @param nodeType string|nil One of D.ACTION_TYPE_* (defaults to ACTION_TYPE_ACTION)
function SLV:_detailAddChild(nodeType)
    if not SLV._detailNode then
        return
    end
    local defaults = D()
    local node = SLV._detailNode
    local newChild = defaults.NewActionNode(nodeType or defaults.ACTION_TYPE_ACTION)

    if node.type == defaults.ACTION_TYPE_IF then
        -- Add to the branch that has the selected child, or true by default
        local branch = SLV._detailSelectedBranch or 1
        if not node.children then
            node.children = { {}, {} }
        end
        if not node.children[branch] then
            node.children[branch] = {}
        end
        node.children[branch][#node.children[branch] + 1] = newChild
    else
        if not node.children then
            node.children = {}
        end
        node.children[#node.children + 1] = newChild
    end

    SLV:_markDirty()
    SLV:_renderDetailPane()
    SLV:RefreshAll()
end

--- Detail pane toolbar: duplicate the selected child.
function SLV:_detailDupChild()
    if not SLV._detailNode or not SLV._detailSelectedChild then
        return
    end
    local defaults = D()
    local node = SLV._detailNode
    local idx = SLV._detailSelectedChild
    local children

    if node.type == defaults.ACTION_TYPE_IF then
        local branch = SLV._detailSelectedBranch or 1
        children = node.children and node.children[branch]
    else
        children = node.children
    end

    if not children or not children[idx] then
        return
    end
    local copy = defaults.DeepCopyActions({ children[idx] })[1]
    table.insert(children, idx + 1, copy)

    SLV:_markDirty()
    SLV:_renderDetailPane()
    SLV:RefreshAll()
end

--- Detail pane toolbar: move selected child up or down.
--- @param direction number -1 for up, +1 for down
function SLV:_detailMoveChild(direction)
    if not SLV._detailNode or not SLV._detailSelectedChild then
        return
    end
    local defaults = D()
    local node = SLV._detailNode
    local idx = SLV._detailSelectedChild
    local children

    if node.type == defaults.ACTION_TYPE_IF then
        local branch = SLV._detailSelectedBranch or 1
        children = node.children and node.children[branch]
    else
        children = node.children
    end

    if not children then
        return
    end
    local target = idx + direction
    if target < 1 or target > #children then
        return
    end
    children[idx], children[target] = children[target], children[idx]
    SLV._detailSelectedChild = target

    SLV:_markDirty()
    SLV:_renderDetailPane()
    SLV:RefreshAll()
end

--- Detail pane toolbar: delete the selected child.
function SLV:_detailDeleteChild()
    if not SLV._detailNode or not SLV._detailSelectedChild then
        return
    end
    local defaults = D()
    local node = SLV._detailNode
    local idx = SLV._detailSelectedChild
    local children

    if node.type == defaults.ACTION_TYPE_IF then
        local branch = SLV._detailSelectedBranch or 1
        children = node.children and node.children[branch]
    else
        children = node.children
    end

    if not children or not children[idx] then
        return
    end
    table.remove(children, idx)
    SLV._detailSelectedChild = nil
    SLV._detailSelectedBranch = nil
    SLV._editingContext = nil

    SLV:_markDirty()
    SLV:_renderDetailPane()
    SLV:RefreshAll()
end

--- Clear the step list to empty state.
function SLV:Clear()
    SLV.workingSteps = {}
    SLV.originalSteps = {}
    SLV.selectedIndex = nil
    SLV._lastLineCount = 0
    SLV.treeMode = false
    SLV.hasActions = false
    SLV.workingActions = nil
    SLV._originalActionsSerialized = nil

    -- Reset detail pane state
    SLV._detailOpen = false
    SLV._detailNavStack = nil
    SLV._detailNode = nil
    SLV._detailNodeIndex = nil
    SLV._detailSelectedChild = nil
    SLV._detailSelectedBranch = nil
    SLV._editingContext = nil
    if SLV._detailContainer then
        SLV._detailContainer:Hide()
    end

    if SLV.scrollView then
        local dp = CreateDataProvider()
        SLV.scrollBox:SetDataProvider(dp)
        SLV.dataProvider = dp
    end

    if SLV.emptyIcon then
        SLV.emptyIcon:Show()
    end
    if SLV.emptyLabel then
        SLV.emptyLabel:Show()
    end
    if SLV.hintLabel then
        SLV.hintLabel:Show()
    end
    if SLV.editArea then
        SLV.editArea:Hide()
    end
    if SLV.selectLabel then
        SLV.selectLabel:Hide()
    end

    -- Reset scrollBox to full-width layout
    if SLV.scrollBox then
        SLV.scrollBox:ClearAllPoints()
        SLV.scrollBox:SetPoint("TOPLEFT", SLV.container, "TOPLEFT", 4, -4)
        SLV.scrollBox:SetPoint("RIGHT", SLV.container, "RIGHT", -18, 0)
        SLV.scrollBox:SetPoint("BOTTOM", SLV.actionBar, "TOP", 0, 4)
        SLV.scrollBox:Show()
    end
    if SLV.scrollBar then
        SLV.scrollBar:ClearAllPoints()
        SLV.scrollBar:SetPoint("TOPLEFT", SLV.scrollBox, "TOPRIGHT", 2, 0)
        SLV.scrollBar:SetPoint("BOTTOMLEFT", SLV.scrollBox, "BOTTOMRIGHT", 2, 0)
        SLV.scrollBar:Show()
    end
end

---------------------------------------------------------------------------
-- Button state management
---------------------------------------------------------------------------

--- Update enabled/disabled state of action buttons.
function SLV:UpdateButtonStates()
    if SLV._updatingButtons then
        return
    end
    SLV._updatingButtons = true

    local C = UI.Colors
    local sel = SLV.selectedIndex
    local count = #SLV.workingSteps

    local treeNi, treeCount
    if SLV.hasActions and SLV.workingActions then
        treeNi = (SLV._editingContext and SLV._editingContext.nodeIndex) or (SLV._detailOpen and SLV._detailNodeIndex)
        treeCount = #SLV.workingActions
    end

    local function setEnabled(btn, enabled)
        if not btn then
            return
        end
        if enabled then
            btn:Enable()
            btn.label:SetTextColor(C.textPrimary:GetRGBA())
            btn:SetBackdropColor(C.bgButton:GetRGBA())
            btn:SetBackdropBorderColor(C.border:GetRGBA())
        else
            btn:Disable()
            btn.label:SetTextColor(C.textMuted:GetRGBA())
            btn:SetBackdropColor(C.bgDeep:GetRGBA())
            btn:SetBackdropBorderColor(C.border:GetRGBA())
        end
    end

    -- Add is always enabled
    setEnabled(SLV.actionButtons["add"], true)
    -- Dup/Del need selection (tree nodeIndex or flat selectedIndex)
    setEnabled(SLV.actionButtons["dup"], sel ~= nil or treeNi ~= nil)
    setEnabled(SLV.actionButtons["del"], sel ~= nil or treeNi ~= nil)
    -- Up needs selection and not first
    setEnabled(SLV.actionButtons["up"], (treeNi and treeNi > 1) or (sel ~= nil and sel > 1))
    -- Down needs selection and not last
    setEnabled(SLV.actionButtons["down"], (treeNi and treeNi < treeCount) or (sel ~= nil and sel < count))

    SLV._updatingButtons = false
end

---------------------------------------------------------------------------
-- Edit area management
---------------------------------------------------------------------------

--- Update the edit area based on current selection.
function SLV:UpdateEditArea()
    if SLV.autocompleteDropdown then
        SLV.autocompleteDropdown:Hide()
    end
    if not SLV.editArea then
        return
    end

    local defaults = D()
    local ctx = SLV._editingContext

    -- Detail pane editing context
    if ctx and ctx.source == "detail" then
        if SLV.ilRow then SLV.ilRow:Hide() end
        if SLV.editBox then
            SLV.editBox:SetPoint("TOPLEFT", SLV.editHeader, "BOTTOMLEFT", 0, -4)
        end
        local childNode = SLV:_resolveDetailChild(ctx.childIndex, ctx.branchIndex)
        if not childNode then
            SLV._editingContext = nil
            SLV.editArea:Show()
            if SLV.editBox then
                SLV.editBox:Hide()
            end
            if SLV.selectLabel then
                SLV.selectLabel:Show()
            end
            return
        end

        SLV.editArea:Show()
        if SLV.selectLabel then
            SLV.selectLabel:Hide()
        end
        if SLV.editBox then
            SLV.editBox:Show()
        end

        local text = childNode.macro or ""
        if SLV.editHeader then
            SLV.editHeader:SetText(ctx.label or "Action:")
        end
        SLV:UpdateEditCharCount(#text)

        if SLV.editBox then
            SLV.editBox._shBusy = true
            SLV.editBox:SetScript("OnTextChanged", nil)
            SLV.editBox:SetText(text)
            SLV._lastLineCount = select(2, text:gsub("\n", "")) + 1

            SLV.editBox:SetScript("OnTextChanged", function(self, userInput)
                if not userInput then
                    return
                end
                local curCtx = SLV._editingContext
                if not curCtx or curCtx.source ~= "detail" then
                    return
                end
                local curChild = SLV:_resolveDetailChild(curCtx.childIndex, curCtx.branchIndex)
                if not curChild then
                    return
                end
                local newText = self:GetText() or ""
                curChild.macro = newText
                SLV:UpdateEditCharCount(#newText)
                SLV:_markDirty()

                local numLines = select(2, newText:gsub("\n", "")) + 1
                if numLines ~= SLV._lastLineCount then
                    SLV._lastLineCount = numLines
                    local lineHeight = 14
                    local desiredH = math.max(
                        defaults.STEP_EDIT_HEIGHT_MIN,
                        math.min(defaults.STEP_EDIT_HEIGHT_MAX, numLines * lineHeight + 8)
                    )
                    self:SetHeight(desiredH)
                end
                SLV:RefreshAutocomplete(self)
            end)
            SLV.editBox._shBusy = false
        end
        return
    end

    -- Outline mode: step row clicked (hasActions = true)
    if ctx and ctx.source == "outline" and SLV.hasActions and SLV.workingActions then
        local nodeIdx = ctx.nodeIndex
        local actionNode = SLV.workingActions[nodeIdx]
        if not actionNode or actionNode.type ~= defaults.ACTION_TYPE_ACTION then
            if SLV.ilRow then SLV.ilRow:Hide() end
            if SLV.editBox then
                SLV.editBox:SetPoint("TOPLEFT", SLV.editHeader, "BOTTOMLEFT", 0, -4)
            end
            SLV._editingContext = nil
            SLV.editArea:Show()
            if SLV.editBox then
                SLV.editBox:Hide()
            end
            if SLV.selectLabel then
                SLV.selectLabel:Show()
            end
            return
        end

        SLV.editArea:Show()
        if SLV.selectLabel then
            SLV.selectLabel:Hide()
        end
        if SLV.editBox then
            SLV.editBox:Show()
        end

        local text = actionNode.macro or ""
        if SLV.editHeader then
            SLV.editHeader:SetText(ctx.label or "Step:")
        end
        SLV:UpdateEditCharCount(#text)

        -- Interleave controls
        if SLV.ilRow then
            local hasIL = actionNode.interval and actionNode.interval >= defaults.ACTION_INTERLEAVE_MIN
            SLV.ilRow:Show()
            SLV.ilCheck:SetChecked(hasIL)
            if hasIL then
                SLV.ilSpinner:SetText(tostring(actionNode.interval))
                SLV.ilSpinner:Show()
                SLV.ilStepsLabel:Show()
            else
                SLV.ilSpinner:Hide()
                SLV.ilStepsLabel:Hide()
            end
            SLV.ilCheck:SetScript("OnClick", function(self)
                if self:GetChecked() then
                    actionNode.interval = defaults.ACTION_INTERLEAVE_DEFAULT
                else
                    actionNode.interval = nil
                end
                SLV:_markDirty()
                SLV:UpdateEditArea()
                SLV:DebouncedRefreshCurrentRow()
            end)
            SLV.ilSpinner:SetScript("OnTextChanged", function(self, userInput)
                if not userInput then return end
                local val = tonumber(self:GetText()) or defaults.ACTION_INTERLEAVE_DEFAULT
                if val < defaults.ACTION_INTERLEAVE_MIN then val = defaults.ACTION_INTERLEAVE_MIN end
                if val > defaults.ACTION_INTERLEAVE_MAX then val = defaults.ACTION_INTERLEAVE_MAX end
                actionNode.interval = val
                SLV:_markDirty()
                SLV:DebouncedRefreshCurrentRow()
            end)
            SLV.ilSpinner:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
            -- Re-anchor editBox below ilRow
            SLV.editBox:SetPoint("TOPLEFT", SLV.ilRow, "BOTTOMLEFT", 0, -4)
        end

        if SLV.editBox then
            SLV.editBox._shBusy = true
            SLV.editBox:SetScript("OnTextChanged", nil)
            SLV.editBox:SetText(text)
            SLV._lastLineCount = select(2, text:gsub("\n", "")) + 1

            SLV.editBox:SetScript("OnTextChanged", function(self, userInput)
                if not userInput then
                    return
                end
                local curCtx = SLV._editingContext
                if not curCtx or curCtx.source ~= "outline" then
                    return
                end
                local curNode = SLV.workingActions[curCtx.nodeIndex]
                if not curNode then
                    return
                end
                local newText = self:GetText() or ""
                curNode.macro = newText
                SLV:UpdateEditCharCount(#newText)
                SLV:_markDirty()

                local numLines = select(2, newText:gsub("\n", "")) + 1
                if numLines ~= SLV._lastLineCount then
                    SLV._lastLineCount = numLines
                    local lineHeight = 14
                    local desiredH = math.max(
                        defaults.STEP_EDIT_HEIGHT_MIN,
                        math.min(defaults.STEP_EDIT_HEIGHT_MAX, numLines * lineHeight + 8)
                    )
                    self:SetHeight(desiredH)
                end
                SLV:DebouncedRefreshCurrentRow()
                SLV:RefreshAutocomplete(self)
            end)
            SLV.editBox._shBusy = false
        end
        return
    end

    -- Flat mode (no actions): original behavior
    if #SLV.workingSteps == 0 and not (SLV.hasActions and SLV.workingActions) then
        if SLV.ilRow then SLV.ilRow:Hide() end
        if SLV.editBox then
            SLV.editBox:SetPoint("TOPLEFT", SLV.editHeader, "BOTTOMLEFT", 0, -4)
        end
        SLV.editArea:Hide()
        if SLV.selectLabel then
            SLV.selectLabel:Hide()
        end
        return
    end

    if not SLV.selectedIndex then
        if SLV.ilRow then SLV.ilRow:Hide() end
        if SLV.editBox then
            SLV.editBox:SetPoint("TOPLEFT", SLV.editHeader, "BOTTOMLEFT", 0, -4)
        end
        SLV.editArea:Show()
        if SLV.editBox then
            SLV.editBox:Hide()
        end
        if SLV.editHeader then
            SLV.editHeader:SetText("")
        end
        if SLV.editCharCount then
            SLV.editCharCount:SetText("")
        end
        if SLV.selectLabel then
            SLV.selectLabel:Show()
        end
        return
    end

    -- Flat step is selected
    if SLV.ilRow then SLV.ilRow:Hide() end
    if SLV.editBox then
        SLV.editBox:SetPoint("TOPLEFT", SLV.editHeader, "BOTTOMLEFT", 0, -4)
    end
    SLV.editArea:Show()
    if SLV.selectLabel then
        SLV.selectLabel:Hide()
    end
    if SLV.editBox then
        SLV.editBox:Show()
    end

    local idx = SLV.selectedIndex
    local text = SLV.workingSteps[idx] or ""

    if SLV.editHeader then
        SLV.editHeader:SetText(string.format(L["GEMS_UI_STEP_HEADER"], idx))
    end

    SLV:UpdateEditCharCount(#text)

    if SLV.editBox then
        SLV.editBox._shBusy = true
        SLV.editBox:SetScript("OnTextChanged", nil)
        SLV.editBox:SetText(text)
        SLV._lastLineCount = select(2, text:gsub("\n", "")) + 1

        SLV.editBox:SetScript("OnTextChanged", function(self, userInput)
            if not userInput then
                return
            end
            if not SLV.selectedIndex then
                return
            end
            local newText = self:GetText() or ""
            SLV.workingSteps[SLV.selectedIndex] = newText
            SLV:UpdateEditCharCount(#newText)
            local SE = GRIPEMS.SequenceEditor
            if SE then
                SE.isDirty = true
                SE:UpdateSaveButtons()
            end

            local numLines = select(2, newText:gsub("\n", "")) + 1
            if numLines ~= SLV._lastLineCount then
                SLV._lastLineCount = numLines
                local lineHeight = 14
                local desiredH = math.max(
                    defaults.STEP_EDIT_HEIGHT_MIN,
                    math.min(defaults.STEP_EDIT_HEIGHT_MAX, numLines * lineHeight + 8)
                )
                self:SetHeight(desiredH)
            end

            SLV:DebouncedRefreshCurrentRow()
            SLV:RefreshAutocomplete(self)
        end)
        SLV.editBox._shBusy = false
    end
end

--- Resolve a child node from the detail pane context.
--- @param childIndex number Index in children array
--- @param branchIndex number|nil For If nodes: 1=true, 2=false
--- @return table|nil child The child node or nil
function SLV:_resolveDetailChild(childIndex, branchIndex)
    if not SLV._detailNode then
        return nil
    end
    local defaults = D()
    local node = SLV._detailNode
    local children
    if node.type == defaults.ACTION_TYPE_IF and branchIndex then
        children = node.children and node.children[branchIndex]
    else
        children = node.children
    end
    if not children then
        return nil
    end
    return children[childIndex]
end

--- Update the char count display in the edit area.
--- @param count number Character count
function SLV:UpdateEditCharCount(count)
    if not SLV.editCharCount then
        return
    end
    local C = UI.Colors
    local defaults = D()
    local kpCost = (SLV.keyPressLen or 0) > 0 and (SLV.keyPressLen + 1) or 0
    local krCost = (SLV.keyReleaseLen or 0) > 0 and (SLV.keyReleaseLen + 1) or 0
    local displayCount = count
    if kpCost > 0 or krCost > 0 then
        displayCount = count + kpCost + krCost
    end

    SLV.editCharCount:SetText(string.format("%d/%d", displayCount, defaults.CHAR_COUNT_DANGER))

    if displayCount >= defaults.CHAR_COUNT_DANGER then
        SLV.editCharCount:SetTextColor(C.textError:GetRGBA())
    elseif displayCount > defaults.CHAR_COUNT_WARNING then
        SLV.editCharCount:SetTextColor(C.textWarning:GetRGBA())
    else
        SLV.editCharCount:SetTextColor(C.textSuccess:GetRGBA())
    end
end

---------------------------------------------------------------------------
-- Debounced row refresh (coalesces rapid OnTextChanged calls)
---------------------------------------------------------------------------

--- Debounce wrapper for RefreshCurrentRow. Coalesces rapid keystroke
--- updates into a single refresh after 0.1s idle. Used by OnTextChanged
--- handlers; autocomplete click handlers call RefreshCurrentRow directly.
function SLV:DebouncedRefreshCurrentRow()
    if self._refreshRowTimer then
        self._refreshRowTimer:Cancel()
    end
    self._refreshRowTimer = C_Timer.NewTimer(0.1, function()
        self._refreshRowTimer = nil
        self:RefreshCurrentRow()
    end)
end

---------------------------------------------------------------------------
-- Lightweight row refresh (flicker-free keystroke updates)
---------------------------------------------------------------------------

--- Lightweight refresh: update only the scroll row matching the
--- selected step. Does NOT rebuild the DataProvider or touch the
--- EditBox. Use this from OnTextChanged to avoid flicker.
function SLV:RefreshCurrentRow()
    if debugSkipRowRefresh then
        return
    end
    if not SLV.selectedIndex or not SLV.scrollBox then
        return
    end
    local idx = SLV.selectedIndex
    local text = SLV.workingSteps[idx] or ""

    -- GetChildren returns all child frames; scroll box children
    -- include the visible row frames managed by the DataProvider.
    for _, frame in pairs({ SLV.scrollBox:GetChildren() }) do
        if frame._stepData and frame._stepData.index == idx then
            -- Update displayed text and char count
            if frame.stepText then
                frame.stepText:SetText(text)
            end
            local count = #text
            if frame.charCount then
                local C = UI.Colors
                local defaults = D()
                local kpCost = (SLV.keyPressLen or 0) > 0 and (SLV.keyPressLen + 1) or 0
                local krCost = (SLV.keyReleaseLen or 0) > 0 and (SLV.keyReleaseLen + 1) or 0
                local displayCount = count
                if kpCost > 0 or krCost > 0 then
                    displayCount = count + kpCost + krCost
                end
                frame.charCount:SetText(string.format("%d/%d", displayCount, defaults.CHAR_COUNT_DANGER))
                if displayCount >= defaults.CHAR_COUNT_DANGER then
                    frame.charCount:SetTextColor(C.textError:GetRGBA())
                elseif displayCount > defaults.CHAR_COUNT_WARNING then
                    frame.charCount:SetTextColor(C.textWarning:GetRGBA())
                else
                    frame.charCount:SetTextColor(C.textSuccess:GetRGBA())
                end
            end
            -- Update stored data reference
            frame._stepData.text = text
            frame._stepData.charCount = count
            break -- found our frame, stop iterating
        end
    end
end

--- Toggle the debugSkipRowRefresh flag (flicker diagnostic).
--- @return boolean New state (true = RefreshCurrentRow is DISABLED)
function SLV:ToggleDebugRowRefresh()
    debugSkipRowRefresh = not debugSkipRowRefresh
    return debugSkipRowRefresh
end

---------------------------------------------------------------------------
-- Undo text snapshot flush
---------------------------------------------------------------------------

--- Flush a pending text-edit undo snapshot (called on focus lost or step change).
function SLV:FlushTextUndoSnapshot()
    if SLV._undoTextSnapshot ~= nil and not SLV._suppressUndo then
        local oldText = SLV._undoTextSnapshot
        local snapIdx = SLV._undoTextSnapshotIdx
        local newText = SLV.workingSteps and SLV.workingSteps[snapIdx]
        if newText and oldText ~= newText then
            local US = GRIPEMS.UndoStack
            if US then
                US:Push(function()
                    SLV.workingSteps[snapIdx] = oldText
                    SLV.selectedIndex = snapIdx
                    SLV:RefreshAll()
                    local SE = GRIPEMS.SequenceEditor
                    if SE then
                        SE.isDirty = true
                        SE:UpdateSaveButtons()
                    end
                end, function()
                    SLV.workingSteps[snapIdx] = newText
                    SLV.selectedIndex = snapIdx
                    SLV:RefreshAll()
                    local SE = GRIPEMS.SequenceEditor
                    if SE then
                        SE.isDirty = true
                        SE:UpdateSaveButtons()
                    end
                end, "Edit step text")
            end
        end
    end
    SLV._undoTextSnapshot = nil
    SLV._undoTextSnapshotIdx = nil
    SLV._preEditText = nil
end

---------------------------------------------------------------------------
-- Step operations
---------------------------------------------------------------------------

--- Add a new empty step after the selected step (or at end).
function SLV:AddStep()
    local pos = (SLV.selectedIndex or #SLV.workingSteps) + 1
    table.insert(SLV.workingSteps, pos, "")
    SLV.selectedIndex = pos

    if not SLV._suppressUndo then
        local US = GRIPEMS.UndoStack
        if US then
            local addedIdx = pos
            US:Push(function()
                table.remove(SLV.workingSteps, addedIdx)
                if SLV.selectedIndex and SLV.selectedIndex >= addedIdx then
                    SLV.selectedIndex = math.max(1, addedIdx - 1)
                end
                if #SLV.workingSteps == 0 then
                    SLV.selectedIndex = nil
                end
                local SE = GRIPEMS.SequenceEditor
                if SE then
                    SE.isDirty = true
                    SE:UpdateSaveButtons()
                end
                SLV:RefreshAll()
            end, function()
                table.insert(SLV.workingSteps, addedIdx, "")
                SLV.selectedIndex = addedIdx
                local SE = GRIPEMS.SequenceEditor
                if SE then
                    SE.isDirty = true
                    SE:UpdateSaveButtons()
                end
                SLV:RefreshAll()
            end, "Add step")
        end
    end

    local SE = GRIPEMS.SequenceEditor
    if SE then
        SE.isDirty = true
        SE:UpdateSaveButtons()
    end

    SLV:RefreshAll()

    -- Focus the EditBox after a frame delay
    C_Timer.After(0, function()
        if SLV.editBox then
            SLV.editBox:SetFocus()
        end
    end)
end

--- Duplicate the selected step.
function SLV:DuplicateStep()
    if not SLV.selectedIndex then
        return
    end
    local copy = SLV.workingSteps[SLV.selectedIndex]
    local dupIdx = SLV.selectedIndex + 1
    table.insert(SLV.workingSteps, dupIdx, copy)
    SLV.selectedIndex = dupIdx

    if not SLV._suppressUndo then
        local US = GRIPEMS.UndoStack
        if US then
            local di = dupIdx
            local dupText = copy
            US:Push(function()
                table.remove(SLV.workingSteps, di)
                if SLV.selectedIndex and SLV.selectedIndex >= di then
                    SLV.selectedIndex = math.max(1, di - 1)
                end
                if #SLV.workingSteps == 0 then
                    SLV.selectedIndex = nil
                end
                local SE = GRIPEMS.SequenceEditor
                if SE then
                    SE.isDirty = true
                    SE:UpdateSaveButtons()
                end
                SLV:RefreshAll()
            end, function()
                table.insert(SLV.workingSteps, di, dupText)
                SLV.selectedIndex = di
                local SE = GRIPEMS.SequenceEditor
                if SE then
                    SE.isDirty = true
                    SE:UpdateSaveButtons()
                end
                SLV:RefreshAll()
            end, "Duplicate step")
        end
    end

    local SE = GRIPEMS.SequenceEditor
    if SE then
        SE.isDirty = true
        SE:UpdateSaveButtons()
    end

    SLV:RefreshAll()
end

--- Move the selected step up.
function SLV:MoveStepUp()
    if not SLV.selectedIndex or SLV.selectedIndex <= 1 then
        return
    end
    if not SLV.workingSteps then
        return
    end
    local fromIdx = SLV.selectedIndex
    local i = SLV.selectedIndex
    SLV.workingSteps[i], SLV.workingSteps[i - 1] = SLV.workingSteps[i - 1], SLV.workingSteps[i]
    SLV.selectedIndex = i - 1

    if not SLV._suppressUndo then
        local US = GRIPEMS.UndoStack
        if US then
            local fi = fromIdx
            US:Push(function()
                local a = fi - 1
                SLV.workingSteps[a], SLV.workingSteps[fi] = SLV.workingSteps[fi], SLV.workingSteps[a]
                SLV.selectedIndex = fi
                local SE = GRIPEMS.SequenceEditor
                if SE then
                    SE.isDirty = true
                    SE:UpdateSaveButtons()
                end
                SLV:RefreshAll()
            end, function()
                SLV.workingSteps[fi], SLV.workingSteps[fi - 1] = SLV.workingSteps[fi - 1], SLV.workingSteps[fi]
                SLV.selectedIndex = fi - 1
                local SE = GRIPEMS.SequenceEditor
                if SE then
                    SE.isDirty = true
                    SE:UpdateSaveButtons()
                end
                SLV:RefreshAll()
            end, "Move step up")
        end
    end

    local SE = GRIPEMS.SequenceEditor
    if SE then
        SE.isDirty = true
        SE:UpdateSaveButtons()
    end

    SLV:RefreshAll()
end

--- Move the selected step down.
function SLV:MoveStepDown()
    if not SLV.workingSteps then
        return
    end
    if not SLV.selectedIndex or SLV.selectedIndex >= #SLV.workingSteps then
        return
    end
    local fromIdx = SLV.selectedIndex
    local i = SLV.selectedIndex
    SLV.workingSteps[i], SLV.workingSteps[i + 1] = SLV.workingSteps[i + 1], SLV.workingSteps[i]
    SLV.selectedIndex = i + 1

    if not SLV._suppressUndo then
        local US = GRIPEMS.UndoStack
        if US then
            local fi = fromIdx
            US:Push(function()
                local a = fi + 1
                SLV.workingSteps[fi], SLV.workingSteps[a] = SLV.workingSteps[a], SLV.workingSteps[fi]
                SLV.selectedIndex = fi
                local SE = GRIPEMS.SequenceEditor
                if SE then
                    SE.isDirty = true
                    SE:UpdateSaveButtons()
                end
                SLV:RefreshAll()
            end, function()
                SLV.workingSteps[fi], SLV.workingSteps[fi + 1] = SLV.workingSteps[fi + 1], SLV.workingSteps[fi]
                SLV.selectedIndex = fi + 1
                local SE = GRIPEMS.SequenceEditor
                if SE then
                    SE.isDirty = true
                    SE:UpdateSaveButtons()
                end
                SLV:RefreshAll()
            end, "Move step down")
        end
    end

    local SE = GRIPEMS.SequenceEditor
    if SE then
        SE.isDirty = true
        SE:UpdateSaveButtons()
    end

    SLV:RefreshAll()
end

--- Delete the selected step (with confirmation).
function SLV:DeleteStep()
    if not SLV.selectedIndex then
        return
    end
    local idx = SLV.selectedIndex
    local removedText = SLV.workingSteps[idx]

    StaticPopupDialogs["GRIPEMS_DELETE_STEP"] = {
        text = string.format(L["GEMS_UI_DELETE_STEP_CONFIRM"], idx),
        button1 = ACCEPT,
        button2 = CANCEL,
        OnAccept = function()
            table.remove(SLV.workingSteps, idx)
            if idx > #SLV.workingSteps then
                SLV.selectedIndex = #SLV.workingSteps > 0 and #SLV.workingSteps or nil
            end

            if not SLV._suppressUndo then
                local US = GRIPEMS.UndoStack
                if US then
                    local di = idx
                    local dt = removedText
                    US:Push(function()
                        table.insert(SLV.workingSteps, di, dt)
                        SLV.selectedIndex = di
                        local SE = GRIPEMS.SequenceEditor
                        if SE then
                            SE.isDirty = true
                            SE:UpdateSaveButtons()
                        end
                        SLV:RefreshAll()
                    end, function()
                        table.remove(SLV.workingSteps, di)
                        if di > #SLV.workingSteps then
                            SLV.selectedIndex = #SLV.workingSteps > 0 and #SLV.workingSteps or nil
                        else
                            SLV.selectedIndex = di
                        end
                        local SE = GRIPEMS.SequenceEditor
                        if SE then
                            SE.isDirty = true
                            SE:UpdateSaveButtons()
                        end
                        SLV:RefreshAll()
                    end, "Delete step")
                end
            end

            local SE = GRIPEMS.SequenceEditor
            if SE then
                SE.isDirty = true
                SE:UpdateSaveButtons()
            end

            SLV:RefreshAll()
        end,
        timeout = 0,
        whileDead = true,
        hideOnEscape = true,
    }
    StaticPopup_Show("GRIPEMS_DELETE_STEP")
end

---------------------------------------------------------------------------
-- Tree mode operations (v1.2.0 S14-B)
---------------------------------------------------------------------------

--- Resolve a tree path (array of indices) to the parent array and target index.
--- Path examples: {2} = actions[2], {2,1} = actions[2].children[1]
--- @param path table Array of 1-based indices into the tree
--- @return table|nil parentArray The array containing the target node
--- @return number|nil targetIndex Index within parentArray
function SLV:_resolveTreePath(path)
    if not path or #path == 0 or not SLV.workingActions then
        return nil, nil
    end
    local current = SLV.workingActions
    for i = 1, #path - 1 do
        local idx = path[i]
        local node = current[idx]
        if not node then
            return nil, nil
        end
        if node.type == D().ACTION_TYPE_IF then
            -- Next index selects branch (1 = true, 2 = false)
            i = i + 1
            if i > #path - 1 then
                -- The branch itself is the parent
                local branchIdx = path[i] or 1
                current = node.children and node.children[branchIdx] or {}
                return current, path[#path]
            end
            local branchIdx = path[i]
            current = node.children and node.children[branchIdx] or {}
        else
            current = node.children or {}
        end
    end
    return current, path[#path]
end

--- Add an action node of the given type at the specified tree path.
--- If parentPath is nil, appends to the root actions array.
--- @param nodeType string One of D().ACTION_TYPE_* constants
--- @param parentPath table|nil Array of indices into the tree
function SLV:AddAction(nodeType, parentPath)
    if not SLV.workingActions then
        return
    end
    local newNode = D().NewActionNode(nodeType)
    if not parentPath or #parentPath == 0 then
        SLV.workingActions[#SLV.workingActions + 1] = newNode
    else
        local parentArray = SLV:_resolveTreePath(parentPath)
        if parentArray then
            parentArray[#parentArray + 1] = newNode
        end
    end

    local SE = GRIPEMS.SequenceEditor
    if SE then
        SE.isDirty = true
        SE:UpdateSaveButtons()
    end
    SLV:RefreshAll()
end

--- Delete the action node at the given tree path.
--- @param path table Array of indices into the tree
function SLV:DeleteAction(path)
    if not path or #path == 0 or not SLV.workingActions then
        return
    end
    local parentArray, targetIndex = SLV:_resolveTreePath(path)
    if parentArray and targetIndex and parentArray[targetIndex] then
        table.remove(parentArray, targetIndex)
        local SE = GRIPEMS.SequenceEditor
        if SE then
            SE.isDirty = true
            SE:UpdateSaveButtons()
        end
        SLV:RefreshAll()
    end
end

--- Move the action node at the given path up or down within its parent.
--- @param path table Array of indices into the tree
--- @param direction number -1 for up, 1 for down
function SLV:MoveAction(path, direction)
    if not path or #path == 0 or not SLV.workingActions then
        return
    end
    local parentArray, targetIndex = SLV:_resolveTreePath(path)
    if not parentArray or not targetIndex then
        return
    end
    local newIndex = targetIndex + direction
    if newIndex < 1 or newIndex > #parentArray then
        return
    end
    parentArray[targetIndex], parentArray[newIndex] = parentArray[newIndex], parentArray[targetIndex]
    local SE = GRIPEMS.SequenceEditor
    if SE then
        SE.isDirty = true
        SE:UpdateSaveButtons()
    end
    SLV:RefreshAll()
end
