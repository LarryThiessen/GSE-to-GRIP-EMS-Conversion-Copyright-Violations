-- GRIP-EMS: Settings
-- AceDB-3.0 profile-based settings with migration from legacy storage

local ADDON_NAME, GRIPEMS = ...

GRIPEMS.Settings = {}
local S = GRIPEMS.Settings

-- AceDB defaults (profile-scoped)
S.defaults = {
    profile = {
        oocDelay = 7, -- seconds for OOC fallback ticker (1-60)
        resetOOC = true, -- default resetOnCombat for new sequences
        debug = false, -- debug logging to chat
        hideLoginMsg = false, -- suppress login banner
        p2pEnabled = true, -- enable/disable P2P transmission
        p2pAutoAcceptFriends = false, -- auto-import from friends (no prompt)
        p2pAnnounceReceive = true, -- print chat message on receive
        trackerShowMode = "NEVER", -- ALWAYS, COMBAT, TARGET, NEVER
        trackerIconSize = 40, -- icon pixel size (20-80)
        trackerOrientation = "HORIZONTAL", -- HORIZONTAL or VERTICAL
        trackerShowName = true, -- show sequence name below icon
        trackerShowModifiers = false, -- show active modifier keys
        trackerLocked = false, -- lock tracker frame position
        trackerScale = 1.0, -- HUD frame scale (0.5-2.0)
        listSortMode = "alpha", -- sequence list sort: alpha, class, updated
        previewMode = "icons", -- rotation preview: icons or text
        msClickRate = 250, -- minimum ms between key presses
        sqwOptimizerEnabled = false, -- dynamic SQW optimizer toggle
        sqwBuffer = 100, -- SQW optimizer safety buffer (ms)
        sqwShowAdvisory = true, -- show SQW click rate advisory
        mythicPlusTierMid = 8, -- M+ key level: Low -> Mid threshold
        mythicPlusTierHigh = 12, -- M+ key level: Mid -> High threshold
        delvesTierHigh = 5, -- Delve tier: Low -> High threshold
        macroResetModifiers = {}, -- empty = all false (defaults from D.MACRO_RESET_MODIFIER_DEFAULTS)
        autoFixCVars = false, -- auto-set recommended CVars on login
        cvarAutoFixEntries = {}, -- per-CVar auto-fix opt-in: {["CvarName"] = true}
        cvarSnapshot = {}, -- last-known CVar values for What Changed detection
        cvarSectionCollapsed = {}, -- collapsed state per section key
        cvarProfiles = {}, -- custom user-created CVar profiles
        cvarProfileMap = {}, -- user overrides: {[contextKey] = profileKey}
        cvarAutoSwitchEnabled = false, -- master toggle for context auto-switching
        cvarActiveProfile = nil, -- currently active profile key (nil = General)
        cvarManualOverride = false, -- true if user manually selected a profile
        syntaxCommandColor = { 0.306, 0.788, 0.690 }, -- #4EC9B0 teal
        syntaxConditionalColor = { 0.773, 0.525, 0.753 }, -- #C586C0 purple
        syntaxVariableColor = { 0.863, 0.863, 0.667 }, -- #DCDCAA gold
        syntaxCommentColor = { 0.416, 0.600, 0.333 }, -- #6A9955 green-grey
        syntaxResetColor = { 0.808, 0.569, 0.471 }, -- #CE9178 orange
        syntaxNumberColor = { 0.710, 0.808, 0.659 }, -- #B5CEA8 light green
        recorderDedup = false, -- deduplicate consecutive identical casts
        floatingMenuShow = false,
        floatingMenuDirection = "DOWN",
        floatingMenuLocked = false,
        floatingMenuScale = 1.0,
        spellOverrides = {},
        contextGroupCollapsed = {}, -- collapsed state per context group header
        barIntegration = true, -- show sequence icons on action bar buttons
        tempoAutoSet = true, -- auto-adjust click rate per sequence
        tempoAlertEnabled = false, -- mismatch alerts off by default
        tempoAlertVisual = true, -- visual alerts when alerts enabled
        tempoAlertAudio = true, -- audio alerts when alerts enabled
        tempoAlertSoundSlow = 43505, -- Raid Warning
        tempoAlertSoundFast = 37666, -- Toast Notification
        tempoAlertChannel = "Master", -- audio channel for alerts
        tempoAlertSlowThreshold = 0.6, -- slow CPS threshold ratio
        tempoAlertFastThreshold = 2.0, -- fast CPS threshold ratio
        tempoSparkline = false, -- CPS sparkline off by default
        tempoOverlayShown = false, -- popout overlay hidden by default
        tempoAdvisorDebug = false, -- TA verbose debug output
        sqwDebug = false, -- SQW optimizer debug output
        holdModeEnabled = false, -- master toggle for hold-to-cast mode
        holdModeSlot = "MultiBar7Button12", -- native button to hijack
        holdModePollRateMin = 50, -- ms floor for poll rate CVar
    },
}

--- Initialize the AceDB instance and migrate legacy settings.
--- Called from Core.lua ADDON_LOADED after raw SavedVariables init.
function S:Initialize()
    local ok, db = pcall(function()
        return LibStub("AceDB-3.0"):New("GRIP_EMS_Settings", self.defaults, true)
    end)
    if not ok or not db then
        GRIPEMS:Debug("Settings: AceDB init failed -- using defaults only")
        return
    end
    self.db = db

    -- Migration: debug flag from per-char config
    if
        _G.GRIP_EMS_CHAR
        and GRIP_EMS_CHAR.config
        and GRIP_EMS_CHAR.config.debug == true
        and self.db.profile.debug == false
    then
        self.db.profile.debug = true
    end
    if _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.config then
        GRIP_EMS_CHAR.config = nil
    end

    -- Migration: legacy GRIP_EMS_DB.settings (previous dev builds)
    if _G.GRIP_EMS_DB and GRIP_EMS_DB.settings then
        for k, v in pairs(GRIP_EMS_DB.settings) do
            if self.defaults.profile[k] ~= nil then
                self.db.profile[k] = v
            end
        end
        GRIP_EMS_DB.settings = nil
    end

    -- Register profile callbacks so UI updates on profile switch
    self.db.RegisterCallback(self, "OnProfileChanged", "OnProfileChanged")
    self.db.RegisterCallback(self, "OnProfileCopied", "OnProfileChanged")
    self.db.RegisterCallback(self, "OnProfileReset", "OnProfileChanged")
end

--- Callback for profile switch/copy/reset. Fires SETTING_CHANGED for all keys.
function S:OnProfileChanged()
    if not GRIPEMS.Fire then
        return
    end
    for key in pairs(self.defaults.profile) do
        GRIPEMS:Fire("SETTING_CHANGED", key, self:Get(key))
    end
end

--- Get a setting value from the active profile, with defaults fallback.
--- @param key string Setting key
--- @return any value
function S:Get(key)
    if self.db and self.db.profile[key] ~= nil then
        return self.db.profile[key]
    end
    return self.defaults.profile[key]
end

--- Set a setting value in the active profile and fire a callback.
--- @param key string Setting key
--- @param value any New value
function S:Set(key, value)
    if self.db then
        self.db.profile[key] = value
    end
    if GRIPEMS.Fire then
        GRIPEMS:Fire("SETTING_CHANGED", key, value)
    end
end

--- Get the AceDB instance (used by SettingsPanel for AceDBOptions).
--- @return table AceDB instance
function S:GetDB()
    return self.db
end

--- Get the effective click rate: TA auto-set, per-character override, then profile default.
--- @return number Click rate in milliseconds
function S:GetEffectiveClickRate()
    -- Faster, Slower auto-set: use TempoAdvisor recommendation for active sequence
    if self:Get("tempoAutoSet") and GRIPEMS.TempoAdvisor then
        local ta = GRIPEMS.TempoAdvisor
        local eng = GRIPEMS.Engine
        local activeSeq = eng and eng._lastClickedSequence
        if activeSeq then
            local rec = ta:GetRecommendation(activeSeq)
            if rec and rec.blendedMs then
                return rec.blendedMs
            elseif rec and rec.recommendedMs then
                return rec.recommendedMs
            end
        end
    end
    -- Per-character override
    if _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.msClickRate and GRIP_EMS_CHAR.msClickRate > 0 then
        return GRIP_EMS_CHAR.msClickRate
    end
    return self:Get("msClickRate")
end

--- Set per-character click rate override.
--- @param value number Click rate in ms (0 = use global)
function S:SetCharClickRate(value)
    if not _G.GRIP_EMS_CHAR then
        _G.GRIP_EMS_CHAR = {}
    end
    GRIP_EMS_CHAR.msClickRate = value
    if GRIPEMS.Fire then
        GRIPEMS:Fire("SETTING_CHANGED", "msClickRate", value)
    end
end

--- Get merged reset modifier table (defaults + profile overrides).
--- @return table Modifier name -> boolean
function S:GetResetModifiers()
    local D = GRIPEMS.Defaults
    local result = {}
    for mod, default in pairs(D.MACRO_RESET_MODIFIER_DEFAULTS) do
        result[mod] = default
    end
    local saved = self:Get("macroResetModifiers")
    if saved and type(saved) == "table" then
        for mod, enabled in pairs(saved) do
            result[mod] = enabled
        end
    end
    return result
end

--- Set a single reset modifier and persist.
--- @param modifier string Modifier key name
--- @param enabled boolean Whether enabled
function S:SetResetModifier(modifier, enabled)
    local current = self:Get("macroResetModifiers")
    if not current or type(current) ~= "table" then
        current = {}
    end
    current[modifier] = enabled
    self:Set("macroResetModifiers", current)
end
