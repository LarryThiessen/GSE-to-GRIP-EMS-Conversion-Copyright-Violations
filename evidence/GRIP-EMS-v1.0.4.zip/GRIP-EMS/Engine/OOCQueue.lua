-- GRIP-EMS: Out-of-Combat Queue
-- Defers protected API calls (CreateMacro, SetAttribute, etc.) until combat ends

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS")

-- OOC Queue module: buffers operations that require out-of-combat execution.
-- Protected WoW APIs (CreateMacro, EditMacro, DeleteMacro, CreateFrame,
-- SetAttribute from insecure code) are blocked during combat lockdown.
-- This queue stores pending operations and processes them when
-- PLAYER_REGEN_ENABLED fires or via a periodic fallback ticker.
GRIPEMS.OOCQueue = {
    queue = {},
}
local OOCQueue = GRIPEMS.OOCQueue

--- Add an operation to the queue, or execute immediately if out of combat.
--- @param func function The function to call
--- @param ... any Arguments to pass to the function
function OOCQueue:Add(func, ...)
    if not func then return end
    if InCombatLockdown() then
        table.insert(self.queue, { func = func, args = { ... } })
        GRIPEMS:Debug(L["GEMS_OOC_QUEUED"])
    else
        func(...)
    end
end

--- Process all queued operations. Silently skips if still in combat.
function OOCQueue:Process()
    if InCombatLockdown() then return end
    local count = #self.queue
    if count == 0 then return end
    for _, item in ipairs(self.queue) do
        item.func(unpack(item.args))
    end
    wipe(self.queue)
    GRIPEMS:Debug(string.format(L["GEMS_OOC_PROCESSED"], count))
end

--- Return the number of pending operations in the queue.
--- @return number
function OOCQueue:GetCount()
    return #self.queue
end

-- Event frame for PLAYER_REGEN_ENABLED (combat end)
local oocFrame = CreateFrame("Frame")
oocFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
oocFrame:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_REGEN_ENABLED" then
        OOCQueue:Process()
    end
end)

-- Periodic fallback ticker: catches edge cases where PLAYER_REGEN_ENABLED
-- might not fire (e.g., forced combat drop, death, disconnect recovery).
local oocInterval = GRIPEMS.Defaults.OOC_TICKER_INTERVAL
local S = GRIPEMS.Settings
if S and S.db then
    oocInterval = S:Get("oocDelay") or oocInterval
end
C_Timer.NewTicker(oocInterval, function()
    if not InCombatLockdown() and #OOCQueue.queue > 0 then
        OOCQueue:Process()
    end
end)
