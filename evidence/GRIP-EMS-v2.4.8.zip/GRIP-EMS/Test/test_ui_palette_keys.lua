-- GRIP-EMS: UI palette key guard
--
-- Created:    2026-08-11
-- Updated:    2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.
--
-- Standalone (Lua 5.1) SET A guard that every colour a UI file reads actually
-- exists in EVERY palette preset in UI/Util.lua.
--
-- WHY THIS EXISTS, and it is a measured failure rather than a hypothetical.
-- UI/KeybindConflictPanel.lua shipped a row backdrop reading C.bgRow. There is no
-- bgRow in any preset -- the scale has bgRowHover and bgRowSelected and never had
-- bgRow -- and on the live client every row in that panel painted WHITE with
-- near-white text on it. The panel's main surface was unreadable.
--
-- IT FAILED SILENTLY AT EVERY LAYER, which is the part worth understanding:
--   * Indexing a missing key on a Lua table is legal and yields nil, so neither
--     luacheck nor selene can see it.
--   * UI:ApplyBackdrop calls SetBackdrop unconditionally and only calls
--     SetBackdropColor when the colour is truthy, so a nil colour APPLIES the
--     backdrop and never tints it, leaving WoW's untinted white.
--   * It then records { bg = nil } in _backdropBindings, so the RebindBackdrops
--     theme walk cannot repair it later either.
--   * No headless test can render a frame, so no existing suite could see it.
-- A grep over the source is the only place the fault is visible at all, which is
-- exactly what this file is.
--
-- EVERY PRESET, NOT JUST ONE. A key present in Default and missing from
-- HighContrast is the same white-row bug, deferred until a user switches theme --
-- and it would then be reported as "the panel breaks when I change theme", which
-- is a far harder trail to follow.
--
-- Run from the EMS root:  lua Test/test_ui_palette_keys.lua
-- Exit code 0 = every referenced colour exists in every preset; 1 = a violation,
-- or a source this guard could not read.

local passedChecks = 0

local function fail(message)
    print("FAIL  test_ui_palette_keys -- " .. message)
    os.exit(1)
end

local function check(ok, message)
    if not ok then
        fail(message)
    end
    passedChecks = passedChecks + 1
end

local PREFIXES = { "", "../", "GRIP/EMS/" }

local function openFirst(relPath)
    for _, prefix in ipairs(PREFIXES) do
        local fh = io.open(prefix .. relPath, "r")
        if fh then
            return fh, prefix
        end
    end
    return nil
end

local function readSource(relPath)
    local fh = openFirst(relPath)
    if not fh then
        fail("could not read " .. relPath .. " from any known prefix; run this from the EMS repo root")
    end
    local src = fh:read("*a")
    fh:close()
    if type(src) ~= "string" or src == "" then
        fail(relPath .. " read as empty")
    end
    return src
end

-- ===========================================================================
-- The palettes
-- ===========================================================================
--
-- Discovered from the source rather than listed here: a list in this file would
-- go stale the moment a fourth preset is added, and would then pass while the new
-- preset was missing half the scale.

local utilSrc = readSource("UI/Util.lua")

local presets = {}
local presetOrder = {}
for name, body in string.gmatch(utilSrc, "UI%.Presets%.([%w_]+)%s*=%s*(%b{})") do
    local keys = {}
    local count = 0
    for key in string.gmatch(body, "([%w_]+)%s*=%s*{") do
        keys[key] = true
        count = count + 1
    end
    presets[name] = keys
    presetOrder[#presetOrder + 1] = name
    check(count > 0, "preset " .. name .. " parsed with zero colour keys (pattern drift?)")
end
table.sort(presetOrder)
check(#presetOrder >= 2, "expected at least two presets in UI/Util.lua, found " .. #presetOrder)

-- ===========================================================================
-- Every colour reference in the UI and Data trees
-- ===========================================================================

-- Files to scan, DISCOVERED FROM THE .toc LOAD GRAPH.
--
-- Two measured reasons this is not a directory listing:
--
--   PORTABILITY. The first version of this block shelled out to `dir /b`, which
--   is cmd syntax. It passed 29/29 on the Windows dev box and FAILED on the
--   ubuntu-latest runner CI actually uses -- no files discovered, the empty-scan
--   guard fired, exit 1, build red. It also left a junk file named `nul` in the
--   repo root, because `2>nul` is a cmd redirect and POSIX reads it as a
--   filename. A guard that only runs on one of the two platforms it runs on is
--   not a guard. io.open needs no shell and behaves identically on both.
--
--   SCOPE. That version scanned UI/ and Data/. Data/ references no colours at
--   all, while Import/ (17 names) and Core/ (4) do -- so a third of the real
--   references sat outside the scan, including the whole import dialog. The .toc
--   IS the load graph: if a file ships, it is scanned, and a new directory is
--   covered the day its first file is listed.
--
-- Libs/ is excluded because it is third-party and gitignored -- a CI checkout has
-- no Libs/ at all. Test/ is excluded because a test is not a shipped surface.
local function tocLuaFiles()
    local src = readSource("GRIP-EMS.toc")
    local files = {}
    local rawFiles = {}
    for line in string.gmatch(src .. "\n", "(.-)\n") do
        local path = string.gsub(line, "\\", "/")
        path = string.gsub(path, "^%s+", "")
        path = string.gsub(path, "%s+$", "")
        if
            string.sub(path, 1, 1) ~= "#"
            and string.sub(path, -4) == ".lua"
            and string.sub(path, 1, 5) ~= "Libs/"
            and string.sub(path, 1, 5) ~= "Test/"
        then
            files[#files + 1] = path
        end
        -- The RAW shipped-file set, computed from every .lua line the .toc names
        -- and deliberately NOT subject to the exclusion chain above. This is the
        -- other half of a differential: the failure mode lives in the FILTER, so
        -- the only honest reference is one the filter never touched. It is spelled
        -- with a directory-NAME test rather than the prefix tests above precisely
        -- so that a broken or extra prefix cannot move both sides together.
        if string.sub(path, 1, 1) ~= "#" and string.sub(path, -4) == ".lua" then
            local top = string.match(path, "^([^/]+)/")
            if top ~= "Libs" and top ~= "Test" then
                rawFiles[path] = true
            end
        end
    end
    return files, rawFiles
end

local scanned, rawFiles = tocLuaFiles()
check(
    #scanned > 20,
    "the .toc yielded only " .. #scanned .. " shipped .lua file(s) -- refusing to report green on a scan this thin"
)

-- EVERY SHIPPED FILE THE .toc NAMES MUST SURVIVE DISCOVERY, and this is a
-- differential rather than a threshold on purpose.
--
-- A count floor cannot see a directory-shaped hole, and a directory-shaped hole is
-- the realistic shape here: every exclusion above is a PREFIX TEST, so the way
-- this breaks is one prefix matching more than it should. Measured against the
-- live .toc, a regression that swallowed Import/ alone -- 9 files, 17 colour
-- names, the whole import dialog, the exact tree this guard was widened to reach
-- -- still leaves 100 files across 5 directories. Any fixed number large enough
-- to tolerate a tree being legitimately retired is too small to notice one going
-- missing, which is why there is no number here at all.
--
-- FILE granularity, not directory granularity, and that is a deliberate upgrade:
-- a per-directory version only proves at least ONE file survived per tree, so a
-- prefix that kept Import/Serialization.lua and dropped the other eight measured
-- PASS at 101 files. Comparing the file sets costs the same and has no residual.
--
-- rawFiles comes from the .toc lines BEFORE the exclusion chain ran, so it is the
-- one reference a broken filter cannot also corrupt.
local seen = {}
for _, rel in ipairs(scanned) do
    seen[rel] = true
end
local missing = {}
for rel in pairs(rawFiles) do
    if not seen[rel] then
        missing[#missing + 1] = rel
    end
end
table.sort(missing)
local shown = {}
for i = 1, math.min(#missing, 5) do
    shown[i] = missing[i]
end
check(
    #missing == 0,
    "the .toc ships "
        .. #missing
        .. " file(s) discovery did not return: "
        .. table.concat(shown, ", ")
        .. (#missing > 5 and " ... and " .. (#missing - 5) .. " more" or "")
)

-- Names that are NOT palette colours even though they are reached off the same
-- table expression. Kept deliberately tiny and each one justified: an allowlist is
-- how a guard like this quietly stops guarding.
local NOT_A_COLOUR = {
    -- UI.Colors itself is the table, not a key on it.
    Colors = true,
}

-- ALLOWLIST. Empty, and the history of why is worth more than the table.
--
-- This guard was written alongside the C.bgRow fix and found a SECOND violation
-- that predated it: statusGreen, read at UI/ContextTab.lua:936-938 behind
-- "C.statusGreen and C.statusGreen:GetRGB() or 0.2" and "if C.statusGreen then".
-- Because every read was nil-guarded it fell through to a literal and could not
-- paint white, so it was allowlisted rather than swept into the unreadable-panel
-- fix. THAT ENTRY IS NOW REMOVED: ContextTab no longer references statusGreen at
-- all. The guarded reads always fell through -- the key is in none of the three
-- presets and never was -- so deleting them changed no rendered colour, and with
-- the last reference gone the entry excused nothing.
--
-- The rule for adding to this table: a reference only belongs here when it is
-- provably nil-guarded at EVERY use site. An unguarded one gets fixed, not
-- allowlisted -- a guard that absorbs its own findings has stopped guarding.
local ALLOWLIST = {}

local violations = {}
local referenced = {}
local refCount = 0

for _, rel in ipairs(scanned) do
    local src = readSource(rel)
    local lineNo = 0
    -- "(.-)\n" over a newline-terminated copy yields exactly one entry per line,
    -- blank lines included. "[^\n]*" would also match the empty string between
    -- separators and report roughly double the real line number.
    for line in string.gmatch(src .. "\n", "(.-)\n") do
        lineNo = lineNo + 1
        -- Skip comment lines: a colour named in prose is not a reference.
        if not string.match(line, "^%s*%-%-") then
            for name in string.gmatch(line, "[^%w_]C%.([%w_]+)") do
                if not NOT_A_COLOUR[name] then
                    referenced[name] = referenced[name] or { file = rel, line = lineNo }
                    refCount = refCount + 1
                end
            end
            for name in string.gmatch(line, "UI%.Colors%.([%w_]+)") do
                if not NOT_A_COLOUR[name] then
                    referenced[name] = referenced[name] or { file = rel, line = lineNo }
                    refCount = refCount + 1
                end
            end
        end
    end
end
check(refCount > 0, "found no C.<name> or UI.Colors.<name> references at all (pattern drift?)")

-- ===========================================================================
-- The assertion
-- ===========================================================================

local names = {}
for name in pairs(referenced) do
    names[#names + 1] = name
end
table.sort(names)

local allowlisted = {}
for _, name in ipairs(names) do
    local missingFrom = {}
    for _, preset in ipairs(presetOrder) do
        if not presets[preset][name] then
            missingFrom[#missingFrom + 1] = preset
        end
    end
    if #missingFrom > 0 then
        local where = referenced[name]
        local line = string.format(
            "%s  first seen %s:%d  missing from: %s",
            name,
            where.file,
            where.line,
            table.concat(missingFrom, ", ")
        )
        if ALLOWLIST[name] then
            allowlisted[#allowlisted + 1] = line .. "  [allowlisted: " .. ALLOWLIST[name] .. "]"
        else
            violations[#violations + 1] = line
        end
    end
end

-- Printed on every run, pass or fail. An allowlist that is invisible while green
-- is an allowlist nobody ever revisits.
for _, line in ipairs(allowlisted) do
    print("ALLOW " .. line)
end

if #violations > 0 then
    print("FAIL  test_ui_palette_keys -- " .. #violations .. " colour reference(s) absent from a palette preset:")
    for _, v in ipairs(violations) do
        print("        " .. v)
    end
    print("      A missing palette key is SILENT: ApplyBackdrop applies the backdrop and skips the tint,")
    print("      so the frame paints untinted white. Fix the reference; do not add the key to the scale")
    print("      unless the colour genuinely belongs in it.")
    os.exit(1)
end

check(true, "every referenced colour exists in every preset")

print("RESULT " .. passedChecks .. " passed, 0 failed")
print(
    string.format(
        "PASS  test_ui_palette_keys -- %d colour name(s) across %d file(s) all present in %d preset(s): %s",
        #names,
        #scanned,
        #presetOrder,
        table.concat(presetOrder, ", ")
    )
)
os.exit(0)
