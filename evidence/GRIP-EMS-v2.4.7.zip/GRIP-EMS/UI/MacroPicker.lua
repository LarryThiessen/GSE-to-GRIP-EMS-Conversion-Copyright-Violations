-- GRIP-EMS: Macro Picker
-- Created: 2026-05-09
-- Updated: 2026-08-17
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)

-- AceGUI-based modal picker for the Layer 4 Macro action type.
-- Lists every macro the user could reference: WoW account/character
-- macros plus EMS-stored macros (account + per-character buckets).
-- Returns the chosen entry to the caller via callback.
--
-- Single public entry:
--     GRIPEMS.MacroPicker:Show(callback)
--         callback({ name, icon, body, source }) on selection
--         callback(nil)                          on cancel
--
-- Modal (single instance): Show() while one is already open closes the
-- existing instance first, then re-opens fresh.

local ADDON_NAME, GRIPEMS = ...
local AceGUI = LibStub("AceGUI-3.0")
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)
local D = GRIPEMS.Defaults

GRIPEMS.MacroPicker = {}
local MP = GRIPEMS.MacroPicker

---------------------------------------------------------------------------
-- Constants
---------------------------------------------------------------------------
local PICKER_WIDTH = 560
local PICKER_HEIGHT = 480
local ROW_HEIGHT = 28
local ICON_SIZE = 24
local NAME_WIDTH = 140
local BADGE_WIDTH = 80
local BODY_PREVIEW_MAX = 80

-- Source badge colors (RGB tuples; alpha applied at render time).
local BADGE_COLOR_WOW = { 0.65, 0.65, 0.65 } -- grey
local BADGE_COLOR_EMS = { 0.0, 0.80, 0.40 } -- EMS brand green
local BADGE_COLOR_BOTH = { 0.30, 0.90, 0.30 } -- bright green

---------------------------------------------------------------------------
-- State (single-instance modal)
---------------------------------------------------------------------------
MP._frame = nil
MP._callback = nil
MP._allEntries = nil -- cached enumeration for the current Show() pass
MP._scrollGroup = nil
MP._searchText = ""
MP._searchTimer = nil -- debounced re-filter handle (C_Timer)

---------------------------------------------------------------------------
-- Helpers
---------------------------------------------------------------------------

--- Resolve the localized badge label + color tuple for a source value.
--- @param source string "wow" | "ems_account" | "ems_char" | "both"
--- @return string label
--- @return table { r, g, b }
local function badgeFor(source)
    if source == "both" then
        return L["GEMS_MACRO_PICKER_SOURCE_BOTH"] or "Both", BADGE_COLOR_BOTH
    elseif source == "ems_account" or source == "ems_char" then
        return L["GEMS_MACRO_PICKER_SOURCE_EMS"] or "EMS only", BADGE_COLOR_EMS
    end
    return L["GEMS_MACRO_PICKER_SOURCE_WOW"] or "WoW only", BADGE_COLOR_WOW
end

--- Single-line truncated body preview.
--- @param body string Macro body (may contain newlines)
--- @return string Truncated single-line preview
local function previewFor(body)
    body = (type(body) == "string") and body or ""
    local firstLine = body:match("[^\r\n]*") or ""
    if #firstLine > BODY_PREVIEW_MAX then
        firstLine = firstLine:sub(1, BODY_PREVIEW_MAX) .. ".."
    end
    return firstLine
end

--- Substring match (case-insensitive). Empty search matches everything.
--- @param entry table { name, body, ... }
--- @param search string Lowercase search text
--- @return boolean
local function matchesSearch(entry, search)
    if not search or search == "" then
        return true
    end
    return strlower(entry.name or ""):find(search, 1, true) ~= nil
end

---------------------------------------------------------------------------
-- Row rendering
---------------------------------------------------------------------------

--- Build a single picker row inside the scroll container.
--- @param entry table { name, icon, body, source }
local function buildRow(entry)
    local row = AceGUI:Create("SimpleGroup")
    row:SetLayout("Flow")
    row:SetFullWidth(true)
    row:SetHeight(ROW_HEIGHT)

    -- Icon
    local iconWidget = AceGUI:Create("Icon")
    iconWidget:SetImage(entry.icon or D.QUESTION_MARK_ICON)
    iconWidget:SetImageSize(ICON_SIZE, ICON_SIZE)
    iconWidget:SetWidth(ICON_SIZE + 4)
    iconWidget:SetHeight(ROW_HEIGHT)
    iconWidget:SetCallback("OnClick", function()
        MP:_finish(entry)
    end)
    row:AddChild(iconWidget)

    -- Name (interactive label)
    local nameLabel = AceGUI:Create("InteractiveLabel")
    nameLabel:SetText(entry.name)
    nameLabel:SetWidth(NAME_WIDTH)
    nameLabel:SetCallback("OnClick", function()
        MP:_finish(entry)
    end)
    row:AddChild(nameLabel)

    -- Source badge (colored interactive label)
    local badgeText, color = badgeFor(entry.source)
    local badge = AceGUI:Create("InteractiveLabel")
    badge:SetText(badgeText)
    badge:SetWidth(BADGE_WIDTH)
    badge:SetColor(color[1], color[2], color[3])
    badge:SetCallback("OnClick", function()
        MP:_finish(entry)
    end)
    row:AddChild(badge)

    -- Body preview (interactive label, dim)
    local preview = AceGUI:Create("InteractiveLabel")
    preview:SetText(previewFor(entry.body))
    preview:SetRelativeWidth(0.50)
    preview:SetColor(0.70, 0.70, 0.70)
    preview:SetCallback("OnClick", function()
        MP:_finish(entry)
    end)
    row:AddChild(preview)

    return row
end

---------------------------------------------------------------------------
-- List render / re-filter
---------------------------------------------------------------------------

--- Repopulate the scroll group with rows that match the current search.
function MP:_repopulate()
    if not self._scrollGroup then
        return
    end
    self._scrollGroup:ReleaseChildren()

    local search = strlower(self._searchText or "")
    local entries = self._allEntries or {}
    local rendered = 0

    for _, entry in ipairs(entries) do
        if matchesSearch(entry, search) then
            self._scrollGroup:AddChild(buildRow(entry))
            rendered = rendered + 1
        end
    end

    if rendered == 0 then
        local empty = AceGUI:Create("Label")
        empty:SetText(L["GEMS_MACRO_PICKER_EMPTY"] or "No macros found.")
        empty:SetFullWidth(true)
        empty:SetColor(0.80, 0.80, 0.40)
        self._scrollGroup:AddChild(empty)
    end
end

---------------------------------------------------------------------------
-- Lifecycle
---------------------------------------------------------------------------

--- Close the picker and fire the stored callback exactly once.
--- Lifecycle order matters: clear self._frame BEFORE AceGUI:Release so the
--- OnClose guard short-circuits (release fires OnClose synchronously).
--- @param selection table|nil { name, icon, body, source } or nil for cancel
function MP:_finish(selection)
    local cb = self._callback
    local frame = self._frame
    self._callback = nil
    self._allEntries = nil
    self._scrollGroup = nil
    self._searchText = ""
    self._frame = nil
    if self._searchTimer then
        self._searchTimer:Cancel()
        self._searchTimer = nil
    end
    if frame then
        AceGUI:Release(frame)
    end
    if type(cb) == "function" then
        cb(selection)
    end
end

--- Show the picker. Modal: any existing instance is closed (with cancel)
--- before opening a fresh one.
--- @param callback function callback({ name, icon, body, source }) or callback(nil)
function MP:Show(callback)
    -- Single-instance guard: close any prior open frame first (cancel)
    if self._frame then
        self:_finish(nil)
    end

    self._callback = callback
    self._allEntries = GRIPEMS.MacroManager:EnumerateAllMacros()
    self._searchText = ""

    local frame = AceGUI:Create("Frame")
    self._frame = frame
    frame:SetTitle(L["GEMS_MACRO_PICKER_TITLE"] or "Pick a Macro")
    frame:SetWidth(PICKER_WIDTH)
    frame:SetHeight(PICKER_HEIGHT)
    frame:SetLayout("Flow")
    frame:EnableResize(false)
    frame:SetCallback("OnClose", function()
        -- AceGUI Frame fires OnClose when the X is clicked; treat as cancel.
        -- When _finish triggered the release, MP._frame was already cleared
        -- and this guard short-circuits (no recursive Release).
        if MP._frame == frame then
            MP._frame = nil
            local cb = MP._callback
            MP._callback = nil
            MP._allEntries = nil
            MP._scrollGroup = nil
            MP._searchText = ""
            if MP._searchTimer then
                MP._searchTimer:Cancel()
                MP._searchTimer = nil
            end
            AceGUI:Release(frame)
            if type(cb) == "function" then
                cb(nil)
            end
        end
    end)

    -- Search box (debounced filter so a 5-char burst only re-renders once)
    local search = AceGUI:Create("EditBox")
    search:SetLabel(L["GEMS_MACRO_PICKER_SEARCH"] or "Search...")
    search:SetFullWidth(true)
    search:DisableButton(true)
    search:SetCallback("OnTextChanged", function(_, _, text)
        MP._searchText = text or ""
        if MP._searchTimer then
            MP._searchTimer:Cancel()
        end
        if C_Timer and C_Timer.NewTimer then
            MP._searchTimer = C_Timer.NewTimer(0.10, function()
                MP._searchTimer = nil
                if MP._frame then
                    MP:_repopulate()
                end
            end)
        end
    end)
    frame:AddChild(search)

    -- Scrolling list
    local scroll = AceGUI:Create("ScrollFrame")
    scroll:SetLayout("List")
    scroll:SetFullWidth(true)
    scroll:SetFullHeight(true)
    self._scrollGroup = scroll
    frame:AddChild(scroll)

    -- Initial population
    self:_repopulate()

    -- Autofocus: cursor lands in search box on the next frame so the user
    -- can immediately type. Guard against the race where the user cancels
    -- the picker before the timer fires (or Show is invoked again).
    if C_Timer and C_Timer.After then
        C_Timer.After(0, function()
            if MP._frame == frame and search and search.editbox then
                search.editbox:SetFocus()
            end
        end)
    end
end

--- Programmatic close (callers can dismiss the picker without selecting).
--- Fires the cancel branch of the callback.
function MP:Hide()
    if self._frame then
        self:_finish(nil)
    end
end
