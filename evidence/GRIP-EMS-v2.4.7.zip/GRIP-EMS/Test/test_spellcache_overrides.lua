-- GRIP-EMS: Headless test for SC:ApplySpellOverrides
--
-- Created:    2026-07-16
-- Updated:    2026-08-17
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
--
-- Standalone (Lua 5.1) test for Data/SpellCache.lua's shared spell-name
-- override apply/revert path, the single path behind the cache build and both
-- SpellCacheViewer edit paths. Drives the REAL SpellCache module via loadfile
-- + setfenv into a sandbox that stubs CreateFrame, C_Timer, LibStub, strlower
-- and a fake GRIPEMS namespace, the same technique as
-- test_spellvalidator_refresh_gate.lua. Keeping the stubs as fields on a local env
-- table (never global assignments) keeps the file luacheck-clean under the
-- read-only WoW std.
--
-- Run from the EMS root:  lua Test/test_spellcache_overrides.lua
-- Exit code 0 = all passed, 1 = at least one failure.
--
-- Cases:
--   T1  no overrides       -> nothing touched, changed=false
--   T2  one override       -> originalName captured, name rewritten, byName
--                             re-keyed, list re-sorted
--   T3  repeat call        -> idempotent, changed=false, originalName intact
--   T4  override removed   -> name reverts to base, originalName cleared,
--                             byName restored
--   T5  collision + revert -> a spell renamed onto another spell's name must
--                             not leave that spell orphaned out of byName once
--                             the override is cleared
--   T6  migration dispatch -> SC:RegisterMigrations really reaches
--                             Engine:RepairPersistedOverrideNames, on both the
--                             refresh-callback path and the already-ready path
--   T7  migration dispatch -> and skips it without raising when the Engine has
--                             not loaded yet (SpellCache loads first)

local ADDON_NAME = "GRIP-EMS"

-- ---------------------------------------------------------------------------
-- Minimal assertion + runner harness (mirrors TestSuite Pass/Fail semantics).
-- ---------------------------------------------------------------------------

local tests = {}

local function test(name, fn)
    tests[#tests + 1] = { name = name, fn = fn }
end

local function assertEqual(expected, actual, label)
    if expected ~= actual then
        error((label or "value") .. ": expected " .. tostring(expected) .. ", got " .. tostring(actual), 2)
    end
end

local function assertTrue(cond, label)
    if not cond then
        error((label or "condition") .. ": expected true", 2)
    end
end

-- ---------------------------------------------------------------------------
-- Sandbox: load the real Data/SpellCache.lua.
-- ---------------------------------------------------------------------------

local env = setmetatable({}, { __index = _G })
env.strlower = string.lower
env.wipe = function(t)
    for k in pairs(t) do
        t[k] = nil
    end
end
env.CreateFrame = function()
    return {
        SetScript = function() end,
        RegisterEvent = function() end,
        UnregisterEvent = function() end,
        UnregisterAllEvents = function() end,
        Show = function() end,
        Hide = function() end,
    }
end
env.C_Timer = {
    After = function(_, f)
        if f then
            f()
        end
    end,
}
env.LibStub = function()
    return {
        GetLocale = function()
            return setmetatable({}, {
                __index = function(_, k)
                    return k
                end,
            })
        end,
        NewLibrary = function()
            return nil
        end,
        GetLibrary = function()
            return nil
        end,
    }
end

local GRIPEMS = {
    Debug = function() end,
    Print = function() end,
    Fire = function() end,
}

-- loadfile is dev-harness file I/O, intentionally outside the addon WoW std.
-- selene: allow(undefined_variable)
local chunk = assert(loadfile("Data/SpellCache.lua"))
setfenv(chunk, env)
chunk(ADDON_NAME, GRIPEMS)

local SC = GRIPEMS.SpellCache
assert(SC and SC.ApplySpellOverrides, "SC:ApplySpellOverrides missing")

local overrides = {}
GRIPEMS.Settings = { db = { profile = { spellOverrides = overrides } } }

-- Arcane Shot(1), Barbed Shot(2), Cobra Shot(3) -- already alphabetical.
local function reset()
    SC.spells = {
        { name = "Arcane Shot", spellID = 1 },
        { name = "Barbed Shot", spellID = 2 },
        { name = "Cobra Shot", spellID = 3 },
    }
    SC.byName = {}
    for _, e in ipairs(SC.spells) do
        SC.byName[string.lower(e.name)] = e
    end
    for k in pairs(overrides) do
        overrides[k] = nil
    end
end

local function names()
    local out = {}
    for _, e in ipairs(SC.spells) do
        out[#out + 1] = e.name
    end
    return table.concat(out, " | ")
end

local function entryFor(spellID)
    for _, e in ipairs(SC.spells) do
        if e.spellID == spellID then
            return e
        end
    end
    return nil
end

-- ---------------------------------------------------------------------------
-- Cases.
-- ---------------------------------------------------------------------------

test("T1 no overrides -- nothing touched", function()
    reset()
    local changed = SC:ApplySpellOverrides()
    assertEqual(false, changed, "changed")
    assertEqual("Arcane Shot | Barbed Shot | Cobra Shot", names(), "names")
end)

test("T2 one override -- capture, rewrite, re-key, re-sort", function()
    reset()
    overrides[2] = "Zulu Shot"
    local changed = SC:ApplySpellOverrides()
    local e = entryFor(2)
    assertEqual(true, changed, "changed")
    assertEqual("Zulu Shot", e.name, "name")
    assertEqual("Barbed Shot", e.originalName, "originalName")
    assertTrue(SC.byName["zulu shot"] == e, "byName re-keyed to custom name")
    assertEqual(nil, SC.byName["barbed shot"], "old byName key dropped")
    assertEqual("Arcane Shot | Cobra Shot | Zulu Shot", names(), "re-sorted")
end)

test("T3 repeat call -- idempotent", function()
    reset()
    overrides[2] = "Zulu Shot"
    SC:ApplySpellOverrides()
    local changed = SC:ApplySpellOverrides()
    local e = entryFor(2)
    assertEqual(false, changed, "changed on second call")
    assertEqual("Barbed Shot", e.originalName, "originalName not re-captured")
    assertEqual("Arcane Shot | Cobra Shot | Zulu Shot", names(), "names stable")
end)

test("T4 override removed -- reverts to base name", function()
    reset()
    overrides[2] = "Zulu Shot"
    SC:ApplySpellOverrides()
    overrides[2] = nil
    local changed = SC:ApplySpellOverrides()
    local e = entryFor(2)
    assertEqual(true, changed, "changed")
    assertEqual("Barbed Shot", e.name, "name reverted")
    assertEqual(nil, e.originalName, "originalName cleared")
    assertTrue(SC.byName["barbed shot"] == e, "byName restored")
    assertEqual(nil, SC.byName["zulu shot"], "custom byName key dropped")
    assertEqual("Arcane Shot | Barbed Shot | Cobra Shot", names(), "re-sorted back")
end)

test("T5 collision then revert -- real owner is not orphaned", function()
    reset()
    local cobra = entryFor(3)
    -- Rename Arcane Shot onto Cobra Shot's exact name. The clobber is expected:
    -- a rebuild produces the same state, so live and post-reload agree.
    overrides[1] = "Cobra Shot"
    SC:ApplySpellOverrides()
    assertTrue(SC.byName["cobra shot"] == entryFor(1), "renamed entry owns the key while the override is live")
    -- Clearing the override must hand the key back, not drop it.
    overrides[1] = nil
    SC:ApplySpellOverrides()
    assertEqual("Arcane Shot", entryFor(1).name, "renamed entry reverted")
    assertTrue(SC.byName["cobra shot"] == cobra, "real Cobra Shot resolvable again (not orphaned)")
    assertTrue(SC.byName["arcane shot"] == entryFor(1), "reverted entry re-keyed")
end)

test("T6 migration dispatch -- SC:RegisterMigrations reaches RepairPersistedOverrideNames", function()
    -- STALE-OVERRIDE-STEP-TEXT, the wiring half. v2.4.4 removed the override
    -- write from Engine:HealOverrideSteps and added a one-time repair for the
    -- text the old writer already stored. The repair is dispatched from THIS
    -- function, and a repair nothing calls is the same as no repair -- the
    -- lesson the N-cases in test_stepadv_numsteps_domain.lua are named for. So
    -- this drives the REAL SC:RegisterMigrations rather than the repair body.
    --
    -- STUB AUDIT.
    --   GRIPEMS.RegisterCallback  records the (owner, event, fn) triple instead
    --                             of registering. LIVE: CallbackHandler-1.0.
    --                             MATCHES in call shape; the case fires the
    --                             captured fn itself.
    --   GRIPEMS.Engine            a spy carrying only the one method. LIVE: the
    --                             real Engine. DIFFERS -- nothing here asserts
    --                             the repair is CORRECT, only that it is
    --                             REACHED, which the S-persist cases in
    --                             test_stepadv_numsteps_domain.lua cover.
    local calls = 0
    local prevEngine = GRIPEMS.Engine
    local prevRegister = GRIPEMS.RegisterCallback
    local prevReady = SC.ready
    local prevLatch = SC._migrationsRegistered
    GRIPEMS.Engine = {
        RepairPersistedOverrideNames = function()
            calls = calls + 1
            return 0
        end,
    }
    local captured
    GRIPEMS.RegisterCallback = function(_, event, fn)
        if event == "SPELL_CACHE_REFRESHED" then
            captured = fn
        end
    end

    -- Cache NOT ready: the immediate block must not fire the repair.
    SC.ready = false
    SC._migrationsRegistered = nil
    local okCold, errCold = pcall(SC.RegisterMigrations, SC)
    local afterCold = calls

    -- Now the refresh arrives.
    SC.ready = true
    local okFire, errFire = pcall(captured or function() end)
    local afterRefresh = calls

    -- And the ready-at-registration path, which is the /reload ordering.
    SC._migrationsRegistered = nil
    local okWarm, errWarm = pcall(SC.RegisterMigrations, SC)
    local afterWarm = calls

    SC.ready = prevReady
    SC._migrationsRegistered = prevLatch
    GRIPEMS.Engine = prevEngine
    GRIPEMS.RegisterCallback = prevRegister

    assertTrue(okCold, "T6: RegisterMigrations raised on the cold path: " .. tostring(errCold))
    assertTrue(captured ~= nil, "T6: a SPELL_CACHE_REFRESHED handler was registered")
    assertEqual(0, afterCold, "T6: an unready cache dispatches no repair")
    assertTrue(okFire, "T6: the refresh handler raised: " .. tostring(errFire))
    assertEqual(1, afterRefresh, "T6: the refresh handler reached the repair exactly once")
    assertTrue(okWarm, "T6: RegisterMigrations raised on the warm path: " .. tostring(errWarm))
    assertEqual(2, afterWarm, "T6: registering against an already-ready cache reaches it too")
end)

test("T7 migration dispatch -- an absent Engine is skipped, not raised", function()
    -- Data/SpellCache.lua loads before Engine/Engine.lua, and the dispatcher can
    -- be reached on a refresh that lands before the Engine exists. It must
    -- retry on the next refresh rather than burn the gate or throw.
    local prevEngine = GRIPEMS.Engine
    local prevRegister = GRIPEMS.RegisterCallback
    local prevReady = SC.ready
    local prevLatch = SC._migrationsRegistered
    local captured
    GRIPEMS.RegisterCallback = function(_, event, fn)
        if event == "SPELL_CACHE_REFRESHED" then
            captured = fn
        end
    end
    GRIPEMS.Engine = nil
    SC.ready = true
    SC._migrationsRegistered = nil

    local okReg, errReg = pcall(SC.RegisterMigrations, SC)
    local okFire, errFire = pcall(captured or function() end)

    SC.ready = prevReady
    SC._migrationsRegistered = prevLatch
    GRIPEMS.Engine = prevEngine
    GRIPEMS.RegisterCallback = prevRegister

    assertTrue(okReg, "T7: RegisterMigrations raised with no Engine: " .. tostring(errReg))
    assertTrue(okFire, "T7: the refresh handler raised with no Engine: " .. tostring(errFire))
end)

-- ---------------------------------------------------------------------------
-- T8 to T10, the base-spell fallback table. THE REAL SC:GetBaseSpellID.
--
-- These live here, and not beside S7 to S11 in
-- Test/test_stepadv_numsteps_domain.lua, for one reason: that harness loads
-- Engine/Engine.lua and Engine/StepFunctions.lua only. It has never loaded
-- Data/SpellCache.lua, so SC:GetBaseSpellID and SC:_ResolveCollision are both
-- out of reach there and any case written against them would be asserting on a
-- stub. This file loads the real module, so it is where the real function is
-- driven. The S-cases over there cover the ENGINE side, that the recovery
-- delegates here at all.
--
-- What Phase 4 changed and why it was invisible: D.BASE_SPELL_TABLE existed for
-- spells the API cannot resolve, and was unreachable for exactly that class.
-- SC:GetBaseSpellID read `if baseID then return baseID end`, and the class the
-- table was built for does not answer nil, it answers the id it was handed.
-- Measured on a live Guardian Druid (Sataanoir, 12.1.0.69299):
-- FindBaseSpellByID(441583) returns 441583 for Ravage. That is TRUTHY, so the
-- early return fired and the table was never consulted.
--
-- STUB AUDIT, additions only.
--   env.C_SpellBook   rawset per case with a FindBaseSpellByID that answers from
--                     a per-case table. LIVE: the client's spellbook. MATCHES in
--                     call shape and in the three measured answers used below.
--   GRIPEMS.Defaults  the REAL Data/Defaults.lua is loaded into a throwaway
--                     namespace and only BASE_SPELL_TABLE is carried across, so
--                     T9 asserts against the SHIPPED table rather than a fixture
--                     copy. Deleting the row from Data/Defaults.lua fails T9.
--   env.IsSpellKnown / env.IsPlayerSpell / env.UnitClass
--                     T10 only, so the collision walk reaches its base-spell
--                     collapse stage instead of returning at an earlier one.
--   env.C_SpellBook.FindSpellOverrideByID
--                     T12 adds a THROWING stub: it errors on anything outside
--                     the signed-32-bit range and answers identity otherwise.
--                     LIVE: the real API, which throws rather than returning nil
--                     on an out-of-range id -- the behaviour SC:TranslateSpellRef
--                     documents at its own call site and which
--                     SC:IsValidSpellID's bounds exist to stay inside. MATCHES in
--                     that respect, and it is load-bearing: a stub returning nil
--                     would let T12 pass on the UNFIXED build and prove nothing.
--   env.C_Spell       T11 and T12. GetSpellName answers for 6807 and 441583 so
--                     SC:RecoverSpellName can turn the resolved id into a name,
--                     which is the string T11 reads. LIVE: the client's
--                     C_Spell.GetSpellName. MATCHES in call shape and returns a
--                     plain string; the NAMES are fixture labels rather than the
--                     client's localised strings, so T11 asserts WHICH id was
--                     resolved and never that a translation is correct.
--                     env.C_SpellBook gains FindSpellOverrideByID in the same
--                     case, as an IDENTITY function: that is the untalented
--                     state, and it is the state the display defect lived in.
-- ---------------------------------------------------------------------------

-- The SHIPPED table, pulled out of the real Data/Defaults.lua.
local SHIPPED_BASE_SPELL_TABLE = {}
do
    local probe = {}
    -- loadfile is dev-harness file I/O, intentionally outside the addon WoW std.
    -- selene: allow(undefined_variable)
    local defaultsChunk = loadfile("Data/Defaults.lua")
    if defaultsChunk then
        setfenv(defaultsChunk, env)
        pcall(defaultsChunk, ADDON_NAME, probe)
        if type(probe.Defaults) == "table" and type(probe.Defaults.BASE_SPELL_TABLE) == "table" then
            SHIPPED_BASE_SPELL_TABLE = probe.Defaults.BASE_SPELL_TABLE
        end
    end
end

--- Point the real SC at a Defaults carrying the given base-spell table, and at a
--- C_SpellBook answering from `links`. Returns a restore function.
local function withBaseSpellEnv(links, baseTable)
    local prevDefaults = GRIPEMS.Defaults
    local prevBook = rawget(env, "C_SpellBook")
    GRIPEMS.Defaults = { BASE_SPELL_TABLE = baseTable or {} }
    env.C_SpellBook = {
        FindBaseSpellByID = function(id)
            return links[id]
        end,
    }
    return function()
        GRIPEMS.Defaults = prevDefaults
        env.C_SpellBook = prevBook
    end
end

test("T8 GetBaseSpellID -- an IDENTITY answer falls through to the table", function()
    -- The reachability fix. Before Phase 4 the identity answer returned early
    -- and this case could not pass on any table contents at all.
    local restore = withBaseSpellEnv(
        -- Ravage answers itself, Raze answers a real base, Maul is the control.
        { [441583] = 441583, [400254] = 6807, [6807] = 6807 },
        { [441583] = 6807 }
    )
    local ravage = SC:GetBaseSpellID(441583)
    local raze = SC:GetBaseSpellID(400254)
    local maul = SC:GetBaseSpellID(6807)
    -- An id the API answers identity for and the table does NOT carry must come
    -- back unchanged, which is the old behaviour preserved.
    local orphan = SC:GetBaseSpellID(999001)
    restore()

    assertEqual(6807, ravage, "T8: identity from the API falls through and the table answers")
    assertEqual(6807, raze, "T8 (control): a real base link still short-circuits ahead of the table")
    assertEqual(6807, maul, "T8 (control): an already-base id answers itself")
    assertEqual(999001, orphan, "T8 (control): identity with no table row still returns the input")
end)

test("T9 GetBaseSpellID -- a nil API answer still reaches the table, and the SHIPPED row is present", function()
    -- The pre-Phase-4 path, proven unbroken: `fallback or baseID or spellID`
    -- must land a nil answer exactly where `fallback or spellID` used to.
    local restore = withBaseSpellEnv({}, { [441583] = 6807 })
    local viaTable = SC:GetBaseSpellID(441583)
    local noRow = SC:GetBaseSpellID(999001)
    restore()

    -- And the real shipped data, so this cannot pass against an empty table.
    assertEqual(6807, SHIPPED_BASE_SPELL_TABLE[441583], "T9: Data/Defaults.lua ships the measured Ravage pair")
    assertEqual(nil, SHIPPED_BASE_SPELL_TABLE[6807], "T9: and does not ship a row for the base spell itself")
    assertEqual(6807, viaTable, "T9: a nil API answer reaches the table")
    assertEqual(999001, noRow, "T9: a nil API answer with no table row returns the input, as before")
end)

test("T10 _ResolveCollision -- unmoved for ids with no table row, and MOVED for the one that has one", function()
    -- SC:GetBaseSpellID has exactly two call sites, SpellCache.lua L1050 and
    -- L1053, both inside this collapse. So the Phase 4 change to that function
    -- reaches the collision walk, and this case states the blast radius rather
    -- than asserting it away.
    --
    -- HALF ONE is a no-movement net: for ids the table says nothing about, the
    -- collapse reads exactly as before. It passes on both sides of the edit ON
    -- PURPOSE. A "behaviour X did not change" assertion that failed before the
    -- change would be asserting the wrong thing.
    --
    -- HALF TWO is the discriminator, and it records a REAL second-order effect.
    -- With the measured row in place, GetBaseSpellID(441583) answers 6807 rather
    -- than 441583, so a pool holding Ravage and Maul now collapses where it
    -- previously did not. That is a genuine behavioural move in the collision
    -- path, it is correct (the two really do share base Maul), and it is the
    -- only place outside the repair where this commit changes anything.
    local prevKnown, prevPlayer, prevUnit = env.IsSpellKnown, env.IsPlayerSpell, env.UnitClass
    -- Nothing is "known", so stage 2 cannot resolve and the walk reaches the
    -- base-spell collapse at stage 3, which is the stage under test.
    env.IsSpellKnown = function()
        return false
    end
    env.IsPlayerSpell = function()
        return false
    end
    env.UnitClass = function()
        return "Druid", "DRUID", nil
    end

    -- Two candidates sharing one base: the collapse must fire and return the
    -- first. Neither id has a table row, so this exercises the API arm only.
    local restore = withBaseSpellEnv({ [400254] = 6807, [6807] = 6807 }, {})
    local collapsed = SC:_ResolveCollision({ { i = 400254, c = "DRUID", k = 1 }, { i = 6807, c = "DRUID", k = 1 } })
    restore()

    -- Two candidates with DIFFERENT bases: the collapse must NOT fire, so the
    -- walk falls through to a later stage. Without this the case would pass on a
    -- build where the collapse fires unconditionally.
    local restore2 = withBaseSpellEnv({ [400254] = 6807, [12345] = 12345 }, {})
    local notCollapsed = SC:_ResolveCollision({ { i = 400254, c = "DRUID", k = 0 }, { i = 12345, c = "DRUID", k = 1 } })
    restore2()

    -- HALF TWO. Ravage and Maul, with the API answering identity for Ravage and
    -- the SHIPPED table supplying the link. Pre-Phase-4 the two bases read
    -- 441583 and 6807, so the collapse did not fire and the walk fell through to
    -- the castable-preference stage, returning Maul. With the fix the two bases
    -- both read 6807, the collapse fires, and the FIRST candidate wins.
    local restore3 = withBaseSpellEnv({ [441583] = 441583, [6807] = 6807 }, SHIPPED_BASE_SPELL_TABLE)
    local ravageBase = SC:GetBaseSpellID(441583)
    local movedPool = SC:_ResolveCollision({ { i = 441583, c = "DRUID", k = 1 }, { i = 6807, c = "DRUID", k = 1 } })
    restore3()

    env.IsSpellKnown, env.IsPlayerSpell, env.UnitClass = prevKnown, prevPlayer, prevUnit

    assertEqual(400254, collapsed, "T10 half one: candidates sharing one base collapse to the first, as before")
    assertEqual(12345, notCollapsed, "T10 half one (control): candidates with different bases do NOT collapse")
    assertEqual(6807, ravageBase, "T10 half two: the table gives Ravage a base, which is what moves the collapse")
    assertEqual(
        441583,
        movedPool,
        "T10 half two: Ravage and Maul now collapse to the first candidate, where before they did not"
    )
end)

test("T11 TranslateMacrotext toNames -- the DISPLAY walk reaches the table through SC:GetBaseSpellID", function()
    -- Phase 4 pointed the REPAIR path at D.BASE_SPELL_TABLE and left ONE inline
    -- C_SpellBook.FindBaseSpellByID call behind, inside SC:TranslateSpellRef
    -- under the opts.useOverrides guard. That is the DISPLAY walk:
    -- Engine:HealOverrideSteps sets { useOverrides = true } and runs on
    -- PLAYER_SPECIALIZATION_CHANGED, TRAIT_CONFIG_UPDATED and the debounced
    -- PLAYER_REGEN_ENABLED.
    --
    -- The defect this pins: a Guardian Druid who UNTALENTS Ravage still has
    -- {spell:441583} stored. The inline call asked the API, got 441583 back,
    -- normalised nothing, and FindSpellOverrideByID then returned it unchanged
    -- because no override is active. So the step list drew Ravage over a
    -- persisted Maul and never self-corrected, since the inline call could not
    -- reach the table that carries 441583 -> 6807.
    --
    -- COST IS A LABEL, NOT A CAST. v2.4.4 persists the base name and this walk
    -- writes no SavedVariables, so nothing here is about a broken macro.
    --
    -- WHY THIS IS NOT A TAUTOLOGY. The fixture API answers 441583 with 441583,
    -- exactly as T8 sets it up and exactly as the live client measured. A build
    -- that kept the inline call therefore gets identity and resolves the Ravage
    -- name; only a build that delegates reaches the SHIPPED table and resolves
    -- Maul. The two disagree and this case reads which one arrived.
    local prevSpell = rawget(env, "C_Spell")
    env.C_Spell = {
        GetSpellName = function(id)
            if id == 6807 then
                return "MaulName"
            elseif id == 441583 then
                return "RavageName"
            end
            return nil
        end,
    }
    local restore = withBaseSpellEnv({ [441583] = 441583, [6807] = 6807 }, SHIPPED_BASE_SPELL_TABLE)
    -- IDENTITY override function: the untalented state, which is the whole
    -- point. If this returned something else the override arm would mask the
    -- base-lookup arm and the case would prove nothing about it.
    env.C_SpellBook.FindSpellOverrideByID = function(id)
        return id
    end

    local withOverrides = SC:TranslateMacrotext("/cast {spell:441583}", "toNames", { useOverrides = true })
    -- CONTROL ONE: the no-opts path, which is what
    -- Engine:RepairPersistedOverrideNames relies on. It must not move, because
    -- this task must not touch the repair path. No opts means the base-lookup
    -- arm is never entered at all, so the id resolves as itself.
    local noOpts = SC:TranslateMacrotext("/cast {spell:441583}", "toNames")
    -- CONTROL TWO: an id with no base link and no table row still resolves as
    -- itself through the SAME useOverrides arm, so a passing case cannot be a
    -- build that rewrites every id it is handed.
    local untouched = SC:TranslateMacrotext("/cast {spell:6807}", "toNames", { useOverrides = true })

    restore()
    env.C_Spell = prevSpell

    -- ORDER MATTERS. The runner pcalls each case, so the first failing assertion
    -- aborts the rest. Both controls are asserted BEFORE the discriminating one,
    -- so on a build that kept the inline call they are seen to pass and the case
    -- fails on the claim it exists for, rather than the controls going
    -- unevaluated and unreportable.
    assertEqual(6807, SHIPPED_BASE_SPELL_TABLE[441583], "T11: Data/Defaults.lua still ships the measured pair")
    assertEqual("/cast RavageName", noOpts, "T11 (control): the no-opts repair path is unchanged")
    assertEqual("/cast MaulName", untouched, "T11 (control): an already-base id resolves as itself")
    assertEqual(
        "/cast MaulName",
        withOverrides,
        "T11: the display walk normalises Ravage to Maul through the table, not to the id the API handed back"
    )
end)

test("T12 GetBaseSpellID -- a malformed BASE_SPELL_TABLE value is rejected, not handed onward", function()
    -- Phase 4b's commit says one function now owns the API call, the
    -- identity-is-a-miss rule, the bounds guard and the fallback table. The
    -- bounds guard half was not literally true: everything above the tail guards
    -- the id handed IN, while the fallback is a raw value out of a hand-curated
    -- table and was never checked.
    --
    -- It matters because of what the caller does next. SC:TranslateSpellRef
    -- assigns resolvedId from this return and then calls FindSpellOverrideByID
    -- on it WITHOUT re-running SC:IsValidSpellID, which only ever saw the
    -- ORIGINAL id. That API throws on out-of-range values rather than returning
    -- nil, and Engine:HealOverrideSteps calls TranslateMacrotext with no pcall,
    -- so a bad row surfaces on PLAYER_SPECIALIZATION_CHANGED or
    -- TRAIT_CONFIG_UPDATED and aborts the heal walk for every sequence after it.
    --
    -- NOT A LIVE DEFECT. The shipped row [441583] = 6807 is well formed and the
    -- control below proves it still resolves. It takes a typo in a FUTURE
    -- measured row to fire, and EMS-OVERRIDE-BASE-MAP-OFFLINE exists to add
    -- exactly those rows, so the exposure widens with every pair added.
    --
    -- The four shapes are the ones measured against the real module on
    -- 2026-08-17, each of which raised "bad argument #1 (outside of expected
    -- range)" before the fix: a digit typo, a sign typo, an accidental quote,
    -- and the reserved value 0.
    local prevSpell = rawget(env, "C_Spell")
    env.C_Spell = {
        GetSpellName = function(id)
            if id == 6807 then
                return "MaulName"
            elseif id == 441583 then
                return "RavageName"
            end
            return nil
        end,
    }

    --- Point the module at one table row and return what the three assertions
    --- below read: the id the function returned, whether the display walk
    --- raised, and the text it resolved to.
    ---
    --- The override stub THROWS outside the signed-32-bit range, mirroring the
    --- live API, so a failure names the raise from FindSpellOverrideByID, which
    --- is the symptom a player would actually hit.
    ---
    --- IT IS NOT WHAT MAKES THIS CASE REAL. An earlier version of this comment
    --- said a nil-returning stub would let the case pass unfixed, and that is
    --- false. Three assertions catch this regression independently, and only the
    --- did-not-raise one needs the throwing stub; half one never reaches the
    --- stub at all, since it reads what SC:GetBaseSpellID returned. Measured
    --- 2026-08-17 across four full reverted trees, Phase 4c EDIT 1 reverted from
    --- bfb1a5e^:
    ---     throwing stub                    11/1, fails on half one
    ---     nil-returning stub               11/1, fails on half one
    ---     nil stub, half one removed       11/1, fails on half three
    ---     throwing stub, half one removed  11/1, fails on half two
    ---
    --- THE REUSABLE PART: a claim that some fixture detail is load-bearing
    --- cannot be tested by swapping that fixture alone, because the first
    --- assertion to fail masks every other one. It needs the other assertions
    --- removed one at a time, which is what the last two rows above are.
    local function probe(rowValue)
        local restore = withBaseSpellEnv({ [441583] = 441583, [6807] = 6807 }, { [441583] = rowValue })
        env.C_SpellBook.FindSpellOverrideByID = function(id)
            if type(id) ~= "number" or id <= 0 or id > 2147483647 then
                error("bad argument #1 to 'FindSpellOverrideByID' (outside of expected range)", 2)
            end
            return id
        end
        local base = SC:GetBaseSpellID(441583)
        local ok, text = pcall(SC.TranslateMacrotext, SC, "/cast {spell:441583}", "toNames", { useOverrides = true })
        restore()
        return base, ok, text
    end

    -- CONTROL FIRST, for the reason Phase 4b established: the runner pcalls each
    -- case and aborts at the first failure, so a control asserted after the
    -- discriminating rows would go unevaluated on a failing build. It also stops
    -- this passing on a build that rejects EVERY fallback.
    local goodBase, goodOK, goodText = probe(6807)

    local shapes = {
        { label = "digit typo", value = 68070000000 },
        { label = "sign typo", value = -6807 },
        { label = "quoted number", value = "6807" },
        { label = "reserved zero", value = 0 },
    }
    local results = {}
    for i = 1, #shapes do
        local base, ok, text = probe(shapes[i].value)
        results[i] = { base = base, ok = ok, text = text }
    end

    env.C_Spell = prevSpell

    assertEqual(6807, goodBase, "T12 (control): the shipped row still answers the base id")
    assertTrue(goodOK, "T12 (control): the display walk did not raise on the shipped row")
    assertEqual("/cast MaulName", goodText, "T12 (control): and it still resolves to the base name")

    for i = 1, #shapes do
        local tag = " [" .. shapes[i].label .. "]"
        local r = results[i]
        -- HALF ONE: the bad value never leaves the function.
        assertEqual(441583, r.base, "T12: the malformed row is rejected and the input is returned" .. tag)
        -- HALF TWO: and the walk that consumes it neither raises nor drops out.
        assertTrue(r.ok, "T12: the display walk did not raise" .. tag .. ": " .. tostring(r.text))
        assertEqual("/cast RavageName", r.text, "T12: it resolves as the unnormalised id" .. tag)
    end
end)

-- ---------------------------------------------------------------------------
-- Run.
-- ---------------------------------------------------------------------------

local passed = 0
local failed = 0
for _, t in ipairs(tests) do
    local ok, err = pcall(t.fn)
    if ok then
        passed = passed + 1
        print("PASS  " .. t.name)
    else
        failed = failed + 1
        print("FAIL  " .. t.name .. " -- " .. tostring(err))
    end
end
print(string.format("RESULT %d passed, %d failed", passed, failed))
os.exit(failed > 0 and 1 or 0)
