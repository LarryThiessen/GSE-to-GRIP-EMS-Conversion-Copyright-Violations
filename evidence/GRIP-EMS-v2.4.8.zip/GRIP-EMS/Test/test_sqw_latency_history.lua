-- GRIP-EMS: Headless test for the SQW optimiser latency sample ring
--
-- Created:    2026-07-19
-- Updated:    2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.
--
-- Standalone (Lua 5.1) test for the latency history capture path: the ring
-- writer SQW:RecordHistory (cap HISTORY_SIZE 30, session-only), the read
-- accessor SQW:GetHistory, and the sampling gate SQW:UpdateLatencySample
-- (EWMA seed / outlier rejection). Drives the REAL Engine/SQWOptimizer.lua
-- via loadfile + setfenv, the same technique as test_cvar_score_history.lua;
-- GetNetStats and GetTime are stubbed so samples are controlled.
--
-- Run from the EMS root:  lua Test/test_sqw_latency_history.lua
-- Exit code 0 = all passed, 1 = at least one failure.
--
-- Cases:
--   T1  RecordHistory appends { time, raw, ewma } entries and preserves order
--   T2  the ring trims oldest-first past HISTORY_SIZE 30; the newest survives
--   T3  GetHistory returns the SAME table the ring mutates (identity check)
--       and its length matches GetState().historyCount
--   T4  UpdateLatencySample rejects an outlier sample (greater than 3x the
--       ewma) WITHOUT recording it, and accepts + records a normal sample

local ADDON_NAME = "GRIP-EMS"

-- ---------------------------------------------------------------------------
-- Minimal assertion + runner harness (mirrors TestSuite Pass/Fail semantics).
-- ---------------------------------------------------------------------------

local tests = {}

local function test(name, fn)
    tests[#tests + 1] = { name = name, fn = fn }
end

local function assertEqual(expected, actual, label)
    if expected ~= actual then
        error((label or "value") .. ": expected " .. tostring(expected) .. ", got " .. tostring(actual), 2)
    end
end

local function assertTrue(cond, label)
    if not cond then
        error((label or "condition") .. ": expected true", 2)
    end
end

-- ---------------------------------------------------------------------------
-- Sandbox: a self-referential no-op stub backs every unknown global so the
-- real module loads without a WoW client. Real stdlib falls through to _G.
-- ---------------------------------------------------------------------------

local stub = {}
setmetatable(stub, {
    __index = function()
        return stub
    end,
    __call = function()
        return stub
    end,
})

local env = setmetatable({}, {
    __index = function(_, k)
        local v = rawget(_G, k)
        if v ~= nil then
            return v
        end
        return stub
    end,
})
env._G = env

-- AceLocale stand-in: every key echoes back so any L["KEY"] format is inert.
local LOCALE = setmetatable({}, {
    __index = function(_, k)
        return k
    end,
})
env.LibStub = function()
    return {
        GetLocale = function()
            return LOCALE
        end,
    }
end
env.strlower = string.lower

-- Deterministic monotonic time for history entries.
local fakeTime = 0
env.GetTime = function()
    fakeTime = fakeTime + 1
    return fakeTime
end
-- Controllable world latency for UpdateLatencySample.
local netLatency = 0
env.GetNetStats = function()
    return 0, 0, 0, netLatency
end
-- GCD surface: no spell cooldown + zero haste so GetCurrentGCD resolves to
-- the deterministic no-haste baseline inside GetState.
env.C_Spell = {
    GetSpellCooldown = function()
        return nil
    end,
}
env.GetHaste = function()
    return 0
end
env.GetCVar = function()
    return nil
end
env.SetCVar = function() end
env.InCombatLockdown = function()
    return false
end

local svStore = {}
local GRIPEMS = {
    version = "headless",
    Print = function() end,
    Debug = function() end,
    Fire = function() end,
    Settings = {
        Get = function(_, key)
            return svStore[key]
        end,
        Set = function(_, key, value)
            svStore[key] = value
        end,
    },
}
env.GRIPEMS = GRIPEMS

-- ---------------------------------------------------------------------------
-- Load the REAL module into the sandbox.
-- ---------------------------------------------------------------------------

local function loadModule(candidates)
    for _, path in ipairs(candidates) do
        -- loadfile is dev-harness file I/O, intentionally outside the addon WoW std.
        -- selene: allow(undefined_variable)
        local chunk = loadfile(path)
        if chunk then
            setfenv(chunk, env)
            chunk(ADDON_NAME, GRIPEMS)
            return true
        end
    end
    return false
end

assert(
    loadModule({
        "Engine/SQWOptimizer.lua",
        "../Engine/SQWOptimizer.lua",
        "GRIP/EMS/Engine/SQWOptimizer.lua",
    }),
    "could not locate Engine/SQWOptimizer.lua (run from the EMS root)"
)

local SQW = GRIPEMS.SQWOptimizer
assert(SQW and SQW.RecordHistory and SQW.GetHistory and SQW.UpdateLatencySample and SQW.GetState, "SQW API missing")

local function reset()
    for k in pairs(svStore) do
        svStore[k] = nil
    end
    SQW.ewmaLatency = nil
    SQW.history = {}
end

-- ---------------------------------------------------------------------------
-- Cases.
-- ---------------------------------------------------------------------------

test("T1 RecordHistory appends { time, raw, ewma } entries, preserves order", function()
    reset()
    SQW.ewmaLatency = 50
    SQW:RecordHistory(10)
    SQW.ewmaLatency = 60
    SQW:RecordHistory(20)
    SQW.ewmaLatency = 70
    SQW:RecordHistory(30)
    assertEqual(3, #SQW.history, "entry count")
    assertEqual(10, SQW.history[1][2], "oldest raw first")
    assertEqual(20, SQW.history[2][2], "middle raw preserved")
    assertEqual(30, SQW.history[3][2], "newest raw last")
    assertEqual(50, SQW.history[1][3], "ewma captured at record time")
    assertEqual(70, SQW.history[3][3], "newest ewma last")
    assertEqual("number", type(SQW.history[1][1]), "entry time is numeric")
    assertTrue(SQW.history[3][1] > SQW.history[1][1], "timestamps advance")
end)

test("T2 ring trims oldest-first past HISTORY_SIZE 30, newest survives", function()
    reset()
    SQW.ewmaLatency = 100
    for i = 1, 35 do
        SQW:RecordHistory(i)
    end
    assertEqual(30, #SQW.history, "capped at 30")
    assertEqual(6, SQW.history[1][2], "five oldest trimmed")
    assertEqual(35, SQW.history[30][2], "newest survives")
end)

test("T3 GetHistory returns the live ring table, length matches GetState", function()
    reset()
    SQW.ewmaLatency = 100
    SQW:RecordHistory(80)
    SQW:RecordHistory(90)
    local view = SQW:GetHistory()
    assertTrue(rawequal(view, SQW.history), "GetHistory returns the ring itself, not a copy")
    assertEqual(2, #view, "view sees existing entries")
    SQW:RecordHistory(95)
    assertEqual(3, #view, "view sees ring mutations")
    assertEqual(#view, SQW:GetState().historyCount, "GetState historyCount matches ring length")
end)

test("T4 UpdateLatencySample rejects outliers, records normal samples", function()
    reset()
    netLatency = 0
    SQW:UpdateLatencySample()
    assertEqual(0, #SQW.history, "zero latency (no data yet) records nothing")
    assertEqual(nil, SQW.ewmaLatency, "zero latency does not seed the ewma")
    netLatency = 100
    SQW:UpdateLatencySample()
    assertEqual(1, #SQW.history, "seed sample records")
    assertEqual(100, SQW.ewmaLatency, "seed sets ewma")
    netLatency = 400
    SQW:UpdateLatencySample()
    assertEqual(1, #SQW.history, "outlier (greater than 3x ewma) is NOT recorded")
    assertEqual(100, SQW.ewmaLatency, "outlier leaves ewma unchanged")
    netLatency = 300
    SQW:UpdateLatencySample()
    assertEqual(2, #SQW.history, "exactly 3x ewma is NOT an outlier (strict comparison)")
    assertEqual(300, SQW.history[2][2], "boundary sample raw is recorded")
    assertTrue(SQW.ewmaLatency > 100 and SQW.ewmaLatency < 300, "boundary sample moves the ewma")
    netLatency = 150
    SQW:UpdateLatencySample()
    assertEqual(3, #SQW.history, "normal sample records")
    assertEqual(150, SQW.history[3][2], "recorded raw is the sampled latency")
    assertEqual(SQW.ewmaLatency, SQW.history[3][3], "recorded ewma is the post-update ewma")
end)

-- ---------------------------------------------------------------------------
-- Run.
-- ---------------------------------------------------------------------------

local passed = 0
local failed = 0
for _, t in ipairs(tests) do
    local ok, err = pcall(t.fn)
    if ok then
        passed = passed + 1
        print("PASS  " .. t.name)
    else
        failed = failed + 1
        print("FAIL  " .. t.name .. " -- " .. tostring(err))
    end
end
print(string.format("RESULT %d passed, %d failed", passed, failed))
os.exit(failed > 0 and 1 or 0)
