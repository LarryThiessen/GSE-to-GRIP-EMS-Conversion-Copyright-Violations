-- GRIP-EMS: Spell Picker
-- Dropdown panel for browsing spells and inserting them (with optional
-- conditionals) into step EditBoxes. Integrates with StepListView and
-- PopupEditor via a small icon button next to each step's EditBox.

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS")

GRIPEMS.SpellPicker = {}
local SP = GRIPEMS.SpellPicker

---------------------------------------------------------------------------
-- Constants
---------------------------------------------------------------------------
local PICKER_WIDTH = 400
local PICKER_HEIGHT = 540
local SPELL_ROW_HEIGHT = 22
local ICON_SIZE = 20
-- MAX_VISIBLE_ROWS reserved for future scroll virtualization
local CONDITIONAL_BUTTONS = {
    "[mod:shift]",
    "[mod:ctrl]",
    "[mod:alt]",
    "[nomod]",
    "[harm]",
    "[help]",
    "[combat]",
    "[nocombat]",
    "[dead]",
    "[nodead]",
    "[channeling]",
}

---------------------------------------------------------------------------
-- State
---------------------------------------------------------------------------
SP._frame = nil
SP._targetEditBox = nil
SP._filterMode = "Spec"
SP._searchText = ""
SP._scrollBox = nil
SP._spellData = {} -- filtered spell list for current display

---------------------------------------------------------------------------
-- Insert text at cursor position in the target EditBox
---------------------------------------------------------------------------

--- Insert text at the cursor position in the active target EditBox.
--- @param text string Text to insert
function SP:InsertText(text)
    local eb = self._targetEditBox
    if not eb then
        return
    end
    eb:Insert(text)
    eb:SetFocus()
end

---------------------------------------------------------------------------
-- Spell filtering
---------------------------------------------------------------------------

--- Collect gear entries (equipped on-use items).
--- @param search string Lowercase search filter
--- @return table Array of gear entries
local function CollectGear(search)
    local results = {}
    for slot = 1, 19 do
        local itemID = GetInventoryItemID("player", slot)
        if itemID then
            local useSpell = GetItemSpell(itemID)
            if useSpell then
                local classID = select(6, C_Item.GetItemInfoInstant(itemID))
                if classID == 2 or classID == 4 then
                    local name = C_Item.GetItemInfo(itemID)
                    if name and (search == "" or name:lower():find(search, 1, true)) then
                        results[#results + 1] = {
                            name = name,
                            spellID = itemID,
                            iconID = GetItemIcon(itemID),
                            _isItem = true,
                        }
                    end
                end
            end
        end
    end
    return results
end

--- Collect consumable entries (bag usable items with classID 0).
--- @param search string Lowercase search filter
--- @return table Array of consumable entries
local function CollectConsumables(search)
    local results = {}
    local seen = {}
    for bag = 0, 5 do
        local numSlots = C_Container.GetContainerNumSlots(bag)
        for slot = 1, numSlots do
            local info = C_Container.GetContainerItemInfo(bag, slot)
            if info and info.itemID and not seen[info.itemID] then
                seen[info.itemID] = true
                local useSpell = GetItemSpell(info.itemID)
                if useSpell then
                    local classID = select(6, C_Item.GetItemInfoInstant(info.itemID))
                    if classID == 0 then
                        local name = C_Item.GetItemInfo(info.itemID)
                        if name and (search == "" or name:lower():find(search, 1, true)) then
                            results[#results + 1] = {
                                name = name,
                                spellID = info.itemID,
                                iconID = GetItemIcon(info.itemID),
                                _isItem = true,
                            }
                        end
                    end
                end
            end
        end
    end
    return results
end

--- Collect generic "Items" entries (bag + warbank, classID not 0/2/4).
--- @param search string Lowercase search filter
--- @return table Array of item entries
local function CollectItems(search)
    local results = {}
    local seen = {}
    local bags = { 0, 1, 2, 3, 4, 5 }
    -- Add warbank tabs if available
    if Enum.BagIndex and Enum.BagIndex.AccountBankTab_1 then
        for tab = Enum.BagIndex.AccountBankTab_1, Enum.BagIndex.AccountBankTab_5 do
            bags[#bags + 1] = tab
        end
    end
    for _, bag in ipairs(bags) do
        local numSlots = C_Container.GetContainerNumSlots(bag)
        for slot = 1, numSlots do
            local info = C_Container.GetContainerItemInfo(bag, slot)
            if info and info.itemID and not seen[info.itemID] then
                seen[info.itemID] = true
                local useSpell = GetItemSpell(info.itemID)
                if useSpell then
                    local classID = select(6, C_Item.GetItemInfoInstant(info.itemID))
                    if classID ~= 0 and classID ~= 2 and classID ~= 4 then
                        local name = C_Item.GetItemInfo(info.itemID)
                        if name and (search == "" or name:lower():find(search, 1, true)) then
                            results[#results + 1] = {
                                name = name,
                                spellID = info.itemID,
                                iconID = GetItemIcon(info.itemID),
                                _isItem = true,
                            }
                        end
                    end
                end
            end
        end
    end
    return results
end

--- Collect toy entries from SpellCache.toyByName.
--- @param search string Lowercase search filter
--- @return table Array of toy entries
local function CollectToys(search)
    local SC = GRIPEMS.SpellCache
    local results = {}
    if not SC or not SC.toyByName then
        return results
    end
    for _, toyItemID in pairs(SC.toyByName) do
        local _, properName, toyIcon = C_ToyBox.GetToyInfo(toyItemID)
        if properName and (search == "" or properName:lower():find(search, 1, true)) then
            results[#results + 1] = {
                name = properName,
                spellID = toyItemID,
                iconID = toyIcon,
                _isToy = true,
            }
        end
    end
    return results
end

--- Collect mount entries from SpellCache.mounts.
--- @param search string Lowercase search filter
--- @return table Array of mount entries
local function CollectMounts(search)
    local SC = GRIPEMS.SpellCache
    local results = {}
    if not SC or not SC.mounts then
        return results
    end
    for _, m in ipairs(SC.mounts) do
        if search == "" or m.name:lower():find(search, 1, true) then
            results[#results + 1] = {
                name = m.name,
                spellID = m.spellID,
                iconID = m.iconID,
                _isMount = true,
            }
        end
    end
    return results
end

--- Collect companion entries from SpellCache.companions.
--- @param search string Lowercase search filter
--- @return table Array of companion entries
local function CollectCompanions(search)
    local SC = GRIPEMS.SpellCache
    local results = {}
    if not SC or not SC.companions then
        return results
    end
    for _, c in ipairs(SC.companions) do
        if search == "" or c.name:lower():find(search, 1, true) then
            results[#results + 1] = {
                name = c.name,
                spellID = c.spellID,
                iconID = c.iconID,
                petID = c.petID,
                _isCompanion = true,
            }
        end
    end
    return results
end

--- Category key mapping for spellbook-based filter modes
local CATEGORY_MAP = {
    Spec = "spec",
    Class = "class",
    Race = "racial",
    Pet = "pet",
    Prof = "profession",
}

--- Get the filtered spell list based on current filter mode and search text.
--- @return table Array of spell entries matching current filters
local function GetFilteredSpells()
    local SC = GRIPEMS.SpellCache
    if not SC or not SC.spells then
        return {}
    end

    local results = {}
    local mode = SP._filterMode
    local search = SP._searchText:lower()

    -- Spellbook-based modes (filter by category)
    local catKey = CATEGORY_MAP[mode]
    if catKey then
        for _, entry in ipairs(SC.spells) do
            local pass
            if catKey == "pet" then
                pass = entry.isPet or entry.category == "pet"
            else
                pass = entry.category == catKey
            end
            if pass and search ~= "" then
                if not entry.name:lower():find(search, 1, true) then
                    pass = false
                end
            end
            if pass then
                results[#results + 1] = entry
            end
        end
    elseif mode == "Gear" then
        results = CollectGear(search)
    elseif mode == "Consumables" then
        results = CollectConsumables(search)
    elseif mode == "Items" then
        results = CollectItems(search)
    elseif mode == "Toys" then
        results = CollectToys(search)
    elseif mode == "Mounts" then
        results = CollectMounts(search)
    elseif mode == "Companions" then
        results = CollectCompanions(search)
    elseif mode == "Other" then
        for _, entry in ipairs(SC.spells) do
            local cat = entry.category
            if cat == "general" or cat == "other" then
                if search == "" or entry.name:lower():find(search, 1, true) then
                    results[#results + 1] = entry
                end
            end
        end
    end

    -- Sort all results alphabetically
    table.sort(results, function(a, b)
        return a.name:lower() < b.name:lower()
    end)

    return results
end

---------------------------------------------------------------------------
-- Row initializer (ScrollBox element)
---------------------------------------------------------------------------

local INT32_MAX = 2147483647
local function SafeSetSpellByID(spellID)
    if spellID and spellID > 0 and spellID <= INT32_MAX then
        GameTooltip:SetSpellByID(spellID)
        return true
    end
    return false
end

local function InitSpellRow(button, data)
    local UI2 = GRIPEMS.UI
    local C = UI2.Colors

    if not button._initialized then
        if not button.SetBackdrop then
            Mixin(button, BackdropTemplateMixin)
        end
        button:SetBackdrop(UI2.Backdrops.panelNoBorder)
        button:SetBackdropColor(0, 0, 0, 0)
        button:SetHeight(SPELL_ROW_HEIGHT)

        button.icon = button:CreateTexture(nil, "ARTWORK")
        button.icon:SetSize(ICON_SIZE, ICON_SIZE)
        button.icon:SetPoint("LEFT", button, "LEFT", 4, 0)

        button.nameLabel = button:CreateFontString(nil, "OVERLAY")
        UI2:SetFont(button.nameLabel, 11)
        button.nameLabel:SetPoint("LEFT", button.icon, "RIGHT", 4, 0)
        button.nameLabel:SetJustifyH("LEFT")
        button.nameLabel:SetWordWrap(false)

        button.idLabel = button:CreateFontString(nil, "OVERLAY")
        UI2:SetFont(button.idLabel, 9)
        button.idLabel:SetPoint("RIGHT", button, "RIGHT", -4, 0)
        button.idLabel:SetJustifyH("RIGHT")
        button.idLabel:SetTextColor(C.textMuted:GetRGBA())

        button._initialized = true
    end

    -- Icon
    button.icon:SetTexture(data.iconID or 134400)

    -- Name (truncate to prevent overflow into ID column)
    local displayName = data.name or ""
    if data.isPet then
        displayName = displayName .. " (Pet)"
    end
    if #displayName > 30 then
        displayName = displayName:sub(1, 28) .. ".."
    end
    button.nameLabel:SetText(displayName)
    button.nameLabel:SetTextColor(C.textPrimary:GetRGBA())
    button.nameLabel:SetPoint("RIGHT", button.idLabel, "LEFT", -4, 0)

    -- ID
    button.idLabel:SetText(data.spellID and tostring(data.spellID) or "")

    -- Tooltip
    button:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.bgRowHover:GetRGBA())
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        if data.isCompanion then
            if data.petID then
                local ok = pcall(GameTooltip.SetCompanionPet, GameTooltip, data.petID)
                if not ok and data.spellID then
                    SafeSetSpellByID(data.spellID)
                end
            elseif data.spellID then
                SafeSetSpellByID(data.spellID)
            end
        elseif data.isItem then
            GameTooltip:SetItemByID(data.spellID)
        elseif data.isToy then
            GameTooltip:SetToyByItemID(data.spellID)
        elseif data.spellID then
            SafeSetSpellByID(data.spellID)
        end
        GameTooltip:Show()
    end)
    button:SetScript("OnLeave", function(self)
        self:SetBackdropColor(0, 0, 0, 0)
        GameTooltip:Hide()
    end)

    -- Click: insert slash command + name
    button:SetScript("OnClick", function()
        local prefix
        if data.isMount then
            prefix = "/cast "
        elseif data.isCompanion then
            prefix = "/summonpet "
        elseif data.isToy then
            prefix = "/use "
        elseif data.isItem then
            prefix = "/use "
        else
            prefix = "/cast "
        end
        SP:InsertText(prefix .. (data.name or ""))
    end)
end

---------------------------------------------------------------------------
-- Refresh the spell list display
---------------------------------------------------------------------------
local function RefreshSpellList()
    local frame = SP._frame
    if not frame or not SP._scrollBox then
        return
    end

    SP._spellData = GetFilteredSpells()
    local data = SP._spellData

    if #data == 0 then
        if frame.noResultsLabel then
            frame.noResultsLabel:Show()
        end
        SP._scrollBox:SetDataProvider(CreateDataProvider())
        return
    end
    if frame.noResultsLabel then
        frame.noResultsLabel:Hide()
    end

    local visibleCount = math.min(#data, 500)
    local dp = CreateDataProvider()
    for i = 1, visibleCount do
        local entry = data[i]
        dp:Insert({
            name = entry.name,
            spellID = entry.spellID,
            iconID = entry.iconID,
            isMount = entry._isMount or false,
            isCompanion = entry._isCompanion or false,
            isItem = entry._isItem or false,
            isToy = entry._isToy or false,
            isPet = entry.isPet or false,
            petID = entry.petID,
        })
    end
    SP._scrollBox:SetDataProvider(dp)
end

---------------------------------------------------------------------------
-- Create the picker frame (lazy, single instance)
---------------------------------------------------------------------------
local function CreatePickerFrame()
    if SP._frame then
        return SP._frame
    end

    local UI = GRIPEMS.UI
    local C = UI.Colors

    local frame = CreateFrame("Frame", "GRIPEMS_SpellPicker", UIParent, "BackdropTemplate")
    frame:SetSize(PICKER_WIDTH, PICKER_HEIGHT)
    frame:SetFrameStrata("DIALOG")
    frame:SetClampedToScreen(true)
    UI:ApplyBackdrop(frame, UI.Backdrops.panel, C.bgMain, C.border)
    frame:EnableKeyboard(true)
    frame:SetScript("OnKeyDown", function(self, key)
        if key == "ESCAPE" then
            self:Hide()
            self:SetPropagateKeyboardInput(false)
        else
            self:SetPropagateKeyboardInput(true)
        end
    end)
    frame:Hide()

    -- Movable via title bar drag
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", function(self)
        self:StartMoving()
    end)
    frame:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
    end)

    -- Title
    local title = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(title, 12)
    title:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, -6)
    title:SetText(L["GEMS_SPELLPICKER_TITLE"])
    title:SetTextColor(C.textPrimary:GetRGBA())

    -- Close button
    local closeBtn = CreateFrame("Button", nil, frame)
    closeBtn:SetSize(16, 16)
    closeBtn:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -4, -4)
    closeBtn:SetNormalTexture("Interface\\Buttons\\UI-Panel-MinimizeButton-Up")
    closeBtn:SetScript("OnClick", function()
        frame:Hide()
    end)

    -- Search EditBox
    local searchBox = CreateFrame("EditBox", nil, frame, "BackdropTemplate")
    searchBox:SetSize(PICKER_WIDTH - 16, 22)
    searchBox:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, -24)
    searchBox:SetAutoFocus(false)
    searchBox:SetMaxLetters(50)
    UI:ApplyBackdrop(searchBox, UI.Backdrops.panel, C.bgInput, C.border)
    searchBox:SetTextInsets(6, 6, 2, 2)
    local fontPath = GameFontNormal:GetFont()
    searchBox:SetFont(fontPath, 11, "")
    searchBox:SetTextColor(C.textPrimary:GetRGBA())

    -- Placeholder text
    searchBox._placeholder = searchBox:CreateFontString(nil, "OVERLAY")
    UI:SetFont(searchBox._placeholder, 11)
    searchBox._placeholder:SetPoint("LEFT", searchBox, "LEFT", 8, 0)
    searchBox._placeholder:SetText(L["GEMS_SPELLPICKER_SEARCH"])
    searchBox._placeholder:SetTextColor(C.textMuted:GetRGBA())

    searchBox:SetScript("OnTextChanged", function(self, userInput)
        local text = self:GetText() or ""
        if text == "" then
            self._placeholder:Show()
        else
            self._placeholder:Hide()
        end
        SP._searchText = text
        RefreshSpellList()
    end)
    searchBox:SetScript("OnEditFocusGained", function(self)
        self._placeholder:Hide()
    end)
    searchBox:SetScript("OnEditFocusLost", function(self)
        if (self:GetText() or "") == "" then
            self._placeholder:Show()
        end
    end)
    searchBox:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
    end)
    frame.searchBox = searchBox

    -- Filter tabs (2 rows of 6: row 1 = spellbook, row 2 = collections)
    local filterModes = {
        { key = "Spec", label = L["GEMS_SPELLPICKER_SPEC"] },
        { key = "Class", label = L["GEMS_SPELLPICKER_CLASS"] },
        { key = "Race", label = L["GEMS_SPELLPICKER_RACE"] },
        { key = "Pet", label = L["GEMS_SPELLPICKER_PET"] },
        { key = "Prof", label = L["GEMS_SPELLPICKER_PROF"] },
        { key = "Other", label = L["GEMS_SPELLPICKER_OTHER"] },
        { key = "Gear", label = L["GEMS_SPELLPICKER_GEAR"] },
        { key = "Consumables", label = L["GEMS_SPELLPICKER_CONSUMABLES"] },
        { key = "Items", label = L["GEMS_SPELLPICKER_ITEMS"] },
        { key = "Toys", label = L["GEMS_SPELLPICKER_TOYS"] },
        { key = "Mounts", label = L["GEMS_SPELLPICKER_MOUNTS"] },
        { key = "Companions", label = L["GEMS_SPELLPICKER_COMPANIONS"] },
    }
    local filterBtns = {}
    local row1Y = -50
    local row2Y = -70
    local ROW2_START = 7 -- first index of row 2
    -- Hardcoded tab widths (GetStringWidth returns 0 before first show)
    local TAB_WIDTHS = {
        Spec = 50,
        Class = 54,
        Race = 50,
        Pet = 80,
        Prof = 50,
        Other = 54,
        Gear = 50,
        Consumables = 84,
        Items = 54,
        Toys = 50,
        Mounts = 60,
        Companions = 80,
    }
    for idx, fm in ipairs(filterModes) do
        local btn = CreateFrame("Button", nil, frame, "BackdropTemplate")
        local tabW = TAB_WIDTHS[fm.key] or 60
        btn:SetSize(tabW, 18)
        btn:SetBackdrop(UI.Backdrops.panelNoBorder)

        local btnLabel = btn:CreateFontString(nil, "OVERLAY")
        UI:SetFont(btnLabel, 10)
        btnLabel:SetPoint("CENTER", btn, "CENTER")
        btnLabel:SetText(fm.label)
        btnLabel:SetWidth(tabW - 4)
        btnLabel:SetWordWrap(false)
        btn._label = btnLabel
        btn._filterKey = fm.key

        if idx == 1 then
            btn:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, row1Y)
        elseif idx == ROW2_START then
            btn:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, row2Y)
        else
            btn:SetPoint("LEFT", filterBtns[idx - 1], "RIGHT", 2, 0)
        end

        btn:SetScript("OnClick", function(self)
            SP._filterMode = self._filterKey
            for _, fb in ipairs(filterBtns) do
                if fb._filterKey == SP._filterMode then
                    fb:SetBackdropColor(C.bgRowSelected:GetRGBA())
                    fb._label:SetTextColor(C.textPrimary:GetRGBA())
                else
                    fb:SetBackdropColor(0, 0, 0, 0)
                    fb._label:SetTextColor(C.textSecondary:GetRGBA())
                end
            end
            RefreshSpellList()
        end)

        filterBtns[idx] = btn
    end
    frame._filterBtns = filterBtns

    -- Set initial filter state
    filterBtns[1]:SetBackdropColor(C.bgRowSelected:GetRGBA())
    filterBtns[1]._label:SetTextColor(C.textPrimary:GetRGBA())
    for i = 2, #filterBtns do
        filterBtns[i]:SetBackdropColor(0, 0, 0, 0)
        filterBtns[i]._label:SetTextColor(C.textSecondary:GetRGBA())
    end

    ---------------------------------------------------------------------------
    -- Spell scroll area (ScrollBox + MinimalScrollBar)
    ---------------------------------------------------------------------------
    local scrollBox = CreateFrame("Frame", nil, frame, "WowScrollBoxList")
    scrollBox:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, -92)
    scrollBox:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -22, 130)
    SP._scrollBox = scrollBox

    local scrollBar = CreateFrame("EventFrame", nil, frame, "MinimalScrollBar")
    scrollBar:SetPoint("TOPLEFT", scrollBox, "TOPRIGHT", 2, 0)
    scrollBar:SetPoint("BOTTOMLEFT", scrollBox, "BOTTOMRIGHT", 2, 0)

    local scrollView = CreateScrollBoxListLinearView()
    scrollView:SetElementExtent(SPELL_ROW_HEIGHT)
    scrollView:SetElementInitializer("Button", function(button, data)
        InitSpellRow(button, data)
    end)
    ScrollUtil.InitScrollBoxListWithScrollBar(scrollBox, scrollBar, scrollView)
    scrollBox:SetDataProvider(CreateDataProvider())

    -- No results label
    local noResults = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(noResults, 11)
    noResults:SetPoint("CENTER", scrollBox, "CENTER")
    noResults:SetText(L["GEMS_SPELLPICKER_NO_RESULTS"])
    noResults:SetTextColor(C.textMuted:GetRGBA())
    noResults:Hide()
    frame.noResultsLabel = noResults

    ---------------------------------------------------------------------------
    -- Conditionals section (bottom)
    ---------------------------------------------------------------------------
    local condHeader = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(condHeader, 10)
    condHeader:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 8, 112)
    condHeader:SetText(L["GEMS_SPELLPICKER_CONDITIONALS"])
    condHeader:SetTextColor(C.textSecondary:GetRGBA())

    -- Conditional buttons grid (3 rows of buttons)
    local btnWidth = 80
    local btnHeight = 18
    local btnsPerRow = 3
    local startY = 90

    for i, cond in ipairs(CONDITIONAL_BUTTONS) do
        local cbtn = CreateFrame("Button", nil, frame, "BackdropTemplate")
        cbtn:SetSize(btnWidth, btnHeight)
        cbtn:SetBackdrop(UI.Backdrops.panelNoBorder)
        cbtn:SetBackdropColor(C.bgButton:GetRGBA())

        local row = math.floor((i - 1) / btnsPerRow)
        local col = (i - 1) % btnsPerRow
        cbtn:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 8 + col * (btnWidth + 4), startY - row * (btnHeight + 2))

        local cLabel = cbtn:CreateFontString(nil, "OVERLAY")
        UI:SetFont(cLabel, 9)
        cLabel:SetPoint("CENTER", cbtn, "CENTER")
        cLabel:SetText(cond)
        cLabel:SetTextColor(C.textPrimary:GetRGBA())

        cbtn:SetScript("OnClick", function()
            SP:InsertText(cond)
        end)
        cbtn:SetScript("OnEnter", function(self)
            self:SetBackdropColor(C.bgRowHover:GetRGBA())
        end)
        cbtn:SetScript("OnLeave", function(self)
            self:SetBackdropColor(C.bgButton:GetRGBA())
        end)
    end

    -- Custom conditional EditBox
    local customLabel = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(customLabel, 9)
    customLabel:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 8, 6)
    customLabel:SetText(L["GEMS_SPELLPICKER_CUSTOM"])
    customLabel:SetTextColor(C.textSecondary:GetRGBA())

    local customBox = CreateFrame("EditBox", nil, frame, "BackdropTemplate")
    customBox:SetSize(200, 20)
    customBox:SetPoint("LEFT", customLabel, "RIGHT", 4, 0)
    customBox:SetAutoFocus(false)
    customBox:SetMaxLetters(100)
    UI:ApplyBackdrop(customBox, UI.Backdrops.panel, C.bgInput, C.border)
    customBox:SetBackdropBorderColor(C.textMuted:GetRGBA())
    customBox:SetTextInsets(4, 4, 2, 2)
    customBox:SetFont(fontPath, 10, "")
    customBox:SetTextColor(C.textPrimary:GetRGBA())
    customBox:SetScript("OnEnterPressed", function(self)
        local text = self:GetText() or ""
        if text ~= "" then
            SP:InsertText(text)
            self:SetText("")
        end
        self:ClearFocus()
    end)
    customBox:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
    end)

    -- Insert custom button
    local insertBtn = UI:CreateButton(frame, L["GEMS_SPELLPICKER_INSERT"], 50, 20)
    insertBtn:SetPoint("LEFT", customBox, "RIGHT", 4, 0)
    insertBtn:SetScript("OnClick", function()
        local text = customBox:GetText() or ""
        if text ~= "" then
            SP:InsertText(text)
            customBox:SetText("")
        end
    end)

    SP._frame = frame
    return frame
end

---------------------------------------------------------------------------
-- Show / Hide
---------------------------------------------------------------------------

--- Show the spell picker anchored to a button, targeting the given EditBox.
--- @param editBox EditBox The EditBox to insert text into
--- @param anchorBtn Button|nil Optional button to anchor the picker to
function SP:Show(editBox, anchorBtn)
    if not editBox then
        return
    end

    local frame = CreatePickerFrame()
    self._targetEditBox = editBox
    self._searchText = ""
    self._filterMode = "Spec"

    -- Reset search box
    if frame.searchBox then
        frame.searchBox:SetText("")
    end

    -- Reset filter buttons
    if frame._filterBtns then
        local C = GRIPEMS.UI.Colors
        for i, btn in ipairs(frame._filterBtns) do
            if i == 1 then
                btn:SetBackdropColor(C.bgRowSelected:GetRGBA())
                btn._label:SetTextColor(C.textPrimary:GetRGBA())
            else
                btn:SetBackdropColor(0, 0, 0, 0)
                btn._label:SetTextColor(C.textSecondary:GetRGBA())
            end
        end
    end

    -- Anchor to button or EditBox
    frame:ClearAllPoints()
    local anchor = anchorBtn or editBox
    frame:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", 0, -2)

    RefreshSpellList()
    frame:Show()
end

--- Hide the spell picker.
function SP:Hide()
    if self._frame then
        self._frame:Hide()
    end
    self._targetEditBox = nil
end

--- Toggle the spell picker for the given EditBox.
--- @param editBox EditBox The EditBox to insert text into
--- @param anchorBtn Button|nil Optional anchor button
function SP:Toggle(editBox, anchorBtn)
    if self._frame and self._frame:IsShown() and self._targetEditBox == editBox then
        self:Hide()
    else
        self:Show(editBox, anchorBtn)
    end
end
