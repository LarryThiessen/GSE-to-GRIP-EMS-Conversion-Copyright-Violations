-- GRIP-EMS: Headless test for display-time spell-override resolution
--
-- Created:    2026-08-17
-- Updated:    2026-08-17
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
--
-- STALE-OVERRIDE-STEP-TEXT, the DISPLAY half. Stage 1 removed the write:
-- Engine:HealOverrideSteps no longer touches version.steps / keyPress /
-- keyRelease, and files the resolved name in Engine._overrideDisplay instead.
-- That only helps if the draw path spends it, so this drives the REAL
-- SLV:InitRow against the REAL Engine walk and reads back what the row was
-- told to show.
--
-- Why the display layer is where override resolution belongs: WoW resolves
-- /cast <base name> through whatever override is live, so the persisted base
-- name is what casts. Measured on a live Guardian Druid 2026-08-17
-- (Research/Override_Name_Castability_Probe_2026-08-17.md): Maul 6807 is
-- castable, known and in the spellbook, while Ravage 441583 resolves to an ID
-- but not to a castable name. Being wrong HERE costs a label; being wrong in
-- SavedVariables costs a macro that does nothing.
--
-- NOTE THE GUARD THAT IS DELIBERATELY ABSENT. The fix proposed on the report
-- thread keyed on C_Spell.DoesSpellExist(name) == false. The same probe
-- falsified it -- Lunar Beam and Incarnation both measured false on a character
-- that casts them, because the NAME form answers a question about the current
-- build rather than about the spell. No case below asserts anything about that
-- predicate because no code under test consults it.
--
-- Run from the EMS root:  lua Test/test_override_display_draw.lua
-- Exit code 0 = all passed, 1 = at least one failure.
--
-- Cases:
--   D1  the REAL InitRow draws the RESOLVED name when an override is live
--   D2  the REAL InitRow draws the PERSISTED text when none is
--   D3  a row the player has EDITED keeps what they typed, not the resolved name
--   D4  neither branch mutates the version table (byte-identical across draws)
--   D5  the helper absorbs every miss without raising and never returns nil
--
-- STUB AUDIT.
--   GRIPEMS.SpellCache  TranslateMacrotext resolves "TAG:<id>" through an
--                       override table so the walk produces a real NAME rather
--                       than a fixed prefix. LIVE: SC:TranslateSpellRef ->
--                       C_SpellBook.FindSpellOverrideByID. DIFFERS -- no real
--                       spell is resolved -- so no case asserts a translation
--                       is CORRECT, only which string reached the row.
--                       ready = true because the heal returns early without
--                       it; the table simply does not carry
--                       ResolveSpellIDsInText, so the draw path skips that
--                       step, whose job is unrelated here.
--   GRIPEMS.SpellValidator  absent, so the step-number colouring block is
--                       skipped. LIVE: the real validator. Colour is not what
--                       these cases observe.
--   row widgets         a recording stepText plus a catch-all backing every
--                       other child. LIVE: real FontStrings and Frames. The
--                       OBSERVABLE is the string handed to stepText:SetText,
--                       which is exactly what the user reads off the row.
--   env.InCombatLockdown  false throughout: the heal's combat gate is pinned by
--                       O1/O2 in test_stepadv_numsteps_domain.lua, not here.

local ADDON_NAME = "GRIP-EMS"

-- ---------------------------------------------------------------------------
-- Minimal assertion + runner harness.
-- ---------------------------------------------------------------------------

local tests = {}

local function test(name, fn)
    tests[#tests + 1] = { name = name, fn = fn }
end

local function assertEqual(expected, actual, label)
    if expected ~= actual then
        error((label or "value") .. ": expected " .. tostring(expected) .. ", got " .. tostring(actual), 2)
    end
end

local function assertTrue(cond, label)
    if not cond then
        error((label or "condition") .. " failed", 2)
    end
end

-- ---------------------------------------------------------------------------
-- Sandbox: a self-referential no-op stub backs every unknown global so the real
-- modules load without a WoW client. Real stdlib falls through to _G.
-- ---------------------------------------------------------------------------

local stub = {}
setmetatable(stub, {
    __index = function()
        return stub
    end,
    __call = function()
        return stub
    end,
})

local env = setmetatable({}, {
    __index = function(_, k)
        local v = rawget(_G, k)
        if v ~= nil then
            return v
        end
        return stub
    end,
})
env._G = env

-- AceLocale stand-in: every key echoes back so any L["KEY"] format is inert.
local LOCALE = setmetatable({}, {
    __index = function(_, k)
        return k
    end,
})
env.LibStub = function()
    return {
        GetLocale = function()
            return LOCALE
        end,
    }
end

-- The heal's combat gate is not what this file pins; keep it open throughout.
env.InCombatLockdown = function()
    return false
end

-- ---------------------------------------------------------------------------
-- GRIPEMS control table.
-- ---------------------------------------------------------------------------

local GRIPEMS = {
    version = "headless",
    Print = function() end,
    Debug = function() end,
    Fire = function() end,
    Defaults = {
        STEP_SEQUENTIAL = "Sequential",
        STEP_RANDOM = "Random",
        STEP_PRIORITY = "Priority",
        STEP_REVERSE_PRIORITY = "ReversePriority",
        ATTR_TYPE_MACRO = "macro",
        MAX_MACROTEXT_LENGTH = 255,
        MAX_SAB_MACROTEXT_LENGTH = 255,
        CONTEXT_NONE = "none",
        OOC_OP_RECOMPILE = "recompile",
        OOC_OP_SETTING = "setting",
        ACTION_TYPE_ACTION = "action",
        ACTION_SUBTYPE_MACROREF = "macroref",
        OVERRIDE_HEAL_DEBOUNCE = 0.5,
        SPELL_STATUS_UNKNOWN = "unknown",
        SPELL_STATUS_KNOWN = "known",
        SPELL_STATUS_CONTEXTUAL = "contextual",
        -- Real values from Data/Defaults.lua. The row's char-count readout
        -- formats against these with %d, and Lua 5.1 raises on a nil there --
        -- a stub table cannot stand in for a number.
        CHAR_COUNT_DANGER = 255,
        CHAR_COUNT_WARNING = 200,
    },
    Settings = {
        GetResetModifiers = function()
            return {}
        end,
    },
    OOCQueue = {
        IsRestricted = function()
            return true
        end,
        Add = function(_, fn)
            fn()
        end,
    },
    MacroManager = {
        UpdateIcon = function() end,
        UpdateStubBody = function() end,
    },
    KeybindManager = {},
    Popup = {
        Define = function() end,
        Show = function() end,
    },
    -- StepListView reads UI.Colors at draw time; every colour answers GetRGBA.
    UI = {
        Colors = setmetatable({}, {
            __index = function()
                return {
                    GetRGBA = function()
                        return 1, 1, 1, 1
                    end,
                }
            end,
        }),
    },
    -- The editor state the draw path reads to know WHICH sequence and version
    -- it is drawing. Set per case.
    SequenceEditor = { currentSequence = nil, activeVersionIndex = 1 },
}

-- ---------------------------------------------------------------------------
-- Load the REAL modules into the sandbox.
-- ---------------------------------------------------------------------------

local function loadModule(candidates)
    for _, path in ipairs(candidates) do
        -- loadfile is dev-harness file I/O, intentionally outside the addon WoW std.
        -- selene: allow(undefined_variable)
        local chunk = loadfile(path)
        if chunk then
            setfenv(chunk, env)
            chunk(ADDON_NAME, GRIPEMS)
            return true
        end
    end
    return false
end

assert(
    loadModule({
        "Engine/StepFunctions.lua",
        "../Engine/StepFunctions.lua",
        "GRIP/EMS/Engine/StepFunctions.lua",
    }),
    "could not locate Engine/StepFunctions.lua (run from the EMS root)"
)
assert(
    loadModule({
        "Engine/Engine.lua",
        "../Engine/Engine.lua",
        "GRIP/EMS/Engine/Engine.lua",
    }),
    "could not locate Engine/Engine.lua (run from the EMS root)"
)
assert(
    loadModule({
        "UI/StepListView.lua",
        "../UI/StepListView.lua",
        "GRIP/EMS/UI/StepListView.lua",
    }),
    "could not locate UI/StepListView.lua (run from the EMS root)"
)

local Engine = GRIPEMS.Engine
local SLV = GRIPEMS.StepListView
assert(Engine ~= nil, "Engine loaded")
assert(SLV ~= nil, "StepListView loaded")
assert(type(Engine.HealOverrideSteps) == "function", "HealOverrideSteps defined")
assert(type(Engine.GetOverrideDisplay) == "function", "GetOverrideDisplay defined")
assert(type(SLV.InitRow) == "function", "InitRow defined")
assert(type(SLV.ResolveOverrideDisplayText) == "function", "ResolveOverrideDisplayText defined")
Engine.sequences = {}
Engine.RecompileSequence = function() end

-- ---------------------------------------------------------------------------
-- Fixtures.
-- ---------------------------------------------------------------------------

local OVERRIDE_NAMES = { [100] = "BaseSpell", [200] = "VariantSpell", [300] = "OtherSpell" }

--- Install a SpellCache whose translator really resolves "TAG:<id>" through an
--- override table. The table is read through a GETTER, not captured, so a case
--- can swap the whole thing between walks.
local function installSpellCache(getOverrides)
    GRIPEMS.SpellCache = {
        -- true because HealOverrideSteps returns early without it. The draw
        -- path still skips ResolveSpellIDsInText because this table simply does
        -- not carry that method, so the string reaching stepText is the one
        -- under test and nothing else.
        ready = true,
        StepToString = function(_, text)
            return type(text) == "string" and text or ""
        end,
        TranslateMacrotext = function(_, text, _, opts)
            local id = tonumber(tostring(text):match("^TAG:(%d+)$"))
            if not id then
                return tostring(text)
            end
            if opts and opts.useOverrides then
                id = (getOverrides() or {})[id] or id
            end
            return "/cast " .. (OVERRIDE_NAMES[id] or ("spell:" .. tostring(id)))
        end,
    }
end

--- A one-sequence store in the shape HealOverrideSteps walks. Returns the
--- version table so a case can snapshot it. Paired with clearStore().
local function installStore(name)
    -- Step 2 is the CONTROL row throughout: its tag has no override, so it
    -- resolves to exactly its own stored text and the walk records nothing for
    -- it. A build that substitutes indiscriminately changes this row too.
    local ver = {
        stepFunction = "Sequential",
        steps = { "/cast BaseSpell", "/cast OtherSpell" },
        taggedSteps = { "TAG:100", "TAG:300" },
        keyPress = "",
        keyRelease = "",
    }
    rawset(env, "GRIP_EMS_CHAR", {
        sequences = { [name] = { name = name, defaultVersion = 1, versions = { ver } } },
    })
    GRIPEMS.SequenceEditor.currentSequence = name
    GRIPEMS.SequenceEditor.activeVersionIndex = 1
    return ver
end

local function clearStore()
    rawset(env, "GRIP_EMS_CHAR", nil)
    Engine._overrideDisplay = nil
    GRIPEMS.SpellCache = nil
    GRIPEMS.SequenceEditor.currentSequence = nil
end

--- Snapshot every persisted field of a version as one comparable string. Lua
--- compares strings by value, so equality on this IS a byte-identity check.
local function persistedSnapshot(ver)
    return table.concat(ver.steps, "\1")
        .. "\2"
        .. table.concat(ver.taggedSteps, "\1")
        .. "\2"
        .. tostring(ver.keyPress)
        .. "\2"
        .. tostring(ver.keyRelease)
end

--- A row frame of the shape InitRow drives. Every child is a catch-all stub
--- except stepText, whose SetText is recorded -- that string is what the user
--- reads off the row, so it is the observable.
local function makeRow()
    local drawn = {}
    -- Self-referential AND callable, the same shape the sandbox catch-all uses:
    -- a row frame is indexed both for child widgets (button.dragHandle) and for
    -- methods (button:SetHeight), and one table has to answer both.
    local rowStub = {}
    setmetatable(rowStub, {
        __index = function()
            return rowStub
        end,
        __call = function()
            return rowStub
        end,
    })
    local stepText = setmetatable({}, {
        __index = function()
            return rowStub
        end,
    })
    stepText.SetText = function(_, s)
        drawn[#drawn + 1] = s
    end
    local button = setmetatable({ stepText = stepText }, {
        __index = function()
            return rowStub
        end,
    })
    return button, drawn
end

--- Drive the REAL SLV:InitRow for one flat step row and return what the row was
--- told to display. Returns nil when the draw raised, with the error second.
local function drawRow(index, text)
    local button, drawn = makeRow()
    local ok, err = pcall(SLV.InitRow, SLV, button, {
        rowType = "step",
        index = index,
        text = text,
        charCount = #text,
    })
    if not ok then
        return nil, err
    end
    return drawn[#drawn], nil
end

-- ---------------------------------------------------------------------------
-- Cases.
-- ---------------------------------------------------------------------------

test("D1 (wired): the REAL InitRow draws the RESOLVED name while an override is live", function()
    installSpellCache(function()
        return { [100] = 200 }
    end)
    local ver = installStore("D1_Seq")
    local ok, err = pcall(Engine.HealOverrideSteps, Engine)
    local entry = Engine:GetOverrideDisplay("D1_Seq", 1)
    local shown, drawErr = drawRow(1, ver.steps[1])
    -- CONTROL in the same draw: step 2's tag has no override, so its row must
    -- come back untouched. Without it this case could pass on a build that
    -- substitutes indiscriminately.
    local shownUntouched, drawErr2 = drawRow(2, ver.steps[2])
    clearStore()

    assertTrue(ok, "D1: HealOverrideSteps raised: " .. tostring(err))
    assertTrue(entry ~= nil, "D1: the walk recorded a display entry for the version")
    assertEqual(nil, drawErr, "D1: InitRow raised on the overridden row")
    assertEqual(nil, drawErr2, "D1: InitRow raised on the control row")
    assertEqual("/cast VariantSpell", shown, "D1: the row shows the resolved override name")
    assertEqual("/cast OtherSpell", shownUntouched, "D1 (control): a step with no override shows its stored text")
end)

test("D2 (fallback): the REAL InitRow draws the PERSISTED text when nothing is resolved", function()
    installSpellCache(function()
        return {}
    end)
    local ver = installStore("D2_Seq")
    local ok, err = pcall(Engine.HealOverrideSteps, Engine)
    local entry = Engine:GetOverrideDisplay("D2_Seq", 1)
    local shown, drawErr = drawRow(1, ver.steps[1])
    clearStore()

    assertTrue(ok, "D2: HealOverrideSteps raised: " .. tostring(err))
    assertEqual(nil, entry, "D2: no override is live, so no entry was recorded")
    assertEqual(nil, drawErr, "D2: InitRow raised")
    assertEqual("/cast BaseSpell", shown, "D2: the row shows the stored base name, exactly as before the fix")
end)

test("D3 (edited row): what the player typed wins over the resolved name", function()
    -- The editor draws a WORKING copy. A build that keyed only on the step
    -- INDEX would paint the resolved name over a row the player just retyped,
    -- which is the display-side version of the defect being fixed.
    installSpellCache(function()
        return { [100] = 200 }
    end)
    local ver = installStore("D3_Seq")
    local ok, err = pcall(Engine.HealOverrideSteps, Engine)
    local entry = Engine:GetOverrideDisplay("D3_Seq", 1)
    -- Same row index, text the player has since changed.
    local shown, drawErr = drawRow(1, "/cast SomethingElse")
    -- And the unedited row still resolves, so this is not passing by the
    -- feature being dead.
    local shownClean = drawRow(1, ver.steps[1])
    clearStore()

    assertTrue(ok, "D3: HealOverrideSteps raised: " .. tostring(err))
    assertTrue(entry ~= nil, "D3: an entry exists for step 1")
    assertEqual(nil, drawErr, "D3: InitRow raised")
    assertEqual("/cast SomethingElse", shown, "D3: the edited row shows what the player typed")
    assertEqual("/cast VariantSpell", shownClean, "D3 (control): the unedited row still resolves")
end)

test("D4 (read-only): drawing mutates NOTHING on the version table", function()
    installSpellCache(function()
        return { [100] = 200 }
    end)
    local ver = installStore("D4_Seq")
    local before = persistedSnapshot(ver)
    local ok, err = pcall(Engine.HealOverrideSteps, Engine)
    local afterHeal = persistedSnapshot(ver)
    -- Draw BOTH branches: the resolved row and the fallback row.
    drawRow(1, ver.steps[1])
    drawRow(2, ver.steps[2])
    local afterResolvedDraws = persistedSnapshot(ver)
    -- Now the fallback-only world, on the SAME version table.
    Engine._overrideDisplay = nil
    drawRow(1, ver.steps[1])
    local afterFallbackDraw = persistedSnapshot(ver)
    clearStore()

    assertTrue(ok, "D4: HealOverrideSteps raised: " .. tostring(err))
    assertEqual(before, afterHeal, "D4: the heal itself wrote nothing")
    assertEqual(before, afterResolvedDraws, "D4: drawing the resolved branch wrote nothing")
    assertEqual(before, afterFallbackDraw, "D4: drawing the fallback branch wrote nothing")
end)

test("D5 (misses): the resolver absorbs every miss and never returns nil", function()
    installSpellCache(function()
        return { [100] = 200 }
    end)
    local ver = installStore("D5_Seq")
    local ok, err = pcall(Engine.HealOverrideSteps, Engine)

    local noIndex = SLV:ResolveOverrideDisplayText(ver.steps[1], nil)
    local badIndex = SLV:ResolveOverrideDisplayText(ver.steps[1], 99)
    local nonString = SLV:ResolveOverrideDisplayText(nil, 1)
    -- No sequence open in the editor at all -- the tab can be drawn before a
    -- sequence is loaded.
    GRIPEMS.SequenceEditor.currentSequence = nil
    local noSequence = SLV:ResolveOverrideDisplayText(ver.steps[1], 1)
    -- And with the whole Engine absent, which is the load-order worst case.
    local prevEngine = GRIPEMS.Engine
    GRIPEMS.Engine = nil
    local noEngine = SLV:ResolveOverrideDisplayText(ver.steps[1], 1)
    GRIPEMS.Engine = prevEngine
    clearStore()

    assertTrue(ok, "D5: HealOverrideSteps raised: " .. tostring(err))
    assertEqual("/cast BaseSpell", noIndex, "D5: a nil step index returns the text unchanged")
    assertEqual("/cast BaseSpell", badIndex, "D5: an out-of-range step index returns the text unchanged")
    assertEqual(nil, nonString, "D5: a non-string text is handed straight back, not coerced")
    assertEqual("/cast BaseSpell", noSequence, "D5: no open sequence returns the text unchanged")
    assertEqual("/cast BaseSpell", noEngine, "D5: no Engine at all returns the text unchanged")
end)

-- ---------------------------------------------------------------------------
-- Run.
-- ---------------------------------------------------------------------------

local passed = 0
local failed = 0
for _, t in ipairs(tests) do
    local ok, err = pcall(t.fn)
    if ok then
        passed = passed + 1
        print("PASS  " .. t.name)
    else
        failed = failed + 1
        print("FAIL  " .. t.name .. " -- " .. tostring(err))
    end
end
print(string.format("RESULT %d passed, %d failed", passed, failed))
os.exit(failed > 0 and 1 or 0)
