-- GRIP-EMS: Settings
-- AceDB-3.0 profile-based settings with migration from legacy storage

local ADDON_NAME, GRIPEMS = ...

GRIPEMS.Settings = {}
local S = GRIPEMS.Settings

-- AceDB defaults (profile-scoped)
S.defaults = {
    profile = {
        clickRate = 250,       -- ms between step advances (100-1000)
        oocDelay = 7,          -- seconds for OOC fallback ticker (1-60)
        resetOOC = true,       -- default resetOnCombat for new sequences
        debug = false,         -- debug logging to chat
        hideLoginMsg = false,  -- suppress login banner
        p2pEnabled = true,           -- enable/disable P2P transmission
        p2pAutoAcceptFriends = false, -- auto-import from friends (no prompt)
        p2pAnnounceReceive = true,   -- print chat message on receive
    },
}

--- Initialize the AceDB instance and migrate legacy settings.
--- Called from Core.lua ADDON_LOADED after raw SavedVariables init.
function S:Initialize()
    self.db = LibStub("AceDB-3.0"):New("GRIP_EMS_Settings", self.defaults, true)

    -- Migration: debug flag from per-char config
    if _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.config
        and GRIP_EMS_CHAR.config.debug == true
        and self.db.profile.debug == false then
        self.db.profile.debug = true
    end
    if _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.config then
        GRIP_EMS_CHAR.config.debug = nil
    end

    -- Migration: legacy GRIP_EMS_DB.settings (previous dev builds)
    if _G.GRIP_EMS_DB and GRIP_EMS_DB.settings then
        for k, v in pairs(GRIP_EMS_DB.settings) do
            if self.defaults.profile[k] ~= nil then
                self.db.profile[k] = v
            end
        end
        GRIP_EMS_DB.settings = nil
    end

    -- Register profile callbacks so UI updates on profile switch
    self.db.RegisterCallback(self, "OnProfileChanged", "OnProfileChanged")
    self.db.RegisterCallback(self, "OnProfileCopied", "OnProfileChanged")
    self.db.RegisterCallback(self, "OnProfileReset", "OnProfileChanged")
end

--- Callback for profile switch/copy/reset. Fires SETTING_CHANGED for all keys.
function S:OnProfileChanged()
    if GRIPEMS.Fire then
        GRIPEMS:Fire("SETTING_CHANGED", "clickRate", self:Get("clickRate"))
        GRIPEMS:Fire("SETTING_CHANGED", "debug", self:Get("debug"))
    end
end

--- Get a setting value from the active profile, with defaults fallback.
--- @param key string Setting key
--- @return any value
function S:Get(key)
    if self.db and self.db.profile[key] ~= nil then
        return self.db.profile[key]
    end
    return self.defaults.profile[key]
end

--- Set a setting value in the active profile and fire a callback.
--- @param key string Setting key
--- @param value any New value
function S:Set(key, value)
    if self.db then
        self.db.profile[key] = value
    end
    if GRIPEMS.Fire then
        GRIPEMS:Fire("SETTING_CHANGED", key, value)
    end
end

--- Get click rate as seconds (for restricted env attribute).
--- @return number seconds
function S:GetClickRateSeconds()
    return self:Get("clickRate") / 1000
end

--- Get the AceDB instance (used by SettingsPanel for AceDBOptions).
--- @return table AceDB instance
function S:GetDB()
    return self.db
end
