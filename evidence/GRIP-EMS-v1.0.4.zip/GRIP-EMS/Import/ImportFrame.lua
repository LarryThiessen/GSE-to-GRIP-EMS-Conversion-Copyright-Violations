-- GRIP-EMS: Import Frame (Two-Stage)
-- Stage 1: AceGUI paste window for import export strings
-- Stage 2: Native-frame picker with ScrollBox for selective import

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS")
local AceGUI = LibStub("AceGUI-3.0")

-- Upvalue accessor for Defaults
local function D() return GRIPEMS.Defaults end

GRIPEMS.ImportFrame = {}
local IF = GRIPEMS.ImportFrame

local frame = nil       -- lazy-created AceGUI Frame, reused
local pasteStage = nil   -- native Frame for stage 1
local pickStage = nil    -- native Frame for stage 2
local previewData = nil  -- result from GI.Preview()

-- Pick stage sub-references
local pickScrollBox, pickScrollBar, pickScrollView, pickDataProvider
local pickHeaderLabel, pickSummaryLine, pickImportBtn

---------------------------------------------------------------------------
-- Icon resolution helper
---------------------------------------------------------------------------

--- Resolve an icon value to a usable texture path or ID.
--- @param icon any Icon from preview entry (number, string, or nil)
--- @return any Resolved texture (number ID or string path)
local function ResolveIcon(icon)
    if type(icon) == "number" then
        return icon
    end
    if type(icon) == "string" then
        if icon:find("^Interface\\") then
            return icon
        end
        if icon ~= "" then
            return "Interface\\Icons\\" .. icon
        end
    end
    return "Interface\\Icons\\" .. D().QUESTION_MARK_ICON
end

---------------------------------------------------------------------------
-- UpdateImportCount: refresh the Import Selected button label + state
---------------------------------------------------------------------------
local function UpdateImportCount()
    if not pickDataProvider or not pickImportBtn then return end

    local count = 0
    for _, entry in pickDataProvider:EnumerateEntireRange() do
        if (entry.type == "sequence" or entry.type == "variable")
            and entry.entry and entry.entry.conflictAction ~= "skip" then
            count = count + 1
        end
    end

    pickImportBtn.label:SetText(string.format(
        L["GEMS_IMPORT_PREVIEW_IMPORT_SELECTED"], count))
    if count == 0 then
        pickImportBtn:Disable()
        pickImportBtn:SetAlpha(0.5)
    else
        pickImportBtn:Enable()
        pickImportBtn:SetAlpha(1.0)
    end
end

---------------------------------------------------------------------------
-- Row initializer for pick stage ScrollBox
---------------------------------------------------------------------------

--- Initialize or refresh a pick-stage row.
--- @param button Button The reusable row frame
--- @param data table Row data with type, index, entry fields
local function InitPickRow(button, data)
    local UI = GRIPEMS.UI
    local C = UI.Colors
    local rowHeight = D().IMPORT_PICKER_ROW_HEIGHT

    button:SetHeight(rowHeight)

    -- Ensure sub-elements created once
    if not button._pickInit then
        button._pickInit = true

        -- Background
        local bg = button:CreateTexture(nil, "BACKGROUND")
        bg:SetAllPoints()
        bg:SetColorTexture(0, 0, 0, 0)
        button._bg = bg

        -- CheckButton
        local cb = CreateFrame("CheckButton", nil, button, "UICheckButtonTemplate")
        cb:SetSize(18, 18)
        cb:SetPoint("LEFT", button, "LEFT", 4, 0)
        cb:SetHitRectInsets(0, 0, 0, 0)
        button._checkBtn = cb

        -- Icon texture
        local icon = button:CreateTexture(nil, "ARTWORK")
        icon:SetSize(20, 20)
        icon:SetPoint("LEFT", cb, "RIGHT", 4, 0)
        button._icon = icon

        -- Name label
        local nameLabel = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(nameLabel, 11)
        nameLabel:SetPoint("LEFT", icon, "RIGHT", 6, 0)
        nameLabel:SetJustifyH("LEFT")
        nameLabel:SetWordWrap(false)
        button._nameLabel = nameLabel

        -- Info label (versions/steps)
        local infoLabel = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(infoLabel, 10)
        infoLabel:SetJustifyH("LEFT")
        infoLabel:SetWordWrap(false)
        button._infoLabel = infoLabel

        -- Status badge
        local statusLabel = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(statusLabel, 10)
        statusLabel:SetJustifyH("RIGHT")
        button._statusLabel = statusLabel

        -- Action button (for existing sequences)
        local actionBtn = UI:CreateButton(button, "", 70, 20)
        actionBtn:SetPoint("RIGHT", button, "RIGHT", -4, 0)
        button._actionBtn = actionBtn

        -- Section header label (for header rows)
        local headerText = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(headerText, 11, "OUTLINE")
        headerText:SetPoint("LEFT", button, "LEFT", 8, 0)
        headerText:SetJustifyH("LEFT")
        button._headerText = headerText
    end

    -- Reset visibility
    button._checkBtn:Hide()
    button._icon:Hide()
    button._nameLabel:Hide()
    button._infoLabel:Hide()
    button._statusLabel:Hide()
    button._actionBtn:Hide()
    button._headerText:Hide()
    button._bg:SetColorTexture(0, 0, 0, 0)

    -----------------------------------------------------------------------
    -- Section header rows
    -----------------------------------------------------------------------
    if data.type == "seqHeader" or data.type == "varHeader" then
        button._headerText:Show()
        button._headerText:SetTextColor(C.textSecondary:GetRGBA())
        button._bg:SetColorTexture(C.bgPanel:GetRGB())
        button._bg:SetAlpha(0.3)
        if data.type == "seqHeader" then
            button._headerText:SetText(string.format(
                L["GEMS_IMPORT_PREVIEW_SEQ_HEADER"], data.count or 0))
        else
            button._headerText:SetText(string.format(
                L["GEMS_IMPORT_PREVIEW_VAR_HEADER"], data.count or 0))
        end
        button:SetScript("OnClick", nil)
        return
    end

    -----------------------------------------------------------------------
    -- Sequence rows
    -----------------------------------------------------------------------
    if data.type == "sequence" then
        local entry = data.entry

        -- CheckButton
        button._checkBtn:Show()
        button._checkBtn:SetChecked(entry.conflictAction ~= "skip")
        button._checkBtn:SetScript("OnClick", function(self)
            if self:GetChecked() then
                if entry._wasRename then
                    entry.conflictAction = "rename"
                    entry._wasRename = nil
                else
                    entry.conflictAction = "import"
                end
            else
                if entry.conflictAction == "rename" then
                    entry._wasRename = true
                end
                entry.conflictAction = "skip"
            end
            UpdateImportCount()
        end)

        -- Icon
        button._icon:Show()
        button._icon:SetTexture(ResolveIcon(entry.icon))

        -- Name
        button._nameLabel:Show()
        button._nameLabel:SetText(entry.name or "")
        button._nameLabel:SetTextColor(C.textPrimary:GetRGBA())
        button._nameLabel:SetWidth(200)

        -- Info: "N versions, N steps"
        button._infoLabel:Show()
        button._infoLabel:SetPoint("LEFT", button._nameLabel, "RIGHT", 8, 0)
        button._infoLabel:SetText(string.format(
            L["GEMS_IMPORT_PREVIEW_INFO"],
            entry.versionCount or 1, entry.stepCount or 0))
        button._infoLabel:SetTextColor(C.textSecondary:GetRGBA())

        -- Status badge
        button._statusLabel:Show()
        if entry.status == "new" then
            button._statusLabel:SetText(L["GEMS_IMPORT_PREVIEW_NEW"])
            button._statusLabel:SetTextColor(C.textSuccess:GetRGBA())
        else
            button._statusLabel:SetText(L["GEMS_IMPORT_PREVIEW_EXISTS"])
            button._statusLabel:SetTextColor(C.textWarning:GetRGBA())
        end

        -- Action dropdown (only for existing sequences)
        if entry.status == "exists" then
            button._actionBtn:Show()
            button._statusLabel:SetPoint("RIGHT", button._actionBtn, "LEFT", -6, 0)

            -- Update action button label
            local actionLabel = L["GEMS_IMPORT_PREVIEW_ACTION_SKIP"]
            if entry.conflictAction == "import" then
                actionLabel = L["GEMS_IMPORT_PREVIEW_ACTION_REPLACE"]
            elseif entry.conflictAction == "rename" then
                actionLabel = L["GEMS_IMPORT_PREVIEW_ACTION_RENAME"]
            end
            button._actionBtn.label:SetText(actionLabel)

            button._actionBtn:SetScript("OnClick", function(self)
                MenuUtil.CreateContextMenu(self, function(_, rootDescription)
                    rootDescription:CreateButton(
                        L["GEMS_IMPORT_PREVIEW_ACTION_SKIP"], function()
                        entry.conflictAction = "skip"
                        entry._wasRename = nil
                        button._checkBtn:SetChecked(false)
                        button._actionBtn.label:SetText(
                            L["GEMS_IMPORT_PREVIEW_ACTION_SKIP"])
                        UpdateImportCount()
                    end)
                    rootDescription:CreateButton(
                        L["GEMS_IMPORT_PREVIEW_ACTION_REPLACE"], function()
                        entry.conflictAction = "import"
                        entry._wasRename = nil
                        button._checkBtn:SetChecked(true)
                        button._actionBtn.label:SetText(
                            L["GEMS_IMPORT_PREVIEW_ACTION_REPLACE"])
                        UpdateImportCount()
                    end)
                    rootDescription:CreateButton(
                        L["GEMS_IMPORT_PREVIEW_ACTION_RENAME"], function()
                        entry.conflictAction = "rename"
                        entry._wasRename = nil
                        button._checkBtn:SetChecked(true)
                        button._actionBtn.label:SetText(
                            L["GEMS_IMPORT_PREVIEW_ACTION_RENAME"])
                        UpdateImportCount()
                    end)
                end)
            end)
        else
            button._statusLabel:SetPoint("RIGHT", button, "RIGHT", -8, 0)
        end

        button:SetScript("OnClick", nil)
        return
    end

    -----------------------------------------------------------------------
    -- Variable rows
    -----------------------------------------------------------------------
    if data.type == "variable" then
        local entry = data.entry

        -- CheckButton
        button._checkBtn:Show()
        button._checkBtn:SetChecked(entry.conflictAction ~= "skip")
        button._checkBtn:SetScript("OnClick", function(self)
            if self:GetChecked() then
                entry.conflictAction = "import"
            else
                entry.conflictAction = "skip"
            end
            UpdateImportCount()
        end)

        -- Name
        button._nameLabel:Show()
        button._nameLabel:SetPoint("LEFT", button._checkBtn, "RIGHT", 6, 0)
        button._nameLabel:SetText(entry.name or "")
        button._nameLabel:SetTextColor(C.textPrimary:GetRGBA())

        -- Status badge
        button._statusLabel:Show()
        button._statusLabel:SetPoint("RIGHT", button, "RIGHT", -8, 0)
        if entry.status == "new" then
            button._statusLabel:SetText(L["GEMS_IMPORT_PREVIEW_NEW"])
            button._statusLabel:SetTextColor(C.textSuccess:GetRGBA())
        else
            button._statusLabel:SetText(L["GEMS_IMPORT_PREVIEW_EXISTS"])
            button._statusLabel:SetTextColor(C.textWarning:GetRGBA())
        end

        button:SetScript("OnClick", nil)
        return
    end
end

---------------------------------------------------------------------------
-- ShowPickStage: transition from paste to pick
---------------------------------------------------------------------------

local function ShowPickStage()
    if not previewData or not previewData.ok then return end

    pasteStage:Hide()
    pickStage:Show()

    -- Update frame title
    frame:SetTitle("GRIP-EMS: " .. L["GEMS_IMPORT_PREVIEW_TITLE"])

    -- Header: "N sequences, N variables"
    pickHeaderLabel:SetText(string.format(L["GEMS_IMPORT_PREVIEW_HEADER"],
        previewData.totalSequences or 0, previewData.totalVariables or 0))

    -- Summary: "N new, N existing"
    local parts = {}
    local newCount = previewData.newSequences or 0
    local existCount = previewData.existingSequences or 0
    if newCount > 0 then
        parts[#parts + 1] = string.format(L["GEMS_IMPORT_PREVIEW_NEW_COUNT"], newCount)
    end
    if existCount > 0 then
        parts[#parts + 1] = string.format(L["GEMS_IMPORT_PREVIEW_EXISTING_COUNT"], existCount)
    end
    pickSummaryLine:SetText(table.concat(parts, ", "))

    -- Build flat data array for ScrollBox
    local flatData = {}

    if previewData.totalSequences > 0 then
        flatData[#flatData + 1] = {
            type = "seqHeader", count = previewData.totalSequences,
        }
        for i, entry in ipairs(previewData.sequences) do
            flatData[#flatData + 1] = {
                type = "sequence", index = i, entry = entry,
            }
        end
    end

    if previewData.totalVariables > 0 then
        flatData[#flatData + 1] = {
            type = "varHeader", count = previewData.totalVariables,
        }
        for i, entry in ipairs(previewData.variables) do
            flatData[#flatData + 1] = {
                type = "variable", index = i, entry = entry,
            }
        end
    end

    -- Populate DataProvider
    pickDataProvider = CreateDataProvider()
    for _, rowData in ipairs(flatData) do
        pickDataProvider:Insert(rowData)
    end
    pickScrollBox:SetDataProvider(pickDataProvider)

    UpdateImportCount()
end

---------------------------------------------------------------------------
-- ShowPasteStage: transition back to paste
---------------------------------------------------------------------------

local function ShowPasteStage()
    pickStage:Hide()
    pasteStage:Show()
    previewData = nil
    frame:SetTitle("GRIP-EMS: Import")
end

---------------------------------------------------------------------------
-- CreatePickStage: builds the native-frame picker UI (once)
---------------------------------------------------------------------------

local function CreatePickStage(rawFrame)
    local UI = GRIPEMS.UI
    local C = UI.Colors

    pickStage = CreateFrame("Frame", nil, rawFrame)
    pickStage:SetPoint("TOPLEFT", rawFrame, "TOPLEFT", 10, -26)
    pickStage:SetPoint("BOTTOMRIGHT", rawFrame, "BOTTOMRIGHT", -10, 8)
    pickStage:Hide()

    -- Header label
    pickHeaderLabel = pickStage:CreateFontString(nil, "OVERLAY")
    UI:SetFont(pickHeaderLabel, 13)
    pickHeaderLabel:SetPoint("TOPLEFT", pickStage, "TOPLEFT", 4, -4)
    pickHeaderLabel:SetTextColor(C.textPrimary:GetRGBA())

    -- Summary line
    pickSummaryLine = pickStage:CreateFontString(nil, "OVERLAY")
    UI:SetFont(pickSummaryLine, 10)
    pickSummaryLine:SetPoint("TOPLEFT", pickHeaderLabel, "BOTTOMLEFT", 0, -4)
    pickSummaryLine:SetTextColor(C.textSecondary:GetRGBA())

    -------------------------------------------------------------------
    -- Bottom bar (36px)
    -------------------------------------------------------------------
    local bottomBar = CreateFrame("Frame", nil, pickStage)
    bottomBar:SetHeight(D().BUTTON_BAR_HEIGHT)
    bottomBar:SetPoint("BOTTOMLEFT", pickStage, "BOTTOMLEFT", 0, 0)
    bottomBar:SetPoint("BOTTOMRIGHT", pickStage, "BOTTOMRIGHT", 0, 0)

    -- Select All
    local selectAllBtn = UI:CreateButton(bottomBar,
        L["GEMS_IMPORT_PREVIEW_SELECT_ALL"], 90, 26)
    selectAllBtn:SetPoint("LEFT", bottomBar, "LEFT", 4, 0)
    selectAllBtn:SetScript("OnClick", function()
        if not pickDataProvider then return end
        for _, entry in pickDataProvider:EnumerateEntireRange() do
            if entry.type == "sequence" or entry.type == "variable" then
                entry.entry.conflictAction = "import"
                entry.entry._wasRename = nil
            end
        end
        pickScrollBox:ForEachFrame(function(btn)
            if btn._checkBtn and btn._checkBtn:IsShown() then
                btn._checkBtn:SetChecked(true)
            end
            if btn._actionBtn and btn._actionBtn:IsShown() then
                btn._actionBtn.label:SetText(
                    L["GEMS_IMPORT_PREVIEW_ACTION_REPLACE"])
            end
        end)
        UpdateImportCount()
    end)

    -- Deselect All
    local deselectAllBtn = UI:CreateButton(bottomBar,
        L["GEMS_IMPORT_PREVIEW_DESELECT_ALL"], 100, 26)
    deselectAllBtn:SetPoint("LEFT", selectAllBtn, "RIGHT", 6, 0)
    deselectAllBtn:SetScript("OnClick", function()
        if not pickDataProvider then return end
        for _, entry in pickDataProvider:EnumerateEntireRange() do
            if entry.type == "sequence" or entry.type == "variable" then
                entry.entry.conflictAction = "skip"
                entry.entry._wasRename = nil
            end
        end
        pickScrollBox:ForEachFrame(function(btn)
            if btn._checkBtn and btn._checkBtn:IsShown() then
                btn._checkBtn:SetChecked(false)
            end
            if btn._actionBtn and btn._actionBtn:IsShown() then
                btn._actionBtn.label:SetText(
                    L["GEMS_IMPORT_PREVIEW_ACTION_SKIP"])
            end
        end)
        UpdateImportCount()
    end)

    -- Import Selected (right-aligned, green-tinted)
    pickImportBtn = UI:CreateButton(bottomBar, "", 160, 26)
    pickImportBtn:SetPoint("RIGHT", bottomBar, "RIGHT", -4, 0)
    pickImportBtn:SetBackdropColor(C.bgSave:GetRGBA())
    pickImportBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.bgSaveHover:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
    end)
    pickImportBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgSave:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
    end)
    pickImportBtn:SetScript("OnClick", function()
        if not previewData then return end

        -- Build selections table
        local selections = { sequences = {}, variables = {} }
        if pickDataProvider then
            for _, rowData in pickDataProvider:EnumerateEntireRange() do
                if rowData.type == "sequence" then
                    selections.sequences[rowData.index] = {
                        selected = rowData.entry.conflictAction ~= "skip",
                        action = rowData.entry.conflictAction,
                    }
                elseif rowData.type == "variable" then
                    selections.variables[rowData.index] = {
                        selected = rowData.entry.conflictAction ~= "skip",
                        action = rowData.entry.conflictAction,
                    }
                end
            end
        end

        local GI = GRIPEMS.GSEImport
        local ok, results = GI.CommitSelected(previewData, selections)
        if ok then
            -- Print summary
            local seqCount = results.count or 0
            local varCount = results.varsImported or 0
            GRIPEMS:Print(string.format(
                L["GEMS_IMPORT_PREVIEW_SUMMARY"], seqCount, varCount))
            for _, name in ipairs(results.names or {}) do
                local stepCount = results.stepCounts
                    and results.stepCounts[name] or 0
                GRIPEMS:Print(string.format(
                    L["GEMS_IMPORT_ENTRY"], name, stepCount))
            end
            if results.warnings then
                for _, w in ipairs(results.warnings) do
                    GRIPEMS:Print(string.format(L["GEMS_IMPORT_WARNING"], w))
                end
            end
            frame:Hide()
        else
            GRIPEMS:Print(string.format(L["GEMS_IMPORT_FAILED"],
                tostring(results)))
        end
    end)

    -- Cancel (left of Import Selected)
    local cancelBtn = UI:CreateButton(bottomBar,
        L["GEMS_IMPORT_PREVIEW_CANCEL"], 80, 26)
    cancelBtn:SetPoint("RIGHT", pickImportBtn, "LEFT", -6, 0)
    cancelBtn:SetScript("OnClick", function()
        ShowPasteStage()
    end)

    -------------------------------------------------------------------
    -- ScrollBox (between summary and bottom bar)
    -------------------------------------------------------------------
    pickScrollBox = CreateFrame("Frame", nil, pickStage, "WowScrollBoxList")
    pickScrollBox:SetPoint("TOPLEFT", pickSummaryLine, "BOTTOMLEFT", 0, -8)
    pickScrollBox:SetPoint("BOTTOMRIGHT", bottomBar, "TOPRIGHT", -18, 4)

    pickScrollBar = CreateFrame("EventFrame", nil, pickStage,
        "MinimalScrollBar")
    pickScrollBar:SetPoint("TOPLEFT", pickScrollBox, "TOPRIGHT", 2, 0)
    pickScrollBar:SetPoint("BOTTOMLEFT", pickScrollBox, "BOTTOMRIGHT", 2, 0)

    pickScrollView = CreateScrollBoxListLinearView()
    pickScrollView:SetElementExtent(D().IMPORT_PICKER_ROW_HEIGHT)

    pickScrollView:SetElementInitializer("Button", function(button, data)
        InitPickRow(button, data)
    end)

    ScrollUtil.InitScrollBoxListWithScrollBar(
        pickScrollBox, pickScrollBar, pickScrollView)

    pickDataProvider = CreateDataProvider()
    pickScrollBox:SetDataProvider(pickDataProvider)
end

---------------------------------------------------------------------------
-- IF:Show() -- main entry point (creates frame on first call)
---------------------------------------------------------------------------

--- Show the import frame. Creates the frame on first call, reuses after.
--- Always resets to paste stage on show.
function IF:Show()
    if not frame then
        frame = AceGUI:Create("Frame")
        frame:SetTitle("GRIP-EMS: Import")
        frame:SetWidth(D().IMPORT_PICKER_WIDTH)
        frame:SetHeight(D().IMPORT_PICKER_HEIGHT)
        frame:SetLayout(nil)  -- manual layout, no AceGUI flow
        frame.frame:SetFrameStrata("DIALOG")
        frame.frame:SetClampedToScreen(true)
        frame:SetCallback("OnClose", function(widget)
            widget:Hide()
        end)

        local rawFrame = frame.frame

        -------------------------------------------------------------------
        -- Stage 1: Paste
        -------------------------------------------------------------------
        pasteStage = CreateFrame("Frame", nil, rawFrame)
        pasteStage:SetPoint("TOPLEFT", rawFrame, "TOPLEFT", 10, -26)
        pasteStage:SetPoint("BOTTOMRIGHT", rawFrame, "BOTTOMRIGHT", -10, 8)

        -- Instructions label
        local instrLabel = pasteStage:CreateFontString(nil, "OVERLAY")
        GRIPEMS.UI:SetFont(instrLabel, 11)
        instrLabel:SetPoint("TOPLEFT", pasteStage, "TOPLEFT", 4, -4)
        instrLabel:SetText(L["GEMS_IMPORT_PASTE_INSTRUCTIONS"])
        instrLabel:SetTextColor(GRIPEMS.UI.Colors.textSecondary:GetRGBA())
        instrLabel:SetWidth(D().IMPORT_PICKER_WIDTH - 40)
        instrLabel:SetJustifyH("LEFT")
        instrLabel:SetWordWrap(true)

        -- Use AceGUI MultiLineEditBox for paste (proven, handles large text)
        local editbox = AceGUI:Create("MultiLineEditBox")
        editbox:SetLabel(L["GEMS_IMPORT_PASTE_LABEL"])
        editbox:SetNumLines(15)
        editbox:DisableButton(true)
        editbox.frame:SetParent(pasteStage)
        editbox.frame:SetPoint("TOPLEFT", instrLabel, "BOTTOMLEFT", -2, -6)
        editbox.frame:SetPoint("BOTTOMRIGHT", pasteStage, "BOTTOMRIGHT",
            -4, 40)
        editbox.frame:Show()
        frame.editbox = editbox

        -- Button bar for paste stage
        local pasteBtnBar = CreateFrame("Frame", nil, pasteStage)
        pasteBtnBar:SetHeight(32)
        pasteBtnBar:SetPoint("BOTTOMLEFT", pasteStage, "BOTTOMLEFT", 4, 4)
        pasteBtnBar:SetPoint("BOTTOMRIGHT", pasteStage, "BOTTOMRIGHT", -4, 4)

        -- Preview button (was "Import")
        local previewBtn = GRIPEMS.UI:CreateButton(pasteBtnBar,
            L["GEMS_IMPORT_PREVIEW_BTN"], 150, 26)
        previewBtn:SetPoint("LEFT", pasteBtnBar, "LEFT", 0, 0)
        previewBtn:SetScript("OnClick", function()
            local text = editbox:GetText()
            if not text or text:trim() == "" then
                GRIPEMS:Print(L["GEMS_IMPORT_USAGE"])
                return
            end

            -- Strip whitespace/newlines
            text = text:gsub("%s+", "")

            local GI = GRIPEMS.GSEImport
            local preview = GI.Preview(text)
            if preview and preview.ok then
                previewData = preview
                ShowPickStage()
            else
                local errMsg = preview and preview.error
                    or "Unknown preview error"
                GRIPEMS:Print(string.format(L["GEMS_IMPORT_FAILED"], errMsg))
            end
        end)

        -- Clear button
        local clearBtn = GRIPEMS.UI:CreateButton(pasteBtnBar,
            L["GEMS_IMPORT_CLEAR"], 100, 26)
        clearBtn:SetPoint("LEFT", previewBtn, "RIGHT", 8, 0)
        clearBtn:SetScript("OnClick", function()
            editbox:SetText("")
            editbox:SetFocus()
        end)

        -------------------------------------------------------------------
        -- Stage 2: Pick (created once, hidden initially)
        -------------------------------------------------------------------
        CreatePickStage(rawFrame)
    end

    -- Always reset to paste stage on show
    pickStage:Hide()
    pasteStage:Show()
    previewData = nil
    frame:SetTitle("GRIP-EMS: Import")
    frame:Show()
    frame.editbox:SetText("")
    frame.editbox:SetFocus()
end

---------------------------------------------------------------------------
-- IF:ShowFromTransmission() -- entry point for P2P received sequences
---------------------------------------------------------------------------

--- Show the import frame pre-loaded with a P2P transmission string.
--- Skips the paste stage and goes directly to the pick stage.
--- @param encodedString string The GRIP1-encoded export string
--- @param senderName string The player who sent the sequence
function IF:ShowFromTransmission(encodedString, senderName)
    if not encodedString or encodedString == "" then return end

    local GI = GRIPEMS.GSEImport
    local preview = GI.Preview(encodedString)
    if not preview or not preview.ok then
        local errMsg = preview and preview.error or "Unknown error"
        GRIPEMS:Print(string.format(L["GEMS_IMPORT_FAILED"], errMsg))
        return
    end

    -- Ensure the frame is created (call Show first, then override stage)
    IF:Show()

    -- Store preview and switch to pick stage
    previewData = preview
    ShowPickStage()

    -- Override frame title with sender info
    frame:SetTitle("GRIP-EMS: " .. string.format(L["GEMS_IMPORT_FROM"], senderName))
end

--- Hide the import frame if shown.
function IF:Hide()
    if frame then
        frame:Hide()
    end
end

--- Check if the import frame is currently shown.
--- @return boolean
function IF:IsShown()
    return frame and frame:IsShown()
end
