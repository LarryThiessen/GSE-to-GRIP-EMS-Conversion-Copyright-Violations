-- GRIP-EMS: Headless gate for the sharing-field carry across every rebuild
--
-- Created:    2026-08-24
-- Updated:    2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.
--
-- A rebuild replaces a stored sequence's seqData table wholesale. Any field the
-- rebuild does not explicitly carry is silently dropped -- and dropping a
-- sharing field turns a refusal into a permission. The fork path was fixed
-- first; save and rename were still dropping the same fields, so a
-- do-not-share sequence became shareable simply by being saved.
--
-- D.SEQUENCE_SHARING_FIELDS is now the single list, and every rebuild site
-- carries it. This file is the gate that keeps that true.
--
-- It has two halves, and they fail for different reasons on purpose:
--
--   HALF ONE is BEHAVIOURAL. It runs the real D.CarrySequenceIdentity and asks
--   the real GE.IsNoRedistribute whether the rebuilt record is still refused.
--
--   HALF TWO is STRUCTURAL. It PARSES the D.SEQUENCE_SHARING_FIELDS literal out
--   of Data/Defaults.lua -- it does not hardcode the field names -- and then
--   asserts every member of that list is reachable at each of the four rebuild
--   sites. Adding a field to the list without carrying it anywhere reddens CI.
--   Each site is located by a stable ANCHOR STRING, never by line number, and a
--   missing anchor FAILS rather than quietly measuring nothing.
--
-- Run from the EMS root:  lua Test/test_rebuild_carry_parity.lua
-- Exit code 0 = all passed, 1 = at least one failure.
--
-- Cases:
--   R1  D.CarrySequenceIdentity carries noRedistribute from a source that has
--       it, and the rebuilt record is still refused by GE.IsNoRedistribute
--   R2  the same for a NATIVE source. This is the shape that shipped broken and
--       the shape the provenance gate does NOT cover, so the carried flag is
--       the only thing standing between that sequence and every export rail
--   R3  CONTROL: a source without the flag produces a rebuild without it. The
--       carry must not be a blanket true
--   R4  the ATTESTATION SPLIT, in both directions: D.CarrySequenceIdentity DOES
--       carry provenanceAttestedBy, because it serves name-preserving rebuilds
--       and a rename is the SAME copy; Identity:StampForked CLEARS it, because
--       a fork is a NEW copy. See the note above the case for the reasoning
--   R5  STRUCTURAL: every field named in the real D.SEQUENCE_SHARING_FIELDS
--       literal is reachable IN CODE at all four rebuild sites -- the two
--       editor save rebuilds, D.CarrySequenceIdentity, and I:StampForked.
--       COMMENTS ARE EXCLUDED: every region is comment-stripped before the
--       check, so a site cannot qualify on the strength of a comment that
--       merely TALKS about the carry. An assignment through the
--       SEQUENCE_SHARING_FIELDS iteration counts, and so does an explicit
--       `<recv>.<field> =`
--   R6  NEGATIVE CONTROL for R5: the same machinery run against a field name
--       that exists nowhere must report it MISSING at every one of the four
--       sites. Without R6, R5 passing proves only that the checker runs
--  R6b  the SECOND negative control, and the one that pins the defect this
--       pass closed. A region whose ONLY mention of the declared fields is
--       inside COMMENTS must report every one of them MISSING. It traps BOTH
--       branches of isReachable, which fail independently: the iteration
--       branch via a comment naming SEQUENCE_SHARING_FIELDS, and the explicit
--       branch via a commented-out `.noRedistribute =` line plus a
--       `.provenanceAttestedBy =` assignment inside a LONG comment. It also
--       asserts the fixture looks fully carried BEFORE stripping, so the
--       control cannot pass by trapping nothing. Before the strip, deleting
--       the three-line carry loop from the main editor save and leaving its
--       comment kept R5 green
--   R7  every field in D.SEQUENCE_SHARING_FIELDS is a member of the LOCKED
--       deny-list in UI/RawTab.lua, the fifth rebuild path. LOCKED is PARSED
--       out of the real file, not retyped, exactly as R5 parses the sharing
--       list
--   R8  BEHAVIOURAL for R7: replicating RawTab's real overlay -- deep copy of
--       the stored record, then every NON-locked key from the parsed text
--       wins -- a raw-text edit clearing noRedistribute or forging
--       provenanceAttestedBy has NO effect, while edits to non-locked fields
--       such as description and url still apply. That second half is the
--       control without which R8 would pass by locking the whole table and
--       silently turning the raw editor read-only
--   R9  BEHAVIOURAL, and the one field family that is NOT on the sharing list:
--       D.CarrySequenceIdentity carries forkedFrom AND forkedFromChain, so a
--       renamed fork of someone else's work is still held foreign and still
--       needs confirming. GE.IsLocallyAuthored reads ancestry, which makes
--       those two fields load-bearing for the confirmation while belonging
--       nowhere near D.SEQUENCE_SHARING_FIELDS -- StampForked INVERTS a member
--       of that list (R4) and ancestry must be carried identically everywhere.
--       Carries a non-vacuity control: a rebuild with the ancestry dropped
--       reads as locally authored and would ship with no prompt at all

-- ---------------------------------------------------------------------------
-- Minimal assertion + runner harness.
-- ---------------------------------------------------------------------------

local tests = {}

local function test(name, fn)
    tests[#tests + 1] = { name = name, fn = fn }
end

local function assertEqual(expected, actual, label)
    if expected ~= actual then
        error((label or "value") .. ": expected " .. tostring(expected) .. ", got " .. tostring(actual), 2)
    end
end

local function assertTrue(cond, label)
    if not cond then
        error((label or "condition") .. " failed", 2)
    end
end

local function assertFalse(cond, label)
    if cond then
        error((label or "condition") .. " expected false, got " .. tostring(cond), 2)
    end
end

local function assertNil(actual, label)
    if actual ~= nil then
        error((label or "value") .. ": expected nil, got " .. tostring(actual), 2)
    end
end

-- ---------------------------------------------------------------------------
-- Sandbox for the LOADED MODULES. Same shape the sibling fork-provenance
-- harness uses: Defaults, Identity and GRIPExport all load standalone, and the
-- only WoW surface touched at file scope is one CreateFrame.
--
-- NOTHING in the modules under test is stubbed here. I:SignSequence and
-- I:SignSequenceV2 run for real -- LibStub resolves to a table with no .sha256
-- so Identity's own shipped djb2 fallback hashes -- because no case below
-- asserts on a signature value, only on the sharing fields.
-- ---------------------------------------------------------------------------

local frameStub = setmetatable({}, {
    __index = function()
        return function() end
    end,
})

local WOW_GLOBALS = {
    CreateFrame = function()
        return frameStub
    end,
    GetLocale = function()
        return "enUS"
    end,
    UnitName = function()
        return "Sataana"
    end,
    UnitClass = function()
        return "Mage", "MAGE", 8
    end,
    UnitFactionGroup = function()
        return "Alliance", "Alliance"
    end,
    GetRealmName = function()
        return "TestRealm"
    end,
    GetNormalizedRealmName = function()
        return "TestRealm"
    end,
    GetCurrentRegion = function()
        return 3
    end,
    BNGetInfo = function()
        return 1, "Tester#1234"
    end,
    C_AddOns = {
        IsAddOnLoaded = function()
            return false
        end,
        GetAddOnMetadata = function()
            return nil
        end,
    },
    C_Timer = {
        After = function() end,
    },
}

local env = setmetatable({}, {
    __index = function(_, k)
        local v = rawget(_G, k)
        if v ~= nil then
            return v
        end
        return WOW_GLOBALS[k]
    end,
})
env._G = env
env.strlower = string.lower
env.strtrim = function(s)
    return (tostring(s):gsub("^%s+", ""):gsub("%s+$", ""))
end
env.time = function()
    return 1000
end
env.date = function(fmt)
    return tostring(fmt)
end

local LOADED_LOCALE = {}
local LOCALE = setmetatable({}, {
    __index = function(_, k)
        return LOADED_LOCALE[k] or k
    end,
})

env.LibStub = function()
    return {
        GetLocale = function()
            return LOCALE
        end,
        NewLocale = function()
            return LOADED_LOCALE
        end,
    }
end

local GRIPEMS = {
    version = "test",
    Debug = function() end,
    Print = function() end,
    Fire = function() end,
}

env.GRIPEMS = GRIPEMS
env.GRIP_EMS_DB = { config = {} }
env.GRIP_EMS_CHAR = {}
_G.GRIPEMS = GRIPEMS

-- ---------------------------------------------------------------------------
-- Shared file reader. Both the module loader and HALF TWO's source parser use
-- it, and both try the bare path and the ../ prefixed one the sibling harnesses
-- use, so the file runs from the EMS root or from Test/.
-- ---------------------------------------------------------------------------

local function readFile(candidates)
    for _, path in ipairs(candidates) do
        -- io is dev-harness file I/O, intentionally outside the addon WoW std.
        -- selene: allow(undefined_variable)
        local fh = io.open(path, "r")
        if fh then
            local text = fh:read("*a")
            fh:close()
            return text
        end
    end
    return nil
end

local function loadModule(candidates)
    for _, path in ipairs(candidates) do
        -- loadfile is dev-harness file I/O, intentionally outside the addon WoW std.
        -- selene: allow(undefined_variable)
        local chunk = loadfile(path)
        if chunk then
            setfenv(chunk, env)
            chunk("GRIP-EMS", GRIPEMS)
            return true
        end
    end
    return false
end

local MODULES = {
    { "Locale/enUS.lua", "../Locale/enUS.lua" },
    { "Data/Defaults.lua", "../Data/Defaults.lua" },
    { "Engine/Identity.lua", "../Engine/Identity.lua" },
    { "Import/GRIPExport.lua", "../Import/GRIPExport.lua" },
}
for _, candidates in ipairs(MODULES) do
    assertTrue(loadModule(candidates), "could not locate " .. candidates[1] .. " (run from the EMS root)")
end

local D = GRIPEMS.Defaults
local I = GRIPEMS.Identity
local GE = GRIPEMS.GRIPExport

assertTrue(type(D) == "table" and type(D.CarrySequenceIdentity) == "function", "D.CarrySequenceIdentity must load")
assertTrue(type(D.SEQUENCE_SHARING_FIELDS) == "table", "D.SEQUENCE_SHARING_FIELDS must load as a table")
assertTrue(type(I) == "table" and type(I.StampForked) == "function", "Identity:StampForked must load")
assertTrue(type(GE) == "table" and type(GE.IsNoRedistribute) == "function", "GRIPExport must load")

-- ---------------------------------------------------------------------------
-- HALF ONE -- behavioural. Drives the REAL D.CarrySequenceIdentity.
-- ---------------------------------------------------------------------------

--- A stored sequence as it sits in Engine.sequences[name].data, in the shape a
--- rename hands to D.CarrySequenceIdentity. `fields` overlays the sharing /
--- provenance shape each case needs.
local function makeSource(fields)
    local seq = {
        name = "Source",
        originalAuthor = "Sataana",
        originalAuthorIdentity = "0badc0de",
        originalAuthorRealm = "TestRealm",
        originalCreatedAt = 500,
        originalSignature = "sig-from-the-source",
        signatureAlgorithm = "ALG_V2_SHA256",
        privacyMode = "public",
        versions = {},
    }
    for k, v in pairs(fields or {}) do
        seq[k] = v
    end
    return seq
end

--- The rebuilt record a rename produces: a FRESH table carrying only the
--- content fields the caller re-derives, before the identity carry runs. This
--- is the whole reason an uncarried field is a dropped field.
local function rebuildFrom(src)
    local newData = { name = "Renamed", versions = {} }
    D.CarrySequenceIdentity(newData, src)
    return newData
end

test("R1 the do-not-share flag survives a rename rebuild", function()
    env.GRIP_EMS_DB.config.provenanceGate = nil
    local src = makeSource({ noRedistribute = true })
    local newData = rebuildFrom(src)

    assertEqual(true, newData.noRedistribute, "rebuilt.noRedistribute")
    assertTrue(GE.IsNoRedistribute(src), "the source must be refused")
    assertTrue(GE.IsNoRedistribute(newData), "the rebuilt record must still be refused")
    assertEqual("marked", GE.RefusalReason(newData), "rebuilt refusal reason")
end)

test("R2 a NATIVE do-not-share source rebuilds still marked", function()
    env.GRIP_EMS_DB.config.provenanceGate = nil
    -- Nothing about this sequence is converted content, so the provenance gate
    -- never touches it. The carried flag is the entire refusal -- which is
    -- exactly why dropping it on save was invisible until someone shared one.
    local src = makeSource({ noRedistribute = true, provenanceSource = "native" })
    local newData = rebuildFrom(src)

    assertEqual(true, newData.noRedistribute, "rebuilt.noRedistribute")
    assertEqual("native", newData.provenanceSource, "provenanceSource is carried unchanged")
    assertFalse(GE.IsProvenanceGated(newData), "a native record must NOT be provenance gated")
    assertTrue(GE.IsNoRedistribute(newData), "the flag axis alone must refuse it")
end)

test("R3 CONTROL an unmarked source rebuilds unmarked", function()
    env.GRIP_EMS_DB.config.provenanceGate = nil
    local src = makeSource({ provenanceSource = "native" })
    local newData = rebuildFrom(src)

    assertNil(newData.noRedistribute, "rebuilt.noRedistribute must stay unset")
    assertFalse(GE.IsNoRedistribute(newData), "an unmarked rebuild must NOT be refused")
    assertNil(GE.RefusalReason(newData), "an unmarked rebuild has no refusal reason")
end)

-- R4 pins a DELIBERATE SPLIT, so the reasoning belongs here rather than in a
-- one-line comment.
--
-- provenanceAttestedBy records that one specific account vouched for one
-- specific copy of converted content, and it releases the provenance gate only
-- while it matches the CURRENT identity. The question is what a rebuild should
-- do with it, and the answer differs by rebuild:
--
--   RENAME and SAVE are the SAME COPY. The record keeps its identity, its
--   signature and its content; only the name or the steps changed. The doc
--   comment on D.CarrySequenceIdentity already notes that carried signatures
--   stay valid across a rename -- the attestation is a weaker claim than the
--   signature sitting beside it, so dropping it while keeping the signature
--   would be incoherent. Dropping it would also silently re-gate a sequence the
--   user had already attested, with no user-visible cause. So it is CARRIED.
--
--   A FORK is a NEW COPY. Identity:StampForked re-stamps the forking user as
--   the new author and issues a fresh signature; the attestation of the parent
--   says nothing about the child. So it is CLEARED there, and that is why
--   StampForked spells the two fields out instead of iterating the list.
--
-- Both directions are asserted below. If either flips, this case is the thing
-- that has to be argued with.
test("R4 the attestation is carried on rename and cleared on fork", function()
    env.GRIP_EMS_DB.config.provenanceGate = nil
    local ATTESTED_BY = "abc123hash"

    -- Rename half: the same copy keeps its attestation.
    local src = makeSource({ provenanceSource = "gse-legacy", provenanceAttestedBy = ATTESTED_BY })
    local renamed = rebuildFrom(src)
    assertEqual(ATTESTED_BY, renamed.provenanceAttestedBy, "a rename must PRESERVE the attestation")

    -- Fork half: a new copy starts unattested. Driven through the real
    -- StampForked, which is the only path that inverts a listed field.
    local forked = { name = "Fork", versions = {} }
    for k, v in pairs(src) do
        if forked[k] == nil then
            forked[k] = v
        end
    end
    assertEqual(ATTESTED_BY, forked.provenanceAttestedBy, "the fork must ARRIVE attested or the clear is vacuous")
    assertTrue(I:StampForked(forked, src), "StampForked must report a first stamp")
    assertNil(forked.provenanceAttestedBy, "a fork must CLEAR the attestation")
end)

-- ---------------------------------------------------------------------------
-- HALF TWO -- structural. Parses the real source; hardcodes no field names.
-- ---------------------------------------------------------------------------

--- The field list, read out of Data/Defaults.lua as TEXT. Deliberately not
--- D.SEQUENCE_SHARING_FIELDS off the loaded module: this half exists to compare
--- the declared list against four files on disk, and reading the declaration
--- from the same disk source keeps the whole check in one medium.
local function extractSharingFields()
    local src = readFile({ "Data/Defaults.lua", "../Data/Defaults.lua" })
    assertTrue(src ~= nil, "could not read Data/Defaults.lua for the field-list parse")
    local literal = src:match("D%.SEQUENCE_SHARING_FIELDS%s*=%s*{(.-)}")
    assertTrue(literal ~= nil, "anchor gone: no D.SEQUENCE_SHARING_FIELDS array literal in Data/Defaults.lua")
    local fields = {}
    for name in literal:gmatch('"([^"]+)"') do
        fields[#fields + 1] = name
    end
    assertTrue(#fields > 0, "D.SEQUENCE_SHARING_FIELDS parsed to ZERO fields -- the gate would measure nothing")
    return fields
end

local SHARING_FIELDS = extractSharingFields()

-- The four rebuild sites, each located by an anchor STRING rather than a line
-- number. anchorEnd must appear after anchorStart; either one missing is a hard
-- failure, because a gate that cannot find its site must never report green.
local SITES = {
    {
        label = "SequenceEditor save rebuild",
        file = { "UI/SequenceEditor.lua", "../UI/SequenceEditor.lua" },
        anchorStart = "-- v2.1.0 Authorship Integrity: carry forward provenance fields from oldData,",
        anchorEnd = "newData.signatureAlgorithm = oldData.signatureAlgorithm",
    },
    {
        label = "PopupEditor save rebuild",
        file = { "UI/PopupEditor.lua", "../UI/PopupEditor.lua" },
        anchorStart = "-- v2.1.0 Authorship Integrity parity: carry forward provenance fields",
        anchorEnd = "newData.signatureAlgorithm = oldData.signatureAlgorithm",
    },
    {
        label = "D.CarrySequenceIdentity",
        file = { "Data/Defaults.lua", "../Data/Defaults.lua" },
        anchorStart = "function D.CarrySequenceIdentity",
        anchorEnd = "\nend\n",
    },
    {
        label = "Identity:StampForked",
        file = { "Engine/Identity.lua", "../Engine/Identity.lua" },
        anchorStart = "function I:StampForked",
        anchorEnd = "\nend\n",
    },
}

-- A region wider than this is a sign the end anchor drifted and the slice
-- swallowed unrelated code, which could make a field look reachable by
-- accident. Cheaper to fail than to pass for the wrong reason.
local MAX_REGION_CHARS = 8000

--- Remove Lua LONG comments -- --[[ ]] and --[==[ ]==] at any level -- leaving
--- the newlines they spanned behind so the line-comment pass below stays
--- line-accurate and cannot join a comment to the code under it.
local function stripLongComments(text)
    local out = {}
    local pos = 1
    while true do
        local startPos, openEnd, level = text:find("%-%-%[(=*)%[", pos)
        if not startPos then
            out[#out + 1] = text:sub(pos)
            break
        end
        out[#out + 1] = text:sub(pos, startPos - 1)
        local close = "]" .. level .. "]"
        local closePos = text:find(close, openEnd + 1, true)
        if not closePos then
            -- Unterminated long comment: everything after it is commented out,
            -- so drop the remainder rather than guessing where it ends.
            break
        end
        out[#out + 1] = (text:sub(startPos, closePos + #close - 1):gsub("[^\n]", ""))
        pos = closePos + #close
    end
    return table.concat(out)
end

--- Remove Lua LINE comments: -- to end of line.
local function stripLineComments(text)
    return (text:gsub("%-%-[^\n]*", ""))
end

--- Strip both comment forms, LONG FIRST. Order is load-bearing: a long comment
--- can contain a line that begins with two hyphens, and stripping line-first
--- would eat that line and leave the long comment's opener and closer behind as
--- apparent code.
---
--- This is a TEXT SCANNER over four known regions of known source, NOT a Lua
--- parser, and it deliberately makes no attempt to spot comment markers inside
--- string literals. If one ever appears in these regions the gate gets
--- STRICTER -- a real carry would read as stripped and the site would be
--- reported missing. That is the safe direction to fail in.
local function stripLuaComments(text)
    return stripLineComments(stripLongComments(text))
end

--- Slice one rebuild site out of its file. Raises on any anchor problem.
---
--- The slice is stripped of comments HERE, once, at the single point every
--- region is captured -- never inside isReachable. Stripping at the consumer
--- would leave any future second consumer silently reading the raw text, which
--- is exactly the shape of the defect this pass closes: R5 used to credit a
--- site whose only mention of the carry was the COMMENT above it, so deleting
--- the three-line carry loop and leaving its comment kept the gate green.
local function readRegion(site)
    local src = readFile(site.file)
    assertTrue(src ~= nil, "could not read " .. site.file[1] .. " for site " .. site.label)
    local startPos = src:find(site.anchorStart, 1, true)
    assertTrue(startPos ~= nil, "anchor gone: start anchor not found for site " .. site.label)
    local endPos = src:find(site.anchorEnd, startPos, true)
    assertTrue(endPos ~= nil, "anchor gone: end anchor not found after start for site " .. site.label)
    local region = src:sub(startPos, endPos + #site.anchorEnd)
    assertTrue(#region > 0, "empty region for site " .. site.label)
    assertTrue(
        #region <= MAX_REGION_CHARS,
        string.format("region for site %s is %d chars -- end anchor has drifted", site.label, #region)
    )
    return stripLuaComments(region)
end

local REGIONS = {}
for _, site in ipairs(SITES) do
    REGIONS[site.label] = readRegion(site)
end
assertEqual(4, #SITES, "the gate must cover exactly the four rebuild sites")

local DECLARED = {}
for _, field in ipairs(SHARING_FIELDS) do
    DECLARED[field] = true
end

--- Is `field` carried at this site? The region arrives with every comment
--- already stripped by readRegion, so both branches below answer about CODE
--- only. Two ways to qualify, both real:
---   1. the site ITERATES D.SEQUENCE_SHARING_FIELDS -- but that only reaches
---      fields the list actually DECLARES, which is why the membership test
---      guards the short-circuit. Without it, the iterating sites would credit
---      any name at all and R6 would be unfalsifiable. R6 caught exactly that.
---   2. an explicit `<receiver>.<field> =` assignment names it directly, which
---      is how I:StampForked qualifies -- it spells the two fields out because
---      it is the one path that INVERTS one of them
local function isReachable(region, field)
    if DECLARED[field] and region:find("SEQUENCE_SHARING_FIELDS", 1, true) then
        return true
    end
    return region:find("%." .. field .. "%s*=") ~= nil
end

--- Every field NOT reachable in one region. This is the whole checker; both
--- findMissing and the R6b fixture drive THIS function, so a control cannot
--- pass against a second, gentler copy of the rule.
local function missingFields(regionText, fields, label)
    local missing = {}
    for _, field in ipairs(fields) do
        if not isReachable(regionText, field) then
            missing[#missing + 1] = label .. " is missing " .. field
        end
    end
    return missing
end

--- Every (site, field) pair where the field is NOT reachable. Returning the
--- misses rather than a boolean is what lets R6 assert the checker can fail.
local function findMissing(fields)
    local missing = {}
    for _, site in ipairs(SITES) do
        for _, entry in ipairs(missingFields(REGIONS[site.label], fields, site.label)) do
            missing[#missing + 1] = entry
        end
    end
    return missing
end

test("R5 every declared sharing field is carried at all four rebuild sites", function()
    -- Report the parsed list so a run that measured a shrunken list is visible
    -- in the log rather than passing quietly.
    print("      parsed D.SEQUENCE_SHARING_FIELDS: " .. table.concat(SHARING_FIELDS, ", "))
    print("      sites checked: " .. #SITES)

    local missing = findMissing(SHARING_FIELDS)
    if #missing > 0 then
        error("uncarried sharing field(s):\n        " .. table.concat(missing, "\n        "), 2)
    end
end)

test("R6 NEGATIVE CONTROL the same check reports an absent field as missing", function()
    -- Without this, R5 passing would prove only that the checker executed. A
    -- field name that exists nowhere in the tree must come back missing at
    -- EVERY site -- four sites, one bogus field, four misses.
    local ABSENT = "zzzNotAField"
    for _, site in ipairs(SITES) do
        assertFalse(
            REGIONS[site.label]:find(ABSENT, 1, true) ~= nil,
            "the control field must genuinely not appear at " .. site.label
        )
    end

    local missing = findMissing({ ABSENT })
    assertEqual(#SITES, #missing, "the absent field must be reported missing at every site")

    -- And the misses must name the sites, not merely count. A checker that
    -- returned four empty strings would satisfy the count above.
    for _, site in ipairs(SITES) do
        local found = false
        for _, entry in ipairs(missing) do
            if entry:find(site.label, 1, true) and entry:find(ABSENT, 1, true) then
                found = true
                break
            end
        end
        assertTrue(found, "the miss list must name " .. site.label .. " and the absent field")
    end
end)

-- A region whose ONLY mention of the declared fields is in COMMENTS. Built as a
-- literal here rather than by editing a file, so the control is self-contained.
--
-- It is a faithful miniature of the defect: the real SequenceEditor site had a
-- five-line comment naming SEQUENCE_SHARING_FIELDS above its three-line carry
-- loop, so deleting only the loop left R5 green. Both branches of isReachable
-- are trapped here because they fail INDEPENDENTLY:
--   * the ITERATION branch, via a line comment containing SEQUENCE_SHARING_FIELDS
--   * the EXPLICIT branch, twice -- once via a commented-out `.noRedistribute =`
--     line, and once via a `.provenanceAttestedBy =` assignment buried in a LONG
--     comment, which is the form the long-first strip order exists to handle
-- There is no live code in the fixture at all, so after stripping there is
-- nothing left that could qualify either field.
local COMMENT_ONLY_FIXTURE = [==[
    -- Sharing flags. Iterated from D.SEQUENCE_SHARING_FIELDS rather than
    -- hand-written, so a field added to that one list reaches this rebuild too.
    -- newData.noRedistribute = oldData.noRedistribute
    --[[
        newData.provenanceAttestedBy = oldData.provenanceAttestedBy
    ]]
]==]

test("R6b NEGATIVE CONTROL a field named only in a COMMENT is reported missing", function()
    -- Step 1: the fixture must be a genuine trap. Against the RAW text every
    -- declared field looks reachable -- if this half did not hold, R6b could
    -- pass simply by never mentioning the fields.
    local rawMisses = missingFields(COMMENT_ONLY_FIXTURE, SHARING_FIELDS, "raw fixture")
    assertEqual(0, #rawMisses, "UNSTRIPPED, the fixture must look fully carried -- otherwise it traps nothing")

    -- Step 2: stripped, nothing survives that could qualify either field.
    local stripped = stripLuaComments(COMMENT_ONLY_FIXTURE)
    assertFalse(stripped:find("SEQUENCE_SHARING_FIELDS", 1, true) ~= nil, "the iteration bait must be stripped")
    assertFalse(stripped:find(".noRedistribute", 1, true) ~= nil, "the line-comment bait must be stripped")
    assertFalse(stripped:find(".provenanceAttestedBy", 1, true) ~= nil, "the long-comment bait must be stripped")

    -- Step 3: the checker reports BOTH declared fields missing.
    local misses = missingFields(stripped, SHARING_FIELDS, "comment-only fixture")
    assertEqual(#SHARING_FIELDS, #misses, "every declared field must be reported missing in a comment-only region")
    for _, field in ipairs(SHARING_FIELDS) do
        local found = false
        for _, entry in ipairs(misses) do
            if entry:find(field, 1, true) then
                found = true
                break
            end
        end
        assertTrue(found, "the miss list must name " .. field)
    end
end)

-- ---------------------------------------------------------------------------
-- R7 / R8 -- the raw-text editor's deny-list.
--
-- UI/RawTab.lua is the fifth rebuild path and the only one built the other way
-- round: a deep copy of the stored record, then every key from the parsed text
-- overlaid UNLESS it is in LOCKED. Nothing is dropped there, which is why the
-- carry list does not apply -- but anything absent from LOCKED is editable by
-- hand, and the sharing fields were absent.
-- ---------------------------------------------------------------------------

--- The LOCKED set, PARSED out of UI/RawTab.lua rather than retyped -- the same
--- discipline R5 applies to the sharing list. A retyped copy would keep
--- answering about the set this test remembers instead of the one that ships.
local function parseLockedTable()
    local src = readFile({ "UI/RawTab.lua", "../UI/RawTab.lua" })
    assertTrue(src ~= nil, "could not read UI/RawTab.lua for the LOCKED parse")
    local literal = src:match("local LOCKED = {(.-)}")
    assertTrue(literal ~= nil, "anchor gone: no `local LOCKED = {` table in UI/RawTab.lua")
    local locked = {}
    local count = 0
    for field in stripLuaComments(literal):gmatch("([%a_][%w_]*)%s*=%s*true") do
        locked[field] = true
        count = count + 1
    end
    assertTrue(count > 0, "LOCKED parsed to ZERO entries -- the gate would measure nothing")
    return locked, count
end

local LOCKED_SET, LOCKED_COUNT = parseLockedTable()

test("R7 every declared sharing field is LOCKED against a raw-text edit", function()
    print("      parsed LOCKED entries: " .. LOCKED_COUNT)
    local notLocked = {}
    for _, field in ipairs(SHARING_FIELDS) do
        if not LOCKED_SET[field] then
            notLocked[#notLocked + 1] = field
        end
    end
    if #notLocked > 0 then
        error("raw-text editable sharing field(s): " .. table.concat(notLocked, ", "), 2)
    end

    -- Sanity: the parse found the set it was meant to find, not some other
    -- table that happens to match the pattern.
    assertTrue(LOCKED_SET.provenanceSource == true, "the parsed set must contain the known-locked provenanceSource")
    assertTrue(LOCKED_SET.originalSignature == true, "the parsed set must contain the known-locked originalSignature")
end)

local function deepCopy(v)
    if type(v) ~= "table" then
        return v
    end
    local copy = {}
    for k, val in pairs(v) do
        copy[k] = deepCopy(val)
    end
    return copy
end

--- Replicates UI/RawTab.lua's overlay EXACTLY -- deep copy of the stored record,
--- then every NON-locked key from the parsed text wins -- driven by the LOCKED
--- set parsed from the real file in R7.
local function applyRawOverlay(oldData, parsedText)
    local newSeqData = deepCopy(oldData)
    for k, v in pairs(parsedText) do
        if not LOCKED_SET[k] then
            newSeqData[k] = v
        end
    end
    return newSeqData
end

test("R8 a raw-text edit cannot clear the mark, but CAN still edit normal fields", function()
    local oldData = {
        noRedistribute = true,
        provenanceAttestedBy = "abc123hash",
        description = "as stored",
        url = "https://example.invalid/stored",
    }
    -- What a user could type into the raw editbox: clear the mark, forge an
    -- attestation, and edit two ordinary fields.
    local edited = {
        noRedistribute = false,
        provenanceAttestedBy = "forged-identity-hash",
        description = "as edited",
        url = "https://example.invalid/edited",
    }
    local result = applyRawOverlay(oldData, edited)

    assertEqual(true, result.noRedistribute, "a raw edit must NOT clear the do-not-share mark")
    assertEqual("abc123hash", result.provenanceAttestedBy, "a raw edit must NOT rewrite the attestation")

    -- The control, without which R8 would pass by locking the entire table and
    -- turning the raw editor into a read-only view.
    assertEqual("as edited", result.description, "a NON-locked field must still be editable")
    assertEqual("https://example.invalid/edited", result.url, "a second NON-locked field must still be editable")
end)

test("R9 the rename carry keeps ANCESTRY, so a renamed fork still needs confirming", function()
    -- WHY THIS CASE EXISTS. GE.IsLocallyAuthored reads forkedFrom and
    -- forkedFromChain: a copy of someone else's work carries the LOCAL identity
    -- stamp (StampForked re-stamps it) and is held foreign by its ancestry
    -- alone. That makes those two fields load-bearing for the confirmation --
    -- and a rebuild drops any field it does not explicitly carry. Rename a fork
    -- with the ancestry dropped and the copy becomes "yours" on the way through.
    --
    -- D.CarrySequenceIdentity names both fields explicitly, and this pins that.
    -- NOT by adding them to D.SEQUENCE_SHARING_FIELDS: that list drives four
    -- rebuild sites and I:StampForked deliberately INVERTS one of its members
    -- (R4), so a field that must be carried identically everywhere does not
    -- belong in it. The carry is pinned directly instead.
    env.GRIP_EMS_DB.config.provenanceGate = nil

    local me = I:GetCurrent()
    assertTrue(
        type(me.identityHash) == "string" and me.identityHash ~= "",
        "the harness identity must produce a hash or this case is vacuous"
    )

    -- Locally stamped at the top level, foreign one hop out: the exact shape
    -- Duplicate produces, and the shape where a dropped ancestry silently
    -- flips the answer.
    local ancestor = {
        originalAuthor = "Gaupanda",
        originalAuthorIdentity = "0badc0de",
        originalAuthorRealm = "OtherRealm",
        originalCreatedAt = 400,
        forkedAt = 500,
    }
    local src = makeSource({
        originalAuthorIdentity = me.identityHash,
        forkedFrom = ancestor,
        forkedFromChain = { ancestor },
    })
    assertTrue(GE.IsLocallyAuthored(src) == false, "the source must be held foreign by its ancestry")
    assertTrue(GE.NeedsAuthorConfirm(src), "and must need confirming before the rebuild")

    local newData = rebuildFrom(src)

    assertTrue(type(newData.forkedFrom) == "table", "the rebuild must carry forkedFrom")
    assertEqual("0badc0de", newData.forkedFrom.originalAuthorIdentity, "with the ancestor's identity intact")
    assertTrue(type(newData.forkedFromChain) == "table", "the rebuild must carry forkedFromChain")
    assertEqual(1, #newData.forkedFromChain, "with the same number of entries")
    assertEqual("0badc0de", newData.forkedFromChain[1].originalAuthorIdentity, "and the same ancestor in it")

    -- The FRESH-table half of D.CarrySequenceIdentity's documented contract:
    -- the rebuilt record must not alias the old object's chain.
    assertTrue(newData.forkedFromChain ~= src.forkedFromChain, "the chain must be a fresh table, not an alias")

    assertEqual(false, GE.IsLocallyAuthored(newData), "the rebuilt record must still be held foreign")
    assertTrue(GE.NeedsAuthorConfirm(newData), "so a renamed fork must still need confirming")

    -- NON-VACUITY. A rebuild that carried the identity but DROPPED the ancestry
    -- -- which is what an uncarried field looks like -- answers the opposite.
    -- Without this the case could pass on a source that was foreign for some
    -- other reason entirely.
    local dropped = { name = "Renamed", versions = {}, originalAuthorIdentity = me.identityHash }
    assertEqual(true, GE.IsLocallyAuthored(dropped), "a rebuild with no ancestry reads as locally authored")
    assertEqual(false, GE.NeedsAuthorConfirm(dropped), "and would ship without a prompt -- that is the drop")
end)

-- ---------------------------------------------------------------------------
-- Runner.
-- ---------------------------------------------------------------------------

local failures = 0
for _, t in ipairs(tests) do
    local ok, err = pcall(t.fn)
    if ok then
        print("PASS  " .. t.name)
    else
        failures = failures + 1
        print("FAIL  " .. t.name)
        print("      " .. tostring(err))
    end
end

print("")
print(string.format("%d/%d passed", #tests - failures, #tests))
if failures > 0 then
    -- os is dev-harness process control, intentionally outside the addon WoW std.
    -- selene: allow(undefined_variable)
    os.exit(1)
end
