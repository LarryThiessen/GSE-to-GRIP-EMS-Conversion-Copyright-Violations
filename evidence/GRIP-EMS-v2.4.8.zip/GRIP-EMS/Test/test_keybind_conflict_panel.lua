-- GRIP-EMS: Keybind conflict panel helper guard
--
-- Created:    2026-08-11
-- Updated:    2026-08-25 (Patch header swept to build 12.1.0.69273; 2026-08-12 Phase 4: GROUP 6, fix plans and staleness)
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.
--
-- Standalone (Lua 5.1) SET A guard over the PRESENTATION half of the keybind
-- conflict panel: Engine/KeybindConflictHelper.lua, driven against the real
-- Engine/KeybindConflict.lua with stubbed WoW globals, plus the locale keys the
-- helper hands back.
--
-- WHY THIS FILE EXISTS AND WHAT IT REFUSES TO REPEAT. Phases 1 and 2 shipped
-- three rounds of defects behind green suites, and every one of them tested the
-- MECHANISM being changed while never testing the situation the module exists to
-- diagnose: two owners contesting one key. GROUP 1 is that situation, it asserts
-- on the RENDERED REPORT rather than on KC.CheckKey's verdict, and it was written
-- and observed failing before the helper it covers existed.
--
-- GROUP 2 is the other gate that cannot come from anywhere else.
-- audit-locale-references scans for literal locale keys in source; the panel
-- builds its keys THROUGH the helper, so no literal exists to scan and that audit
-- is structurally blind to them. This file walks the published KC tables and
-- proves copy exists for every token in them, including key_budget_exhausted,
-- which is conditional at runtime and would otherwise only be missed by a user
-- who had already exhausted the key budget.
--
-- Run from the EMS root:  lua Test/test_keybind_conflict_panel.lua
-- Exit code 0 = every check passed; 1 = a failure, or a source this guard could
-- not read.

local passedChecks = 0

local function fail(message)
    print("FAIL  test_keybind_conflict_panel -- " .. message)
    os.exit(1)
end

--- Record one passing check, or fail the file with a message naming what went
--- wrong. The RESULT footer prints from this counter and never from a literal,
--- because a hardcoded count desyncs silently the first time a check is added.
local function check(ok, message)
    if not ok then
        fail(message)
    end
    passedChecks = passedChecks + 1
end

-- The three prefixes the repo already uses. Unlike the in-game specs this does
-- NOT skip when nothing opens: under SET A the working directory is the repo root
-- and every file below is guaranteed present, so an unreadable source means this
-- guard is broken, not absent. A skip here would report green while proving
-- nothing.
local PREFIXES = { "", "../", "GRIP/EMS/" }

local function readSource(relPath)
    for _, prefix in ipairs(PREFIXES) do
        local fh = io.open(prefix .. relPath, "r")
        if fh then
            local src = fh:read("*a")
            fh:close()
            if type(src) == "string" and src ~= "" then
                return src
            end
        end
    end
    fail("could not read " .. relPath .. " from any known prefix; run this from the EMS repo root")
end

-- ===========================================================================
-- Load the real modules through the WoW vararg contract
-- ===========================================================================

local GRIPEMS = {}

--- Compile and run one addon file with the (ADDON_NAME, GRIPEMS) varargs the
--- client passes.
---
--- loadstring over a read, NOT loadfile: wow.toml declares loadfile removed --
--- correctly, the WoW client does not have it -- and this file is linted by the
--- same selene run as shipped code. loadstring is a real WoW global, so this uses
--- only what the client actually provides.
local function loadAddonFile(relPath)
    local chunk, err = loadstring(readSource(relPath), "@" .. relPath)
    if not chunk then
        fail("could not compile " .. relPath .. ": " .. tostring(err))
    end
    chunk("GRIP-EMS", GRIPEMS)
end

loadAddonFile("Engine/KeybindConflict.lua")
if type(GRIPEMS.KeybindConflict) ~= "table" then
    fail("Engine/KeybindConflict.lua did not populate GRIPEMS.KeybindConflict")
end

loadAddonFile("Engine/KeybindConflictHelper.lua")
if type(GRIPEMS.KeybindConflictHelper) ~= "table" then
    fail("Engine/KeybindConflictHelper.lua did not populate GRIPEMS.KeybindConflictHelper")
end

local KC = GRIPEMS.KeybindConflict
local KCH = GRIPEMS.KeybindConflictHelper

-- Locale keys declared in enUS, read as TEXT rather than executed: the locale
-- file needs LibStub and AceLocale, neither of which exists here.
local DECLARED_KEYS = {}
for key in string.gmatch(readSource("Locale/enUS.lua"), 'L%["([A-Za-z0-9_]+)"%]%s*=') do
    DECLARED_KEYS[key] = true
end
check(next(DECLARED_KEYS) ~= nil, "no locale keys were parsed out of Locale/enUS.lua (pattern drift?)")

-- ===========================================================================
-- Shared stubs
-- ===========================================================================

-- The sanitiser and prefix KC.ExpectedActionForSequence reaches through
-- addonDep. Injected rather than reimplemented: a second sanitiser here would be
-- free to drift from Engine:SanitizeName, and this guard would then prove an
-- action string no key on the client carries.
local ENGINE_STUB = {
    SanitizeName = function(_, name)
        return (string.gsub(name, "[^%w_]", ""))
    end,
}
local DEFAULTS_STUB = { BUTTON_PREFIX = "GRIPEMS_" }

--- Stub deps for one contested key. baseAction is what the saved binding table
--- reports, effectiveAction what actually receives the keypress.
local function contestDeps(baseAction, effectiveAction, state)
    return {
        strict = true,
        refresh = true,
        state = state,
        Engine = ENGINE_STUB,
        Defaults = DEFAULTS_STUB,
        GetBindingAction = function(_, checkOverride)
            if checkOverride then
                return effectiveAction
            end
            return baseAction
        end,
        GetModifiedClick = function()
            return "NONE"
        end,
    }
end

--- An attribution buffer holding one record per owner in owners, all on one key.
--- Built by installing the real hooks into a private state with a fake
--- hooksecurefunc and firing them, rather than by hand-assembling records: a
--- hand-built buffer could hold a shape the recorder can never produce.
local function attributionWithOwners(key, owners, callers)
    local captured = {}
    local index = 0
    local deps = {
        strict = true,
        state = KC.NewAttributionState(),
        hooksecurefunc = function(name, fn)
            captured[name] = fn
        end,
        SetOverrideBindingClick = function() end,
        debugstack = function()
            index = index + 1
            local caller = callers[index] or callers[#callers]
            return "[C]: in function 'SetOverrideBindingClick'\n"
                .. "[Interface/AddOns/"
                .. caller
                .. "/Bars.lua]:"
                .. tostring(10 + index)
                .. ": in function 'Apply'"
        end,
    }
    KC.InstallAttributionHooks(deps)
    local hook = captured["SetOverrideBindingClick"]
    if type(hook) ~= "function" then
        fail("the SetOverrideBindingClick hook was not captured while seeding attribution")
    end
    for _, owner in ipairs(owners) do
        hook(owner, true, key, "ActionButton5")
    end
    return deps.state
end

--- Count rows by kind in a report.
local function countRows(report, kind)
    local total = 0
    for _, row in ipairs(report.rows) do
        if row.kind == kind then
            total = total + 1
        end
    end
    return total
end

--- Find the first row matching a kind and an optional predicate.
local function findRow(report, kind, predicate)
    for _, row in ipairs(report.rows) do
        if row.kind == kind and (predicate == nil or predicate(row)) then
            return row
        end
    end
    return nil
end

-- ===========================================================================
-- GROUP 1 -- TWO OWNERS CONTEST ONE KEY, asserted on the REPORT
-- ===========================================================================
--
-- The scenario the whole feature exists to diagnose, and the one no suite in
-- Phases 1 or 2 covered. A native binding holds the key in the saved table, a
-- DIFFERENT addon's override actually receives the keypress, and EMS expects to
-- own it. Two attribution records name two different callers.
--
-- Every assertion below reads the RENDERED REPORT. Asserting KC.CheckKey's
-- verdict here would be testing the mechanism again, which is precisely the habit
-- that let three rounds of defects ship green.

local frameA, frameB = {}, {}
local contestState = attributionWithOwners("ALT-CTRL-SHIFT-5", { frameA, frameB }, { "AddonA", "AddonB" })
local contestReport = KCH.BuildReport({
    { family = "sequence", label = "SeqA", key = "shift-ctrl-alt-5", seqName = "SeqA" },
}, contestDeps("ACTIONBUTTON5", "CLICK OtherAddonButton1:LeftButton", contestState))

check(type(contestReport) == "table", "BuildReport returned no report for the contested key")
check(type(contestReport.rows) == "table" and #contestReport.rows > 0, "the contested key produced no rows")

local verdictRow = findRow(contestReport, "verdict")
check(verdictRow ~= nil, "no verdict row was emitted for the contested key")
check(
    verdictRow.status == KC.STATUS.conflict,
    "verdict row status: expected " .. KC.STATUS.conflict .. ", got " .. tostring(verdictRow.status)
)
check(
    verdictRow.severity == KC.SEVERITY.error,
    "verdict row severity: expected " .. KC.SEVERITY.error .. ", got " .. tostring(verdictRow.severity)
)
check(
    verdictRow.key == "ALT-CTRL-SHIFT-5",
    "the verdict row carries the CANONICAL key, got " .. tostring(verdictRow.key)
)

-- The base layer holds a native binding and no healthy override masks it, so it
-- stays a conflict and is republished as a context note.
local baseNote = findRow(contestReport, "note", function(row)
    return row.layerId == KC.LAYER_IDS.base
end)
check(baseNote ~= nil, "the base layer conflict was not republished as a note row")
check(
    baseNote.reason == KC.NOTE_REASONS.baseOwner,
    "base note reason: expected " .. KC.NOTE_REASONS.baseOwner .. ", got " .. tostring(baseNote.reason)
)
check(
    baseNote.copyKey == KCH.CopyKeyFor("noteReason", KC.NOTE_REASONS.baseOwner),
    "the base note carries the copy key mapped from its reason token, got " .. tostring(baseNote.copyKey)
)
check(
    DECLARED_KEYS[baseNote.copyKey] == true,
    "the base note copy key is not declared in enUS: " .. tostring(baseNote.copyKey)
)

-- Both callers survive into the report. One row per record, and the two records
-- must name different addons -- a single row here is the owner-blind dedup
-- regression coming back through a different door.
local attributionRows = countRows(contestReport, "attribution")
check(attributionRows == 2, "expected 2 attribution rows for two contesting owners, got " .. tostring(attributionRows))
local sawAddonA, sawAddonB = false, false
for _, row in ipairs(contestReport.rows) do
    if row.kind == "attribution" then
        sawAddonA = sawAddonA or row.addon == "AddonA"
        sawAddonB = sawAddonB or row.addon == "AddonB"
    end
end
check(sawAddonA and sawAddonB, "the two attribution rows do not name two different addons")

-- One row per layer, every layer, so a clear layer is still visible as evidence.
local layerRows = countRows(contestReport, "layer")
check(layerRows == 4, "expected one row per layer (4), got " .. tostring(layerRows))

-- The tally has to describe the rows that were actually emitted. A counts table
-- computed from anything else is a second source of truth.
local tally = { critical = 0, error = 0, warning = 0, info = 0 }
for _, row in ipairs(contestReport.rows) do
    if row.severity and tally[row.severity] ~= nil then
        tally[row.severity] = tally[row.severity] + 1
    end
end
for severity, expected in pairs(tally) do
    check(
        contestReport.counts[severity] == expected,
        "counts."
            .. severity
            .. ": report says "
            .. tostring(contestReport.counts[severity])
            .. ", rows say "
            .. expected
    )
end

-- Sections exist and the family round-trips.
check(type(contestReport.sections) == "table" and #contestReport.sections == 1, "expected exactly one section")
check(contestReport.sections[1].family == "sequence", "section family")
check(
    DECLARED_KEYS[contestReport.sections[1].copyKey] == true,
    "the section copy key is not declared in enUS: " .. tostring(contestReport.sections[1].copyKey)
)

-- ===========================================================================
-- GROUP 2 -- COPY COMPLETENESS, enumerated from the published tables
-- ===========================================================================
--
-- Walked off the KC tables, never off a list written here: a list in this file
-- would drift exactly the way the panel's map would, and then agree with it.

local function assertCopyForSet(kind, tokens, label)
    for name, token in pairs(tokens) do
        local copyKey = KCH.CopyKeyFor(kind, token)
        check(
            type(copyKey) == "string" and copyKey ~= "",
            label .. "." .. tostring(name) .. " (" .. tostring(token) .. ") has no copy key"
        )
        check(
            copyKey ~= KCH.CopyKeyFor(kind, "__no_such_token__"),
            label .. "." .. tostring(name) .. " (" .. tostring(token) .. ") fell back instead of mapping"
        )
        check(
            DECLARED_KEYS[copyKey] == true,
            label .. "." .. tostring(name) .. " maps to " .. copyKey .. ", which is not declared in enUS"
        )
    end
end

assertCopyForSet("status", KC.STATUS, "KC.STATUS")
assertCopyForSet("layer", KC.LAYER_IDS, "KC.LAYER_IDS")
assertCopyForSet("noteReason", KC.NOTE_REASONS, "KC.NOTE_REASONS")
assertCopyForSet("limit", KC.ATTRIBUTION_LIMITS, "KC.ATTRIBUTION_LIMITS")
assertCopyForSet("severity", KC.SEVERITY, "KC.SEVERITY")

-- key_budget_exhausted is CONDITIONAL at runtime: it only appears on the limits
-- list once a bucket has been refused. Called out separately because a missing
-- mapping for it would otherwise surface for the first time in front of a user
-- who had already hit the cap.
check(
    DECLARED_KEYS[KCH.CopyKeyFor("limit", KC.ATTRIBUTION_LIMITS.keyBudgetExhausted)] == true,
    "the conditional key_budget_exhausted limit has no declared copy"
)

-- ===========================================================================
-- GROUP 3 -- LAYER ID PARITY, both directions
-- ===========================================================================
--
-- Catches drift in the four layer functions without editing them, which matters
-- because one of them is md5-pinned.

local parityResult = KC.CheckKey("ALT-Q", "CLICK GRIPEMS_SeqA:LeftButton", contestDeps("", "", nil))
check(parityResult ~= nil, "CheckKey returned nil for a valid key during the parity check")

local publishedIds = {}
for _, id in pairs(KC.LAYER_IDS) do
    publishedIds[id] = false
end
for _, layer in ipairs(parityResult.layers) do
    check(
        publishedIds[layer.id] ~= nil,
        "CheckKey emitted layer id '" .. tostring(layer.id) .. "', absent from KC.LAYER_IDS"
    )
    publishedIds[layer.id] = true
end
for id, seen in pairs(publishedIds) do
    check(seen, "KC.LAYER_IDS publishes '" .. id .. "', which CheckKey never emits")
end

-- ===========================================================================
-- GROUP 4 -- FALLBACK
-- ===========================================================================
--
-- CopyKeyFor is total. A nil here renders as a blank row, and a blank row reads
-- as "nothing found", which is the most damaging thing this panel could say.

for _, kind in ipairs({ "status", "layer", "noteReason", "limit", "severity" }) do
    local fallback = KCH.CopyKeyFor(kind, "__no_such_token__")
    check(type(fallback) == "string" and fallback ~= "", "CopyKeyFor('" .. kind .. "', unknown) returned no key")
    check(DECLARED_KEYS[fallback] == true, "the " .. kind .. " fallback key " .. fallback .. " is not declared in enUS")
end
check(
    type(KCH.CopyKeyFor("__no_such_kind__", "whatever")) == "string",
    "CopyKeyFor with an unknown KIND returned no key"
)
check(type(KCH.CopyKeyFor(nil, nil)) == "string", "CopyKeyFor(nil, nil) returned no key")

-- ===========================================================================
-- GROUP 5 -- the limits and capabilities are a property of the STATE
-- ===========================================================================
--
-- MEASURED on the live client, on a character with no sequence keybinds bound for
-- the current spec, which is the ORDINARY FIRST-OPEN STATE:
--
--     summary line   No keybinds to check. Bind a sequence to a key first.
--     context block  What this check cannot see
--                    11 installed addon(s) are not loaded ...
--
-- The four STRUCTURAL limits were absent. A header promising to name what the
-- check cannot see, followed only by an addon count, tells the user the check saw
-- everything else -- which is exactly the completeness this panel is forbidden to
-- imply, and the reason those four tokens are published in the first place.
--
-- Measured headless against the shipped code before the client confirmed it:
--     BuildReport, no entries           limits 0   capabilities nil
--     BuildReport, one invalid key      limits 0   capabilities nil
--     BuildReport, one valid key        limits 4   capabilities present
--     KC.GetAttributionState direct     limits 4
-- The harvest was inside the per-entry loop, so with nothing to check it never
-- ran. The unloaded-addon line survived only because ListUnloadedAddons is called
-- outside the loop, which is what made the gap visible instead of total.
--
-- This case is the exact probe that found it.

local emptyState = attributionWithOwners("F13", { {} }, { "SeedAddon" })
local emptyDeps = contestDeps("", "", emptyState)
local emptyReport = KCH.BuildReport({}, emptyDeps)

check(type(emptyReport) == "table", "BuildReport returned no report for an empty entry list")
check(#emptyReport.rows == 0, "an empty entry list must produce no rows, got " .. #emptyReport.rows)

-- The authority on WHICH tokens apply is KC.GetAttributionState, never a list
-- re-derived here: which are structural and which are conditional is decided
-- there, and duplicating that decision is how the two drift.
local stateLimits = KC.GetAttributionState(emptyDeps).limits
check(#stateLimits > 0, "the attribution state published no limits, so this case would prove nothing")
check(
    #emptyReport.limits == #stateLimits,
    "empty report carries " .. #emptyReport.limits .. " limit row(s), the state publishes " .. #stateLimits
)

local reportedTokens = {}
for _, limit in ipairs(emptyReport.limits) do
    reportedTokens[limit.token] = limit.copyKey
end
for _, token in ipairs(stateLimits) do
    check(reportedTokens[token] ~= nil, "the empty report is missing the limit row for '" .. token .. "'")
    check(
        DECLARED_KEYS[reportedTokens[token] or ""] == true,
        "the limit row for '" .. token .. "' has no declared copy"
    )
end

-- Capabilities travel with the state too. Without them the panel cannot say which
-- checks could not run in this game build, which is the third line of the same
-- "what this cannot see" block.
check(type(emptyReport.capabilities) == "table", "an empty report still has to carry a capabilities table")

-- And the same holds when the only entry is an unusable key, which is reachable
-- from the probe box the moment a user types something wrong.
local invalidReport = KCH.BuildReport({ { family = "probe", label = "", key = "" } }, emptyDeps)
check(
    #invalidReport.limits == #stateLimits,
    "a report whose only entry was an invalid key carries " .. #invalidReport.limits .. " limit row(s)"
)
check(type(invalidReport.capabilities) == "table", "an invalid-key report still has to carry capabilities")

-- ===========================================================================
-- GROUP 6 -- fix plans (Phase 4)
-- ===========================================================================
--
-- The resolution half of the feature WRITES to the client's binding registry, so
-- everything about what to write and whether it is still safe to write it lives
-- in pure functions here rather than in the panel. These are the cases that
-- cover them.
--
-- THE SCENARIO CASE IS FIRST, deliberately. Three prior rounds of defects on this
-- feature all came from testing the branch being edited rather than the contest
-- the module exists to diagnose.

--- Deps for one key whose modifier layer holds a MIXTURE of redirect and
--- non-redirect actions on the same modifier. That mixture is the scenario: it is
--- what a real character looks like, and it is where both plausible bugs live.
local function mixedModifierDeps(expected)
    local names = { "SELFCAST", "FOCUSCAST", "CHATLINK" }
    return {
        strict = true,
        refresh = true,
        state = KC.NewAttributionState(),
        Engine = ENGINE_STUB,
        Defaults = DEFAULTS_STUB,
        GetBindingAction = function(_, checkOverride)
            if checkOverride then
                return expected
            end
            return ""
        end,
        GetNumModifiedClickActions = function()
            return #names
        end,
        GetModifiedClickAction = function(index)
            return names[index]
        end,
        GetModifiedClick = function(action)
            if action == "CHATLINK" then
                -- Measured on a stock client: a compound modifier-plus-button
                -- value. It shares the modifier and is NOT a cast redirect.
                return "ALT-BUTTON1"
            end
            return "ALT"
        end,
    }
end

-- CASE 1 -- THE SCENARIO. One key, three modified-click actions on the same
-- modifier, two of which redirect casts and one of which does not.
--
-- This case catches BOTH plausible bugs at once, and they pull in opposite
-- directions:
--   * TOO NARROW. The research record names SetModifiedClick("SELFCAST", "NONE")
--     because SELFCAST was what the probe character had. Fixing only SELFCAST
--     reports success while FOCUSCAST goes on redirecting every spell.
--   * TOO BROAD. Sweeping every entry on the modifier layer would also clear
--     CHATLINK, which does not consume a keypress and is ordinary user
--     configuration nobody asked us to touch.
local mixedExpected = "CLICK GRIPEMS_SeqA:LeftButton"
local mixedReport = KCH.BuildReport({
    { family = "sequence", label = "SeqA", key = "alt-q", seqName = "SeqA" },
}, mixedModifierDeps(mixedExpected))

local mixedModifierRow = findRow(mixedReport, "layer", function(row)
    return row.layerId == KC.LAYER_IDS.modifier
end)
check(mixedModifierRow ~= nil, "no modifier layer row in the mixed-modifier report")
check(
    mixedModifierRow.status == KC.STATUS.conflict,
    "the mixed-modifier layer must be a conflict, got " .. tostring(mixedModifierRow.status)
)
check(
    type(mixedModifierRow.entries) == "table" and #mixedModifierRow.entries == 3,
    "the fixture must put THREE entries on the modifier layer, got "
        .. tostring(mixedModifierRow.entries and #mixedModifierRow.entries)
)

local mixedPlan = KCH.BuildFixPlan(mixedModifierRow)
check(mixedPlan ~= nil, "no plan built for a modifier-layer conflict")
check(mixedPlan.kind == KCH.FIX_KINDS.modifier, "plan kind: " .. tostring(mixedPlan.kind))
check(
    #mixedPlan.actions == 2,
    "the plan must name exactly the TWO cast redirects, got " .. tostring(#mixedPlan.actions)
)
local planned = {}
for _, entry in ipairs(mixedPlan.actions) do
    planned[entry.action] = entry.previous
end
check(planned.SELFCAST == "ALT", "the plan names SELFCAST and captures its value, got " .. tostring(planned.SELFCAST))
check(
    planned.FOCUSCAST == "ALT",
    "the plan names FOCUSCAST and captures its value, got " .. tostring(planned.FOCUSCAST)
)
check(planned.CHATLINK == nil, "the plan must NOT name CHATLINK -- it modifies a click, it does not redirect a cast")

-- CASE 2 -- the biconditional. Every row in a real report either has both a plan
-- and manual copy, or neither. Walked over BuildReport output rather than over
-- hand-built row literals, because a caller passes real rows and those are a
-- different shape from anything a test would invent.
for _, row in ipairs(contestReport.rows) do
    local hasPlan = KCH.BuildFixPlan(row) ~= nil
    local hasManual = KCH.ManualFixKeyFor(row) ~= nil
    check(
        hasPlan == hasManual,
        "plan/manual disagreement on a "
            .. tostring(row.kind)
            .. " row (layer "
            .. tostring(row.layerId)
            .. ", status "
            .. tostring(row.status)
            .. "): plan="
            .. tostring(hasPlan)
            .. " manual="
            .. tostring(hasManual)
    )
end

-- CASE 3 -- base plan content. The contested fixture puts ACTIONBUTTON5 on the
-- saved binding table and another addon's CLICK target on the override, so the
-- base layer is a genuine conflict and its action is what a revert restores.
local baseRow = findRow(contestReport, "layer", function(row)
    return row.layerId == KC.LAYER_IDS.base
end)
check(baseRow ~= nil, "no base layer row in the contested report")
local basePlan = KCH.BuildFixPlan(baseRow)
check(basePlan ~= nil, "no plan built for a base-layer conflict")
check(basePlan.kind == KCH.FIX_KINDS.base, "base plan kind: " .. tostring(basePlan.kind))
check(basePlan.previous == "ACTIONBUTTON5", "base plan previous: " .. tostring(basePlan.previous))
check(basePlan.key == "ALT-CTRL-SHIFT-5", "base plan carries the CANONICAL key, got " .. tostring(basePlan.key))
-- A base conflict with no action is not fixable: a plan with a nil previous is a
-- fix that cannot be undone.
check(
    KCH.BuildFixPlan({ kind = "layer", layerId = KC.LAYER_IDS.base, status = KC.STATUS.conflict, key = "Q" }) == nil,
    "a base conflict with no action must not yield a plan"
)

-- CASE 4 -- refusal, both directions. Every one of these is a moment where the
-- world moved between the read and the click.
local okChanged, tokenChanged = KCH.PlanMatchesObservedState(basePlan, { baseAction = "SOMETHINGELSE" })
check(okChanged == false, "a changed base action must refuse")
check(
    tokenChanged == KCH.PLAN_REJECT.baseChanged,
    "refusal token: expected " .. KCH.PLAN_REJECT.baseChanged .. ", got " .. tostring(tokenChanged)
)
check(KCH.PlanMatchesObservedState(basePlan, nil) == false, "a nil observed must refuse, never pass")
check(KCH.PlanMatchesObservedState(basePlan, {}) == false, "a missing baseAction field must refuse, never pass")
check(KCH.PlanMatchesObservedState(basePlan, { baseAction = "ACTIONBUTTON5" }) == true, "an unchanged world must pass")

local baseRevert = KCH.BuildRevertPlan(basePlan)
check(baseRevert ~= nil and baseRevert.restore == "ACTIONBUTTON5", "the revert restores what the plan captured")
local okFree, tokenFree = KCH.RevertMatchesObservedState(baseRevert, { baseAction = "SOMEONEELSE" })
check(okFree == false, "reverting onto a key something else now holds must refuse")
check(
    tokenFree == KCH.PLAN_REJECT.keyNowFree,
    "revert refusal token: expected " .. KCH.PLAN_REJECT.keyNowFree .. ", got " .. tostring(tokenFree)
)
check(KCH.RevertMatchesObservedState(baseRevert, { baseAction = "" }) == true, "an empty key accepts the revert")
check(KCH.RevertMatchesObservedState(baseRevert, {}) == true, "an unbound key accepts the revert")

-- CASE 4b -- the MODIFIER branch of both predicates, through the COMPARISON.
--
-- The Phase 4 report declared this uncovered and it was: every production call
-- site happens to pass a base plan, so CASE 4 above exercised the base branch
-- only, and the modifier branch was reached solely by constructing a plan. That
-- is the branch deciding whether a modifier fix WRITES, and leaving it to a manual
-- in-game step means a regression in it ships silently until somebody sets up two
-- redirects on one key by hand.
--
-- The asymmetry that matters: a MISSING value must refuse. GetModifiedClick can
-- fail, and ReadObserved deliberately turns a raised call into an absent field --
-- "we could not look" must never score the same as "we looked and it matched".
local mixedObserved = { modifierValues = { SELFCAST = "ALT", FOCUSCAST = "ALT", CHATLINK = "ALT" } }
check(KCH.PlanMatchesObservedState(mixedPlan, mixedObserved) == true, "an unchanged modifier world must pass")

local okOneMoved, tokenOneMoved =
    KCH.PlanMatchesObservedState(mixedPlan, { modifierValues = { SELFCAST = "ALT", FOCUSCAST = "CTRL" } })
check(okOneMoved == false, "ONE moved redirect is enough to refuse the whole modifier plan")
check(
    tokenOneMoved == KCH.PLAN_REJECT.modifierChanged,
    "modifier refusal token: expected " .. KCH.PLAN_REJECT.modifierChanged .. ", got " .. tostring(tokenOneMoved)
)
check(
    KCH.PlanMatchesObservedState(mixedPlan, { modifierValues = { SELFCAST = "ALT" } }) == false,
    "a modifier value MISSING from the observed table must refuse, never pass"
)
check(KCH.PlanMatchesObservedState(mixedPlan, {}) == false, "a missing modifierValues table must refuse")
check(KCH.PlanMatchesObservedState(mixedPlan, nil) == false, "a nil observed must refuse on the modifier branch too")

-- CHATLINK is not in the plan, so moving it must NOT block the fix. The plan's
-- business is the two redirects and nothing else.
check(
    KCH.PlanMatchesObservedState(
        mixedPlan,
        { modifierValues = { SELFCAST = "ALT", FOCUSCAST = "ALT", CHATLINK = "SHIFT" } }
    ) == true,
    "a value the plan never named must not block the fix"
)

local mixedRevert = KCH.BuildRevertPlan(mixedPlan)
check(mixedRevert ~= nil and mixedRevert.kind == KCH.FIX_KINDS.modifier, "no modifier revert plan built")
check(#mixedRevert.actions == 2, "the revert must restore both redirects, got " .. tostring(#mixedRevert.actions))
local restored = {}
for _, entry in ipairs(mixedRevert.actions) do
    restored[entry.action] = entry.restore
end
check(restored.SELFCAST == "ALT" and restored.FOCUSCAST == "ALT", "the revert restores the captured modifier values")
check(
    KCH.RevertMatchesObservedState(mixedRevert, { modifierValues = { SELFCAST = "NONE", FOCUSCAST = "NONE" } }) == true,
    "a revert onto still-cleared redirects must be accepted"
)
local okClaimed =
    KCH.RevertMatchesObservedState(mixedRevert, { modifierValues = { SELFCAST = "NONE", FOCUSCAST = "SHIFT" } })
check(okClaimed == false, "a redirect the user re-set since the fix must refuse the revert, not overwrite it")

-- CASE 5 -- identity. The panel keys fix status by this, and a status has to
-- survive the Rebuild that happens immediately after a fix lands.
local identityVerdict = findRow(contestReport, "verdict")
check(identityVerdict ~= nil, "no verdict row for the identity check")
local seenIdentities = {}
check(KCH.RowIdentity(identityVerdict) ~= nil, "the verdict row has no identity")
seenIdentities[KCH.RowIdentity(identityVerdict)] = "verdict"
for _, row in ipairs(contestReport.rows) do
    if row.kind == "layer" then
        local identity = KCH.RowIdentity(row)
        check(identity ~= nil, "a layer row has no identity: " .. tostring(row.layerId))
        check(
            seenIdentities[identity] == nil,
            "identity collision between "
                .. tostring(seenIdentities[identity])
                .. " and layer "
                .. tostring(row.layerId)
        )
        seenIdentities[identity] = "layer " .. tostring(row.layerId)
    end
end
-- Stable across rebuilds: the same input must produce the same identity, or a
-- status set before a Rebuild is orphaned the instant one happens.
local rebuilt = KCH.BuildReport({
    { family = "sequence", label = "SeqA", key = "shift-ctrl-alt-5", seqName = "SeqA" },
}, contestDeps("ACTIONBUTTON5", "CLICK OtherAddonButton1:LeftButton", contestState))
local rebuiltBase = findRow(rebuilt, "layer", function(row)
    return row.layerId == KC.LAYER_IDS.base
end)
check(rebuiltBase ~= nil, "no base row in the rebuilt report")
check(
    KCH.RowIdentity(rebuiltBase) == KCH.RowIdentity(baseRow),
    "row identity is not stable across a rebuild: "
        .. tostring(KCH.RowIdentity(baseRow))
        .. " vs "
        .. tostring(KCH.RowIdentity(rebuiltBase))
)
check(KCH.RowIdentity(nil) == nil, "RowIdentity(nil) is nil, not a string")
check(KCH.RowIdentity({ kind = "layer" }) == nil, "a row with no key has no identity")

-- CASE 6 -- copy exists for every refusal token, through the same mechanism
-- every other published token set uses.
assertCopyForSet("planReject", KCH.PLAN_REJECT, "KCH.PLAN_REJECT")
check(
    DECLARED_KEYS[KCH.CopyKeyFor("planReject", "__no_such_token__")] == true,
    "the planReject fallback key is not declared in enUS"
)

-- CASE 7 -- the Fix button never makes a claim the panel contradicts one row up.
--
-- The tooltip on a disabled Fix button reads "There is no supported way for an
-- addon to take this key back for you." Phase 4 made ManualFixKeyFor derive from
-- BuildFixPlan, which is right, but it left every row that is NOT a fixable layer
-- row falling through to that sentence -- including the NOTE row that reports the
-- very same finding as the layer row directly above it, which now carries an
-- ENABLED Fix. The panel asserted "no supported way" and offered the way in the
-- same section.
--
-- KCH.FixButtonStateFor is the pure decision: actionable, unavailable, or none.
-- "unavailable" is reserved for a row where the sentence is TRUE -- a conflict
-- this addon genuinely cannot resolve, which is the override case on the
-- effective layer. Everything else gets no button at all rather than a button
-- carrying a false negative.
check(type(KCH.FixButtonStateFor) == "function", "KCH.FixButtonStateFor is missing")
check(type(KCH.FIX_BUTTON_STATES) == "table", "KCH.FIX_BUTTON_STATES is missing")

local STATES = KCH.FIX_BUTTON_STATES
-- THE INVARIANT THAT ACTUALLY PROTECTS fixStatus. RowIdentity is known to collide
-- for two attribution rows on one key, which is harmless only for as long as no
-- attribution row can carry a status. Rather than leave that resting on a comment,
-- pin the property that matters: every row that can be ACTED on has an identity
-- nothing else shares, so a status can never be written against the wrong row.
local actionableIdentities = {}
-- Every row of the contested report, cross-checked against the plan. The
-- biconditional CASE 2 pins is plan <-> manual copy; this is plan <-> button.
for _, row in ipairs(contestReport.rows) do
    local state = KCH.FixButtonStateFor(row)
    local plan = KCH.BuildFixPlan(row)
    check(
        state == STATES.actionable or state == STATES.unavailable or state == STATES.none,
        "FixButtonStateFor returned an unpublished state: " .. tostring(state)
    )
    if plan ~= nil then
        check(state == STATES.actionable, "a row with a plan must be actionable, got " .. tostring(state))
        local identity = KCH.RowIdentity(row)
        check(identity ~= nil, "an actionable row must have an identity to key its status by")
        check(
            actionableIdentities[identity] == nil,
            "two actionable rows share one identity, so a fix status could land on the wrong row: "
                .. tostring(identity)
        )
        actionableIdentities[identity] = true
    else
        check(state ~= STATES.actionable, "a row with no plan must never be actionable: " .. tostring(row.kind))
    end
    -- THE DEFECT THIS CASE EXISTS FOR. A note row restates a finding whose layer
    -- row is fixable, so it must never be the row that says the fix is impossible.
    if row.kind == "note" then
        check(
            state == STATES.none,
            "a note row must carry no Fix button, got " .. tostring(state) .. " for reason " .. tostring(row.reason)
        )
    end
    -- Only a genuine unfixable CONFLICT may claim there is no supported way.
    if state == STATES.unavailable then
        check(
            row.kind == "layer" and row.status == KC.STATUS.conflict,
            "only a conflicting layer row may claim no-supported-way, got kind "
                .. tostring(row.kind)
                .. " status "
                .. tostring(row.status)
        )
    end
end

-- The override case is the one the sentence was written for, and it must still
-- reach it: the effective layer is held by another addon here, and no addon can
-- clear another's override binding.
local effectiveRow = findRow(contestReport, "layer", function(row)
    return row.layerId == KC.LAYER_IDS.effective and row.status == KC.STATUS.conflict
end)
check(effectiveRow ~= nil, "no conflicting effective layer row in the contested fixture")
check(
    KCH.FixButtonStateFor(effectiveRow) == STATES.unavailable,
    "the override row must keep its honest no-supported-way button"
)

-- A clear layer row is not a finding and does not need a button arguing about it.
local clearLayer = findRow(contestReport, "layer", function(row)
    return row.status == KC.STATUS.clear
end)
if clearLayer ~= nil then
    check(KCH.FixButtonStateFor(clearLayer) == STATES.none, "a clear layer row must carry no Fix button")
end

check(KCH.FixButtonStateFor(nil) == STATES.none, "FixButtonStateFor(nil) must be none")
check(KCH.FixButtonStateFor({ kind = "section" }) == STATES.none, "a section row must carry no Fix button")

-- CASE 8 -- a stuck revert must not strand the reverts beneath it.
--
-- Refusing without discarding is the right call: the revert becomes valid again
-- the moment whatever claimed the key lets go. But an Undo that reads ONLY the
-- top of the stack turns that virtue into a trap, and the trap is reachable in
-- two clicks: fix key A, fix key B, rebind B by hand from the game's own panel.
-- B now refuses forever, sits at the head, and A's way back is gone while the
-- Undo button stays lit.
--
-- No headless case could see that, because the walk lived in the panel. It lives
-- in KCH.SelectRevertIndex now, and this is the case that holds it.
local stack = {}
KCH.PushRevertEntry(stack, { key = "ALT-Q", revert = { kind = "base", key = "ALT-Q", restore = "AAA" } })
KCH.PushRevertEntry(stack, { key = "ALT-W", revert = { kind = "base", key = "ALT-W", restore = "BBB" } })
check(#stack == 2, "two reverts for two different keys must both be kept, got " .. tostring(#stack))

-- The head is stuck. The entry beneath it must still be reachable.
local stuck = { ["ALT-W"] = true }
local pickIndex, pickRefused = KCH.SelectRevertIndex(stack, function(entry)
    return not stuck[entry.key]
end)
check(pickIndex == 1, "a stuck head must not strand the entry beneath it, picked " .. tostring(pickIndex))
check(#pickRefused == 1 and pickRefused[1] == 2, "the stuck head must be reported as refused, not skipped in silence")

-- Nothing applicable: every entry refuses, and NOTHING is selected. The caller
-- removes on success only, so the whole stack survives to be tried again.
local noneIndex, noneRefused = KCH.SelectRevertIndex(stack, function()
    return false
end)
check(noneIndex == nil, "when every revert refuses, no index may be returned")
check(#noneRefused == 2, "every refusal must be reported, got " .. tostring(#noneRefused))
check(#stack == 2, "SelectRevertIndex must not mutate the stack")

-- Newest first: with nothing stuck, the top is the pick.
local topIndex = KCH.SelectRevertIndex(stack, function()
    return true
end)
check(topIndex == 2, "with nothing stuck the NEWEST revert is the pick, got " .. tostring(topIndex))

-- KEY UNIQUENESS, which is what makes skipping safe. Fix a key, rebind it by
-- hand, fix it again: the older entry describes a world the user already
-- replaced, so newest wins and the stack does not grow.
KCH.PushRevertEntry(stack, { key = "ALT-Q", revert = { kind = "base", key = "ALT-Q", restore = "CCC" } })
check(#stack == 2, "a second revert for the same key must REPLACE, not append, got " .. tostring(#stack))
check(
    stack[2].revert.restore == "CCC",
    "the newest revert for a key must win, got " .. tostring(stack[2].revert.restore)
)
check(stack[1].key == "ALT-W", "replacing must not disturb the other key's entry, got " .. tostring(stack[1].key))

check(select(
    1,
    KCH.SelectRevertIndex(nil, function()
        return true
    end)
) == nil, "SelectRevertIndex(nil) must be nil, not an error")
check(select(1, KCH.SelectRevertIndex(stack, nil)) == nil, "SelectRevertIndex with no predicate must be nil")

-- ===========================================================================
-- Footer
-- ===========================================================================

print("RESULT " .. passedChecks .. " passed, 0 failed")
print("PASS  test_keybind_conflict_panel -- contested-key report, copy for every published token, layer-id parity")
os.exit(0)
