-- GRIP-EMS: Cursor Overlay (Phase 4 item 15)
-- Created: 2026-04-23
-- Updated: 2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.
--
-- Optional ring or crosshair overlay that tracks the mouse cursor
-- for improved visibility. Sibling to FocusRing -- same ReclaimFrame
-- + TOOLTIP strata + OnPaletteChanged pattern, but tied to the
-- cursor (GetCursorPosition) rather than the focused widget. Color
-- follows UI.Colors.focusRing so contrast-preset switches take
-- effect immediately.
--
-- Three size presets: 1.0x, 1.5x, 2.0x (base ring box = 32px).
-- Two modes: "ring" (4 edge textures) and "crosshair" (2 strips).
-- No per-element theming; out of scope for v2.0.0 (bounded by
-- The Work.md item 15).

local ADDON_NAME, GRIPEMS = ...

GRIPEMS.UI = GRIPEMS.UI or {}
local UI = GRIPEMS.UI

local CursorOverlay = {}
GRIPEMS.UI.CursorOverlay = CursorOverlay

local overlay
local THICKNESS = 2
local BASE = 32

local function createOverlay()
    local f = GRIPEMS.UI:ReclaimFrame("GRIPEMS_CursorOverlay", "Frame", UIParent)
    f:SetFrameStrata("HIGH")
    f:SetFrameLevel(100)
    f:EnableMouse(false)
    f:Hide()

    -- Inventory surviving Texture regions (same pattern as FocusRing).
    -- ReclaimFrame hides regions on /reload but cannot unparent textures,
    -- so reuse anything already bound to this frame before creating more.
    local pool = {}
    for _, r in ipairs({ f:GetRegions() }) do
        if r.GetObjectType and r:GetObjectType() == "Texture" then
            pool[#pool + 1] = r
        end
    end

    local claimed = {}
    local function ensureTex(texName)
        for _, r in ipairs(pool) do
            if not claimed[r] and r.GetName and r:GetName() == texName then
                claimed[r] = true
                return r
            end
        end
        for _, r in ipairs(pool) do
            if not claimed[r] then
                claimed[r] = true
                return r
            end
        end
        return f:CreateTexture(texName, "OVERLAY")
    end

    f.ring = f.ring or {}
    f.ring.top = ensureTex("GRIPEMS_CursorOverlay_Top")
    f.ring.bottom = ensureTex("GRIPEMS_CursorOverlay_Bottom")
    f.ring.left = ensureTex("GRIPEMS_CursorOverlay_Left")
    f.ring.right = ensureTex("GRIPEMS_CursorOverlay_Right")

    f.crosshair = f.crosshair or {}
    f.crosshair.h = ensureTex("GRIPEMS_CursorOverlay_CrossH")
    f.crosshair.v = ensureTex("GRIPEMS_CursorOverlay_CrossV")

    return f
end

local function applyColor(f)
    local c = UI.Colors and UI.Colors.focusRing
    local r, g, b, a
    if c and c.GetRGBA then
        r, g, b, a = c:GetRGBA()
    else
        r, g, b, a = 1.0, 0.85, 0.10, 1
    end
    f.ring.top:SetColorTexture(r, g, b, a)
    f.ring.bottom:SetColorTexture(r, g, b, a)
    f.ring.left:SetColorTexture(r, g, b, a)
    f.ring.right:SetColorTexture(r, g, b, a)
    f.crosshair.h:SetColorTexture(r, g, b, a)
    f.crosshair.v:SetColorTexture(r, g, b, a)
end

local function applyMode(f, mode, sizeMult)
    local ringBox = BASE * sizeMult
    local armLen = (BASE / 2) * sizeMult

    if mode == "crosshair" then
        f.ring.top:Hide()
        f.ring.bottom:Hide()
        f.ring.left:Hide()
        f.ring.right:Hide()

        f:SetSize(armLen * 2, armLen * 2)

        f.crosshair.h:ClearAllPoints()
        f.crosshair.h:SetPoint("LEFT", f, "LEFT", 0, 0)
        f.crosshair.h:SetPoint("RIGHT", f, "RIGHT", 0, 0)
        f.crosshair.h:SetHeight(THICKNESS)
        f.crosshair.h:Show()

        f.crosshair.v:ClearAllPoints()
        f.crosshair.v:SetPoint("TOP", f, "TOP", 0, 0)
        f.crosshair.v:SetPoint("BOTTOM", f, "BOTTOM", 0, 0)
        f.crosshair.v:SetWidth(THICKNESS)
        f.crosshair.v:Show()
    else
        f.crosshair.h:Hide()
        f.crosshair.v:Hide()

        f:SetSize(ringBox, ringBox)

        f.ring.top:ClearAllPoints()
        f.ring.top:SetPoint("TOPLEFT", f, "TOPLEFT", 0, 0)
        f.ring.top:SetPoint("TOPRIGHT", f, "TOPRIGHT", 0, 0)
        f.ring.top:SetHeight(THICKNESS)
        f.ring.top:Show()

        f.ring.bottom:ClearAllPoints()
        f.ring.bottom:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 0, 0)
        f.ring.bottom:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", 0, 0)
        f.ring.bottom:SetHeight(THICKNESS)
        f.ring.bottom:Show()

        f.ring.left:ClearAllPoints()
        f.ring.left:SetPoint("TOPLEFT", f, "TOPLEFT", 0, 0)
        f.ring.left:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 0, 0)
        f.ring.left:SetWidth(THICKNESS)
        f.ring.left:Show()

        f.ring.right:ClearAllPoints()
        f.ring.right:SetPoint("TOPRIGHT", f, "TOPRIGHT", 0, 0)
        f.ring.right:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", 0, 0)
        f.ring.right:SetWidth(THICKNESS)
        f.ring.right:Show()
    end
end

local function onUpdate(self)
    local x, y = GetCursorPosition()
    local s = UIParent:GetEffectiveScale() or 1.0
    if s == 0 then
        return
    end
    self:ClearAllPoints()
    self:SetPoint("CENTER", UIParent, "BOTTOMLEFT", x / s, y / s)
end

-- Idempotent builder. Constructs the overlay frame, its texture-pool
-- inventory (createOverlay), the initial color/mode, the palette hook,
-- and the cursor-tracking OnUpdate script. Runs at most once (guarded by
-- the `overlay` upvalue). This is the sole construction path, reachable
-- only from Refresh: it fires lazily on the first enable, or at login
-- only when the feature is already enabled. A user who never enables the
-- overlay never builds the frame and never attaches OnUpdate. The
-- profile-change watch is registered separately (registerProfileWatch)
-- so it survives even when the frame is never built.
local function buildOverlay()
    if overlay then
        return
    end
    overlay = createOverlay()
    applyColor(overlay)

    local a = GRIPEMS.Settings
        and GRIPEMS.Settings.db
        and GRIPEMS.Settings.db.profile
        and GRIPEMS.Settings.db.profile.accessibility
    local mode = (a and a.cursorOverlayMode) or "ring"
    local sz = (a and tonumber(a.cursorOverlaySize)) or 1.5
    if sz ~= 1.0 and sz ~= 1.5 and sz ~= 2.0 then
        sz = 1.5
    end
    if mode ~= "ring" and mode ~= "crosshair" then
        mode = "ring"
    end
    applyMode(overlay, mode, sz)

    if UI.OnPaletteChanged then
        UI:OnPaletteChanged(function()
            if overlay and overlay:IsShown() then
                applyColor(overlay)
            end
        end)
    end

    overlay:SetScript("OnUpdate", onUpdate)
end

-- Cheap, idempotent profile-change watch. Registered eagerly at login
-- (via Init) regardless of enabled state, so a profile switch to an
-- overlay-enabled profile shows the overlay even when the frame was
-- never built this session. Kept separate from buildOverlay so the
-- heavy frame/texture/OnUpdate construction stays lazy.
local profileWatchRegistered = false
local function registerProfileWatch()
    if profileWatchRegistered then
        return
    end
    local db = GRIPEMS.Settings and GRIPEMS.Settings.db
    if db and db.RegisterCallback then
        db.RegisterCallback(CursorOverlay, "OnProfileChanged", "Refresh")
        db.RegisterCallback(CursorOverlay, "OnProfileCopied", "Refresh")
        db.RegisterCallback(CursorOverlay, "OnProfileReset", "Refresh")
        profileWatchRegistered = true
    end
end

-- Public entry point, called unconditionally at login. Registers the
-- cheap profile-change watch (idempotent) so a later switch to an
-- overlay-enabled profile shows the overlay, then hands off to Refresh,
-- which builds the frame lazily only when the feature is enabled. Init
-- never builds the frame directly -- that stays inside Refresh.
function CursorOverlay:Init()
    registerProfileWatch()
    CursorOverlay:Refresh()
end

function CursorOverlay:Refresh()
    registerProfileWatch()
    local a = GRIPEMS.Settings
        and GRIPEMS.Settings.db
        and GRIPEMS.Settings.db.profile
        and GRIPEMS.Settings.db.profile.accessibility
    if not a or not a.cursorOverlayEnabled then
        -- Feature off: if the frame was never built, do nothing (the
        -- lazy win). If it was built earlier this session, hide it.
        if overlay then
            overlay:Hide()
        end
        return
    end
    -- Feature on: build lazily the first time it is actually enabled,
    -- then paint and show.
    if not overlay then
        buildOverlay()
    end
    local mode = a.cursorOverlayMode or "ring"
    local sz = tonumber(a.cursorOverlaySize) or 1.5
    if sz ~= 1.0 and sz ~= 1.5 and sz ~= 2.0 then
        sz = 1.5
    end
    if mode ~= "ring" and mode ~= "crosshair" then
        mode = "ring"
    end
    applyColor(overlay)
    applyMode(overlay, mode, sz)
    overlay:Show()
end
