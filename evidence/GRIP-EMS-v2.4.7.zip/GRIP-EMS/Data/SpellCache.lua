-- GRIP-EMS: Spell Cache
-- Runtime spell name cache built from C_SpellBook API for autocomplete and validation
-- Created: 2025 (pre-stamping)
-- Updated: 2026-08-17
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)
-- Upvalue accessor for Defaults
local function D()
    return GRIPEMS.Defaults
end

GRIPEMS.SpellCache = {}
local SC = GRIPEMS.SpellCache

--- Validate that a value is a usable WoW spell ID.
--- Spell IDs are signed-32-bit integers in WoW. The C_SpellBook APIs
--- (FindBaseSpellByID, FindSpellOverrideByID) throw on values outside
--- the (0, 2147483647] range. Reserved value 0 is rejected; no real
--- spell uses it. Non-integer numbers are rejected for defensive
--- consistency. The single-point predicate replaces 4 prior inline
--- bounds checks that disagreed on whether 0 was valid.
--- @param spellID any Value to validate
--- @return boolean true if usable as a WoW spell ID
function SC:IsValidSpellID(spellID)
    if type(spellID) ~= "number" then
        return false
    end
    if spellID <= 0 or spellID > 2147483647 then
        return false
    end
    if math.floor(spellID) ~= spellID then
        return false
    end
    return true
end

--- Is a spell ID resolvable to a usable spell name on this client?
--- Rejects non-numbers, out-of-range ids, 12.0 secret values, and
--- in-range integers that C_Spell.GetSpellName cannot resolve. The
--- last case covers packed hero-talent override handles (e.g.
--- 0x06000003) returned by C_SpellBook.FindSpellOverrideByID on 12.0
--- for spells like Dark Ranger Black Arrow (override of Kill Shot).
--- Those are in-range positive ints -- IsValidSpellID accepts them --
--- but never map to a name, so a {spell:handle} built from one can
--- never translate back and leaks a literal brace into the macrotext.
--- @param spellID any Candidate spell id
--- @return boolean true when the id maps to a non-empty spell name
function SC:IsResolvableSpellID(spellID)
    if type(spellID) ~= "number" then
        return false
    end
    if not SC:IsValidSpellID(spellID) then
        return false
    end
    if issecretvalue and issecretvalue(spellID) then
        return false
    end
    local name = C_Spell and C_Spell.GetSpellName and C_Spell.GetSpellName(spellID)
    if issecretvalue and issecretvalue(name) then
        return false
    end
    return name ~= nil and name ~= ""
end

-- Best-effort recovery of a resolvable spell NAME from a possibly-packed id.
-- Resolvable ids return their name directly. Patch 12.0 packs some pet-bank
-- ability ids into a handle ABOVE the signed-32-bit max whose low 16 bits hold
-- the real base id (e.g. 3238019515 -> 16827 Claw). Only that out-of-range class
-- is unpacked; in-range-unresolvable override handles (0x06.., 0x07..) have
-- meaningless low bits and stay unrecovered. The unpacked candidate is accepted
-- ONLY if it independently resolves, so a wrong unpack can never yield a name.
function SC:RecoverSpellName(spellID)
    if type(spellID) ~= "number" then
        return nil
    end
    if SC:IsResolvableSpellID(spellID) then
        return C_Spell.GetSpellName(spellID)
    end
    if spellID > 2147483647 then
        local low = spellID % 65536
        if low > 0 and SC:IsResolvableSpellID(low) then
            return C_Spell.GetSpellName(low)
        end
    end
    return nil
end

--- Scrub macrotext of lines containing out-of-range {spell:N}
--- tokens. WoW Patch 12.0 restricted env rejects btn:Execute on
--- macrotext that contains spell-id tokens above signed-int max
--- (2,147,483,647) with "Direct table creation is not permitted"
--- -- the restricted env appears to take a numeric-overflow
--- error-reporting path that constructs `{...}` table literals,
--- which the env then rejects.
---
--- The bad tokens originate from pre-v2.1.5 imports that bypassed
--- the IsValidSpellID guard later added in v2.1.5 TranslateSpellRef
--- on the write side. SavedVariables written before that fix can
--- still hold them. This runtime scrubber removes the offending
--- lines from the macrotext before it reaches btn:Execute, so the
--- restricted-env failure no longer fires.
---
--- Confirmed empirically against Jesper's DaddySat SavedVariables
--- on 2026-05-23: stripping the 12 offending lines (4 {spell:3238019515}
--- + 8 {spell:3238019941}) made the "Direct table creation" BugSack
--- stack stop firing. Restoring the original SV brought it back.
---
--- Diagnostic side-effect: removed lines are appended to
--- SC._scrubbedTags so the in-game console can inspect which
--- macrotext content got cleaned and from which sequence.
---
--- @param macrotext string|nil The macrotext to scrub
--- @return string Macrotext with invalid-spell-id lines removed
function SC:ScrubInvalidSpellTags(macrotext)
    if type(macrotext) ~= "string" or macrotext == "" then
        return macrotext
    end
    -- Fast path: no spell tokens at all.
    if not macrotext:find("{spell:", 1, true) then
        return macrotext
    end
    local cleaned = {}
    local removed = 0
    for line in macrotext:gmatch("[^\r\n]+") do
        local hasInvalid = false
        for idStr in line:gmatch("{spell:(%d+)}") do
            local id = tonumber(idStr)
            if id and not SC:IsResolvableSpellID(id) then
                hasInvalid = true
                break
            end
        end
        if hasInvalid then
            removed = removed + 1
            SC._scrubbedTags = SC._scrubbedTags or {}
            SC._scrubbedTags[#SC._scrubbedTags + 1] = line
        else
            cleaned[#cleaned + 1] = line
        end
    end
    if removed > 0 and GRIPEMS and GRIPEMS.Debug then
        GRIPEMS:Debug(
            string.format("ScrubInvalidSpellTags: removed %d line(s) with unresolvable {spell:N} tokens", removed)
        )
    end
    return table.concat(cleaned, "\n")
end

-- Recover or drop unresolvable {spell:N} handle tokens in a macrotext. Per token:
-- resolvable -> keep; recoverable via SC:RecoverSpellName -> replace the TOKEN
-- with the recovered NAME; otherwise the line can never cast -> drop that whole
-- line. Returns cleaned text, recovered-token count, dropped-line count.
function SC:RecoverHandleTokensInText(macrotext)
    if type(macrotext) ~= "string" or macrotext == "" then
        return macrotext, 0, 0
    end
    if not macrotext:find("{spell:", 1, true) then
        return macrotext, 0, 0
    end
    local outLines = {}
    local recovered, dropped = 0, 0
    for line in macrotext:gmatch("[^\r\n]+") do
        local dropLine = false
        local newLine = line:gsub("{spell:(%d+)}", function(idStr)
            local id = tonumber(idStr)
            if id and SC:IsResolvableSpellID(id) then
                return nil
            end
            local name = id and SC:RecoverSpellName(id)
            if name then
                recovered = recovered + 1
                return name
            end
            dropLine = true
            return nil
        end)
        if dropLine then
            dropped = dropped + 1
        else
            outLines[#outLines + 1] = newLine
        end
    end
    return table.concat(outLines, "\n"), recovered, dropped
end

-- One-time stored-data recovery: walk every stored sequence version and convert
-- unresolvable {spell:N} handle tokens back to names (dropping only genuinely-dead
-- lines) in BOTH the plain fields (steps / keyPress / keyRelease) AND the tagged
-- fields (taggedSteps / taggedKeyPress / taggedKeyRelease). Tagged fields are
-- healed in place with the SAME per-line transform, which keeps still-valid tokens
-- (e.g. {spell:49966} Smack) intact and replaces only unresolvable handles.
-- NormalizeVersionLocale runs ONLY when a PLAIN field changed: it re-derives the
-- tagged fields from steps, so running it after a tagged-only heal would downgrade
-- those still-valid tokens to plain names. Idempotent; unit-testable.
function SC:RecoverStoredHandleTokens(sequences)
    if type(sequences) ~= "table" then
        return 0, 0
    end
    local totalRec, totalDrop = 0, 0
    for _, seqData in pairs(sequences) do
        if type(seqData) == "table" and type(seqData.versions) == "table" then
            for _, version in ipairs(seqData.versions) do
                if type(version) == "table" then
                    -- plainDirty tracks ONLY plain-field (steps/keyPress/keyRelease)
                    -- changes. NormalizeVersionLocale re-derives the tagged fields
                    -- from steps, so it must run only after a plain field changed --
                    -- never after a tagged-only heal (that would downgrade still-valid
                    -- tokens like {spell:49966} Smack back to plain names).
                    local plainDirty = false
                    if type(version.steps) == "table" then
                        for si, step in ipairs(version.steps) do
                            if type(step) == "string" then
                                local cleaned, rec, drop = SC:RecoverHandleTokensInText(step)
                                if rec > 0 or drop > 0 then
                                    version.steps[si] = cleaned
                                    totalRec = totalRec + rec
                                    totalDrop = totalDrop + drop
                                    plainDirty = true
                                end
                            end
                        end
                    end
                    if type(version.keyPress) == "string" then
                        local cleaned, rec, drop = SC:RecoverHandleTokensInText(version.keyPress)
                        if rec > 0 or drop > 0 then
                            version.keyPress = cleaned
                            totalRec = totalRec + rec
                            totalDrop = totalDrop + drop
                            plainDirty = true
                        end
                    end
                    if type(version.keyRelease) == "string" then
                        local cleaned, rec, drop = SC:RecoverHandleTokensInText(version.keyRelease)
                        if rec > 0 or drop > 0 then
                            version.keyRelease = cleaned
                            totalRec = totalRec + rec
                            totalDrop = totalDrop + drop
                            plainDirty = true
                        end
                    end
                    -- Tagged fields: heal in place with the same per-line transform.
                    -- These do NOT set plainDirty -- they are already healed here, and
                    -- re-deriving them from steps via NormalizeVersionLocale would
                    -- downgrade still-valid {spell:N} tokens to plain names.
                    if type(version.taggedSteps) == "table" then
                        for si, step in ipairs(version.taggedSteps) do
                            if type(step) == "string" then
                                local cleaned, rec, drop = SC:RecoverHandleTokensInText(step)
                                if rec > 0 or drop > 0 then
                                    version.taggedSteps[si] = cleaned
                                    totalRec = totalRec + rec
                                    totalDrop = totalDrop + drop
                                end
                            end
                        end
                    end
                    if type(version.taggedKeyPress) == "string" then
                        local cleaned, rec, drop = SC:RecoverHandleTokensInText(version.taggedKeyPress)
                        if rec > 0 or drop > 0 then
                            version.taggedKeyPress = cleaned
                            totalRec = totalRec + rec
                            totalDrop = totalDrop + drop
                        end
                    end
                    if type(version.taggedKeyRelease) == "string" then
                        local cleaned, rec, drop = SC:RecoverHandleTokensInText(version.taggedKeyRelease)
                        if rec > 0 or drop > 0 then
                            version.taggedKeyRelease = cleaned
                            totalRec = totalRec + rec
                            totalDrop = totalDrop + drop
                        end
                    end
                    if plainDirty then
                        SC:NormalizeVersionLocale(version, seqData.classID)
                    end
                end
            end
        end
    end
    return totalRec, totalDrop
end

-- Cache structure (runtime only, never saved to SavedVariables)
SC.spells = {} -- sorted array of { name, spellID, iconID [, isPet], castTime, gcdMS }
SC.byName = {} -- lowercase name -> entry lookup
SC.byID = {} -- spellID -> entry lookup (OPP-FCG: flyout-child guard)
SC.ready = false -- true after first successful scan
-- Press-hold-release ("empower") spells known to this character, discovered in the
-- SC:Scan spellbook walk. Detection is C_Spell.IsPressHoldReleaseSpell ONLY -- never
-- a class ID, class name, spec ID or hardcoded spell list. The API is the sanctioned
-- primitive and carries SecretArguments AllowedWhenTainted.
SC.empowerIDs = {} -- spellID -> true for every press-hold-release spell in the book
SC.hasEmpower = false -- true when the book contains at least one of them

-- Item cache: lowercase name -> itemID (from bags + equipped)
SC.itemByName = {}
-- Toy cache: lowercase name -> itemID (from collection)
SC.toyByName = {}
-- Resolved-macro-text cache: raw text -> resolved text (wiped on SC:Scan)
SC._resolveCache = {}
SC._resolveCacheCount = 0
-- Mount cache: sorted array of { name, spellID, iconID, mountID }
SC.mounts = {}
-- Companion cache: sorted array of { name, spellID, iconID, petID }
SC.companions = {}

-- Dirty flags per collection. All start true so the initial Scan builds
-- every subset. Each collection-mutation event sets its own flag; the
-- matching sub-builder clears it when it runs. PLAYER_ENTERING_WORLD does
-- NOT set any flag, so a pure zone change with no real mutation becomes
-- a Scan no-op. /reload and ADDON_LOADED take the "all dirty" boot path.
SC.collectionsDirty = {
    spells = true,
    items = true,
    toys = true,
    mounts = true,
    companions = true,
}

-- Lazy-build gate for collections that are expensive to rebuild and not
-- needed until the user opens SpellPicker. Mounts, companions, and toys
-- are skipped by Scan() entirely; a deferred C_Timer.After(3, ...) from
-- PEW and an on-demand Ensure<X>Cache call from each reader both drain
-- the flag. Collection-mutation events flip the matching flag back to
-- true. Wipe-and-rebuild remains the mutation strategy inside each
-- Build<X>Cache; lazyDirty only controls WHEN to pay that cost.
SC.lazyDirty = {
    mounts = true,
    companions = true,
    toys = true,
}

-- Debounce timer handle (cancelled/replaced on re-trigger)
local debounceTimer = nil

---------------------------------------------------------------------------
-- Scan
---------------------------------------------------------------------------

--- Scan the player's spellbook and build the sorted spell cache.
--- Clears and rebuilds spells array and byName lookup from scratch.
--- Each sub-collection is gated by its own dirty flag -- a pure zone change
--- (no collection-mutation event) becomes a no-op. Fires SPELL_CACHE_REFRESHED
--- only when at least one sub-builder actually ran.
function SC:Scan()
    local dirty = self.collectionsDirty
    -- mounts/companions/toys are lazy: see SC:EnsureMountCache etc.
    -- Event handlers still flip dirty.mounts/toys/companions to signal
    -- lazyDirty was already set, but Scan no longer consumes those flags.
    if not dirty.spells and not dirty.items then
        return
    end

    local anyRan = false

    if dirty.spells then
        wipe(self.spells)
        wipe(self.byName)
        wipe(self.byID)
        wipe(self._resolveCache)
        self._resolveCacheCount = 0
        wipe(self.empowerIDs)
        self.hasEmpower = false

        -- Guard: some spellbook entries return actionID values outside the
        -- signed 32-bit range that FindSpellOverrideByID rejects.
        local function SafeOverrideID(actionID)
            if not actionID or type(actionID) ~= "number" then
                return actionID
            end
            if not SC:IsValidSpellID(actionID) then
                return actionID
            end
            return FindSpellOverrideByID(actionID) or actionID
        end

        local numSkillLines = C_SpellBook.GetNumSpellBookSkillLines()
        if not numSkillLines then
            self.ready = true
            GRIPEMS:Debug("SpellCache: no skill lines available")
            return
        end

        -- Categorization context (computed once, applied per skill line)
        local currentSpecIndex = GetSpecialization()
        local currentSpecID = currentSpecIndex and GetSpecializationInfo(currentSpecIndex) or nil
        local _, classEn = UnitClass("player")
        local _, raceEn = UnitRace("player")

        -- Build profession name set from GetProfessions indices
        local profIndices = { GetProfessions() }
        local profNames = {}
        for _, idx in ipairs(profIndices) do
            if idx then
                local profInfo = C_SpellBook.GetSpellBookSkillLineInfo(idx)
                if profInfo and profInfo.name then
                    profNames[strlower(profInfo.name)] = true
                end
            end
        end
        -- Hardcoded fallback for known profession names (12.0 index safety net)
        local KNOWN_PROFESSIONS = {
            "herbalism",
            "mining",
            "engineering",
            "enchanting",
            "alchemy",
            "tailoring",
            "leatherworking",
            "blacksmithing",
            "jewelcrafting",
            "inscription",
            "skinning",
            "cooking",
            "fishing",
            "archaeology",
            "first aid",
        }

        -- Scan player spellbook tabs
        for i = 1, numSkillLines do
            local info = C_SpellBook.GetSpellBookSkillLineInfo(i)
            if info then
                GRIPEMS:Debug(
                    string.format(
                        "SpellCache: skill line [%d] %s: shouldHide=%s, spells=%d",
                        i,
                        info.name or "?",
                        tostring(info.shouldHide),
                        info.numSpellBookItems or 0
                    )
                )
                -- Phase H1.9a: lift the offSpecID guard so off-spec skill lines
                -- enter the scan. Visibility is gated downstream by the
                -- entry.activeSpec tag + SpellPicker spec scope dropdown.
                if not info.isGuild then
                    -- Determine category for this skill line
                    local nameLower = strlower(info.name or "")
                    local category = "other" -- default fallback
                    if info.specID and currentSpecID and info.specID == currentSpecID then
                        category = "spec"
                    elseif info.specID then
                        category = "spec"
                    elseif info.offSpecID then
                        category = "spec"
                    elseif strlower(classEn or "") == nameLower then
                        category = "class"
                    elseif nameLower == "general" then
                        category = "general"
                    elseif strlower(raceEn or "") == nameLower then
                        category = "racial"
                    elseif profNames[nameLower] then
                        category = "profession"
                    else
                        -- Hardcoded profession name fallback
                        for _, pn in ipairs(KNOWN_PROFESSIONS) do
                            if nameLower == pn then
                                category = "profession"
                                break
                            end
                        end
                    end
                    GRIPEMS:Debug(
                        string.format("SpellCache: skill line [%d] %s -> category=%s", i, info.name or "?", category)
                    )
                    local offset = info.itemIndexOffset or 0
                    local count = info.numSpellBookItems or 0

                    for slot = offset + 1, offset + count do
                        local itemInfo = C_SpellBook.GetSpellBookItemInfo(slot, Enum.SpellBookSpellBank.Player)
                        if itemInfo then
                            -- Phase H1.9a: lift the isOffSpec guard. Passives still
                            -- skipped (picker stays castable-only); off-spec items
                            -- are tagged via entry.activeSpec for downstream filtering.
                            if
                                not itemInfo.isPassive
                                and (
                                    itemInfo.itemType == Enum.SpellBookItemType.Spell
                                    or itemInfo.itemType == Enum.SpellBookItemType.Flyout
                                )
                            then
                                -- actionID is the BASE slot ID, but name is the OVERRIDE name.
                                -- Resolve to the override spell ID so name<->ID stay consistent.
                                -- e.g. BM Hunter: actionID=56641 (Steady Shot base), but name="Barbed Shot"
                                -- FindSpellOverrideByID(56641) -> 217200 (Barbed Shot) -> matches name.
                                local resolvedID = SafeOverrideID(itemInfo.actionID)
                                -- C_Spell.GetSpellInfo is a stable modern API; it returns nil cleanly
                                -- for unknown IDs and never raises. OPP-13 dropped the pcall guard.
                                local spellInfo = C_Spell.GetSpellInfo(resolvedID)
                                local castTime = (spellInfo and spellInfo.castTime) or 0
                                local okGCD, gcdMS
                                okGCD, _, gcdMS = pcall(GetSpellBaseCooldown, resolvedID)
                                if not okGCD then
                                    gcdMS = 0
                                end
                                gcdMS = gcdMS or 0
                                -- Press-hold-release ("empower") detection. This API is the ONLY
                                -- gate: never a class ID, class name, spec ID or hardcoded spell
                                -- list. The pcall plus issecretvalue guard mirrors the treatment
                                -- of C_Spell.DoesSpellExist in Data/SpellValidator.lua, where a
                                -- secret return is excluded before the boolean is trusted.
                                local isPH = false
                                if C_Spell.IsPressHoldReleaseSpell and resolvedID then
                                    local okPH, phv = pcall(C_Spell.IsPressHoldReleaseSpell, resolvedID)
                                    if okPH and phv and not issecretvalue(phv) then
                                        isPH = true
                                    end
                                end
                                if isPH then
                                    self.empowerIDs[resolvedID] = true
                                    self.hasEmpower = true
                                end
                                local entry = {
                                    name = itemInfo.name,
                                    spellID = resolvedID,
                                    iconID = itemInfo.iconID,
                                    category = category,
                                    castTime = castTime,
                                    gcdMS = gcdMS,
                                    pressHold = isPH,
                                }
                                -- Skip flyout parents (Call Pet, Pet Utility etc)
                                -- They are not castable; only their children are useful
                                if itemInfo.itemType ~= Enum.SpellBookItemType.Flyout then
                                    -- Racial detection: in 12.0 racials live inside "General"
                                    if category == "general" and entry.spellID then
                                        local subtext = C_Spell.GetSpellSubtext(entry.spellID)
                                        if subtext and subtext ~= "" and subtext:find("^Racial") then
                                            entry.category = "racial"
                                            GRIPEMS:Debug(
                                                string.format(
                                                    "SpellCache: %s subtext=%s -> racial",
                                                    entry.name,
                                                    subtext
                                                )
                                            )
                                        end
                                    end
                                    -- Phase H1.9a: tag spec ownership so the SpellPicker
                                    -- scope dropdown can split current-spec vs off-spec
                                    -- entries. activeSpec is true only for the player's
                                    -- currently active spec skill line.
                                    entry.specID = info.specID or info.offSpecID
                                    entry.activeSpec = (info.specID ~= nil)
                                        and (currentSpecID ~= nil)
                                        and (info.specID == currentSpecID)
                                    table.insert(self.spells, entry)
                                end

                                -- Flyout children: iterate slots to cache each
                                -- child spell (e.g. Call Pet 1-5, Summon Imp, etc.)
                                -- Uses C_Spell.GetSpellName for castable base name
                                -- (NOT the pet/demon display name from itemInfo)
                                if itemInfo.itemType == Enum.SpellBookItemType.Flyout then
                                    local flyoutID = itemInfo.actionID
                                    if flyoutID then
                                        local _, _, numSlots, isKnown = GetFlyoutInfo(flyoutID)
                                        if isKnown and numSlots then
                                            for fi = 1, numSlots do
                                                local childSpellID, _, childIsKnown = GetFlyoutSlotInfo(flyoutID, fi)
                                                if childSpellID and childIsKnown then
                                                    local childName = C_Spell.GetSpellName(childSpellID)
                                                    if childName and childName ~= "" then
                                                        local childIcon = C_Spell.GetSpellTexture(childSpellID)
                                                        local childCat = category
                                                        if childCat == "general" then
                                                            local cSub = C_Spell.GetSpellSubtext(childSpellID)
                                                            if cSub and cSub ~= "" and cSub:find("^Racial") then
                                                                childCat = "racial"
                                                                GRIPEMS:Debug(
                                                                    string.format(
                                                                        "SpellCache: %s subtext=%s -> racial",
                                                                        childName,
                                                                        cSub
                                                                    )
                                                                )
                                                            end
                                                        end
                                                        -- C_Spell.GetSpellInfo returns nil cleanly for unknown IDs.
                                                        -- OPP-13 dropped the pcall guard.
                                                        local childSpellInfo = C_Spell.GetSpellInfo(childSpellID)
                                                        local childCastTime = (
                                                            childSpellInfo
                                                            and childSpellInfo.castTime
                                                        )
                                                            or 0
                                                        local okCGCD, childGcdMS
                                                        okCGCD, _, childGcdMS =
                                                            pcall(GetSpellBaseCooldown, childSpellID)
                                                        if not okCGCD then
                                                            childGcdMS = 0
                                                        end
                                                        childGcdMS = childGcdMS or 0
                                                        local childEntry = {
                                                            name = childName,
                                                            spellID = childSpellID,
                                                            iconID = childIcon,
                                                            isFlyoutChild = true,
                                                            category = childCat,
                                                            castTime = childCastTime,
                                                            gcdMS = childGcdMS,
                                                        }
                                                        -- Phase H1.9a: inherit spec ownership from the
                                                        -- parent skill line so spec-category flyout
                                                        -- children are visible in the right scope.
                                                        childEntry.specID = info.specID or info.offSpecID
                                                        childEntry.activeSpec = (info.specID ~= nil)
                                                            and (currentSpecID ~= nil)
                                                            and (info.specID == currentSpecID)
                                                        table.insert(self.spells, childEntry)
                                                    end
                                                end
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end

        -- Scan pet spells if applicable (Hunter, Warlock, etc.)
        local numPetSpells = C_SpellBook.HasPetSpells()
        if numPetSpells then
            for i = 1, numPetSpells do
                local petInfo = C_SpellBook.GetSpellBookItemInfo(i, Enum.SpellBookSpellBank.Pet)
                if petInfo and not petInfo.isPassive then
                    local petResolvedID = SafeOverrideID(petInfo.actionID)
                    -- C_Spell.GetSpellInfo returns nil cleanly for unknown IDs.
                    -- OPP-13 dropped the pcall guard.
                    local petSpellInfo = C_Spell.GetSpellInfo(petResolvedID)
                    local petCastTime = (petSpellInfo and petSpellInfo.castTime) or 0
                    local okPGCD, petGcdMS
                    okPGCD, _, petGcdMS = pcall(GetSpellBaseCooldown, petResolvedID)
                    if not okPGCD then
                        petGcdMS = 0
                    end
                    petGcdMS = petGcdMS or 0
                    local entry = {
                        name = petInfo.name,
                        spellID = petResolvedID,
                        iconID = petInfo.iconID,
                        isPet = true,
                        category = "pet",
                        castTime = petCastTime,
                        gcdMS = petGcdMS,
                    }
                    table.insert(self.spells, entry)
                end
            end
        end

        -- Scan profession spells via GetProfessionInfo spelloffset
        -- In 12.0 professions are not in skill line tabs; use GetProfessions indices
        local profSlots = { GetProfessions() }
        for pi = 1, 5 do
            local profIdx = profSlots[pi]
            if profIdx then
                local profName, _, _, _, numAbilities, spelloffset = GetProfessionInfo(profIdx)
                if profName and numAbilities and spelloffset then
                    GRIPEMS:Debug(
                        string.format(
                            "SpellCache: profession %s: %d abilities from offset %d",
                            profName,
                            numAbilities,
                            spelloffset
                        )
                    )
                    for slot = spelloffset + 1, spelloffset + numAbilities do
                        local pInfo = C_SpellBook.GetSpellBookItemInfo(slot, Enum.SpellBookSpellBank.Player)
                        if pInfo and not pInfo.isPassive and pInfo.itemType == Enum.SpellBookItemType.Spell then
                            local pEntry = {
                                name = pInfo.name,
                                spellID = SafeOverrideID(pInfo.actionID),
                                iconID = pInfo.iconID,
                                category = "profession",
                            }
                            table.insert(self.spells, pEntry)
                        end
                    end
                end
            end
        end

        -- Sort alphabetically by name (case-insensitive, pre-computed keys)
        for _, entry in ipairs(self.spells) do
            entry._lower = strlower(entry.name)
        end
        table.sort(self.spells, function(a, b)
            return a._lower < b._lower
        end)
        for _, entry in ipairs(self.spells) do
            entry._lower = nil
        end

        -- Build byName lookup (player spells win over pet spells on collision)
        for _, entry in ipairs(self.spells) do
            local key = strlower(entry.name)
            local existing = self.byName[key]
            if not existing then
                self.byName[key] = entry
            elseif not entry.isPet and existing.isPet then
                GRIPEMS:Debug(
                    "SpellCache: byName collision '%s' -- player entry (id=%s) replaces pet entry (id=%s)",
                    entry.name,
                    tostring(entry.spellID),
                    tostring(existing.spellID)
                )
                self.byName[key] = entry
            else
                GRIPEMS:Debug(
                    "SpellCache: byName collision '%s' -- kept existing (id=%s) over new (id=%s, isPet=%s)",
                    entry.name,
                    tostring(existing.spellID),
                    tostring(entry.spellID),
                    tostring(entry.isPet)
                )
            end
        end

        -- Build byID lookup (flyout-child guard in TempoAdvisor)
        for _, entry in ipairs(self.spells) do
            if entry.spellID then
                self.byID[entry.spellID] = entry
            end
        end

        -- Register hero-talent override variants in byName so the typed
        -- override name (e.g. Soul Immolation over Immolation Aura with
        -- the Felscarred DH hero talent) resolves to a real entry. The
        -- spellbook walk only stores the base name; without this pass
        -- SpellValidator marks the override unknown. API-nil guard
        -- covers pre-12.0 patches; bounds check matches the shape of
        -- SafeOverrideID at L92-100. Iterates a stable snapshot via
        -- ipairs and only writes new byName keys -- existing base
        -- entries are preserved.
        local overrideAdded = 0
        if C_SpellBook and C_SpellBook.FindSpellOverrideByID then
            for _, entry in ipairs(self.spells) do
                local baseID = entry.spellID
                if SC:IsValidSpellID(baseID) then
                    local overrideID = C_SpellBook.FindSpellOverrideByID(baseID)
                    if overrideID and overrideID ~= 0 and overrideID ~= baseID then
                        local overrideName = C_Spell.GetSpellName(overrideID)
                        if overrideName and overrideName ~= "" and overrideName ~= entry.name then
                            local key = strlower(overrideName)
                            if not self.byName[key] then
                                local overrideIcon = C_Spell.GetSpellTexture(overrideID) or entry.iconID
                                self.byName[key] = {
                                    spellID = overrideID,
                                    name = overrideName,
                                    iconID = overrideIcon,
                                    isPet = entry.isPet,
                                    isOverride = true,
                                    baseSpellID = baseID,
                                }
                                overrideAdded = overrideAdded + 1
                            end
                        end
                    end
                end
            end
        end
        GRIPEMS:Debug(string.format("SpellCache: registered %d override variants", overrideAdded))

        self.ready = true

        -- Apply spell name overrides from user profile. Shared with the
        -- viewer's rename and Clear Overrides paths so a live edit and a
        -- rebuild land on the same cache state.
        SC:ApplySpellOverrides()

        GRIPEMS:Debug("SpellCache: scanned %d spells", #self.spells)
        dirty.spells = false
        anyRan = true

        -- Layer B: post-scan validation. Catches hero-talent override
        -- timing races by checking that every sequence step's spell
        -- reference resolved against byName; schedules a single retry
        -- with extended delay if any did not.
        SC:_ValidateAndMaybeRetry()
    end

    if dirty.items then
        self:BuildItemCache()
        dirty.items = false
        anyRan = true
    end
    -- Toy/mount/companion caches are built lazily on first picker read
    -- (see SC:EnsureToyCache / SC:EnsureMountCache / SC:EnsureCompanionCache)
    -- with a deferred eager build 3s after PEW as fallback. OPP-01.
    dirty.toys = false
    dirty.mounts = false
    dirty.companions = false

    if anyRan and GRIPEMS.Fire then
        GRIPEMS:Fire("SPELL_CACHE_REFRESHED")
    end
end

---------------------------------------------------------------------------
-- Spell name overrides
---------------------------------------------------------------------------

--- Apply user spell-name overrides to the live cache, and revert entries
--- whose override was removed. Idempotent, so the viewer can call it after
--- every edit and Scan can call it on every rebuild.
--- Reverting needs entry.originalName: the apply overwrites entry.name and
--- drops the old byName key, so without a stored copy the base name is
--- unrecoverable short of a full rescan. That is why Clear Overrides used to
--- leave the custom name on screen until /reload.
--- Re-sorts on change: the build-time apply runs after the alphabetical sort,
--- so a renamed entry would otherwise keep its old slot.
--- @return boolean changed true when any entry name was rewritten
function SC:ApplySpellOverrides()
    local db = GRIPEMS.Settings and GRIPEMS.Settings.db
    local overrides = db and db.profile and db.profile.spellOverrides
    local changed = false

    for _, entry in ipairs(self.spells) do
        local custom = entry.spellID and overrides and overrides[entry.spellID]
        local target = custom or entry.originalName
        if target and target ~= entry.name then
            local oldKey = strlower(entry.name)
            if self.byName[oldKey] == entry then
                self.byName[oldKey] = nil
            end
            if custom then
                entry.originalName = entry.originalName or entry.name
            else
                entry.originalName = nil
            end
            entry.name = target
            self.byName[strlower(target)] = entry
            changed = true
        end
    end

    if changed then
        for _, entry in ipairs(self.spells) do
            entry._lower = strlower(entry.name)
        end
        table.sort(self.spells, function(a, b)
            return a._lower < b._lower
        end)
        for _, entry in ipairs(self.spells) do
            entry._lower = nil
        end

        -- Re-register any entry whose byName key went missing. Reverting an
        -- override that had been renamed onto another spell's name drops that
        -- key, which would otherwise leave the real owner unresolvable by name
        -- until the next rescan. Fill empty keys only -- never displace a
        -- current owner, mirroring the build-time first-writer-wins rule.
        for _, entry in ipairs(self.spells) do
            local key = strlower(entry.name)
            if self.byName[key] == nil then
                self.byName[key] = entry
            end
        end
    end

    return changed
end

---------------------------------------------------------------------------
-- Prefix Search
---------------------------------------------------------------------------

--- Search for spells whose name starts with the given prefix.
--- Returns up to maxResults matches from the sorted cache.
--- @param prefix string The prefix to match against spell names
--- @param maxResults number|nil Maximum results to return (default from Defaults)
--- @return table Array of matching { name, spellID, iconID } entries
function SC:PrefixSearch(prefix, maxResults)
    if not prefix then
        return {}
    end
    prefix = strlower(prefix)
    maxResults = maxResults or D().AUTOCOMPLETE_MAX_RESULTS

    -- Caller enforces min-chars threshold (see handleTabAutocomplete)

    local results = {}
    local prefixLen = #prefix
    for _, entry in ipairs(self.spells) do
        if strlower(entry.name):sub(1, prefixLen) == prefix then
            table.insert(results, entry)
            if #results >= maxResults then
                break
            end
        end
    end

    return results
end

---------------------------------------------------------------------------
-- Icon Lookup
---------------------------------------------------------------------------

--- Get the icon ID for a spell by name.
--- Checks the cache first (fast), falls back to C_Spell.GetSpellTexture.
--- @param spellName string The spell name to look up
--- @return number|nil iconID The file ID of the spell icon, or nil
function SC:GetIcon(spellName)
    if not spellName then
        return nil
    end

    local entry = self.byName[strlower(spellName)]
    if entry then
        return entry.iconID
    end

    -- Fallback: try the API directly (handles spells not in spellbook)
    local iconID = C_Spell.GetSpellTexture(spellName)
    return iconID
end

---------------------------------------------------------------------------
-- Spell ID Lookup
---------------------------------------------------------------------------

--- Build (once) and return the bundled catalog name->ID index. Maps both the
--- English catalog name AND the WoW-localized name (resolved per ID) to the
--- spell ID. This is the locale-independent name->ID source: a client only
--- knows spell names in its OWN locale, so an import string carrying English
--- names cannot tag to IDs via the spellbook on a non-enUS client. The catalog
--- can. Lazy-built on first call; shared with SC:_NotifySpellResolveFailure.
--- @return table|nil index map of lowercased name to spellID, or nil
function SC:_EnsureCatalogNameIndex()
    if self._catalogNameIndex then
        return self._catalogNameIndex
    end
    local CC = GRIPEMS.CrossClassSpellCatalog
    if not CC then
        return nil
    end
    local idx = {}
    for _, entry in ipairs(CC) do
        if entry.n and entry.id then
            idx[strlower(entry.n)] = entry.id
            -- Also index the localized name so a non-enUS client resolves names
            -- already in its own locale. GetSpellName by ID returns the real
            -- localized name regardless of loadout; on enUS it equals the English
            -- name (no-op second insert).
            if C_Spell and C_Spell.GetSpellName then
                local localized = C_Spell.GetSpellName(entry.id)
                if localized and localized ~= "" then
                    idx[strlower(localized)] = entry.id
                end
            end
        end
    end
    -- Phase 2 bundle: load the locale-name bundle on demand (LoadOnDemand sub-addon
    -- GRIP-EMS_LocaleNames) then merge the cross-locale names + collision table. The
    -- sub-addon's data file assigns the global _G.GRIPEMS_LocaleNamesBundle because a
    -- LoadOnDemand addon's vararg is its own private table, not GRIPEMS. Names are stored
    -- RAW; strlower here so build-time keys equal runtime lookup keys by construction. If
    -- the load fails, the if-guard below skips the merge and resolution degrades to
    -- bare-catalog names only.
    if C_AddOns and C_AddOns.LoadAddOn then
        C_AddOns.LoadAddOn("GRIP-EMS_LocaleNames")
    end
    local LB = _G.GRIPEMS_LocaleNamesBundle
    if LB then
        if LB.flat then
            for rawName, id in pairs(LB.flat) do
                local key = strlower(rawName)
                if idx[key] == nil then
                    idx[key] = id
                end
            end
        end
        self._catalogNameCollisions = LB.collisions
    end

    self._catalogNameIndex = idx
    -- The bundle is fully merged into idx above, and its collisions table is
    -- retained via self._catalogNameCollisions. The index is built once and
    -- never rebuilt, and this function is the bundle's only reader, so drop
    -- the ~2.6 MB source table to reclaim the duplicate copy and let the
    -- LoadOnDemand sub-addon unload.
    _G.GRIPEMS_LocaleNamesBundle = nil
    return idx
end

-- Catalog class shortname -> WoW classID. Stable; class IDs do not change between patches.
local CLASS_SHORT_TO_ID = {
    warrior = 1,
    paladin = 2,
    hunter = 3,
    rogue = 4,
    priest = 5,
    deathknight = 6,
    shaman = 7,
    mage = 8,
    warlock = 9,
    monk = 10,
    druid = 11,
    demonhunter = 12,
    evoker = 13,
}

--- Disambiguate a colliding catalog name to one SpellID using game facts only.
--- Order: class-context -> IsSpellKnown -> base-spell collapse -> prefer-castable -> lowest id.
--- @param candidates table Array of { i = id, c = classShort, k = castableInt } (from bundle).
--- @param contextClassID number|nil Sequence/author classID; defaults to the player's class.
--- @return number|nil spellID
function SC:_ResolveCollision(candidates, contextClassID)
    if not candidates or #candidates == 0 then
        return nil
    end
    local pool = candidates
    -- 1. class-context
    local ctx = contextClassID or select(3, UnitClass("player"))
    if ctx then
        local byClass = {}
        for _, cand in ipairs(pool) do
            if CLASS_SHORT_TO_ID[cand.c] == ctx then
                byClass[#byClass + 1] = cand
            end
        end
        if #byClass > 0 then
            pool = byClass
        end
    end
    if #pool == 1 then
        return pool[1].i
    end
    -- 2. IsSpellKnown (covers IsPlayerSpell for passives/talents)
    local known = {}
    for _, cand in ipairs(pool) do
        if IsSpellKnown(cand.i) or IsPlayerSpell(cand.i) then
            known[#known + 1] = cand
        end
    end
    if #known == 1 then
        return known[1].i
    end
    if #known > 1 then
        pool = known
    end
    -- 3. base-spell collapse: if all remaining share one base, any is correct
    local base = self:GetBaseSpellID(pool[1].i)
    local collapsed = true
    for _, cand in ipairs(pool) do
        if self:GetBaseSpellID(cand.i) ~= base then
            collapsed = false
            break
        end
    end
    if collapsed then
        return pool[1].i
    end
    -- 4. prefer castable (active) over passive/aura
    local active = {}
    for _, cand in ipairs(pool) do
        if cand.k == 1 then
            active[#active + 1] = cand
        end
    end
    if #active == 1 then
        return active[1].i
    end
    if #active > 1 then
        pool = active
    end
    -- 5. deterministic final tiebreak: lowest SpellID
    local best = pool[1].i
    for _, cand in ipairs(pool) do
        if cand.i < best then
            best = cand.i
        end
    end
    return best
end

--- Resolve a spell name to an ID via the bundled English-keyed catalog.
--- Locale-independent fallback used by SC:GetSpellID so English import strings
--- tag to real IDs on non-enUS clients.
--- @param spellName string The spell name to resolve
--- @return number|nil spellID A valid spell ID, or nil if not in catalog
function SC:_CatalogIDForName(spellName, contextClassID)
    if not spellName or spellName == "" then
        return nil
    end
    local idx = self:_EnsureCatalogNameIndex()
    if not idx then
        return nil
    end
    local key = strlower(spellName)
    local collisions = self._catalogNameCollisions
    if collisions and collisions[key] then
        local id = self:_ResolveCollision(collisions[key], contextClassID)
        if type(id) == "number" and self:IsValidSpellID(id) then
            return id
        end
        return nil
    end
    local id = idx[key]
    if type(id) == "number" and self:IsValidSpellID(id) then
        return id
    end
    return nil
end

--- Get the spell ID for a spell by name.
--- Checks cache first (fast), falls back to C_Spell.GetSpellInfo, then to the
--- bundled English-keyed catalog (locale-independent).
--- @param spellName string The spell name to look up
--- @return number|nil spellID The spell ID, or nil if not found
function SC:GetSpellID(spellName, contextClassID)
    if not spellName then
        return nil
    end

    local entry = self.byName[strlower(spellName)]
    if entry then
        return entry.spellID
    end

    -- Fallback: WoW API. Both this and the byName cache above are CLIENT-LOCALE
    -- bound -- an English name will not resolve on a deDE/frFR/etc. client.
    local info = C_Spell.GetSpellInfo(spellName)
    if info and info.spellID then
        return info.spellID
    end

    -- Locale-independent fallback: the bundled English-keyed catalog. This is what
    -- lets an imported/shared sequence authored in English tag to real spell-ID
    -- tokens on a non-enUS client, which toNames then renders in the client locale.
    return self:_CatalogIDForName(spellName, contextClassID)
end

--- Normalize a spell ID to its base (talent-portable) form.
--- Strips talent overrides so stored ID works across talent changes.
---
--- Answers come from C_SpellBook.FindBaseSpellByID first and from
--- D.BASE_SPELL_TABLE when the API has nothing to offer. "Nothing to offer" is
--- TWO answers, not one: a nil return, and a return of the id it was handed.
--- The second is the one the Ravage class gives, and reading it as a real answer
--- is what kept the table unreachable before v2.4.4.
---
--- THE TABLE IS HAND-CURATED DATA, so its VALUES are validated on the way out
--- and not only the id handed in. A row is added by a person copying a number
--- off a live client, and a digit typo, a sign typo, a quoted number or the
--- reserved 0 all produce a value that no guard here used to see. A rejected row
--- falls through exactly as a missing row does, so the function still answers.
---
--- The consumer that makes this matter is SC:TranslateSpellRef: it assigns
--- resolvedId from this return and then calls C_SpellBook.FindSpellOverrideByID
--- on it WITHOUT re-running SC:IsValidSpellID, which only ever saw the ORIGINAL
--- id. That API throws on values outside the signed-32-bit range rather than
--- returning nil (see the comment at the FindSpellOverrideByID call site), and
--- Engine:HealOverrideSteps calls TranslateMacrotext with no pcall, so a bad row
--- would surface on PLAYER_SPECIALIZATION_CHANGED or TRAIT_CONFIG_UPDATED and
--- abort the heal walk for every sequence after it. No shipped row can trigger
--- that today; the exposure grows with each pair added under
--- EMS-OVERRIDE-BASE-MAP-OFFLINE, which is why the check is here now.
--- @param spellID number The spell ID to normalize
--- @return number|nil baseID The base spell ID, or nil if input is nil
function SC:GetBaseSpellID(spellID)
    if not spellID then
        return nil
    end
    -- Bounds guard: FindBaseSpellByID throws on IDs outside signed-32-bit
    -- range. Matches the SafeOverrideID pattern at L92-100. User-typed
    -- {spell:N} tokens are not bounded; reject without API call.
    if not SC:IsValidSpellID(spellID) then
        return spellID
    end
    if not C_SpellBook.FindBaseSpellByID then
        return spellID
    end
    local baseID = C_SpellBook.FindBaseSpellByID(spellID)
    -- An IDENTITY answer is not an answer. Measured on a live Guardian Druid
    -- (Sataanoir, 12.1.0.69299): FindBaseSpellByID(441583) returns 441583 for
    -- Ravage, its own id, which is TRUTHY. The old `if baseID then return` fired
    -- on that and the fallback table below was never consulted -- unreachable
    -- for exactly the class it was built to cover. Raze 400254 returns 6807 and
    -- still short-circuits here, unchanged.
    if baseID and baseID ~= spellID then
        return baseID
    end
    -- Hardcoded fallback for spells where the API returns nil OR returns the id
    -- it was handed. `baseID or spellID` on the tail keeps both of those landing
    -- exactly where they land today whenever the table has no entry: a nil API
    -- answer falls to spellID, an identity answer falls to baseID, and the two
    -- are the same value.
    local fallback = D().BASE_SPELL_TABLE[spellID]
    -- VALIDATE THE VALUE, not just the input. Everything above guards the id
    -- handed IN; this is a hand-curated table, so its values are the one input
    -- to this function that no guard had seen. `~= nil` rather than a bare
    -- truthiness test on purpose: a row written as `false` is malformed too, and
    -- a truthy test would skip it silently instead of reporting it.
    if fallback ~= nil and not SC:IsValidSpellID(fallback) then
        if GRIPEMS and GRIPEMS.Debug then
            GRIPEMS:Debug(
                "SC:GetBaseSpellID rejecting malformed BASE_SPELL_TABLE row ["
                    .. tostring(spellID)
                    .. "] = "
                    .. tostring(fallback)
            )
        end
        fallback = nil
    end
    return fallback or baseID or spellID
end

--- Is this spell a press-hold-release ("empower") spell?
--- Reads the set discovered by SC:Scan; never calls the API directly, so every
--- consumer shares one detection path and one set of guards.
--- @param spellID number|nil The spell ID to test
--- @return boolean isEmpower True only for IDs the spellbook walk flagged
function SC:IsEmpowerSpell(spellID)
    return spellID ~= nil and self.empowerIDs[spellID] == true
end

--- Does this character know at least one press-hold-release spell?
--- This is the condition the user-facing "Evoker Mode" surface is named after.
--- It is a capability test, NOT a class test: any character whose book contains
--- a press-hold-release spell satisfies it.
--- @return boolean hasEmpower
function SC:HasEmpowerSpells()
    return self.hasEmpower == true
end

---------------------------------------------------------------------------
-- Remote Cache Merge (P2P spell cache sharing)
---------------------------------------------------------------------------

--- Merge spell entries received from a remote player into the local cache.
--- Only adds entries not already present. Entries are keyed by lowercase name.
--- @param entries table Remote cache: spellName -> spellID
--- @return number merged Count of newly merged entries
function SC:MergeRemoteCache(entries)
    if type(entries) ~= "table" then
        return 0
    end
    local merged = 0
    for name, id in pairs(entries) do
        local key = strlower(name)
        if not self.byName[key] then
            local entry = {
                name = name,
                spellID = id,
                iconID = nil,
            }
            self.byName[key] = entry
            table.insert(self.spells, entry)
            merged = merged + 1
        end
    end
    return merged
end

---------------------------------------------------------------------------
-- Locale Tagging (Phase 2 dual-store)
---------------------------------------------------------------------------

--- Tag an array of macro steps with spell ID tokens.
--- Thin wrapper over TranslateMacrotext for batch tagging.
--- @param steps table Array of macro text strings
--- @return table tagged Array of tagged strings with {spell:ID} tokens
function SC:TagSteps(steps, opts)
    local tagged = {}
    for i, step in ipairs(steps) do
        tagged[i] = self:TranslateMacrotext(step, "toIDs", opts)
    end
    return tagged
end

--- Translate a single action-node macro field. node.macro is dual-format: a
--- full "/command X" line (MigrateStepsToActions stores the whole step) OR a
--- bare spell name (hand-authored IF children; the IF compiler wraps bare
--- payloads as /cast). TranslateMacrotext only acts on command lines, so a bare
--- name is wrapped as /cast, translated, then unwrapped -- preserving the bare
--- vs full form.
--- @param macro string The node.macro value
--- @param direction string "toIDs" or "toNames"
--- @return string translated
function SC:_TranslateActionMacro(macro, direction, opts)
    if type(macro) ~= "string" or macro == "" then
        return macro
    end
    if macro:find("\n") or macro:find("/%a") then
        return self:TranslateMacrotext(macro, direction, opts)
    end
    local wrapped = self:TranslateMacrotext("/cast " .. macro, direction, opts)
    return (wrapped:gsub("^/cast ", "", 1))
end

--- Walk an action-node array, calling fn(node) on every node (including nested
--- IF / Loop subtrees). Mirrors D.DeepCopyActions' children dispatch: IF nodes
--- carry children = { trueBranch, falseBranch } (two node arrays); every other
--- node type carries a flat node array.
--- @param nodes table Action-node array
--- @param fn function Called as fn(node) per node
function SC:_WalkActions(nodes, fn)
    if type(nodes) ~= "table" then
        return
    end
    for _, node in ipairs(nodes) do
        if type(node) == "table" then
            fn(node)
            if node.children then
                if node.type == D().ACTION_TYPE_IF then
                    self:_WalkActions(node.children[1], fn)
                    self:_WalkActions(node.children[2], fn)
                else
                    self:_WalkActions(node.children, fn)
                end
            end
        end
    end
end

--- Localize every macro in an action tree to the CURRENT client locale and stash
--- the canonical ID form on node.macroTagged. The engine recompiles ver.steps
--- from ver.actions on activation, so the action tree -- not just the flat steps
--- -- must carry client-locale macro text for a native / imported sequence to
--- cast on a non-enUS client.
--- @param nodes table Action-node array (version.actions)
function SC:NormalizeActionsLocale(nodes, opts)
    self:_WalkActions(nodes, function(node)
        if type(node.macro) == "string" and node.macro ~= "" then
            local tagged = self:_TranslateActionMacro(node.macro, "toIDs", opts)
            node.macroTagged = tagged
            node.macro = self:_TranslateActionMacro(tagged, "toNames")
        end
    end)
end

--- Tag every macro in an action tree to spell-ID tokens for export, so the
--- transport is locale-independent (mirrors the toIDs step tagging in
--- PrepareExportVersions). Strips the storage-only macroTagged field.
--- @param nodes table Action-node array
function SC:TagActionsToIDs(nodes, opts)
    self:_WalkActions(nodes, function(node)
        if type(node.macro) == "string" and node.macro ~= "" then
            -- Reuse the stored canonical ID form (set by NormalizeActionsLocale)
            -- when present so the transport is independent of the exporter's
            -- client locale; fall back to a fresh toIDs resolution otherwise.
            node.macro = node.macroTagged or self:_TranslateActionMacro(node.macro, "toIDs", opts)
        end
        node.macroTagged = nil
    end)
end

--- Normalize a version's locale data. Ensures taggedSteps hold canonical
--- spell-ID tokens, then renders steps / keyPress / keyRelease into the CURRENT
--- client locale from those IDs, localizes the action tree, and stamps
--- stepsLocale. Single enforcement point for the dual-store invariant -- call it
--- at every surface that stores a version (import, P2P receive, migrate, /gems
--- revalidate, edit-save, new-from-scratch, boot migration). Idempotent and
--- edit-safe: it re-tags FROM the current steps first, so a user edit is
--- captured, never overwritten. Names the catalog cannot resolve stay in their
--- source language (per-line graceful degradation).
--- @param version table A sequence version with steps / keyPress / keyRelease
function SC:NormalizeVersionLocale(version, classID)
    if type(version) ~= "table" then
        return
    end
    -- Q2 Phase 4: thread the sequence's classID so a colliding localized name tags to the
    -- author's class, not the importer's. classID 0 (class-neutral) is handled by the resolver;
    -- nil classID preserves the prior player-default behavior exactly.
    local idOpts = classID and { classID = classID } or nil
    -- 1. Canonical ID tokens from the current step text (cross-locale via the
    --    catalog fallback in SC:GetSpellID).
    version.taggedSteps = self:TagSteps(version.steps or {}, idOpts)
    version.taggedKeyPress = self:TranslateMacrotext(version.keyPress or "", "toIDs", idOpts)
    version.taggedKeyRelease = self:TranslateMacrotext(version.keyRelease or "", "toIDs", idOpts)
    -- 2. Render the client-locale cast text back from those IDs.
    if version.steps then
        for i, tagged in ipairs(version.taggedSteps) do
            version.steps[i] = self:TranslateMacrotext(tagged, "toNames")
        end
    end
    if version.taggedKeyPress and version.taggedKeyPress ~= "" then
        version.keyPress = self:TranslateMacrotext(version.taggedKeyPress, "toNames")
    end
    if version.taggedKeyRelease and version.taggedKeyRelease ~= "" then
        version.keyRelease = self:TranslateMacrotext(version.taggedKeyRelease, "toNames")
    end
    -- 2.5 Localize the action tree too: the engine recompiles ver.steps from
    --     ver.actions on activation, so an action tree (IF / Loop / interleave)
    --     must carry client-locale macro text or the recompile clobbers the
    --     localized flat steps above.
    self:NormalizeActionsLocale(version.actions, idOpts)
    -- 3. Stamp: steps are now in the current locale.
    version.stepsLocale = GetLocale()
end

---------------------------------------------------------------------------
-- Item and Toy Caches (Phase 2d)
---------------------------------------------------------------------------

--- Build item name -> ID lookup from bags and equipped items.
--- Called after spell scan and on BAG_UPDATE_DELAYED / PLAYER_EQUIPMENT_CHANGED.
function SC:BuildItemCache()
    wipe(self.itemByName)
    local pendingIDs = {}
    -- Scan bags (0 = Backpack, 1-4 = bags, 5 = ReagentBag)
    for bag = 0, 5 do
        local numSlots = C_Container.GetContainerNumSlots(bag)
        for slot = 1, numSlots do
            local info = C_Container.GetContainerItemInfo(bag, slot)
            if info and info.itemID then
                local name = C_Item.GetItemInfo(info.itemID)
                if name then
                    self.itemByName[strlower(name)] = info.itemID
                else
                    pendingIDs[info.itemID] = true
                end
            end
        end
    end
    -- Scan equipped items (slots 1-19)
    for slot = 1, 19 do
        local itemID = GetInventoryItemID("player", slot)
        if itemID then
            local name = C_Item.GetItemInfo(itemID)
            if name then
                self.itemByName[strlower(name)] = itemID
            else
                pendingIDs[itemID] = true
            end
        end
    end
    -- Scan warbank tabs (account bank, may be nil when not at banker)
    if Enum.BagIndex and Enum.BagIndex.AccountBankTab_1 then
        for tab = Enum.BagIndex.AccountBankTab_1, Enum.BagIndex.AccountBankTab_5 do
            local numSlots = C_Container.GetContainerNumSlots(tab)
            for slot = 1, numSlots do
                local wbInfo = C_Container.GetContainerItemInfo(tab, slot)
                if wbInfo and wbInfo.itemID then
                    local name = C_Item.GetItemInfo(wbInfo.itemID)
                    if name then
                        self.itemByName[strlower(name)] = wbInfo.itemID
                    else
                        pendingIDs[wbInfo.itemID] = true
                    end
                end
            end
        end
    end
    -- Request missing item data and schedule a single retry
    if next(pendingIDs) and not SC._itemRetryScheduled then
        for itemID in pairs(pendingIDs) do
            C_Item.RequestLoadItemDataByID(itemID)
        end
        SC._itemRetryScheduled = true
        if C_Timer and C_Timer.After then
            C_Timer.After(2, function()
                SC._itemRetryScheduled = nil
                SC:BuildItemCache()
            end)
        end
    end
end

--- Build toy name -> ID lookup from toy collection.
--- Only indexes toys the player has collected.
--- Called once after spell scan (toys are account-wide, rarely change).
function SC:BuildToyCache()
    wipe(self.toyByName)
    for i = 1, C_ToyBox.GetNumToys() do
        local itemID = C_ToyBox.GetToyFromIndex(i)
        if itemID and itemID > 0 and PlayerHasToy(itemID) then
            local _, toyName = C_ToyBox.GetToyInfo(itemID)
            if toyName and toyName ~= "" then
                self.toyByName[strlower(toyName)] = itemID
            end
        end
    end
end

--- Build mount cache from collected mounts.
--- Sorted array of { name, spellID, iconID, mountID }.
function SC:BuildMountCache()
    wipe(self.mounts)
    local mountIDs = C_MountJournal.GetMountIDs()
    if not mountIDs then
        return
    end
    for _, mountID in ipairs(mountIDs) do
        local name, spellID, icon, _, _, _, _, _, _, _, isCollected = C_MountJournal.GetMountInfoByID(mountID)
        if isCollected and name then
            table.insert(self.mounts, {
                name = name,
                spellID = spellID,
                iconID = icon,
                mountID = mountID,
            })
        end
    end
    table.sort(self.mounts, function(a, b)
        return a.name:lower() < b.name:lower()
    end)
end

--- Build companion (battle pet) cache from collected pets.
--- Sorted array of { name, spellID, iconID, petID }, deduplicated by speciesID.
function SC:BuildCompanionCache()
    wipe(self.companions)
    -- Clear journal filters so we see all owned pets
    C_PetJournal.ClearSearchFilter()
    C_PetJournal.SetAllPetSourcesChecked(true)
    C_PetJournal.SetAllPetTypesChecked(true)

    local numPets = C_PetJournal.GetNumPets()
    if not numPets or numPets == 0 then
        return
    end
    local seenSpecies = {}
    for i = 1, numPets do
        local petID, speciesID, owned, _, _, _, _, speciesName, icon = C_PetJournal.GetPetInfoByIndex(i)
        if owned and speciesName and speciesID and not seenSpecies[speciesID] then
            seenSpecies[speciesID] = true
            table.insert(self.companions, {
                name = speciesName,
                spellID = speciesID,
                iconID = icon,
                petID = petID,
            })
        end
    end
    table.sort(self.companions, function(a, b)
        return a.name:lower() < b.name:lower()
    end)
end

---------------------------------------------------------------------------
-- Lazy Ensure Helpers (OPP-01)
--
-- Toy/mount/companion caches are expensive on first boot and most sessions
-- never open the picker UIs that read them. The Ensure helpers build each
-- cache on demand at the first picker read, then gate subsequent reads
-- with lazyDirty so a second picker open is a no-op until the player
-- acquires a new collectible.
--
-- OnEvent sets both collectionsDirty.X (for Scan bookkeeping) and
-- lazyDirty.X (for the next Ensure call). PEW schedules a deferred eager
-- build at 3s as a fallback so /gems perftest and collection browsers
-- that read the cache directly still see populated data without opening
-- the picker first.
---------------------------------------------------------------------------
function SC:EnsureMountCache()
    if SC.lazyDirty.mounts then
        SC:BuildMountCache()
        SC.lazyDirty.mounts = false
    end
end

function SC:EnsureCompanionCache()
    if SC.lazyDirty.companions then
        SC:BuildCompanionCache()
        SC.lazyDirty.companions = false
    end
end

function SC:EnsureToyCache()
    if SC.lazyDirty.toys then
        SC:BuildToyCache()
        SC.lazyDirty.toys = false
    end
end

--- Look up an item ID by name from the item cache.
--- @param itemName string The item name to look up
--- @return number|nil itemID The item ID, or nil if not found
function SC:GetItemID(itemName)
    if not itemName or itemName == "" then
        return nil
    end
    return self.itemByName[strlower(itemName)]
end

--- Look up a toy item ID by name from the toy cache.
--- @param toyName string The toy name to look up
--- @return number|nil itemID The toy's item ID, or nil if not found
function SC:GetToyID(toyName)
    if not toyName or toyName == "" then
        return nil
    end
    return self.toyByName[strlower(toyName)]
end

---------------------------------------------------------------------------
-- Macro Text Translation (locale-safe export/import)
---------------------------------------------------------------------------

-- Commands whose arguments need locale translation
local TRANSLATABLE_COMMANDS = {
    ["/cast"] = true,
    ["/use"] = true,
    ["/castsequence"] = true,
    ["/castrandom"] = true,
    ["/userandom"] = true,
    ["/cancelaura"] = true,
    ["/usetoy"] = true,
    ["/equip"] = true,
    ["/equipslot"] = true,
}

--- Consume all leading [conditional] blocks from a string.
--- Returns the conditionals prefix and the remaining text.
--- @param text string Text that may start with [cond] blocks
--- @return string condPrefix All consumed [cond] blocks with trailing space
--- @return string rest Remaining text after conditionals
local function ConsumeConditionals(text)
    local condParts = {}
    local pos = 1
    local len = #text

    while pos <= len do
        -- Skip whitespace
        while pos <= len and text:sub(pos, pos) == " " do
            pos = pos + 1
        end
        -- Check for opening bracket
        if pos <= len and text:sub(pos, pos) == "[" then
            -- Find the balanced close bracket
            local close = text:find("%]", pos + 1)
            if close then
                condParts[#condParts + 1] = text:sub(pos, close)
                pos = close + 1
            else
                break -- unbalanced bracket, stop
            end
        else
            break
        end
    end

    if #condParts == 0 then
        return "", text
    end

    local condPrefix = table.concat(condParts, " ")
    local rest = text:sub(pos)
    -- Preserve any space between last conditional and spell list
    condPrefix = condPrefix .. " "
    if rest:sub(1, 1) == " " then
        rest = rest:sub(2)
    end

    return condPrefix, rest
end

--- Translate a single spell reference between name and ID tag.
--- @param ref string A spell name or {spell:ID} tag
--- @param direction string "toIDs" or "toNames"
--- @return string translated The translated reference
local function TranslateSpellRef(ref, direction, opts)
    -- Trim whitespace
    local trimmed = ref:match("^%s*(.-)%s*$")
    if not trimmed or trimmed == "" then
        return ref
    end

    if direction == "toIDs" then
        -- Already a {spell:N} tag with a valid ID? keep as-is.
        -- v2.1.5 polish: garbage IDs typed by users (e.g. {spell:3238019941})
        -- previously passed through unchanged here. Validate before persisting
        -- so taggedSteps never holds out-of-bounds IDs.
        local existingTaggedID = trimmed:match("^{spell:(%d+)}$")
        if existingTaggedID then
            local numericID = tonumber(existingTaggedID)
            if SC:IsValidSpellID(numericID) then
                return ref
            end
            -- Out-of-range tag: log to DebugWindow and fall through to the
            -- name-lookup path. If the name path also fails the ref is
            -- returned unchanged at the end of the function (line ~979).
            if GRIPEMS and GRIPEMS.Debug then
                GRIPEMS:Debug(
                    string.format(
                        "TranslateSpellRef: dropping out-of-range tagged spell ID '%s' (must be in (0, 2147483647])",
                        tostring(existingTaggedID)
                    )
                )
            end
            -- Fall through (do not return) so the rest of the function
            -- tries name/item/toy lookups against the raw ref.
        end
        -- Already numeric? keep as-is
        if tonumber(trimmed) then
            return ref
        end
        -- Check for ! prefix (e.g. !Steady Shot)
        local bangPrefix = ""
        local lookupName = trimmed
        if trimmed:sub(1, 1) == "!" then
            bangPrefix = "!"
            lookupName = trimmed:sub(2)
        end
        -- Check for (Rank N) suffix
        local rankSuffix = ""
        local baseName = lookupName
        local nameNoRank, rank = lookupName:match("^(.-)(%s*%(Rank%s+%d+%))$")
        if nameNoRank then
            baseName = nameNoRank
            rankSuffix = rank
        end
        -- Look up spell ID (Q2 Phase 4: opts.classID = author class for collision resolution)
        local spellID = SC:GetSpellID(baseName, opts and opts.classID)
        if spellID and SC:IsResolvableSpellID(spellID) then
            -- NOTE: Do NOT normalize to base spell ID here. FindBaseSpellByID
            -- walks the full replacement chain (e.g. Barbed Shot -> Steady Shot)
            -- which loses the actual spell identity. WoW /cast handles talent
            -- overrides natively, so the spell's own ID is correct for export.
            -- Preserve leading whitespace from original ref
            local leading = ref:match("^(%s*)")
            return leading .. bangPrefix .. "{spell:" .. spellID .. "}" .. rankSuffix
        end
        -- Try item lookup (Phase 2d)
        local itemID = SC:GetItemID(baseName)
        if itemID then
            local leading = ref:match("^(%s*)")
            return leading .. bangPrefix .. "{item:" .. itemID .. "}"
        end
        -- Try toy lookup (Phase 2d)
        local toyID = SC:GetToyID(baseName)
        if toyID then
            local leading = ref:match("^(%s*)")
            return leading .. bangPrefix .. "{toy:" .. toyID .. "}"
        end
        -- Lookup failed (unknown name) -- keep original
        return ref
    elseif direction == "toNames" then
        local leading = ref:match("^(%s*)") or ""
        local hasBang = false
        local inner = trimmed

        -- Strip ! prefix if present
        if inner:sub(1, 1) == "!" then
            hasBang = true
            inner = inner:sub(2)
        end

        -- Try {spell:ID}
        local spellId = inner:match("^{spell:(%d+)}$")
        if spellId then
            local resolvedId = tonumber(spellId)
            -- L500 Strategy A Phase 2: when opts.useOverrides is set, apply the
            -- current talent state's spell override before resolving the name.
            -- C_SpellBook.FindSpellOverrideByID returns the active variant ID
            -- (e.g. base 56641 Steady Shot -> 217200 Barbed Shot with BM
            -- override talented), or returns the input ID unchanged when no
            -- override is active. Mirrors the SafeOverrideID pattern at L91-99.
            if opts and opts.useOverrides and C_SpellBook and C_SpellBook.FindSpellOverrideByID then
                -- v2.1.5 hardening: bounds-guard both C_SpellBook calls below. The API
                -- rejects spell IDs outside the signed-32-bit range with a throw, not a
                -- nil return. User-typed {spell:N} tokens are not bounded. Matches
                -- SafeOverrideID at L92-100. BugSack repro: {spell:3238019941}.
                if SC:IsValidSpellID(resolvedId) then
                    -- L500 Strategy A Phase 5a: handle the import-with-override-active
                    -- direction (Pershizzle's reverse case). If the stored ID is itself
                    -- a variant (e.g. 217200 Barbed Shot, stored because the player
                    -- imported while BM was already talented), walk the replacement
                    -- chain back to the source base FIRST.
                    -- Then FindSpellOverrideByID re-applies whatever override is
                    -- active in the CURRENT talent state -- which may be the same
                    -- variant (heal is a no-op via the equality check above),
                    -- a different variant (re-translate), or no override (heal
                    -- back to base name). Closes Backlog L502.
                    --
                    -- DELEGATED in v2.4.4 Phase 4b. This used to call
                    -- C_SpellBook.FindBaseSpellByID inline, which is why the DISPLAY
                    -- walk could not see D.BASE_SPELL_TABLE: the API answers Ravage
                    -- 441583 with its OWN id, so the inline call normalised nothing and
                    -- the table that carries the 441583 -> 6807 link was never
                    -- consulted. A Guardian Druid who untalented Ravage kept reading
                    -- Ravage over a persisted Maul on every heal. Going through
                    -- SC:GetBaseSpellID means this walk shares the one function that
                    -- owns the table, the identity-is-a-miss rule and the guards.
                    -- An absent FindBaseSpellByID still degrades to no normalisation,
                    -- because the delegate returns its input unchanged on any miss --
                    -- which is also why the equality test below still reads as "a real
                    -- base link was found".
                    --
                    -- The IsValidSpellID(resolvedId) guard above STAYS. It gates the
                    -- FindSpellOverrideByID call further down as well, and that call is
                    -- not delegated, so dropping it would unguard a second API.
                    local baseId = SC:GetBaseSpellID(resolvedId)
                    if baseId and baseId ~= resolvedId then
                        if GRIPEMS and GRIPEMS.Debug then
                            GRIPEMS:Debug("SC:TranslateSpellRef base " .. resolvedId .. " -> " .. baseId)
                        end
                        resolvedId = baseId
                    end
                    local override = C_SpellBook.FindSpellOverrideByID(resolvedId)
                    if override and override ~= resolvedId then
                        if GRIPEMS and GRIPEMS.Debug then
                            GRIPEMS:Debug("SC:TranslateSpellRef override " .. resolvedId .. " -> " .. override)
                        end
                        resolvedId = override
                    end
                end
            end
            local sname = SC:RecoverSpellName(resolvedId)
            if sname then
                return leading .. (hasBang and "!" or "") .. sname
            end
            return ref
        end

        -- Try {item:ID} (Phase 2d)
        local itemId = inner:match("^{item:(%d+)}$")
        if itemId then
            local iname = C_Item.GetItemInfo(tonumber(itemId))
            if iname then
                return leading .. (hasBang and "!" or "") .. iname
            end
            return ref
        end

        -- Try {toy:ID} (Phase 2d)
        local toyId = inner:match("^{toy:(%d+)}$")
        if toyId then
            local _, tname = C_ToyBox.GetToyInfo(tonumber(toyId))
            if tname then
                return leading .. (hasBang and "!" or "") .. tname
            end
            return ref
        end

        -- Not a recognized tag, pass through
        return ref
    end

    return ref
end

--- Translate macrotext between localized names and spell ID tags.
--- Used at export/import boundaries for locale-safe sharing.
--- @param macrotext string The macro text to translate
--- @param direction string "toIDs" (export) or "toNames" (import)
--- @param opts table|nil Optional flags. Currently supports
---   opts.useOverrides (boolean) -- when true and direction is
---   "toNames", apply C_SpellBook.FindSpellOverrideByID to each
---   spell ID before name lookup. The single caller is
---   Engine:HealOverrideSteps, which as of v2.4.4 uses the result for
---   DISPLAY only -- it is never written back to SavedVariables,
---   because the override API cannot separate a durable talent
---   override from a transient form / channel / proc one and a
---   transient name stored in a step is a macro that does nothing.
---   Engine:RepairPersistedOverrideNames deliberately omits opts for
---   the same reason: with no override logic the tag resolves to the
---   durable base name, which is what persisted text must carry.
---   Nil or absent opts preserves prior behavior exactly -- this is a
---   strict extension.
--- @return string translated The translated macrotext
function SC:TranslateMacrotext(macrotext, direction, opts)
    macrotext = self:StepToString(macrotext)
    if macrotext == "" then
        return ""
    end

    local lines = {}
    for line in (macrotext .. "\n"):gmatch("([^\n]*)\n") do
        lines[#lines + 1] = line
    end

    for i, line in ipairs(lines) do
        -- Match command: leading whitespace + /command + space + rest
        local prefix, cmd, sep, rest = line:match("^(%s*)(/%a+)(%s+)(.*)")
        if cmd and TRANSLATABLE_COMMANDS[cmd:lower()] then
            -- Consume [conditional] blocks from rest
            local condPrefix, spellPart = ConsumeConditionals(rest)

            -- For /castsequence: consume reset=... clause
            local resetClause = ""
            if cmd:lower() == "/castsequence" then
                local reset, afterReset = spellPart:match("^(reset=%S+%s*)(.*)")
                if reset then
                    resetClause = reset
                    spellPart = afterReset
                end
            end

            -- For /equipslot: consume leading slot number (Phase 2d)
            local slotPrefix = ""
            if cmd:lower() == "/equipslot" then
                local slot, remainder = spellPart:match("^(%d+%s+)(.*)")
                if slot then
                    slotPrefix = slot
                    spellPart = remainder
                end
            end

            -- Determine delimiter: /castsequence uses comma, others use semicolon
            local delimiter
            if cmd:lower() == "/castsequence" then
                delimiter = ","
            else
                delimiter = ";"
            end

            -- Split spell references by delimiter
            local refs = {}
            local pos = 1
            local spLen = #spellPart
            while pos <= spLen do
                local delimPos = spellPart:find(delimiter, pos, true)
                if delimPos then
                    refs[#refs + 1] = spellPart:sub(pos, delimPos - 1)
                    pos = delimPos + 1
                else
                    refs[#refs + 1] = spellPart:sub(pos)
                    pos = spLen + 1
                end
            end

            -- For non-castsequence commands, each semicolon-delimited ref
            -- may itself contain comma-separated spells (e.g. /castrandom A, B; C)
            -- But actually /cast and friends use semicolons for fallback casts only.
            -- /castsequence uses commas. Keep it simple: one delimiter per command type.

            -- Translate each ref
            for j, ref in ipairs(refs) do
                -- For /castsequence: each comma-delimited entry is one spell
                -- For others: each semicolon-delimited entry may have conditionals
                if cmd:lower() ~= "/castsequence" and ref:find("%[") then
                    -- This ref has its own conditionals (fallback with conditions)
                    -- Preserve leading whitespace (e.g. space after ; delimiter)
                    local leading = ref:match("^(%s*)") or ""
                    local innerCond, innerSpell = ConsumeConditionals(ref)
                    innerSpell = TranslateSpellRef(innerSpell, direction, opts)
                    refs[j] = leading .. innerCond .. innerSpell
                else
                    refs[j] = TranslateSpellRef(ref, direction, opts)
                end
            end

            -- Reassemble
            lines[i] = prefix .. cmd .. sep .. condPrefix .. resetClause .. slotPrefix .. table.concat(refs, delimiter)
        end
        -- Non-translatable lines pass through unchanged
    end

    return table.concat(lines, "\n")
end

---------------------------------------------------------------------------
-- Macro Command Autocomplete
---------------------------------------------------------------------------

-- WoW macro commands for autocomplete (source: warcraft.wiki.gg/Macro_commands)
-- Includes all combat, targeting, pet, character, chat, system, and
-- metacommands that users might write in macro sequences.
SC.macroCommands = {
    -- Metacommands (# prefix)
    "#show",
    "#showtooltip",
    -- Battle pets
    "/dismisspet",
    "/randomfavoritepet",
    "/randompet",
    "/summonpet",
    -- Character / movement
    "/dismount",
    "/equip",
    "/equipset",
    "/equipslot",
    "/follow",
    "/leavevehicle",
    -- Chat (commonly used in macros)
    "/emote",
    "/guild",
    "/officer",
    "/party",
    "/raid",
    "/reply",
    "/rw",
    "/say",
    "/tell",
    "/whisper",
    "/yell",
    -- Combat
    "/cancelaura",
    "/cancelform",
    "/cancelqueuedspell",
    "/cast",
    "/castrandom",
    "/castsequence",
    "/changeactionbar",
    "/click",
    "/startattack",
    "/stopattack",
    "/stopcasting",
    "/stopmacro",
    "/stopspelltarget",
    "/swapactionbar",
    "/use",
    "/userandom",
    "/usetoy",
    -- Pet
    "/petassist",
    "/petattack",
    "/petautocastoff",
    "/petautocaston",
    "/petautocasttoggle",
    "/petdefensive",
    "/petdismiss",
    "/petfollow",
    "/petmoveto",
    "/petpassive",
    "/petstay",
    -- PvP
    "/duel",
    "/forfeit",
    "/pvp",
    -- Raid / party
    "/clearworldmarker",
    "/invite",
    "/readycheck",
    "/targetmarker",
    "/worldmarker",
    -- System
    "/dump",
    "/logout",
    "/played",
    "/random",
    "/reload",
    "/run",
    "/script",
    -- Targeting
    "/assist",
    "/clearfocus",
    "/cleartarget",
    "/focus",
    "/target",
    "/targetenemy",
    "/targetenemyplayer",
    "/targetexact",
    "/targetfriend",
    "/targetfriendplayer",
    "/targetlastenemy",
    "/targetlastfriend",
    "/targetlasttarget",
    "/targetparty",
    "/targetraid",
}

--- Search macro commands by prefix.
--- Handles both "/" and "#" prefixed commands.
--- @param prefix string The prefix to match (must start with "/" or "#")
--- @param maxResults number|nil Maximum results (default from Defaults)
--- @return table Array of { name } entries matching the prefix
function SC:MacroCommandSearch(prefix, maxResults)
    if not prefix then
        return {}
    end
    local firstChar = prefix:sub(1, 1)
    if firstChar ~= "/" and firstChar ~= "#" then
        return {}
    end
    prefix = strlower(prefix)
    maxResults = maxResults or D().AUTOCOMPLETE_MAX_RESULTS

    local results = {}
    for _, cmd in ipairs(self.macroCommands) do
        if strlower(cmd):sub(1, #prefix) == prefix then
            table.insert(results, { name = cmd })
            if #results >= maxResults then
                break
            end
        end
    end
    return results
end

---------------------------------------------------------------------------
-- Macro Text Spell Extraction
---------------------------------------------------------------------------

--- Coerce a step value to a macro-text string.
--- Steps may be stored as plain strings (user authored), as
--- compiled attribute tables { macrotext = "..." } (priority
--- compile pipeline), or as arrays of macro lines { "/cast X" }
--- (legacy/imported payloads). Unrecognised shapes return "".
--- @param step any The step value to coerce
--- @return string The macrotext string (may be empty)
function SC:StepToString(step)
    if type(step) == "string" then
        return step
    end
    if type(step) == "table" then
        if type(step.macrotext) == "string" then
            return step.macrotext
        end
        local parts = {}
        for i = 1, #step do
            if type(step[i]) == "string" then
                parts[#parts + 1] = step[i]
            end
        end
        return table.concat(parts, "\n")
    end
    return ""
end

--- Extract the most relevant castable spell name from macro text.
--- Input may be a plain string, a compiled attribute table of the
--- form { macrotext = "..." }, or an array of macro lines such
--- as { "/cast X", "/cast Y" }. The input is coerced via
--- SC:StepToString; an empty result returns nil.
--- Prefers rotation spells ([combat] or unconditional) over housekeeping
--- (conditional utility lines). Returns the last preferred match, or the
--- first conditional match as fallback.
--- Handles /cast, /use, /castrandom, /castsequence with conditionals,
--- reset= clauses, rank syntax, and multi-line text.
--- @param macrotext string|table The macro text to parse (see SC:StepToString)
--- @return string|nil spellName The most relevant spell name found, or nil
function SC:ParseSpellFromMacrotext(macrotext)
    macrotext = self:StepToString(macrotext)
    if macrotext == "" then
        return nil
    end

    -- Commands that don't cast spells -- skip these lines
    local skipPrefixes = D().SKIP_SPELL_PREFIXES

    local preferred = nil
    local fallback = nil

    for line in macrotext:gmatch("[^\r\n]+") do
        -- Check if this line should be skipped
        local skip = false
        local lineLower = line:lower()
        for _, pat in ipairs(skipPrefixes) do
            if lineLower:match(pat) then
                skip = true
                break
            end
        end

        if not skip then
            -- Match /cast, /use, /castrandom, /castsequence (case-insensitive)
            local cmdMatch = line:match("^%s*/[Cc][Aa][Ss][Tt]%s")
                or line:match("^%s*/[Uu][Ss][Ee]%s")
                or line:match("^%s*/[Cc][Aa][Ss][Tt][Rr][Aa][Nn][Dd][Oo][Mm]%s")
                or line:match("^%s*/[Cc][Aa][Ss][Tt][Ss][Ee][Qq][Uu][Ee][Nn][Cc][Ee]%s")

            if cmdMatch then
                -- Classify: check for conditionals and [combat] token
                local hasConditionals = line:match("%[.-%]") ~= nil
                local hasCombat = false
                if hasConditionals then
                    for condBlock in lineLower:gmatch("%[(.-)%]") do
                        for token in condBlock:gmatch("[^,]+") do
                            token = token:match("^%s*(.-)%s*$")
                            if token == "combat" then
                                hasCombat = true
                                break
                            end
                        end
                        if hasCombat then
                            break
                        end
                    end
                end

                -- Strip the command prefix
                local rest = line:match("^%s*/[%a]+%s+(.*)")
                if rest then
                    -- Strip [conditionals] blocks
                    rest = rest:gsub("%[.-%]", "")
                    -- Strip reset=... clause (for /castsequence)
                    rest = rest:gsub("reset=%S+%s*", "")
                    -- Trim leading/trailing whitespace
                    rest = rest:match("^%s*(.-)%s*$")

                    if rest and rest ~= "" then
                        -- /castsequence and /castrandom use commas to separate multiple
                        -- spells; for those take the first. For /cast and /use the comma is
                        -- part of the spell name (e.g. "Invoke Niuzao, the Black Ox").
                        local isMultiSpell = lineLower:match("^%s*/castsequence%s")
                            or lineLower:match("^%s*/castrandom%s")
                        local spell
                        if isMultiSpell then
                            spell = rest:match("^([^,;]+)")
                        else
                            spell = rest:match("^([^;]+)")
                        end
                        if spell then
                            spell = spell:match("^%s*(.-)%s*$")
                            -- Strip "(Rank N)" suffix
                            spell = spell:gsub("%s*%(Rank%s+%d+%)%s*$", "")
                            -- Strip trailing semicolons
                            spell = spell:gsub(";+%s*$", "")
                            spell = spell:match("^%s*(.-)%s*$")
                            if spell and spell ~= "" then
                                -- Skip /use inventory slots (pure numeric)
                                local isUseCmd = lineLower:match("^%s*/use%s")
                                local isSlot = isUseCmd and tonumber(spell)
                                if not isSlot then
                                    if not hasConditionals or hasCombat then
                                        preferred = spell -- last preferred wins
                                    elseif not fallback then
                                        fallback = spell -- first fallback preserved
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end

    return preferred or fallback
end

---------------------------------------------------------------------------
-- Spell ID -> Name Resolution (display-only)
---------------------------------------------------------------------------

--- Resolve numeric spell IDs in /cast, /castsequence, /castrandom lines to
--- their localized spell names. Preserves leading whitespace, command case,
--- conditional brackets, reset= clause, and comma/semicolon delimiters.
--- Returns original text on any failure. DISPLAY ONLY -- callers must not
--- mutate the stored macro.
---
--- /use lines are deliberately excluded from numeric resolution: a bare
--- number after /use is an inventory slot (e.g. /use 13 = top trinket),
--- never a spell ID, so /use lines are emitted verbatim and never
--- name-resolved. This is the display-side twin of the import-side guard.
--- @param text string Macro text that may contain /cast NNN-style numeric IDs
--- @return string Text with numeric IDs replaced by names; unresolvable tokens preserved
function SC:ResolveSpellIDsInText(text)
    text = self:StepToString(text)
    if text == "" then
        return ""
    end
    local cached = SC._resolveCache[text]
    if cached ~= nil then
        return cached
    end
    if not C_Spell or not C_Spell.GetSpellName then
        return text
    end

    -- Try to resolve a single token (possibly with whitespace + "!" prefix).
    -- Returns the token unchanged if not purely numeric or if API returns nil.
    local function resolveToken(token)
        if not token or token == "" then
            return token
        end
        local leading = token:match("^(%s*)") or ""
        local trailing = token:match("(%s*)$") or ""
        local core = token:sub(#leading + 1, #token - #trailing)
        if core == "" then
            return token
        end
        local bang = ""
        if core:sub(1, 1) == "!" then
            bang = "!"
            core = core:sub(2)
        end
        if not core:match("^%d+$") then
            return token
        end
        local n = tonumber(core)
        if not n then
            return token
        end
        local name = C_Spell.GetSpellName(n)
        if not name or name == "" then
            return token
        end
        return leading .. bang .. name .. trailing
    end

    local lines = {}
    for line in (text .. "\n"):gmatch("([^\n]*)\n") do
        lines[#lines + 1] = line
    end

    for li, line in ipairs(lines) do
        local prefix, cmd, sep, rest = line:match("^(%s*)(/%a+)(%s+)(.*)$")
        if cmd and rest then
            local cmdLower = cmd:lower()
            local isCast = cmdLower == "/cast"
            local isSeq = cmdLower == "/castsequence"
            local isRnd = cmdLower == "/castrandom"

            if isCast or isSeq or isRnd then
                local condPrefix, spellPart = ConsumeConditionals(rest)

                local resetClause = ""
                if isSeq then
                    local r, afterReset = spellPart:match("^(reset=%S+%s*)(.*)$")
                    if r then
                        resetClause = r
                        spellPart = afterReset
                    end
                end

                local delimiter = (isSeq or isRnd) and "," or ";"

                local tokens = {}
                local pos = 1
                local slen = #spellPart
                while pos <= slen do
                    local dp = spellPart:find(delimiter, pos, true)
                    if dp then
                        tokens[#tokens + 1] = spellPart:sub(pos, dp - 1)
                        tokens[#tokens + 1] = delimiter
                        pos = dp + 1
                    else
                        tokens[#tokens + 1] = spellPart:sub(pos)
                        pos = slen + 1
                    end
                end
                if #tokens == 0 and spellPart ~= "" then
                    tokens[1] = spellPart
                end

                for ti, tok in ipairs(tokens) do
                    if tok ~= delimiter then
                        if isCast and tok:find("%[") then
                            local innerCond, innerSpell = ConsumeConditionals(tok)
                            tokens[ti] = innerCond .. resolveToken(innerSpell)
                        else
                            tokens[ti] = resolveToken(tok)
                        end
                    end
                end

                lines[li] = prefix .. cmd .. sep .. condPrefix .. resetClause .. table.concat(tokens)
            end
        end
    end

    local result = table.concat(lines, "\n")
    if SC._resolveCacheCount >= 512 then
        wipe(SC._resolveCache)
        SC._resolveCacheCount = 0
    end
    SC._resolveCache[text] = result
    SC._resolveCacheCount = SC._resolveCacheCount + 1
    return result
end

---------------------------------------------------------------------------
-- Event-Driven Refresh with Debounce
---------------------------------------------------------------------------

--- Schedule a debounced cache rescan. Cancels any pending timer.
--- @param kind string|nil "talent" for talent / spec / loadout events
--- (uses longer SPELL_CACHE_TALENT_DEBOUNCE so the override API
--- has time to settle); any other value uses the standard delay.
--- Combat lockdown overrides both and uses SPELL_CACHE_COMBAT_DEBOUNCE.
local function ScheduleRescan(kind)
    if debounceTimer then
        debounceTimer:Cancel()
        debounceTimer = nil
    end
    local delay
    if InCombatLockdown() then
        delay = D().SPELL_CACHE_COMBAT_DEBOUNCE
    elseif kind == "talent" then
        delay = D().SPELL_CACHE_TALENT_DEBOUNCE
    else
        delay = D().SPELL_CACHE_DEBOUNCE
    end
    if C_Timer and C_Timer.NewTimer then
        debounceTimer = C_Timer.NewTimer(delay, function()
            debounceTimer = nil
            SC:Scan()
        end)
    end
end

---------------------------------------------------------------------------
-- One-Time Migration: generate taggedSteps for existing sequences (Phase 2a)
---------------------------------------------------------------------------

--- Generate taggedSteps for all sequences that lack them.
--- Called once after SpellCache first reports ready, if pendingTagMigration is set.
--- After completion, clears the flag so it never runs again.
local function RunPendingTagMigration()
    if not SC.ready then
        return
    end
    if not _G.GRIP_EMS_DB or not GRIP_EMS_DB.pendingTagMigration then
        return
    end
    if not _G.GRIP_EMS_CHAR or not GRIP_EMS_CHAR.sequences then
        return
    end

    local count = 0
    for name, seqData in pairs(GRIP_EMS_CHAR.sequences) do
        if type(seqData) == "table" then
            for _, version in ipairs(type(seqData.versions) == "table" and seqData.versions or {}) do
                if not version.taggedSteps then
                    SC:NormalizeVersionLocale(version, seqData.classID)
                    count = count + 1
                end
            end
        end
    end

    GRIP_EMS_DB.pendingTagMigration = nil
    GRIP_EMS_DB.taggedStepsMigrated = true
    if count > 0 then
        local GE = GRIPEMS
        GE:Print(string.format("Locale protection added to %d sequence versions.", count))
    end
end

--- One-time locale re-normalize (parachute). Sequences imported before the
--- catalog name->ID fallback existed may hold English step text stamped with the
--- current locale, so HealLocaleSteps' locale-mismatch guard never fires. This
--- pass force-normalizes every version once so those sequences localize without
--- the user running /gems revalidate. Gated by a per-character flag so every
--- character's sequences get the pass (sequences live in per-character
--- SavedVariables).
local function RunLocaleRenormalizeMigration()
    if not SC.ready then
        return
    end
    if not _G.GRIP_EMS_CHAR or GRIP_EMS_CHAR.localeRenormalizeV1 then
        return
    end
    if not _G.GRIP_EMS_CHAR or not GRIP_EMS_CHAR.sequences then
        return
    end
    local count = 0
    for _, seqData in pairs(GRIP_EMS_CHAR.sequences) do
        if type(seqData) == "table" then
            for _, version in ipairs(type(seqData.versions) == "table" and seqData.versions or {}) do
                SC:NormalizeVersionLocale(version, seqData.classID)
                count = count + 1
            end
        end
    end
    GRIP_EMS_CHAR.localeRenormalizeV1 = true
    if count > 0 then
        GRIPEMS:Debug("Locale re-normalize: processed %d sequence version(s)", count)
    end
end

-- One-time stored-data handle-token recovery. Gated per-character (sequences
-- live in per-character SavedVariables) so every character's storage is healed.
-- Replaces the reverted Phase 3 delete-repair: recovers names, does not delete.
local function RunHandleTokenRecovery()
    if not SC.ready then
        return
    end
    if not _G.GRIP_EMS_CHAR or not GRIP_EMS_CHAR.sequences then
        return
    end
    -- V2 re-key: the V1 pass ran only on the dev character before release and
    -- missed the tagged fields, so re-run once under a fresh key and clear the
    -- orphan V1 key.
    if GRIP_EMS_CHAR.handleTokenRecoveryV2 then
        return
    end
    local recovered, dropped = SC:RecoverStoredHandleTokens(GRIP_EMS_CHAR.sequences)
    GRIP_EMS_CHAR.handleTokenRecoveryV2 = true
    GRIP_EMS_CHAR.handleTokenRecoveryV1 = nil
    if recovered > 0 or dropped > 0 then
        GRIPEMS:Debug("Handle-token recovery: recovered %d token(s), dropped %d dead line(s)", recovered, dropped)
    end
end

-- One-time heal for sequences imported before the bare-name macro inline fix: a
-- referenced /macro stored only by name typed the name into chat at fire time.
-- The macro was recreated on the original import, so resolve the body from the
-- stored / live macro and inline it across the flat steps, keyPress / keyRelease,
-- and the action tree; then NormalizeVersionLocale regenerates the tagged mirrors.
-- Per-character (sequences live in per-character SavedVariables); idempotent (a
-- healed body is no longer a bare name, and the per-character flag stops re-walks).
local function RunBareNameMacroHeal()
    if not SC.ready then
        return
    end
    if not _G.GRIP_EMS_CHAR or GRIP_EMS_CHAR.bareNameMacroHealV1 then
        return
    end
    local LI = GRIPEMS.LegacyImport
    if not LI or not LI._HealBareMacroField then
        return -- import module not ready yet; retry on the next cache refresh
    end
    if not GRIP_EMS_CHAR.sequences then
        GRIP_EMS_CHAR.bareNameMacroHealV1 = true
        return
    end
    local healed = 0
    for _, seqData in pairs(GRIP_EMS_CHAR.sequences) do
        if type(seqData) == "table" then
            for _, version in ipairs(type(seqData.versions) == "table" and seqData.versions or {}) do
                local changed = false
                if type(version.steps) == "table" then
                    for i, step in ipairs(version.steps) do
                        local new, did = LI._HealBareMacroField(step)
                        if did then
                            version.steps[i] = new
                            changed = true
                        end
                    end
                end
                local kp, kpDid = LI._HealBareMacroField(version.keyPress or "")
                if kpDid then
                    version.keyPress = kp
                    changed = true
                end
                local kr, krDid = LI._HealBareMacroField(version.keyRelease or "")
                if krDid then
                    version.keyRelease = kr
                    changed = true
                end
                if type(version.actions) == "table" then
                    SC:_WalkActions(version.actions, function(node)
                        if LI._HealBareMacroNode(node) then
                            changed = true
                        end
                    end)
                end
                if changed then
                    SC:NormalizeVersionLocale(version, seqData.classID)
                    healed = healed + 1
                end
            end
        end
    end
    GRIP_EMS_CHAR.bareNameMacroHealV1 = true
    if healed > 0 then
        GRIPEMS:Debug("Bare-name macro heal: repaired %d sequence version(s)", healed)
    end
end

-- One-time repair for step text poisoned by the pre-v2.4.4 override writer.
-- Engine:HealOverrideSteps used to write the live override name into
-- version.steps / keyPress / keyRelease, and those are SavedVariables: a heal
-- taken while a form, channel or proc override was up left a name the player
-- cannot cast. The writer is gone as of v2.4.4, but the poisoned text it
-- already stored is still there, so this re-derives the persisted text from
-- the tags with no override logic. Per-character and gated inside the Engine
-- function on GRIP_EMS_CHAR.overrideNameRepairV1, matching the two passes
-- above. The Engine may not have loaded yet on the first refresh, in which
-- case this retries on the next one rather than burning the gate.
local function RunOverrideNameRepair()
    if not SC.ready then
        return
    end
    local E = GRIPEMS.Engine
    if not E or type(E.RepairPersistedOverrideNames) ~= "function" then
        return
    end
    E:RepairPersistedOverrideNames()
end

-- Migration registration. MUST run after GRIPEMS.RegisterCallback exists
-- (created in Core.lua's ADDON_LOADED handler). The old file-load block
-- silently no-op'd because RegisterCallback was nil at file scope.
function SC:RegisterMigrations()
    if not GRIPEMS.RegisterCallback or SC._migrationsRegistered then
        return
    end
    SC._migrationsRegistered = true
    -- CallbackHandler-1.0 keys callbacks by (event, registrant): one slot
    -- per registrant per event, silently replaced on re-register (see
    -- Libs/CallbackHandler-1.0, the events[eventname][self] assignment).
    -- Three GRIPEMS-owner registrations would self-clobber down to the
    -- last one, and Transmission:Initialize later registers this same
    -- event under the GRIPEMS owner too (spell-cache broadcast),
    -- replacing whatever remained. One wrapper under the distinct SC
    -- owner keeps its own slot, runs all three in order, and leaves the
    -- broadcast untouched. Proven headless:
    -- GRIP/Hub/Tools/lua_headless/test_callbackhandler_owner_clobber.lua
    GRIPEMS.RegisterCallback(SC, "SPELL_CACHE_REFRESHED", function()
        RunPendingTagMigration()
        RunLocaleRenormalizeMigration()
        RunHandleTokenRecovery()
        RunBareNameMacroHeal()
        RunOverrideNameRepair()
    end)
    -- If the cache already settled before registration, run the pending passes
    -- once now so they do not wait for the next scan.
    if SC.ready then
        RunPendingTagMigration()
        RunLocaleRenormalizeMigration()
        RunHandleTokenRecovery()
        RunBareNameMacroHeal()
        RunOverrideNameRepair()
    end
end

---------------------------------------------------------------------------
-- Post-Scan Validation (Layers B + C) -- hero-talent override timing race
---------------------------------------------------------------------------

--- Walk Engine.sequences and collect every spell name referenced
--- via /cast / /castrandom / /castsequence / /use. Names that do
--- not resolve against SC.byName are returned in a map.
--- @return table { [spellName] = sequenceName } unresolved refs
local function CollectUnresolvedSpellRefs()
    local unresolved = {}
    local engine = GRIPEMS.Engine
    if not engine or not engine.sequences then
        return unresolved
    end
    for seqName, entry in pairs(engine.sequences) do
        -- Fix 1: skip dormant sequences. Dormant means
        -- entry.button is nil (sequence is registered but
        -- not active, typically because it belongs to a
        -- different class than the current character). Dormant
        -- sequences cannot fire from the keybind path so their
        -- unresolved refs do not affect runtime; flagging them
        -- produces false-positive chat warnings at every login
        -- for any user with multi-class saved sequences.
        -- type(), not truthiness: ipairs() below rejects a non-table outright
        -- ("bad argument #1 to 'ipairs' (table expected, got number)"), so a
        -- scalar .versions from a corrupt import raises here.
        if entry and entry.button and entry.data and type(entry.data.versions) == "table" then
            for _, ver in ipairs(entry.data.versions) do
                for _, step in ipairs(ver.steps or {}) do
                    local spellName = SC:ParseSpellFromMacrotext(step)
                    if type(spellName) == "string" and spellName ~= "" then
                        if not SC.byName[strlower(spellName)] then
                            unresolved[spellName] = seqName
                        end
                    end
                end
            end
        end
    end
    return unresolved
end

--- Run after SC:Scan completes. Checks every sequence step's
--- spell ref against SC.byName. If any unresolved, schedule a
--- single retry Scan with extended delay (gives the override API
--- more time to converge). After the retry, fire
--- SC:_NotifySpellResolveFailure if refs are still missing.
function SC:_ValidateAndMaybeRetry()
    if SC._validationRetryScheduled or SC._inValidationRetry then
        return
    end
    local unresolved = CollectUnresolvedSpellRefs()
    if not next(unresolved) then
        SC._unresolvedAfterScan = nil
        return
    end
    SC._unresolvedAfterScan = unresolved
    local count = 0
    local names = {}
    for refName in pairs(unresolved) do
        count = count + 1
        names[count] = refName
    end
    table.sort(names)
    local shown = math.min(3, count)
    local nameList = table.concat(names, ", ", 1, shown)
    if count > shown then
        nameList = nameList .. (" +%d more"):format(count - shown)
    end
    -- Session cap: one unresolvable active ref previously re-armed a
    -- full rescan on EVERY Scan call (observed: 4 full rescans in 17s
    -- at login). Past the cap, log and stop re-arming for the session.
    SC._validationRetryCount = (SC._validationRetryCount or 0) + 1
    if SC._validationRetryCount > (D().SPELL_CACHE_VALIDATION_MAX_RETRIES or 2) then
        GRIPEMS:Debug(
            ("SpellCache: %d unresolved spell ref(s) [%s]; retry cap reached, not re-arming"):format(count, nameList)
        )
        return
    end
    SC._validationRetryScheduled = true
    GRIPEMS:Debug(("SpellCache: %d unresolved spell ref(s) [%s]; scheduling retry"):format(count, nameList))
    if C_Timer and C_Timer.After then
        C_Timer.After(D().SPELL_CACHE_VALIDATION_RETRY_DELAY, function()
            SC._validationRetryScheduled = false
            SC.collectionsDirty.spells = true
            SC._inValidationRetry = true
            SC:Scan()
            SC._inValidationRetry = false
            local stillMissing = CollectUnresolvedSpellRefs()
            if next(stillMissing) then
                SC:_NotifySpellResolveFailure(stillMissing)
            end
            SC._unresolvedAfterScan = nil
        end)
    end
end

--- Notify the user that spell-cache scan did not resolve some
--- referenced spell names after the validation retry. Strategy C
--- user diagnostic for hero-talent override timing races.
--- @param unresolvedMap table { [spellName] = true } map of names
--- that still failed to resolve after the retry Scan completed.
function SC:_NotifySpellResolveFailure(unresolvedMap)
    if type(unresolvedMap) ~= "table" then
        return
    end
    local names = {}
    local skipped = {}
    for spellName in pairs(unresolvedMap) do
        if type(spellName) == "string" and spellName ~= "" then
            -- Fix 2: silently drop names WoW recognizes as
            -- legitimate spells. These are spells the user
            -- knows about (in another hero spec, off-spec, or
            -- another class) but are not in the current
            -- spellbook walk. Switching loadout makes them
            -- work; warning the user every login is wrong.
            -- Only WoW-unrecognized names (typos, deleted
            -- spells, fake overrides) reach the chat warning.
            local info = C_Spell and C_Spell.GetSpellInfo and C_Spell.GetSpellInfo(spellName)
            if info and info.spellID then
                skipped[spellName] = true
            else
                -- Fix 3 (v2.1.7 follow-up): catalog fallback
                -- for override-class hero talents. The wiki
                -- contract for C_Spell.GetSpellInfo by NAME
                -- says "Using name will always check for an
                -- override on that spell" -- the lookup
                -- follows the override chain and returns nil
                -- when the active loadout does not have the
                -- override active. Black Arrow (Hunter Dark
                -- Ranger hero talent, spellID 466930, registered
                -- as an override of Kill Shot via spellID
                -- 466932) is the canonical case: nil on Pack
                -- Leader even though the spell exists. The
                -- bundled CrossClassSpellCatalog already knows
                -- about override-class hero talents by name,
                -- so a lowercase-name lookup against it catches
                -- the class without regressing the 5 names the
                -- API already resolves (Soul Immolation, Void
                -- Metamorphosis, Void Ray, Consume, Reap).
                -- Shared lazy index (see SC:_EnsureCatalogNameIndex). The
                -- override-class suppression below only needs name->truthy; the
                -- index stores name->spellID, a strict superset, so behavior is
                -- preserved.
                local idx = SC:_EnsureCatalogNameIndex()
                if idx and idx[strlower(spellName)] then
                    skipped[spellName] = true
                else
                    names[#names + 1] = spellName
                end
            end
        end
    end
    -- Persist BOTH categories in the session-scope diagnostic
    -- log -- skipped entries are useful for debugging "why is
    -- my keybind not firing" even though no chat warning fires.
    SC._unresolvedSpells = SC._unresolvedSpells or {}
    for spellName in pairs(skipped) do
        SC._unresolvedSpells[spellName] = time()
    end
    if #names == 0 then
        return
    end
    -- Always record in the session diagnostic log (used by debug tooling
    -- even when the chat notice is off).
    for _, n in ipairs(names) do
        SC._unresolvedSpells[n] = time()
    end
    -- Chat notice is opt-in (off by default) AND de-duplicated: each name
    -- is announced at most once per session, so the frequent rescans
    -- (SPELLS_CHANGED, bag/equipment/pet events) cannot re-spam it.
    if not (GRIPEMS.Settings and GRIPEMS.Settings:Get("showUnresolvedSpellWarnings")) then
        return
    end
    SC._chatWarnedSpells = SC._chatWarnedSpells or {}
    local newNames = {}
    for _, n in ipairs(names) do
        if not SC._chatWarnedSpells[n] then
            newNames[#newNames + 1] = n
        end
    end
    if #newNames == 0 then
        return
    end
    table.sort(newNames)
    GRIPEMS:Print(string.format(L["GEMS_SPELL_CACHE_UNRESOLVED"], table.concat(newNames, ", ")))
    for _, n in ipairs(newNames) do
        SC._chatWarnedSpells[n] = true
    end
end

--- Register events that trigger spell cache refresh.
--- Called once during addon initialization.
function SC:RegisterEvents()
    -- Named for /reload reuse -- prevents orphan C++ frame objects
    local eventFrame = _G["GRIPEMS_SpellCacheEvent"] or CreateFrame("Frame", "GRIPEMS_SpellCacheEvent")
    eventFrame:UnregisterAllEvents()
    eventFrame:RegisterEvent("SPELLS_CHANGED")
    eventFrame:RegisterEvent("TRAIT_CONFIG_UPDATED")
    eventFrame:RegisterEvent("PLAYER_TALENT_UPDATE")
    eventFrame:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")
    eventFrame:RegisterEvent("ACTIVE_COMBAT_CONFIG_CHANGED")
    eventFrame:RegisterEvent("TRAIT_CONFIG_CREATED")
    eventFrame:RegisterEvent("TRAIT_CONFIG_DELETED")
    eventFrame:RegisterEvent("LEARNED_SPELL_IN_SKILL_LINE")
    eventFrame:RegisterEvent("SKILL_LINES_CHANGED")
    eventFrame:RegisterEvent("PLAYER_LEVEL_UP")
    eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
    eventFrame:RegisterEvent("UNIT_PET")
    eventFrame:RegisterEvent("PET_BAR_UPDATE")
    eventFrame:RegisterEvent("NEW_MOUNT_ADDED")
    eventFrame:RegisterEvent("NEW_TOY_ADDED")
    eventFrame:RegisterEvent("PET_JOURNAL_LIST_UPDATE")

    eventFrame:RegisterEvent("BAG_UPDATE_DELAYED")
    eventFrame:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")

    local TALENT_EVENTS = {
        TRAIT_CONFIG_UPDATED = true,
        TRAIT_CONFIG_CREATED = true,
        TRAIT_CONFIG_DELETED = true,
        PLAYER_TALENT_UPDATE = true,
        PLAYER_SPECIALIZATION_CHANGED = true,
        ACTIVE_COMBAT_CONFIG_CHANGED = true,
    }
    eventFrame:SetScript("OnEvent", function(_, event, arg1)
        local dirty = SC.collectionsDirty
        if
            event == "SPELLS_CHANGED"
            or event == "LEARNED_SPELL_IN_SKILL_LINE"
            or event == "SKILL_LINES_CHANGED"
            or event == "PLAYER_LEVEL_UP"
        then
            dirty.spells = true
            ScheduleRescan()
            return
        elseif TALENT_EVENTS[event] then
            dirty.spells = true
            ScheduleRescan("talent")
            return
        elseif event == "NEW_MOUNT_ADDED" then
            dirty.mounts = true
            SC.lazyDirty.mounts = true
        elseif event == "NEW_TOY_ADDED" then
            dirty.toys = true
            SC.lazyDirty.toys = true
        elseif event == "PET_JOURNAL_LIST_UPDATE" then
            dirty.companions = true
            SC.lazyDirty.companions = true
        elseif event == "BAG_UPDATE_DELAYED" or event == "PLAYER_EQUIPMENT_CHANGED" then
            dirty.items = true
        elseif event == "UNIT_PET" then
            if arg1 ~= "player" then
                return
            end
            dirty.companions = true
            SC.lazyDirty.companions = true
        elseif event == "PET_BAR_UPDATE" then
            dirty.companions = true
            SC.lazyDirty.companions = true
        elseif event == "PLAYER_ENTERING_WORLD" then
            -- Deferred eager build of the lazy caches 3s after PEW so
            -- direct consumers (perftest, collection browsers) still
            -- see populated data without opening the picker UIs first.
            -- OPP-01.
            if C_Timer and C_Timer.After then
                C_Timer.After(3, function()
                    if SC and SC.EnsureMountCache then
                        SC:EnsureMountCache()
                        SC:EnsureCompanionCache()
                        SC:EnsureToyCache()
                    end
                end)
            end
            -- No flag set; Scan is a no-op unless another event already dirtied something
            if not (dirty.spells or dirty.items or dirty.toys or dirty.mounts or dirty.companions) then
                return
            end
        end
        ScheduleRescan()
    end)

    SC.eventFrame = eventFrame
end

-- Auto-register events when file loads (Core.lua has already created GRIPEMS)
SC:RegisterEvents()
