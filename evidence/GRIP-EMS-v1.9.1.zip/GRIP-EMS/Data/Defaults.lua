-- GRIP-EMS: Defaults
-- Constants, limits, and template data for the sequencer engine

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS")

-- Defaults module: provides named constants for all numeric limits, icon IDs,
-- and template sequence data used throughout the engine. No magic numbers in
-- any other file -- they all reference GRIPEMS.Defaults instead.
GRIPEMS.Defaults = {}
local D = GRIPEMS.Defaults

-- Macro system limits (verified against 12.0.1 API, Research/07 Section 2)
D.MAX_MACROTEXT_LENGTH = 255 -- macrotext cap (CreateMacro + SecureActionButton) since Patch 11.0.2
D.MAX_SAB_MACROTEXT_LENGTH = 255 -- SAB macrotext hard cap (same as CreateMacro since 11.0.2)
D.MAX_MACRO_BODY = 255 -- CreateMacro body cap
D.MAX_MACRO_NAME = 16 -- WoW UI enforced name length
D.MAX_PER_CHAR_MACROS = MAX_CHARACTER_MACROS or 30 -- per-character macro slots
D.MAX_ACCOUNT_MACROS = MAX_ACCOUNT_MACROS or 120 -- account-wide macro slots

-- Icons
D.QUESTION_MARK_ICON = "INV_Misc_QuestionMark" -- string texture name (guaranteed format)

-- Attribute type constants (SecureActionButton type values)
D.ATTR_TYPE_SPELL = "spell" -- CastSpellByID/Name
D.ATTR_TYPE_MACRO = "macro" -- RunMacro/RunMacroText (255-char macrotext limit)
D.ATTR_TYPE_ITEM = "item" -- UseItem
D.ATTR_TYPE_CLICK = "click" -- clickbutton:Click() (also used as pause/no-op)

-- Action tree node type constants (v1.2.0 S14)
D.ACTION_TYPE_ACTION = "action"
D.ACTION_TYPE_LOOP = "loop"
D.ACTION_TYPE_IF = "if"
D.ACTION_TYPE_EMBED = "embed"
D.ACTION_TYPE_PAUSE = "pause"

-- Action tree limits
D.ACTION_MAX_DEPTH = 10
D.ACTION_LOOP_MAX_REPEAT = 50
D.ACTION_LOOP_DEFAULT_REPEAT = 1

-- Action interleave limits
D.ACTION_INTERLEAVE_MIN = 2
D.ACTION_INTERLEAVE_MAX = 50
D.ACTION_INTERLEAVE_DEFAULT = 2

-- Node badge display constants (Outline + Detail pane)
D.NODE_BADGE_HEIGHT = 28
D.NODE_ICONS = {
    loop = { label = "Loop", symbol = "L", color = { 0.30, 0.65, 1.0, 1.0 } },
    pause = { label = "Pause", symbol = "P", color = { 0.90, 0.72, 0.0, 1.0 } },
    ["if"] = { label = "If", symbol = "?", color = { 0.78, 0.49, 1.0, 1.0 } },
    embed = { label = "Embed", symbol = "E", color = { 0.30, 0.90, 0.66, 1.0 } },
}

-- Macro stub naming
D.MACRO_PREFIX = "GEMS:" -- prefix for GRIP-EMS managed macros
D.BUTTON_PREFIX = "GRIPEMS_" -- prefix for SecureActionButton global names
-- Two %s args: both the button global name. The [button:1] conditional targets
-- left-click /click events with LeftButton+t flags; the trailing bare name is
-- a fallback for virtual button and keyboard-only usage.
D.MACRO_BODY_TEMPLATE = "#showtooltip\n/click [button:1] %s LeftButton t; %s"

-- OOC queue
D.OOC_TICKER_INTERVAL = 7 -- seconds between fallback queue processing

-- OOC operation type constants (priority queue dedup keys)
D.OOC_OP_ACTIVATE = "activate"
D.OOC_OP_DEACTIVATE = "deactivate"
D.OOC_OP_RECOMPILE = "recompile"
D.OOC_OP_RESET = "reset"
D.OOC_OP_ICON = "icon"
D.OOC_OP_SETTING = "setting"
D.OOC_OP_RELOAD = "reload"
D.OOC_OP_GENERIC = "generic"

-- Priority table (lower = higher priority, processed first)
D.OOC_PRIORITY = {
    [D.OOC_OP_ACTIVATE] = 10,
    [D.OOC_OP_DEACTIVATE] = 20,
    [D.OOC_OP_RELOAD] = 30,
    [D.OOC_OP_RECOMPILE] = 40,
    [D.OOC_OP_RESET] = 50,
    [D.OOC_OP_ICON] = 60,
    [D.OOC_OP_SETTING] = 70,
    [D.OOC_OP_GENERIC] = 80,
}

-- Click rate throttle (ms between key presses)
D.MS_CLICK_RATE_MIN = 100
D.MS_CLICK_RATE_MAX = 1000
D.MS_CLICK_RATE_DEFAULT = 250
D.MS_CLICK_RATE_STEP = 10

-- Faster, Slower: TempoAdvisor defaults (Phase 2)
D.TEMPO_AUTO_SET_DEFAULT = true
D.TEMPO_ALERT_ENABLED_DEFAULT = false
D.TEMPO_ALERT_VISUAL_DEFAULT = true
D.TEMPO_ALERT_AUDIO_DEFAULT = true
D.TEMPO_ALERT_SLOW_THRESHOLD = 0.6
D.TEMPO_ALERT_FAST_THRESHOLD = 2.0
D.TEMPO_SPARKLINE_DEFAULT = false

-- Step function names (registry keys)
D.STEP_SEQUENTIAL = "Sequential"
D.STEP_RANDOM = "Random"
D.STEP_PRIORITY = "Priority"
D.STEP_REVERSE_PRIORITY = "ReversePriority"

-- Spell validation status values (v1.1.0)
D.SPELL_STATUS_VALID = "valid"
D.SPELL_STATUS_KNOWN = "known"
D.SPELL_STATUS_UNKNOWN = "unknown"
D.SPELL_STATUS_ITEM = "item"
D.SPELL_STATUS_VARIABLE = "variable"
D.SPELL_STATUS_TOOLTIP_STALE = "tooltip_stale"

-- Hardcoded fallback for spells where C_SpellBook.FindBaseSpellByID
-- returns nil. Key = replacement spellID, value = base spellID.
-- Expand this table as API gaps are discovered in the field.
-- Format: [replacementID] = baseID
D.BASE_SPELL_TABLE = {}

-- Variable event list: ordered categories with event name arrays.
-- Used by the VariablesTab event dropdown for quick event selection.
D.VARIABLE_EVENT_LIST = {
    {
        name = "Actionbar",
        events = {
            "ACTIONBAR_SLOT_CHANGED",
            "ACTIONBAR_UPDATE_COOLDOWN",
            "ACTIONBAR_UPDATE_STATE",
            "ACTIONBAR_UPDATE_USABLE",
            "UPDATE_BONUS_ACTIONBAR",
        },
    },
    {
        name = "Bag / Equipment",
        events = {
            "BAG_UPDATE",
            "EQUIPMENT_SETS_CHANGED",
            "EQUIPMENT_SWAP_FINISHED",
            "PLAYER_EQUIPMENT_CHANGED",
            "UNIT_INVENTORY_CHANGED",
        },
    },
    {
        name = "Combat",
        events = {
            "PLAYER_REGEN_DISABLED",
            "PLAYER_REGEN_ENABLED",
        },
    },
    {
        name = "Encounter",
        events = {
            "ENCOUNTER_START",
            "ENCOUNTER_END",
            "BOSS_KILL",
            "CHALLENGE_MODE_START",
            "CHALLENGE_MODE_COMPLETED",
        },
    },
    {
        name = "Group",
        events = {
            "GROUP_JOINED",
            "GROUP_LEFT",
            "GROUP_ROSTER_UPDATE",
            "PARTY_LEADER_CHANGED",
            "PARTY_MEMBERS_CHANGED",
        },
    },
    {
        name = "Pet",
        events = {
            "UNIT_PET",
            "PET_BAR_UPDATE",
            "PET_SPECIALIZATION_CHANGED",
            "PET_STABLE_UPDATE",
            "PET_UI_UPDATE",
        },
    },
    {
        name = "Player State",
        events = {
            "PLAYER_ENTERING_WORLD",
            "PLAYER_LEAVING_WORLD",
            "PLAYER_LEVEL_UP",
            "PLAYER_LOGIN",
            "PLAYER_LOGOUT",
            "PLAYER_XP_UPDATE",
        },
    },
    {
        name = "PVP",
        events = {
            "UNIT_FACTION",
            "PLAYER_PVP_KILLS_CHANGED",
            "PLAYER_PVP_RANK_CHANGED",
        },
    },
    {
        name = "Spec / Talents",
        events = {
            "ACTIVE_TALENT_GROUP_CHANGED",
            "CHARACTER_POINTS_CHANGED",
            "PLAYER_PVP_TALENT_UPDATE",
            "PLAYER_SPECIALIZATION_CHANGED",
            "PLAYER_TALENT_UPDATE",
            "SPEC_INVOLUNTARILY_CHANGED",
            "TRAIT_CONFIG_UPDATED",
        },
    },
    {
        name = "Spells",
        events = {
            "SPELL_UPDATE_CHARGES",
            "SPELL_UPDATE_COOLDOWN",
            "SPELLS_CHANGED",
            "UNIT_SPELLCAST_FAILED",
            "UNIT_SPELLCAST_INTERRUPTED",
            "UNIT_SPELLCAST_START",
            "UNIT_SPELLCAST_STOP",
            "UNIT_SPELLCAST_SUCCEEDED",
        },
    },
    {
        name = "Talent Loadout",
        events = {
            "SELECTED_LOADOUT_CHANGED",
            "ACTIVE_COMBAT_CONFIG_CHANGED",
        },
    },
    {
        name = "Target",
        events = {
            "PLAYER_TARGET_CHANGED",
        },
    },
    {
        name = "Unit",
        events = {
            "UNIT_AURA",
            "UNIT_HEALTH",
            "UNIT_MAXHEALTH",
            "UNIT_POWER_UPDATE",
            "UNIT_DISPLAYPOWER",
        },
    },
    {
        name = "Vehicle",
        events = {
            "UNIT_ENTERED_VEHICLE",
            "UNIT_EXITED_VEHICLE",
            "UPDATE_VEHICLE_ACTIONBAR",
        },
    },
    {
        name = "Zone",
        events = {
            "ZONE_CHANGED",
            "ZONE_CHANGED_NEW_AREA",
            "PLAYER_DIFFICULTY_CHANGED",
        },
    },
    {
        name = "EMS Internal",
        events = {
            "CONTEXT_CHANGED",
            "KEYBIND_CHANGED",
            "PLUGIN_REGISTERED",
            "PLUGIN_SEQUENCES_LOADED",
            "SEQUENCE_CREATED",
            "SEQUENCE_DELETED",
            "SEQUENCE_IMPORTED",
            "SEQUENCE_STEP_ADVANCED",
            "SEQUENCE_UPDATED",
            "SETTING_CHANGED",
            "SPELL_CACHE_REFRESHED",
            "SPELL_VALIDATION_UPDATED",
            "VARIABLE_CREATED",
            "VARIABLE_DELETED",
            "VARIABLE_UPDATED",
        },
    },
}

-- Context version selection (T2-1)
D.CONTEXT_NONE = "none"

-- Ordered array of all 53 context key strings
D.CONTEXT_KEYS = {
    "Raid",
    "RaidLFR",
    "RaidHeroic",
    "RaidMythic",
    "Arena",
    "RatedArena",
    "SoloShuffle",
    "PVP",
    "RatedBG",
    "BattlegroundBlitz",
    "MythicPlus",
    "MythicPlusLow",
    "MythicPlusMid",
    "MythicPlusHigh",
    "Mythic",
    "Heroic",
    "Dungeon",
    "Timewalking",
    "TimewalkingRaid",
    "Delves",
    "DelvesLow",
    "DelvesHigh",
    "Party",
    "Solo",
    "Scenario",
    -- Arena maps (v1.2.0 S22-F)
    "Arena_BladesEdge",
    "Arena_Nagrand",
    "Arena_Lordaeron",
    "Arena_Dalaran",
    "Arena_TigersPeak",
    "Arena_TolViron",
    "Arena_BlackRook",
    "Arena_Ashamane",
    "Arena_HookPoint",
    "Arena_Mugambala",
    "Arena_Empyrean",
    "Arena_Enigma",
    "Arena_Nokhudon",
    "Arena_Maldraxxus",
    "Arena_Robodrome",
    -- Battleground maps (v1.2.0 S22-F)
    "BG_AlteracValley",
    "BG_WarsongGulch",
    "BG_ArathiBasin",
    "BG_EyeOfTheStorm",
    "BG_IsleOfConquest",
    "BG_TwinPeaks",
    "BG_Gilneas",
    "BG_TempleOfKotmogu",
    "BG_DeepwindGorge",
    "BG_Ashran",
    "BG_SilvershardMines",
    "BG_SeethingShore",
    "BG_Wintergrasp",
}

-- Display labels for each context key
D.CONTEXT_LABELS = {
    Raid = "Raid",
    RaidLFR = "Raid: LFR",
    RaidHeroic = "Raid: Heroic",
    RaidMythic = "Raid: Mythic",
    Arena = "Arena",
    RatedArena = "Rated Arena",
    SoloShuffle = "Solo Shuffle",
    PVP = "Battleground",
    RatedBG = "Rated Battleground",
    BattlegroundBlitz = "BG Blitz",
    MythicPlus = "Mythic+",
    MythicPlusLow = "Mythic+ (Low Key)",
    MythicPlusMid = "Mythic+ (Mid Key)",
    MythicPlusHigh = "Mythic+ (High Key)",
    Mythic = "Mythic Dungeon",
    Heroic = "Heroic Dungeon",
    Dungeon = "Normal Dungeon",
    Timewalking = "Timewalking",
    TimewalkingRaid = "Timewalking Raid",
    Delves = "Delves",
    DelvesLow = "Delves (Low Tier)",
    DelvesHigh = "Delves (High Tier)",
    Party = "Party (World)",
    Solo = "Solo (World)",
    Scenario = "Scenario",
    -- Arena maps (v1.2.0 S22-F)
    Arena_BladesEdge = "Blade's Edge Arena",
    Arena_Nagrand = "Nagrand Arena",
    Arena_Lordaeron = "Ruins of Lordaeron",
    Arena_Dalaran = "Dalaran Sewers",
    Arena_TigersPeak = "Tiger's Peak",
    Arena_TolViron = "Tol'Viron Arena",
    Arena_BlackRook = "Black Rook Hold Arena",
    Arena_Ashamane = "Ashamane's Fall",
    Arena_HookPoint = "Hook Point",
    Arena_Mugambala = "Mugambala",
    Arena_Empyrean = "Empyrean Domain",
    Arena_Enigma = "Enigma Crucible",
    Arena_Nokhudon = "Nokhudon Proving Grounds",
    Arena_Maldraxxus = "Maldraxxus Coliseum",
    Arena_Robodrome = "The Robodrome",
    -- Battleground maps (v1.2.0 S22-F)
    BG_AlteracValley = "Alterac Valley",
    BG_WarsongGulch = "Warsong Gulch",
    BG_ArathiBasin = "Arathi Basin",
    BG_EyeOfTheStorm = "Eye of the Storm",
    BG_IsleOfConquest = "Isle of Conquest",
    BG_TwinPeaks = "Twin Peaks",
    BG_Gilneas = "Battle for Gilneas",
    BG_TempleOfKotmogu = "Temple of Kotmogu",
    BG_DeepwindGorge = "Deepwind Gorge",
    BG_Ashran = "Ashran",
    BG_SilvershardMines = "Silvershard Mines",
    BG_SeethingShore = "Seething Shore",
    BG_Wintergrasp = "Wintergrasp",
}

-- Fallback chains: each context key maps to an ordered array of fallback
-- keys to check before defaultVersion. Table-driven cascade logic.
D.CONTEXT_FALLBACKS = {
    RaidMythic = { "RaidHeroic", "RaidLFR", "Raid" },
    RaidHeroic = { "RaidLFR", "Raid" },
    RaidLFR = { "Raid" },
    Arena = { "PVP" },
    RatedArena = { "Arena", "PVP" },
    SoloShuffle = { "RatedArena", "Arena", "PVP" },
    RatedBG = { "PVP" },
    BattlegroundBlitz = { "RatedBG", "PVP" },
    MythicPlus = { "Mythic", "Heroic", "Dungeon" },
    MythicPlusLow = { "MythicPlus", "Mythic", "Heroic", "Dungeon" },
    MythicPlusMid = { "MythicPlusLow", "MythicPlus", "Mythic", "Heroic", "Dungeon" },
    MythicPlusHigh = { "MythicPlusMid", "MythicPlusLow", "MythicPlus", "Mythic", "Heroic", "Dungeon" },
    Mythic = { "Heroic", "Dungeon" },
    Heroic = { "Dungeon" },
    TimewalkingRaid = { "Timewalking" },
    Delves = { "Scenario" },
    DelvesLow = { "Delves", "Scenario" },
    DelvesHigh = { "DelvesLow", "Delves", "Scenario" },
    -- Arena maps fall back to Arena (v1.2.0 S22-F)
    Arena_BladesEdge = { "Arena" },
    Arena_Nagrand = { "Arena" },
    Arena_Lordaeron = { "Arena" },
    Arena_Dalaran = { "Arena" },
    Arena_TigersPeak = { "Arena" },
    Arena_TolViron = { "Arena" },
    Arena_BlackRook = { "Arena" },
    Arena_Ashamane = { "Arena" },
    Arena_HookPoint = { "Arena" },
    Arena_Mugambala = { "Arena" },
    Arena_Empyrean = { "Arena" },
    Arena_Enigma = { "Arena" },
    Arena_Nokhudon = { "Arena" },
    Arena_Maldraxxus = { "Arena" },
    Arena_Robodrome = { "Arena" },
    -- BG maps fall back to PVP (v1.2.0 S22-F)
    BG_AlteracValley = { "PVP" },
    BG_WarsongGulch = { "PVP" },
    BG_ArathiBasin = { "PVP" },
    BG_EyeOfTheStorm = { "PVP" },
    BG_IsleOfConquest = { "PVP" },
    BG_TwinPeaks = { "PVP" },
    BG_Gilneas = { "PVP" },
    BG_TempleOfKotmogu = { "PVP" },
    BG_DeepwindGorge = { "PVP" },
    BG_Ashran = { "PVP" },
    BG_SilvershardMines = { "PVP" },
    BG_SeethingShore = { "PVP" },
    BG_Wintergrasp = { "PVP" },
}

-- Context groups for the Context tab UI (T2-1b)
D.CONTEXT_GROUPS = {
    { name = "Raids", keys = { "Raid", "RaidLFR", "RaidHeroic", "RaidMythic" } },
    {
        name = "Dungeons",
        keys = {
            "Dungeon",
            "Heroic",
            "Mythic",
            "MythicPlus",
            "MythicPlusLow",
            "MythicPlusMid",
            "MythicPlusHigh",
        },
    },
    { name = "PvP", keys = { "Arena", "RatedArena", "SoloShuffle", "PVP", "RatedBG", "BattlegroundBlitz" } },
    {
        name = "Arena Maps",
        keys = {
            "Arena_BladesEdge",
            "Arena_Nagrand",
            "Arena_Lordaeron",
            "Arena_Dalaran",
            "Arena_TigersPeak",
            "Arena_TolViron",
            "Arena_BlackRook",
            "Arena_Ashamane",
            "Arena_HookPoint",
            "Arena_Mugambala",
            "Arena_Empyrean",
            "Arena_Enigma",
            "Arena_Nokhudon",
            "Arena_Maldraxxus",
            "Arena_Robodrome",
        },
    },
    {
        name = "Battleground Maps",
        keys = {
            "BG_AlteracValley",
            "BG_WarsongGulch",
            "BG_ArathiBasin",
            "BG_EyeOfTheStorm",
            "BG_IsleOfConquest",
            "BG_TwinPeaks",
            "BG_Gilneas",
            "BG_TempleOfKotmogu",
            "BG_DeepwindGorge",
            "BG_Ashran",
            "BG_SilvershardMines",
            "BG_SeethingShore",
            "BG_Wintergrasp",
        },
    },
    {
        name = "Other",
        keys = {
            "Timewalking",
            "TimewalkingRaid",
            "Delves",
            "DelvesLow",
            "DelvesHigh",
            "Party",
            "Solo",
            "Scenario",
        },
    },
}

-- Built-in CVar profiles: named sets of CVar overrides per gameplay context.
-- Profiles store ONLY overrides (CVars that differ from General recommendations
-- in D.CVAR_SECTIONS). General is NOT a profile -- it is the baseline.
D.CVAR_PROFILES = {
    {
        key = "raid",
        label = L["GEMS_CVAR_PROFILE_RAID"],
        desc = L["GEMS_CVAR_PROFILE_RAID_DESC"],
        icon = 236396, -- Achievement_Dungeon_ClassicRaid
        overrides = {
            ["nameplateMaxDistance"] = "41",
            ["nameplatePlayerMaxDistance"] = "41",
            ["nameplateMotion"] = "1",
        },
    },
    {
        key = "mythicplus",
        label = L["GEMS_CVAR_PROFILE_MPLUS"],
        desc = L["GEMS_CVAR_PROFILE_MPLUS_DESC"],
        icon = 648207, -- INV_Relics_Hourglass
        overrides = {
            ["nameplateShowEnemyMinions"] = "1",
            ["nameplateMaxDistance"] = "41",
            ["nameplatePlayerMaxDistance"] = "41",
        },
    },
    {
        key = "solo",
        label = L["GEMS_CVAR_PROFILE_SOLO"],
        desc = L["GEMS_CVAR_PROFILE_SOLO_DESC"],
        icon = 132331, -- Ability_Mount_Gryphon01
        overrides = {
            ["SoftTargetInteractArc"] = "2",
            ["RAIDsettingsEnabled"] = "0",
            ["nameplateShowAll"] = "0",
        },
    },
    {
        key = "pvp",
        label = L["GEMS_CVAR_PROFILE_PVP"],
        desc = L["GEMS_CVAR_PROFILE_PVP_DESC"],
        icon = 236549, -- Achievement_BG_WinAB
        overrides = {
            ["nameplateShowFriendlyPlayers"] = "1",
            ["nameplateShowEnemyMinions"] = "1",
            ["nameplateMaxDistance"] = "41",
            ["nameplatePlayerMaxDistance"] = "41",
            ["nameplateMotion"] = "1",
        },
    },
}

-- Map context keys (from DetectContext()) to profile keys.
-- Contexts not listed fall through to General (no profile override).
D.CVAR_PROFILE_MAP = {
    -- Raids
    Raid = "raid",
    RaidLFR = "raid",
    RaidHeroic = "raid",
    RaidMythic = "raid",
    -- Dungeons (M+ only; normal/heroic/mythic0 use General)
    MythicPlus = "mythicplus",
    MythicPlusLow = "mythicplus",
    MythicPlusMid = "mythicplus",
    MythicPlusHigh = "mythicplus",
    -- PvP (arena/BG map-specific keys resolve via CONTEXT_FALLBACKS)
    Arena = "pvp",
    RatedArena = "pvp",
    SoloShuffle = "pvp",
    PVP = "pvp",
    RatedBG = "pvp",
    BattlegroundBlitz = "pvp",
    -- Solo / Open World
    Solo = "solo",
    Party = "solo",
}

-- Map difficultyID to context key (used for instanceType "party" and "raid")
D.DIFFICULTY_CONTEXT = {
    -- Party difficulties
    [1] = "Dungeon",
    [2] = "Heroic",
    [8] = "MythicPlus",
    [23] = "Mythic",
    [24] = "Timewalking",
    [150] = "Dungeon",
    [205] = "Dungeon",
    -- Raid difficulties
    [14] = "Raid",
    [15] = "RaidHeroic",
    [16] = "RaidMythic",
    [17] = "RaidLFR",
    [33] = "TimewalkingRaid",
    [151] = "RaidLFR",
    -- Scenario difficulties
    [167] = "Scenario", -- Torghast
    [152] = "Scenario", -- Visions of N'Zoth
    -- Additional dungeon/raid difficulties
    [216] = "Dungeon", -- Quest Dungeon
    [220] = "Raid", -- Story Raid
    [236] = "Timewalking", -- Lorewalking Dungeon
    [241] = "TimewalkingRaid", -- Lorewalking Raid
    -- Legacy raid difficulties
    [3] = "Raid",
    [4] = "Raid",
    [5] = "RaidHeroic",
    [6] = "RaidHeroic",
    [7] = "RaidLFR",
    [9] = "Raid",
}

-- Map instanceType string to context key (types that do NOT need difficultyID)
D.INSTANCE_TYPE_CONTEXT = {
    arena = "Arena",
    pvp = "PVP",
}

-- Per-map context keys for arenas and battlegrounds (v1.2.0 S22-F)
-- Maps instanceMapID (8th return of GetInstanceInfo) to context key.
-- Populated with known IDs; unknown maps fall through to generic type.
D.ARENA_MAP_CONTEXT = {
    [562] = "Arena_BladesEdge",
    [559] = "Arena_Nagrand",
    [572] = "Arena_Lordaeron",
    [617] = "Arena_Dalaran",
    [980] = "Arena_TigersPeak",
    [1134] = "Arena_TolViron",
    [1504] = "Arena_BlackRook",
    [1672] = "Arena_Ashamane",
    [2167] = "Arena_HookPoint",
    [2373] = "Arena_Mugambala",
    [2509] = "Arena_Empyrean",
    [2547] = "Arena_Enigma",
    [2563] = "Arena_Nokhudon",
    [2686] = "Arena_Maldraxxus",
    [2690] = "Arena_Robodrome",
}

D.BG_MAP_CONTEXT = {
    [30] = "BG_AlteracValley",
    [489] = "BG_WarsongGulch",
    [529] = "BG_ArathiBasin",
    [566] = "BG_EyeOfTheStorm",
    [628] = "BG_IsleOfConquest",
    [726] = "BG_TwinPeaks",
    [761] = "BG_Gilneas",
    [998] = "BG_TempleOfKotmogu",
    [1105] = "BG_DeepwindGorge",
    [1191] = "BG_Ashran",
    [2106] = "BG_SilvershardMines",
    [2107] = "BG_SeethingShore",
    [2245] = "BG_Wintergrasp",
}

-- Context detection tier thresholds (v1.2.0 S19)
D.MYTHICPLUS_TIER_MID_DEFAULT = 8
D.MYTHICPLUS_TIER_HIGH_DEFAULT = 12
D.DELVES_TIER_HIGH_DEFAULT = 5

-- Version template (per-version fields: steps, stepFunction, reset conditions)
D.NewVersion = {
    stepFunction = "Sequential",
    steps = {},
    keyPress = "/stopmacro [channeling]",
    keyRelease = "",
    resetOnCombat = false,
    resetOnTarget = false,
    resetOnGear = false,
    resetOnSpec = false,
    resetTimer = 0,
    resetModifiers = nil, -- nil = use global, table = per-sequence overrides
}

-- Reset token mapping: string token -> version field name
-- Used by ParseResetString/BuildResetString for combined reset syntax
D.RESET_TOKEN_MAP = {
    combat = "resetOnCombat",
    target = "resetOnTarget",
    gear = "resetOnGear",
    head = "resetOnGear", -- alias: legacy format uses Head for gear swap
    spec = "resetOnSpec",
}

-- Ordered keys for BuildResetString output (fixed order, no aliases)
D.RESET_BUILD_ORDER = {
    { token = "combat", field = "resetOnCombat" },
    { token = "target", field = "resetOnTarget" },
    { token = "gear", field = "resetOnGear" },
    { token = "spec", field = "resetOnSpec" },
}

-- Parse a slash-separated reset string into a table of reset fields
-- Input:  "target/combat/5"
-- Output: { resetOnCombat=true, resetOnTarget=true, resetOnGear=false,
--           resetOnSpec=false, resetTimer=5 }
-- Returns nil if str is nil or empty
function D.ParseResetString(str)
    if not str or str == "" then
        return nil
    end

    local result = {
        resetOnCombat = false,
        resetOnTarget = false,
        resetOnGear = false,
        resetOnSpec = false,
        resetTimer = 0,
    }

    for token in str:gmatch("[^/]+") do
        token = strtrim(token)
        local lower = strlower(token)
        local field = D.RESET_TOKEN_MAP[lower]
        if field then
            result[field] = true
        else
            local num = tonumber(token)
            if num then
                result.resetTimer = num
            end
            -- Unknown non-numeric tokens: skip (forward-compatible)
        end
    end

    return result
end

-- Build a slash-separated reset string from a version table
-- Input:  { resetOnCombat=true, resetOnTarget=true, resetTimer=5 }
-- Output: "combat/target/5"
-- Returns "" if no conditions set
function D.BuildResetString(ver)
    if not ver then
        return ""
    end

    local parts = {}
    for _, entry in ipairs(D.RESET_BUILD_ORDER) do
        if ver[entry.field] then
            parts[#parts + 1] = entry.token
        end
    end

    if ver.resetTimer and ver.resetTimer > 0 then
        parts[#parts + 1] = tostring(ver.resetTimer)
    end

    return table.concat(parts, "/")
end

-- Test sequence for /gems create (verifies engine with harmless /say commands)
D.TestSequence = {
    name = "TestSeq",
    icon = D.QUESTION_MARK_ICON,
    defaultVersion = 1,
    versions = {
        [1] = {
            stepFunction = "Sequential",
            keyPress = "/stopmacro [channeling]",
            keyRelease = "",
            resetOnCombat = true,
            resetOnTarget = false,
            resetOnGear = false,
            resetOnSpec = false,
            resetTimer = 0,
            steps = {
                "/say GRIP-EMS Step 1",
                "/say GRIP-EMS Step 2",
                "/say GRIP-EMS Step 3",
            },
        },
    },
}

-- Import/Export format constants
D.GSE3_PREFIX = "!GSE3!" -- 6-char prefix for legacy encoded strings
D.GRIP1_PREFIX = "!GRIP1!" -- 7-char prefix for GRIP-EMS native encoded strings
D.GRIP_FORMAT_VERSION = 4 -- v4: action tree export (S14-C)
D.LOCALE_STORE_VERSION = 1 -- v1: taggedSteps shadow copy (Phase 2a)

-- UI frame defaults (Phase 3A)
D.MAIN_FRAME_WIDTH = 800
D.MAIN_FRAME_HEIGHT = 500
D.MAIN_FRAME_MIN_WIDTH = 750
D.MAIN_FRAME_MIN_HEIGHT = 500
D.LEFT_PANEL_WIDTH = 280
D.LEFT_PANEL_MIN_WIDTH = 180
D.LEFT_PANEL_MAX_WIDTH = 400
D.TITLE_BAR_HEIGHT = 40
D.MINIMIZED_HEIGHT = 40
D.ROW_HEIGHT = 32

-- UI list/editor constants (Phase 3A-2)
D.SEARCH_BOX_HEIGHT = 28
D.BUTTON_BAR_HEIGHT = 36
D.TAB_HEIGHT = 28
D.STEP_ROW_HEIGHT = 24
D.EDITOR_HEADER_HEIGHT = 200
D.CHAR_COUNT_WARNING = 200 -- yellow threshold for step char count
D.CHAR_COUNT_DANGER = D.MAX_SAB_MACROTEXT_LENGTH -- red threshold (macrotext limit: 255)

-- Phase 3B-1 constants
D.STEP_ACTION_BAR_HEIGHT = 30
D.STEP_EDIT_HEIGHT_MIN = 40
D.STEP_EDIT_HEIGHT_MAX = 80
D.STEP_BUTTON_WIDTH = 50
D.STEP_BUTTON_HEIGHT = 24
D.STEP_DRAG_HANDLE_WIDTH = 16
D.DRAG_SCROLL_EDGE_ZONE = 30
D.DRAG_SCROLL_INCREMENT = 0.02
D.NAME_EDITBOX_HEIGHT = 22

-- Vehicle and pet battle keybind slots (v1.2.0 S23)
D.VEHICLE_KEYBIND_SLOTS = 12
D.PET_BATTLE_SLOTS = 6
D.PET_BATTLE_SLOT_NAMES = {
    "Ability 1",
    "Ability 2",
    "Ability 3",
    "Swap Pet",
    "Pass Turn",
    "Forfeit",
}

-- Bar integration
D.BAR_INTEGRATION_DEFAULT = true

-- Phase 3B-2 constants
D.KEYBIND_DISPLAY_FONT_SIZE = 16
D.KEY_CAPTURE_BUTTON_WIDTH = 120
D.KEY_CAPTURE_BUTTON_HEIGHT = 28
D.SPEC_ROW_HEIGHT = 26
D.PREVIEW_FRAME_HEIGHT = 80
D.PREVIEW_ICON_SIZE = 36
D.PREVIEW_ICON_SPACING = 4
D.PREVIEW_MAX_STEPS = 30
D.PREVIEW_MODE_ICONS = "icons"
D.PREVIEW_MODE_TEXT = "text"
D.PREVIEW_MODE_COMPILED = "compiled"
D.STUB_ROW_HEIGHT = 20
D.MACROS_TAB_MAX_STUBS = 30

-- Phase 3C-1 constants
D.AUTOCOMPLETE_MIN_CHARS = 2 -- minimum prefix length for macro commands (/ or #)
D.AUTOCOMPLETE_MIN_SPELL_CHARS = 1 -- minimum prefix length for spell names
D.AUTOCOMPLETE_MAX_RESULTS = 10 -- max suggestions to show in popup
D.AUTOCOMPLETE_SEQ_ICON = 134327 -- INV_Misc_Note_01 fileID (macro scroll icon)
D.AUTOCOMPLETE_MIN_SEQ_CHARS = 2 -- minimum prefix length for sequence name fallback
D.SPELL_CACHE_DEBOUNCE = 0.5 -- seconds to debounce spell cache refresh
D.SPELL_CACHE_COMBAT_DEBOUNCE = 5.0 -- seconds to debounce spell cache refresh during combat
D.HOLD_MODE_SLOT_DEFAULT = "MultiBar7Button12"
D.HOLD_MODE_POLL_MIN_DEFAULT = 50 -- ms floor for UseKeyHeldSpellErrorPollTime
D.HOLD_MODE_BIND_COMMAND_DEFAULT = "MULTIACTIONBAR7BUTTON12"
D.SPELL_VALIDATE_DEBOUNCE = 1.0 -- seconds to debounce spell validation after cache refresh

-- Phase 3C-3 constants (Variable System)
D.VAR_PATTERN = "~(%w+)~" -- pattern to match variable references in macrotext
D.VAR_MAX_NAME = 32 -- max variable name length
D.VAR_MAX_FUNC = 1024 -- max function body length
D.VAR_EVAL_TIMEOUT = 0.05 -- max eval time before warning (logged, not enforced)
D.VAR_CONSOLIDATION = 0.1 -- event consolidation timer seconds

-- Macro command prefixes to skip during spell extraction
D.SKIP_SPELL_PREFIXES = {
    "^%s*#show",
    "^%s*/stopcasting",
    "^%s*/stopattack",
    "^%s*/stopmacro",
    "^%s*/cancelaura",
    "^%s*/cancelform",
    "^%s*/startattack",
    "^%s*/target",
    "^%s*/focus",
    "^%s*/clearfocus",
    "^%s*/cleartarget",
}

-- Phase 3C-3b constants (Variables Tab UI)
D.VAR_LIST_WIDTH = 140 -- variable list panel width
D.VAR_EDITOR_ROW_HEIGHT = 24 -- row height in variable list
D.VAR_FUNC_EDIT_HEIGHT = 100 -- function editor height

-- Phase 3C-2 constants (Icon Picker)
D.ICON_PICKER_WIDTH = 320
D.ICON_PICKER_HEIGHT = 380
D.ICON_GRID_COLS = 8
D.ICON_GRID_SIZE = 32
D.ICON_GRID_GAP = 4

-- Raw tab constants
D.RAW_HEADER_HEIGHT = 28
D.RAW_STATUS_HEIGHT = 16

-- Import preview picker constants (T2-4)
D.IMPORT_PICKER_WIDTH = 550
D.IMPORT_PICKER_HEIGHT = 500
D.IMPORT_PICKER_ROW_HEIGHT = 28

-- Export preview picker constants (T2-12)
D.EXPORT_PICKER_WIDTH = 550
D.EXPORT_PICKER_HEIGHT = 500
D.EXPORT_PICKER_ROW_HEIGHT = 28
D.EXPORT_META_NAME_MAX = 64
D.EXPORT_META_DESC_MAX = 256
D.EXPORT_META_URL_MAX = 256

-- Corrupt sequence recovery actions
D.CORRUPT_ACTION_DELETE = "delete"
D.CORRUPT_ACTION_SKIP = "skip"
D.CORRUPT_ACTION_EXPORT = "export"

-- Transmission constants (T2-9)
D.COMM_PREFIX = "GRIPEMS" -- max 16 chars
D.CMD_TRANSMIT = "GEMS_TRANSMIT" -- send sequence(s)
D.CMD_REQUEST = "GEMS_REQUEST" -- request a sequence
D.CMD_VERSION = "GEMS_VERSION" -- version check
D.CMD_META_REQUEST = "GEMS_META_REQ" -- request sequence metadata
D.CMD_META = "GEMS_META" -- sequence metadata response
D.CMD_SPELLCACHE = "GEMS_SPELLCACHE" -- spell cache broadcast
D.CMD_LIST_REQUEST = "GEMS_LISTREQ" -- request sequence list from player
D.CMD_LIST_RESPONSE = "GEMS_LISTRESP" -- sequence list response
D.COMM_LINK_PREFIX = "GRIPEMS" -- for chat hyperlinks
D.COMM_MAX_PENDING = 10 -- max pending incoming

-- Debug window constants
D.DEBUG_WINDOW_WIDTH = 500
D.DEBUG_WINDOW_HEIGHT = 300

-- Undo/redo stack depth (v1.2.0 S22)
D.UNDO_MAX_DEPTH = 30

-- Periodic garbage collection interval (seconds)
D.GC_INTERVAL = 30

-- Popup editor constants (v1.2.0 S07a)
D.POPUP_EDITOR_WIDTH = 500
D.POPUP_EDITOR_HEIGHT = 550
D.POPUP_EDITOR_MIN_WIDTH = 400
D.POPUP_EDITOR_MIN_HEIGHT = 400
D.MAX_POPUP_EDITORS = 4

-- Macro reset modifier keys (15 toggles)
D.MACRO_RESET_MODIFIERS = {
    "LeftButton",
    "RightButton",
    "MiddleButton",
    "Button4",
    "Button5",
    "LeftAlt",
    "RightAlt",
    "Alt",
    "LeftControl",
    "RightControl",
    "Control",
    "LeftShift",
    "RightShift",
    "Shift",
    "AnyMod",
}
D.MACRO_RESET_MODIFIER_DEFAULTS = {}
for _, mod in ipairs(D.MACRO_RESET_MODIFIERS) do
    D.MACRO_RESET_MODIFIER_DEFAULTS[mod] = false
end

-- Float-safe CVar comparison (IEEE 754 precision workaround)
local function CvarMatch(current, recommended)
    if recommended == nil then
        return true
    end
    local numC, numR = tonumber(current), tonumber(recommended)
    if numC and numR then
        return math.abs(numC - numR) < 0.001
    end
    return current == recommended
end
D.CvarMatch = CvarMatch

-- CVar recommendations organized by section (213 entries, 13 sections)
D.CVAR_SECTIONS = {
    -- Section 1: Macro Sequencing
    {
        key = "macro_sequencing",
        label = L["GEMS_CVAR_SECTION_MACRO"],
        order = 1,
        cvars = {
            {
                cvar = "ActionButtonUseKeyDown",
                recommended = "1",
                label = L["GEMS_CVAR_MACRO_KEYDOWN"],
                desc = L["GEMS_CVAR_MACRO_KEYDOWN_DESC"],
                critical = true,
            },
            {
                cvar = "ActionButtonUseKeyHeldSpell",
                recommended = "0",
                label = L["GEMS_CVAR_MACRO_KEYHELD"],
                desc = L["GEMS_CVAR_MACRO_KEYHELD_DESC"],
                critical = false,
            },
            {
                cvar = "SpellQueueWindow",
                recommended = "400",
                label = L["GEMS_CVAR_MACRO_SPELLQUEUE"],
                desc = L["GEMS_CVAR_MACRO_SPELLQUEUE_DESC"],
                critical = true,
            },
            {
                cvar = "lockActionBars",
                recommended = "1",
                label = L["GEMS_CVAR_MACRO_LOCKBARS"],
                desc = L["GEMS_CVAR_MACRO_LOCKBARS_DESC"],
                critical = false,
            },
            {
                cvar = "enableMultiActionBars",
                recommended = nil,
                label = L["GEMS_CVAR_MACRO_MULTIBARS"],
                desc = L["GEMS_CVAR_MACRO_MULTIBARS_DESC"],
                critical = false,
            },
            {
                cvar = "AutoPushSpellToActionBar",
                recommended = "0",
                label = L["GEMS_CVAR_MACRO_AUTOPUSH"],
                desc = L["GEMS_CVAR_MACRO_AUTOPUSH_DESC"],
                critical = false,
            },
            {
                cvar = "autoSelfCast",
                recommended = "1",
                label = L["GEMS_CVAR_MACRO_SELFCAST"],
                desc = L["GEMS_CVAR_MACRO_SELFCAST_DESC"],
                critical = false,
            },
            {
                cvar = "autoStand",
                recommended = "1",
                label = L["GEMS_CVAR_MACRO_AUTOSTAND"],
                desc = L["GEMS_CVAR_MACRO_AUTOSTAND_DESC"],
                critical = false,
            },
            {
                cvar = "autoUnshift",
                recommended = "1",
                label = L["GEMS_CVAR_MACRO_AUTOUNSHIFT"],
                desc = L["GEMS_CVAR_MACRO_AUTOUNSHIFT_DESC"],
                critical = false,
            },
            {
                cvar = "stopAutoAttackOnTargetChange",
                recommended = "0",
                label = L["GEMS_CVAR_MACRO_STOPATTACK"],
                desc = L["GEMS_CVAR_MACRO_STOPATTACK_DESC"],
                critical = false,
            },
            {
                cvar = "assistedCombatIconUpdateRate",
                recommended = "0.05",
                label = L["GEMS_CVAR_MACRO_ICONRATE"],
                desc = L["GEMS_CVAR_MACRO_ICONRATE_DESC"],
                critical = false,
            },
            {
                cvar = "countdownForCooldowns",
                recommended = "1",
                label = L["GEMS_CVAR_MACRO_CDCOUNT"],
                desc = L["GEMS_CVAR_MACRO_CDCOUNT_DESC"],
                critical = false,
            },
            {
                cvar = "secureAbilityToggle",
                recommended = "1",
                label = L["GEMS_CVAR_MACRO_SECTOGGLE"],
                desc = L["GEMS_CVAR_MACRO_SECTOGGLE_DESC"],
                critical = false,
            },
            {
                cvar = "empowerTapControls",
                recommended = "0",
                label = L["GEMS_CVAR_MACRO_EMPTAP"],
                desc = L["GEMS_CVAR_MACRO_EMPTAP_DESC"],
                critical = false,
            },
            {
                cvar = "EmpowerMinHoldStagePercent",
                recommended = "1.0",
                label = L["GEMS_CVAR_MACRO_EMPHOLD"],
                desc = L["GEMS_CVAR_MACRO_EMPHOLD_DESC"],
                critical = false,
            },
            {
                cvar = "UseKeyHeldSpellErrorPollTime",
                recommended = "500",
                label = L["GEMS_CVAR_MACRO_HELDPOLL"],
                desc = L["GEMS_CVAR_MACRO_HELDPOLL_DESC"],
                critical = false,
            },
            {
                cvar = "PreemptiveCastEnable",
                recommended = "0",
                label = L["GEMS_CVAR_MACRO_PRECAST"],
                desc = L["GEMS_CVAR_MACRO_PRECAST_DESC"],
                critical = false,
            },
        },
    },
    -- Section 2: Combat & Targeting
    {
        key = "combat_targeting",
        label = L["GEMS_CVAR_SECTION_COMBAT"],
        order = 2,
        cvars = {
            {
                cvar = "SoftTargetEnemy",
                recommended = "3",
                label = L["GEMS_CVAR_COMBAT_SOFTENEMY"],
                desc = L["GEMS_CVAR_COMBAT_SOFTENEMY_DESC"],
                critical = true,
            },
            {
                cvar = "SoftTargetEnemyArc",
                recommended = "2",
                label = L["GEMS_CVAR_COMBAT_SOFTARC"],
                desc = L["GEMS_CVAR_COMBAT_SOFTARC_DESC"],
                critical = false,
            },
            {
                cvar = "SoftTargetEnemyRange",
                recommended = "45",
                label = L["GEMS_CVAR_COMBAT_SOFTRANGE"],
                desc = L["GEMS_CVAR_COMBAT_SOFTRANGE_DESC"],
                critical = false,
            },
            {
                cvar = "SoftTargetForce",
                recommended = "1",
                label = L["GEMS_CVAR_COMBAT_SOFTFORCE"],
                desc = L["GEMS_CVAR_COMBAT_SOFTFORCE_DESC"],
                critical = true,
            },
            {
                cvar = "SoftTargetFriend",
                recommended = "0",
                label = L["GEMS_CVAR_COMBAT_SOFTFRIEND"],
                desc = L["GEMS_CVAR_COMBAT_SOFTFRIEND_DESC"],
                critical = false,
            },
            {
                cvar = "SoftTargetWithLocked",
                recommended = "2",
                label = L["GEMS_CVAR_COMBAT_SOFTLOCKED"],
                desc = L["GEMS_CVAR_COMBAT_SOFTLOCKED_DESC"],
                critical = false,
            },
            {
                cvar = "SoftTargetMatchLocked",
                recommended = "1",
                label = L["GEMS_CVAR_COMBAT_SOFTMATCH"],
                desc = L["GEMS_CVAR_COMBAT_SOFTMATCH_DESC"],
                critical = false,
            },
            {
                cvar = "TargetNearestUseNew",
                recommended = "1",
                label = L["GEMS_CVAR_COMBAT_TABNEW"],
                desc = L["GEMS_CVAR_COMBAT_TABNEW_DESC"],
                critical = true,
            },
            {
                cvar = "TargetPriorityCombatLock",
                recommended = "1",
                label = L["GEMS_CVAR_COMBAT_COMBATLOCK"],
                desc = L["GEMS_CVAR_COMBAT_COMBATLOCK_DESC"],
                critical = false,
            },
            {
                cvar = "TargetPriorityCombatLockContextualRelaxation",
                recommended = "1",
                label = L["GEMS_CVAR_COMBAT_LOCKRELAX"],
                desc = L["GEMS_CVAR_COMBAT_LOCKRELAX_DESC"],
                critical = false,
            },
            {
                cvar = "TargetPriorityPvp",
                recommended = "1",
                label = L["GEMS_CVAR_COMBAT_PVPPRIO"],
                desc = L["GEMS_CVAR_COMBAT_PVPPRIO_DESC"],
                critical = false,
            },
            {
                cvar = "TargetEnemyAttacker",
                recommended = "1",
                label = L["GEMS_CVAR_COMBAT_ATTACKER"],
                desc = L["GEMS_CVAR_COMBAT_ATTACKER_DESC"],
                critical = false,
            },
            {
                cvar = "TargetAutoEnemy",
                recommended = "1",
                label = L["GEMS_CVAR_COMBAT_AUTOENEMY"],
                desc = L["GEMS_CVAR_COMBAT_AUTOENEMY_DESC"],
                critical = false,
            },
            {
                cvar = "deselectOnClick",
                recommended = "0",
                label = L["GEMS_CVAR_COMBAT_DESELECT"],
                desc = L["GEMS_CVAR_COMBAT_DESELECT_DESC"],
                critical = false,
            },
            {
                cvar = "interactOnLeftClick",
                recommended = "1",
                label = L["GEMS_CVAR_COMBAT_LEFTCLICK"],
                desc = L["GEMS_CVAR_COMBAT_LEFTCLICK_DESC"],
                critical = false,
            },
            {
                cvar = "assistedCombatHighlight",
                recommended = "0",
                label = L["GEMS_CVAR_COMBAT_HIGHLIGHT"],
                desc = L["GEMS_CVAR_COMBAT_HIGHLIGHT_DESC"],
                critical = false,
            },
            {
                cvar = "displaySpellActivationOverlays",
                recommended = "1",
                label = L["GEMS_CVAR_COMBAT_PROCS"],
                desc = L["GEMS_CVAR_COMBAT_PROCS_DESC"],
                critical = false,
            },
            {
                cvar = "spellActivationOverlayOpacity",
                recommended = "0.65",
                label = L["GEMS_CVAR_COMBAT_PROCOPACITY"],
                desc = L["GEMS_CVAR_COMBAT_PROCOPACITY_DESC"],
                critical = false,
            },
            {
                cvar = "lossOfControl",
                recommended = "1",
                label = L["GEMS_CVAR_COMBAT_LOC"],
                desc = L["GEMS_CVAR_COMBAT_LOC_DESC"],
                critical = false,
            },
            {
                cvar = "enableMouseoverCast",
                recommended = nil,
                label = L["GEMS_CVAR_COMBAT_MOUSEOVER"],
                desc = L["GEMS_CVAR_COMBAT_MOUSEOVER_DESC"],
                critical = false,
            },
            {
                cvar = "SoftTargetFriendArc",
                recommended = "2",
                label = L["GEMS_CVAR_COMBAT_FRIENDARC"],
                desc = L["GEMS_CVAR_COMBAT_FRIENDARC_DESC"],
                critical = false,
            },
            {
                cvar = "SoftTargetFriendRange",
                recommended = "45",
                label = L["GEMS_CVAR_COMBAT_FRIENDRANGE"],
                desc = L["GEMS_CVAR_COMBAT_FRIENDRANGE_DESC"],
                critical = false,
            },
        },
    },
    -- Section 3: Nameplates
    {
        key = "nameplates",
        label = L["GEMS_CVAR_SECTION_NAMEPLATES"],
        order = 3,
        cvars = {
            {
                cvar = "nameplateShowAll",
                recommended = "1",
                label = L["GEMS_CVAR_NAMEPLATES_SHOWALL"],
                desc = L["GEMS_CVAR_NAMEPLATES_SHOWALL_DESC"],
                critical = false,
            },
            {
                cvar = "nameplateShowEnemies",
                recommended = "1",
                label = L["GEMS_CVAR_NAMEPLATES_SHOWENEMY"],
                desc = L["GEMS_CVAR_NAMEPLATES_SHOWENEMY_DESC"],
                critical = true,
            },
            {
                cvar = "nameplateShowSelf",
                recommended = "1",
                label = L["GEMS_CVAR_NAMEPLATES_SHOWSELF"],
                desc = L["GEMS_CVAR_NAMEPLATES_SHOWSELF_DESC"],
                critical = false,
            },
            {
                cvar = "nameplateMaxDistance",
                recommended = "60",
                label = L["GEMS_CVAR_NAMEPLATES_MAXDIST"],
                desc = L["GEMS_CVAR_NAMEPLATES_MAXDIST_DESC"],
                critical = false,
            },
            {
                cvar = "nameplatePlayerMaxDistance",
                recommended = "60",
                label = L["GEMS_CVAR_NAMEPLATES_PLAYERDIST"],
                desc = L["GEMS_CVAR_NAMEPLATES_PLAYERDIST_DESC"],
                critical = false,
            },
            {
                cvar = "nameplateMinAlpha",
                recommended = "0.8",
                label = L["GEMS_CVAR_NAMEPLATES_MINALPHA"],
                desc = L["GEMS_CVAR_NAMEPLATES_MINALPHA_DESC"],
                critical = true,
            },
            {
                cvar = "nameplateMaxAlpha",
                recommended = "1.0",
                label = L["GEMS_CVAR_NAMEPLATES_MAXALPHA"],
                desc = L["GEMS_CVAR_NAMEPLATES_MAXALPHA_DESC"],
                critical = false,
            },
            {
                cvar = "nameplateMinScale",
                recommended = "0.8",
                label = L["GEMS_CVAR_NAMEPLATES_MINSCALE"],
                desc = L["GEMS_CVAR_NAMEPLATES_MINSCALE_DESC"],
                critical = false,
            },
            {
                cvar = "nameplateMaxScale",
                recommended = "1.0",
                label = L["GEMS_CVAR_NAMEPLATES_MAXSCALE"],
                desc = L["GEMS_CVAR_NAMEPLATES_MAXSCALE_DESC"],
                critical = false,
            },
            {
                cvar = "nameplateSelectedScale",
                recommended = "1.2",
                label = L["GEMS_CVAR_NAMEPLATES_SELSCALE"],
                desc = L["GEMS_CVAR_NAMEPLATES_SELSCALE_DESC"],
                critical = false,
            },
            {
                cvar = "nameplateOccludedAlphaMult",
                recommended = "0.6",
                label = L["GEMS_CVAR_NAMEPLATES_OCCLUDED"],
                desc = L["GEMS_CVAR_NAMEPLATES_OCCLUDED_DESC"],
                critical = true,
            },
            {
                cvar = "nameplateOverlapH",
                recommended = "0.8",
                label = L["GEMS_CVAR_NAMEPLATES_OVERLAPH"],
                desc = L["GEMS_CVAR_NAMEPLATES_OVERLAPH_DESC"],
                critical = false,
            },
            {
                cvar = "nameplateOverlapV",
                recommended = "1.1",
                label = L["GEMS_CVAR_NAMEPLATES_OVERLAPV"],
                desc = L["GEMS_CVAR_NAMEPLATES_OVERLAPV_DESC"],
                critical = false,
            },
            {
                cvar = "nameplateShowCastBars",
                recommended = "1",
                label = L["GEMS_CVAR_NAMEPLATES_CASTBARS"],
                desc = L["GEMS_CVAR_NAMEPLATES_CASTBARS_DESC"],
                critical = true,
            },
            {
                cvar = "nameplateShowClassColor",
                recommended = "1",
                label = L["GEMS_CVAR_NAMEPLATES_CLASSCOLOR"],
                desc = L["GEMS_CVAR_NAMEPLATES_CLASSCOLOR_DESC"],
                critical = false,
            },
            {
                cvar = "nameplateShowDebuffsOnFriendly",
                recommended = "1",
                label = L["GEMS_CVAR_NAMEPLATES_DEBUFFS"],
                desc = L["GEMS_CVAR_NAMEPLATES_DEBUFFS_DESC"],
                critical = false,
            },
            {
                cvar = "nameplateShowEnemyMinions",
                recommended = "0",
                label = L["GEMS_CVAR_NAMEPLATES_MINIONS"],
                desc = L["GEMS_CVAR_NAMEPLATES_MINIONS_DESC"],
                critical = false,
            },
            {
                cvar = "nameplateShowEnemyMinus",
                recommended = "1",
                label = L["GEMS_CVAR_NAMEPLATES_MINUS"],
                desc = L["GEMS_CVAR_NAMEPLATES_MINUS_DESC"],
                critical = false,
            },
            {
                cvar = "nameplateShowEnemyTotems",
                recommended = "1",
                label = L["GEMS_CVAR_NAMEPLATES_TOTEMS"],
                desc = L["GEMS_CVAR_NAMEPLATES_TOTEMS_DESC"],
                critical = false,
            },
            {
                cvar = "nameplateShowFriendlyPlayers",
                recommended = "0",
                label = L["GEMS_CVAR_NAMEPLATES_FRIENDLY"],
                desc = L["GEMS_CVAR_NAMEPLATES_FRIENDLY_DESC"],
                critical = false,
            },
            {
                cvar = "nameplateAuraScale",
                recommended = "1.2",
                label = L["GEMS_CVAR_NAMEPLATES_AURASCALE"],
                desc = L["GEMS_CVAR_NAMEPLATES_AURASCALE_DESC"],
                critical = false,
            },
            {
                cvar = "nameplateShowOnlyNameForFriendlyPlayerUnits",
                recommended = "0",
                label = L["GEMS_CVAR_NAMEPLATES_NAMEONLY"],
                desc = L["GEMS_CVAR_NAMEPLATES_NAMEONLY_DESC"],
                critical = false,
            },
            {
                cvar = "nameplateOtherAtBase",
                recommended = "0",
                label = L["GEMS_CVAR_NAMEPLATES_ATBASE"],
                desc = L["GEMS_CVAR_NAMEPLATES_ATBASE_DESC"],
                critical = false,
            },
            {
                cvar = "nameplateShowOffscreen",
                recommended = "0",
                label = L["GEMS_CVAR_NAMEPLATES_OFFSCREEN"],
                desc = L["GEMS_CVAR_NAMEPLATES_OFFSCREEN_DESC"],
                critical = false,
            },
            {
                cvar = "nameplateTargetRadialPosition",
                recommended = "0",
                label = L["GEMS_CVAR_NAMEPLATES_RADIAL"],
                desc = L["GEMS_CVAR_NAMEPLATES_RADIAL_DESC"],
                critical = false,
            },
            {
                cvar = "SoftTargetNameplateEnemy",
                recommended = "1",
                label = L["GEMS_CVAR_NAMEPLATES_SOFTNP"],
                desc = L["GEMS_CVAR_NAMEPLATES_SOFTNP_DESC"],
                critical = false,
            },
            {
                cvar = "SoftTargetNameplateSize",
                recommended = "25",
                label = L["GEMS_CVAR_NAMEPLATES_SOFTSIZE"],
                desc = L["GEMS_CVAR_NAMEPLATES_SOFTSIZE_DESC"],
                critical = false,
            },
            {
                cvar = "nameplateDebuffPadding",
                recommended = "0",
                label = L["GEMS_CVAR_NAMEPLATES_DEBUFFPAD"],
                desc = L["GEMS_CVAR_NAMEPLATES_DEBUFFPAD_DESC"],
                critical = false,
            },
            {
                cvar = "nameplateMotion",
                recommended = "2",
                label = L["GEMS_CVAR_NAMEPLATES_MOTION"],
                desc = L["GEMS_CVAR_NAMEPLATES_MOTION_DESC"],
                critical = false,
            },
            {
                cvar = "nameplateMotionSpeed",
                recommended = "0.025",
                label = L["GEMS_CVAR_NAMEPLATES_MOTIONSPD"],
                desc = L["GEMS_CVAR_NAMEPLATES_MOTIONSPD_DESC"],
                critical = false,
            },
        },
    },
    -- Section 4: Raiding
    {
        key = "raiding",
        label = L["GEMS_CVAR_SECTION_RAIDING"],
        order = 4,
        cvars = {
            {
                cvar = "advancedCombatLogging",
                recommended = "1",
                label = L["GEMS_CVAR_RAIDING_COMBATLOG"],
                desc = L["GEMS_CVAR_RAIDING_COMBATLOG_DESC"],
                critical = true,
            },
            {
                cvar = "threatWarning",
                recommended = "3",
                label = L["GEMS_CVAR_RAIDING_THREATWARN"],
                desc = L["GEMS_CVAR_RAIDING_THREATWARN_DESC"],
                critical = false,
            },
            {
                cvar = "threatShowNumeric",
                recommended = "1",
                label = L["GEMS_CVAR_RAIDING_THREATNUM"],
                desc = L["GEMS_CVAR_RAIDING_THREATNUM_DESC"],
                critical = false,
            },
            {
                cvar = "threatPlaySounds",
                recommended = "1",
                label = L["GEMS_CVAR_RAIDING_THREATSOUND"],
                desc = L["GEMS_CVAR_RAIDING_THREATSOUND_DESC"],
                critical = false,
            },
            {
                cvar = "threatWorldText",
                recommended = "1",
                label = L["GEMS_CVAR_RAIDING_THREATTEXT"],
                desc = L["GEMS_CVAR_RAIDING_THREATTEXT_DESC"],
                critical = false,
            },
            {
                cvar = "encounterTimelineEnabled",
                recommended = "1",
                label = L["GEMS_CVAR_RAIDING_TIMELINE"],
                desc = L["GEMS_CVAR_RAIDING_TIMELINE_DESC"],
                critical = false,
            },
            {
                cvar = "encounterTimelineHideForOtherRoles",
                recommended = "1",
                label = L["GEMS_CVAR_RAIDING_TIMEROLE"],
                desc = L["GEMS_CVAR_RAIDING_TIMEROLE_DESC"],
                critical = false,
            },
            {
                cvar = "encounterWarningsEnabled",
                recommended = "1",
                label = L["GEMS_CVAR_RAIDING_WARNINGS"],
                desc = L["GEMS_CVAR_RAIDING_WARNINGS_DESC"],
                critical = false,
            },
            {
                cvar = "encounterWarningsHideIfNotTargetingPlayer",
                recommended = "0",
                label = L["GEMS_CVAR_RAIDING_WARNHIDE"],
                desc = L["GEMS_CVAR_RAIDING_WARNHIDE_DESC"],
                critical = false,
            },
            {
                cvar = "raidFramesDisplayAggroHighlight",
                recommended = "1",
                label = L["GEMS_CVAR_RAIDING_AGGRO"],
                desc = L["GEMS_CVAR_RAIDING_AGGRO_DESC"],
                critical = false,
            },
            {
                cvar = "raidFramesDisplayDebuffs",
                recommended = "1",
                label = L["GEMS_CVAR_RAIDING_RDEBUFFS"],
                desc = L["GEMS_CVAR_RAIDING_RDEBUFFS_DESC"],
                critical = false,
            },
            {
                cvar = "raidFramesDisplayIncomingHeals",
                recommended = "1",
                label = L["GEMS_CVAR_RAIDING_HEALPRED"],
                desc = L["GEMS_CVAR_RAIDING_HEALPRED_DESC"],
                critical = false,
            },
            {
                cvar = "raidFramesDisplayPowerBars",
                recommended = "0",
                label = L["GEMS_CVAR_RAIDING_POWERBARS"],
                desc = L["GEMS_CVAR_RAIDING_POWERBARS_DESC"],
                critical = false,
            },
            {
                cvar = "raidFramesDisplayClassColor",
                recommended = "1",
                label = L["GEMS_CVAR_RAIDING_RCLASSCOLOR"],
                desc = L["GEMS_CVAR_RAIDING_RCLASSCOLOR_DESC"],
                critical = false,
            },
            {
                cvar = "raidFramesDisplayOnlyDispellableDebuffs",
                recommended = "0",
                label = L["GEMS_CVAR_RAIDING_DISPONLY"],
                desc = L["GEMS_CVAR_RAIDING_DISPONLY_DESC"],
                critical = false,
            },
            {
                cvar = "raidFramesDisplayLargerRoleSpecificDebuffs",
                recommended = "1",
                label = L["GEMS_CVAR_RAIDING_ROLEDEBUFF"],
                desc = L["GEMS_CVAR_RAIDING_ROLEDEBUFF_DESC"],
                critical = false,
            },
            {
                cvar = "raidFramesCenterBigDefensive",
                recommended = "1",
                label = L["GEMS_CVAR_RAIDING_BIGDEF"],
                desc = L["GEMS_CVAR_RAIDING_BIGDEF_DESC"],
                critical = false,
            },
            {
                cvar = "raidFramesDispelIndicatorType",
                recommended = "2",
                label = L["GEMS_CVAR_RAIDING_DISPTYPE"],
                desc = L["GEMS_CVAR_RAIDING_DISPTYPE_DESC"],
                critical = false,
            },
            {
                cvar = "raidFramesHealthText",
                recommended = "none",
                label = L["GEMS_CVAR_RAIDING_HEALTHTEXT"],
                desc = L["GEMS_CVAR_RAIDING_HEALTHTEXT_DESC"],
                critical = false,
            },
            {
                cvar = "raidOptionSortMode",
                recommended = "role",
                label = L["GEMS_CVAR_RAIDING_SORTMODE"],
                desc = L["GEMS_CVAR_RAIDING_SORTMODE_DESC"],
                critical = false,
            },
            {
                cvar = "raidOptionKeepGroupsTogether",
                recommended = "0",
                label = L["GEMS_CVAR_RAIDING_KEEPGRP"],
                desc = L["GEMS_CVAR_RAIDING_KEEPGRP_DESC"],
                critical = false,
            },
            {
                cvar = "raidOptionDisplayMainTankAndAssist",
                recommended = "1",
                label = L["GEMS_CVAR_RAIDING_TANKASSIST"],
                desc = L["GEMS_CVAR_RAIDING_TANKASSIST_DESC"],
                critical = false,
            },
            {
                cvar = "findYourselfInRaid",
                recommended = "1",
                label = L["GEMS_CVAR_RAIDING_FINDSELF"],
                desc = L["GEMS_CVAR_RAIDING_FINDSELF_DESC"],
                critical = false,
            },
            {
                cvar = "showCastableBuffs",
                recommended = "0",
                label = L["GEMS_CVAR_RAIDING_CASTBUFFS"],
                desc = L["GEMS_CVAR_RAIDING_CASTBUFFS_DESC"],
                critical = false,
            },
            {
                cvar = "showDispelDebuffs",
                recommended = "1",
                label = L["GEMS_CVAR_RAIDING_DISPDEBUFFS"],
                desc = L["GEMS_CVAR_RAIDING_DISPDEBUFFS_DESC"],
                critical = false,
            },
            {
                cvar = "RAIDsettingsEnabled",
                recommended = "1",
                label = L["GEMS_CVAR_RAIDING_RAIDSETTINGS"],
                desc = L["GEMS_CVAR_RAIDING_RAIDSETTINGS_DESC"],
                critical = true,
            },
            {
                cvar = "noBuffDebuffFilterOnTarget",
                recommended = "0",
                label = L["GEMS_CVAR_RAIDING_NOFILTER"],
                desc = L["GEMS_CVAR_RAIDING_NOFILTER_DESC"],
                critical = false,
            },
            {
                cvar = "spellClutter",
                recommended = "1",
                label = L["GEMS_CVAR_RAIDING_SPELLCLUTTER"],
                desc = L["GEMS_CVAR_RAIDING_SPELLCLUTTER_DESC"],
                critical = false,
            },
            {
                cvar = "emphasizeMySpellEffects",
                recommended = "1",
                label = L["GEMS_CVAR_RAIDING_MYSPELLS"],
                desc = L["GEMS_CVAR_RAIDING_MYSPELLS_DESC"],
                critical = false,
            },
            {
                cvar = "combatWarningsEnabled",
                recommended = "1",
                label = L["GEMS_CVAR_RAIDING_COMBATWARN"],
                desc = L["GEMS_CVAR_RAIDING_COMBATWARN_DESC"],
                critical = false,
            },
        },
    },
    -- Section 5: Dungeons
    {
        key = "dungeons",
        label = L["GEMS_CVAR_SECTION_DUNGEON"],
        order = 5,
        cvars = {
            {
                cvar = "damageMeterResetOnNewInstance",
                recommended = "1",
                label = L["GEMS_CVAR_DUNGEON_DPSRESET"],
                desc = L["GEMS_CVAR_DUNGEON_DPSRESET_DESC"],
                critical = false,
            },
            {
                cvar = "showDungeonEntrancesOnMap",
                recommended = "1",
                label = L["GEMS_CVAR_DUNGEON_ENTRANCE"],
                desc = L["GEMS_CVAR_DUNGEON_ENTRANCE_DESC"],
                critical = false,
            },
            {
                cvar = "unitClutterInstancesOnly",
                recommended = "1",
                label = L["GEMS_CVAR_DUNGEON_CLUTTER"],
                desc = L["GEMS_CVAR_DUNGEON_CLUTTER_DESC"],
                critical = false,
            },
            {
                cvar = "showArenaEnemyCastbar",
                recommended = "1",
                label = L["GEMS_CVAR_DUNGEON_ENEMYCAST"],
                desc = L["GEMS_CVAR_DUNGEON_ENEMYCAST_DESC"],
                critical = false,
            },
            {
                cvar = "combatLogRetentionTime",
                recommended = "300",
                label = L["GEMS_CVAR_DUNGEON_LOGTIME"],
                desc = L["GEMS_CVAR_DUNGEON_LOGTIME_DESC"],
                critical = false,
            },
            {
                cvar = "combatLogUniqueFilename",
                recommended = "1",
                label = L["GEMS_CVAR_DUNGEON_LOGFILE"],
                desc = L["GEMS_CVAR_DUNGEON_LOGFILE_DESC"],
                critical = false,
            },
            {
                cvar = "spellDiminishPVPEnemiesEnabled",
                recommended = "1",
                label = L["GEMS_CVAR_DUNGEON_DIMINISH"],
                desc = L["GEMS_CVAR_DUNGEON_DIMINISH_DESC"],
                critical = false,
            },
        },
    },
    -- Section 6: Solo Play
    {
        key = "solo_play",
        label = L["GEMS_CVAR_SECTION_SOLO"],
        order = 6,
        cvars = {
            {
                cvar = "autoLootDefault",
                recommended = "1",
                label = L["GEMS_CVAR_SOLO_AUTOLOOT"],
                desc = L["GEMS_CVAR_SOLO_AUTOLOOT_DESC"],
                critical = true,
            },
            {
                cvar = "autoLootRate",
                recommended = "50",
                label = L["GEMS_CVAR_SOLO_LOOTRATE"],
                desc = L["GEMS_CVAR_SOLO_LOOTRATE_DESC"],
                critical = false,
            },
            {
                cvar = "lootUnderMouse",
                recommended = "1",
                label = L["GEMS_CVAR_SOLO_LOOTMOUSE"],
                desc = L["GEMS_CVAR_SOLO_LOOTMOUSE_DESC"],
                critical = false,
            },
            {
                cvar = "disableAELooting",
                recommended = "0",
                label = L["GEMS_CVAR_SOLO_AELOOT"],
                desc = L["GEMS_CVAR_SOLO_AELOOT_DESC"],
                critical = false,
            },
            {
                cvar = "autoDismount",
                recommended = "1",
                label = L["GEMS_CVAR_SOLO_DISMOUNT"],
                desc = L["GEMS_CVAR_SOLO_DISMOUNT_DESC"],
                critical = false,
            },
            {
                cvar = "autoDismountFlying",
                recommended = "0",
                label = L["GEMS_CVAR_SOLO_DISMOUNTFLY"],
                desc = L["GEMS_CVAR_SOLO_DISMOUNTFLY_DESC"],
                critical = false,
            },
            {
                cvar = "showTargetOfTarget",
                recommended = "1",
                label = L["GEMS_CVAR_SOLO_TOT"],
                desc = L["GEMS_CVAR_SOLO_TOT_DESC"],
                critical = false,
            },
            {
                cvar = "showTargetCastbar",
                recommended = "1",
                label = L["GEMS_CVAR_SOLO_TCASTBAR"],
                desc = L["GEMS_CVAR_SOLO_TCASTBAR_DESC"],
                critical = false,
            },
            {
                cvar = "autoQuestWatch",
                recommended = "1",
                label = L["GEMS_CVAR_SOLO_QUESTWATCH"],
                desc = L["GEMS_CVAR_SOLO_QUESTWATCH_DESC"],
                critical = false,
            },
            {
                cvar = "questPOI",
                recommended = "1",
                label = L["GEMS_CVAR_SOLO_QUESTPOI"],
                desc = L["GEMS_CVAR_SOLO_QUESTPOI_DESC"],
                critical = false,
            },
            {
                cvar = "showPartyPets",
                recommended = "0",
                label = L["GEMS_CVAR_SOLO_PARTYPETS"],
                desc = L["GEMS_CVAR_SOLO_PARTYPETS_DESC"],
                critical = false,
            },
            {
                cvar = "SoftTargetInteract",
                recommended = "3",
                label = L["GEMS_CVAR_SOLO_INTERACT"],
                desc = L["GEMS_CVAR_SOLO_INTERACT_DESC"],
                critical = false,
            },
            {
                cvar = "SoftTargetInteractArc",
                recommended = "1",
                label = L["GEMS_CVAR_SOLO_INTERARC"],
                desc = L["GEMS_CVAR_SOLO_INTERARC_DESC"],
                critical = false,
            },
            {
                cvar = "SoftTargetInteractRange",
                recommended = "10",
                label = L["GEMS_CVAR_SOLO_INTERRANGE"],
                desc = L["GEMS_CVAR_SOLO_INTERRANGE_DESC"],
                critical = false,
            },
            {
                cvar = "SoftTargetIconInteract",
                recommended = "1",
                label = L["GEMS_CVAR_SOLO_INTERICON"],
                desc = L["GEMS_CVAR_SOLO_INTERICON_DESC"],
                critical = false,
            },
            {
                cvar = "autoInteract",
                recommended = "0",
                label = L["GEMS_CVAR_SOLO_AUTOINTER"],
                desc = L["GEMS_CVAR_SOLO_AUTOINTER_DESC"],
                critical = false,
            },
            {
                cvar = "interactQuestItems",
                recommended = "1",
                label = L["GEMS_CVAR_SOLO_QUESTITEMS"],
                desc = L["GEMS_CVAR_SOLO_QUESTITEMS_DESC"],
                critical = false,
            },
        },
    },
    -- Section 7: UI & Quality of Life
    {
        key = "ui_qol",
        label = L["GEMS_CVAR_SECTION_UI"],
        order = 7,
        cvars = {
            {
                cvar = "showTutorials",
                recommended = "0",
                label = L["GEMS_CVAR_UI_TUTORIALS"],
                desc = L["GEMS_CVAR_UI_TUTORIALS_DESC"],
                critical = false,
            },
            {
                cvar = "showNPETutorials",
                recommended = "0",
                label = L["GEMS_CVAR_UI_NPE"],
                desc = L["GEMS_CVAR_UI_NPE_DESC"],
                critical = false,
            },
            {
                cvar = "showLoadingScreenTips",
                recommended = "1",
                label = L["GEMS_CVAR_UI_LOADTIPS"],
                desc = L["GEMS_CVAR_UI_LOADTIPS_DESC"],
                critical = false,
            },
            {
                cvar = "alwaysCompareItems",
                recommended = "1",
                label = L["GEMS_CVAR_UI_COMPARE"],
                desc = L["GEMS_CVAR_UI_COMPARE_DESC"],
                critical = false,
            },
            {
                cvar = "UberTooltips",
                recommended = "1",
                label = L["GEMS_CVAR_UI_TOOLTIPS"],
                desc = L["GEMS_CVAR_UI_TOOLTIPS_DESC"],
                critical = false,
            },
            {
                cvar = "missingTransmogSourceInItemTooltips",
                recommended = "1",
                label = L["GEMS_CVAR_UI_TRANSMOG"],
                desc = L["GEMS_CVAR_UI_TRANSMOG_DESC"],
                critical = false,
            },
            {
                cvar = "screenshotFormat",
                recommended = "tga",
                label = L["GEMS_CVAR_UI_SSFORMAT"],
                desc = L["GEMS_CVAR_UI_SSFORMAT_DESC"],
                critical = false,
            },
            {
                cvar = "screenshotQuality",
                recommended = "10",
                label = L["GEMS_CVAR_UI_SSQUALITY"],
                desc = L["GEMS_CVAR_UI_SSQUALITY_DESC"],
                critical = false,
            },
            {
                cvar = "cameraDistanceMaxZoomFactor",
                recommended = "2.6",
                label = L["GEMS_CVAR_UI_ZOOM"],
                desc = L["GEMS_CVAR_UI_ZOOM_DESC"],
                critical = false,
            },
            {
                cvar = "screenEdgeFlash",
                recommended = "1",
                label = L["GEMS_CVAR_UI_EDGEFLASH"],
                desc = L["GEMS_CVAR_UI_EDGEFLASH_DESC"],
                critical = false,
            },
            {
                cvar = "chatBubbles",
                recommended = "1",
                label = L["GEMS_CVAR_UI_BUBBLES"],
                desc = L["GEMS_CVAR_UI_BUBBLES_DESC"],
                critical = false,
            },
            {
                cvar = "breakUpLargeNumbers",
                recommended = "1",
                label = L["GEMS_CVAR_UI_BIGNUMS"],
                desc = L["GEMS_CVAR_UI_BIGNUMS_DESC"],
                critical = false,
            },
            {
                cvar = "buffDurations",
                recommended = "1",
                label = L["GEMS_CVAR_UI_BUFFDUR"],
                desc = L["GEMS_CVAR_UI_BUFFDUR_DESC"],
                critical = false,
            },
            {
                cvar = "comboPointLocation",
                recommended = "2",
                label = L["GEMS_CVAR_UI_COMBOPT"],
                desc = L["GEMS_CVAR_UI_COMBOPT_DESC"],
                critical = false,
            },
            {
                cvar = "fstack_enabled",
                recommended = "0",
                label = L["GEMS_CVAR_UI_FSTACK"],
                desc = L["GEMS_CVAR_UI_FSTACK_DESC"],
                critical = false,
            },
            {
                cvar = "rawMouseEnable",
                recommended = "0",
                label = L["GEMS_CVAR_UI_RAWMOUSE"],
                desc = L["GEMS_CVAR_UI_RAWMOUSE_DESC"],
                critical = false,
            },
            {
                cvar = "taintLog",
                recommended = "0",
                label = L["GEMS_CVAR_UI_TAINT"],
                desc = L["GEMS_CVAR_UI_TAINT_DESC"],
                critical = false,
            },
            {
                cvar = "combinedBags",
                recommended = "1",
                label = L["GEMS_CVAR_UI_BAGS"],
                desc = L["GEMS_CVAR_UI_BAGS_DESC"],
                critical = false,
            },
            {
                cvar = "rotateMinimap",
                recommended = "0",
                label = L["GEMS_CVAR_UI_ROTATEMM"],
                desc = L["GEMS_CVAR_UI_ROTATEMM_DESC"],
                critical = false,
            },
        },
    },
    -- Section 8: FPS & Performance
    {
        key = "fps_performance",
        label = L["GEMS_CVAR_SECTION_FPS"],
        order = 8,
        cvars = {
            {
                cvar = "maxFPS",
                recommended = nil,
                label = L["GEMS_CVAR_FPS_MAXFPS"],
                desc = L["GEMS_CVAR_FPS_MAXFPS_DESC"],
                critical = false,
            },
            {
                cvar = "maxFPSBk",
                recommended = "30",
                label = L["GEMS_CVAR_FPS_BGFPS"],
                desc = L["GEMS_CVAR_FPS_BGFPS_DESC"],
                critical = false,
            },
            {
                cvar = "maxFPSLoading",
                recommended = "10",
                label = L["GEMS_CVAR_FPS_LOADFPS"],
                desc = L["GEMS_CVAR_FPS_LOADFPS_DESC"],
                critical = false,
            },
            {
                cvar = "useMaxFPS",
                recommended = "1",
                label = L["GEMS_CVAR_FPS_USEMAXFPS"],
                desc = L["GEMS_CVAR_FPS_USEMAXFPS_DESC"],
                critical = false,
            },
            {
                cvar = "vsync",
                recommended = "0",
                label = L["GEMS_CVAR_FPS_VSYNC"],
                desc = L["GEMS_CVAR_FPS_VSYNC_DESC"],
                critical = false,
            },
            {
                cvar = "targetFPS",
                recommended = "60",
                label = L["GEMS_CVAR_FPS_TARGETFPS"],
                desc = L["GEMS_CVAR_FPS_TARGETFPS_DESC"],
                critical = false,
            },
            {
                cvar = "useTargetFPS",
                recommended = "0",
                label = L["GEMS_CVAR_FPS_USETARGET"],
                desc = L["GEMS_CVAR_FPS_USETARGET_DESC"],
                critical = false,
            },
            {
                cvar = "GxMaxFrameLatency",
                recommended = "1",
                label = L["GEMS_CVAR_FPS_LATENCY"],
                desc = L["GEMS_CVAR_FPS_LATENCY_DESC"],
                critical = true,
            },
            {
                cvar = "RenderScale",
                recommended = "1.0",
                label = L["GEMS_CVAR_FPS_RSCALE"],
                desc = L["GEMS_CVAR_FPS_RSCALE_DESC"],
                critical = false,
            },
            {
                cvar = "DynamicRenderScale",
                recommended = "0",
                label = L["GEMS_CVAR_FPS_DYNSCALE"],
                desc = L["GEMS_CVAR_FPS_DYNSCALE_DESC"],
                critical = false,
            },
            {
                cvar = "LowLatencyMode",
                recommended = nil,
                label = L["GEMS_CVAR_FPS_LOWLAT"],
                desc = L["GEMS_CVAR_FPS_LOWLAT_DESC"],
                critical = false,
            },
            {
                cvar = "GxCompatCommandListMultiThreading",
                recommended = "1",
                label = L["GEMS_CVAR_FPS_MULTITHREAD"],
                desc = L["GEMS_CVAR_FPS_MULTITHREAD_DESC"],
                critical = true,
            },
            {
                cvar = "spellClutter",
                recommended = "1",
                label = L["GEMS_CVAR_FPS_SPELLCLUTTER"],
                desc = L["GEMS_CVAR_FPS_SPELLCLUTTER_DESC"],
                critical = false,
            },
            {
                cvar = "particleDensity",
                recommended = "50",
                label = L["GEMS_CVAR_FPS_PARTICLES"],
                desc = L["GEMS_CVAR_FPS_PARTICLES_DESC"],
                critical = false,
            },
            {
                cvar = "weatherDensity",
                recommended = "1",
                label = L["GEMS_CVAR_FPS_WEATHER"],
                desc = L["GEMS_CVAR_FPS_WEATHER_DESC"],
                critical = false,
            },
            {
                cvar = "animFrameSkipLOD",
                recommended = "1",
                label = L["GEMS_CVAR_FPS_ANIMLOD"],
                desc = L["GEMS_CVAR_FPS_ANIMLOD_DESC"],
                critical = false,
            },
            {
                cvar = "spellVisualDensityFilterSetting",
                recommended = "1",
                label = L["GEMS_CVAR_FPS_VFXDENSITY"],
                desc = L["GEMS_CVAR_FPS_VFXDENSITY_DESC"],
                critical = false,
            },
        },
    },
    -- Section 9: Visual Quality
    {
        key = "visual_quality",
        label = L["GEMS_CVAR_SECTION_VISUAL"],
        order = 9,
        cvars = {
            {
                cvar = "graphicsQuality",
                recommended = nil,
                label = L["GEMS_CVAR_VISUAL_QUALITY"],
                desc = L["GEMS_CVAR_VISUAL_QUALITY_DESC"],
                critical = false,
            },
            {
                cvar = "graphicsShadowQuality",
                recommended = "3",
                label = L["GEMS_CVAR_VISUAL_SHADOWS"],
                desc = L["GEMS_CVAR_VISUAL_SHADOWS_DESC"],
                critical = false,
            },
            {
                cvar = "graphicsSSAO",
                recommended = "3",
                label = L["GEMS_CVAR_VISUAL_SSAO"],
                desc = L["GEMS_CVAR_VISUAL_SSAO_DESC"],
                critical = false,
            },
            {
                cvar = "graphicsViewDistance",
                recommended = "5",
                label = L["GEMS_CVAR_VISUAL_VIEWDIST"],
                desc = L["GEMS_CVAR_VISUAL_VIEWDIST_DESC"],
                critical = false,
            },
            {
                cvar = "graphicsGroundClutter",
                recommended = "3",
                label = L["GEMS_CVAR_VISUAL_GROUND"],
                desc = L["GEMS_CVAR_VISUAL_GROUND_DESC"],
                critical = false,
            },
            {
                cvar = "graphicsTextureResolution",
                recommended = "2",
                label = L["GEMS_CVAR_VISUAL_TEXRES"],
                desc = L["GEMS_CVAR_VISUAL_TEXRES_DESC"],
                critical = false,
            },
            {
                cvar = "graphicsLiquidDetail",
                recommended = "1",
                label = L["GEMS_CVAR_VISUAL_LIQUID"],
                desc = L["GEMS_CVAR_VISUAL_LIQUID_DESC"],
                critical = false,
            },
            {
                cvar = "graphicsProjectedTextures",
                recommended = "1",
                label = L["GEMS_CVAR_VISUAL_PROJTEX"],
                desc = L["GEMS_CVAR_VISUAL_PROJTEX_DESC"],
                critical = true,
            },
            {
                cvar = "graphicsOutlineMode",
                recommended = "2",
                label = L["GEMS_CVAR_VISUAL_OUTLINE"],
                desc = L["GEMS_CVAR_VISUAL_OUTLINE_DESC"],
                critical = false,
            },
            {
                cvar = "ffxAntiAliasingMode",
                recommended = "3",
                label = L["GEMS_CVAR_VISUAL_AA"],
                desc = L["GEMS_CVAR_VISUAL_AA_DESC"],
                critical = false,
            },
            {
                cvar = "ffxGlow",
                recommended = "1",
                label = L["GEMS_CVAR_VISUAL_GLOW"],
                desc = L["GEMS_CVAR_VISUAL_GLOW_DESC"],
                critical = false,
            },
            {
                cvar = "ffxDeath",
                recommended = "1",
                label = L["GEMS_CVAR_VISUAL_DEATH"],
                desc = L["GEMS_CVAR_VISUAL_DEATH_DESC"],
                critical = false,
            },
            {
                cvar = "ResampleAlwaysSharpen",
                recommended = "1",
                label = L["GEMS_CVAR_VISUAL_SHARPEN"],
                desc = L["GEMS_CVAR_VISUAL_SHARPEN_DESC"],
                critical = false,
            },
            {
                cvar = "ResampleSharpness",
                recommended = "0.2",
                label = L["GEMS_CVAR_VISUAL_SHARPNESS"],
                desc = L["GEMS_CVAR_VISUAL_SHARPNESS_DESC"],
                critical = false,
            },
            {
                cvar = "farclip",
                recommended = "800",
                label = L["GEMS_CVAR_VISUAL_FARCLIP"],
                desc = L["GEMS_CVAR_VISUAL_FARCLIP_DESC"],
                critical = false,
            },
        },
    },
    -- Section 10: Sound
    {
        key = "sound",
        label = L["GEMS_CVAR_SECTION_SOUND"],
        order = 10,
        cvars = {
            {
                cvar = "Sound_EnableAllSound",
                recommended = "1",
                label = L["GEMS_CVAR_SOUND_MASTER"],
                desc = L["GEMS_CVAR_SOUND_MASTER_DESC"],
                critical = true,
            },
            {
                cvar = "Sound_MasterVolume",
                recommended = "0.8",
                label = L["GEMS_CVAR_SOUND_MASTERVOL"],
                desc = L["GEMS_CVAR_SOUND_MASTERVOL_DESC"],
                critical = false,
            },
            {
                cvar = "Sound_SFXVolume",
                recommended = "1.0",
                label = L["GEMS_CVAR_SOUND_SFX"],
                desc = L["GEMS_CVAR_SOUND_SFX_DESC"],
                critical = false,
            },
            {
                cvar = "Sound_MusicVolume",
                recommended = "0.2",
                label = L["GEMS_CVAR_SOUND_MUSIC"],
                desc = L["GEMS_CVAR_SOUND_MUSIC_DESC"],
                critical = false,
            },
            {
                cvar = "Sound_AmbienceVolume",
                recommended = "0.3",
                label = L["GEMS_CVAR_SOUND_AMBIENCE"],
                desc = L["GEMS_CVAR_SOUND_AMBIENCE_DESC"],
                critical = false,
            },
            {
                cvar = "Sound_DialogVolume",
                recommended = "1.0",
                label = L["GEMS_CVAR_SOUND_DIALOG"],
                desc = L["GEMS_CVAR_SOUND_DIALOG_DESC"],
                critical = false,
            },
            {
                cvar = "Sound_EnableSoundWhenGameIsInBG",
                recommended = "1",
                label = L["GEMS_CVAR_SOUND_BGAUDIO"],
                desc = L["GEMS_CVAR_SOUND_BGAUDIO_DESC"],
                critical = false,
            },
            {
                cvar = "Sound_EnableEncounterWarningsSounds",
                recommended = "1",
                label = L["GEMS_CVAR_SOUND_ENCWARN"],
                desc = L["GEMS_CVAR_SOUND_ENCWARN_DESC"],
                critical = false,
            },
            {
                cvar = "Sound_EncounterWarningsVolume",
                recommended = "1.0",
                label = L["GEMS_CVAR_SOUND_ENCVOL"],
                desc = L["GEMS_CVAR_SOUND_ENCVOL_DESC"],
                critical = false,
            },
            {
                cvar = "Sound_EnableErrorSpeech",
                recommended = "0",
                label = L["GEMS_CVAR_SOUND_ERRSPEECH"],
                desc = L["GEMS_CVAR_SOUND_ERRSPEECH_DESC"],
                critical = false,
            },
            {
                cvar = "Sound_EnableGameplaySFX",
                recommended = "1",
                label = L["GEMS_CVAR_SOUND_GAMEPLAY"],
                desc = L["GEMS_CVAR_SOUND_GAMEPLAY_DESC"],
                critical = false,
            },
        },
    },
    -- Section 11: Floating Combat Text
    {
        key = "floating_combat_text",
        label = L["GEMS_CVAR_SECTION_FCT"],
        order = 11,
        cvars = {
            {
                cvar = "enableFloatingCombatText",
                recommended = "1",
                label = L["GEMS_CVAR_FCT_ENABLE"],
                desc = L["GEMS_CVAR_FCT_ENABLE_DESC"],
                critical = false,
            },
            {
                cvar = "floatingCombatTextCombatDamage_v2",
                recommended = "1",
                label = L["GEMS_CVAR_FCT_DAMAGE"],
                desc = L["GEMS_CVAR_FCT_DAMAGE_DESC"],
                critical = false,
            },
            {
                cvar = "floatingCombatTextCombatDamageAllAutos_v2",
                recommended = "1",
                label = L["GEMS_CVAR_FCT_AUTOS"],
                desc = L["GEMS_CVAR_FCT_AUTOS_DESC"],
                critical = false,
            },
            {
                cvar = "floatingCombatTextCombatHealing_v2",
                recommended = "1",
                label = L["GEMS_CVAR_FCT_HEALING"],
                desc = L["GEMS_CVAR_FCT_HEALING_DESC"],
                critical = false,
            },
            {
                cvar = "floatingCombatTextCombatHealingAbsorbSelf_v2",
                recommended = "1",
                label = L["GEMS_CVAR_FCT_ABSSELF"],
                desc = L["GEMS_CVAR_FCT_ABSSELF_DESC"],
                critical = false,
            },
            {
                cvar = "floatingCombatTextCombatHealingAbsorbTarget_v2",
                recommended = "1",
                label = L["GEMS_CVAR_FCT_ABSTARGET"],
                desc = L["GEMS_CVAR_FCT_ABSTARGET_DESC"],
                critical = false,
            },
            {
                cvar = "floatingCombatTextCombatLogPeriodicSpells_v2",
                recommended = "1",
                label = L["GEMS_CVAR_FCT_PERIODIC"],
                desc = L["GEMS_CVAR_FCT_PERIODIC_DESC"],
                critical = false,
            },
            {
                cvar = "floatingCombatTextDodgeParryMiss_v2",
                recommended = "1",
                label = L["GEMS_CVAR_FCT_DODGEMISS"],
                desc = L["GEMS_CVAR_FCT_DODGEMISS_DESC"],
                critical = false,
            },
            {
                cvar = "floatingCombatTextLowManaHealth_v2",
                recommended = "1",
                label = L["GEMS_CVAR_FCT_LOWRES"],
                desc = L["GEMS_CVAR_FCT_LOWRES_DESC"],
                critical = false,
            },
            {
                cvar = "floatingCombatTextFloatMode_v2",
                recommended = "1",
                label = L["GEMS_CVAR_FCT_FLOATMODE"],
                desc = L["GEMS_CVAR_FCT_FLOATMODE_DESC"],
                critical = false,
            },
            {
                cvar = "floatingCombatTextCombatDamageDirectionalScale_v2",
                recommended = "1.0",
                label = L["GEMS_CVAR_FCT_DIRSCALE"],
                desc = L["GEMS_CVAR_FCT_DIRSCALE_DESC"],
                critical = false,
            },
            {
                cvar = "floatingCombatTextPetMeleeDamage_v2",
                recommended = "1",
                label = L["GEMS_CVAR_FCT_PETMELEE"],
                desc = L["GEMS_CVAR_FCT_PETMELEE_DESC"],
                critical = false,
            },
            {
                cvar = "floatingCombatTextPetSpellDamage_v2",
                recommended = "1",
                label = L["GEMS_CVAR_FCT_PETSPELL"],
                desc = L["GEMS_CVAR_FCT_PETSPELL_DESC"],
                critical = false,
            },
            {
                cvar = "floatingCombatTextReactives_v2",
                recommended = "1",
                label = L["GEMS_CVAR_FCT_REACTIVES"],
                desc = L["GEMS_CVAR_FCT_REACTIVES_DESC"],
                critical = false,
            },
            {
                cvar = "floatingCombatTextEnergyGains_v2",
                recommended = "0",
                label = L["GEMS_CVAR_FCT_ENERGY"],
                desc = L["GEMS_CVAR_FCT_ENERGY_DESC"],
                critical = false,
            },
            {
                cvar = "floatingCombatTextAuras_v2",
                recommended = "0",
                label = L["GEMS_CVAR_FCT_AURAS"],
                desc = L["GEMS_CVAR_FCT_AURAS_DESC"],
                critical = false,
            },
            {
                cvar = "floatingCombatTextFriendlyHealers_v2",
                recommended = "0",
                label = L["GEMS_CVAR_FCT_HEALERS"],
                desc = L["GEMS_CVAR_FCT_HEALERS_DESC"],
                critical = false,
            },
        },
    },
    -- Section 12: Accessibility
    {
        key = "accessibility",
        label = L["GEMS_CVAR_SECTION_ACCESS"],
        order = 12,
        cvars = {
            {
                cvar = "colorblindMode",
                recommended = nil,
                label = L["GEMS_CVAR_ACCESS_COLORBLIND"],
                desc = L["GEMS_CVAR_ACCESS_COLORBLIND_DESC"],
                critical = false,
            },
            {
                cvar = "CameraKeepCharacterCentered",
                recommended = "1",
                label = L["GEMS_CVAR_ACCESS_CENTERED"],
                desc = L["GEMS_CVAR_ACCESS_CENTERED_DESC"],
                critical = false,
            },
            {
                cvar = "CameraReduceUnexpectedMovement",
                recommended = "0",
                label = L["GEMS_CVAR_ACCESS_REDUCEMOVE"],
                desc = L["GEMS_CVAR_ACCESS_REDUCEMOVE_DESC"],
                critical = false,
            },
            {
                cvar = "motionSicknessFocalCircle",
                recommended = "0",
                label = L["GEMS_CVAR_ACCESS_FOCAL"],
                desc = L["GEMS_CVAR_ACCESS_FOCAL_DESC"],
                critical = false,
            },
            {
                cvar = "questTextContrast",
                recommended = "0",
                label = L["GEMS_CVAR_ACCESS_TEXTCONTRAST"],
                desc = L["GEMS_CVAR_ACCESS_TEXTCONTRAST_DESC"],
                critical = false,
            },
            {
                cvar = "CAAEnabled",
                recommended = "0",
                label = L["GEMS_CVAR_ACCESS_CAA"],
                desc = L["GEMS_CVAR_ACCESS_CAA_DESC"],
                critical = false,
            },
        },
    },
    -- Section 13: Dragonriding
    {
        key = "dragonriding",
        label = L["GEMS_CVAR_SECTION_DRAGON"],
        order = 13,
        cvars = {
            {
                cvar = "AdvFlyingDynamicFOVEnabled",
                recommended = "1",
                label = L["GEMS_CVAR_DRAGON_DYNFOV"],
                desc = L["GEMS_CVAR_DRAGON_DYNFOV_DESC"],
                critical = false,
            },
            {
                cvar = "advFlyKeyboardMaxPitchFactor",
                recommended = "6.0",
                label = L["GEMS_CVAR_DRAGON_MAXPITCH"],
                desc = L["GEMS_CVAR_DRAGON_MAXPITCH_DESC"],
                critical = false,
            },
            {
                cvar = "advFlyKeyboardMaxTurnFactor",
                recommended = "10.0",
                label = L["GEMS_CVAR_DRAGON_MAXTURN"],
                desc = L["GEMS_CVAR_DRAGON_MAXTURN_DESC"],
                critical = false,
            },
            {
                cvar = "advFlyKeyboardMinPitchFactor",
                recommended = "3.0",
                label = L["GEMS_CVAR_DRAGON_MINPITCH"],
                desc = L["GEMS_CVAR_DRAGON_MINPITCH_DESC"],
                critical = false,
            },
            {
                cvar = "advFlyPitchControl",
                recommended = "3",
                label = L["GEMS_CVAR_DRAGON_PITCHCTRL"],
                desc = L["GEMS_CVAR_DRAGON_PITCHCTRL_DESC"],
                critical = false,
            },
        },
    },
}

-- Empty sequence template (used when creating new sequences via UI in Phase 3)
D.NewSequence = {
    name = "",
    icon = D.QUESTION_MARK_ICON,
    defaultVersion = 1,
    contextOverrides = {},
    versions = {
        [1] = {
            stepFunction = "Sequential",
            steps = {},
            keyPress = "/stopmacro [channeling]",
            keyRelease = "",
            resetOnCombat = false,
            resetOnTarget = false,
            resetOnGear = false,
            resetOnSpec = false,
            resetTimer = 0,
        },
    },
}

--- Deep-copy a template sequence, stamp author/classID/timestamps.
--- @param name string Sequence name
--- @param template table|nil Source template (defaults to D.NewSequence)
--- @return table seqData Ready-to-activate sequence data
function D.NewSequenceFromTemplate(name, template)
    local tmpl = template or D.NewSequence
    local ver1 = tmpl.versions and tmpl.versions[1] or D.NewVersion
    local seqData = {
        name = name,
        icon = tmpl.icon or D.QUESTION_MARK_ICON,
        defaultVersion = 1,
        contextOverrides = {},
        versions = {
            [1] = {
                stepFunction = ver1.stepFunction or "Sequential",
                steps = {},
                keyPress = ver1.keyPress or "",
                keyRelease = ver1.keyRelease or "",
                resetOnCombat = ver1.resetOnCombat or false,
                resetOnTarget = ver1.resetOnTarget or false,
                resetOnGear = ver1.resetOnGear or false,
                resetOnSpec = ver1.resetOnSpec or false,
                resetTimer = ver1.resetTimer or 0,
            },
        },
        author = UnitName("player") or "",
        version = "1",
        description = "",
        help = "",
        helplink = "",
        classID = select(3, UnitClass("player")) or 0,
        specID = nil,
        createdAt = time(),
        updatedAt = time(),
    }
    -- Copy steps from template
    for i, step in ipairs(ver1.steps) do
        seqData.versions[1].steps[i] = step
    end
    return seqData
end

--- Shallow-copy all version fields, then deep-copy the steps array.
--- Future fields are automatically included (no whitelist needed).
--- @param ver table Version table to copy
--- @return table copy Independent copy of the version
function D.CopyVersion(ver)
    if type(ver) ~= "table" then
        return {}
    end
    local copy = {}
    for k, v in pairs(ver) do
        copy[k] = v
    end
    -- Deep-copy steps array (strings, not shared references)
    if ver.steps then
        copy.steps = {}
        for i, step in ipairs(ver.steps) do
            copy.steps[i] = step
        end
    end
    -- Deep-copy actions tree if present (v1.2.0 S14)
    if ver.actions then
        copy.actions = D.DeepCopyActions(ver.actions)
    end
    return copy
end

--- Build a short summary string for a node badge row.
--- @param node table Action node
--- @return string Summary text
function D.NodeSummary(node)
    if not node or not node.type then
        return ""
    end
    local t = node.type
    if t == D.ACTION_TYPE_LOOP then
        local r = node["repeat"] or D.ACTION_LOOP_DEFAULT_REPEAT
        local sf = node.stepFunction or D.STEP_SEQUENTIAL
        local childCount = node.children and #node.children or 0
        return string.format("x%d %s, %d actions", r, sf, childCount)
    elseif t == D.ACTION_TYPE_PAUSE then
        if node.ms then
            return tostring(node.ms) .. "ms"
        elseif node.gcd then
            return tostring(node.gcd) .. " GCD"
        else
            return tostring(node.clicks or 1) .. " clicks"
        end
    elseif t == D.ACTION_TYPE_IF then
        local cond = node.variable or ""
        if #cond > 20 then
            cond = cond:sub(1, 20) .. ".."
        end
        local trueCount = node.children and node.children[1] and #node.children[1] or 0
        local falseCount = node.children and node.children[2] and #node.children[2] or 0
        return string.format("[%s] ? %d : %d", cond, trueCount, falseCount)
    elseif t == D.ACTION_TYPE_EMBED then
        local seq = node.sequence or ""
        if seq == "" then
            return "(none)"
        end
        return seq
    end
    return ""
end

--- Create a template action node for the given type.
--- @param actionType string One of D.ACTION_TYPE_* constants
--- @return table node Template action node
function D.NewActionNode(actionType)
    if actionType == D.ACTION_TYPE_ACTION then
        return { type = D.ACTION_TYPE_ACTION, macro = "" }
    elseif actionType == D.ACTION_TYPE_LOOP then
        return {
            type = D.ACTION_TYPE_LOOP,
            name = "",
            children = {},
            ["repeat"] = D.ACTION_LOOP_DEFAULT_REPEAT,
            stepFunction = D.STEP_SEQUENTIAL,
        }
    elseif actionType == D.ACTION_TYPE_IF then
        return {
            type = D.ACTION_TYPE_IF,
            name = "",
            variable = "= true",
            children = { {}, {} },
        }
    elseif actionType == D.ACTION_TYPE_EMBED then
        return { type = D.ACTION_TYPE_EMBED, name = "", sequence = "" }
    elseif actionType == D.ACTION_TYPE_PAUSE then
        return { type = D.ACTION_TYPE_PAUSE, name = "", clicks = 1 }
    end
    return { type = D.ACTION_TYPE_ACTION, macro = "" }
end

--- Recursive deep-copy of an action node array.
--- Handles both flat children arrays and If-style dual-branch children.
--- @param actions table Array of action nodes
--- @return table copy Independent deep copy
function D.DeepCopyActions(actions)
    if type(actions) ~= "table" then
        return {}
    end
    local copy = {}
    for i, node in ipairs(actions) do
        local nodeCopy = {}
        for k, v in pairs(node) do
            nodeCopy[k] = v
        end
        if node.children then
            if node.type == D.ACTION_TYPE_IF then
                -- If node: children is { trueBranch, falseBranch }
                nodeCopy.children = {
                    D.DeepCopyActions(node.children[1] or {}),
                    D.DeepCopyActions(node.children[2] or {}),
                }
            else
                -- Loop and other types: children is a flat array
                nodeCopy.children = D.DeepCopyActions(node.children)
            end
        end
        copy[i] = nodeCopy
    end
    return copy
end
