-- GRIP-EMS: Variable Store
-- Account-wide variable definitions: CRUD, evaluation, event re-evaluation

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS")
local D = GRIPEMS.Defaults

-- VariableStore module: manages user-defined Lua functions stored account-wide
-- in GRIP_EMS_DB.variables. Variables are referenced in step macrotext as
-- ~varname~ and substituted at compile time by Engine:CompileSteps.
-- Each variable can optionally register for WoW events to trigger
-- re-evaluation, which fires VARIABLE_UPDATED if the value changed.
GRIPEMS.VariableStore = {}
local VS = GRIPEMS.VariableStore

-- Internal state
local cachedValues = {}         -- name -> last evaluated value
local eventFrame = nil          -- hidden frame for event registration
local consolidationTimer = nil  -- C_Timer handle for event batching
local pendingReeval = {}        -- set of varNames needing re-evaluation

--- Get the variables table from SavedVariables (lazy, nil-safe).
--- @return table variables table (may be empty)
local function GetStore()
    if _G.GRIP_EMS_DB and GRIP_EMS_DB.variables then
        return GRIP_EMS_DB.variables
    end
    return {}
end

--- Get a writable reference to the variables table.
--- Creates the table if it does not exist.
--- @return table variables table
local function GetOrCreateStore()
    if not _G.GRIP_EMS_DB then
        _G.GRIP_EMS_DB = {}
    end
    if not GRIP_EMS_DB.variables then
        GRIP_EMS_DB.variables = {}
    end
    return GRIP_EMS_DB.variables
end

--- Initialize the VariableStore module.
--- Called from Core.lua after SavedVariables are available.
function VS:Initialize()
    -- Evaluate all existing variables to populate cache
    self:EvaluateAll()
    -- Build event registration for all variable event triggers
    self:RebuildEventRegistration()
    GRIPEMS:Debug("VariableStore initialized.")
end

--- Get a variable definition by name.
--- @param name string Variable name
--- @return table|nil varDef or nil if not found
function VS:Get(name)
    if not name then return nil end
    local store = GetStore()
    return store[name]
end

--- Get all variable definitions.
--- @return table name -> varDef mapping
function VS:GetAll()
    return GetStore()
end

--- Save or update a variable definition.
--- @param name string Variable name
--- @param varDef table Variable definition table
function VS:Set(name, varDef)
    if not name or not varDef then return end
    local store = GetOrCreateStore()

    varDef.name = name
    varDef.updatedAt = time()
    if not varDef.createdAt then
        varDef.createdAt = time()
    end
    if varDef.author == nil then
        varDef.author = UnitName("player") or ""
    end
    if varDef.version == nil then
        varDef.version = "1"
    end

    local isNew = (store[name] == nil)
    store[name] = varDef

    -- Re-evaluate immediately
    local value = self:Evaluate(name)
    cachedValues[name] = value

    -- Rebuild event registrations (events may have changed)
    self:RebuildEventRegistration()

    if isNew and GRIPEMS.Fire then
        GRIPEMS:Fire("VARIABLE_CREATED", name)
    end
    if GRIPEMS.Fire then
        GRIPEMS:Fire("VARIABLE_UPDATED", name, value)
    end

    GRIPEMS:Debug(string.format(L["GEMS_VAR_SAVED"], name))
end

--- Delete a variable by name.
--- @param name string Variable name
function VS:Delete(name)
    if not name then return end
    local store = GetOrCreateStore()
    if not store[name] then return end

    store[name] = nil
    cachedValues[name] = nil

    self:RebuildEventRegistration()

    if GRIPEMS.Fire then
        GRIPEMS:Fire("VARIABLE_DELETED", name)
    end

    GRIPEMS:Debug(string.format(L["GEMS_VAR_DELETED"], name))
end

--- Rename a variable and update all sequence references.
--- @param oldName string Current variable name
--- @param newName string New variable name
--- @return boolean success
--- @return string|nil error message
function VS:Rename(oldName, newName)
    if not oldName or not newName then
        return false, "Missing name"
    end

    local validName, nameErr = self:ValidateName(newName)
    if not validName then
        return false, nameErr
    end

    local store = GetOrCreateStore()
    if not store[oldName] then
        return false, string.format("Variable '%s' not found", oldName)
    end
    if store[newName] then
        return false, string.format(L["GEMS_VAR_NAME_EXISTS"], newName)
    end

    -- Move the definition
    local varDef = store[oldName]
    varDef.name = newName
    varDef.updatedAt = time()
    store[newName] = varDef
    store[oldName] = nil

    -- Move cached value
    cachedValues[newName] = cachedValues[oldName]
    cachedValues[oldName] = nil

    -- Update all sequence references: replace ~oldName~ with ~newName~
    local oldPattern = "~" .. oldName .. "~"
    local newPattern = "~" .. newName .. "~"
    if _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.sequences then
        for _, seqData in pairs(GRIP_EMS_CHAR.sequences) do
            -- Update versioned steps (T2-2+ layout)
            if seqData.versions and type(seqData.versions) == "table" then
                for _, ver in ipairs(seqData.versions) do
                    if ver and ver.steps then
                        for i, step in ipairs(ver.steps) do
                            if type(step) == "string"
                                and step:find(oldPattern, 1, true) then
                                ver.steps[i] = step:gsub(oldPattern, newPattern)
                            end
                        end
                    end
                end
            end
            -- Fallback: legacy flat steps (pre-T2-2 un-migrated data)
            if seqData.steps then
                for i, step in ipairs(seqData.steps) do
                    if type(step) == "string"
                        and step:find(oldPattern, 1, true) then
                        seqData.steps[i] = step:gsub(oldPattern, newPattern)
                    end
                end
            end
        end
    end

    self:RebuildEventRegistration()

    if GRIPEMS.Fire then
        GRIPEMS:Fire("VARIABLE_DELETED", oldName)
        GRIPEMS:Fire("VARIABLE_CREATED", newName)
        GRIPEMS:Fire("VARIABLE_UPDATED", newName, cachedValues[newName])
    end

    return true
end

--- Evaluate a single variable by name.
--- Uses pcall + loadstring with "return " prefix so expressions work.
--- @param name string Variable name
--- @return any value Result of evaluation, or nil on failure
--- @return string|nil err Error message on failure
function VS:Evaluate(name)
    if not name then return nil, "No name" end
    local store = GetStore()
    local varDef = store[name]
    if not varDef then return nil, "Not found" end
    if varDef.disabled then return nil, "Disabled" end
    if not varDef.funct or varDef.funct == "" then return nil, "Empty function" end

    local fn, loadErr = loadstring("return " .. varDef.funct)
    if not fn then
        GRIPEMS:Debug(string.format(L["GEMS_VAR_EVAL_ERROR"], name,
            tostring(loadErr)))
        return nil, loadErr
    end

    local ok, result = pcall(fn)
    if not ok then
        GRIPEMS:Debug(string.format(L["GEMS_VAR_EVAL_ERROR"], name,
            tostring(result)))
        return nil, result
    end

    return result
end

--- Evaluate all enabled variables and return a name -> value table.
--- @return table name -> value mapping (skips disabled variables)
function VS:EvaluateAll()
    local store = GetStore()
    local results = {}
    for name, varDef in pairs(store) do
        if not varDef.disabled then
            local value = self:Evaluate(name)
            results[name] = value
            cachedValues[name] = value
        end
    end
    return results
end

--- Validate a variable name.
--- @param name string Name to validate
--- @return boolean valid
--- @return string|nil error message
function VS:ValidateName(name)
    if not name or name == "" then
        return false, L["GEMS_VAR_NAME_EMPTY"]
    end
    if #name > D.VAR_MAX_NAME then
        return false, string.format(L["GEMS_VAR_NAME_TOO_LONG"], D.VAR_MAX_NAME)
    end
    if not name:match("^[%w_]+$") then
        return false, L["GEMS_VAR_INVALID_NAME"]
    end
    return true
end

--- Validate a function body string (loadstring test, no execution).
--- @param funcStr string Function body to validate
--- @return boolean valid
--- @return string|nil error message
function VS:ValidateFunction(funcStr)
    if not funcStr or funcStr == "" then
        return true -- empty is valid (just evaluates to nil)
    end
    if #funcStr > D.VAR_MAX_FUNC then
        return false, string.format(L["GEMS_VAR_FUNC_TOO_LONG"], D.VAR_MAX_FUNC)
    end
    local fn, err = loadstring("return " .. funcStr)
    if not fn then
        return false, err
    end
    return true
end

--- Scan all sequences for references to a variable (~name~ pattern).
--- Checks versioned steps (T2-2+) and legacy flat steps as fallback.
--- @param name string Variable name to search for
--- @return table Array of sequence names that reference this variable
function VS:GetReferences(name)
    if not name then return {} end
    local refs = {}
    local pattern = "~" .. name .. "~"
    if _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.sequences then
        for seqName, seqData in pairs(GRIP_EMS_CHAR.sequences) do
            local found = false
            -- Check versioned steps (T2-2+ layout)
            if seqData.versions and type(seqData.versions) == "table" then
                for _, ver in ipairs(seqData.versions) do
                    if ver and ver.steps then
                        for _, step in ipairs(ver.steps) do
                            if type(step) == "string"
                                and step:find(pattern, 1, true) then
                                found = true
                                break
                            end
                        end
                    end
                    if found then break end
                end
            end
            -- Fallback: legacy flat steps (pre-T2-2 un-migrated data)
            if not found and seqData.steps then
                for _, step in ipairs(seqData.steps) do
                    if type(step) == "string"
                        and step:find(pattern, 1, true) then
                        found = true
                        break
                    end
                end
            end
            if found then
                refs[#refs + 1] = seqName
            end
        end
    end
    table.sort(refs)
    return refs
end

--- Rebuild event registration based on all variable definitions.
--- Parses each varDef.events string, registers unique events on a hidden frame.
function VS:RebuildEventRegistration()
    -- Create the hidden event frame if needed
    if not eventFrame then
        eventFrame = CreateFrame("Frame")
        eventFrame:SetScript("OnEvent", function(_, event)
            VS:OnVariableEvent(event)
        end)
    end

    -- Unregister all current events
    eventFrame:UnregisterAllEvents()

    -- Collect unique events from all variable definitions
    local store = GetStore()
    local uniqueEvents = {}
    for _, varDef in pairs(store) do
        if not varDef.disabled and varDef.events and varDef.events ~= "" then
            for eventName in varDef.events:gmatch("[^,]+") do
                eventName = eventName:match("^%s*(.-)%s*$") -- trim whitespace
                if eventName ~= "" then
                    uniqueEvents[eventName] = true
                end
            end
        end
    end

    -- Register each unique event
    for eventName in pairs(uniqueEvents) do
        local ok = pcall(function()
            eventFrame:RegisterEvent(eventName)
        end)
        if not ok then
            GRIPEMS:Debug("Invalid event for variable: " .. eventName)
        end
    end
end

--- Handle a WoW event that a variable is listening to.
--- Queues affected variables for re-evaluation with consolidation timer.
--- @param event string WoW event name
function VS:OnVariableEvent(event)
    -- Find all variables listening to this event
    local store = GetStore()
    for name, varDef in pairs(store) do
        if not varDef.disabled and varDef.events and varDef.events ~= "" then
            for eventName in varDef.events:gmatch("[^,]+") do
                eventName = eventName:match("^%s*(.-)%s*$")
                if eventName == event then
                    pendingReeval[name] = true
                    break
                end
            end
        end
    end

    -- Start consolidation timer if not already running
    if next(pendingReeval) and not consolidationTimer then
        consolidationTimer = C_Timer.NewTimer(D.VAR_CONSOLIDATION, function()
            VS:ProcessPendingReeval()
            consolidationTimer = nil
        end)
    end
end

--- Process all pending variable re-evaluations.
--- Fires VARIABLE_UPDATED only if the value actually changed.
function VS:ProcessPendingReeval()
    local toReeval = pendingReeval
    pendingReeval = {}

    for name in pairs(toReeval) do
        local newValue = self:Evaluate(name)
        local oldValue = cachedValues[name]

        -- Compare: use tostring for comparison since values can be any type
        if tostring(newValue) ~= tostring(oldValue) then
            cachedValues[name] = newValue
            if GRIPEMS.Fire then
                GRIPEMS:Fire("VARIABLE_UPDATED", name, newValue)
            end
        end
    end
end

--- Get the cached value of a variable (last evaluated result).
--- @param name string Variable name
--- @return any Cached value, or nil if not cached
function VS:GetCachedValue(name)
    return cachedValues[name]
end
