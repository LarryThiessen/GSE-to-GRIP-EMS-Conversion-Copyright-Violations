-- GRIP-EMS: Slash built-in drift guard
--
-- Created:    2026-06-29
-- Updated:    2026-06-29
-- Patch: 12.0.7.68275 Midnight (Retail LIVE)
--
-- Standalone (Lua 5.1) guard that the GRIPEMS._builtinSlashCommands reserved set in
-- Core/Core.lua lists every /gems subcommand the dispatcher's if/elseif chain matches.
-- The plugin RegisterSlashCommand path (Plugin API v3 Phase C) rejects a sub that
-- collides with a built-in via GRIPEMS.IsBuiltinSlashCommand, which reads that set -- so a
-- new built-in cmd added to the dispatcher but NOT to the set would let a plugin shadow
-- it. This test fails the moment those two drift apart.
--
-- Run from the EMS root:  lua Test/test_slash_builtin_drift.lua
-- Exit code 0 = in sync (or Core.lua not locatable -> SKIP); 1 = a dispatcher cmd is
-- missing from the reserved set.

-- Locate Core/Core.lua from the EMS root or the Test dir; never hard-fail on path.
local paths = { "Core/Core.lua", "../Core/Core.lua", "GRIP/EMS/Core/Core.lua" }
local src
for _, p in ipairs(paths) do
    local fh = io.open(p, "r")
    if fh then
        src = fh:read("*a")
        fh:close()
        break
    end
end

if not src then
    print("SKIP  test_slash_builtin_drift -- could not locate Core/Core.lua (run from the EMS root)")
    os.exit(0)
end

-- Dispatcher cmd literals: every  cmd == "<token>"  in the file. ParseSlashInput
-- lowercases the input, so every literal is a clean [a-z0-9_] token; the empty-string
-- open case ("") does not match the pattern and is correctly excluded.
local dispatcherCmds = {}
for token in src:gmatch('cmd == "([%l%d_]+)"') do
    dispatcherCmds[#dispatcherCmds + 1] = token
end

-- Reserved-set keys: every  ["<token>"] = true  inside the balanced
-- GRIPEMS._builtinSlashCommands = { ... } table region.
local reserved = {}
local setRegion = src:match("GRIPEMS%._builtinSlashCommands = (%b{})")
if setRegion then
    for token in setRegion:gmatch('%["([%l%d_]+)"%]%s*=%s*true') do
        reserved[token] = true
    end
end

if #dispatcherCmds == 0 then
    print("FAIL  test_slash_builtin_drift -- no dispatcher cmd literals found (pattern drift?)")
    os.exit(1)
end

local missing = {}
for _, token in ipairs(dispatcherCmds) do
    if not reserved[token] then
        missing[#missing + 1] = token
    end
end

if #missing > 0 then
    table.sort(missing)
    print(
        "FAIL  test_slash_builtin_drift -- "
            .. #missing
            .. " dispatcher cmd(s) missing from GRIPEMS._builtinSlashCommands: "
            .. table.concat(missing, ", ")
    )
    os.exit(1)
end

print(
    "PASS  test_slash_builtin_drift -- all "
        .. #dispatcherCmds
        .. " dispatcher cmd literals are present in GRIPEMS._builtinSlashCommands"
)
os.exit(0)
