-- GRIP-EMS: Keybind bind-priority pin
--
-- Created:    2026-08-11
-- Updated:    2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.
--
-- Standalone (Lua 5.1) source-text guard covering three coupled facts:
--   * every sequence-keybind SetBindingClick site in Engine/KeybindManager.lua
--     passes the SAME isPriority literal;
--   * that literal is the one Test/keybind_matrix_spec.lua declares as
--     EXPECTED_BIND_PRIORITY, so the in-game pin and the source cannot drift;
--   * Engine/VehicleKeybinds.lua still binds at priority TRUE at all five of its
--     sites, which is the load-bearing half of why the sequence path stays at
--     non-priority.
--
-- WHY THIS LIVES IN SET A AND NOT IN THE SPEC. The six-site check was first
-- written as a case inside Test/keybind_matrix_spec.lua, and it could not execute
-- in any lane:
--   * in-game there is no io at all, so a file-reading case skips at its guard;
--   * the lua_headless harness loads exactly one EMS spec, and it is not this one;
--   * the alltest SET C classifier lists keybind_matrix_spec.lua as in-game-only
--     and skips it.
-- A case that can never run is worse than no case, because its body claims
-- coverage it never delivers. SET A is the home that works: cowork_util.py alltest
-- discovers Test/test_*.lua by glob (no registration anywhere) and runs each file
-- with the EMS repo root as the working directory, so the "" prefix below opens
-- Engine/KeybindManager.lua directly. .github/workflows/lint.yml runs that same
-- gate, so this file is CI, rule for rule.
--
-- Run from the EMS root:  lua Test/test_keybind_bind_priority_pin.lua
-- Exit code 0 = every site agrees with the spec constant; 1 = drift, or a source
-- this guard could not read.

-- The number of sequence-keybind bind sites Engine/KeybindManager.lua is expected
-- to have. If this moves, the six line numbers quoted in that module's comments
-- and in the backlog have drifted with it, and the correct response is to fail and
-- re-read the file rather than to adapt the number here.
local EXPECTED_SITE_COUNT = 6

-- Engine/VehicleKeybinds.lua binds at priority true in five places, split across
-- two different APIs. Both counts are pinned separately so a message can name
-- WHICH family moved.
local EXPECTED_VK_CLICK_SITES = 3
local EXPECTED_VK_BINDING_SITES = 2

local passedChecks = 0

local function fail(message)
    print("FAIL  test_keybind_bind_priority_pin -- " .. message)
    os.exit(1)
end

--- Record one passing check, or fail the whole file with a message naming what
--- disagreed. The counter is what the RESULT footer prints; the footer must never
--- carry a hardcoded number, because that desyncs silently the moment a check is
--- added below.
local function check(ok, message)
    if not ok then
        fail(message)
    end
    passedChecks = passedChecks + 1
end

-- The three prefixes the repo already uses, so this file runs from the EMS root,
-- from Test/, or from the Hub root. UNLIKE the spec version this loop came from,
-- a source that opens nowhere is NOT a skip: under SET A the working directory is
-- the repo root and both files are guaranteed present, so an unreadable source
-- means the guard itself is broken. A skip here would report green while pinning
-- nothing, which is the exact failure this file was created to end.
local PREFIXES = { "", "../", "GRIP/EMS/" }

local function readSource(relPath)
    for _, prefix in ipairs(PREFIXES) do
        local fh = io.open(prefix .. relPath, "r")
        if fh then
            local src = fh:read("*a")
            fh:close()
            if type(src) == "string" and src ~= "" then
                return src
            end
        end
    end
    fail("could not read " .. relPath .. " from any of the known prefixes; run this from the EMS repo root")
end

-- ===========================================================================
-- CHECK 1 -- the site count in Engine/KeybindManager.lua
-- ===========================================================================

local managerSrc = readSource("Engine/KeybindManager.lua")

local literals = {}
for literal in string.gmatch(managerSrc, "SetBindingClick%(%s*(%a+)%s*,") do
    literals[#literals + 1] = literal
end

check(
    #literals == EXPECTED_SITE_COUNT,
    "Engine/KeybindManager.lua has "
        .. #literals
        .. " SetBindingClick site(s), expected "
        .. EXPECTED_SITE_COUNT
        .. "; the site inventory and the line numbers quoted in that module have drifted"
)

-- ===========================================================================
-- CHECK 2 -- all six sites agree with each other
-- ===========================================================================
--
-- This is the check the in-game GROUP 8 pin cannot make. GROUP 8 reads the driver
-- snippet off a frame attribute, which is ONE of the six sites, so a partial flip
-- of the other five passes it. Here every site is compared to the first, and the
-- message names the site that broke ranks.

local disagreeIndex, disagreeLiteral
for index = 2, #literals do
    if literals[index] ~= literals[1] then
        disagreeIndex = index
        disagreeLiteral = literals[index]
        break
    end
end

check(
    disagreeIndex == nil,
    "Engine/KeybindManager.lua bind site "
        .. tostring(disagreeIndex)
        .. " passes isPriority "
        .. tostring(disagreeLiteral)
        .. " while site 1 passes "
        .. tostring(literals[1])
        .. "; a partial flip is never intentional"
)

-- ===========================================================================
-- CHECK 3 -- the spec constant is declared exactly once
-- ===========================================================================
--
-- Matched as a BINDING, not as a mention, so the prose above the declaration and
-- any later reference cannot satisfy it. The count is asserted rather than the
-- first match taken: zero means the constant was renamed or deleted, and two or
-- more means something shadows it, in which case reading match one would be a
-- fail-open -- the guard would keep passing against a constant nothing uses.

local specSrc = readSource("Test/keybind_matrix_spec.lua")

local declarations = {}
for value in string.gmatch(specSrc, 'local EXPECTED_BIND_PRIORITY%s*=%s*"(%a+)"') do
    declarations[#declarations + 1] = value
end

check(
    #declarations == 1,
    "Test/keybind_matrix_spec.lua declares EXPECTED_BIND_PRIORITY "
        .. #declarations
        .. " time(s), expected exactly 1; zero means renamed or deleted, two or more means shadowed"
)

-- ===========================================================================
-- CHECK 4 -- the cross-file lock
-- ===========================================================================
--
-- The point of the whole file. The in-game GROUP 8 pin reads the spec constant;
-- this guard reads the spec constant AND the real source. The three can therefore
-- never drift apart, and a deliberate flip becomes one edit in one place that this
-- test then demands be made everywhere else too.

check(
    declarations[1] == literals[1],
    "Test/keybind_matrix_spec.lua declares EXPECTED_BIND_PRIORITY "
        .. tostring(declarations[1])
        .. " but Engine/KeybindManager.lua binds at "
        .. tostring(literals[1])
        .. "; the spec constant and the source have drifted apart"
)

-- ===========================================================================
-- CHECK 5 -- Engine/VehicleKeybinds.lua still binds at priority true
-- ===========================================================================
--
-- WHY THIS BELONGS IN THE SAME FILE. The rejection of the sequence-path flip rests
-- on VehicleKeybinds winning an overlapped key at priority true. If VehicleKeybinds
-- ever drops to non-priority, the argument for holding the sequence path at
-- non-priority collapses, and that should surface as a failing pin rather than as a
-- quietly stale rationale in a comment. The two SetBinding sites are the
-- ACTIONBUTTON overrides the suspend watchdog names, and a scan for SetBindingClick
-- alone cannot see them -- which is exactly how the original inventory undercounted.
--
-- PATTERN CHOICE, stated because the near-miss is easy to write by accident:
-- SetBinding%( anchors on an open paren IMMEDIATELY after the name, and that alone
-- is what keeps it from also matching SetBindingClick%( -- the character after
-- SetBinding there is "C", not "(". A leading non-word-character anchor would work
-- as well and is not used, because nothing else in the file ends in SetBinding and
-- the immediate-paren form reads as the thing it is checking.

local vehicleSrc = readSource("Engine/VehicleKeybinds.lua")

local vkClickSites = 0
for _ in string.gmatch(vehicleSrc, "SetBindingClick%(%s*true%s*,") do
    vkClickSites = vkClickSites + 1
end

local vkBindingSites = 0
for _ in string.gmatch(vehicleSrc, "SetBinding%(%s*true%s*,") do
    vkBindingSites = vkBindingSites + 1
end

check(
    vkClickSites == EXPECTED_VK_CLICK_SITES,
    "Engine/VehicleKeybinds.lua has "
        .. vkClickSites
        .. " SetBindingClick site(s) at priority true, expected "
        .. EXPECTED_VK_CLICK_SITES
)

check(
    vkBindingSites == EXPECTED_VK_BINDING_SITES,
    "Engine/VehicleKeybinds.lua has "
        .. vkBindingSites
        .. " SetBinding site(s) at priority true, expected "
        .. EXPECTED_VK_BINDING_SITES
        .. " (the ACTIONBUTTON overrides the suspend watchdog names)"
)

-- ===========================================================================
-- Footer
-- ===========================================================================

print("RESULT " .. passedChecks .. " passed, 0 failed")
print(
    "PASS  test_keybind_bind_priority_pin -- all "
        .. #literals
        .. " sequence-keybind bind sites in Engine/KeybindManager.lua pass isPriority "
        .. literals[1]
        .. ", matching EXPECTED_BIND_PRIORITY in Test/keybind_matrix_spec.lua"
)
os.exit(0)
