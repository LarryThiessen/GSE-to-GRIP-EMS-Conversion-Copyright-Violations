-- GRIP-EMS: Conditions
-- Created: 2026-05-04
-- Updated: 2026-06-21
-- Patch: 12.0.7.68256 Midnight (Retail LIVE)
--
-- Layer 1 boolean condition helpers exposed on the GRIPEMS namespace
-- for use in user variable expressions. Numeric helpers (HealthBelow,
-- PowerBelow, GetBuffStacks, SpellCooldownLeft) are architecturally
-- blocked by the 12.0+ secret-value system -- see Research/Variable_
-- Taint_Solution_2026-05-04.md v2.3 section. Do NOT add numeric
-- helpers here without re-reading that research doc.
--
-- Every helper below is safe to call in combat under
-- restrictions[Combat=0]=true. Each returns a clean Lua boolean (never
-- nil, never throws, never propagates a secret-tagged value). All
-- public-API calls go through pcall so a malformed spellID, an unknown
-- unit token, or a missing namespace cannot bubble up as a Lua error.

local ADDON_NAME, GRIPEMS = ...

-- Conservative aura-iteration cap. Modern WoW has no hard limit but
-- player and standard target units stay well below this in practice;
-- the loop terminates early on the first nil from GetAuraDataByIndex.
local AURA_SCAN_LIMIT = 40

--- Check whether `unit` currently has a buff matching `spellID`.
--- For unit "player" (or nil) this uses C_UnitAuras.GetPlayerAuraBySpellID,
--- which inspects only the player's own auras. For other units this
--- iterates C_UnitAuras.GetAuraDataByIndex with the HELPFUL filter and
--- matches by aura.spellId. Existence-only -- never reads aura.applications,
--- aura.duration, or other numeric fields that may be secret-tagged.
--- @param spellID number|nil Spell ID of the buff to look for
--- @param unit string|nil Unit token (default "player")
--- @return boolean hasBuff True iff a matching buff is present
function GRIPEMS.HasBuff(spellID, unit)
    if not spellID then
        return false
    end
    unit = unit or "player"
    if not C_UnitAuras then
        return false
    end
    if unit == "player" and C_UnitAuras.GetPlayerAuraBySpellID then
        local ok, aura = pcall(C_UnitAuras.GetPlayerAuraBySpellID, spellID)
        return (ok and aura ~= nil) and true or false
    end
    if not C_UnitAuras.GetAuraDataByIndex then
        return false
    end
    for i = 1, AURA_SCAN_LIMIT do
        local ok, aura = pcall(C_UnitAuras.GetAuraDataByIndex, unit, i, "HELPFUL")
        if not ok or not aura then
            return false
        end
        if aura.spellId == spellID then
            return true
        end
    end
    return false
end

--- Check whether `unit` currently has a debuff matching `spellID`.
--- Iterates C_UnitAuras.GetAuraDataByIndex with the HARMFUL filter and
--- matches by aura.spellId. Existence-only -- never reads aura.applications,
--- aura.duration, or other numeric fields that may be secret-tagged.
--- @param spellID number|nil Spell ID of the debuff to look for
--- @param unit string|nil Unit token (default "player")
--- @return boolean hasDebuff True iff a matching debuff is present
function GRIPEMS.HasDebuff(spellID, unit)
    if not spellID then
        return false
    end
    unit = unit or "player"
    if not (C_UnitAuras and C_UnitAuras.GetAuraDataByIndex) then
        return false
    end
    for i = 1, AURA_SCAN_LIMIT do
        local ok, aura = pcall(C_UnitAuras.GetAuraDataByIndex, unit, i, "HARMFUL")
        if not ok or not aura then
            return false
        end
        if aura.spellId == spellID then
            return true
        end
    end
    return false
end

--- Check whether a spell is currently usable.
--- Wraps C_Spell.IsSpellUsable. The secondary insufficientPower return is
--- ignored on purpose -- this helper answers "is the cast button green
--- right now", not "could you cast this if you had resources". Verified
--- clean in combat per v2.2 Path D8 sweeps.
--- @param spellID number|nil Spell ID to check
--- @return boolean usable True iff the spell is usable right now
function GRIPEMS.SpellReady(spellID)
    if not spellID then
        return false
    end
    if not (C_Spell and C_Spell.IsSpellUsable) then
        return false
    end
    local ok, usable = pcall(C_Spell.IsSpellUsable, spellID)
    if not ok then
        return false
    end
    return usable and true or false
end

--- Check whether a spell is currently on cooldown.
--- Reads info.isActive from C_Spell.GetSpellCooldown. Does NOT compute
--- time remaining -- info.startTime, info.duration, and info.modRate are
--- secret-tagged in combat per v2.2 Path D8 findings and cannot be
--- subtracted or compared in user expressions.
--- @param spellID number|nil Spell ID to check
--- @return boolean onCooldown True iff info.isActive is true
function GRIPEMS.SpellOnCooldown(spellID)
    if not spellID then
        return false
    end
    if not (C_Spell and C_Spell.GetSpellCooldown) then
        return false
    end
    local ok, info = pcall(C_Spell.GetSpellCooldown, spellID)
    if not ok or not info then
        return false
    end
    return info.isActive and true or false
end

--- Check whether a spell is enabled (not on hold).
--- Reads info.isEnabled from C_Spell.GetSpellCooldown. False when the
--- spell is on hold (e.g. a charged spell waiting for an active spell to
--- be cancelled). Verified clean in combat per v2.2 Path D8 sweeps.
--- @param spellID number|nil Spell ID to check
--- @return boolean enabled True iff info.isEnabled is true
function GRIPEMS.SpellEnabled(spellID)
    if not spellID then
        return false
    end
    if not (C_Spell and C_Spell.GetSpellCooldown) then
        return false
    end
    local ok, info = pcall(C_Spell.GetSpellCooldown, spellID)
    if not ok or not info then
        return false
    end
    return info.isEnabled and true or false
end

--- Check whether any addon-action restriction is currently active.
--- Reads the GRIPEMS.restrictions table maintained by the
--- ADDON_RESTRICTION_STATE_CHANGED handler in Engine/OOCQueue.lua. Returns
--- true when any of Encounter (1), ChallengeMode (2), or PvPMatch (3) is
--- in a state other than 0 (Inactive). Does NOT register its own event
--- handler -- OOCQueue.lua already populates the table at file load.
--- @return boolean restricted True iff any tracked restriction is active
function GRIPEMS.IsRestricted()
    local r = GRIPEMS.restrictions
    if not r then
        return false
    end
    for _, state in pairs(r) do
        if state and state ~= 0 then
            return true
        end
    end
    return false
end

-- ===========================================================================
-- IC-VAR-04 helpers (v2.1.8) -- macro-conditional dispatch helpers
-- ===========================================================================
--
-- These 23 helpers map 1:1 to WoW macro conditional keys. The
-- MacroConditionalBaker (Engine/MacroConditionalBaker.lua) parses
-- user variables whose body reduces to calls into this set, then
-- rewrites `~varname~` references in macrotext to native
-- `[conditional] X; Y` form at compile time. Variables that call
-- these helpers at runtime (via VariableStore:Evaluate) get clean
-- boolean returns -- the same defensive idiom as the Layer 1 boolean
-- helpers above. Each helper is safe in combat (no secret-tagged
-- returns, no taint exposure). See Research/IC-VAR-04_Design.md
-- for the full helper -> conditional mapping table.

--- Check whether the player is currently in combat.
--- Wraps UnitAffectingCombat("player"). Maps to the macro conditional
--- `[combat]`. Returns a clean boolean -- combat state itself is not
--- secret-tagged on the 12.0 surface.
--- @return boolean inCombat True iff the player has aggro
function GRIPEMS.InCombat()
    if not UnitAffectingCombat then
        return false
    end
    local ok, result = pcall(UnitAffectingCombat, "player")
    return (ok and result) and true or false
end

--- Check whether a modifier key is currently held down.
--- Maps to `[mod:modKey]`. Accepts the nine canonical modkey strings
--- (shift, ctrl, alt, lshift, rshift, lctrl, rctrl, lalt, ralt).
--- Unknown modKey returns false -- the MCB parser pre-validates the
--- string against the same allowlist before bake, so an unknown modKey
--- at runtime is either a manual user call or a stale cache.
--- @param modKey string Modifier key name
--- @return boolean held True iff the named modifier is pressed
function GRIPEMS.HasMod(modKey)
    if type(modKey) ~= "string" then
        return false
    end
    if modKey == "shift" then
        local ok, r = pcall(IsShiftKeyDown)
        return (ok and r) and true or false
    end
    if modKey == "ctrl" then
        local ok, r = pcall(IsControlKeyDown)
        return (ok and r) and true or false
    end
    if modKey == "alt" then
        local ok, r = pcall(IsAltKeyDown)
        return (ok and r) and true or false
    end
    if modKey == "lshift" then
        local ok, r = pcall(IsLeftShiftKeyDown)
        return (ok and r) and true or false
    end
    if modKey == "rshift" then
        local ok, r = pcall(IsRightShiftKeyDown)
        return (ok and r) and true or false
    end
    if modKey == "lctrl" then
        local ok, r = pcall(IsLeftControlKeyDown)
        return (ok and r) and true or false
    end
    if modKey == "rctrl" then
        local ok, r = pcall(IsRightControlKeyDown)
        return (ok and r) and true or false
    end
    if modKey == "lalt" then
        local ok, r = pcall(IsLeftAltKeyDown)
        return (ok and r) and true or false
    end
    if modKey == "ralt" then
        local ok, r = pcall(IsRightAltKeyDown)
        return (ok and r) and true or false
    end
    return false
end

--- Check whether the player is in the given stance index (1-3).
--- Maps to `[stance:N]`. Stance form IDs are clean integers in the
--- 12.0 surface -- the numeric compare is safe.
--- @param N number Stance index, 1..3
--- @return boolean inStance True iff GetShapeshiftFormID() == N
function GRIPEMS.InStance(N)
    if type(N) ~= "number" or N < 1 or N > 3 then
        return false
    end
    if not GetShapeshiftFormID then
        return false
    end
    local ok, formID = pcall(GetShapeshiftFormID)
    if not ok or formID == nil then
        return false
    end
    return formID == N
end

--- Check whether the player is in the given form index (0-7).
--- Maps to `[form:N]`. Identical underlying API to InStance, but the
--- form vocabulary spans more indexes (druid forms, ghost wolf,
--- shadowform, etc.). N=0 means "humanoid / no form" -- matches the
--- macro conditional `[form:0]` semantics. Form IDs are clean integers.
--- @param N number Form index, 0..7
--- @return boolean inForm True iff the current form matches N
function GRIPEMS.InForm(N)
    if type(N) ~= "number" or N < 0 or N > 7 then
        return false
    end
    if not GetShapeshiftFormID then
        return false
    end
    local ok, formID = pcall(GetShapeshiftFormID)
    if not ok then
        return false
    end
    if N == 0 then
        return formID == nil or formID == 0
    end
    return formID == N
end

--- Check whether the player has the given specialization active (1-4).
--- Maps to `[spec:N]`. GetSpecialization returns nil when the player
--- has no specialization (e.g. low-level alts), in which case any N
--- returns false. Spec index is a clean integer.
--- @param N number Specialization index, 1..4
--- @return boolean inSpec True iff GetSpecialization() == N
function GRIPEMS.InSpec(N)
    if type(N) ~= "number" or N < 1 or N > 4 then
        return false
    end
    if not GetSpecialization then
        return false
    end
    local ok, spec = pcall(GetSpecialization)
    if not ok or spec == nil then
        return false
    end
    return spec == N
end

--- Check whether the current bonus bar matches N (0-5).
--- Maps to `[bonusbar:N]`. 0 is the default action bar; 1-5 are
--- vehicle / shapeshift / quest override bars. Bonus bar index is a
--- clean integer.
--- @param N number Bonus bar index, 0..5
--- @return boolean inBonusBar True iff GetBonusBarIndex() == N
function GRIPEMS.InBonusBar(N)
    if type(N) ~= "number" or N < 0 or N > 5 then
        return false
    end
    if not GetBonusBarIndex then
        return false
    end
    local ok, idx = pcall(GetBonusBarIndex)
    if not ok or idx == nil then
        return false
    end
    return idx == N
end

--- Check whether the player is currently stealthed.
--- Maps to `[stealth]`. Wraps IsStealthed(). Stealth state is a clean
--- boolean on the 12.0 surface.
--- @return boolean stealthed True iff the player is stealthed
function GRIPEMS.IsStealthed()
    if not IsStealthed then
        return false
    end
    local ok, result = pcall(IsStealthed)
    return (ok and result) and true or false
end

--- Check whether the given unit is dead or a ghost.
--- Maps to `[dead]` (when no unit) or `[dead,@unit]` (with unit).
--- Unit defaults to "target". UnitIsDeadOrGhost returns nil for
--- nonexistent units; we coerce to false.
--- @param unit string|nil Unit token (default "target")
--- @return boolean dead True iff the unit is dead or a ghost
function GRIPEMS.IsDead(unit)
    unit = unit or "target"
    if type(unit) ~= "string" then
        return false
    end
    if not UnitIsDeadOrGhost then
        return false
    end
    local ok, result = pcall(UnitIsDeadOrGhost, unit)
    return (ok and result) and true or false
end

--- Check whether the player can assist the given unit (friendly).
--- Maps to `[help]`. Unit defaults to "target". UnitCanAssist returns
--- nil for nonexistent units; we coerce to false.
--- @param unit string|nil Unit token (default "target")
--- @return boolean canHelp True iff the player can cast helpful on unit
function GRIPEMS.IsHelp(unit)
    unit = unit or "target"
    if type(unit) ~= "string" then
        return false
    end
    if not UnitCanAssist then
        return false
    end
    local ok, result = pcall(UnitCanAssist, "player", unit)
    return (ok and result) and true or false
end

--- Check whether the player can attack the given unit (hostile).
--- Maps to `[harm]`. Unit defaults to "target". UnitCanAttack returns
--- nil for nonexistent units; we coerce to false.
--- @param unit string|nil Unit token (default "target")
--- @return boolean canHarm True iff the player can cast harmful on unit
function GRIPEMS.IsHarm(unit)
    unit = unit or "target"
    if type(unit) ~= "string" then
        return false
    end
    if not UnitCanAttack then
        return false
    end
    local ok, result = pcall(UnitCanAttack, "player", unit)
    return (ok and result) and true or false
end

--- Check whether the given unit exists.
--- Maps to `[exists]`. Unit defaults to "target". UnitExists returns
--- a clean boolean on the 12.0 surface.
--- @param unit string|nil Unit token (default "target")
--- @return boolean exists True iff the unit exists
function GRIPEMS.UnitExists(unit)
    unit = unit or "target"
    if type(unit) ~= "string" then
        return false
    end
    if not _G.UnitExists then
        return false
    end
    local ok, result = pcall(_G.UnitExists, unit)
    return (ok and result) and true or false
end

--- Check whether the player is in a party (grouped but not a raid).
--- Maps to `[party]`. The macro conditional [party] is true in 5-man
--- parties only -- if the group has been promoted to a raid, [party]
--- becomes false. Mirrors that here: IsInGroup() and not IsInRaid().
--- @return boolean inParty True iff in a party (not raid)
function GRIPEMS.InParty()
    if not IsInGroup or not IsInRaid then
        return false
    end
    local ok1, inGroup = pcall(IsInGroup)
    local ok2, inRaid = pcall(IsInRaid)
    if not ok1 or not ok2 then
        return false
    end
    return (inGroup and not inRaid) and true or false
end

--- Check whether the player is in a raid group.
--- Maps to `[raid]`. Wraps IsInRaid(). Raid membership is a clean
--- boolean on the 12.0 surface.
--- @return boolean inRaid True iff the player is in a raid
function GRIPEMS.InRaid()
    if not IsInRaid then
        return false
    end
    local ok, result = pcall(IsInRaid)
    return (ok and result) and true or false
end

--- Check whether the player is in any group (party or raid).
--- Maps to `[group]`. Wraps IsInGroup(). The macro conditional [group]
--- is true for either party or raid -- the broad version of [party].
--- @return boolean inGroup True iff the player is in a party or raid
function GRIPEMS.InGroup()
    if not IsInGroup then
        return false
    end
    local ok, result = pcall(IsInGroup)
    return (ok and result) and true or false
end

--- Check whether the player is currently channeling a spell.
--- Maps to `[channeling]`. Reads only the existence of the
--- UnitChannelInfo return tuple -- never inspects .startTime,
--- .endTime, or other numeric fields that may be secret-tagged on
--- the 12.0 surface. Existence-only is sufficient for the bake-pass.
--- @return boolean channeling True iff a channel is active
function GRIPEMS.IsChanneling()
    if not UnitChannelInfo then
        return false
    end
    local ok, name = pcall(UnitChannelInfo, "player")
    if not ok then
        return false
    end
    return (name ~= nil) and true or false
end

--- Check whether the player knows the given spell.
--- Maps to `[known:Name]`. Accepts either a number (spellID) or a
--- string (spell name). String input is resolved through SpellCache
--- to obtain the spell ID -- the locale-risk surface that VS:GetLocaleRisk
--- already tracks (see Research/IC-VAR-04_Design.md "Locale risk").
--- Unknown name or missing SpellCache returns false.
--- @param spellOrID number|string Spell ID or spell name
--- @return boolean known True iff the player has learned the spell
function GRIPEMS.KnowsSpell(spellOrID)
    if not (C_Spell and C_Spell.IsSpellKnown) then
        return false
    end
    if type(spellOrID) == "number" then
        local ok, known = pcall(C_Spell.IsSpellKnown, spellOrID)
        return (ok and known) and true or false
    end
    if type(spellOrID) == "string" then
        local SC = GRIPEMS.SpellCache
        if not SC or not SC.GetSpellID then
            return false
        end
        local id = SC:GetSpellID(spellOrID)
        if not id then
            return false
        end
        local ok, known = pcall(C_Spell.IsSpellKnown, id)
        return (ok and known) and true or false
    end
    return false
end

--- Check whether the player is mounted.
--- Maps to `[mounted]`. Wraps IsMounted(). Mount state is a clean
--- boolean on the 12.0 surface.
--- @return boolean mounted True iff the player is on a mount
function GRIPEMS.IsMounted()
    if not IsMounted then
        return false
    end
    local ok, result = pcall(IsMounted)
    return (ok and result) and true or false
end

--- Check whether the player is currently indoors.
--- Maps to `[indoors]`. Wraps IsIndoors(). Indoor state is a clean
--- boolean on the 12.0 surface.
--- @return boolean indoors True iff the player is indoors
function GRIPEMS.IsIndoors()
    if not IsIndoors then
        return false
    end
    local ok, result = pcall(IsIndoors)
    return (ok and result) and true or false
end

--- Check whether the player is currently outdoors.
--- Maps to `[outdoors]`. Wraps IsOutdoors(). Outdoor state is a clean
--- boolean on the 12.0 surface.
--- @return boolean outdoors True iff the player is outdoors
function GRIPEMS.IsOutdoors()
    if not IsOutdoors then
        return false
    end
    local ok, result = pcall(IsOutdoors)
    return (ok and result) and true or false
end

--- Check whether the player is currently swimming.
--- Maps to `[swimming]`. Wraps IsSwimming(). Swim state is a clean
--- boolean on the 12.0 surface.
--- @return boolean swimming True iff the player is swimming
function GRIPEMS.IsSwimming()
    if not IsSwimming then
        return false
    end
    local ok, result = pcall(IsSwimming)
    return (ok and result) and true or false
end

--- Check whether the given unit currently has a vehicle UI showing.
--- Maps to `[unithasvehicleui]`. Unit defaults to "player" -- this
--- conditional is most useful for the player's own vehicle state but
--- the macro form accepts any unit.
--- @param unit string|nil Unit token (default "player")
--- @return boolean hasUI True iff the unit has the vehicle UI
function GRIPEMS.UnitHasVehicleUI(unit)
    unit = unit or "player"
    if type(unit) ~= "string" then
        return false
    end
    if not UnitHasVehicleUI then
        return false
    end
    local ok, result = pcall(UnitHasVehicleUI, unit)
    return (ok and result) and true or false
end

--- Check whether the player currently has a possess bar.
--- Maps to `[possessbar]`. Wraps HasPossessBar() -- true when the
--- player has a possess bar from mind control, controlled vehicles,
--- or similar mechanics. Returns false if the API is missing.
--- @return boolean hasBar True iff the possess bar is active
function GRIPEMS.InPossessBar()
    if not HasPossessBar then
        return false
    end
    local ok, result = pcall(HasPossessBar)
    return (ok and result) and true or false
end

--- Check whether the player has an override action bar showing.
--- Maps to `[overridebar]`. Wraps HasOverrideActionBar() -- true when
--- the main action bar has been replaced by quest UI, vehicle UI, or
--- certain spell-driven overrides. Returns false if the API is missing.
--- @return boolean hasOverride True iff an override bar is active
function GRIPEMS.InOverrideBar()
    if not HasOverrideActionBar then
        return false
    end
    local ok, result = pcall(HasOverrideActionBar)
    return (ok and result) and true or false
end
