-- GRIP-EMS: Test spec for Layer 1 boolean condition helpers (Phase 3b)
--
-- Created:    2026-05-04
-- Updated:    2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.
--
-- Registers tests in TestSuite under category "conditions" covering the
-- six boolean helpers exposed on GRIPEMS by Engine/Conditions.lua: HasBuff,
-- HasDebuff, SpellReady, SpellOnCooldown, SpellEnabled, IsRestricted.
-- Game-state-dependent assertions (live aura on player, cooldown active on
-- a known spell) skip with a clear message when the prerequisite is not
-- present, so the suite is safe to run from any character at any time.
-- Also pins a regression fence for the v2.1.8 D.VAR_PATTERN widening:
-- underscore-named variables must substitute through the runtime path.

local ADDON_NAME, GRIPEMS = ...

local TS = GRIPEMS.TestSuite
if not TS then
    return
end

-- A spellID guaranteed not to map to any known spell. Used for the
-- "unknown spellID returns false" code paths without touching live state.
local UNKNOWN_SPELL_ID = 999999999

-- Stable spell IDs known to almost every retail character. Used as
-- candidates for live-state probes; each lookup is independently optional
-- and tests skip cleanly if no candidate matches the required state.
local CANDIDATE_SPELL_IDS = {
    8690, -- Hearthstone (all characters)
    6603, -- Auto Attack (all characters)
    20549, -- War Stomp (Tauren racial)
    20572, -- Blood Fury (Orc racial)
    7744, -- Will of the Forsaken (Undead racial)
    59752, -- Will to Survive (Human racial)
    58984, -- Shadowmeld (Night Elf racial)
    883, -- Call Pet 1 (Hunter)
    1130, -- Hunter's Mark (Hunter)
    5384, -- Feign Death (Hunter)
    2643, -- Multi-Shot (Hunter)
    2825, -- Bloodlust (Shaman) / 32182 Heroism
}

-- ---------------------------------------------------------------------------
-- Discovery helpers (return nil when the prerequisite is not satisfied)
-- ---------------------------------------------------------------------------

local function findActiveAuraID(unit, filter)
    if not (C_UnitAuras and C_UnitAuras.GetAuraDataByIndex) then
        return nil
    end
    for i = 1, 40 do
        local ok, aura = pcall(C_UnitAuras.GetAuraDataByIndex, unit, i, filter)
        if not ok or not aura then
            return nil
        end
        if aura.spellId then
            return aura.spellId
        end
    end
    return nil
end

local function findUsableSpellID()
    if not (C_Spell and C_Spell.IsSpellUsable) then
        return nil
    end
    for _, id in ipairs(CANDIDATE_SPELL_IDS) do
        local ok, usable = pcall(C_Spell.IsSpellUsable, id)
        if ok and usable then
            return id
        end
    end
    return nil
end

local function findCooldownStateSpellID(wantActive)
    if not (C_Spell and C_Spell.GetSpellCooldown) then
        return nil
    end
    for _, id in ipairs(CANDIDATE_SPELL_IDS) do
        local ok, info = pcall(C_Spell.GetSpellCooldown, id)
        if ok and info and (info.isActive and true or false) == wantActive then
            return id
        end
    end
    -- Fallback: scan the SpellCache for any cached spell with the
    -- requested cooldown state. This lets the "spell on cooldown"
    -- test PASS once the user has cast anything within the spell's
    -- cooldown window. GRIPEMS.SpellCache.spells is a sorted array
    -- of entry tables { name, spellID, iconID, ... }, so iterate the
    -- list and read entry.spellID rather than treating keys as IDs.
    local SC = GRIPEMS and GRIPEMS.SpellCache
    local cache = SC and SC.spells
    if type(cache) == "table" then
        for _, entry in ipairs(cache) do
            local sid = type(entry) == "table" and entry.spellID
            if type(sid) == "number" then
                local ok, info = pcall(C_Spell.GetSpellCooldown, sid)
                if ok and info and (info.isActive and true or false) == wantActive then
                    return sid
                end
            end
        end
    end
    return nil
end

local function findEnabledSpellID()
    if not (C_Spell and C_Spell.GetSpellCooldown) then
        return nil
    end
    for _, id in ipairs(CANDIDATE_SPELL_IDS) do
        local ok, info = pcall(C_Spell.GetSpellCooldown, id)
        if ok and info and info.isEnabled then
            return id
        end
    end
    return nil
end

-- Candidate non-player unit tokens for iteration-path tests.
-- "target" is the historical default but is empty on a fresh login;
-- widen to focus / pet / party / partypet / boss so common setups
-- (Hunters with active pet, group play, raid targets) hit the
-- iteration code path without manual prep.
local NON_PLAYER_UNIT_CANDIDATES = {
    "target",
    "focus",
    "pet",
    "party1",
    "partypet1",
    "boss1",
    "boss2",
}

local function findExistingNonPlayerUnit()
    if not UnitExists then
        return nil
    end
    for _, u in ipairs(NON_PLAYER_UNIT_CANDIDATES) do
        if UnitExists(u) then
            return u
        end
    end
    return nil
end

local function findUnitWithAuraType(filter)
    if not UnitExists then
        return nil, nil
    end
    for _, u in ipairs(NON_PLAYER_UNIT_CANDIDATES) do
        if UnitExists(u) then
            local id = findActiveAuraID(u, filter)
            if id then
                return u, id
            end
        end
    end
    return nil, nil
end

-- ---------------------------------------------------------------------------
-- HasBuff
-- ---------------------------------------------------------------------------

TS:Register("Conditions.HasBuff: nil spellID returns false", "conditions", function(self)
    if GRIPEMS.HasBuff(nil) == false then
        self:Pass()
    else
        self:Fail("expected false for nil spellID")
    end
end)

TS:Register("Conditions.HasBuff: unknown spellID returns false", "conditions", function(self)
    if GRIPEMS.HasBuff(UNKNOWN_SPELL_ID) == false then
        self:Pass()
    else
        self:Fail("expected false for unknown spellID")
    end
end)

TS:Register("Conditions.HasBuff: known buff on player returns true", "conditions", function(self)
    local id = findActiveAuraID("player", "HELPFUL")
    if not id then
        self:Skip("no buff currently on player")
        return
    end
    if GRIPEMS.HasBuff(id) == true then
        self:Pass()
    else
        self:Fail("expected true for known player buff " .. tostring(id))
    end
end)

TS:Register("Conditions.HasBuff: known buff on non-player unit via iteration path", "conditions", function(self)
    local unit, id = findUnitWithAuraType("HELPFUL")
    if not unit then
        self:Skip("no non-player unit with HELPFUL aura -- run /gems test prep")
        return
    end
    if GRIPEMS.HasBuff(id, unit) == true then
        self:Pass()
    else
        self:Fail("expected true for " .. unit .. " buff " .. tostring(id))
    end
end)

TS:Register("Conditions.HasBuff: no matching buff on unit returns false", "conditions", function(self)
    if GRIPEMS.HasBuff(UNKNOWN_SPELL_ID, "player") == false then
        self:Pass()
    else
        self:Fail("expected false for unknown spellID against player")
    end
end)

-- ---------------------------------------------------------------------------
-- HasDebuff
-- ---------------------------------------------------------------------------

TS:Register("Conditions.HasDebuff: nil spellID returns false", "conditions", function(self)
    if GRIPEMS.HasDebuff(nil) == false then
        self:Pass()
    else
        self:Fail("expected false for nil spellID")
    end
end)

TS:Register("Conditions.HasDebuff: no debuff on target returns false", "conditions", function(self)
    local unit = findExistingNonPlayerUnit()
    if not unit then
        self:Skip("no non-player unit available -- run /gems test prep")
        return
    end
    if GRIPEMS.HasDebuff(UNKNOWN_SPELL_ID, unit) == false then
        self:Pass()
    else
        self:Fail("expected false for unknown debuff on " .. unit)
    end
end)

TS:Register("Conditions.HasDebuff: known debuff on target returns true", "conditions", function(self)
    local unit, id = findUnitWithAuraType("HARMFUL")
    if not unit then
        self:Skip("no non-player unit with HARMFUL aura -- run /gems test prep")
        return
    end
    if GRIPEMS.HasDebuff(id, unit) == true then
        self:Pass()
    else
        self:Fail("expected true for " .. unit .. " debuff " .. tostring(id))
    end
end)

-- ---------------------------------------------------------------------------
-- SpellReady
--
-- Semantic note: SpellReady wraps C_Spell.IsSpellUsable. Cooldown state alone
-- does not flip "usable" to false -- the API also tracks resource cost and
-- learned/known status. A spell that is currently usable will continue to
-- return true through any subsequent cooldown completion that does not
-- change the underlying IsSpellUsable verdict.
-- ---------------------------------------------------------------------------

TS:Register("Conditions.SpellReady: nil spellID returns false", "conditions", function(self)
    if GRIPEMS.SpellReady(nil) == false then
        self:Pass()
    else
        self:Fail("expected false for nil spellID")
    end
end)

TS:Register("Conditions.SpellReady: unknown spellID returns false", "conditions", function(self)
    if GRIPEMS.SpellReady(UNKNOWN_SPELL_ID) == false then
        self:Pass()
    else
        self:Fail("expected false for unknown spellID")
    end
end)

TS:Register("Conditions.SpellReady: usable spell returns true", "conditions", function(self)
    local id = findUsableSpellID()
    if not id then
        self:Skip("no candidate spell currently usable")
        return
    end
    if GRIPEMS.SpellReady(id) == true then
        self:Pass()
    else
        self:Fail("expected true for usable spell " .. tostring(id))
    end
end)

TS:Register("Conditions.SpellReady: helper agrees with IsSpellUsable", "conditions", function(self)
    if not (C_Spell and C_Spell.IsSpellUsable) then
        self:Skip("C_Spell.IsSpellUsable unavailable")
        return
    end
    local id = CANDIDATE_SPELL_IDS[1]
    local ok, usable = pcall(C_Spell.IsSpellUsable, id)
    if not ok then
        self:Skip("IsSpellUsable errored for candidate " .. tostring(id))
        return
    end
    local expected = (usable and true or false)
    if GRIPEMS.SpellReady(id) == expected then
        self:Pass()
    else
        self:Fail("helper disagreed with IsSpellUsable for " .. tostring(id))
    end
end)

-- ---------------------------------------------------------------------------
-- SpellOnCooldown
-- ---------------------------------------------------------------------------

TS:Register("Conditions.SpellOnCooldown: nil spellID returns false", "conditions", function(self)
    if GRIPEMS.SpellOnCooldown(nil) == false then
        self:Pass()
    else
        self:Fail("expected false for nil spellID")
    end
end)

TS:Register("Conditions.SpellOnCooldown: unknown spellID returns false", "conditions", function(self)
    if GRIPEMS.SpellOnCooldown(UNKNOWN_SPELL_ID) == false then
        self:Pass()
    else
        self:Fail("expected false for unknown spellID")
    end
end)

TS:Register("Conditions.SpellOnCooldown: spell off cooldown returns false", "conditions", function(self)
    local id = findCooldownStateSpellID(false)
    if not id then
        self:Skip("no candidate spell currently off cooldown")
        return
    end
    if GRIPEMS.SpellOnCooldown(id) == false then
        self:Pass()
    else
        self:Fail("expected false for off-cooldown spell " .. tostring(id))
    end
end)

TS:Register("Conditions.SpellOnCooldown: spell on cooldown returns true", "conditions", function(self)
    local id = findCooldownStateSpellID(true)
    if not id then
        self:Skip("no candidate spell on cooldown -- run /gems test prep")
        return
    end
    if GRIPEMS.SpellOnCooldown(id) == true then
        self:Pass()
    else
        self:Fail("expected true for on-cooldown spell " .. tostring(id))
    end
end)

-- ---------------------------------------------------------------------------
-- SpellEnabled
-- ---------------------------------------------------------------------------

TS:Register("Conditions.SpellEnabled: nil spellID returns false", "conditions", function(self)
    if GRIPEMS.SpellEnabled(nil) == false then
        self:Pass()
    else
        self:Fail("expected false for nil spellID")
    end
end)

TS:Register("Conditions.SpellEnabled: unknown spellID returns false", "conditions", function(self)
    if GRIPEMS.SpellEnabled(UNKNOWN_SPELL_ID) == false then
        self:Pass()
    else
        self:Fail("expected false for unknown spellID")
    end
end)

TS:Register("Conditions.SpellEnabled: normal spell returns true", "conditions", function(self)
    local id = findEnabledSpellID()
    if not id then
        self:Skip("no candidate spell currently enabled")
        return
    end
    if GRIPEMS.SpellEnabled(id) == true then
        self:Pass()
    else
        self:Fail("expected true for enabled spell " .. tostring(id))
    end
end)

-- ---------------------------------------------------------------------------
-- IsRestricted
--
-- These tests temporarily replace GRIPEMS.restrictions and restore it after.
-- Each call site wraps GRIPEMS.IsRestricted in pcall so the restoration runs
-- unconditionally; the framework's outer pcall would catch a throw but skip
-- the restoration line, leaking corrupted state to subsequent tests.
--
-- The IsRestricted impl iterates GRIPEMS.restrictions with pairs() and returns
-- true for any non-nil value other than 0. The docstring lists only Encounter
-- (1), ChallengeMode (2), and PvPMatch (3); a future fourth key such as [4]=Map
-- with state ~= 0 would currently flip IsRestricted to true. The REGRESSION
-- FENCE test below pins this pairs-based contract -- a future polish that
-- aligns the docstring with a {1,2,3} filter will surface as a fail there.
-- ---------------------------------------------------------------------------

TS:Register("Conditions.IsRestricted: empty restrictions returns false", "conditions", function(self)
    local saved = GRIPEMS.restrictions
    GRIPEMS.restrictions = {}
    local ok, result = pcall(GRIPEMS.IsRestricted)
    GRIPEMS.restrictions = saved
    if not ok then
        self:Fail("IsRestricted threw: " .. tostring(result))
        return
    end
    if result == false then
        self:Pass()
    else
        self:Fail("expected false for empty restrictions, got " .. tostring(result))
    end
end)

TS:Register("Conditions.IsRestricted: restrictions[1]=2 (Active) returns true", "conditions", function(self)
    local saved = GRIPEMS.restrictions
    GRIPEMS.restrictions = { [1] = 2, [2] = 0, [3] = 0 }
    local ok, result = pcall(GRIPEMS.IsRestricted)
    GRIPEMS.restrictions = saved
    if not ok then
        self:Fail("IsRestricted threw: " .. tostring(result))
        return
    end
    if result == true then
        self:Pass()
    else
        self:Fail("expected true for restrictions[1]=2, got " .. tostring(result))
    end
end)

TS:Register("Conditions.IsRestricted: restrictions[1]=0 (Inactive) returns false", "conditions", function(self)
    local saved = GRIPEMS.restrictions
    GRIPEMS.restrictions = { [1] = 0, [2] = 0, [3] = 0 }
    local ok, result = pcall(GRIPEMS.IsRestricted)
    GRIPEMS.restrictions = saved
    if not ok then
        self:Fail("IsRestricted threw: " .. tostring(result))
        return
    end
    if result == false then
        self:Pass()
    else
        self:Fail("expected false for all-zero restrictions, got " .. tostring(result))
    end
end)

TS:Register(
    "Conditions.IsRestricted: REGRESSION FENCE -- [4]=1 returns true (update when impl filters to keys 1-3)",
    "conditions",
    function(self)
        local saved = GRIPEMS.restrictions
        GRIPEMS.restrictions = { [1] = 0, [2] = 0, [3] = 0, [4] = 1 }
        local ok, result = pcall(GRIPEMS.IsRestricted)
        GRIPEMS.restrictions = saved
        if not ok then
            self:Fail("IsRestricted threw: " .. tostring(result))
            return
        end
        if result == true then
            self:Pass()
        else
            self:Fail("expected true (current pairs-based impl flags any non-zero key); got " .. tostring(result))
        end
    end
)

-- ---------------------------------------------------------------------------
-- VarPattern -- underscore-named variable substitution (v2.1.8 regression fence)
--
-- D.VAR_PATTERN widened from "~(%w+)~" to "~([%w_]+)~" in v2.1.8. Lua %w is
-- [A-Za-z0-9] only, so the old pattern silently skipped any variable whose name
-- contained an underscore, even though VS:ValidateName ("^[%w_]+$") accepts
-- underscores. The literal ~combat_check_var~ then survived into final macrotext,
-- where WoW mis-read it as a spell name and the cast failed with no error.
--
-- Pins the three surfaces that must agree: the match pattern, the runtime
-- substitution path (Engine:SubstituteVariables -> VS:Evaluate), and the name
-- validator. Inserts a temp variable and restores any pre-existing same-named
-- variable on teardown, so it is safe to run from any account.
-- ---------------------------------------------------------------------------

TS:Register("Conditions.VarPattern: underscore var substitutes at runtime", "conditions", function(self)
    local D = GRIPEMS.Defaults
    local VS = GRIPEMS.VariableStore
    local Engine = GRIPEMS.Engine
    if not (D and D.VAR_PATTERN and VS and Engine) then
        self:Skip("Defaults / VariableStore / Engine unavailable")
        return
    end

    local NAME = "combat_check_var"
    local EXPECTED = "GEMS_UNDERSCORE_OK"

    -- Surface 1: the pattern must capture an underscore-containing name.
    local captured = ("~" .. NAME .. "~"):match(D.VAR_PATTERN)
    if captured ~= NAME then
        self:Fail("D.VAR_PATTERN did not capture underscore name; got " .. tostring(captured))
        return
    end

    -- Surface 2: the validator must accept the same name (idempotent with the pattern).
    if VS:ValidateName(NAME) ~= true then
        self:Fail("VS:ValidateName rejected underscore name " .. NAME)
        return
    end

    -- Surface 3: full runtime substitution. Insert a temp variable, then restore
    -- any pre-existing one on teardown so a real user variable is never clobbered.
    local saved = VS:Get(NAME)
    VS:Set(NAME, { funct = string.format("%q", EXPECTED) })

    local ok, resolved = pcall(function()
        return Engine:SubstituteVariables("~" .. NAME .. "~")
    end)

    if saved then
        VS:Set(NAME, saved)
    else
        VS:Delete(NAME)
    end

    if not ok then
        self:Fail("SubstituteVariables threw: " .. tostring(resolved))
        return
    end
    if resolved == EXPECTED then
        self:Pass()
    else
        self:Fail("expected '" .. EXPECTED .. "', got '" .. tostring(resolved) .. "'")
    end
end)

-- end of Test/conditions_spec.lua
