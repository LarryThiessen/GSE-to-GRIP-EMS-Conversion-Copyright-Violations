-- GRIP-EMS: Test spec for the v2.3.3 export envelope enrichment
--
-- Created:    2026-07-02
-- Updated:    2026-07-02
-- Patch: 12.0.7 Midnight (Retail LIVE)
--
-- Registers tests in TestSuite under category "export_enrichment" covering:
--   insights      -- GE.BuildInsights spellsUsed aggregation + modifiersUsed dedup
--   dependencies  -- GE.BuildDependenciesField merged wire field (nil when empty)
--   exportedBy    -- GE.BuildExportedBy privacy modes (private / pseudonymous / public)
--   collection    -- GE.BuildCollectionPayload per-sequence single-path parity +
--                    envelope exportedAt / schemaRev
--   carry         -- LegacyImport.ProcessSequence native arm carries
--                    originalSignatureV2 + forkedFromChain (v2.3.3 bug fix)
--   envelope      -- GE.Export envelope exportedAt / schemaRev / insights.stepCount
--
-- Seam note (carry test): the REAL LI.ProcessSequence is called directly with
-- GRIPEMS.Engine swapped for a capture stub (the same harness shape
-- test_forge_import_provenance.lua uses), so the carry arm runs exactly as
-- shipped and the stored seqData is read back from the stub -- no splice.
--
-- Dual-mode: in-game it loads as a normal *_spec.lua via /gems test. Run
-- directly under plain Lua 5.1 (lua Test/export_enrichment_spec.lua, from the
-- EMS repo root) it bootstraps the REAL Defaults + Identity + GRIPExport +
-- ExportPreview + LegacyImport modules in a headless sandbox and runs its own
-- tests. Exit code 0 = all passed, 1 = at least one fail.

local ADDON_NAME, GRIPEMS = ...

local standalone = false

-- ---------------------------------------------------------------------------
-- Headless bootstrap (only when not loaded by the game client).
-- ---------------------------------------------------------------------------

if not GRIPEMS then
    standalone = true
    local addonName = "GRIP-EMS"

    -- Globals the shipped modules expect that plain Lua 5.1 does not provide.
    if not _G.strmatch then
        _G.strmatch = string.match
    end
    if not _G.strlower then
        _G.strlower = string.lower
    end
    if not _G.strupper then
        _G.strupper = string.upper
    end
    if not _G.strfind then
        _G.strfind = string.find
    end
    if not _G.strtrim then
        _G.strtrim = function(s)
            return (s:gsub("^%s+", ""):gsub("%s+$", ""))
        end
    end
    if not _G.format then
        _G.format = string.format
    end
    if not _G.time then
        _G.time = os.time
    end
    if not _G.GetLocale then
        _G.GetLocale = function()
            return "enUS"
        end
    end
    -- ProcessSequence derives the author class from the player class.
    if not _G.UnitClass then
        _G.UnitClass = function()
            return "Warrior", "WARRIOR", 1
        end
    end
    -- Identity:GetCurrent touches BNet + name/realm APIs. No BattleTag forces
    -- the deterministic name-realm fallback path.
    if not _G.UnitName then
        _G.UnitName = function()
            return "Testchar"
        end
    end
    if not _G.BNGetInfo then
        _G.BNGetInfo = function()
            return nil, nil
        end
    end
    if not _G.GetRealmName then
        _G.GetRealmName = function()
            return "TestRealm"
        end
    end
    -- Identity.lua load-time frame/timer surface.
    if not _G.CreateFrame then
        _G.CreateFrame = function()
            return setmetatable({}, {
                __index = function()
                    return function() end
                end,
            })
        end
    end
    _G.C_Timer = _G.C_Timer or {}
    _G.C_Timer.After = _G.C_Timer.After or function() end

    -- Minimal AceLocale: every key resolves to itself.
    local locale = setmetatable({}, {
        __index = function(_, key)
            return key
        end,
    })
    if not _G.LibStub then
        _G.LibStub = function()
            return {
                GetLocale = function()
                    return locale
                end,
                NewLocale = function()
                    return locale
                end,
            }
        end
    end

    -- Locate a repo file from the EMS root, the Test dir, or the Hub root.
    local function loadModule(relPath)
        local prefixes = { "", "../", "GRIP/EMS/" }
        for _, prefix in ipairs(prefixes) do
            -- loadfile is dev-harness file I/O, intentionally outside the WoW std.
            -- selene: allow(undefined_variable)
            local chunk = loadfile(prefix .. relPath)
            if chunk then
                return chunk
            end
        end
        error("could not locate " .. relPath .. " (run from the EMS repo root)")
    end

    GRIPEMS = {
        version = "headless",
        Print = function() end,
        Debug = function() end,
    }

    -- Engine capture stub: BuildCollectionPayload / GE.Export read .sequences;
    -- ProcessSequence hands the finished seqData to ActivateSequence.
    GRIPEMS.Engine = {
        sequences = {},
        ActivateSequence = function(self, name, seqData)
            self.sequences[name] = seqData
        end,
        RegisterSequenceOnly = function(self, name, seqData)
            self.sequences[name] = seqData
        end,
        GetActiveVersion = function(_, seqData)
            if not seqData or not seqData.versions then
                return nil
            end
            local idx = seqData.defaultVersion or 1
            return seqData.versions[idx] or seqData.versions[1]
        end,
    }

    -- GRIPExport captures SpellCache / VariableStore / Serialization as
    -- file-locals at load, so all three stubs must exist BEFORE loadModule.
    GRIPEMS.SpellCache = {
        TranslateMacrotext = function(_, text)
            return text
        end,
        TagActionsToIDs = function() end,
    }
    GRIPEMS.VariableStore = {
        Get = function()
            return nil
        end,
    }
    -- Reversible Encode/Decode: Encode stashes the real payload table behind a
    -- token so the envelope test can read back what GE.Export actually built.
    local encodeStash = {}
    GRIPEMS.Serialization = {
        Encode = function(payload)
            encodeStash[#encodeStash + 1] = payload
            return true, "STASH#" .. #encodeStash
        end,
        Decode = function(s)
            local n = tonumber(type(s) == "string" and s:match("^STASH#(%d+)$") or nil)
            if not n or not encodeStash[n] then
                return false, "unknown stash token"
            end
            return true, encodeStash[n], "EMS1"
        end,
    }

    -- SavedVariables stubs: ProcessSequence's SpellCache-not-ready fallback
    -- writes GRIP_EMS_DB.pendingTagMigration; the dormant path writes
    -- GRIP_EMS_CHAR.sequences.
    _G.GRIP_EMS_DB = {}
    _G.GRIP_EMS_CHAR = { sequences = {} }

    -- Load the REAL modules under test (WoW addon vararg contract).
    loadModule("Data/Defaults.lua")(addonName, GRIPEMS)
    loadModule("Engine/Identity.lua")(addonName, GRIPEMS)
    loadModule("Import/GRIPExport.lua")(addonName, GRIPEMS)
    loadModule("Import/ExportPreview.lua")(addonName, GRIPEMS)
    loadModule("Import/LegacyImport.lua")(addonName, GRIPEMS)

    -- TestSuite shim mirroring the in-game Pass/Fail/Skip contract.
    local current
    local TS = { tests = {} }
    function TS:Register(name, category, fn)
        self.tests[#self.tests + 1] = { name = name, category = category, fn = fn }
    end
    function TS:Pass()
        current.status = "pass"
    end
    function TS:Fail(msg)
        current.status = "fail"
        current.message = msg or "no reason"
    end
    function TS:Skip(msg)
        current.status = "skip"
        current.message = msg or ""
    end
    function TS:Assert(cond, msg)
        if not cond then
            self:Fail(msg or "assertion failed")
        end
    end
    function TS:RunStandalone()
        local passed, failed, skipped = 0, 0, 0
        for _, t in ipairs(self.tests) do
            current = { status = "pending" }
            local runOk, err = pcall(t.fn, self)
            if not runOk then
                current.status = "fail"
                current.message = "error: " .. tostring(err)
            end
            if current.status == "pass" then
                passed = passed + 1
                print("PASS  " .. t.name)
            elseif current.status == "skip" then
                skipped = skipped + 1
                print("SKIP  " .. t.name .. " -- " .. tostring(current.message))
            else
                failed = failed + 1
                print("FAIL  " .. t.name .. " -- " .. tostring(current.message))
            end
        end
        print(string.format("RESULT %d passed, %d failed, %d skipped", passed, failed, skipped))
        return failed
    end
    GRIPEMS.TestSuite = TS
end

-- ---------------------------------------------------------------------------
-- Shared spec body (runs both in-game and headless).
-- ---------------------------------------------------------------------------

local TS = GRIPEMS.TestSuite
if not TS then
    return
end

local CATEGORY = "export_enrichment"

-- Assertion helper: returns false (and marks the test failed) on mismatch so
-- the caller can early-return.
local function eq(self, expected, actual, label)
    if expected ~= actual then
        self:Fail((label or "value") .. ": expected " .. tostring(expected) .. ", got " .. tostring(actual))
        return false
    end
    return true
end

-- ===========================================================================
-- GE.BuildInsights
-- ===========================================================================

TS:Register("Export enrichment: BuildInsights aggregates spellsUsed sorted by id", CATEGORY, function(self)
    local GE = GRIPEMS.GRIPExport
    if not GE or not GE.BuildInsights then
        self:Skip("GE.BuildInsights not available")
        return
    end
    -- {spell:34026} appears twice (step 1 + keyPress), {spell:217200} once.
    local exportVersions = {
        {
            steps = { "/cast [mod:shift] {spell:34026}", "/cast {spell:217200}" },
            keyPress = "/use {spell:34026}",
        },
    }
    local insights = GE.BuildInsights("_TS_EnrichInsights", { defaultVersion = 1 }, exportVersions)
    if not eq(self, "table", type(insights), "insights is a table") then
        return
    end
    if not eq(self, 2, insights.stepCount, "stepCount reads the default version") then
        return
    end
    if not eq(self, 2, insights.stepCounts and insights.stepCounts[1], "stepCounts[1] per-version count") then
        return
    end
    local spells = insights.spellsUsed
    if not eq(self, "table", type(spells), "spellsUsed is a table") then
        return
    end
    if not eq(self, 2, #spells, "exactly two distinct spell ids") then
        return
    end
    if not eq(self, 34026, spells[1].id, "entry 1 id (sorted ascending)") then
        return
    end
    if not eq(self, 2, spells[1].count, "entry 1 count (step + keyPress)") then
        return
    end
    if not eq(self, 217200, spells[2].id, "entry 2 id") then
        return
    end
    if not eq(self, 1, spells[2].count, "entry 2 count") then
        return
    end
    self:Pass()
end)

TS:Register("Export enrichment: BuildInsights dedupes and sorts modifiersUsed", CATEGORY, function(self)
    local GE = GRIPEMS.GRIPExport
    if not GE or not GE.BuildInsights then
        self:Skip("GE.BuildInsights not available")
        return
    end
    local exportVersions = {
        {
            steps = { "/cast [mod:shift] Alpha", "/cast [modifier:ctrl,alt] Beta" },
        },
    }
    local insights = GE.BuildInsights("_TS_EnrichMods", { defaultVersion = 1 }, exportVersions)
    local mods = insights and insights.modifiersUsed
    if not eq(self, "table", type(mods), "modifiersUsed is a table") then
        return
    end
    if not eq(self, 3, #mods, "three distinct modifier tokens") then
        return
    end
    if not eq(self, "alt", mods[1], "modifiers sorted: alt first") then
        return
    end
    if not eq(self, "ctrl", mods[2], "modifiers sorted: ctrl second") then
        return
    end
    if not eq(self, "shift", mods[3], "modifiers sorted: shift last") then
        return
    end
    self:Pass()
end)

-- ===========================================================================
-- GE.BuildDependenciesField
-- ===========================================================================

TS:Register(
    "Export enrichment: BuildDependenciesField scans embeds + variables, nil when empty",
    CATEGORY,
    function(self)
        local GE = GRIPEMS.GRIPExport
        if not GE or not GE.BuildDependenciesField then
            self:Skip("GE.BuildDependenciesField not available")
            return
        end
        local deps = GE.BuildDependenciesField({}, {
            { steps = { "/click GRIPEMS_SubSeq", "/cast ~myvar~" } },
        })
        if not eq(self, "table", type(deps), "a sequence with deps yields a table") then
            return
        end
        if not eq(self, "SubSeq", deps.Sequences and deps.Sequences[1], "embedded /click GRIPEMS_* captured") then
            return
        end
        if not eq(self, "myvar", deps.Variables and deps.Variables[1], "tilde variable token captured") then
            return
        end
        local none = GE.BuildDependenciesField({}, {
            { steps = { "/cast Fireball" } },
        })
        if not eq(self, nil, none, "no macros, embeds, or variables keeps the key off the wire") then
            return
        end
        self:Pass()
    end
)

-- ===========================================================================
-- GE.BuildExportedBy
-- ===========================================================================

TS:Register("Export enrichment: BuildExportedBy honours privacy modes", CATEGORY, function(self)
    local GE = GRIPEMS.GRIPExport
    if not GE or not GE.BuildExportedBy then
        self:Skip("GE.BuildExportedBy not available")
        return
    end
    -- Fixture identity + config; restore the live modules BEFORE asserting.
    local savedIdentity = GRIPEMS.Identity
    local savedDB = _G.GRIP_EMS_DB
    GRIPEMS.Identity = {
        GetCurrent = function()
            return { displayName = "Testchar", identityHash = "HASH1234", realm = "TestRealm" }
        end,
    }
    _G.GRIP_EMS_DB = { config = { pseudonym = "MaskedAuthor" } }

    local priv = GE.BuildExportedBy("private")
    local pseu = GE.BuildExportedBy("pseudonymous")
    local publ = GE.BuildExportedBy("public")

    GRIPEMS.Identity = savedIdentity
    _G.GRIP_EMS_DB = savedDB

    if not eq(self, nil, priv, "private mode omits the block entirely") then
        return
    end
    if not eq(self, "table", type(pseu), "pseudonymous mode returns a block") then
        return
    end
    if not eq(self, "MaskedAuthor", pseu and pseu.name, "pseudonymous name is the configured pseudonym") then
        return
    end
    if not eq(self, "pseudonymous", pseu and pseu.mode, "pseudonymous mode field") then
        return
    end
    if not eq(self, "HASH1234", pseu and pseu.identity, "pseudonymous keeps the identity hash") then
        return
    end
    if not eq(self, nil, pseu and pseu.realm, "pseudonymous omits the realm") then
        return
    end
    if not eq(self, "table", type(publ), "public mode returns a block") then
        return
    end
    if not eq(self, "Testchar", publ and publ.name, "public name is the display name") then
        return
    end
    if not eq(self, "TestRealm", publ and publ.realm, "public carries the realm") then
        return
    end
    if not eq(self, "HASH1234", publ and publ.identity, "public carries the identity hash") then
        return
    end
    self:Pass()
end)

-- ===========================================================================
-- GE.BuildCollectionPayload -- per-sequence single-path parity
-- ===========================================================================

TS:Register("Export enrichment: collection payload carries the single-path metadata block", CATEGORY, function(self)
    local GE = GRIPEMS.GRIPExport
    local Engine = GRIPEMS.Engine
    local D = GRIPEMS.Defaults
    if not GE or not GE.BuildCollectionPayload or not Engine or not D then
        self:Skip("GE.BuildCollectionPayload or Engine not available")
        return
    end
    local nameA, nameB = "_TS_EnrichColA", "_TS_EnrichColB"
    local savedA, savedB = Engine.sequences[nameA], Engine.sequences[nameB]
    Engine.sequences[nameA] = {
        data = {
            versions = { { stepFunction = "Sequential", steps = { "/cast Alpha" } } },
            defaultVersion = 1,
            classID = 1,
            specID = 71,
            author = "AuthorA",
            description = "DescA",
            createdAt = 1111,
            updatedAt = 2222,
        },
    }
    Engine.sequences[nameB] = {
        data = {
            versions = { { stepFunction = "Sequential", steps = { "/cast Beta", "/cast Gamma" } } },
            defaultVersion = 1,
            classID = 2,
            specID = 65,
            author = "AuthorB",
            description = "DescB",
            createdAt = 3333,
            updatedAt = 4444,
        },
    }

    local payload = GE.BuildCollectionPayload({ nameA, nameB }, nil, nil, nil)

    Engine.sequences[nameA], Engine.sequences[nameB] = savedA, savedB

    if not eq(self, "table", type(payload), "payload built") then
        return
    end
    if not eq(self, true, payload.exportedAt ~= nil, "envelope exportedAt present") then
        return
    end
    if not eq(self, D.EMS_EXPORT_SCHEMA_REV, payload.schemaRev, "envelope schemaRev matches the constant") then
        return
    end
    local a = payload.sequences and payload.sequences[nameA]
    local b = payload.sequences and payload.sequences[nameB]
    if not eq(self, "table", type(a), "sequence A emitted") then
        return
    end
    if not eq(self, "table", type(b), "sequence B emitted") then
        return
    end
    if not eq(self, "AuthorA", a.author, "A author") then
        return
    end
    if not eq(self, "DescA", a.description, "A description") then
        return
    end
    if not eq(self, 1, a.classID, "A classID") then
        return
    end
    if not eq(self, 71, a.specID, "A specID") then
        return
    end
    if not eq(self, 1111, a.createdAt, "A createdAt preserved") then
        return
    end
    if not eq(self, 2222, a.updatedAt, "A updatedAt preserved") then
        return
    end
    if not eq(self, 1, a.versionCount, "A versionCount") then
        return
    end
    if not eq(self, "table", type(a.insights), "A insights computed") then
        return
    end
    if not eq(self, 1, a.insights.stepCount, "A insights stepCount") then
        return
    end
    if not eq(self, "AuthorB", b.author, "B author") then
        return
    end
    if not eq(self, 2, b.classID, "B classID") then
        return
    end
    if not eq(self, 65, b.specID, "B specID") then
        return
    end
    if not eq(self, 3333, b.createdAt, "B createdAt preserved") then
        return
    end
    if not eq(self, "table", type(b.insights), "B insights computed") then
        return
    end
    if not eq(self, 2, b.insights.stepCount, "B insights stepCount") then
        return
    end
    self:Pass()
end)

-- ===========================================================================
-- LegacyImport.ProcessSequence -- V2 signature + fork chain carry (bug fix)
-- ===========================================================================

TS:Register("Export enrichment: ProcessSequence carries originalSignatureV2 + forkedFromChain", CATEGORY, function(self)
    local LI = GRIPEMS.LegacyImport
    if not LI or not LI.ProcessSequence then
        self:Skip("LI.ProcessSequence not available")
        return
    end
    -- Swap the engine for a capture stub so the REAL ProcessSequence runs as
    -- shipped without activating anything in the live engine (seam note in
    -- the file header). Restore BEFORE asserting.
    local savedEngine = GRIPEMS.Engine
    GRIPEMS.Engine = {
        sequences = {},
        ActivateSequence = function(engineSelf, name, seqData)
            engineSelf.sequences[name] = seqData
        end,
        RegisterSequenceOnly = function(engineSelf, name, seqData)
            engineSelf.sequences[name] = seqData
        end,
    }
    local savedDB = _G.GRIP_EMS_DB
    _G.GRIP_EMS_DB = _G.GRIP_EMS_DB or {}

    local results = { names = {}, warnings = {}, count = 0, stepCounts = {}, stepFunctions = {} }
    local wireSeq = {
        MacroVersions = { { Actions = { { Type = "spell", Spell = "Fireball" } } } },
        originalAuthor = "SomeAuthor",
        originalSignatureV2 = "abc",
        forkedFromChain = { { author = "Ancestor" } },
    }
    local callOk, okP, errP = pcall(LI.ProcessSequence, "_TS_EnrichCarrySeq", wireSeq, results)
    local stored = GRIPEMS.Engine.sequences["_TS_EnrichCarrySeq"]

    GRIPEMS.Engine = savedEngine
    _G.GRIP_EMS_DB = savedDB

    if not eq(self, true, callOk, "ProcessSequence did not error: " .. tostring(okP)) then
        return
    end
    if not eq(self, true, okP, "ProcessSequence succeeded: " .. tostring(errP)) then
        return
    end
    if not eq(self, "table", type(stored), "seqData stored via the capture stub") then
        return
    end
    if not eq(self, "SomeAuthor", stored.originalAuthor, "carry arm fired (originalAuthor verbatim)") then
        return
    end
    if not eq(self, "abc", stored.originalSignatureV2, "originalSignatureV2 carried (v2.3.3 fix)") then
        return
    end
    if not eq(self, "table", type(stored.forkedFromChain), "forkedFromChain carried as a table") then
        return
    end
    if not eq(self, 1, #stored.forkedFromChain, "forkedFromChain entry count") then
        return
    end
    if
        not eq(self, "Ancestor", stored.forkedFromChain[1] and stored.forkedFromChain[1].author, "chain entry intact")
    then
        return
    end
    self:Pass()
end)

-- ===========================================================================
-- GE.Export -- enriched envelope
-- ===========================================================================

TS:Register("Export enrichment: GE.Export envelope carries exportedAt + schemaRev + insights", CATEGORY, function(self)
    local GE = GRIPEMS.GRIPExport
    local Engine = GRIPEMS.Engine
    local S = GRIPEMS.Serialization
    local D = GRIPEMS.Defaults
    if not GE or not GE.Export or not Engine or not S or not S.Decode or not D then
        self:Skip("GE.Export or Serialization not available")
        return
    end
    local name = "_TS_EnrichExportSeq"
    local saved = Engine.sequences[name]
    Engine.sequences[name] = {
        data = {
            versions = { { stepFunction = "Sequential", steps = { "/cast Alpha", "/cast Beta" } } },
            defaultVersion = 1,
            classID = 1,
        },
    }

    local okX, encoded = GE.Export(name)
    local decOk, payload
    if okX then
        decOk, payload = S.Decode(encoded)
    end

    Engine.sequences[name] = saved

    if not eq(self, true, okX, "GE.Export succeeded: " .. tostring(encoded)) then
        return
    end
    if not eq(self, true, decOk, "encoded payload decodes: " .. tostring(payload)) then
        return
    end
    if not eq(self, "table", type(payload), "decoded payload is a table") then
        return
    end
    if not eq(self, true, payload.exportedAt ~= nil, "envelope exportedAt present") then
        return
    end
    if not eq(self, D.EMS_EXPORT_SCHEMA_REV, payload.schemaRev, "envelope schemaRev matches the constant") then
        return
    end
    local insights = payload.sequence and payload.sequence.insights
    if not eq(self, "table", type(insights), "sequence insights present") then
        return
    end
    if not eq(self, 2, insights.stepCount, "insights stepCount matches the fixture step count") then
        return
    end
    self:Pass()
end)

-- ---------------------------------------------------------------------------
-- Headless runner entry point.
-- ---------------------------------------------------------------------------

if standalone then
    -- os.exit is dev-harness only; the game client never reaches this branch.
    -- selene: allow(undefined_variable)
    os.exit(GRIPEMS.TestSuite:RunStandalone() > 0 and 1 or 0)
end
