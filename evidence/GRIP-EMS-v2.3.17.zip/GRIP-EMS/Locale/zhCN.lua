-- GRIP-EMS: Locale-zhCN
-- Created: 2026-04-03
-- Updated: 2026-08-01
-- Patch: 12.0.7.68275 Midnight (Retail LIVE)

-- GRIP-EMS: Simplified Chinese Locale (Machine Translated, Needs Review)
-- All user-facing strings. L["key"] = translated value

local L = LibStub("AceLocale-3.0"):NewLocale("GRIP-EMS", "zhCN")
if not L then
    return
end

-- GEMS_KEYBINDS_ universal-parity backfill 2026-06-12 (MT bootstrap, native review pending)
L["GEMS_KEYBINDS_LOST_WARN"] = "这次没能载入你的序列按键绑定，但已保存的绑定仍然还在。" -- MT
L["GEMS_KEYBINDS_LOST_HINT"] = "输入 /gems binds restore 即可恢复。" -- MT
L["GEMS_KEYBINDS_RESTORE_DONE"] = "已恢复 %d 个按键绑定。" -- MT
L["GEMS_KEYBINDS_RESTORE_NONE"] = "还没有可用于恢复的已保存数据。" -- MT
L["GEMS_KEYBINDS_PRUNED_NOTICE"] =
    "已从被删除的配置中移除 %d 个按键绑定。输入 /gems binds restore 可以找回。" -- MT
L["GEMS_KEYBINDS_CLEARED_NOTICE"] = "已从该配置清除 %d 个按键绑定。" -- MT

-- GEMS_ universal-parity backfill 2026-06-04 (MT bootstrap, native review pending)
L["GEMS_HOLD_FREEZE_HEADER"] = "按住以冻结" -- MT
L["GEMS_HOLD_FREEZE_ENABLE"] = "启用按住以冻结" -- MT
L["GEMS_HOLD_FREEZE_ENABLE_DESC"] =
    "按住一个修饰键可将当前激活的序列暂停在当前步骤。按住期间它不会前进或施放，松开后会从暂停处继续。" -- MT
L["GEMS_HOLD_FREEZE_MODIFIER"] = "冻结修饰键" -- MT
L["GEMS_HOLD_FREEZE_MODIFIER_DESC"] =
    "按住哪个修饰键时冻结序列。如果某个序列将同一修饰键用于变体，则会改为运行该变体。如果你也在此修饰键上设置了重置，则按住期间冻结优先。" -- MT
L["GEMS_HOLD_FREEZE_MOD_ALT"] = "Alt" -- MT
L["GEMS_HOLD_FREEZE_MOD_CTRL"] = "Ctrl" -- MT
L["GEMS_HOLD_FREEZE_MOD_SHIFT"] = "Shift" -- MT
L["GEMS_HOLD_FREEZE_CONFLICT_RESET"] =
    "按住以冻结：你也在 %s 上设置了重置。按住该修饰键期间，冻结优先于重置。" -- MT
L["GEMS_HOLD_FREEZE_CONFLICT_VARIANT"] =
    "按住以冻结：序列 %s 将 %s 用于变体，因此会在那里运行变体而不是冻结。" -- MT
L["GEMS_RESTRICTED_PAUSED"] =
    "在受保护操作受限期间（战斗、竞技场、史诗钥石或团队首领战），已暂停 %d 个序列。限制解除后会自动重新启用。" -- MT
L["GEMS_SETTING_UNRESOLVED_WARN_LABEL"] = "在聊天中警告无法识别的法术" -- MT
L["GEMS_SETTING_UNRESOLVED_WARN_DESC"] =
    "当序列引用的法术名称在你当前的法术书中找不到时，在聊天中显示一条消息。默认关闭。受影响的序列始终会在列表中以图标标记。" -- MT
L["GEMS_UI_CTX_ENABLE_STEP"] = "启用步骤" -- MT
L["GEMS_UI_CTX_DISABLE_STEP"] = "禁用步骤" -- MT
L["GEMS_UI_STEP_DISABLED_PREFIX"] = "(关) " -- MT
L["GEMS_UI_STEP_DISABLE_CONVERTED"] = "此序列现在是动作序列。撤销可恢复。" -- MT

-- General
L["GRIP - Enhanced Macro Sequencer"] = "GRIP - 增强宏序列器" -- MT

-- Slash command help
L["GEMS_HELP_HEADER"] = "可用命令:" -- MT
L["GEMS_HELP_NONE"] = "  /gems - 打开主窗口(若窗口未就绪则显示帮助)" -- MT
L["GEMS_HELP_HELP"] = "  /gems help - 显示此帮助信息" -- MT
L["GEMS_HELP_CREATE"] = "  /gems create [name] - 创建测试序列(默认:TestSeq)" -- MT
L["GEMS_HELP_DELETE"] = "  /gems delete <name> - 删除序列及其宏存根" -- MT
L["GEMS_HELP_LIST"] = "  /gems list - 列出所有活动序列" -- MT
L["GEMS_HELP_TEST"] = "  /gems test <name> - 手动推进步骤(调试)" -- MT
L["GEMS_HELP_RESET"] = "  /gems reset <name> - 将序列重置到第1步" -- MT
L["GEMS_HELP_DEBUG"] = "  /gems debug - 切换调试模式" -- MT
L["GEMS_HELP_STATUS"] = "  /gems status - 显示运行状态" -- MT
L["GEMS_HELP_TESTLOCALE"] = "  /gems testlocale - 测试本地化翻译" -- MT
L["GEMS_HELP_TESTSPELLID"] = "  /gems testspellid - 测试法术ID解析" -- MT

-- Slash command responses
L["GEMS_VERSION"] = "|cFF00CC66GRIP|r - 增强宏序列器 |cFFAAAAAAv%s|r" -- MT
L["GEMS_DEBUG_ENABLED"] = "调试模式 |cFF00FF00已启用|r。" -- MT
L["GEMS_DEBUG_DISABLED"] = "调试模式 |cFFFF4444已禁用|r。" -- MT
L["GEMS_UNKNOWN_CMD"] = "未知命令 '%s'。输入 /gems help 查看可用命令。" -- MT

-- Sequence creation/deletion
L["GEMS_CREATED"] = "序列 |cFF00FF00'%s'|r 已创建,共 %d 步骤(%s)。" -- MT
L["GEMS_DELETED"] = "序列 |cFF00FF00'%s'|r 已删除。" -- MT
L["GEMS_ALREADY_EXISTS"] = "序列 '%s' 已存在。请先使用 /gems delete %s 删除。" -- MT
L["GEMS_NOT_FOUND"] = "未找到序列 '%s'。" -- MT
L["GEMS_DELETE_NEED_NAME"] = "用法: /gems delete <name>" -- MT

-- Sequence list
L["GEMS_LIST_HEADER"] = "活动序列 (%d):" -- MT
L["GEMS_LIST_ENTRY"] = "  |cFF00FF00%s|r - %d 步骤,步骤 %d/%d (%s)" -- MT
L["GEMS_LIST_EMPTY"] = "无活动序列。使用 /gems create 创建一个。" -- MT

-- Sequence test/reset
L["GEMS_TEST_NEED_NAME"] = "用法: /gems test <name>" -- MT
L["GEMS_TEST_ADVANCED"] = "|cFF00FF00%s|r:已推进到步骤 %d/%d。" -- MT
L["GEMS_RESET_NEED_NAME"] = "用法: /gems reset <name>" -- MT
L["GEMS_RESET_DONE"] = "|cFF00FF00%s|r:已重置到第1步。" -- MT

-- Status
L["GEMS_STATUS_HEADER"] = "--- GRIP-EMS 状态 ---" -- MT
L["GEMS_STATUS_SEQUENCES"] = "活动序列:%d" -- MT
L["GEMS_STATUS_MACROS"] = "宏槽位:%d/%d 角色专属已使用" -- MT
L["GEMS_STATUS_KEYDOWN"] = "ActionButtonUseKeyDown:%s (按钮覆盖:true)" -- MT
L["GEMS_STATUS_SQW"] = "SpellQueueWindow:%s 毫秒" -- MT
L["GEMS_STATUS_OOC"] = "战斗外队列:%d 待处理" -- MT
L["GEMS_STATUS_LOADOUT"] = "  Saved loadout: %d (%s)" -- MT
L["GEMS_STATUS_LOADOUT_NONE"] = "  Saved loadout: not selected yet" -- MT
L["GEMS_STATUS_PENDING_ACTIVE"] = "  Pending switch: target %d, elapsed %.1fs" -- MT
L["GEMS_STATUS_PENDING_NONE"] = "  Pending switch: no switch in progress" -- MT
L["GEMS_LM_FAIL_COMMIT_REJECTED"] = "Loadout switch failed: server rejected commit for build %d." -- MT
L["GEMS_LM_FAIL_TIMEOUT"] = "Loadout switch timed out after 15 seconds for build %d." -- MT
L["GEMS_LM_FAIL_PARTIAL"] = "Loadout switch ended with a different build active (target %d, got %d)." -- MT
L["GEMS_LM_FAIL_CANNOT_EDIT_TALENTS"] = "Cannot switch loadouts right now (in combat or restricted)." -- MT

-- Step function descriptions
L["GEMS_STEPFUNC_SEQUENTIAL_DESC"] = "按顺序循环执行步骤:1, 2, 3, ..., N, 1, ..." -- MT
L["GEMS_STEPFUNC_RANDOM_DESC"] = "每次按下随机选择一个步骤" -- MT
L["GEMS_STEPFUNC_PRIORITY_DESC"] = "编号较高的步骤比较低的更频繁触发(加权)" -- MT
L["GEMS_STEPFUNC_REVERSEPRIORITY_DESC"] = "反向优先级:较后的步骤(列表底部)比较前的更频繁触发" -- MT

-- Validation errors
L["GEMS_STEP_TOO_LONG"] = "步骤 %d 过长(%d 字符,最大 %d)。" -- MT
L["GEMS_STEP_NIL"] = "步骤 %d 缺失。" -- MT
L["GEMS_ERR_NO_NAME"] = "需要序列名称。" -- MT

-- Macro manager
L["GEMS_ERR_NO_MACRO_SLOTS"] = "没有可用的宏槽位(此角色已使用 %d/%d 个槽位)。" -- MT
L["GEMS_ERR_MACRO_CREATE_FAILED"] = "无法为序列 '%s' 创建宏。" -- MT
L["GEMS_MACRO_CREATED"] = "宏存根 '%s' 已创建(槽位 %d)。" -- MT
L["GEMS_MACROS_SCANNED"] = "已回收 %d 个现有的 GRIP-EMS 宏存根。" -- MT
L["GEMS_WARN_KP_LINES_TRIMMED"] = "按下:%d/%d 行适合步骤宏(255字符限制)" -- MT
L["GEMS_WARN_KR_LINES_TRIMMED"] = "释放:%d/%d 行适合步骤宏(255字符限制)" -- MT
L["GEMS_WARN_KP_STEP_OVERFLOW"] = "按下:适合 %d/%d 步骤(由于255字符限制,%d 个步骤无按下命令运行)" -- MT
L["GEMS_KP_STATUS_ALL_FIT"] = "适合所有 %d 步骤" -- MT
L["GEMS_KP_STATUS_PARTIAL"] = "适合 %d/%d 步骤(255字符限制)" -- MT
L["GEMS_KP_STATUS_NONE"] = "对任何步骤都过长(0/%d)" -- MT

-- OOC Queue
L["GEMS_OOC_QUEUED"] = "操作已加入战斗外处理队列。" -- MT
L["GEMS_OOC_PROCESSED"] = "已处理 %d 个排队操作。" -- MT
L["GEMS_OOC_REPLACED"] = "战斗外队列:已为 %s 替换 %s" -- MT
L["GEMS_OOC_PRIORITY_PROCESSED"] = "战斗外队列:已处理 %d 项(按优先级顺序)" -- MT

-- Keybind manager
L["GEMS_HELP_BIND"] = "  /gems bind <name> <key> - 绑定按键来触发序列(例如 CTRL-F12)" -- MT
L["GEMS_HELP_UNBIND"] = "  /gems unbind <name> - 移除序列的按键绑定" -- MT
L["GEMS_HELP_BINDS"] = "  /gems binds - 列出当前专精的所有按键绑定" -- MT
L["GEMS_BIND_SUCCESS"] = "已将 |cFF00FF00'%s'|r 绑定到 |cFFFFFF00%s|r。按下该键触发序列。" -- MT
L["GEMS_BIND_NEED_ARGS"] = "用法: /gems bind <name> <key> (例如 /gems bind TestSeq CTRL-F12)" -- MT
L["GEMS_UNBIND_SUCCESS"] = "已解除绑定 |cFF00FF00'%s'|r。" -- MT
L["GEMS_UNBIND_NO_BIND"] = "序列 '%s' 没有按键绑定。" -- MT
L["GEMS_UNBIND_NEED_NAME"] = "用法: /gems unbind <name>" -- MT
L["GEMS_BINDS_HEADER"] = "按键绑定(专精 %d):" -- MT
L["GEMS_BINDS_ENTRY"] = "  |cFFFFFF00%s|r -> |cFF00FF00%s|r" -- MT
L["GEMS_BINDS_EMPTY"] = "未设置按键绑定。使用 /gems bind <name> <key>。" -- MT
L["GEMS_KEYBINDS_LOADED"] = "已加载 %d 个按键绑定,专精 %d。" -- MT
L["GEMS_STATUS_KEYBINDS"] = "按键绑定:当前专精 %d 个" -- MT

-- IF action node UI surfaces (spec section 10)
L["GEMS_IF_COND_HINT"] = "e.g. mod:shift, combat, harm" -- MT
L["GEMS_IF_COND_TOOLTIP_TITLE"] = "Macro condition" -- MT
L["GEMS_IF_COND_TOOLTIP_BODY"] =
    "Type a WoW macro conditional. Comma-separated values are AND'd. Multiple bracket forms (e.g. [a][b]) are OR'd. Full reference: warcraft.wiki.gg/wiki/Macro_conditionals" -- MT
L["GEMS_IF_COND_INVALID"] = "Invalid condition" -- MT
L["GEMS_IF_PATH_SINGLE"] = "Single line" -- MT
L["GEMS_IF_PATH_TWO_LINE"] = "Two-line split" -- MT
L["GEMS_IF_PATH_PER_STEP"] = "Per-step" -- MT
L["GEMS_IF_PATH_FALL_THROUGH"] = "Fall-through" -- MT
L["GEMS_IF_PREVIEW_HEADER"] = "Compiled output" -- MT
L["GEMS_IF_PREVIEW_NEG_LABEL"] = "neg" -- MT
L["GEMS_IF_PREVIEW_EMPTY"] = "(no compiled output)" -- MT
L["GEMS_IF_LEN_WARN"] = "Approaching 255-char limit (%d)" -- MT
L["GEMS_IF_LEN_ERROR"] = "Exceeds 255-char limit (%d)" -- MT

-- IF action node combat-blocked command lint (spec section 10.8, 11.6, Phase H2)
L["GEMS_IF_LINT_COMBAT_BLOCKED_MARKER"] = "combat-blocked: %s" -- MT
L["GEMS_IF_LINT_COMBAT_BLOCKED_TOOLTIP_HEADER"] = "Combat-blocked commands:" -- MT
L["GEMS_IF_LINT_COMBAT_BLOCKED_HARD"] = "%s -- blocked in combat" -- MT
L["GEMS_IF_LINT_COMBAT_BLOCKED_PARTIAL"] = "%s -- partially blocked in combat" -- MT
L["GEMS_IF_LINT_COMBAT_BLOCKED_TOOLTIP_HINT"] = "Gate with [nocombat] in the Cond box, or move to an OOC sequence." -- MT
L["GEMS_IF_LINT_COMBAT_BLOCKED_VALIDATE_FMT"] = "Node %s: compiled step contains combat-blocked command %s" -- MT
L["GEMS_INTERLEAVE_OVERFLOW_LOOP_FMT"] =
    "Node %s: interval %s exceeds this loop's %s compiled steps. Clamped to %s so it still fires. Set the loop's Repeat to %s for an exact interval of %s." -- MT
L["GEMS_INTERLEAVE_OVERFLOW_ROOT_FMT"] =
    "Node %s: interval %s exceeds the sequence's %s base steps. Clamped to %s so it still fires; lower the interval to that or less for an exact interval." -- MT
L["GEMS_INTERLEAVE_BUDGET_FMT"] =
    "Node %s: the interleave copy budget (%s) is spent. This action emits %s of its %s copies. Lower an interval or remove an interleave." -- MT

-- IF action node conditional picker (spec section 10.7, Phase H1)
L["GEMS_IF_PICKER_TITLE"] = "Conditional picker" -- MT
L["GEMS_IF_PICKER_TAB_COMBAT"] = "Combat-relevant" -- MT
L["GEMS_IF_PICKER_TAB_GENERAL"] = "General-purpose" -- MT
L["GEMS_IF_PICKER_TAB_UI"] = "UI-state" -- MT
L["GEMS_IF_PICKER_APPLY"] = "Apply" -- MT
L["GEMS_IF_PICKER_CANCEL"] = "Cancel" -- MT
L["GEMS_IF_PICKER_NEGATE"] = "not" -- MT
L["GEMS_IF_PICKER_NEGATE_TOOLTIP"] =
    "Negate this conditional. mod:shift becomes nomod:shift, harm becomes noharm, etc. Spec section 5.2 (DeMorgan)." -- MT
L["GEMS_IF_PICKER_OR_GROUP_WARNING"] =
    "Multi-bracket OR groups not editable in picker (Phase H4). Use Cancel to keep the current value, or empty the Cond box and re-pick if you want a single-clause condition." -- MT

-- Combat-relevant rows
L["GEMS_IF_PICKER_COMBAT_LABEL"] = "combat" -- MT
L["GEMS_IF_PICKER_COMBAT_TOOLTIP"] =
    "True while you are in combat. Use to gate burst cooldowns or lockout-only abilities." -- MT
L["GEMS_IF_PICKER_NOCOMBAT_LABEL"] = "nocombat" -- MT
L["GEMS_IF_PICKER_NOCOMBAT_TOOLTIP"] =
    "True while you are out of combat. Use for pre-pull buffs, mount casts, or reset behaviours." -- MT
L["GEMS_IF_PICKER_HARM_LABEL"] = "harm" -- MT
L["GEMS_IF_PICKER_HARM_TOOLTIP"] = "True when your target is hostile. Pair with help in mixed friend/foe macros." -- MT
L["GEMS_IF_PICKER_HELP_LABEL"] = "help" -- MT
L["GEMS_IF_PICKER_HELP_TOOLTIP"] = "True when your target is friendly. Use for heals in mixed damage/heal macros." -- MT
L["GEMS_IF_PICKER_DEAD_LABEL"] = "dead" -- MT
L["GEMS_IF_PICKER_DEAD_TOOLTIP"] =
    "True when the target unit is dead. Use to swap to a resurrection spell or skip the cast." -- MT
L["GEMS_IF_PICKER_STEALTH_LABEL"] = "stealth" -- MT
L["GEMS_IF_PICKER_STEALTH_TOOLTIP"] =
    "True while in Stealth, Prowl, or Shadowmeld. Use for opener vs continuation branching." -- MT
L["GEMS_IF_PICKER_PVPCOMBAT_LABEL"] = "pvpcombat" -- MT
L["GEMS_IF_PICKER_PVPCOMBAT_TOOLTIP"] = "True while flagged for PvP combat. Use to swap PvP vs PvE talents or trinkets." -- MT
L["GEMS_IF_PICKER_CHANNELING_LABEL"] = "channelling" -- MT
L["GEMS_IF_PICKER_CHANNELING_TOOLTIP"] =
    "True while you are channelling a spell. Use to skip casts that would interrupt the channel." -- MT
L["GEMS_IF_PICKER_PET_LABEL"] = "pet" -- MT
L["GEMS_IF_PICKER_PET_TOOLTIP"] =
    "True when a pet (matching the optional name or family) is active. Leave the field empty to match any pet." -- MT
L["GEMS_IF_PICKER_NOPET_LABEL"] = "nopet" -- MT
L["GEMS_IF_PICKER_NOPET_TOOLTIP"] =
    "True when no pet is active. Used by the Hunter pattern to substitute a self-cast when soloing." -- MT
L["GEMS_IF_PICKER_PETBATTLE_LABEL"] = "petbattle" -- MT
L["GEMS_IF_PICKER_PETBATTLE_TOOLTIP"] = "True while in a pet battle. Use to swap to pet-battle abilities." -- MT
L["GEMS_IF_PICKER_MOD_LABEL"] = "mod:<key>" -- MT
L["GEMS_IF_PICKER_MOD_TOOLTIP"] =
    "True when the chosen modifier key is held. Pick shift, ctrl, alt, or an L/R variant for AoE vs single-target swaps." -- MT
L["GEMS_IF_PICKER_BUTTON_LABEL"] = "button:N" -- MT
L["GEMS_IF_PICKER_BUTTON_TOOLTIP"] =
    "True when the macro fired from the chosen mouse button or bind index. 1=left, 2=right, 3=middle, 4 and 5 are side buttons." -- MT
L["GEMS_IF_PICKER_PARTY_LABEL"] = "party" -- MT
L["GEMS_IF_PICKER_PARTY_TOOLTIP"] =
    "True while in a party. Use for group-only utility such as Battle Resurrection or party-target buffs." -- MT
L["GEMS_IF_PICKER_RAID_LABEL"] = "raid" -- MT
L["GEMS_IF_PICKER_RAID_TOOLTIP"] = "True while in a raid. Use for raid-only burst windows or cooldown alignment." -- MT
L["GEMS_IF_PICKER_EXISTS_LABEL"] = "exists" -- MT
L["GEMS_IF_PICKER_EXISTS_TOOLTIP"] =
    "True when the target unit exists. Pair with @focus or @mouseover so the macro has a fallback when the unit is gone." -- MT
L["GEMS_IF_PICKER_UNITVEHICLE_LABEL"] = "unithasvehicleui" -- MT
L["GEMS_IF_PICKER_UNITVEHICLE_TOOLTIP"] =
    "True when the unit is presenting a vehicle UI. Use to skip casts that would target the driver instead of the vehicle." -- MT

-- General-purpose rows
L["GEMS_IF_PICKER_MOUNTED_LABEL"] = "mounted" -- MT
L["GEMS_IF_PICKER_MOUNTED_TOOLTIP"] =
    "True while you are mounted. Common pattern: dismount in the true branch, cast a mount in the false branch." -- MT
L["GEMS_IF_PICKER_SWIMMING_LABEL"] = "swimming" -- MT
L["GEMS_IF_PICKER_SWIMMING_TOOLTIP"] = "True while you are swimming. Use to swap to a swim-form mount or aquatic spell." -- MT
L["GEMS_IF_PICKER_FLYING_LABEL"] = "flying" -- MT
L["GEMS_IF_PICKER_FLYING_TOOLTIP"] =
    "True while you are airborne on a flying mount. Use to skip ground-only casts mid-flight." -- MT
L["GEMS_IF_PICKER_FLYABLE_LABEL"] = "flyable" -- MT
L["GEMS_IF_PICKER_FLYABLE_TOOLTIP"] =
    "True in zones where standard flying is allowed. Pair with mount toggles for ground vs air swaps." -- MT
L["GEMS_IF_PICKER_ADVFLYABLE_LABEL"] = "advflyable" -- MT
L["GEMS_IF_PICKER_ADVFLYABLE_TOOLTIP"] =
    "True in zones where Skyriding is allowed. Use for sky vs ground mount swaps in modern zones." -- MT
L["GEMS_IF_PICKER_INDOORS_LABEL"] = "indoors" -- MT
L["GEMS_IF_PICKER_INDOORS_TOOLTIP"] =
    "True while indoors (mount-blocked area). Use to skip mount casts that would error or to fall back to a teleport." -- MT
L["GEMS_IF_PICKER_OUTDOORS_LABEL"] = "outdoors" -- MT
L["GEMS_IF_PICKER_OUTDOORS_TOOLTIP"] = "True while outdoors. Mirror of indoors; use for mount or ground-spell branches." -- MT
L["GEMS_IF_PICKER_RESTING_LABEL"] = "resting" -- MT
L["GEMS_IF_PICKER_RESTING_TOOLTIP"] =
    "True while resting in an inn or capital. Use for free-cast buffs or hearthstone shortcuts." -- MT
L["GEMS_IF_PICKER_GROUP_LABEL"] = "group" -- MT
L["GEMS_IF_PICKER_GROUP_TOOLTIP"] = "True while in any group (party or raid). Quick group-vs-solo branch." -- MT
L["GEMS_IF_PICKER_NOGROUP_LABEL"] = "nogroup" -- MT
L["GEMS_IF_PICKER_NOGROUP_TOOLTIP"] = "True when soloing. Use for solo burst that would be wasteful in a group context." -- MT
L["GEMS_IF_PICKER_SPEC_LABEL"] = "spec:N" -- MT
L["GEMS_IF_PICKER_SPEC_TOOLTIP"] =
    "True when the chosen specialisation slot (1-4) is active. Pair with utility branches per spec." -- MT
L["GEMS_IF_PICKER_FORM_LABEL"] = "form:N" -- MT
L["GEMS_IF_PICKER_FORM_TOOLTIP"] =
    "True when the chosen shapeshift or stance form is active. Druid, Warrior, and Rogue stance branches." -- MT
L["GEMS_IF_PICKER_STANCE_LABEL"] = "stance:N" -- MT
L["GEMS_IF_PICKER_STANCE_TOOLTIP"] = "Alias for form. Same semantics; kept for legacy macro compatibility." -- MT
L["GEMS_IF_PICKER_EQUIPPED_LABEL"] = "equipped:type" -- MT
L["GEMS_IF_PICKER_EQUIPPED_TOOLTIP"] =
    "True when the chosen item type is equipped (e.g. Sword, Shield, Polearm). Use for weapon-aware swaps." -- MT
L["GEMS_IF_PICKER_WORN_LABEL"] = "worn:type" -- MT
L["GEMS_IF_PICKER_WORN_TOOLTIP"] = "Alias for equipped. Same semantics." -- MT
L["GEMS_IF_PICKER_KNOWN_LABEL"] = "known:spell" -- MT
L["GEMS_IF_PICKER_KNOWN_TOOLTIP"] =
    "True when the chosen spell is known. Replaces the removed talent: conditional; type the spell name into the field." -- MT
L["GEMS_IF_PICKER_CANEXITVEHICLE_LABEL"] = "canexitvehicle" -- MT
L["GEMS_IF_PICKER_CANEXITVEHICLE_TOOLTIP"] =
    "True while in a vehicle that allows exiting. Pair with /run VehicleExit() guards." -- MT

-- UI-state rows
L["GEMS_IF_PICKER_BONUSBAR_LABEL"] = "bonusbar:N" -- MT
L["GEMS_IF_PICKER_BONUSBAR_TOOLTIP"] =
    "True when the chosen bonus action bar (1-10) is active. Pair with stance or form toggles." -- MT
L["GEMS_IF_PICKER_OVERRIDEBAR_LABEL"] = "overridebar" -- MT
L["GEMS_IF_PICKER_OVERRIDEBAR_TOOLTIP"] =
    "True when the override action bar is active (vehicle, possess, or quest override)." -- MT
L["GEMS_IF_PICKER_POSSESSBAR_LABEL"] = "possessbar" -- MT
L["GEMS_IF_PICKER_POSSESSBAR_TOOLTIP"] = "True when the possess bar is active (mind control or certain quests)." -- MT
L["GEMS_IF_PICKER_VEHICLEUI_LABEL"] = "vehicleui" -- MT
L["GEMS_IF_PICKER_VEHICLEUI_TOOLTIP"] =
    "True when the vehicle UI is active. Use when driving a mount-style vehicle with its own action bar." -- MT
L["GEMS_IF_PICKER_EXTRABAR_LABEL"] = "extrabar" -- MT
L["GEMS_IF_PICKER_EXTRABAR_TOOLTIP"] = "True when the extra action button is visible (boss fight or quest button)." -- MT
L["GEMS_IF_PICKER_CURSOR_LABEL"] = "cursor" -- MT
L["GEMS_IF_PICKER_CURSOR_TOOLTIP"] =
    "True when an item or spell is on the cursor. Use to skip casts that would consume the pickup." -- MT
L["GEMS_IF_PICKER_ACTIONBAR_LABEL"] = "actionbar:N" -- MT
L["GEMS_IF_PICKER_ACTIONBAR_TOOLTIP"] =
    "True when the chosen action bar page (1-12) is active. Pair with stance or form macros." -- MT
L["GEMS_IF_PICKER_BAR_LABEL"] = "bar:N" -- MT
L["GEMS_IF_PICKER_BAR_TOOLTIP"] = "Alias for actionbar. Same semantics; commonly used in older macros." -- MT
L["GEMS_IF_PICKER_SHAPESHIFT_LABEL"] = "shapeshift" -- MT
L["GEMS_IF_PICKER_SHAPESHIFT_TOOLTIP"] = "True when in any shapeshift form. Use for caster vs animal-form branching." -- MT
L["GEMS_IF_PICKER_HOUSE_LABEL"] = "house:where" -- MT
L["GEMS_IF_PICKER_HOUSE_TOOLTIP"] =
    "True when at the chosen housing location (inside, plot, editor, or neighbourhood). Use for housing toy macros." -- MT
L["GEMS_IF_PICKER_SEARCH_SPELL_HINT"] = "Search spell..." -- MT
L["GEMS_IF_PICKER_PETMODE_FAMILY"] = "F" -- MT
L["GEMS_IF_PICKER_PETMODE_NAME"] = "N" -- MT
L["GEMS_IF_PICKER_PETMODE_TOOLTIP"] = "Toggle: F = pick from family list, N = type a literal pet name" -- MT

-- IF action node conditional picker Custom tab (Phase H1.7)
L["GEMS_IF_PICKER_CUSTOM_TAB"] = "Custom" -- MT
L["GEMS_IF_PICKER_CUSTOM_HEADER"] = "Custom spell reference" -- MT
L["GEMS_IF_PICKER_CUSTOM_HINT"] = "Enter a spell ID or name. Either field fills the other when validated." -- MT
L["GEMS_IF_PICKER_CUSTOM_ID_LABEL"] = "Spell ID" -- MT
L["GEMS_IF_PICKER_CUSTOM_NAME_LABEL"] = "Name" -- MT
L["GEMS_IF_PICKER_CUSTOM_RESOLVED"] = "Resolved: %s (ID %s)" -- MT
L["GEMS_IF_PICKER_CUSTOM_UNRESOLVED"] = "Spell not in cache (will use raw value)" -- MT
L["GEMS_IF_PICKER_CUSTOM_FOUND"] = "Found %d matches" -- MT

-- Phase H1.9a: SpellPicker Spec filter sub-scope dropdown
L["GEMS_SPELLPICKER_SPEC_SCOPE_LABEL"] = "Scope:" -- MT
L["GEMS_SPELLPICKER_SPEC_SCOPE_CURRENT"] = "Current spec" -- MT
L["GEMS_SPELLPICKER_SPEC_SCOPE_ALL"] = "All specs" -- MT

-- Phase H1.9b: SpellPicker All Classes filter tab + class scope dropdown
L["GEMS_SPELLPICKER_ALLCLASSES"] = "All Classes" -- MT
L["GEMS_SPELLPICKER_CLASS_SCOPE_ALL"] = "All classes" -- MT
L["GEMS_SPELL_CACHE_UNRESOLVED"] =
    "GRIP-EMS: Unrecognised spell(s) after rescan: %s. If these are valid in your current talent loadout, run /reload." -- MT
L["GEMS_SPELL_CATALOG_DRIFT"] =
    "Spell catalogue last refreshed for build %s; you are on %s. Browsing may show outdated or missing entries." -- MT

-- Phase H4b: Conditional builder modal chrome
L["GEMS_IF_BUILDER_TITLE"] = "Conditional builder" -- MT
L["GEMS_IF_BUILDER_CLAUSE_HEADER"] = "OR clause %d" -- MT
L["GEMS_IF_BUILDER_ADD_OR_CLAUSE"] = "+ Add OR clause" -- MT
L["GEMS_IF_BUILDER_REMOVE_CLAUSE"] = "Remove" -- MT
L["GEMS_IF_BUILDER_APPLY"] = "Apply" -- MT
L["GEMS_IF_BUILDER_CANCEL"] = "Cancel" -- MT
L["GEMS_IF_BUILDER_PREVIEW"] = "Preview: %s" -- MT
-- Phase H4c: interactive multi-clause builder + picker escalation
L["GEMS_IF_BUILDER_CONVERT_TO_OR"] = "Convert to OR group" -- MT
L["GEMS_IF_BUILDER_EMPTY_CLAUSE_WARN"] = "Add a condition or remove this clause" -- MT
-- Phase H4d: targeting tab
L["GEMS_IF_BUILDER_TARGETING_TAB"] = "Targeting" -- MT
L["GEMS_IF_BUILDER_TARGETING_NONE"] = "(none)" -- MT
L["GEMS_IF_BUILDER_TARGETING_UNIT_HINT"] = "Custom unit (e.g. raid1, party2, arena1)" -- MT

-- Import/Export
L["GEMS_HELP_IMPORT"] = "  /gems import - 打开导入窗口(粘贴导出字符串)" -- MT
L["GEMS_HELP_EXPORT"] = "  /gems export <name> - 将序列导出为GRIP字符串" -- MT
L["GEMS_IMPORT_ENTRY"] = "  - '%s' (%d 步骤)" -- MT
L["GEMS_IMPORT_FAILED"] = "导入失败:%s" -- MT
L["GEMS_IMPORT_WARNING"] = "警告:%s" -- MT
L["GEMS_IMPORT_USAGE"] = "用法: /gems import (打开导出字符串粘贴窗口)" -- MT
L["GEMS_EXPORT_USAGE"] = "用法: /gems export <name>" -- MT
L["GEMS_EXPORT_RESULT"] = "导出:%s" -- MT
L["GEMS_EXPORT_FAILED"] = "导出失败:%s" -- MT
L["GEMS_IMPORT_PASTE_INSTRUCTIONS"] = "请在下方粘贴导出字符串,然后点击导入。" -- MT
L["GEMS_IMPORT_PASTE_LABEL"] = "导出字符串" -- MT
L["GEMS_IMPORT_CLEAR"] = "清除" -- MT
L["GEMS_IMPORT_SHORT_STRING"] = "提示:对长字符串使用 /gems import (无参数)打开粘贴窗口。" -- MT
L["GEMS_IMPORT_USE_FRAME"] = "提示:字符串可能被截断。使用 |cFFFFFF00/gems import|r 打开粘贴窗口。" -- MT
L["GEMS_IMPORT_UNKNOWN_FORMAT"] = "未知导入格式" -- MT
L["GEMS_IMPORT_ACTION_SKIPPED"] = "已跳过动作:%s" -- MT
L["GEMS_IMPORT_EMBED_SKIPPED"] = "已跳过嵌入序列 '%s' (不可用)" -- MT
L["GEMS_IMPORT_PAUSE_CONVERTED"] = "暂停已转换为 %d 个空步骤" -- MT
L["GEMS_IMPORT_INTERVAL_PRESERVED"] = "已保留 %d 个交错动作" -- MT
L["GEMS_IMPORT_EMPTY_CASTSEQ_STRIPPED"] = "Removed %d empty cast sequence line(s) (they error on every press in-game)" -- MT
L["GEMS_ACTION_INTERLEAVE_EVERY"] = "每:" -- MT
L["GEMS_ACTION_INTERLEAVE_STEPS"] = "步骤" -- MT
L["GEMS_INTERLEAVE_TOOLTIP_TITLE"] = "交错" -- MT
L["GEMS_INTERLEAVE_TOOLTIP_DESC"] =
    "启用后,此动作每N次按键触发一次,而非每次按键。适合长冷却增益与主循环搭配。" -- MT
L["GEMS_ADD_ACTION_INTERLEAVE"] = "动作(交错)" -- MT

-- Layer 4: Macro action type (editor-side picker + drift UI)
L["GEMS_ADD_ACTION_MACRO"] = "Macro" -- MT
L["GEMS_MACRO_PICKER_TITLE"] = "Pick a Macro" -- MT
L["GEMS_MACRO_PICKER_SEARCH"] = "Search..." -- MT
L["GEMS_MACRO_PICKER_SOURCE_WOW"] = "WoW only" -- MT
L["GEMS_MACRO_PICKER_SOURCE_EMS"] = "EMS only" -- MT
L["GEMS_MACRO_PICKER_SOURCE_BOTH"] = "Both" -- MT
L["GEMS_MACRO_PICKER_EMPTY"] = "No macros found." -- MT
L["GEMS_MACROREF_NAME"] = "Macro:" -- MT
L["GEMS_MACROREF_DRIFT_INDICATOR"] = "stored body differs from /macro" -- MT
L["GEMS_MACROREF_SOURCE_MISSING"] = "source macro missing -- re-pick from picker" -- MT
L["GEMS_MACROREF_REFRESH"] = "Refresh from /macro" -- MT
L["GEMS_MACROREF_AUTOREFRESH"] = "自动刷新宏引用步骤" -- TODO: MT 2026-06-21
L["GEMS_MACROREF_AUTOREFRESH_DESC"] =
    "启用后，由你的某个宏创建的步骤会在你编辑该宏后自动更新，这样你就无需打开该步骤并手动刷新。默认关闭。只有你在此角色上创建或刷新过的步骤才会自动更新；导入的步骤会保持不变，直到你手动刷新一次。" -- TODO: MT 2026-06-21
L["GEMS_MACROREF_AUTOREFRESH_DEBUG"] = "已自动刷新 %d 个序列中的宏引用内容" -- TODO: MT 2026-06-21

-- Auxiliary-macro import (audit Layer 1: closes the bare-name macro gap)
L["GEMS_IMPORT_MACRO_LINE"] = "Macro %s was imported." -- MT
L["GEMS_IMPORT_MACROS_IMPORTED"] = "%d macro(s) imported." -- MT
L["GEMS_IMPORT_MACROS_SKIPPED"] = "%d macro(s) skipped." -- MT
L["GEMS_IMPORT_MACROS_OVERFLOW"] =
    "Macro '%s' could not be created -- macro slots full (%d/%d). Delete unused /macro entries and re-import." -- MT
L["GEMS_IMPORT_MACROS_SECTION_HEADING"] = "Macros" -- MT
L["GEMS_IMPORT_MACROS_BADGE_NEW"] = "(New)" -- MT
L["GEMS_IMPORT_MACROS_BADGE_UPDATE"] = "(Update)" -- MT
L["GEMS_IMPORT_MACRO_DEP_MISSING"] = "%s: references macro '%s' which is not in the import payload and not in your saved macros." -- MT
    .. " The step will type '%s' into chat at runtime." -- MT
L["GEMS_IMPORT_SEQUENCE_DEP_MISSING"] =
    "%s: embeds sequence '%s' which is not in the import payload and not in your saved sequences." -- MT

-- UI strings (Phase 3)
L["GEMS_HELP_OPEN"] = "  /gems open - 打开/关闭主窗口" -- MT
L["GEMS_UI_TITLE"] = "GRIP-EMS" -- MT
L["GEMS_UI_SELECT_SEQUENCE"] = "选择要编辑的序列" -- MT
L["GEMS_UI_SEQUENCE_LIST_PLACEHOLDER"] = "正在加载序列列表..." -- MT
L["GEMS_UI_NO_SEQUENCES"] = "未找到序列。请创建或导入一个。" -- MT
L["GEMS_UI_RESIZE"] = "调整大小" -- MT
L["GEMS_UI_RESIZE_DESC"] = "拖动以调整窗口大小" -- MT
L["GEMS_UI_MINIMAP_LEFT"] = "左键点击:打开/关闭" -- MT
L["GEMS_UI_MINIMAP_RIGHT"] = "右键点击:快捷菜单" -- MT
L["GEMS_UI_MINIMAP_RIGHTCLICK_SOON"] = "右键快捷菜单即将推出。" -- MT
L["GEMS_UI_MINIMAP_OOC_QUEUE"] = "战斗外队列" -- MT
L["GEMS_UI_MINIMAP_OOC_PENDING"] = "%d 待处理" -- MT
L["GEMS_UI_MINIMAP_PARTY_USERS"] = "队伍用户" -- MT
L["GEMS_UI_MINIMAP_PARTY_NONE"] = "未检测到" -- MT

-- UI strings (Phase 3A-2): Search
L["GEMS_UI_SEARCH"] = "搜索..." -- MT
L["GEMS_UI_SEARCH_DESC"] = "按名称筛选序列" -- MT

-- UI strings (Phase 3A-2): Buttons
L["GEMS_UI_NEW"] = "新建" -- MT
L["GEMS_UI_NEW_DESC"] = "创建新序列" -- MT
L["GEMS_UI_IMPORT_BTN"] = "导入" -- MT
L["GEMS_UI_IMPORT_BTN_DESC"] = "从导出字符串导入序列" -- MT

-- UI strings (Phase 3A-2): Context menu
L["GEMS_UI_DUPLICATE"] = "复制" -- MT
L["GEMS_UI_DELETE"] = "删除" -- MT
L["GEMS_UI_EXPORT_CTX"] = "导出" -- MT
L["GEMS_UI_RENAME"] = "重命名" -- MT
L["GEMS_UI_REPAIR"] = "修复" -- MT
L["GEMS_UI_REPAIR_ALL"] = "全部修复" -- MT

-- Repair module strings
L["GEMS_REPAIR_USAGE"] = "用法: /gems repair <name> (或先选择序列)" -- MT
L["GEMS_REPAIR_NOT_LOADED"] = "修复模块未加载" -- MT
L["GEMS_REPAIR_SEQ_NOT_FOUND"] = "未找到序列:%s" -- MT
L["GEMS_REPAIR_NONE"] = "未发现问题(健康度:%d)" -- MT
L["GEMS_REPAIR_ALL_HEALTHY"] = "所有序列均健康!" -- MT
L["GEMS_REPAIR_IMPORT_ISSUES"] = "已导入 %s。发现 %d 个问题 -- 使用 /gems repair %s 查看。" -- MT
L["GEMS_REPAIR_EXPORT_WARN"] =
    "在选定序列中发现 %d 个问题。接收方可能看到异常行为。仍要导出吗?" -- MT
L["GEMS_REPAIR_EXPORT_ACCEPT"] = "仍然导出" -- MT
L["GEMS_REPAIR_SEND_WARN"] = "发现 %d 个问题。接收方可能看到异常行为。仍要发送吗?" -- MT
L["GEMS_REPAIR_SEND_ACCEPT"] = "仍然发送" -- MT

-- UI strings (Phase 3A-2): Editor header
L["GEMS_UI_SEQ_ICON"] = "图标" -- MT
L["GEMS_UI_STEP_FUNCTION"] = "步骤函数" -- MT
L["GEMS_UI_RESET_COMBAT"] = "战斗结束时重置" -- MT
L["GEMS_UI_RESET_COMBAT_DESC"] = "战斗结束时重置步骤计数器" -- MT
L["GEMS_UI_RESET_TARGET"] = "切换目标时重置" -- MT
L["GEMS_UI_RESET_TARGET_DESC"] = "切换目标时重置步骤计数器(仅战斗外)" -- MT
L["GEMS_UI_RESET_GEAR"] = "装备变化" -- MT
L["GEMS_UI_RESET_GEAR_DESC"] = "装备变更时重置步骤计数器(仅战斗外)" -- MT
L["GEMS_UI_RESET_SPEC"] = "专精变化" -- MT
L["GEMS_UI_RESET_SPEC_DESC"] = "专精变更时重置步骤计数器" -- MT
L["GEMS_UI_RESET_TIMER"] = "计时器(秒)" -- MT
L["GEMS_UI_RESET_TIMER_DESC"] = "经过此秒数无活动后重置步骤计数器(0为禁用)" -- MT
L["GEMS_UI_REPEAT_COUNT"] = "Repeat" -- MT
L["GEMS_UI_REPEAT_COUNT_DESC"] =
    "Number of times to run the full sequence before cycling back to step 1. Use 1 (default) for infinite cycling. Best paired with the Sequential step function -- Priority/Reverse Priority combinations expand the weighted distribution across the repeats." -- MT
L["GEMS_UI_KEYPRESS"] = "按下" -- MT
L["GEMS_UI_KEYPRESS_DESC"] =
    "按键按下时运行的命令,在每个步骤触发前(例如 /stopmacro [channeling])。当总长不超过255字符时合并到每个步骤的宏中。超出限制的步骤无按下命令运行 -- 检查预览选项卡查看哪些步骤适合。" -- MT
L["GEMS_UI_KEYRELEASE"] = "释放" -- MT
L["GEMS_UI_KEYRELEASE_DESC"] =
    "按键释放时运行的命令,在每个步骤触发后。当总长不超过255字符时合并到每个步骤的宏中。超出限制的步骤无释放命令运行 -- 检查预览选项卡查看哪些步骤适合。" -- MT

-- UI strings: Metadata section
L["GEMS_EDITOR_METADATA"] = "元数据" -- MT
L["GEMS_EDITOR_METADATA_AUTHOR"] = "作者" -- MT
L["GEMS_EDITOR_METADATA_DESCRIPTION"] = "描述" -- MT
L["GEMS_EDITOR_METADATA_HELP"] = "帮助文本" -- MT
L["GEMS_EDITOR_METADATA_HELPLINK"] = "帮助链接" -- MT
L["GEMS_EDITOR_METADATA_CLASS"] = "职业" -- MT
L["GEMS_EDITOR_METADATA_SPEC"] = "专精" -- MT
L["GEMS_EDITOR_METADATA_CREATED"] = "创建" -- MT
L["GEMS_EDITOR_METADATA_UPDATED"] = "更新" -- MT
-- Per-sequence sound cue overrides (Phase 4 item 22 Phase 2)
L["GEMS_EDITOR_SEQ_SOUND_HEADER"] = "序列声音提示(可选)" -- MT
L["GEMS_EDITOR_SEQ_SOUND_DESC"] = "覆盖此序列的全局提示音。留空使用全局设置。" -- MT
L["GEMS_EDITOR_SEQ_SOUND_ERROR"] = "错误提示" -- MT
L["GEMS_EDITOR_SEQ_SOUND_SUCCESS"] = "成功提示" -- MT
L["GEMS_EDITOR_SEQ_SOUND_INFO"] = "信息提示" -- MT
L["GEMS_EDITOR_SEQ_SOUND_STEP"] = "步骤提示" -- MT
L["GEMS_EDITOR_SEQ_SOUND_NONE"] = "(全局默认)" -- MT

-- UI strings: Dependencies section
L["GEMS_DEPS_HEADER"] = "依赖" -- MT
L["GEMS_DEPS_VARIABLES"] = "变量" -- MT
L["GEMS_DEPS_SEQUENCES"] = "序列" -- MT
L["GEMS_DEPS_EMBEDDED_BY"] = "被嵌入于" -- MT
L["GEMS_DEPS_NONE"] = "(无)" -- MT
L["GEMS_DEPS_NOT_EMBEDDED"] = "未被任何序列嵌入" -- MT
L["GEMS_DEPS_MACROS"] = "Macros" -- MT
L["GEMS_UI_MACRO_DEPS_SECTION"] = "Macro Dependencies" -- MT
L["GEMS_UI_MACRO_DEPS_HINT"] = "Tag macros this sequence uses so they auto-include on export." -- MT
L["GEMS_UI_MACRO_DEPS_EMPTY"] = "No macros found. Use /macro to create one." -- MT

-- UI strings (Phase 3A-2): Tabs
L["GEMS_UI_TAB_STEPS"] = "步骤" -- MT
L["GEMS_UI_TAB_KEYBIND"] = "按键绑定" -- MT
L["GEMS_UI_TAB_VARIABLES"] = "变量" -- MT
L["GEMS_UI_TAB_RAW"] = "原始" -- MT
L["GEMS_UI_TAB_COMING_SOON"] = "即将推出" -- MT

-- UI strings (Phase 3A-2): Step list
L["GEMS_UI_STEP_NUM"] = "#%d" -- MT
L["GEMS_UI_NO_STEPS"] = "未定义步骤。" -- MT
L["GEMS_UI_ADD_STEP_HINT"] = "无步骤。点击 '+ 添加' 创建一个。" -- MT

-- UI strings (Phase 3A-2): Dialogs
L["GEMS_UI_NEW_SEQ_DESC"] = "输入新序列的名称:" -- MT
L["GEMS_UI_DELETE_CONFIRM"] = "确定要删除 '%s' 吗?此操作无法撤销。" -- MT
L["GEMS_UI_DUP_DESC"] = "输入副本的名称:" -- MT
L["GEMS_UI_RENAME_DESC"] = "输入新名称:" -- MT
L["GEMS_UI_NAME_EXISTS"] = "名为 '%s' 的序列已存在。" -- MT
L["GEMS_UI_RENAME_PLUGIN_OWNED"] = "Cannot rename '%s': it is managed by plugin '%s'." -- MT
L["GEMS_UI_NAME_EMPTY"] = "序列名称不能为空。" -- MT

-- UI strings (Phase 3A-2): Status text in rows
L["GEMS_UI_ROW_SUBTITLE"] = "%s | %d 步骤" -- MT

-- UI strings (Phase 3A-2): Sort
L["GEMS_UI_SORT_ALPHA"] = "A-Z" -- MT
L["GEMS_UI_SORT_CLASS"] = "职业" -- MT
L["GEMS_UI_SORT_UPDATED"] = "最近" -- MT
L["GEMS_UI_SORT_ALPHA_TIP"] = "按字母顺序" -- MT
L["GEMS_UI_SORT_CLASS_TIP"] = "按职业" -- MT
L["GEMS_UI_SORT_UPDATED_TIP"] = "最近更新" -- MT
L["GEMS_UI_SORT_HINT"] = "排序" -- MT
L["GEMS_UI_SORT_CYCLE"] = "点击切换排序模式" -- MT

-- Spell validation (v1.1.0)
L["GEMS_SPELL_WARN_BANNER"] = "此序列中可能有 %d 个无效法术" -- MT
L["GEMS_SPELL_VALIDATE_SUMMARY"] = "已检查 %d 个序列:%d 个正常,%d 个有警告" -- MT
L["GEMS_SPELL_VALIDATE_CLEAN"] = "所有序列已验证 -- 未发现问题" -- MT
L["GEMS_SPELL_VALIDATE_SEQ"] = "  %s:%d 未知,%d 受天赋限制" -- MT
L["GEMS_SPELL_STATUS_LABEL"] = "可能有 %d 个无效法术" -- MT
L["GEMS_SPELL_INFO_LABEL"] = "%d 已知但未学习" -- MT
L["GEMS_IMPORT_FREEFORM_WARN"] = "'%s':%d 个步骤包含原始宏命令。它们不会自动翻译到其他语言。" -- MT
L["GEMS_IMPORT_FREEFORM_LABEL"] = "%d 自由格式" -- MT
L["GEMS_IMPORT_ICON_AUTO"] = "(自动检测)" -- MT
L["GEMS_IMPORT_PICK_AUTO"] = "[自动]" -- MT
L["GEMS_IMPORT_PICK_VAR_DEPS"] = "使用 %d 个变量" -- MT
L["GEMS_SPELL_TOOLTIP_UNKNOWN"] = "未找到:%s" -- MT
L["GEMS_SPELL_TOOLTIP_KNOWN"] = "不在法术书中:%s" -- MT
L["GEMS_SPELL_TOOLTIP_COSMETIC"] = "|cff888888#showtooltip: %s|r" -- MT

-- Rotation Preview (v1.1.0)
L["GEMS_PLUGIN_LOADED"] = "插件序列已加载:%s" -- MT
L["GEMS_PLUGIN_NOT_FOUND"] = "未知插件:%s" -- MT
L["GEMS_PLUGIN_REGISTERED"] = "已注册插件:%s v%s (%d 个序列)" -- MT
L["GEMS_PLUGIN_SKIP_EXISTS"] = "插件 %s:跳过 '%s' (用户版本已存在)" -- MT

L["GEMS_PREVIEW_ICONS"] = "图标" -- MT
L["GEMS_PREVIEW_TEXT"] = "文本" -- MT
L["GEMS_PREVIEW_TOGGLE_TIP"] = "切换预览模式" -- MT
L["GEMS_PREVIEW_RANDOM_HINT"] = "随机 -- 任一可能触发" -- MT
L["GEMS_PREVIEW_STEP_TOOLTIP"] = "步骤 %d:%s" -- MT
L["GEMS_PREVIEW_SPELL_TOOLTIP"] = "法术:%s" -- MT
L["GEMS_PREVIEW_COMPILED"] = "已编译" -- MT
L["GEMS_PREVIEW_COMPILED_TIP"] = "显示每步的已编译宏(WoW 实际运行内容)" -- MT
L["GEMS_PREVIEW_KP_FIT"] = "%d/%d 步骤适合按下+释放" -- MT
L["GEMS_PREVIEW_KP_DROPPED"] = "红色步骤的按下/释放被丢弃(超过255字符限制)" -- MT
L["GEMS_PREVIEW_COPY"] = "复制" -- MT
L["GEMS_PREVIEW_COPY_TIP"] = "复制循环预览到剪贴板" -- MT

-- UI strings (Phase 3A-2): Editor misc
L["GEMS_UI_ICON_HINT"] = "点击更换图标" -- MT
L["GEMS_UI_DUPLICATE_FAILED"] = "复制失败。" -- MT
L["GEMS_UI_COPY_SUFFIX"] = "_copy" -- MT

-- UI strings (Phase 3A-2): Step function labels
L["GEMS_UI_SF_SEQUENTIAL"] = "顺序" -- MT
L["GEMS_UI_SF_RANDOM"] = "随机" -- MT
L["GEMS_UI_SF_PRIORITY"] = "优先级" -- MT
L["GEMS_UI_SF_REVERSEPRIORITY"] = "反向优先级" -- MT

-- UI strings (Phase 3B-1): Step editor
L["GEMS_UI_ADD_STEP"] = "+ 添加" -- MT
L["GEMS_UI_ADD_STEP_DESC"] = "在所选项下方添加新空步骤" -- MT
L["GEMS_UI_DUP_STEP"] = "复制" -- MT
L["GEMS_UI_DUP_STEP_DESC"] = "复制所选步骤" -- MT
L["GEMS_UI_MOVE_UP"] = "上移" -- MT
L["GEMS_UI_MOVE_UP_DESC"] = "向上移动所选步骤" -- MT
L["GEMS_UI_MOVE_DOWN"] = "下移" -- MT
L["GEMS_UI_MOVE_DOWN_DESC"] = "向下移动所选步骤" -- MT
L["GEMS_UI_DEL_STEP"] = "删除" -- MT
L["GEMS_UI_DEL_STEP_DESC"] = "删除所选步骤" -- MT
L["GEMS_UI_STEP_HEADER"] = "步骤 %d:" -- MT
L["GEMS_UI_SELECT_STEP"] = "选择要编辑的步骤" -- MT
L["GEMS_UI_DELETE_STEP_CONFIRM"] = "删除步骤 %d?此操作无法撤销。" -- MT
L["GEMS_UI_CTX_DUP_STEP"] = "复制步骤" -- MT
L["GEMS_UI_CTX_MOVE_UP"] = "上移" -- MT
L["GEMS_UI_CTX_MOVE_DOWN"] = "下移" -- MT
L["GEMS_UI_CTX_DELETE_STEP"] = "删除步骤" -- MT
L["GEMS_UI_DRAG_HANDLE_DESC"] = "拖动以重新排序" -- MT
L["GEMS_UI_EXPORT_BTN_EDITOR"] = "导出" -- MT
L["GEMS_UI_EXPORT_BTN_EDITOR_DESC"] = "将此序列导出为 GRIP-EMS 字符串" -- MT
L["GEMS_UI_NAME_TOOLTIP"] = "序列名称" -- MT
L["GEMS_UI_NAME_EDIT_HINT"] = "点击重命名。按回车确认,Esc取消。" -- MT
L["GEMS_UI_SAVE_PROMPT"] = "保存对 '%s' 的更改吗?" -- MT
L["GEMS_UI_SAVE"] = "保存" -- MT
L["GEMS_UI_SAVE_BTN_DESC"] = "保存对此序列的更改" -- MT
L["GEMS_UI_DISCARD"] = "放弃" -- MT
L["GEMS_UI_DISCARD_BTN_DESC"] = "放弃更改并恢复到上次保存版本" -- MT
L["GEMS_UI_SAVE_COMBAT"] = "战斗中不可用" -- MT
L["GEMS_UI_ENABLE"] = "启用" -- MT
L["GEMS_UI_DISABLE"] = "禁用" -- MT
L["GEMS_UI_ENABLE_BTN_DESC"] = "重新启用此序列(重新激活按钮和按键绑定)" -- MT
L["GEMS_UI_DISABLE_BTN_DESC"] = "禁用此序列(移除按钮和按键绑定,保留数据)" -- MT
L["GEMS_UI_DISABLED_BADGE"] = "[已禁用]" -- MT

-- Version bar (UX-4)
L["GEMS_VERSION_OF"] = "版本 %d / %d" -- MT
L["GEMS_VERSION_LABEL"] = "版本 %d" -- MT
L["GEMS_VERSION_DEFAULT_SUFFIX"] = " (默认)" -- MT
L["GEMS_VERSION_DEFAULT_MARKER"] = " (*)" -- MT
L["GEMS_VERSION_TOOLTIP_TITLE"] = "版本" -- MT
L["GEMS_VERSION_TOOLTIP_DESC"] = "选择要编辑的版本" -- MT
L["GEMS_VERSION_ADD_TITLE"] = "添加版本" -- MT
L["GEMS_VERSION_ADD_DESC"] = "创建新空白版本" -- MT
L["GEMS_VERSION_DUP_TITLE"] = "复制版本" -- MT
L["GEMS_VERSION_DUP_DESC"] = "将当前版本复制为新版本" -- MT
L["GEMS_VERSION_DEL_TITLE"] = "删除版本" -- MT
L["GEMS_VERSION_DEL_DESC"] = "移除当前版本" -- MT
L["GEMS_VERSION_DEFAULT_TITLE"] = "设为默认" -- MT
L["GEMS_VERSION_DEFAULT_DESC"] = "标记此版本为执行的默认版本" -- MT

-- Phase 3B-2: Keybind tab
L["GEMS_UI_CURRENT_KEYBIND"] = "当前按键绑定" -- MT
L["GEMS_UI_KEYBIND_DISPLAY_NONE"] = "无" -- MT
L["GEMS_UI_SET_KEYBIND"] = "设置按键绑定" -- MT
L["GEMS_UI_CHANGE_KEYBIND"] = "更改" -- MT
L["GEMS_UI_CLEAR_KEYBIND"] = "清除" -- MT
L["GEMS_UI_PRESS_KEY"] = "请按一个键..." -- MT
L["GEMS_UI_KEYBIND_HINT"] =
    "按键绑定按专精保存在你的 GRIP-EMS 配置文件中。它们不会改变你的常规 WoW 按键绑定。" -- MT
L["GEMS_UI_CAPTURE_COMBAT"] = "战斗中无法捕获按键绑定。" -- MT
L["GEMS_UI_SPEC_KEYBINDS"] = "按专精的按键绑定" -- MT
L["GEMS_UI_CURRENT_SPEC"] = "(当前)" -- MT
L["GEMS_UI_LOADOUT_COMING_SOON"] = "按天赋配置的按键绑定:即将推出" -- MT
L["GEMS_UI_CAPTURE_ESC_HINT"] = "(按 ESC 取消)" -- MT
L["GEMS_UI_KEYBIND_CONFLICT"] = "%s 之前绑定到 '%s'。现已绑定到此序列。" -- MT
L["GEMS_UI_KEYBIND_CP_CONFLICT"] = "%s 在 ConsolePort 中绑定到 '%s'。EMS 将在序列激活时覆盖该绑定。" -- MT
L["GEMS_KEYBIND_MOUSE_NEEDS_MODIFIER"] = "鼠标1和鼠标2需要修饰键(Alt、Ctrl 或 Shift)才能绑定。" -- MT
L["GEMS_UI_GAMEPAD_HINT"] = "检测到控制器 -- 你可以绑定手柄按键。" -- MT
L["GEMS_UI_SIMPLIFIED_LOCKED_HINT"] =
    "简化模式已开启。点击解锁编辑器以编辑此序列，或在设置中关闭简化模式。" -- MT

-- Phase 3B-2: Macros tab
L["GEMS_UI_TAB_MACROS"] = "宏" -- MT
L["GEMS_UI_MACRO_STUB_SECTION"] = "宏存根" -- MT
L["GEMS_UI_STUB_INFO"] = "%s (槽位 %d)" -- MT
L["GEMS_UI_STUB_NONE"] = "无宏存根" -- MT
L["GEMS_UI_SLOTS_USED"] = "已使用 %d/%d 角色专属宏槽位" -- MT
L["GEMS_UI_REFRESH_STUBS"] = "刷新" -- MT
L["GEMS_UI_REFRESH_STUBS_DESC"] = "重新扫描现有的 GRIP-EMS 宏存根" -- MT
L["GEMS_UI_CLEAN_ORPHANS"] = "清理孤立项" -- MT
L["GEMS_UI_CLEAN_ORPHANS_DESC"] = "删除已不存在序列的宏存根" -- MT
L["GEMS_UI_CLEAN_CONFIRM"] = "删除 %d 个孤立宏存根?此操作无法撤销。" -- MT
L["GEMS_UI_ORPHANS_CLEANED"] = "已清理 %d 个孤立宏存根。" -- MT
L["GEMS_UI_NO_ORPHANS"] = "未发现孤立存根。" -- MT
L["GEMS_UI_STUB_LIST_HEADER"] = "所有存根 (%d)" -- MT
L["GEMS_UI_NO_STUBS"] = "未发现宏存根。" -- MT
L["GEMS_UI_STUBS_MORE"] = "还有 %d 个存根未显示" -- MT

-- Phase 3B-2: Priority preview

-- Phase 3C-1: Spell autocomplete

-- Phase 3C-2: Icon picker
L["GEMS_UI_ICON_PICKER_TITLE"] = "选择图标" -- MT
L["GEMS_UI_AUTO_DETECT"] = "自动检测" -- MT
L["GEMS_UI_AUTO_DETECT_DESC"] = "从首个 /cast 法术自动检测图标" -- MT

-- Context version selection (T2-1)
L["GEMS_CONTEXT_CHANGED"] = "上下文已变更:%s" -- MT
L["GEMS_CONTEXT_NONE_LABEL"] = "无" -- MT
L["GEMS_CONTEXT_RELOAD"] = "已切换上下文:重新加载了 %d 个序列" -- MT

-- Context tab (T2-1b)
L["GEMS_UI_TAB_CONTEXT"] = "上下文" -- MT
L["GEMS_CONTEXT_DEFAULT_LABEL"] = "默认版本:%d" -- MT
L["GEMS_CONTEXT_CURRENT_INFO"] = "当前上下文:%s" -- MT
L["GEMS_CONTEXT_VIEWING"] = "版本 %d 的分配" -- MT
L["GEMS_CONTEXT_NO_VERSIONS"] = "添加第二个版本以设置上下文覆盖。" -- MT
L["GEMS_CONTEXT_HINT"] =
    "勾选此版本应激活的内容类型。未勾选的上下文回退到更广泛的类别(例如:史诗钥石回退到地下城,然后是默认)。" -- MT
L["GEMS_CONTEXT_CONFLICT_MSG"] = "%s 已分配给版本 %d。\n重新分配给版本 %d?" -- MT
L["GEMS_CONTEXT_CONFLICT_MULTI_MSG"] =
    "此分组中有 %d 个上下文已分配给其他版本。\n将它们全部重新分配给版本 %d?" -- MT
L["GEMS_CONTEXT_SELECT_ALL_TIP"] =
    "将此分组中的所有上下文分配给当前查看的版本。已分配给其他版本的上下文会请求一次确认。" -- MT
L["GEMS_CONTEXT_CLEAR_ALL_TIP"] =
    "清除此分组在当前查看版本下的分配。属于其他版本的分配保持不变。" -- MT
L["GEMS_CONTEXT_DEFAULT_TIP_TITLE"] = "默认版本" -- MT
L["GEMS_CONTEXT_DEFAULT_TIP_TEXT"] = "当没有匹配的上下文覆盖时使用的版本。" -- MT
L["GEMS_CONTEXT_ASSIGNED_OTHER"] = "(版本 %d)" -- MT
L["GEMS_CONTEXT_GROUP_RAIDS"] = "团队副本" -- MT
L["GEMS_CONTEXT_GROUP_DUNGEONS"] = "地下城" -- MT
L["GEMS_CONTEXT_GROUP_PVP"] = "PvP" -- MT
L["GEMS_CONTEXT_GROUP_ARENA_MAPS"] = "竞技场地图" -- MT
L["GEMS_CONTEXT_GROUP_BG_MAPS"] = "战场地图" -- MT
L["GEMS_CONTEXT_GROUP_OTHER"] = "其他" -- MT
L["GEMS_CONTEXT_WRONG_VERSION"] = "%s 已分配给版本 %d。切换到该版本以修改它。" -- MT

-- Context group buttons and fallback chain (v1.2.0 S19)
L["GEMS_CONTEXT_SELECT_ALL"] = "全部" -- MT
L["GEMS_CONTEXT_CLEAR_ALL"] = "无" -- MT
L["GEMS_CONTEXT_FALLBACK_NONE"] = "无活动上下文 -- 默认版本 %d" -- MT
L["GEMS_CONTEXT_FALLBACK_MATCH"] = " (v%d)" -- MT
L["GEMS_CONTEXT_FALLBACK_DEFAULT"] = "默认" -- MT
L["GEMS_CONTEXT_FALLBACK_SEP"] = " > " -- MT
L["GEMS_SETTINGS_CONTEXT_HEADER"] = "上下文检测" -- MT
L["GEMS_SETTINGS_CONTEXT_DESC"] = "选择插件如何根据你正在做的内容自动选取正确的版本。" -- MT
L["GEMS_SETTINGS_MPLUS_MID"] = "史诗钥石中等档次" -- MT
L["GEMS_SETTINGS_MPLUS_MID_DESC"] = "史诗钥石内容类型从低到中变化的钥石等级。" -- MT
L["GEMS_SETTINGS_MPLUS_HIGH"] = "史诗钥石高等档次" -- MT
L["GEMS_SETTINGS_MPLUS_HIGH_DESC"] = "史诗钥石内容类型从中到高变化的钥石等级。" -- MT
L["GEMS_SETTINGS_DELVES_HIGH"] = "深岩洞穴高等档次" -- MT
L["GEMS_SETTINGS_DELVES_HIGH_DESC"] = "深岩洞穴内容类型从低到高变化的档次。" -- MT

-- Context migration (T2-3)

-- Phase 2B: Migration
L["GEMS_HELP_MIGRATE"] = "  /gems migrate - 从其他序列器迁移序列" -- MT
L["GEMS_UI_MIGRATE_BTN"] = "迁移" -- MT
L["GEMS_UI_MIGRATE_BTN_DESC"] = "从其他序列器导入所有序列" -- MT
L["GEMS_MIGRATE_NO_SOURCE"] = "未找到兼容的序列器。" -- MT
L["GEMS_MIGRATE_SOURCE_DISABLED"] =
    "已安装兼容序列器但已禁用。请在插件列表中启用,然后 /reload 进行迁移。" -- MT
L["GEMS_MIGRATE_FAILED"] = "迁移失败:%s" -- MT
L["GEMS_MIGRATE_CONFIRM"] =
    "从你之前的序列器迁移所有序列?\n\n找到 %d 个序列。同名的现有序列将被跳过。" -- MT
L["GEMS_DELETE_COMBAT"] = "战斗中无法删除序列。" -- MT
L["GEMS_MIGRATE_COMBAT"] = "战斗中无法迁移。请战斗后重试。" -- MT
L["GEMS_MIGRATE_EMPTY"] = "源库中未找到序列。" -- MT
L["GEMS_MIGRATE_SKIPPED"] = "%s (已存在,已跳过)" -- MT
L["GEMS_MIGRATE_KEYBINDS"] = "按键绑定:%d 已迁移,%d 已跳过,%d 冲突" -- MT
L["GEMS_MIGRATE_AO_WARNING"] =
    "%d 个动作条绑定未迁移。EMS 绑定按键,而非动作条槽位。使用 /gems bind 设置它们。" -- MT

-- Phase 2C: Export frame
L["GEMS_EXPORT_FRAME_LABEL"] = "已导出:%s" -- MT
L["GEMS_EXPORT_FRAME_HINT"] = "按 Ctrl+C 复制,然后粘贴到其他玩家的导入窗口。" -- MT

-- Phase 3C-3: Variable system
L["GEMS_VAR_EVAL_ERROR"] = "变量 '%s' 求值失败:%s" -- MT
L["GEMS_VAR_SANDBOX_BLOCKED"] = "Variable '%s': global '%s' is not on the sandbox whitelist; resolved to nil." -- MT
L["GEMS_VAR_INVALID_NAME"] = "变量名称只能使用字母、数字或下划线(a-z, 0-9, _)。" -- MT
L["GEMS_VAR_NAME_TOO_LONG"] = "变量名称超过 %d 字符" -- MT
L["GEMS_VAR_FUNC_TOO_LONG"] = "变量函数超过 %d 字符" -- MT
L["GEMS_VAR_NAME_EMPTY"] = "变量名称不能为空" -- MT
L["GEMS_VAR_NAME_EXISTS"] = "变量 '%s' 已存在" -- MT
L["GEMS_VAR_DELETED"] = "变量 '%s' 已删除" -- MT
L["GEMS_VAR_SAVED"] = "变量 '%s' 已保存" -- MT
L["GEMS_VAR_IMPORT_PAUSE"] = "带变量的暂停已转换为注释" -- MT
L["GEMS_VAR_IMPORT_SKIPPED"] = "已跳过 %d 个变量(已存在)。" -- MT
L["GEMS_VAR_RECOMPILE"] = "正在重新编译 '%s' (变量已变更)" -- MT

-- Phase 3C-3b: Variables Tab UI
L["GEMS_VAR_TAB_EMPTY"] = "未定义变量。点击新建创建一个。" -- MT
L["GEMS_VAR_NEW"] = "新建变量" -- MT
L["GEMS_VAR_NAME_LABEL"] = "名称" -- MT
L["GEMS_VAR_FUNC_LABEL"] = "函数体" -- MT
L["GEMS_VAR_FUNC_PLACEHOLDER"] = "return GetHaste() > 20" -- MT
L["GEMS_VAR_EVENTS_LABEL"] = "事件(逗号分隔)" -- MT
L["GEMS_VAR_EVENTS_PLACEHOLDER"] = "SPELL_CAST_SUCCESS, UNIT_AURA" -- MT
L["GEMS_VAR_COMMENTS_LABEL"] = "注释" -- MT
L["GEMS_VAR_DISABLED_LABEL"] = "已禁用" -- MT
L["GEMS_VAR_SAVE"] = "保存" -- MT
L["GEMS_VAR_TEST"] = "测试" -- MT
L["GEMS_VAR_TEST_RESULT"] = "变量 '%s' = %s" -- MT
L["GEMS_VAR_TEST_ERROR"] = "变量 '%s' 错误:%s" -- MT
L["GEMS_VAR_VALID"] = "有效" -- MT
L["GEMS_VAR_INVALID"] = "错误:%s" -- MT
L["GEMS_VAR_USED_BY"] = "用于:%s" -- MT
L["GEMS_VAR_NOT_USED"] = "未被任何序列使用" -- MT
L["GEMS_VAR_DELETE_CONFIRM"] = "删除变量 '%s'?" -- MT
L["GEMS_VAR_DELETE_REFS_WARN"] = "此变量被 %d 个序列使用。仍要删除吗?" -- MT
L["GEMS_VAR_RENAME"] = "重命名变量" -- MT
L["GEMS_VAR_EVENTS_BROWSE"] = "浏览事件" -- MT
L["GEMS_VAR_NEW_DESC"] = "创建新变量" -- MT
L["GEMS_VAR_SAVE_DESC"] = "保存对此变量的更改" -- MT
L["GEMS_VAR_TEST_DESC"] = "运行函数并显示结果" -- MT
L["GEMS_VAR_DELETE_DESC"] = "永久删除此变量" -- MT
L["GEMS_VAR_EVENTS_BROWSE_TIP"] = "点击浏览可用事件" -- MT
L["GEMS_VAR_EVENTS_ENABLED_DESC"] =
    "未勾选时,此变量停止监听事件。事件列表保留以便重新开启时使用。" -- MT
L["GEMS_VAR_LOCALE_WARN"] = "变量返回法术名 '%s'。为本地化安全,请使用:%s" -- MT
L["GEMS_VAR_PRIVATE_AURA_WARN"] =
    "Variable returns spell '%s' (ID %d) whose aura is marked private; addon detection (UnitAura) will return nil." -- MT
L["GEMS_VAR_FUNC_HELP"] =
    "可用辅助函数(12.0+ 战斗安全):\n  GRIPEMS.HasBuff(spellID, unit) - 单位是否有该增益\n  GRIPEMS.HasDebuff(spellID, unit) - 单位是否有该减益\n  GRIPEMS.SpellReady(spellID) - 法术当前是否可用\n  GRIPEMS.SpellOnCooldown(spellID) - 法术是否处于冷却中\n  GRIPEMS.SpellEnabled(spellID) - 法术是否启用\n  GRIPEMS.IsRestricted() - 是否有任何插件操作限制激活\nunit 默认为 'player'。所有辅助函数对缺失法术返回 false。\n\n私有光环说明:某些 12.0+ 光环被标记为私有,对插件遍历隐藏。HasBuff 和 HasDebuff 无法检测它们。如果你在游戏中看到增益但辅助函数返回 false,可能是私有光环。\n\n对于本地化安全的法术名称,使用 C_Spell.GetSpellName(spellID)。例如:C_Spell.GetSpellName(133) 替代 'Fireball'。" -- MT
L["GEMS_VAR_INSERT_HELPER"] = "插入辅助函数" -- MT
L["GEMS_VAR_INSERT_HELPER_TIP"] = "在光标位置插入条件辅助函数" -- MT
L["GEMS_VAR_INSERT_HASBUFF_PLAYER_DESC"] = "玩家是否拥有该增益" -- MT
L["GEMS_VAR_INSERT_HASBUFF_TARGET_DESC"] = "目标是否拥有该增益" -- MT
L["GEMS_VAR_INSERT_HASDEBUFF_PLAYER_DESC"] = "玩家是否拥有该减益" -- MT
L["GEMS_VAR_INSERT_HASDEBUFF_TARGET_DESC"] = "目标是否拥有该减益" -- MT
L["GEMS_VAR_INSERT_SPELLREADY_DESC"] = "法术当前是否可用" -- MT
L["GEMS_VAR_INSERT_SPELLONCD_DESC"] = "法术是否处于冷却中" -- MT
L["GEMS_VAR_INSERT_SPELLENABLED_DESC"] = "法术是否启用" -- MT
L["GEMS_VAR_INSERT_ISRESTRICTED_DESC"] = "是否有任何插件操作限制激活" -- MT

-- Raw tab
L["GEMS_RAW_TITLE"] = "原始数据" -- MT
L["GEMS_RAW_EDIT"] = "编辑" -- MT
L["GEMS_RAW_APPLY"] = "应用" -- MT
L["GEMS_RAW_CANCEL"] = "取消" -- MT
L["GEMS_RAW_INVALID"] = "无效:%s" -- MT
L["GEMS_RAW_MISSING_FIELD"] = "缺少必需字段:%s" -- MT
L["GEMS_RAW_APPLIED"] = "更改已应用" -- MT
L["GEMS_RAW_NAME_IGNORED"] = "名称更改被忽略。请从右键菜单使用重命名。" -- MT
L["GEMS_RAW_NO_SEQUENCE"] = "未选择序列" -- MT
L["GEMS_RAW_READONLY_HINT"] = "点击编辑进行修改。应用前会检查更改。" -- MT
L["GEMS_RAW_CANCEL_DESC"] = "关闭而不应用更改" -- MT
L["GEMS_RAW_EDIT_DESC"] = "解析并将 Lua 表作为序列数据应用" -- MT

-- Step action bar (Save + hint)
L["GEMS_STEP_SAVE"] = "保存" -- MT
L["GEMS_STEP_SAVE_DESC"] = "将所有步骤更改保存到序列" -- MT
L["GEMS_STEP_UNSAVED_HINT"] = "未保存的更改" -- MT

-- Engine debug
L["GEMS_SEQ_ACTIVATED"] = "序列 '%s' 已激活 (%d 步骤)。" -- MT
L["GEMS_SEQ_DEACTIVATED"] = "序列 '%s' 已停用。" -- MT
L["GEMS_SEQUENCE_REFRESH_FAILED"] = "GRIP-EMS: Sequence '%s' edit did not apply. Run /reload to retry." -- MT
L["GEMS_STEP_RESET"] = "序列 '%s' 步骤已重置到 1。" -- MT
L["GEMS_STEP_ADVANCED"] = "序列 '%s' 步骤已推进到 %d/%d。" -- MT
L["GEMS_COMBAT_RESET"] = "序列 '%s' 已重置(脱离战斗)。" -- MT
L["GEMS_TARGET_RESET"] = "序列 '%s' 已重置(目标变更)。" -- MT
L["GEMS_GEAR_RESET"] = "%s:装备变化时重置(原步骤 %d,槽位 %d)。" -- MT
L["GEMS_SPEC_RESET"] = "%s:专精变化时重置(原步骤 %d)。" -- MT
L["GEMS_RESTORED"] = "已恢复 %d 个保存的序列。" -- MT

-- Compiler messages
L["GEMS_COMPILE_DEPTH_EXCEEDED"] =
    "已超过最大序列嵌套深度 (%d) -- 已编译步骤中丢弃了一个 Loop 或其他嵌套节点。请减少步骤选项卡中的嵌套。" -- MT

-- Settings panel (T1-1 + T1-7)
L["GEMS_HELP_SETTINGS"] = "  /gems settings|config|options - 打开设置面板" -- MT
L["GEMS_SETTINGS_HEADER_DESC"] = "GRIP - 增强宏序列器的行为和外观设置。" -- MT
L["GEMS_OVERVIEW_NAME"] = "概览" -- MT
L["GEMS_OVERVIEW_VERSION_LABEL"] = "版本:%s" -- MT
L["GEMS_OVERVIEW_NAVIGATE_HINT"] = "使用左侧的树导航到设置类别。" -- MT
L["GEMS_OVERVIEW_DISCORD_BUTTON"] = "加入 Discord" -- MT
L["GEMS_OVERVIEW_AUTHOR_LINE"] = "作者:Sataana" -- MT
L["GEMS_SETTINGS_GENERAL"] = "通用" -- MT
L["GEMS_SETTINGS_OOC_DELAY"] = "战斗外队列延迟(秒)" -- MT
L["GEMS_SETTINGS_OOC_DELAY_DESC"] =
    "战斗结束后等待多久再运行排队任务。数值越小执行越快。默认为 7 秒。重载 UI 应用新值。" -- MT
L["GEMS_SETTINGS_RESET_OOC"] = "战斗结束时重置(默认)" -- MT
L["GEMS_SETTINGS_RESET_OOC_DESC"] =
    "为新建的任何序列设置 '战斗结束时重置' 的初始值。已创建的序列保持原样。" -- MT
L["GEMS_SETTINGS_AUTO_RELOAD"] = "Auto-reload sequences at combat end" -- MT
L["GEMS_SETTINGS_AUTO_RELOAD_DESC"] =
    "When ON, EMS auto-applies queued sequence operations (recompile, activate, deactivate, imports) when combat ends. When OFF, queued operations wait until you run /gems apply. Default is ON." -- MT
L["GEMS_APPLY_DRAINED"] = "Applied %d queued operation(s)." -- MT
L["GEMS_APPLY_NOTHING_QUEUED"] = "Nothing queued." -- MT
L["GEMS_APPLY_IN_COMBAT"] =
    "Cannot apply queued operations during combat. Wait for combat to end or run /gems apply afterwards." -- MT
L["GEMS_HELP_APPLY"] = "  /gems apply - Apply queued sequence operations (when Auto-reload is OFF)" -- MT
L["GEMS_SETTINGS_UI"] = "显示" -- MT
L["GEMS_SETTINGS_HIDE_LOGIN"] = "隐藏登录消息" -- MT
L["GEMS_SETTINGS_HIDE_LOGIN_DESC"] = "隐藏登录时打印在聊天中的 'GRIP-EMS vX.X' 行。" -- MT
L["GEMS_SETTINGS_DEBUG"] = "调试模式" -- MT
L["GEMS_SETTINGS_DEBUG_DESC"] = "在聊天中打印额外的技术消息。也可使用 /gems debug 开关。" -- MT
L["GEMS_SETTINGS_INFO"] = "信息" -- MT
L["GEMS_SETTINGS_VERSION_INFO"] = "GRIP-EMS v%s | %d 个活动序列" -- MT

-- Accessibility panel (v2.0.0 Phase 1A)
L["ACCESS_PANEL_NAME"] = "无障碍" -- MT
L["ACCESS_GENERAL_TAB"] = "通用" -- MT
L["ACCESS_THEMING_OVERVIEW_TAB"] = "概览" -- MT
L["ACCESS_THEMING_CUSTOMIZE_TAB"] = "自定义" -- MT
L["ACCESS_SECTION_DISPLAY"] = "显示" -- MT
L["ACCESS_SECTION_DISPLAY_DESC"] = "大小和布局选项" -- MT
L["ACCESS_SECTION_MOTION"] = "动效" -- MT
L["ACCESS_SECTION_MOTION_DESC"] = "动画选项" -- MT
L["ACCESS_SECTION_AUDIO"] = "音频" -- MT
L["ACCESS_SECTION_AUDIO_DESC"] = "语音和声音选项" -- MT
L["ACCESS_REDUCE_MOTION_LABEL"] = "减少动效" -- MT
L["ACCESS_REDUCE_MOTION_DESC"] = "关闭脉冲、淡入淡出和闪烁动画。最终颜色和图标仍会显示。" -- MT
L["ACCESS_FLICKER_SAFE_LABEL"] = "防闪烁模式" -- MT
L["ACCESS_FLICKER_SAFE_DESC"] =
    "为光敏用户静音速度和追踪动画上的alpha脉冲。首次运行时从你的暴雪无障碍设置自动检测。" -- MT
L["ACCESS_SPEECH_ENABLED_LABEL"] = "朗读步骤变化" -- MT
L["ACCESS_SPEECH_ENABLED_DESC"] =
    "使用暴雪文字转语音播报步骤推进和警告。需要在暴雪设置中启用语音聊天。" -- MT
L["ACCESS_SPEECH_RATE_LABEL"] = "语音速率" -- MT
L["ACCESS_SPEECH_RATE_DESC"] = "更快或更慢的语音。0 是暴雪默认值。" -- MT
L["ACCESS_SPEECH_VOLUME_LABEL"] = "语音音量" -- MT
L["ACCESS_SPEECH_VOLUME_DESC"] = "语音播放的响度。" -- MT
L["ACCESS_SPEECH_NO_VOICE_TOAST"] = "在社交菜单中启用暴雪语音聊天以听到步骤播报。" -- MT
L["ACCESS_SPEECH_STEP_FORMAT"] = "步骤 %d/%d" -- MT
L["ACCESS_CHAT_EMITTER_ENABLED_LABEL"] = "向聊天窗口发送状态" -- MT
L["ACCESS_CHAT_EMITTER_ENABLED_DESC"] =
    "将每次序列状态变化发送到聊天窗口。仅本地 -- 不通过网络发送。屏幕阅读器桥接(BlindSlash、NVDA)可以停靠所选窗口并朗读消息。配合上方的语音设置使用。" -- MT
L["ACCESS_CHAT_EMITTER_FRAME_LABEL"] = "聊天窗口槽位" -- MT
L["ACCESS_CHAT_EMITTER_FRAME_DESC"] =
    "10个聊天窗口中哪一个接收状态消息。默认是窗口 9,通常是隐藏的 -- 适合屏幕阅读器桥接。避免使用窗口 2(战斗记录)。" -- MT
L["ACCESS_CHAT_EMITTER_PREFIX"] = "[EMS] " -- MT
L["ACCESS_CHAT_EMITTER_INVALID_TOAST"] = "聊天窗口 %d 不可用。改用默认聊天窗口。" -- MT
L["ACCESS_STEP_LABEL_LABEL"] = "步骤标签" -- MT
L["ACCESS_STEP_LABEL_DESC"] = "启用语音时朗读的可选短名称,显示在步骤编号旁。" -- MT
L["ACCESS_STEP_LABEL_PLACEHOLDER"] = "标签(可选)" -- MT
L["ACCESS_MODE_SECTION_NAME"] = "无障碍模式" -- MT
L["ACCESS_MODE_SECTION_DESC"] =
    "一键预设,启用语音、高对比度、减少动效和更大的编辑器。之后可以微调任一设置。" -- MT
L["ACCESS_MODE_TOGGLE_LABEL"] = "开启无障碍模式" -- MT
L["ACCESS_MODE_TOGGLE_DESC"] =
    "一步启用语音、高对比度颜色、减少动效和 1.25 倍编辑器缩放。关闭以恢复出厂默认值。" -- MT
L["ACCESS_MODE_TOAST_APPLIED"] = "无障碍模式已开启。重载 UI 以获得完整效果。" -- MT
L["ACCESS_MODE_TOAST_REVERTED"] =
    "无障碍模式已关闭。已恢复出厂默认值。重载 UI 以获得完整效果。" -- MT
L["ACCESS_MODE_SMALL_DISPLAY_WARNING"] =
    "EMS:无障碍模式已开启,但你的显示器在此 UI 缩放下太小。MainFrame 可能无法完全适配。考虑禁用无障碍模式或移到更大的显示器。" -- MT
L["ACCESS_CVAR_MIRROR_SECTION_NAME"] = "CVar 自动镜像" -- MT
L["ACCESS_CVAR_MIRROR_SECTION_DESC"] =
    "首次登录时,将你的暴雪无障碍设置复制到 EMS。已经在 EMS 中更改的设置会保留。" -- MT
L["ACCESS_CVAR_MIRROR_REDETECT_LABEL"] = "重新检测无障碍设置" -- MT
L["ACCESS_CVAR_MIRROR_REDETECT_DESC"] =
    "重新检查你的暴雪色盲、镜头动效和手柄设置,并重新应用相应的 EMS 默认值。已经在 EMS 中更改的设置会保留。" -- MT
L["ACCESS_CVAR_MIRROR_TOAST_APPLIED"] = "GRIP-EMS:已将 %d 个暴雪无障碍设置复制到 EMS。" -- MT
L["ACCESS_CVAR_MIRROR_TOAST_NOOP"] = "GRIP-EMS:无需复制无障碍设置。" -- MT
L["ACCESS_FONT_LABEL"] = "UI 字体" -- MT
L["ACCESS_FONT_DESC"] =
    "选择 EMS 面板和编辑器使用的字体。Atkinson Hyperlegible 内置以提供阅读障碍友好可读性(仅拉丁字符;其他字符回退到默认游戏字体)。" -- MT
L["ACCESS_FONT_RELOAD_NOTICE"] = "重载 UI 以使新字体在任何位置生效。" -- MT
L["ACCESS_THEME_SECTION_NAME"] = "主题" -- MT
L["ACCESS_THEME_SECTION_DESC"] =
    "微调背景和边框不透明度、每个面板的alpha,以及影响每个 EMS 面板的全局 UI 缩放。Tempo 和 Tracker 覆盖层使用固定品牌颜色 -- 不透明度滑块不会改变这些颜色,但覆盖层 alpha 滑块仍会让它们淡入淡出。" -- MT
L["ACCESS_THEME_UI_SCALE_LABEL"] = "UI 缩放(所有 EMS 面板)" -- MT
L["ACCESS_THEME_UI_SCALE_DESC"] = "缩放每个 EMS 面板和覆盖层。1.0 是原生大小。" -- MT
L["ACCESS_THEME_BG_OPACITY_LABEL"] = "背景不透明度" -- MT
L["ACCESS_THEME_BG_OPACITY_DESC"] = "面板背景透明度的乘数。1.0 保持主题默认。" -- MT
L["ACCESS_THEME_BORDER_OPACITY_LABEL"] = "边框不透明度" -- MT
L["ACCESS_THEME_BORDER_OPACITY_DESC"] = "面板边框透明度的乘数。1.0 保持主题默认。" -- MT
L["ACCESS_THEME_PANEL_ALPHA_LABEL"] = "面板 alpha" -- MT
L["ACCESS_THEME_PANEL_ALPHA_DESC"] = "主 EMS 面板的整体透明度 -- 主窗口、编辑器和对话框。" -- MT
L["ACCESS_THEME_OVERLAY_ALPHA_LABEL"] = "覆盖层 alpha" -- MT
L["ACCESS_THEME_OVERLAY_ALPHA_DESC"] = "覆盖层(Tempo、Tracker HUD、浮动菜单、新功能)的整体透明度。" -- MT
L["ACCESS_THEME_RESET_LABEL"] = "重置主题为默认" -- MT
L["ACCESS_THEME_RESET_DESC"] = "将所有主题滑块返回到 1.0。" -- MT
L["ACCESS_COLORBLIND_SECTION_NAME"] = "色觉" -- MT
L["ACCESS_COLORBLIND_SECTION_DESC"] =
    "如果你有色觉缺陷,请在下方选择最接近的匹配并调整校正强度。EMS 将转移自身颜色,使错误、警告和高亮保持可区分。" -- MT
L["ACCESS_COLORBLIND_TYPE_LABEL"] = "色觉缺陷" -- MT
L["ACCESS_COLORBLIND_TYPE_DESC"] = "应用于对比度预设之上。选择无即禁用校正。" -- MT
L["ACCESS_COLORBLIND_TYPE_NONE"] = "无" -- MT
L["ACCESS_COLORBLIND_TYPE_PROTANOMALY"] = "红色弱(红色感知减弱)" -- MT
L["ACCESS_COLORBLIND_TYPE_PROTANOPIA"] = "红色盲(无红色感知)" -- MT
L["ACCESS_COLORBLIND_TYPE_DEUTERANOMALY"] = "绿色弱(绿色感知减弱)" -- MT
L["ACCESS_COLORBLIND_TYPE_DEUTERANOPIA"] = "绿色盲(无绿色感知)" -- MT
L["ACCESS_COLORBLIND_TYPE_TRITANOMALY"] = "蓝色弱(蓝色感知减弱)" -- MT
L["ACCESS_COLORBLIND_TYPE_TRITANOPIA"] = "蓝色盲(无蓝色感知)" -- MT
L["ACCESS_COLORBLIND_TYPE_ACHROMATOMALY"] = "色弱(部分色觉丧失)" -- MT
L["ACCESS_COLORBLIND_TYPE_ACHROMATOPSIA"] = "全色盲(完全色觉丧失)" -- MT
L["ACCESS_COLORBLIND_STRENGTH_LABEL"] = "校正强度" -- MT
L["ACCESS_COLORBLIND_STRENGTH_DESC"] = "零保持 EMS 颜色不变。一百对所选缺陷应用完全校正。" -- MT
L["ACCESS_COLORBLIND_ACHROMAT_HINT"] =
    "在最大强度下,全色盲将 EMS 颜色压缩为灰度。如果你更喜欢基于标签的提示而非颜色,请将高对比度预设与无配对。" -- MT
L["ACCESS_COLORBLIND_PREVIEW_LABEL"] = "预览:" -- MT
L["ACCESS_COLORBLIND_STACK_WARN"] =
    "所选预设已为此缺陷调整。叠加可能过度校正 -- 试试默认预设或降低强度。" -- MT

-- Accessibility Tour (v2.0.0 Phase 3 item 10)
L["ACCESS_TOUR_WELCOME_TITLE"] = "欢迎使用 GRIP-EMS" -- MT
L["ACCESS_TOUR_WELCOME_BODY"] = "这个简短的导览将带你了解序列编辑器。你可以随时跳过。" -- MT
L["ACCESS_TOUR_LIST_TITLE"] = "你的序列" -- MT
L["ACCESS_TOUR_LIST_BODY"] = "此面板列出你的所有序列。点击其中一个来编辑。" -- MT
L["ACCESS_TOUR_STEPS_TITLE"] = "步骤选项卡" -- MT
L["ACCESS_TOUR_STEPS_BODY"] = "在这里编写序列的宏步骤。每个宏行一个步骤。" -- MT
L["ACCESS_TOUR_MACROS_TITLE"] = "宏选项卡" -- MT
L["ACCESS_TOUR_MACROS_BODY"] = "此选项卡显示生成的宏槽位。你可以将它们固定到动作条上。" -- MT
L["ACCESS_TOUR_KEYBIND_TITLE"] = "按键绑定选项卡" -- MT
L["ACCESS_TOUR_KEYBIND_BODY"] = "在这里为序列绑定按键。捕获新绑定或从列表中选择。" -- MT
L["ACCESS_TOUR_TEST_TITLE"] = "测试和禁用" -- MT
L["ACCESS_TOUR_TEST_BODY"] = "使用此按钮在不删除的情况下禁用序列。战斗中安全。" -- MT
L["ACCESS_TOUR_IMPORT_TITLE"] = "导入和导出" -- MT
L["ACCESS_TOUR_IMPORT_BODY"] = "在此粘贴序列字符串以导入。导出你的序列与其他玩家分享。" -- MT
L["ACCESS_TOUR_DONE_TITLE"] = "你已就绪" -- MT
L["ACCESS_TOUR_DONE_BODY"] =
    "打开无障碍设置以调整缩放、对比度和语音选项。任何时候用 /gems tour 重新运行导览。" -- MT
L["ACCESS_TOUR_BACK"] = "返回" -- MT
L["ACCESS_TOUR_SKIP"] = "跳过" -- MT
L["ACCESS_TOUR_NEXT"] = "下一步" -- MT
L["ACCESS_TOUR_DONE"] = "完成" -- MT
L["ACCESS_TOUR_RESET_TOAST"] = "教程已重置。下次登录时显示。" -- MT

-- Accessibility: Help popovers (Phase 3 #11)
L["ACCESS_HELP_BUTTON_LABEL"] = "?" -- MT
L["ACCESS_HELP_BUTTON_TOOLTIP"] = "帮助" -- MT
L["ACCESS_HELP_CLOSE"] = "关闭" -- MT
L["ACCESS_HELP_TITLE_STEPS"] = "步骤选项卡" -- MT
L["ACCESS_HELP_BODY_STEPS"] =
    "每行是序列中的一个步骤。添加按钮可以插入法术、物品、宏或嵌套动作。拖动行进行重新排序。当列表有键盘焦点时,使用方向键在行间移动。" -- MT
L["ACCESS_HELP_TITLE_KEYBIND"] = "按键绑定选项卡" -- MT
L["ACCESS_HELP_BODY_KEYBIND"] =
    "设置触发此序列的按键。支持修饰键(Shift、Ctrl、Alt)和鼠标按键。每个序列只能一个按键绑定。与现有绑定的冲突会内联标记。" -- MT
L["ACCESS_HELP_TITLE_MACROS"] = "宏选项卡" -- MT
L["ACCESS_HELP_BODY_MACROS"] =
    "编写与序列一同运行的辅助宏行。用它们处理目标选择、停止施法或不需要单独步骤的任何操作。它们随序列触发的每个步骤一起运行。" -- MT
L["ACCESS_HELP_TITLE_CONTEXT"] = "上下文选项卡" -- MT
L["ACCESS_HELP_BODY_CONTEXT"] =
    "尚不可用。此选项卡将允许按区域、难度、专精或其他游戏内上下文限制序列。" -- MT
L["ACCESS_HELP_TITLE_VARIABLES"] = "变量选项卡" -- MT
L["ACCESS_HELP_BODY_VARIABLES"] =
    "尚不可用。此选项卡将允许定义可被步骤按名称引用的可重用值。" -- MT
L["ACCESS_HELP_TITLE_RAW"] = "原始选项卡" -- MT
L["ACCESS_HELP_BODY_RAW"] = "尚不可用。此选项卡将显示序列的完整生成宏文本,用于调试。" -- MT
L["ACCESS_HELP_TITLE_DEFAULT"] = "序列编辑器" -- MT
L["ACCESS_HELP_BODY_DEFAULT"] =
    "在上方选择选项卡以切换部分。右上的按钮行处理保存、放弃、导出、禁用、录制和发送。? 按钮打开活动选项卡的帮助。" -- MT
L["ACCESS_HELP_TITLE_PICKER"] = "法术 / 物品 / 宏选择器" -- MT
L["ACCESS_HELP_BODY_PICKER"] = "在法术、物品、宏和斜杠命令中搜索。" -- MT
    .. "使用左侧栏按类别筛选。"
    .. "点击行将其插入步骤。底部的条件按钮"
    .. "添加修饰前缀。ESC 关闭。" -- MT

-- About info (T1-5)
L["GEMS_ABOUT_AUTHOR"] = "作者:Sataana (MrSataana)" -- MT
L["GEMS_ABOUT_LINKS"] =
    "指南:jesperlive.github.io/grip-ems-guide/\nCurseForge:curseforge.com/wow/addons/grip-enhanced-macro-sequencer\nWago:addons.wago.io/addons/qGZODqNd\nWoWInterface:wowinterface.com/downloads/info27081" -- MT
L["GEMS_ABOUT_KEYBINDS"] = "活动按键绑定:%d" -- MT
L["GEMS_ABOUT_OOC_QUEUE"] = "战斗外队列:%d 待处理" -- MT
L["GEMS_ABOUT_SOURCE_STATUS"] = "迁移源:%s" -- MT
L["GEMS_ABOUT_MACRO_SLOTS"] = "宏槽位:%d / %d (每角色)" -- MT
L["GEMS_UI_ACTIVE_SEQUENCES_LABEL"] = "活动序列" -- MT
L["GEMS_UI_CONTEXT_LABEL"] = "上下文" -- MT
L["GEMS_LOGIN_ACTIVE"] = "|cFF888888  %d 个活动序列|r" -- MT
L["GEMS_UI_SETTINGS_BTN"] = "设置" -- MT
L["GEMS_UI_SETTINGS_BTN_DESC"] = "打开 GRIP-EMS 设置面板" -- MT

-- Migration report (T1-9)
L["GEMS_REPORT_HEADER_MIGRATE"] = "--- GRIP-EMS 迁移报告 ---" -- MT
L["GEMS_REPORT_HEADER_IMPORT"] = "--- GRIP-EMS 导入报告 ---" -- MT
L["GEMS_REPORT_IMPORTED"] = "已导入:%d 个序列,%d 个变量" -- MT
L["GEMS_REPORT_DORMANT"] = "  (%d 个为其他职业储存,登录时激活)" -- MT
L["GEMS_REPORT_SKIPPED"] = "已跳过:%d (已存在)" -- MT
L["GEMS_REPORT_SEQ_ENTRY"] = "  + %s (%d 步骤,%s)" -- MT
L["GEMS_REPORT_LIMITATIONS"] = "已知限制:" -- MT
L["GEMS_REPORT_VERSIONS_DROPPED"] = "  - %d 个额外版本未导入(仅支持默认版本)" -- MT
L["GEMS_REPORT_PAUSES_CONVERTED"] = "  - %d 个暂停动作已转换为 %d 个空步骤" -- MT
L["GEMS_REPORT_EMBEDS_SKIPPED"] = "  - %d 个嵌入序列引用已跳过(尚不支持)" -- MT
L["GEMS_REPORT_TRUNCATED"] = "  - %d 个步骤太长被截断(WoW 将宏限制为 255 字符)" -- MT
L["GEMS_REPORT_ENCRYPTED_SKIPPED"] = "  - 已跳过 %d 个加密项目（受保护内容，无法导入）" -- TODO: MT 2026-06-21
L["GEMS_REPORT_TIP_VERIFY"] = "提示:打开每个迁移的序列并验证步骤是否正确。" -- MT
L["GEMS_REPORT_TIP_VERSIONS"] = "使用 /gems 打开编辑器并配置上下文版本覆盖。" -- MT

-- Guide (T1-10)
L["GEMS_GUIDE_TITLE"] = "GRIP-EMS 交互指南" -- MT
L["GEMS_GUIDE_PATH"] = "复制此 URL 并在浏览器中打开:" -- MT
L["GEMS_GUIDE_TIP"] = "本地文件:Interface/AddOns/GRIP-EMS/Guide/GRIP-EMS_Guide.html" -- MT
L["GEMS_GUIDE_URL"] = "https://jesperlive.github.io/grip-ems-guide/" -- MT
L["GEMS_GUIDE_CLICK"] = "|cff4ecca3|HGRIPEMSguide|h[点击此处打开 GRIP-EMS 指南]|h|r" -- MT
L["GEMS_HELP_GUIDE"] = "  /gems guide - GRIP-EMS 交互指南" -- MT

-- Import preview (T2-4)
L["GEMS_IMPORT_PREVIEW_TITLE"] = "导入预览" -- MT
L["GEMS_IMPORT_PREVIEW_SEQ_HEADER"] = "序列 (%d)" -- MT
L["GEMS_IMPORT_PREVIEW_VAR_HEADER"] = "变量 (%d)" -- MT
L["GEMS_IMPORT_PREVIEW_NEW"] = "新建" -- MT
L["GEMS_IMPORT_PREVIEW_EXISTS"] = "已存在" -- MT
L["GEMS_IMPORT_PREVIEW_IDENTICAL"] = "相同" -- MT
L["GEMS_IMPORT_PREVIEW_DIFFERENT"] = "不同" -- MT
L["GEMS_IMPORT_PREVIEW_IMPORT_SELECTED"] = "导入所选 (%d)" -- MT
L["GEMS_IMPORT_PREVIEW_CANCEL"] = "取消" -- MT
L["GEMS_IMPORT_PREVIEW_SELECT_ALL"] = "全选" -- MT
L["GEMS_IMPORT_PREVIEW_DESELECT_ALL"] = "取消全选" -- MT
L["GEMS_IMPORT_PREVIEW_EMPTY"] = "此字符串中未找到序列或变量。" -- MT
L["GEMS_IMPORT_PREVIEW_DESC"] = "读取粘贴的文本并显示可导入的序列" -- MT
L["GEMS_IMPORT_CLEAR_DESC"] = "清空粘贴框" -- MT
L["GEMS_IMPORT_SELECT_ALL_DESC"] = "选择所有序列以导入" -- MT
L["GEMS_IMPORT_DESELECT_ALL_DESC"] = "取消选择所有序列" -- MT
L["GEMS_IMPORT_CANCEL_DESC"] = "返回粘贴步骤" -- MT
L["GEMS_IMPORT_COMMIT_DESC"] = "导入所选序列" -- MT
L["GEMS_IMPORT_PREVIEW_SUMMARY"] = "已导入 %d 个序列,%d 个变量" -- MT
L["GEMS_IMPORT_PREVIEW_BTN"] = "预览" -- MT
L["GEMS_IMPORT_PREVIEW_HEADER"] = "%d 个序列,%d 个变量" -- MT
L["GEMS_IMPORT_PREVIEW_NEW_COUNT"] = "%d 个新增" -- MT
L["GEMS_IMPORT_PREVIEW_EXISTING_COUNT"] = "%d 个已有" -- MT
L["GEMS_IMPORT_PREVIEW_INFO"] = "%d 个版本,%d 个步骤" -- MT
L["GEMS_IMPORT_PREVIEW_ACTION_SKIP"] = "跳过" -- MT
L["GEMS_IMPORT_PREVIEW_ACTION_REPLACE"] = "替换" -- MT
L["GEMS_IMPORT_PREVIEW_ACTION_RENAME"] = "重命名" -- MT

-- Advanced Export (T2-12)
L["GEMS_EXPORT_PICK_TITLE"] = "导出序列" -- MT
L["GEMS_EXPORT_PICK_HEADER"] = "%d sequences, %d variables, %d macros available" -- MT
L["GEMS_EXPORT_PICK_SEQ_HEADER"] = "序列 (%d)" -- MT
L["GEMS_EXPORT_PICK_VAR_HEADER"] = "变量 (%d)" -- MT
L["GEMS_EXPORT_PICK_MACRO_HEADER"] = "Macros (%d)" -- MT
L["GEMS_EXPORT_PICK_MACRO_DEPS"] = "(+%d macros)" -- MT
L["GEMS_EXPORT_PICK_MACRO_SCOPE_ACCOUNT"] = "account" -- MT
L["GEMS_EXPORT_PICK_MACRO_SCOPE_CHARACTER"] = "char" -- MT
L["GEMS_EXPORT_PICK_INFO"] = "%d 个版本,%d 个步骤" -- MT
L["GEMS_EXPORT_PICK_VAR_DEPS"] = "(+%d 个变量)" -- MT
L["GEMS_EXPORT_PICK_USED_BY"] = "用于:%s" -- MT
L["GEMS_EXPORT_PICK_AUTO"] = "自动" -- MT
L["GEMS_EXPORT_PICK_SELECT_ALL"] = "全选" -- MT
L["GEMS_EXPORT_PICK_DESELECT_ALL"] = "取消全选" -- MT
L["GEMS_EXPORT_PICK_EXPORT_SELECTED"] = "导出所选 (%d)" -- MT
L["GEMS_EXPORT_PICK_BACK"] = "返回" -- MT
L["GEMS_EXPORT_PICK_DISPLAY_HEADER"] = "Exported %d sequences, %d variables, %d macros" -- MT
L["GEMS_EXPORT_PICK_EMBEDDED_WARN"] = "%s 使用 %s (未选择)" -- MT
L["GEMS_EXPORT_PICK_LOCALE_WARN"] =
    "依赖于本地化特定法术名称的变量可能对使用其他游戏语言的玩家不起作用" -- MT
L["GEMS_EXPORT_COPY_TEXT"] = "复制为文本" -- MT
L["GEMS_EXPORT_COPY_TEXT_DESC"] = "将可读摘要复制到剪贴板" -- MT
L["GEMS_EXPORT_META_TITLE"] = "导出元数据" -- MT
L["GEMS_EXPORT_META_SUBTITLE"] = "在导出 %d 个序列前查看并自定义" -- MT
L["GEMS_EXPORT_META_NAME"] = "集合名称" -- MT
L["GEMS_EXPORT_META_AUTHOR"] = "作者" -- MT
L["GEMS_EXPORT_META_DESC"] = "描述" -- MT
L["GEMS_EXPORT_META_URL"] = "URL / 链接" -- MT
L["GEMS_EXPORT_META_TALENT"] = "天赋配置" -- MT
L["GEMS_EXPORT_META_INCLUDE_AUTHOR"] = "包含作者" -- MT
L["GEMS_EXPORT_META_INCLUDE_DESC"] = "包含描述" -- MT
L["GEMS_EXPORT_META_INCLUDE_TALENT"] = "包含天赋字符串" -- MT
L["GEMS_EXPORT_META_INCLUDE_URL"] = "包含 URL" -- MT
L["GEMS_EXPORT_META_GENERATE"] = "生成导出字符串" -- MT
L["GEMS_EXPORT_META_BACK"] = "返回选择" -- MT
L["GEMS_IMPORT_COLLECTION_HEADER"] = "集合:%s,作者 %s" -- MT
L["GEMS_UI_EXPORT_MULTI"] = "导出多个..." -- MT
L["GEMS_HELP_EXPORTALL"] = "  /gems exportall - 打开多选导出窗口" -- MT
L["GEMS_EXPORT_GENERATE_DESC"] = "从所选序列生成导出字符串" -- MT
L["GEMS_EXPORT_COPY_DESC"] = "将导出字符串复制到剪贴板" -- MT
L["GEMS_EXPORT_SELECT_ALL_DESC"] = "选择所有序列以导出" -- MT
L["GEMS_EXPORT_DESELECT_ALL_DESC"] = "取消选择所有序列" -- MT
L["GEMS_EXPORT_BACK_DESC"] = "返回选择" -- MT
L["GEMS_EXPORT_CLOSE_DESC"] = "关闭导出窗口" -- MT

-- Transmission (T2-9)
L["GEMS_HELP_SEND"] = "  /gems send <name> <player> - 发送序列给其他玩家" -- MT
L["GEMS_HELP_ACCEPT"] = "  /gems accept - 接受最新到达的序列" -- MT
L["GEMS_HELP_VALIDATE"] = "  /gems validate - 验证所有序列以查找过时/无效法术" -- MT
L["GEMS_SEND_USAGE"] = "用法: /gems send <name> <player>" -- MT
L["GEMS_SEND_SUCCESS"] = "已发送 '%s' 给 %s" -- MT
L["GEMS_SEND_FAILED"] = "发送失败:%s" -- MT
L["GEMS_SEND_DISABLED"] = "P2P 共享在设置中已禁用。" -- MT
L["GEMS_SEND_NO_SEQ"] = "未找到名为 '%s' 的序列。" -- MT
L["GEMS_EXPORT_NO_REDISTRIBUTE"] = "Sequence '%s' is marked do-not-share by its author; sharing is refused." -- MT
L["GEMS_RECEIVE_ANNOUNCE"] = "已从 %s 接收序列。正在打开导入..." -- MT
L["GEMS_RECEIVE_AUTO"] = "已从 %s (好友)自动导入 '%s'。" -- MT
L["GEMS_REQUEST_SENT"] = "正在向 %s 请求 '%s'..." -- MT
L["GEMS_REQUEST_FULFILLED"] = "已发送 '%s' 给 %s (已请求)。" -- MT
L["GEMS_VERSION_ANNOUNCE"] = "检测到 GRIP-EMS 用户:%s (v%s)" -- MT
L["GEMS_ACCEPT_USAGE"] = "没有待接受的序列。" -- MT
L["GEMS_UI_SEND_PLAYER"] = "发送给玩家" -- MT
L["GEMS_UI_SEND_BTN"] = "发送" -- MT
L["GEMS_UI_SEND_BTN_DESC"] = "将此序列发送给其他玩家" -- MT
L["GEMS_SEND_DIALOG_TEXT"] = "将 '%s' 发送给:" -- MT
L["GEMS_SEND_DIALOG_ACCEPT"] = "发送" -- MT
L["GEMS_SEND_DIALOG_KNOWN"] = "已知用户:" -- MT
L["GEMS_META_SENT"] = "已发送 '%s' 的元数据同步请求。" -- MT
L["GEMS_META_NEWER"] = "%s 提供 '%s' 的更新版本,正在请求..." -- MT
L["GEMS_META_CURRENT"] = "本地 '%s' 是最新的(远端来自 %s)。" -- MT
L["GEMS_SPELLCACHE_SENT"] = "已向队伍广播法术缓存。" -- MT
L["GEMS_SPELLCACHE_MERGED"] = "已合并来自 %s 的 %d 个法术缓存条目。" -- MT
L["GEMS_P2P_ENABLED"] = "启用 P2P 共享" -- MT
L["GEMS_P2P_ENABLED_DESC"] = "与使用此插件的其他玩家发送和接收序列。" -- MT
L["GEMS_P2P_AUTO_FRIENDS"] = "自动接受好友的序列" -- MT
L["GEMS_P2P_AUTO_FRIENDS_DESC"] = "无需询问即保存好友发送的序列。" -- MT
L["GEMS_P2P_ANNOUNCE"] = "宣布接收" -- MT
L["GEMS_P2P_ANNOUNCE_DESC"] = "从其他玩家接收序列时打印聊天行。" -- MT
L["GEMS_IMPORT_FROM"] = "从 %s 导入" -- MT

-- Block list (T2-9)
L["GEMS_BLOCK_ADDED"] = "已阻止 %s 进行 P2P 传输。" -- MT
L["GEMS_BLOCK_REMOVED"] = "已解除阻止 %s。" -- MT
L["GEMS_BLOCK_NOT_FOUND"] = "%s 未被阻止。" -- MT
L["GEMS_BLOCK_LIST_EMPTY"] = "没有被阻止的玩家。" -- MT
L["GEMS_BLOCK_LIST_HEADER"] = "已阻止玩家:" -- MT
L["GEMS_SETTINGS_BLOCKED_PLAYERS"] = "已阻止玩家" -- MT
L["GEMS_SETTINGS_BLOCKED_PLAYERS_DESC"] = "此列表中的玩家无法向你发送序列。" -- MT
L["GEMS_HELP_BLOCK"] = "  /gems block <player> - 阻止玩家向你发送序列" -- MT
L["GEMS_HELP_UNBLOCK"] = "  /gems unblock <player> - 解除阻止玩家" -- MT
L["GEMS_HELP_BLOCKLIST"] = "  /gems blocklist - 列出所有被阻止的玩家" -- MT

-- Tracker HUD (T2-7)
L["GEMS_TRACKER_TOGGLE"] = "追踪器 HUD %s。" -- MT
L["GEMS_TRACKER_LOCKED"] = "追踪器已锁定。" -- MT
L["GEMS_TRACKER_UNLOCKED"] = "追踪器已解锁。" -- MT
L["GEMS_TRACKER_HEADER"] = "追踪器 HUD" -- MT
L["GEMS_TRACKER_ICONSIZE_DESC"] = "设置每个序列图标的像素大小。" -- MT
L["GEMS_TRACKER_ORIENTATION_DESC"] = "图标按行或按列堆叠。" -- MT
L["GEMS_TRACKER_SHOWNAME_DESC"] = "在每个图标下方显示序列名称。" -- MT
L["GEMS_TRACKER_SHOWMODS_DESC"] = "显示当前按住的修饰键(Alt、Shift 或 Ctrl)。" -- MT
L["GEMS_TRACKER_LOCK_DESC"] = "锁定追踪器 HUD,使其无法拖动。" -- MT
L["GEMS_TRACKER_SHOWMODE_DESC"] = "选择追踪器 HUD 何时显示在屏幕上。" -- MT
L["GEMS_TRACKER_MODE_ALWAYS"] = "始终" -- MT
L["GEMS_TRACKER_MODE_COMBAT"] = "战斗中" -- MT
L["GEMS_TRACKER_MODE_TARGET"] = "有目标时" -- MT
L["GEMS_TRACKER_MODE_NEVER"] = "从不" -- MT
L["GEMS_TRACKER_SCALE_DESC"] = "更改追踪器 HUD 的整体大小。" -- MT
L["GEMS_TRACKER_PREVIEW_HINT"] = "预览显示 HUD 当前的样子。战斗中数值可能不同。" -- MT
L["GEMS_HELP_TRACKER"] = "  /gems tracker [lock] - 切换追踪器 HUD" -- MT

-- Debug window (T1-6)
L["GEMS_HELP_DEBUGWINDOW"] = "  /gems debugwindow - 切换调试消息窗口" -- MT
L["GEMS_DEBUG_WINDOW_TITLE"] = "GRIP-EMS 调试" -- MT
L["GEMS_DEBUG_CLEAR"] = "清除" -- MT
L["GEMS_DEBUG_COPY"] = "复制" -- MT
L["GEMS_DEBUG_COPY_HINT"] = "使用 /gems export 或从导出框 Ctrl+C 复制调试输出。" -- MT
L["GEMS_UI_WHATSNEW_DISMISS"] = "不再显示" -- MT
L["GEMS_WHATSNEW_DISMISS_DESC"] = "在此版本中不再显示此消息" -- MT
L["GEMS_DEBUG_CLOSE_DESC"] = "关闭调试窗口" -- MT
L["GEMS_DEBUG_CLEAR_DESC"] = "清除所有调试消息" -- MT
L["GEMS_DEBUG_COPY_DESC"] = "将所有消息复制到剪贴板" -- MT

-- Locale Phase 2e
L["GEMS_HELP_REVALIDATE"] = "  /gems revalidate - 用当前法术 ID 更新所有序列" -- MT

-- Click rate (v1.2.0 S01)
L["GEMS_SETTINGS_CLICK_RATE"] = "点击速率(毫秒)" -- MT
-- TODO: MT 2026-06-13, needs native review (match British enUS)
L["GEMS_SETTINGS_CLICK_RATE_DESC"] =
    "序列的按键速度（毫秒）。EMS 每次按键前进一步，不会限制你的按键速度；此数值用于指导 Faster, Slower 推荐和导入暂停的计时。默认值为 250 毫秒。" -- MT
L["GEMS_SETTINGS_CHAR_OVERRIDES"] = "角色覆盖" -- MT
L["GEMS_SETTINGS_CHAR_CLICK_RATE"] = "每角色点击速率(毫秒)" -- MT
L["GEMS_SETTINGS_CHAR_CLICK_RATE_DESC"] = "仅在此角色上使用不同的点击速率。设为 0 改用共享值。" -- MT
L["GEMS_STATUS_CLICK_RATE"] = "点击速率:%d 毫秒(生效)" -- MT
L["GEMS_STATUS_CVAR_PENDING_LINE"] = "%d pending CVar changes:" -- MT
L["GEMS_STATUS_CVAR_CAUSE_LINE"] = "  %d %s" -- MT

-- Macro reset modifiers (v1.2.0 S01)
L["GEMS_SETTINGS_MACRO_RESET"] = "宏重置" -- MT
L["GEMS_RESET_MOD_DESC"] = "按下按键时按住此修饰键则将步骤计数器重置为 1。" -- MT
L["GEMS_UI_RESET_MODS_HEADER"] = "重置修饰键覆盖" -- MT
L["GEMS_UI_RESET_MODS_ENABLE"] = "使用每个序列的覆盖" -- MT
L["GEMS_UI_RESET_MODS_GLOBAL"] = "(使用全局设置)" -- MT
L["GEMS_RESET_MOD_LEFTBUTTON"] = "左键点击" -- MT
L["GEMS_RESET_MOD_RIGHTBUTTON"] = "右键点击" -- MT
L["GEMS_RESET_MOD_MIDDLEBUTTON"] = "中键点击" -- MT
L["GEMS_RESET_MOD_BUTTON4"] = "鼠标按键 4" -- MT
L["GEMS_RESET_MOD_BUTTON5"] = "鼠标按键 5" -- MT
L["GEMS_RESET_MOD_LEFTALT"] = "左 Alt" -- MT
L["GEMS_RESET_MOD_RIGHTALT"] = "右 Alt" -- MT
L["GEMS_RESET_MOD_ALT"] = "任意 Alt" -- MT
L["GEMS_RESET_MOD_LEFTCONTROL"] = "左 Ctrl" -- MT
L["GEMS_RESET_MOD_RIGHTCONTROL"] = "右 Ctrl" -- MT
L["GEMS_RESET_MOD_CONTROL"] = "任意 Ctrl" -- MT
L["GEMS_RESET_MOD_LEFTSHIFT"] = "左 Shift" -- MT
L["GEMS_RESET_MOD_RIGHTSHIFT"] = "右 Shift" -- MT
L["GEMS_RESET_MOD_SHIFT"] = "任意 Shift" -- MT
L["GEMS_RESET_MOD_ANYMOD"] = "任意修饰键" -- MT
L["GEMS_RESET_MOD_MOUSE_HEADER"] = "鼠标按键" -- MT
L["GEMS_RESET_MOD_ALT_HEADER"] = "Alt 键" -- MT
L["GEMS_RESET_MOD_CONTROL_HEADER"] = "Ctrl 键" -- MT
L["GEMS_RESET_MOD_SHIFT_HEADER"] = "Shift 键" -- MT
L["GEMS_RESET_MOD_ANY_HEADER"] = "组合" -- MT

-- Corrupt sequence recovery
L["GEMS_CORRUPT_TITLE"] = "检测到损坏的序列" -- MT
L["GEMS_CORRUPT_TEXT"] = "无法加载序列 '%s'。\n\n错误:%s\n\n选择一个操作:" -- MT
L["GEMS_CORRUPT_DELETE"] = "删除" -- MT
L["GEMS_CORRUPT_SKIP"] = "跳过" -- MT
L["GEMS_CORRUPT_EXPORT"] = "导出原始" -- MT
L["GEMS_CORRUPT_SUMMARY"] = "损坏的序列:%d 已删除,%d 已跳过,%d 已导出" -- MT
L["GEMS_CORRUPT_NONE"] = "未发现损坏的序列。" -- MT

-- Execution Tracer (v1.2.0 S03-B)
L["GEMS_TRACE_CAST"] = "[追踪] %s (ID: %d)%s" -- MT
L["GEMS_TRACE_STARTED"] = "执行追踪已开始" -- MT
L["GEMS_TRACE_STOPPED"] = "执行追踪已停止" -- MT
L["GEMS_TRACE_STATUS"] = "执行追踪器:%s (%.2f CPS)。" -- MT
L["GEMS_TRACE_STATE_ON"] = "开" -- MT
L["GEMS_TRACE_STATE_OFF"] = "关" -- MT
L["GEMS_TRACE_UNAVAILABLE"] = "执行追踪器不可用。" -- MT

-- CVar health (v1.2.0 S01)
L["GEMS_SETTINGS_CVAR_HEALTH"] = "CVar 健康" -- MT
L["GEMS_SETTINGS_CVAR_DESC"] =
    "%d 个类别的游戏变量(%d 个 CVar)。绿色 = 最佳,黄色 = 不理想,红色 = 关键,灰色 = 信息性。" -- MT
L["GEMS_SETTINGS_CVAR_AUTOFIX"] = "登录时自动修复 CVar" -- MT
L["GEMS_SETTINGS_CVAR_AUTOFIX_DESC"] = "每次登录时为你设置建议的 CVar 值。" -- MT
L["GEMS_SETTINGS_CVAR_FIX"] = "修复" -- MT

-- CVar Dashboard UI strings
L["GEMS_CVAR_FIX_ALL"] = "全部修复" -- MT
L["GEMS_CVAR_FIX_ALL_CRITICAL"] = "修复所有关键项" -- MT
L["GEMS_CVAR_FIX_ALL_SECTION"] = "修复此部分所有项" -- MT
L["GEMS_CVAR_AUTOFIX_ENTRY"] = "登录时自动修复" -- MT
L["GEMS_CVAR_AUTOFIX_ENTRY_GATED"] =
    "必须先启用主自动修复。开启上方的自动修复推荐值以使用每个 CVar 的选择启用。" -- MT
L["GEMS_CVAR_AUTOFIX_SECTION_GATED"] =
    "Master Auto-fix is off. Turn on Auto-fix recommended values above to choose per-CVar opt-ins." -- MT
L["GEMS_CVAR_AUTOFIX_PIN_OVERRIDE"] = "Pinned -- auto-fix is overridden until you unpin." -- MT
L["GEMS_CVAR_AUTOFIX_COUNT"] = "GEMS:登录时自动修复了 %d 个 CVar。" -- MT
L["GEMS_CVAR_HEALTH_SCORE"] = "CVar 健康:%d/100" -- MT
L["GEMS_CVAR_SCORE_HISTORY_HEADER"] = "评分历史" -- MT
L["GEMS_CVAR_SCORE_HISTORY_EMPTY"] = "暂无历史记录：将在登录时记录。" -- MT
L["GEMS_CVAR_SCORE_HISTORY_RANGE"] = "最低 %d / 最高 %d" -- MT
L["GEMS_CVAR_SECTION_HEALTH"] = "%s %s"
L["GEMS_CVAR_HEALTH_EXPLAIN_HEADER"] = "评分原因:" -- MT
L["GEMS_CVAR_HEALTH_EXPLAIN_PERFECT"] = "所有推荐值已应用。无需修复。" -- MT
L["GEMS_CVAR_HEALTH_EXPLAIN_OFFENDER"] = "  - %s:%s -> %s (权重 %d)" -- MT
L["GEMS_CVAR_HEALTH_EXPLAIN_SQW_CREDIT"] = "  - SpellQueueWindow:由 SQW 优化器管理(自动计入)" -- MT
L["GEMS_CVAR_HEALTH_EXPLAIN_MORE"] = "  ...还有 %d 个(打开相关部分查看全部)。" -- MT
L["GEMS_CVAR_SECURE_TAG"] = " (安全)" -- MT
L["GEMS_CVAR_COMBAT_DISABLED"] = "战斗中无法更改安全 CVar。" -- MT
L["GEMS_CVAR_INFORMATIONAL"] = " (信息性)" -- MT
L["GEMS_CVAR_YOUR_CHOICE"] = "(你的选择)" -- MT
L["GEMS_CVAR_WILL_CHANGE"] = "将从 %s 变为 %s。" -- MT
L["GEMS_CVAR_SET_VALUE"] = "设置值" -- MT
L["GEMS_CVAR_UNDO"] = "撤销" -- MT
L["GEMS_CVAR_UNDO_DESC"] =
    "恢复此 CVar 的上一个值(EMS 上次更改之前的值)。CVar 被固定时禁用 -- 请先解除固定。" -- MT
L["GEMS_CVAR_UNDO_TO"] = "撤销到 %s" -- MT
L["GEMS_CVAR_REDO"] = "Redo" -- MT
L["GEMS_CVAR_REDO_DESC"] =
    "Reapply the value that was undone by the last Undo. Disabled while the CVar is pinned -- unpin first." -- MT
L["GEMS_CVAR_REDO_TO"] = "Redo to %s" -- MT
L["GEMS_CVAR_PIN"] = "固定我的选择" -- MT
L["GEMS_CVAR_PIN_DESC"] =
    "将此值标记为你的有意选择。EMS 不会通过修复操作、配置文件交换或登录时自动修复来修改它。CVar 健康评分将其计为最佳。" -- MT
L["GEMS_CVAR_PIN_PINNED"] = "已固定 -- EMS 不会更改此 CVar。" -- MT
L["GEMS_CVAR_OPTION_RECOMMENDED"] = "%s (推荐)" -- MT

-- L372 G.3b first wave -- options + descLong for 6 cvars (MT placeholders, awaiting native review)
L["GEMS_CVAR_MACRO_KEYDOWN_OPT_0"] = "Key Up (release)" -- MT
L["GEMS_CVAR_MACRO_KEYDOWN_OPT_1"] = "Key Down (press)" -- MT
L["GEMS_CVAR_MACRO_KEYDOWN_DESCLONG"] =
    "Controls whether action bar buttons fire when you press the key (1) or when you release it (0). EMS macro sequences need this set to 1 -- the click-on-press path is what advances the step counter. Set to 0 and your sequences either don't advance or fire on the wrong key event." -- MT

L["GEMS_CVAR_MACRO_LOCKBARS_OPT_0"] = "Unlocked" -- MT
L["GEMS_CVAR_MACRO_LOCKBARS_OPT_1"] = "Locked" -- MT
L["GEMS_CVAR_MACRO_LOCKBARS_DESCLONG"] =
    "Locks action bar buttons in place so you cannot drag them off the bar by accident. Recommended on (1) once you have your bars set up the way you want -- accidentally dragging a spell off mid-fight is a frustrating way to die. Turn it off (0) when you actively want to rearrange spells." -- MT

L["GEMS_CVAR_NAMEPLATES_SHOWENEMY_OPT_0"] = "Hide" -- MT
L["GEMS_CVAR_NAMEPLATES_SHOWENEMY_OPT_1"] = "Show" -- MT
L["GEMS_CVAR_NAMEPLATES_SHOWENEMY_DESCLONG"] =
    "Master toggle for showing nameplates above enemy units. Recommended on (1) for anyone who plays in groups or PvP -- you need them to read incoming damage and target priority. Off (0) only makes sense for solo overworld questing where the screen is already cluttered." -- MT

L["GEMS_CVAR_FCT_ENABLE_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_FCT_ENABLE_OPT_1"] = "On" -- MT
L["GEMS_CVAR_FCT_ENABLE_DESCLONG"] =
    "Master toggle for the floating numbers that pop up when you deal or take damage. Recommended on (1) -- the numbers are how most players read combat tempo and gauge how hard a hit landed. Off (0) cleans the screen but you lose the per-hit feedback that healers and DPS both lean on." -- MT

L["GEMS_CVAR_MACRO_SELFCAST_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_MACRO_SELFCAST_OPT_1"] = "On" -- MT
L["GEMS_CVAR_MACRO_SELFCAST_DESCLONG"] =
    "Lets the game cast certain friendly spells on you when you have no target. Recommended on (1) -- without it, healing spells with no target either silently fail or pop a no-target error. With it on, you save a modifier-key tap for self-heals. Off (0) is for players who use macros that already encode their self-cast intent." -- MT

L["GEMS_CVAR_MACRO_AUTOPUSH_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_MACRO_AUTOPUSH_OPT_1"] = "On" -- MT
L["GEMS_CVAR_MACRO_AUTOPUSH_DESCLONG"] =
    "When you learn a new spell, the game automatically places it on your first empty action bar slot. Recommended off (0) -- for players running organised bars, which is most EMS users, the auto-place behaviour scatters newly learned spells into random slots you then have to find and remove. Off lets you place spells where you want them." -- MT

L["GEMS_CVAR_MACRO_MULTIBARS_OPT_0"] = "0 (None)" -- MT
L["GEMS_CVAR_MACRO_MULTIBARS_OPT_1"] = "1 (Action Bar 2)" -- MT
L["GEMS_CVAR_MACRO_MULTIBARS_OPT_3"] = "3 (Action Bars 2 + 3)" -- MT
L["GEMS_CVAR_MACRO_MULTIBARS_OPT_12"] = "12 (Right Action Bars 1 + 2)" -- MT
L["GEMS_CVAR_MACRO_MULTIBARS_OPT_15"] = "15 (All four extra bars)" -- MT
L["GEMS_CVAR_MACRO_MULTIBARS_DESCLONG"] =
    "Picks which extra action bars are visible on top of your main action bar. WoW exposes four extra bars and stores your selection as a 4-bit mask: bit 1 (value 1) shows Action Bar 2 (Bottom Left), bit 2 (value 2) shows Action Bar 3 (Bottom Right), bit 4 (value 4) shows Right Action Bar 1, bit 8 (value 8) shows Right Action Bar 2. The dropdown exposes five common combinations: 0=None, 1=Action Bar 2 only, 3=Action Bars 2+3 (both bottom), 12=Right Action Bars 1+2 (both right), 15=all four. For mixed combinations not in the list (e.g. bottom-left + right only = 5), use the in-game ActionBars settings panel (Settings > ActionBars) which exposes per-bar checkboxes, or run /console set enableMultiActionBars N where N is your chosen bitmask sum. EMS does not auto-set this value because bar-layout is a personal UX choice -- pick what matches your playstyle. This setting is per-character (each alt has its own bar visibility)." -- MT

L["GEMS_CVAR_MACRO_HELDPOLL_OPT_100"] = "100 ms (minimum, clamped)" -- MT
L["GEMS_CVAR_MACRO_HELDPOLL_OPT_250"] = "250 ms (snappy)" -- MT
L["GEMS_CVAR_MACRO_HELDPOLL_OPT_500"] = "500 ms (Blizzard default, recommended)" -- MT
L["GEMS_CVAR_MACRO_HELDPOLL_OPT_1000"] = "1000 ms (relaxed)" -- MT
L["GEMS_CVAR_MACRO_HELDPOLL_OPT_2000"] = "2000 ms (very relaxed)" -- MT
L["GEMS_CVAR_MACRO_HELDPOLL_DESCLONG"] =
    "Controls how often the WoW engine retries casting a held-key spell after a failed cast attempt -- the spell-error poll interval in milliseconds. Default 500 ms means the engine polls roughly twice per second; lower values poll faster (more responsive when the cast becomes available) but consume slightly more client CPU. Higher values reduce polling overhead at the cost of a brief delay before the spell actually fires once it becomes castable. The Blizzard engine clamps any chosen value to the 100-10000 ms range. NOTE: Blizzard documents this as Internal-only -- advanced users only. Changing it rarely helps in practice and may cause unexpected interactions with other addons that rely on the default polling cadence. EMS recommends staying at 500 (Blizzard default) unless you have a specific reason to tune it." -- MT

-- L372 G.3b second wave -- options + descLong for 3 numeric-range cvars (MT placeholders, awaiting native review)
L["GEMS_CVAR_NAMEPLATES_MAXDIST_OPT_20"] = "20 yards (close)" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXDIST_OPT_41"] = "41 yards (Classic)" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXDIST_OPT_60"] = "60 yards (raid/M+)" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXDIST_OPT_80"] = "80 yards (long range)" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXDIST_OPT_100"] = "100 yards (max)" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXDIST_DESCLONG"] =
    "Sets how far away enemy nameplates stay visible, in yards. 20 keeps the screen uncluttered in solo overworld content but loses visibility on ranged threats in groups. 60 is the modern raid and M+ sweet spot -- you see every relevant enemy without the screen drowning in plates. 80-100 maxes out the range for ranged DPS who want to spot casters at extreme distance, at the cost of more screen noise. 41 is the legacy Classic cap, harmless on Retail but rarely the right choice." -- MT

L["GEMS_CVAR_FPS_MAXFPS_OPT_0"] = "0 (uncapped)" -- MT
L["GEMS_CVAR_FPS_MAXFPS_OPT_60"] = "60 (60Hz monitor)" -- MT
L["GEMS_CVAR_FPS_MAXFPS_OPT_120"] = "120 (120Hz monitor)" -- MT
L["GEMS_CVAR_FPS_MAXFPS_OPT_144"] = "144 (144Hz monitor)" -- MT
L["GEMS_CVAR_FPS_MAXFPS_OPT_240"] = "240 (240Hz monitor)" -- MT
L["GEMS_CVAR_FPS_MAXFPS_DESCLONG"] =
    "Caps your in-game frame rate when the window is focused. 0 (uncapped) is fine on high-end hardware but causes coil whine and runs the GPU hot. Matching your monitor's refresh rate (60, 120, 144, or 240) gives smooth scrolling and saves power without any visible loss. Set lower than your refresh rate only if you're hitting thermal limits or want quieter fans." -- MT

L["GEMS_CVAR_MACRO_SPELLQUEUE_OPT_0"] = "0 ms (no queue)" -- MT
L["GEMS_CVAR_MACRO_SPELLQUEUE_OPT_100"] = "100 ms (Retail default)" -- MT
L["GEMS_CVAR_MACRO_SPELLQUEUE_OPT_200"] = "200 ms (relaxed)" -- MT
L["GEMS_CVAR_MACRO_SPELLQUEUE_OPT_400"] = "400 ms (max)" -- MT
L["GEMS_CVAR_MACRO_SPELLQUEUE_DESCLONG"] =
    "The time window in milliseconds after a global cooldown finishes during which a queued spell fires on its own. EMS needs 400 (the engine maximum) so macro sequence steps don't drop when GCDs finish a tick later than expected. Lower values (0, 100, 200) work for hand-cast play where you time inputs precisely, but they cause EMS sequences to skip clicks on variable latency. Set this to 400 for any EMS work." -- MT

-- L372 G.3b third wave -- options + descLong for 3 tiered-quality cvars (MT placeholders, awaiting native review)
L["GEMS_CVAR_VISUAL_SHADOWS_OPT_0"] = "Low" -- MT
L["GEMS_CVAR_VISUAL_SHADOWS_OPT_1"] = "Fair" -- MT
L["GEMS_CVAR_VISUAL_SHADOWS_OPT_2"] = "Good" -- MT
L["GEMS_CVAR_VISUAL_SHADOWS_OPT_3"] = "High" -- MT
L["GEMS_CVAR_VISUAL_SHADOWS_OPT_4"] = "Ultra" -- MT
L["GEMS_CVAR_VISUAL_SHADOWS_DESCLONG"] =
    "Sets the resolution and depth of shadow maps under units, trees, and structures. Low and Fair save GPU memory and frame time, which helps on integrated graphics or a laptop on battery. Medium and High sit in the middle -- soft shadow edges and reasonable draw distance without dropping frames on mid-range cards. Ultra and Ultra High raise the shadow-map resolution and cascade depth for pristine screenshots, at a cost of 5-15 FPS on most cards for marginal in-motion gain. The default is High." -- MT

L["GEMS_CVAR_FPS_PARTICLES_OPT_0"] = "0 (Off)" -- MT
L["GEMS_CVAR_FPS_PARTICLES_OPT_25"] = "25 (Low)" -- MT
L["GEMS_CVAR_FPS_PARTICLES_OPT_50"] = "50 (Medium)" -- MT
L["GEMS_CVAR_FPS_PARTICLES_OPT_75"] = "75 (High)" -- MT
L["GEMS_CVAR_FPS_PARTICLES_OPT_100"] = "100 (Full)" -- MT
L["GEMS_CVAR_FPS_PARTICLES_DESCLONG"] =
    "Controls how many spell and environmental particle effects the game draws. Disabled removes them completely -- the biggest GPU saving, but it also strips some combat visual cues, so you can miss effects firing around you. Low through High trade detail for frame rate; Ultra keeps every spark and flame, which looks best solo but can bury the ground effects you need to dodge in 20-player raids and busy M+ pulls. The Blizzard default is High." -- MT

L["GEMS_CVAR_VISUAL_TEXRES_OPT_0"] = "Low" -- MT
L["GEMS_CVAR_VISUAL_TEXRES_OPT_1"] = "Fair" -- MT
L["GEMS_CVAR_VISUAL_TEXRES_OPT_2"] = "High" -- MT
L["GEMS_CVAR_VISUAL_TEXRES_OPT_3"] = "Ultra" -- MT
L["GEMS_CVAR_VISUAL_TEXRES_DESCLONG"] =
    "Sets the resolution of in-game texture maps for terrain, buildings, armour, and weapons. Low and Fair compress textures heavily to save VRAM, which gives older or low-VRAM cards a usable game but leaves armour and walls looking soft. High strikes the modern balance: textures sharpen at typical viewing distances without filling VRAM on a 4-6 GB card. Ultra loads full-resolution mip levels, which pushes total texture memory past 8 GB during raid bosses and pulls in stutter for anything below that VRAM line." -- MT

-- L372 G.3b fourth wave -- options + descLong for 14 floatingCombatText 0/1 toggle cvars (MT placeholders, awaiting native review)
L["GEMS_CVAR_FCT_DAMAGE_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_FCT_DAMAGE_OPT_1"] = "On" -- MT
L["GEMS_CVAR_FCT_DAMAGE_DESCLONG"] =
    "Shows the damage numbers that float up from enemies you hit with spells and abilities. Recommended on (1) -- this is the headline DPS feedback most players rely on to read combat tempo. Off (0) hides every damage number and leaves only debuff/buff feedback." -- MT

L["GEMS_CVAR_FCT_AUTOS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_FCT_AUTOS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_FCT_AUTOS_DESCLONG"] =
    "Shows damage numbers for every auto-attack swing, not just abilities. Recommended on (1) for melee specs where auto damage is a noticeable share of total damage -- you can read auto cadence visually. Off (0) hides the auto trickle and only shows ability hits, which cleans the screen for caster specs that don't auto-attack much." -- MT

L["GEMS_CVAR_FCT_HEALING_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_FCT_HEALING_OPT_1"] = "On" -- MT
L["GEMS_CVAR_FCT_HEALING_DESCLONG"] =
    "Shows healing numbers that float up when you or allies receive healing in combat. Recommended on (1) -- healers read team health recovery from these numbers, and DPS see when they're being topped off. Off (0) hides all healing feedback in combat." -- MT

L["GEMS_CVAR_FCT_ABSSELF_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_FCT_ABSSELF_OPT_1"] = "On" -- MT
L["GEMS_CVAR_FCT_ABSSELF_DESCLONG"] =
    "Shows absorb numbers when your own shields (Power Word: Shield, Ice Barrier, similar) soak incoming damage. Recommended on (1) -- you can see how much your defensive cooldowns are mitigating versus the boss's hit size. Off (0) hides the absorb feedback even though the shield still works." -- MT

L["GEMS_CVAR_FCT_ABSTARGET_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_FCT_ABSTARGET_OPT_1"] = "On" -- MT
L["GEMS_CVAR_FCT_ABSTARGET_DESCLONG"] =
    "Shows absorb numbers when your shields soak damage on a friendly target you're shielding. Recommended on (1) for healers and tank-shielding specs (Disc Priest, Brewmaster) who need to see if their bubbles are landing. Off (0) is fine for DPS who do not cast absorbs." -- MT

L["GEMS_CVAR_FCT_PERIODIC_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_FCT_PERIODIC_OPT_1"] = "On" -- MT
L["GEMS_CVAR_FCT_PERIODIC_DESCLONG"] =
    "Shows damage/healing tick numbers for periodic effects (DoTs, HoTs) from the combat log. Recommended on (1) -- visible DoT ticks help you confirm bleeds and DoTs are still ticking on the target. Off (0) hides every tick but the spell is still working in the background." -- MT

L["GEMS_CVAR_FCT_DODGEMISS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_FCT_DODGEMISS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_FCT_DODGEMISS_DESCLONG"] =
    "Shows MISS / DODGE / PARRY markers when your attacks fail to land. Recommended on (1) -- you can see at a glance whether you're hitting from the wrong angle or whether the boss is parrying everything. Off (0) hides the miss feedback even though the attack still misses." -- MT

L["GEMS_CVAR_FCT_LOWRES_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_FCT_LOWRES_OPT_1"] = "On" -- MT
L["GEMS_CVAR_FCT_LOWRES_DESCLONG"] =
    "Shows the floating warning when your health or resource pool drops below the danger threshold. Recommended on (1) -- this is your last-second visual cue to pop a defensive or healing potion before you die. Off (0) hides the warning and you rely on bar UI alone." -- MT

L["GEMS_CVAR_FCT_PETMELEE_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_FCT_PETMELEE_OPT_1"] = "On" -- MT
L["GEMS_CVAR_FCT_PETMELEE_DESCLONG"] =
    "Shows damage numbers for your pet's auto-attacks. Recommended on (1) for Hunters, Warlocks, and Unholy DKs where pet damage is a noticeable share of the meter. Off (0) is fine for specs without a permanent pet, where the toggle does nothing anyway." -- MT

L["GEMS_CVAR_FCT_PETSPELL_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_FCT_PETSPELL_OPT_1"] = "On" -- MT
L["GEMS_CVAR_FCT_PETSPELL_DESCLONG"] =
    "Shows damage numbers for your pet's ability casts (Kill Command, Felhunter Spell Lock, etc.). Recommended on (1) for any pet-spec where the pet's ability output is part of the rotation. Off (0) keeps the pet's contribution invisible in the visual stream." -- MT

L["GEMS_CVAR_FCT_REACTIVES_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_FCT_REACTIVES_OPT_1"] = "On" -- MT
L["GEMS_CVAR_FCT_REACTIVES_DESCLONG"] =
    "Shows the floating notification when a reactive ability becomes usable (Overpower after dodge, Riposte after parry, Counterstrike). Recommended on (1) -- the popup is how you know a procced ability is available before it falls off. Off (0) hides the proc indicator and you watch the bar instead." -- MT

-- L372 G.3b fifth wave -- options + descLong for 15 raid-cluster 0/1 toggle cvars (MT placeholders, awaiting native review)
L["GEMS_CVAR_RAIDING_AGGRO_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_AGGRO_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_AGGRO_DESCLONG"] =
    "Highlights raid frame portraits red when a unit pulls aggro from the boss. Recommended on (1) -- healers and off-tanks read aggro at a glance from this colour cue. Off (0) hides the red flash even when a squishy is about to die from boss attention." -- MT

L["GEMS_CVAR_RAIDING_RDEBUFFS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_RDEBUFFS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_RDEBUFFS_DESCLONG"] =
    "Shows debuff icons on raid frame portraits so you can see who needs cleansing. Recommended on (1) -- healers and dispellers track who has bleeds, magic debuffs, or curses without needing a separate addon. Off (0) hides all debuff icons and you watch the chat log instead." -- MT

L["GEMS_CVAR_RAIDING_HEALPRED_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_HEALPRED_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_HEALPRED_DESCLONG"] =
    "Shows an incoming-heal overlay on raid frame health bars when an ally has cast a heal but it has not landed yet. Recommended on (1) for healers running multiple casters together -- you can see if another healer's heal is already inbound and avoid overhealing. Off (0) hides the prediction and you rely on call-outs." -- MT

L["GEMS_CVAR_RAIDING_POWERBARS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_POWERBARS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_POWERBARS_DESCLONG"] =
    "Shows mana, energy, rage, or focus bars under raid frame portraits. Recommended off (0) by default -- reclaims vertical space on every raid frame which matters in 20-40 player groups. On (1) is useful for healers (mana visibility on other healers) and for tanks (rage visibility on co-tank)." -- MT

L["GEMS_CVAR_RAIDING_RCLASSCOLOR_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_RCLASSCOLOR_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_RCLASSCOLOR_DESCLONG"] =
    "Colours raid frame health bars by class colour (Mage blue, Warrior brown, etc.) instead of green-to-red health gradient. Recommended on (1) -- you can identify who is who at a glance, especially in mixed groups. Off (0) uses the threat-level gradient instead, which some players prefer for at-a-glance health reading." -- MT

L["GEMS_CVAR_RAIDING_DISPONLY_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_DISPONLY_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_DISPONLY_DESCLONG"] =
    "Filters raid frame debuff icons so only debuffs your class can dispel are shown. Recommended off (0) by default -- shows every debuff regardless of dispel kit, useful for understanding what's happening across the raid. On (1) for dispelling classes (Priest/Druid/Shaman/Paladin/Monk healers, Mage Spellsteal) cuts visual noise to only actionable debuffs." -- MT

L["GEMS_CVAR_RAIDING_ROLEDEBUFF_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_ROLEDEBUFF_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_ROLEDEBUFF_DESCLONG"] =
    "Renders certain role-specific debuff icons (boss mechanics, tank busters, healer-action-required debuffs) larger than normal so they stand out. Recommended on (1) -- the size difference makes major mechanics impossible to miss versus background noise. Off (0) renders every debuff at uniform size." -- MT

L["GEMS_CVAR_RAIDING_BIGDEF_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_BIGDEF_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_BIGDEF_DESCLONG"] =
    "Centres large defensive-cooldown icons on raid frame portraits when a tank or DPS is using a major defensive (Shield Wall, Icebound Fortitude, etc.). Recommended on (1) for healers -- you can see when the tank already mitigated incoming damage and adjust healing priority. Off (0) hides the defensive indicator entirely." -- MT

L["GEMS_CVAR_RAIDING_TIMELINE_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_TIMELINE_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_TIMELINE_DESCLONG"] =
    "Shows the in-game encounter timeline UI that lists upcoming boss abilities. Recommended on (1) -- the timeline helps new raiders learn fight sequences without external addons. Off (0) hides the timeline; you rely on DBM, BigWigs, or voice calls instead." -- MT

L["GEMS_CVAR_RAIDING_TIMEROLE_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_TIMEROLE_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_TIMEROLE_DESCLONG"] =
    "Filters the encounter timeline to show only abilities that affect your role. Recommended on (1) -- DPS players don't need to see healer-specific timeline notes and vice versa. Off (0) shows the full timeline including notes targeted at other roles." -- MT

L["GEMS_CVAR_RAIDING_WARNINGS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_WARNINGS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_WARNINGS_DESCLONG"] =
    "Shows large screen warnings for major boss mechanics (Targeted-by-Beam, Move-Away, etc.). Recommended on (1) for raiders without DBM or BigWigs -- the in-engine warning is the only call-out you'll get. Off (0) hides the warnings; useful if you use addons that fire competing warnings." -- MT

L["GEMS_CVAR_RAIDING_WARNHIDE_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_WARNHIDE_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_WARNHIDE_DESCLONG"] =
    "Filters encounter warnings to show only mechanics specifically targeting you. Recommended off (0) by default -- shows every encounter warning regardless of target, important for healers tracking group-wide mechanics. On (1) cuts visual noise on mechanics that don't require your action." -- MT

L["GEMS_CVAR_RAIDING_THREATNUM_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_THREATNUM_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_THREATNUM_DESCLONG"] =
    "Shows numeric threat percentage on target frame instead of just the threat colour band. Recommended on (1) for tanks -- you can read exact threat lead over the second-highest player and plan taunts. Off (0) shows the colour band only (green / yellow / orange / red)." -- MT

L["GEMS_CVAR_RAIDING_THREATSOUND_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_THREATSOUND_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_THREATSOUND_DESCLONG"] =
    "Plays an audio cue when you pull or lose threat. Recommended on (1) for tanks who pay attention to ears more than eyes -- the sound is faster than reading the bar colour. Off (0) makes threat purely visual, which matters if you raid with VoIP on speakers." -- MT

L["GEMS_CVAR_RAIDING_THREATTEXT_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_THREATTEXT_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_THREATTEXT_DESCLONG"] =
    "Shows a floating PULLED THREAT text in the screen middle when you pull aggro you shouldn't have. Recommended on (1) for DPS -- the warning is your last-second cue to drop threat or stop casting. Off (0) keeps the in-engine threat warnings purely on the unit frame." -- MT

-- L372 G.3b sixth wave -- options + descLong for 14 combat_targeting 0/1 toggle cvars (MT placeholders, awaiting native review)
L["GEMS_CVAR_COMBAT_SOFTFORCE_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBAT_SOFTFORCE_OPT_1"] = "On" -- MT
L["GEMS_CVAR_COMBAT_SOFTFORCE_DESCLONG"] =
    "Forces soft-targeting on units even when a hard target is already locked. Recommended on (1) -- this is how the modern WoW soft-target system smoothly hands off between manually picked targets and contextual soft-targets. Off (0) hides the soft-target indicator whenever a hard target is set, which is the legacy pre-Dragonflight behaviour." -- MT

L["GEMS_CVAR_COMBAT_SOFTFRIEND_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBAT_SOFTFRIEND_OPT_1"] = "Gamepad only" -- MT
L["GEMS_CVAR_COMBAT_SOFTFRIEND_DESCLONG"] =
    "Sets the soft-target highlight for friendly units -- the ghosted unit frame that appears when you face a player or NPC ally. Off (the default, and the EMS recommendation) suppresses it, which most healers prefer because they pick frames directly. Gamepad only enables it for controller binds. Mouse and keyboard only restricts it to KBM. Always shows it for both input modes. Healers and tanks who use click-targeting tend to leave this off so the soft-target overlay does not interfere with mouse picks." -- MT

L["GEMS_CVAR_COMBAT_TABNEW_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBAT_TABNEW_OPT_1"] = "On" -- MT
L["GEMS_CVAR_COMBAT_TABNEW_DESCLONG"] =
    "Uses the modern target-nearest algorithm (introduced in Dragonflight) instead of the legacy alphabetical-by-name tab-target order. Recommended on (1) -- the modern algorithm picks based on screen position, which is what 99% of players actually want when they hit TAB. Off (0) reverts to the legacy algorithm which can feel random." -- MT

L["GEMS_CVAR_COMBAT_COMBATLOCK_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBAT_COMBATLOCK_OPT_1"] = "On" -- MT
L["GEMS_CVAR_COMBAT_COMBATLOCK_DESCLONG"] =
    "Locks tab-target priority to your current target's combat-engagement set while you are in combat. Recommended on (1) -- prevents accidentally tabbing onto a non-combat NPC or summon when you're mid-pull. Off (0) lets TAB cycle through any unit in range regardless of combat state." -- MT

L["GEMS_CVAR_COMBAT_LOCKRELAX_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBAT_LOCKRELAX_OPT_1"] = "On" -- MT
L["GEMS_CVAR_COMBAT_LOCKRELAX_DESCLONG"] =
    "Allows tab-target priority lock to relax when no valid combat target remains nearby (e.g. last enemy died, you stepped out of combat). Recommended on (1) -- the relaxation prevents getting stuck with no tab-targetable unit after a pull ends. Off (0) keeps the lock active until combat explicitly ends, which can leave you without a tab target if combat is still technically active." -- MT

L["GEMS_CVAR_COMBAT_PVPPRIO_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBAT_PVPPRIO_OPT_1"] = "On" -- MT
L["GEMS_CVAR_COMBAT_PVPPRIO_DESCLONG"] =
    "Treats hostile players as higher priority than NPCs when picking tab-targets in PvP zones. Recommended on (1) for any open-world PvP play -- you want to tab onto the human threatening you, not the wolf next to them. Off (0) treats players and NPCs at equal priority, which is fine for purely PvE play." -- MT

L["GEMS_CVAR_COMBAT_ATTACKER_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBAT_ATTACKER_OPT_1"] = "On" -- MT
L["GEMS_CVAR_COMBAT_ATTACKER_DESCLONG"] =
    "Auto-targets the enemy that just attacked you if you have no current target. Recommended on (1) for casters and ranged classes -- the auto-target gives you something to retaliate against without losing a global cooldown to manual targeting. Off (0) is for players who want full manual control even in unexpected combat." -- MT

L["GEMS_CVAR_COMBAT_AUTOENEMY_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBAT_AUTOENEMY_OPT_1"] = "On" -- MT
L["GEMS_CVAR_COMBAT_AUTOENEMY_DESCLONG"] =
    "Auto-targets the nearest enemy when you start attacking with no target selected. Recommended on (1) -- the auto-pick is the fastest way to begin a melee engagement when you're walking into a pull. Off (0) means autoattack does nothing without a manual target first." -- MT

L["GEMS_CVAR_COMBAT_DESELECT_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBAT_DESELECT_OPT_1"] = "On" -- MT
L["GEMS_CVAR_COMBAT_DESELECT_DESCLONG"] =
    "Drops your current target when you click in empty space. Recommended off (0) by default -- accidental click-drops in the middle of a fight are a common cause of losing a kick-target or boss tab-target. On (1) for players who specifically want click-deselect as a quick way to clear targeting." -- MT

L["GEMS_CVAR_COMBAT_LEFTCLICK_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBAT_LEFTCLICK_OPT_1"] = "On" -- MT
L["GEMS_CVAR_COMBAT_LEFTCLICK_DESCLONG"] =
    "Allows left-click to interact with NPCs (talk, loot, vendor) instead of needing right-click. Recommended on (1) -- the modern Retail default since left-click is faster and matches every other game's interaction model. Off (0) reverts to the legacy right-click-to-interact behaviour." -- MT

L["GEMS_CVAR_COMBAT_HIGHLIGHT_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBAT_HIGHLIGHT_OPT_1"] = "On" -- MT
L["GEMS_CVAR_COMBAT_HIGHLIGHT_DESCLONG"] =
    "Highlights the unit that the AI assist system suggests you target next. Recommended off (0) by default -- the assist suggestions are noisy in busy fights and most experienced players ignore them. On (1) for new players learning a class who want the suggestion overlay as a training aid." -- MT

L["GEMS_CVAR_COMBAT_PROCS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBAT_PROCS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_COMBAT_PROCS_DESCLONG"] =
    "Shows the screen-edge flash overlay when a procced spell becomes castable (Hot Streak, Snipe, Sudden Death, etc.). Recommended on (1) -- the proc flash is how most rotations communicate cast this now to the player. Off (0) leaves you reading the bar manually, which is fine if you use WeakAura-style addons for procs." -- MT

L["GEMS_CVAR_COMBAT_LOC_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBAT_LOC_OPT_1"] = "On" -- MT
L["GEMS_CVAR_COMBAT_LOC_DESCLONG"] =
    "Shows the large screen overlay when you are stunned, silenced, feared, or otherwise loss-of-control'd. Recommended on (1) -- the overlay tells you what specifically is preventing you from acting and how long it lasts. Off (0) hides the overlay; you read your debuff bar instead." -- MT

L["GEMS_CVAR_COMBAT_MOUSEOVER_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBAT_MOUSEOVER_OPT_1"] = "On" -- MT
L["GEMS_CVAR_COMBAT_MOUSEOVER_DESCLONG"] =
    "Lets you cast targeted spells on whatever unit you're hovering over with the cursor, without changing your hard target. No recommended value -- mouseover casting is a healer-style technique that requires custom macros and isn't a universal default. On (1) enables the feature engine-wide; off (0) keeps cursor hover purely cosmetic." -- MT

L["GEMS_CVAR_FCT_ENERGY_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_FCT_ENERGY_OPT_1"] = "On" -- MT
L["GEMS_CVAR_FCT_ENERGY_DESCLONG"] =
    "Shows the floating numbers when you gain energy, rage, focus, or runic power outside of regen ticks (e.g. procced resource refunds). Recommended off (0) -- the gains are already visible on the resource bar, and the floating numbers add screen clutter. Turn on (1) only if you specifically want to track refund procs visually." -- MT

L["GEMS_CVAR_FCT_AURAS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_FCT_AURAS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_FCT_AURAS_DESCLONG"] =
    "Shows the floating notification when buffs or debuffs appear or fall off. Recommended off (0) -- BuffFrame and aura addons already display this with better positioning and grouping. Turn on (1) only if you don't use a buff addon and want the in-engine feedback." -- MT

L["GEMS_CVAR_FCT_HEALERS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_FCT_HEALERS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_FCT_HEALERS_DESCLONG"] =
    "Shows a marker over friendly healers in PvP combat so allies can see who is healing them. Recommended off (0) -- the engine implementation is unreliable on modern Retail and most arena UIs already track healers better through party frames. Turn on (1) if you specifically want the in-engine cue and don't use a focused PvP UI." -- MT

-- L372 G.3b seventh wave -- options + descLong for 12 solo_play 0/1 toggle cvars (MT placeholders, awaiting native review)
L["GEMS_CVAR_SOLO_AUTOLOOT_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_SOLO_AUTOLOOT_OPT_1"] = "On" -- MT
L["GEMS_CVAR_SOLO_AUTOLOOT_DESCLONG"] =
    "When you loot a corpse, every item lands in your bags automatically without the per-slot click prompt. Recommended on (1) -- the manual click prompt was the default 15 years ago and exists today only for nostalgia. Off (0) is for players who specifically want to see each item before accepting it, useful when sharing loot in old-world group play." -- MT

L["GEMS_CVAR_SOLO_LOOTMOUSE_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_SOLO_LOOTMOUSE_OPT_1"] = "On" -- MT
L["GEMS_CVAR_SOLO_LOOTMOUSE_DESCLONG"] =
    "Spawns the loot window directly under your cursor instead of in a fixed screen position. Recommended on (1) -- you don't have to drag the cursor across the screen to right-click items. Off (0) puts the window in a fixed location, easier to predict but slower to click through." -- MT

L["GEMS_CVAR_SOLO_AELOOT_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_SOLO_AELOOT_OPT_1"] = "On" -- MT
L["GEMS_CVAR_SOLO_AELOOT_DESCLONG"] =
    "Disables area-of-effect looting (one Shift-click loots every corpse in range). Recommended off (0) by default -- AE looting is the modern default and saves hundreds of clicks per session in mob-grinding content. Turn on (1) only if you want forced one-corpse-at-a-time looting for nostalgia or for picking through specific item drops." -- MT

L["GEMS_CVAR_SOLO_DISMOUNT_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_SOLO_DISMOUNT_OPT_1"] = "On" -- MT
L["GEMS_CVAR_SOLO_DISMOUNT_DESCLONG"] =
    "Automatically dismounts you when you try to cast a spell or attack while mounted. Recommended on (1) -- the alternative is the cast silently failing because mounted players cannot cast. Off (0) forces you to dismount manually before casting, which is fine for players who treat casting-while-mounted as a mistake worth blocking." -- MT

L["GEMS_CVAR_SOLO_DISMOUNTFLY_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_SOLO_DISMOUNTFLY_OPT_1"] = "On" -- MT
L["GEMS_CVAR_SOLO_DISMOUNTFLY_DESCLONG"] =
    "Automatically dismounts you from flying mounts even when in flight. Recommended off (0) by default -- dismounting at flight altitude drops you several hundred yards and almost always kills you. On (1) for players who fly low and want consistency with the ground-mount auto-dismount behaviour." -- MT

L["GEMS_CVAR_SOLO_TOT_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_SOLO_TOT_OPT_1"] = "On" -- MT
L["GEMS_CVAR_SOLO_TOT_DESCLONG"] =
    "Shows a small target-of-target frame near the main target frame so you can see who your target is targeting. Recommended on (1) for tanks (am I being attacked?) and healers (who is my tank healing?). Off (0) reclaims a small chunk of screen space, fine if you rely on raid frames or addons for the same info." -- MT

L["GEMS_CVAR_SOLO_TCASTBAR_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_SOLO_TCASTBAR_OPT_1"] = "On" -- MT
L["GEMS_CVAR_SOLO_TCASTBAR_DESCLONG"] =
    "Shows a castbar on the target frame for enemies and friendlies that are casting spells. Recommended on (1) -- the castbar tells you what the enemy is about to do and when to interrupt. Off (0) only makes sense for players who rely on dedicated nameplate or boss-mod castbar addons." -- MT

L["GEMS_CVAR_SOLO_QUESTWATCH_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_SOLO_QUESTWATCH_OPT_1"] = "On" -- MT
L["GEMS_CVAR_SOLO_QUESTWATCH_DESCLONG"] =
    "Automatically adds newly accepted quests to the visible quest tracker on the right side of the screen. Recommended on (1) -- accepting a quest implies you want to see how to do it. Off (0) is for players who manage the tracker manually and prefer a clean default state." -- MT

L["GEMS_CVAR_SOLO_QUESTPOI_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_SOLO_QUESTPOI_OPT_1"] = "On" -- MT
L["GEMS_CVAR_SOLO_QUESTPOI_DESCLONG"] =
    "Shows quest objectives as numbered icons on the world map and minimap. Recommended on (1) -- the POI icons are how modern WoW shows you where to go for any active quest. Off (0) reverts to text-only objective lists, useful only for players who specifically want a no-map exploration experience." -- MT

L["GEMS_CVAR_SOLO_PARTYPETS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_SOLO_PARTYPETS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_SOLO_PARTYPETS_DESCLONG"] =
    "Shows party-member pets in your party frame list (separate small bars under each party member). Recommended off (0) by default -- party pet bars clutter the party UI and most players read pet health through nameplates instead. On (1) for healers who explicitly want pet visibility, especially in Hunter-heavy or Warlock-heavy groups where pet damage tanking is part of the strategy." -- MT

L["GEMS_CVAR_SOLO_INTERICON_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_SOLO_INTERICON_OPT_1"] = "On" -- MT
L["GEMS_CVAR_SOLO_INTERICON_DESCLONG"] =
    "Shows the soft-target interact icon (the floating cursor-like glyph) on units you can interact with while in range. Recommended on (1) -- the icon tells you at a glance whether the NPC in front of you is talkable or just decoration. Off (0) hides the icon and you rely on cursor hover to discover interactable units." -- MT

L["GEMS_CVAR_SOLO_AUTOINTER_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_SOLO_AUTOINTER_OPT_1"] = "On" -- MT
L["GEMS_CVAR_SOLO_AUTOINTER_DESCLONG"] =
    "Auto-triggers the interact action on the soft-targeted unit when you walk into interact range. Recommended off (0) by default -- auto-interact is aggressive and triggers any time you walk past an NPC you didn't mean to talk to. On (1) is a controller or streamlined-UI preference for players who use the interact key as a primary input." -- MT

-- L372 G.3b eighth wave -- options + descLong for 17 dungeons + raid-leftover 0/1 toggle cvars (MT placeholders, awaiting native review)
L["GEMS_CVAR_RAIDING_COMBATWARN_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_COMBATWARN_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_COMBATWARN_DESCLONG"] =
    "Master toggle for all engine-level in-combat screen warnings (pull timers, role calls, encounter start). Recommended on (1) -- the master toggle gates every per-feature warning below it. Off (0) suppresses combat warnings engine-wide, useful only if you fully rely on an addon stack for raid feedback." -- MT

L["GEMS_CVAR_DUNGEON_DPSRESET_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_DUNGEON_DPSRESET_OPT_1"] = "On" -- MT
L["GEMS_CVAR_DUNGEON_DPSRESET_DESCLONG"] =
    "Resets the in-engine damage meter when you zone into a new dungeon or raid instance. Recommended on (1) -- the meter should show numbers for this pull, not lifetime totals from previous content. Off (0) keeps a running tally across instances, mostly useful only if you don't use Details or Skada for proper metering." -- MT

L["GEMS_CVAR_DUNGEON_ENTRANCE_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_DUNGEON_ENTRANCE_OPT_1"] = "On" -- MT
L["GEMS_CVAR_DUNGEON_ENTRANCE_DESCLONG"] =
    "Shows dungeon and raid entrance markers on the world map and minimap. Recommended on (1) -- the markers help locate dungeon entrances when running into-instance from outside (M+ pulls, weekly chest visits). Off (0) hides the markers; you navigate by memory or by group leader's coordinates." -- MT

L["GEMS_CVAR_DUNGEON_CLUTTER_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_DUNGEON_CLUTTER_OPT_1"] = "On" -- MT
L["GEMS_CVAR_DUNGEON_CLUTTER_DESCLONG"] =
    "Restricts the unit-clutter visual cleanup (transparent friendly players in dense areas) to inside instances only. Recommended on (1) -- the cleanup helps see boss mechanics in raids without affecting overworld visibility. Off (0) extends the clutter cleanup to overworld content too, which can hide players in capital cities." -- MT

L["GEMS_CVAR_DUNGEON_ENEMYCAST_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_DUNGEON_ENEMYCAST_OPT_1"] = "On" -- MT
L["GEMS_CVAR_DUNGEON_ENEMYCAST_DESCLONG"] =
    "Shows enemy castbars on Arena UI enemy frames. Recommended on (1) for arena PvP -- you need to see enemy casts to interrupt or counter them, and the Arena UI is often the cleanest source of that info. Off (0) hides the castbars; only fine if you use a dedicated PvP enemy-cast addon." -- MT

L["GEMS_CVAR_DUNGEON_LOGFILE_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_DUNGEON_LOGFILE_OPT_1"] = "On" -- MT
L["GEMS_CVAR_DUNGEON_LOGFILE_DESCLONG"] =
    "Appends a timestamp to each combat log file so new logs don't overwrite old ones. Recommended on (1) -- separate files per session are how Warcraft Logs uploaders find each raid night's data. Off (0) reuses one filename and overwrites, useful only if you don't archive combat logs." -- MT

L["GEMS_CVAR_DUNGEON_DIMINISH_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_DUNGEON_DIMINISH_OPT_1"] = "On" -- MT
L["GEMS_CVAR_DUNGEON_DIMINISH_DESCLONG"] =
    "Shows diminishing-returns indicators on enemy nameplates in PvP combat (stun, fear, root, etc.). Recommended on (1) for any PvP play -- you can see whether your next CC will be reduced-duration or completely immune. Off (0) hides the DR icons; you track DRs in your head." -- MT

L["GEMS_CVAR_RAIDING_COMBATLOG_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_COMBATLOG_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_COMBATLOG_DESCLONG"] =
    "Enables high-detail combat logging (per-event metadata, more granular timestamps). Recommended on (1) for any raider running parses through Warcraft Logs -- the advanced log fields are required for accurate parse uploading. Off (0) writes a slimmer log that uploads fail to parse correctly." -- MT

L["GEMS_CVAR_RAIDING_KEEPGRP_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_KEEPGRP_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_KEEPGRP_DESCLONG"] =
    "When sorting raid frames, keeps the original sub-group (Group 1, Group 2) ordering instead of merging across groups. Recommended off (0) by default -- modern role-sort is more useful than group-sort for healing. On (1) for raid leaders who use group composition as a tactical assignment (e.g. group 1 = ranged, group 2 = melee)." -- MT

L["GEMS_CVAR_RAIDING_TANKASSIST_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_TANKASSIST_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_TANKASSIST_DESCLONG"] =
    "Shows the Main Tank and Main Assist callouts visually on raid frames. Recommended on (1) -- the visual marker helps the raid identify who to follow for kill order and who to look at for taunt swaps. Off (0) hides the markers; fine only if your raid doesn't use the MA/MT system." -- MT

L["GEMS_CVAR_RAIDING_FINDSELF_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_FINDSELF_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_FINDSELF_DESCLONG"] =
    "Highlights your own raid frame more strongly than others. Recommended on (1) -- in a 30-person raid with similar-looking frames, you need to know which one is YOU at a glance. Off (0) treats your frame identically to everyone else's, which can cause confusion when self-healing or self-buffing." -- MT

L["GEMS_CVAR_RAIDING_CASTBUFFS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_CASTBUFFS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_CASTBUFFS_DESCLONG"] =
    "Shows buffs you can cast on raid frame portraits (your own Power Word: Shield, Innervate, etc.). Recommended off (0) by default -- the buff icons clutter raid frames and most players track their own cooldowns via the action bar. On (1) for buff-class healers who want visual confirmation of who has their HoT or shield active." -- MT

L["GEMS_CVAR_RAIDING_DISPDEBUFFS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_DISPDEBUFFS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_DISPDEBUFFS_DESCLONG"] =
    "Shows debuffs you can dispel on raid frame portraits (your Mass Dispel, Cure Disease, Decurse, etc.). Recommended on (1) for dispelling specs -- the highlight is how you spot which raid member needs the dispel without scanning the whole frame. Off (0) hides the highlight; you read raw debuff icons instead." -- MT

L["GEMS_CVAR_RAIDING_RAIDSETTINGS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_RAIDSETTINGS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_RAIDSETTINGS_DESCLONG"] =
    "Enables the raid-specific UI profile (alternate raid frame layout, larger nameplates, etc.) when you enter a raid instance. Recommended on (1) -- the raid profile is designed for 20-40 player groups and looks better than the party profile at that scale. Off (0) uses your party profile in raids, fine for players who explicitly want one consistent UI." -- MT

L["GEMS_CVAR_RAIDING_RAIDCLUTTER_OPT_0"] = "0 (none, dev-only)" -- MT
L["GEMS_CVAR_RAIDING_RAIDCLUTTER_OPT_1"] = "1 (minimum, recommended)" -- MT
L["GEMS_CVAR_RAIDING_RAIDCLUTTER_OPT_2"] = "2 (reduced, default)" -- MT
L["GEMS_CVAR_RAIDING_RAIDCLUTTER_OPT_3"] = "3 (performance)" -- MT
L["GEMS_CVAR_RAIDING_RAIDCLUTTER_OPT_4"] = "4 (full)" -- MT
L["GEMS_CVAR_RAIDING_RAIDCLUTTER_DESCLONG"] =
    "启用团队专用图形设置后（EMS 在上方推荐启用），团队副本会使用这一团队专用镜像值，而不是常规的法术视觉密度。EMS 推荐 1，理由与主设置相同：最低密度能在人多的战斗中保持首领机制和地面效果清晰可读。该团队镜像值的暴雪默认值为 2。" -- MT

L["GEMS_CVAR_RAIDING_NOFILTER_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_NOFILTER_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_NOFILTER_DESCLONG"] =
    "Disables the default filtering of buffs and debuffs on the target frame (shows every buff/debuff regardless of source). Recommended off (0) by default -- the filter hides irrelevant buffs from the target frame which keeps it readable. Turn on (1) for tanks and theorycrafters who need full debuff visibility regardless of source." -- MT

L["GEMS_CVAR_RAIDING_MYSPELLS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_MYSPELLS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_MYSPELLS_DESCLONG"] =
    "Makes your own spell effects render more prominently than other players' effects on screen. Recommended on (1) -- you need to see whether your ground effect (Healing Rain, Death and Decay, Consecration) landed where you placed it, distinct from teammates' similar effects. Off (0) renders every player's spell effects at uniform intensity." -- MT

-- L372 G.3b ninth wave -- options + descLong for 2 string-enum cvars (MT placeholders, awaiting native review)
L["GEMS_CVAR_RAIDING_HEALTHTEXT_OPT_NONE"] = "None" -- MT
L["GEMS_CVAR_RAIDING_HEALTHTEXT_OPT_PERC"] = "Percentage" -- MT
L["GEMS_CVAR_RAIDING_HEALTHTEXT_OPT_HEALTH"] = "Health value" -- MT
L["GEMS_CVAR_RAIDING_HEALTHTEXT_OPT_LOSTHEALTH"] = "Lost health" -- MT
L["GEMS_CVAR_RAIDING_HEALTHTEXT_DESCLONG"] =
    "Sets what text appears on raid frame health bars. None (the default) keeps bars clean and lets you focus on the bar fill alone. Percentage shows XX% which is the most readable at-a-glance health gauge. Health shows the raw health value (e.g. 347000 / 480000), useful for tanks tracking specific HP thresholds for defensive cooldowns. Lost health shows the missing-HP number (e.g. -133000), useful for healers matching incoming heal sizes to actual deficits." -- MT

L["GEMS_CVAR_RAIDING_SORTMODE_OPT_ROLE"] = "By role (tank / heal / DPS)" -- MT
L["GEMS_CVAR_RAIDING_SORTMODE_OPT_GROUP"] = "By group number" -- MT
L["GEMS_CVAR_RAIDING_SORTMODE_DESCLONG"] =
    "Sets the sort order for raid frames. Role (the default) groups tanks at the top, then healers, then DPS -- matches the priority-of-attention order most players want. Group keeps Group 1 / Group 2 / Group N groupings intact, useful for raid leaders who use group composition as tactical assignment." -- MT

L["GEMS_CVAR_FIX_ALL_BUSY"] = "GEMS:正在修复 %d 个 CVar..." -- MT
L["GEMS_CVAR_FIX_ALL_DONE"] = "GEMS:已修复 %d 个 CVar。" -- MT
L["GEMS_CVAR_FIX_ALL_DONE_PARTIAL"] = "GEMS: Fixed %d of %d CVars (%d pinned or combat-locked)." -- MT
L["GEMS_CVAR_RESET_DEFAULTS"] = "全部重置为暴雪默认" -- MT
-- TODO: gloss SQW (MT review)
L["GEMS_CVAR_RESET_DEFAULTS_DESC"] =
    "将每个推荐 CVar 重置为暴雪发货的默认值。固定的 CVar 和 SQW 管理的条目会被跳过。每行都有撤销按钮以恢复。登录自动修复选择启用也会被清除 -- 重置后如果想让 EMS 再次管理它们,请重新切换。" -- MT
-- TODO: gloss SQW (MT review)
L["GEMS_CVAR_RESET_DEFAULTS_CONFIRM"] =
    "将 %d 个 CVar 重置为暴雪默认值?固定的 CVar 和 SQW 管理的条目会被跳过。你可以单独撤销每个被恢复的 CVar。" -- MT
L["GEMS_CVAR_RESET_DEFAULTS_BUSY"] = "GEMS:正在将 %d 个 CVar 重置为暴雪默认值..." -- MT
L["GEMS_CVAR_RESET_DEFAULTS_DONE"] =
    "GEMS:已重置 %d 个 CVar。每行都有撤销。登录自动修复选择启用已清除。" -- MT
L["GEMS_CVAR_RESET_DEFAULTS_DONE_PARTIAL"] =
    "GEMS: Reset %d of %d CVars (%d pinned or combat-locked). Each row has Undo. Auto-fix-on-login opt-ins were cleared." -- MT
L["GEMS_CVAR_ONBOARDING_BODY"] =
    "EMS 扫描 %d 个游戏设置(CVar)并显示哪些与推荐值匹配。绿点表示匹配。红色是关键不匹配。黄色是不理想。\n\n点击任一行的修复以应用推荐,或使用顶部按钮一次修复多个。固定我的选择告诉 EMS 不要更改某个 CVar,适用于你想保留自己值的情况。" -- MT

-- CVar Section Headers
L["GEMS_CVAR_SECTION_MACRO"] = "宏序列" -- MT
L["GEMS_CVAR_SECTION_COMBAT"] = "战斗与目标选择" -- MT
L["GEMS_CVAR_SECTION_NAMEPLATES"] = "姓名板" -- MT
L["GEMS_CVAR_SECTION_RAIDING"] = "团队副本" -- MT
L["GEMS_CVAR_SECTION_DUNGEON"] = "地下城与史诗钥石" -- MT
L["GEMS_CVAR_SECTION_SOLO"] = "单人玩法与开放世界" -- MT
L["GEMS_CVAR_SECTION_UI"] = "UI 与生活质量" -- MT
L["GEMS_CVAR_SECTION_FPS"] = "FPS 与性能" -- MT
L["GEMS_CVAR_SECTION_VISUAL"] = "视觉质量" -- MT
L["GEMS_CVAR_SECTION_SOUND"] = "声音" -- MT
L["GEMS_CVAR_SECTION_FCT"] = "浮动战斗文字" -- MT
L["GEMS_CVAR_SECTION_ACCESS"] = "无障碍" -- MT
L["GEMS_CVAR_SECTION_DRAGON"] = "驭龙术与高级飞行" -- MT

-- CVar Section: Macro Sequencing
L["GEMS_CVAR_MACRO_KEYDOWN"] = "按下时施法" -- MT
L["GEMS_CVAR_MACRO_KEYDOWN_DESC"] =
    "在按键按下时触发能力,而非释放时。如果为 0,每次宏按键都会有 50-100ms 额外延迟。序列化的必备项。" -- MT
L["GEMS_CVAR_MACRO_KEYHELD"] = "按住施法" -- MT
L["GEMS_CVAR_MACRO_KEYHELD_DESC"] =
    "按住自动重复能力。仅在原生暴雪动作按钮上有效,插件创建的按钮无效。激活时由保持模式管理此设置。基于偏好 -- 没有任何方向的推荐。" -- MT
L["GEMS_CVAR_MACRO_SPELLQUEUE"] = "法术队列窗口" -- MT
L["GEMS_CVAR_MACRO_SPELLQUEUE_DESC"] =
    "GCD 结束前可以排队下一个法术的毫秒数。400ms 对大多数玩家最佳。" -- MT
L["GEMS_CVAR_MACRO_LOCKBARS"] = "锁定动作条" -- MT
L["GEMS_CVAR_MACRO_LOCKBARS_DESC"] = "防止战斗中意外将宏存根从动作条上拖走。" -- MT
L["GEMS_CVAR_MACRO_MULTIBARS"] = "多重动作条" -- MT
L["GEMS_CVAR_MACRO_MULTIBARS_DESC"] =
    "选择启用哪些额外动作条(0=无,15=全部)。条数越多 = 宏存根空间越多。" -- MT
L["GEMS_CVAR_MACRO_AUTOPUSH"] = "自动推送法术" -- MT
L["GEMS_CVAR_MACRO_AUTOPUSH_DESC"] =
    "自动将新法术放置到条上。推荐关闭 -- 升级时的新法术会将宏存根挤出条。" -- MT
L["GEMS_CVAR_MACRO_SELFCAST"] = "自动自我施法" -- MT
L["GEMS_CVAR_MACRO_SELFCAST_DESC"] =
    "无有效目标时自动对自己施放有益法术。对带自我治疗的宏步骤很重要。" -- MT
L["GEMS_CVAR_MACRO_AUTOSTAND"] = "自动站立" -- MT
L["GEMS_CVAR_MACRO_AUTOSTAND_DESC"] = "施法时自动站立。否则坐下时宏序列会静默失败。" -- MT
L["GEMS_CVAR_MACRO_AUTOUNSHIFT"] = "自动解除变形" -- MT
L["GEMS_CVAR_MACRO_AUTOUNSHIFT_DESC"] =
    "施放不兼容法术时自动离开变形/潜行。否则德鲁伊/盗贼宏步骤会静默失败。" -- MT
L["GEMS_CVAR_MACRO_STOPATTACK"] = "切换时停止攻击" -- MT
L["GEMS_CVAR_MACRO_STOPATTACK_DESC"] =
    "切换目标时保持自动攻击。如果为 1,序列中切换目标会停止近战自动攻击。" -- MT
L["GEMS_CVAR_MACRO_ICONRATE"] = "图标更新速率" -- MT
L["GEMS_CVAR_MACRO_ICONRATE_DESC"] =
    "动作条图标多久刷新一次(秒)。0.05 = 20 次/秒,比默认 0.1 更平滑。" -- MT
L["GEMS_CVAR_MACRO_CDCOUNT"] = "冷却倒数" -- MT
L["GEMS_CVAR_MACRO_CDCOUNT_DESC"] =
    "在动作按钮上显示数字冷却计时器。对查看序列按钮的精确剩余冷却至关重要。" -- MT
L["GEMS_CVAR_MACRO_SECTOGGLE"] = "安全能力切换" -- MT
L["GEMS_CVAR_MACRO_SECTOGGLE_DESC"] = "防止双击切换关闭能力。防止快速按键停用切换能力。" -- MT
L["GEMS_CVAR_MACRO_EMPTAP"] = "强化点击控制" -- MT
L["GEMS_CVAR_MACRO_EMPTAP_DESC"] =
    "强化法术的点击-点击对按住-释放(唤魔师)。按住-释放与序列配合更好。" -- MT
L["GEMS_CVAR_MACRO_EMPHOLD"] = "强化按住阶段" -- MT
L["GEMS_CVAR_MACRO_EMPHOLD_DESC"] =
    "自动释放前所需的第一个强化阶段百分比 [0.0-1.0]。唤魔师专属。" -- MT
L["GEMS_CVAR_MACRO_HELDPOLL"] = "按住法术轮询时间" -- MT
L["GEMS_CVAR_MACRO_HELDPOLL_DESC"] =
    "按住法术施法失败时的重试间隔毫秒数。越低 = 重试越快,响应越灵敏。" -- MT
L["GEMS_CVAR_MACRO_PRECAST"] = "预先施法" -- MT
L["GEMS_CVAR_MACRO_PRECAST_DESC"] = "在法术实际触发前略早显示施法动画。未公开的暴雪功能。" -- MT

-- CVar Section: Combat & Targeting
L["GEMS_CVAR_COMBAT_SOFTENEMY"] = "软目标敌人" -- MT
L["GEMS_CVAR_COMBAT_SOFTENEMY_DESC"] =
    "敌人软目标何时激活。0=关,1=手柄,2=键鼠,3=始终。推荐 3 自动获取。" -- MT
L["GEMS_CVAR_COMBAT_SOFTARC"] = "软目标弧度" -- MT
L["GEMS_CVAR_COMBAT_SOFTARC_DESC"] =
    "敌人软目标的方向约束。0=必须直接面对,1=前方弧,2=任意方向。" -- MT
L["GEMS_CVAR_COMBAT_SOFTRANGE"] = "软目标范围" -- MT
L["GEMS_CVAR_COMBAT_SOFTRANGE_DESC"] =
    "敌人软目标检测的最大范围(码)。45 码涵盖大部分远程能力。" -- MT
L["GEMS_CVAR_COMBAT_SOFTFORCE"] = "软目标强制" -- MT
L["GEMS_CVAR_COMBAT_SOFTFORCE_DESC"] = "自动锁定软目标。否则软目标显示目标但法术对空触发。" -- MT
L["GEMS_CVAR_COMBAT_SOFTFRIEND"] = "软目标友方" -- MT
L["GEMS_CVAR_COMBAT_SOFTFRIEND_DESC"] =
    "友方的软目标。0=关。治疗者可能想要 3(始终)。DPS 应保持 0。" -- MT
L["GEMS_CVAR_COMBAT_SOFTLOCKED"] = "锁定时软目标" -- MT
L["GEMS_CVAR_COMBAT_SOFTLOCKED_DESC"] = "有硬锁定目标时允许软目标。2=始终允许软目标预览。" -- MT
L["GEMS_CVAR_COMBAT_SOFTMATCH"] = "软目标匹配锁定" -- MT
L["GEMS_CVAR_COMBAT_SOFTMATCH_DESC"] =
    "软目标匹配锁定目标。保持软目标指示器与你的实际目标同步。" -- MT
L["GEMS_CVAR_COMBAT_TABNEW"] = "新 Tab 目标选择" -- MT
L["GEMS_CVAR_COMBAT_TABNEW_DESC"] =
    "使用现代(7.2+)Tab 目标选择算法。优先选择面前和战斗中的敌人。" -- MT
L["GEMS_CVAR_COMBAT_COMBATLOCK"] = "战斗目标锁定" -- MT
L["GEMS_CVAR_COMBAT_COMBATLOCK_DESC"] =
    "将 Tab 目标锁定到战斗中的敌人。防止跳到尚未拉怪的远处怪物。" -- MT
L["GEMS_CVAR_COMBAT_LOCKRELAX"] = "锁定放松" -- MT
L["GEMS_CVAR_COMBAT_LOCKRELAX_DESC"] = "无战斗中目标可用时智能放松战斗锁。" -- MT
L["GEMS_CVAR_COMBAT_PVPPRIO"] = "PvP 目标优先级" -- MT
L["GEMS_CVAR_COMBAT_PVPPRIO_DESC"] = "在 PvP 中,优先选择玩家和重要 PvP 目标。1=玩家优先。" -- MT
L["GEMS_CVAR_COMBAT_ATTACKER"] = "目标攻击者" -- MT
L["GEMS_CVAR_COMBAT_ATTACKER_DESC"] = "自动以攻击你的敌人为目标。怪物有仇恨的单人玩法必备。" -- MT
L["GEMS_CVAR_COMBAT_AUTOENEMY"] = "自动目标敌人" -- MT
L["GEMS_CVAR_COMBAT_AUTOENEMY_DESC"] =
    "无目标时自动以最近的敌人为目标施放攻击法术。确保宏触发。" -- MT
L["GEMS_CVAR_COMBAT_DESELECT"] = "点击取消选择" -- MT
L["GEMS_CVAR_COMBAT_DESELECT_DESC"] =
    "点击地形时清除目标。如果为 1,战斗中点击地面会丢失目标。" -- MT
L["GEMS_CVAR_COMBAT_LEFTCLICK"] = "交互左键点击" -- MT
L["GEMS_CVAR_COMBAT_LEFTCLICK_DESC"] = "左键点击与 NPC 互动。大多数玩家期望的标准行为。" -- MT
L["GEMS_CVAR_COMBAT_HIGHLIGHT"] = "战斗高亮" -- MT
L["GEMS_CVAR_COMBAT_HIGHLIGHT_DESC"] = "下一个施法法术高亮。视觉上与序列追踪冲突。推荐关闭。" -- MT
L["GEMS_CVAR_COMBAT_PROCS"] = "触发覆盖" -- MT
L["GEMS_CVAR_COMBAT_PROCS_DESC"] =
    "显示触发/法术警报覆盖(发光边框)。对查看影响宏优先级的触发很重要。" -- MT
L["GEMS_CVAR_COMBAT_PROCOPACITY"] = "触发覆盖不透明度" -- MT
L["GEMS_CVAR_COMBAT_PROCOPACITY_DESC"] =
    "法术警报覆盖的不透明度。默认 0.65 不错。难以看清时增加到 0.8-1.0。" -- MT
L["GEMS_CVAR_COMBAT_LOC"] = "失控" -- MT
L["GEMS_CVAR_COMBAT_LOC_DESC"] = "被晕眩/沉默时显示失控横幅。帮助理解为何宏序列卡住。" -- MT
L["GEMS_CVAR_COMBAT_MOUSEOVER"] = "鼠标悬停施法" -- MT
L["GEMS_CVAR_COMBAT_MOUSEOVER_DESC"] = "对光标下的单位施法而不更改目标。对治疗者帮助巨大。" -- MT
L["GEMS_CVAR_COMBAT_FRIENDARC"] = "友方软弧" -- MT
L["GEMS_CVAR_COMBAT_FRIENDARC_DESC"] =
    "友方软目标的方向限制。与敌人弧度设置同理。仅在软目标友方开启时有效。" -- MT
L["GEMS_CVAR_COMBAT_FRIENDRANGE"] = "友方软范围" -- MT
L["GEMS_CVAR_COMBAT_FRIENDRANGE_DESC"] = "友方软目标检测的最大范围。45 码涵盖所有治疗法术。" -- MT

-- CVar Section: Nameplates
L["GEMS_CVAR_NAMEPLATES_SHOWALL"] = "显示所有姓名板" -- MT
L["GEMS_CVAR_NAMEPLATES_SHOWALL_DESC"] =
    "显示所有姓名板(敌人、友方 NPC、宠物)。主开关。大多数战斗玩家想要开启。" -- MT
L["GEMS_CVAR_NAMEPLATES_SHOWENEMY"] = "显示敌方姓名板" -- MT
L["GEMS_CVAR_NAMEPLATES_SHOWENEMY_DESC"] = "显示敌方姓名板。任何战斗感知都必须开启。" -- MT
L["GEMS_CVAR_NAMEPLATES_SHOWSELF"] = "显示自身姓名板" -- MT
L["GEMS_CVAR_NAMEPLATES_SHOWSELF_DESC"] =
    "显示个人资源显示(角色下方的生命/法力条)。许多玩家不知道这个存在。" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXDIST"] = "最大距离" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXDIST_DESC"] =
    "最大姓名板渲染距离。60 码是上限和默认。较低值节省 GPU 但失去感知。" -- MT
L["GEMS_CVAR_NAMEPLATES_PLAYERDIST"] = "玩家最大距离" -- MT
L["GEMS_CVAR_NAMEPLATES_PLAYERDIST_DESC"] = "玩家姓名板的最大距离。保持等于 nameplateMaxDistance。" -- MT
L["GEMS_CVAR_NAMEPLATES_MINALPHA"] = "最小不透明度" -- MT
L["GEMS_CVAR_NAMEPLATES_MINALPHA_DESC"] =
    "远处姓名板的最小不透明度。默认 0.6 使远处姓名板难以看清。0.8 更好。" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXALPHA"] = "最大不透明度" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXALPHA_DESC"] =
    "近处姓名板的最大不透明度。1.0 = 完全不透明。无理由降低。" -- MT
L["GEMS_CVAR_NAMEPLATES_MINSCALE"] = "最小缩放" -- MT
L["GEMS_CVAR_NAMEPLATES_MINSCALE_DESC"] =
    "远处姓名板的最小缩放。较低值使远处姓名板太小而难以阅读。" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXSCALE"] = "最大缩放" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXSCALE_DESC"] = "近处姓名板的最大缩放。" -- MT
L["GEMS_CVAR_NAMEPLATES_SELSCALE"] = "选定缩放" -- MT
L["GEMS_CVAR_NAMEPLATES_SELSCALE_DESC"] =
    "你当前目标姓名板的缩放乘数。默认 1.2 使目标视觉上突出。" -- MT
L["GEMS_CVAR_NAMEPLATES_OCCLUDED"] = "遮挡不透明度" -- MT
L["GEMS_CVAR_NAMEPLATES_OCCLUDED_DESC"] =
    "墙后/物体后姓名板的不透明度。默认 0.4 几乎不可见。0.6 保持可读。" -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPH"] = "水平重叠" -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPH_DESC"] = "水平堆叠重叠。较低 = 更分散。0.8 是默认堆叠行为。" -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPV"] = "垂直重叠" -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPV_DESC"] = "垂直堆叠重叠。控制 AoE 包中姓名板如何垂直堆叠。" -- MT
L["GEMS_CVAR_NAMEPLATES_CASTBARS"] = "姓名板施法条" -- MT
L["GEMS_CVAR_NAMEPLATES_CASTBARS_DESC"] = "在姓名板上显示施法条。打断必备。" -- MT
L["GEMS_CVAR_NAMEPLATES_CLASSCOLOR"] = "职业颜色条" -- MT
L["GEMS_CVAR_NAMEPLATES_CLASSCOLOR_DESC"] =
    "按职业为敌方姓名板生命条着色。对 PvP 目标识别很重要。" -- MT
L["GEMS_CVAR_NAMEPLATES_DEBUFFS"] = "友方减益" -- MT
L["GEMS_CVAR_NAMEPLATES_DEBUFFS_DESC"] = "在友方姓名板上显示减益。对治疗者和驱散者有用。" -- MT
L["GEMS_CVAR_NAMEPLATES_MINIONS"] = "敌方仆从" -- MT
L["GEMS_CVAR_NAMEPLATES_MINIONS_DESC"] =
    "显示仆从姓名板。默认关闭以减少混乱。如果仆从生命有意义,在史诗钥石中启用。" -- MT
L["GEMS_CVAR_NAMEPLATES_MINUS"] = "微不足道的敌人" -- MT
L["GEMS_CVAR_NAMEPLATES_MINUS_DESC"] =
    "显示微不足道(减号)敌人的姓名板。开放世界中查看所有怪物时有用。" -- MT
L["GEMS_CVAR_NAMEPLATES_TOTEMS"] = "敌方图腾" -- MT
L["GEMS_CVAR_NAMEPLATES_TOTEMS_DESC"] = "显示敌方图腾姓名板。在 PvP 中很重要 -- 图腾是击杀目标。" -- MT
L["GEMS_CVAR_NAMEPLATES_FRIENDLY"] = "友方玩家" -- MT
L["GEMS_CVAR_NAMEPLATES_FRIENDLY_DESC"] =
    "显示友方玩家姓名板。PvE 中关闭以减少混乱。PvP 中开启以获得感知。" -- MT
L["GEMS_CVAR_NAMEPLATES_AURASCALE"] = "光环图标缩放" -- MT
L["GEMS_CVAR_NAMEPLATES_AURASCALE_DESC"] =
    "姓名板上增益/减益图标的缩放乘数。1.2 使一目了然的 DoT 追踪更容易。" -- MT
L["GEMS_CVAR_NAMEPLATES_NAMEONLY"] = "仅名称友方" -- MT
L["GEMS_CVAR_NAMEPLATES_NAMEONLY_DESC"] =
    "将友方姓名板剥离为仅名称(无生命条)。减少团队中的视觉噪音。" -- MT
L["GEMS_CVAR_NAMEPLATES_ATBASE"] = "底部位置" -- MT
L["GEMS_CVAR_NAMEPLATES_ATBASE_DESC"] = "将非目标姓名板定位在角色底部而非头顶。0=头顶(标准)。" -- MT
L["GEMS_CVAR_NAMEPLATES_OFFSCREEN"] = "显示屏幕外" -- MT
L["GEMS_CVAR_NAMEPLATES_OFFSCREEN_DESC"] = "显示屏幕外目标的姓名板。可能有用但也可能混乱。" -- MT
L["GEMS_CVAR_NAMEPLATES_RADIAL"] = "径向位置" -- MT
L["GEMS_CVAR_NAMEPLATES_RADIAL_DESC"] = "目标在屏幕外时,沿屏幕边缘径向显示姓名板。0=关。" -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTNP"] = "软目标姓名板" -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTNP_DESC"] = "始终显示软目标敌人的姓名板。" -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTSIZE"] = "软目标大小" -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTSIZE_DESC"] =
    "姓名板上软目标指示器的大小。默认 19 难以看清。25 更好。" -- MT
L["GEMS_CVAR_NAMEPLATES_DEBUFFPAD"] = "减益填充" -- MT
L["GEMS_CVAR_NAMEPLATES_DEBUFFPAD_DESC"] = "减益列表与生命条之间的填充。0 = 紧凑。" -- MT

-- CVar Section: Raiding
L["GEMS_CVAR_RAIDING_COMBATLOG"] = "高级战斗记录" -- MT
L["GEMS_CVAR_RAIDING_COMBATLOG_DESC"] =
    "启用高级战斗记录(额外事件数据)。准确上传 Warcraft Logs 必备。" -- MT
L["GEMS_CVAR_RAIDING_THREATWARN"] = "仇恨警告" -- MT
L["GEMS_CVAR_RAIDING_THREATWARN_DESC"] = "仇恨警告显示。0=关,1=地下城,2=队伍,3=始终。" -- MT
L["GEMS_CVAR_RAIDING_THREATNUM"] = "数字仇恨" -- MT
L["GEMS_CVAR_RAIDING_THREATNUM_DESC"] =
    "在目标/焦点框上显示数字仇恨值。对坦克和注重仇恨的 DPS 有用。" -- MT
L["GEMS_CVAR_RAIDING_THREATSOUND"] = "仇恨声音" -- MT
L["GEMS_CVAR_RAIDING_THREATSOUND_DESC"] = "仇恨过渡时播放声音(获得/失去仇恨)。" -- MT
L["GEMS_CVAR_RAIDING_THREATTEXT"] = "仇恨世界文字" -- MT
L["GEMS_CVAR_RAIDING_THREATTEXT_DESC"] = "战斗中显示仇恨浮动文字(仇恨文本)。" -- MT
L["GEMS_CVAR_RAIDING_TIMELINE"] = "遭遇时间线" -- MT
L["GEMS_CVAR_RAIDING_TIMELINE_DESC"] = "启用 Boss 遭遇时间线。显示即将到来的 Boss 能力。" -- MT
L["GEMS_CVAR_RAIDING_TIMEROLE"] = "时间线职责筛选" -- MT
L["GEMS_CVAR_RAIDING_TIMEROLE_DESC"] =
    "隐藏与你的职责无关的遭遇时间线事件。减少 DPS/治疗者的噪音。" -- MT
L["GEMS_CVAR_RAIDING_WARNINGS"] = "遭遇警告" -- MT
L["GEMS_CVAR_RAIDING_WARNINGS_DESC"] = "显示遭遇警告消息(Boss 能力警报)。" -- MT
L["GEMS_CVAR_RAIDING_WARNHIDE"] = "隐藏非目标警告" -- MT
L["GEMS_CVAR_RAIDING_WARNHIDE_DESC"] =
    "隐藏不针对你的 Boss 警告。0=显示全部(更安全)。1=对经验丰富的团长噪音更少。" -- MT
L["GEMS_CVAR_RAIDING_AGGRO"] = "仇恨高亮" -- MT
L["GEMS_CVAR_RAIDING_AGGRO_DESC"] = "玩家有仇恨时高亮团队框。" -- MT
L["GEMS_CVAR_RAIDING_RDEBUFFS"] = "团队框减益" -- MT
L["GEMS_CVAR_RAIDING_RDEBUFFS_DESC"] = "在团队框上显示减益。对治疗者和驱散者必备。" -- MT
L["GEMS_CVAR_RAIDING_HEALPRED"] = "传入治疗" -- MT
L["GEMS_CVAR_RAIDING_HEALPRED_DESC"] = "在团队框上显示传入治疗预测。" -- MT
L["GEMS_CVAR_RAIDING_POWERBARS"] = "团队能量条" -- MT
L["GEMS_CVAR_RAIDING_POWERBARS_DESC"] = "在团队框上显示法力/怒气/能量条。默认关闭以节省空间。" -- MT
L["GEMS_CVAR_RAIDING_RCLASSCOLOR"] = "团队职业颜色" -- MT
L["GEMS_CVAR_RAIDING_RCLASSCOLOR_DESC"] =
    "按职业为团队框生命条着色。让一目了然识别玩家更容易。" -- MT
L["GEMS_CVAR_RAIDING_DISPONLY"] = "仅可驱散" -- MT
L["GEMS_CVAR_RAIDING_DISPONLY_DESC"] = "筛选只显示你能驱散的减益。0=显示全部。" -- MT
L["GEMS_CVAR_RAIDING_ROLEDEBUFF"] = "职责减益大小" -- MT
L["GEMS_CVAR_RAIDING_ROLEDEBUFF_DESC"] =
    "以更大尺寸显示职责相关的减益。坦克看到坦克减益更大,治疗者看到治疗者减益更大。" -- MT
L["GEMS_CVAR_RAIDING_BIGDEF"] = "中央大型防御" -- MT
L["GEMS_CVAR_RAIDING_BIGDEF_DESC"] = "在团队框中央显示大型防御冷却(铁皮、苦痛压制)。" -- MT
L["GEMS_CVAR_RAIDING_DISPTYPE"] = "驱散指示器" -- MT
L["GEMS_CVAR_RAIDING_DISPTYPE_DESC"] = "驱散指示器样式。0=无,1=图标,2=图标+高亮。" -- MT
L["GEMS_CVAR_RAIDING_HEALTHTEXT"] = "生命文字模式" -- MT
L["GEMS_CVAR_RAIDING_HEALTHTEXT_DESC"] =
    "生命文字显示模式。无、生命、丢失生命或百分比。基于偏好。" -- MT
L["GEMS_CVAR_RAIDING_SORTMODE"] = "团队排序模式" -- MT
L["GEMS_CVAR_RAIDING_SORTMODE_DESC"] = "团队框排序模式。职责(坦克/治疗者/DPS)或组。" -- MT
L["GEMS_CVAR_RAIDING_KEEPGRP"] = "保持组在一起" -- MT
L["GEMS_CVAR_RAIDING_KEEPGRP_DESC"] = "保持团队组视觉分离。0=混合,1=组块。" -- MT
L["GEMS_CVAR_RAIDING_TANKASSIST"] = "坦克和助理" -- MT
L["GEMS_CVAR_RAIDING_TANKASSIST_DESC"] = "在团队框中显示主坦克和主助理单位。" -- MT
L["GEMS_CVAR_RAIDING_FINDSELF"] = "找到自己" -- MT
L["GEMS_CVAR_RAIDING_FINDSELF_DESC"] = "在团队框中高亮你自己的角色。" -- MT
L["GEMS_CVAR_RAIDING_CASTBUFFS"] = "可施放增益" -- MT
L["GEMS_CVAR_RAIDING_CASTBUFFS_DESC"] = "只显示你能施放的增益(仅团队)。0=显示全部。" -- MT
L["GEMS_CVAR_RAIDING_DISPDEBUFFS"] = "显示驱散减益" -- MT
L["GEMS_CVAR_RAIDING_DISPDEBUFFS_DESC"] = "只显示你能驱散的减益(仅团队)。" -- MT
L["GEMS_CVAR_RAIDING_RAIDSETTINGS"] = "团队图形设置" -- MT
L["GEMS_CVAR_RAIDING_RAIDSETTINGS_DESC"] =
    "为团队启用单独的图形设置。最大的单一团队 FPS 改进。许多玩家错过这个。" -- MT
L["GEMS_CVAR_RAIDING_RAIDCLUTTER"] = "团队法术视觉密度" -- MT
L["GEMS_CVAR_RAIDING_RAIDCLUTTER_DESC"] = "启用团队专用设置时，团队副本内使用的法术视觉密度。" -- MT
L["GEMS_CVAR_RAIDING_NOFILTER"] = "无增益/减益筛选" -- MT
L["GEMS_CVAR_RAIDING_NOFILTER_DESC"] =
    "禁用目标框上所有增益/减益筛选。0=正常筛选。1=查看一切。" -- MT
L["GEMS_CVAR_RAIDING_MYSPELLS"] = "强调我的法术" -- MT
L["GEMS_CVAR_RAIDING_MYSPELLS_DESC"] =
    "降低其他玩家的法术效果同时保持你的全开。20 人团队中必备。" -- MT
L["GEMS_CVAR_RAIDING_COMBATWARN"] = "战斗警告" -- MT
L["GEMS_CVAR_RAIDING_COMBATWARN_DESC"] = "战斗警告 UI 的主开关(Boss 时间线 + 警告)。" -- MT

-- CVar Section: Dungeons & M+
L["GEMS_CVAR_DUNGEON_DPSRESET"] = "DPS 仪表重置" -- MT
L["GEMS_CVAR_DUNGEON_DPSRESET_DESC"] =
    "进入新副本时自动重置伤害仪表。每个地下城清洁数据,无需手动重置。" -- MT
L["GEMS_CVAR_DUNGEON_ENTRANCE"] = "地下城入口" -- MT
L["GEMS_CVAR_DUNGEON_ENTRANCE_DESC"] = "在世界地图上显示地下城入口图标。" -- MT
L["GEMS_CVAR_DUNGEON_CLUTTER"] = "单位混乱筛选" -- MT
L["GEMS_CVAR_DUNGEON_CLUTTER_DESC"] = "限制单位混乱(NPC 堆叠减少)仅在副本中。" -- MT
L["GEMS_CVAR_DUNGEON_ENEMYCAST"] = "敌方施法条" -- MT
L["GEMS_CVAR_DUNGEON_ENEMYCAST_DESC"] = "在竞技场框上显示敌方施法条。也影响史诗钥石队伍感知。" -- MT
L["GEMS_CVAR_DUNGEON_LOGTIME"] = "日志保留时间" -- MT
L["GEMS_CVAR_DUNGEON_LOGTIME_DESC"] =
    "保留战斗日志条目的秒数。默认 300 秒。长史诗钥石拉怪增加到 600。" -- MT
L["GEMS_CVAR_DUNGEON_LOGFILE"] = "唯一日志文件名" -- MT
L["GEMS_CVAR_DUNGEON_LOGFILE_DESC"] = "使用带时间戳的战斗日志文件名。防止覆盖之前的日志。" -- MT
L["GEMS_CVAR_DUNGEON_DIMINISH"] = "控制递减效果" -- MT
L["GEMS_CVAR_DUNGEON_DIMINISH_DESC"] = "在敌方框上显示控制递减。" -- MT

-- CVar Section: Solo Play & Open World
L["GEMS_CVAR_SOLO_AUTOLOOT"] = "自动拾取" -- MT
L["GEMS_CVAR_SOLO_AUTOLOOT_DESC"] =
    "自动拾取物品。默认关闭意味着单独点击每个物品。几乎每个玩家都想要开启。" -- MT
L["GEMS_CVAR_SOLO_LOOTRATE"] = "拾取速度" -- MT
L["GEMS_CVAR_SOLO_LOOTRATE_DESC"] =
    "自动拾取节奏之间的毫秒数。默认 150ms 感觉缓慢。50ms 几乎瞬间拾取。" -- MT
L["GEMS_CVAR_SOLO_LOOTMOUSE"] = "光标处拾取" -- MT
L["GEMS_CVAR_SOLO_LOOTMOUSE_DESC"] = "在鼠标光标处打开拾取窗口。节省鼠标移动。" -- MT
L["GEMS_CVAR_SOLO_AELOOT"] = "AoE 拾取" -- MT
L["GEMS_CVAR_SOLO_AELOOT_DESC"] = "禁用范围拾取。0=AoE 拾取启用(一次拾取所有附近尸体)。" -- MT
L["GEMS_CVAR_SOLO_DISMOUNT"] = "自动下马" -- MT
L["GEMS_CVAR_SOLO_DISMOUNT_DESC"] = "施法时自动下马。" -- MT
L["GEMS_CVAR_SOLO_DISMOUNTFLY"] = "飞行时下马" -- MT
L["GEMS_CVAR_SOLO_DISMOUNTFLY_DESC"] = "飞行时自动下马(你会坠落)。默认关闭是合理的。" -- MT
L["GEMS_CVAR_SOLO_TOT"] = "目标的目标" -- MT
L["GEMS_CVAR_SOLO_TOT_DESC"] = "显示目标的目标框。对坦克(看到 Boss 的目标)和 DPS 必备。" -- MT
L["GEMS_CVAR_SOLO_TCASTBAR"] = "目标施法条" -- MT
L["GEMS_CVAR_SOLO_TCASTBAR_DESC"] = "显示目标的施法条。打断必备。" -- MT
L["GEMS_CVAR_SOLO_QUESTWATCH"] = "自动任务追踪" -- MT
L["GEMS_CVAR_SOLO_QUESTWATCH_DESC"] = "获取任务时自动在目标追踪器中追踪。" -- MT
L["GEMS_CVAR_SOLO_QUESTPOI"] = "地图上的任务 POI" -- MT
L["GEMS_CVAR_SOLO_QUESTPOI_DESC"] = "在世界地图上显示任务兴趣点。" -- MT
L["GEMS_CVAR_SOLO_PARTYPETS"] = "显示队伍宠物" -- MT
L["GEMS_CVAR_SOLO_PARTYPETS_DESC"] = "在队伍 UI 中显示宠物框。默认关闭以节省屏幕空间。" -- MT
L["GEMS_CVAR_SOLO_INTERACT"] = "软互动" -- MT
L["GEMS_CVAR_SOLO_INTERACT_DESC"] =
    "互动对象的软目标选择。0=关,1=手柄,3=始终。任务的巨大生活质量提升。" -- MT
L["GEMS_CVAR_SOLO_INTERARC"] = "互动弧度" -- MT
L["GEMS_CVAR_SOLO_INTERARC_DESC"] =
    "互动软目标的方向约束。0=必须直接面对,1=前方弧,2=任意方向。" -- MT
L["GEMS_CVAR_SOLO_INTERRANGE"] = "互动范围" -- MT
L["GEMS_CVAR_SOLO_INTERRANGE_DESC"] = "软互动检测的最大范围(码)。10 是默认和上限。" -- MT
L["GEMS_CVAR_SOLO_INTERICON"] = "互动图标" -- MT
L["GEMS_CVAR_SOLO_INTERICON_DESC"] = "为软互动目标显示图标指示器。保持开启以获得视觉反馈。" -- MT
L["GEMS_CVAR_SOLO_AUTOINTER"] = "自动移动到互动" -- MT
L["GEMS_CVAR_SOLO_AUTOINTER_DESC"] = "自动移动到互动目标。在战斗区域中可能令人不知所措。" -- MT
L["GEMS_CVAR_SOLO_QUESTITEMS"] = "任务物品互动" -- MT
L["GEMS_CVAR_SOLO_QUESTITEMS_DESC"] =
    "允许将任务物品作为互动使用。让你直接从软互动键使用任务物品。" -- MT
L["GEMS_CVAR_SOLO_QUESTITEMS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_SOLO_QUESTITEMS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_SOLO_QUESTITEMS_DESCLONG"] =
    "Enables quest items to participate in soft-target interaction. Recommended on (1) -- quest items become eligible for soft-target highlighting and interaction alongside NPCs and objects, which matches how the rest of the modern open-world interaction system works. Off (0) excludes quest items from the soft-target system; you click them manually like in older expansions." -- MT

-- CVar Section: UI & Quality of Life
L["GEMS_CVAR_UI_TUTORIALS"] = "教程弹窗" -- MT
L["GEMS_CVAR_UI_TUTORIALS_DESC"] = "显示教程弹窗。经验丰富的玩家应禁用 -- 教程会打断游戏。" -- MT
L["GEMS_CVAR_UI_NPE"] = "新玩家教程" -- MT
L["GEMS_CVAR_UI_NPE_DESC"] = "显示新玩家体验教程。经验丰富的玩家请禁用。" -- MT
L["GEMS_CVAR_UI_LOADTIPS"] = "加载屏幕提示" -- MT
L["GEMS_CVAR_UI_LOADTIPS_DESC"] = "在加载屏幕上显示提示。低成本,偶尔有用。" -- MT
L["GEMS_CVAR_UI_COMPARE"] = "比较物品" -- MT
L["GEMS_CVAR_UI_COMPARE_DESC"] = "悬停装备时始终显示物品比较提示。" -- MT
L["GEMS_CVAR_UI_TOOLTIPS"] = "详细提示" -- MT
L["GEMS_CVAR_UI_TOOLTIPS_DESC"] = "显示带属性的详细/详尽提示。" -- MT
L["GEMS_CVAR_UI_TRANSMOG"] = "缺失幻化来源" -- MT
L["GEMS_CVAR_UI_TRANSMOG_DESC"] = "显示是否缺少幻化外观来源。收藏家的隐藏宝石。" -- MT
L["GEMS_CVAR_UI_SSFORMAT"] = "截图格式" -- MT
L["GEMS_CVAR_UI_SSFORMAT_DESC"] = "截图文件格式。TGA 无损,JPEG 节省磁盘空间但看起来更差。" -- MT
L["GEMS_CVAR_UI_SSQUALITY"] = "截图质量" -- MT
L["GEMS_CVAR_UI_SSQUALITY_DESC"] = "JPEG 质量(1-10)。默认 3 非常低。如果使用 JPEG,使用 10。" -- MT
L["GEMS_CVAR_UI_ZOOM"] = "镜头缩放距离" -- MT
L["GEMS_CVAR_UI_ZOOM_DESC"] = "最大镜头拉远乘数。默认 1.9 感觉很近。2.6 提供更多战场感知。" -- MT
L["GEMS_CVAR_UI_EDGEFLASH"] = "屏幕边缘闪烁" -- MT
L["GEMS_CVAR_UI_EDGEFLASH_DESC"] = "战斗中地图打开时屏幕边缘的红色闪烁。安全提醒。" -- MT
L["GEMS_CVAR_UI_BUBBLES"] = "聊天气泡" -- MT
L["GEMS_CVAR_UI_BUBBLES_DESC"] = "显示游戏内对话气泡。" -- MT
L["GEMS_CVAR_UI_BIGNUMS"] = "拆分数字" -- MT
L["GEMS_CVAR_UI_BIGNUMS_DESC"] = "在大数字中使用逗号(1,000,000 vs 1000000)。" -- MT
L["GEMS_CVAR_UI_BUFFDUR"] = "增益持续时间" -- MT
L["GEMS_CVAR_UI_BUFFDUR_DESC"] = "在增益图标上显示剩余持续时间。" -- MT
L["GEMS_CVAR_UI_COMBOPT"] = "连击点位置" -- MT
L["GEMS_CVAR_UI_COMBOPT_DESC"] = "连击点显示。1=在目标框上,2=在自己上(个人资源显示下方)。" -- MT
L["GEMS_CVAR_UI_FSTACK"] = "框架堆栈调试" -- MT
L["GEMS_CVAR_UI_FSTACK_DESC"] =
    "启用框架堆栈提示(开发者工具)。悬停时显示框架名称。对调试有用。" -- MT
L["GEMS_CVAR_UI_RAWMOUSE"] = "原始鼠标输入" -- MT
L["GEMS_CVAR_UI_RAWMOUSE_DESC"] = "原始鼠标输入模式。自 2024 补丁后损坏 -- 保持开启不起作用。" -- MT
L["GEMS_CVAR_UI_TAINT"] = "污染日志" -- MT
L["GEMS_CVAR_UI_TAINT_DESC"] =
    "污染调试日志。0=关,1=记录到文件,2=记录+聊天。插件开发者设为 1 调试。" -- MT
L["GEMS_CVAR_UI_BAGS"] = "合并背包" -- MT
L["GEMS_CVAR_UI_BAGS_DESC"] =
    "将所有背包显示为一个合并的库存视图。在巨龙时代添加。管理更简洁。" -- MT
L["GEMS_CVAR_UI_ROTATEMM"] = "旋转小地图" -- MT
L["GEMS_CVAR_UI_ROTATEMM_DESC"] = "旋转小地图以匹配玩家朝向方向,而非固定北上。基于偏好。" -- MT

-- CVar Section: FPS & Performance
L["GEMS_CVAR_FPS_MAXFPS"] = "最大 FPS" -- MT
L["GEMS_CVAR_FPS_MAXFPS_DESC"] = "FPS 上限。应匹配显示器刷新率。更高浪费 GPU。" -- MT
L["GEMS_CVAR_FPS_BGFPS"] = "后台 FPS" -- MT
L["GEMS_CVAR_FPS_BGFPS_DESC"] =
    "后台 FPS 上限(游戏未聚焦)。30 节省电力/热量。降到 8 实现最大节省。" -- MT
L["GEMS_CVAR_FPS_LOADFPS"] = "加载屏幕 FPS" -- MT
L["GEMS_CVAR_FPS_LOADFPS_DESC"] = "加载屏幕 FPS 上限。低就好 -- 加载期间无游戏。" -- MT
L["GEMS_CVAR_FPS_USEMAXFPS"] = "启用 FPS 上限" -- MT
L["GEMS_CVAR_FPS_USEMAXFPS_DESC"] = "启用 FPS 上限。默认关闭意味着无限 FPS(浪费 GPU,产生热量)。" -- MT
L["GEMS_CVAR_FPS_VSYNC"] = "垂直同步" -- MT
L["GEMS_CVAR_FPS_VSYNC_DESC"] = "防止屏幕撕裂但增加输入延迟。竞技游戏请禁用,改用 FPS 上限。" -- MT
L["GEMS_CVAR_FPS_TARGETFPS"] = "目标 FPS" -- MT
L["GEMS_CVAR_FPS_TARGETFPS_DESC"] = "动态质量缩放的目标 FPS。游戏自动降低设置以达到此值。" -- MT
L["GEMS_CVAR_FPS_USETARGET"] = "使用目标 FPS" -- MT
L["GEMS_CVAR_FPS_USETARGET_DESC"] =
    "启用目标 FPS 系统。可能导致刺眼的质量波动。优先使用静态设置。" -- MT
L["GEMS_CVAR_FPS_LATENCY"] = "GPU 帧延迟" -- MT
L["GEMS_CVAR_FPS_LATENCY_DESC"] =
    "CPU 可在 GPU 前排队的最大帧数。默认 3 = 60fps 时约 50ms 延迟。1 = 约 16ms,对宏值得。" -- MT
L["GEMS_CVAR_FPS_RSCALE"] = "渲染缩放" -- MT
L["GEMS_CVAR_FPS_RSCALE_DESC"] =
    "渲染分辨率乘数。1.0 = 原生。低于 1.0 = 模糊但更快。高于 1.0 = 超采样。" -- MT
L["GEMS_CVAR_FPS_DYNSCALE"] = "动态渲染缩放" -- MT
L["GEMS_CVAR_FPS_DYNSCALE_DESC"] =
    "GPU 受限时自动降低渲染缩放。测试功能 -- 可能导致卡顿。除非需要否则关闭。" -- MT
L["GEMS_CVAR_FPS_LOWLAT"] = "低延迟模式" -- MT
L["GEMS_CVAR_FPS_LOWLAT_DESC"] = "低延迟渲染。0=无,2=Reflex (NVIDIA),4=XeLL (Intel)。AMD 用户保持 0。" -- MT
L["GEMS_CVAR_FPS_MULTITHREAD"] = "多线程渲染" -- MT
L["GEMS_CVAR_FPS_MULTITHREAD_DESC"] = "多线程渲染。禁用会显著降低帧率。永远不要设为 0。" -- MT
L["GEMS_CVAR_FPS_SPELLCLUTTER"] = "法术视觉密度" -- MT
L["GEMS_CVAR_FPS_SPELLCLUTTER_DESC"] = "全局法术视觉密度。1=仅必要,4=全部。越低 = FPS 增益越大。" -- MT
L["GEMS_CVAR_FPS_PARTICLES"] = "粒子密度" -- MT
L["GEMS_CVAR_FPS_PARTICLES_DESC"] =
    "Particle effect detail. Lower tiers cut GPU load in particle-heavy fights; Disabled turns particles off entirely (and hides some combat cues)." -- MT
L["GEMS_CVAR_FPS_WEATHER"] = "天气密度" -- MT
L["GEMS_CVAR_FPS_WEATHER_DESC"] = "天气效果密度。降低移除雨/雪粒子。" -- MT
L["GEMS_CVAR_FPS_ANIMLOD"] = "动画跳帧" -- MT
L["GEMS_CVAR_FPS_ANIMLOD_DESC"] = "为远处角色跳过动画帧。节省 CPU 而无可见影响。" -- MT
L["GEMS_CVAR_FPS_VFXDENSITY"] = "VFX 密度筛选" -- MT
L["GEMS_CVAR_FPS_VFXDENSITY_DESC"] =
    "替代法术视觉密度控制。作为第二轮筛选与 spellClutter 一起工作。" -- MT
L["GEMS_CVAR_FPS_USEMAXFPS_OPT_0"] = "Off (default)" -- MT
L["GEMS_CVAR_FPS_USEMAXFPS_OPT_1"] = "On (recommended)" -- MT
L["GEMS_CVAR_FPS_USEMAXFPS_DESCLONG"] =
    "Master switch for the FPS limit. EMS recommends 1 because uncapped frames can spike to 300+ in light scenes (e.g. open-world solo play), spinning your GPU up to high power draw for no visible benefit on a 60-144Hz monitor. Setting a cap reduces fan noise, lowers GPU temperature, and prevents the framerate-cliff sensation when you enter dense content. Pair this with maxFPS at your monitor refresh rate. Set to 0 if you specifically want uncapped frames for input-latency reasons (high-refresh competitive PvP). This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_FPS_VSYNC_OPT_0"] = "Off (recommended)" -- MT
L["GEMS_CVAR_FPS_VSYNC_OPT_1"] = "On (default)" -- MT
L["GEMS_CVAR_FPS_VSYNC_DESCLONG"] =
    "Vertical sync, synchronising frame output to your monitor refresh rate. EMS recommends 0 because vsync adds input latency (typically one full frame, 8-16ms on a 60-120Hz monitor) which is noticeable during reactive play -- interrupt windows feel mushier and dragonriding inputs feel delayed. Modern high-refresh-rate monitors generally handle tearing well without vsync. Set to 1 only if you see visible tearing artefacts that bother you and your monitor lacks G-Sync or FreeSync support. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_FPS_USETARGET_OPT_0"] = "Off (recommended)" -- MT
L["GEMS_CVAR_FPS_USETARGET_OPT_1"] = "On (default)" -- MT
L["GEMS_CVAR_FPS_USETARGET_DESCLONG"] =
    "Enables the dynamic-FPS-adjustment system: WoW lowers render scale, particle density, and other quality settings on the fly when actual FPS drops below targetFPS. EMS recommends 0 because the dynamic adjustments cause visible quality shifts mid-fight (textures pop, shadows fade in and out) which is more distracting than a stable lower framerate. Set quality manually to a level your hardware sustains and accept the framerate that produces. Set to 1 if you specifically prefer the dynamic-quality tradeoff. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_FPS_DYNSCALE_OPT_0"] = "Off (default, recommended)" -- MT
L["GEMS_CVAR_FPS_DYNSCALE_OPT_1"] = "On" -- MT
L["GEMS_CVAR_FPS_DYNSCALE_DESCLONG"] =
    "Lowers render scale dynamically if GPU-bound to hit targetFPS. EMS recommends 0 (match-default) because Blizzard marks this as BETA with known issues (May cause hitching. May behave poorly with vsync on). The trade-off is visible: text and UI go subtly blurry when DynamicRenderScale kicks in, which is more distracting than a stable lower framerate. Set to 1 only if you specifically want dynamic GPU-bound adjustment. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_FPS_MULTITHREAD_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_FPS_MULTITHREAD_OPT_1"] = "On (default, recommended)" -- MT
L["GEMS_CVAR_FPS_MULTITHREAD_DESCLONG"] =
    "Multi-threaded command list compatibility mode. Default 1 is correct -- disabling this significantly reduces framerate per Blizzard's own description, particularly on multi-core CPUs (which is every modern system). Only set to 0 if you experience specific multi-threaded rendering bugs that disabling solves; this is rare. Critical setting -- changes take effect on the next graphics reset (logout + login, or /console gxRestart). This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_FPS_ANIMLOD_OPT_0"] = "Off (default)" -- MT
L["GEMS_CVAR_FPS_ANIMLOD_OPT_1"] = "On (recommended)" -- MT
L["GEMS_CVAR_FPS_ANIMLOD_DESCLONG"] =
    "Skips animation frames for distant units to save CPU. EMS recommends 1 because crowded scenes (raid, capital city, mass PvP) can have dozens of off-screen or far-away animated units whose animation updates burn CPU cycles you do not see. Frame-skipping at distance is visually imperceptible at 30+ yards (the units are too small to notice their reduced anim cadence) and frees CPU for the units that matter (the boss, your party, the unit you target). Set to 0 if you want full animation fidelity at all distances. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_FPS_LATENCY_OPT_1"] = "1 (recommended, lowest input lag)" -- MT
L["GEMS_CVAR_FPS_LATENCY_OPT_2"] = "2 (balanced)" -- MT
L["GEMS_CVAR_FPS_LATENCY_OPT_3"] = "3 (default, smoothest frame pacing)" -- MT
L["GEMS_CVAR_FPS_LATENCY_DESCLONG"] =
    "Maximum number of frames the CPU can render ahead of the GPU (input-to-display pipeline depth). EMS recommends 1 because the Blizzard default 3 adds substantial input latency (each queued frame is one frame of delay between keypress and on-screen action). Setting to 1 cuts the pipeline to the minimum, reducing input lag noticeably for reactive play (interrupt windows, dodge mechanics, dragonriding). Trade-off: on a CPU-bottlenecked system, lower values can cause minor frame pacing inconsistency. Increase to 2 or 3 if you see hitching. Critical setting -- changes take effect on the next graphics reset (logout + login, or /console gxRestart). This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_FPS_WEATHER_OPT_0"] = "0 (off)" -- MT
L["GEMS_CVAR_FPS_WEATHER_OPT_1"] = "1 (light, recommended)" -- MT
L["GEMS_CVAR_FPS_WEATHER_OPT_2"] = "2 (full, default)" -- MT
L["GEMS_CVAR_FPS_WEATHER_DESCLONG"] =
    "Density of weather particle effects (rain, snow, sandstorm). EMS recommends 1 because the Blizzard default 2 (full) renders thousands of weather particles in outdoor zones -- the FPS cost runs 10-20% in dense storms with little gameplay benefit. Setting to 1 (light) keeps the atmospheric feel but cuts the particle count to a level that does not tank framerate during outdoor combat. Set to 0 if you want zero weather rendering (max FPS in storms). This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_FPS_VFXDENSITY_OPT_1"] = "1 (minimum, recommended)" -- MT
L["GEMS_CVAR_FPS_VFXDENSITY_OPT_2"] = "2 (reduced)" -- MT
L["GEMS_CVAR_FPS_VFXDENSITY_OPT_3"] = "3 (performance)" -- MT
L["GEMS_CVAR_FPS_VFXDENSITY_OPT_4"] = "4 (full, default)" -- MT
L["GEMS_CVAR_FPS_VFXDENSITY_DESCLONG"] =
    "Filters out overlapping spell visuals (SVKs) in dense scenes. EMS recommends 1 (minimum) because the Blizzard default 4 (full) renders every spell visual in raid scenes which causes catastrophic FPS drops in 20+ player encounters with multiple AoE effects (think Mythic raid bosses with overlapping ground effects). Minimum mode drops less-important visuals first while keeping your own spell cues clear. Increase to 2 (reduced) or 3 (performance) only if you have headroom; the FPS difference between settings is dramatic in dense raid content. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_FPS_BGFPS_OPT_8"] = "8 (minimum)" -- MT
L["GEMS_CVAR_FPS_BGFPS_OPT_30"] = "30 (default, recommended)" -- MT
L["GEMS_CVAR_FPS_BGFPS_OPT_60"] = "60 (smooth)" -- MT
L["GEMS_CVAR_FPS_BGFPS_OPT_120"] = "120 (high)" -- MT
L["GEMS_CVAR_FPS_BGFPS_OPT_240"] = "240 (very high)" -- MT
L["GEMS_CVAR_FPS_BGFPS_DESCLONG"] =
    "Background FPS limit -- the cap applied when WoW is not the focused window (Alt-Tab to browser, Discord). Default 30 is correct because backgrounded WoW still consumes some CPU/GPU and capping it at 30 lets the focused application (your browser, Discord) have full performance headroom. Lower to 8 (minimum) if you want WoW to use almost no resources when backgrounded. Raise to 60+ if you stream WoW from a backgrounded source. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_FPS_LOADFPS_OPT_5"] = "5 (very low)" -- MT
L["GEMS_CVAR_FPS_LOADFPS_OPT_10"] = "10 (default, recommended)" -- MT
L["GEMS_CVAR_FPS_LOADFPS_OPT_30"] = "30 (low)" -- MT
L["GEMS_CVAR_FPS_LOADFPS_OPT_60"] = "60 (mid)" -- MT
L["GEMS_CVAR_FPS_LOADFPS_OPT_120"] = "120 (high)" -- MT
L["GEMS_CVAR_FPS_LOADFPS_DESCLONG"] =
    "FPS cap during loading screens. Default 10 is correct because loading screens are static visuals; rendering them at 200 FPS only loads the GPU for no benefit. Lower to 5 if you want the absolute minimum power draw during loads. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_FPS_TARGETFPS_OPT_30"] = "30 (low)" -- MT
L["GEMS_CVAR_FPS_TARGETFPS_OPT_45"] = "45 (mid-low)" -- MT
L["GEMS_CVAR_FPS_TARGETFPS_OPT_60"] = "60 (default, recommended)" -- MT
L["GEMS_CVAR_FPS_TARGETFPS_OPT_90"] = "90 (high)" -- MT
L["GEMS_CVAR_FPS_TARGETFPS_OPT_120"] = "120 (very high)" -- MT
L["GEMS_CVAR_FPS_TARGETFPS_DESCLONG"] =
    "Target FPS for the dynamic adjustment system (only used when useTargetFPS is On). Default 60 is the standard target for stable play on a 60Hz monitor. Set to your monitor refresh rate if higher (120 for 120Hz, 144 for 144Hz). Lower targets accept worse quality to maintain framerate; higher targets reduce quality more aggressively. This setting only matters when useTargetFPS is enabled. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_FPS_LOWLAT_OPT_0"] = "0 None (default, safe)" -- MT
L["GEMS_CVAR_FPS_LOWLAT_OPT_1"] = "1 BuiltIn (works on any GPU)" -- MT
L["GEMS_CVAR_FPS_LOWLAT_OPT_2"] = "2 Reflex (NVIDIA RTX only)" -- MT
L["GEMS_CVAR_FPS_LOWLAT_OPT_3"] = "3 Reflex+Boost (NVIDIA RTX only)" -- MT
L["GEMS_CVAR_FPS_LOWLAT_OPT_4"] = "4 XeLL (Intel Arc only)" -- MT
L["GEMS_CVAR_FPS_LOWLAT_DESCLONG"] =
    "Hardware-specific frame latency reduction. Default 0 (None) is universally safe. Options: 0=None (no vendor-specific path); 1=BuiltIn (Blizzard's generic latency reduction, works on any GPU); 2=Reflex (NVIDIA Reflex, requires RTX GPU and updated NVIDIA driver); 3=Reflex+Boost (NVIDIA Reflex with Boost, RTX GPU only); 4=XeLL (Intel Xe Low Latency, requires Intel Arc GPU and updated Intel driver). Pick the option matching your hardware: NVIDIA RTX owners use 2 or 3, Intel Arc owners use 4, all others use 1 (BuiltIn) for moderate gains or 0 (safe default). Note: setting an unsupported mode (e.g. Reflex on an AMD GPU) is harmless -- the driver simply ignores the request. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_FPS_SPELLCLUTTER_OPT_0"] = "0 (none, dev-only)" -- MT
L["GEMS_CVAR_FPS_SPELLCLUTTER_OPT_1"] = "1 (minimum, recommended)" -- MT
L["GEMS_CVAR_FPS_SPELLCLUTTER_OPT_2"] = "2 (reduced)" -- MT
L["GEMS_CVAR_FPS_SPELLCLUTTER_OPT_3"] = "3 (performance)" -- MT
L["GEMS_CVAR_FPS_SPELLCLUTTER_OPT_4"] = "4 (full, default)" -- MT
L["GEMS_CVAR_FPS_SPELLCLUTTER_DESCLONG"] =
    "Legacy Spell Density CVar paired with spellVisualDensityFilterSetting (same 0-4 enum where 0=none dev-only, 1=minimum, 2=reduced, 3=performance, 4=full). EMS recommends 1 for the same reason as spellVisualDensityFilterSetting: at 4 (full) raid scenes can drop FPS by 50%+ during overlapping AoE effects. Keep both cvars at 1 for consistent spell-density behaviour. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_FPS_RSCALE_OPT_75"] = "0.75 (undersample, blurry, FPS gain)" -- MT
L["GEMS_CVAR_FPS_RSCALE_OPT_90"] = "0.9 (light undersample)" -- MT
L["GEMS_CVAR_FPS_RSCALE_OPT_100"] = "1.0 (native, default, recommended)" -- MT
L["GEMS_CVAR_FPS_RSCALE_OPT_125"] = "1.25 (light supersample)" -- MT
L["GEMS_CVAR_FPS_RSCALE_OPT_150"] = "1.5 (supersample, sharper, GPU cost)" -- MT
L["GEMS_CVAR_FPS_RSCALE_DESCLONG"] =
    "Render scale: 1.0 is native resolution, values above 1.0 supersample (render at higher resolution then downscale, sharper image, more GPU cost), values below 1.0 undersample (render at lower resolution, blurrier, less GPU cost). Default 1.0 is correct for almost every player. Set to 1.25 or 1.5 only if you have substantial GPU headroom and want sharper visuals at 1080p/1440p. Set to 0.9 or 0.75 if you need FPS gains and can accept a softer image. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT

-- CVar Section: Visual Quality
L["GEMS_CVAR_VISUAL_QUALITY"] = "图形质量" -- MT
L["GEMS_CVAR_VISUAL_QUALITY_DESC"] = "主图形质量预设(1-10)。一次性更改所有子设置。" -- MT
L["GEMS_CVAR_VISUAL_SHADOWS"] = "阴影质量" -- MT
L["GEMS_CVAR_VISUAL_SHADOWS_DESC"] =
    "Shadow quality (0-5). Shadows are GPU-expensive; lowering to Low or Fair gives significant FPS gains." -- MT
L["GEMS_CVAR_VISUAL_SSAO"] = "环境光遮蔽" -- MT
L["GEMS_CVAR_VISUAL_SSAO_DESC"] =
    "屏幕空间环境光遮蔽质量。为阴影添加深度。0=关(最快),4=最高。" -- MT
L["GEMS_CVAR_VISUAL_VIEWDIST"] = "视野距离" -- MT
L["GEMS_CVAR_VISUAL_VIEWDIST_DESC"] = "视野距离(1-10)。降到 5 在副本内容中节省 GPU 而视觉影响小。" -- MT
L["GEMS_CVAR_VISUAL_GROUND"] = "地面杂物" -- MT
L["GEMS_CVAR_VISUAL_GROUND_DESC"] = "草/地面细节密度(1-10)。纯外观 -- 降低不影响游戏并节省 FPS。" -- MT
L["GEMS_CVAR_VISUAL_TEXRES"] = "纹理分辨率" -- MT
L["GEMS_CVAR_VISUAL_TEXRES_DESC"] = "纹理分辨率质量(1-3)。影响 VRAM 使用。VRAM 受限时降低。" -- MT
L["GEMS_CVAR_VISUAL_LIQUID"] = "水质量" -- MT
L["GEMS_CVAR_VISUAL_LIQUID_DESC"] = "水渲染质量。越低 = 反射水越少,水边 FPS 越好。" -- MT
L["GEMS_CVAR_VISUAL_PROJTEX"] = "投射纹理" -- MT
L["GEMS_CVAR_VISUAL_PROJTEX_DESC"] =
    "法术地面效果(治疗之雨、奉献)。必须开启 -- 否则 Boss 机制不可见。" -- MT
L["GEMS_CVAR_VISUAL_OUTLINE"] = "轮廓模式" -- MT
L["GEMS_CVAR_VISUAL_OUTLINE_DESC"] = "角色/NPC 轮廓模式。0=无,1=细,2=正常。帮助可见性。" -- MT
L["GEMS_CVAR_VISUAL_AA"] = "抗锯齿" -- MT
L["GEMS_CVAR_VISUAL_AA_DESC"] =
    "抗锯齿模式。0=无,1=FXAA 低,2=FXAA 高,3=CMAA。CMAA 是最佳质量与成本比。" -- MT
L["GEMS_CVAR_VISUAL_GLOW"] = "辉光效果" -- MT
L["GEMS_CVAR_VISUAL_GLOW_DESC"] = "全屏辉光效果。微妙但增添氛围。" -- MT
L["GEMS_CVAR_VISUAL_DEATH"] = "死亡效果" -- MT
L["GEMS_CVAR_VISUAL_DEATH_DESC"] = "死亡饱和度效果。死亡时变灰度。" -- MT
L["GEMS_CVAR_VISUAL_SHARPEN"] = "锐化通过" -- MT
L["GEMS_CVAR_VISUAL_SHARPEN_DESC"] =
    "即使没有 FSR 升采样也启用锐化。在原生分辨率下使图像更清晰。标准图形菜单中不显示。" -- MT
L["GEMS_CVAR_VISUAL_SHARPNESS"] = "锐化强度" -- MT
L["GEMS_CVAR_VISUAL_SHARPNESS_DESC"] = "锐化强度(0.0-2.0)。仅在锐化启用或 FSR 开启时起作用。" -- MT
L["GEMS_CVAR_VISUAL_FARCLIP"] = "远剪切平面" -- MT
L["GEMS_CVAR_VISUAL_FARCLIP_DESC"] =
    "世界单位中的最大渲染距离。越低 = 远处几何越少 = FPS 越好。800 足够。" -- MT
L["GEMS_CVAR_VISUAL_PROJTEX_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_VISUAL_PROJTEX_OPT_1"] = "On (default, recommended)" -- MT
L["GEMS_CVAR_VISUAL_PROJTEX_DESCLONG"] =
    "Projected textures for ground-effect indicators (AoE markers, void zones, fire patches, healing circles). Default 1 is correct because turning this off removes the visible ground indicators for raid mechanics -- you cannot see where the swirly is. Critical setting -- changes take effect on the next graphics reset (logout + login, or /console gxRestart). Set to 0 only if you have a specific GPU-bottleneck issue and use a third-party addon that draws its own AoE markers. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_VISUAL_GLOW_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_VISUAL_GLOW_OPT_1"] = "On (default, recommended)" -- MT
L["GEMS_CVAR_VISUAL_GLOW_DESCLONG"] =
    "Full-screen glow effect -- the soft bloom on bright surfaces (light sources, magic spells, sun glare). Default 1 is correct because bloom is a small visual flourish with negligible FPS cost on modern hardware. Set to 0 if you find bloom distracting in dark zones or if you specifically prefer a flatter visual style. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_VISUAL_DEATH_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_VISUAL_DEATH_OPT_1"] = "On (default, recommended)" -- MT
L["GEMS_CVAR_VISUAL_DEATH_DESCLONG"] =
    "Full-screen death desaturation effect -- the grey-out filter applied when your character dies. Default 1 is correct because the desat is a useful visual cue confirming your death state (vs a screen freeze or disconnect). Set to 0 if you find the grey-out disorienting during PvP corpse runs. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_VISUAL_SHARPEN_OPT_0"] = "Off (default)" -- MT
L["GEMS_CVAR_VISUAL_SHARPEN_OPT_1"] = "On (recommended)" -- MT
L["GEMS_CVAR_VISUAL_SHARPEN_DESCLONG"] =
    "Forces the sharpness pass to run even when AMD FSR upscaling is disabled. EMS recommends 1 because the default 0 means sharpening only applies during FSR upscaling, which most players are not using -- the result is a soft, slightly washed-out image at native resolution. Setting to 1 enables the sharpness pass regardless, giving you crisper text and UI at all resolutions. ResampleSharpness controls the strength (see below). Set to 0 if you prefer the softer default look. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_VISUAL_OUTLINE_OPT_0"] = "0 (None)" -- MT
L["GEMS_CVAR_VISUAL_OUTLINE_OPT_1"] = "1 (Some)" -- MT
L["GEMS_CVAR_VISUAL_OUTLINE_OPT_2"] = "2 (All, default, recommended)" -- MT
L["GEMS_CVAR_VISUAL_OUTLINE_DESCLONG"] =
    "Character outline rendering: 0=None, 1=Some (allies and selected enemies), 2=All (every character has an outline). Default 2 is correct because outlines help you visually parse character positions in dense scenes (raid stacking, crowded PvP). Set to 0 if you prefer a flatter look or use a third-party UI that handles unit visibility differently. Set to 1 for a middle ground. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_VISUAL_SSAO_OPT_0"] = "0 (Low)" -- MT
L["GEMS_CVAR_VISUAL_SSAO_OPT_1"] = "1 (Fair)" -- MT
L["GEMS_CVAR_VISUAL_SSAO_OPT_2"] = "2 (High)" -- MT
L["GEMS_CVAR_VISUAL_SSAO_OPT_3"] = "3 (Ultra, default, recommended)" -- MT
L["GEMS_CVAR_VISUAL_SSAO_DESCLONG"] =
    "Screen-space ambient occlusion -- the soft contact shadow where objects meet surfaces. Blizzard's tiers run Disabled, Low, Medium, High, Ultra. High (the default) is a sensible stop: SSAO is a cheap way to keep characters looking grounded instead of floating above the terrain, and the frame cost from Disabled up to High is small on modern GPUs. Go to Ultra for the cleanest contact shadows, or drop it only if you need every frame for competitive play. This setting resets each session and does not persist across logouts; EMS re-applies your choice on every login." -- MT
L["GEMS_CVAR_VISUAL_LIQUID_OPT_0"] = "0 (Low)" -- MT
L["GEMS_CVAR_VISUAL_LIQUID_OPT_1"] = "1 (Fair, recommended)" -- MT
L["GEMS_CVAR_VISUAL_LIQUID_OPT_2"] = "2 (High, default)" -- MT
L["GEMS_CVAR_VISUAL_LIQUID_OPT_3"] = "3 (Ultra)" -- MT
L["GEMS_CVAR_VISUAL_LIQUID_DESCLONG"] =
    "Water and lava surface rendering: 0=Low (flat coloured surface), 1=Fair (basic ripples), 2=High (reflections, refraction), 3=Ultra (caustics, volumetric depth). EMS recommends 1 because the Blizzard default 2 renders full reflections on every water surface which costs noticeable FPS in zones with large water areas (Suramar, Nazjatar, Azshara, the Plunderstorm coastline). Setting to 1 keeps the surface looking like water without the expensive reflection pass. Set to 2 or 3 if you specifically enjoy water visuals and have GPU headroom. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_VISUAL_VIEWDIST_OPT_1"] = "1 (very low)" -- MT
L["GEMS_CVAR_VISUAL_VIEWDIST_OPT_3"] = "3 (low)" -- MT
L["GEMS_CVAR_VISUAL_VIEWDIST_OPT_5"] = "5 (recommended)" -- MT
L["GEMS_CVAR_VISUAL_VIEWDIST_OPT_7"] = "7 (high)" -- MT
L["GEMS_CVAR_VISUAL_VIEWDIST_OPT_10"] = "10 (ultra)" -- MT
L["GEMS_CVAR_VISUAL_VIEWDIST_DESCLONG"] =
    "How far the engine renders distant terrain, buildings, and props on Blizzard's 1-10 scale. EMS recommends 5 because the Blizzard default 6 renders enough distance that outdoor zones with many distant objects (Boralus, Valdrakken, Dornogal skyline) cost FPS for environment your camera barely catches. Setting to 5 keeps the playable horizon visible but trims the far-distance prop count. Set to 7 or higher if you specifically want maximum draw distance for screenshots or extended Skyriding flight planning. Set to 1-3 only if you need aggressive FPS gains. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_VISUAL_GROUND_OPT_1"] = "1 (very low)" -- MT
L["GEMS_CVAR_VISUAL_GROUND_OPT_3"] = "3 (recommended)" -- MT
L["GEMS_CVAR_VISUAL_GROUND_OPT_5"] = "5 (mid)" -- MT
L["GEMS_CVAR_VISUAL_GROUND_OPT_7"] = "7 (high)" -- MT
L["GEMS_CVAR_VISUAL_GROUND_OPT_10"] = "10 (ultra)" -- MT
L["GEMS_CVAR_VISUAL_GROUND_DESCLONG"] =
    "Density of small ground objects: grass, pebbles, leaves, flowers, debris. EMS recommends 3 because the Blizzard default 6 fills outdoor zones with thousands of grass and flower tiles that cost FPS without contributing to gameplay -- you cannot interact with them, they do not hide units, and at typical camera angles you mostly see the top surface. Setting to 3 keeps the ground looking varied without the high-density particle cost. Set to 5+ if you specifically enjoy the dense vegetation look in outdoor zones. Set to 1 for maximum FPS in dense outdoor content. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_VISUAL_AA_OPT_0"] = "0 (Disabled, default)" -- MT
L["GEMS_CVAR_VISUAL_AA_OPT_1"] = "1 (FXAA Low)" -- MT
L["GEMS_CVAR_VISUAL_AA_OPT_2"] = "2 (FXAA High)" -- MT
L["GEMS_CVAR_VISUAL_AA_OPT_3"] = "3 (CMAA, recommended)" -- MT
L["GEMS_CVAR_VISUAL_AA_OPT_4"] = "4 (CMAA2, sharpest)" -- MT
L["GEMS_CVAR_VISUAL_AA_DESCLONG"] =
    "Post-process anti-aliasing technique. EMS recommends 3 (CMAA) because the Blizzard default 0 leaves pixel edges jagged at every resolution, while CMAA gives clean edges with no temporal smearing and very low FPS cost on modern hardware. Options: 0=Disabled, 1=FXAA Low (blurry, cheap), 2=FXAA High (less blurry, slightly more expensive), 3=CMAA (sharp, well-balanced), 4=CMAA2 (sharpest, slightly more expensive than CMAA). Pick CMAA2 if you have GPU headroom and want the cleanest edges, FXAA Low if you need maximum FPS, or Disabled if you specifically prefer pixel-perfect rendering. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_VISUAL_FARCLIP_OPT_500"] = "500 yds (low)" -- MT
L["GEMS_CVAR_VISUAL_FARCLIP_OPT_800"] = "800 yds (recommended)" -- MT
L["GEMS_CVAR_VISUAL_FARCLIP_OPT_1000"] = "1000 yds (default)" -- MT
L["GEMS_CVAR_VISUAL_FARCLIP_OPT_1500"] = "1500 yds (high)" -- MT
L["GEMS_CVAR_VISUAL_FARCLIP_OPT_2500"] = "2500 yds (max)" -- MT
L["GEMS_CVAR_VISUAL_FARCLIP_DESCLONG"] =
    "Maximum render distance in yards for the world far-clipping plane. EMS recommends 800 because the Blizzard default 1000 renders an extra 200 yards of distant terrain and props you rarely visually engage with -- the FPS cost is real in outdoor zones with long sightlines (Suramar overlooks, Plunderstorm coast, Skyriding mid-altitude). Setting to 800 trims the horizon to the practical play distance. Set to 1500 or 2500 if you take landscape screenshots or want maximum visibility for long-range Skyriding flight planning. Set to 500 only if you need aggressive FPS gains in outdoor content. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_VISUAL_QUALITY_OPT_1"] = "1 (Low)" -- MT
L["GEMS_CVAR_VISUAL_QUALITY_OPT_3"] = "3 (Fair)" -- MT
L["GEMS_CVAR_VISUAL_QUALITY_OPT_6"] = "6 (Good, default, recommended)" -- MT
L["GEMS_CVAR_VISUAL_QUALITY_OPT_8"] = "8 (High)" -- MT
L["GEMS_CVAR_VISUAL_QUALITY_OPT_10"] = "10 (Ultra)" -- MT
L["GEMS_CVAR_VISUAL_QUALITY_DESCLONG"] =
    "Master video-quality slider on Blizzard's 1-10 preset scale (1=Low, 3=Fair, 6=Good (default), 8=High, 10=Ultra). Default 6 (Good) is correct for balanced play on modern hardware. WARNING: changing this value cascades to all other graphics CVars (shadowQuality, viewDistance, groundClutter, liquidDetail, textureResolution, SSAO, projectedTextures, outlineMode, AA, glow, death, sharpen, sharpness, farclip) -- the preset rewrites every per-cvar tuning you made in the panel above. If you have tuned individual graphics cvars in EMS to specific values, picking a different preset here will OVERWRITE those tunings to the preset's defaults. Recommended workflow: leave this at 6 (Good) and tune individual cvars above for fine-grained control. Pick a different preset only if you want to reset all graphics cvars to Blizzard's preset values. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_VISUAL_SHARPNESS_OPT_NEG_100"] = "-1.0 (disabled)" -- MT
L["GEMS_CVAR_VISUAL_SHARPNESS_OPT_0"] = "0.0 (full strength)" -- MT
L["GEMS_CVAR_VISUAL_SHARPNESS_OPT_20"] = "0.2 (default, recommended)" -- MT
L["GEMS_CVAR_VISUAL_SHARPNESS_OPT_50"] = "0.5 (mild)" -- MT
L["GEMS_CVAR_VISUAL_SHARPNESS_OPT_100"] = "1.0 (soft)" -- MT
L["GEMS_CVAR_VISUAL_SHARPNESS_DESCLONG"] =
    "FSR upscaling sharpness strength on a 0.0-2.0 scale where 0.0 is full strength, 2.0 is minimum, and -1 disables. Default 0.2 is correct -- slightly off full strength to avoid over-sharpening text artefacts. Pairs with ResampleAlwaysSharpen above (which controls whether sharpening runs at all). Set to 0.0 for maximum sharpening (slightly more aliasing artefacts on text). Set to 0.5 or 1.0 for a softer look. Set to -1 to fully disable the sharpness pass regardless of ResampleAlwaysSharpen. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT

-- CVar Section: Sound
L["GEMS_CVAR_SOUND_MASTER"] = "主声音开关" -- MT
L["GEMS_CVAR_SOUND_MASTER_DESC"] = "主声音开关。任何音频都必须开启。" -- MT
L["GEMS_CVAR_SOUND_MASTERVOL"] = "主音量" -- MT
L["GEMS_CVAR_SOUND_MASTERVOL_DESC"] = "主音量(0.0-1.0)。0.8 给 Discord/Spotify 与 WoW 留出余地。" -- MT
L["GEMS_CVAR_SOUND_SFX"] = "音效音量" -- MT
L["GEMS_CVAR_SOUND_SFX_DESC"] = "音效音量。保持 1.0 以听到战斗音频提示。" -- MT
L["GEMS_CVAR_SOUND_MUSIC"] = "音乐音量" -- MT
L["GEMS_CVAR_SOUND_MUSIC_DESC"] = "音乐音量。团队/地下城中降低以听到 Boss 能力音频提示。" -- MT
L["GEMS_CVAR_SOUND_AMBIENCE"] = "环境音量" -- MT
L["GEMS_CVAR_SOUND_AMBIENCE_DESC"] =
    "环境音量。在团队中降低 -- 环境噪音可能掩盖重要的战斗音频。" -- MT
L["GEMS_CVAR_SOUND_DIALOG"] = "对话音量" -- MT
L["GEMS_CVAR_SOUND_DIALOG_DESC"] = "语音/对话音量(Boss 配音、任务旁白)。" -- MT
L["GEMS_CVAR_SOUND_BGAUDIO"] = "后台音频" -- MT
L["GEMS_CVAR_SOUND_BGAUDIO_DESC"] =
    "WoW 在后台时播放声音。alt-tab 时对队列弹出和准备检查很重要。" -- MT
L["GEMS_CVAR_SOUND_ENCWARN"] = "遭遇警告声音" -- MT
L["GEMS_CVAR_SOUND_ENCWARN_DESC"] = "为遭遇/Boss 警告播放声音。" -- MT
L["GEMS_CVAR_SOUND_ENCVOL"] = "遭遇警告音量" -- MT
L["GEMS_CVAR_SOUND_ENCVOL_DESC"] = "遭遇警告声音的音量(0.0-1.0)。" -- MT
L["GEMS_CVAR_SOUND_ERRSPEECH"] = "错误语音" -- MT
L["GEMS_CVAR_SOUND_ERRSPEECH_DESC"] =
    "错误语音(法力不足等)。请禁用 -- 宏序列触发冷却会快速触发此项。" -- MT
L["GEMS_CVAR_SOUND_GAMEPLAY"] = "游戏音效" -- MT
L["GEMS_CVAR_SOUND_GAMEPLAY_DESC"] = "启用游戏音效(战斗、能力、NPC)。" -- MT
L["GEMS_CVAR_SOUND_MASTER_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_SOUND_MASTER_OPT_1"] = "On (default, recommended)" -- MT
L["GEMS_CVAR_SOUND_MASTER_DESCLONG"] =
    "Master switch for all WoW audio output. On is the default and the right answer for almost every player. Turn Off if you want to play silent (during a stream where you have separate music, or to switch to Discord-only voice). Note: when Off, in-game UI ping sounds disappear too, including ready check and trade requests. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_SOUND_MASTERVOL_OPT_50"] = "0.5 (quiet)" -- MT
L["GEMS_CVAR_SOUND_MASTERVOL_OPT_70"] = "0.7 (lower)" -- MT
L["GEMS_CVAR_SOUND_MASTERVOL_OPT_80"] = "0.8 (recommended)" -- MT
L["GEMS_CVAR_SOUND_MASTERVOL_OPT_90"] = "0.9 (loud)" -- MT
L["GEMS_CVAR_SOUND_MASTERVOL_OPT_100"] = "1.0 (default, max)" -- MT
L["GEMS_CVAR_SOUND_MASTERVOL_DESCLONG"] =
    "Overall game volume across every audio channel. EMS recommends 0.8 because at 1.0 the game audio sits at the same level as Discord, music apps, and OS notifications, which forces you to constantly rebalance them in Windows Volume Mixer. 0.8 gives voice chat and music headroom to sit above ambience without manual ducking on every raid pull. Lower it further if you stream and want game audio to clearly sit below your mic. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_SOUND_SFX_OPT_50"] = "0.5 (quiet)" -- MT
L["GEMS_CVAR_SOUND_SFX_OPT_70"] = "0.7 (lower)" -- MT
L["GEMS_CVAR_SOUND_SFX_OPT_85"] = "0.85 (mid)" -- MT
L["GEMS_CVAR_SOUND_SFX_OPT_95"] = "0.95 (slightly soft)" -- MT
L["GEMS_CVAR_SOUND_SFX_OPT_100"] = "1.0 (default, recommended)" -- MT
L["GEMS_CVAR_SOUND_SFX_DESCLONG"] =
    "Combat sound effects channel: spell impacts, weapon swings, ability cast clicks, environmental SFX. Default 1.0 is correct for almost every player because SFX carries the audio cues you need for reactive play (interrupt windows, AoE markers, channelled-cast endings). Lower only if you find combat noise fatiguing during very long sessions. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_SOUND_MUSIC_OPT_0"] = "0.0 (off)" -- MT
L["GEMS_CVAR_SOUND_MUSIC_OPT_10"] = "0.1 (very quiet)" -- MT
L["GEMS_CVAR_SOUND_MUSIC_OPT_20"] = "0.2 (recommended)" -- MT
L["GEMS_CVAR_SOUND_MUSIC_OPT_40"] = "0.4 (default)" -- MT
L["GEMS_CVAR_SOUND_MUSIC_OPT_70"] = "0.7 (loud)" -- MT
L["GEMS_CVAR_SOUND_MUSIC_DESCLONG"] =
    "Background music channel. EMS recommends 0.2 because at the Blizzard default 0.4 the soundtrack competes with combat SFX during raid mechanics -- you can miss a Sated cast bar because the zone music swell drowned the cue. 0.2 keeps the soundtrack as ambient mood without burying spell audio. Set to 0.0 if you prefer Spotify for background music. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_SOUND_AMBIENCE_OPT_0"] = "0.0 (off)" -- MT
L["GEMS_CVAR_SOUND_AMBIENCE_OPT_15"] = "0.15 (quiet)" -- MT
L["GEMS_CVAR_SOUND_AMBIENCE_OPT_30"] = "0.3 (recommended)" -- MT
L["GEMS_CVAR_SOUND_AMBIENCE_OPT_60"] = "0.6 (default)" -- MT
L["GEMS_CVAR_SOUND_AMBIENCE_OPT_100"] = "1.0 (max)" -- MT
L["GEMS_CVAR_SOUND_AMBIENCE_DESCLONG"] =
    "Zone ambience channel: waterfalls, wind, crowd noise, weather. EMS recommends 0.3 because at the Blizzard default 0.6 zone ambience often sits louder than combat audio during raid mechanics, especially in outdoor encounters with weather sound layers. 0.3 keeps the zone atmosphere readable without competing with mechanic cues. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_SOUND_DIALOG_OPT_50"] = "0.5 (quiet)" -- MT
L["GEMS_CVAR_SOUND_DIALOG_OPT_70"] = "0.7 (lower)" -- MT
L["GEMS_CVAR_SOUND_DIALOG_OPT_85"] = "0.85 (mid)" -- MT
L["GEMS_CVAR_SOUND_DIALOG_OPT_95"] = "0.95 (slightly soft)" -- MT
L["GEMS_CVAR_SOUND_DIALOG_OPT_100"] = "1.0 (default, recommended)" -- MT
L["GEMS_CVAR_SOUND_DIALOG_DESCLONG"] =
    "NPC dialogue and voice-over channel: questgiver speech, boss in-fight callouts, lore voice cues. Default 1.0 is correct because boss callouts often carry mechanic timing information you want clearly audible above music and ambience. Lower if you find quest-NPC chatter fatiguing during long levelling sessions. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_SOUND_BGAUDIO_OPT_0"] = "Off (default)" -- MT
L["GEMS_CVAR_SOUND_BGAUDIO_OPT_1"] = "On (recommended)" -- MT
L["GEMS_CVAR_SOUND_BGAUDIO_DESCLONG"] =
    "Keeps WoW audio running when the game window is in the background (Alt-Tab to browser, Discord, Spotify). EMS recommends 1 because the Blizzard default 0 silences the game the moment you tab out, which means you can miss queue pops, raid pulls, AH bid wars, and group invites while reading a guide in another window. Set to 0 if you specifically want WoW quiet when not focused (streaming with shared audio devices, sharing the room with someone working). This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_SOUND_ENCWARN_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_SOUND_ENCWARN_OPT_1"] = "On (default, recommended)" -- MT
L["GEMS_CVAR_SOUND_ENCWARN_DESCLONG"] =
    "In-game warning sounds for boss encounter callouts (the alarm tone that plays alongside a boss yell). Default 1 is correct because these sounds carry mechanic timing for fights where the visual on-screen text is easy to miss in raid chaos. Turn Off only if you use a third-party boss mod that plays its own warning audio and you want to avoid the doubled audio cue. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_SOUND_ENCVOL_OPT_50"] = "0.5 (quiet)" -- MT
L["GEMS_CVAR_SOUND_ENCVOL_OPT_70"] = "0.7 (lower)" -- MT
L["GEMS_CVAR_SOUND_ENCVOL_OPT_85"] = "0.85 (mid)" -- MT
L["GEMS_CVAR_SOUND_ENCVOL_OPT_95"] = "0.95 (slightly soft)" -- MT
L["GEMS_CVAR_SOUND_ENCVOL_OPT_100"] = "1.0 (default, recommended)" -- MT
L["GEMS_CVAR_SOUND_ENCVOL_DESCLONG"] =
    "Volume for the encounter warning sound channel above. Default 1.0 is the safe answer because boss warnings need to cut through music and combat SFX clearly. Lower only if you find the warning tone uncomfortably loud relative to the rest of the audio mix. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_SOUND_ERRSPEECH_OPT_0"] = "Off (recommended)" -- MT
L["GEMS_CVAR_SOUND_ERRSPEECH_OPT_1"] = "On (default)" -- MT
L["GEMS_CVAR_SOUND_ERRSPEECH_DESCLONG"] =
    "Spoken error voice lines from your character (the cannot-do-that-yet and not-enough-rage style audio). EMS recommends 0 because the on-screen red text already tells you the same information, the voice lines get repetitive in a long session (you hear the same six clips dozens of times), and many players find them immersion-breaking. Set to 1 if you specifically like the auditory cue distinct from reading the red text. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_SOUND_GAMEPLAY_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_SOUND_GAMEPLAY_OPT_1"] = "On (default, recommended)" -- MT
L["GEMS_CVAR_SOUND_GAMEPLAY_DESCLONG"] =
    "Gameplay-specific sound effects (separate from the SFXVolume channel) -- includes click feedback for action bar buttons and secondary UI sounds. Default 1 is correct because action bar clicks help confirm an input registered, especially during high-APM rotations. Turn Off only if you prefer fully silent action bar feedback. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT

-- CVar Section: Floating Combat Text
L["GEMS_CVAR_FCT_ENABLE"] = "浮动战斗文字" -- MT
L["GEMS_CVAR_FCT_ENABLE_DESC"] = "浮动战斗文字主开关。默认关闭!启用以查看伤害/治疗数字。" -- MT
L["GEMS_CVAR_FCT_DAMAGE"] = "伤害数字" -- MT
L["GEMS_CVAR_FCT_DAMAGE_DESC"] = "在敌方目标上显示伤害数字。" -- MT
L["GEMS_CVAR_FCT_AUTOS"] = "自动攻击数字" -- MT
L["GEMS_CVAR_FCT_AUTOS_DESC"] = "显示所有自动攻击数字(不仅是暴击/触发)。" -- MT
L["GEMS_CVAR_FCT_HEALING"] = "治疗数字" -- MT
L["GEMS_CVAR_FCT_HEALING_DESC"] = "在目标上显示治疗数字。" -- MT
L["GEMS_CVAR_FCT_ABSSELF"] = "自身吸收" -- MT
L["GEMS_CVAR_FCT_ABSSELF_DESC"] = "显示对自己应用的护盾/吸收数量。" -- MT
L["GEMS_CVAR_FCT_ABSTARGET"] = "目标吸收" -- MT
L["GEMS_CVAR_FCT_ABSTARGET_DESC"] = "显示对目标应用的护盾/吸收数量。" -- MT
L["GEMS_CVAR_FCT_PERIODIC"] = "周期伤害" -- MT
L["GEMS_CVAR_FCT_PERIODIC_DESC"] = "显示 DoT/HoT 节奏数字。" -- MT
L["GEMS_CVAR_FCT_DODGEMISS"] = "闪避/招架/未命中" -- MT
L["GEMS_CVAR_FCT_DODGEMISS_DESC"] = "显示闪避/招架/未命中文本。对查看能力被避免有用。" -- MT
L["GEMS_CVAR_FCT_LOWRES"] = "低资源警告" -- MT
L["GEMS_CVAR_FCT_LOWRES_DESC"] = "显示低法力/生命警告。" -- MT
L["GEMS_CVAR_FCT_FLOATMODE"] = "浮动方向" -- MT
L["GEMS_CVAR_FCT_FLOATMODE_DESC"] = "浮动方向。1=上,2=下,3=弧形。1(上)是标准。" -- MT
L["GEMS_CVAR_FCT_FLOATMODE_OPT_1"] = "Scroll Up" -- MT
L["GEMS_CVAR_FCT_FLOATMODE_OPT_2"] = "Scroll Down" -- MT
L["GEMS_CVAR_FCT_FLOATMODE_OPT_3"] = "Fountain" -- MT
L["GEMS_CVAR_FCT_FLOATMODE_DESCLONG"] =
    "Direction floating combat text travels from the engagement point. Scroll Up (1, recommended) rises from the target -- the long-standing default that players expect. Scroll Down (2) falls from the target -- some players prefer this for reduced overlap with target buffs above the unit. Fountain (3) arcs outward in a fountain pattern, a more visual style. All three values are documented Blizzard CVar settings; the in-engine fallback for any non-1/non-2 input is fountain." -- MT
L["GEMS_CVAR_FCT_DIRSCALE"] = "方向缩放" -- MT
L["GEMS_CVAR_FCT_DIRSCALE_DESC"] = "方向伤害数字移动缩放。0=无方向移动。1.0=默认。" -- MT
L["GEMS_CVAR_FCT_PETMELEE"] = "宠物近战伤害" -- MT
L["GEMS_CVAR_FCT_PETMELEE_DESC"] =
    "显示宠物近战伤害数字。对宠物职业宏(BM 猎人、毁灭术士)很重要。" -- MT
L["GEMS_CVAR_FCT_PETSPELL"] = "宠物法术伤害" -- MT
L["GEMS_CVAR_FCT_PETSPELL_DESC"] = "显示宠物法术伤害数字。" -- MT
L["GEMS_CVAR_FCT_REACTIVES"] = "反应触发" -- MT
L["GEMS_CVAR_FCT_REACTIVES_DESC"] =
    "显示反应能力触发(压制、复仇)。帮助发现宏序列应反应的触发。" -- MT
L["GEMS_CVAR_FCT_ENERGY"] = "能量获得" -- MT
L["GEMS_CVAR_FCT_ENERGY_DESC"] = "显示能量/怒气/法力获得数字。默认关闭 -- 可能非常垃圾邮件。" -- MT
L["GEMS_CVAR_FCT_AURAS"] = "增益/减益文字" -- MT
L["GEMS_CVAR_FCT_AURAS_DESC"] =
    "显示增益/减益应用文字。默认关闭 -- 在团队内容中非常垃圾邮件。" -- MT
L["GEMS_CVAR_FCT_HEALERS"] = "治疗者名称" -- MT
L["GEMS_CVAR_FCT_HEALERS_DESC"] = "显示治疗你的治疗者名称。" -- MT

-- CVar Section: Accessibility
L["GEMS_CVAR_ACCESS_COLORBLIND"] = "色盲模式" -- MT
L["GEMS_CVAR_ACCESS_COLORBLIND_DESC"] =
    "Colourblind mode. Adds colourblind-friendly text labels to tooltips and other interfaces." -- MT
L["GEMS_CVAR_ACCESS_CENTERED"] = "保持居中" -- MT
L["GEMS_CVAR_ACCESS_CENTERED_DESC"] = "将角色头部保持在屏幕中心作为运动参考点。减少晕动症。" -- MT
L["GEMS_CVAR_ACCESS_REDUCEMOVE"] = "减少移动" -- MT
L["GEMS_CVAR_ACCESS_REDUCEMOVE_DESC"] = "减少自动镜头移动。帮助晕动症但可能感觉无响应。" -- MT
L["GEMS_CVAR_ACCESS_FOCAL"] = "焦点圆" -- MT
L["GEMS_CVAR_ACCESS_FOCAL_DESC"] = "骑乘时显示焦点圆。在快速移动时减少晕动症。" -- MT
L["GEMS_CVAR_ACCESS_TEXTCONTRAST"] = "任务文字对比度" -- MT
L["GEMS_CVAR_ACCESS_TEXTCONTRAST_DESC"] = "增加任务 UI 中的文字对比度。帮助可读性。" -- MT
L["GEMS_CVAR_ACCESS_COLORBLIND_OPT_0"] = "Off (default, recommended)" -- MT
L["GEMS_CVAR_ACCESS_COLORBLIND_OPT_1"] = "On (colourblind accessibility)" -- MT
L["GEMS_CVAR_ACCESS_COLORBLIND_DESCLONG"] =
    "Enables colourblind accessibility features across the WoW UI. Default 0 (Off) is the safe baseline for non-colourblind players. Set to 1 if you have any form of colour vision deficiency -- this adds gold/silver/copper text labels next to coin icons, debuff type prefixes on aura tooltips, talent button icons that do not rely solely on colour, gem colour text in the socketing UI, mail error text without coin-colour indicators, and many other accessibility helpers. EMS does not auto-detect your accessibility needs; pick the value that matches your vision. (The Protanopia/Deuteranopia/Tritanopia screen filter is the separate Colourblind Filter row below.)" -- MT
L["GEMS_CVAR_ACCESS_CENTERED_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_ACCESS_CENTERED_OPT_1"] = "On (default, recommended)" -- MT
L["GEMS_CVAR_ACCESS_CENTERED_DESCLONG"] =
    "Motion-sickness control: keeps your character's head fixed at the centre of the screen as a stable reference point, reducing the visual drift sensation during fast camera movement. Default 1 (On) is the right answer for almost every player because the stable head anchor helps with motion sickness during dragonriding, fast camera turns, and mounted travel. Set to 0 if you specifically prefer the unanchored cinematic camera and have no motion-sickness sensitivity." -- MT
L["GEMS_CVAR_ACCESS_REDUCEMOVE_OPT_0"] = "Off (default, recommended)" -- MT
L["GEMS_CVAR_ACCESS_REDUCEMOVE_OPT_1"] = "On (motion-sickness mode)" -- MT
L["GEMS_CVAR_ACCESS_REDUCEMOVE_DESCLONG"] =
    "Motion-sickness control: reduces camera movement that happens without your direct input (autocamera adjustments during combat, terrain bumps, ledge edges). Default 0 (Off) is the baseline because the autocamera adjustments are usually helpful for tracking action. Set to 1 if you experience motion sickness from camera-without-input movements -- this is often paired with CameraKeepCharacterCentered=1 for full motion-sickness accommodation." -- MT
L["GEMS_CVAR_ACCESS_FOCAL_OPT_0"] = "Off (default, recommended)" -- MT
L["GEMS_CVAR_ACCESS_FOCAL_OPT_1"] = "On (focal point while mounted)" -- MT
L["GEMS_CVAR_ACCESS_FOCAL_DESCLONG"] =
    "Motion-sickness control: shows a small visual focal circle in the centre of your screen while mounted to give your eyes a fixed point to focus on. Default 0 (Off) is the baseline. Set to 1 if you experience motion sickness during mount travel or Skyriding flights -- a static focal point reduces the brain's confusion when the world rushes past." -- MT
L["GEMS_CVAR_ACCESS_TEXTCONTRAST_OPT_0"] = "Off (default, recommended)" -- MT
L["GEMS_CVAR_ACCESS_TEXTCONTRAST_OPT_1"] = "On (high contrast quest UI)" -- MT
L["GEMS_CVAR_ACCESS_TEXTCONTRAST_DESCLONG"] =
    "Increases the contrast of text in quest UI windows (questgiver dialogues, quest log details, objective tracker). Default 0 (Off) preserves the standard parchment-style appearance. Set to 1 if you find quest text difficult to read against the textured backgrounds -- the high-contrast mode darkens the parchment and brightens the text. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_DRAGON_DYNFOV"] = "动态视野" -- MT
L["GEMS_CVAR_DRAGON_DYNFOV_DESC"] = "基于滑翔速度的动态视野。创造速度感。如有晕动症请禁用。" -- MT
L["GEMS_CVAR_DRAGON_MAXPITCH"] = "最大俯仰速率" -- MT
L["GEMS_CVAR_DRAGON_MAXPITCH_DESC"] =
    "键盘驭龙术的最大俯仰速率。默认 5 可能感觉缓慢。6-7 响应更灵敏。" -- MT
L["GEMS_CVAR_DRAGON_MAXTURN"] = "最大转弯速率" -- MT
L["GEMS_CVAR_DRAGON_MAXTURN_DESC"] =
    "键盘驭龙术的最大转弯速率。默认 8 可能感觉慢。10 改善机动性。" -- MT
L["GEMS_CVAR_DRAGON_MINPITCH"] = "最小俯仰速率" -- MT
L["GEMS_CVAR_DRAGON_MINPITCH_DESC"] = "最小俯仰速率。影响精细俯仰控制。略高给出更精确控制。" -- MT
L["GEMS_CVAR_DRAGON_PITCHCTRL"] = "俯仰控制模式" -- MT
L["GEMS_CVAR_DRAGON_PITCHCTRL_DESC"] = "前/后输入如何影响俯仰。3=切换。键盘玩家最舒适。" -- MT

-- Comparison Frame (v1.2.0 S04-B)
L["GEMS_IMPORT_COMPARE"] = "比较" -- MT
L["GEMS_UI_COMPARE_WITH"] = "比较..." -- MT
L["GEMS_COMPARE_TITLE"] = "序列比较" -- MT
L["GEMS_COMPARE_LEFT_LABEL"] = "现有" -- MT
L["GEMS_COMPARE_RIGHT_LABEL"] = "传入" -- MT
L["GEMS_COMPARE_STEPS"] = "%d 步骤" -- MT
L["GEMS_COMPARE_NO_STEPS"] = "无步骤" -- MT
L["GEMS_COMPARE_CLOSE_DESC"] = "关闭比较视图" -- MT

-- Sequence autocomplete (v1.2.0 S07b)
L["GEMS_AUTOCOMPLETE_SEQUENCES"] = "序列" -- MT
L["GEMS_AUTOCOMPLETE_CLICK_INSERT"] = "/click GRIPEMS_%s" -- MT

-- Popup Editor (v1.2.0 S07a)
L["GEMS_UI_OPEN_NEW_WINDOW"] = "在新窗口中打开" -- MT
L["GEMS_UI_POPUP_TITLE"] = "GRIP-EMS 编辑器" -- MT
L["GEMS_UI_POPUP_CLOSE_DIRTY"] = "此编辑器有未保存的更改。\n关闭前保存吗?" -- MT
L["GEMS_UI_POPUP_MAX_REACHED"] = "已达到编辑器窗口限制(%d)。" -- MT

-- Editor Colours (v1.2.0 S08a)
L["GEMS_SETTINGS_EDITOR_COLOURS"] = "编辑器颜色" -- MT
L["GEMS_SETTINGS_SYNTAX_COMMAND"] = "斜杠命令" -- MT
L["GEMS_SETTINGS_SYNTAX_COMMAND_DESC"] = "用于斜杠命令(如 /cast、/use 和 /click)的颜色。" -- MT
L["GEMS_SETTINGS_SYNTAX_CONDITIONAL"] = "条件" -- MT
L["GEMS_SETTINGS_SYNTAX_CONDITIONAL_DESC"] = "用于宏条件(如 [mod:shift] 或 [talent:X])的颜色。" -- MT
L["GEMS_SETTINGS_SYNTAX_VARIABLE"] = "变量" -- MT
L["GEMS_SETTINGS_SYNTAX_VARIABLE_DESC"] = "用于写为 ~name~ 的宏序列变量的颜色。" -- MT
L["GEMS_SETTINGS_SYNTAX_COMMENT"] = "注释" -- MT
L["GEMS_SETTINGS_SYNTAX_COMMENT_DESC"] = "用于以两个短划线开头的注释行的颜色。" -- MT
L["GEMS_SETTINGS_SYNTAX_RESET"] = "重置条件" -- MT
L["GEMS_SETTINGS_SYNTAX_RESET_DESC"] = "用于重置规则(如 reset=target、reset=combat 或 reset=5)的颜色。" -- MT
L["GEMS_SETTINGS_SYNTAX_NUMBER"] = "数字" -- MT
L["GEMS_SETTINGS_SYNTAX_NUMBER_DESC"] = "宏文本中数字的颜色。" -- MT

-- Floating Menu (v1.2.0 S09a)
L["GEMS_FLOATING_HEADER"] = "浮动菜单" -- MT
L["GEMS_FLOATING_SHOW_DESC"] = "在屏幕上显示浮动快捷访问菜单。" -- MT
L["GEMS_FLOATING_DIRECTION_DESC"] = "菜单按钮从主按钮打开的方向。" -- MT
L["GEMS_FLOATING_LOCK_DESC"] = "锁定浮动菜单,使其无法拖动。" -- MT
L["GEMS_FLOATING_SCALE_DESC"] = "更改浮动菜单的整体大小。" -- MT
L["GEMS_FLOATING_LOCKED"] = "浮动菜单已锁定。" -- MT
L["GEMS_FLOATING_UNLOCKED"] = "浮动菜单已解锁。" -- MT
L["GEMS_FLOATING_BTN_SEQUENCES"] = "序列" -- MT
L["GEMS_FLOATING_BTN_IMPORT"] = "导入" -- MT
L["GEMS_FLOATING_BTN_EXPORT"] = "导出" -- MT
L["GEMS_FLOATING_BTN_VARIABLES"] = "变量" -- MT
L["GEMS_FLOATING_BTN_TRACKER"] = "追踪器" -- MT
L["GEMS_FLOATING_BTN_OPTIONS"] = "选项" -- MT
L["GEMS_FLOATING_BTN_COLLAPSE"] = "折叠" -- MT
L["GEMS_FLOATING_BTN_EXPAND"] = "展开" -- MT
L["GEMS_FLOATING_BTN_CLOSE"] = "关闭" -- MT
L["GEMS_FLOATING_DIR_UP"] = "向上" -- MT
L["GEMS_FLOATING_DIR_DOWN"] = "向下" -- MT
L["GEMS_FLOATING_DIR_LEFT"] = "向左" -- MT
L["GEMS_FLOATING_DIR_RIGHT"] = "向右" -- MT
L["GEMS_HELP_MENU"] = "  /gems menu - 切换浮动菜单栏" -- MT

-- Support tab (v1.2.0 S10-B)
L["GEMS_SETTINGS_SUPPORT"] = "支持" -- MT
L["GEMS_SUPPORT_CREDITS"] = "由 Sataana (MrSataana / JesperLive) 创建" -- MT
L["GEMS_SUPPORT_DISCORD"] = "Discord:discord.gg/temptingus" -- MT
L["GEMS_SUPPORT_SYSTEM_HEADER"] = "系统信息" -- MT
L["GEMS_SUPPORT_CREDITS_HEADER"] = "致谢" -- MT
L["GEMS_SUPPORT_DISCORD_HEADER"] = "社区" -- MT
L["GEMS_HELP_COMPRESS"] = "  /gems compress <name> - 编码序列(开发)" -- MT
L["GEMS_HELP_DECOMPRESS"] = "  /gems decompress <string> - 解码字符串(开发)" -- MT

-- Remote Browser (v1.2.0 S13b)
L["GEMS_UI_REMOTE_BROWSER_TITLE"] = "远程宏浏览器" -- MT
L["GEMS_UI_REMOTE_PLAYERS_HEADER"] = "拥有 EMS 的玩家" -- MT
L["GEMS_UI_REMOTE_REFRESH"] = "刷新" -- MT
L["GEMS_UI_REMOTE_SEQUENCES_FROM"] = "来自 %s 的序列" -- MT
L["GEMS_UI_REMOTE_WAITING"] = "正在等待响应..." -- MT
L["GEMS_UI_REMOTE_NO_PLAYERS"] = "未找到 EMS 用户。加入小队以发现玩家。" -- MT
L["GEMS_UI_REMOTE_NO_SEQUENCES"] = "此玩家没有可用的序列。" -- MT
L["GEMS_UI_REMOTE_IMPORT"] = "导入" -- MT
L["GEMS_UI_REMOTE_REQUEST_SENT"] = "已请求 %s 来自 %s" -- MT
L["GEMS_UI_REMOTE_LIST_RECEIVED"] = "已从 %s 接收序列列表(%d 个序列)" -- MT
L["GEMS_HELP_BROWSE"] = "  /gems browse - 打开远程序列浏览器" -- MT
L["GEMS_BROWSE_REFRESH_DESC"] = "刷新队伍成员及其序列列表" -- MT
L["GEMS_BROWSE_IMPORT_DESC"] = "将此序列导入到你的库" -- MT
L["GEMS_BROWSE_CLOSE_DESC"] = "关闭浏览器" -- MT

-- Recorder
L["GEMS_UI_RECORD"] = "录制" -- MT
L["GEMS_UI_RECORDING"] = "正在录制..." -- MT
L["GEMS_UI_RECORDING_COUNT"] = "正在录制(%d)" -- MT
L["GEMS_RECORDER_MAX_REACHED"] = "录制已停止:已达到步骤限制。" -- MT
L["GEMS_RECORDER_STARTED"] = "宏录制器:已开始。" -- MT
L["GEMS_RECORDER_STOPPED"] = "录制已停止:已捕获 %d 个法术。" -- MT
L["GEMS_RECORDER_UNAVAILABLE"] = "宏录制器不可用。" -- MT
L["GEMS_RECORDER_CREATE_CONFIRM"] = "录制已捕获 %d 个法术。从此录制创建新序列?" -- MT
L["GEMS_RECORDER_CREATE_YES"] = "创建序列" -- MT
L["GEMS_RECORDER_CREATE_NO"] = "丢弃" -- MT
L["GEMS_RECORDER_EMPTY"] = "未录制任何法术。" -- MT
L["GEMS_SETTINGS_RECORDER_HEADER"] = "录制器" -- MT
L["GEMS_SETTINGS_RECORDER_DEDUP"] = "将重复施法合并为一个步骤" -- MT
L["GEMS_SETTINGS_RECORDER_DEDUP_DESC"] = "开启时,录制器将连续相同法术的施法合并为一个步骤。" -- MT

-- Spell Cache Viewer (v1.2.0 S16)
L["GEMS_SPELLCACHE_TITLE"] = "法术缓存" -- MT
L["GEMS_SPELLCACHE_TAB_SPELLS"] = "法术" -- MT
L["GEMS_SPELLCACHE_TAB_ITEMS"] = "物品" -- MT
L["GEMS_SPELLCACHE_TAB_TOYS"] = "玩具" -- MT
L["GEMS_SPELLCACHE_SEARCH"] = "搜索..." -- MT
L["GEMS_SPELLCACHE_REFRESH"] = "刷新" -- MT
L["GEMS_SPELLCACHE_CLEAR_OVERRIDES"] = "清除覆盖" -- MT
L["GEMS_SPELLCACHE_CLEAR_CONFIRM"] = "移除所有法术名称覆盖?此操作无法撤销。" -- MT
L["GEMS_SPELLCACHE_SHOWING"] = "显示 %d / %d" -- MT
L["GEMS_SPELLCACHE_SCANNING"] = "正在扫描..." -- MT
L["GEMS_SPELLCACHE_NOT_AVAILABLE"] = "法术缓存查看器不可用。" -- MT
L["GEMS_SPELLCACHE_OVERRIDE_CLEARED"] = "法术名称覆盖已清除。" -- MT
L["GEMS_HELP_SPELLCACHE"] = "|cFF00CC66/gems spellcache|r -- 打开法术缓存查看器" -- MT
L["GEMS_HELP_MAPINFO"] = "|cFF00CC66/gems mapinfo|r -- 显示当前地图/副本 ID" -- MT

-- Inline string localization (v1.2.0 S22-D)
L["GEMS_UI_STUB_PREVIEW"] = "宏存根预览" -- MT
L["GEMS_UI_EMPTY_HINT"] = "导入或创建序列开始" -- MT
L["GEMS_UI_KEYBIND_TOOLTIP"] = "按键绑定:%s" -- MT

-- Vehicle / Pet Battle Keybinds (v1.2.0 S23)
L["GEMS_VEHICLE_KEYBINDS_HEADER"] = "载具/覆盖条按键绑定" -- MT
L["GEMS_PET_BATTLE_KEYBINDS_HEADER"] = "宠物对战按键绑定" -- MT
L["GEMS_VEHICLE_SLOT"] = "槽位 %d" -- MT
L["GEMS_VEHICLE_KEYBINDS_APPLIED"] = "载具按键绑定已应用:%d 个绑定" -- MT
L["GEMS_VEHICLE_KEYBINDS_CLEARED"] = "载具按键绑定已清除" -- MT
L["GEMS_PET_BATTLE_KEYBINDS_APPLIED"] = "宠物对战按键绑定已应用:%d 个绑定" -- MT
L["GEMS_PET_BATTLE_KEYBINDS_CLEARED"] = "宠物对战按键绑定已清除" -- MT
L["GEMS_PET_BATTLE_ABILITY"] = "能力 %d" -- MT
L["GEMS_PET_BATTLE_SWAP"] = "切换宠物" -- MT
L["GEMS_PET_BATTLE_PASS"] = "跳过回合" -- MT
L["GEMS_PET_BATTLE_FORFEIT"] = "认输" -- MT
L["GEMS_BAR_INTEGRATION_HEADER"] = "动作条集成" -- MT
L["GEMS_BAR_INTEGRATION_DESC"] = "在持有序列的动作条按钮上显示序列图标。" -- MT
L["GEMS_BAR_INTEGRATION_TRACKED"] = "动作条集成:已追踪 %d 个按钮(%s)" -- MT
L["GEMS_UI_NOT_BOUND"] = "未绑定" -- MT

-- Feature: Click Rate Diagnostics (/gems diag)
L["GEMS_DIAG_HEADER"] = "--- 执行诊断 ---" -- MT
L["GEMS_DIAG_CPS"] = "实时 CPS:%.1f" -- MT
L["GEMS_DIAG_CONFIGURED"] = "配置点击速率:%d 毫秒(生效)" -- MT
L["GEMS_DIAG_TOTAL"] = "已追踪施法总数:%d" -- MT
L["GEMS_DIAG_TRACER"] = "追踪器:%s" -- MT
L["GEMS_DIAG_TRACER_ON"] = "活动" -- MT
L["GEMS_DIAG_TRACER_OFF"] = "未激活" -- MT
L["GEMS_DIAG_TOP_SPELLS"] = "热门法术:" -- MT
L["GEMS_DIAG_SPELL_ROW"] = "  %d. %s (ID: %d) -- %d 次施法" -- MT
L["GEMS_DIAG_NO_DATA"] = "暂无施法数据。请先使用序列。" -- MT
L["GEMS_HELP_DIAG"] = "显示执行诊断(CPS、热门法术)" -- MT
L["GEMS_HELP_MEMCHECK"] = "内存诊断(GC、表大小、堆)" -- MT
L["GEMS_HELP_PERF"] = "性能分析(OnUpdate、帧、计时)" -- MT
L["GEMS_HELP_MONITOR"] = "300 帧连续分析器(挂钩关键函数)" -- MT

-- Feature: Optimal MS Advisor (/gems msadvisor)
L["GEMS_MSADVISOR_HEADER"] = "--- MS 顾问%s ---" -- MT
L["GEMS_MSADVISOR_GCD"] = "基础 GCD:%d 毫秒(%.1f%% 急速)" -- MT
L["GEMS_MSADVISOR_LAG"] = "世界延迟:%d 毫秒" -- MT
L["GEMS_MSADVISOR_SQW"] = "法术队列窗口:%d 毫秒" -- MT
L["GEMS_MSADVISOR_RECOMMEND"] = "推荐点击速率:%d 毫秒" -- MT
L["GEMS_MSADVISOR_CURRENT"] = "当前配置:%d 毫秒" -- MT
L["GEMS_MSADVISOR_DELTA"] = "差异:%+d 毫秒(%s)" -- MT
L["GEMS_MSADVISOR_FASTER"] = "你可以点击得更快" -- MT
L["GEMS_MSADVISOR_SLOWER"] = "你的点击速度超过了 GCD 允许范围" -- MT
L["GEMS_MSADVISOR_GOOD"] = "匹配良好" -- MT
L["GEMS_MSADVISOR_ROTATION"] = "序列 '%s':%d 步骤,完整循环约 %d 毫秒" -- MT
L["GEMS_MSADVISOR_NOT_FOUND"] = "未找到序列 '%s'。" -- MT
L["GEMS_HELP_MSADVISOR"] = "基于急速推荐最佳点击速率" -- MT

-- Feature: Dormant Sequence Lazy Loading
L["GEMS_DORMANT_LOADED"] = "  %d 个序列加载为休眠(不同职业)" -- MT
L["GEMS_DORMANT_LABEL"] = "(休眠)" -- MT
L["GEMS_HELP_LOADCLASS"] = "为职业 ID 激活休眠序列" -- MT
L["GEMS_HELP_REPAIR"] = "/gems repair <name> -- 分析并修复序列" -- MT
L["GEMS_HELP_REPAIRALL"] = "/gems repairall -- 分析并修复所有序列" -- MT
L["GEMS_HELP_RECORD"] = "/gems record -- 切换宏录制器(将法术捕获到序列中)。" -- MT
L["GEMS_HELP_TRACE"] = "/gems trace [on|off|status] -- 切换执行追踪器。" -- MT
L["GEMS_HELP_RESETUI"] = "/gems resetui -- 将窗口重置为默认大小和位置" -- MT
L["GEMS_RESETUI_DONE"] = "UI 已重置为默认大小和位置。" -- MT
L["GEMS_LOADCLASS_ALREADY"] = "职业 %d 序列已加载。" -- MT
L["GEMS_LOADCLASS_DONE"] = "已为职业 %d 激活 %d 个休眠序列。" -- MT
L["GEMS_LOADCLASS_USAGE"] = "用法: /gems loadclass <classID> (1=战士, 2=圣骑士, ...)" -- MT
L["GEMS_UI_ACTIVATE"] = "激活" -- MT

-- Feature: Raw Macrotext Import
L["GEMS_RAWIMPORT_DETECTED"] = "找到原始宏文本。正在解析 %d 行..." -- MT
L["GEMS_RAWIMPORT_RESULT"] = "已从原始宏文本解析 %d 个步骤。" -- MT
L["GEMS_RAWIMPORT_NAME"] = "已导入宏" -- MT
L["GEMS_RAWIMPORT_NO_SPELLS"] = "粘贴的文本中未找到可施法的行。" -- MT

-- Feature: Step Spell Picker
L["GEMS_SPELLPICKER_TITLE"] = "法术选择器" -- MT
L["GEMS_SPELLPICKER_SEARCH"] = "搜索法术..." -- MT
L["GEMS_SPELLPICKER_ALL"] = "全部" -- MT
L["GEMS_SPELLPICKER_CLASS"] = "职业" -- MT
L["GEMS_SPELLPICKER_PET"] = "宠物能力" -- MT
L["GEMS_SPELLPICKER_ITEMS"] = "物品" -- MT
L["GEMS_SPELLPICKER_GEAR"] = "装备" -- MT
L["GEMS_SPELLPICKER_CONSUMABLES"] = "消耗品" -- MT
L["GEMS_SPELLPICKER_TOYS"] = "玩具" -- MT
L["GEMS_SPELLPICKER_SPEC"] = "专精" -- MT
L["GEMS_SPELLPICKER_RACE"] = "种族" -- MT
L["GEMS_SPELLPICKER_GENERAL"] = "通用" -- MT
L["GEMS_SPELLPICKER_PROF"] = "专业" -- MT
L["GEMS_SPELLPICKER_OTHER"] = "其他" -- MT
L["GEMS_SPELLPICKER_MOUNTS"] = "坐骑" -- MT
L["GEMS_SPELLPICKER_COMPANIONS"] = "宠物" -- MT
L["GEMS_SPELLPICKER_CONDITIONALS"] = "条件" -- MT
L["GEMS_SPELLPICKER_CUSTOM"] = "自定义:" -- MT
L["GEMS_SPELLPICKER_INSERT"] = "插入" -- MT
L["GEMS_SPELLPICKER_NO_RESULTS"] = "无匹配的法术" -- MT
L["GEMS_SPELLPICKER_FAVORITES"] = "收藏" -- MT
L["GEMS_SPELLPICKER_WARBANK_NOTE"] = "战团银行物品仅在银行可见" -- MT
L["GEMS_SPELLPICKER_MACROS"] = "宏" -- MT
L["GEMS_SPELLPICKER_SLASH"] = "斜杠" -- MT
L["GEMS_HELP_SPELLPICKER"] = "点击任一步骤的图标按钮打开法术选择器。" -- MT

-- Feature: Gear-Aware Variables
L["GEMS_GEAR_VAR_HEADER"] = "装备变量(自动检测的使用效果):" -- MT
L["GEMS_GEAR_VAR_ROW"] = "  ~%s~ = %s" -- MT
L["GEMS_GEAR_VAR_NONE"] = "未检测到已装备的使用效果。" -- MT
L["GEMS_GEAR_VAR_UPDATED"] = "装备变量已更新(检测到 %d 个使用效果)。" -- MT

-- Feature: CVar Profiles & Context-Aware Switching (Phase 2)
L["GEMS_CVAR_PROFILE_GENERAL"] = "通用(默认)" -- MT
L["GEMS_CVAR_PROFILE_RAID"] = "团队副本" -- MT
L["GEMS_CVAR_PROFILE_RAID_DESC"] = "为团队遭遇调整:更短的姓名板范围,堆叠的姓名板布局。" -- MT
L["GEMS_CVAR_PROFILE_MPLUS"] = "史诗钥石" -- MT
L["GEMS_CVAR_PROFILE_MPLUS_DESC"] = "为史诗钥石地下城调整:开启敌方仆从姓名板,更短范围。" -- MT
L["GEMS_CVAR_PROFILE_SOLO"] = "单人/开放世界" -- MT
L["GEMS_CVAR_PROFILE_SOLO_DESC"] = "为单人内容调整:完整视觉,更宽互动弧,姓名板关闭。" -- MT
L["GEMS_CVAR_PROFILE_DELVES"] = "深岩洞穴" -- MT
L["GEMS_CVAR_PROFILE_DELVES_DESC"] =
    "Tuned for Delves: enemy minion nameplates on, shorter nameplate range, wider interact arc." -- MT
L["GEMS_CVAR_PROFILE_PVP"] = "PvP" -- MT
L["GEMS_CVAR_PROFILE_PVP_DESC"] =
    "为 PvP 调整:友方姓名板开启,敌方仆从姓名板开启,堆叠姓名板布局。" -- MT
L["GEMS_CVAR_PROFILE_ACTIVE"] = "活动配置文件:%s" -- MT
L["GEMS_CVAR_PROFILE_SELECT"] = "选择配置文件" -- MT
L["GEMS_CVAR_PROFILE_AUTO"] = "自动(基于上下文)" -- MT
L["GEMS_CVAR_PROFILE_AUTOSWITCH"] = "按上下文自动切换" -- MT
L["GEMS_CVAR_PROFILE_AUTOSWITCH_DESC"] =
    "进入团队副本、地下城、PvP 比赛或开放世界时为你切换 CVar 配置文件。" -- MT
L["GEMS_CVAR_PROFILE_MANAGE"] = "管理配置文件..." -- MT
L["GEMS_CVAR_PROFILE_MANAGE_DESC"] = "创建并管理带有每个 CVar 覆盖的自定义 CVar 配置文件。" -- MT
L["GEMS_CVAR_PROFILE_CREATE"] = "创建配置文件" -- MT
L["GEMS_CVAR_PROFILE_CREATE_NAME"] = "配置文件名称:" -- MT
L["GEMS_CVAR_PROFILE_CLONE_FROM"] = "克隆自:" -- MT
L["GEMS_CVAR_PROFILE_DELETE"] = "删除配置文件" -- MT
L["GEMS_CVAR_PROFILE_DELETE_CONFIRM"] = '删除自定义配置文件 "%s"?此操作无法撤销。' -- MT
L["GEMS_CVAR_PROFILE_OVERRIDE"] = "配置文件覆盖" -- MT
L["GEMS_CVAR_PROFILE_OVERRIDE_NONE"] = "无覆盖(使用通用)" -- MT
L["GEMS_CVAR_PROFILE_ADD_OVERRIDE"] = "添加覆盖..." -- MT
L["GEMS_CVAR_PROFILE_SWITCHED"] = "CVar 配置文件已切换到:%s" -- MT
L["GEMS_CVAR_PROFILE_QUEUED"] = "%d 个安全 CVar 已排队(战斗外应用)" -- MT
L["GEMS_CVAR_CHANGES_DETECTED"] = "自上次会话以来 %d 个 CVar 已变更" -- MT
L["GEMS_CVAR_CHANGES_INSESSION"] = "本次会话中 %d 个 CVar 已变更" -- MT
L["GEMS_CVAR_SESSION_NOTICE"] = "通知本次会话中的 CVar 变更" -- TODO: MT 2026-06-20
L["GEMS_CVAR_SESSION_NOTICE_DESC"] =
    "开启后，EMS 会为本次会话中每个发生变更的 CVar 输出一行聊天信息，并标明变更来源。默认关闭；可随时使用 /gems cvar changes 查看。" -- TODO: MT 2026-06-20
L["GEMS_CVAR_NOTICE_TOGGLED"] = "CVar 会话通知：%s" -- TODO: MT 2026-06-20
L["GEMS_CVAR_CHANGES_DISMISS"] = "忽略" -- MT
L["GEMS_CVAR_CHANGES_FIX_ALL"] = "修复所有变更" -- MT
L["GEMS_CVAR_CHANGES_CAUSE_PATCH"] = "可能:游戏补丁重置" -- MT
L["GEMS_CVAR_CHANGES_CAUSE_ADDON"] = "可能:由插件/UI 更改" -- MT
L["GEMS_CVAR_CHANGES_CAUSE_AUTOFIX"] = "由 EMS 自动修复" -- MT
L["GEMS_CVAR_CHANGES_CAUSE_PROFILE"] = "Profile swap" -- MT
L["GEMS_CVAR_CHANGES_CAUSE_UNKNOWN"] = "自上次会话以来变更" -- MT
L["GEMS_CVAR_CHANGES_BULK_SUMMARY"] = "%d CVars %s -- open /gems options -> CVar Health to review" -- MT
L["GEMS_CVAR_PROFILE_NOT_FOUND"] = "未知配置文件:%s" -- MT
L["GEMS_CVAR_AUTO_TOGGLED"] = "CVar 自动切换:%s" -- MT
L["GEMS_CVAR_NO_CHANGES"] = "自上次会话以来未检测到 CVar 变更" -- MT
L["GEMS_CVAR_PROFILE_RENAME"] = "重命名" -- MT
L["GEMS_CVAR_PROFILE_OVERRIDES"] = "覆盖(%d)" -- MT
L["GEMS_CVAR_PROFILE_NO_OVERRIDES"] = "无覆盖" -- MT
L["GEMS_CVAR_PROFILE_TRIGGERED_BY"] = "由以下触发:%s" -- MT
L["GEMS_CVAR_PROFILE_TRIGGER_MANUAL"] = "手动选择" -- MT
L["GEMS_CVAR_PROFILE_TRIGGER_AUTO"] = "自动切换(%s)" -- MT
L["GEMS_CVAR_PROFILE_TRIGGER_AUTO_NO_CONTEXT"] = "自动切换(无活动上下文)" -- MT
L["GEMS_CVAR_PROFILE_TRIGGER_DISABLED"] = "自动切换关闭(保留上次选择)" -- MT

-- Profile Diff (G19)
L["GEMS_CVAR_DIFF_TAB"] = "比较配置文件" -- MT
L["GEMS_CVAR_DIFF_DESC"] =
    "选择两个配置文件查看它们覆盖了哪些 CVar 以及差异。颜色编码:红色表示两个配置文件用不同值覆盖该 CVar,黄色表示只有一个配置文件覆盖,绿色表示两个用相同值覆盖。" -- MT
L["GEMS_CVAR_DIFF_LEFT"] = "左侧配置文件" -- MT
L["GEMS_CVAR_DIFF_RIGHT"] = "右侧配置文件" -- MT
L["GEMS_CVAR_DIFF_SHOW_DIFFS_ONLY"] = "仅显示差异" -- MT
L["GEMS_CVAR_DIFF_HEADER"] = "比较 %s 与 %s:" -- MT
L["GEMS_CVAR_DIFF_NO_DIFFERENCES"] = "无可比较的覆盖。选择两个带自定义 CVar 值的配置文件。" -- MT
L["GEMS_CVAR_DIFF_LEFT_ONLY"] = "%s:%s | (无)" -- MT
L["GEMS_CVAR_DIFF_RIGHT_ONLY"] = "%s:(无) | %s" -- MT
L["GEMS_CVAR_DIFF_BOTH_DIFFER"] = "%s:%s | %s" -- MT
L["GEMS_CVAR_DIFF_BOTH_SAME"] = "%s:%s" -- MT

-- Profile Export/Import (G20)
L["GEMS_CVAR_PROFILE_EXPORT"] = "导出" -- MT
L["GEMS_CVAR_PROFILE_EXPORT_DESC"] =
    "为此配置文件生成粘贴字符串。与其他角色或玩家分享以复制覆盖集。" -- MT
L["GEMS_CVAR_PROFILE_EXPORT_RESULT"] =
    "%s 的导出字符串。按 Ctrl+C 复制,然后粘贴到其他角色的导入框。" -- MT
L["GEMS_CVAR_PROFILE_EXPORT_ERROR_NOT_FOUND"] = "未找到配置文件。" -- MT
L["GEMS_CVAR_PROFILE_IMPORT"] = "导入配置文件" -- MT
L["GEMS_CVAR_PROFILE_IMPORT_DESC"] =
    "粘贴来自其他角色的导出字符串以将其添加为新自定义配置文件。" -- MT
L["GEMS_CVAR_PROFILE_IMPORT_INPUT"] = "粘贴导出字符串" -- MT
L["GEMS_CVAR_PROFILE_IMPORT_LABEL"] = "新配置文件名称(可选)" -- MT
L["GEMS_CVAR_PROFILE_IMPORT_LABEL_DESC"] =
    "覆盖导入的配置文件名称。留空使用导出字符串中嵌入的名称。" -- MT
L["GEMS_CVAR_PROFILE_IMPORT_BUTTON"] = "导入" -- MT
L["GEMS_CVAR_PROFILE_IMPORT_SUCCESS"] = "GEMS:已导入配置文件 %s,%d 个覆盖。" -- MT
L["GEMS_CVAR_PROFILE_IMPORT_ERROR"] = "GEMS:导入失败:%s" -- MT
L["GEMS_CVAR_PROFILE_IMPORT_ERROR_FORMAT"] = "空或无效输入。" -- MT
L["GEMS_CVAR_PROFILE_IMPORT_ERROR_DECODE"] = "解码失败 -- 不是 GEMSCP1 导出字符串。" -- MT
L["GEMS_CVAR_PROFILE_IMPORT_ERROR_PAYLOAD"] = "导出负载格式错误或不支持的版本。" -- MT

L["GEMS_CVAR_MAP_HEADER"] = "上下文配置文件映射" -- MT
L["GEMS_CVAR_MAP_DESC"] = "选择每个上下文应用哪个 CVar 配置文件" -- MT
L["GEMS_CVAR_MAP_DEFAULT"] = "默认 (%s)" -- MT
L["GEMS_CVAR_MAP_NONE"] = "通用(无配置文件)" -- MT

-- SQW Optimizer
L["GEMS_SQW_OPTIMIZER"] = "动态 SQW 优化器" -- MT
L["GEMS_SQW_OPTIMIZER_LINK"] = "启用时,这会自动管理宏序列部分中的 SpellQueueWindow CVar。" -- MT
L["GEMS_SQW_OPTIMIZER_DESC"] = "基于网络延迟自动设置法术队列窗口(SQW)。" -- MT
L["GEMS_SQW_BUFFER"] = "安全缓冲(毫秒)" -- MT
L["GEMS_SQW_BUFFER_DESC"] =
    "添加到法术队列窗口(SQW)的额外时间填充。较高值丢失较少按键;较低值感觉更灵敏。建议值为 100 毫秒。" -- MT
L["GEMS_SQW_LIVE"] = "SQW:%d 毫秒(延迟:%d 毫秒 + 缓冲:%d 毫秒)" -- MT
L["GEMS_SQW_ADVISORY"] = "推荐点击速率:%d 毫秒" -- MT
L["GEMS_SQW_ADVISORY_DETAIL"] = "GCD:%d 毫秒,SQW:%d 毫秒,延迟:%d 毫秒" -- MT
L["GEMS_SQW_ADVISORY_DELTA"] = "你的设置:%d 毫秒(比推荐 %s %d 毫秒)" -- MT
L["GEMS_SQW_MANAGED"] = "由 SQW 优化器管理" -- MT
L["GEMS_SQW_ENABLED"] = "SQW 优化器已启用" -- MT
L["GEMS_SQW_DISABLED"] = "SQW 优化器已禁用(SQW 重置为 %d)" -- MT
L["GEMS_SQW_STATUS"] = "SQW:%d 毫秒 | 延迟:%d 毫秒 | 缓冲:%d 毫秒 | 建议:%d 毫秒" -- MT
L["GEMS_SQW_HISTORY_HEADER"] = "Latency trend" -- MT
L["GEMS_SQW_HISTORY_EMPTY"] = "No latency samples yet -- samples record while the optimiser runs." -- MT
L["GEMS_SQW_HISTORY_RANGE"] = "low %d / high %d ms" -- MT
L["GEMS_SQW_BUFFER_SET"] = "SQW 缓冲设为 %d 毫秒" -- MT
L["GEMS_SQW_BUFFER_RANGE"] = "缓冲必须在 50 到 200 之间" -- MT
L["GEMS_SQW_SLOWER"] = "慢" -- MT
L["GEMS_SQW_FASTER"] = "快" -- MT

-- Faster, Slower (TempoAdvisor)
L["FS_CMD_HELP"] = "用法: /gems fs [name] - 分析序列点击速率" -- MT
L["FS_STATUS_HEADER"] = "更快、更慢" -- MT
L["FS_COMPLEXITY_RELAXED"] = "轻松" -- MT
L["FS_COMPLEXITY_STANDARD"] = "标准" -- MT
L["FS_COMPLEXITY_DEMANDING"] = "苛刻" -- MT
L["FS_COMPLEXITY_INTENSE"] = "密集" -- MT
L["FS_CONFIDENCE_ESTIMATED"] = "估计" -- MT
L["FS_CONFIDENCE_PRECISE"] = "精确" -- MT
L["FS_CONFIDENCE_CALIBRATED"] = "已校准" -- MT
L["FS_UNKNOWN_SPELLS"] = "%d 个未知法术 - 使用通用估计" -- MT
L["FS_RECOMMENDED"] = "推荐:%d 毫秒(%d/秒)" -- MT
L["FS_COMPLEXITY"] = "复杂度:%s" -- MT
L["FS_NO_SEQUENCE"] = "无活动序列" -- MT
L["FS_NO_STEPS"] = "无可分析的步骤" -- MT
L["FS_ANALYZING"] = "正在分析 %s..." -- MT
L["FS_DEBUG_ON"] = "更快、更慢调试已启用" -- MT
L["FS_DEBUG_OFF"] = "更快、更慢调试已禁用" -- MT
L["FS_HOLD_DEV"] = "保持模式正在开发中。查看 /gems fs 获取可用命令。" -- MT
L["FS_HOLD_RESET_DONE"] = "保持模式 GCD 外覆盖已重置。正在重新检查..." -- MT
L["FS_HOLD_DIAG_HEADER"] = "--- 保持模式诊断 ---" -- MT
L["FS_HOLD_DIAG_STATE"] = "  active=%s  seq=%s  key=%s" -- MT
L["FS_HOLD_DIAG_BUTTON"] = "  button=%s  step=%s" -- MT
L["FS_HOLD_DIAG_CVAR"] = "  CVar held=%s  poll=%s" -- MT
L["FS_HOLD_DIAG_STEPS"] = "  compiled steps=%d" -- MT

-- Faster, Slower Phase 2: Settings + Auto-Set
L["FS_AUTO_SET"] = "按序列自动调整点击速率" -- MT
L["FS_AUTO_SET_DESC"] = "激活每个序列时点击速率会调整。" -- MT
L["FS_SPARKLINE"] = "显示 CPS 迷你图" -- MT
L["FS_ALERT_ENABLED"] = "启用不匹配警报" -- MT
L["FS_ALERT_VISUAL"] = "视觉警报" -- MT
L["FS_ALERT_AUDIO"] = "音频警报" -- MT
L["FS_ALERT_SOUND_SLOW"] = "慢速警报声音" -- MT
L["FS_ALERT_SOUND_FAST"] = "快速警报声音" -- MT
L["FS_ALERT_CHANNEL"] = "音频频道" -- MT
L["FS_ALERT_TEST"] = "测试" -- MT
L["FS_ALERT_SLOW"] = "慢速阈值" -- MT
L["FS_ALERT_FAST"] = "快速阈值" -- MT
L["FS_AUTO_LABEL"] = "自动:%d 毫秒(%s)" -- MT
L["FS_MANUAL_OVERRIDE"] = "手动覆盖" -- MT
L["FS_CLEAR_OVERRIDE"] = "清除覆盖" -- MT
L["FS_OVERRIDE_SET"] = "%s 的手动覆盖设为 %d 毫秒" -- MT
L["FS_OVERRIDE_CLEARED"] = "已清除 %s 的覆盖" -- MT
L["FS_RATE_WILL_UPDATE"] = "脱离战斗时点击速率将更新" -- MT
L["FS_OVERLAY_TITLE"] = "更快、更慢" -- MT
L["FS_OVERLAY_LOCKED"] = "覆盖层已锁定" -- MT
L["FS_OVERLAY_UNLOCKED"] = "覆盖层已解锁" -- MT
L["FS_OVERLAY_SHOWN"] = "显示点击速率覆盖层" -- MT
L["FS_LDB_NO_SEQ"] = "-- /秒" -- MT
L["FS_LDB_SPAM"] = "%.1f/秒 . %d 毫秒" -- MT
L["FS_LDB_HOLD"] = "保持 . %d 毫秒" -- MT
L["FS_ALERT_TOO_SLOW"] = "点击太慢!" -- MT
L["FS_ALERT_TOO_FAST"] = "点击太快" -- MT
L["FS_HOLD_AUTOTUNED"] = "自动调整 . 轮询 %d 毫秒" -- MT
L["FS_HOLD_CONFLICT"] = "保持模式与 %s 冲突。两个插件都管理按住施法。" -- MT
L["FS_HOLD_ACTIVATED"] = "已为 %s 激活保持模式" -- MT
L["FS_HOLD_DEACTIVATED"] = "保持模式已停用" -- MT
L["FS_HOLD_NO_BUTTON"] = "保持模式:未找到原生按钮" -- MT
L["FS_HOLD_NO_KEYBIND"] = "保持模式:'%s' 未分配按键绑定 -- 请先在按键绑定选项卡中分配。" -- MT
L["FS_HOLD_ENABLED"] = "启用保持模式" -- MT
L["FS_HOLD_ENABLED_DESC"] = "按住按键而非垃圾按。EMS 使用原生动作按钮并为你调整重复速率。" -- MT
L["FS_HOLD_SLOT"] = "原生按钮槽位" -- MT
L["FS_HOLD_SLOT_DESC"] =
    "EMS 将使用哪个原生动作条按钮(默认:MultiBar7Button12 -- 第 7 条,槽 12)。请在动作条上保持此槽位空。" -- MT
L["FS_HOLD_POLL_MIN"] = "最小轮询速率(毫秒)" -- MT
L["FS_HOLD_POLL_MIN_DESC"] = "保持轮询速率的下限。较小值响应更灵敏但可能错过输入。" -- MT
L["FS_HOLD_NOTE"] =
    "保持模式使用未使用的原生按钮,使你可以按住按键重复。在序列编辑器中按序列开启。" -- MT
L["FS_HOLD_TOGGLED_ON"] = "已为 %s 启用保持模式" -- MT
L["FS_HOLD_TOGGLED_OFF"] = "已为 %s 禁用保持模式" -- MT
L["FS_HOLD_SEQ_TOGGLE"] = "保持模式" -- MT
L["FS_HOLD_SEQ_TOGGLE_DESC"] =
    "对此序列使用按住施法而非垃圾点击。需要在更快、更慢设置中启用保持模式。" -- MT
L["FS_TEMPO_JUST_RIGHT"] = "正合适" -- MT
L["FS_TEMPO_FASTER"] = "更快" -- MT
L["FS_TEMPO_FASTER_URGENT"] = "更快!" -- MT
L["FS_ALERT_DISABLED"] = "不匹配警报已禁用" -- MT
L["FS_ADJUSTED"] = "基于你的游戏数据调整推荐" -- MT
L["FS_WASTED_CLICKS"] = "%d / %d 次/秒点击浪费" -- MT

-- Phase 4 item 21 Phase B per-element theming editor
L["ACCESS_THEMING_EDITOR_NAME"] = "按元素主题" -- MT
L["ACCESS_THEMING_EDITOR_DESC"] = "为每个 UI 元素类微调颜色、alpha、字体和大小。" -- MT
L["ACCESS_THEMING_SWATCH_ADVANCED"] = "色样" -- MT
L["ACCESS_THEMING_FIELD_BG"] = "背景颜色" -- MT
L["ACCESS_THEMING_FIELD_BORDER"] = "边框颜色" -- MT
L["ACCESS_THEMING_FIELD_TEXT"] = "文字颜色" -- MT
L["ACCESS_THEMING_FIELD_ALPHA"] = "Alpha" -- MT
L["ACCESS_THEMING_FIELD_FONT"] = "字体" -- MT
L["ACCESS_THEMING_FIELD_FONT_DESC"] =
    "在此选择字体可将此文字元素固定到所选字体和大小,绕过暴雪 UIFontSize CVar 和 EMS UI 缩放。其他 EMS 文字继续随两者缩放。" -- MT
L["ACCESS_THEMING_FIELD_SIZE"] = "大小" -- MT
L["ACCESS_THEMING_FIELD_BG_TEXTURE"] = "背景纹理" -- MT
L["ACCESS_THEMING_FIELD_BG_TEXTURE_DESC"] = "选择平铺背景图像。留空保持纯色填充。" -- MT
L["ACCESS_THEMING_FIELD_BORDER_TEXTURE"] = "边框纹理" -- MT
L["ACCESS_THEMING_FIELD_BORDER_TEXTURE_DESC"] = "选择边框样式。留空保持细薄默认边框。" -- MT
L["ACCESS_THEMING_RESET_CLASS"] = "重置" -- MT
L["ACCESS_THEMING_RESET_CLASS_DESC"] = "移除此元素的覆盖并回退到预设。" -- MT
L["ACCESS_THEMING_GROUP_PANELS"] = "面板" -- MT
L["ACCESS_THEMING_GROUP_OVERLAYS"] = "覆盖层" -- MT
L["ACCESS_THEMING_GROUP_ROWS"] = "行" -- MT
L["ACCESS_THEMING_GROUP_BUTTONS"] = "按钮" -- MT
L["ACCESS_THEMING_GROUP_TEXT"] = "文字" -- MT
L["ACCESS_THEMING_GROUP_EMPHASIS"] = "强调" -- MT
L["ACCESS_THEMING_GROUP_GLOBAL"] = "全局" -- MT
L["ACCESS_THEMING_SLOTS_HEADER"] = "已保存主题" -- MT
L["ACCESS_THEMING_SLOTS_DESC"] = "保存最多五个主题并在它们之间切换。" -- MT
L["ACCESS_THEMING_SLOT_NAME"] = "名称" -- MT
L["ACCESS_THEMING_SLOT_SAVE"] = "保存" -- MT
L["ACCESS_THEMING_SLOT_LOAD"] = "加载" -- MT
L["ACCESS_THEMING_SLOT_RENAME"] = "重命名" -- MT
L["ACCESS_THEMING_SLOT_CLEAR"] = "清除" -- MT
L["ACCESS_THEMING_SLOT_CLEAR_CONFIRM"] = "清除此槽位?" -- MT
L["ACCESS_THEMING_SLOT_EMPTY"] = "(空)" -- MT
L["ACCESS_THEMING_SLOT_DEFAULT_NAME"] = "主题 %d" -- MT
L["ACCESS_THEMING_SLOT_OVERWRITE_CONFIRM"] = "覆盖槽位 %d (%s)?" -- MT
L["ACCESS_THEMING_IMPORTEXPORT_HEADER"] = "导入 / 导出" -- MT
L["ACCESS_THEMING_EXPORT_LABEL"] = "导出" -- MT
L["ACCESS_THEMING_IMPORT_LABEL"] = "导入" -- MT
L["ACCESS_THEMING_IMPORT_APPLY"] = "应用导入" -- MT
L["ACCESS_THEMING_IMPORT_OK"] = "主题已导入。" -- MT
L["ACCESS_THEMING_IMPORT_FAIL"] = "导入失败" -- MT
L["ACCESS_THEMING_PRESET_HEADER"] = "预设" -- MT
L["ACCESS_THEMING_PRESET_LABEL"] = "预设" -- MT
L["ACCESS_THEMING_PRESET_DEFAULT"] = "默认" -- MT
L["ACCESS_THEMING_PRESET_HIGH_CONTRAST"] = "高对比度" -- MT
L["ACCESS_THEMING_PRESET_CUSTOM"] = "自定义" -- MT
L["ACCESS_THEMING_RESET_ALL"] = "全部重置" -- MT
L["ACCESS_THEMING_RESET_ALL_DESC"] = "清除每个元素的覆盖并恢复所选预设。" -- MT
L["ACCESS_THEMING_RESET_ALL_CONFIRM"] = "将每个主题覆盖重置为默认?" -- MT
L["ACCESS_THEMING_COPY_ALL_PROFILES"] = "复制到所有配置文件" -- MT
L["ACCESS_THEMING_COPY_ALL_PROFILES_DESC"] = "将当前主题应用到每个 EMS 配置文件。" -- MT
L["ACCESS_THEMING_COPY_ALL_CONFIRM"] = "将当前主题复制到每个配置文件?" -- MT
L["ACCESS_THEMING_FOOTER_HEADER"] = "" -- MT
L["ACCESS_THEMING_MODAL_TITLE"] = "GRIP-EMS 按元素主题" -- MT
L["ACCESS_THEMING_MODAL_DESC"] =
    "自定义每个 EMS 面板、按钮、行、文字和覆盖层类。更改实时应用并按配置文件保存。" -- MT
L["ACCESS_THEMING_MODAL_COMBAT_BLOCKED"] = "战斗中主题编辑器隐藏。" -- MT
L["ACCESS_THEMING_SLASH_HINT"] = "打开按元素主题编辑器。" -- MT
L["ACCESS_THEMING_CONTRAST_WARN_TITLE"] = "对比度警告" -- MT
L["ACCESS_THEMING_CONTRAST_WARN_TEXT"] =
    "%s 上的文字 %s 是 %.1f:1 (AA 需要 %.1f:1)。低视力用户可能无法阅读。" -- MT
L["ACCESS_THEMING_CONTRAST_WARN_UI"] = "UI %s 对 %s 是 %.1f:1 (需要 3:1)。" -- MT
L["ACCESS_THEMING_CONTRAST_LOW_ALPHA"] = "低 alpha:%s 是 %.2f (低于 0.3,可能不可见)。" -- MT
L["ACCESS_THEMING_CONTRAST_TEXTURE_UNKNOWN"] = "%s 的对比度检查已禁用 -- %s 使用自定义背景纹理。" -- MT
L["ACCESS_THEMING_TEXTURE_MISSING"] = "EMS:主题纹理 '%s' 不可用。回退到默认纹理。" -- MT
L["ACCESS_THEMING_CONTRAST_DISMISS"] = "忽略(30 分钟)" -- MT
L["ACCESS_THEMING_CONTRAST_AUTOFIX"] = "自动修复背景" -- MT
L["ACCESS_THEMING_CONTRAST_BADGE_PASS"] = "|TInterface\\RAIDFRAME\\ReadyCheck-Ready:12:12|t" -- MT
L["ACCESS_THEMING_CONTRAST_BADGE_FAIL"] = "|TInterface\\RAIDFRAME\\ReadyCheck-NotReady:12:12|t" -- MT
L["ACCESS_THEMING_CONTRAST_QUEUE_MORE"] = "+%d 个更多" -- MT
L["ACCESS_THEMING_CONTRAST_SILENCE_HEADER"] = "已静默对比度" -- MT
L["ACCESS_THEMING_CONTRAST_SILENCE_HEADER_BADGE"] = "已静默对比度(%d)" -- MT
L["ACCESS_THEMING_CONTRAST_SILENCE_EMPTY"] = "当前没有静默的对比度警告。" -- MT
L["ACCESS_THEMING_CONTRAST_SILENCE_REMAINING"] = "%s -- 剩余 %d 分钟" -- MT
L["ACCESS_THEMING_CONTRAST_SILENCE_UNSILENCE"] = "解除静默" -- MT
L["ACCESS_THEMING_CONTRAST_SILENCE_UNSILENCE_ALL"] = "全部解除静默" -- MT
L["ACCESS_THEMING_CONTRAST_SILENCE_UNSILENCE_ALL_CONFIRM"] =
    "清除所有 %d 个静默类的静默?它们将在下次主题应用或 /reload 时再次警告。" -- MT
L["ACCESS_THEMING_CHATLINK_INSERT"] = "插入聊天链接" -- MT
L["ACCESS_THEMING_CHATLINK_INSERT_DESC"] =
    "在活动聊天编辑框中插入可点击的主题链接。接收方点击它进行预览和应用。" -- MT
L["ACCESS_THEMING_CHATLINK_NO_EDITBOX"] = "请先打开聊天编辑框,然后点击插入聊天链接。" -- MT
L["ACCESS_THEMING_CHATLINK_NO_RECEIVER"] = "%s 未安装 EMS。" -- MT
L["ACCESS_THEMING_CHATLINK_OWN_LINK"] = "那是你自己的主题链接。与其他玩家分享以发送。" -- MT
L["ACCESS_THEMING_CHATLINK_RECEIVE_PROMPT"] = "接受来自 %s 的主题?" -- MT
L["ACCESS_THEMING_CHATLINK_TIMEOUT"] = "主题传输超时。" -- MT
L["ACCESS_THEMING_CHATLINK_VERSION_MISMATCH"] = "此主题来自较新的 EMS 版本。请更新 EMS 后重试。" -- MT
L["ACCESS_THEMING_CHATLINK_DOS_BLOCK"] = "EMS:主题传输被拒绝。发送方声称的块过多。" -- MT
L["ACCESS_THEMING_CHATLINK_REALM_BLOCK"] = "EMS:主题链接发送方位于未连接的服务器。点击已忽略。" -- MT
L["ACCESS_THEMING_CHATLINK_RATE_LIMIT"] = "EMS:对该玩家的主题请求过多。请稍后重试。" -- MT
L["ACCESS_THEMING_INSPECT_ENTER_HINT"] = "检查模式开。悬停任一 EMS 框查看其主题类。按 Esc 退出。" -- MT
L["ACCESS_THEMING_INSPECT_NO_CLASS"] = "此框上无 EMS 类。" -- MT
L["ACCESS_THEMING_INSPECT_MODE_BUTTON"] = "检查模式" -- MT
L["ACCESS_THEMING_INSPECT_TOOLTIP_HINT"] = "点击主题化的 EMS 框打开滚动到该类的编辑器。" -- MT

-- Sound cues (item 14)
L["ACCESS_SOUND_SECTION_NAME"] = "声音提示" -- MT
L["ACCESS_SOUND_SECTION_DESC"] =
    "用于验证结果和序列触发的简短音频提示。其他插件向 SharedMedia 注册的任何声音都出现在下方下拉菜单中。默认禁用。" -- MT
L["ACCESS_SOUND_ENABLED_LABEL"] = "启用声音提示" -- MT
L["ACCESS_SOUND_ENABLED_DESC"] =
    "开启以在验证错误、成功、信息提示和序列步骤上播放简短音频提示。" -- MT
L["ACCESS_SOUND_CHANNEL_LABEL"] = "声音频道" -- MT
L["ACCESS_SOUND_CHANNEL_DESC"] = "哪个暴雪音频频道播放提示。音量遵循游戏内频道滑块。" -- MT
L["ACCESS_SOUND_CUE_ERROR_LABEL"] = "错误提示" -- MT
L["ACCESS_SOUND_CUE_ERROR_DESC"] = "出错时播放 -- 导入失败、序列损坏或专精无效。" -- MT
L["ACCESS_SOUND_CUE_SUCCESS_LABEL"] = "成功提示" -- MT
L["ACCESS_SOUND_CUE_SUCCESS_DESC"] = "成功保存、导入和验证通过时播放。" -- MT
L["ACCESS_SOUND_CUE_INFO_LABEL"] = "信息提示" -- MT
L["ACCESS_SOUND_CUE_INFO_DESC"] = "信息性提示时播放 -- 首次运行通知、检查点消息。" -- MT
L["ACCESS_SOUND_CUE_STEP_LABEL"] = "步骤提示" -- MT
L["ACCESS_SOUND_CUE_STEP_DESC"] =
    "序列推进到下一步时播放。每半秒播放一次封顶,使快速序列不会垃圾邮件音频。" -- MT
L["ACCESS_SOUND_PREVIEW_LABEL"] = "播放" -- MT
L["ACCESS_SOUND_VISUAL_LABEL"] = "声音提示的视觉闪烁" -- MT
L["ACCESS_SOUND_VISUAL_DESC"] =
    "声音提示触发时显示简短中央闪烁。独立于音频开关,使聋哑和听力障碍用户可以使用视觉而无声。闪烁颜色告诉你是哪个提示:红色为错误,绿色为成功,青色为信息,金色为步骤完成。" -- MT
-- Per-cue Blizzard channel routing (Phase 4 item 22 Phase 2)
L["ACCESS_SOUND_CHANNEL_PER_CUE_DESC"] =
    "为此特定提示选择暴雪音频频道。音量遵循 WoW 声音选项中的频道滑块。" -- MT
L["ACCESS_SOUND_CHANNEL_ERROR_LABEL"] = "错误频道" -- MT
L["ACCESS_SOUND_CHANNEL_SUCCESS_LABEL"] = "成功频道" -- MT
L["ACCESS_SOUND_CHANNEL_INFO_LABEL"] = "信息频道" -- MT
L["ACCESS_SOUND_CHANNEL_STEP_LABEL"] = "步骤频道" -- MT

-- Cursor overlay (item 15)
L["ACCESS_CURSOR_SECTION_NAME"] = "光标覆盖层" -- MT
L["ACCESS_CURSOR_SECTION_DESC"] =
    "在鼠标光标周围绘制有色环或十字准星,使其更容易找到。颜色遵循活动对比度预设。" -- MT
L["ACCESS_CURSOR_ENABLED_LABEL"] = "启用光标覆盖层" -- MT
L["ACCESS_CURSOR_ENABLED_DESC"] = "开启或关闭光标覆盖层。" -- MT
L["ACCESS_CURSOR_MODE_LABEL"] = "覆盖层形状" -- MT
L["ACCESS_CURSOR_MODE_DESC"] = "选择环或十字准星。" -- MT
L["ACCESS_CURSOR_MODE_RING"] = "环" -- MT
L["ACCESS_CURSOR_MODE_CROSSHAIR"] = "十字准星" -- MT
L["ACCESS_CURSOR_SIZE_LABEL"] = "覆盖层大小" -- MT
L["ACCESS_CURSOR_SIZE_DESC"] = "选择默认大小的 1 倍、1.5 倍或 2 倍。" -- MT
L["ACCESS_CURSOR_SIZE_1X"] = "1x" -- MT
L["ACCESS_CURSOR_SIZE_15X"] = "1.5x" -- MT
L["ACCESS_CURSOR_SIZE_2X"] = "2x" -- MT
L["ACCESS_CURSOR_COLOR_INFO"] = "覆盖层颜色遵循活动对比度预设的焦点环颜色。" -- MT

-- Feedback and accessibility resources (item 17 / A11Y-DEFER-16)
L["ACCESS_FEEDBACK_SECTION_NAME"] = "无障碍资源和反馈" -- MT
L["ACCESS_FEEDBACK_SECTION_DESC"] =
    "无障碍标准、WoW 社区纪念以及报告问题或分享反馈的地方的链接。" -- MT
L["ACCESS_FEEDBACK_APX_LABEL"] = "AbleGamers APX" -- MT
L["ACCESS_FEEDBACK_APX_DESC"] = "AbleGamers 无障碍玩家体验框架。打开可复制的链接。" -- MT
L["ACCESS_FEEDBACK_GAG_LABEL"] = "游戏无障碍指南" -- MT
L["ACCESS_FEEDBACK_GAG_DESC"] = "游戏无障碍社区框架。打开可复制的链接。" -- MT
L["ACCESS_FEEDBACK_IBELIN_LABEL"] = "纪念 Ibelin" -- MT
L["ACCESS_FEEDBACK_IBELIN_DESC"] =
    "Mats Steen 1989-2014。重新定义了这款游戏意义的 WoW 玩家的致敬网站。打开可复制的链接。" -- MT
L["ACCESS_FEEDBACK_DISCORD_LABEL"] = "报告无障碍问题" -- MT
L["ACCESS_FEEDBACK_DISCORD_DESC"] =
    "打开到 GRIP Discord 的可复制链接,你可以在那里报告无障碍问题或分享反馈。" -- MT
L["ACCESS_FEEDBACK_POPUP_TEXT"] = "复制此链接以在浏览器中打开:" -- MT
L["ACCESS_GUIDE_SECTION_NAME"] = "无障碍指南" -- MT
L["ACCESS_GUIDE_SECTION_DESC"] =
    "完整的无障碍文档位于插件根目录的 ACCESSIBILITY.md。交互指南在线下有摘要,在无障碍部分。" -- MT
L["ACCESS_GUIDE_BUTTON_LABEL"] = "打开交互指南" -- MT
L["ACCESS_GUIDE_BUTTON_DESC"] = "打开显示交互指南链接的弹窗,使你可以用 Ctrl+C 复制。" -- MT

-- Large-target density (item 16 / A11Y-DEFER-14)
L["ACCESS_DENSITY_SECTION_NAME"] = "大型交互目标" -- MT
L["ACCESS_DENSITY_SECTION_DESC"] =
    "使可点击的目标(如按钮、复选框和选项卡)更容易点击。将点击区域增大到 WCAG 2.5.5 最小值 44x44 像素而不改变视觉大小。" -- MT
L["ACCESS_DENSITY_TOGGLE_LABEL"] = "扩大点击区域" -- MT
L["ACCESS_DENSITY_TOGGLE_DESC"] =
    "增大选项卡、复选框和对话框按钮的点击区域。视觉大小保持不变。立即应用到打开的窗口。" -- MT
L["ACCESS_DENSITY_RELOAD_HINT"] =
    "点击区域增强立即应用。某些序列编辑器行只在你关闭并重新打开编辑器后才接收更改。" -- MT

-- Simplified Mode (item 18 / A11Y-DEFER-17)
L["ACCESS_SIMPLIFIED_SECTION_NAME"] = "简化模式" -- MT
L["ACCESS_SIMPLIFIED_SECTION_DESC"] =
    "将编辑器折叠为最小表面,以适合开关、眼动追踪器和单按钮用户。" -- MT
L["ACCESS_SIMPLIFIED_TOGGLE_LABEL"] = "启用简化模式" -- MT
L["ACCESS_SIMPLIFIED_TOGGLE_DESC"] =
    "将编辑器减少为四个 Tab 可达控件 -- 步骤选项卡、动作条、标题栏和运行按钮。最适合大密度和 UI 缩放 1.25 或更高。" -- MT
L["ACCESS_SIMPLIFIED_DELAY_LABEL"] = "接受后延迟(毫秒)" -- MT
L["ACCESS_SIMPLIFIED_DELAY_DESC"] =
    "激活之间的冷却。500ms 匹配游戏无障碍指南的运动高级。对更强的震颤或开关反弹增加。" -- MT
L["ACCESS_SIMPLIFIED_FIRST_ENABLE_HINT"] =
    "简化模式已激活。使用 Tab、Shift+Tab、Enter、Space 和 Escape 进行导航。" -- MT
L["ACCESS_SIMPLIFIED_RELOAD_HINT"] = "简化模式已应用。为获得最佳效果,切换后输入 /reload。" -- MT
L["ACCESS_SIMPLIFIED_DENSITY_REJECT"] = "简化模式需要大型目标。请先关闭简化模式。" -- MT
L["ACCESS_SIMPLIFIED_SCALE_REJECT"] = "简化模式需要 UI 缩放 1.25 或更高。关闭简化模式以降低。" -- MT
L["ACCESS_SIMPLIFIED_UNLOCK_BUTTON"] = "解锁编辑器" -- MT
L["ACCESS_SIMPLIFIED_RUN_BUTTON"] = "运行序列" -- MT

-- Phase G.7 (G23): ReloadGate
L["RELOAD_GATE_POPUP_TITLE"] = "EMS - 重载以完全应用" -- MT
L["RELOAD_GATE_POPUP_BODY"] =
    "%d 个设置更改在 %d 个操作中应用。立即重载使更改完全生效,或继续而不重载。\n\n%s" -- MT
L["RELOAD_GATE_RELOAD_NOW"] = "立即重载" -- MT
L["RELOAD_GATE_LATER"] = "稍后" -- MT
L["RELOAD_GATE_TOOLTIP_TITLE"] = "EMS - 待处理更改" -- MT
L["RELOAD_GATE_TOOLTIP_NONE"] = "无待处理更改。" -- MT
L["RELOAD_GATE_TOOLTIP_HINT"] = "点击查看详情" -- MT
L["RELOAD_GATE_CAUSE_AUTOFIX"] = "登录时自动修复" -- MT
L["RELOAD_GATE_CAUSE_FIX_ALL_CRIT"] = "修复所有关键项" -- MT
L["RELOAD_GATE_CAUSE_FIX_ALL_SEC"] = "修复此部分所有项" -- MT
L["RELOAD_GATE_CAUSE_PER_ROW_FIX"] = "修复单个设置" -- MT
L["RELOAD_GATE_CAUSE_PER_ROW_SET"] = "设置自定义值" -- MT
L["RELOAD_GATE_CAUSE_RESET_DEFS"] = "重置为默认" -- MT
L["RELOAD_GATE_CAUSE_PROFILE_SWP"] = "配置文件交换" -- MT
L["RELOAD_GATE_CAUSE_PROFILE_IMP"] = "配置文件导入" -- MT
L["RELOAD_GATE_CAUSE_OOC_QUEUED"] = "已排队(战斗)" -- MT
L["RELOAD_GATE_CAUSE_OOC_APPLIED"] = "已应用(战斗后)" -- MT

-- G8-AUDIT-04 / -10 / -14 / -19 / -27 / -36 / -50 (G.8c.2 TTS coverage)
-- These strings are spoken aloud by TTS and emitted to chat. Plain
-- language only. No marketing tone. No em dashes. Short sentences.
L["ACCESS_ANNOUNCE_RELOAD_PENDING"] = "重载待处理" -- MT
L["ACCESS_ANNOUNCE_S18_EXPORT_READY"] = "%s 的导出已就绪。按 Control C 复制。" -- MT
L["ACCESS_ANNOUNCE_S18_IMPORT_OK"] = "配置文件已作为 %s 导入。%d 个设置。" -- MT
L["ACCESS_ANNOUNCE_S18_IMPORT_ERROR"] = "导入失败。%s" -- MT
L["ACCESS_ANNOUNCE_S18_DELETE_CONFIRM"] = "删除 %s?确认或取消。" -- MT
L["ACCESS_ANNOUNCE_CVAR_FIX"] = "已将 %s 修复到 %s" -- MT
L["ACCESS_ANNOUNCE_CVAR_SET"] = "%s 设为 %s" -- MT
L["ACCESS_ANNOUNCE_CVAR_UNDO"] = "%s 已恢复到 %s" -- MT
L["ACCESS_ANNOUNCE_CVAR_REDO"] = "%s reapplied to %s" -- MT
L["ACCESS_ANNOUNCE_CVAR_PIN_ON"] = "%s 已固定" -- MT
L["ACCESS_ANNOUNCE_CVAR_PIN_OFF"] = "%s 已解除固定" -- MT
L["ACCESS_ANNOUNCE_CVAR_AUTOFIX_ON"] = "%s 的自动修复开" -- MT
L["ACCESS_ANNOUNCE_CVAR_AUTOFIX_OFF"] = "%s 的自动修复关" -- MT
L["ACCESS_ANNOUNCE_CVAR_FIXALL_BUSY"] = "正在修复 %d 个设置" -- MT
L["ACCESS_ANNOUNCE_CVAR_FIXALL_DONE"] = "已修复 %d 个设置" -- MT
L["ACCESS_ANNOUNCE_TOGGLE_REDUCE_MOTION_ON"] = "减少动效开" -- MT
L["ACCESS_ANNOUNCE_TOGGLE_REDUCE_MOTION_OFF"] = "减少动效关" -- MT
L["ACCESS_ANNOUNCE_TOGGLE_FLICKER_SAFE_ON"] = "防闪烁模式开" -- MT
L["ACCESS_ANNOUNCE_TOGGLE_FLICKER_SAFE_OFF"] = "防闪烁模式关" -- MT
L["ACCESS_ANNOUNCE_TOGGLE_SPEECH_ENABLED_ON"] = "语音开" -- MT
L["ACCESS_ANNOUNCE_TOGGLE_SPEECH_ENABLED_OFF"] = "语音关" -- MT
L["ACCESS_ANNOUNCE_TOGGLE_CHAT_EMITTER_ON"] = "聊天发送开" -- MT
L["ACCESS_ANNOUNCE_TOGGLE_CHAT_EMITTER_OFF"] = "聊天发送关" -- MT
-- G.9: cvarHealth numbered-key + skip-to-issues nav announcements.
L["ACCESS_ANNOUNCE_SECTION_JUMP"] = "部分 %d / %d:%s" -- MT
L["ACCESS_ANNOUNCE_ISSUE_JUMP"] = "问题 %d / %d:%s" -- MT

-- v2.1.0 Authorship Integrity (Phase A): English values stubbed, awaiting MT pass.
L["GEMS_AUTHOR_LOCKED_TOOLTIP"] =
    "Original Author is set on creation and cannot be changed. Use Fork to create your own version." -- MT
L["GEMS_AUTHOR_ORIGINAL_LABEL"] = "Original Author" -- MT
L["GEMS_AUTHOR_LAST_MODIFIED_LABEL"] = "Last modified by" -- MT
L["GEMS_AUTHOR_CREATED_AT"] = "Created" -- MT
L["GEMS_AUTHOR_LAST_MODIFIED_VALUE"] = "%s on %s" -- MT
L["GEMS_PROVENANCE_UNKNOWN"] = "Provenance unknown" -- MT
L["GEMS_PROVENANCE_UNKNOWN_TOOLTIP"] =
    "No signature on file. Sequence predates v2.1.0 or was imported from a source without provenance." -- MT
L["GEMS_PROVENANCE_LEGACY_IMPORT"] = "Legacy import" -- MT
L["GEMS_PROVENANCE_LEGACY_IMPORT_TOOLTIP"] = "Imported from a legacy format. Original author: %s (unverified)." -- MT
L["GEMS_PROVENANCE_FORGE_IMPORT"] = "Forge import" -- MT
L["GEMS_PROVENANCE_FORGE_IMPORT_TOOLTIP"] = "Built with GRIP Forge. Attribution: %s (unverified)." -- MT

-- v2.1.0 Authorship Integrity (Phase B): English values stubbed, awaiting MT pass.
L["GEMS_PROVENANCE_VERIFIED"] = "Verified" -- MT
L["GEMS_PROVENANCE_VERIFIED_TOOLTIP"] = "Signature matches. This is the unmodified original." -- MT
L["GEMS_PROVENANCE_MODIFIED"] = "Modified" -- MT
L["GEMS_PROVENANCE_MODIFIED_TOOLTIP"] = "Original signature intact. Modifier chain has %d entries." -- MT
L["GEMS_PROVENANCE_TAMPERED"] = "Tampered" -- MT
L["GEMS_PROVENANCE_TAMPERED_TOOLTIP"] = "Signature mismatch. Provenance fields may have been edited outside the addon." -- MT
L["GEMS_PROVENANCE_DAMAGED"] = "Damaged" -- MT
L["GEMS_PROVENANCE_DAMAGED_TOOLTIP"] =
    "Provenance fields present but signature missing. SavedVariables file may be partially corrupted." -- MT
L["GEMS_PROVENANCE_FORKED_BADGE"] = "Forked" -- MT
L["GEMS_PROVENANCE_FORKED_TOOLTIP"] = "This sequence was forked from another author. See chain for details." -- MT
L["GEMS_AUTHOR_MODIFIER_CHAIN_HEADER"] = "Modification chain" -- MT

-- v2.1.0 Authorship Integrity (Phase C): English values stubbed, awaiting MT pass.
L["GEMS_FORK_BUTTON"] = "Fork" -- MT
L["GEMS_FORK_TOOLTIP"] =
    "Create a new sequence based on this one, with you as the Original Author. The original sequence is unchanged." -- MT
L["GEMS_FORK_DIALOG_TITLE"] = "Fork sequence" -- MT
L["GEMS_FORK_DIALOG_BODY"] =
    "Forking '%s' creates a new sequence with you as the Original Author. Enter a name for the fork:" -- MT
L["GEMS_FORK_CONFIRM"] = "Fork '%s' as a new sequence?" -- MT
L["GEMS_PROVENANCE_SHOW_ALL_CHAIN"] = "Show all (%d)" -- MT

-- v2.1.0 Authorship Integrity (Phase C polish): English values stubbed, awaiting MT pass.
L["GEMS_AUTHOR_FORKED_FROM_LABEL"] = "Forked from" -- MT
L["GEMS_AUTHOR_FORKED_FROM_VALUE"] = "%s on %s" -- MT
L["GEMS_AUTHOR_FORKED_FROM_CHAIN_TRUNCATE"] = "(+%d more)" -- MT
L["GEMS_AUTHOR_FORK_LINEAGE_HEADER"] = "Fork lineage" -- MT

-- v2.1.0 Authorship Integrity (Phase D): English values stubbed, awaiting MT pass.
L["GEMS_PRIVACY_GROUP_NAME"] = "Authorship Privacy" -- MT
L["GEMS_PRIVACY_MODE_LABEL"] = "Privacy mode" -- MT
L["GEMS_PRIVACY_MODE_PUBLIC"] = "Public" -- MT
L["GEMS_PRIVACY_MODE_PSEUDONYMOUS"] = "Pseudonymous" -- MT
L["GEMS_PRIVACY_MODE_PRIVATE"] = "Private" -- MT
L["GEMS_PRIVACY_DEFAULT_LABEL"] = "Default privacy mode for new sequences" -- MT
L["GEMS_PRIVACY_DEFAULT_DESC"] = "New sequences inherit this privacy mode unless overridden per-sequence." -- MT
L["GEMS_PRIVACY_PSEUDONYM_LABEL"] = "Pseudonym" -- MT
L["GEMS_PRIVACY_PSEUDONYM_DESC"] =
    "Display name used in pseudonymous-mode exports. Identity hash is preserved so receivers can link sequences from the same author." -- MT
L["GEMS_PRIVACY_SHOW_BADGES_LABEL"] = "Show provenance badges in sequence list" -- MT
L["GEMS_PRIVACY_SHOW_BADGES_DESC"] = "Render the small verification badge next to each sequence row." -- MT

-- ===========================================================================
-- L372 Wave 10a+10b: 14 CVar option labels + descLong (2026-05-19, MT)
-- ===========================================================================

L["GEMS_CVAR_COMBAT_SOFTENEMY_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBAT_SOFTENEMY_OPT_1"] = "Gamepad only" -- MT
L["GEMS_CVAR_COMBAT_SOFTENEMY_OPT_2"] = "Mouse and keyboard only" -- MT
L["GEMS_CVAR_COMBAT_SOFTENEMY_OPT_3"] = "Always (gamepad and KBM)" -- MT
L["GEMS_CVAR_COMBAT_SOFTENEMY_DESCLONG"] =
    "Sets the soft-target highlight for enemies -- the ghosted unit frame that appears when you face an enemy without clicking it. Off disables it. Gamepad only lights it up when a controller is bound. Mouse and keyboard only restricts it to KBM input, an unusual pick. Always (the EMS recommendation) shows it for both input modes, which gives KBM players the same on-the-fly target hint controller players already get." -- MT

L["GEMS_CVAR_COMBAT_SOFTFRIEND_OPT_2"] = "Mouse and keyboard only" -- MT
L["GEMS_CVAR_COMBAT_SOFTFRIEND_OPT_3"] = "Always (gamepad and KBM)" -- MT

L["GEMS_CVAR_SOLO_INTERACT_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_SOLO_INTERACT_OPT_1"] = "Gamepad only" -- MT
L["GEMS_CVAR_SOLO_INTERACT_OPT_2"] = "Mouse and keyboard only" -- MT
L["GEMS_CVAR_SOLO_INTERACT_OPT_3"] = "Always (gamepad and KBM)" -- MT
L["GEMS_CVAR_SOLO_INTERACT_DESCLONG"] =
    "Sets the soft-target highlight for interactable objects -- NPCs, mailboxes, ore nodes, herbs, quest items. Off disables it. Gamepad only lights up the nearest interactable when a controller is bound. Mouse and keyboard only restricts it to KBM input. Always (the EMS recommendation) shows it for both input modes, which keeps controller and KBM behaviour the same and helps you spot quest objects you might otherwise click past." -- MT

L["GEMS_CVAR_RAIDING_THREATWARN_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_THREATWARN_OPT_1"] = "Progressive (warning text)" -- MT
L["GEMS_CVAR_RAIDING_THREATWARN_OPT_2"] = "Flashing health bar" -- MT
L["GEMS_CVAR_RAIDING_THREATWARN_OPT_3"] = "Tinted health bar" -- MT
L["GEMS_CVAR_RAIDING_THREATWARN_DESCLONG"] =
    "Sets how nameplates warn you about threat. Off hides the warning entirely. Progressive shows a warning text overlay when your threat ramps. Flashing health bar pulses the nameplate red as a strong visual cue. Tinted health bar (the default, and the EMS recommendation) tints the nameplate fill from yellow through orange to red as your threat percentage climbs -- the same data as flashing but at a glance, without the eye strain." -- MT

L["GEMS_CVAR_RAIDING_DISPTYPE_OPT_0"] = "Hidden" -- MT
L["GEMS_CVAR_RAIDING_DISPTYPE_OPT_1"] = "Only ones I can dispel" -- MT
L["GEMS_CVAR_RAIDING_DISPTYPE_OPT_2"] = "All dispellable debuffs" -- MT
L["GEMS_CVAR_RAIDING_DISPTYPE_DESCLONG"] =
    "Sets which dispellable debuffs show on raid frames. Hidden suppresses the indicator entirely. Only ones I can dispel filters to the debuff types your spec can actually remove, which is the cleanest look for non-healer roles. All dispellable debuffs (the default, and the EMS recommendation) shows everything someone in the group could remove, which is what healers want so they can see which categories their off-healers should be covering." -- MT

L["GEMS_CVAR_COMBAT_SOFTLOCKED_OPT_0"] = "Off (suppress when target is locked)" -- MT
L["GEMS_CVAR_COMBAT_SOFTLOCKED_OPT_1"] = "On (keep showing soft target)" -- MT
L["GEMS_CVAR_COMBAT_SOFTLOCKED_DESCLONG"] =
    "Controls whether the soft-target overlay stays visible while you have a hard target locked. Off suppresses the soft overlay when something is locked, reducing visual noise. On (the default, and the EMS recommendation) keeps the soft-target ghost visible alongside your locked target, which is what you usually want for fast target swaps without re-acquiring." -- MT

L["GEMS_CVAR_COMBAT_SOFTMATCH_OPT_0"] = "Off (always use soft target if unlocked)" -- MT
L["GEMS_CVAR_COMBAT_SOFTMATCH_OPT_1"] = "On (prefer soft target that matches your locked target)" -- MT
L["GEMS_CVAR_COMBAT_SOFTMATCH_DESCLONG"] =
    "Controls how the soft-target picks a candidate when you already have a hard target locked. Off lets the soft target choose freely based on your aim cone. On (the default, and the EMS recommendation) biases the soft target towards whatever you have locked, which keeps your soft and hard targets aligned for actions that prefer the hard target while leaving room to glance at others nearby." -- MT

L["GEMS_CVAR_COMBAT_SOFTRANGE_OPT_20"] = "20 yards (melee plus a small buffer)" -- MT
L["GEMS_CVAR_COMBAT_SOFTRANGE_OPT_30"] = "30 yards (close ranged)" -- MT
L["GEMS_CVAR_COMBAT_SOFTRANGE_OPT_45"] = "45 yards (standard ranged)" -- MT
L["GEMS_CVAR_COMBAT_SOFTRANGE_OPT_60"] = "60 yards (long ranged)" -- MT
L["GEMS_CVAR_COMBAT_SOFTRANGE_OPT_100"] = "100 yards (extreme range)" -- MT
L["GEMS_CVAR_COMBAT_SOFTRANGE_DESCLONG"] =
    "Sets the maximum distance for the enemy soft-target pick. Lower values keep the soft target focused on the closest enemies and ignore distant mobs you cannot reach. 45 yards (the default, and the EMS recommendation) matches the standard spell range for most ranged DPS specs, so soft target picks the same mobs your finishers can actually hit. Raise it for hunters or balance druids who want to acquire targets at long range; lower it for melee specs who do not want to lock onto far-away mobs." -- MT

L["GEMS_CVAR_COMBAT_FRIENDRANGE_OPT_20"] = "20 yards (melee plus a small buffer)" -- MT
L["GEMS_CVAR_COMBAT_FRIENDRANGE_OPT_30"] = "30 yards (close ranged)" -- MT
L["GEMS_CVAR_COMBAT_FRIENDRANGE_OPT_45"] = "45 yards (standard ranged)" -- MT
L["GEMS_CVAR_COMBAT_FRIENDRANGE_OPT_60"] = "60 yards (long ranged)" -- MT
L["GEMS_CVAR_COMBAT_FRIENDRANGE_OPT_100"] = "100 yards (extreme range)" -- MT
L["GEMS_CVAR_COMBAT_FRIENDRANGE_DESCLONG"] =
    "Sets the maximum distance for the friendly soft-target pick. Lower values keep the soft target on nearby allies; higher values let the soft target reach distant party members. 45 yards (the default, and the EMS recommendation) matches the standard heal range, which is the most useful value for healers who lean on soft targeting. Raise it for druids or priests with longer-range heals; drop it for melee healers who only care about the immediate group cluster." -- MT

L["GEMS_CVAR_SOLO_INTERRANGE_OPT_5"] = "5 yards (right next to you)" -- MT
L["GEMS_CVAR_SOLO_INTERRANGE_OPT_10"] = "10 yards (one step away)" -- MT
L["GEMS_CVAR_SOLO_INTERRANGE_OPT_15"] = "15 yards (a short walk)" -- MT
L["GEMS_CVAR_SOLO_INTERRANGE_OPT_20"] = "20 yards (visible nearby)" -- MT
L["GEMS_CVAR_SOLO_INTERRANGE_OPT_30"] = "30 yards (full screen visible)" -- MT
L["GEMS_CVAR_SOLO_INTERRANGE_DESCLONG"] =
    "Sets the maximum distance the soft-target picker uses for interactable objects -- ore nodes, herbs, mailboxes, NPCs, quest items. 10 yards (the default, and the EMS recommendation) matches the actual interact range the game enforces, so the soft target only lights up when you can actually reach the object. Raising it gives you an earlier visual hint that something is nearby but you still need to walk into actual interact range to use it; useful for quest hubs or gathering zones where you want a heads-up. Lower it if soft targeting is grabbing too many objects in dense areas." -- MT

L["GEMS_CVAR_COMBAT_PROCOPACITY_OPT_025"] = "25% (barely visible)" -- MT
L["GEMS_CVAR_COMBAT_PROCOPACITY_OPT_050"] = "50% (subdued)" -- MT
L["GEMS_CVAR_COMBAT_PROCOPACITY_OPT_065"] = "65% (default)" -- MT
L["GEMS_CVAR_COMBAT_PROCOPACITY_OPT_085"] = "85% (strong)" -- MT
L["GEMS_CVAR_COMBAT_PROCOPACITY_OPT_100"] = "100% (full)" -- MT
L["GEMS_CVAR_COMBAT_PROCOPACITY_DESCLONG"] =
    "Sets the opacity of the spell-activation glow -- the coloured aura that lights up around your action bars when a proc is ready (Tidal Waves, Hot Streak, Spotlight, and so on). 65% (the default, and the EMS recommendation) is bright enough to catch your eye without overpowering the action-bar icons. Lower it if the glow is distracting; raise it if you keep missing procs on a busy UI." -- MT

L["GEMS_CVAR_FCT_DIRSCALE_OPT_070"] = "70% (subtle)" -- MT
L["GEMS_CVAR_FCT_DIRSCALE_OPT_085"] = "85% (small)" -- MT
L["GEMS_CVAR_FCT_DIRSCALE_OPT_100"] = "100% (default)" -- MT
L["GEMS_CVAR_FCT_DIRSCALE_OPT_125"] = "125% (large)" -- MT
L["GEMS_CVAR_FCT_DIRSCALE_OPT_150"] = "150% (exaggerated)" -- MT
L["GEMS_CVAR_FCT_DIRSCALE_DESCLONG"] =
    "Sets how much the floating-combat-text numbers grow when damage comes from a specific direction. 100% (the default, and the EMS recommendation) shows numbers at their normal size. Lower values tamp down the directional emphasis if combat text is cluttering your view. Higher values exaggerate hits from your front and sides, useful for tanks who use damage direction as a positional cue." -- MT

L["GEMS_CVAR_SOLO_LOOTRATE_OPT_50"] = "50 ms (snappy)" -- MT
L["GEMS_CVAR_SOLO_LOOTRATE_OPT_100"] = "100 ms (fast)" -- MT
L["GEMS_CVAR_SOLO_LOOTRATE_OPT_150"] = "150 ms (Blizzard default)" -- MT
L["GEMS_CVAR_SOLO_LOOTRATE_OPT_250"] = "250 ms (relaxed)" -- MT
L["GEMS_CVAR_SOLO_LOOTRATE_OPT_500"] = "500 ms (slow)" -- MT
L["GEMS_CVAR_SOLO_LOOTRATE_DESCLONG"] =
    "Sets the polling interval for auto-loot in milliseconds. Lower values process loot pickups faster but check the loot system more often. 50 ms (the EMS recommendation) makes auto-loot feel near-instant on a single corpse and matters most during mass mob clears where you skim past dozens of bodies. 150 ms is the Blizzard default and is fine for normal play. Higher values are mainly useful if you are hunting CPU savings on a weak machine." -- MT

L["GEMS_CVAR_DUNGEON_LOGTIME_OPT_60"] = "1 minute (very short)" -- MT
L["GEMS_CVAR_DUNGEON_LOGTIME_OPT_180"] = "3 minutes (short)" -- MT
L["GEMS_CVAR_DUNGEON_LOGTIME_OPT_300"] = "5 minutes (default)" -- MT
L["GEMS_CVAR_DUNGEON_LOGTIME_OPT_600"] = "10 minutes (long)" -- MT
L["GEMS_CVAR_DUNGEON_LOGTIME_OPT_1800"] = "30 minutes (very long)" -- MT
L["GEMS_CVAR_DUNGEON_LOGTIME_DESCLONG"] =
    "Sets how long the in-memory combat log keeps events before discarding them. 5 minutes (the default, and the EMS recommendation) covers most boss fights with margin for trash before. Raise it for long fights where you want to scrub back through several pulls worth of events; drop it on weaker hardware where the in-memory log is causing FPS dips during heavy AoE." -- MT

L["GEMS_CVAR_UI_TUTORIALS_OPT_0"] = "Off (hide tutorial pop-ups)" -- MT
L["GEMS_CVAR_UI_TUTORIALS_OPT_1"] = "On (show tutorial pop-ups)" -- MT
L["GEMS_CVAR_UI_TUTORIALS_DESCLONG"] =
    "Controls whether Blizzard's tutorial pop-ups appear as you play. Off (the EMS recommendation) hides them entirely, which is what most players past their first character want. On (the default) shows the standard tutorial prompts Blizzard added to teach UI features." -- MT

L["GEMS_CVAR_UI_NPE_OPT_0"] = "Off (skip new-player overlays)" -- MT
L["GEMS_CVAR_UI_NPE_OPT_1"] = "On (show new-player overlays)" -- MT
L["GEMS_CVAR_UI_NPE_DESCLONG"] =
    "Controls whether the New Player Experience overlays appear during early-level questing. Off (the EMS recommendation) hides the NPE prompts, which are aimed at brand-new accounts and feel intrusive on alts. On (the default) shows the full NPE walkthrough Blizzard ships for first-time players." -- MT

L["GEMS_CVAR_UI_LOADTIPS_OPT_0"] = "Off (blank loading screen)" -- MT
L["GEMS_CVAR_UI_LOADTIPS_OPT_1"] = "On (show tips during loading)" -- MT
L["GEMS_CVAR_UI_LOADTIPS_DESCLONG"] =
    "Shows helpful tips on the loading screen while you wait for a zone to finish loading. Off leaves the loading bar blank. On (the default, and the EMS recommendation) shows rotating tips and lore snippets, which makes loading screens less dead time. This setting resets each time you log in and does not persist across sessions." -- MT

L["GEMS_CVAR_UI_COMPARE_OPT_0"] = "Off (require Shift to compare)" -- MT
L["GEMS_CVAR_UI_COMPARE_OPT_1"] = "On (always show comparison)" -- MT
L["GEMS_CVAR_UI_COMPARE_DESCLONG"] =
    "Controls whether item tooltips automatically show a side-by-side comparison with whatever you currently have equipped. Off requires Shift while hovering to bring up the compare panel. On (the default, and the EMS recommendation) always shows comparisons, which saves a keypress every time you loot or browse the auction house." -- MT

L["GEMS_CVAR_UI_TOOLTIPS_OPT_0"] = "Off (basic tooltip text)" -- MT
L["GEMS_CVAR_UI_TOOLTIPS_OPT_1"] = "On (full stats and details)" -- MT
L["GEMS_CVAR_UI_TOOLTIPS_DESCLONG"] =
    "Controls how much detail item and ability tooltips show. Off uses a stripped-down tooltip with only the basics. On (the default, and the EMS recommendation) shows full stats, item level, slot type, and set-bonus information, which is what every modern UI relies on." -- MT

L["GEMS_CVAR_UI_TRANSMOG_OPT_0"] = "Off (no appearance highlight)" -- MT
L["GEMS_CVAR_UI_TRANSMOG_OPT_1"] = "On (tag unknown appearances)" -- MT
L["GEMS_CVAR_UI_TRANSMOG_DESCLONG"] =
    "Highlights items whose appearance you have not yet collected for transmog. Off (the default) gives no indication. On (the EMS recommendation) tags missing-appearance gear directly in item tooltips, which is what transmog collectors want when running old content. This is a per-character setting, since alts can be at different points in the collection." -- MT

L["GEMS_CVAR_UI_EDGEFLASH_OPT_0"] = "Off (no edge flash)" -- MT
L["GEMS_CVAR_UI_EDGEFLASH_OPT_1"] = "On (flash at low health)" -- MT
L["GEMS_CVAR_UI_EDGEFLASH_DESCLONG"] =
    "Controls the red flash around the screen edges when you take heavy damage or your health drops low. Off removes the flash entirely. On (the default, and the EMS recommendation) keeps the visual cue, which is a useful low-attention warning when you are focused on your rotation instead of your health bar." -- MT

L["GEMS_CVAR_UI_BUBBLES_OPT_0"] = "Off (no floating speech)" -- MT
L["GEMS_CVAR_UI_BUBBLES_OPT_1"] = "On (show floating speech bubbles)" -- MT
L["GEMS_CVAR_UI_BUBBLES_DESCLONG"] =
    "Controls whether NPC and player chat appears as floating speech bubbles over their heads in addition to the chat frame. Off only shows messages in the chat window. On (the default, and the EMS recommendation) adds the floating bubbles, which makes it easier to follow conversations in busy areas without watching the chat log." -- MT

L["GEMS_CVAR_UI_BIGNUMS_OPT_0"] = "Off (raw digits like 1234567)" -- MT
L["GEMS_CVAR_UI_BIGNUMS_OPT_1"] = "On (grouped digits like 1,234,567)" -- MT
L["GEMS_CVAR_UI_BIGNUMS_DESCLONG"] =
    "Adds thousand separators (commas or periods, depending on locale) to large numbers in tooltips and the UI. Off shows raw digit strings like 1234567. On (the default, and the EMS recommendation) shows 1,234,567, which is much easier to read at a glance for damage numbers, gold totals, and item stats." -- MT

L["GEMS_CVAR_UI_BUFFDUR_OPT_0"] = "Off (no countdown on icons)" -- MT
L["GEMS_CVAR_UI_BUFFDUR_OPT_1"] = "On (show seconds remaining)" -- MT
L["GEMS_CVAR_UI_BUFFDUR_DESCLONG"] =
    "Shows the seconds remaining on buff and debuff icons in the default UI. Off shows only the icon and stack count. On (the default, and the EMS recommendation) overlays a countdown timer, which is what you want for tracking cooldown durations, stack timers, and time-sensitive buffs." -- MT

L["GEMS_CVAR_UI_FSTACK_OPT_0"] = "Off (no debug overlay)" -- MT
L["GEMS_CVAR_UI_FSTACK_OPT_1"] = "On (show frame stack debug)" -- MT
L["GEMS_CVAR_UI_FSTACK_DESCLONG"] =
    "Toggles the frame stack debug overlay, a tool that shows which UI frame is under your mouse cursor. Off (the default, and the EMS recommendation) is what every player wants. On is a developer aid for troubleshooting an addon UI bug. This resets each session and does not persist." -- MT

L["GEMS_CVAR_UI_RAWMOUSE_OPT_0"] = "Off (standard mouse path)" -- MT
L["GEMS_CVAR_UI_RAWMOUSE_OPT_1"] = "On (bypass OS acceleration)" -- MT
L["GEMS_CVAR_UI_RAWMOUSE_DESCLONG"] =
    "Toggles raw mouse input mode, which bypasses Windows pointer acceleration and reads input directly from the device. Off (the default, and the EMS recommendation) uses the standard mouse path, which is what nearly every player wants. On is a niche option for players who prefer a 1:1 input feel and have already disabled OS acceleration. This resets each session." -- MT

L["GEMS_CVAR_UI_TAINT_OPT_0"] = "Off (no taint logging)" -- MT
L["GEMS_CVAR_UI_TAINT_OPT_1"] = "On (write taint events to disk)" -- MT
L["GEMS_CVAR_UI_TAINT_DESCLONG"] =
    "Toggles taint logging, which writes UI taint events to a file for addon debugging. Off (the default, and the EMS recommendation) keeps taint logging silent. On is for addon authors investigating taint chains and adds disk I/O. This resets each session." -- MT

L["GEMS_CVAR_UI_BAGS_OPT_0"] = "Off (separate bag windows)" -- MT
L["GEMS_CVAR_UI_BAGS_OPT_1"] = "On (single combined bag)" -- MT
L["GEMS_CVAR_UI_BAGS_DESCLONG"] =
    "Controls whether the bag UI shows as a single combined window or as separate panels per bag. Off (the default) gives you four separate bag frames. On (the EMS recommendation) merges everything into one combined window, which is the modern bag UI Blizzard added in Dragonflight." -- MT

L["GEMS_CVAR_UI_ROTATEMM_OPT_0"] = "Off (north stays at top)" -- MT
L["GEMS_CVAR_UI_ROTATEMM_OPT_1"] = "On (rotates with facing)" -- MT
L["GEMS_CVAR_UI_ROTATEMM_DESCLONG"] =
    "Controls whether the minimap rotates as you turn your character or stays fixed with north at the top. Off (the default, and the EMS recommendation) keeps north pinned, which makes the minimap behave like a map you would read on a table. On rotates it so the top always points the direction you face, which some players find more intuitive but most experienced players find disorienting." -- MT

-- L372 Wave 12: Section 7 non-toggle CVars + WAVE10c SoftTargetArc trio (2026-05-19)
L["GEMS_CVAR_UI_SSFORMAT_OPT_JPEG"] = "JPEG (small files, lossy)" -- MT
L["GEMS_CVAR_UI_SSFORMAT_OPT_PNG"] = "PNG (lossless, mid size)" -- MT
L["GEMS_CVAR_UI_SSFORMAT_OPT_TGA"] = "TGA (lossless, large files)" -- MT
L["GEMS_CVAR_UI_SSFORMAT_DESCLONG"] =
    "File format the game writes to your Screenshots folder. JPEG keeps file size down at the cost of compression artefacts. TGA and PNG are lossless. EMS picks TGA because guides and transmog comparisons need pixel-accurate screenshots." -- MT
L["GEMS_CVAR_UI_SSQUALITY_OPT_01"] = "1 (lowest)" -- MT
L["GEMS_CVAR_UI_SSQUALITY_OPT_03"] = "3 (default)" -- MT
L["GEMS_CVAR_UI_SSQUALITY_OPT_05"] = "5 (medium)" -- MT
L["GEMS_CVAR_UI_SSQUALITY_OPT_08"] = "8 (high)" -- MT
L["GEMS_CVAR_UI_SSQUALITY_OPT_10"] = "10 (max)" -- MT
L["GEMS_CVAR_UI_SSQUALITY_DESCLONG"] =
    "JPEG compression quality, 1 to 10. Lower values produce smaller files with more visible artefacts. Has no effect when screenshotFormat is set to TGA or PNG, since those formats are already lossless. If you stay on JPEG, 10 is the right pick." -- MT
L["GEMS_CVAR_UI_ZOOM_OPT_100"] = "1.0 (15 yards)" -- MT
L["GEMS_CVAR_UI_ZOOM_OPT_150"] = "1.5 (22.5 yards)" -- MT
L["GEMS_CVAR_UI_ZOOM_OPT_190"] = "1.9 (28.5 yards, default)" -- MT
L["GEMS_CVAR_UI_ZOOM_OPT_220"] = "2.2 (33 yards)" -- MT
L["GEMS_CVAR_UI_ZOOM_OPT_260"] = "2.6 (39 yards, max)" -- MT
L["GEMS_CVAR_UI_ZOOM_DESCLONG"] =
    "Multiplier on the camera's max zoom-out distance. The engine caps at 2.6, which gives roughly 39 yards out from the player. The default 1.9 (28.5 yards) feels cramped on melee classes trying to see swirly mechanics at the edge of the screen. EMS picks the max." -- MT
L["GEMS_CVAR_UI_COMBOPT_OPT_1"] = "On target" -- MT
L["GEMS_CVAR_UI_COMBOPT_OPT_2"] = "On player (below resource bar)" -- MT
L["GEMS_CVAR_UI_COMBOPT_DESCLONG"] =
    "Where the combo-point UI element draws. Set to 1 to show points above the targeted unit's nameplate; 2 (the default) shows them on the player below the personal resource display. EMS keeps the default." -- MT
L["GEMS_CVAR_COMBAT_SOFTARC_OPT_0"] = "Straight ahead only" -- MT
L["GEMS_CVAR_COMBAT_SOFTARC_OPT_1"] = "Front arc" -- MT
L["GEMS_CVAR_COMBAT_SOFTARC_OPT_2"] = "Anywhere in tab area" -- MT
L["GEMS_CVAR_COMBAT_SOFTARC_DESCLONG"] =
    "How wide the yaw arc is for picking a soft-target enemy. 0 only selects mobs directly in front of you. 1 selects within a narrow front arc. 2 selects anywhere in the tab-target search area. Default and recommended is 2 for the widest catch." -- MT
L["GEMS_CVAR_COMBAT_FRIENDARC_OPT_0"] = "Straight ahead only" -- MT
L["GEMS_CVAR_COMBAT_FRIENDARC_OPT_1"] = "Front arc" -- MT
L["GEMS_CVAR_COMBAT_FRIENDARC_OPT_2"] = "Anywhere in targeting area" -- MT
L["GEMS_CVAR_COMBAT_FRIENDARC_DESCLONG"] =
    "How wide the yaw arc is for picking a soft-target friendly. Mirrors the enemy version: 0 directly ahead, 1 narrow front arc, 2 anywhere in the targeting area. Default and recommended is 2." -- MT
L["GEMS_CVAR_SOLO_INTERARC_OPT_0"] = "Straight ahead only" -- MT
L["GEMS_CVAR_SOLO_INTERARC_OPT_1"] = "Front arc" -- MT
L["GEMS_CVAR_SOLO_INTERARC_OPT_2"] = "Anywhere in targeting area" -- MT
L["GEMS_CVAR_SOLO_INTERARC_DESCLONG"] =
    "How wide the yaw arc is for the interact (Tab-to-loot, NPC click) softtarget. The default 0 only catches things directly in front, which often misses corpses or NPCs at a slight angle. EMS picks 1 (the narrow front arc), wider than the default but narrow enough to avoid accidental selection." -- MT
L["GEMS_CVAR_MACRO_KEYHELD_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_MACRO_KEYHELD_OPT_1"] = "On" -- MT
L["GEMS_CVAR_MACRO_KEYHELD_DESCLONG"] =
    "Activates the press-and-hold cast option on key-down. When On, holding the key past the cast triggers an error-retry path some macros use for repeat-cast behaviour. Default Off works for almost everyone." -- MT
L["GEMS_CVAR_MACRO_AUTOSTAND_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_MACRO_AUTOSTAND_OPT_1"] = "On" -- MT
L["GEMS_CVAR_MACRO_AUTOSTAND_DESCLONG"] =
    "Automatically stands your character when you cast a spell that requires standing. With this Off you have to /stand by hand before any seated cast works. Leave On unless you want strict seated control." -- MT
L["GEMS_CVAR_MACRO_AUTOUNSHIFT_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_MACRO_AUTOUNSHIFT_OPT_1"] = "On" -- MT
L["GEMS_CVAR_MACRO_AUTOUNSHIFT_DESCLONG"] =
    "Automatically leaves your shapeshift form (Druid form, Warrior stance, Evoker hover) when you cast a spell that cannot be cast in the current form. With this Off the cast fails and you have to shift out by hand. Leave On for normal play." -- MT
L["GEMS_CVAR_MACRO_STOPATTACK_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_MACRO_STOPATTACK_OPT_1"] = "On" -- MT
L["GEMS_CVAR_MACRO_STOPATTACK_DESCLONG"] =
    "Stops your auto-attack when you switch targets. With this On a target swap makes you stop swinging; you have to re-engage with /startattack. The default Off keeps you swinging through target swaps. This is a per-character setting." -- MT
L["GEMS_CVAR_MACRO_ICONRATE_OPT_000"] = "0 sec (every frame)" -- MT
L["GEMS_CVAR_MACRO_ICONRATE_OPT_005"] = "0.05 sec (responsive)" -- MT
L["GEMS_CVAR_MACRO_ICONRATE_OPT_010"] = "0.10 sec (default)" -- MT
L["GEMS_CVAR_MACRO_ICONRATE_OPT_025"] = "0.25 sec (low overhead)" -- MT
L["GEMS_CVAR_MACRO_ICONRATE_OPT_050"] = "0.50 sec (very low overhead)" -- MT
L["GEMS_CVAR_MACRO_ICONRATE_DESCLONG"] =
    "How often the assisted-combat action-bar icon refreshes, in seconds. Lower values are more responsive but cost a small amount of CPU each frame; higher values save CPU at the cost of a slightly slower icon swap. EMS recommends 0.05 which keeps the icon snappy without measurable overhead." -- MT
L["GEMS_CVAR_MACRO_CDCOUNT_OPT_0"] = "Off (radial swipe)" -- MT
L["GEMS_CVAR_MACRO_CDCOUNT_OPT_1"] = "On (number countdown)" -- MT
L["GEMS_CVAR_MACRO_CDCOUNT_DESCLONG"] =
    "Replaces the spinning radial cooldown overlay on action buttons with a numeric countdown. The Blizzard default is the radial swipe; EMS recommends the number countdown because it is easier to read at a glance while watching a sequence run." -- MT
L["GEMS_CVAR_MACRO_SECTOGGLE_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_MACRO_SECTOGGLE_OPT_1"] = "On" -- MT
L["GEMS_CVAR_MACRO_SECTOGGLE_DESCLONG"] =
    "Protects you from accidentally double-clicking a toggle ability (Shadow Form, Skirmisher, etc.) and turning it back off. With this Off a fast double-click can deactivate the toggle; the default On treats the second click as a no-op. Leave On for normal play." -- MT
L["GEMS_CVAR_MACRO_EMPTAP_OPT_0"] = "Off (press-hold-release)" -- MT
L["GEMS_CVAR_MACRO_EMPTAP_OPT_1"] = "On (tap-tap)" -- MT
L["GEMS_CVAR_MACRO_EMPTAP_DESCLONG"] =
    "Evoker only. Changes how Empower spells trigger. Default Off uses press-hold-release: hold the key to charge stages, release to fire. On switches to a tap-tap scheme where each tap advances the stage. Pick the scheme that matches your macros. This is a per-character setting." -- MT
L["GEMS_CVAR_MACRO_EMPHOLD_OPT_000"] = "0.00 (release any time)" -- MT
L["GEMS_CVAR_MACRO_EMPHOLD_OPT_025"] = "0.25 (release after 25%)" -- MT
L["GEMS_CVAR_MACRO_EMPHOLD_OPT_050"] = "0.50 (release after 50%)" -- MT
L["GEMS_CVAR_MACRO_EMPHOLD_OPT_075"] = "0.75 (release after 75%)" -- MT
L["GEMS_CVAR_MACRO_EMPHOLD_OPT_100"] = "1.00 (full first stage required)" -- MT
L["GEMS_CVAR_MACRO_EMPHOLD_DESCLONG"] =
    "Evoker only. Sets the minimum portion of an Empower spell's first stage you must hold before a release is accepted. The default 1.00 requires the full first stage to elapse before any release fires; lower values let you release earlier at the cost of accidental misfires. Tune this if Empower macros feel like they release too early or too late." -- MT
L["GEMS_CVAR_MACRO_PRECAST_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_MACRO_PRECAST_OPT_1"] = "On" -- MT
L["GEMS_CVAR_MACRO_PRECAST_DESCLONG"] =
    "Enables preemptive cast visuals: the cast animation can begin before the spell release timing fully confirms. This resets each session and does not persist across logouts. Leave Off unless you are testing visual latency." -- MT
L["GEMS_CVAR_NAMEPLATES_SHOWALL_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_SHOWALL_OPT_1"] = "On" -- MT
L["GEMS_CVAR_NAMEPLATES_SHOWALL_DESCLONG"] =
    "Turns on every nameplate category at once: enemies, friendly NPCs, pets, guardians, and totems. The individual category toggles below still apply -- this is the master switch. EMS recommends On because nameplates are the primary mechanic-tracking surface in modern WoW; the Blizzard default Off was set when nameplates were a niche feature." -- MT
L["GEMS_CVAR_NAMEPLATES_SHOWSELF_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_SHOWSELF_OPT_1"] = "On" -- MT
L["GEMS_CVAR_NAMEPLATES_SHOWSELF_DESCLONG"] =
    "Shows the personal resource display: a nameplate floating below your character with your own health and resource. EMS recommends On because resource-gated rotations are easier to read off the personal plate than the unit frame. This is a per-character setting." -- MT
L["GEMS_CVAR_NAMEPLATES_CASTBARS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_CASTBARS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_NAMEPLATES_CASTBARS_DESCLONG"] =
    "Shows cast bars under each unit nameplate so you can see what mob is casting and when. On is the default and the right answer for almost every player; Off only makes sense if you have a dedicated cast tracker that draws over the nameplates. This is a per-character setting." -- MT
L["GEMS_CVAR_NAMEPLATES_CLASSCOLOR_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_CLASSCOLOR_OPT_1"] = "On" -- MT
L["GEMS_CVAR_NAMEPLATES_CLASSCOLOR_DESCLONG"] =
    "Colours enemy player nameplate health bars by class so you can spot a Mage vs a Warrior at a glance. On is the default. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_NAMEPLATES_DEBUFFS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_DEBUFFS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_NAMEPLATES_DEBUFFS_DESCLONG"] =
    "Shows debuff icons on friendly nameplates so you can see who needs a dispel or a cleanse. On is the default. Turn Off only if you run a dedicated raid frame that already surfaces these debuffs. This is a per-character setting." -- MT
L["GEMS_CVAR_NAMEPLATES_MINIONS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_MINIONS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_NAMEPLATES_MINIONS_DESCLONG"] =
    "Shows nameplates for enemy minions (Warlock pets, Hunter pets, Death Knight pets, mage water-elemental, etc.). Off is the default and keeps PvE clutter down. Turn On for PvP where you may want to focus a pet to cleave its owner." -- MT
L["GEMS_CVAR_NAMEPLATES_MINUS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_MINUS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_NAMEPLATES_MINUS_DESCLONG"] =
    "Shows nameplates for trash mobs marked as weaker than you (the minus-sign mobs in the world). On is the default and you want it on for any AoE-tagging or open-world farming." -- MT
L["GEMS_CVAR_NAMEPLATES_TOTEMS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_TOTEMS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_NAMEPLATES_TOTEMS_DESCLONG"] =
    "Shows nameplates for enemy totems. EMS recommends On because hostile totems carry mechanic-critical information (Storm Totem damage, Healing Stream Totem healing, Capacitor Totem stun timer); the Blizzard default Off hides them behind the totem 3D model." -- MT
L["GEMS_CVAR_NAMEPLATES_FRIENDLY_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_FRIENDLY_OPT_1"] = "On" -- MT
L["GEMS_CVAR_NAMEPLATES_FRIENDLY_DESCLONG"] =
    "Shows nameplates for friendly players (your raid, your party, your guild). Off is the default and the right answer in raids -- friendly nameplates carry an FPS cost because each plate processes aura updates whether the plate is visible or not. Turn On only in BG/Arena where you want to track friendly positions." -- MT
L["GEMS_CVAR_NAMEPLATES_NAMEONLY_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_NAMEONLY_OPT_1"] = "On" -- MT
L["GEMS_CVAR_NAMEPLATES_NAMEONLY_DESCLONG"] =
    "When On, friendly player nameplates collapse to just the name (no health bar, no resource bar). Pairs naturally with friendly-nameplates being On. Off is the default. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_NAMEPLATES_ATBASE_OPT_0"] = "Off (overhead)" -- MT
L["GEMS_CVAR_NAMEPLATES_ATBASE_OPT_1"] = "On (at base)" -- MT
L["GEMS_CVAR_NAMEPLATES_ATBASE_DESCLONG"] =
    "Positions nameplates at the unit's feet (On) rather than over its head (Off, default). Some players prefer base-positioned plates because they line up with ground swirls and AoE markers, but the default overhead position keeps the plate clear of ground effects." -- MT
L["GEMS_CVAR_NAMEPLATES_OFFSCREEN_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_OFFSCREEN_OPT_1"] = "On" -- MT
L["GEMS_CVAR_NAMEPLATES_OFFSCREEN_DESCLONG"] =
    "Keeps a nameplate visible at the edge of your screen when its owner is in combat with you or with someone in your group, even if the unit itself is off-screen. Off is the default. On is useful in fights where you must track a mob you cannot see (back-camera bosses, ranged adds)." -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTNP_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTNP_OPT_1"] = "On" -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTNP_DESCLONG"] =
    "Forces a nameplate to always be visible on your soft enemy target (the auto-acquired target you have not hard-clicked yet). On is the default and pairs with the soft-targeting system from the Combat section." -- MT
L["GEMS_CVAR_NAMEPLATES_RADIAL_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_RADIAL_OPT_1"] = "Target Only" -- MT
L["GEMS_CVAR_NAMEPLATES_RADIAL_OPT_2"] = "All In Combat" -- MT
L["GEMS_CVAR_NAMEPLATES_RADIAL_DESCLONG"] =
    "When a unit is off-screen, this setting decides whether to draw its nameplate radially around the edges of your screen instead of hiding it. Off (default) hides off-screen plates. Target Only draws a plate at the edge for your current target. All In Combat draws plates at the edges for every unit you are fighting -- useful when you must track several mobs at once but can be visually busy." -- MT
L["GEMS_CVAR_NAMEPLATES_MINALPHA_OPT_020"] = "0.2 (very faded)" -- MT
L["GEMS_CVAR_NAMEPLATES_MINALPHA_OPT_040"] = "0.4 (faded)" -- MT
L["GEMS_CVAR_NAMEPLATES_MINALPHA_OPT_060"] = "0.6 (default)" -- MT
L["GEMS_CVAR_NAMEPLATES_MINALPHA_OPT_080"] = "0.8 (readable)" -- MT
L["GEMS_CVAR_NAMEPLATES_MINALPHA_OPT_100"] = "1.0 (fully opaque)" -- MT
L["GEMS_CVAR_NAMEPLATES_MINALPHA_DESCLONG"] =
    "Sets the minimum opacity (alpha) of nameplates as they fade with distance. A nameplate fades from MaxAlpha at the close range down to MinAlpha at the far edge. EMS recommends 0.8 because the Blizzard default 0.6 lets distant plates drop to a hard-to-read 60% opacity; 0.8 keeps the text legible at every range while preserving the visual distance cue. This is a per-character setting." -- MT
L["GEMS_CVAR_NAMEPLATES_MAXALPHA_OPT_060"] = "0.6 (subtle)" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXALPHA_OPT_075"] = "0.75" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXALPHA_OPT_085"] = "0.85" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXALPHA_OPT_095"] = "0.95" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXALPHA_OPT_100"] = "1.0 (fully opaque)" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXALPHA_DESCLONG"] =
    "Sets the maximum opacity (alpha) of nameplates at close range. The default 1.0 is fully opaque and the right choice for almost everyone. Lower values bake in a permanent see-through look that pairs with very low MinAlpha for an art-style preference; there is no gameplay reason to drop it. This is a per-character setting." -- MT
L["GEMS_CVAR_NAMEPLATES_MINSCALE_OPT_050"] = "0.5 (very small)" -- MT
L["GEMS_CVAR_NAMEPLATES_MINSCALE_OPT_065"] = "0.65" -- MT
L["GEMS_CVAR_NAMEPLATES_MINSCALE_OPT_080"] = "0.8 (default)" -- MT
L["GEMS_CVAR_NAMEPLATES_MINSCALE_OPT_100"] = "1.0 (no shrink)" -- MT
L["GEMS_CVAR_NAMEPLATES_MINSCALE_OPT_120"] = "1.2 (larger far)" -- MT
L["GEMS_CVAR_NAMEPLATES_MINSCALE_DESCLONG"] =
    "Sets the minimum size of distant nameplates. The default 0.8 shrinks far plates to 80% of MaxScale so they read as smaller in the depth cue. Setting MinScale equal to MaxScale (e.g. both 1.0) disables the depth-scaling entirely so every plate is the same size at every range. This is a per-character setting." -- MT
L["GEMS_CVAR_NAMEPLATES_MAXSCALE_OPT_080"] = "0.8 (small)" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXSCALE_OPT_090"] = "0.9" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXSCALE_OPT_100"] = "1.0 (default)" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXSCALE_OPT_110"] = "1.1" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXSCALE_OPT_120"] = "1.2 (large)" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXSCALE_DESCLONG"] =
    "Sets the maximum size of nameplates at close range. The default 1.0 is the baseline. Larger values make close plates more readable at the cost of more screen real estate; smaller values keep the screen cleaner but cost some legibility. This is a per-character setting." -- MT
L["GEMS_CVAR_NAMEPLATES_SELSCALE_OPT_100"] = "1.0 (no bump)" -- MT
L["GEMS_CVAR_NAMEPLATES_SELSCALE_OPT_110"] = "1.1" -- MT
L["GEMS_CVAR_NAMEPLATES_SELSCALE_OPT_120"] = "1.2 (default)" -- MT
L["GEMS_CVAR_NAMEPLATES_SELSCALE_OPT_130"] = "1.3" -- MT
L["GEMS_CVAR_NAMEPLATES_SELSCALE_OPT_150"] = "1.5 (big bump)" -- MT
L["GEMS_CVAR_NAMEPLATES_SELSCALE_DESCLONG"] =
    "Sets the scale multiplier applied to the currently selected unit's nameplate. The default 1.2 enlarges your target's plate to 120% so it stands out in a crowd. Setting this to 1.0 disables the bump entirely; higher values make the target plate even more prominent. This is a per-character setting." -- MT
L["GEMS_CVAR_NAMEPLATES_OCCLUDED_OPT_020"] = "0.2 (mostly hidden)" -- MT
L["GEMS_CVAR_NAMEPLATES_OCCLUDED_OPT_040"] = "0.4 (default)" -- MT
L["GEMS_CVAR_NAMEPLATES_OCCLUDED_OPT_060"] = "0.6 (visible)" -- MT
L["GEMS_CVAR_NAMEPLATES_OCCLUDED_OPT_080"] = "0.8 (clear)" -- MT
L["GEMS_CVAR_NAMEPLATES_OCCLUDED_OPT_100"] = "1.0 (no fade)" -- MT
L["GEMS_CVAR_NAMEPLATES_OCCLUDED_DESCLONG"] =
    "Alpha multiplier applied to nameplates of targets behind walls or terrain (occluded line-of-sight). The Blizzard default 0.4 fades occluded plates down to 40% which is hard to track. EMS recommends 0.6 because tracking a mob you cannot directly see is exactly when you need its plate readable -- think peeling adds around a pillar, or a healer hiding behind a doorway in PvP. Setting this to 1.0 disables the fade entirely if you want full visibility. This is a per-character setting." -- MT
L["GEMS_CVAR_NAMEPLATES_AURASCALE_OPT_080"] = "0.8 (compact)" -- MT
L["GEMS_CVAR_NAMEPLATES_AURASCALE_OPT_100"] = "1.0 (default)" -- MT
L["GEMS_CVAR_NAMEPLATES_AURASCALE_OPT_120"] = "1.2 (larger)" -- MT
L["GEMS_CVAR_NAMEPLATES_AURASCALE_OPT_140"] = "1.4 (big)" -- MT
L["GEMS_CVAR_NAMEPLATES_AURASCALE_OPT_160"] = "1.6 (very big)" -- MT
L["GEMS_CVAR_NAMEPLATES_AURASCALE_DESCLONG"] =
    "Sets the size multiplier for the buff and debuff icons that show on each nameplate. EMS recommends 1.2 because the default 1.0 icons can vanish behind the unit name when several auras stack, and 1.2 keeps each icon legible without dominating the plate. Push higher (1.4 or 1.6) if you raid on a 4K display where the default reads small." -- MT
L["GEMS_CVAR_NAMEPLATES_PLAYERDIST_OPT_20"] = "20 yds (close only)" -- MT
L["GEMS_CVAR_NAMEPLATES_PLAYERDIST_OPT_41"] = "41 yds (raid-tuned)" -- MT
L["GEMS_CVAR_NAMEPLATES_PLAYERDIST_OPT_60"] = "60 yds (default)" -- MT
L["GEMS_CVAR_NAMEPLATES_PLAYERDIST_OPT_80"] = "80 yds (long)" -- MT
L["GEMS_CVAR_NAMEPLATES_PLAYERDIST_OPT_100"] = "100 yds (max)" -- MT
L["GEMS_CVAR_NAMEPLATES_PLAYERDIST_DESCLONG"] =
    "Maximum distance at which friendly-player nameplates are drawn. The default 60 yards is the right answer for almost every situation. Raid scenes use 41 yards to match the in-combat range cap, and short-range setups (5-man, PvP) can drop to 20 yards to declutter the screen. The 80 / 100 yard values are useful for outdoor world play or large pulls where you want to spot a friend at extreme range. This is a per-character setting." -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPH_OPT_050"] = "0.5 (tight)" -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPH_OPT_070"] = "0.7" -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPH_OPT_080"] = "0.8 (default)" -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPH_OPT_100"] = "1.0 (loose)" -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPH_OPT_120"] = "1.2 (very loose)" -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPH_DESCLONG"] =
    "Horizontal-overlap factor that controls how aggressively the nameplate engine spreads adjacent plates apart along the X axis. Lower values let plates sit closer together (tighter packing, more overlap); higher values force more horizontal separation. The default 0.8 is a balanced middle ground. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPV_OPT_080"] = "0.8 (tight)" -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPV_OPT_100"] = "1.0" -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPV_OPT_110"] = "1.1 (default)" -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPV_OPT_130"] = "1.3 (loose)" -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPV_OPT_150"] = "1.5 (very loose)" -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPV_DESCLONG"] =
    "Vertical-overlap factor that controls how aggressively the nameplate engine spreads adjacent plates apart along the Y axis. Lower values let plates sit closer together; higher values force more vertical separation. The default 1.1 leaves a small visual gap between stacked plates. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTSIZE_OPT_0"] = "0 (off)" -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTSIZE_OPT_19"] = "19 (default)" -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTSIZE_OPT_25"] = "25 (recommended)" -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTSIZE_OPT_35"] = "35 (large)" -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTSIZE_OPT_50"] = "50 (huge)" -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTSIZE_DESCLONG"] =
    "Size in pixels of the soft-target marker icon that overlays the current soft-target's nameplate. EMS recommends 25 because the Blizzard default 19 reads small on modern displays, especially in dense raid scenes; 25 makes the marker visible at a glance without dominating the plate. Set to 0 to disable the icon entirely if your nameplate addon draws its own target indicator." -- MT
L["GEMS_CVAR_NAMEPLATES_DEBUFFPAD_OPT_0"] = "0 (compact, default)" -- MT
L["GEMS_CVAR_NAMEPLATES_DEBUFFPAD_OPT_2"] = "2 px" -- MT
L["GEMS_CVAR_NAMEPLATES_DEBUFFPAD_OPT_4"] = "4 px" -- MT
L["GEMS_CVAR_NAMEPLATES_DEBUFFPAD_OPT_6"] = "6 px" -- MT
L["GEMS_CVAR_NAMEPLATES_DEBUFFPAD_OPT_8"] = "8 px (loose)" -- MT
L["GEMS_CVAR_NAMEPLATES_DEBUFFPAD_DESCLONG"] =
    "Padding in pixels between the debuff icon row and the health bar on each nameplate. The default 0 packs the row directly against the bar (compact). Higher values insert a gap so the debuffs read as a separate strip; useful on large nameplate scales or 4K displays where the debuff icons sit visually too close to the bar text." -- MT
L["GEMS_CVAR_DRAGON_DYNFOV_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_DRAGON_DYNFOV_OPT_1"] = "On" -- MT
L["GEMS_CVAR_DRAGON_DYNFOV_DESCLONG"] =
    "Widens the camera field of view as your gliding speed increases. On is the default and the right answer for almost every player -- the FOV stretch sells the sensation of speed during a dive. Turn Off if you find the dynamic FOV motion-sickening or if you prefer a fixed-frame look during long flights. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_DRAGON_MAXPITCH_OPT_30"] = "3.0 (slow)" -- MT
L["GEMS_CVAR_DRAGON_MAXPITCH_OPT_50"] = "5.0 (default)" -- MT
L["GEMS_CVAR_DRAGON_MAXPITCH_OPT_60"] = "6.0 (recommended)" -- MT
L["GEMS_CVAR_DRAGON_MAXPITCH_OPT_80"] = "8.0 (fast)" -- MT
L["GEMS_CVAR_DRAGON_MAXPITCH_OPT_100"] = "10.0 (very fast)" -- MT
L["GEMS_CVAR_DRAGON_MAXPITCH_DESCLONG"] =
    "Maximum pitch rate when steering Skyriding / Dragonriding with the keyboard. EMS recommends 6.0 because the Blizzard default 5.0 feels sluggish during reactive manoeuvres (avoiding map geometry, chasing a friend's slipstream); 6.0 gives the keyboard pitch parity with a mid-sensitivity mouse without overshooting on small inputs. Lower values give finer precision at the cost of slower turns." -- MT
L["GEMS_CVAR_DRAGON_MAXTURN_OPT_50"] = "5.0 (slow)" -- MT
L["GEMS_CVAR_DRAGON_MAXTURN_OPT_80"] = "8.0 (default)" -- MT
L["GEMS_CVAR_DRAGON_MAXTURN_OPT_100"] = "10.0 (recommended)" -- MT
L["GEMS_CVAR_DRAGON_MAXTURN_OPT_120"] = "12.0 (fast)" -- MT
L["GEMS_CVAR_DRAGON_MAXTURN_OPT_150"] = "15.0 (very fast)" -- MT
L["GEMS_CVAR_DRAGON_MAXTURN_DESCLONG"] =
    "Maximum turn rate when steering Skyriding / Dragonriding with the keyboard. EMS recommends 10.0 because the Blizzard default 8.0 caps your yaw rate below what the dragon can actually execute; 10.0 lets you carve tighter holding patterns around treasure spawns and pull off the half-cobra reversal during PvP duels. Lower values feel safer but cost time on every turn." -- MT
L["GEMS_CVAR_DRAGON_MINPITCH_OPT_15"] = "1.5 (very gentle)" -- MT
L["GEMS_CVAR_DRAGON_MINPITCH_OPT_25"] = "2.5 (default)" -- MT
L["GEMS_CVAR_DRAGON_MINPITCH_OPT_30"] = "3.0 (recommended)" -- MT
L["GEMS_CVAR_DRAGON_MINPITCH_OPT_40"] = "4.0 (sharper)" -- MT
L["GEMS_CVAR_DRAGON_MINPITCH_OPT_50"] = "5.0 (sharpest)" -- MT
L["GEMS_CVAR_DRAGON_MINPITCH_DESCLONG"] =
    "Minimum pitch rate -- the floor that small keyboard taps produce. EMS recommends 3.0 because the Blizzard default 2.5 makes light corrective taps feel mushy; 3.0 gives every tap a noticeable nose change so you can fine-tune your dive angle without overcommitting. Lower values feel more cinematic; higher values feel snappier." -- MT
L["GEMS_CVAR_DRAGON_PITCHCTRL_OPT_1"] = "1 (Forward/Up)" -- MT
L["GEMS_CVAR_DRAGON_PITCHCTRL_OPT_2"] = "2 (Backward/Up)" -- MT
L["GEMS_CVAR_DRAGON_PITCHCTRL_OPT_3"] = "3 (Default, recommended)" -- MT
L["GEMS_CVAR_DRAGON_PITCHCTRL_DESCLONG"] =
    "Helps with hand motor function during Skyriding by remapping which keyboard input pitches your dragon up. Default 3 (Default) uses Blizzard's standard pitch behaviour -- pitch follows mouse and spacebar, forward and backward inputs are used purely for thrust. Set to 1 (Forward/Up) if you want the Move Forward key to also pitch the dragon up (and Move Backward to pitch down) -- useful for players who find combined mouse+forward inputs physically demanding. Set to 2 (Backward/Up) for the inverse mapping (Move Backward pitches up, Move Forward pitches down). Blizzard's official description: \"Helps to address hand motor function while skyriding.\" EMS does not auto-detect your accessibility needs; pick the option that matches your physical comfort." -- MT

-- ExportAsText labels (POLISH-EXPORTASTEXT-LOCALE, Backlog L97)
L["GEMS_EXPORTTEXT_SEQUENCE_LABEL"] = "Sequence: " -- MT
L["GEMS_EXPORTTEXT_AUTHOR_LABEL"] = "Author: " -- MT
L["GEMS_EXPORTTEXT_AUTHOR_UNKNOWN"] = "(unknown)" -- MT
L["GEMS_EXPORTTEXT_SPEC_LABEL"] = "Spec: " -- MT
L["GEMS_EXPORTTEXT_STEPFUNCTION_LABEL"] = "Step Function: " -- MT
L["GEMS_EXPORTTEXT_ICON_LABEL"] = "Icon: " -- MT
L["GEMS_EXPORTTEXT_VERSIONS_LABEL"] = "Versions: " -- MT
L["GEMS_EXPORTTEXT_VARIABLES_HEADING"] = "Variables:" -- MT
L["GEMS_EXPORTTEXT_MACROS_HEADING"] = "Macros:" -- MT
L["GEMS_EXPORTTEXT_VARIABLE_EVENT_SUFFIX"] = " (Event: %s)" -- MT
L["GEMS_EXPORTTEXT_VERSION_HEADING"] = "Version %d:" -- MT
L["GEMS_EXPORTTEXT_VERSION_HEADING_DEFAULT"] = "Version %d (Default):" -- MT
L["GEMS_EXPORTTEXT_RESET_LABEL"] = "  Reset: " -- MT
L["GEMS_EXPORTTEXT_STEPS_HEADING"] = "  Steps:" -- MT
L["GEMS_EXPORTTEXT_STEPS_NONE"] = "    (none)" -- MT
L["GEMS_EXPORTTEXT_ACTIONS_HEADING"] = "  Actions:" -- MT
L["GEMS_EXPORTTEXT_KEYPRESS_LABEL"] = "  Key Press: " -- MT
L["GEMS_EXPORTTEXT_KEYRELEASE_LABEL"] = "  Key Release: " -- MT

-- v2.1.6 Author Picker
L["GEMS_AUTHOR_PICKER_PSEUDONYM"] = "%s (pseudonym)" -- MT
L["GEMS_AUTHOR_PICKER_CURRENT"] = "%s (this character)" -- MT
L["GEMS_AUTHOR_PICKER_ALT"] = "%s (%s)" -- MT

-- v2.2.0 Per-loadout keybinds (L127)
L["GEMS_KEYBINDS_PER_LOADOUT_TOGGLE"] = "Per-loadout keybinds" -- MT
L["GEMS_KEYBINDS_PER_LOADOUT_TOGGLE_TOOLTIP"] =
    "When on, new keybinds bind to the currently active talent loadout. Per-spec keybinds set previously stay as a fallback for loadouts with no override." -- MT
L["GEMS_KEYBINDS_SUPPRESS_IN_LOADOUT"] = "Suppress in this loadout" -- MT
L["GEMS_KEYBINDS_SUPPRESS_IN_LOADOUT_TOOLTIP"] =
    "Hide this per-spec binding while this loadout is active. The binding stays active in other loadouts of this spec." -- MT
L["GEMS_KEYBINDS_ACTIVE_LOADOUT_LABEL"] = "Active loadout: %s" -- MT
L["GEMS_KEYBINDS_NO_ACTIVE_LOADOUT"] = "No active loadout (per-spec bindings only)." -- MT
L["GEMS_KEYBINDS_FALLBACK_NOTICE"] = "Showing per-spec fallback bindings." -- MT
L["GEMS_KEYBINDS_COPY_BUTTON"] = "Copy bindings from another loadout" -- MT
L["GEMS_KEYBINDS_MANAGE_ALL"] = "Manage all loadouts" -- MT
L["GEMS_KEYBINDS_LOADOUT_BINDING_COUNT"] = "%s: %d binding(s)" -- MT
L["GEMS_HELP_BIND_LOADOUT_FLAG"] =
    "  /gems bind <name> <key> [--loadout <id-or-name>] - bind to a specific loadout (default: active loadout if per-loadout mode is on)" -- MT
L["GEMS_BIND_LOADOUT_NOT_FOUND"] = "Loadout '%s' not found for current spec." -- MT
L["GEMS_KEYBINDS_LOADOUT_OVERRIDES_HINT"] = "  + %d loadout(s) with overrides" -- MT
L["GEMS_RESERVED_NAME"] = "Sequence name '%s' is reserved and cannot be used." -- MT

L["GEMS_REPARENT_DEPTH_REJECT"] =
    "无法放置在此处 -- 这会超过最大嵌套深度 (%d)。请将其移动到更浅的循环中。" -- TODO: MT 2026-06-21
-- Auto-mirrored from enUS for prefix GEMS_ADD_MENU_DEPTH_CAP_HINT (cowork_util fix-locale-parity 2026-05-25)
L["GEMS_ADD_MENU_DEPTH_CAP_HINT"] =
    "Max nesting depth (%d) reached -- add disabled here. Reduce nesting in a parent container to enable additions." -- MT

-- Auto-mirrored from enUS for prefix GEMS_SETTINGS_CHAR (cowork_util fix-locale-parity 2026-05-25)
L["GEMS_SETTINGS_CHAR_CLICK_RATE_WARN"] = "Your setting: %dms (%dms faster than the %dms human/hardware floor)" -- MT

-- Auto-mirrored from enUS for prefix GEMS_VARIANT_ (cowork_util fix-locale-parity 2026-05-26)
L["GEMS_VARIANT_ADDED"] = "Added variant '%s' to %s (modifier: %s)." -- MT
L["GEMS_VARIANT_BAD_MODIFIER"] = "Invalid modifier '%s'. Must be one of: shift, ctrl, alt." -- MT
L["GEMS_VARIANT_DUP_MODIFIER"] = "Cannot add variant: modifier '%s' already exists on %s." -- MT
L["GEMS_VARIANT_LIST_HEADER"] = "Variants for %s:" -- MT
L["GEMS_VARIANT_LIST_NONE"] = "%s has no variant overrides (single variant only)." -- MT
L["GEMS_VARIANT_LIST_ROW"] = "  v%d %s (modifier: %s, %d steps)" -- MT
L["GEMS_VARIANT_MAX_REACHED"] = "Cannot add variant: %s already has the maximum of %d overrides." -- MT
L["GEMS_VARIANT_NOT_FOUND"] = "Sequence %s has no variant with modifier '%s'." -- MT
L["GEMS_VARIANT_REMOVED"] = "Removed variant on %s (modifier: %s)." -- MT

-- Variant indicator strip (IC-VAR-08 Phase 3) -- MT mirror from enUS
L["GEMS_VARIANT_INDICATOR_LABEL_PLAIN"] = "1" -- MT
L["GEMS_VARIANT_INDICATOR_LABEL_SHIFT"] = "S" -- MT
L["GEMS_VARIANT_INDICATOR_LABEL_CTRL"] = "C" -- MT
L["GEMS_VARIANT_INDICATOR_LABEL_ALT"] = "A" -- MT
L["GEMS_VARIANT_INDICATOR_TOOLTIP"] = "Variant: %s  Modifier: %s  Bind: %s" -- MT
L["GEMS_SETTINGS_VARIANT_INDICATORS_TRACKER"] = "TrackerHUD variant indicators" -- MT
L["GEMS_SETTINGS_VARIANT_INDICATORS_TRACKER_DESC"] =
    "Show coloured status icons, cooldown rings, and a pulsing border for each variant of a Smart Keybind Group sequence inside the Tracker HUD." -- MT
L["GEMS_SETTINGS_VARIANT_INDICATORS_BAR"] = "Action bar variant indicators" -- MT
L["GEMS_SETTINGS_VARIANT_INDICATORS_BAR_DESC"] =
    "Overlay the same variant indicators on action bar buttons that run /click GRIPEMS_<seq>_v<N>." -- MT

-- Auto-mirrored from enUS for prefix GEMS_HELP_VARIANTS (cowork_util fix-locale-parity 2026-05-26)
L["GEMS_HELP_VARIANTS"] = "  /gems variants - List and manage Smart Keybind Group variants" -- MT

-- Auto-mirrored from enUS for prefix GEMS_UI_TAB_VARIANTS (cowork_util fix-locale-parity 2026-05-26)
L["GEMS_UI_TAB_VARIANTS"] = "Variants" -- MT

-- Auto-mirrored from enUS for prefix GEMS_VARIANTS_ (cowork_util fix-locale-parity 2026-05-26)
L["GEMS_VARIANTS_ADD"] = "Add" -- MT
L["GEMS_VARIANTS_COMPILE_ERROR"] = "Recommend function did not compile: %s" -- MT
L["GEMS_VARIANTS_MOD_ALT_ROW"] = "Alt" -- MT
L["GEMS_VARIANTS_MOD_CTRL_ROW"] = "Ctrl" -- MT
L["GEMS_VARIANTS_MOD_PLAIN_ROW"] = "Plain (base)" -- MT
L["GEMS_VARIANTS_MOD_SHIFT_ROW"] = "Shift" -- MT
L["GEMS_VARIANTS_REMOVE"] = "Remove" -- MT
L["GEMS_VARIANTS_SEQ_RECOMMEND"] = "Sequence-level recommend function" -- MT
L["GEMS_VARIANTS_SEQ_RECOMMEND_TT"] =
    "Lua function returning one of: plain, shift, ctrl, alt. Falls back per-version if version-level is set." -- MT
L["GEMS_VARIANTS_UNSAFE_API_WARN"] = "Recommend function references restricted API. Run OOC only." -- MT
L["GEMS_VARIANTS_VER_RECOMMEND"] = "Per-version recommend function" -- MT
L["GEMS_VARIANTS_VER_RECOMMEND_EMPTY"] = "Using sequence default" -- MT
L["GEMS_VARIANTS_VER_TARGET_LIVE"] = "Rows edit version %d (live)" -- MT
L["GEMS_VARIANTS_VER_TARGET_NOT_LIVE"] = "Rows edit version %d (NOT live)" -- MT

-- Auto-mirrored from enUS for prefix GEMS_SETTINGS_SHOW_VARIANTS_TAB (cowork_util fix-locale-parity 2026-05-26)
L["GEMS_SETTINGS_SHOW_VARIANTS_TAB"] = "Show Variants tab in Sequence Editor" -- MT
L["GEMS_SETTINGS_SHOW_VARIANTS_TAB_DESC"] =
    "Adds a Variants subtab to the Sequence Editor for managing per-modifier variant overrides and the recommend function." -- MT

-- Auto-mirrored from enUS for prefix GEMS_UI_FILTER_ (cowork_util fix-locale-parity 2026-06-02)
L["GEMS_UI_FILTER_CLASS"] = "Current class only" -- MT
L["GEMS_UI_FILTER_CLASS_TIP"] = "Hide sequences that belong to other classes" -- MT

-- Auto-mirrored from enUS for prefix GEMS_MIGRATE_ (cowork_util fix-locale-parity 2026-06-02)
L["GEMS_MIGRATE_ALL_CLASSES"] = "All Classes" -- MT
L["GEMS_MIGRATE_CURRENT_CLASS"] = "Current Class Only" -- MT

-- Auto-mirrored from enUS for prefix GEMS_SPELL_TOOLTIP_ (cowork_util fix-locale-parity 2026-06-03)
L["GEMS_SPELL_TOOLTIP_CONTEXTUAL"] = "Castable in the right form or state: %s" -- MT

-- Auto-mirrored from enUS for prefix GEMS_VEHICLE_EXT (cowork_util fix-locale-parity 2026-06-11)
L["GEMS_VEHICLE_EXT_COLLISION"] = "Sky riding binds from %s also use: %s" -- MT

-- Auto-mirrored from enUS for prefix ACCESS_ANNOUNCE_SIMPLIFIED_ (cowork_util fix-locale-parity 2026-06-11)
L["ACCESS_ANNOUNCE_SIMPLIFIED_RUN"] = "Running %s" -- MT
L["ACCESS_ANNOUNCE_SIMPLIFIED_UNLOCKED"] = "Editing unlocked" -- MT
L["ACCESS_ANNOUNCE_SIMPLIFIED_LOCKED"] = "Editing locked" -- MT
L["ACCESS_ANNOUNCE_SIMPLIFIED_CLOSED"] = "Window closed" -- MT

-- Auto-mirrored from enUS for prefix GEMS_VERSION (cowork_util fix-locale-parity 2026-06-29)
L["GEMS_VERSION_LIVE_BADGE"] = "Live: V%d" -- MT
L["GEMS_VERSION_LIVE_MARKER"] = " (Live)" -- MT
L["GEMS_VERSION_TOOLTIP_LIVE_HINT"] =
    "This selects which version you edit. The live version your keybind runs is shown by the Live badge and can differ by content type." -- MT
L["GEMS_VERSION_PINNED_BADGE"] = "Live: V%d (pinned)" -- MT
L["GEMS_VERSION_PIN_ACTION"] = "Make live (pin)" -- MT
L["GEMS_VERSION_UNPIN_ACTION"] = "Unpin (use context)" -- MT
L["GEMS_VERSION_PIN_COMBAT_NOTE"] = " -- applies after combat" -- MT

-- Auto-mirrored from enUS for prefix GEMS_SWAP (cowork_util fix-locale-parity 2026-06-29)
L["GEMS_SWAP_USAGE"] = "Usage: /gems swap <sequence> <version#>" -- MT
L["GEMS_SWAP_DONE"] = "%s is now running version %d." -- MT
L["GEMS_SWAP_DONE_COMBAT"] = "%s will switch to version %d when combat ends." -- MT

-- Auto-mirrored from enUS for prefix GEMS_UNPIN (cowork_util fix-locale-parity 2026-06-29)
L["GEMS_UNPIN_USAGE"] = "Usage: /gems unpin <sequence>" -- MT
L["GEMS_UNPIN_DONE"] = "%s is back to its context or default version." -- MT
L["GEMS_HELP_SWAP"] = "  /gems swap <name> <n> - Pin the running version to version n (until unpinned)" -- MT
L["GEMS_HELP_UNPIN"] = "  /gems unpin <name> - Clear the pin; use the context or default version" -- MT

-- Auto-mirrored from enUS for prefix GEMS_EDITOR_METADATA_CHANGELOG (cowork_util fix-locale-parity 2026-06-30)
L["GEMS_EDITOR_METADATA_CHANGELOG"] = "Changelog" -- MT

-- Auto-mirrored from enUS for prefix GEMS_EXPORTTEXT_ (cowork_util fix-locale-parity 2026-07-02)
L["GEMS_EXPORTTEXT_CLASS_LABEL"] = "Class: " -- MT
L["GEMS_EXPORTTEXT_DESC_LABEL"] = "Description: " -- MT
L["GEMS_EXPORTTEXT_TALENT_LABEL"] = "Talents: " -- MT
L["GEMS_EXPORTTEXT_URL_LABEL"] = "Link: " -- MT
L["GEMS_EXPORTTEXT_CREATEDBY"] = "Created by: %s" -- MT
L["GEMS_EXPORTTEXT_FOOTER"] = "Exported from GRIP-EMS v%s (WoW %s)" -- MT

-- Auto-mirrored from enUS for prefix GEMS_CVAR_NAMEPLATES_STACKING (cowork_util fix-locale-parity 2026-07-09)
L["GEMS_CVAR_NAMEPLATES_STACKING"] = "Nameplate Stacking" -- MT
L["GEMS_CVAR_NAMEPLATES_STACKING_DESC"] = "Which nameplates stack apart instead of overlapping." -- MT
L["GEMS_CVAR_NAMEPLATES_STACKING_OPT_NONE"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_STACKING_OPT_ENEMY"] = "Enemy" -- MT
L["GEMS_CVAR_NAMEPLATES_STACKING_OPT_FRIENDLY"] = "Friendly" -- MT
L["GEMS_CVAR_NAMEPLATES_STACKING_OPT_BOTH"] = "Enemy + Friendly" -- MT
L["GEMS_CVAR_NAMEPLATES_STACKING_DESCLONG"] =
    "Controls which nameplates stack apart when they would overlap, so you can read them in a pack. Enemy keeps enemy plates separated for target selection in dungeons and raids. Friendly does the same for friendly plates. EMS 推荐仅敌对：暴雪默认完全不堆叠姓名板，怪群中敌对姓名板会彼此重叠；启用敌对堆叠可让每个姓名板都能点选。PvP 配置会自动应用敌对 + 友方，因为它同时开启友方玩家姓名板。" -- MT
L["GEMS_INTERLEAVE_NOBASE_WARN"] =
    "All actions are set to Interleave, so there is no base step to interleave into. Compiled them as a normal rotation instead. Turn off Interleave on at least one action to set your base rotation." -- MT
L["GEMS_UI_CTX_DUP_SELECTED"] = "Duplicate Selected (%d)" -- MT
L["GEMS_UI_CTX_DELETE_SELECTED"] = "Delete Selected (%d)" -- MT
L["GEMS_UI_STEPS_SELECTED"] = "%d steps selected" -- MT
L["GEMS_UI_DELETE_STEPS_CONFIRM"] = "Delete %d steps? This cannot be undone." -- MT
L["GEMS_SETTINGS_PLUGINS"] = "Plugins" -- MT
L["GEMS_EXPORT_META_FORMAT_LABEL"] = "Format:" -- MT
L["GEMS_EXPORT_FORMAT_BUILTIN"] = "GRIP-EMS" -- MT
L["GEMS_CVAR_FPS_USEMAXFPSBK"] = "Use Background Cap" -- MT
L["GEMS_CVAR_FPS_USEMAXFPSBK_DESC"] = "Turns the background FPS limit on or off when the game window loses focus." -- MT
L["GEMS_CVAR_FPS_USEMAXFPSBK_OPT_0"] = "Off (full FPS in background)" -- MT
L["GEMS_CVAR_FPS_USEMAXFPSBK_OPT_1"] = "On (default, recommended)" -- MT
L["GEMS_CVAR_FPS_USEMAXFPSBK_DESCLONG"] =
    "Works together with Background FPS. When enabled, the client drops to the Background FPS value while you are tabbed out, cutting GPU load and heat. Disable only if you record or stream the game window in the background." -- MT
L["GEMS_CVAR_FPS_DYNSCALEMIN"] = "Dynamic Scale Floor" -- MT
L["GEMS_CVAR_FPS_DYNSCALEMIN_DESC"] = "Lowest render scale the dynamic scaler is allowed to reach." -- MT
L["GEMS_CVAR_FPS_DYNSCALEMIN_OPT_33"] = "33% (default, recommended)" -- MT
L["GEMS_CVAR_FPS_DYNSCALEMIN_OPT_50"] = "50% (balanced)" -- MT
L["GEMS_CVAR_FPS_DYNSCALEMIN_OPT_67"] = "67% (sharper)" -- MT
L["GEMS_CVAR_FPS_DYNSCALEMIN_OPT_75"] = "75% (minimal savings)" -- MT
L["GEMS_CVAR_FPS_DYNSCALEMIN_DESCLONG"] =
    "Only matters while Dynamic Render Scale is enabled. The default 33% floor keeps FPS stable at a heavy image-quality cost; raise the floor to keep the image sharper in exchange for smaller FPS savings." -- MT
L["GEMS_CVAR_VISUAL_RESAMPLEQ"] = "Resample Quality" -- MT
L["GEMS_CVAR_VISUAL_RESAMPLEQ_DESC"] = "Upscaling filter used when Render Scale is not 100%." -- MT
L["GEMS_CVAR_VISUAL_RESAMPLEQ_OPT_0"] = "Point (fastest)" -- MT
L["GEMS_CVAR_VISUAL_RESAMPLEQ_OPT_1"] = "Bilinear" -- MT
L["GEMS_CVAR_VISUAL_RESAMPLEQ_OPT_2"] = "Bicubic" -- MT
L["GEMS_CVAR_VISUAL_RESAMPLEQ_OPT_3"] = "FidelityFX Super Resolution (default, recommended)" -- MT
L["GEMS_CVAR_VISUAL_RESAMPLEQ_DESCLONG"] =
    "Only applies while Render Scale differs from 100%. FidelityFX Super Resolution gives the cleanest upscale on modern GPUs; Point and Bilinear are cheaper fallbacks for very old hardware." -- MT
L["GEMS_CVAR_DUNGEON_UNITCLUTTER"] = "Unit Clutter Reduction" -- MT
L["GEMS_CVAR_DUNGEON_UNITCLUTTER_DESC"] = "Master toggle for the system that thins out stacked NPCs and pets." -- MT
L["GEMS_CVAR_DUNGEON_UNITCLUTTER_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_DUNGEON_UNITCLUTTER_OPT_1"] = "On (default, recommended)" -- MT
L["GEMS_CVAR_DUNGEON_UNITCLUTTER_DESCLONG"] =
    "Master switch for unit clutter reduction. Keep it on so crowded scenes stay readable; the instances-only setting scopes where it applies and the player threshold controls how many nearby players it takes to kick in." -- MT
L["GEMS_CVAR_DUNGEON_CLUTTERTHRESH"] = "Clutter Player Threshold" -- MT
L["GEMS_CVAR_DUNGEON_CLUTTERTHRESH_DESC"] = "Nearby players required before clutter reduction kicks in." -- MT
L["GEMS_CVAR_DUNGEON_CLUTTERTHRESH_OPT_5"] = "5 (aggressive)" -- MT
L["GEMS_CVAR_DUNGEON_CLUTTERTHRESH_OPT_9"] = "9 (default, recommended)" -- MT
L["GEMS_CVAR_DUNGEON_CLUTTERTHRESH_OPT_15"] = "15 (relaxed)" -- MT
L["GEMS_CVAR_DUNGEON_CLUTTERTHRESH_OPT_20"] = "20 (rarely triggers)" -- MT
L["GEMS_CVAR_DUNGEON_CLUTTERTHRESH_DESCLONG"] =
    "Lower values start hiding cosmetic units earlier, which helps framerate in busy hubs and raids. The default of 9 is a solid middle ground; raise it if you only want clutter reduction in very large groups." -- MT
L["GEMS_CVAR_COMBAT_SOFTICONENEMY"] = "Enemy Soft Target Icon" -- MT
L["GEMS_CVAR_COMBAT_SOFTICONENEMY_DESC"] = "Show an icon above the enemy action targeting has picked." -- MT
L["GEMS_CVAR_COMBAT_SOFTICONENEMY_OPT_0"] = "Hidden (default)" -- MT
L["GEMS_CVAR_COMBAT_SOFTICONENEMY_OPT_1"] = "Shown (recommended)" -- MT
L["GEMS_CVAR_COMBAT_SOFTICONENEMY_DESCLONG"] =
    "With enemy soft targeting active, this icon marks exactly which enemy your next cast will hit. Recommended for sequence users: you see what the engine sees before the button press." -- MT
L["GEMS_CVAR_COMBAT_SOFTICONFRIEND"] = "Friendly Soft Target Icon" -- MT
L["GEMS_CVAR_COMBAT_SOFTICONFRIEND_DESC"] = "Show an icon above your current friendly soft target." -- MT
L["GEMS_CVAR_COMBAT_SOFTICONFRIEND_OPT_0"] = "Hidden (default, recommended)" -- MT
L["GEMS_CVAR_COMBAT_SOFTICONFRIEND_OPT_1"] = "Shown" -- MT
L["GEMS_CVAR_COMBAT_SOFTICONFRIEND_DESCLONG"] =
    "Only relevant when friendly soft targeting is enabled, which the registry recommends leaving off. Keep the icon off unless you have turned friendly soft targeting on for support play." -- MT
L["GEMS_CVAR_SOLO_INTERHARDRANGE"] = "Hard Interact Range Cutoff" -- MT
L["GEMS_CVAR_SOLO_INTERHARDRANGE_DESC"] = "Treat the interact range as a hard cutoff in every case." -- MT
L["GEMS_CVAR_SOLO_INTERHARDRANGE_OPT_0"] = "Off (default, recommended)" -- MT
L["GEMS_CVAR_SOLO_INTERHARDRANGE_OPT_1"] = "On (strict)" -- MT
L["GEMS_CVAR_SOLO_INTERHARDRANGE_DESCLONG"] =
    "Off keeps the forgiving behaviour: an object already in interact range stays targetable at the edge. On drops the soft target the moment it leaves the configured range. Leave off unless you want strict range discipline." -- MT
L["GEMS_CVAR_SOLO_INTERICONGO"] = "Object Interact Icon" -- MT
L["GEMS_CVAR_SOLO_INTERICONGO_DESC"] = "Show an icon on usable objects that cannot normally be targeted." -- MT
L["GEMS_CVAR_SOLO_INTERICONGO_OPT_0"] = "Hidden (default)" -- MT
L["GEMS_CVAR_SOLO_INTERICONGO_OPT_1"] = "Shown (recommended)" -- MT
L["GEMS_CVAR_SOLO_INTERICONGO_DESCLONG"] =
    "Extends the interact icon to chests, levers, and other world objects without a real target frame. Pairs with the interact icon and range settings above so every usable object is flagged before you press interact." -- MT
L["GEMS_CVAR_SOLO_LOWPRIOICONS"] = "Low-Priority Interact Icons" -- MT
L["GEMS_CVAR_SOLO_LOWPRIOICONS_DESC"] = "Show interact icons on objects quest or loot effects already mark." -- MT
L["GEMS_CVAR_SOLO_LOWPRIOICONS_OPT_0"] = "Hidden (default, recommended)" -- MT
L["GEMS_CVAR_SOLO_LOWPRIOICONS_OPT_1"] = "Always shown" -- MT
L["GEMS_CVAR_SOLO_LOWPRIOICONS_DESCLONG"] =
    "Off keeps the screen quieter by letting quest sparkles and loot glows stand alone. Turn it on if you want the interact icon visible on every usable object regardless of other markers." -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTNPFRIEND"] = "Friendly Soft Target Nameplate" -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTNPFRIEND_DESC"] = "Always show a nameplate for your current friendly soft target." -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTNPFRIEND_OPT_0"] = "Off (default, recommended)" -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTNPFRIEND_OPT_1"] = "On" -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTNPFRIEND_DESCLONG"] =
    "Only relevant when friendly soft targeting is enabled, which the registry recommends leaving off. Leave disabled to keep friendly nameplates uncluttered." -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTNPINTERACT"] = "Interact Target Nameplate" -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTNPINTERACT_DESC"] = "Always show a nameplate for your current soft interact target." -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTNPINTERACT_OPT_0"] = "Off (default)" -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTNPINTERACT_OPT_1"] = "On (recommended)" -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTNPINTERACT_DESCLONG"] =
    "Puts a nameplate on the NPC or object your interact key is pointed at, which makes the pick unambiguous in crowded quest hubs. Pairs with the interact icons for full interact visibility." -- MT
L["GEMS_CVAR_FILTER_ISSUES"] = "Show only issues" -- MT
L["GEMS_CVAR_FILTER_ISSUES_DESC"] =
    "Hide rows that already match the recommendation and hide sections with nothing to fix. Rows you marked as your choice count as fine and are hidden too. Session-only; the filter resets on reload." -- MT
L["GEMS_CVAR_SEARCH"] = "Find a CVar" -- MT
L["GEMS_CVAR_SEARCH_DESC"] =
    "Type part of a CVar name or its label. Up to eight matches appear below; click one to jump to its section page." -- MT
L["GEMS_CVAR_SEARCH_NOMATCH"] = "No matching CVar." -- MT
L["GEMS_CVAR_NAMEPLATES_THREATDISP"] = "Threat Display" -- MT
L["GEMS_CVAR_NAMEPLATES_THREATDISP_DESC"] = "How threat is shown on enemy nameplates." -- MT
L["GEMS_CVAR_NAMEPLATES_INFODISP"] = "Nameplate Info" -- MT
L["GEMS_CVAR_NAMEPLATES_INFODISP_DESC"] = "Extra info shown on nameplates." -- MT
L["GEMS_CVAR_NAMEPLATES_CASTBARDISP"] = "Cast Bar Info" -- MT
L["GEMS_CVAR_NAMEPLATES_CASTBARDISP_DESC"] = "What nameplate cast bars show." -- MT
L["GEMS_CVAR_NAMEPLATES_AURAENEMYPLAYER"] = "Enemy Player Auras" -- MT
L["GEMS_CVAR_NAMEPLATES_AURAENEMYPLAYER_DESC"] = "Buffs, debuffs, and loss of control on enemy player nameplates." -- MT
L["GEMS_CVAR_NAMEPLATES_AURAENEMYNPC"] = "Enemy NPC Auras" -- MT
L["GEMS_CVAR_NAMEPLATES_AURAENEMYNPC_DESC"] = "Buffs, debuffs, and crowd control on enemy NPC nameplates." -- MT
L["GEMS_CVAR_NAMEPLATES_AURAFRIENDPLAYER"] = "Friendly Player Auras" -- MT
L["GEMS_CVAR_NAMEPLATES_AURAFRIENDPLAYER_DESC"] = "Buffs, debuffs, and loss of control on friendly player nameplates." -- MT
L["GEMS_CVAR_NAMEPLATES_THREATDISP_OPT_OFF"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_THREATDISP_OPT_PROGRESSIVE"] = "Progressive" -- MT
L["GEMS_CVAR_NAMEPLATES_THREATDISP_OPT_FLASH"] = "Aggro Flash" -- MT
L["GEMS_CVAR_NAMEPLATES_THREATDISP_OPT_HBCOLOR"] = "Health Bar Colour" -- MT
L["GEMS_CVAR_NAMEPLATES_THREATDISP_OPT_ALL"] = "All" -- MT
L["GEMS_CVAR_NAMEPLATES_THREATDISP_DESCLONG"] =
    "Off matches the default. Progressive fills a threat meter on the plate, Aggro Flash warns when you gain or lose aggro, and Health Bar Colour tints the health bar by threat state. Tanks get the most from Health Bar Colour." -- MT
L["GEMS_CVAR_NAMEPLATES_INFODISP_OPT_OFF"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_INFODISP_OPT_RARITY"] = "Rarity Icon" -- MT
L["GEMS_CVAR_NAMEPLATES_INFODISP_OPT_PCT"] = "Health Percent" -- MT
L["GEMS_CVAR_NAMEPLATES_INFODISP_OPT_PCTRARITY"] = "Health Percent + Rarity" -- MT
L["GEMS_CVAR_NAMEPLATES_INFODISP_OPT_ALL"] = "Everything" -- MT
L["GEMS_CVAR_NAMEPLATES_INFODISP_DESCLONG"] =
    "Rarity Icon matches the default: rare and elite mobs get a marker on their plate. The percent options add a health number readout. Everything shows percent, exact value, and the rarity marker at once." -- MT
L["GEMS_CVAR_NAMEPLATES_CASTBARDISP_OPT_OFF"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_CASTBARDISP_OPT_NAMEICON"] = "Name + Icon" -- MT
L["GEMS_CVAR_NAMEPLATES_CASTBARDISP_OPT_HIGHLIGHTS"] = "Name, Icon + Highlights" -- MT
L["GEMS_CVAR_NAMEPLATES_CASTBARDISP_OPT_ALL"] = "Everything" -- MT
L["GEMS_CVAR_NAMEPLATES_CASTBARDISP_DESCLONG"] =
    "Name, Icon + Highlights matches the default: spell name and icon, plus a highlight for important casts and for casts aimed at you. Everything adds the cast target name so you can see who the mob is casting at. Off hides cast bar extras." -- MT
L["GEMS_CVAR_NAMEPLATES_AURAENEMYPLAYER_OPT_OFF"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_AURAENEMYPLAYER_OPT_DEBUFFS"] = "Debuffs Only" -- MT
L["GEMS_CVAR_NAMEPLATES_AURAENEMYPLAYER_OPT_BUFFSDEBUFFS"] = "Buffs + Debuffs" -- MT
L["GEMS_CVAR_NAMEPLATES_AURAENEMYPLAYER_OPT_ALL"] = "Buffs, Debuffs + Loss of Control" -- MT
L["GEMS_CVAR_NAMEPLATES_AURAENEMYPLAYER_DESCLONG"] =
    "The recommended setting adds loss of control markers, so you can tell when an enemy player is stunned, feared, or silenced straight from their plate. The game default leaves those markers off." -- MT
L["GEMS_CVAR_NAMEPLATES_AURAENEMYNPC_OPT_OFF"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_AURAENEMYNPC_OPT_DEBUFFS"] = "Debuffs Only" -- MT
L["GEMS_CVAR_NAMEPLATES_AURAENEMYNPC_OPT_BUFFSDEBUFFS"] = "Buffs + Debuffs" -- MT
L["GEMS_CVAR_NAMEPLATES_AURAENEMYNPC_OPT_ALL"] = "Buffs, Debuffs + Crowd Control" -- MT
L["GEMS_CVAR_NAMEPLATES_AURAENEMYNPC_DESCLONG"] =
    "The default shows all three. Crowd control markers on NPC plates show which mobs are already locked down, so the group does not stack CC on the same target in dungeons." -- MT
L["GEMS_CVAR_NAMEPLATES_AURAFRIENDPLAYER_OPT_OFF"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_AURAFRIENDPLAYER_OPT_DEBUFFS"] = "Debuffs Only" -- MT
L["GEMS_CVAR_NAMEPLATES_AURAFRIENDPLAYER_OPT_BUFFSDEBUFFS"] = "Buffs + Debuffs" -- MT
L["GEMS_CVAR_NAMEPLATES_AURAFRIENDPLAYER_OPT_ALL"] = "Buffs, Debuffs + Loss of Control" -- MT
L["GEMS_CVAR_NAMEPLATES_AURAFRIENDPLAYER_DESCLONG"] =
    "Buffs + Debuffs matches the default. Add loss of control if you play healer and want to see which teammates are stunned or silenced without staring at raid frames." -- MT

-- Auto-mirrored from enUS for prefix GEMS_CVAR_COMBATAUDIO_ (cowork_util fix-locale-parity 2026-07-20)
L["GEMS_CVAR_COMBATAUDIO_ENABLE"] = "Combat Audio Alerts" -- MT
L["GEMS_CVAR_COMBATAUDIO_ENABLE_DESC"] = "Master switch for the game's spoken combat alerts." -- MT
L["GEMS_CVAR_COMBATAUDIO_ENABLE_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBATAUDIO_ENABLE_OPT_1"] = "On" -- MT
L["GEMS_CVAR_COMBATAUDIO_ENABLE_DESCLONG"] =
    "Turns on the game's built-in spoken combat alerts. Every other row in this section only does something while this is on. It is off by default; turn it on if you want callouts for casts, interrupts, and target changes without watching the screen." -- MT
L["GEMS_CVAR_COMBATAUDIO_TARGETNAME"] = "Speak Target Name" -- MT
L["GEMS_CVAR_COMBATAUDIO_TARGETNAME_DESC"] = "Say the target's name when you switch targets." -- MT
L["GEMS_CVAR_COMBATAUDIO_TARGETNAME_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBATAUDIO_TARGETNAME_OPT_1"] = "On" -- MT
L["GEMS_CVAR_COMBATAUDIO_TARGETNAME_DESCLONG"] =
    "Reads out each new target's name as you tab or click onto it. On by default once combat audio is enabled. Useful for confirming your target without looking at the target frame." -- MT
L["GEMS_CVAR_COMBATAUDIO_COMBATSTART"] = "Announce Combat Start" -- MT
L["GEMS_CVAR_COMBATAUDIO_COMBATSTART_DESC"] = "Say a line when you enter combat." -- MT
L["GEMS_CVAR_COMBATAUDIO_COMBATSTART_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBATAUDIO_COMBATSTART_OPT_1"] = "On" -- MT
L["GEMS_CVAR_COMBATAUDIO_COMBATSTART_DESCLONG"] =
    "Speaks a short line the moment you enter combat. On by default. A cue that a pull has started when you are looking away from the screen." -- MT
L["GEMS_CVAR_COMBATAUDIO_COMBATEND"] = "Announce Combat End" -- MT
L["GEMS_CVAR_COMBATAUDIO_COMBATEND_DESC"] = "Say a line when you leave combat." -- MT
L["GEMS_CVAR_COMBATAUDIO_COMBATEND_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBATAUDIO_COMBATEND_OPT_1"] = "On" -- MT
L["GEMS_CVAR_COMBATAUDIO_COMBATEND_DESCLONG"] =
    "Speaks a short line when combat ends. On by default. Pairs with the combat-start callout to bracket each fight." -- MT
L["GEMS_CVAR_COMBATAUDIO_TARGETCAST"] = "Target Cast Alerts" -- MT
L["GEMS_CVAR_COMBATAUDIO_TARGETCAST_DESC"] = "Speak when your target starts or finishes a cast." -- MT
L["GEMS_CVAR_COMBATAUDIO_TARGETCAST_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBATAUDIO_TARGETCAST_OPT_1"] = "Cast Start" -- MT
L["GEMS_CVAR_COMBATAUDIO_TARGETCAST_OPT_2"] = "Cast End" -- MT
L["GEMS_CVAR_COMBATAUDIO_TARGETCAST_DESCLONG"] =
    "Reads out your target's casts. Off by default. Cast Start speaks as the cast begins, which gives you the most warning for an interrupt. Cast End speaks as it finishes. Off keeps the audio quiet." -- MT
L["GEMS_CVAR_COMBATAUDIO_TARGETCASTMIN"] = "Target Cast Minimum Length" -- MT
L["GEMS_CVAR_COMBATAUDIO_TARGETCASTMIN_DESC"] = "Only speak target casts at least this long." -- MT
L["GEMS_CVAR_COMBATAUDIO_TARGETCASTMIN_OPT_ALL"] = "All Casts" -- MT
L["GEMS_CVAR_COMBATAUDIO_TARGETCASTMIN_OPT_10"] = "1 second" -- MT
L["GEMS_CVAR_COMBATAUDIO_TARGETCASTMIN_OPT_15"] = "1.5 seconds" -- MT
L["GEMS_CVAR_COMBATAUDIO_TARGETCASTMIN_OPT_20"] = "2 seconds" -- MT
L["GEMS_CVAR_COMBATAUDIO_TARGETCASTMIN_OPT_30"] = "3 seconds" -- MT
L["GEMS_CVAR_COMBATAUDIO_TARGETCASTMIN_DESCLONG"] =
    "Filters which target casts get read out by length. The default is 1.5 seconds, so very short casts stay quiet and only slower ones are announced. All Casts reads every cast, which gets noisy in dungeons. Raise it if you only care about long, dangerous casts." -- MT
L["GEMS_CVAR_COMBATAUDIO_PLAYERCAST"] = "Your Cast Alerts" -- MT
L["GEMS_CVAR_COMBATAUDIO_PLAYERCAST_DESC"] = "Speak when you start or finish a cast." -- MT
L["GEMS_CVAR_COMBATAUDIO_PLAYERCAST_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBATAUDIO_PLAYERCAST_OPT_1"] = "Cast Start" -- MT
L["GEMS_CVAR_COMBATAUDIO_PLAYERCAST_OPT_2"] = "Cast End" -- MT
L["GEMS_CVAR_COMBATAUDIO_PLAYERCAST_DESCLONG"] =
    "Reads out your own casts. Off by default. Cast Start speaks as you begin casting, Cast End as it lands. Mostly for accessibility, or for confirming a cast fired without watching the cast bar." -- MT
L["GEMS_CVAR_COMBATAUDIO_INTERRUPT"] = "Announce Interruptible Casts" -- MT
L["GEMS_CVAR_COMBATAUDIO_INTERRUPT_DESC"] = "Speak when the target begins something you can interrupt." -- MT
L["GEMS_CVAR_COMBATAUDIO_INTERRUPT_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBATAUDIO_INTERRUPT_OPT_1"] = "On" -- MT
L["GEMS_CVAR_COMBATAUDIO_INTERRUPT_DESCLONG"] =
    "Speaks a cue when your target starts a cast that can be interrupted. Off by default. A hands-free prompt to use your kick, which pairs well with a sequencer keybind." -- MT
L["GEMS_CVAR_COMBATAUDIO_INTERRUPTOK"] = "Announce Interrupt Success" -- MT
L["GEMS_CVAR_COMBATAUDIO_INTERRUPTOK_DESC"] = "Speak when the target's cast is interrupted." -- MT
L["GEMS_CVAR_COMBATAUDIO_INTERRUPTOK_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBATAUDIO_INTERRUPTOK_OPT_1"] = "On" -- MT
L["GEMS_CVAR_COMBATAUDIO_INTERRUPTOK_DESCLONG"] =
    "Speaks a cue when your target's cast gets interrupted. Off by default. Confirms the kick landed so you are not lining up a second one for a cast that already stopped." -- MT
L["GEMS_CVAR_COMBATAUDIO_VOLUME"] = "Alert Volume" -- MT
L["GEMS_CVAR_COMBATAUDIO_VOLUME_DESC"] = "How loud the combat audio alerts are." -- MT
L["GEMS_CVAR_COMBATAUDIO_VOLUME_OPT_0"] = "Muted" -- MT
L["GEMS_CVAR_COMBATAUDIO_VOLUME_OPT_25"] = "25%" -- MT
L["GEMS_CVAR_COMBATAUDIO_VOLUME_OPT_50"] = "50%" -- MT
L["GEMS_CVAR_COMBATAUDIO_VOLUME_OPT_75"] = "75%" -- MT
L["GEMS_CVAR_COMBATAUDIO_VOLUME_OPT_100"] = "100% (default)" -- MT
L["GEMS_CVAR_COMBATAUDIO_VOLUME_DESCLONG"] =
    "Sets the volume of the spoken combat alerts, separate from your other sound sliders. Full volume by default. Lower it if the callouts drown out game sound, or mute it to keep the feature configured but silent." -- MT

-- Auto-mirrored from enUS for prefix GEMS_CVAR_SECTION_COMBATAUDIO (cowork_util fix-locale-parity 2026-07-20)
L["GEMS_CVAR_SECTION_COMBATAUDIO"] = "Combat Audio" -- MT

-- Auto-mirrored from enUS for prefix GEMS_CVAR_ACCESS_ (cowork_util fix-locale-parity 2026-07-20)
L["GEMS_CVAR_ACCESS_SHAKECAM"] = "Camera Shake Strength" -- MT
L["GEMS_CVAR_ACCESS_SHAKECAM_DESC"] = "How much combat and spell effects shake the camera." -- MT
L["GEMS_CVAR_ACCESS_SHAKECAM_OPT_0"] = "None" -- MT
L["GEMS_CVAR_ACCESS_SHAKECAM_OPT_25"] = "Light" -- MT
L["GEMS_CVAR_ACCESS_SHAKECAM_OPT_50"] = "Half" -- MT
L["GEMS_CVAR_ACCESS_SHAKECAM_OPT_75"] = "Strong" -- MT
L["GEMS_CVAR_ACCESS_SHAKECAM_OPT_100"] = "Full (default)" -- MT
L["GEMS_CVAR_ACCESS_SHAKECAM_DESCLONG"] =
    "Scales how much screen effects shake the 3D camera. Full is the default. Lower it, or set it to None, if camera shake causes motion discomfort. This is a common motion-sickness aid." -- MT
L["GEMS_CVAR_ACCESS_SHAKEUI"] = "UI Shake Strength" -- MT
L["GEMS_CVAR_ACCESS_SHAKEUI_DESC"] = "How much effects shake the 2D interface." -- MT
L["GEMS_CVAR_ACCESS_SHAKEUI_OPT_0"] = "None" -- MT
L["GEMS_CVAR_ACCESS_SHAKEUI_OPT_25"] = "Light" -- MT
L["GEMS_CVAR_ACCESS_SHAKEUI_OPT_50"] = "Half" -- MT
L["GEMS_CVAR_ACCESS_SHAKEUI_OPT_75"] = "Strong" -- MT
L["GEMS_CVAR_ACCESS_SHAKEUI_OPT_100"] = "Full (default)" -- MT
L["GEMS_CVAR_ACCESS_SHAKEUI_DESCLONG"] =
    "Scales how much screen effects shake the flat UI layer, separate from the camera. Full is the default. Lower it if on-screen shake bothers you but you still want the camera effect, or set both shake rows down together." -- MT
L["GEMS_CVAR_ACCESS_CBSIM"] = "Colourblind Filter" -- MT
L["GEMS_CVAR_ACCESS_CBSIM_DESC"] = "Which type of colourblindness the colour filter is tuned for." -- MT
L["GEMS_CVAR_ACCESS_CBSIM_OPT_0"] = "None (default)" -- MT
L["GEMS_CVAR_ACCESS_CBSIM_OPT_1"] = "Protanopia (red)" -- MT
L["GEMS_CVAR_ACCESS_CBSIM_OPT_2"] = "Deuteranopia (green)" -- MT
L["GEMS_CVAR_ACCESS_CBSIM_OPT_3"] = "Tritanopia (blue)" -- MT
L["GEMS_CVAR_ACCESS_CBSIM_DESCLONG"] =
    "Selects the type of colourblindness the game's colour filter is tuned for. None is the default, which leaves the screen unchanged. Pick a type here to turn the filter on; the strength row below sets how far it shifts. This is separate from the Colourblind Mode toggle above, which adds colourblind-friendly text labels rather than filtering the screen." -- MT
L["GEMS_CVAR_ACCESS_CBWEAK"] = "Colourblind Strength" -- MT
L["GEMS_CVAR_ACCESS_CBWEAK_DESC"] = "How strongly the colourblind filter shifts colours." -- MT
L["GEMS_CVAR_ACCESS_CBWEAK_OPT_0"] = "0 (none)" -- MT
L["GEMS_CVAR_ACCESS_CBWEAK_OPT_25"] = "0.25" -- MT
L["GEMS_CVAR_ACCESS_CBWEAK_OPT_50"] = "0.5 (default)" -- MT
L["GEMS_CVAR_ACCESS_CBWEAK_OPT_75"] = "0.75" -- MT
L["GEMS_CVAR_ACCESS_CBWEAK_OPT_100"] = "1.0 (full)" -- MT
L["GEMS_CVAR_ACCESS_CBWEAK_DESCLONG"] =
    "Sets how strongly the colourblind filter shifts colours, from none at 0 to full at 1. The default is 0.5. Only does anything when a colourblind filter type is selected above." -- MT
L["GEMS_CVAR_ACCESS_CURSORSIZE"] = "Cursor Size" -- MT
L["GEMS_CVAR_ACCESS_CURSORSIZE_DESC"] = "Size of the mouse cursor." -- MT
L["GEMS_CVAR_ACCESS_CURSORSIZE_OPT_AUTO"] = "Auto (by monitor)" -- MT
L["GEMS_CVAR_ACCESS_CURSORSIZE_OPT_0"] = "Small (32px)" -- MT
L["GEMS_CVAR_ACCESS_CURSORSIZE_OPT_1"] = "Medium (48px)" -- MT
L["GEMS_CVAR_ACCESS_CURSORSIZE_OPT_2"] = "Large (64px)" -- MT
L["GEMS_CVAR_ACCESS_CURSORSIZE_OPT_3"] = "Extra Large (96px)" -- MT
L["GEMS_CVAR_ACCESS_CURSORSIZE_OPT_4"] = "Huge (128px)" -- MT
L["GEMS_CVAR_ACCESS_CURSORSIZE_DESCLONG"] =
    "Sets the mouse cursor size. Auto picks a size from your monitor resolution and is the default. The fixed sizes make the cursor easier to track on a busy screen or a large display." -- MT
L["GEMS_CVAR_ACCESS_CLIPCURSOR"] = "Lock Cursor to Window" -- MT
L["GEMS_CVAR_ACCESS_CLIPCURSOR_DESC"] = "Keep the mouse cursor inside the game window." -- MT
L["GEMS_CVAR_ACCESS_CLIPCURSOR_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_ACCESS_CLIPCURSOR_OPT_1"] = "On" -- MT
L["GEMS_CVAR_ACCESS_CLIPCURSOR_DESCLONG"] =
    "Stops the mouse from leaving the game window. Off is the default. Turn it on for windowed play across multiple monitors so the cursor does not slip onto another screen mid-fight." -- MT
L["GEMS_CVAR_ACCESS_TTS"] = "Chat Text to Speech" -- MT
L["GEMS_CVAR_ACCESS_TTS_DESC"] = "Read chat messages out loud." -- MT
L["GEMS_CVAR_ACCESS_TTS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_ACCESS_TTS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_ACCESS_TTS_DESCLONG"] =
    "Reads incoming chat out loud using the system voice. Off is the default. This is separate from the combat audio alerts in their own section; this row is for chat channels." -- MT
L["GEMS_CVAR_ACCESS_STT"] = "Voice Transcription" -- MT
L["GEMS_CVAR_ACCESS_STT_DESC"] = "Show on-screen text for spoken words in voice chat." -- MT
L["GEMS_CVAR_ACCESS_STT_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_ACCESS_STT_OPT_1"] = "On" -- MT
L["GEMS_CVAR_ACCESS_STT_DESCLONG"] =
    "Transcribes other players' voice chat into on-screen text. Off is the default. Useful if you are in a voice channel but cannot hear it clearly or at all." -- MT
L["GEMS_CVAR_ACCESS_TTSCHAR"] = "Per-Character Voice Settings" -- MT
L["GEMS_CVAR_ACCESS_TTSCHAR_DESC"] = "Use separate text-to-speech settings for this character." -- MT
L["GEMS_CVAR_ACCESS_TTSCHAR_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_ACCESS_TTSCHAR_OPT_1"] = "On" -- MT
L["GEMS_CVAR_ACCESS_TTSCHAR_DESCLONG"] =
    "When on, this character keeps its own text-to-speech voice and options instead of sharing the account-wide set. On is the default. Turn it off to use one shared voice setup across every character." -- MT
L["GEMS_CVAR_VISUAL_RAIDSHADOWS"] = "Raid Shadow Quality" -- MT
L["GEMS_CVAR_VISUAL_RAIDSHADOWS_DESC"] =
    "Shadow tier for the raid and battleground graphics profile (0-5). Lower it for FPS in big group content; your open-world shadows stay untouched." -- MT
L["GEMS_CVAR_VISUAL_RAIDSHADOWS_DESCLONG"] =
    "WoW keeps a separate graphics profile for raids and battlegrounds so you can run lighter settings where framerate matters most. This is the shadow tier for that profile, on Blizzard's scale from Low up to Ultra High. Shadows are one of the heaviest GPU settings, so dropping raid shadows to Low or Fair frees the most frames in a 20-player pull or a packed battleground, and everywhere else keeps full shadows. The live raid default is High. Drop it if raids stutter, keep it up if your GPU has room. This setting resets each session and does not persist across logouts; EMS re-applies your choice on every login." -- MT
L["GEMS_CVAR_VISUAL_RAIDSSAO"] = "Raid Ambient Occlusion" -- MT
L["GEMS_CVAR_VISUAL_RAIDSSAO_DESC"] =
    "Ambient occlusion tier for the raid and battleground profile (0 off, 4 highest). Cheaper than shadows; leave at default unless you need every frame." -- MT
L["GEMS_CVAR_VISUAL_RAIDSSAO_DESCLONG"] =
    "Screen-space ambient occlusion is the soft contact shadow where objects meet the ground. This is the raid and battleground copy of that setting, separate from your open-world value, with tiers running Disabled, Low, Medium, High, Ultra. It costs less GPU than shadow quality, so most people leave it at the default High and only drop to Low or Disabled when a dense pull needs the frames. The live raid default is High. This setting resets each session and does not persist across logouts; EMS re-applies your choice on every login." -- MT
L["GEMS_CVAR_VISUAL_RAIDGROUND"] = "Raid Ground Clutter" -- MT
L["GEMS_CVAR_VISUAL_RAIDGROUND_DESC"] =
    "Grass and ground-detail density in raids and battlegrounds (1-10). Cosmetic, so lowering it costs nothing in gameplay." -- MT
L["GEMS_CVAR_VISUAL_RAIDGROUND_DESCLONG"] =
    "Density of small ground objects like grass, pebbles, and leaves while you are in a raid or battleground, kept separate from your open-world value. It is purely cosmetic: clutter never hides a unit or a ground effect, so trimming it is free FPS. The recommended value matches the live raid default of 6, which is fairly dense; most raid bosses sit indoors where you barely see grass, so dropping to 1 through 3 is a safe cut if you want a few more frames. This setting resets each session and does not persist across logouts; EMS re-applies your choice on every login." -- MT
L["GEMS_CVAR_VISUAL_RAIDPROJTEX"] = "Raid Projected Textures" -- MT
L["GEMS_CVAR_VISUAL_RAIDPROJTEX_DESC"] =
    "Spell ground effects (swirls, void zones) inside raids and battlegrounds. Keep it on; off hides boss telegraphs." -- MT
L["GEMS_CVAR_VISUAL_RAIDPROJTEX_DESCLONG"] =
    "Projected textures are the ground-effect decals for raid mechanics: AoE swirls, void zones, fire patches, healing circles. This is the raid and battleground copy of the setting, separate from your open-world value. Keep it on (1), because with it off those indicators do not draw and you cannot see where a mechanic is about to land, in exactly the content where that gets you killed. Turn it off only if you have a real GPU bottleneck and run a third-party addon that draws its own markers. This setting resets each session and does not persist across logouts; EMS re-applies your choice on every login." -- MT
L["GEMS_CVAR_DRAGON_NOFSFX"] = "Disable Full-Screen Flight Effects" -- MT
L["GEMS_CVAR_DRAGON_NOFSFX_DESC"] =
    "Turns off the full-screen speed blur and vignette during Skyriding. Unchecked by default; tick it if they bother you." -- MT
L["GEMS_CVAR_DRAGON_NOFSFX_DESCLONG"] =
    "The advanced-flying full-screen effects are the speed blur and edge vignette that wash across the screen while you Skyride at pace. This setting disables them: unchecked (the default) keeps the effects on, ticked turns them off. EMS recommends leaving it unchecked because the blur and vignette are part of the intended sense-of-speed feedback, but tick it if they trigger motion sickness or you want a cleaner view on long flights. This setting is saved account-wide, so it persists across sessions once you set it." -- MT
L["GEMS_CVAR_DRAGON_NOVELVFX"] = "Disable Flight Velocity Effects" -- MT
L["GEMS_CVAR_DRAGON_NOVELVFX_DESC"] =
    "Turns off the streaking speed-line particles during Skyriding. Unchecked by default; tick it for a calmer view." -- MT
L["GEMS_CVAR_DRAGON_NOVELVFX_DESCLONG"] =
    "The velocity VFX are the streaking speed-line particles that trail past the camera as your Skyriding speed climbs. This setting disables them: unchecked (the default) keeps them on, ticked turns them off. EMS recommends leaving it unchecked since the speed lines reinforce the feel of fast flight, but tick it if the particles distract you or add to motion discomfort. This setting is saved account-wide, so it persists across sessions once you set it." -- MT
L["GEMS_CVAR_DRAGON_LOOKAHEAD"] = "Dynamic Flight Look-Ahead" -- MT
L["GEMS_CVAR_DRAGON_LOOKAHEAD_DESC"] =
    "Leans the camera into your direction of travel for a more dynamic flight feel. Off by default." -- MT
L["GEMS_CVAR_DRAGON_LOOKAHEAD_DESCLONG"] =
    "When enabled, the game makes more dynamic attitude adjustments while you fly, leaning the view into your direction of travel so the horizon tilts with your manoeuvres. It is off by default. Turn it on for a livelier flight camera that leans with you; leave it off if you prefer a steady horizon or find the extra motion uncomfortable. This setting resets each session and does not persist across logouts; EMS re-applies your choice on every login." -- MT

-- Auto-mirrored from enUS for prefix GEMS_IMPORT_PREVIEW_STEPS_MALFORMED (cowork_util fix-locale-parity 2026-07-27)
L["GEMS_IMPORT_PREVIEW_STEPS_MALFORMED"] = "'%s': steps field is malformed, no steps could be read." -- MT
