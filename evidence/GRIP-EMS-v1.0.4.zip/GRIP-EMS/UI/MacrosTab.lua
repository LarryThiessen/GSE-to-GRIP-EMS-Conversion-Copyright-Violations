-- GRIP-EMS: Macros Tab
-- Macro stub management panel with info, slot usage, and orphan cleanup

local ADDON_NAME, GRIPEMS = ...
local UI = GRIPEMS.UI
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS")

-- Upvalue accessor for Defaults
local function D() return GRIPEMS.Defaults end

GRIPEMS.MacrosTab = {}
local MT = GRIPEMS.MacrosTab

-- Runtime state
MT.currentSeqName = nil

---------------------------------------------------------------------------
-- Initialization
---------------------------------------------------------------------------

--- Build the macros tab UI inside the given parent frame (content area).
--- @param parentFrame Frame The content area that hosts tab content
function MT:Init(parentFrame)
    if not parentFrame then return end
    local C = UI.Colors

    MT.container = parentFrame

    local frame = CreateFrame("Frame", nil, parentFrame)
    frame:SetAllPoints(parentFrame)
    frame:Hide()
    MT.frame = frame

    local yOff = -8

    -----------------------------------------------------------------------
    -- A) Stub Info for Current Sequence
    -----------------------------------------------------------------------
    local stubLabel = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(stubLabel, 10)
    stubLabel:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, yOff)
    stubLabel:SetText(L["GEMS_UI_MACRO_STUB_SECTION"])
    stubLabel:SetTextColor(C.textSecondary:GetRGBA())

    -- Stub icon
    local stubIcon = frame:CreateTexture(nil, "ARTWORK")
    stubIcon:SetSize(20, 20)
    stubIcon:SetPoint("TOPLEFT", stubLabel, "BOTTOMLEFT", 0, -4)
    stubIcon:Hide()
    MT.stubIcon = stubIcon

    -- Stub info text
    local stubInfo = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(stubInfo, 11)
    stubInfo:SetPoint("LEFT", stubIcon, "RIGHT", 6, 0)
    stubInfo:SetText(L["GEMS_UI_STUB_NONE"])
    stubInfo:SetTextColor(C.textMuted:GetRGBA())
    MT.stubInfo = stubInfo

    yOff = yOff - 14 - 4 - 20 - 12

    -----------------------------------------------------------------------
    -- B) Slot Usage
    -----------------------------------------------------------------------
    local slotInfo = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(slotInfo, 11)
    slotInfo:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, yOff)
    slotInfo:SetText("")
    slotInfo:SetTextColor(C.textSecondary:GetRGBA())
    MT.slotInfo = slotInfo

    yOff = yOff - 18

    -----------------------------------------------------------------------
    -- C) Action Buttons
    -----------------------------------------------------------------------
    local btnRow = CreateFrame("Frame", nil, frame)
    btnRow:SetHeight(D().KEY_CAPTURE_BUTTON_HEIGHT + 4)
    btnRow:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, yOff)
    btnRow:SetPoint("RIGHT", frame, "RIGHT", -8, 0)

    -- Refresh button
    local refreshBtn = UI:CreateButton(btnRow, L["GEMS_UI_REFRESH_STUBS"],
        80, D().KEY_CAPTURE_BUTTON_HEIGHT)
    refreshBtn:SetPoint("LEFT", btnRow, "LEFT", 0, 0)
    refreshBtn:SetScript("OnClick", function()
        local MM = GRIPEMS.MacroManager
        if MM then
            MM:ScanExisting()
            MT:RefreshDisplay()
        end
    end)
    refreshBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.bgRowHover:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
        UI:ShowTooltip(self, L["GEMS_UI_REFRESH_STUBS"],
            L["GEMS_UI_REFRESH_STUBS_DESC"])
    end)
    refreshBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
        UI:HideTooltip()
    end)

    -- Clean Orphans button
    local cleanBtn = UI:CreateButton(btnRow, L["GEMS_UI_CLEAN_ORPHANS"],
        110, D().KEY_CAPTURE_BUTTON_HEIGHT)
    cleanBtn:SetPoint("LEFT", refreshBtn, "RIGHT", 4, 0)
    cleanBtn:SetScript("OnClick", function()
        MT:CleanOrphans()
    end)
    cleanBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.bgRowHover:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
        UI:ShowTooltip(self, L["GEMS_UI_CLEAN_ORPHANS"],
            L["GEMS_UI_CLEAN_ORPHANS_DESC"])
    end)
    cleanBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
        UI:HideTooltip()
    end)

    yOff = yOff - D().KEY_CAPTURE_BUTTON_HEIGHT - 12

    -----------------------------------------------------------------------
    -- D) Stub List
    -----------------------------------------------------------------------
    local listHeader = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(listHeader, 10)
    listHeader:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, yOff)
    listHeader:SetText("")
    listHeader:SetTextColor(C.textSecondary:GetRGBA())
    MT.listHeader = listHeader

    -- Container for stub rows
    local listContainer = CreateFrame("Frame", nil, frame)
    listContainer:SetPoint("TOPLEFT", listHeader, "BOTTOMLEFT", 0, -4)
    listContainer:SetPoint("RIGHT", frame, "RIGHT", -8, 0)
    listContainer:SetHeight(D().MACROS_TAB_MAX_STUBS * D().STUB_ROW_HEIGHT)
    MT.listContainer = listContainer

    MT.stubRows = {}

    -- Register for sequence change callbacks so stub list auto-refreshes
    if GRIPEMS.RegisterCallback then
        GRIPEMS.RegisterCallback(MT, "SEQUENCE_CREATED", "OnSequenceChanged")
        GRIPEMS.RegisterCallback(MT, "SEQUENCE_DELETED", "OnSequenceChanged")
        GRIPEMS.RegisterCallback(MT, "SEQUENCE_UPDATED", "OnSequenceChanged")
    end
end

--- Auto-refresh when sequences change (callback handler).
function MT:OnSequenceChanged(event, name, data)
    if MT.frame and MT.frame:IsShown() then
        MT:RefreshDisplay()
    end
end

---------------------------------------------------------------------------
-- Orphan cleanup
---------------------------------------------------------------------------

--- Find and delete orphan macro stubs (stubs for sequences that no longer exist).
function MT:CleanOrphans()
    local MM = GRIPEMS.MacroManager
    local engine = GRIPEMS.Engine
    if not MM or not engine then return end

    -- Find orphans
    local orphans = {}
    for seqName, _ in pairs(MM.stubs) do
        if not engine.sequences[seqName] then
            orphans[#orphans + 1] = seqName
        end
    end

    if #orphans == 0 then
        GRIPEMS:Print(L["GEMS_UI_NO_ORPHANS"])
        return
    end

    -- Show confirmation dialog
    StaticPopupDialogs["GRIPEMS_CLEAN_ORPHANS"] = {
        text = string.format(L["GEMS_UI_CLEAN_CONFIRM"], #orphans),
        button1 = ACCEPT,
        button2 = CANCEL,
        OnAccept = function()
            local count = 0
            for _, seqName in ipairs(orphans) do
                MM:DeleteStub(seqName)
                count = count + 1
            end
            -- Rescan to rebuild accurate slot indices after batch deletion
            MM:ScanExisting()
            GRIPEMS:Print(string.format(L["GEMS_UI_ORPHANS_CLEANED"], count))
            MT:RefreshDisplay()
        end,
        timeout = 0,
        whileDead = true,
        hideOnEscape = true,
    }
    StaticPopup_Show("GRIPEMS_CLEAN_ORPHANS")
end

---------------------------------------------------------------------------
-- Display refresh
---------------------------------------------------------------------------

--- Refresh the entire macros tab display.
function MT:RefreshDisplay()
    if not MT.frame then return end
    local C = UI.Colors
    local MM = GRIPEMS.MacroManager

    -- Stub info for current sequence
    if MT.currentSeqName and MM and MM.stubs[MT.currentSeqName] then
        local slotId = MM.stubs[MT.currentSeqName]
        local macroName, macroIcon = GetMacroInfo(slotId)
        if macroName then
            MT.stubInfo:SetText(string.format(L["GEMS_UI_STUB_INFO"],
                macroName, slotId))
            MT.stubInfo:SetTextColor(C.textPrimary:GetRGBA())
            if macroIcon then
                MT.stubIcon:SetTexture(macroIcon)
                MT.stubIcon:Show()
            end
        else
            MT.stubInfo:SetText(L["GEMS_UI_STUB_NONE"])
            MT.stubInfo:SetTextColor(C.textMuted:GetRGBA())
            MT.stubIcon:Hide()
        end
    else
        MT.stubInfo:SetText(L["GEMS_UI_STUB_NONE"])
        MT.stubInfo:SetTextColor(C.textMuted:GetRGBA())
        MT.stubIcon:Hide()
    end

    -- Slot usage
    if MT.slotInfo then
        local _, perChar = GetNumMacros()
        local maxSlots = D().MAX_PER_CHAR_MACROS
        MT.slotInfo:SetText(string.format(L["GEMS_UI_SLOTS_USED"],
            perChar, maxSlots))

        if perChar >= maxSlots then
            MT.slotInfo:SetTextColor(C.textError:GetRGBA())
        elseif perChar >= 14 then
            MT.slotInfo:SetTextColor(C.textWarning:GetRGBA())
        else
            MT.slotInfo:SetTextColor(C.textSuccess:GetRGBA())
        end
    end

    -- Stub list
    MT:RefreshStubList()
end

--- Refresh the stub list display.
function MT:RefreshStubList()
    if not MT.listContainer then return end
    local C = UI.Colors
    local MM = GRIPEMS.MacroManager
    local engine = GRIPEMS.Engine

    -- Hide existing rows
    for _, row in ipairs(MT.stubRows) do
        row:Hide()
    end

    if not MM or not next(MM.stubs) then
        if MT.listHeader then
            MT.listHeader:SetText(L["GEMS_UI_NO_STUBS"])
        end
        return
    end

    -- Build sorted list of stubs
    local stubList = {}
    for seqName, slotId in pairs(MM.stubs) do
        stubList[#stubList + 1] = {
            name = seqName,
            slotId = slotId,
            isActive = engine and engine.sequences[seqName] ~= nil,
        }
    end
    table.sort(stubList, function(a, b) return a.name < b.name end)

    if MT.listHeader then
        MT.listHeader:SetText(string.format(L["GEMS_UI_STUB_LIST_HEADER"],
            #stubList))
    end

    -- Create/update rows (capped at MACROS_TAB_MAX_STUBS)
    local maxRows = math.min(#stubList, D().MACROS_TAB_MAX_STUBS)
    for i = 1, maxRows do
        local entry = stubList[i]
        local row = MT.stubRows[i]

        if not row then
            row = CreateFrame("Frame", nil, MT.listContainer)
            row:SetHeight(D().STUB_ROW_HEIGHT)

            -- Status dot
            row.dot = row:CreateTexture(nil, "ARTWORK")
            row.dot:SetSize(8, 8)
            row.dot:SetPoint("LEFT", row, "LEFT", 2, 0)
            row.dot:SetColorTexture(0, 1, 0, 1)

            -- Name text
            row.nameText = row:CreateFontString(nil, "OVERLAY")
            UI:SetFont(row.nameText, 10)
            row.nameText:SetPoint("LEFT", row.dot, "RIGHT", 4, 0)
            row.nameText:SetJustifyH("LEFT")

            -- Slot text
            row.slotText = row:CreateFontString(nil, "OVERLAY")
            UI:SetFont(row.slotText, 10)
            row.slotText:SetPoint("RIGHT", row, "RIGHT", -4, 0)
            row.slotText:SetJustifyH("RIGHT")

            MT.stubRows[i] = row
        end

        -- Position
        row:SetPoint("TOPLEFT", MT.listContainer, "TOPLEFT", 0,
            -(i - 1) * D().STUB_ROW_HEIGHT)
        row:SetPoint("RIGHT", MT.listContainer, "RIGHT", 0, 0)

        -- Content
        row.nameText:SetText(entry.name)
        row.slotText:SetText("slot " .. entry.slotId)

        if entry.isActive then
            row.dot:SetColorTexture(0, 0.8, 0.4, 1)  -- green
            row.nameText:SetTextColor(C.textPrimary:GetRGBA())
            row.slotText:SetTextColor(C.textSecondary:GetRGBA())
        else
            row.dot:SetColorTexture(1, 0.267, 0.267, 1)  -- red
            row.nameText:SetTextColor(C.textError:GetRGBA())
            row.slotText:SetTextColor(C.textMuted:GetRGBA())
        end

        row:Show()
    end
end

---------------------------------------------------------------------------
-- Data flow methods (called by SequenceEditor)
---------------------------------------------------------------------------

--- Load macro data for a sequence.
--- @param name string Sequence name
function MT:LoadSequence(name)
    MT.currentSeqName = name
    MT:RefreshDisplay()
end

--- Clear the macros tab.
function MT:Clear()
    MT.currentSeqName = nil
    for _, row in ipairs(MT.stubRows) do
        row:Hide()
    end
end

--- Show the macros tab.
function MT:Show()
    if MT.frame then MT.frame:Show() end
    MT:RefreshDisplay()
end

--- Hide the macros tab.
function MT:Hide()
    if MT.frame then MT.frame:Hide() end
end
