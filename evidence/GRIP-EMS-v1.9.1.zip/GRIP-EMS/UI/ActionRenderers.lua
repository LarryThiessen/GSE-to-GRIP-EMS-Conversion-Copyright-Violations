-- GRIP-EMS: Action Tree Renderers
-- Renders hierarchical action nodes (Loop, If, Embed, Pause, Action)
-- in the StepListView tree mode. Each renderer creates frames for one
-- node type with indentation, controls, and child containers.

local ADDON_NAME, GRIPEMS = ...
local UI = GRIPEMS.UI

local function D()
    return GRIPEMS.Defaults
end

GRIPEMS.ActionRenderers = {}
local AR = GRIPEMS.ActionRenderers

-- Tree indent per depth level (px)
local INDENT_PER_DEPTH = 20

-- Row heights
local NODE_ROW_HEIGHT = 28
local HEADER_ROW_HEIGHT = 26
local TOOLBAR_HEIGHT = 28

-- Frame pool for reuse across refreshes
AR._framePool = {}
AR._poolIndex = 0
AR._recycleBin = CreateFrame("Frame")
AR._recycleBin:Hide()

---------------------------------------------------------------------------
-- Frame pool management
---------------------------------------------------------------------------

--- Reset the pool index before a full re-render.
function AR.ResetPool()
    AR._poolIndex = 0
    -- Purge recycle bin to allow GC of old children
    if AR._recycleBin then
        for _, child in ipairs({ AR._recycleBin:GetChildren() }) do
            child:ClearAllPoints()
            child:SetParent(nil)
        end
        for _, region in ipairs({ AR._recycleBin:GetRegions() }) do
            region:ClearAllPoints()
            region:SetParent(nil)
        end
    end
end

--- Get or create a frame from the pool, parented to the given frame.
--- @param parent Frame Parent frame
--- @param template string|nil Template name (nil for plain Frame)
--- @return Frame Pooled or new frame
local function AcquireFrame(parent, template)
    AR._poolIndex = AR._poolIndex + 1
    local frame = AR._framePool[AR._poolIndex]
    if frame then
        -- Wipe children from previous render to prevent EditBox accumulation.
        local children = { frame:GetChildren() }
        for _, child in ipairs(children) do
            child:Hide()
            child:SetParent(AR._recycleBin)
        end
        local regions = { frame:GetRegions() }
        for _, region in ipairs(regions) do
            region:Hide()
            region:SetParent(AR._recycleBin)
        end
        frame:SetParent(parent)
        frame:ClearAllPoints()
        frame:Show()
        return frame
    end
    if template then
        frame = CreateFrame("Frame", nil, parent, template)
    else
        frame = CreateFrame("Frame", nil, parent)
    end
    AR._framePool[AR._poolIndex] = frame
    return frame
end

--- Hide all unused pool frames after rendering.
function AR.HideUnused()
    for i = AR._poolIndex + 1, #AR._framePool do
        AR._framePool[i]:Hide()
    end
end

---------------------------------------------------------------------------
-- Shared helpers
---------------------------------------------------------------------------

--- Create a type label (left-aligned text showing node type name).
--- @param parent Frame Parent frame
--- @param text string Label text
--- @param depth number Nesting depth for indent
--- @return FontString The label
local function CreateTypeLabel(parent, text, depth)
    local C = UI.Colors
    local label = parent:CreateFontString(nil, "OVERLAY")
    UI:SetFont(label, 10, "OUTLINE")
    label:SetPoint("LEFT", parent, "LEFT", depth * INDENT_PER_DEPTH + 4, 0)
    label:SetText(text)
    label:SetTextColor(C.gripGreen:GetRGBA())
    return label
end

--- Create a small button within a row frame.
--- @param parent Frame Parent frame
--- @param labelText string Button label
--- @param width number Button width
--- @param onClick function Click handler
--- @return Button The button
local function CreateSmallButton(parent, labelText, width, onClick)
    local btn = UI:CreateButton(parent, labelText, width, 20)
    btn:SetScript("OnClick", onClick)
    return btn
end

--- Build an EditBox for inline text editing within a node row.
--- @param parent Frame Parent frame
--- @param initialText string Starting text
--- @param onChanged function Callback(newText)
--- @return EditBox The EditBox
local function CreateInlineEditBox(parent, initialText, onChanged)
    local C = UI.Colors
    local editBox = CreateFrame("EditBox", nil, parent, "BackdropTemplate")
    editBox:SetHeight(20)
    editBox:SetAutoFocus(false)
    editBox:SetMultiLine(false)
    editBox:SetMaxBytes(255)
    UI:ApplyBackdrop(editBox, UI.Backdrops.panel, C.bgInput, C.border)
    editBox:SetTextInsets(4, 4, 2, 2)
    local fontPath = GameFontNormal:GetFont()
    editBox:SetFont(fontPath, 11, "")
    editBox:SetTextColor(C.textPrimary:GetRGBA())
    editBox:SetText(initialText or "")
    editBox:SetScript("OnTextChanged", function(self, userInput)
        if not userInput then
            return
        end
        if onChanged then
            onChanged(self:GetText() or "")
        end
    end)
    editBox:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
    end)
    editBox:SetScript("OnEditFocusGained", function(self)
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
    end)
    editBox:SetScript("OnEditFocusLost", function(self)
        self:SetBackdropBorderColor(C.border:GetRGBA())
    end)

    return editBox
end

--- Build a char count indicator FontString.
--- @param parent Frame Parent frame
--- @param count number Initial char count
--- @return FontString The indicator
local function CreateCharCount(parent, count)
    local C = UI.Colors
    local defaults = D()
    local fs = parent:CreateFontString(nil, "OVERLAY")
    UI:SetFont(fs, 9)
    fs:SetPoint("RIGHT", parent, "RIGHT", -4, 0)
    local displayCount = count or 0
    fs:SetText(string.format("%d/%d", displayCount, defaults.CHAR_COUNT_DANGER))
    if displayCount >= defaults.CHAR_COUNT_DANGER then
        fs:SetTextColor(C.textError:GetRGBA())
    elseif displayCount > defaults.CHAR_COUNT_WARNING then
        fs:SetTextColor(C.textWarning:GetRGBA())
    else
        fs:SetTextColor(C.textSuccess:GetRGBA())
    end
    return fs
end

--- Update a char count FontString.
--- @param fs FontString The char count label
--- @param count number New char count
local function UpdateCharCount(fs, count)
    if not fs then
        return
    end
    local C = UI.Colors
    local defaults = D()
    local displayCount = count or 0
    fs:SetText(string.format("%d/%d", displayCount, defaults.CHAR_COUNT_DANGER))
    if displayCount >= defaults.CHAR_COUNT_DANGER then
        fs:SetTextColor(C.textError:GetRGBA())
    elseif displayCount > defaults.CHAR_COUNT_WARNING then
        fs:SetTextColor(C.textWarning:GetRGBA())
    else
        fs:SetTextColor(C.textSuccess:GetRGBA())
    end
end

--- Build move/delete buttons for a node row.
--- @param parent Frame Row frame
--- @param callbacks table { onDelete, onMoveUp, onMoveDown }
--- @return number rightEdge X offset for anchoring further left
local function CreateNodeControls(parent, callbacks)
    local delBtn = CreateSmallButton(parent, "X", 20, function()
        if callbacks.onDelete then
            callbacks.onDelete()
        end
    end)
    delBtn:SetPoint("RIGHT", parent, "RIGHT", -2, 0)

    local downBtn = CreateSmallButton(parent, "v", 20, function()
        if callbacks.onMoveDown then
            callbacks.onMoveDown()
        end
    end)
    downBtn:SetPoint("RIGHT", delBtn, "LEFT", -2, 0)

    local upBtn = CreateSmallButton(parent, "^", 20, function()
        if callbacks.onMoveUp then
            callbacks.onMoveUp()
        end
    end)
    upBtn:SetPoint("RIGHT", downBtn, "LEFT", -2, 0)

    return -70
end

---------------------------------------------------------------------------
-- RenderAction: single macro text node
---------------------------------------------------------------------------

--- Render an action (macro text) node.
--- @param parentFrame Frame Scroll child or container
--- @param node table Action node { type, macro }
--- @param depth number Nesting depth
--- @param callbacks table { onChanged, onDelete, onMoveUp, onMoveDown }
--- @param yOffset number Current Y offset in parent
--- @return number newYOffset Updated Y offset after this node
function AR.RenderAction(parentFrame, node, depth, callbacks, yOffset)
    local row = AcquireFrame(parentFrame, "BackdropTemplate")
    row:SetHeight(NODE_ROW_HEIGHT)
    row:SetPoint("TOPLEFT", parentFrame, "TOPLEFT", 0, yOffset)
    row:SetPoint("RIGHT", parentFrame, "RIGHT", 0, 0)

    local C = UI.Colors
    local defaults = D()
    if not row.SetBackdrop then
        Mixin(row, BackdropTemplateMixin)
    end
    row:SetBackdrop(UI.Backdrops.panelNoBorder)
    row:SetBackdropColor(C.bgMain:GetRGBA())

    -- Node controls (delete, move)
    CreateNodeControls(row, callbacks)

    -- NOTE: Interval UI below is currently unreachable. StepListView.lua
    -- _renderDetailSettings handles the live interval controls. This code
    -- exists as reference for when ActionRenderers is wired into the UI.

    -- Char count -- shift left when interleave controls are visible
    local hasInterleave = node.interval and node.interval >= defaults.ACTION_INTERLEAVE_MIN
    local charRightOffset = hasInterleave and -200 or -70
    local charFs = CreateCharCount(row, #(node.macro or ""))
    charFs:ClearAllPoints()
    charFs:SetPoint("RIGHT", row, "RIGHT", charRightOffset, 0)

    -- Interleave controls
    if hasInterleave then
        -- "Every:" label
        local everyLabel = row:CreateFontString(nil, "OVERLAY")
        UI:SetFont(everyLabel, 10)
        everyLabel:SetPoint("LEFT", charFs, "RIGHT", 4, 0)
        everyLabel:SetText("Every:")
        everyLabel:SetTextColor(C.textSecondary:GetRGBA())

        -- Interval spinner
        local intervalBox = CreateFrame("EditBox", nil, row, "BackdropTemplate")
        intervalBox:SetSize(36, 18)
        intervalBox:SetPoint("LEFT", everyLabel, "RIGHT", 4, 0)
        intervalBox:SetAutoFocus(false)
        intervalBox:SetNumeric(true)
        intervalBox:SetMaxLetters(3)
        UI:ApplyBackdrop(intervalBox, UI.Backdrops.panel, C.bgInput, C.border)
        intervalBox:SetTextInsets(4, 4, 2, 2)
        local fontPath = GameFontNormal:GetFont()
        intervalBox:SetFont(fontPath, 10, "")
        intervalBox:SetTextColor(C.textPrimary:GetRGBA())
        intervalBox:SetText(tostring(node.interval))
        intervalBox:SetScript("OnTextChanged", function(self, userInput)
            if not userInput then
                return
            end
            local val = tonumber(self:GetText()) or defaults.ACTION_INTERLEAVE_DEFAULT
            if val < defaults.ACTION_INTERLEAVE_MIN then
                val = defaults.ACTION_INTERLEAVE_MIN
            end
            if val > defaults.ACTION_INTERLEAVE_MAX then
                val = defaults.ACTION_INTERLEAVE_MAX
            end
            node.interval = val
            if callbacks.onChanged then
                callbacks.onChanged()
            end
        end)
        intervalBox:SetScript("OnEscapePressed", function(self)
            self:ClearFocus()
        end)

        -- "steps" label
        local stepsLabel = row:CreateFontString(nil, "OVERLAY")
        UI:SetFont(stepsLabel, 10)
        stepsLabel:SetPoint("LEFT", intervalBox, "RIGHT", 4, 0)
        stepsLabel:SetText("steps")
        stepsLabel:SetTextColor(C.textSecondary:GetRGBA())

        -- Clear button
        local clearBtn = CreateSmallButton(row, "x", 16, function()
            node.interval = nil
            if callbacks.onChanged then
                callbacks.onChanged()
            end
        end)
        clearBtn:SetPoint("LEFT", stepsLabel, "RIGHT", 4, 0)
    else
        -- Toggle button to enable interleave
        local ilBtn = CreateSmallButton(row, "IL", 24, function()
            node.interval = defaults.ACTION_INTERLEAVE_DEFAULT
            if callbacks.onChanged then
                callbacks.onChanged()
            end
        end)
        ilBtn:SetPoint("RIGHT", charFs, "LEFT", -4, 0)
    end

    -- EditBox
    local editBox = CreateInlineEditBox(row, node.macro or "", function(newText)
        node.macro = newText
        UpdateCharCount(charFs, #newText)
        if callbacks.onChanged then
            callbacks.onChanged()
        end
    end)
    editBox:SetPoint("LEFT", row, "LEFT", depth * INDENT_PER_DEPTH + 4, 0)
    if hasInterleave then
        editBox:SetPoint("RIGHT", charFs, "LEFT", -4, 0)
    else
        editBox:SetPoint("RIGHT", charFs, "LEFT", -32, 0)
    end
    editBox:SetHeight(20)

    return yOffset - NODE_ROW_HEIGHT
end

---------------------------------------------------------------------------
-- RenderLoop: loop block with children
---------------------------------------------------------------------------

--- Render a Loop block node.
--- @param parentFrame Frame Container
--- @param node table Loop node { type, children, repeat, stepFunction }
--- @param depth number Nesting depth
--- @param callbacks table Callbacks
--- @param yOffset number Current Y offset
--- @return number newYOffset Updated Y offset
function AR.RenderLoop(parentFrame, node, depth, callbacks, yOffset)
    local C = UI.Colors

    -- Header row
    local header = AcquireFrame(parentFrame, "BackdropTemplate")
    header:SetHeight(HEADER_ROW_HEIGHT)
    header:SetPoint("TOPLEFT", parentFrame, "TOPLEFT", 0, yOffset)
    header:SetPoint("RIGHT", parentFrame, "RIGHT", 0, 0)
    if not header.SetBackdrop then
        Mixin(header, BackdropTemplateMixin)
    end
    header:SetBackdrop(UI.Backdrops.panelNoBorder)
    header:SetBackdropColor(C.bgPanel:GetRGBA())

    -- Node controls
    CreateNodeControls(header, callbacks)

    -- Loop label
    CreateTypeLabel(header, "Loop", depth)

    -- Repeat spinner (EditBox with numeric clamping)
    local repeatLabel = header:CreateFontString(nil, "OVERLAY")
    UI:SetFont(repeatLabel, 10)
    repeatLabel:SetPoint("LEFT", header, "LEFT", depth * INDENT_PER_DEPTH + 50, 0)
    repeatLabel:SetText("Repeat:")
    repeatLabel:SetTextColor(C.textSecondary:GetRGBA())

    local repeatBox = CreateFrame("EditBox", nil, header, "BackdropTemplate")
    repeatBox:SetSize(36, 18)
    repeatBox:SetPoint("LEFT", repeatLabel, "RIGHT", 4, 0)
    repeatBox:SetAutoFocus(false)
    repeatBox:SetNumeric(true)
    repeatBox:SetMaxLetters(3)
    UI:ApplyBackdrop(repeatBox, UI.Backdrops.panel, C.bgInput, C.border)
    repeatBox:SetTextInsets(4, 4, 2, 2)
    local fontPath = GameFontNormal:GetFont()
    repeatBox:SetFont(fontPath, 10, "")
    repeatBox:SetTextColor(C.textPrimary:GetRGBA())
    repeatBox:SetText(tostring(node["repeat"] or D().ACTION_LOOP_DEFAULT_REPEAT))
    repeatBox:SetScript("OnTextChanged", function(self, userInput)
        if not userInput then
            return
        end
        local val = tonumber(self:GetText()) or D().ACTION_LOOP_DEFAULT_REPEAT
        if val < 1 then
            val = 1
        end
        if val > D().ACTION_LOOP_MAX_REPEAT then
            val = D().ACTION_LOOP_MAX_REPEAT
        end
        node["repeat"] = val
        if callbacks.onChanged then
            callbacks.onChanged()
        end
    end)
    repeatBox:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
    end)

    -- Step function dropdown
    local sfLabel = header:CreateFontString(nil, "OVERLAY")
    UI:SetFont(sfLabel, 10)
    sfLabel:SetPoint("LEFT", repeatBox, "RIGHT", 8, 0)
    sfLabel:SetText("SF:")
    sfLabel:SetTextColor(C.textSecondary:GetRGBA())

    local sfNames = { D().STEP_SEQUENTIAL, D().STEP_PRIORITY, D().STEP_REVERSE_PRIORITY, D().STEP_RANDOM }
    local sfBtn = CreateSmallButton(header, node.stepFunction or D().STEP_SEQUENTIAL, 80, function(self)
        MenuUtil.CreateContextMenu(self, function(_, rootDescription)
            for _, sfName in ipairs(sfNames) do
                rootDescription:CreateButton(sfName, function()
                    node.stepFunction = sfName
                    self.label:SetText(sfName)
                    if callbacks.onChanged then
                        callbacks.onChanged()
                    end
                end)
            end
        end)
    end)
    sfBtn:SetPoint("LEFT", sfLabel, "RIGHT", 4, 0)

    yOffset = yOffset - HEADER_ROW_HEIGHT

    -- Render children recursively
    local children = node.children or {}
    for i, child in ipairs(children) do
        local childCallbacks = {
            onChanged = callbacks.onChanged,
            onDelete = function()
                table.remove(children, i)
                if callbacks.onChanged then
                    callbacks.onChanged()
                end
            end,
            onMoveUp = function()
                if i > 1 then
                    children[i], children[i - 1] = children[i - 1], children[i]
                    if callbacks.onChanged then
                        callbacks.onChanged()
                    end
                end
            end,
            onMoveDown = function()
                if i < #children then
                    children[i], children[i + 1] = children[i + 1], children[i]
                    if callbacks.onChanged then
                        callbacks.onChanged()
                    end
                end
            end,
        }
        yOffset = AR.RenderNode(parentFrame, child, depth + 1, childCallbacks, yOffset)
    end

    -- Add Action button at bottom of loop
    local addRow = AcquireFrame(parentFrame)
    addRow:SetHeight(22)
    addRow:SetPoint("TOPLEFT", parentFrame, "TOPLEFT", 0, yOffset)
    addRow:SetPoint("RIGHT", parentFrame, "RIGHT", 0, 0)

    local addBtn = CreateSmallButton(addRow, "+ Action", 70, function()
        children[#children + 1] = D().NewActionNode(D().ACTION_TYPE_ACTION)
        if callbacks.onChanged then
            callbacks.onChanged()
        end
    end)
    addBtn:SetPoint("LEFT", addRow, "LEFT", (depth + 1) * INDENT_PER_DEPTH + 4, 0)

    yOffset = yOffset - 22

    return yOffset
end

---------------------------------------------------------------------------
-- RenderIf: conditional block with true/false branches
---------------------------------------------------------------------------

--- Render an If block node.
--- @param parentFrame Frame Container
--- @param node table If node { type, variable, children = { trueBranch, falseBranch } }
--- @param depth number Nesting depth
--- @param callbacks table Callbacks
--- @param yOffset number Current Y offset
--- @return number newYOffset Updated Y offset
function AR.RenderIf(parentFrame, node, depth, callbacks, yOffset)
    local C = UI.Colors

    -- Header row
    local header = AcquireFrame(parentFrame, "BackdropTemplate")
    header:SetHeight(HEADER_ROW_HEIGHT)
    header:SetPoint("TOPLEFT", parentFrame, "TOPLEFT", 0, yOffset)
    header:SetPoint("RIGHT", parentFrame, "RIGHT", 0, 0)
    if not header.SetBackdrop then
        Mixin(header, BackdropTemplateMixin)
    end
    header:SetBackdrop(UI.Backdrops.panelNoBorder)
    header:SetBackdropColor(C.bgPanel:GetRGBA())

    CreateNodeControls(header, callbacks)
    CreateTypeLabel(header, "If", depth)

    -- Variable EditBox
    local varEditBox = CreateInlineEditBox(header, node.variable or "= true", function(newText)
        node.variable = newText
        if callbacks.onChanged then
            callbacks.onChanged()
        end
    end)
    varEditBox:SetPoint("LEFT", header, "LEFT", depth * INDENT_PER_DEPTH + 30, 0)
    varEditBox:SetPoint("RIGHT", header, "RIGHT", -74, 0)
    varEditBox:SetHeight(18)

    yOffset = yOffset - HEADER_ROW_HEIGHT

    -- True branch label
    local trueLbl = AcquireFrame(parentFrame)
    trueLbl:SetHeight(18)
    trueLbl:SetPoint("TOPLEFT", parentFrame, "TOPLEFT", 0, yOffset)
    trueLbl:SetPoint("RIGHT", parentFrame, "RIGHT", 0, 0)
    local trueFs = trueLbl:CreateFontString(nil, "OVERLAY")
    UI:SetFont(trueFs, 9)
    trueFs:SetPoint("LEFT", trueLbl, "LEFT", (depth + 1) * INDENT_PER_DEPTH + 4, 0)
    trueFs:SetText("True:")
    trueFs:SetTextColor(C.textSuccess:GetRGBA())
    yOffset = yOffset - 18

    -- Ensure children branches exist
    if not node.children then
        node.children = { {}, {} }
    end
    if not node.children[1] then
        node.children[1] = {}
    end
    if not node.children[2] then
        node.children[2] = {}
    end

    -- Render true branch children
    local trueBranch = node.children[1]

    for i, child in ipairs(trueBranch) do
        local childCallbacks = {
            onChanged = callbacks.onChanged,
            onDelete = function()
                table.remove(trueBranch, i)
                if callbacks.onChanged then
                    callbacks.onChanged()
                end
            end,
            onMoveUp = function()
                if i > 1 then
                    trueBranch[i], trueBranch[i - 1] = trueBranch[i - 1], trueBranch[i]
                    if callbacks.onChanged then
                        callbacks.onChanged()
                    end
                end
            end,
            onMoveDown = function()
                if i < #trueBranch then
                    trueBranch[i], trueBranch[i + 1] = trueBranch[i + 1], trueBranch[i]
                    if callbacks.onChanged then
                        callbacks.onChanged()
                    end
                end
            end,
        }
        yOffset = AR.RenderNode(parentFrame, child, depth + 2, childCallbacks, yOffset)
    end

    -- Add Action for true branch
    local addTrueRow = AcquireFrame(parentFrame)
    addTrueRow:SetHeight(22)
    addTrueRow:SetPoint("TOPLEFT", parentFrame, "TOPLEFT", 0, yOffset)
    addTrueRow:SetPoint("RIGHT", parentFrame, "RIGHT", 0, 0)
    local addTrueBtn = CreateSmallButton(addTrueRow, "+ Action", 70, function()
        trueBranch[#trueBranch + 1] = D().NewActionNode(D().ACTION_TYPE_ACTION)
        if callbacks.onChanged then
            callbacks.onChanged()
        end
    end)
    addTrueBtn:SetPoint("LEFT", addTrueRow, "LEFT", (depth + 2) * INDENT_PER_DEPTH + 4, 0)
    yOffset = yOffset - 22

    -- False branch label
    local falseLbl = AcquireFrame(parentFrame)
    falseLbl:SetHeight(18)
    falseLbl:SetPoint("TOPLEFT", parentFrame, "TOPLEFT", 0, yOffset)
    falseLbl:SetPoint("RIGHT", parentFrame, "RIGHT", 0, 0)
    local falseFs = falseLbl:CreateFontString(nil, "OVERLAY")
    UI:SetFont(falseFs, 9)
    falseFs:SetPoint("LEFT", falseLbl, "LEFT", (depth + 1) * INDENT_PER_DEPTH + 4, 0)
    falseFs:SetText("False:")
    falseFs:SetTextColor(C.textError:GetRGBA())
    yOffset = yOffset - 18

    -- Render false branch children
    local falseBranch = node.children[2]
    for i, child in ipairs(falseBranch) do
        local childCallbacks = {
            onChanged = callbacks.onChanged,
            onDelete = function()
                table.remove(falseBranch, i)
                if callbacks.onChanged then
                    callbacks.onChanged()
                end
            end,
            onMoveUp = function()
                if i > 1 then
                    falseBranch[i], falseBranch[i - 1] = falseBranch[i - 1], falseBranch[i]
                    if callbacks.onChanged then
                        callbacks.onChanged()
                    end
                end
            end,
            onMoveDown = function()
                if i < #falseBranch then
                    falseBranch[i], falseBranch[i + 1] = falseBranch[i + 1], falseBranch[i]
                    if callbacks.onChanged then
                        callbacks.onChanged()
                    end
                end
            end,
        }
        yOffset = AR.RenderNode(parentFrame, child, depth + 2, childCallbacks, yOffset)
    end

    -- Add Action for false branch
    local addFalseRow = AcquireFrame(parentFrame)
    addFalseRow:SetHeight(22)
    addFalseRow:SetPoint("TOPLEFT", parentFrame, "TOPLEFT", 0, yOffset)
    addFalseRow:SetPoint("RIGHT", parentFrame, "RIGHT", 0, 0)
    local addFalseBtn = CreateSmallButton(addFalseRow, "+ Action", 70, function()
        falseBranch[#falseBranch + 1] = D().NewActionNode(D().ACTION_TYPE_ACTION)
        if callbacks.onChanged then
            callbacks.onChanged()
        end
    end)
    addFalseBtn:SetPoint("LEFT", addFalseRow, "LEFT", (depth + 2) * INDENT_PER_DEPTH + 4, 0)
    yOffset = yOffset - 22

    return yOffset
end

---------------------------------------------------------------------------
-- RenderEmbed: sequence reference
---------------------------------------------------------------------------

--- Render an Embed node.
--- @param parentFrame Frame Container
--- @param node table Embed node { type, sequence }
--- @param depth number Nesting depth
--- @param callbacks table Callbacks
--- @param yOffset number Current Y offset
--- @return number newYOffset Updated Y offset
function AR.RenderEmbed(parentFrame, node, depth, callbacks, yOffset)
    local C = UI.Colors

    local row = AcquireFrame(parentFrame, "BackdropTemplate")
    row:SetHeight(NODE_ROW_HEIGHT)
    row:SetPoint("TOPLEFT", parentFrame, "TOPLEFT", 0, yOffset)
    row:SetPoint("RIGHT", parentFrame, "RIGHT", 0, 0)
    if not row.SetBackdrop then
        Mixin(row, BackdropTemplateMixin)
    end
    row:SetBackdrop(UI.Backdrops.panelNoBorder)
    row:SetBackdropColor(C.bgMain:GetRGBA())

    CreateNodeControls(row, callbacks)
    CreateTypeLabel(row, "Embed", depth)

    -- Sequence dropdown button
    local seqBtn = CreateSmallButton(row, node.sequence or "(select)", 120, function(self)
        -- Build list of sequences for current class
        local Engine = GRIPEMS.Engine
        if not Engine or not Engine.sequences then
            return
        end
        MenuUtil.CreateContextMenu(self, function(_, rootDescription)
            local names = {}
            for seqName in pairs(Engine.sequences) do
                names[#names + 1] = seqName
            end
            table.sort(names)
            for _, seqName in ipairs(names) do
                rootDescription:CreateButton(seqName, function()
                    node.sequence = seqName
                    self.label:SetText(seqName)
                    if callbacks.onChanged then
                        callbacks.onChanged()
                    end
                end)
            end
        end)
    end)
    seqBtn:SetPoint("LEFT", row, "LEFT", depth * INDENT_PER_DEPTH + 55, 0)

    return yOffset - NODE_ROW_HEIGHT
end

---------------------------------------------------------------------------
-- RenderPause: pause (empty keypresses)
---------------------------------------------------------------------------

--- Render a Pause node.
--- @param parentFrame Frame Container
--- @param node table Pause node { type, clicks, ms, gcd }
--- @param depth number Nesting depth
--- @param callbacks table Callbacks
--- @param yOffset number Current Y offset
--- @return number newYOffset Updated Y offset
function AR.RenderPause(parentFrame, node, depth, callbacks, yOffset)
    local C = UI.Colors

    local row = AcquireFrame(parentFrame, "BackdropTemplate")
    row:SetHeight(NODE_ROW_HEIGHT)
    row:SetPoint("TOPLEFT", parentFrame, "TOPLEFT", 0, yOffset)
    row:SetPoint("RIGHT", parentFrame, "RIGHT", 0, 0)
    if not row.SetBackdrop then
        Mixin(row, BackdropTemplateMixin)
    end
    row:SetBackdrop(UI.Backdrops.panelNoBorder)
    row:SetBackdropColor(C.bgMain:GetRGBA())

    CreateNodeControls(row, callbacks)
    CreateTypeLabel(row, "Pause", depth)

    -- Mode dropdown (Clicks / MS / GCD)
    local modes = { "clicks", "ms", "gcd" }
    local modeLabels = { clicks = "Clicks", ms = "MS", gcd = "GCD" }
    local currentMode = "clicks"
    if node.ms then
        currentMode = "ms"
    elseif node.gcd then
        currentMode = "gcd"
    end

    local modeBtn = CreateSmallButton(row, modeLabels[currentMode], 50, function(self)
        MenuUtil.CreateContextMenu(self, function(_, rootDescription)
            for _, mode in ipairs(modes) do
                rootDescription:CreateButton(modeLabels[mode], function()
                    -- Clear old mode values
                    node.clicks = nil
                    node.ms = nil
                    node.gcd = nil
                    if mode == "clicks" then
                        node.clicks = 1
                    elseif mode == "ms" then
                        node.ms = 250
                    elseif mode == "gcd" then
                        node.gcd = 1
                    end
                    self.label:SetText(modeLabels[mode])
                    if callbacks.onChanged then
                        callbacks.onChanged()
                    end
                end)
            end
        end)
    end)
    modeBtn:SetPoint("LEFT", row, "LEFT", depth * INDENT_PER_DEPTH + 55, 0)

    -- Value EditBox
    local initialVal = node.clicks or node.ms or node.gcd or 1
    local valBox = CreateFrame("EditBox", nil, row, "BackdropTemplate")
    valBox:SetSize(50, 18)
    valBox:SetPoint("LEFT", modeBtn, "RIGHT", 4, 0)
    valBox:SetAutoFocus(false)
    valBox:SetNumeric(true)
    valBox:SetMaxLetters(5)
    UI:ApplyBackdrop(valBox, UI.Backdrops.panel, C.bgInput, C.border)
    valBox:SetTextInsets(4, 4, 2, 2)
    local fontPath = GameFontNormal:GetFont()
    valBox:SetFont(fontPath, 10, "")
    valBox:SetTextColor(C.textPrimary:GetRGBA())
    valBox:SetText(tostring(initialVal))
    valBox:SetScript("OnTextChanged", function(self, userInput)
        if not userInput then
            return
        end
        local val = tonumber(self:GetText()) or 1
        if val < 1 then
            val = 1
        end
        if node.clicks then
            node.clicks = val
        elseif node.ms then
            node.ms = val
        elseif node.gcd then
            node.gcd = val
        end
        if callbacks.onChanged then
            callbacks.onChanged()
        end
    end)
    valBox:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
    end)

    return yOffset - NODE_ROW_HEIGHT
end

---------------------------------------------------------------------------
-- RenderNode: dispatcher
---------------------------------------------------------------------------

--- Render any node by dispatching to the type-specific renderer.
--- @param parentFrame Frame Container
--- @param node table Action node
--- @param depth number Nesting depth
--- @param callbacks table Callbacks
--- @param yOffset number Current Y offset
--- @return number newYOffset Updated Y offset
function AR.RenderNode(parentFrame, node, depth, callbacks, yOffset)
    if not node or not node.type then
        return yOffset
    end

    local defaults = D()
    local nodeType = node.type

    if nodeType == defaults.ACTION_TYPE_ACTION then
        return AR.RenderAction(parentFrame, node, depth, callbacks, yOffset)
    elseif nodeType == defaults.ACTION_TYPE_LOOP then
        return AR.RenderLoop(parentFrame, node, depth, callbacks, yOffset)
    elseif nodeType == defaults.ACTION_TYPE_IF then
        return AR.RenderIf(parentFrame, node, depth, callbacks, yOffset)
    elseif nodeType == defaults.ACTION_TYPE_EMBED then
        return AR.RenderEmbed(parentFrame, node, depth, callbacks, yOffset)
    elseif nodeType == defaults.ACTION_TYPE_PAUSE then
        return AR.RenderPause(parentFrame, node, depth, callbacks, yOffset)
    end

    return yOffset
end

---------------------------------------------------------------------------
-- RenderActionTree: top-level entry point
---------------------------------------------------------------------------

--- Render a full action tree into a scroll child frame.
--- Clears and re-renders all nodes plus the bottom toolbar.
--- @param scrollChild Frame The scroll child frame to render into
--- @param actions table Array of action nodes
--- @param callbacks table { onChanged }
function AR.RenderActionTree(scrollChild, actions, callbacks)
    if not scrollChild or not actions then
        return
    end

    AR.ResetPool()

    local yOffset = 0

    for i, node in ipairs(actions) do
        local nodeCallbacks = {
            onChanged = callbacks.onChanged,
            onDelete = function()
                table.remove(actions, i)
                if callbacks.onChanged then
                    callbacks.onChanged()
                end
            end,
            onAddChild = function()
                if node.children then
                    node.children[#node.children + 1] = D().NewActionNode(D().ACTION_TYPE_ACTION)
                    if callbacks.onChanged then
                        callbacks.onChanged()
                    end
                end
            end,
            onMoveUp = function()
                if i > 1 then
                    actions[i], actions[i - 1] = actions[i - 1], actions[i]
                    if callbacks.onChanged then
                        callbacks.onChanged()
                    end
                end
            end,
            onMoveDown = function()
                if i < #actions then
                    actions[i], actions[i + 1] = actions[i + 1], actions[i]
                    if callbacks.onChanged then
                        callbacks.onChanged()
                    end
                end
            end,
        }
        yOffset = AR.RenderNode(scrollChild, node, 0, nodeCallbacks, yOffset)
    end

    -- Bottom toolbar: add buttons for each action type
    -- S30-BUG-03: Skip button bar in read-only mode
    if not (callbacks and callbacks.readOnly) then
        local toolbar = AcquireFrame(scrollChild)
        toolbar:SetHeight(TOOLBAR_HEIGHT)
        toolbar:SetPoint("TOPLEFT", scrollChild, "TOPLEFT", 0, yOffset)
        toolbar:SetPoint("RIGHT", scrollChild, "RIGHT", 0, 0)

        local defaults = D()
        local addDefs = {
            { label = "+ Action", nodeType = defaults.ACTION_TYPE_ACTION },
            { label = "+ Loop", nodeType = defaults.ACTION_TYPE_LOOP },
            { label = "+ If", nodeType = defaults.ACTION_TYPE_IF },
            { label = "+ Embed", nodeType = defaults.ACTION_TYPE_EMBED },
            { label = "+ Pause", nodeType = defaults.ACTION_TYPE_PAUSE },
        }
        local prevBtn
        for _, def in ipairs(addDefs) do
            local btn = CreateSmallButton(toolbar, def.label, 60, function()
                actions[#actions + 1] = D().NewActionNode(def.nodeType)
                if callbacks.onChanged then
                    callbacks.onChanged()
                end
            end)
            if prevBtn then
                btn:SetPoint("LEFT", prevBtn, "RIGHT", 4, 0)
            else
                btn:SetPoint("LEFT", toolbar, "LEFT", 4, 0)
            end
            prevBtn = btn
        end

        yOffset = yOffset - TOOLBAR_HEIGHT
    end

    -- Update scroll child height
    scrollChild:SetHeight(math.abs(yOffset) + 10)

    AR.HideUnused()
end
