local _, ns = ...
ns.deferred = ns.deferred or {}

local function setup()
local GSE = ns.GSE
local UI = GSE.UI
local L = GSE.L

local cacheFrame = UI:Create("Frame")
UI.MakePopup(cacheFrame.frame, {center = true})
cacheFrame:Hide()
GSE.GUICacheFrame = cacheFrame
function GSE.GUICreateCacheTabs()
    local tabl = {}

    for key, _ in pairs(GSESpellCache or {}) do
        table.insert(
            tabl,
            {
                text = key,
                value = key
            }
        )
    end
    return tabl
end

function GSE.GUISelectCacheTab(container, event, group)
    if not GSE.isEmpty(container) then
        cacheFrame.reloading = true
        container:ReleaseChildren()
        cacheFrame.SelectedTab = group
        GSE:GUIDrawSpellCacheEditor(container, group)
        cacheFrame.reloading = false
    end
end

local function addKeyPairRow(container, rowWidth, key, value, language)
    local blank = false

    if GSE.isEmpty(key) then
        blank = true
    end
    if GSE.isEmpty(value) then
        blank = true
    end
    if GSE.isEmpty(language) then
        blank = true
    end
    if blank == true then
        return
    end

    local linegroup1 = UI:Create("SimpleGroup")
    linegroup1:SetLayout("Flow")
    linegroup1:SetWidth(rowWidth)
    rowWidth = rowWidth - 70

    local keyEditBox = UI:Create("EditBox")
    keyEditBox:SetLabel()
    keyEditBox:DisableButton(true)
    keyEditBox:SetWidth(rowWidth * 0.50)
    keyEditBox:SetText(key)
    local currentKey = key
    keyEditBox:SetCallback(
        "OnTextChanged",
        function(self, event, text)
            GSESpellCache[language][text] = GSESpellCache[language][currentKey]
            GSESpellCache[language][currentKey] = nil
            currentKey = text
        end
    )
    linegroup1:AddChild(keyEditBox)

    local spacerlabel1 = UI:Create("Label")
    spacerlabel1:SetWidth(5)
    linegroup1:AddChild(spacerlabel1)

    local valueEditBox = UI:Create("EditBox")
    valueEditBox:SetLabel()
    valueEditBox:SetWidth(rowWidth * 0.50)
    valueEditBox:DisableButton(true)
    valueEditBox:SetText(value)
    valueEditBox:SetCallback(
        "OnTextChanged",
        function(self, event, text)
            GSESpellCache[language][currentKey] = text
        end
    )
    valueEditBox:SetCallback(
        "OnEditFocusLost",
        function()
            valueEditBox:SetText(GSESpellCache[language][currentKey])
        end
    )

    linegroup1:AddChild(valueEditBox)

    local spacerlabel2 = UI:Create("Label")
    spacerlabel2:SetWidth(15)
    linegroup1:AddChild(spacerlabel2)

    local deleteRowButton = UI:Create("Icon")
    deleteRowButton:SetImageSize(20, 20)
    deleteRowButton:SetWidth(20)
    deleteRowButton:SetHeight(20)
    deleteRowButton:SetImage("Interface\\Icons\\spell_chargenegative")

    deleteRowButton:SetCallback(
        "OnClick",
        function()
            GSESpellCache[language][currentKey] = nil
            linegroup1:ReleaseChildren()
        end
    )

    linegroup1:AddChild(deleteRowButton)

    container:AddChild(linegroup1)
    return keyEditBox
end

function GSE:GUIDrawSpellCacheEditor(container, language)
    local languageCache = GSESpellCache and GSESpellCache[language]
    if type(languageCache) ~= "table" then languageCache = {} end

    local maxWidth = container.frame:GetWidth()
    local scrollcontainer = UI:Create("SimpleGroup") -- "InlineGroup" is also good
    scrollcontainer:SetFullWidth(true)
    scrollcontainer:SetHeight(cacheFrame.Height - 110)
    scrollcontainer:SetLayout("Fill") -- Important!

    local contentcontainer = UI:Create("ScrollFrame") -- "InlineGroup" is also good
    contentcontainer:SetWidth(maxWidth)
    contentcontainer:SetAutoAdjustHeight(true)
    scrollcontainer:AddChild(contentcontainer)
    local linegroup1 = UI:Create("SimpleGroup")
    linegroup1:SetLayout("Flow")
    local columnWidth = maxWidth - 55

    linegroup1:SetWidth(columnWidth + 5)

    local nameLabel = UI:Create("Heading")
    nameLabel:SetText(L["Spell Name"])
    nameLabel:SetWidth(columnWidth * 0.48)
    linegroup1:AddChild(nameLabel)

    local spacerlabel1 = UI:Create("Label")
    spacerlabel1:SetWidth(5)
    linegroup1:AddChild(spacerlabel1)

    local valueLabel = UI:Create("Heading")
    valueLabel:SetText(L["Spell ID"])
    valueLabel:SetWidth(columnWidth * 0.47)
    linegroup1:AddChild(valueLabel)

    local spacerlabel2 = UI:Create("Label")
    spacerlabel2:SetWidth(5)
    linegroup1:AddChild(spacerlabel2)

    local delLabel = UI:Create("Heading")
    delLabel:SetText(L["Actions"])
    delLabel:SetWidth(columnWidth * 0.10)
    linegroup1:AddChild(delLabel)
    contentcontainer:AddChild(linegroup1)
    for key, value in pairs(languageCache) do
        addKeyPairRow(contentcontainer, columnWidth, key, value, language)
    end
    container:AddChild(scrollcontainer)
end

cacheFrame.Height = GSEOptions.cacheHeight and GSEOptions.cacheHeight or 700
cacheFrame.Width = GSEOptions.cacheWidth and GSEOptions.cacheWidth or 700
if cacheFrame.Height < 500 then
    cacheFrame.Height = 500
    GSEOptions.cacheHeight = cacheFrame.Height
end
if cacheFrame.Width < 700 then
    cacheFrame.Width = 700
    GSEOptions.cacheWidth = cacheFrame.Width
end
cacheFrame.frame:SetClampRectInsets(10, 0, 0, 0)
cacheFrame.frame:SetHeight(cacheFrame.Height)
cacheFrame.frame:SetWidth(cacheFrame.Width)
cacheFrame:SetTitle(L["Spell Cache Editor"])
cacheFrame:SetCallback(
    "OnClose",
    function(self)
        cacheFrame:Hide()
    end
)
cacheFrame:SetLayout("List")
cacheFrame.frame:SetScript(
    "OnSizeChanged",
    function(self, width, height)
        cacheFrame.Height = height
        cacheFrame.Width = width
        if cacheFrame.Height > GetScreenHeight() then
            cacheFrame.Height = GetScreenHeight() - 10
            cacheFrame:SetHeight(cacheFrame.Height)
        end
        if cacheFrame.Height < 500 then
            cacheFrame.Height = 500
            cacheFrame:SetHeight(cacheFrame.Height)
        end
        if cacheFrame.Width < 700 then
            cacheFrame.Width = 700
            cacheFrame:SetWidth(cacheFrame.Width)
        end
        GSEOptions.cacheHeight = cacheFrame.Height
        GSEOptions.cacheWidth = cacheFrame.Width
        GSE.GUISelectCacheTab(cacheFrame.ContentContainer, "Resize", cacheFrame.SelectedTab)
        cacheFrame:DoLayout()
    end
)

local tabgrp = UI:Create("TabGroup")
tabgrp:SetLayout("Flow")
local cacheTabs = GSE.GUICreateCacheTabs()
tabgrp:SetTabs(cacheTabs)
cacheFrame.ContentContainer = tabgrp
tabgrp:SetCallback(
    "OnGroupSelected",
    function(container, event, group)
        GSE.GUISelectCacheTab(container, event, group)
    end
)

tabgrp:SetFullWidth(true)
tabgrp:SetFullHeight(true)

if cacheTabs[1] then
    tabgrp:SelectTab(cacheTabs[1].value)
end
cacheFrame:AddChild(tabgrp)

if cacheFrame and cacheFrame.frame and GSE.RegisterUIScaleFrame then
    GSE.RegisterUIScaleFrame(cacheFrame.frame)
end
end
table.insert(ns.deferred, setup)
