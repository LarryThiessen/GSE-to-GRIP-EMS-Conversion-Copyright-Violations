# CurseForge IP / Copyright Complaint — GRIP-EMS

**Submit to:** CurseForge / Overwolf copyright & IP team (support.curseforge.com → "Report copyright / IP infringement," or their designated DMCA/IP agent). Paste this into the form or attach it; attach the technical exhibit and the license.

---

## 1. Complainant (rights holder)

- **Name:** Larry A. Thiessen
- **Doing business as:** ScaryLarryGames ("SLG")
- **Email:** larry.thiessen.jr@gmail.com
- **Mailing address / phone:** __________ (required by CurseForge/DMCA)
- **Role:** Author and copyright owner of the works identified in §3.

## 2. The project complained about

- **Project:** GRIP – Enhanced Macro Sequencer ("GRIP-EMS")
- **Author (CurseForge):** Sataana (MrSataana / JesperLive)
- **CurseForge project ID:** 1489414
- **URL:** https://www.curseforge.com/wow/addons/grip-enhanced-macro-sequencer
- **Scope:** all releases; the functionality complained of is present in every release from v1.0.4 (2026-03-21) through the current v2.3.5 (2026-07-03).

## 3. My copyrighted works and their license

- **Works:** original World of Warcraft macro **sequences** I authored under the "SLG-Sequences" name — the macro step logic, step ordering, variables, and associated metadata are original creative expression fixed in a tangible medium.
- **Publication:** on my CurseForge sequence projects (URLs): __________ . Additionally, roughly 80% of my sequences are distributed **privately** to supporters/subscribers and are not published openly.
- **License:** each of my sequence projects is published with its Project License set to **"All Rights Reserved,"** whose full text is the SLG-Sequences License (attached; also at `github.com/LarryThiessen/SLG-Sequences`). It **prohibits** redistribution, re-hosting, distribution of derivative versions, and removal/alteration of author or attribution notices, and reserves all rights (clauses 2(a), 2(b), 2(d), 3, 4). The no-redistribution terms are therefore publicly posted on every project page.

## 4. The infringing conduct

GRIP-EMS contains functionality that, without my authorization and contrary to the All-Rights-Reserved license above, reproduces my copyrighted sequences and enables their redistribution. Every step is verifiable in GRIP's shipped, plain-text Lua on CurseForge (file/line citations in the attached exhibit):

1. **Reproduction.** GRIP's migration/import (`Import/LegacyMigrate.lua`) reads the user's installed GSE data — the in-memory sequence library (`GSE.Library`, force-decompressing every class) and the `GSE.lua` SavedVariables (`GSESequences`) — and **bulk-copies every sequence present**, including my sequences that a user has, into GRIP's own storage.

2. **Knowledge of origin.** GRIP records, per sequence, the **source GSE version** it imported from (`Import/LegacyImport.lua`, `importMeta.sourceVersion = ...MetaData.GSEVersion`), demonstrating awareness that the content is third-party GSE-authored.

3. **Removal of the author identifier.** On import, GRIP copies a fixed set of fields (author label, description, spec, timestamp, icon, class) and **omits the `PlatformID`** — the GSE.Tools identity that binds each of my sequences to my author account. `PlatformID` appears nowhere in GRIP's code. My license expressly forbids removal or alteration of author/attribution notices (clause 2(d)).

4. **Redistribution.** GRIP re-encodes the copied sequence into its own shareable formats (`Import/GRIPExport.lua`; `!GRIP1!`/`!EMS1!` strings) and provides **player-to-player distribution** (`Engine/Transmission.lua`, AceComm sharing). There is no license check, author-permission check, or redistribution guard in that path.

**Net effect:** my All-Rights-Reserved sequences — including private, supporter-only sequences never licensed for distribution — are reproduced into GRIP, stripped of the identifier binding them to my account, and made freely redistributable, without my permission and in violation of my posted license.

## 5. Why this infringes my rights and violates CurseForge policy

- **Copyright infringement:** unauthorized **reproduction** (17 U.S.C. § 106(1)) and **distribution** (§ 106(3)) of my original copyrighted sequences, and preparation/distribution of **derivative** re-encoded versions (§ 106(2)).
- **License violation:** my works are posted **All Rights Reserved**; GRIP's reproduction and redistribution breach SLG-Sequences License clauses **2(a)** (no redistribution/re-hosting), **2(b)** (no distribution of derivative versions), **2(d)** (no removal/alteration of author or attribution notices), and **3** (subscriber/paid content may not be shared).
- **CurseForge IP policy:** CurseForge's project-moderation policy prohibits projects that infringe the intellectual property rights of others. GRIP provides, as a core feature, the unauthorized reproduction and redistribution of other creators' All-Rights-Reserved content.

*(A supporting statutory theory — removal of copyright-management information under 17 U.S.C. § 1202, based on the `PlatformID` omission in §4(3) — is set out in a separate legal memo and is not necessary to this complaint.)*

## 6. Requested remedy

Under CurseForge's IP/moderation policy, I request that CurseForge require GRIP-EMS to, at minimum:

1. **Cease reproducing and enabling redistribution of third-party All-Rights-Reserved sequences** without the author's consent — specifically, gate or remove the GSE-import and re-export/share functionality so that sequences imported from GSE cannot be re-exported or shared unless the original author has permitted redistribution, and cease removing the author-bound `PlatformID` identifier from imported content; or
2. Failing that, **removal of the infringing functionality (or the project)** under CurseForge's IP-infringement policy.

## 7. Required statements

- I have a good-faith belief that the use of my copyrighted works in the manner described is not authorized by me, my agent, or the law.
- The information in this notification is accurate, and **under penalty of perjury**, I am the owner, or authorized to act on behalf of the owner, of the copyright(s) that are allegedly infringed.
- I request that CurseForge take action in accordance with its policies and applicable law.

**Signature:** Larry A. Thiessen ("ScaryLarryGames")
**Date:** __________

## 8. Scope (what is and isn't claimed)

- This complaint concerns GRIP's **handling of sequence content authored by third parties** — its unauthorized reproduction and redistribution of my licensed sequences, and its removal of the author-bound `PlatformID` from that content. It is **not** a claim that GRIP's own program source code was copied from another addon.
- A user converting **their own installed copy** of a sequence for **personal use** is not the target. The conduct complained of is (a) reproducing **other creators'** licensed content and (b) enabling its **redistribution** with the author identifier removed.

## 9. Attachments

- `grip-cmi-evidence-exhibit.md` — code-cited technical exhibit (import→export path with file/line citations; per-version confirmation across all releases; SLG license).
- SLG-Sequences License (full text; also in the exhibit, Appendix B).
- (Optional) `grip-1202-cmi-analysis.md` — supporting §1202 legal memo.
