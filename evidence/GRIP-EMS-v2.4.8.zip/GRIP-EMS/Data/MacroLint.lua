-- GRIP-EMS: MacroLint
-- Created: 2026-05-11
-- Updated: 2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.

-- GRIP-EMS: MacroLint
-- Static-lint pass for combat-blocked slash commands in macro bodies.
-- Mirrors the SpellValidator pattern (per-step extraction + recursive node
-- walk). Surfaces a warn-level finding when a macro line's leading slash
-- command appears in the BLOCKED list. False positives erode trust faster
-- than missed positives -- precision over coverage.

local ADDON_NAME, GRIPEMS = ...

GRIPEMS.MacroLint = {}
local ML = GRIPEMS.MacroLint

---------------------------------------------------------------------------
-- BLOCKED COMMAND TABLE
---------------------------------------------------------------------------
-- Canonical source of truth:
--   Hub/GRIP/Hub/Projects/EMS/Research/Combat_Blocked_Commands_2026-05-10.md
-- AVAV cross-checks this table against the Research doc on every Phase H2
-- audit cycle. If Blizzard adds or removes restrictions, update the doc
-- FIRST then mirror here.
--
-- Categories:
--   "hard"    -- engine refuses outright in combat (gear, action-bar swap)
--   "partial" -- conditionally blocked under specific game state
local BLOCKED_COMMANDS = {
    ["/equip"] = { category = "hard", localeKey = "GEMS_IF_LINT_COMBAT_BLOCKED_HARD" },
    ["/equipset"] = { category = "hard", localeKey = "GEMS_IF_LINT_COMBAT_BLOCKED_HARD" },
    ["/equipslot"] = { category = "hard", localeKey = "GEMS_IF_LINT_COMBAT_BLOCKED_HARD" },
    ["/changeactionbar"] = { category = "hard", localeKey = "GEMS_IF_LINT_COMBAT_BLOCKED_HARD" },
    ["/swapactionbar"] = { category = "hard", localeKey = "GEMS_IF_LINT_COMBAT_BLOCKED_HARD" },
    ["/cancelaura"] = { category = "partial", localeKey = "GEMS_IF_LINT_COMBAT_BLOCKED_PARTIAL" },
    ["/focus"] = { category = "partial", localeKey = "GEMS_IF_LINT_COMBAT_BLOCKED_PARTIAL" },
    ["/leavevehicle"] = { category = "partial", localeKey = "GEMS_IF_LINT_COMBAT_BLOCKED_PARTIAL" },
    ["/click"] = { category = "partial", localeKey = "GEMS_IF_LINT_COMBAT_BLOCKED_PARTIAL" },
}

---------------------------------------------------------------------------
-- LINE-LEVEL EXTRACTION
---------------------------------------------------------------------------

--- Extract the leading slash command from a single macro line.
--- Strips leading whitespace, skips blank lines and `#`-prefixed comment
--- lines per WoW macro convention. Returns the lowercased "/<word>" or nil
--- when the line is blank, a comment, or does not start with a slash.
--- @param line string Single macro line (no embedded newlines)
--- @return string|nil Lowercased command word or nil
function ML.ExtractFirstCommand(line)
    if type(line) ~= "string" then
        return nil
    end
    local stripped = line:match("^%s*(.-)%s*$")
    if not stripped or stripped == "" then
        return nil
    end
    if stripped:sub(1, 1) == "#" then
        return nil
    end
    local word = stripped:match("^(/%a+)")
    if not word then
        return nil
    end
    return word:lower()
end

---------------------------------------------------------------------------
-- MACRO-LEVEL LINT
---------------------------------------------------------------------------

--- Scan a multi-line macro body for combat-blocked slash commands.
--- Each non-blank, non-comment line is checked independently. Conditional
--- brackets do NOT change the leading command word: `/equipset [combat]`
--- still flags. Case-insensitive match.
--- @param macrotext string Macro body (may contain \n)
--- @return string|nil severity "warn" if any line flagged, nil otherwise
--- @return table findings Array of { lineNumber, cmd, category, localeKey }
function ML.LintMacro(macrotext)
    local findings = {}
    if type(macrotext) ~= "string" or macrotext == "" then
        return nil, findings
    end

    local lineNumber = 0
    for line in (macrotext .. "\n"):gmatch("([^\n]*)\n") do
        lineNumber = lineNumber + 1
        local cmd = ML.ExtractFirstCommand(line)
        if cmd then
            local entry = BLOCKED_COMMANDS[cmd]
            if entry then
                findings[#findings + 1] = {
                    lineNumber = lineNumber,
                    cmd = cmd,
                    category = entry.category,
                    localeKey = entry.localeKey,
                }
            end
        end
    end

    if #findings > 0 then
        return "warn", findings
    end
    return nil, findings
end

---------------------------------------------------------------------------
-- NODE RECURSIVE WALK
---------------------------------------------------------------------------

--- Walk a node's descendants and collect every combat-blocked finding.
--- Signature mirrors SpellValidator:NodeHasInvalidSpells. ACTION nodes call
--- LintMacro on node.macro. LOOP / IF / EMBED recurse. IF walks
--- children[1] (true branch) and children[2] (false branch). EMBED
--- resolves the sequence name via the visited-guard pattern.
--- @param node table Action tree node
--- @param visited table|nil Recursion guard for EMBED cycle detection
--- @param collectAll boolean|nil If true, walk entire subtree; if false/nil,
---        short-circuit on first finding (badge path).
--- @return string|nil severity "warn" if any finding, nil otherwise
--- @return table findings Aggregated findings from descendants
function ML:NodeHasBlockedCommands(node, visited, collectAll)
    if not node or type(node) ~= "table" then
        return nil, {}
    end
    local defs = GRIPEMS.Defaults
    if not defs then
        return nil, {}
    end
    visited = visited or {}

    local worst = nil
    local findings = {}
    local seen = {}
    local function addFinding(f)
        local k = tostring(f.cmd) .. ":" .. tostring(f.category)
        if not seen[k] then
            seen[k] = true
            findings[#findings + 1] = f
        end
    end

    local function walk(n)
        if not collectAll and worst == "warn" then
            return
        end
        if not n or type(n) ~= "table" then
            return
        end

        if n.type == defs.ACTION_TYPE_ACTION then
            local macro = n.macro or ""
            if macro ~= "" then
                local resolved = macro
                local eng = GRIPEMS.Engine
                if eng and eng.SubstituteVariables then
                    local ok, out = pcall(eng.SubstituteVariables, eng, macro)
                    if ok and type(out) == "string" then
                        resolved = out
                    end
                end
                local sev, lineFindings = ML.LintMacro(resolved)
                if sev == "warn" then
                    worst = "warn"
                    for _, f in ipairs(lineFindings) do
                        addFinding(f)
                        if not collectAll then
                            return
                        end
                    end
                end
            end
            return
        end

        if n.type == defs.ACTION_TYPE_EMBED then
            local seqName = n.sequence
            if not seqName or seqName == "" then
                return
            end
            if visited[seqName] then
                return
            end
            if (visited._depth or 0) >= 10 then
                return
            end
            visited[seqName] = true
            visited._depth = (visited._depth or 0) + 1
            local eng = GRIPEMS.Engine
            local entry = eng and eng.sequences and eng.sequences[seqName]
            if entry and entry.data and eng.GetActiveVersion then
                local ver = eng:GetActiveVersion(entry.data)
                if ver and ver.actions then
                    for _, child in ipairs(ver.actions) do
                        walk(child)
                        if not collectAll and worst == "warn" then
                            visited._depth = visited._depth - 1
                            return
                        end
                    end
                elseif ver and ver.steps then
                    for _, macroText in ipairs(ver.steps) do
                        walk({ type = defs.ACTION_TYPE_ACTION, macro = macroText })
                        if not collectAll and worst == "warn" then
                            visited._depth = visited._depth - 1
                            return
                        end
                    end
                end
            end
            visited._depth = visited._depth - 1
            return
        end

        if n.children and type(n.children) == "table" then
            if n.type == defs.ACTION_TYPE_IF then
                local trueBranch = n.children[1]
                if type(trueBranch) == "table" then
                    for _, child in ipairs(trueBranch) do
                        walk(child)
                        if not collectAll and worst == "warn" then
                            return
                        end
                    end
                end
                local falseBranch = n.children[2]
                if type(falseBranch) == "table" then
                    for _, child in ipairs(falseBranch) do
                        walk(child)
                        if not collectAll and worst == "warn" then
                            return
                        end
                    end
                end
            else
                for _, child in ipairs(n.children) do
                    walk(child)
                    if not collectAll and worst == "warn" then
                        return
                    end
                end
            end
        end
    end

    walk(node)
    return worst, findings
end
