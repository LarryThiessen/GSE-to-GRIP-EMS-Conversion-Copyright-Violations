-- GRIP-EMS: PublicAPI
-- Created: 2026-06-23
-- Updated: 2026-08-17
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)

-- Frozen, versioned public plugin API (GRIPEMS.API): handshake, listen-only events, read-only data, sequence registration.

local ADDON_NAME, GRIPEMS = ...

-- Private implementation table. Every field and method lives here; the public
-- GRIPEMS.API is a read-only proxy that reads through to impl (see the freeze
-- block at the bottom of the file). Methods take a leading ignored self param
-- because callers use GRIPEMS.API:Method(...), so self is the frozen proxy.
local impl = {}

-- ---------------------------------------------------------------------------
-- Tier 0 -- discovery / handshake
-- ---------------------------------------------------------------------------

-- Integer API contract version. Bumped on any addition to this surface, breaking or not.
-- A method added mid-version still needs a presence check: v2.3.7 shipped GetAuthoredSteps under 3.
impl.API_VERSION = 4

-- Running EMS version string, read once at file load (e.g. "2.1.29").
impl.EMS_VERSION = GRIPEMS.version

--- Check that the running API is new enough for a plugin.
--- @param n number Minimum API_VERSION the caller requires
--- @return boolean ok True when the running API satisfies the requirement
--- @return string|nil reason Failure reason when ok is false
function impl.RequireVersion(_, n)
    if type(n) ~= "number" then
        return false, "RequireVersion: required version must be a number"
    end
    if n <= impl.API_VERSION then
        return true
    end
    return false, string.format("GRIP-EMS API v%d is running; plugin requires v%d", impl.API_VERSION, n)
end

-- Capability ids this build supports. Never handed out directly -- GetCapabilities
-- copies it so a caller mutating one result cannot affect the next.
local CAPABILITIES = {
    "events",
    "data",
    "sequences",
    "ui",
    "preview",
    "variables",
    "conditions",
    "stepfunctions",
    "plugins",
    "authoring",
    "panels",
    "views",
    "settings",
    "cvars",
    "stepdata",
    "macro",
    "slash",
    "authoredsteps",
}

--- Capability ids this build supports. Returns a fresh array each call.
--- @return table Array of capability-id strings
function impl.GetCapabilities(_)
    local out = {}
    for i = 1, #CAPABILITIES do
        out[i] = CAPABILITIES[i]
    end
    return out
end

--- Register a plugin and receive its frozen handle. After the handshake
--- (RequireVersion / GetCapabilities) a plugin registers here. Thin pass-through
--- to the core plugin registrar (Core/PluginAPI.lua), which builds the
--- ownership-tagged handle, creates the per-plugin teardown journal, persists the
--- enable state, and runs the enable lifecycle. The handle carries the plugin id
--- in a closure -- every contribution made through it is owned by this id and is
--- reverted when the plugin is disabled.
--- @param id string Plugin id (the namespace for everything it contributes)
--- @param meta table|nil Optional { name, version, OnEnable, OnDisable }
--- @return table|nil handle Frozen plugin handle, or nil on rejection
--- @return string|nil reason Failure reason when handle is nil
function impl.RegisterPlugin(_, id, meta)
    return GRIPEMS.RegisterPluginImpl(id, meta)
end

-- ---------------------------------------------------------------------------
-- Tier 1 -- events (listen-only wrapper over the CallbackHandler bus)
-- ---------------------------------------------------------------------------

-- Public event catalog. Plugins may listen to these; they may not fire them
-- (no public Fire) -- EMS fires, plugins react.
local PUBLIC_EVENTS = {
    "SEQUENCE_CREATED",
    "SEQUENCE_DELETED",
    "SEQUENCE_IMPORTED",
    "SEQUENCE_STEP_ADVANCED",
    "SETTING_CHANGED",
    "PLUGIN_REGISTERED",
    "PLUGIN_SEQUENCES_LOADED",
    -- Tier 1 core reads (Phase B): sequence/keybind/context/loadout change signals
    -- a plugin observes. All four already fire in-core; Phase B only adds them to
    -- this listen-only catalog. SEQUENCE_UPDATED fires in the Engine sequence-save
    -- path, KEYBIND_CHANGED in the KeybindManager, CONTEXT_CHANGED in
    -- Engine:UpdateContext, and LOADOUT_CHANGED in Engine:UpdateLoadout. All carry
    -- scalar payloads.
    "SEQUENCE_UPDATED",
    "KEYBIND_CHANGED",
    "CONTEXT_CHANGED",
    "LOADOUT_CHANGED",
    -- Tier 3 UI surface (Phase 1b): host-frame + layout-provider lifecycle and
    -- the rotation-preview signals plugins may observe (EMS fires, plugins react).
    "GEMS_UI_READY",
    "GEMS_UI_LAYOUT_APPLY",
    "GEMS_UI_NAV_CHANGED",
    "GEMS_EDITOR_TAB_CHANGED",
    "GEMS_SEQUENCE_SELECTED",
    "GEMS_PREVIEW_MODE_CHANGED",
    "GEMS_PREVIEW_UPDATE",
}

local PUBLIC_EVENT_SET = {}
for i = 1, #PUBLIC_EVENTS do
    PUBLIC_EVENT_SET[PUBLIC_EVENTS[i]] = true
end

-- Opaque-handle registry: token -> { event = <eventname> } for every live
-- subscription handed out by On(). The token is the CallbackHandler dedup key.
local subscriptions = {}
local tokenSeq = 0

-- Recursive deep copy. Tier 1 event payloads handed to plugins are
-- read-only snapshots (design: payloads are read-only snapshots), so a
-- plugin handler mutating a received table cannot reach engine-owned
-- state. Scalars pass through; nested tables are cloned.
local function DeepCopy(value)
    if type(value) ~= "table" then
        return value
    end
    local copy = {}
    for k, v in pairs(value) do
        copy[k] = DeepCopy(v)
    end
    return copy
end

--- List the public event names a plugin may subscribe to.
--- @return table Fresh array of event-name strings
function impl.ListEvents(_)
    local out = {}
    for i = 1, #PUBLIC_EVENTS do
        out[i] = PUBLIC_EVENTS[i]
    end
    return out
end

--- Subscribe to a public event. The handler runs inside pcall, so a broken
--- plugin handler degrades to "its feature does not work" and never crashes the
--- firing site. The handler receives the event payload only (not the name).
--- @param event string An event name from ListEvents()
--- @param handler function Listener invoked with the event payload
--- @return string|boolean handle Opaque handle on success, or false on rejection
--- @return string|nil reason Failure reason when the first return is false
function impl.On(_, event, handler)
    if not PUBLIC_EVENT_SET[event] then
        return false, "On: unknown event '" .. tostring(event) .. "'"
    end
    if type(handler) ~= "function" then
        return false, "On: handler must be a function"
    end
    tokenSeq = tokenSeq + 1
    local token = "GRIPEMS_API_sub_" .. tokenSeq
    -- CallbackHandler dispatches function callbacks as fn(eventname, ...payload);
    -- drop the leading event name and forward only the payload to the plugin.
    local function wrapper(_, ...)
        -- Hand the plugin read-only snapshots: copy every table-valued
        -- payload arg so a handler cannot reach engine state by holding a
        -- reference (SEQUENCE_CREATED forwards live Engine sequence data).
        local n = select("#", ...)
        local args = { ... }
        for i = 1, n do
            if type(args[i]) == "table" then
                args[i] = DeepCopy(args[i])
            end
        end
        local ok, err = pcall(handler, unpack(args, 1, n))
        if not ok then
            GRIPEMS:Debug("plugin On(%s) handler error: %s", event, tostring(err))
        end
    end
    GRIPEMS.RegisterCallback(token, event, wrapper)
    subscriptions[token] = { event = event }
    return token
end

--- Cancel a subscription created by On(). An unknown handle is a no-op.
--- @param handle string The token returned by On()
function impl.Off(_, handle)
    local sub = subscriptions[handle]
    if not sub then
        return
    end
    GRIPEMS.UnregisterCallback(handle, sub.event)
    subscriptions[handle] = nil
end

-- ---------------------------------------------------------------------------
-- Tier 2 -- read-only data accessors (copies / scalars only, never setters)
-- ---------------------------------------------------------------------------

--- Snapshot of every registered sequence (active and dormant), name + summary.
--- The engine also returns dormant sequences (button = nil, registered but not
--- activated). The engine already returns a freshly built sorted list, so it is
--- safe to hand back directly.
--- @return table Array of sequence summary tables
function impl.GetSequenceList(_)
    return GRIPEMS.Engine:GetSequenceList()
end

--- Read-only metadata for one sequence, or nil when it does not exist. The
--- returned table is fresh -- mutating it never reaches stored sequence data.
--- @param name string Sequence name
--- @return table|nil Metadata snapshot, or nil if the sequence is unknown
function impl.GetSequenceInfo(_, name)
    local Engine = GRIPEMS.Engine
    local entry = Engine.sequences[name]
    if not entry then
        return nil
    end
    local data = entry.data
    local versions = (data and type(data.versions) == "table" and data.versions) or {}
    local activeVersion = Engine:GetActiveVersion(data)
    local activeVersionIndex
    for i, version in ipairs(versions) do
        if version == activeVersion then
            activeVersionIndex = i
            break
        end
    end
    local activeStepCount = 0
    if activeVersion and activeVersion.steps then
        activeStepCount = #activeVersion.steps
    end
    -- Keybind: call-time lookup through the KeybindManager when the module and
    -- method exist (nil-safe in a headless or pre-build context). A scalar key
    -- string or nil; nothing stored is aliased.
    local keybind
    local KM = GRIPEMS.KeybindManager
    if KM and KM.GetKeybind then
        keybind = KM:GetKeybind(name)
    end
    -- Variable dependencies: a FRESH, sorted array of dependency name strings.
    -- ResolveVariableDeps returns a set (name -> true); copy its keys into a new
    -- array so the snapshot aliases nothing the resolver built. Empty array when
    -- nothing resolves or the export module is absent -- never the live set.
    local variableDeps = {}
    local GE = GRIPEMS.GRIPExport
    if GE and GE.ResolveVariableDeps then
        local depSet = GE.ResolveVariableDeps({ name })
        if type(depSet) == "table" then
            for depName in pairs(depSet) do
                variableDeps[#variableDeps + 1] = depName
            end
            table.sort(variableDeps)
        end
    end
    -- Scalars are copied by value (stepFunction is a string id, never a strategy
    -- object) and variableDeps is a freshly built array, so this snapshot aliases
    -- nothing stored: mutating the returned table never reaches sequence data.
    return {
        name = name,
        stepFunction = activeVersion and activeVersion.stepFunction or nil,
        versionCount = #versions,
        defaultVersion = data and data.defaultVersion or nil,
        activeVersionIndex = activeVersionIndex,
        activeStepCount = activeStepCount,
        classID = data and data.classID or nil,
        author = data and data.author or nil,
        description = data and data.description or nil,
        help = data and data.help or nil,
        helplink = data and data.helplink or nil,
        changelog = data and data.changelog or nil,
        talentString = data and data.talentString or nil,
        url = data and data.url or nil,
        privacyMode = data and data.privacyMode or nil,
        version = data and data.version or nil,
        specID = data and data.specID or nil,
        createdAt = data and data.createdAt or nil,
        updatedAt = data and data.updatedAt or nil,
        disabled = (data and data.disabled) and true or false,
        contextVersionCount = #versions,
        keybind = keybind,
        variableDeps = variableDeps,
    }
end

--- Read-only per-step spell data for a sequence's ACTIVE version, in the same execution
--- order the secure button advances through (so a plugin can map a SEQUENCE_STEP_ADVANCED
--- step index straight onto this array). Returns a fresh array of
--- { index, spellID, spellName, icon } scalar snapshots, or nil when the sequence does
--- not exist. A step that casts no resolvable spell still gets an entry (nil spell
--- fields) so the index stays aligned with the button. All values are public scalars.
--- @param name string Sequence name
--- @return table|nil Array of per-step { index, spellID, spellName, icon }, or nil
function impl.GetSequenceSteps(_, name)
    local Engine = GRIPEMS.Engine
    local entry = Engine and Engine.sequences and Engine.sequences[name]
    if not entry then
        return nil
    end
    return Engine:GetActiveVersionStepList(entry.data)
end

--- Read-only per-step spell data for a sequence's ACTIVE version in AUTHORED base
--- order -- the order the user actually wrote, before the step function expands it
--- and before interleave copies are inserted. Returns a fresh array of
--- { index, spellID, spellName, icon } scalar snapshots, or nil when the sequence
--- does not exist. Pair this with nothing: it is NOT the domain currentStep or
--- SEQUENCE_STEP_ADVANCED index live in -- use GetSequenceSteps for those.
--- Limits: Loops are unrolled and IF branches flattened, so a Loop with repeat 3
--- contributes its children three times. The version's repeatCount is NOT applied.
--- @param name string Sequence name
--- @return table|nil Array of per-step { index, spellID, spellName, icon }, or nil
function impl.GetAuthoredSteps(_, name)
    local Engine = GRIPEMS.Engine
    local entry = Engine and Engine.sequences and Engine.sequences[name]
    if not entry then
        return nil
    end
    return Engine:GetAuthoredStepList(entry.data)
end

--- Read-only macro slot index for a sequence's action-bar macro stub, or nil when no
--- stub exists yet. The index is EMS's tracked slot (valid for the session; rebuilt from
--- the live macro list on login). A plugin pairs this with handle:EnsureSequenceMacro to
--- create the stub, then PickupMacro(index) to drag it onto a bar. Pure read -- no
--- creation, no journaling.
--- @param name string Sequence name
--- @return number|nil Macro slot index, or nil when no stub exists
function impl.GetSequenceMacroIndex(_, name)
    local MM = GRIPEMS.MacroManager
    return MM and MM.stubs and MM.stubs[name] or nil
end

--- The name of the sequence the engine most recently drove, or nil when none has been driven
--- yet. Read-only scalar -- there is no setter. Two things a plugin must not assume: the name
--- is NEVER cleared when a sequence stops, so a non-nil return means "most recently driven"
--- and never "currently running"; and hold mode writes the same field, so the value tracks
--- hold-mode activation as well as a secure-button click -- which is why this is not called
--- GetClickedSequence.
--- @return string|nil Name of the most recently driven sequence, or nil
function impl.GetActiveSequence(_)
    local Engine = GRIPEMS.Engine
    return Engine and Engine._lastClickedSequence or nil
end

--- The detected content context (string enum, e.g. "none"). Read-only.
--- @return string Current context key
function impl.GetCurrentContext(_)
    return GRIPEMS.Engine.currentContext
end

-- Settings a plugin may read. Anything outside this set returns nil. There is
-- no public setter -- plugins read settings, they never write them. Keep this
-- allowlist to scalar-valued keys (string/number/boolean): GetSetting hands the
-- value back as-is, so a table-valued setting would expose a live reference into
-- the profile. Both current entries are scalar (debug boolean; uiLayout a
-- "classic"|"modern" string enum stored since Phase 1b).
local SETTING_ALLOWLIST = { uiLayout = true, debug = true }

--- Read an allowlisted setting value. Non-allowlisted keys return nil. uiLayout
--- has no stored value before Phase 1b and simply returns nil without error.
--- @param key string Setting key
--- @return any Setting value, or nil when the key is not allowlisted
function impl.GetSetting(_, key)
    if not SETTING_ALLOWLIST[key] then
        return nil
    end
    return GRIPEMS.Settings:Get(key)
end

--- The list of registered plugins. The registry already returns a fresh list.
--- @return table Array of { name, version, loaded, sequenceCount }
function impl.GetRegisteredPlugins(_)
    return GRIPEMS.GetRegisteredAddons()
end

-- ---------------------------------------------------------------------------
-- Tier 4 (partial) -- sequence registration re-export
-- ---------------------------------------------------------------------------

--- Register a plugin's sequences. Thin pass-through to the existing validated
--- registrar, which validates inputs, namespaces by plugin id, and fires
--- PLUGIN_REGISTERED. The bare GRIPEMS.RegisterAddon stays for back-compat.
--- @param name string Plugin name
--- @param version string Plugin version
--- @param seqNames table Array of sequence-name strings
--- @param seqTable table Sequences keyed by name
--- @return boolean success
function impl.RegisterSequences(_, name, version, seqNames, seqTable)
    return GRIPEMS.RegisterAddon(name, version, seqNames, seqTable)
end

-- ---------------------------------------------------------------------------
-- Tier 4 -- variable providers (Plugin API Phase 2a)
--
-- Read-only value sources for the ~name~ variable system. A provider is
-- consulted by Engine:SubstituteVariables ONLY after user variables and gear
-- variables miss, so a plugin never shadows a user's own variable. The registry
-- is an ordered array: registration order is resolution order, and the first
-- provider to return a plain scalar wins. Shared with the engine through
-- GRIPEMS._variableProviders + GRIPEMS:ResolvePluginVariable below -- those are
-- NOT on the frozen proxy (same core-to-core split as the layout registry).
-- ---------------------------------------------------------------------------

-- id-ordered array of validated provider tables.
local variableProviders = {}

-- A plugin variable value is substituted into macrotext, which can flow into the
-- secure execution environment. Only a plain, non-secret scalar is safe there. A
-- table, function, or userdata is caught by the type allowlist. A 12.0 secret-
-- tagged value is NOT -- it reports a normal scalar type via type() (a secret
-- number is type()=="number"), so issecretvalue is the only reliable detector.
-- nil-safe: the global is absent on pre-12.0 clients and in the headless harness.
-- Mirrors the Data/SpellCache.lua IsResolvableSpellID secret guard.
local function IsPlainScalar(value)
    local t = type(value)
    if t ~= "string" and t ~= "number" and t ~= "boolean" then
        return false
    end
    if issecretvalue and issecretvalue(value) then
        return false
    end
    return true
end

-- Validate a variable provider against the Tier 4 contract. Required: id (a
-- string equal to the registry id), name (a string), Resolve (a function). The
-- optional OnRegister must be a function when present.
local function ValidateVariableProvider(id, spec)
    if type(id) ~= "string" then
        return false, "RegisterVariableProvider: id must be a string"
    end
    if type(spec) ~= "table" then
        return false, "RegisterVariableProvider: provider must be a table"
    end
    if type(spec.id) ~= "string" or spec.id ~= id then
        return false, "RegisterVariableProvider: provider.id must be a string equal to the registry id"
    end
    if type(spec.name) ~= "string" then
        return false, "RegisterVariableProvider: provider.name must be a string"
    end
    if type(spec.Resolve) ~= "function" then
        return false, "RegisterVariableProvider: provider.Resolve must be a function"
    end
    if spec.OnRegister ~= nil and type(spec.OnRegister) ~= "function" then
        return false, "RegisterVariableProvider: OnRegister must be a function when present"
    end
    return true
end

--- Register a read-only variable provider. Validates the Tier 4 contract, rejects
--- a duplicate id (never overwrites), appends to the ordered registry, and runs
--- the optional OnRegister inside pcall.
--- @param id string Registry id; must equal spec.id
--- @param spec table Provider table (id, name, Resolve, optional OnRegister)
--- @return boolean ok True on success
--- @return string|nil reason Failure reason when ok is false
function impl.RegisterVariableProvider(_, id, spec)
    local ok, reason = ValidateVariableProvider(id, spec)
    if not ok then
        return false, reason
    end
    for i = 1, #variableProviders do
        if variableProviders[i].id == id then
            return false, "RegisterVariableProvider: id '" .. id .. "' is already registered"
        end
    end
    variableProviders[#variableProviders + 1] = spec
    if spec.OnRegister then
        pcall(spec.OnRegister, spec)
    end
    return true
end

-- Engine-internal channel (NOT on the frozen proxy). Engine:SubstituteVariables
-- calls ResolvePluginVariable on a user+gear miss.
GRIPEMS._variableProviders = variableProviders

--- Resolve a ~name~ through the registered variable providers, in registration
--- order. Each provider's Resolve runs in pcall; only a plain scalar return is
--- accepted (a table / function / userdata / secret return is rejected so nothing
--- taint-sensitive can reach macrotext). Returns the first accepted scalar, or nil
--- when no provider resolves the name.
--- @param varName string The variable name found inside ~...~
--- @return string|number|boolean|nil The resolved scalar, or nil if unresolved
function GRIPEMS:ResolvePluginVariable(varName)
    for i = 1, #variableProviders do
        local provider = variableProviders[i]
        local ok, value = pcall(provider.Resolve, provider, varName)
        if ok and value ~= nil then
            if IsPlainScalar(value) then
                return value
            end
            GRIPEMS:Debug(
                "plugin variable provider '%s' returned a non-scalar for '%s'; ignored",
                tostring(provider.id),
                tostring(varName)
            )
        end
    end
    return nil
end

-- ---------------------------------------------------------------------------
-- Tier 4 -- condition registry (Plugin API Phase 2b)
--
-- A condition is a plugin-supplied boolean predicate usable inside a user
-- variable body at runtime, e.g.:
--     GRIPEMS.API:EvaluateCondition("acme_lowmana") and "Spell A" or "Spell B"
-- Conditions are runtime-only: they cannot map to a native WoW macro conditional
-- (a plugin cannot invent one), so MacroConditionalBaker rejects the
-- EvaluateCondition shape and the variable falls through to runtime resolution.
-- EvaluateCondition runs the predicate in pcall and returns a CLEAN boolean -- a
-- thrown error (e.g. a secret comparison), a nil/non-boolean result, or a
-- secret-tagged result all collapse to false, so nothing taint-sensitive leaves
-- this surface. The registry is a dict keyed by id (duplicate id rejected, never
-- overwritten); GRIPEMS._conditions shares it with the core (NOT on the frozen
-- proxy), the same split as the variable-provider and layout registries.
-- ---------------------------------------------------------------------------

-- id -> validated condition spec.
local conditions = {}

-- Validate a condition against the Tier 4 contract. Required: id (a string equal
-- to the registry id), name (a string), Evaluate (a function). The optional
-- OnRegister must be a function when present.
local function ValidateCondition(id, spec)
    if type(id) ~= "string" then
        return false, "RegisterCondition: id must be a string"
    end
    if type(spec) ~= "table" then
        return false, "RegisterCondition: condition must be a table"
    end
    if type(spec.id) ~= "string" or spec.id ~= id then
        return false, "RegisterCondition: condition.id must be a string equal to the registry id"
    end
    if type(spec.name) ~= "string" then
        return false, "RegisterCondition: condition.name must be a string"
    end
    if type(spec.Evaluate) ~= "function" then
        return false, "RegisterCondition: condition.Evaluate must be a function"
    end
    if spec.OnRegister ~= nil and type(spec.OnRegister) ~= "function" then
        return false, "RegisterCondition: OnRegister must be a function when present"
    end
    return true
end

--- Register a plugin condition (a named boolean predicate). Validates the Tier 4
--- contract, rejects a duplicate id (never overwrites), stores it, and runs the
--- optional OnRegister inside pcall.
--- @param id string Registry id; must equal spec.id
--- @param spec table Condition table (id, name, Evaluate, optional OnRegister)
--- @return boolean ok True on success
--- @return string|nil reason Failure reason when ok is false
function impl.RegisterCondition(_, id, spec)
    local ok, reason = ValidateCondition(id, spec)
    if not ok then
        return false, reason
    end
    if conditions[id] then
        return false, "RegisterCondition: id '" .. id .. "' is already registered"
    end
    conditions[id] = spec
    if spec.OnRegister then
        pcall(spec.OnRegister, spec)
    end
    return true
end

--- Evaluate a registered condition by id and return a CLEAN boolean. An unknown
--- id, a predicate that errors (e.g. a secret comparison throws), a nil or
--- non-boolean result, or a secret-tagged result all return false -- so a caller
--- (a user variable body) always gets a safe boolean and nothing taint-sensitive
--- escapes. The predicate runs in pcall. issecretvalue is nil-safe (absent on
--- pre-12.0 clients and in the headless harness).
--- @param id string A registered condition id
--- @return boolean result True only when the predicate yields a truthy, non-secret value
function impl.EvaluateCondition(_, id)
    local spec = conditions[id]
    if not spec then
        return false
    end
    local ok, result = pcall(spec.Evaluate, spec)
    if not ok then
        return false
    end
    if issecretvalue and issecretvalue(result) then
        return false
    end
    return result and true or false
end

-- Engine-internal channel (NOT on the frozen proxy): shares the registry with the
-- core and the test harness, the same pattern as GRIPEMS._variableProviders.
GRIPEMS._conditions = conditions

-- ---------------------------------------------------------------------------
-- Tier 4 -- step-function registry (Plugin API Phase 2c)
--
-- A step function is a pure step-ORDERING strategy (like the built-in
-- Priority weighting). The plugin supplies Expand(self, resolvedStepTexts) ->
-- array of macrotext strings; EMS owns the secure WrapScript click body
-- (always the Sequential round-robin body) and wraps each returned string
-- into an attribute table itself, so a plugin NEVER supplies secure code and
-- can never inject an attribute beyond type = macro + macrotext. The registry
-- lives in GRIPEMS.StepFunctions (the engine module the compiler already
-- consults via SF:Get / SF:IsExpander); this is a thin frozen-proxy wrapper
-- that delegates there in pcall. A registered step function becomes active
-- when a plugin registers a sequence whose version.stepFunction is the id.
-- ---------------------------------------------------------------------------

--- Register a plugin step function (a named, pure step-ordering strategy).
--- Delegates to GRIPEMS.StepFunctions:RegisterStepFunction, which validates
--- the spec, rejects a duplicate id or a built-in collision, and reuses the
--- EMS Sequential secure body. The plugin never supplies secure code.
--- @param id string Registry id; must equal spec.id and not collide with a built-in
--- @param spec table { id, name, Expand(self, resolvedStepTexts)->{string,...}, OnRegister? }
--- @return boolean ok
--- @return string|nil reason
function impl.RegisterStepFunction(_, id, spec)
    local SF = GRIPEMS.StepFunctions
    if not SF or not SF.RegisterStepFunction then
        return false, "RegisterStepFunction: step-function module unavailable"
    end
    local ok, regOk, reason = pcall(SF.RegisterStepFunction, SF, id, spec)
    if not ok then
        return false, "RegisterStepFunction: registration error"
    end
    if not regOk then
        return false, reason or "RegisterStepFunction: rejected"
    end
    return true
end

-- ---------------------------------------------------------------------------
-- Tier 3 -- UI host frames + layout-provider registry
--
-- Plugins reach this surface through GRIPEMS.API.UI, a frozen sub-proxy with
-- the same read-only contract as the top-level API. The core reaches the same
-- registry through the engine-internal channel below (GRIPEMS._layoutProviders
-- + GRIPEMS:ResolveActiveLayoutProvider) -- those are NOT on the frozen proxy.
-- A layout provider owns how the seven host frames on GRIPEMS_MainFrame are
-- positioned; the in-core "classic" provider (UI/MainFrame.lua) reproduces
-- today's two-panel UI byte-for-byte.
-- ---------------------------------------------------------------------------

-- id -> validated provider table. Shared with the core via GRIPEMS._layoutProviders.
local layoutProviders = {}

-- ---------------------------------------------------------------------------
-- Tier 3 -- mountable built-in panels (Plugin API Phase C)
--
-- A modern layout provider can pull a built-in panel's CONTENT out of the
-- classic two-panel chrome and mount it into one of its own host frames. Only
-- NON-SECURE panel content is reparentable here -- the single secure button
-- (the Simplified Mode Run button) is root-parented to GRIPEMS_MainFrame and
-- never lives under a mountable panel. Each panel module registers its content
-- root through the engine-internal GRIPEMS:RegisterMountablePanel below (NOT on
-- the frozen proxy, same core-to-core split as the layout registry); a plugin
-- mounts it through GRIPEMS.API.UI:MountPanel. Classic never calls MountPanel,
-- so classic placement is untouched.
-- ---------------------------------------------------------------------------

-- panelId -> root Frame of a registered content panel.
local mountablePanels = {}
-- panelId -> original parent, captured on first mount for a later revert.
local mountOriginalParent = {}
-- panelId -> host requested before the panel registered (deferred-mount intent).
local pendingPanelMounts = {}

-- Every panel id MountPanel recognizes. Content panels reparent into a host;
-- dialog-class ids launch a standalone window; vehiclePet / metadata are
-- reserved (no panel module yet); preview delegates to the Preview facade.
local KNOWN_PANEL_IDS = {
    sequenceList = true,
    editor = true,
    variables = true,
    conditions = true,
    macros = true,
    source = true,
    vehiclePet = true,
    options = true,
    import = true,
    export = true,
    about = true,
    metadata = true,
    preview = true,
}

-- Ids that open a standalone dialog window instead of mounting into a host.
local DIALOG_PANEL_IDS = {
    options = true,
    import = true,
    export = true,
    about = true,
}

-- Reparent a non-secure frame to fill a host, inside pcall (the same body the
-- Preview facade uses). Returns the pcall ok boolean.
local function _reparent(frame, host)
    return pcall(function()
        frame:SetParent(host)
        frame:ClearAllPoints()
        frame:SetAllPoints(host)
    end)
end

-- ---------------------------------------------------------------------------
-- Tier 3 -- view / nav model (Plugin API Phase D)
--
-- A view is a NAMED top-level screen (Sequences, Editor, Variables, ...). A
-- modern layout provider registers views and drives SetActiveView to swap the
-- screen; classic has no nav region and registers no views. The registry mirrors
-- layoutProviders / mountablePanels: a chunk-level table reached by plugins
-- through GRIPEMS.API.UI and by the core through the engine-internal channel
-- (GRIPEMS._views) below. activeViewId lives in memory only (a provider rebuilds
-- it each load), so it is never persisted -- unlike the uiLayout setting.
-- ---------------------------------------------------------------------------

-- viewId -> validated view def. Shared with the core via GRIPEMS._views.
local views = {}
-- The active view id, or nil when no view is active (the classic default).
local activeViewId

-- Validate a view against the Tier 3 contract. Required: id (a string equal to
-- the registry key) and name (a string). Returns true, or false + a reason.
local function ValidateView(id, def)
    if type(id) ~= "string" then
        return false, "RegisterView: id must be a string"
    end
    if type(def) ~= "table" then
        return false, "RegisterView: def must be a table"
    end
    if type(def.id) ~= "string" or def.id ~= id then
        return false, "RegisterView: def.id must be a string equal to the registry id"
    end
    if type(def.name) ~= "string" then
        return false, "RegisterView: def.name must be a string"
    end
    return true
end

-- Resolved lazily; nil until SetActiveLayoutProvider runs. The getters fall back
-- to the stored uiLayout setting, then to the "classic" default.
local activeLayoutProviderId

-- Provider lifecycle callbacks. Each is optional, but must be a function when
-- supplied (the MainFrame dispatcher nil-checks before calling).
local LAYOUT_PROVIDER_CALLBACKS = {
    "OnRegister",
    "OnInitMainFrame",
    "OnInitPanels",
    "OnApplyLayout",
    "OnMinimize",
    "OnRestore",
}

-- Validate a provider against the Tier 3 contract. Required: id (a string equal
-- to the registry key) and name (a string). The six callbacks are optional but
-- must be functions when present. Returns true, or false + a reason string.
local function ValidateLayoutProvider(id, provider)
    if type(id) ~= "string" then
        return false, "RegisterLayoutProvider: id must be a string"
    end
    if type(provider) ~= "table" then
        return false, "RegisterLayoutProvider: provider must be a table"
    end
    if type(provider.id) ~= "string" or provider.id ~= id then
        return false, "RegisterLayoutProvider: provider.id must be a string equal to the registry id"
    end
    if type(provider.name) ~= "string" then
        return false, "RegisterLayoutProvider: provider.name must be a string"
    end
    for i = 1, #LAYOUT_PROVIDER_CALLBACKS do
        local key = LAYOUT_PROVIDER_CALLBACKS[i]
        local cb = provider[key]
        if cb ~= nil and type(cb) ~= "function" then
            return false, "RegisterLayoutProvider: " .. key .. " must be a function when present"
        end
    end
    return true
end

-- uiImpl backs the frozen impl.UI sub-proxy. Methods take a leading ignored
-- self because callers use GRIPEMS.API.UI:Method(...).
local uiImpl = {}

--- Register a layout provider under an id. Validates the Tier 3 contract,
--- rejects a duplicate id (never overwrites), stores the provider, and calls
--- its OnRegister (when present) inside pcall.
--- @param id string Registry id; must equal provider.id
--- @param provider table Provider table (id, name, optional callbacks)
--- @return boolean ok True on success
--- @return string|nil reason Failure reason when ok is false
function uiImpl.RegisterLayoutProvider(_, id, provider)
    local ok, reason = ValidateLayoutProvider(id, provider)
    if not ok then
        return false, reason
    end
    if layoutProviders[id] then
        return false, "RegisterLayoutProvider: id '" .. id .. "' is already registered"
    end
    layoutProviders[id] = provider
    if provider.OnRegister then
        pcall(provider.OnRegister, provider)
    end
    return true
end

--- Select the active layout provider by id. Rejects an unknown id. On success
--- the in-session active provider is always set; persistence to the uiLayout
--- setting is best-effort (it is skipped only when no settings writer exists,
--- e.g. a headless harness), and the call still returns true in that case.
--- @param id string A registered provider id
--- @return boolean ok True on success
--- @return string|nil reason Failure reason when ok is false
function uiImpl.SetActiveLayoutProvider(_, id)
    if not layoutProviders[id] then
        return false, "SetActiveLayoutProvider: unknown layout provider id '" .. tostring(id) .. "'"
    end
    activeLayoutProviderId = id
    if GRIPEMS.Settings and GRIPEMS.Settings.Set then
        GRIPEMS.Settings:Set("uiLayout", id)
    end
    return true
end

--- The active layout provider id. Falls back to the stored uiLayout setting,
--- then to "classic". Returns the id string (not the provider table).
--- @return string Provider id
function uiImpl.GetActiveLayoutProvider(_)
    return activeLayoutProviderId or (GRIPEMS.Settings and GRIPEMS.Settings:Get("uiLayout")) or "classic"
end

--- Look up a named host frame on the live main frame, or nil. Resolved at call
--- time so it works whether or not the main frame has been built yet.
--- @param name string Host name (e.g. "editorHost")
--- @return table|nil The host frame, or nil when absent
function uiImpl.GetHost(_, name)
    local mf = _G.GRIPEMS_MainFrame
    return mf and mf.hosts and mf.hosts[name] or nil
end

--- Tier 5 re-export: register a frame with the panel-style registry. Nil-safe.
--- @param frame table The frame to register
--- @param category string Panel category
--- @param class string Panel class key
function uiImpl.RegisterPanelFrame(_, frame, category, class)
    if GRIPEMS.UI and GRIPEMS.UI.RegisterPanelFrame then
        GRIPEMS.UI:RegisterPanelFrame(frame, category, class)
    end
end

--- Mount a built-in panel into a provider host frame. Content panels
--- (sequenceList / editor / variables / conditions / macros / source) reparent
--- their registered content root to fill the host; when the panel has not yet
--- registered, the host is recorded as deferred-mount intent and applied at
--- registration. The preview id delegates to the Preview facade. Dialog-class
--- ids (options / import / export / about) launch their existing standalone
--- window and ignore the host. vehiclePet / metadata are reserved ids with no
--- panel module yet. Classic never calls this, so classic placement is untouched.
--- @param panelId string A known panel id
--- @param host table|nil Host frame for content panels (ignored by dialog ids)
--- @return boolean ok True on success
--- @return string|nil reason Failure reason when ok is false
function uiImpl.MountPanel(_, panelId, host)
    if not KNOWN_PANEL_IDS[panelId] then
        return false, "MountPanel: unknown panel id '" .. tostring(panelId) .. "'"
    end
    if panelId == "vehiclePet" or panelId == "metadata" then
        return false, "MountPanel: panel '" .. panelId .. "' is not yet mountable (no panel implemented)"
    end
    if panelId == "preview" then
        return GRIPEMS.API.Preview:MountSidebar(host)
    end
    if DIALOG_PANEL_IDS[panelId] then
        if panelId == "import" then
            if GRIPEMS.ImportFrame then
                GRIPEMS.ImportFrame:Show()
                return true
            end
            return false, "import frame unavailable"
        elseif panelId == "export" then
            if GRIPEMS.ExportFrame then
                GRIPEMS.ExportFrame:Show()
                return true
            end
            return false, "export frame unavailable"
        else
            -- options and about both open the standalone settings window; SP:Open
            -- takes no group arg today, so about opens the default (its group lives
            -- in the AceConfig tree, reachable once Open accepts a section in F).
            if GRIPEMS.SettingsPanel then
                GRIPEMS.SettingsPanel:Open()
                return true
            end
            return false, "settings panel unavailable"
        end
    end
    if type(host) ~= "table" then
        return false, "MountPanel: host must be a frame table"
    end
    local frame = mountablePanels[panelId]
    if not frame then
        pendingPanelMounts[panelId] = host
        return true
    end
    if mountOriginalParent[panelId] == nil then
        mountOriginalParent[panelId] = frame:GetParent()
    end
    local ok = _reparent(frame, host)
    if not ok then
        return false, "MountPanel: reparent failed"
    end
    return true
end

--- Show or hide the classic two-panel chrome (left panel, divider, right panel,
--- title bar) so a modern layout provider can present its own. Reversible:
--- SetClassicChrome(true) (or nil) restores; SetClassicChrome(false) hides. The
--- frames are only toggled, never reparented or destroyed -- their children
--- (placeholders, title buttons) hide and show with them. Classic never calls
--- this, so the classic chrome stays shown.
--- @param enabled boolean|nil false hides the classic chrome; true / nil shows it
--- @return boolean ok True on success
--- @return string|nil reason Failure reason when ok is false
function uiImpl.SetClassicChrome(_, enabled)
    local mf = _G.GRIPEMS_MainFrame
    if not mf then
        return false, "SetClassicChrome: main frame not built"
    end
    local show = enabled ~= false
    for _, name in ipairs({ "leftPanel", "divider", "rightPanel", "titleBar" }) do
        local f = mf[name]
        if f and f.SetShown then
            f:SetShown(show)
        end
    end
    return true
end

--- Register a named top-level view (screen) a modern provider can switch to.
--- Validates the Tier 3 contract, rejects a duplicate id (never overwrites), and
--- stores the def. Classic registers no views.
--- @param id string Registry id; must equal def.id
--- @param def table View def ({ id, name })
--- @return boolean ok True on success
--- @return string|nil reason Failure reason when ok is false
function uiImpl.RegisterView(_, id, def)
    local ok, reason = ValidateView(id, def)
    if not ok then
        return false, reason
    end
    if views[id] then
        return false, "RegisterView: id '" .. id .. "' is already registered"
    end
    views[id] = def
    return true
end

--- Set the active view by id. Rejects an unknown id. Sets the in-session active
--- view (in memory -- a provider rebuilds it each load, so it is not persisted)
--- and fires GEMS_UI_NAV_CHANGED with the view id.
--- @param id string A registered view id
--- @return boolean ok True on success
--- @return string|nil reason Failure reason when ok is false
function uiImpl.SetActiveView(_, id)
    if not views[id] then
        return false, "SetActiveView: unknown view id '" .. tostring(id) .. "'"
    end
    activeViewId = id
    GRIPEMS:Fire("GEMS_UI_NAV_CHANGED", id)
    return true
end

--- The active view id, or nil when no view is active (the classic default).
--- @return string|nil Active view id
function uiImpl.GetActiveView(_)
    return activeViewId
end

-- Engine-internal core-to-core channel. NOT on the frozen proxy: the core uses
-- these to resolve and drive the active provider; plugins use GRIPEMS.API.UI.
-- layoutProviders / activeLayoutProviderId are upvalues in this chunk.
GRIPEMS._layoutProviders = layoutProviders

-- View registry engine channel (Phase D). Same core-to-core split: the teardown
-- in Core/PluginAPI.lua removes a disabled plugin's views by id from this table.
GRIPEMS._views = views

--- Resolve the active provider TABLE (not its id). Falls back to the stored
--- uiLayout setting, then to the registered "classic" provider.
--- @return table|nil The active provider, or nil if nothing is registered yet
function GRIPEMS:ResolveActiveLayoutProvider()
    local id = activeLayoutProviderId or (GRIPEMS.Settings and GRIPEMS.Settings:Get("uiLayout")) or "classic"
    return layoutProviders[id] or layoutProviders["classic"]
end

-- Engine-internal channel (NOT on the frozen proxy, same core-to-core split as
-- GRIPEMS._layoutProviders / GRIPEMS:ResolvePluginVariable). A built-in panel
-- module registers its mountable content root here from its Init; if a plugin
-- requested a mount before the panel was built, the recorded deferred-mount
-- intent is consumed now and the panel reparents into the waiting host.
--- @param panelId string A known content-panel id
--- @param frame table The panel's content root Frame
function GRIPEMS:RegisterMountablePanel(panelId, frame)
    if not KNOWN_PANEL_IDS[panelId] or type(frame) ~= "table" then
        GRIPEMS:Debug("RegisterMountablePanel: rejected panel id '%s' (frame type %s)", tostring(panelId), type(frame))
        return
    end
    mountablePanels[panelId] = frame
    if pendingPanelMounts[panelId] then
        local host = pendingPanelMounts[panelId]
        pendingPanelMounts[panelId] = nil
        if mountOriginalParent[panelId] == nil then
            mountOriginalParent[panelId] = frame:GetParent()
        end
        _reparent(frame, host)
    end
end

--- Engine-internal: un-mount a previously mounted panel, restoring it to the
--- parent captured on its first mount (mountOriginalParent). Clears that record
--- and any pending-mount intent so the panel returns to its default-installed
--- placement. No-op for an id that was never mounted (dialog / preview ids never
--- register a content root, so this is a graceful no-op for them).
--- @param panelId string A known content-panel id
function GRIPEMS:UnmountPanel(panelId)
    local frame = mountablePanels[panelId]
    local orig = mountOriginalParent[panelId]
    if frame and orig then
        _reparent(frame, orig)
    end
    mountOriginalParent[panelId] = nil
    pendingPanelMounts[panelId] = nil
end

--- Engine-internal: restore the active view during plugin teardown. Sets the
--- active view directly and does NOT fire GEMS_UI_NAV_CHANGED -- restoring to the
--- pre-plugin state is internal bookkeeping, not a user nav action. priorId may
--- be nil (no active view = the classic default); a priorId whose view was
--- already unregistered also falls back to nil.
--- @param priorId string|nil The view id to restore, or nil for the default
function GRIPEMS:RestoreActiveView(priorId)
    if priorId ~= nil and views[priorId] then
        activeViewId = priorId
    else
        activeViewId = nil
    end
end

-- Freeze impl.UI through the same read-only proxy pattern as the top-level API.
impl.UI = setmetatable({}, {
    __index = uiImpl,
    __newindex = function()
        error("GRIPEMS.API.UI is read-only", 2)
    end,
    __metatable = false,
})

-- ---------------------------------------------------------------------------
-- Tier 3 -- Preview facade (Plugin API Phase 1c)
--
-- GRIPEMS.API.Preview is a frozen sub-proxy (same read-only pattern as impl.UI)
-- that lets a layout provider drive and mount the sequence preview WITHOUT
-- reaching into SequenceEditor internals. First incremental step of the preview
-- extraction (design risk #2: SequenceEditor.lua is large -- extract in small
-- classic-parity steps, never one rewrite). Every method DELEGATES to the
-- existing SE preview methods/frames; no rendering code moves here. Methods are
-- call-time lazy and nil-guard SequenceEditor (the editor may not be built yet,
-- or at all in a headless / foreground-only context). Classic never calls this
-- facade, so the classic preview behaves byte-for-byte as before -- including
-- the SE:UpdatePreview tabBar<->previewFrame anchor coupling, which this facade
-- does not touch (re-driving it after a Mount* is the modern provider's job in
-- its OnApplyLayout).
-- ---------------------------------------------------------------------------

local previewImpl = {}

--- The current preview mode ("icons" | "text" | "compiled"), or the icons
--- default when unset.
--- @return string Preview mode id
function previewImpl.GetMode(_)
    local S = GRIPEMS.Settings
    return (S and S:Get("previewMode")) or GRIPEMS.Defaults.PREVIEW_MODE_ICONS
end

--- Set the preview mode. Rejects a mode outside the three known ids. On a valid
--- mode it persists the setting, re-renders the live preview (when the editor is
--- built), and fires GEMS_PREVIEW_MODE_CHANGED.
--- @param mode string One of the PREVIEW_MODE_* ids
--- @return boolean ok True on success
--- @return string|nil reason Failure reason when ok is false
function previewImpl.SetMode(_, mode)
    local D = GRIPEMS.Defaults
    if not D then
        return false, "SetMode: preview-mode constants unavailable"
    end
    if mode ~= D.PREVIEW_MODE_ICONS and mode ~= D.PREVIEW_MODE_TEXT and mode ~= D.PREVIEW_MODE_COMPILED then
        return false, "SetMode: mode must be one of 'icons', 'text', 'compiled'"
    end
    -- Require a settings writer: the side effects below (re-render + event)
    -- announce a mode change, so they must not run when the persist could not.
    local S = GRIPEMS.Settings
    if not (S and S.Set) then
        return false, "SetMode: settings store unavailable"
    end
    S:Set("previewMode", mode)
    local SE = GRIPEMS.SequenceEditor
    if SE and SE.UpdatePreview then
        pcall(SE.UpdatePreview, SE)
    end
    GRIPEMS:Fire("GEMS_PREVIEW_MODE_CHANGED", mode)
    return true
end

--- Re-render the live preview. The version argument is accepted for forward
--- compatibility but is currently advisory -- classic SE:UpdatePreview derives
--- the version from the selected sequence internally, and its signature is NOT
--- changed this phase.
--- @param version table|nil Advisory version handle (currently unused)
--- @return boolean ok Always true
function previewImpl.Update(_, version)
    local SE = GRIPEMS.SequenceEditor
    if SE and SE.UpdatePreview then
        pcall(SE.UpdatePreview, SE)
    end
    GRIPEMS:Fire("GEMS_PREVIEW_UPDATE")
    return true
end

--- Hide the live preview frame. Nil-safe no-op when the editor is not built.
function previewImpl.Hide(_)
    local SE = GRIPEMS.SequenceEditor
    if SE and SE.previewFrame then
        pcall(SE.previewFrame.Hide, SE.previewFrame)
    end
end

--- Reparent the preview frame into a provider host (e.g. a modern layout's
--- configHost). Classic never calls this, so classic placement is untouched.
--- @param host table A host Frame to mount the preview into
--- @return boolean ok True on success
--- @return string|nil reason Failure reason when ok is false
function previewImpl.MountSidebar(_, host)
    if type(host) ~= "table" then
        return false, "MountSidebar: host must be a frame table"
    end
    local SE = GRIPEMS.SequenceEditor
    if not SE then
        return false, "MountSidebar: SequenceEditor not built"
    end
    -- Record the desired host first (deferred-mount intent): the host is kept
    -- even if previewFrame is not built yet, so a later mount can consume it.
    SE._previewSidebarHost = host
    local frame = SE.previewFrame
    if not frame then
        return false, "MountSidebar: previewFrame not built"
    end
    local ok = pcall(function()
        frame:SetParent(host)
        frame:ClearAllPoints()
        frame:SetAllPoints(host)
    end)
    if not ok then
        return false, "MountSidebar: reparent failed"
    end
    return true
end

--- Reparent the preview icon strip into a provider host. The icon strip lives
--- inside SE.previewFrame today, so a true sidebar/footer split is a later
--- increment; for now this relocates SE.previewIconScroll into host.
--- @param host table A host Frame to mount the icon strip into
--- @return boolean ok True on success
--- @return string|nil reason Failure reason when ok is false
function previewImpl.MountIconFooter(_, host)
    if type(host) ~= "table" then
        return false, "MountIconFooter: host must be a frame table"
    end
    local SE = GRIPEMS.SequenceEditor
    if not SE then
        return false, "MountIconFooter: SequenceEditor not built"
    end
    -- Record the desired host first (deferred-mount intent): the host is kept
    -- even if previewIconScroll is not built yet, so a later mount can consume it.
    SE._previewFooterHost = host
    local strip = SE.previewIconScroll
    if not strip then
        return false, "MountIconFooter: previewIconScroll not built"
    end
    local ok = pcall(function()
        strip:SetParent(host)
        strip:ClearAllPoints()
        strip:SetAllPoints(host)
    end)
    if not ok then
        return false, "MountIconFooter: reparent failed"
    end
    return true
end

-- Freeze impl.Preview through the same read-only proxy pattern as impl.UI.
impl.Preview = setmetatable({}, {
    __index = previewImpl,
    __newindex = function()
        error("GRIPEMS.API.Preview is read-only", 2)
    end,
    __metatable = false,
})

-- ---------------------------------------------------------------------------
-- Tier 5 -- import / export format providers (Plugin API Phase G)
--
-- A plugin supplies a parser (import) or a serializer (export); EMS owns the
-- import / export pipeline. These registries are the registration hooks: a plugin
-- contributes a provider, EMS journals it, and disable removes it. Each registry is
-- an ordered array (registration order), shared with the core through
-- GRIPEMS._importProviders / GRIPEMS._exportProviders below -- NOT on the frozen
-- proxy, the same core-to-core split as the variable-provider and layout registries.
-- A duplicate id is rejected (never overwritten).
-- ---------------------------------------------------------------------------

-- id-ordered array of validated import-provider tables.
local importProviders = {}

-- Validate an import provider against the Tier 5 contract. Required: id (a string
-- equal to the registry id), name (a string), Parse (a function). Detect and
-- OnRegister must be functions when present.
local function ValidateImportProvider(id, spec)
    if type(id) ~= "string" then
        return false, "RegisterImportProvider: id must be a string"
    end
    if type(spec) ~= "table" then
        return false, "RegisterImportProvider: provider must be a table"
    end
    if type(spec.id) ~= "string" or spec.id ~= id then
        return false, "RegisterImportProvider: provider.id must be a string equal to the registry id"
    end
    if type(spec.name) ~= "string" then
        return false, "RegisterImportProvider: provider.name must be a string"
    end
    if type(spec.Parse) ~= "function" then
        return false, "RegisterImportProvider: provider.Parse must be a function"
    end
    if spec.Detect ~= nil and type(spec.Detect) ~= "function" then
        return false, "RegisterImportProvider: Detect must be a function when present"
    end
    if spec.OnRegister ~= nil and type(spec.OnRegister) ~= "function" then
        return false, "RegisterImportProvider: OnRegister must be a function when present"
    end
    return true
end

--- Register an import format provider. Validates the Tier 5 contract, rejects a
--- duplicate id (never overwrites), appends to the ordered registry, and runs the
--- optional OnRegister inside pcall.
--- @param id string Registry id; must equal spec.id
--- @param spec table Provider table (id, name, Parse, optional Detect, OnRegister)
--- @return boolean ok
--- @return string|nil reason
function impl.RegisterImportProvider(_, id, spec)
    local ok, reason = ValidateImportProvider(id, spec)
    if not ok then
        return false, reason
    end
    for i = 1, #importProviders do
        if importProviders[i].id == id then
            return false, "RegisterImportProvider: id '" .. id .. "' is already registered"
        end
    end
    importProviders[#importProviders + 1] = spec
    if spec.OnRegister then
        pcall(spec.OnRegister, spec)
    end
    return true
end

-- Engine-internal channel (NOT on the frozen proxy). The registration channel for
-- plugin-supplied import parsers.
GRIPEMS._importProviders = importProviders

-- id-ordered array of validated export-provider tables.
local exportProviders = {}

-- Validate an export provider against the Tier 5 contract. Required: id (a string
-- equal to the registry id), name (a string), Serialize (a function). OnRegister
-- must be a function when present.
local function ValidateExportProvider(id, spec)
    if type(id) ~= "string" then
        return false, "RegisterExportProvider: id must be a string"
    end
    if type(spec) ~= "table" then
        return false, "RegisterExportProvider: provider must be a table"
    end
    if type(spec.id) ~= "string" or spec.id ~= id then
        return false, "RegisterExportProvider: provider.id must be a string equal to the registry id"
    end
    if type(spec.name) ~= "string" then
        return false, "RegisterExportProvider: provider.name must be a string"
    end
    if type(spec.Serialize) ~= "function" then
        return false, "RegisterExportProvider: provider.Serialize must be a function"
    end
    if spec.OnRegister ~= nil and type(spec.OnRegister) ~= "function" then
        return false, "RegisterExportProvider: OnRegister must be a function when present"
    end
    return true
end

--- Register an export format provider. Validates the Tier 5 contract, rejects a
--- duplicate id (never overwrites), appends to the ordered registry, and runs the
--- optional OnRegister inside pcall.
--- @param id string Registry id; must equal spec.id
--- @param spec table Provider table (id, name, Serialize, optional OnRegister)
--- @return boolean ok
--- @return string|nil reason
function impl.RegisterExportProvider(_, id, spec)
    local ok, reason = ValidateExportProvider(id, spec)
    if not ok then
        return false, reason
    end
    for i = 1, #exportProviders do
        if exportProviders[i].id == id then
            return false, "RegisterExportProvider: id '" .. id .. "' is already registered"
        end
    end
    exportProviders[#exportProviders + 1] = spec
    if spec.OnRegister then
        pcall(spec.OnRegister, spec)
    end
    return true
end

-- Engine-internal channel (NOT on the frozen proxy). The registration channel for
-- plugin-supplied export serializers.
GRIPEMS._exportProviders = exportProviders

-- ---------------------------------------------------------------------------
-- Freeze: expose impl through a read-only proxy.
--
-- The proxy table holds no real keys, so EVERY assignment -- new key or an
-- attempt to overwrite an existing field/method -- misses the proxy and hits
-- __newindex, which errors. Reads fall through __index to impl. __metatable
-- blocks getmetatable/setmetatable tampering with the proxy.
-- ---------------------------------------------------------------------------

GRIPEMS.API = setmetatable({}, {
    __index = impl,
    __newindex = function()
        error("GRIPEMS.API is read-only", 2)
    end,
    __metatable = false,
})

-- Stable global alias for plugins. Does not expose any internals on its own.
_G.GRIPEMS_API = GRIPEMS.API
