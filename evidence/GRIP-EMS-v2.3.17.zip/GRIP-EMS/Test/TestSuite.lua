-- GRIP-EMS: TestSuite
-- Created: 2026-04-03
-- Updated: 2026-07-26
-- Patch: 12.0.7.68453 Midnight (Retail LIVE)

-- GRIP-EMS: TestSuite
-- In-game test framework for /gems test

local ADDON_NAME, GRIPEMS = ...

GRIPEMS.TestSuite = {}
local TS = GRIPEMS.TestSuite

-- ---------------------------------------------------------------------------
-- Test registry
-- ---------------------------------------------------------------------------

TS.tests = {} -- array of {name, category, func}
TS.results = {} -- array of {name, status, time, message}

--- Register a test function.
--- @param name string Human-readable test name
--- @param category string Category tag for filtering (e.g. "crud", "import")
--- @param func function Test body: must call TS:Pass(), TS:Fail(msg), or TS:Skip(msg)
function TS:Register(name, category, func)
    self.tests[#self.tests + 1] = {
        name = name,
        category = category,
        func = func,
    }
end

--- Print a /gems test prep checklist. Walks the user through the
--- one-time game-state setup required for the four environment-
--- dependent tests to PASS instead of SKIP:
---   - HasBuff non-player iteration (needs a unit with HELPFUL aura)
---   - HasDebuff no-debuff (needs any non-player unit)
---   - HasDebuff known-debuff (needs a unit with HARMFUL aura)
---   - SpellOnCooldown returns true (needs a spell on CD)
--- Skip-clean tests still skip if the user does not follow prep.
function TS:PrintPrep()
    local function line(msg)
        GRIPEMS:Print(msg)
    end
    line("=== /gems test prep ===")
    line("Do these steps once before running /gems test so the environment-dependent tests PASS instead of SKIP:")
    line("  1) Target any non-player unit. A training dummy in a capital city is ideal.")
    line("     Example: target a Combat Dummy in Orgrimmar / Stormwind.")
    line("  2) Have at least one HELPFUL aura on a non-player unit.")
    line("     Easiest options:")
    line("       - Summon your pet (Hunter / Warlock / DK) -- pet passives cover it.")
    line("       - In a party / raid, target a buffed party member.")
    line("       - Solo non-pet classes: target a friendly NPC with visible buffs (a city guard).")
    line("  3) Apply a debuff to the target. Cast any DoT or mark.")
    line("     Hunter: Hunter's Mark. Mage: Frostbolt. Warrior: Hamstring.")
    line("  4) Cast any spell to put it on cooldown.")
    line("     Hearthstone works (long CD makes the test reliable for several minutes).")
    line("Then run /gems test for the full green run.")
end

-- ---------------------------------------------------------------------------
-- Assertion helpers (called inside test functions)
-- ---------------------------------------------------------------------------

local currentResult -- set by Run() before each test

--- Mark the current test as passed.
function TS:Pass()
    currentResult.status = "pass"
end

--- Mark the current test as failed with a reason.
--- @param msg string Failure description
function TS:Fail(msg)
    currentResult.status = "fail"
    currentResult.message = msg or "no reason"
end

--- Mark the current test as skipped with a reason.
--- @param msg string Skip reason
function TS:Skip(msg)
    currentResult.status = "skip"
    currentResult.message = msg or ""
end

--- Skip the current test when in combat. Sequence-activation tests cannot
--- run cleanly in combat: Engine:ActivateSequence defers via OOCQueue, so
--- the test's own DeactivateSequence teardown no-ops and the activation
--- persists a _TS_ row past combat. Every activation test calls this as
--- its first line. Returns true when it skipped (caller must return).
--- @return boolean skipped
function TS:_SkipIfCombat()
    local OOC = GRIPEMS.OOCQueue
    if OOC and OOC.IsRestricted() then
        self:Skip("requires out of combat (sequence activation defers via OOCQueue in combat)")
        return true
    end
    return false
end

--- Assert that a condition is truthy; fails the test if not.
--- @param cond any Value to test
--- @param msg string Failure message if cond is falsy
function TS:Assert(cond, msg)
    if not cond then
        self:Fail(msg or "assertion failed")
    end
end

--- Assert two values are equal; fails with a diff message if not.
--- @param expected any Expected value
--- @param actual any Actual value
--- @param label string Optional context label
function TS:AssertEqual(expected, actual, label)
    if expected ~= actual then
        local prefix = label and (label .. ": ") or ""
        self:Fail(prefix .. "expected " .. tostring(expected) .. ", got " .. tostring(actual))
    end
end

-- ---------------------------------------------------------------------------
-- Suite hygiene: residue matcher, scrub, census
-- ---------------------------------------------------------------------------

-- A persisted key counts as suite residue when it carries the _TS_ prefix
-- or is the one repair fixture registered without it.
local function IsResidueName(name)
    return type(name) == "string" and (name:find("^_TS_") ~= nil or name == "TrueIndexTest")
end

-- Plain-text needles that mark a persisted trace line as suite output
-- (result rows, runner banner and summary, residue sequence names).
local TRACE_SCRUB_NEEDLES = {
    "[TestSuite]",
    "_TS_",
    "TrueIndexTest",
    "PASS|r ",
    "FAIL|r ",
    "SKIP|r ",
}

--- Remove persisted TempoAdvisor recommendation rows for residue names
--- across every spec table. Suite-level cleanup only: DeactivateSequence
--- cannot reap these (see the deactivate-then-reactivate cycles in
--- Engine.lua), so activations during a run recreate rows that this
--- reap clears again afterwards.
--- @return number Rows removed
function TS:_ReapTempoRows()
    local n = 0
    if _G.GRIP_EMS_CHAR and type(GRIP_EMS_CHAR.tempoAdvisor) == "table" then
        for _, rows in pairs(GRIP_EMS_CHAR.tempoAdvisor) do
            if type(rows) == "table" then
                for seqName in pairs(rows) do
                    if IsResidueName(seqName) then
                        rows[seqName] = nil
                        n = n + 1
                    end
                end
            end
        end
    end
    return n
end

--- Count every persisted keybind entry: per-spec layer keys plus
--- per-loadout bucket keys across all spec tables. One total so the
--- post-suite audit can assert a zero delta across the run.
--- @return number Total persisted keybind entries
function TS:_CountKeybinds()
    local total = 0
    if not (_G.GRIP_EMS_CHAR and type(GRIP_EMS_CHAR.keybinds) == "table") then
        return total
    end
    for _, specBinds in pairs(GRIP_EMS_CHAR.keybinds) do
        if type(specBinds) == "table" then
            for key in pairs(specBinds) do
                if key ~= "_byLoadout" then
                    total = total + 1
                end
            end
            if type(specBinds._byLoadout) == "table" then
                for _, bucket in pairs(specBinds._byLoadout) do
                    if type(bucket) == "table" then
                        for _ in pairs(bucket) do
                            total = total + 1
                        end
                    end
                end
            end
        end
    end
    return total
end

--- Count empty per-loadout buckets (a cleared bucket should be reaped by
--- KeybindManager; any empty bucket after a run is residue).
--- @return number Empty buckets
function TS:_CountEmptyOverlays()
    local n = 0
    if not (_G.GRIP_EMS_CHAR and type(GRIP_EMS_CHAR.keybinds) == "table") then
        return n
    end
    for _, specBinds in pairs(GRIP_EMS_CHAR.keybinds) do
        if type(specBinds) == "table" and type(specBinds._byLoadout) == "table" then
            for _, bucket in pairs(specBinds._byLoadout) do
                if type(bucket) == "table" and next(bucket) == nil then
                    n = n + 1
                end
            end
        end
    end
    return n
end

--- List persisted or runtime sequences that still carry a residue name.
--- Store and runtime only: tempo rows are reaped mechanically by the
--- audit, keybinds are asserted via the census delta.
--- @return table Array of "runtime:NAME" / "store:NAME" strings
function TS:_ListResidue()
    local left = {}
    local Engine = GRIPEMS.Engine
    if Engine and Engine.sequences then
        for name in pairs(Engine.sequences) do
            if IsResidueName(name) then
                left[#left + 1] = "runtime:" .. name
            end
        end
    end
    if _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.sequences then
        for name in pairs(GRIP_EMS_CHAR.sequences) do
            if IsResidueName(name) then
                left[#left + 1] = "store:" .. name
            end
        end
    end
    return left
end

--- Pre-suite purge: remove every persisted leftover from older suite
--- versions. Store rows go through the engine's full deactivate path so
--- buttons and macro stubs tear down with them; stale store rows with no
--- runtime entry are removed directly. Also reaps tempo rows, keybind
--- entries naming residue sequences, empty per-loadout buckets, and
--- historical suite lines in the persisted trace ring.
--- @return number Items removed
function TS:_ScrubResidue()
    local removed = 0
    local Engine = GRIPEMS.Engine

    -- 1) Sequences: collect first (DeactivateSequence mutates both the
    --    runtime table and the store), then tear down.
    local names = {}
    if Engine and Engine.sequences then
        for name in pairs(Engine.sequences) do
            if IsResidueName(name) then
                names[#names + 1] = name
            end
        end
    end
    if _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.sequences then
        for name in pairs(GRIP_EMS_CHAR.sequences) do
            if IsResidueName(name) and not (Engine and Engine.sequences and Engine.sequences[name]) then
                names[#names + 1] = name
            end
        end
    end
    for _, name in ipairs(names) do
        if Engine and Engine.sequences and Engine.sequences[name] then
            Engine:DeactivateSequence(name)
        elseif _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.sequences then
            GRIP_EMS_CHAR.sequences[name] = nil
        end
        removed = removed + 1
    end

    -- 2) TempoAdvisor rows.
    removed = removed + self:_ReapTempoRows()

    -- 3) Keybind entries naming residue sequences + empty buckets. The
    --    _byLoadout container itself stays (schema-v2 structure).
    if _G.GRIP_EMS_CHAR and type(GRIP_EMS_CHAR.keybinds) == "table" then
        for _, specBinds in pairs(GRIP_EMS_CHAR.keybinds) do
            if type(specBinds) == "table" then
                for key, seqName in pairs(specBinds) do
                    if key ~= "_byLoadout" and IsResidueName(seqName) then
                        specBinds[key] = nil
                        removed = removed + 1
                    end
                end
                if type(specBinds._byLoadout) == "table" then
                    for lid, bucket in pairs(specBinds._byLoadout) do
                        if type(bucket) == "table" then
                            for key, seqName in pairs(bucket) do
                                if IsResidueName(seqName) then
                                    bucket[key] = nil
                                    removed = removed + 1
                                end
                            end
                            if next(bucket) == nil then
                                specBinds._byLoadout[lid] = nil
                                removed = removed + 1
                            end
                        end
                    end
                end
            end
        end
    end

    -- 4) Historical suite lines in the persisted trace ring.
    local Trace = GRIPEMS.Trace
    local events = Trace and Trace.db and Trace.db.events
    if type(events) == "table" then
        for i = #events, 1, -1 do
            local m = events[i] and events[i].m
            if type(m) == "string" then
                for _, needle in ipairs(TRACE_SCRUB_NEEDLES) do
                    if m:find(needle, 1, true) then
                        table.remove(events, i)
                        removed = removed + 1
                        break
                    end
                end
            end
        end
    end

    return removed
end

-- ---------------------------------------------------------------------------
-- Runner
-- ---------------------------------------------------------------------------

--- Run all registered tests, or only those matching a category filter.
--- Results are printed to DebugWindow and chat.
--- @param filter string|nil Category filter (nil = run all)
function TS:Run(filter)
    -- Suspend trace persistence for the whole run: suite output stays
    -- visible in the debug window but never lands in the persisted
    -- GRIP_EMS_TRACE ring (one run otherwise evicts most of the real
    -- debug history out of the capped ring).
    -- Signal an active suite run for frame side-effect guards: the tutorial
    -- auto-start checks this so a test-bootstrapped window open stays
    -- side-effect free (no orphaned popover, no consumed once-per-session
    -- start). Each test body runs under pcall, so the reset at the end of
    -- Run is not skippable by a failing test.
    self._running = true
    if GRIPEMS.Trace then
        GRIPEMS.Trace._suspend = true
    end
    local DW = GRIPEMS.DebugWindow
    if DW and DW.Show then
        DW:Show()
    end

    wipe(self.results)
    local startAll = debugprofilestop()
    local passed, failed, skipped = 0, 0, 0

    local function Out(msg)
        if DW and DW.AddMessage then
            DW:AddMessage(msg)
        end
    end

    Out("|cFF00CC66[TestSuite]|r Running tests" .. (filter and (" [" .. filter .. "]") or "") .. " ...")

    -- Pre-suite hygiene: clear residue left by older suite versions, then
    -- take the keybind census the post-suite audit asserts against.
    local scrubbed = self:_ScrubResidue()
    if scrubbed > 0 then
        Out("|cFF00CC66[TestSuite]|r Pre-suite scrub removed " .. scrubbed .. " residue entries")
    end
    local kbBaseline = self:_CountKeybinds()
    local mfBase = _G.GRIPEMS_MainFrame
    local mfShownBaseline = (mfBase and mfBase.IsShown and mfBase:IsShown()) and true or false

    local matchedCount = 0
    for _, test in ipairs(self.tests) do
        if not filter or filter == "" or test.category == filter then
            matchedCount = matchedCount + 1
            currentResult = {
                name = test.name,
                status = "pending",
                time = 0,
                message = "",
            }

            local t0 = debugprofilestop()
            local ok, err = pcall(test.func, self)
            local elapsed = debugprofilestop() - t0

            currentResult.time = elapsed
            if not ok then
                currentResult.status = "fail"
                currentResult.message = tostring(err)
            elseif currentResult.status == "pending" then
                currentResult.status = "fail"
                currentResult.message = "test did not call Pass()"
            end

            self.results[#self.results + 1] = currentResult

            -- Per-test output
            local color
            if currentResult.status == "pass" then
                color = "|cFF00FF00"
                passed = passed + 1
            elseif currentResult.status == "skip" then
                color = "|cFFFFFF00"
                skipped = skipped + 1
            else
                color = "|cFFFF4444"
                failed = failed + 1
            end
            local suffix = ""
            if currentResult.message and currentResult.message ~= "" then
                suffix = " -- " .. currentResult.message
            end
            Out(
                color
                    .. string.upper(currentResult.status)
                    .. "|r "
                    .. test.name
                    .. " |cFF888888("
                    .. string.format("%.1f", elapsed)
                    .. "ms)|r"
                    .. suffix
            )
        end
    end

    -- A filter that matched NOTHING must say so, loudly, before the hygiene
    -- audit prints its unconditional PASS. Observed 2026-07-16: a one-letter
    -- typo ("keybin") ran zero tests and the summary still read "1 passed,
    -- 0 failed" -- a green gate with nothing behind it. Category match is
    -- exact by design (substring matching would make "keybind" also run a
    -- hypothetical "keybinds" category); the remedy for a miss is telling
    -- the user what the valid categories are.
    if filter and filter ~= "" and matchedCount == 0 then
        local cats, seen = {}, {}
        for _, test in ipairs(self.tests) do
            if test.category and not seen[test.category] then
                seen[test.category] = true
                cats[#cats + 1] = test.category
            end
        end
        table.sort(cats)
        Out("|cFFFF4444[TestSuite]|r filter '" .. filter .. "' matched 0 registered tests (category match is exact)")
        Out("|cFFFF4444[TestSuite]|r known categories: " .. table.concat(cats, ", "))
    end

    -- Suite-hygiene audit. Lives inside Run() rather than as a registered
    -- test: the TOC loads spec files after this file, so a registered audit
    -- could not be guaranteed to run last. Asserts the per-test teardowns
    -- held (zero residue sequences, zero keybind delta, zero empty
    -- buckets); tempo rows recreated by activations during the run are
    -- reaped mechanically and reported.
    local leftovers = self:_ListResidue()
    local tempoReaped = self:_ReapTempoRows()
    local kbDelta = self:_CountKeybinds() - kbBaseline
    local emptyOverlays = self:_CountEmptyOverlays()
    local mfNow = _G.GRIPEMS_MainFrame
    local mfShownNow = (mfNow and mfNow.IsShown and mfNow:IsShown()) and true or false
    local mfShownDelta = mfShownNow ~= mfShownBaseline
    -- Applied-state invariant: at suite end the live window scale must match
    -- the profile uiScale. Catches the whole class of specs that apply a
    -- scale and restore only the stored value (the 2026-07-16 giant-window
    -- leak). GetScale is compared against GetUIScale because ApplyUIScale
    -- sets exactly that value on every registered panel frame.
    local mfScaleDrift = false
    if mfNow and mfNow.GetScale and GRIPEMS.UI and GRIPEMS.UI.GetUIScale then
        local applied = mfNow:GetScale()
        local stored = GRIPEMS.UI:GetUIScale()
        if type(applied) == "number" and type(stored) == "number" then
            mfScaleDrift = math.abs(applied - stored) > 0.001
        end
    end
    local hygiene = {
        name = "suite hygiene: zero residue, zero keybind delta",
        status = "pass",
        time = 0,
        message = "tempo rows reaped: " .. tempoReaped,
    }
    if #leftovers > 0 or kbDelta ~= 0 or emptyOverlays > 0 or mfShownDelta or mfScaleDrift then
        hygiene.status = "fail"
        local parts = {
            "keybind delta " .. kbDelta,
            "empty buckets " .. emptyOverlays,
            "tempo rows reaped: " .. tempoReaped,
        }
        if mfShownDelta then
            parts[#parts + 1] = "window shown-state changed across the run"
        end
        if mfScaleDrift then
            parts[#parts + 1] = "window scale drifted from profile uiScale"
        end
        if #leftovers > 0 then
            parts[#parts + 1] = table.concat(leftovers, ", ")
        end
        hygiene.message = table.concat(parts, "; ")
    end
    self.results[#self.results + 1] = hygiene
    if hygiene.status == "pass" then
        passed = passed + 1
        Out("|cFF00FF00PASS|r " .. hygiene.name .. " |cFF888888(" .. hygiene.message .. ")|r")
    else
        failed = failed + 1
        Out("|cFFFF4444FAIL|r " .. hygiene.name .. " -- " .. hygiene.message)
    end

    local totalTime = debugprofilestop() - startAll
    local summary = string.format(
        "|cFF00CC66[TestSuite]|r %d passed, %d failed, %d skipped in %.2fs",
        passed,
        failed,
        skipped,
        totalTime / 1000
    )
    Out(summary)
    GRIPEMS:Print(summary)

    -- Auto-record: persist a compact summary of every run into the account
    -- SV as a capped ring (most recent 10 runs, evicted from the front).
    -- Type-guarded so a missing or malformed GRIP_EMS_DB can never error
    -- the runner itself.
    if type(_G.GRIP_EMS_DB) == "table" then
        local runs = _G.GRIP_EMS_DB.testRuns
        if type(runs) ~= "table" then
            runs = {}
            _G.GRIP_EMS_DB.testRuns = runs
        end
        local bad = {}
        for _, r in ipairs(self.results) do
            if r.status ~= "pass" then
                bad[#bad + 1] = r.status .. ":" .. r.name
            end
        end
        local badStr = table.concat(bad, ";")
        if #badStr > 1000 then
            badStr = badStr:sub(1, 1000)
        end
        runs[#runs + 1] = {
            t = date("%Y-%m-%d %H:%M:%S"),
            filter = filter or "all",
            passed = passed,
            failed = failed,
            skipped = skipped,
            bad = badStr,
        }
        while #runs > 10 do
            table.remove(runs, 1)
        end
    end

    if GRIPEMS.Trace then
        GRIPEMS.Trace._suspend = nil
    end
    self._running = nil
end

-- ===========================================================================
-- BUILT-IN TESTS
-- ===========================================================================

-- ---------------------------------------------------------------------------
-- Category: crud -- Sequence CRUD
-- ---------------------------------------------------------------------------

TS:Register("Create sequence via Core API", "crud", function(self)
    if self:_SkipIfCombat() then
        return
    end
    local D = GRIPEMS.Defaults
    local Engine = GRIPEMS.Engine
    if not D or not Engine then
        self:Fail("Defaults or Engine not loaded")
        return
    end

    local name = "_TS_CrudCreate"
    -- Clean up if leftover from a previous run
    if Engine.sequences[name] then
        Engine:DeactivateSequence(name)
    end

    local seqData = D.NewSequenceFromTemplate(name, D.TestSequence)
    Engine:ActivateSequence(name, seqData)

    if Engine.sequences[name] then
        self:Pass()
    else
        self:Fail("sequence not found after ActivateSequence")
    end

    -- Cleanup
    Engine:DeactivateSequence(name)
end)

TS:Register("Delete sequence, verify removal", "crud", function(self)
    if self:_SkipIfCombat() then
        return
    end
    local D = GRIPEMS.Defaults
    local Engine = GRIPEMS.Engine
    if not D or not Engine then
        self:Fail("Defaults or Engine not loaded")
        return
    end

    local name = "_TS_CrudDelete"
    if Engine.sequences[name] then
        Engine:DeactivateSequence(name)
    end

    local seqData = D.NewSequenceFromTemplate(name, D.TestSequence)
    Engine:ActivateSequence(name, seqData)
    Engine:DeactivateSequence(name)

    if Engine.sequences[name] then
        self:Fail("sequence still present after DeactivateSequence")
    else
        self:Pass()
    end
end)

TS:Register("Rename sequence (deactivate old, activate new)", "crud", function(self)
    if self:_SkipIfCombat() then
        return
    end
    local D = GRIPEMS.Defaults
    local Engine = GRIPEMS.Engine
    if not D or not Engine then
        self:Fail("Defaults or Engine not loaded")
        return
    end

    local oldName = "_TS_CrudRenameOld"
    local newName = "_TS_CrudRenameNew"
    -- Clean up leftovers
    if Engine.sequences[oldName] then
        Engine:DeactivateSequence(oldName)
    end
    if Engine.sequences[newName] then
        Engine:DeactivateSequence(newName)
    end

    local seqData = D.NewSequenceFromTemplate(oldName, D.TestSequence)
    Engine:ActivateSequence(oldName, seqData)

    -- Rename = deactivate old, re-activate under new name
    local data = Engine.sequences[oldName] and Engine.sequences[oldName].data
    if not data then
        self:Fail("could not read sequence data for rename")
        return
    end
    Engine:DeactivateSequence(oldName)
    data.name = newName
    Engine:ActivateSequence(newName, data)

    local oldGone = not Engine.sequences[oldName]
    local newPresent = Engine.sequences[newName] ~= nil
    if oldGone and newPresent then
        self:Pass()
    else
        self:Fail("oldGone=" .. tostring(oldGone) .. " newPresent=" .. tostring(newPresent))
    end

    -- Cleanup
    Engine:DeactivateSequence(newName)
end)

-- ---------------------------------------------------------------------------
-- Category: import -- Import/Export round-trip
-- ---------------------------------------------------------------------------

TS:Register("EMS1 native export/import round-trip", "import", function(self)
    if self:_SkipIfCombat() then
        return
    end
    local D = GRIPEMS.Defaults
    local Engine = GRIPEMS.Engine
    local GE = GRIPEMS.GRIPExport
    if not D or not Engine or not GE then
        self:Fail("Defaults, Engine, or GRIPExport not loaded")
        return
    end

    local name = "_TS_ImportRoundTrip"
    if Engine.sequences[name] then
        Engine:DeactivateSequence(name)
    end

    local seqData = D.NewSequenceFromTemplate(name, D.TestSequence)
    seqData.versions[1].steps = { "/cast Fireball", "/cast Frostbolt" }
    Engine:ActivateSequence(name, seqData)

    -- Export
    local okExp, encoded = GE.Export(name)
    Engine:DeactivateSequence(name)
    if not okExp then
        self:Fail("export failed: " .. tostring(encoded))
        return
    end

    -- Import
    local okImp, impName, impData = GE.ImportNative(encoded)
    if not okImp then
        self:Fail("import failed: " .. tostring(impName))
        return
    end

    -- Verify step content matches
    local impVer = impData and impData.versions and impData.versions[1]
    if not impVer or not impVer.steps then
        self:Fail("imported data has no version/steps")
        return
    end
    if #impVer.steps ~= 2 then
        self:Fail("expected 2 steps, got " .. #impVer.steps)
        return
    end

    self:Pass()
end)

-- ---------------------------------------------------------------------------
-- Category: import -- ARCH-MIGRATE Phase 3 round-trip (repeatCount + Loop node)
-- ---------------------------------------------------------------------------

TS:Register("EMS1 round-trip preserves repeatCount + Loop nodes", "import", function(self)
    if self:_SkipIfCombat() then
        return
    end
    local D = GRIPEMS.Defaults
    local Engine = GRIPEMS.Engine
    local GE = GRIPEMS.GRIPExport
    if not D or not Engine or not GE then
        self:Fail("Defaults, Engine, or GRIPExport not loaded")
        return
    end

    local name = "_TS_RepeatLoopRoundTrip"
    if Engine.sequences[name] then
        Engine:DeactivateSequence(name)
    end

    local seqData = D.NewSequenceFromTemplate(name, D.TestSequence)
    local v1 = seqData.versions[1]
    v1.steps = { "/cast Fireball", "/cast Frostbolt" }
    v1.repeatCount = 3
    v1.actions = {
        {
            type = D.ACTION_TYPE_LOOP,
            ["repeat"] = 2,
            stepFunction = D.STEP_SEQUENTIAL,
            children = {
                { type = D.ACTION_TYPE_ACTION, macro = "/cast Fireball" },
                { type = D.ACTION_TYPE_ACTION, macro = "/cast Frostbolt" },
            },
        },
    }
    Engine:ActivateSequence(name, seqData)

    local okExp, encoded = GE.Export(name)
    Engine:DeactivateSequence(name)
    if not okExp then
        self:Fail("export failed: " .. tostring(encoded))
        return
    end

    local okImp, impName, impData = GE.ImportNative(encoded)
    if not okImp then
        self:Fail("import failed: " .. tostring(impName))
        return
    end

    local impVer = impData and impData.versions and impData.versions[1]
    if not impVer then
        self:Fail("imported data has no version")
        return
    end

    if impVer.repeatCount ~= 3 then
        self:Fail("repeatCount lost: expected 3, got " .. tostring(impVer.repeatCount))
        return
    end

    local acts = impVer.actions
    if not acts or not acts[1] then
        self:Fail("action tree lost on round-trip")
        return
    end
    local loop = acts[1]
    if loop.type ~= D.ACTION_TYPE_LOOP then
        self:Fail("node 1 type expected loop, got " .. tostring(loop.type))
        return
    end
    if loop["repeat"] ~= 2 then
        self:Fail("loop repeat lost: expected 2, got " .. tostring(loop["repeat"]))
        return
    end
    if not loop.children or #loop.children ~= 2 then
        self:Fail("loop children lost: expected 2, got " .. tostring(loop.children and #loop.children))
        return
    end

    self:Pass()
end)

-- ---------------------------------------------------------------------------
-- Category: import -- EMS1-IMPORT-PROVENANCE-CARRY
-- The native commit path (BuildSeqDataFromGRIP1 in ImportPreview.lua) and
-- the test-only GE.ImportNative rail both carry the v2.1.0 provenance block
-- from the wire payload onto the committed sequence. These fixtures pin:
-- (a) export -> ImportNative round-trip preserves every carried field,
-- (b) the Preview + CommitSelected rail lands the same fields for BOTH
--     BuildSeqDataFromGRIP1 call-site shapes (collection entry: seqObj IS
--     the sequence payload; single entry: seqObj.sequence is),
-- (c) a payload without originalAuthor commits with provenance fields nil
--     (the one-shot repair pass in Core/Core.lua owns that family),
-- (d) an inbound originalAuthorBattleTag never lands (LOCAL ONLY field).
-- ---------------------------------------------------------------------------

-- Stamp the full v2.1.0 provenance fixture block onto a sequence table.
-- One prior chain entry + one fork ancestor, so length assertions can
-- distinguish "carried" from "rebuilt" on the import side.
local function provStampFixture(seq)
    seq.originalAuthor = "Provenancia"
    seq.originalAuthorIdentity = "tsprovhash00000001"
    seq.originalAuthorRealm = "TestRealm"
    seq.originalCreatedAt = 1700000000
    seq.originalSignature = "tsprovsig0001"
    seq.signatureAlgorithm = "ALG_V0_DJB2"
    seq.lastModifier = "Provenancia"
    seq.lastModifierIdentity = "tsprovhash00000001"
    seq.lastModifierRealm = "TestRealm"
    seq.lastModifiedAt = 1700000100
    seq.modifierChain = {
        {
            name = "Provenancia",
            identity = "tsprovhash00000001",
            realm = "TestRealm",
            at = 1700000100,
            kind = "edited",
        },
    }
    seq.forkedFrom = {
        originalAuthor = "Ancestoria",
        originalAuthorIdentity = "tsancestorhash01",
    }
    seq.forkedFromChain = {
        { originalAuthor = "Ancestoria", originalAuthorIdentity = "tsancestorhash01" },
    }
    seq.provenanceSource = "native"
    seq.privacyMode = "public"
end

-- Shared post-import assertions: the carried fields plus the single
-- "imported" chain entry the carry appends. Returns early on first fail
-- via the caller's currentResult check.
local function provAssertCarried(self, data, label)
    self:AssertEqual("Provenancia", data.originalAuthor, label .. ": originalAuthor carried")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("native", data.provenanceSource, label .. ": provenanceSource carried")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("tsprovsig0001", data.originalSignature, label .. ": originalSignature carried")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("public", data.privacyMode, label .. ": privacyMode carried")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("ALG_V0_DJB2", data.signatureAlgorithm, label .. ": signatureAlgorithm carried")
    if currentResult.status == "fail" then
        return
    end
    -- Wire chain had one entry; the carry appends exactly one import stamp.
    self:AssertEqual(2, data.modifierChain and #data.modifierChain, label .. ": modifierChain is wire length + 1")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(
        "imported",
        data.modifierChain and data.modifierChain[2] and data.modifierChain[2].kind,
        label .. ": appended chain entry is the import stamp"
    )
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(1, data.forkedFromChain and #data.forkedFromChain, label .. ": forkedFromChain carried")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(
        "Ancestoria",
        data.forkedFromChain and data.forkedFromChain[1] and data.forkedFromChain[1].originalAuthor,
        label .. ": fork ancestor attribution carried"
    )
    if currentResult.status == "fail" then
        return
    end
    self:Assert(data.forkedFrom ~= nil, label .. ": forkedFrom reference carried")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(nil, data.originalAuthorBattleTag, label .. ": BattleTag never lands from the wire")
end

TS:Register("EMS1 round-trip preserves provenance fields", "import", function(self)
    if self:_SkipIfCombat() then
        return
    end
    local D = GRIPEMS.Defaults
    local Engine = GRIPEMS.Engine
    local GE = GRIPEMS.GRIPExport
    local Identity = GRIPEMS.Identity
    if not D or not Engine or not GE or not Identity then
        self:Fail("Defaults, Engine, GRIPExport, or Identity not loaded")
        return
    end

    local name = "_TS_ProvRoundTrip"
    if Engine.sequences[name] then
        Engine:DeactivateSequence(name)
    end

    -- Author-side fixture: a sequence that already carries the full
    -- provenance block. Public privacy mode, so the export-side scrub is
    -- a pass-through and the wire carries the fields verbatim.
    local seqData = D.NewSequenceFromTemplate(name, D.TestSequence)
    seqData.versions[1].steps = { "/cast Fireball" }
    provStampFixture(seqData)
    Engine:ActivateSequence(name, seqData)

    local okExp, encoded = GE.Export(name)
    Engine:DeactivateSequence(name)
    if not okExp then
        self:Fail("export failed: " .. tostring(encoded))
        return
    end

    local okImp, impName, impData = GE.ImportNative(encoded)
    if not okImp then
        self:Fail("import failed: " .. tostring(impName))
        return
    end

    provAssertCarried(self, impData, "round-trip")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("EMS1 commit rail carries provenance (single-sequence shape)", "import", function(self)
    local D = GRIPEMS.Defaults
    local Engine = GRIPEMS.Engine
    local GE = GRIPEMS.GRIPExport
    local LI = GRIPEMS.LegacyImport
    local Identity = GRIPEMS.Identity
    if not D or not Engine or not GE or not LI or not Identity then
        self:Fail("Defaults, Engine, GRIPExport, LegacyImport, or Identity not loaded")
        return
    end

    -- Commit activates the sequence through the engine; in combat that
    -- defers via OOCQueue and teardown cannot complete. Same guard as the
    -- FRG1 commit-rail test.
    local OOC = GRIPEMS.OOCQueue
    if OOC and OOC.IsRestricted() then
        self:Skip("in combat -- commit activation defers; teardown cannot complete")
        return
    end

    local name = "_TS_ProvCommitSingle"
    if Engine.sequences[name] then
        Engine:DeactivateSequence(name)
    end

    -- Real exporter output, so the fixture has exactly the wire field set
    -- (notably NO originalAuthorBattleTag -- the exporter never ships it).
    local seqData = D.NewSequenceFromTemplate(name, D.TestSequence)
    seqData.versions[1].steps = { "/cast Fireball" }
    provStampFixture(seqData)
    Engine:ActivateSequence(name, seqData)
    local okExp, encoded = GE.Export(name)
    Engine:DeactivateSequence(name)
    if not okExp then
        self:Fail("export failed: " .. tostring(encoded))
        return
    end

    -- Single-sequence wire shape: entry.seqObj is the WHOLE payload and
    -- CommitSelected hands entry.seqObj.sequence to BuildSeqDataFromGRIP1
    -- (the second call site).
    local preview = LI.Preview(encoded)
    if not preview or not preview.ok then
        self:Fail("preview failed: " .. tostring(preview and preview.error))
        return
    end
    self:AssertEqual("GRIP1", preview.format, "native preview format is GRIP1")
    if currentResult.status == "fail" then
        return
    end
    local entry = preview.sequences and preview.sequences[1]
    self:Assert(entry ~= nil and not entry.isCollection, "preview entry is the single-sequence shape")
    if currentResult.status == "fail" then
        return
    end

    local selections = { sequences = { [1] = { selected = true, action = "import" } }, variables = {} }
    local okCommit = LI.CommitSelected(preview, selections)
    self:Assert(okCommit == true, "CommitSelected succeeds")
    if currentResult.status == "fail" then
        return
    end

    local data = Engine.sequences[name] and Engine.sequences[name].data
    self:Assert(data ~= nil, "committed sequence registered in engine")
    if currentResult.status ~= "fail" and data then
        provAssertCarried(self, data, "single-shape commit")
    end

    -- Teardown through the engine. ActivateSequence persisted a char store
    -- row; DeactivateSequence removes it, and the explicit clear below keeps
    -- the suite residue-free even if that contract shifts.
    if Engine.sequences[name] then
        Engine:DeactivateSequence(name)
    end
    if _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.sequences then
        GRIP_EMS_CHAR.sequences[name] = nil
    end
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("EMS1 commit rail carries provenance (collection shape)", "import", function(self)
    local D = GRIPEMS.Defaults
    local Engine = GRIPEMS.Engine
    local LI = GRIPEMS.LegacyImport
    local S = GRIPEMS.Serialization
    local Identity = GRIPEMS.Identity
    if not D or not Engine or not LI or not S or not Identity then
        self:Fail("Defaults, Engine, LegacyImport, Serialization, or Identity not loaded")
        return
    end

    local OOC = GRIPEMS.OOCQueue
    if OOC and OOC.IsRestricted() then
        self:Skip("in combat -- commit activation defers; teardown cannot complete")
        return
    end

    local name = "_TS_ProvCommitCol"
    if Engine.sequences[name] then
        Engine:DeactivateSequence(name)
    end

    -- Hand-crafted COLLECTION wire payload: the entry's seqObj IS the
    -- sequence payload (the first BuildSeqDataFromGRIP1 call site).
    -- Deliberately minimal -- no help/helplink/createdAt/updatedAt/
    -- contextOverrides -- so the commit-side defaults are exercised, and
    -- with an inbound originalAuthorBattleTag the carry must discard.
    local seqPayload = {
        versions = {
            [1] = {
                steps = { "/cast Fireball" },
                stepFunction = D.STEP_SEQUENTIAL,
            },
        },
        defaultVersion = 1,
        author = "Provenancia",
    }
    provStampFixture(seqPayload)
    seqPayload.originalAuthorBattleTag = "Inbound#1234"
    local payload = {
        format = "GRIP-EMS",
        version = D.GRIP_FORMAT_VERSION,
        locale = GetLocale(),
        type = "COLLECTION",
        sequences = {
            [name] = seqPayload,
        },
    }
    local encOk, encoded = S.Encode(payload, D.EMS1_PREFIX)
    if not encOk then
        self:Fail("encode failed: " .. tostring(encoded))
        return
    end

    local preview = LI.Preview(encoded)
    if not preview or not preview.ok then
        self:Fail("preview failed: " .. tostring(preview and preview.error))
        return
    end
    local entry = preview.sequences and preview.sequences[1]
    self:Assert(entry ~= nil and entry.isCollection == true, "preview entry is the collection shape")
    if currentResult.status == "fail" then
        return
    end

    local selections = { sequences = { [1] = { selected = true, action = "import" } }, variables = {} }
    local okCommit = LI.CommitSelected(preview, selections)
    self:Assert(okCommit == true, "CommitSelected succeeds")
    if currentResult.status == "fail" then
        return
    end

    local data = Engine.sequences[name] and Engine.sequences[name].data
    self:Assert(data ~= nil, "committed sequence registered in engine")
    if currentResult.status ~= "fail" and data then
        provAssertCarried(self, data, "collection-shape commit")
    end

    -- Teardown: the collection branch also writes the char store row.
    if Engine.sequences[name] then
        Engine:DeactivateSequence(name)
    end
    if _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.sequences then
        GRIP_EMS_CHAR.sequences[name] = nil
    end
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("EMS1 import without provenance leaves fields nil", "import", function(self)
    local D = GRIPEMS.Defaults
    local Engine = GRIPEMS.Engine
    local GE = GRIPEMS.GRIPExport
    local LI = GRIPEMS.LegacyImport
    local S = GRIPEMS.Serialization
    if not D or not Engine or not GE or not LI or not S then
        self:Fail("Defaults, Engine, GRIPExport, LegacyImport, or Serialization not loaded")
        return
    end

    local OOC = GRIPEMS.OOCQueue
    if OOC and OOC.IsRestricted() then
        self:Skip("in combat -- commit activation defers; teardown cannot complete")
        return
    end

    local name = "_TS_ProvAbsent"
    if Engine.sequences[name] then
        Engine:DeactivateSequence(name)
    end

    -- Pre-provenance wire payload: no originalAuthor anywhere. The carry
    -- guard must not fire; every provenance field stays nil so the
    -- one-shot repair pass in Core/Core.lua stamps the no-provenance
    -- family on next load (contract unchanged).
    local payload = {
        format = "GRIP-EMS",
        version = D.GRIP_FORMAT_VERSION,
        locale = GetLocale(),
        name = name,
        sequence = {
            versions = {
                [1] = {
                    steps = { "/cast Fireball" },
                    stepFunction = D.STEP_SEQUENTIAL,
                },
            },
            defaultVersion = 1,
            author = "Someone",
        },
    }
    local encOk, encoded = S.Encode(payload, D.EMS1_PREFIX)
    if not encOk then
        self:Fail("encode failed: " .. tostring(encoded))
        return
    end

    -- Parity rail first: ImportNative must leave the fields nil too.
    local okImp, impName, impData = GE.ImportNative(encoded)
    if not okImp then
        self:Fail("import failed: " .. tostring(impName))
        return
    end
    self:Assert(
        impData.originalAuthor == nil
            and impData.provenanceSource == nil
            and impData.modifierChain == nil
            and impData.forkedFromChain == nil,
        "ImportNative leaves provenance fields nil"
    )
    if currentResult.status == "fail" then
        return
    end

    -- Commit rail: same payload through Preview + CommitSelected.
    local preview = LI.Preview(encoded)
    if not preview or not preview.ok then
        self:Fail("preview failed: " .. tostring(preview and preview.error))
        return
    end
    local selections = { sequences = { [1] = { selected = true, action = "import" } }, variables = {} }
    local okCommit = LI.CommitSelected(preview, selections)
    self:Assert(okCommit == true, "CommitSelected succeeds")
    if currentResult.status == "fail" then
        return
    end

    local data = Engine.sequences[name] and Engine.sequences[name].data
    self:Assert(data ~= nil, "committed sequence registered in engine")
    if currentResult.status ~= "fail" and data then
        self:AssertEqual(nil, data.originalAuthor, "originalAuthor stays nil")
    end
    if currentResult.status ~= "fail" and data then
        self:AssertEqual(nil, data.provenanceSource, "provenanceSource stays nil")
    end
    if currentResult.status ~= "fail" and data then
        self:AssertEqual(nil, data.originalSignature, "originalSignature stays nil")
    end
    if currentResult.status ~= "fail" and data then
        self:AssertEqual(nil, data.modifierChain, "modifierChain stays nil")
    end
    if currentResult.status ~= "fail" and data then
        self:AssertEqual(nil, data.forkedFromChain, "forkedFromChain stays nil")
    end
    if currentResult.status ~= "fail" and data then
        self:AssertEqual(nil, data.privacyMode, "privacyMode stays nil")
    end
    if currentResult.status ~= "fail" and data then
        self:AssertEqual(nil, data.signatureAlgorithm, "signatureAlgorithm stays nil")
    end

    if Engine.sequences[name] then
        Engine:DeactivateSequence(name)
    end
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

-- ---------------------------------------------------------------------------
-- Category: arch-migrate -- ARCH-MIGRATE-LOOP-PRESERVATION Phase 4
-- Native-vs-import parity regression fences. Each fixture documents a
-- deliberate, already-shipped difference between the flat import compile
-- path (LI.CompileMacroVersion -> baked steps) and the activation-time tree
-- recompile path (AC.CompileActions over LI.MapLegacyActionsToTree nodes).
-- They are regression fences, not bug fixes: each asserts a known gap
-- (GAP-01..GAP-07) stays exactly as designed. The Phase 1 import-baked gate
-- (ver.importBakedSteps) keeps baked steps authoritative for imports, which
-- is why these differences are safe to ship.
-- ---------------------------------------------------------------------------

-- Tally exact-match occurrences of a macro string in a flat steps array.
-- Plain equality (no pattern matching) so interleave copies count exactly.
local function archCountSteps(steps, needle)
    local n = 0
    for _, step in ipairs(steps) do
        if step == needle then
            n = n + 1
        end
    end
    return n
end

TS:Register("mid-array Repeat weaves identically flat-vs-tree (GAP-01)", "arch-migrate", function(self)
    local LI = GRIPEMS.LegacyImport
    local AC = GRIPEMS.ActionCompiler
    if not LI or not AC then
        self:Fail("LegacyImport or ActionCompiler not loaded")
        return
    end
    -- GAP-01: a Repeat at a mid-array index (neither first nor last slot, so
    -- the edge in-place rule does NOT fire) now weaves through
    -- the shared ActionCompiler helper in BOTH paths. The flat import bake and
    -- the tree recompile produce byte-identical steps, so importing then
    -- editing a sequence cannot change the rotation. The Repeat is woven only;
    -- it is never emitted as an in-line base step at its source position.
    local legacyActions = {
        { Type = "spell", Spell = "Fireball" },
        { Type = "Repeat", macro = "/cast Shoot", Interval = 2 },
        { Type = "spell", Spell = "Frostbolt" },
        { Type = "spell", Spell = "Pyroblast" },
    }

    local flat = LI.CompileMacroVersion({ Actions = legacyActions })
    local tree = LI.MapLegacyActionsToTree(legacyActions)
    local steps = AC.CompileActions(tree, nil)

    self:AssertEqual(#steps, #flat.steps, "flat bake and tree recompile have the same step count")
    if currentResult.status == "fail" then
        return
    end
    for i = 1, #steps do
        if flat.steps[i] ~= steps[i] then
            self:Fail("flat-vs-tree divergence at step " .. i)
            return
        end
    end

    -- The Repeat is woven, not placed at its source slot 2.
    self:Assert(flat.steps[2] ~= "/cast Shoot", "Repeat is not emitted as an in-line base at slot 2")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(archCountSteps(flat.steps, "/cast Shoot") >= 1, "the Repeat is woven at least once")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("interleaves space against original indices, independent (INTERLEAVE-INDEP)", "arch-migrate", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    -- Eight base steps plus two interleaves at different intervals. Each
    -- interleave must space against the ORIGINAL eight, independent of the
    -- other: interval 4 -> 2 copies (after base 4, 8); interval 2 -> 4
    -- copies (after base 2, 4, 6, 8). The pre-fix in-place loop drifted the
    -- second interleave because it counted the first's inserted copies.
    local tree = {
        { type = D.ACTION_TYPE_ACTION, macro = "/cast B1" },
        { type = D.ACTION_TYPE_ACTION, macro = "/cast B2" },
        { type = D.ACTION_TYPE_ACTION, macro = "/cast B3" },
        { type = D.ACTION_TYPE_ACTION, macro = "/cast B4" },
        { type = D.ACTION_TYPE_ACTION, macro = "/cast B5" },
        { type = D.ACTION_TYPE_ACTION, macro = "/cast B6" },
        { type = D.ACTION_TYPE_ACTION, macro = "/cast B7" },
        { type = D.ACTION_TYPE_ACTION, macro = "/cast B8" },
        { type = D.ACTION_TYPE_ACTION, macro = "/cast IA", interval = 4 },
        { type = D.ACTION_TYPE_ACTION, macro = "/cast IB", interval = 2 },
    }
    local steps = AC.CompileActions(tree, nil)
    self:AssertEqual(2, archCountSteps(steps, "/cast IA"), "interval 4 yields 2 copies over 8 base steps")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(4, archCountSteps(steps, "/cast IB"), "interval 2 yields 4 copies, not drifted by IA")
    if currentResult.status == "fail" then
        return
    end
    for i = 1, 8 do
        if archCountSteps(steps, "/cast B" .. i) ~= 1 then
            self:Fail("base step /cast B" .. i .. " not present exactly once")
            return
        end
    end
    self:AssertEqual(14, #steps, "8 base + 2 + 4 interleave copies = 14 steps")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register(
    "stacking eight interleaves stays bounded and well-formed (INTERLEAVE-STACK8)",
    "arch-migrate",
    function(self)
        local AC = GRIPEMS.ActionCompiler
        local D = GRIPEMS.Defaults
        if not AC or not D then
            self:Fail("ActionCompiler or Defaults not loaded")
            return
        end
        -- The reported repro shape: a sequence with many interleaved steps (the
        -- Prot Warrior M+ case stacked eight). Confirm the compile stays bounded,
        -- keeps every base step, and produces no nil holes -- a hole is what
        -- breaks the runtime step cycle and stops the keybind firing.
        local tree = {}
        for i = 1, 8 do
            tree[i] = { type = D.ACTION_TYPE_ACTION, macro = "/cast Base" .. i }
        end
        for i = 1, 8 do
            tree[#tree + 1] = { type = D.ACTION_TYPE_ACTION, macro = "/cast IL" .. i, interval = 2 }
        end
        local steps = AC.CompileActions(tree, nil)
        for i = 1, 8 do
            if archCountSteps(steps, "/cast Base" .. i) ~= 1 then
                self:Fail("base step /cast Base" .. i .. " missing after stacking interleaves")
                return
            end
        end
        local dense = true
        for i = 1, #steps do
            if steps[i] == nil then
                dense = false
            end
        end
        self:Assert(dense, "compiled steps array has no nil holes")
        if currentResult.status == "fail" then
            return
        end
        self:Assert(#steps <= 8 + 200, "expanded step count stays within the insert cap")
        if currentResult.status == "fail" then
            return
        end
        self:Pass()
    end
)

TS:Register("interleave expansion honors the MAX_INSERTED cap (INTERLEAVE-CAP)", "arch-migrate", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    -- Pathological input: 50 base steps plus 12 small-interval interleaves
    -- request far more than 200 copies. The cap holds the total inserted at
    -- 200, originals are never dropped, and the result stays dense.
    local tree = {}
    for i = 1, 50 do
        tree[i] = { type = D.ACTION_TYPE_ACTION, macro = "/cast S" .. i }
    end
    for i = 1, 12 do
        tree[#tree + 1] = { type = D.ACTION_TYPE_ACTION, macro = "/cast X" .. i, interval = D.ACTION_INTERLEAVE_MIN }
    end
    local steps = AC.CompileActions(tree, nil)
    for i = 1, 50 do
        if archCountSteps(steps, "/cast S" .. i) ~= 1 then
            self:Fail("original step /cast S" .. i .. " dropped")
            return
        end
    end
    self:Assert(#steps <= 250, "total inserted copies capped at MAX_INSERTED (50 + 200)")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(#steps >= 50, "all originals retained")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("Repeat interval clamp tree-build and flat-weave (GAP-02)", "arch-migrate", function(self)
    local LI = GRIPEMS.LegacyImport
    local D = GRIPEMS.Defaults
    if not LI or not D then
        self:Fail("LegacyImport or Defaults not loaded")
        return
    end
    -- GAP-02: the tree builder clamps a Repeat interval to [MIN, MAX]. The flat
    -- import bake now weaves through the same shared helper, which applies the
    -- same clamp. Sub-MIN clamps up to MIN, over-MAX clamps down to MAX.
    local lowArr = {
        { Type = "spell", Spell = "Fireball" },
        { Type = "Repeat", macro = "/cast R", Interval = 0 },
        { Type = "spell", Spell = "Frostbolt" },
        { Type = "spell", Spell = "Pyroblast" },
    }
    local lowTree = LI.MapLegacyActionsToTree(lowArr)
    self:AssertEqual(D.ACTION_INTERLEAVE_MIN, lowTree[2].interval, "sub-MIN interval clamps up to MIN")
    if currentResult.status == "fail" then
        return
    end

    local highArr = {
        { Type = "spell", Spell = "Fireball" },
        { Type = "Repeat", macro = "/cast R", Interval = 60 },
        { Type = "spell", Spell = "Frostbolt" },
        { Type = "spell", Spell = "Pyroblast" },
    }
    local highTree = LI.MapLegacyActionsToTree(highArr)
    self:AssertEqual(D.ACTION_INTERLEAVE_MAX, highTree[2].interval, "over-MAX interval clamps down to MAX")
    if currentResult.status == "fail" then
        return
    end

    -- Flat path weaves "/cast R" through the shared helper, which clamps the
    -- sub-MIN interval up to MIN, so the base appears more than once in the
    -- baked steps.
    local flat = LI.CompileMacroVersion({ Actions = lowArr })
    local base = "/cast R"
    self:Assert(archCountSteps(flat.steps, base) > 1, "flat weaves the base at the clamped interval")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("embed flat-skip vs tree-inline (GAP-03)", "arch-migrate", function(self)
    local LI = GRIPEMS.LegacyImport
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not LI or not AC or not D then
        self:Fail("LegacyImport, ActionCompiler, or Defaults not loaded")
        return
    end
    -- GAP-03: the flat import skips an Embed with a warning (zero baked
    -- steps); the tree recompile inlines the embed target's current steps,
    -- or zero steps when the target sequence is not loaded.
    local flat = LI.CompileMacroVersion({ Actions = { { Type = "Embed", Sequence = "_TS_EmbedTarget" } } })
    self:AssertEqual(0, #flat.steps, "flat embed contributes zero baked steps")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(#flat.warnings >= 1, "flat embed emits a skip warning")
    if currentResult.status == "fail" then
        return
    end

    -- Tree inline: mock engine exposes the embed target's steps.
    local mockEngine = {
        sequences = {
            ["_TS_EmbedTarget"] = { data = { steps = { "/cast A", "/cast B", "/cast C" } } },
        },
    }
    mockEngine.GetActiveVersion = function(_, data)
        return data
    end
    local node = { type = D.ACTION_TYPE_EMBED, sequence = "_TS_EmbedTarget" }
    local steps = AC.CompileActions({ node }, mockEngine)
    self:AssertEqual(3, #steps, "tree inlines the embed target's current steps")
    if currentResult.status == "fail" then
        return
    end

    local missing = AC.CompileActions({ node }, { sequences = {} })
    self:AssertEqual(0, #missing, "tree embed yields zero steps when the target is not loaded")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("unknown variable flat-drop vs tree-carry + runtime no-op (GAP-04)", "arch-migrate", function(self)
    local LI = GRIPEMS.LegacyImport
    local AC = GRIPEMS.ActionCompiler
    if not LI or not AC then
        self:Fail("LegacyImport or ActionCompiler not loaded")
        return
    end
    -- GAP-04: an unknown variable (no matching definition) is dropped from
    -- the flat baked steps but carried by the tree as a /run ~name~ token.
    -- At runtime the unresolved token substitutes to empty string (no crash).
    local flat = LI.CompileMacroVersion({ Actions = { { Type = "Variable", Variable = "_TS_NoSuchVar" } } })
    self:AssertEqual(0, #flat.steps, "flat drops the unknown variable from baked steps")
    if currentResult.status == "fail" then
        return
    end

    local tree = LI.MapLegacyActionsToTree({ { Type = "Variable", Variable = "_TS_NoSuchVar" } })
    local steps = AC.CompileActions(tree, nil)
    local carried = false
    for _, step in ipairs(steps) do
        if step:find("~_TS_NoSuchVar~", 1, true) then
            carried = true
            break
        end
    end
    self:Assert(carried, "tree carries the variable token the flat path dropped")
    if currentResult.status == "fail" then
        return
    end

    -- Runtime probe: an unresolved ~var~ substitutes to empty string.
    local Engine = GRIPEMS.Engine
    if GRIPEMS.VariableStore and Engine and Engine.SubstituteVariables then
        local out = Engine:SubstituteVariables("/run ~_TS_NoSuchVar~")
        self:Assert(out:find("~", 1, true) == nil, "unresolved token resolves to empty (no leftover ~)")
        if currentResult.status == "fail" then
            return
        end
        self:Pass()
    else
        self:Skip("VariableStore or Engine substitution not loaded")
    end
end)

TS:Register("loop ReversePriority triangle vs flat sequential (GAP-06)", "arch-migrate", function(self)
    local LI = GRIPEMS.LegacyImport
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not LI or not AC or not D then
        self:Fail("LegacyImport, ActionCompiler, or Defaults not loaded")
        return
    end
    -- GAP-06: the flat import demotes a Loop to plain sequential expansion
    -- (children x repeat, StepFunction ignored). The tree recompile honors
    -- ReversePriority AND repeat: it builds the descending triangle
    -- (1+2+3 = 6) once per repeat (x3 = 18). Flat-vs-tree still diverges for
    -- RP loops because the flat importer ignores StepFunction (pre-existing).
    local flat = LI.CompileMacroVersion({
        Actions = {
            {
                Type = "Loop",
                StepFunction = "ReversePriority",
                Repeat = 3,
                Actions = {
                    { Type = "spell", Spell = "Fireball" },
                    { Type = "spell", Spell = "Frostbolt" },
                    { Type = "spell", Spell = "Pyroblast" },
                },
            },
        },
    })
    self:AssertEqual(9, #flat.steps, "flat expands children sequentially x repeat (3 x 3)")
    if currentResult.status == "fail" then
        return
    end

    local node = {
        type = D.ACTION_TYPE_LOOP,
        ["repeat"] = 3,
        stepFunction = D.STEP_REVERSE_PRIORITY,
        children = {
            { type = D.ACTION_TYPE_ACTION, macro = "/cast Fireball" },
            { type = D.ACTION_TYPE_ACTION, macro = "/cast Frostbolt" },
            { type = D.ACTION_TYPE_ACTION, macro = "/cast Pyroblast" },
        },
    }
    local steps = AC.CompileActions({ node }, nil)
    self:AssertEqual(18, #steps, "tree builds the reverse-priority triangle (1+2+3) once per repeat (x3 = 18)")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("SimulateSteps reflects compiled Priority loop repeat", "engine", function(self)
    local AC = GRIPEMS.ActionCompiler
    local E = GRIPEMS.Engine
    local D = GRIPEMS.Defaults
    if not AC or not E or not D then
        self:Fail("ActionCompiler, Engine, or Defaults not loaded")
        return
    end
    local loopNode = {
        type = D.ACTION_TYPE_LOOP,
        stepFunction = D.STEP_PRIORITY,
        ["repeat"] = 2,
        children = {
            { type = D.ACTION_TYPE_ACTION, macro = "/cast Alpha" },
        },
    }
    local compiled = AC.CompileActions({ loopNode }, E, {})
    self:Assert(#compiled >= 2, "1-child Priority loop x repeat 2 compiles to at least 2 steps")
    if currentResult.status == "fail" then
        return
    end
    local n = #compiled
    local sim = E:SimulateSteps(compiled, D.STEP_SEQUENTIAL, n * 2)
    self:AssertEqual(n * 2, #sim, "SimulateSteps yields count entries from the compiled steps")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(1, sim[1].stepIndex, "first simulated step index is 1")
    self:AssertEqual(1, sim[n + 1].stepIndex, "round-robin wraps to step 1 after n compiled steps")
    self:Assert(sim[1].macrotext == sim[n + 1].macrotext, "wrap repeats the same macrotext")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("import-baked gate prevents taggedSteps desync (GAP-07)", "arch-migrate", function(self)
    local SC = GRIPEMS.SpellCache
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    if not SC or not SC.NormalizeVersionLocale then
        self:Skip("SpellCache normalizer not loaded")
        return
    end
    -- GAP-07: an ungated activation recompile replaces ver.steps and leaves
    -- ver.taggedSteps describing the old array (a length desync). The
    -- importBakedSteps gate skips that recompile, so the locale sidecars
    -- stay aligned with the baked steps. Build a version whose tree
    -- recompiles to a different step count than its baked steps.
    local version = {
        steps = { "/cast A", "/cast B" },
        keyPress = "",
        keyRelease = "",
        actions = {
            {
                type = D.ACTION_TYPE_LOOP,
                ["repeat"] = 3,
                stepFunction = D.STEP_SEQUENTIAL,
                children = {
                    { type = D.ACTION_TYPE_ACTION, macro = "/cast A" },
                },
            },
        },
    }
    SC:NormalizeVersionLocale(version)
    self:AssertEqual(2, #version.taggedSteps, "taggedSteps tracks the 2 baked steps")
    if currentResult.status == "fail" then
        return
    end

    -- Ungated recompile: the tree expands to 3 steps, desyncing from the
    -- length-2 taggedSteps sidecar (do NOT re-tag).
    local recompiledSteps = AC.CompileActions(version.actions, nil)
    self:Assert(#recompiledSteps ~= #version.taggedSteps, "ungated recompile desyncs (3 vs 2)")
    if currentResult.status == "fail" then
        return
    end

    -- Gated recompile: simulate the Phase 1 gate decision. With
    -- importBakedSteps set, the activation site skips the recompile and
    -- keeps the baked steps, so the lengths still match.
    version.importBakedSteps = true
    local gatedSteps = version.steps
    if not version.importBakedSteps then
        gatedSteps = AC.CompileActions(version.actions, nil)
    end
    self:AssertEqual(#version.taggedSteps, #gatedSteps, "gated recompile keeps the sidecars in sync")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("legacy import edit-loop round-trip equivalence (smoke)", "arch-migrate", function(self)
    if self:_SkipIfCombat() then
        return
    end
    local D = GRIPEMS.Defaults
    local Engine = GRIPEMS.Engine
    local GE = GRIPEMS.GRIPExport
    local LI = GRIPEMS.LegacyImport
    local AC = GRIPEMS.ActionCompiler
    if not D or not Engine or not GE or not LI or not AC then
        self:Fail("Defaults, Engine, GRIPExport, LegacyImport, or ActionCompiler not loaded")
        return
    end

    local name = "_TS_ArchMigrateEditLoop"
    if Engine.sequences[name] then
        Engine:DeactivateSequence(name)
    end

    -- Import a legacy single-Loop version to flat steps + an action tree.
    local legacyActions = {
        {
            Type = "Loop",
            Repeat = 2,
            StepFunction = "Sequential",
            Actions = {
                { Type = "spell", Spell = "Fireball" },
                { Type = "spell", Spell = "Frostbolt" },
            },
        },
    }
    local flat = LI.CompileMacroVersion({ Actions = legacyActions })
    local tree = LI.MapLegacyActionsToTree(legacyActions)

    local seqData = D.NewSequenceFromTemplate(name, D.TestSequence)
    local v1 = seqData.versions[1]
    v1.steps = flat.steps
    v1.actions = tree
    v1.repeatCount = 3
    v1.importBakedSteps = true
    Engine:ActivateSequence(name, seqData)

    -- Edit the loop count from 2 to 4. An explicit edit accepts native
    -- semantics, so clear the import-baked gate and recompile the steps.
    local loopNode = v1.actions[1]
    loopNode["repeat"] = 4
    v1.importBakedSteps = nil
    v1.steps = AC.CompileActions(v1.actions, Engine, v1)

    -- Re-activate with the edit, then export -> deactivate -> re-import.
    Engine:ActivateSequence(name, seqData)
    local okExp, encoded = GE.Export(name)
    Engine:DeactivateSequence(name)
    if not okExp then
        self:Fail("export failed: " .. tostring(encoded))
        return
    end

    local okImp, impName, impData = GE.ImportNative(encoded)
    if not okImp then
        self:Fail("import failed: " .. tostring(impName))
        return
    end

    local impVer = impData and impData.versions and impData.versions[1]
    if not impVer then
        self:Fail("imported data has no version")
        return
    end
    self:AssertEqual(3, impVer.repeatCount, "top-level repeatCount survives the round-trip")
    if currentResult.status == "fail" then
        return
    end
    local loop = impVer.actions and impVer.actions[1]
    if not loop then
        self:Fail("action tree lost on round-trip")
        return
    end
    self:AssertEqual(D.ACTION_TYPE_LOOP, loop.type, "node 1 is still a loop")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(4, loop["repeat"], "the loop-count edit (2 -> 4) survives the round-trip")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(2, loop.children and #loop.children, "loop children survive the round-trip")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

-- ---------------------------------------------------------------------------
-- Category: import -- bare-name macro steps inline the bundled macro body so the
-- step runs the macro instead of typing its name into chat. Covers the flat
-- compiler (LI.CompileAction) and the action tree (LI._MapActionToNode).
-- ---------------------------------------------------------------------------

TS:Register("bare-name macro step inlines bundled body (MACROREF-A)", "import", function(self)
    local LI = GRIPEMS.LegacyImport
    if not LI then
        self:Fail("LegacyImport not loaded")
        return
    end
    LI._importMacroBodies = { TESTMAC = "#showtooltip\n/cast TestSpell" }
    local out = LI.CompileAction({ Type = "Action", type = "macro", macro = "TESTMAC" })
    LI._importMacroBodies = nil
    local body = out[1] or ""
    self:Assert(string.find(body, "/cast TestSpell", 1, true) ~= nil, "inlined body has /cast TestSpell")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(body ~= "TESTMAC", "step is not the bare macro name")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("bare-name macro with no body keeps the name (MACROREF-B)", "import", function(self)
    local LI = GRIPEMS.LegacyImport
    if not LI then
        self:Fail("LegacyImport not loaded")
        return
    end
    LI._importMacroBodies = nil
    local out = LI.CompileAction({ Type = "Action", type = "macro", macro = "NOSUCHMACRO_XYZ" })
    self:AssertEqual("NOSUCHMACRO_XYZ", out[1], "unresolvable bare name is preserved")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("slash macrotext step is not inlined (MACROREF-C)", "import", function(self)
    local LI = GRIPEMS.LegacyImport
    if not LI then
        self:Fail("LegacyImport not loaded")
        return
    end
    LI._importMacroBodies = { ["/cast Foo"] = "SHOULD_NOT_USE" }
    local out = LI.CompileAction({ Type = "Action", type = "macro", macro = "/cast Foo" })
    LI._importMacroBodies = nil
    self:AssertEqual("/cast Foo", out[1], "slash macrotext passes through unchanged")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("action tree emits macro-ref node for bare name (MACROREF-D)", "import", function(self)
    local LI = GRIPEMS.LegacyImport
    local D = GRIPEMS.Defaults
    if not LI or not D then
        self:Fail("LegacyImport or Defaults not loaded")
        return
    end
    LI._importMacroBodies = { TESTMAC = "#showtooltip\n/cast TestSpell" }
    local node = LI._MapActionToNode({ Type = "Action", type = "macro", macro = "TESTMAC" })
    LI._importMacroBodies = nil
    self:Assert(node ~= nil, "tree node is produced")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(D.ACTION_SUBTYPE_MACROREF, node.subtype, "node is a macro-ref")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("TESTMAC", node.macroName, "macroName preserves the bare name")
    if currentResult.status == "fail" then
        return
    end
    local nodeBody = node.macro or ""
    self:Assert(string.find(nodeBody, "/cast TestSpell", 1, true) ~= nil, "node.macro has inlined body")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("build macro-body map from COLLECTION payload (MACROREF-E)", "import", function(self)
    local LI = GRIPEMS.LegacyImport
    if not LI then
        self:Fail("LegacyImport not loaded")
        return
    end
    local map = LI._BuildMacroBodyMap({
        Macros = {
            TEXTMAC = { name = "TEXTMAC", text = "#showtooltip\n/cast Alpha" },
            MANAGEMAC = { name = "MANAGEMAC", manageMacro = "#showtooltip\n/cast Beta" },
            EMPTYMAC = { name = "EMPTYMAC", text = "" },
            BODYLESS = { name = "BODYLESS" },
        },
    })
    self:Assert(string.find(map.TEXTMAC or "", "/cast Alpha", 1, true) ~= nil, "text body mapped")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(string.find(map.MANAGEMAC or "", "/cast Beta", 1, true) ~= nil, "manageMacro body mapped")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(map.EMPTYMAC == nil, "empty-body node not mapped")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(map.BODYLESS == nil, "body-less node not mapped")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(next(LI._BuildMacroBodyMap(nil)) == nil, "nil payload yields empty map")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(next(LI._BuildMacroBodyMap({})) == nil, "payload without Macros yields empty map")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("payload-built map resolves bare name end to end (MACROREF-F)", "import", function(self)
    local LI = GRIPEMS.LegacyImport
    if not LI then
        self:Fail("LegacyImport not loaded")
        return
    end
    LI._importMacroBodies = LI._BuildMacroBodyMap({
        Macros = { DH_FoEradicate = { name = "DH_FoEradicate", manageMacro = "#showtooltip\n/cast Eradicate" } },
    })
    local out = LI.CompileAction({ Type = "Action", type = "macro", macro = "DH_FoEradicate" })
    LI._importMacroBodies = nil
    self:Assert(string.find(out[1] or "", "/cast Eradicate", 1, true) ~= nil, "payload map resolves bare name")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(out[1] ~= "DH_FoEradicate", "step is not the bare macro name")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

-- ---------------------------------------------------------------------------
-- Category: import-weave -- imported Repeat-interval steps weave correctly and
-- stay edit-safe. The flat import bake routes through the same ActionCompiler
-- helper the editor uses, so an import then an edit cannot change the rotation.
-- ---------------------------------------------------------------------------

TS:Register("import weaves only Repeat, no drift (WEAVE-A)", "import-weave", function(self)
    local LI = GRIPEMS.LegacyImport
    if not LI then
        self:Fail("LegacyImport not loaded")
        return
    end
    -- AAA/III/CCC are Type=="Action" and must NOT weave even though they carry
    -- an Interval. TTT/SSS are Type=="Repeat" at interval 1 (every other step).
    local Actions = {
        { Type = "Action", type = "macro", macro = "/cast AAA", Interval = 4 },
        { Type = "Repeat", type = "macro", macro = "/cast TTT", Interval = 1 },
        { Type = "Repeat", type = "macro", macro = "/cast SSS", Interval = 1 },
        { Type = "Action", type = "macro", macro = "/cast III", Interval = 3 },
        { Type = "Action", type = "macro", macro = "/cast CCC", Interval = 3 },
    }
    local result = LI.CompileMacroVersion({ Actions = Actions })
    local expected = {
        "/cast AAA",
        "/cast TTT",
        "/cast SSS",
        "/cast III",
        "/cast TTT",
        "/cast SSS",
        "/cast CCC",
        "/cast TTT",
        "/cast SSS",
    }
    self:AssertEqual(#expected, #result.steps, "import weaves to exactly 9 steps")
    if currentResult.status == "fail" then
        return
    end
    for i = 1, #expected do
        if result.steps[i] ~= expected[i] then
            self:Fail("step " .. i .. " expected " .. expected[i] .. " got " .. tostring(result.steps[i]))
            return
        end
    end
    self:Pass()
end)

TS:Register("import bake equals editor recompile (WEAVE-B)", "import-weave", function(self)
    local LI = GRIPEMS.LegacyImport
    local AC = GRIPEMS.ActionCompiler
    if not LI or not AC then
        self:Fail("LegacyImport or ActionCompiler not loaded")
        return
    end
    -- The edit-safety invariant: baking the import and recompiling the mapped
    -- action tree must yield identical steps, so import-then-edit-then-save
    -- cannot silently change the rotation.
    local Actions = {
        { Type = "Action", type = "macro", macro = "/cast AAA", Interval = 4 },
        { Type = "Repeat", type = "macro", macro = "/cast TTT", Interval = 1 },
        { Type = "Repeat", type = "macro", macro = "/cast SSS", Interval = 1 },
        { Type = "Action", type = "macro", macro = "/cast III", Interval = 3 },
        { Type = "Action", type = "macro", macro = "/cast CCC", Interval = 3 },
    }
    local baked = LI.CompileMacroVersion({ Actions = Actions })
    local tree = LI.MapLegacyActionsToTree(Actions)
    local recompiled = AC.CompileActions(tree, nil)
    self:AssertEqual(#baked.steps, #recompiled, "bake and recompile have the same step count")
    if currentResult.status == "fail" then
        return
    end
    for i = 1, #baked.steps do
        if baked.steps[i] ~= recompiled[i] then
            self:Fail("import bake diverges from recompile at step " .. i)
            return
        end
    end
    self:Pass()
end)

TS:Register("interval 1 weaves every other step (WEAVE-C)", "import-weave", function(self)
    local LI = GRIPEMS.LegacyImport
    if not LI then
        self:Fail("LegacyImport not loaded")
        return
    end
    local Actions = {
        { Type = "Action", type = "macro", macro = "/cast AAA" },
        { Type = "Repeat", type = "macro", macro = "/cast TTT", Interval = 1 },
        { Type = "Action", type = "macro", macro = "/cast BBB" },
    }
    local result = LI.CompileMacroVersion({ Actions = Actions })
    local expected = { "/cast AAA", "/cast TTT", "/cast BBB", "/cast TTT" }
    self:AssertEqual(#expected, #result.steps, "interval 1 yields 4 steps")
    if currentResult.status == "fail" then
        return
    end
    for i = 1, #expected do
        if result.steps[i] ~= expected[i] then
            self:Fail("step " .. i .. " expected " .. expected[i] .. " got " .. tostring(result.steps[i]))
            return
        end
    end
    self:Pass()
end)

TS:Register("Action block with stale Interval is not woven (WEAVE-D)", "import-weave", function(self)
    local LI = GRIPEMS.LegacyImport
    if not LI then
        self:Fail("LegacyImport not loaded")
        return
    end
    local Actions = {
        { Type = "Action", type = "macro", macro = "/cast AAA", Interval = 2 },
        { Type = "Action", type = "macro", macro = "/cast BBB", Interval = 2 },
    }
    local result = LI.CompileMacroVersion({ Actions = Actions })
    local expected = { "/cast AAA", "/cast BBB" }
    self:AssertEqual(#expected, #result.steps, "Action blocks ignore a stale Interval (no weave)")
    if currentResult.status == "fail" then
        return
    end
    for i = 1, #expected do
        if result.steps[i] ~= expected[i] then
            self:Fail("step " .. i .. " expected " .. expected[i] .. " got " .. tostring(result.steps[i]))
            return
        end
    end
    self:Pass()
end)

TS:Register("interleave floor is 1 (WEAVE-E)", "import-weave", function(self)
    local D = GRIPEMS.Defaults
    if not D then
        self:Fail("Defaults not loaded")
        return
    end
    self:AssertEqual(1, D.ACTION_INTERLEAVE_MIN, "ACTION_INTERLEAVE_MIN is 1")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("first-slot weave is woven, not promoted (WEAVE-F)", "import-weave", function(self)
    local LI = GRIPEMS.LegacyImport
    if not LI then
        self:Fail("LegacyImport not loaded")
        return
    end
    -- A weave (Repeat with a positive interval) placed at the FIRST slot must be
    -- woven by the interval pass, not promoted to keyPress as an every-press cast.
    -- Same every-other cadence as the mid-array weave in WEAVE-C.
    local Actions = {
        { Type = "Repeat", type = "macro", macro = "/cast TTT", Interval = 1 },
        { Type = "Action", type = "macro", macro = "/cast AAA" },
        { Type = "Action", type = "macro", macro = "/cast BBB" },
    }
    local result = LI.CompileMacroVersion({ Actions = Actions })
    self:Assert(result.keyPress == nil or result.keyPress == "", "first-slot weave not promoted to keyPress")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(4, #result.steps, "first-slot weave yields 4 steps")
    if currentResult.status == "fail" then
        return
    end
    local ttt, aaa, bbb = 0, 0, 0
    for _, s in ipairs(result.steps) do
        if s == "/cast TTT" then
            ttt = ttt + 1
        elseif s == "/cast AAA" then
            aaa = aaa + 1
        elseif s == "/cast BBB" then
            bbb = bbb + 1
        end
    end
    self:AssertEqual(2, ttt, "TTT woven twice")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(1, aaa, "AAA appears once")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(1, bbb, "BBB appears once")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("last-slot weave is woven, not promoted (WEAVE-G)", "import-weave", function(self)
    local LI = GRIPEMS.LegacyImport
    if not LI then
        self:Fail("LegacyImport not loaded")
        return
    end
    -- A weave placed at the LAST slot must be woven, not promoted to keyRelease.
    local Actions = {
        { Type = "Action", type = "macro", macro = "/cast AAA" },
        { Type = "Action", type = "macro", macro = "/cast BBB" },
        { Type = "Repeat", type = "macro", macro = "/cast TTT", Interval = 1 },
    }
    local result = LI.CompileMacroVersion({ Actions = Actions })
    self:Assert(result.keyRelease == nil or result.keyRelease == "", "last-slot weave not promoted to keyRelease")
    if currentResult.status == "fail" then
        return
    end
    local ttt, aaa, bbb = 0, 0, 0
    for _, s in ipairs(result.steps) do
        if s == "/cast TTT" then
            ttt = ttt + 1
        elseif s == "/cast AAA" then
            aaa = aaa + 1
        elseif s == "/cast BBB" then
            bbb = bbb + 1
        end
    end
    self:Assert(ttt >= 2, "TTT woven at least twice")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(1, aaa, "AAA appears once")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(1, bbb, "BBB appears once")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("interval-less edge Repeat compiles in place (WEAVE-H)", "import-weave", function(self)
    local LI = GRIPEMS.LegacyImport
    if not LI then
        self:Fail("LegacyImport not loaded")
        return
    end
    -- An interval-less Repeat at the first or last slot compiles as an IN-PLACE
    -- step at its own position (source-engine parity); it is never a key block.
    local Actions = {
        { Type = "Repeat", type = "macro", macro = "/cast MMM" },
        { Type = "Action", type = "macro", macro = "/cast AAA" },
    }
    local result = LI.CompileMacroVersion({ Actions = Actions })
    self:Assert(result.keyPress == nil or result.keyPress == "", "interval-less edge Repeat is not a key block")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(2, #result.steps, "marker and action both compile as steps")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("/cast MMM", result.steps[1], "marker lands in place as the first step")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("/cast AAA", result.steps[2], "action follows the in-place marker")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

-- ---------------------------------------------------------------------------
-- Category: frg1 -- GRIP Forge export envelope import path (E1 + E2).
-- Prefix detection, envelope validation, encode/decode round-trip, the
-- forge-import provenance verdict family, and the preview arm + commit
-- rail (preview entries carry forge attribution and commit opts).
-- Two payload kinds ride inside the envelope: a legacy-shaped COLLECTION
-- (formatVersion 1) and a GRIP-EMS native COLLECTION (formatVersion 2).
-- The reader discriminates on the payload shape, so both kinds preview and
-- commit regardless of the envelope's formatVersion.
-- ---------------------------------------------------------------------------

TS:Register("FRG1 prefix detection", "frg1", function(self)
    local S = GRIPEMS.Serialization
    local D = GRIPEMS.Defaults
    if not S or not D then
        self:Fail("Serialization or Defaults not loaded")
        return
    end
    self:AssertEqual("FRG1", S.DetectFormat(D.FRG1_PREFIX .. "AAAA"), "FRG1 prefix detects as FRG1")
    if currentResult.status == "fail" then
        return
    end
    -- Non-regression: the legacy prefix still routes to its own format.
    self:AssertEqual("GSE3", S.DetectFormat(D.GSE3_PREFIX .. "AAAA"), "legacy prefix still detects as GSE3")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("FRG1 envelope validation", "frg1", function(self)
    local LI = GRIPEMS.LegacyImport
    local D = GRIPEMS.Defaults
    if not LI or not D then
        self:Fail("LegacyImport or Defaults not loaded")
        return
    end
    if not LI.ValidateForgeEnvelope then
        self:Skip("ValidateForgeEnvelope not loaded")
        return
    end

    -- Reject: not a FORGE_EXPORT envelope.
    local forge, err = LI.ValidateForgeEnvelope({ type = "COLLECTION" })
    self:Assert(forge == nil and type(err) == "string", "non-envelope table rejected with error string")
    if currentResult.status == "fail" then
        return
    end

    -- Reject: format version newer than this client supports.
    forge, err = LI.ValidateForgeEnvelope({
        type = "FORGE_EXPORT",
        formatVersion = D.FRG1_FORMAT_VERSION + 1,
        forge = { author = "MrSataana" },
        payload = { type = "COLLECTION" },
    })
    self:Assert(forge == nil and type(err) == "string", "newer formatVersion rejected with error string")
    if currentResult.status == "fail" then
        return
    end

    -- Reject: missing required attribution (forge.author).
    forge, err = LI.ValidateForgeEnvelope({
        type = "FORGE_EXPORT",
        formatVersion = 1,
        forge = {},
        payload = { type = "COLLECTION" },
    })
    self:Assert(forge == nil and type(err) == "string", "missing forge.author rejected with error string")
    if currentResult.status == "fail" then
        return
    end

    -- Reject: payload is not a COLLECTION.
    forge, err = LI.ValidateForgeEnvelope({
        type = "FORGE_EXPORT",
        formatVersion = 1,
        forge = { author = "MrSataana" },
        payload = { type = "PROFILE" },
    })
    self:Assert(forge == nil and type(err) == "string", "non-COLLECTION payload rejected with error string")
    if currentResult.status == "fail" then
        return
    end

    -- Accept: a well-formed envelope returns its forge table.
    local envelope = {
        type = "FORGE_EXPORT",
        formatVersion = 1,
        forge = { author = "MrSataana", exportedAt = "20260610120000" },
        payload = { type = "COLLECTION", payload = { Sequences = {} } },
    }
    forge, err = LI.ValidateForgeEnvelope(envelope)
    self:Assert(forge == envelope.forge and err == nil, "well-formed envelope returns its forge table")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("FRG1 encode/decode round-trip", "frg1", function(self)
    local S = GRIPEMS.Serialization
    local D = GRIPEMS.Defaults
    if not S or not D then
        self:Fail("Serialization or Defaults not loaded")
        return
    end

    -- Minimal envelope through the real C_EncodingUtil pipeline. Pure
    -- encode/decode -- no import side effects.
    local envelope = {
        type = "FORGE_EXPORT",
        formatVersion = 1,
        forge = { author = "MrSataana", exportedAt = "20260610120000" },
        payload = { type = "COLLECTION", payload = { Sequences = {} } },
    }
    local okEnc, encoded = S.Encode(envelope, D.FRG1_PREFIX)
    if not okEnc then
        self:Fail("encode failed: " .. tostring(encoded))
        return
    end
    local okDec, decoded, fmt = S.Decode(encoded)
    if not okDec then
        self:Fail("decode failed: " .. tostring(decoded))
        return
    end
    self:AssertEqual("FRG1", fmt, "decode reports the FRG1 format")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("MrSataana", decoded.forge and decoded.forge.author, "forge.author survives the round-trip")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("COLLECTION", decoded.payload and decoded.payload.type, "payload.type survives the round-trip")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("forge-import verdict family", "frg1", function(self)
    local I = GRIPEMS.Identity
    if not I then
        self:Fail("Identity not loaded")
        return
    end

    -- Unsigned forge-import sequences verify as "unknown" (same unsigned
    -- family as legacy imports), not "damaged".
    local seq = {
        originalAuthor = "GRIP Forge",
        originalSignature = "",
        provenanceSource = "forge-import",
    }
    self:AssertEqual("unknown", I:VerifySequence(seq), "forge-import verdict is unknown")
    if currentResult.status == "fail" then
        return
    end

    -- Control: an unrecognized provenanceSource stays "damaged".
    local control = {
        originalAuthor = "GRIP Forge",
        originalSignature = "",
        provenanceSource = "bogus-source",
    }
    self:AssertEqual("damaged", I:VerifySequence(control), "unrecognized source verdict is damaged")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("FRG1 preview rejects invalid envelope", "frg1", function(self)
    local LI = GRIPEMS.LegacyImport
    local S = GRIPEMS.Serialization
    local D = GRIPEMS.Defaults
    if not LI or not S or not D then
        self:Fail("LegacyImport, Serialization, or Defaults not loaded")
        return
    end
    -- forge.author is REQUIRED; the preview arm must reject the whole
    -- string with the validator's error, not fall through to the legacy
    -- branch as an unknown format.
    local envelope = {
        type = "FORGE_EXPORT",
        formatVersion = 1,
        forge = {},
        payload = { type = "COLLECTION", payload = { Sequences = {} } },
    }
    local encOk, encoded = S.Encode(envelope, D.FRG1_PREFIX)
    if not encOk then
        self:Fail("encode failed: " .. tostring(encoded))
        return
    end
    local preview = LI.Preview(encoded)
    self:Assert(
        preview ~= nil and preview.ok == false and type(preview.error) == "string",
        "invalid envelope rejected by preview with error string"
    )
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("FRG1 preview path + commit rail", "frg1", function(self)
    local LI = GRIPEMS.LegacyImport
    local S = GRIPEMS.Serialization
    local D = GRIPEMS.Defaults
    local Engine = GRIPEMS.Engine
    if not LI or not S or not D or not Engine then
        self:Fail("LegacyImport, Serialization, Defaults, or Engine not loaded")
        return
    end

    -- Commit activates the sequence through the engine; in combat that
    -- defers via OOCQueue and teardown cannot complete. Same guard as the
    -- legacy minimal-string import test.
    local OOC = GRIPEMS.OOCQueue
    if OOC and OOC.IsRestricted() then
        self:Skip("in combat -- commit activation defers; teardown cannot complete")
        return
    end

    -- Real C_EncodingUtil pipeline: encode a one-sequence envelope, preview
    -- it, then commit through the CommitSelected legacy rail. The inner
    -- sequence reuses the proven minimal shape from the legacy import test.
    local envelope = {
        type = "FORGE_EXPORT",
        formatVersion = 1,
        forge = { author = "MrSataana", exportedAt = "20260610120000" },
        payload = {
            type = "COLLECTION",
            payload = {
                Sequences = {
                    ["_TS_Frg1Prev"] = {
                        MacroVersions = {
                            [1] = {
                                StepFunction = "Sequential",
                                KeyPress = {},
                                KeyRelease = {},
                                Actions = {
                                    [1] = {
                                        Type = "Action",
                                        type = "macro",
                                        macro = "/cast Fireball",
                                    },
                                },
                            },
                        },
                        MetaData = {
                            Default = 1,
                            Author = "MrSataana",
                        },
                    },
                },
            },
        },
    }
    local encOk, encoded = S.Encode(envelope, D.FRG1_PREFIX)
    if not encOk then
        self:Fail("encode failed: " .. tostring(encoded))
        return
    end

    local preview = LI.Preview(encoded)
    if not preview or not preview.ok then
        self:Fail("preview failed: " .. tostring(preview and preview.error))
        return
    end
    self:AssertEqual("FRG1", preview.format, "preview format is FRG1")
    if currentResult.status == "fail" then
        return
    end
    local entry = preview.sequences and preview.sequences[1]
    self:Assert(entry ~= nil, "preview has one sequence entry")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("MrSataana", entry.forge and entry.forge.author, "entry carries the forge attribution")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(
        "MrSataana",
        entry.opts and entry.opts.forgeProvenance and entry.opts.forgeProvenance.author,
        "entry.opts threads forgeProvenance for the commit rail"
    )
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(
        "forge-import",
        entry.provenance and entry.provenance.provenanceSource,
        "preview provenance shows forge-import"
    )
    if currentResult.status == "fail" then
        return
    end

    local selections = { sequences = { [1] = { selected = true, action = "import" } }, variables = {} }
    local okCommit = LI.CommitSelected(preview, selections)
    self:Assert(okCommit == true, "CommitSelected succeeds")
    if currentResult.status == "fail" then
        return
    end
    local seqEntry = Engine.sequences and Engine.sequences["_TS_Frg1Prev"]
    local data = seqEntry and seqEntry.data
    self:Assert(data ~= nil, "committed sequence registered in engine")
    if currentResult.status ~= "fail" and data then
        self:AssertEqual("forge-import", data.provenanceSource, "committed stamp is forge-import")
    end
    if currentResult.status ~= "fail" and data then
        self:AssertEqual("GRIP Forge", data.originalAuthor, "committed byline is GRIP Forge")
    end
    if currentResult.status ~= "fail" and data then
        self:AssertEqual(
            "MrSataana",
            data.importMeta and data.importMeta.forge and data.importMeta.forge.author,
            "importMeta.forge preserves the envelope attribution"
        )
    end

    -- Teardown through the engine: store row, button, and macro stub all
    -- go away (same pattern as the legacy minimal-string import test).
    if Engine.sequences and Engine.sequences["_TS_Frg1Prev"] then
        Engine:DeactivateSequence("_TS_Frg1Prev")
    end
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

--- Build a GRIP-EMS native COLLECTION payload for the FRG1 v2 tests.
--- Mirrors GE.BuildCollectionPayload's canonical shape: the v2 envelope
--- carries exactly this table in its payload slot.
--- @param names table Array of sequence names
--- @return table payload Native COLLECTION payload
local function frg1NativePayload(names)
    local D = GRIPEMS.Defaults
    local payload = {
        format = "GRIP-EMS",
        version = D.GRIP_FORMAT_VERSION,
        type = "COLLECTION",
        locale = GetLocale(),
        sequences = {},
        variables = {},
    }
    for _, name in ipairs(names) do
        payload.sequences[name] = {
            versions = {
                [1] = {
                    steps = { "/cast Fireball" },
                    stepFunction = D.STEP_SEQUENTIAL,
                },
            },
            defaultVersion = 1,
            author = "Forged",
        }
    end
    return payload
end

--- Build a legacy-shaped COLLECTION payload (the v1 envelope wire shape).
--- @param name string Sequence name
--- @return table payload Legacy COLLECTION payload
local function frg1LegacyPayload(name)
    return {
        type = "COLLECTION",
        payload = {
            Sequences = {
                [name] = {
                    MacroVersions = {
                        [1] = {
                            StepFunction = "Sequential",
                            KeyPress = {},
                            KeyRelease = {},
                            Actions = {
                                [1] = { Type = "Action", type = "macro", macro = "/cast Fireball" },
                            },
                        },
                    },
                    MetaData = { Default = 1, Author = "MrSataana" },
                },
            },
        },
    }
end

--- Wrap a payload in a Forge export envelope.
--- @param formatVersion number Envelope formatVersion
--- @param payload table Payload table (native or legacy shaped)
--- @return table envelope FORGE_EXPORT envelope
local function frg1Envelope(formatVersion, payload)
    return {
        type = "FORGE_EXPORT",
        formatVersion = formatVersion,
        forge = { author = "MrSataana", exportedAt = "20260610120000" },
        payload = payload,
    }
end

TS:Register("FRG1 v2 envelope reports native payload kind", "frg1", function(self)
    local LI = GRIPEMS.LegacyImport
    local D = GRIPEMS.Defaults
    if not LI or not D then
        self:Fail("LegacyImport or Defaults not loaded")
        return
    end
    if not LI.ValidateForgeEnvelope then
        self:Skip("ValidateForgeEnvelope not loaded")
        return
    end

    local envelope = frg1Envelope(2, frg1NativePayload({ "_TS_Frg1V2Kind" }))
    local forge, err, kind = LI.ValidateForgeEnvelope(envelope)
    self:Assert(forge == envelope.forge and err == nil, "v2 native envelope validates")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("native", kind, "v2 native envelope reports payloadKind native")
    if currentResult.status == "fail" then
        return
    end

    -- The kind is discriminated on the payload SHAPE, never on the envelope
    -- formatVersion: a v1 envelope carrying a native payload still reads.
    local legacyVersioned = frg1Envelope(1, frg1NativePayload({ "_TS_Frg1V2Kind" }))
    local forge2, err2, kind2 = LI.ValidateForgeEnvelope(legacyVersioned)
    self:Assert(forge2 ~= nil and err2 == nil, "v1 envelope with native payload validates")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("native", kind2, "payload kind follows the shape, not formatVersion")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("FRG1 v1 envelope reports legacy payload kind", "frg1", function(self)
    local LI = GRIPEMS.LegacyImport
    if not LI then
        self:Fail("LegacyImport not loaded")
        return
    end
    if not LI.ValidateForgeEnvelope then
        self:Skip("ValidateForgeEnvelope not loaded")
        return
    end

    -- Back-compat: every envelope already in the wild is v1 around a
    -- legacy-shaped COLLECTION and must keep validating unchanged.
    local envelope = frg1Envelope(1, frg1LegacyPayload("_TS_Frg1V1Kind"))
    local forge, err, kind = LI.ValidateForgeEnvelope(envelope)
    self:Assert(forge == envelope.forge and err == nil, "v1 legacy envelope validates")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("legacy", kind, "v1 legacy envelope reports payloadKind legacy")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("FRG1 v2 preview reports native payload kind", "frg1", function(self)
    local LI = GRIPEMS.LegacyImport
    local S = GRIPEMS.Serialization
    local D = GRIPEMS.Defaults
    if not LI or not S or not D then
        self:Fail("LegacyImport, Serialization, or Defaults not loaded")
        return
    end

    local envelope = frg1Envelope(2, frg1NativePayload({ "_TS_Frg1V2PrevA", "_TS_Frg1V2PrevB" }))
    local encOk, encoded = S.Encode(envelope, D.FRG1_PREFIX)
    if not encOk then
        self:Fail("encode failed: " .. tostring(encoded))
        return
    end

    local preview = LI.Preview(encoded)
    if not preview or not preview.ok then
        self:Fail("preview failed: " .. tostring(preview and preview.error))
        return
    end
    self:AssertEqual("FRG1", preview.format, "preview format is FRG1")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("native", preview.payloadKind, "preview payloadKind is native")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(2, #preview.sequences, "preview lists both native sequences")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(2, preview.totalSequences, "counts match the native sequence total")
    if currentResult.status == "fail" then
        return
    end
    -- The native route must produce native entries, not legacy walk output.
    self:Assert(preview.sequences[1].isCollection == true, "entries carry the native collection shape")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("FRG1 v2 preview stamps forge provenance", "frg1", function(self)
    local LI = GRIPEMS.LegacyImport
    local S = GRIPEMS.Serialization
    local D = GRIPEMS.Defaults
    if not LI or not S or not D then
        self:Fail("LegacyImport, Serialization, or Defaults not loaded")
        return
    end

    local envelope = frg1Envelope(2, frg1NativePayload({ "_TS_Frg1V2ProvA", "_TS_Frg1V2ProvB" }))
    local encOk, encoded = S.Encode(envelope, D.FRG1_PREFIX)
    if not encOk then
        self:Fail("encode failed: " .. tostring(encoded))
        return
    end

    local preview = LI.Preview(encoded)
    if not preview or not preview.ok then
        self:Fail("preview failed: " .. tostring(preview and preview.error))
        return
    end
    self:AssertEqual("MrSataana", preview.forge and preview.forge.author, "preview carries the envelope forge block")
    if currentResult.status == "fail" then
        return
    end
    for _, entry in ipairs(preview.sequences) do
        local label = tostring(entry.name)
        self:AssertEqual("MrSataana", entry.forge and entry.forge.author, label .. ": entry carries forge attribution")
        if currentResult.status == "fail" then
            return
        end
        self:AssertEqual(
            "MrSataana",
            entry.opts and entry.opts.forgeProvenance and entry.opts.forgeProvenance.author,
            label .. ": entry.opts threads forgeProvenance"
        )
        if currentResult.status == "fail" then
            return
        end
        self:AssertEqual(
            "forge-import",
            entry.provenance and entry.provenance.provenanceSource,
            label .. ": preview provenance shows forge-import"
        )
        if currentResult.status == "fail" then
            return
        end
        self:AssertEqual(
            "GRIP Forge",
            entry.provenance and entry.provenance.originalAuthor,
            label .. ": preview byline is GRIP Forge"
        )
        if currentResult.status == "fail" then
            return
        end
    end
    self:Pass()
end)

TS:Register("FRG1 rejects newer format version", "frg1", function(self)
    local LI = GRIPEMS.LegacyImport
    local S = GRIPEMS.Serialization
    local D = GRIPEMS.Defaults
    if not LI or not S or not D then
        self:Fail("LegacyImport, Serialization, or Defaults not loaded")
        return
    end

    -- The ceiling check runs before the payload-kind discriminator, so a
    -- native payload from a future Forge is still refused by version.
    local envelope = frg1Envelope(D.FRG1_FORMAT_VERSION + 1, frg1NativePayload({ "_TS_Frg1Future" }))
    local forge, err, kind = LI.ValidateForgeEnvelope(envelope)
    self:Assert(forge == nil and kind == nil, "newer formatVersion rejected without a payload kind")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(
        type(err) == "string" and err:find("Update GRIP-EMS", 1, true) ~= nil,
        "rejection keeps the update-GRIP-EMS message"
    )
    if currentResult.status == "fail" then
        return
    end

    local encOk, encoded = S.Encode(envelope, D.FRG1_PREFIX)
    if not encOk then
        self:Fail("encode failed: " .. tostring(encoded))
        return
    end
    local preview = LI.Preview(encoded)
    self:Assert(
        preview ~= nil
            and preview.ok == false
            and type(preview.error) == "string"
            and preview.error:find("Update GRIP-EMS", 1, true) ~= nil,
        "preview arm refuses the newer envelope with the same message"
    )
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("FRG1 v2 commit rail", "frg1", function(self)
    local LI = GRIPEMS.LegacyImport
    local S = GRIPEMS.Serialization
    local D = GRIPEMS.Defaults
    local Engine = GRIPEMS.Engine
    if not LI or not S or not D or not Engine then
        self:Fail("LegacyImport, Serialization, Defaults, or Engine not loaded")
        return
    end

    -- Commit activates the sequence through the engine; in combat that
    -- defers via OOCQueue and teardown cannot complete. Same guard as the
    -- v1 FRG1 preview + commit rail test.
    local OOC = GRIPEMS.OOCQueue
    if OOC and OOC.IsRestricted() then
        self:Skip("in combat -- commit activation defers; teardown cannot complete")
        return
    end

    local name = "_TS_Frg1V2Commit"
    if Engine.sequences and Engine.sequences[name] then
        Engine:DeactivateSequence(name)
    end

    local envelope = frg1Envelope(2, frg1NativePayload({ name }))
    local encOk, encoded = S.Encode(envelope, D.FRG1_PREFIX)
    if not encOk then
        self:Fail("encode failed: " .. tostring(encoded))
        return
    end

    local preview = LI.Preview(encoded)
    if not preview or not preview.ok then
        self:Fail("preview failed: " .. tostring(preview and preview.error))
        return
    end
    self:AssertEqual("native", preview.payloadKind, "preview payloadKind is native")
    if currentResult.status == "fail" then
        return
    end

    local selections = { sequences = { [1] = { selected = true, action = "import" } }, variables = {} }
    local okCommit = LI.CommitSelected(preview, selections)
    self:Assert(okCommit == true, "CommitSelected succeeds")
    if currentResult.status == "fail" then
        return
    end

    local seqEntry = Engine.sequences and Engine.sequences[name]
    local data = seqEntry and seqEntry.data
    self:Assert(data ~= nil, "committed sequence registered in engine")
    if currentResult.status ~= "fail" and data then
        self:AssertEqual("forge-import", data.provenanceSource, "committed stamp is forge-import")
    end
    if currentResult.status ~= "fail" and data then
        self:AssertEqual("GRIP Forge", data.originalAuthor, "committed byline is GRIP Forge")
    end
    if currentResult.status ~= "fail" and data then
        self:AssertEqual(
            "MrSataana",
            data.importMeta and data.importMeta.forge and data.importMeta.forge.author,
            "importMeta.forge preserves the envelope attribution"
        )
    end
    if currentResult.status ~= "fail" and data then
        local ver = Engine:GetActiveVersion(data)
        self:AssertEqual(1, ver and ver.steps and #ver.steps, "committed sequence keeps its native step")
    end

    -- Teardown through the engine: store row, button, and macro stub all
    -- go away (same pattern as the v1 FRG1 commit rail test).
    if Engine.sequences and Engine.sequences[name] then
        Engine:DeactivateSequence(name)
    end
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("FRG1 v2 direct import rail", "frg1", function(self)
    local LI = GRIPEMS.LegacyImport
    local S = GRIPEMS.Serialization
    local D = GRIPEMS.Defaults
    local Engine = GRIPEMS.Engine
    if not LI or not S or not D or not Engine then
        self:Fail("LegacyImport, Serialization, Defaults, or Engine not loaded")
        return
    end

    local OOC = GRIPEMS.OOCQueue
    if OOC and OOC.IsRestricted() then
        self:Skip("in combat -- import activation defers; teardown cannot complete")
        return
    end

    -- LI.Import is the no-UI rail (/gems import <string>). A native payload
    -- cannot go through the legacy COLLECTION walk, so the v2 arm routes to
    -- the preview + commit rail instead. Non-regression for the v1 arm lives
    -- in the "FRG1 v2 commit rail" and legacy import tests.
    local name = "_TS_Frg1V2Direct"
    if Engine.sequences and Engine.sequences[name] then
        Engine:DeactivateSequence(name)
    end

    local encOk, encoded = S.Encode(frg1Envelope(2, frg1NativePayload({ name })), D.FRG1_PREFIX)
    if not encOk then
        self:Fail("encode failed: " .. tostring(encoded))
        return
    end

    local okImport, result = LI.Import(encoded)
    self:Assert(okImport == true, "LI.Import accepts a v2 native envelope: " .. tostring(result))
    if currentResult.status == "fail" then
        return
    end

    local seqEntry = Engine.sequences and Engine.sequences[name]
    local data = seqEntry and seqEntry.data
    self:Assert(data ~= nil, "imported sequence registered in engine")
    if currentResult.status ~= "fail" and data then
        self:AssertEqual("forge-import", data.provenanceSource, "direct import stamp is forge-import")
    end
    if currentResult.status ~= "fail" and data then
        self:AssertEqual("GRIP Forge", data.originalAuthor, "direct import byline is GRIP Forge")
    end

    if Engine.sequences and Engine.sequences[name] then
        Engine:DeactivateSequence(name)
    end
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("Legacy format import (minimal string)", "import", function(self)
    local LI = GRIPEMS.LegacyImport
    local S = GRIPEMS.Serialization
    if not LI or not S then
        self:Fail("LegacyImport or Serialization not loaded")
        return
    end

    -- Import auto-activates the decoded sequence through the engine. In
    -- combat that activation defers via OOCQueue, so the teardown at the end
    -- of this test cannot remove a not-yet-registered sequence and
    -- _TS_LegacyImp would persist past combat. Skip in combat so the suite
    -- leaves zero trace on every path; the pre-suite scrub clears any
    -- leftover from an earlier in-combat attempt.
    local OOC = GRIPEMS.OOCQueue
    if OOC and OOC.IsRestricted() then
        self:Skip("in combat -- import activation defers; teardown cannot complete")
        return
    end

    -- Build a minimal legacy-format payload and encode it
    local payload = {
        type = "COLLECTION",
        payload = {
            Sequences = {
                ["_TS_LegacyImp"] = {
                    MacroVersions = {
                        [1] = {
                            StepFunction = "Sequential",
                            KeyPress = {},
                            KeyRelease = {},
                            Actions = {
                                [1] = {
                                    Type = "Action",
                                    type = "macro",
                                    macro = "/cast Fireball",
                                },
                            },
                        },
                    },
                    MetaData = {
                        Default = 1,
                    },
                },
            },
        },
    }
    local encOk, encoded = S.Encode(payload, "!GSE3!")
    if not encOk or not encoded then
        self:Fail("failed to encode legacy payload")
        return
    end

    local ok, result = LI.Import(encoded)
    if not ok then
        self:Fail("legacy import failed: " .. tostring(result))
        return
    end

    -- LI.Import returns a results table; check that our sequence name appears
    if type(result) == "table" and result.names then
        local found = false
        for _, name in ipairs(result.names) do
            if name == "_TS_LegacyImp" then
                found = true
                break
            end
        end
        if found then
            self:Pass()
        else
            self:Fail("sequence not in import results")
        end
    else
        -- Import succeeded but result format unexpected; accept
        self:Pass()
    end

    -- Teardown: the import activated the sequence through the engine, so
    -- tear it down through the engine -- store row, button, and macro stub
    -- all go away. This test previously left the sequence persisted, where
    -- it re-activated at every login.
    local Engine = GRIPEMS.Engine
    if Engine and Engine.sequences and Engine.sequences["_TS_LegacyImp"] then
        Engine:DeactivateSequence("_TS_LegacyImp")
    end
end)

TS:Register("DetectFormat returns nil for garbage input", "import", function(self)
    local Ser = GRIPEMS.Serialization
    if not Ser then
        self:Fail("Serialization not loaded")
        return
    end
    local fmt = Ser.DetectFormat("RANDOMGARBAGE12345")
    self:AssertEqual(nil, fmt, "garbage input should return nil")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("DetectFormat recognizes GRIP1 prefix", "import", function(self)
    local Ser = GRIPEMS.Serialization
    if not Ser then
        self:Fail("Serialization not loaded")
        return
    end
    local fmt = Ser.DetectFormat("!GRIP1!somedata")
    self:AssertEqual("GRIP1", fmt, "GRIP1 prefix detection")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("DetectFormat recognizes legacy prefix", "import", function(self)
    local Ser = GRIPEMS.Serialization
    if not Ser then
        self:Fail("Serialization not loaded")
        return
    end
    local fmt = Ser.DetectFormat("!GSE3!somedata")
    self:AssertEqual("GSE3", fmt, "legacy GSE3 prefix detection")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("DetectFormat recognizes EMS1 prefix", "import", function(self)
    local Ser = GRIPEMS.Serialization
    if not Ser then
        self:Fail("Serialization not loaded")
        return
    end
    local fmt = Ser.DetectFormat("!EMS1!somedata")
    self:AssertEqual("EMS1", fmt, "EMS1 prefix detection")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("DetectFormat flags !GSE3!+ as encrypted", "import", function(self)
    local Ser = GRIPEMS.Serialization
    local D = GRIPEMS.Defaults
    if not Ser or not D then
        self:Fail("Serialization or Defaults not loaded")
        return
    end
    local s = D.GSE3_ENCRYPTED_PREFIX .. "1AAAA"
    self:AssertEqual("GSE3_ENCRYPTED", Ser.DetectFormat(s), "!GSE3!+ detects as encrypted")
    if currentResult.status == "fail" then
        return
    end
    local ok, msg, token = Ser.Decode(s)
    self:AssertEqual(false, ok, "encrypted sequence import is refused")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("GSE3_ENCRYPTED", token, "refusal reports the encrypted token")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(type(msg) == "string" and #msg > 0, "refusal carries a user-facing message")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("Malformed !GSE3!+ refuses without error", "import", function(self)
    local Ser = GRIPEMS.Serialization
    local D = GRIPEMS.Defaults
    if not Ser or not D then
        self:Fail("Serialization or Defaults not loaded")
        return
    end
    local s = D.GSE3_ENCRYPTED_PREFIX .. "9####"
    local callOk, ok = pcall(Ser.Decode, s)
    self:AssertEqual(true, callOk, "Decode does not throw on malformed encrypted input")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(false, ok, "malformed encrypted input is refused")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("Plain !GSE3! still imports after encrypted guard", "import", function(self)
    local Ser = GRIPEMS.Serialization
    local D = GRIPEMS.Defaults
    if not Ser or not D then
        self:Fail("Serialization or Defaults not loaded")
        return
    end
    local payload = { type = "sequence", sequence = { name = "_TS_PlainGSE3" } }
    local encOk, encoded = Ser.Encode(payload, D.GSE3_PREFIX)
    if not encOk then
        self:Fail("legacy encode failed: " .. tostring(encoded))
        return
    end
    self:AssertEqual("GSE3", Ser.DetectFormat(encoded), "plain legacy still detects as GSE3")
    if currentResult.status == "fail" then
        return
    end
    local ok, decoded, fmt = Ser.Decode(encoded)
    self:Assert(ok, "plain legacy still decodes: " .. tostring(decoded))
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("GSE3", fmt, "decode reports GSE3")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(
        "_TS_PlainGSE3",
        decoded and decoded.sequence and decoded.sequence.name,
        "payload survives the round-trip"
    )
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("!GSE3! vs !GSE3!+ prefix boundary is exact", "import", function(self)
    local Ser = GRIPEMS.Serialization
    local D = GRIPEMS.Defaults
    if not Ser or not D then
        self:Fail("Serialization or Defaults not loaded")
        return
    end
    self:AssertEqual("GSE3", Ser.DetectFormat("!GSE3!A"), "non-plus 7th char stays GSE3")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("GSE3_ENCRYPTED", Ser.DetectFormat("!GSE3!+"), "!GSE3!+ is encrypted")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("GSE3", Ser.DetectFormat(D.GSE3_PREFIX .. "AAAA"), "bare legacy prefix stays GSE3")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("EMS1 Encode/Decode round-trip", "import", function(self)
    local D = GRIPEMS.Defaults
    local S = GRIPEMS.Serialization
    if not D or not S then
        self:Fail("Defaults or Serialization not loaded")
        return
    end
    local payload = {
        format = "GRIP-EMS",
        version = D.GRIP_FORMAT_VERSION,
        type = "sequence",
        sequence = {
            name = "_TS_EMS1RoundTrip",
            originalAuthor = "TestUser",
            originalAuthorIdentity = "deadbeef",
            originalCreatedAt = 1234567890,
            signatureAlgorithm = "ALG_V0_DJB2",
        },
    }
    local encOk, encoded = S.Encode(payload, D.EMS1_PREFIX)
    if not encOk or not encoded then
        self:Fail("EMS1 encode failed: " .. tostring(encoded))
        return
    end
    self:Assert(encoded:sub(1, #D.EMS1_PREFIX) == D.EMS1_PREFIX, "encoded string must begin with " .. D.EMS1_PREFIX)
    if currentResult.status == "fail" then
        return
    end

    local decOk, decoded, format = S.Decode(encoded)
    if not decOk then
        self:Fail("EMS1 decode failed: " .. tostring(decoded))
        return
    end
    self:AssertEqual("EMS1", format, "decoded format must be EMS1")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(decoded.sequence ~= nil, "round-trip preserves sequence table")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("TestUser", decoded.sequence.originalAuthor, "round-trip preserves originalAuthor")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("deadbeef", decoded.sequence.originalAuthorIdentity, "round-trip preserves originalAuthorIdentity")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

-- v2.1.0 Phase A polish: explicit GRIP1 round-trip regression. The earlier
-- "EMS1" round-trip is the renamed Phase A test; pre-v2.1.0 exports in the
-- wild are still GRIP1-prefixed and v2.1.0 still accepts them on import,
-- so a regression in this path would silently break back-compat.
TS:Register("GRIP1 native export/import round-trip", "import", function(self)
    local D = GRIPEMS.Defaults
    local S = GRIPEMS.Serialization
    if not (D and S and D.GRIP1_PREFIX) then
        self:Skip("Serialization or D.GRIP1_PREFIX not loaded")
        return
    end
    local payload = {
        format = "GRIP-EMS",
        version = D.GRIP_FORMAT_VERSION,
        type = "sequence",
        sequence = {
            name = "_TS_GRIP1RoundTrip",
            originalAuthor = "TestUser",
            originalAuthorIdentity = "deadbeef",
            originalCreatedAt = 1234567890,
            signatureAlgorithm = "ALG_V1_SHA256",
        },
    }
    local encOk, encoded = S.Encode(payload, D.GRIP1_PREFIX)
    if not encOk or not encoded then
        self:Fail("GRIP1 encode failed: " .. tostring(encoded))
        return
    end
    self:Assert(encoded:sub(1, #D.GRIP1_PREFIX) == D.GRIP1_PREFIX, "encoded string must begin with " .. D.GRIP1_PREFIX)
    if currentResult.status == "fail" then
        return
    end

    local decOk, decoded, format = S.Decode(encoded)
    if not decOk then
        self:Fail("GRIP1 decode failed: " .. tostring(decoded))
        return
    end
    self:AssertEqual("GRIP1", format, "decoded format must be GRIP1")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(decoded.sequence ~= nil, "round-trip preserves sequence table")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("TestUser", decoded.sequence.originalAuthor, "round-trip preserves originalAuthor")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("deadbeef", decoded.sequence.originalAuthorIdentity, "round-trip preserves originalAuthorIdentity")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("importStats defaults exist in DB", "import", function(self)
    local db = _G.GRIP_EMS_DB
    if not db then
        self:Skip("DB not initialized")
        return
    end
    self:Assert(db.importStats ~= nil, "importStats missing from DB defaults")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(type(db.importStats) == "table", "importStats should be table")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

-- ---------------------------------------------------------------------------
-- Category: phase-b -- LibHash SHA-256 + signature pipeline (v2.1.0 Phase B)
-- ---------------------------------------------------------------------------

TS:Register("LibHash SHA-256 reference vector: empty string", "phase-b", function(self)
    local lh = LibStub("LibHash-1.0", true)
    if not lh then
        self:Skip("LibHash not loaded")
        return
    end
    self:AssertEqual(
        "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        lh.sha256(""),
        "SHA-256 of empty string"
    )
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("LibHash SHA-256 reference vector: 'abc'", "phase-b", function(self)
    local lh = LibStub("LibHash-1.0", true)
    if not lh then
        self:Skip("LibHash not loaded")
        return
    end
    self:AssertEqual(
        "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
        lh.sha256("abc"),
        "SHA-256 of 'abc' (NIST FIPS 180-4 Appendix B)"
    )
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("LibHash SHA-256 reference vector: 'your string'", "phase-b", function(self)
    local lh = LibStub("LibHash-1.0", true)
    if not lh then
        self:Skip("LibHash not loaded")
        return
    end
    self:AssertEqual(
        "d14d691dac70eada14d9f23ef80091bca1c75cf77cf1cd5cf2d04180ca0d9911",
        lh.sha256("your string"),
        "SHA-256 of 'your string' (LibHash README example)"
    )
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("Identity:SignSequence + VerifySequence round-trip", "phase-b", function(self)
    local I = GRIPEMS.Identity
    if not I then
        self:Skip("Identity module not loaded")
        return
    end
    local seq = {
        versions = { primary = { spells = { 100 } } },
        contextOverrides = {},
        description = "test",
        specID = 0,
        classID = 3,
        icon = 0,
        url = "",
        talentString = "",
        originalAuthor = "TestUser",
        originalAuthorIdentity = string.rep("a", 64),
        originalAuthorRealm = "TestRealm",
        originalCreatedAt = 1234567890,
        signatureAlgorithm = "ALG_V1_SHA256",
        modifierChain = {
            {
                name = "TestUser",
                identity = string.rep("a", 64),
                realm = "TestRealm",
                at = 1234567890,
                kind = "created",
            },
        },
        provenanceSource = "native",
    }
    seq.originalSignature = I:SignSequence(seq)
    self:AssertEqual("verified", I:VerifySequence(seq), "clean sign+verify")
    if currentResult.status == "fail" then
        return
    end

    -- Tamper: change content, signature should now mismatch
    seq.description = "tampered"
    self:AssertEqual("tampered", I:VerifySequence(seq), "content change detected")
    if currentResult.status == "fail" then
        return
    end

    -- Restore + add modifier: should be "modified" not "tampered"
    seq.description = "test"
    table.insert(seq.modifierChain, {
        name = "OtherUser",
        identity = string.rep("b", 64),
        realm = "OtherRealm",
        at = 1234567900,
        kind = "edited",
    })
    self:AssertEqual("modified", I:VerifySequence(seq), "chain growth without content change")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

-- ---------------------------------------------------------------------------
-- Category: phase-c -- v2.1.0 Authorship Integrity Phase C
-- (Fork mechanism, VerifySequence reorder, Engine:DuplicateSequence rewire)
-- ---------------------------------------------------------------------------

TS:Register("Identity:StampForked round-trip", "phase-c", function(self)
    local I = GRIPEMS.Identity
    if not I then
        self:Skip("Identity module not loaded")
        return
    end
    local source = {
        originalAuthor = "OrigAuthor",
        originalAuthorIdentity = string.rep("a", 64),
        originalAuthorRealm = "OrigRealm",
        originalCreatedAt = 1234567890,
        originalSignature = "fakesig",
        versions = { primary = { spells = { 100 } } },
        contextOverrides = {},
        modifierChain = {
            {
                name = "OrigAuthor",
                identity = string.rep("a", 64),
                realm = "OrigRealm",
                at = 1234567890,
                kind = "created",
            },
        },
        signatureAlgorithm = "ALG_V1_SHA256",
        provenanceSource = "native",
    }
    local fork = {
        versions = source.versions,
        contextOverrides = source.contextOverrides,
    }
    local ok = I:StampForked(fork, source)
    self:AssertEqual(true, ok, "first fork stamp succeeds")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(fork.forkedFrom ~= nil, "forkedFrom recorded")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("OrigAuthor", fork.forkedFrom.originalAuthor, "lineage preserved")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(fork.originalAuthor ~= "OrigAuthor", "fork has new author")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(1, #fork.modifierChain, "fork chain restarts at length 1")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("forked-from", fork.modifierChain[1].kind, "first chain entry is forked-from")
    if currentResult.status == "fail" then
        return
    end
    -- Idempotency: stamping a fork that already has forkedFrom returns false.
    local secondOk = I:StampForked(fork, source)
    self:AssertEqual(false, secondOk, "second StampForked refuses re-stamp")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("VerifySequence forked-vs-tampered ordering", "phase-c", function(self)
    local I = GRIPEMS.Identity
    if not I then
        self:Skip("Identity module not loaded")
        return
    end
    local seq = {
        versions = { primary = { spells = { 100 } } },
        contextOverrides = {},
        description = "test",
        specID = 0,
        classID = 3,
        icon = 0,
        url = "",
        talentString = "",
        originalAuthor = "TestUser",
        originalAuthorIdentity = string.rep("a", 64),
        originalAuthorRealm = "TestRealm",
        originalCreatedAt = 1234567890,
        signatureAlgorithm = "ALG_V1_SHA256",
        modifierChain = {
            {
                name = "TestUser",
                identity = string.rep("a", 64),
                realm = "TestRealm",
                at = 1234567890,
                kind = "forked-from",
            },
        },
        provenanceSource = "native",
        forkedFrom = {
            originalAuthor = "OrigAuthor",
            originalAuthorIdentity = string.rep("b", 64),
            originalSignature = "fakesig",
            forkedAt = 1234500000,
        },
    }
    seq.originalSignature = I:SignSequence(seq)
    self:AssertEqual("forked", I:VerifySequence(seq), "clean fork verifies as forked")
    if currentResult.status == "fail" then
        return
    end
    seq.description = "tampered"
    self:AssertEqual("tampered", I:VerifySequence(seq), "tampered fork detected (not masked as forked)")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("Engine:DuplicateSequence re-stamps as fork", "phase-c", function(self)
    if self:_SkipIfCombat() then
        return
    end
    local Engine = GRIPEMS.Engine
    if not Engine or not Engine.DuplicateSequence then
        self:Skip("Engine not loaded")
        return
    end
    local I = GRIPEMS.Identity
    if not I then
        self:Skip("Identity module not loaded")
        return
    end
    local sourceName = "_TS_ForkSource"
    local forkName = "_TS_ForkResult"
    -- Clean up any prior leftovers
    if Engine.sequences[sourceName] then
        Engine:DeactivateSequence(sourceName)
    end
    if Engine.sequences[forkName] then
        Engine:DeactivateSequence(forkName)
    end

    -- Build a source sequence with a foreign author + signature.
    local sourceData = {
        name = sourceName,
        icon = 0,
        autoIcon = true,
        defaultVersion = 1,
        versions = { { steps = {}, stepFunction = "Sequential" } },
        contextOverrides = {},
        author = "OrigAuthor",
        version = "1",
        description = "src",
        classID = 0,
        specID = 0,
        createdAt = 1234567890,
        updatedAt = 1234567890,
        originalAuthor = "OrigAuthor",
        originalAuthorIdentity = string.rep("a", 64),
        originalAuthorRealm = "OrigRealm",
        originalCreatedAt = 1234567890,
        signatureAlgorithm = "ALG_V1_SHA256",
        modifierChain = {
            {
                name = "OrigAuthor",
                identity = string.rep("a", 64),
                realm = "OrigRealm",
                at = 1234567890,
                kind = "created",
            },
        },
        provenanceSource = "native",
    }
    sourceData.originalSignature = I:SignSequence(sourceData)
    Engine:ActivateSequence(sourceName, sourceData)

    local ok, err = Engine:DuplicateSequence(sourceName, forkName)
    self:AssertEqual(true, ok, "DuplicateSequence succeeds (" .. tostring(err) .. ")")
    if currentResult.status == "fail" then
        Engine:DeactivateSequence(sourceName)
        return
    end
    local forkEntry = Engine.sequences[forkName]
    self:Assert(forkEntry and forkEntry.data, "fork registered")
    if currentResult.status == "fail" then
        Engine:DeactivateSequence(sourceName)
        return
    end
    local fd = forkEntry.data
    self:Assert(fd.forkedFrom ~= nil, "fork records source lineage")
    if currentResult.status == "fail" then
        Engine:DeactivateSequence(sourceName)
        Engine:DeactivateSequence(forkName)
        return
    end
    self:AssertEqual("OrigAuthor", fd.forkedFrom.originalAuthor, "lineage preserves source author")
    if currentResult.status == "fail" then
        Engine:DeactivateSequence(sourceName)
        Engine:DeactivateSequence(forkName)
        return
    end
    self:Assert(fd.originalAuthor and fd.originalAuthor ~= "OrigAuthor", "fork stamps new originalAuthor")
    if currentResult.status == "fail" then
        Engine:DeactivateSequence(sourceName)
        Engine:DeactivateSequence(forkName)
        return
    end
    self:Assert(
        fd.originalSignature and fd.originalSignature ~= sourceData.originalSignature,
        "fork has fresh signature"
    )
    Engine:DeactivateSequence(sourceName)
    Engine:DeactivateSequence(forkName)
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

-- v2.1.6 Phase 1.7: end-to-end coverage for the DuplicateSequence ->
-- StampForked -> StampOriginal chain when config.privacyDefault is
-- pseudonymous AND config.pseudonym is set. Verifies that:
--   1) DuplicateSequence seeds newData.privacyMode from config.privacyDefault
--      (NOT from src.privacyMode, which is deliberately "public" here)
--   2) StampOriginal consults the seeded privacyMode and stamps the
--      configured pseudonym as originalAuthor
--   3) originalAuthorIdentity still derives from the LOCAL identity hash
--      regardless of the displayed pseudonym (signature anchor unchanged)
-- Phase 1.5 shipped unit-test-green code that failed this end-to-end path;
-- Phase 1.6 closed the gap at both call site and resolver; this test makes
-- a future double-regression impossible to ship silently.
TS:Register("Engine:DuplicateSequence propagates pseudonymous default", "phase-c", function(self)
    if self:_SkipIfCombat() then
        return
    end
    local Engine = GRIPEMS.Engine
    if not Engine or not Engine.DuplicateSequence then
        self:Skip("Engine not loaded")
        return
    end
    local I = GRIPEMS.Identity
    if not I then
        self:Skip("Identity module not loaded")
        return
    end

    -- Sandbox the two config fields this test mutates. Save originals
    -- now, restore via the cleanup closure below regardless of which
    -- branch the test exits through.
    GRIP_EMS_DB = GRIP_EMS_DB or {}
    GRIP_EMS_DB.config = GRIP_EMS_DB.config or {}
    local origPseudonym = GRIP_EMS_DB.config.pseudonym
    local origPrivacyDefault = GRIP_EMS_DB.config.privacyDefault
    GRIP_EMS_DB.config.pseudonym = "TestDoom"
    GRIP_EMS_DB.config.privacyDefault = "pseudonymous"

    local sourceName = "_TS_ForkSourcePseudo"
    local forkName = "_TS_ForkResultPseudo"

    local function cleanup()
        if Engine.sequences[sourceName] then
            Engine:DeactivateSequence(sourceName)
        end
        if Engine.sequences[forkName] then
            Engine:DeactivateSequence(forkName)
        end
        GRIP_EMS_DB.config.pseudonym = origPseudonym
        GRIP_EMS_DB.config.privacyDefault = origPrivacyDefault
    end

    -- Clean up any prior leftovers
    if Engine.sequences[sourceName] then
        Engine:DeactivateSequence(sourceName)
    end
    if Engine.sequences[forkName] then
        Engine:DeactivateSequence(forkName)
    end

    -- Build a source whose privacyMode is deliberately "public", so the
    -- assertion fork.privacyMode == "pseudonymous" can only pass if the
    -- fork inherited from config.privacyDefault, NOT from src.
    local sourceData = {
        name = sourceName,
        icon = 0,
        autoIcon = true,
        defaultVersion = 1,
        versions = { { steps = {}, stepFunction = "Sequential" } },
        contextOverrides = {},
        author = "OrigAuthor",
        version = "1",
        description = "src",
        privacyMode = "public",
        classID = 0,
        specID = 0,
        createdAt = 1234567890,
        updatedAt = 1234567890,
        originalAuthor = "OrigAuthor",
        originalAuthorIdentity = string.rep("a", 64),
        originalAuthorRealm = "OrigRealm",
        originalCreatedAt = 1234567890,
        signatureAlgorithm = "ALG_V1_SHA256",
        modifierChain = {
            {
                name = "OrigAuthor",
                identity = string.rep("a", 64),
                realm = "OrigRealm",
                at = 1234567890,
                kind = "created",
            },
        },
        provenanceSource = "native",
    }
    sourceData.originalSignature = I:SignSequence(sourceData)
    Engine:ActivateSequence(sourceName, sourceData)

    local ok, err = Engine:DuplicateSequence(sourceName, forkName)
    self:AssertEqual(true, ok, "DuplicateSequence succeeds (" .. tostring(err) .. ")")
    if currentResult.status == "fail" then
        cleanup()
        return
    end

    local forkEntry = Engine.sequences[forkName]
    self:Assert(forkEntry and forkEntry.data, "fork registered")
    if currentResult.status == "fail" then
        cleanup()
        return
    end
    local fd = forkEntry.data

    -- Assertion 1: DuplicateSequence seeded privacyMode from config,
    -- NOT inherited from src.privacyMode (which was "public").
    self:AssertEqual(
        "pseudonymous",
        fd.privacyMode,
        "fork inherits LOCAL config.privacyDefault (src was 'public', expected 'pseudonymous')"
    )
    if currentResult.status == "fail" then
        cleanup()
        return
    end

    -- Assertion 2: StampOriginal stamped the configured pseudonym as
    -- originalAuthor (the full chain works end-to-end).
    self:AssertEqual("TestDoom", fd.originalAuthor, "fork's originalAuthor is the configured pseudonym")
    if currentResult.status == "fail" then
        cleanup()
        return
    end

    -- Assertion 3: originalAuthorIdentity still derives from the local
    -- identity hash, NOT a hash of the pseudonym. Signature anchor is
    -- unchanged across the picker + pseudonym layers.
    local me = I:GetCurrent()
    self:AssertEqual(
        me.identityHash,
        fd.originalAuthorIdentity,
        "originalAuthorIdentity is local user's hash, NOT a hash of the pseudonym"
    )

    cleanup()
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

-- v2.1.0 Phase C polish: multi-hop fork chain growth. Each fork prepends
-- the immediate parent and inherits the source's prior chain so the full
-- ancestry survives across N hops (Daddysat -> John -> Paul -> Peter).
TS:Register("Identity:StampForked builds multi-hop chain", "phase-c", function(self)
    local I = GRIPEMS.Identity
    if not I then
        self:Skip("Identity module not loaded")
        return
    end
    -- Source A: Gaupanda's original (no fork lineage)
    local srcA = {
        originalAuthor = "Gaupanda",
        originalAuthorIdentity = string.rep("a", 64),
        originalAuthorRealm = "Realm",
        originalCreatedAt = 1000,
        originalSignature = "sigA",
        versions = { primary = { spells = { 100 } } },
        contextOverrides = {},
        modifierChain = {},
    }
    -- First fork: Daddysat -> Gaupanda
    local forkB = {
        versions = srcA.versions,
        contextOverrides = srcA.contextOverrides,
    }
    I:StampForked(forkB, srcA)
    self:AssertEqual(1, #(forkB.forkedFromChain or {}), "first fork: chain has 1 entry (the immediate parent)")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("Gaupanda", forkB.forkedFromChain[1].originalAuthor, "first fork: chain[1] is Gaupanda")
    if currentResult.status == "fail" then
        return
    end

    -- Second fork: John -> Daddysat -> Gaupanda
    local forkC = {
        versions = forkB.versions,
        contextOverrides = forkB.contextOverrides,
    }
    I:StampForked(forkC, forkB)
    self:AssertEqual(2, #(forkC.forkedFromChain or {}), "second fork: chain has 2 entries")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(
        forkB.originalAuthor,
        forkC.forkedFromChain[1].originalAuthor,
        "second fork: chain[1] is the immediate parent (Daddysat)"
    )
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(
        "Gaupanda",
        forkC.forkedFromChain[2].originalAuthor,
        "second fork: chain[2] is Gaupanda (preserved through chain)"
    )
    if currentResult.status == "fail" then
        return
    end

    -- Third fork: Paul -> John -> Daddysat -> Gaupanda
    local forkD = {
        versions = forkC.versions,
        contextOverrides = forkC.contextOverrides,
    }
    I:StampForked(forkD, forkC)
    self:AssertEqual(3, #(forkD.forkedFromChain or {}), "third fork: chain has 3 entries")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(forkC.originalAuthor, forkD.forkedFromChain[1].originalAuthor, "third fork: chain[1] is John")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(forkB.originalAuthor, forkD.forkedFromChain[2].originalAuthor, "third fork: chain[2] is Daddysat")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(
        "Gaupanda",
        forkD.forkedFromChain[3].originalAuthor,
        "third fork: chain[3] is Gaupanda (preserved 2 hops back)"
    )
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

-- v2.1.0 Phase C polish: legacy-source inheritance. A pre-polish v2.1.0 fork
-- has forkedFrom but no forkedFromChain. Forking THAT sequence must still
-- produce a 2-deep chain (immediate + the legacy single-parent pointer).
TS:Register("Identity:StampForked inherits from legacy forkedFrom", "phase-c", function(self)
    local I = GRIPEMS.Identity
    if not I then
        self:Skip("Identity module not loaded")
        return
    end
    -- Pre-polish fork: forkedFrom set, forkedFromChain absent
    local legacyFork = {
        originalAuthor = "Daddysat",
        originalAuthorIdentity = string.rep("d", 64),
        originalAuthorRealm = "Realm",
        originalCreatedAt = 2000,
        originalSignature = "sigB",
        versions = { primary = { spells = { 200 } } },
        contextOverrides = {},
        modifierChain = {},
        forkedFrom = {
            originalAuthor = "Gaupanda",
            originalAuthorIdentity = string.rep("a", 64),
            originalAuthorRealm = "Realm",
            originalCreatedAt = 1000,
            originalSignature = "sigA",
            forkedAt = 1500,
        },
    }
    local newFork = {
        versions = legacyFork.versions,
        contextOverrides = legacyFork.contextOverrides,
    }
    I:StampForked(newFork, legacyFork)
    self:AssertEqual(
        2,
        #(newFork.forkedFromChain or {}),
        "legacy-source fork: chain has 2 entries (immediate + inherited grand-parent)"
    )
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(
        "Daddysat",
        newFork.forkedFromChain[1].originalAuthor,
        "legacy-source fork: chain[1] is the immediate parent"
    )
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(
        "Gaupanda",
        newFork.forkedFromChain[2].originalAuthor,
        "legacy-source fork: chain[2] inherited from sourceSeq.forkedFrom"
    )
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("Engine:DuplicateSequence carries MetaData.Dependencies", "phase-c", function(self)
    if self:_SkipIfCombat() then
        return
    end
    local Engine = GRIPEMS.Engine
    if not Engine or not Engine.DuplicateSequence then
        self:Skip("Engine not loaded")
        return
    end

    local sourceName = "_TS_ForkMetaSource"
    local forkName = "_TS_ForkMetaResult"

    local function cleanup()
        if Engine.sequences[sourceName] then
            Engine:DeactivateSequence(sourceName)
        end
        if Engine.sequences[forkName] then
            Engine:DeactivateSequence(forkName)
        end
    end

    cleanup()

    local sourceData = {
        name = sourceName,
        icon = 0,
        autoIcon = true,
        defaultVersion = 1,
        versions = { { steps = {}, stepFunction = "Sequential" } },
        contextOverrides = {},
        author = "MetaAuthor",
        version = "1",
        description = "src with MetaData",
        classID = 0,
        specID = 0,
        createdAt = 1234567890,
        updatedAt = 1234567890,
        MetaData = {
            Checksum = "abc123",
            GSEVersion = "3.3.07",
            Dependencies = {
                Macros = { "MacroA", "MacroB" },
                Sequences = { "SeqX" },
            },
        },
    }
    Engine:ActivateSequence(sourceName, sourceData)

    local ok, err = Engine:DuplicateSequence(sourceName, forkName)
    self:AssertEqual(true, ok, "DuplicateSequence succeeds (" .. tostring(err) .. ")")
    if currentResult.status == "fail" then
        cleanup()
        return
    end

    local forkEntry = Engine.sequences[forkName]
    self:Assert(forkEntry and forkEntry.data, "fork registered")
    if currentResult.status == "fail" then
        cleanup()
        return
    end

    local fd = forkEntry.data

    self:Assert(fd.MetaData, "fork has MetaData table")
    if currentResult.status == "fail" then
        cleanup()
        return
    end

    self:AssertEqual("abc123", fd.MetaData.Checksum, "fork preserves non-Dependencies MetaData (Checksum)")
    if currentResult.status == "fail" then
        cleanup()
        return
    end

    self:AssertEqual("3.3.07", fd.MetaData.GSEVersion, "fork preserves non-Dependencies MetaData (GSEVersion)")
    if currentResult.status == "fail" then
        cleanup()
        return
    end

    self:Assert(fd.MetaData.Dependencies, "fork has MetaData.Dependencies")
    if currentResult.status == "fail" then
        cleanup()
        return
    end

    local fMacros = fd.MetaData.Dependencies.Macros
    self:Assert(type(fMacros) == "table" and #fMacros == 2, "fork Dependencies.Macros is 2-entry array")
    if currentResult.status == "fail" then
        cleanup()
        return
    end

    self:AssertEqual("MacroA", fMacros[1], "fork Macros[1] == MacroA")
    self:AssertEqual("MacroB", fMacros[2], "fork Macros[2] == MacroB")

    local fSeqs = fd.MetaData.Dependencies.Sequences
    self:Assert(type(fSeqs) == "table" and #fSeqs == 1 and fSeqs[1] == "SeqX", "fork Dependencies.Sequences preserved")
    if currentResult.status == "fail" then
        cleanup()
        return
    end

    -- Independence check: mutating the fork's array MUST NOT touch source's array.
    fMacros[1] = "MutatedByFork"
    local srcEntry = Engine.sequences[sourceName]
    local sMacros = srcEntry
        and srcEntry.data
        and srcEntry.data.MetaData
        and srcEntry.data.MetaData.Dependencies
        and srcEntry.data.MetaData.Dependencies.Macros
    self:Assert(
        sMacros and sMacros[1] == "MacroA",
        "source Macros[1] unchanged after fork mutation (deep-copy independence)"
    )

    cleanup()
    self:Pass()
end)

-- ---------------------------------------------------------------------------
-- Category: phase-d -- v2.1.0 Authorship Integrity Phase D (Privacy modes)
-- ---------------------------------------------------------------------------

TS:Register("BuildExportPayload public mode preserves identity", "phase-d", function(self)
    local I = GRIPEMS.Identity
    if not I or not I.BuildExportPayload then
        self:Skip("Identity:BuildExportPayload not available")
        return
    end
    local me = I:GetCurrent()
    if not me or not me.identityHash or me.identityHash == "" then
        self:Skip("Identity:GetCurrent unavailable in test environment")
        return
    end
    local seq = {
        originalAuthor = me.displayName,
        originalAuthorIdentity = me.identityHash,
        originalAuthorRealm = me.realm,
        originalAuthorBattleTag = me.battleTag,
        modifierChain = {
            { name = me.displayName, identity = me.identityHash, kind = "created" },
        },
        privacyMode = "public",
    }
    local payload = I:BuildExportPayload(seq, "public")
    self:AssertEqual(me.displayName, payload.originalAuthor, "public: originalAuthor unchanged")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(me.identityHash, payload.originalAuthorIdentity, "public: identityHash unchanged")
    if currentResult.status == "fail" then
        return
    end
    -- Source must not be mutated even in public mode (deep-copy invariant)
    self:AssertEqual(me.displayName, seq.originalAuthor, "public: source seq not mutated")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("BuildExportPayload pseudonymous scrubs name keeps hash", "phase-d", function(self)
    local I = GRIPEMS.Identity
    if not I or not I.BuildExportPayload then
        self:Skip("Identity:BuildExportPayload not available")
        return
    end
    local me = I:GetCurrent()
    if not me or not me.identityHash or me.identityHash == "" then
        self:Skip("Identity:GetCurrent unavailable in test environment")
        return
    end
    _G.GRIP_EMS_DB = _G.GRIP_EMS_DB or {}
    _G.GRIP_EMS_DB.config = _G.GRIP_EMS_DB.config or {}
    local savedPseudonym = _G.GRIP_EMS_DB.config.pseudonym
    _G.GRIP_EMS_DB.config.pseudonym = "TestAlias"
    local seq = {
        originalAuthor = me.displayName,
        originalAuthorIdentity = me.identityHash,
        originalAuthorRealm = me.realm,
        originalAuthorBattleTag = me.battleTag,
        lastModifier = me.displayName,
        lastModifierIdentity = me.identityHash,
        modifierChain = {
            { name = me.displayName, identity = me.identityHash, kind = "created" },
        },
    }
    local payload = I:BuildExportPayload(seq, "pseudonymous")
    _G.GRIP_EMS_DB.config.pseudonym = savedPseudonym
    self:AssertEqual("TestAlias", payload.originalAuthor, "pseudonymous: originalAuthor replaced with pseudonym")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(
        me.identityHash,
        payload.originalAuthorIdentity,
        "pseudonymous: originalAuthorIdentity preserved (linkable across pseudonymous exports)"
    )
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(nil, payload.originalAuthorBattleTag, "pseudonymous: BattleTag stripped at export boundary")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("TestAlias", payload.lastModifier, "pseudonymous: lastModifier replaced with pseudonym")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(
        "TestAlias",
        payload.modifierChain[1].name,
        "pseudonymous: local modifierChain entry replaced with pseudonym"
    )
    if currentResult.status == "fail" then
        return
    end
    -- Source still untouched (deep-copy invariant)
    self:AssertEqual(me.displayName, seq.originalAuthor, "pseudonymous: source seq not mutated")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("BuildExportPayload private mode unlinkable per export", "phase-d", function(self)
    local I = GRIPEMS.Identity
    if not I or not I.BuildExportPayload then
        self:Skip("Identity:BuildExportPayload not available")
        return
    end
    local me = I:GetCurrent()
    if not me or not me.identityHash or me.identityHash == "" then
        self:Skip("Identity:GetCurrent unavailable in test environment")
        return
    end
    local seq = {
        originalAuthor = me.displayName,
        originalAuthorIdentity = me.identityHash,
        originalAuthorRealm = me.realm,
        modifierChain = {
            { name = me.displayName, identity = me.identityHash, kind = "created" },
        },
    }
    local p1 = I:BuildExportPayload(seq, "private")
    local p2 = I:BuildExportPayload(seq, "private")
    self:AssertEqual("Anonymous", p1.originalAuthor, "private: originalAuthor replaced with Anonymous")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("Anonymous", p2.originalAuthor, "private: second export also Anonymous")
    if currentResult.status == "fail" then
        return
    end
    -- The two exports must have DIFFERENT identityHash values (per-export salt)
    if p1.originalAuthorIdentity == p2.originalAuthorIdentity then
        self:Fail(
            "private: two exports produced the SAME identityHash; per-export salt missing -- exports would be linkable"
        )
        return
    end
    self:AssertEqual(64, #p1.originalAuthorIdentity, "private: salt is 64-char hex")
    if currentResult.status == "fail" then
        return
    end
    -- The real identity must not leak through any exported field
    if p1.originalAuthorIdentity == me.identityHash then
        self:Fail("private: salt collides with real identityHash; identity not actually scrubbed")
        return
    end
    self:Pass()
end)

TS:Register("BuildExportPayload preserves foreign chain entries", "phase-d", function(self)
    local I = GRIPEMS.Identity
    if not I or not I.BuildExportPayload then
        self:Skip("Identity:BuildExportPayload not available")
        return
    end
    local me = I:GetCurrent()
    if not me or not me.identityHash or me.identityHash == "" then
        self:Skip("Identity:GetCurrent unavailable in test environment")
        return
    end
    local foreignHash = string.rep("a", 64)
    local seq = {
        originalAuthor = me.displayName,
        originalAuthorIdentity = me.identityHash,
        originalAuthorRealm = me.realm,
        modifierChain = {
            { name = "Gaupanda", identity = foreignHash, kind = "created" },
            { name = me.displayName, identity = me.identityHash, kind = "forked-from" },
        },
        forkedFrom = {
            originalAuthor = "Gaupanda",
            originalAuthorIdentity = foreignHash,
            originalAuthorRealm = "Realm",
            originalCreatedAt = 1000,
            originalSignature = "sigA",
            forkedAt = 1500,
        },
        forkedFromChain = {
            {
                originalAuthor = "Gaupanda",
                originalAuthorIdentity = foreignHash,
                originalAuthorRealm = "Realm",
                originalCreatedAt = 1000,
                originalSignature = "sigA",
                forkedAt = 1500,
            },
        },
    }
    local payload = I:BuildExportPayload(seq, "private")
    self:AssertEqual("Anonymous", payload.originalAuthor, "private: local originalAuthor scrubbed")
    if currentResult.status == "fail" then
        return
    end
    -- Foreign author entries MUST stay visible
    self:AssertEqual("Gaupanda", payload.forkedFromChain[1].originalAuthor, "foreign forkedFromChain entry preserved")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(
        foreignHash,
        payload.forkedFromChain[1].originalAuthorIdentity,
        "foreign forkedFromChain identityHash preserved"
    )
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("Gaupanda", payload.forkedFrom.originalAuthor, "foreign forkedFrom entry preserved")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("Gaupanda", payload.modifierChain[1].name, "foreign modifierChain[1] (Gaupanda) preserved")
    if currentResult.status == "fail" then
        return
    end
    -- Local modifierChain entry was scrubbed
    self:AssertEqual("Anonymous", payload.modifierChain[2].name, "local modifierChain[2] scrubbed to Anonymous")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

-- ---------------------------------------------------------------------------
-- Category: variables -- Variable evaluation
-- ---------------------------------------------------------------------------

TS:Register("Create variable, verify evaluation", "variables", function(self)
    local VS = GRIPEMS.VariableStore
    if not VS then
        self:Fail("VariableStore not loaded")
        return
    end

    local varName = "_TS_VarSimple"
    VS:Set(varName, {
        name = varName,
        funct = "42",
        enabled = true,
    })

    local val = VS:Evaluate(varName)
    VS:Delete(varName)

    self:AssertEqual(42, val, "simple variable evaluation")
    if currentResult.status ~= "fail" then
        self:Pass()
    end
end)

TS:Register("Transitive variable reference returns nil (design intent)", "variables", function(self)
    local VS = GRIPEMS.VariableStore
    if not VS then
        self:Fail("VariableStore not loaded")
        return
    end

    local base = "_TS_VarBase"
    local ref = "_TS_VarRef"
    VS:Set(base, { name = base, funct = "100", enabled = true })
    VS:Set(ref, { name = ref, funct = "~" .. base .. "~ + 1", enabled = true })

    local val = VS:Evaluate(ref)
    VS:Delete(ref)
    VS:Delete(base)

    -- VS:Evaluate loadstrings the funct text verbatim. A funct
    -- containing "~name~" produces a Lua syntax error and
    -- Evaluate returns nil. Inline transitive substitution
    -- is intentionally NOT performed at the evaluator layer --
    -- Engine:SubstituteVariables handles the outer macrotext
    -- substitution pass. This test pins that boundary.
    if val == nil then
        self:Pass()
    else
        self:Fail("expected nil (transitive substitution not inline), got " .. tostring(val))
    end
end)

TS:Register("Delete variable, check dependents flagged", "variables", function(self)
    local VS = GRIPEMS.VariableStore
    if not VS then
        self:Fail("VariableStore not loaded")
        return
    end

    local varName = "_TS_VarDeps"
    VS:Set(varName, { name = varName, value = "1", enabled = true })

    -- GetReferences returns sequence names that use ~varName~
    -- (call it to exercise the path, result not needed for this test)
    VS:GetReferences(varName)
    VS:Delete(varName)

    -- After delete, variable should be gone
    local gone = VS:Get(varName) == nil
    if gone then
        self:Pass()
    else
        self:Fail("variable still present after Delete")
    end
end)

TS:Register("Variable with spell name gets localeRiskFlags", "variables", function(self)
    local VS = GRIPEMS.VariableStore
    if not VS then
        self:Skip("VariableStore not loaded")
        return
    end
    local name = "_TS_VarLocaleRisk"
    VS:Set(name, { name = name, value = '"Kill Command"', enabled = true })
    local risk = VS:GetLocaleRisk(name)
    VS:Delete(name)
    if risk then
        self:Assert(risk.spellName ~= nil, "localeRisk should have spellName")
        self:Assert(risk.spellID ~= nil, "localeRisk should have spellID")
    end
    self:Pass()
end)

TS:Register("Variable with non-spell value has no localeRiskFlags", "variables", function(self)
    local VS = GRIPEMS.VariableStore
    if not VS then
        self:Skip("VariableStore not loaded")
        return
    end
    local name = "_TS_VarNoRisk"
    VS:Set(name, { name = name, value = "42", enabled = true })
    local risk = VS:GetLocaleRisk(name)
    VS:Delete(name)
    self:AssertEqual(nil, risk, "numeric value should have no locale risk")
    self:Pass()
end)

TS:Register("Variable taggedValue populated after Set (if spell known)", "variables", function(self)
    local VS = GRIPEMS.VariableStore
    if not VS then
        self:Skip("VariableStore not loaded")
        return
    end
    local name = "_TS_VarTagged"
    VS:Set(name, {
        name = name,
        value = '"/cast Kill Command"',
        enabled = true,
    })
    local raw = VS:Get(name)
    VS:Delete(name)
    if raw and raw.taggedValue then
        self:Assert(raw.taggedValue:find("{spell:"), "taggedValue should contain {spell:} tag")
        self:Assert(raw.valueLocale ~= nil, "valueLocale should be set")
    end
    self:Pass()
end)

TS:Register("HealLocaleVariables exists and is callable", "variables", function(self)
    local VS = GRIPEMS.VariableStore
    if not VS then
        self:Skip("VariableStore not loaded")
        return
    end
    self:Assert(VS.HealLocaleVariables ~= nil, "HealLocaleVariables should exist")
    local healed = VS:HealLocaleVariables()
    self:Assert(type(healed) == "number", "HealLocaleVariables should return count")
    self:Pass()
end)

-- ---------------------------------------------------------------------------
-- Category: keybind -- Keybind assignment
-- ---------------------------------------------------------------------------

TS:Register("Assign keybind, verify GetKeybind", "keybind", function(self)
    local KM = GRIPEMS.KeybindManager
    local OOC = GRIPEMS.OOCQueue
    local D = GRIPEMS.Defaults
    local Engine = GRIPEMS.Engine
    if not KM or not OOC or not D or not Engine then
        self:Fail("KeybindManager, OOCQueue, Defaults, or Engine not loaded")
        return
    end

    if OOC.IsRestricted() then
        self:Skip("in combat -- keybind tests require OOC")
        return
    end

    local name = "_TS_KeybindSet"
    if Engine.sequences[name] then
        Engine:DeactivateSequence(name)
    end

    local seqData = D.NewSequenceFromTemplate(name, D.TestSequence)
    Engine:ActivateSequence(name, seqData)

    KM:SetKeybind(name, "F12")
    local bound = KM:GetKeybind(name)

    -- Cleanup
    KM:ClearKeybind(name)
    Engine:DeactivateSequence(name)

    if bound == "F12" then
        self:Pass()
    else
        self:Fail("expected F12, got " .. tostring(bound))
    end
end)

TS:Register("Clear keybind, verify cleared", "keybind", function(self)
    local KM = GRIPEMS.KeybindManager
    local OOC = GRIPEMS.OOCQueue
    local D = GRIPEMS.Defaults
    local Engine = GRIPEMS.Engine
    if not KM or not OOC or not D or not Engine then
        self:Fail("KeybindManager, OOCQueue, Defaults, or Engine not loaded")
        return
    end

    if OOC.IsRestricted() then
        self:Skip("in combat -- keybind tests require OOC")
        return
    end

    local name = "_TS_KeybindClr"
    if Engine.sequences[name] then
        Engine:DeactivateSequence(name)
    end

    local seqData = D.NewSequenceFromTemplate(name, D.TestSequence)
    Engine:ActivateSequence(name, seqData)
    KM:SetKeybind(name, "F11")
    KM:ClearKeybind(name)

    local bound = KM:GetKeybind(name)
    Engine:DeactivateSequence(name)

    if bound == nil then
        self:Pass()
    else
        self:Fail("keybind still present: " .. tostring(bound))
    end
end)

TS:Register("Clear keybind per-loadout: dispatch routes overlay clear", "keybind", function(self)
    local KM = GRIPEMS.KeybindManager
    local OOC = GRIPEMS.OOCQueue
    local D = GRIPEMS.Defaults
    local Engine = GRIPEMS.Engine
    if not KM or not OOC or not D or not Engine then
        self:Fail("KeybindManager, OOCQueue, Defaults, or Engine not loaded")
        return
    end

    if OOC.IsRestricted() then
        self:Skip("in combat -- keybind tests require OOC")
        return
    end

    -- Per-loadout dispatch needs an active saved loadout; skip cleanly when the
    -- current session has none (e.g. a fresh character with no applied loadout).
    local activeLoadoutID = KM:_GetActiveLoadoutID()
    if not activeLoadoutID then
        self:Skip("no active loadout -- per-loadout dispatch path unavailable")
        return
    end

    -- Force the per-loadout flag so SetKeybind/ClearKeybind take the overlay
    -- path. Snapshot the prior value so the suite stays repeatable.
    GRIP_EMS_CHAR = GRIP_EMS_CHAR or {}
    local savedFlag = GRIP_EMS_CHAR.keybindsPerLoadout
    GRIP_EMS_CHAR.keybindsPerLoadout = true

    local name = "_TS_KeybindClrPL"
    if Engine.sequences[name] then
        Engine:DeactivateSequence(name)
    end

    local seqData = D.NewSequenceFromTemplate(name, D.TestSequence)
    Engine:ActivateSequence(name, seqData)
    KM:SetKeybind(name, "F11")
    local boundBefore = KM:GetKeybind(name)
    KM:ClearKeybind(name)
    local boundAfter = KM:GetKeybind(name)

    -- Restore session state before asserting.
    GRIP_EMS_CHAR.keybindsPerLoadout = savedFlag
    Engine:DeactivateSequence(name)

    if boundBefore ~= "F11" then
        self:Fail("setup failed: expected F11 before clear, got " .. tostring(boundBefore))
        return
    end
    if boundAfter == nil then
        self:Pass()
    else
        self:Fail("keybind still present after per-loadout clear: " .. tostring(boundAfter))
    end
end)

TS:Register("KB: Clear falls back to the per-spec layer when the loadout overlay is empty", "keybind", function(self)
    local KM = GRIPEMS.KeybindManager
    local OOC = GRIPEMS.OOCQueue
    local D = GRIPEMS.Defaults
    local Engine = GRIPEMS.Engine
    if not KM or not OOC or not D or not Engine then
        self:Fail("KeybindManager, OOCQueue, Defaults, or Engine not loaded")
        return
    end

    if OOC.IsRestricted() then
        self:Skip("in combat -- keybind tests require OOC")
        return
    end

    local activeLoadoutID = KM:_GetActiveLoadoutID()
    if not activeLoadoutID then
        self:Skip("no active loadout -- per-loadout dispatch path unavailable")
        return
    end

    -- Reach the reported shape: a bind that lives in the PER-SPEC layer while a
    -- loadout is active. Binding with the flag OFF routes SetKeybind through
    -- _SetKeybindPerSpec, which is how the reporter got here (bound before
    -- per-loadout mode was switched on). Going through KM:SetKeybind rather than
    -- poking _SetKeybindPerSpec keeps the fixture on the public path.
    GRIP_EMS_CHAR = GRIP_EMS_CHAR or {}
    local savedFlag = GRIP_EMS_CHAR.keybindsPerLoadout
    GRIP_EMS_CHAR.keybindsPerLoadout = false

    local name = "_TS_KeybindClrFallback"
    if Engine.sequences[name] then
        Engine:DeactivateSequence(name)
    end

    local seqData = D.NewSequenceFromTemplate(name, D.TestSequence)
    Engine:ActivateSequence(name, seqData)
    KM:SetKeybind(name, "F11")

    -- Now switch per-loadout mode on. The overlay holds nothing for this
    -- sequence, but the merged view still renders the per-spec key -- exactly
    -- what the Current Keybind box showed when Clear reported no binding.
    GRIP_EMS_CHAR.keybindsPerLoadout = true
    local boundBefore = KM:GetKeybind(name)

    KM:ClearKeybind(name)

    local boundAfter = KM:GetKeybind(name)
    -- Read the per-spec layer directly too: a suppress-based implementation would
    -- also make the merged view read nil, so the merged read alone cannot tell a
    -- global removal from a loadout-scoped one.
    local specIdx = KM:GetCurrentSpec()
    local specBinds = GRIP_EMS_CHAR.keybinds and GRIP_EMS_CHAR.keybinds[specIdx]
    local perSpecKey = nil
    if specBinds then
        for key, boundSeq in pairs(specBinds) do
            if key ~= "_byLoadout" and boundSeq == name then
                perSpecKey = key
                break
            end
        end
    end

    -- Restore session state before asserting.
    GRIP_EMS_CHAR.keybindsPerLoadout = savedFlag
    Engine:DeactivateSequence(name)

    if boundBefore ~= "F11" then
        self:Fail("setup failed: expected F11 from the merged view before clear, got " .. tostring(boundBefore))
        return
    end
    if boundAfter ~= nil then
        self:Fail("keybind still present after fallback clear: " .. tostring(boundAfter))
        return
    end
    if perSpecKey ~= nil then
        self:Fail("per-spec layer still carries the key after fallback clear: " .. tostring(perSpecKey))
        return
    end
    self:Pass()
end)

TS:Register("KB: GetKeybind returns nil while the active loadout suppresses the per-spec key", "keybind", function(self)
    local KM = GRIPEMS.KeybindManager
    local OOC = GRIPEMS.OOCQueue
    local D = GRIPEMS.Defaults
    local Engine = GRIPEMS.Engine
    if not KM or not OOC or not D or not Engine then
        self:Fail("KeybindManager, OOCQueue, Defaults, or Engine not loaded")
        return
    end

    if OOC.IsRestricted() then
        self:Skip("in combat -- keybind tests require OOC")
        return
    end

    local activeLoadoutID = KM:_GetActiveLoadoutID()
    if not activeLoadoutID then
        self:Skip("no active loadout -- per-loadout dispatch path unavailable")
        return
    end

    -- Bind with the flag OFF so the key lands in the PER-SPEC layer, then plant
    -- the active loadout's "__suppress__" sentinel on that key -- the exact
    -- state the suppress checkbox produces. The merged read must report the
    -- bind dead while the sentinel stands and alive again once it is lifted;
    -- the live driver already behaves this way, so any other answer is the UI
    -- contradicting the engine.
    GRIP_EMS_CHAR = GRIP_EMS_CHAR or {}
    local savedFlag = GRIP_EMS_CHAR.keybindsPerLoadout
    GRIP_EMS_CHAR.keybindsPerLoadout = false

    local name = "_TS_KeybindSuppressRead"
    if Engine.sequences[name] then
        Engine:DeactivateSequence(name)
    end

    local seqData = D.NewSequenceFromTemplate(name, D.TestSequence)
    Engine:ActivateSequence(name, seqData)
    KM:SetKeybind(name, "F11")

    KM:_SuppressKeybindForLoadout("F11", activeLoadoutID)
    local suppressedRead = KM:GetKeybind(name)

    KM:_UnsuppressKeybindForLoadout("F11", activeLoadoutID)
    local unsuppressedRead = KM:GetKeybind(name)

    -- Restore session state before asserting. The flag is still OFF, so this
    -- clear routes through the per-spec layer where the fixture bound the key.
    KM:ClearKeybind(name)
    Engine:DeactivateSequence(name)
    GRIP_EMS_CHAR.keybindsPerLoadout = savedFlag

    if suppressedRead ~= nil then
        self:Fail("GetKeybind rendered a suppressed bind as live: " .. tostring(suppressedRead))
        return
    end
    if unsuppressedRead ~= "F11" then
        self:Fail("expected F11 back after unsuppress, got " .. tostring(unsuppressedRead))
        return
    end
    self:Pass()
end)

-- Depends on the suppress-sentinel check in GetKeybind proven by the test
-- above: a stale sentinel is only VISIBLE here because GetKeybind returns nil
-- for a suppressed per-spec key. With the sentinel sweep in
-- _ClearKeybindPerSpec reverted, the sentinel survives the clear and that
-- check turns the fresh F11 rebind into a nil read, failing the final assert.
TS:Register("KB: per-spec clear reaps suppress sentinels so a rebind is not ghost-hidden", "keybind", function(self)
    local KM = GRIPEMS.KeybindManager
    local OOC = GRIPEMS.OOCQueue
    local D = GRIPEMS.Defaults
    local Engine = GRIPEMS.Engine
    if not KM or not OOC or not D or not Engine then
        self:Fail("KeybindManager, OOCQueue, Defaults, or Engine not loaded")
        return
    end

    if OOC.IsRestricted() then
        self:Skip("in combat -- keybind tests require OOC")
        return
    end

    local activeLoadoutID = KM:_GetActiveLoadoutID()
    if not activeLoadoutID then
        self:Skip("no active loadout -- per-loadout dispatch path unavailable")
        return
    end

    -- Per-spec bind plus a loadout sentinel on its key, then a flag-ON Clear:
    -- the overlay probe returns false (a sentinel is not a sequence entry), so
    -- Clear falls back to the per-spec layer, which must remove the binding
    -- AND reap the now-referentless sentinel. A surviving sentinel would
    -- silently hide a FUTURE rebind of the same key in this loadout -- a
    -- suppression the user never chose for the new binding.
    GRIP_EMS_CHAR = GRIP_EMS_CHAR or {}
    local savedFlag = GRIP_EMS_CHAR.keybindsPerLoadout
    GRIP_EMS_CHAR.keybindsPerLoadout = false

    local name = "_TS_KeybindSuppressReap"
    if Engine.sequences[name] then
        Engine:DeactivateSequence(name)
    end

    local seqData = D.NewSequenceFromTemplate(name, D.TestSequence)
    Engine:ActivateSequence(name, seqData)
    KM:SetKeybind(name, "F11")
    KM:_SuppressKeybindForLoadout("F11", activeLoadoutID)

    GRIP_EMS_CHAR.keybindsPerLoadout = true
    KM:ClearKeybind(name)

    local specIdx = KM:GetCurrentSpec()
    local specBinds = GRIP_EMS_CHAR.keybinds and GRIP_EMS_CHAR.keybinds[specIdx]
    local perSpecKey = nil
    if specBinds then
        for key, boundSeq in pairs(specBinds) do
            if key ~= "_byLoadout" and boundSeq == name then
                perSpecKey = key
                break
            end
        end
    end
    local bucket = specBinds and specBinds._byLoadout and specBinds._byLoadout[activeLoadoutID]
    local sentinelSurvives = bucket ~= nil and bucket["F11"] ~= nil

    -- Rebind the same key with the flag OFF again: the fresh per-spec bind
    -- must read back live through the merged view.
    GRIP_EMS_CHAR.keybindsPerLoadout = false
    KM:SetKeybind(name, "F11")
    local reboundRead = KM:GetKeybind(name)

    -- Restore session state before asserting. The flag is OFF, so this clear
    -- routes through the per-spec layer where the rebind landed.
    KM:ClearKeybind(name)
    Engine:DeactivateSequence(name)
    GRIP_EMS_CHAR.keybindsPerLoadout = savedFlag

    if perSpecKey ~= nil then
        self:Fail("per-spec layer still maps a key to the sequence after clear: " .. tostring(perSpecKey))
        return
    end
    if sentinelSurvives then
        self:Fail("suppress sentinel for F11 survived the per-spec clear")
        return
    end
    if reboundRead ~= "F11" then
        self:Fail("fresh rebind ghost-hidden by a stale sentinel: expected F11, got " .. tostring(reboundRead))
        return
    end
    self:Pass()
end)

TS:Register("keybind set recompute disables without loaded sequence", "keybind", function(self)
    local KT = GRIPEMS.KeybindTab
    local UI = GRIPEMS.UI
    local OOC = GRIPEMS.OOCQueue
    if not KT or not UI or not OOC then
        self:Fail("KeybindTab, UI, or OOCQueue not loaded")
        return
    end

    if OOC.IsRestricted() then
        self:Skip("in combat -- keybind tests require OOC")
        return
    end

    local mf = _G.GRIPEMS_MainFrame
    local openedByTest = false
    if not (mf and mf.IsShown and mf:IsShown()) then
        if not (UI and UI.ToggleMainFrame) then
            self:Skip("GRIPEMS.UI.ToggleMainFrame missing -- cannot bootstrap the EMS window")
            return
        end
        UI:ToggleMainFrame()
        openedByTest = true
    end
    if not KT.frame then
        if openedByTest then
            UI:ToggleMainFrame()
        end
        self:Skip("KeybindTab UI unavailable after ToggleMainFrame")
        return
    end

    -- The recompute must actively Disable when no sequence is loaded; the old
    -- shape left whatever state the button happened to carry.
    local savedName = KT.currentSeqName
    KT.currentSeqName = nil
    KT:RefreshDisplay()
    local enabled = KT.setBtn and KT.setBtn:IsEnabled()

    -- Restore the prior tab state before asserting.
    KT.currentSeqName = savedName
    KT:RefreshDisplay()
    if openedByTest then
        UI:ToggleMainFrame()
    end

    if enabled then
        self:Fail("Set button stayed enabled with no loaded sequence")
        return
    end
    self:Pass()
end)

TS:Register("keybind set recompute heals stale disable when loaded", "keybind", function(self)
    local KT = GRIPEMS.KeybindTab
    local UI = GRIPEMS.UI
    local OOC = GRIPEMS.OOCQueue
    local D = GRIPEMS.Defaults
    local Engine = GRIPEMS.Engine
    if not KT or not UI or not OOC or not D or not Engine then
        self:Fail("KeybindTab, UI, OOCQueue, Defaults, or Engine not loaded")
        return
    end

    if OOC.IsRestricted() then
        self:Skip("in combat -- keybind tests require OOC")
        return
    end

    local mf = _G.GRIPEMS_MainFrame
    local openedByTest = false
    if not (mf and mf.IsShown and mf:IsShown()) then
        if not (UI and UI.ToggleMainFrame) then
            self:Skip("GRIPEMS.UI.ToggleMainFrame missing -- cannot bootstrap the EMS window")
            return
        end
        UI:ToggleMainFrame()
        openedByTest = true
    end
    if not KT.frame then
        if openedByTest then
            UI:ToggleMainFrame()
        end
        self:Skip("KeybindTab UI unavailable after ToggleMainFrame")
        return
    end

    local savedName = KT.currentSeqName

    local name = "_TS_KeybindSetHeal"
    if Engine.sequences[name] then
        Engine:DeactivateSequence(name)
    end

    local seqData = D.NewSequenceFromTemplate(name, D.TestSequence)
    Engine:ActivateSequence(name, seqData)

    -- Fake the stale combat-time Disable, then load the sequence: the
    -- both-ways recompute in RefreshDisplay must re-enable from the loaded
    -- state alone, with no keybind event required.
    if KT.setBtn then
        KT.setBtn:Disable()
    end
    KT:LoadSequence(name)
    local enabled = KT.setBtn and KT.setBtn:IsEnabled()

    -- Teardown: drop the temp sequence, then restore the prior tab state.
    -- Restore via currentSeqName + RefreshDisplay (the Test A idiom), NOT
    -- KT:Clear -- Clear pops the KeybindTab focus context, which kills the
    -- tab's Tab-focus targets when the user's window stays open on it.
    -- RefreshDisplay with a nil name renders the same cleared state (None
    -- display, Set and Clear disabled) without the pop.
    Engine:DeactivateSequence(name)
    if savedName and Engine.sequences[savedName] then
        KT:LoadSequence(savedName)
    else
        KT.currentSeqName = nil
        KT:RefreshDisplay()
    end
    if openedByTest then
        UI:ToggleMainFrame()
    end

    if not enabled then
        self:Fail("Set button still disabled after LoadSequence recompute")
        return
    end
    self:Pass()
end)

TS:Register("keybind deferred-activation repair reloads selected sequence", "keybind", function(self)
    local KT = GRIPEMS.KeybindTab
    local SE = GRIPEMS.SequenceEditor
    local SL = GRIPEMS.SequenceList
    local UI = GRIPEMS.UI
    local OOC = GRIPEMS.OOCQueue
    local D = GRIPEMS.Defaults
    local Engine = GRIPEMS.Engine
    if not KT or not SE or not SL or not UI or not OOC or not D or not Engine then
        self:Fail("KeybindTab, SequenceEditor, SequenceList, UI, OOCQueue, Defaults, or Engine not loaded")
        return
    end

    if OOC.IsRestricted() then
        self:Skip("in combat -- keybind tests require OOC")
        return
    end

    local mf = _G.GRIPEMS_MainFrame
    local openedByTest = false
    if not (mf and mf.IsShown and mf:IsShown()) then
        if not (UI and UI.ToggleMainFrame) then
            self:Skip("GRIPEMS.UI.ToggleMainFrame missing -- cannot bootstrap the EMS window")
            return
        end
        UI:ToggleMainFrame()
        openedByTest = true
    end
    if not KT.frame then
        if openedByTest then
            UI:ToggleMainFrame()
        end
        self:Skip("KeybindTab UI unavailable after ToggleMainFrame")
        return
    end

    -- The repair path reloads the live editor, which drops unsaved edits and
    -- the undo history. Never sacrifice real work to a diagnostic run.
    if SE.isDirty then
        if openedByTest then
            UI:ToggleMainFrame()
        end
        self:Skip("editor has unsaved changes -- save or discard before running this test")
        return
    end

    local savedSelection = UI.selectedSequence
    local savedEditorName = SE.currentSequence

    local name = "_TS_KeybindDeferRepair"
    if Engine.sequences[name] then
        Engine:DeactivateSequence(name)
    end

    -- Simulate the in-combat New Sequence leftover: the list row is selected
    -- but the editor never loaded the (then missing) engine entry, so
    -- SE.currentSequence differs from the selected name.
    UI.selectedSequence = name
    if savedEditorName == name then
        SE:Clear()
    end

    -- Minimal seqData shaped like the New dialog template.
    local seqData = {
        name = name,
        icon = D.NewSequence.icon,
        defaultVersion = 1,
        versions = {
            [1] = {
                stepFunction = D.NewVersion.stepFunction,
                steps = {},
            },
        },
        author = UnitName("player") or "",
        version = "1",
        classID = select(3, UnitClass("player")) or 0,
    }

    -- Out of combat the queued activation closure runs synchronously and
    -- fires SEQUENCE_CREATED; the repair in SL:OnSequenceChanged must reload
    -- the editor for the still-selected name.
    Engine:ActivateSequence(name, seqData)

    local editorLoaded = SE.currentSequence == name
    local tabLoaded = KT.currentSeqName == name

    -- Teardown: drop the temp sequence, then restore the prior selection.
    Engine:DeactivateSequence(name)
    if savedSelection and Engine.sequences[savedSelection] then
        SL:DoSelectSequence(savedSelection)
    else
        UI.selectedSequence = savedSelection
        SE:Clear()
        SL._dataDirty = true
        SL:RefreshDataProvider()
    end
    if openedByTest then
        UI:ToggleMainFrame()
    end

    if not editorLoaded then
        self:Fail("editor did not reload the selected sequence when the queued activation landed")
        return
    end
    if not tabLoaded then
        self:Fail("keybind tab did not receive the sequence after the deferred-activation repair")
        return
    end
    self:Pass()
end)

TS:Register("keybind dormant row loads editor exactly once", "keybind", function(self)
    local KT = GRIPEMS.KeybindTab
    local SE = GRIPEMS.SequenceEditor
    local SL = GRIPEMS.SequenceList
    local UI = GRIPEMS.UI
    local OOC = GRIPEMS.OOCQueue
    local D = GRIPEMS.Defaults
    local Engine = GRIPEMS.Engine
    if not KT or not SE or not SL or not UI or not OOC or not D or not Engine then
        self:Fail("KeybindTab, SequenceEditor, SequenceList, UI, OOCQueue, Defaults, or Engine not loaded")
        return
    end

    if OOC.IsRestricted() then
        self:Skip("in combat -- keybind tests require OOC")
        return
    end

    local mf = _G.GRIPEMS_MainFrame
    local openedByTest = false
    if not (mf and mf.IsShown and mf:IsShown()) then
        if not (UI and UI.ToggleMainFrame) then
            self:Skip("GRIPEMS.UI.ToggleMainFrame missing -- cannot bootstrap the EMS window")
            return
        end
        UI:ToggleMainFrame()
        openedByTest = true
    end
    if not KT.frame then
        if openedByTest then
            UI:ToggleMainFrame()
        end
        self:Skip("KeybindTab UI unavailable after ToggleMainFrame")
        return
    end

    -- Selecting the dormant row loads the live editor, which drops unsaved
    -- edits and the undo history. Never sacrifice real work to a diagnostic
    -- run.
    if SE.isDirty then
        if openedByTest then
            UI:ToggleMainFrame()
        end
        self:Skip("editor has unsaved changes -- save or discard before running this test")
        return
    end

    local savedSelection = UI.selectedSequence
    local savedEditorName = SE.currentSequence

    local name = "_TS_KeybindDormantLoad"
    if Engine.sequences[name] then
        Engine:DeactivateSequence(name)
    end
    if savedEditorName == name then
        SE:Clear()
    end

    -- Fabricate a wrong-class dormant temp through the SAME registration
    -- entry the login path uses (RestoreSavedSequences wrong-class branch:
    -- RegisterSequenceOnly leaves button = nil). Minimal seqData shaped like
    -- the New dialog template.
    local myClass = select(3, UnitClass("player")) or 0
    local foreignClass = (myClass == 1) and 2 or 1
    local seqData = {
        name = name,
        icon = D.NewSequence.icon,
        defaultVersion = 1,
        versions = {
            [1] = {
                stepFunction = D.NewVersion.stepFunction,
                steps = {},
            },
        },
        author = UnitName("player") or "",
        version = "1",
        classID = foreignClass,
    }
    Engine:RegisterSequenceOnly(name, seqData)

    if not Engine:IsSequenceDormant(name) then
        if Engine.sequences[name] then
            Engine:DeactivateSequence(name)
        end
        if openedByTest then
            UI:ToggleMainFrame()
        end
        self:Skip("could not fabricate a dormant sequence")
        return
    end

    -- Count-wrap the editor load: clicking the dormant row must promote and
    -- populate exactly once (the load latch keeps the SEQUENCE_CREATED repair
    -- from re-entering mid-load). Restore the wrap IMMEDIATELY after the
    -- call, before captures and asserts, so a Fail can never leak the
    -- wrapper.
    local origLoad = SE.LoadSequence
    local loadCalls = 0
    SE.LoadSequence = function(...)
        loadCalls = loadCalls + 1
        return origLoad(...)
    end
    local ok, err = pcall(SL.DoSelectSequence, SL, name)
    SE.LoadSequence = origLoad

    local promoted = not Engine:IsSequenceDormant(name)
    local editorLoaded = SE.currentSequence == name
    local btnEnabled = KT.setBtn and KT.setBtn:IsEnabled()

    -- Teardown: drop the temp sequence, then restore the prior selection.
    Engine:DeactivateSequence(name)
    if savedSelection and Engine.sequences[savedSelection] then
        SL:DoSelectSequence(savedSelection)
    else
        UI.selectedSequence = savedSelection
        SE:Clear()
        SL._dataDirty = true
        SL:RefreshDataProvider()
    end
    if openedByTest then
        UI:ToggleMainFrame()
    end

    if not ok then
        self:Fail(tostring(err))
        return
    end
    if loadCalls ~= 1 then
        self:Fail("editor populated " .. loadCalls .. " times -- expected exactly 1")
        return
    end
    if not promoted then
        self:Fail("dormant sequence was not promoted on row selection")
        return
    end
    if not editorLoaded then
        self:Fail("editor did not load the promoted sequence")
        return
    end
    if not btnEnabled then
        self:Fail("Set button not enabled after the dormant row load")
        return
    end
    self:Pass()
end)

TS:Register("keybind set disables on editor clear cascade", "keybind", function(self)
    local KT = GRIPEMS.KeybindTab
    local SE = GRIPEMS.SequenceEditor
    local SL = GRIPEMS.SequenceList
    local UI = GRIPEMS.UI
    local OOC = GRIPEMS.OOCQueue
    local D = GRIPEMS.Defaults
    local Engine = GRIPEMS.Engine
    if not KT or not SE or not SL or not UI or not OOC or not D or not Engine then
        self:Fail("KeybindTab, SequenceEditor, SequenceList, UI, OOCQueue, Defaults, or Engine not loaded")
        return
    end

    if OOC.IsRestricted() then
        self:Skip("in combat -- keybind tests require OOC")
        return
    end

    local mf = _G.GRIPEMS_MainFrame
    local openedByTest = false
    if not (mf and mf.IsShown and mf:IsShown()) then
        if not (UI and UI.ToggleMainFrame) then
            self:Skip("GRIPEMS.UI.ToggleMainFrame missing -- cannot bootstrap the EMS window")
            return
        end
        UI:ToggleMainFrame()
        openedByTest = true
    end
    if not KT.frame then
        if openedByTest then
            UI:ToggleMainFrame()
        end
        self:Skip("KeybindTab UI unavailable after ToggleMainFrame")
        return
    end

    -- The load + clear below replace the live editor content, which drops
    -- unsaved edits and the undo history. Never sacrifice real work to a
    -- diagnostic run.
    if SE.isDirty then
        if openedByTest then
            UI:ToggleMainFrame()
        end
        self:Skip("editor has unsaved changes -- save or discard before running this test")
        return
    end

    local savedSelection = UI.selectedSequence
    local savedEditorName = SE.currentSequence

    local name = "_TS_KeybindClearCascade"
    if Engine.sequences[name] then
        Engine:DeactivateSequence(name)
    end
    if savedEditorName == name then
        SE:Clear()
    end

    local seqData = D.NewSequenceFromTemplate(name, D.TestSequence)
    Engine:ActivateSequence(name, seqData)

    -- Load through the editor so the keybind tab picks the sequence up, then
    -- drive the cascade: SE:Clear calls KT:Clear, which must actively disable
    -- the Set button (a cleared tab with an enabled no-op Set is the bug).
    SE:LoadSequence(name)
    local enabledLoaded = KT.setBtn and KT.setBtn:IsEnabled()

    SE:Clear()
    local enabledCleared = KT.setBtn and KT.setBtn:IsEnabled()

    -- Teardown: drop the temp sequence, then restore the prior selection.
    Engine:DeactivateSequence(name)
    if savedSelection and Engine.sequences[savedSelection] then
        SL:DoSelectSequence(savedSelection)
    else
        UI.selectedSequence = savedSelection
        SE:Clear()
        SL._dataDirty = true
        SL:RefreshDataProvider()
    end
    if openedByTest then
        UI:ToggleMainFrame()
    end

    if not enabledLoaded then
        self:Fail("Set button not enabled after load")
        return
    end
    if enabledCleared then
        self:Fail("Set button stayed enabled after the editor clear cascade")
        return
    end
    self:Pass()
end)

TS:Register("keybind dormant re-fire does not re-enter editor", "keybind", function(self)
    local KT = GRIPEMS.KeybindTab
    local SE = GRIPEMS.SequenceEditor
    local SL = GRIPEMS.SequenceList
    local UI = GRIPEMS.UI
    local OOC = GRIPEMS.OOCQueue
    local D = GRIPEMS.Defaults
    local Engine = GRIPEMS.Engine
    if not KT or not SE or not SL or not UI or not OOC or not D or not Engine then
        self:Fail("KeybindTab, SequenceEditor, SequenceList, UI, OOCQueue, Defaults, or Engine not loaded")
        return
    end

    if OOC.IsRestricted() then
        self:Skip("in combat -- keybind tests require OOC")
        return
    end

    local mf = _G.GRIPEMS_MainFrame
    local openedByTest = false
    if not (mf and mf.IsShown and mf:IsShown()) then
        if not (UI and UI.ToggleMainFrame) then
            self:Skip("GRIPEMS.UI.ToggleMainFrame missing -- cannot bootstrap the EMS window")
            return
        end
        UI:ToggleMainFrame()
        openedByTest = true
    end
    if not KT.frame then
        if openedByTest then
            UI:ToggleMainFrame()
        end
        self:Skip("KeybindTab UI unavailable after ToggleMainFrame")
        return
    end

    -- A guard regression would re-enter the live editor and drop unsaved
    -- edits and the undo history. Never sacrifice real work to a diagnostic
    -- run.
    if SE.isDirty then
        if openedByTest then
            UI:ToggleMainFrame()
        end
        self:Skip("editor has unsaved changes -- save or discard before running this test")
        return
    end

    local savedSelection = UI.selectedSequence
    local savedEditorName = SE.currentSequence

    local name = "_TS_KeybindDormantRefire"
    if Engine.sequences[name] then
        Engine:DeactivateSequence(name)
    end
    if savedEditorName == name then
        SE:Clear()
    end

    -- Fabricate a wrong-class dormant temp through the SAME registration
    -- entry the login path uses (RestoreSavedSequences wrong-class branch:
    -- RegisterSequenceOnly leaves button = nil). Minimal seqData shaped like
    -- the New dialog template.
    local myClass = select(3, UnitClass("player")) or 0
    local foreignClass = (myClass == 1) and 2 or 1
    local seqData = {
        name = name,
        icon = D.NewSequence.icon,
        defaultVersion = 1,
        versions = {
            [1] = {
                stepFunction = D.NewVersion.stepFunction,
                steps = {},
            },
        },
        author = UnitName("player") or "",
        version = "1",
        classID = foreignClass,
    }
    Engine:RegisterSequenceOnly(name, seqData)

    if not Engine:IsSequenceDormant(name) then
        if Engine.sequences[name] then
            Engine:DeactivateSequence(name)
        end
        if openedByTest then
            UI:ToggleMainFrame()
        end
        self:Skip("could not fabricate a dormant sequence")
        return
    end

    -- The disabled/dormant re-fire shape from the Phase 1 investigation:
    -- selected name, editor not loaded, sequence still dormant. Select
    -- WITHOUT going through the list so the editor stays unloaded, then fire
    -- SEQUENCE_CREATED for the still-dormant name -- the dormant guard in
    -- SL:OnSequenceChanged plus the load latch must keep the repair from
    -- re-entering the editor. Restore the wrap IMMEDIATELY after the fire,
    -- before teardown and asserts, so a Fail can never leak the wrapper.
    UI.selectedSequence = name

    local origLoad = SE.LoadSequence
    local loadCalls = 0
    SE.LoadSequence = function(...)
        loadCalls = loadCalls + 1
        return origLoad(...)
    end
    GRIPEMS:Fire("SEQUENCE_CREATED", name, seqData)
    SE.LoadSequence = origLoad

    -- Teardown: drop the temp if it survived, then restore the prior
    -- selection.
    if Engine.sequences[name] then
        Engine:DeactivateSequence(name)
    end
    if savedSelection and Engine.sequences[savedSelection] then
        SL:DoSelectSequence(savedSelection)
    else
        UI.selectedSequence = savedSelection
        SE:Clear()
        SL._dataDirty = true
        SL:RefreshDataProvider()
    end
    if openedByTest then
        UI:ToggleMainFrame()
    end

    if loadCalls ~= 0 then
        self:Fail("repair re-entered the editor on a still-dormant fire -- guard regressed")
        return
    end
    self:Pass()
end)

-- ---------------------------------------------------------------------------
-- Category: context -- Context version dispatch
-- ---------------------------------------------------------------------------

TS:Register("Context version dispatch (Raid vs Dungeon)", "context", function(self)
    if self:_SkipIfCombat() then
        return
    end
    local D = GRIPEMS.Defaults
    local Engine = GRIPEMS.Engine
    if not D or not Engine then
        self:Fail("Defaults or Engine not loaded")
        return
    end

    local name = "_TS_CtxDispatch"
    if Engine.sequences[name] then
        Engine:DeactivateSequence(name)
    end

    -- Build a sequence with 2 versions: v1=Raid, v2=Dungeon
    local seqData = D.NewSequenceFromTemplate(name, D.TestSequence)
    seqData.versions[1].steps = { "/cast Fireball" }
    seqData.versions[2] = {
        stepFunction = "Sequential",
        steps = { "/cast Frostbolt" },
        keyPress = "",
        keyRelease = "",
        resetOnCombat = false,
        resetOnTarget = false,
        resetOnGear = false,
        resetOnSpec = false,
        resetTimer = 0,
    }
    seqData.contextOverrides = {
        ["Raid"] = 1,
        ["Dungeon"] = 2,
    }

    -- GetActiveVersion uses DetectContext internally. We cannot mock
    -- instance state, so verify the data structure is correct and
    -- that GetActiveVersion returns a valid version table.
    Engine:ActivateSequence(name, seqData)
    local entry = Engine.sequences[name]
    local activeVer = entry and Engine:GetActiveVersion(entry.data)

    Engine:DeactivateSequence(name)

    if not activeVer then
        self:Fail("GetActiveVersion returned nil")
        return
    end

    -- Verify both versions exist in the data
    local v1 = seqData.versions[1]
    local v2 = seqData.versions[2]
    if not v1 or not v2 then
        self:Fail("version data missing")
        return
    end

    -- Verify overrides are set
    if seqData.contextOverrides["Raid"] ~= 1 then
        self:Fail("Raid override not set to version 1")
        return
    end
    if seqData.contextOverrides["Dungeon"] ~= 2 then
        self:Fail("Dungeon override not set to version 2")
        return
    end

    self:Pass()
end)

-- ---------------------------------------------------------------------------
-- Step Function Tests
-- ---------------------------------------------------------------------------

TS:Register("ExpandPriority produces correct count", "stepfunc", function(self)
    local SF = GRIPEMS.StepFunctions
    local D = GRIPEMS.Defaults
    if not SF or not D then
        self:Fail("StepFunctions or Defaults not loaded")
        return
    end
    local result = SF:ExpandPriority({ "A", "B", "C" })
    self:AssertEqual(6, #result, "ExpandPriority count")
    if currentResult.status == "fail" then
        return
    end
    for i, entry in ipairs(result) do
        if entry.type ~= D.ATTR_TYPE_MACRO then
            self:Fail("entry " .. i .. " type is not ATTR_TYPE_MACRO")
            return
        end
    end
    self:Pass()
end)

TS:Register("ExpandReversePriority produces correct count", "stepfunc", function(self)
    local SF = GRIPEMS.StepFunctions
    local D = GRIPEMS.Defaults
    if not SF or not D then
        self:Fail("StepFunctions or Defaults not loaded")
        return
    end
    local result = SF:ExpandReversePriority({ "A", "B", "C" })
    self:AssertEqual(6, #result, "ExpandReversePriority count")
    if currentResult.status == "fail" then
        return
    end
    for i, entry in ipairs(result) do
        if entry.type ~= D.ATTR_TYPE_MACRO then
            self:Fail("entry " .. i .. " type is not ATTR_TYPE_MACRO")
            return
        end
    end
    self:Pass()
end)

TS:Register("ExpandPriority empty input returns fallback", "stepfunc", function(self)
    local SF = GRIPEMS.StepFunctions
    if not SF then
        self:Fail("StepFunctions not loaded")
        return
    end
    local result = SF:ExpandPriority({})
    self:AssertEqual(1, #result, "empty fallback count")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("ValidateSteps catches overlong step", "stepfunc", function(self)
    local SF = GRIPEMS.StepFunctions
    if not SF then
        self:Fail("StepFunctions not loaded")
        return
    end
    local longStr = string.rep("x", 300)
    local ok, errors = SF:ValidateSteps({ longStr })
    self:Assert(not ok, "expected ok=false for overlong step")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(1, #errors, "error count")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("ValidateSteps passes valid steps", "stepfunc", function(self)
    local SF = GRIPEMS.StepFunctions
    if not SF then
        self:Fail("StepFunctions not loaded")
        return
    end
    local ok, errors = SF:ValidateSteps({ "/cast Fireball", "/cast Frostbolt" })
    self:Assert(ok, "expected ok=true for valid steps")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(0, #errors, "error count")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("Get returns definition for known name", "stepfunc", function(self)
    local SF = GRIPEMS.StepFunctions
    if not SF then
        self:Fail("StepFunctions not loaded")
        return
    end
    self:Assert(SF:Get("Sequential") ~= nil, "Sequential not found")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(SF:Get("Random") ~= nil, "Random not found")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(SF:Get("Priority") ~= nil, "Priority not found")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(SF:Get("NONEXISTENT") == nil, "NONEXISTENT should be nil")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("GetNames returns all registered step functions", "stepfunc", function(self)
    local SF = GRIPEMS.StepFunctions
    if not SF then
        self:Fail("StepFunctions not loaded")
        return
    end
    local names = SF:GetNames()
    self:Assert(#names >= 4, "expected at least 4 step functions, got " .. #names)
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

-- ---------------------------------------------------------------------------
-- Action Compiler Tests
-- ---------------------------------------------------------------------------

TS:Register("CompileActions simple action nodes", "compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    local actions = {
        { type = D.ACTION_TYPE_ACTION, macro = "/cast Fireball" },
        { type = D.ACTION_TYPE_ACTION, macro = "/cast Frostbolt" },
    }
    local steps = AC.CompileActions(actions, nil)
    self:AssertEqual(2, #steps, "step count")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("/cast Fireball", steps[1], "step 1")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("/cast Frostbolt", steps[2], "step 2")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("CompileActions interleave-only tree falls back to base steps", "compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    local tree = {
        {
            type = D.ACTION_TYPE_LOOP,
            ["repeat"] = 1,
            stepFunction = D.STEP_SEQUENTIAL,
            children = {
                { type = D.ACTION_TYPE_ACTION, macro = "/cast A", interval = 2 },
                { type = D.ACTION_TYPE_ACTION, macro = "/cast B", interval = 2 },
            },
        },
    }
    local steps = AC.CompileActions(tree, nil)
    self:Assert(#steps == 2, "interleave-only loop compiles to 2 base steps, got " .. #steps)
    self:Assert(steps[1] == "/cast A" and steps[2] == "/cast B", "base step order preserved")
    self:Assert(AC.CompilesEmptyDueToInterleave(tree), "detected as interleave-no-base")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("ValidateActions flags interleave-only no base step", "compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    local tree = {
        { type = D.ACTION_TYPE_ACTION, macro = "/cast A", interval = 2 },
        { type = D.ACTION_TYPE_ACTION, macro = "/cast B", interval = 2 },
    }
    local okv = AC.ValidateActions(tree)
    self:Assert(not okv, "interleave-only tree is invalid")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("interleave interval over base steps clamps instead of vanishing", "compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    -- Root scope: 6 base steps, one interleave at interval 8 (> 6). Before the
    -- clamp the interleave bucketed against original index 8, landed zero
    -- copies, and vanished from the compiled macro. It now clamps to 6 and
    -- fires once per cycle, immediately after the last base step.
    local tree = {}
    for i = 1, 6 do
        tree[i] = { type = D.ACTION_TYPE_ACTION, macro = "/cast B" .. i }
    end
    tree[7] = { type = D.ACTION_TYPE_ACTION, macro = "/cast IL", interval = 8 }
    local steps = AC.CompileActions(tree, nil)
    self:AssertEqual(1, archCountSteps(steps, "/cast IL"), "clamped interleave fires exactly once")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(7, #steps, "6 base + 1 clamped copy = 7 steps")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(steps[6] == "/cast B6" and steps[7] == "/cast IL", "copy sits immediately after base step 6")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("interleave overrun inside a loop clamps to the loop's compiled count", "compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    -- LOOP repeat 1: 6 base children plus one interleave at interval 8. The loop
    -- compiles 6 base steps, so interval 8 clamps to 6 and fires once.
    local children = {}
    for i = 1, 6 do
        children[i] = { type = D.ACTION_TYPE_ACTION, macro = "/cast B" .. i }
    end
    children[7] = { type = D.ACTION_TYPE_ACTION, macro = "/cast IL", interval = 8 }
    local tree = {
        {
            type = D.ACTION_TYPE_LOOP,
            ["repeat"] = 1,
            stepFunction = D.STEP_SEQUENTIAL,
            children = children,
        },
    }
    local steps = AC.CompileActions(tree, nil)
    self:AssertEqual(1, archCountSteps(steps, "/cast IL"), "clamped loop interleave fires exactly once")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("raising a loop's repeat lets the authored interval land unclamped", "compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    -- Same loop as the clamp test but repeat 2: the loop now compiles 12 base
    -- steps, so interval 8 fits and lands after the 8th base step -- NOT at the
    -- end. This proves the clamp did not swallow a legitimately fitting case.
    local children = {}
    for i = 1, 6 do
        children[i] = { type = D.ACTION_TYPE_ACTION, macro = "/cast B" .. i }
    end
    children[7] = { type = D.ACTION_TYPE_ACTION, macro = "/cast IL", interval = 8 }
    local tree = {
        {
            type = D.ACTION_TYPE_LOOP,
            ["repeat"] = 2,
            stepFunction = D.STEP_SEQUENTIAL,
            children = children,
        },
    }
    local steps = AC.CompileActions(tree, nil)
    self:AssertEqual(1, archCountSteps(steps, "/cast IL"), "interval 8 fires once over 12 compiled steps")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("/cast IL", steps[9], "copy lands at position 9, after the 8th base step")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(13, #steps, "12 base + 1 copy = 13 steps")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("Priority loop interleave fits the triangle -- no false overflow warning", "compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    -- A Priority loop over 6 base children expands to a TRIANGLE: 6*7/2 = 21
    -- compiled base steps, not 6. Interval 8 fits inside 21 and lands two copies
    -- (base indices 8 and 16); the compiler clamps nothing. The overflow helper
    -- must obtain the count by compiling, so it sees 21 and stays silent. Before
    -- the compile-derived count it re-derived 6 * 1 = 6 and falsely warned that
    -- interval 8 exceeded "6 compiled steps" while nothing had been clamped.
    local children = {}
    for i = 1, 6 do
        children[i] = { type = D.ACTION_TYPE_ACTION, macro = "/cast B" .. i }
    end
    children[7] = { type = D.ACTION_TYPE_ACTION, macro = "/cast IL", interval = 8 }
    local tree = {
        {
            type = D.ACTION_TYPE_LOOP,
            ["repeat"] = 1,
            stepFunction = D.STEP_PRIORITY,
            children = children,
        },
    }
    local steps = AC.CompileActions(tree, nil)
    self:AssertEqual(23, #steps, "21 triangle base steps + 2 interleave copies = 23")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(2, archCountSteps(steps, "/cast IL"), "interleave macro lands twice, not clamped")
    if currentResult.status == "fail" then
        return
    end
    local isValid, _, warnings = AC.ValidateActions(tree)
    self:Assert(isValid, "a fitting interval is always valid")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(0, #warnings, "interval 8 fits inside 21 compiled steps -- no warning")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("ValidateActions warns when a loop interleave overruns, naming the repeat", "compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    -- The loop-clamp tree: repeat 1, 6 base children plus interval-8 interleave.
    -- Validation must accept it (warning, never an error) and name the Repeat
    -- count -- ceil(8 / 6) == 2 -- that makes interval 8 land unclamped.
    local children = {}
    for i = 1, 6 do
        children[i] = { type = D.ACTION_TYPE_ACTION, macro = "/cast B" .. i }
    end
    children[7] = { type = D.ACTION_TYPE_ACTION, macro = "/cast IL", interval = 8 }
    local tree = {
        {
            type = D.ACTION_TYPE_LOOP,
            ["repeat"] = 1,
            stepFunction = D.STEP_SEQUENTIAL,
            children = children,
        },
    }
    local isValid, _, warnings = AC.ValidateActions(tree)
    self:Assert(isValid, "loop interleave overrun is a warning, never blocks save")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(1, #warnings, "exactly one overflow warning")
    if currentResult.status == "fail" then
        return
    end
    local w = warnings[1] or ""
    self:Assert(string.find(w, "interval 8", 1, true) ~= nil, "warning names interval 8")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(string.find(w, "6 compiled steps", 1, true) ~= nil, "warning names the 6 compiled steps")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(string.find(w, "Repeat to 2", 1, true) ~= nil, "warning names suggested repeat 2")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("ValidateActions warns when a root interleave overruns", "compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    -- Root scope: 6 base steps, one interleave at interval 8. Validation accepts
    -- it and warns that interval 8 exceeds the 6 base steps.
    local tree = {}
    for i = 1, 6 do
        tree[i] = { type = D.ACTION_TYPE_ACTION, macro = "/cast B" .. i }
    end
    tree[7] = { type = D.ACTION_TYPE_ACTION, macro = "/cast IL", interval = 8 }
    local isValid, _, warnings = AC.ValidateActions(tree)
    self:Assert(isValid, "root interleave overrun is a warning, never blocks save")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(1, #warnings, "exactly one overflow warning")
    if currentResult.status == "fail" then
        return
    end
    local w = warnings[1] or ""
    self:Assert(string.find(w, "interval 8", 1, true) ~= nil, "warning names interval 8")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(string.find(w, "6 base steps", 1, true) ~= nil, "warning names the 6 base steps")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("interval within base steps compiles unchanged and warns nothing", "compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    -- Regression guard: interval 3 already fits within 6 base steps, so the
    -- clamp must not touch it. Copies land after base steps 3 and 6.
    local tree = {}
    for i = 1, 6 do
        tree[i] = { type = D.ACTION_TYPE_ACTION, macro = "/cast B" .. i }
    end
    tree[7] = { type = D.ACTION_TYPE_ACTION, macro = "/cast IL", interval = 3 }
    local steps = AC.CompileActions(tree, nil)
    self:AssertEqual(8, #steps, "6 base + 2 copies = 8 steps")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(steps[4] == "/cast IL" and steps[8] == "/cast IL", "copies land after base steps 3 and 6")
    if currentResult.status == "fail" then
        return
    end
    local _, _, warnings = AC.ValidateActions(tree)
    self:AssertEqual(0, #warnings, "an interval that already fits emits no overflow warning")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("interleave-only tree does not hang and still reports empty", "compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    -- Infinite-loop guard: the only node is an interleave at interval 8, so the
    -- base-step count is 0. The clamp must NOT clamp interval to 0 (that makes
    -- k = 0 and the insert loop never terminates). Reaching the assert proves
    -- the call returned. The interleave-only fallback still compiles the action
    -- as a base step so the sequence runs.
    local tree = {
        { type = D.ACTION_TYPE_ACTION, macro = "/cast IL", interval = 8 },
    }
    local steps = AC.CompileActions(tree, nil)
    self:AssertEqual(1, #steps, "interleave-only tree falls back to 1 base step")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(steps[1] == "/cast IL", "fallback compiles the interleave as a base step")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(AC.CompilesEmptyDueToInterleave(tree), "still detected as interleave-no-base")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("pleggster repro: 6 base steps with intervals 4, 8 and 8 all fire", "compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    -- The reported Feral shape: 6 base casts, Tiger's Fury at interval 4,
    -- Convoke and Frantic Frenzy both at interval 8. Before the clamp only the
    -- interval-4 macro survived; the two interval-8 macros vanished.
    local tree = {}
    for i = 1, 6 do
        tree[i] = { type = D.ACTION_TYPE_ACTION, macro = "/cast Base" .. i }
    end
    tree[#tree + 1] = { type = D.ACTION_TYPE_ACTION, macro = "/cast TigersFury", interval = 4 }
    tree[#tree + 1] = { type = D.ACTION_TYPE_ACTION, macro = "/cast Convoke", interval = 8 }
    tree[#tree + 1] = { type = D.ACTION_TYPE_ACTION, macro = "/cast FranticFrenzy", interval = 8 }
    local steps = AC.CompileActions(tree, nil)
    self:Assert(archCountSteps(steps, "/cast TigersFury") >= 1, "interval-4 interleave fires")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(archCountSteps(steps, "/cast Convoke") >= 1, "first interval-8 interleave fires after clamp")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(archCountSteps(steps, "/cast FranticFrenzy") >= 1, "second interval-8 interleave fires after clamp")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("import weave parity: interval over base clamps like an editor recompile", "compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    -- Call-site coverage for Import/LegacyImport.CompileMacroVersion, which weaves
    -- imported Repeat actions by calling AC.ApplyInterleaving(steps, {}, intervalActions)
    -- on a flat base-step array. An imported Repeat whose interval exceeds the flat
    -- base-step count now clamps -- the baked import must stay byte-identical to an
    -- editor recompile of the equivalent tree, or an edited-then-saved import would
    -- diverge from what was imported. ApplyInterleaving mutates flatSteps in place.
    local flatSteps = {}
    for i = 1, 6 do
        flatSteps[i] = "/cast B" .. i
    end
    local intervalActions = { { macro = "/cast IL", interval = 8 } }
    AC.ApplyInterleaving(flatSteps, {}, intervalActions)

    local tree = {}
    for i = 1, 6 do
        tree[i] = { type = D.ACTION_TYPE_ACTION, macro = "/cast B" .. i }
    end
    tree[7] = { type = D.ACTION_TYPE_ACTION, macro = "/cast IL", interval = 8 }
    local editorSteps = AC.CompileActions(tree, nil)

    self:AssertEqual(7, #flatSteps, "import weave clamps interval 8 to one copy over 6 base steps")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(#editorSteps, #flatSteps, "import-baked length equals editor recompile length")
    if currentResult.status == "fail" then
        return
    end
    for i = 1, #editorSteps do
        if flatSteps[i] ~= editorSteps[i] then
            self:Fail("import-baked step " .. i .. " diverges from editor recompile")
            return
        end
    end
    self:Pass()
end)

TS:Register("interleave overflow counts an embed's real steps, no false warning", "compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    -- DEFECT 1 regression guard. Scope: [Embed -> 10 steps, Action, Action,
    -- interleave at interval 8]. The live compile resolves the embed through the
    -- engine to 10 steps, so the base count is 12 and interval 8 fits -- no
    -- overflow. The overflow helper must resolve the SAME embed (passing the
    -- engine) or it counts the embed as 0 steps, computes a base of 2, and warns
    -- falsely that interval 8 exceeds "the sequence's 2 base steps".
    local embedSteps = {}
    for i = 1, 10 do
        embedSteps[i] = "/cast Embed" .. i
    end
    local engine = {
        sequences = { MySeq = { data = { marker = true } } },
        GetActiveVersion = function(_, _)
            return { steps = embedSteps }
        end,
    }
    local tree = {
        { type = D.ACTION_TYPE_EMBED, sequence = "MySeq" },
        { type = D.ACTION_TYPE_ACTION, macro = "/cast Act1" },
        { type = D.ACTION_TYPE_ACTION, macro = "/cast Act2" },
        { type = D.ACTION_TYPE_ACTION, macro = "/cast IL", interval = 8 },
    }
    -- Sanity: with the engine the embed resolves to 10 -> base 12, one copy.
    local steps = AC.CompileActions(tree, engine)
    self:AssertEqual(13, #steps, "embed resolved to 10 base steps (12 base + 1 copy)")
    if currentResult.status == "fail" then
        return
    end
    local overflows, capped = AC.InterleaveOverflows(tree, nil, engine)
    self:AssertEqual(0, #overflows, "interval 8 fits inside a base count of 12 -- no false overflow")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(0, #capped, "no copy-budget truncation")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("CompileActions pause node", "compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    local actions = {
        { type = D.ACTION_TYPE_PAUSE, clicks = 3 },
    }
    local steps = AC.CompileActions(actions, nil)
    self:AssertEqual(3, #steps, "pause step count")
    if currentResult.status == "fail" then
        return
    end
    for i, step in ipairs(steps) do
        if step ~= "" then
            self:Fail("pause step " .. i .. " should be empty string")
            return
        end
    end
    self:Pass()
end)

TS:Register("CompileActions loop node with repeat", "compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    local loopNode = {
        type = D.ACTION_TYPE_LOOP,
        ["repeat"] = 2,
        stepFunction = "Sequential",
        children = {
            { type = D.ACTION_TYPE_ACTION, macro = "/cast Fireball" },
        },
    }
    local steps = AC.CompileActions({ loopNode }, nil)
    self:AssertEqual(2, #steps, "loop repeat=2")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("CompileActions LOOP skips disabled children", "compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    local loopNode = {
        type = D.ACTION_TYPE_LOOP,
        ["repeat"] = 2,
        stepFunction = D.STEP_SEQUENTIAL,
        children = {
            { type = D.ACTION_TYPE_ACTION, macro = "/cast Alpha" },
            { type = D.ACTION_TYPE_ACTION, macro = "/cast Bravo", disabled = true },
            { type = D.ACTION_TYPE_ACTION, macro = "/cast Charlie" },
        },
    }
    local steps = AC.CompileActions({ loopNode }, nil)
    self:AssertEqual(4, #steps, "loop repeat=2 over two enabled children")
    if currentResult.status == "fail" then
        return
    end
    for i, step in ipairs(steps) do
        if step == "/cast Bravo" then
            self:Fail("disabled child compiled at step " .. i)
            return
        end
    end
    self:AssertEqual("/cast Alpha", steps[1], "step 1")
    self:AssertEqual("/cast Charlie", steps[2], "step 2")
    self:AssertEqual("/cast Alpha", steps[3], "step 3")
    self:AssertEqual("/cast Charlie", steps[4], "step 4")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("CompileActions LOOP Priority triangle over enabled children only", "compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    local loopNode = {
        type = D.ACTION_TYPE_LOOP,
        ["repeat"] = 1,
        stepFunction = D.STEP_PRIORITY,
        children = {
            { type = D.ACTION_TYPE_ACTION, macro = "/cast Alpha" },
            { type = D.ACTION_TYPE_ACTION, macro = "/cast Bravo", disabled = true },
            { type = D.ACTION_TYPE_ACTION, macro = "/cast Charlie" },
        },
    }
    local steps = AC.CompileActions({ loopNode }, nil)
    self:AssertEqual(3, #steps, "two-child Priority triangle")
    if currentResult.status == "fail" then
        return
    end
    for i, step in ipairs(steps) do
        if step == "/cast Bravo" then
            self:Fail("disabled child woven into triangle at step " .. i)
            return
        end
    end
    self:AssertEqual("/cast Alpha", steps[1], "step 1")
    self:AssertEqual("/cast Alpha", steps[2], "step 2")
    self:AssertEqual("/cast Charlie", steps[3], "step 3")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("CompileActions IF node true branch only", "compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    local ifNode = {
        type = D.ACTION_TYPE_IF,
        variable = "nopet",
        children = {
            { { type = D.ACTION_TYPE_ACTION, macro = "982" } },
            {},
        },
    }
    local steps = AC.CompileActions({ ifNode }, nil)
    self:AssertEqual(1, #steps, "IF true-only step count")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(steps[1]:find("%[nopet%]"), "step should contain [nopet]")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(steps[1]:find("982"), "step should contain spell 982")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("/cast [nopet] 982", steps[1], "full step text")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("CompileActions IF node true and false branches", "compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    local ifNode = {
        type = D.ACTION_TYPE_IF,
        variable = "nopet",
        children = {
            { { type = D.ACTION_TYPE_ACTION, macro = "982" } },
            { { type = D.ACTION_TYPE_ACTION, macro = "217200" } },
        },
    }
    local steps = AC.CompileActions({ ifNode }, nil)
    self:AssertEqual(1, #steps, "IF true+false step count")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(steps[1]:find("982"), "step should contain spell 982")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(steps[1]:find("217200"), "step should contain spell 217200")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("/cast [nopet] 982; 217200", steps[1], "full step text")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("CompileActions IF node complex multi-action true branch", "compiler", function(self)
    -- Phase A rewrite: complex IF now uses per-step injection (spec section 7
    -- path f). Each true-branch step gets [cond] injected; false-branch steps
    -- get [neg(cond)] injected. Replaces the prior "false branch discarded"
    -- behavior that this test previously asserted.
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    local ifNode = {
        type = D.ACTION_TYPE_IF,
        variable = "mod:shift",
        children = {
            {
                { type = D.ACTION_TYPE_ACTION, macro = "/cast 34026" },
                { type = D.ACTION_TYPE_ACTION, macro = "/cast 217200" },
            },
            {},
        },
    }
    local steps = AC.CompileActions({ ifNode }, nil)
    self:AssertEqual(2, #steps, "complex IF step count")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("/cast [mod:shift] 34026", steps[1], "complex IF step 1")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("/cast [mod:shift] 217200", steps[2], "complex IF step 2")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("CompileActions IF node inside loop", "compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    local ifNode = {
        type = D.ACTION_TYPE_IF,
        variable = "nopet",
        children = {
            { { type = D.ACTION_TYPE_ACTION, macro = "982" } },
            { { type = D.ACTION_TYPE_ACTION, macro = "217200" } },
        },
    }
    local loopNode = {
        type = D.ACTION_TYPE_LOOP,
        ["repeat"] = 1,
        stepFunction = "Sequential",
        children = {
            { type = D.ACTION_TYPE_ACTION, macro = "/cast 53351" },
            ifNode,
        },
    }
    local steps = AC.CompileActions({ loopNode }, nil)
    self:AssertEqual(2, #steps, "loop+IF step count")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("/cast 53351", steps[1], "loop step 1 (action)")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("/cast [nopet] 982; 217200", steps[2], "loop step 2 (IF)")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("CompileActions ACTION node carries label to step", "compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    local actions = {
        { type = D.ACTION_TYPE_ACTION, macro = "/cast X", label = "atk" },
    }
    local steps, labels = AC.CompileActions(actions, nil)
    self:AssertEqual(1, #steps, "step count")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("atk", labels[1], "label[1]")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("CompileActions PAUSE label on first click only", "compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    local actions = {
        { type = D.ACTION_TYPE_PAUSE, clicks = 3, label = "wait" },
    }
    local steps, labels = AC.CompileActions(actions, nil)
    self:AssertEqual(3, #steps, "pause step count")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("wait", labels[1], "label[1]")
    if currentResult.status == "fail" then
        return
    end
    if labels[2] ~= nil then
        self:Fail("label[2] should be nil, got " .. tostring(labels[2]))
        return
    end
    if labels[3] ~= nil then
        self:Fail("label[3] should be nil, got " .. tostring(labels[3]))
        return
    end
    self:Pass()
end)

TS:Register("CompileActions EMBED label on first step only", "compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    -- EMBED needs a mock engine with a resolvable sequence.
    local mockEngine = {
        sequences = {
            ["Embedded"] = { data = { steps = { "/cast A", "/cast B", "/cast C" } } },
        },
    }
    mockEngine.GetActiveVersion = function(_, data)
        return data
    end
    local actions = {
        { type = D.ACTION_TYPE_EMBED, sequence = "Embedded", label = "emb" },
    }
    local steps, labels = AC.CompileActions(actions, mockEngine)
    self:AssertEqual(3, #steps, "embed step count")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("emb", labels[1], "label[1]")
    if currentResult.status == "fail" then
        return
    end
    if labels[2] ~= nil then
        self:Fail("label[2] should be nil, got " .. tostring(labels[2]))
        return
    end
    if labels[3] ~= nil then
        self:Fail("label[3] should be nil, got " .. tostring(labels[3]))
        return
    end
    self:Pass()
end)

TS:Register("CompileActions LOOP Sequential label on each iteration first step", "compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    local loopNode = {
        type = D.ACTION_TYPE_LOOP,
        ["repeat"] = 3,
        stepFunction = "Sequential",
        label = "loop",
        children = {
            { type = D.ACTION_TYPE_ACTION, macro = "/cast A" },
            { type = D.ACTION_TYPE_ACTION, macro = "/cast B" },
        },
    }
    local steps, labels = AC.CompileActions({ loopNode }, nil)
    self:AssertEqual(6, #steps, "loop sequential step count")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("loop", labels[1], "label[1]")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("loop", labels[3], "label[3]")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("loop", labels[5], "label[5]")
    if currentResult.status == "fail" then
        return
    end
    if labels[2] ~= nil then
        self:Fail("label[2] should be nil, got " .. tostring(labels[2]))
        return
    end
    if labels[4] ~= nil then
        self:Fail("label[4] should be nil, got " .. tostring(labels[4]))
        return
    end
    if labels[6] ~= nil then
        self:Fail("label[6] should be nil, got " .. tostring(labels[6]))
        return
    end
    self:Pass()
end)

TS:Register("CompileActions LOOP Priority label on labels[1]", "compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    local loopNode = {
        type = D.ACTION_TYPE_LOOP,
        stepFunction = "Priority",
        label = "prio",
        children = {
            { type = D.ACTION_TYPE_ACTION, macro = "/cast A" },
            { type = D.ACTION_TYPE_ACTION, macro = "/cast B" },
            { type = D.ACTION_TYPE_ACTION, macro = "/cast C" },
        },
    }
    local steps, labels = AC.CompileActions({ loopNode }, nil)
    -- Priority expansion on 3 children yields 1+2+3 = 6 steps.
    self:AssertEqual(6, #steps, "priority expansion step count")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("prio", labels[1], "label[1]")
    if currentResult.status == "fail" then
        return
    end
    if labels[2] ~= nil then
        self:Fail("label[2] should be nil, got " .. tostring(labels[2]))
        return
    end
    if labels[3] ~= nil then
        self:Fail("label[3] should be nil, got " .. tostring(labels[3]))
        return
    end
    self:Pass()
end)

TS:Register("CompileActions LOOP Priority honors repeat count", "compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    local loopNode = {
        type = D.ACTION_TYPE_LOOP,
        ["repeat"] = 2,
        stepFunction = "Priority",
        children = {
            { type = D.ACTION_TYPE_ACTION, macro = "/cast A" },
            { type = D.ACTION_TYPE_ACTION, macro = "/cast B" },
            { type = D.ACTION_TYPE_ACTION, macro = "/cast C" },
        },
    }
    local steps = AC.CompileActions({ loopNode }, nil)
    -- One priority iteration on 3 children = 1+2+3 = 6 steps; repeat=2 = 12.
    self:AssertEqual(12, #steps, "priority repeat=2 step count")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("/cast A", steps[1], "iter1 first step")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("/cast A", steps[7], "iter2 first step")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("/cast C", steps[12], "iter2 last step")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("CompileActions LOOP ReversePriority honors repeat count", "compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    local loopNode = {
        type = D.ACTION_TYPE_LOOP,
        ["repeat"] = 2,
        stepFunction = "ReversePriority",
        children = {
            { type = D.ACTION_TYPE_ACTION, macro = "/cast A" },
            { type = D.ACTION_TYPE_ACTION, macro = "/cast B" },
            { type = D.ACTION_TYPE_ACTION, macro = "/cast C" },
        },
    }
    local steps = AC.CompileActions({ loopNode }, nil)
    -- One reverse-priority iteration on 3 children = 6 steps; repeat=2 = 12.
    self:AssertEqual(12, #steps, "reverse-priority repeat=2 step count")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("DeactivateSequence keepStub preserves macro stub mapping", "engine", function(self)
    local E = GRIPEMS.Engine
    local MM = GRIPEMS.MacroManager
    local D = GRIPEMS.Defaults
    if not E or not MM or not D then
        self:Fail("Engine, MacroManager, or Defaults not loaded")
        return
    end
    local name = "_TS_KeepStub"
    E.sequences[name] = {
        data = {
            name = name,
            defaultVersion = 1,
            contextOverrides = {},
            versions = { { steps = {}, stepFunction = D.STEP_SEQUENTIAL } },
        },
        button = nil,
        variantButtons = nil,
    }
    MM.stubs[name] = 12345
    -- keepStub=true must NOT delete the stub: the action-bar placement
    -- survives a context/version rebuild (delete+recreate would orphan it).
    E:DeactivateSequence(name, true)
    local preserved = MM.stubs[name]
    -- cleanup before asserting
    MM.stubs[name] = nil
    E.sequences[name] = nil
    self:AssertEqual(12345, preserved, "keepStub=true preserves MM.stubs[name]")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("CompileActions IF simple label on labels[1]", "compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    local ifNode = {
        type = D.ACTION_TYPE_IF,
        variable = "nopet",
        label = "cond",
        children = {
            { { type = D.ACTION_TYPE_ACTION, macro = "/cast X" } },
            {},
        },
    }
    local steps, labels = AC.CompileActions({ ifNode }, nil)
    self:AssertEqual(1, #steps, "IF simple step count")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("cond", labels[1], "label[1]")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("CompileActions IF complex preserves child labels", "compiler", function(self)
    -- Observed rule (ActionCompiler.lua L264-L278, complex IF branch):
    --   1. Iterate trueBranch children, collect their steps + labels.
    --   2. If node.label is set and #steps > 0, overwrite labels[1] = node.label.
    --   3. Children at labels[2..N] keep their labels; only the first slot loses.
    -- Two-action trueBranch forces complex path (simple requires exactly 1 action).
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    local ifNode = {
        type = D.ACTION_TYPE_IF,
        variable = "mod:shift",
        label = "if",
        children = {
            {
                { type = D.ACTION_TYPE_ACTION, macro = "/cast A", label = "a" },
                { type = D.ACTION_TYPE_ACTION, macro = "/cast B", label = "b" },
            },
            {},
        },
    }
    local steps, labels = AC.CompileActions({ ifNode }, nil)
    self:AssertEqual(2, #steps, "IF complex step count")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("if", labels[1], "label[1] (IF label overwrites child 'a')")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("b", labels[2], "label[2] (child label preserved)")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("MigrateStepsToActions round-trip", "compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    local inputSteps = { "/cast Fireball", "/cast Frostbolt" }
    local actions = AC.MigrateStepsToActions(inputSteps)
    self:AssertEqual(2, #actions, "action count")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(D.ACTION_TYPE_ACTION, actions[1].type, "action 1 type")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("/cast Fireball", actions[1].macro, "action 1 macro")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("Migrate then disable middle step skips it on compile", "compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    if not AC then
        self:Fail("ActionCompiler not loaded")
        return
    end
    local inputSteps = { "/cast A", "/cast B", "/cast C" }
    local actions = AC.MigrateStepsToActions(inputSteps)
    self:AssertEqual(3, #actions, "migrated action count")
    if currentResult.status == "fail" then
        return
    end
    actions[2].disabled = true
    local steps = AC.CompileActions(actions, nil)
    self:AssertEqual(2, #steps, "compiled step count (middle disabled skipped)")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("/cast A", steps[1], "step 1 is first enabled macro")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("/cast C", steps[2], "step 2 is third enabled macro (middle skipped)")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("ValidateActions catches empty macro", "compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    local actions = {
        { type = D.ACTION_TYPE_ACTION, macro = "" },
    }
    local ok, errors = AC.ValidateActions(actions)
    self:Assert(not ok, "expected validation to fail for empty macro")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(#errors >= 1, "expected at least 1 error")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("ValidateActions passes valid tree", "compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    local actions = {
        { type = D.ACTION_TYPE_ACTION, macro = "/cast Fireball" },
    }
    local ok, errors = AC.ValidateActions(actions)
    self:Assert(ok, "expected validation to pass")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(0, #errors, "error count")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("ValidateActions flags IF with only disabled children", "compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    local actions = {
        {
            type = D.ACTION_TYPE_IF,
            variable = "combat",
            children = {
                { { type = D.ACTION_TYPE_ACTION, macro = "/cast Alpha", disabled = true } },
                { { type = D.ACTION_TYPE_ACTION, macro = "/cast Bravo", disabled = true } },
            },
        },
    }
    local ok, errors = AC.ValidateActions(actions)
    self:Assert(not ok, "expected validation to fail when every branch child is disabled")
    if currentResult.status == "fail" then
        return
    end
    local found = false
    for _, err in ipairs(errors) do
        if err:find("no actions in either branch", 1, true) then
            found = true
            break
        end
    end
    self:Assert(found, "expected the empty-branches error")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("CompileActions IF with only disabled children compiles to zero steps", "compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    local ifNode = {
        type = D.ACTION_TYPE_IF,
        variable = "combat",
        children = {
            { { type = D.ACTION_TYPE_ACTION, macro = "/cast Alpha", disabled = true } },
            { { type = D.ACTION_TYPE_ACTION, macro = "/cast Bravo", disabled = true } },
        },
    }
    local steps = AC.CompileActions({ ifNode }, nil)
    self:AssertEqual(0, #steps, "zero steps for all-disabled IF")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

-- ---------------------------------------------------------------------------
-- Category: if-compiler -- IF Action Node Complete (Phase A+C)
--
-- 30 byte-exact tests per IF_Node_Complete_Spec.md section 12 (E01-E30)
-- plus 3 integration tests (round-trip, backwards-compat, validation).
-- Every test uses table.concat + direct string equality on the steps array.
-- ---------------------------------------------------------------------------

local function ifCompileAssert(self, ifNode, expectedSteps, label)
    local AC = GRIPEMS.ActionCompiler
    if not AC then
        self:Fail("ActionCompiler not loaded")
        return false
    end
    local steps = AC.CompileActions({ ifNode }, nil)
    if #steps ~= #expectedSteps then
        self:Fail(
            (label or "compile") .. ": step count expected " .. tostring(#expectedSteps) .. ", got " .. tostring(#steps)
        )
        return false
    end
    for i = 1, #expectedSteps do
        if steps[i] ~= expectedSteps[i] then
            self:Fail(
                (label or "compile")
                    .. ": step "
                    .. tostring(i)
                    .. ' expected "'
                    .. tostring(expectedSteps[i])
                    .. '", got "'
                    .. tostring(steps[i])
                    .. '"'
            )
            return false
        end
    end
    return true
end

local function makeIf(cond, trueMacros, falseMacros)
    local D = GRIPEMS.Defaults
    local function toActions(macros)
        local out = {}
        for _, m in ipairs(macros or {}) do
            out[#out + 1] = { type = D.ACTION_TYPE_ACTION, macro = m }
        end
        return out
    end
    return {
        type = D.ACTION_TYPE_IF,
        variable = cond,
        children = {
            toActions(trueMacros),
            toActions(falseMacros),
        },
    }
end

TS:Register("if-compiler E01 mod:shift T=Frostbolt F=Fireball", "if-compiler", function(self)
    local node = makeIf("mod:shift", { "Frostbolt" }, { "Fireball" })
    if not ifCompileAssert(self, node, { "/cast [mod:shift] Frostbolt; Fireball" }, "E01") then
        return
    end
    self:Pass()
end)

TS:Register("if-compiler E02 mod:shift T=Frostbolt F=empty", "if-compiler", function(self)
    local node = makeIf("mod:shift", { "Frostbolt" }, {})
    if not ifCompileAssert(self, node, { "/cast [mod:shift] Frostbolt" }, "E02") then
        return
    end
    self:Pass()
end)

TS:Register("if-compiler E03 mod:shift T=empty F=Fireball", "if-compiler", function(self)
    local node = makeIf("mod:shift", {}, { "Fireball" })
    if not ifCompileAssert(self, node, { "/cast [nomod:shift] Fireball" }, "E03") then
        return
    end
    self:Pass()
end)

TS:Register("if-compiler E04 combat,harm T=Frostbolt F=Fireball", "if-compiler", function(self)
    local node = makeIf("combat,harm", { "Frostbolt" }, { "Fireball" })
    if not ifCompileAssert(self, node, { "/cast [combat,harm] Frostbolt; Fireball" }, "E04") then
        return
    end
    self:Pass()
end)

TS:Register("if-compiler E05 combat,harm T=empty F=Fireball", "if-compiler", function(self)
    local node = makeIf("combat,harm", {}, { "Fireball" })
    if not ifCompileAssert(self, node, { "/cast [nocombat][noharm] Fireball" }, "E05") then
        return
    end
    self:Pass()
end)

TS:Register("if-compiler E06 mod:shift T=3 actions F=2 actions", "if-compiler", function(self)
    local node = makeIf("mod:shift", { "A", "B", "C" }, { "D", "E" })
    if
        not ifCompileAssert(self, node, {
            "/cast [mod:shift] A",
            "/cast [mod:shift] B",
            "/cast [mod:shift] C",
            "/cast [nomod:shift] D",
            "/cast [nomod:shift] E",
        }, "E06")
    then
        return
    end
    self:Pass()
end)

TS:Register("if-compiler E07 combat,harm T=2 actions F=1 action", "if-compiler", function(self)
    local node = makeIf("combat,harm", { "A", "B" }, { "D" })
    if
        not ifCompileAssert(self, node, {
            "/cast [combat,harm] A",
            "/cast [combat,harm] B",
            "/cast [nocombat][noharm] D",
        }, "E07")
    then
        return
    end
    self:Pass()
end)

TS:Register("if-compiler E08 mod:shift T=/use Healthstone F=/use Healing Potion", "if-compiler", function(self)
    local node = makeIf("mod:shift", { "/use Healthstone" }, { "/use Healing Potion" })
    if not ifCompileAssert(self, node, { "/use [mod:shift] Healthstone; Healing Potion" }, "E08") then
        return
    end
    self:Pass()
end)

TS:Register("if-compiler E09 mod:shift T=/use 13 F=/cast Healthstone", "if-compiler", function(self)
    local node = makeIf("mod:shift", { "/use 13" }, { "/cast Healthstone" })
    if
        not ifCompileAssert(self, node, {
            "/use [mod:shift] 13",
            "/cast [nomod:shift] Healthstone",
        }, "E09")
    then
        return
    end
    self:Pass()
end)

TS:Register("if-compiler E10 mod:shift T=/cast [@focus] Polymorph F=Frostbolt", "if-compiler", function(self)
    local node = makeIf("mod:shift", { "/cast [@focus] Polymorph" }, { "Frostbolt" })
    if
        not ifCompileAssert(self, node, {
            "/cast [mod:shift,@focus] Polymorph; [nomod:shift] Frostbolt",
        }, "E10")
    then
        return
    end
    self:Pass()
end)

TS:Register("if-compiler E11 mod:shift T=multi-clause F=Frostbolt", "if-compiler", function(self)
    local node = makeIf("mod:shift", { "/cast [@focus,harm] Polymorph; [help] Renew" }, { "Frostbolt" })
    if
        not ifCompileAssert(self, node, {
            "/cast [mod:shift,@focus,harm] Polymorph; [mod:shift,help] Renew; [nomod:shift] Frostbolt",
        }, "E11")
    then
        return
    end
    self:Pass()
end)

TS:Register("if-compiler E12 mod:shift T=/castsequence F=/cast", "if-compiler", function(self)
    local node = makeIf("mod:shift", { "/castsequence reset=10 A, B, C" }, { "/cast Z" })
    if
        not ifCompileAssert(self, node, {
            "/castsequence [mod:shift] reset=10 A, B, C",
            "/cast [nomod:shift] Z",
        }, "E12")
    then
        return
    end
    self:Pass()
end)

TS:Register("if-compiler E13 mod:shift T=/equipset Tank F=/equipset DPS", "if-compiler", function(self)
    local node = makeIf("mod:shift", { "/equipset Tank" }, { "/equipset DPS" })
    if not ifCompileAssert(self, node, { "/equipset [mod:shift] Tank; DPS" }, "E13") then
        return
    end
    self:Pass()
end)

TS:Register("if-compiler E14 combat T=/cast Bloodlust F=/dismount", "if-compiler", function(self)
    local node = makeIf("combat", { "/cast Bloodlust" }, { "/dismount" })
    if
        not ifCompileAssert(self, node, {
            "/cast [combat] Bloodlust",
            "/dismount [nocombat]",
        }, "E14")
    then
        return
    end
    self:Pass()
end)

TS:Register("if-compiler E15 empty cond -- compile empty + validate error", "if-compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    local node = makeIf("", { "anything" }, { "anything else" })
    local steps = AC.CompileActions({ node }, nil)
    self:AssertEqual(0, #steps, "step count")
    if currentResult.status == "fail" then
        return
    end
    local ok, errors = AC.ValidateActions({ node })
    self:Assert(not ok, "expected validation to fail for empty cond")
    if currentResult.status == "fail" then
        return
    end
    local found = false
    for _, e in ipairs(errors) do
        if e:find("empty variable", 1, true) then
            found = true
            break
        end
    end
    self:Assert(found, "expected 'empty variable' in error messages")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("if-compiler E16 cond present both branches empty", "if-compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    local node = makeIf("mod:shift", {}, {})
    local steps = AC.CompileActions({ node }, nil)
    self:AssertEqual(0, #steps, "step count")
    if currentResult.status == "fail" then
        return
    end
    local ok, errors = AC.ValidateActions({ node })
    self:Assert(not ok, "expected validation to fail for both branches empty")
    if currentResult.status == "fail" then
        return
    end
    local found = false
    for _, e in ipairs(errors) do
        if e:find("no actions in either branch", 1, true) then
            found = true
            break
        end
    end
    self:Assert(found, "expected 'no actions in either branch' in error messages")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("if-compiler E17 mod:shift,combat,harm,stealth T=empty F=Fireball", "if-compiler", function(self)
    local node = makeIf("mod:shift,combat,harm,stealth", {}, { "Fireball" })
    if
        not ifCompileAssert(self, node, {
            "/cast [nomod:shift][nocombat][noharm][nostealth] Fireball",
        }, "E17")
    then
        return
    end
    self:Pass()
end)

TS:Register("if-compiler E18 [mod:shift][combat] OR input T=Frostbolt F=Fireball", "if-compiler", function(self)
    local node = makeIf("[mod:shift][combat]", { "Frostbolt" }, { "Fireball" })
    if not ifCompileAssert(self, node, {
        "/cast [mod:shift][combat] Frostbolt; Fireball",
    }, "E18") then
        return
    end
    self:Pass()
end)

TS:Register("if-compiler E19 [mod:shift][combat] OR input T=empty F=Fireball", "if-compiler", function(self)
    local node = makeIf("[mod:shift][combat]", {}, { "Fireball" })
    if not ifCompileAssert(self, node, {
        "/cast [nomod:shift,nocombat] Fireball",
    }, "E19") then
        return
    end
    self:Pass()
end)

TS:Register("if-compiler E20 nomod:shift already-negated T=Frostbolt F=Fireball", "if-compiler", function(self)
    -- DEVIATION FROM SPEC SECTION 12 E20 expected output. Spec shows two-line
    -- form to illustrate double-negation collapse, but the byte-identical
    -- backwards-compat form for already-negated cond (matching the [nopet]
    -- Hunter sequence) is the single-line semicolon fall-through. Both forms
    -- have identical runtime semantics. Spec amendment proposed in
    -- housekeeping section of the Phase A handoff.
    local node = makeIf("nomod:shift", { "Frostbolt" }, { "Fireball" })
    if not ifCompileAssert(self, node, {
        "/cast [nomod:shift] Frostbolt; Fireball",
    }, "E20") then
        return
    end
    self:Pass()
end)

TS:Register("if-compiler E21 mod:shift T=comment+/cast F=empty", "if-compiler", function(self)
    local D = GRIPEMS.Defaults
    local node = {
        type = D.ACTION_TYPE_IF,
        variable = "mod:shift",
        children = {
            {
                { type = D.ACTION_TYPE_ACTION, macro = "# this is a comment" },
                { type = D.ACTION_TYPE_ACTION, macro = "/cast Frostbolt" },
            },
            {},
        },
    }
    if
        not ifCompileAssert(self, node, {
            "# this is a comment",
            "/cast [mod:shift] Frostbolt",
        }, "E21")
    then
        return
    end
    self:Pass()
end)

TS:Register("if-compiler E22 mod:shift T=/run print(...) F=empty -- passthrough", "if-compiler", function(self)
    local node = makeIf("mod:shift", { "/run print('hi')" }, {})
    if not ifCompileAssert(self, node, { "/run print('hi')" }, "E22") then
        return
    end
    self:Pass()
end)

TS:Register("if-compiler E23 mod:shift T=Frostbolt+/use Healthstone F=empty", "if-compiler", function(self)
    local node = makeIf("mod:shift", { "Frostbolt", "/use Healthstone" }, {})
    if
        not ifCompileAssert(self, node, {
            "/cast [mod:shift] Frostbolt",
            "/use [mod:shift] Healthstone",
        }, "E23")
    then
        return
    end
    self:Pass()
end)

TS:Register("if-compiler E24 talent:7/3 removed -- compile + validate warn", "if-compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    local node = makeIf("talent:7/3", { "X" }, { "Y" })
    local steps = AC.CompileActions({ node }, nil)
    self:AssertEqual(1, #steps, "step count")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("/cast [talent:7/3] X; Y", steps[1], "compile output")
    if currentResult.status == "fail" then
        return
    end
    local _, errors = AC.ValidateActions({ node })
    local foundRemoved = false
    for _, e in ipairs(errors) do
        if e:find("removed in 10.0.0", 1, true) and e:find("known:", 1, true) then
            foundRemoved = true
            break
        end
    end
    self:Assert(foundRemoved, "expected 'removed in 10.0.0' + 'known:' warning")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("if-compiler E25 mod:shift T=LOOP F=Frostbolt", "if-compiler", function(self)
    local D = GRIPEMS.Defaults
    local node = {
        type = D.ACTION_TYPE_IF,
        variable = "mod:shift",
        children = {
            {
                {
                    type = D.ACTION_TYPE_LOOP,
                    ["repeat"] = 2,
                    stepFunction = D.STEP_SEQUENTIAL,
                    children = {
                        { type = D.ACTION_TYPE_ACTION, macro = "/cast 53351" },
                    },
                },
            },
            { { type = D.ACTION_TYPE_ACTION, macro = "Frostbolt" } },
        },
    }
    if
        not ifCompileAssert(self, node, {
            "/cast [mod:shift] 53351",
            "/cast [mod:shift] 53351",
            "/cast [nomod:shift] Frostbolt",
        }, "E25")
    then
        return
    end
    self:Pass()
end)

TS:Register("if-compiler E26 mod:shift T=nested IF F=Frostbolt", "if-compiler", function(self)
    local D = GRIPEMS.Defaults
    local innerIf = {
        type = D.ACTION_TYPE_IF,
        variable = "combat",
        children = {
            { { type = D.ACTION_TYPE_ACTION, macro = "/cast Bloodlust" } },
            {},
        },
    }
    local node = {
        type = D.ACTION_TYPE_IF,
        variable = "mod:shift",
        children = {
            { innerIf },
            { { type = D.ACTION_TYPE_ACTION, macro = "Frostbolt" } },
        },
    }
    if
        not ifCompileAssert(self, node, {
            "/cast [mod:shift,combat] Bloodlust; [nomod:shift] Frostbolt",
        }, "E26")
    then
        return
    end
    self:Pass()
end)

TS:Register("if-compiler E27 mod:shift T=EMBED F=Frostbolt", "if-compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    local mockEngine = {
        sequences = {
            ["Embedded"] = { data = { steps = { "/cast A", "/cast B" } } },
        },
    }
    mockEngine.GetActiveVersion = function(_, data)
        return data
    end
    local node = {
        type = D.ACTION_TYPE_IF,
        variable = "mod:shift",
        children = {
            { { type = D.ACTION_TYPE_EMBED, sequence = "Embedded" } },
            { { type = D.ACTION_TYPE_ACTION, macro = "Frostbolt" } },
        },
    }
    local expected = {
        "/cast [mod:shift] A",
        "/cast [mod:shift] B",
        "/cast [nomod:shift] Frostbolt",
    }
    local steps = AC.CompileActions({ node }, mockEngine)
    if #steps ~= #expected then
        self:Fail("E27: step count expected " .. #expected .. ", got " .. #steps)
        return
    end
    for i = 1, #expected do
        if steps[i] ~= expected[i] then
            self:Fail(
                "E27: step " .. tostring(i) .. ' expected "' .. expected[i] .. '", got "' .. tostring(steps[i]) .. '"'
            )
            return
        end
    end
    self:Pass()
end)

TS:Register("if-compiler E28 mod:shift T=PAUSE clicks=2 F=Frostbolt", "if-compiler", function(self)
    local D = GRIPEMS.Defaults
    local node = {
        type = D.ACTION_TYPE_IF,
        variable = "mod:shift",
        children = {
            { { type = D.ACTION_TYPE_PAUSE, clicks = 2 } },
            { { type = D.ACTION_TYPE_ACTION, macro = "Frostbolt" } },
        },
    }
    if
        not ifCompileAssert(self, node, {
            "",
            "",
            "/cast [nomod:shift] Frostbolt",
        }, "E28")
    then
        return
    end
    self:Pass()
end)

TS:Register("if-compiler E29 long line exceeds 255 chars -- validate error", "if-compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    local longSpell = string.rep("X", 250)
    local node = makeIf("mod:shift", { "/cast " .. longSpell }, {})
    local steps = AC.CompileActions({ node }, nil)
    self:AssertEqual(1, #steps, "step count")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(#steps[1] > 255, "compiled step length expected > 255, got " .. tostring(#steps[1]))
    if currentResult.status == "fail" then
        return
    end
    local _, errors = AC.ValidateActions({ node })
    local found = false
    for _, e in ipairs(errors) do
        if e:find("exceeds 255 chars", 1, true) then
            found = true
            break
        end
    end
    self:Assert(found, "expected 'exceeds 255 chars' validation error")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("if-compiler E30 mod:shift T=/cast Pyroblast F=/cast Pyroblast (no dedup)", "if-compiler", function(self)
    local node = makeIf("mod:shift", { "/cast Pyroblast" }, { "/cast Pyroblast" })
    if not ifCompileAssert(self, node, { "/cast [mod:shift] Pyroblast; Pyroblast" }, "E30") then
        return
    end
    self:Pass()
end)

-- ---------------------------------------------------------------------------
-- Integration tests (Phase A acceptance)
-- ---------------------------------------------------------------------------

TS:Register("if-roundtrip-edit-save-recompile", "if-compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local MS = GRIPEMS.MacroSyntax
    local D = GRIPEMS.Defaults
    if not AC or not MS or not D then
        self:Fail("ActionCompiler or MacroSyntax or Defaults not loaded")
        return
    end
    local node = makeIf("mod:shift", { "/cast [@focus] Polymorph" }, { "Frostbolt" })
    local steps = AC.CompileActions({ node }, nil)
    self:AssertEqual(1, #steps, "compile step count")
    if currentResult.status == "fail" then
        return
    end
    local compiled = steps[1]
    local cmd = compiled:match("^(/%S+)")
    self:Assert(cmd ~= nil, "compiled output missing command")
    if currentResult.status == "fail" then
        return
    end
    local rem = compiled:sub(#cmd + 2)
    local ast = MS.Parse(rem)
    local serialized = MS.Serialize(ast)
    local reconstituted = cmd .. " " .. serialized
    self:AssertEqual(compiled, reconstituted, "parse->serialize round-trip mismatch")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("if-backwards-compat-nopet-hunter", "if-compiler", function(self)
    -- Production sequence verified Apr 2026 (Backlog L816, L825). Output MUST
    -- be byte-identical to the pre-Phase A shipped form.
    local node = makeIf("nopet", { "/cast 982" }, { "/cast 217200" })
    if not ifCompileAssert(self, node, { "/cast [nopet] 982; 217200" }, "nopet-hunter") then
        return
    end
    self:Pass()
end)

TS:Register("if-validation-empty-cond", "if-compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    local node = makeIf("", { "anything" }, { "anything else" })
    local ok, validateErr = pcall(function()
        local v, errors = AC.ValidateActions({ node })
        return v, errors
    end)
    self:Assert(ok, "ValidateActions threw an error: " .. tostring(validateErr))
    if currentResult.status == "fail" then
        return
    end
    local _, errors = AC.ValidateActions({ node })
    local found = false
    for _, e in ipairs(errors) do
        if e:find("empty variable", 1, true) then
            found = true
            break
        end
    end
    self:Assert(found, "expected 'empty variable' in error messages")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("if-macrosyntax-idempotence-double-call-equals-single", "if-compiler", function(self)
    local MS = GRIPEMS.MacroSyntax
    if not MS then
        self:Fail("MacroSyntax not loaded")
        return
    end
    -- Five canonical option-string shapes that exercise the
    -- injectConditionList code paths: bare value, targeting prefix,
    -- numeric (slot), castsequence keyword form, and a multi-clause OR.
    local inputs = {
        "Frostbolt",
        "[@focus] Polymorph",
        "13",
        "reset=10 A,B",
        "[combat] X; Y",
    }
    local conds = { "mod:shift", "combat,harm" }
    for _, input in ipairs(inputs) do
        for _, cond in ipairs(conds) do
            local once = MS.InjectIntoOptions(input, cond, "and")
            local twice = MS.InjectIntoOptions(once, cond, "and")
            if once ~= twice then
                self:Fail(
                    "idempotence broken for input='"
                        .. input
                        .. "', cond='"
                        .. cond
                        .. "', once='"
                        .. once
                        .. "', twice='"
                        .. twice
                        .. "'"
                )
                return
            end
        end
    end
    self:Pass()
end)

TS:Register("if-macrosyntax-malformed-bracket-input-rejected", "if-compiler", function(self)
    local MS = GRIPEMS.MacroSyntax
    if not MS then
        self:Fail("MacroSyntax not loaded")
        return
    end
    local malformed = {
        "mod:shift][combat",
        "mod:shift]combat",
        "[mod:shift",
        "mod:shift]",
    }
    for _, input in ipairs(malformed) do
        local result = MS.ParseCondBoxInput(input)
        if #result.errors == 0 then
            self:Fail("expected error for malformed input '" .. input .. "', got none")
            return
        end
        local found = false
        for _, e in ipairs(result.errors) do
            if e:find("bracket", 1, true) then
                found = true
                break
            end
        end
        if not found then
            self:Fail(
                "expected 'bracket' in error for input '" .. input .. "', got: " .. table.concat(result.errors, "; ")
            )
            return
        end
    end
    self:Pass()
end)

TS:Register("if-condbox-legacy-condition-matrix", "if-compiler", function(self)
    local MS = GRIPEMS.MacroSyntax
    if not MS then
        self:Fail("MacroSyntax not loaded")
        return
    end
    -- Imported conditional blocks embed their condition string as bracket
    -- content; this matrix pins which real-world shapes the cond box
    -- grammar accepts (the IF survives a recompile) vs rejects (the IF
    -- compiles to zero steps). Empirically settled 2026-06-07 (v2.1.17).
    local accept = {
        "mod:shift",
        "combat",
        "nomod",
        "@focus,harm",
        "mod:shift/alt",
        "mod:ctrl,combat",
        "harm,nodead",
        "known:12345",
        "talent:1/2",
        "= true",
        "MyVariable",
        "[mod:shift]",
        "[mod:shift][combat]",
    }
    local reject = {
        "[combat] Greater Heal",
        "[combat] Greater Heal; Heal",
        "",
    }
    for _, input in ipairs(accept) do
        local r = MS.ParseCondBoxInput(input)
        if #r.errors > 0 then
            self:Fail("expected accept for '" .. input .. "', got: " .. table.concat(r.errors, "; "))
            return
        end
    end
    for _, input in ipairs(reject) do
        local r = MS.ParseCondBoxInput(input)
        if #r.errors == 0 then
            self:Fail("expected reject for '" .. input .. "', got none")
            return
        end
    end
    self:Pass()
end)

TS:Register("if-compiler validate-warn-200-chars", "if-compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    -- Spell name 200 chars, plus "/cast " (6) and "[mod:shift] " (12)
    -- yields a compiled step in the 200-255 warn band.
    local longSpell = string.rep("X", 200)
    local node = makeIf("mod:shift", { "/cast " .. longSpell }, {})
    local steps = AC.CompileActions({ node }, nil)
    self:AssertEqual(1, #steps, "step count")
    if currentResult.status == "fail" then
        return
    end
    local len = #steps[1]
    self:Assert(len > 200 and len <= 255, "compiled step length expected in (200,255], got " .. tostring(len))
    if currentResult.status == "fail" then
        return
    end
    local _, errors, warnings = AC.ValidateActions({ node })
    self:Assert(#errors == 0, "expected no errors, got: " .. table.concat(errors, "; "))
    if currentResult.status == "fail" then
        return
    end
    local found = false
    for _, w in ipairs(warnings or {}) do
        if w:find("approaching 255 chars", 1, true) then
            found = true
            break
        end
    end
    self:Assert(found, "expected 'approaching 255 chars' warning, got " .. tostring(#(warnings or {})) .. " warnings")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("if-compiler validate-error-still-fires-at-256", "if-compiler", function(self)
    -- Sanity: the > 255 hard error path remains intact alongside the new
    -- 200-char warning level. Mirrors E29 but with an explicit 256+ check
    -- to guard against the warning band swallowing the error case.
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    local longSpell = string.rep("Y", 250)
    local node = makeIf("mod:shift", { "/cast " .. longSpell }, {})
    local steps = AC.CompileActions({ node }, nil)
    self:AssertEqual(1, #steps, "step count")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(#steps[1] > 255, "compiled step length expected > 255, got " .. tostring(#steps[1]))
    if currentResult.status == "fail" then
        return
    end
    local _, errors = AC.ValidateActions({ node })
    local found = false
    for _, e in ipairs(errors) do
        if e:find("exceeds 255 chars", 1, true) then
            found = true
            break
        end
    end
    self:Assert(found, "expected 'exceeds 255 chars' validation error")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("if-compiler disabled middle node excluded from compile", "if-compiler", function(self)
    local AC = GRIPEMS.ActionCompiler
    local D = GRIPEMS.Defaults
    if not AC or not D then
        self:Fail("ActionCompiler or Defaults not loaded")
        return
    end
    -- Three enabled ACTION nodes would compile to three steps; marking the
    -- middle node disabled must drop exactly that one, leaving the other two
    -- in their original order. Mirrors the compile-skip guard in
    -- AC.CompileActions (node.disabled branch).
    local actions = {
        { type = D.ACTION_TYPE_ACTION, macro = "/cast Fireball" },
        { type = D.ACTION_TYPE_ACTION, macro = "/cast Frostbolt", disabled = true },
        { type = D.ACTION_TYPE_ACTION, macro = "/cast Pyroblast" },
    }
    local steps = AC.CompileActions(actions, nil)
    self:AssertEqual(2, #steps, "disabled middle node excluded -- two steps remain")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("/cast Fireball", steps[1], "step 1 is the first enabled node")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("/cast Pyroblast", steps[2], "step 2 is the third node; disabled macro absent")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

-- ---------------------------------------------------------------------------
-- Category: if-lint -- Combat-blocked command static lint (Phase H2)
--
-- Mirrors the BLOCKED + NOT-blocked tables in
-- Research/Combat_Blocked_Commands_2026-05-10.md. Severity is warn-only;
-- false positives erode trust faster than missed positives.
-- ---------------------------------------------------------------------------

TS:Register("if-lint /equipset detection", "if-lint", function(self)
    local ML = GRIPEMS.MacroLint
    if not ML then
        self:Fail("MacroLint not loaded")
        return
    end
    local sev, findings = ML.LintMacro("/equipset Tank")
    self:AssertEqual("warn", sev, "severity")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(1, #findings, "finding count")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("/equipset", findings[1].cmd, "cmd")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("hard", findings[1].category, "category")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("if-lint /cast NOT flagged", "if-lint", function(self)
    local ML = GRIPEMS.MacroLint
    if not ML then
        self:Fail("MacroLint not loaded")
        return
    end
    local sev, findings = ML.LintMacro("/cast Frostbolt")
    self:Assert(sev == nil, "severity expected nil, got " .. tostring(sev))
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(0, #findings, "finding count")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("if-lint comment lines skipped", "if-lint", function(self)
    local ML = GRIPEMS.MacroLint
    if not ML then
        self:Fail("MacroLint not loaded")
        return
    end
    local sev, findings = ML.LintMacro("# comment\n/equipset Tank")
    self:AssertEqual("warn", sev, "severity")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(1, #findings, "finding count")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(2, findings[1].lineNumber, "lineNumber")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("if-lint /cancelaura partial", "if-lint", function(self)
    local ML = GRIPEMS.MacroLint
    if not ML then
        self:Fail("MacroLint not loaded")
        return
    end
    local sev, findings = ML.LintMacro("/cancelaura Mount")
    self:AssertEqual("warn", sev, "severity")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(1, #findings, "finding count")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("partial", findings[1].category, "category")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("if-lint case-insensitive", "if-lint", function(self)
    local ML = GRIPEMS.MacroLint
    if not ML then
        self:Fail("MacroLint not loaded")
        return
    end
    local sev, findings = ML.LintMacro("/EquipSet Tank")
    self:AssertEqual("warn", sev, "severity")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(1, #findings, "finding count")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("/equipset", findings[1].cmd, "cmd lowercased")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("if-lint recursive walk via NodeHasBlockedCommands", "if-lint", function(self)
    local ML = GRIPEMS.MacroLint
    if not ML then
        self:Fail("MacroLint not loaded")
        return
    end
    local ifNode = makeIf("mod:shift", { "/equipset Tank" }, {})
    local sev, findings = ML:NodeHasBlockedCommands(ifNode, nil, true)
    self:AssertEqual("warn", sev, "severity")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(findings and #findings >= 1, "expected at least one finding")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("/equipset", findings[1].cmd, "cmd")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

-- ---------------------------------------------------------------------------
-- Category: restriction -- Restriction state tracking
-- ---------------------------------------------------------------------------

TS:Register("GRIPEMS.restrictions table initialized", "restriction", function(self)
    self:Assert(GRIPEMS.restrictions ~= nil, "restrictions table missing")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(type(GRIPEMS.restrictions) == "table", "restrictions is not a table")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(0, GRIPEMS.restrictions[1], "Encounter default")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(0, GRIPEMS.restrictions[2], "ChallengeMode default")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(0, GRIPEMS.restrictions[3], "PvPMatch default")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("OOCQueue:IsRestricted returns boolean", "restriction", function(self)
    local OOC = GRIPEMS.OOCQueue
    if not OOC or not OOC.IsRestricted then
        self:Skip("OOCQueue or IsRestricted not available")
        return
    end
    local result = OOC:IsRestricted()
    self:Assert(type(result) == "boolean", "IsRestricted should return boolean, got " .. type(result))
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("OOCQueue:IsRestricted equals InCombatLockdown", "restriction", function(self)
    -- ARENA-RELOAD-OOC invariant: the queue gate must mirror combat lockdown
    -- exactly. AddOnRestriction states (arena/M+/encounter) must NOT flip it,
    -- or the queue starves for the whole match after an instance /reload.
    local OOC = GRIPEMS.OOCQueue
    if not OOC or not OOC.IsRestricted then
        self:Skip("OOCQueue or IsRestricted not available")
        return
    end
    local expected = InCombatLockdown() and true or false
    local actual = OOC:IsRestricted() and true or false
    self:AssertEqual(expected, actual, "IsRestricted must mirror InCombatLockdown")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("IsCVarSecure reads GetCVarInfo isSecure (return 6)", "restriction", function(self)
    local CPM = GRIPEMS.CvarProfileManager
    if not (CPM and CPM.IsCVarSecure and C_CVar and C_CVar.GetCVarInfo) then
        self:Skip("CvarProfileManager.IsCVarSecure or C_CVar.GetCVarInfo unavailable")
        return
    end
    -- GetCVarInfo returns: value, defaultValue, isStoredServerAccount,
    -- isStoredServerCharacter, isLockedFromUser (5), isSecure (6), isReadOnly.
    -- Make 5 and 6 DIFFER so a wrong-position read is caught. Stub/restore
    -- routes through a local helper whose param breaks luacheck's read-only
    -- global-field guard, mirroring the SetApiField stubs used elsewhere here
    -- (the module-level SetApiField is declared below this test, out of scope).
    local function StubApi(apiTable, key, fn)
        apiTable[key] = fn
    end
    local realGetCVarInfo = C_CVar.GetCVarInfo
    StubApi(C_CVar, "GetCVarInfo", function()
        return "1", "0", false, false, true, false, false
    end)
    local lockedNotSecure = CPM.IsCVarSecure("__grip_test__")
    StubApi(C_CVar, "GetCVarInfo", function()
        return "1", "0", false, false, false, true, false
    end)
    local secureNotLocked = CPM.IsCVarSecure("__grip_test__")
    StubApi(C_CVar, "GetCVarInfo", realGetCVarInfo)
    self:AssertEqual(false, lockedNotSecure, "isLockedFromUser true isSecure false must report NOT secure")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(true, secureNotLocked, "isSecure true must report secure (reads return 6)")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

-- ---------------------------------------------------------------------------
-- Engine Reset/Step Tracking Tests
-- ---------------------------------------------------------------------------

TS:Register("ResetStep resets to step 1", "reset", function(self)
    if self:_SkipIfCombat() then
        return
    end
    local D = GRIPEMS.Defaults
    local Engine = GRIPEMS.Engine
    local OOC = GRIPEMS.OOCQueue
    if not D or not Engine then
        self:Fail("Defaults or Engine not loaded")
        return
    end
    if OOC and OOC.IsRestricted and OOC:IsRestricted() then
        self:Skip("in combat -- cannot test reset")
        return
    end

    local name = "_TS_ResetStep"
    if Engine.sequences[name] then
        Engine:DeactivateSequence(name)
    end

    local seqData = D.NewSequenceFromTemplate(name, D.TestSequence)
    Engine:ActivateSequence(name, seqData)

    local entry = Engine.sequences[name]
    if not entry or not entry.button then
        self:Fail("sequence not activated")
        Engine:DeactivateSequence(name)
        return
    end

    -- Advance step via button attribute
    entry.button:SetAttribute("step", 3)

    -- Reset
    if Engine.ResetStep then
        Engine:ResetStep(name)
    elseif entry.button then
        entry.button:SetAttribute("step", 1)
    end

    local step = tonumber(entry.button:GetAttribute("step")) or 0
    Engine:DeactivateSequence(name)

    self:AssertEqual(1, step, "step after reset")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("GetResetModifiers returns 15 keys", "reset", function(self)
    local S = GRIPEMS.Settings
    local D = GRIPEMS.Defaults
    if not S or not S.GetResetModifiers then
        self:Skip("Settings:GetResetModifiers not available")
        return
    end
    if not D or not D.MACRO_RESET_MODIFIERS then
        self:Skip("Defaults not loaded")
        return
    end
    local mods = S:GetResetModifiers()
    self:Assert(type(mods) == "table", "GetResetModifiers should return table")
    if currentResult.status == "fail" then
        return
    end
    local count = 0
    for _ in pairs(mods) do
        count = count + 1
    end
    self:AssertEqual(15, count, "should have 15 modifier keys")
    if currentResult.status == "fail" then
        return
    end
    for _, mod in ipairs(D.MACRO_RESET_MODIFIERS) do
        if mods[mod] == nil then
            self:Fail("missing modifier key: " .. mod)
            return
        end
    end
    self:Pass()
end)

TS:Register("SetResetModifier persists value", "reset", function(self)
    local S = GRIPEMS.Settings
    if not S or not S.GetResetModifiers or not S.SetResetModifier then
        self:Skip("Settings reset modifier API not available")
        return
    end
    S:SetResetModifier("Alt", true)
    local after = S:GetResetModifiers()
    self:AssertEqual(true, after.Alt, "Alt should be true after set")
    if currentResult.status == "fail" then
        S:SetResetModifier("Alt", false)
        return
    end
    S:SetResetModifier("Alt", false) -- restore
    self:Pass()
end)

TS:Register("NewVersion template has nil resetModifiers", "reset", function(self)
    local D = GRIPEMS.Defaults
    if not D or not D.NewVersion then
        self:Skip("Defaults not loaded")
        return
    end
    self:AssertEqual(nil, D.NewVersion.resetModifiers, "default should be nil (use global)")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("Per-sequence override merge respects false values", "reset", function(self)
    local S = GRIPEMS.Settings
    local D = GRIPEMS.Defaults
    if not S or not S.GetResetModifiers or not D then
        self:Skip("Settings or Defaults not loaded")
        return
    end
    local globalMods = S:GetResetModifiers()
    local seqResetMods = { Alt = false, Shift = true }
    local merged = {}
    for mod, default in pairs(globalMods) do
        if seqResetMods[mod] ~= nil then
            merged[mod] = seqResetMods[mod]
        else
            merged[mod] = default
        end
    end
    self:AssertEqual(false, merged.Alt, "false override preserved")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(true, merged.Shift, "true override preserved")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(globalMods.Control, merged.Control, "non-overridden key follows global")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("Per-sequence nil resetModifiers falls back to global", "reset", function(self)
    local S = GRIPEMS.Settings
    if not S or not S.GetResetModifiers then
        self:Skip("Settings not loaded")
        return
    end
    local globalMods = S:GetResetModifiers()
    local seqResetMods = nil
    local resetMods = seqResetMods and {} or globalMods
    self:Assert(resetMods == globalMods, "nil seqResetMods should return globalMods reference")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

-- ---------------------------------------------------------------------------
-- Category: locale -- Spell translation round-trip
-- ---------------------------------------------------------------------------

TS:Register("TranslateMacrotext spell round-trip", "locale", function(self)
    local SC = GRIPEMS.SpellCache
    if not SC or not SC.TranslateMacrotext then
        self:Skip("SpellCache not loaded")
        return
    end
    local input = "/cast Kill Command"
    local tagged = SC:TranslateMacrotext(input, "toIDs")
    local restored = SC:TranslateMacrotext(tagged, "toNames")
    self:AssertEqual(input, restored, "spell round-trip")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("Handle-token recovery at conversion boundary", "locale", function(self)
    local SC = GRIPEMS.SpellCache
    if not SC or not SC.RecoverSpellName or not SC.RecoverHandleTokensInText or not SC.TranslateMacrotext then
        self:Skip("SpellCache recovery not loaded")
        return
    end
    -- Claw base id 16827; the patch-12.0 packed handle for it is 3238019515
    -- (low 16 bits = 16827). Skip when the client cannot resolve the base id
    -- (headless, or a character without the pet ability learned).
    local clawName = SC:IsResolvableSpellID(16827) and C_Spell.GetSpellName(16827)
    if not clawName then
        self:Skip("pet ability Claw (16827) not resolvable on this client")
        return
    end

    -- (a) a resolvable id returns its name directly; the packed handle unpacks
    -- to the same base name.
    self:AssertEqual(clawName, SC:RecoverSpellName(16827), "resolvable id returns its name")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(clawName, SC:RecoverSpellName(3238019515), "packed handle recovers base name")
    if currentResult.status == "fail" then
        return
    end

    -- (b) the per-text transform replaces a packed-handle token with the name
    -- (no leaked brace) and reports one recovery, zero drops.
    local cleaned, rec, drop = SC:RecoverHandleTokensInText("/use [@pettarget] {spell:3238019515}")
    self:AssertEqual("/use [@pettarget] " .. clawName, cleaned, "handle token replaced by name")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(1, rec, "one token recovered")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(0, drop, "no line dropped")
    if currentResult.status == "fail" then
        return
    end

    -- a genuinely-dead handle (in-range-unresolvable 0x06.. override style, low
    -- bits meaningless so never unpacked) drops its whole line.
    if not SC:IsResolvableSpellID(100663299) then
        local deadText, deadRec, deadDrop = SC:RecoverHandleTokensInText("/cast {spell:100663299}")
        self:AssertEqual("", deadText, "dead line dropped to empty text")
        if currentResult.status == "fail" then
            return
        end
        self:AssertEqual(0, deadRec, "no token recovered from dead handle")
        if currentResult.status == "fail" then
            return
        end
        self:AssertEqual(1, deadDrop, "dead line counted as dropped")
        if currentResult.status == "fail" then
            return
        end
    end

    -- (c) a stored handle token round-trips through the reader to the NAME,
    -- with no {spell:} brace left behind (covered by the name equality).
    local restored = SC:TranslateMacrotext("/cast {spell:3238019515}", "toNames")
    self:AssertEqual("/cast " .. clawName, restored, "handle token renders to name via reader")
    if currentResult.status == "fail" then
        return
    end

    self:Pass()
end)

TS:Register("Catalog name->ID fallback resolves English names (locale-independent)", "locale", function(self)
    local SC = GRIPEMS.SpellCache
    if not SC or not SC._CatalogIDForName then
        self:Skip("SpellCache catalog fallback not loaded")
        return
    end
    -- Path of Frost (id 3714) is a stable Death Knight entry in the bundled
    -- catalog. The catalog is English-keyed, so it resolves on any client locale
    -- -- the whole point of the fallback for non-enUS imports.
    local id = SC:_CatalogIDForName("Path of Frost")
    self:AssertEqual(3714, id, "English catalog name resolves to its ID")
    if currentResult.status == "fail" then
        return
    end
    local unknown = SC:_CatalogIDForName("Definitely Not A Real Spell Name")
    self:AssertEqual(nil, unknown, "unknown name returns nil")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("NormalizeVersionLocale tags steps and stamps locale", "locale", function(self)
    local SC = GRIPEMS.SpellCache
    if not SC or not SC.NormalizeVersionLocale then
        self:Skip("SpellCache normalizer not loaded")
        return
    end
    local version = { steps = { "/cast Path of Frost" }, keyPress = "", keyRelease = "" }
    SC:NormalizeVersionLocale(version)
    local got = version.taggedSteps and version.taggedSteps[1]
    self:AssertEqual("/cast {spell:3714}", got, "step tagged to canonical ID")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(GetLocale(), version.stepsLocale, "stepsLocale stamped to current locale")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("NormalizeActionsLocale tags IF + nested Loop action macros", "locale", function(self)
    local SC = GRIPEMS.SpellCache
    if not SC or not SC.NormalizeActionsLocale then
        self:Skip("SpellCache action normalizer not loaded")
        return
    end
    local D = GRIPEMS.Defaults
    -- IF true-branch carries a BARE name; the false-branch nests a LOOP whose
    -- child carries a FULL /cast line. Both forms must tag to canonical IDs.
    -- Path of Frost = 3714, Death Coil = 47541 (bundled catalog, locale-independent).
    local tree = {
        {
            type = D.ACTION_TYPE_IF,
            variable = "mod:shift",
            children = {
                { { type = D.ACTION_TYPE_ACTION, macro = "Path of Frost" } },
                {
                    {
                        type = D.ACTION_TYPE_LOOP,
                        children = {
                            { type = D.ACTION_TYPE_ACTION, macro = "/cast Death Coil" },
                        },
                    },
                },
            },
        },
    }
    SC:NormalizeActionsLocale(tree)
    local bare = tree[1].children[1][1]
    local full = tree[1].children[2][1].children[1]
    self:AssertEqual("{spell:3714}", bare.macroTagged, "bare IF action tagged to bare ID token")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("/cast {spell:47541}", full.macroTagged, "full-line nested Loop action tagged")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("TranslateMacrotext colon spell (Shadow Word: Pain)", "locale", function(self)
    local SC = GRIPEMS.SpellCache
    if not SC or not SC.TranslateMacrotext then
        self:Skip("SpellCache not loaded")
        return
    end
    local input = "/cast Shadow Word: Pain"
    local tagged = SC:TranslateMacrotext(input, "toIDs")
    local restored = SC:TranslateMacrotext(tagged, "toNames")
    self:AssertEqual(input, restored, "colon spell round-trip")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("#showtooltip passthrough (not in TRANSLATABLE_COMMANDS)", "locale", function(self)
    local SC = GRIPEMS.SpellCache
    if not SC or not SC.TranslateMacrotext then
        self:Skip("SpellCache not loaded")
        return
    end
    local input = "#showtooltip Kill Command"
    local tagged = SC:TranslateMacrotext(input, "toIDs")
    self:AssertEqual(input, tagged, "#showtooltip should passthrough untranslated")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("Empty conditionals /cast [] Spell", "locale", function(self)
    local SC = GRIPEMS.SpellCache
    if not SC or not SC.TranslateMacrotext then
        self:Skip("SpellCache not loaded")
        return
    end
    local input = "/cast [] Bestial Wrath"
    local tagged = SC:TranslateMacrotext(input, "toIDs")
    local restored = SC:TranslateMacrotext(tagged, "toNames")
    self:AssertEqual(input, restored, "empty bracket round-trip")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("Multi-branch conditional round-trip", "locale", function(self)
    local SC = GRIPEMS.SpellCache
    if not SC or not SC.TranslateMacrotext then
        self:Skip("SpellCache not loaded")
        return
    end
    local input = "/cast [mod:shift,@focus] Holy Light; [mod:alt] Flash of Light; Holy Shock"
    local tagged = SC:TranslateMacrotext(input, "toIDs")
    local restored = SC:TranslateMacrotext(tagged, "toNames")
    self:AssertEqual(input, restored, "multi-branch conditional round-trip")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("/use numeric slot passthrough", "locale", function(self)
    local SC = GRIPEMS.SpellCache
    if not SC or not SC.TranslateMacrotext then
        self:Skip("SpellCache not loaded")
        return
    end
    local input = "/use 13"
    local tagged = SC:TranslateMacrotext(input, "toIDs")
    self:AssertEqual(input, tagged, "numeric slot should passthrough")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("/use item by name (Healthstone)", "locale", function(self)
    local SC = GRIPEMS.SpellCache
    if not SC or not SC.TranslateMacrotext then
        self:Skip("SpellCache not loaded")
        return
    end
    local input = "/use Healthstone"
    local tagged = SC:TranslateMacrotext(input, "toIDs")
    local restored = SC:TranslateMacrotext(tagged, "toNames")
    self:AssertEqual(input, restored, "item round-trip or passthrough")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("/usetoy with apostrophe", "locale", function(self)
    local SC = GRIPEMS.SpellCache
    if not SC or not SC.TranslateMacrotext then
        self:Skip("SpellCache not loaded")
        return
    end
    local input = "/usetoy Lil' Ragnaros"
    local tagged = SC:TranslateMacrotext(input, "toIDs")
    local restored = SC:TranslateMacrotext(tagged, "toNames")
    self:AssertEqual(input, restored, "toy with apostrophe round-trip or passthrough")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("ResolveSpellIDsInText /use slot stays a slot (display)", "locale", function(self)
    local SC = GRIPEMS.SpellCache
    if not SC or not SC.ResolveSpellIDsInText then
        self:Skip("SpellCache not loaded")
        return
    end
    -- /use NNN is an inventory slot, never a spell ID, so the display
    -- resolver leaves it verbatim (the stored macro is never touched).
    local slot = SC:ResolveSpellIDsInText("/use 13")
    self:AssertEqual("/use 13", slot, "/use 13 slot not name-resolved")
    if currentResult.status == "fail" then
        return
    end
    local slotCond = SC:ResolveSpellIDsInText("/use [combat] 14")
    self:AssertEqual("/use [combat] 14", slotCond, "/use cond slot not resolved")
    if currentResult.status == "fail" then
        return
    end
    -- /cast NNN must still resolve to a spell name when the client has it.
    if C_Spell and C_Spell.GetSpellName then
        local name13 = C_Spell.GetSpellName(13)
        if name13 and name13 ~= "" then
            local castOut = SC:ResolveSpellIDsInText("/cast 13")
            self:AssertEqual("/cast " .. name13, castOut, "/cast 13 resolves to name")
            if currentResult.status == "fail" then
                return
            end
        else
            currentResult.message = "GetSpellName(13) nil; skipped /cast 13 assertion"
        end
    else
        currentResult.message = "C_Spell.GetSpellName missing; skipped /cast 13 assertion"
    end
    self:Pass()
end)

TS:Register("ExtractAllSpells #showtooltip slot skipped, spell kept", "locale", function(self)
    local SV = GRIPEMS.SpellValidator
    if not SV or not SV.ExtractAllSpells then
        self:Skip("SpellValidator not loaded")
        return
    end
    -- BUG-052 sibling: a bare number after #showtooltip is an inventory
    -- slot (e.g. 13 = top trinket), never a spell, so it is dropped before
    -- validation -- no spurious stale-tooltip warning on trinket macros.
    local slotEntries = SV:ExtractAllSpells("#showtooltip 13")
    local sawSlot = false
    for _, e in ipairs(slotEntries) do
        if e.name == "13" then
            sawSlot = true
            break
        end
    end
    self:Assert(not sawSlot, "numeric #showtooltip slot 13 should be skipped")
    if currentResult.status == "fail" then
        return
    end
    -- A real spell name after #showtooltip is unaffected.
    local spellEntries = SV:ExtractAllSpells("#showtooltip Fireball")
    local sawSpell = false
    for _, e in ipairs(spellEntries) do
        if e.name == "Fireball" and e.command == "showtooltip" then
            sawSpell = true
            break
        end
    end
    self:Assert(sawSpell, "non-numeric #showtooltip Fireball should still extract")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

-- ---------------------------------------------------------------------------
-- Category: gamepad -- ConsolePort integration
-- ---------------------------------------------------------------------------

TS:Register("ConsolePort detection is nil-safe", "gamepad", function(self)
    local detected = C_AddOns and C_AddOns.IsAddOnLoaded and C_AddOns.IsAddOnLoaded("ConsolePort")
    self:Assert(detected == true or detected == false or detected == nil, "ConsolePort detection should not error")
    self:Pass()
end)

TS:Register("CheckConsolePortConflict is nil-safe without ConsolePort", "gamepad", function(self)
    local KT = GRIPEMS.KeybindTab
    if not KT then
        self:Skip("KeybindTab not loaded")
        return
    end
    if KT.CheckConsolePortConflict then
        local result = KT.CheckConsolePortConflict("F1")
        if not ConsolePort then
            self:AssertEqual(nil, result, "should return nil without ConsolePort")
            if currentResult.status == "fail" then
                return
            end
        end
    end
    self:Pass()
end)

-- ---------------------------------------------------------------------------
-- Category: repair -- RepairAnalyzer diagnostics
-- ---------------------------------------------------------------------------

-- Helper: build a test sequence with optional overrides for corruption testing
local function buildTestSequence(overrides)
    local D = GRIPEMS.Defaults
    local sd = {
        name = "_TS_Repair",
        icon = D.QUESTION_MARK_ICON,
        defaultVersion = 1,
        contextOverrides = {},
        versions = {
            [1] = {
                stepFunction = D.STEP_SEQUENTIAL,
                steps = { "/cast Fireball", "/cast Frostbolt" },
                keyPress = "/stopmacro [channeling]",
                keyRelease = "",
                resetOnCombat = false,
                resetOnTarget = false,
                resetOnGear = false,
                resetOnSpec = false,
                resetTimer = 0,
            },
        },
        author = "TestSuite",
        version = "1",
        description = "test",
        help = "",
        helplink = "",
        classID = select(3, UnitClass("player")) or 1,
        specID = nil,
        createdAt = time(),
        updatedAt = time(),
    }
    if overrides then
        for k, v in pairs(overrides) do
            if k == "steps" then
                sd.versions[1].steps = v
            elseif k == "stepFunction" then
                sd.versions[1].stepFunction = v
            elseif k == "keyPress" then
                sd.versions[1].keyPress = v
            elseif k == "keyRelease" then
                sd.versions[1].keyRelease = v
            else
                sd[k] = v
            end
        end
    end
    return sd
end

TS:Register("Detect empty steps -> STRUCTURE issue", "repair", function(self)
    local RA = GRIPEMS.RepairAnalyzer
    if not RA then
        self:Fail("RepairAnalyzer not loaded")
        return
    end
    local sd = buildTestSequence({ steps = {} })
    local issues = RA:Analyze(sd, "_TS_RepairEmpty")
    local found = false
    for _, iss in ipairs(issues) do
        if iss.category == RA.CAT_STRUCTURE then
            found = true
            break
        end
    end
    self:Assert(found, "expected STRUCTURE issue for empty steps")
    if currentResult.status ~= "fail" then
        self:Pass()
    end
end)

TS:Register("Detect keyPress cast with empty steps -> READINESS", "repair", function(self)
    local RA = GRIPEMS.RepairAnalyzer
    if not RA then
        self:Fail("RepairAnalyzer not loaded")
        return
    end
    local sd = buildTestSequence({ steps = {}, keyPress = "/cast Fireball" })
    local issues = RA:Analyze(sd, "_TS_RepairKPCast")
    local found = false
    for _, iss in ipairs(issues) do
        if iss.category == RA.CAT_READINESS then
            found = true
            break
        end
    end
    self:Assert(found, "expected READINESS issue for keyPress cast with empty steps")
    if currentResult.status ~= "fail" then
        self:Pass()
    end
end)

TS:Register("Detect no delivery -> READINESS critical", "repair", function(self)
    local RA = GRIPEMS.RepairAnalyzer
    if not RA then
        self:Fail("RepairAnalyzer not loaded")
        return
    end
    local sd = buildTestSequence({ steps = { "/cast Fireball" } })
    local issues = RA:Analyze(sd, "_TS_RepairNoDlvr")
    local found = false
    for _, iss in ipairs(issues) do
        if iss.category == RA.CAT_READINESS and iss.severity == RA.SEVERITY_CRITICAL then
            found = true
            break
        end
    end
    self:Assert(found, "expected READINESS critical for no keybind/stub")
    if currentResult.status ~= "fail" then
        self:Pass()
    end
end)

TS:Register("Detect unknown spell -> SPELLS issue", "repair", function(self)
    local RA = GRIPEMS.RepairAnalyzer
    local SV = GRIPEMS.SpellValidator
    if not RA then
        self:Fail("RepairAnalyzer not loaded")
        return
    end
    if not SV then
        self:Skip("SpellValidator not loaded")
        return
    end
    local sd = buildTestSequence({ steps = { "/cast Nonexistent Spell 12345" } })
    local issues = RA:Analyze(sd, "_TS_RepairSpell")
    local found = false
    for _, iss in ipairs(issues) do
        if iss.category == RA.CAT_SPELLS then
            found = true
            break
        end
    end
    self:Assert(found, "expected SPELLS issue for unknown spell")
    if currentResult.status ~= "fail" then
        self:Pass()
    end
end)

TS:Register("Detect missing variable -> VARIABLES issue", "repair", function(self)
    local RA = GRIPEMS.RepairAnalyzer
    local VS = GRIPEMS.VariableStore
    if not RA then
        self:Fail("RepairAnalyzer not loaded")
        return
    end
    if not VS then
        self:Skip("VariableStore not loaded")
        return
    end
    local sd = buildTestSequence({ steps = { "/cast ~nosuchvar~" } })
    local issues = RA:Analyze(sd, "_TS_RepairVar")
    local found = false
    for _, iss in ipairs(issues) do
        if iss.category == RA.CAT_VARIABLES then
            found = true
            break
        end
    end
    self:Assert(found, "expected VARIABLES issue for missing variable")
    if currentResult.status ~= "fail" then
        self:Pass()
    end
end)

TS:Register("Detect overlong step -> LIMITS issue", "repair", function(self)
    local RA = GRIPEMS.RepairAnalyzer
    if not RA then
        self:Fail("RepairAnalyzer not loaded")
        return
    end
    local longStep = string.rep("x", 300)
    local sd = buildTestSequence({ steps = { longStep } })
    local issues = RA:Analyze(sd, "_TS_RepairLong")
    local found = false
    for _, iss in ipairs(issues) do
        if iss.category == RA.CAT_LIMITS then
            found = true
            break
        end
    end
    self:Assert(found, "expected LIMITS issue for 300-char step")
    if currentResult.status ~= "fail" then
        self:Pass()
    end
end)

TS:Register("Detect resolved overflow -> POST_SUB issue", "repair", function(self)
    local RA = GRIPEMS.RepairAnalyzer
    local VS = GRIPEMS.VariableStore
    local E = GRIPEMS.Engine
    if not RA then
        self:Fail("RepairAnalyzer not loaded")
        return
    end
    if not VS then
        self:Skip("VariableStore not loaded")
        return
    end
    if not E or not E.SubstituteVariables then
        self:Skip("Engine not loaded")
        return
    end
    local bigVal = string.rep("A", 250)
    VS:Set("TSbigvar", { name = "TSbigvar", funct = '"' .. bigVal .. '"', events = "" })
    local step = string.rep("B", 50) .. "~TSbigvar~"
    local sd = buildTestSequence({ steps = { step } })
    local issues = RA:Analyze(sd, "_TS_RepairPSub")
    VS:Delete("TSbigvar")
    local found = false
    for _, iss in ipairs(issues) do
        if iss.category == RA.CAT_POST_SUB then
            found = true
            break
        end
    end
    self:Assert(found, "expected POST_SUB issue for resolved overflow")
    if currentResult.status ~= "fail" then
        self:Pass()
    end
end)

TS:Register("Fix missing fields (stepFunction, keyPress)", "repair", function(self)
    local RA = GRIPEMS.RepairAnalyzer
    local D = GRIPEMS.Defaults
    if not RA then
        self:Fail("RepairAnalyzer not loaded")
        return
    end
    local sd = buildTestSequence({ steps = { "/cast Fireball" } })
    sd.versions[1].stepFunction = nil
    sd.versions[1].keyPress = nil
    local issues = RA:Analyze(sd, "_TS_RepairFixFields")
    local fixed = 0
    for _, iss in ipairs(issues) do
        if iss.fixable and iss.fixFn and iss.category == RA.CAT_STRUCTURE then
            iss.fixFn(sd)
            fixed = fixed + 1
        end
    end
    self:Assert(fixed > 0, "expected fixable STRUCTURE issues")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(D.STEP_SEQUENTIAL, sd.versions[1].stepFunction, "stepFunction")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("", sd.versions[1].keyPress, "keyPress")
    if currentResult.status ~= "fail" then
        self:Pass()
    end
end)

TS:Register("Fix defaultVersion out of bounds", "repair", function(self)
    local RA = GRIPEMS.RepairAnalyzer
    if not RA then
        self:Fail("RepairAnalyzer not loaded")
        return
    end
    local sd = buildTestSequence({})
    -- Add a second version
    sd.versions[2] = {
        stepFunction = "Sequential",
        steps = { "/cast Frostbolt" },
        keyPress = "",
        keyRelease = "",
        resetOnCombat = false,
        resetOnTarget = false,
        resetOnGear = false,
        resetOnSpec = false,
        resetTimer = 0,
    }
    sd.defaultVersion = 99
    local issues = RA:Analyze(sd, "_TS_RepairDVOOB")
    for _, iss in ipairs(issues) do
        if iss.fixable and iss.fixFn and iss.title == "defaultVersion out of range" then
            iss.fixFn(sd)
        end
    end
    self:Assert(
        sd.defaultVersion >= 1 and sd.defaultVersion <= #sd.versions,
        "defaultVersion should be clamped, got " .. tostring(sd.defaultVersion)
    )
    if currentResult.status ~= "fail" then
        self:Pass()
    end
end)

TS:Register("Fix move keyPress to step", "repair", function(self)
    local RA = GRIPEMS.RepairAnalyzer
    if not RA then
        self:Fail("RepairAnalyzer not loaded")
        return
    end
    local sd = buildTestSequence({ steps = {}, keyPress = "/cast Fireball" })
    local issues = RA:Analyze(sd, "_TS_RepairMoveKP")
    for _, iss in ipairs(issues) do
        if iss.fixable and iss.fixFn and iss.category == RA.CAT_READINESS then
            iss.fixFn(sd)
        end
    end
    self:Assert(
        sd.versions[1].steps[1] and sd.versions[1].steps[1]:find("Fireball"),
        "step[1] should contain Fireball after fix"
    )
    if currentResult.status ~= "fail" then
        self:Pass()
    end
end)

TS:Register("Roundtrip clean sequence -> zero issues", "repair", function(self)
    if self:_SkipIfCombat() then
        return
    end
    local RA = GRIPEMS.RepairAnalyzer
    local Engine = GRIPEMS.Engine
    if not RA then
        self:Fail("RepairAnalyzer not loaded")
        return
    end
    if not Engine then
        self:Fail("Engine not loaded")
        return
    end
    local name = "_TS_RepairClean"
    local sd = buildTestSequence({ steps = { "/cast Fireball" } })
    sd.name = name
    Engine:ActivateSequence(name, sd)
    local issues = RA:Analyze(sd, name)
    Engine:DeactivateSequence(name)
    -- Filter out expected issues (no stub/keybind is expected for test sequences)
    local realIssues = {}
    for _, iss in ipairs(issues) do
        if
            iss.category ~= RA.CAT_READINESS
            and iss.category ~= RA.CAT_STUBS
            and iss.category ~= RA.CAT_CONCURRENT
            and iss.category ~= RA.CAT_STATE_SYNC
            and iss.category ~= RA.CAT_LOCALE
            and iss.category ~= RA.CAT_SPELLS
        then
            realIssues[#realIssues + 1] = iss
        end
    end
    self:AssertEqual(0, #realIssues, "clean sequence should have zero structural issues")
    if currentResult.status ~= "fail" then
        self:Pass()
    end
end)

TS:Register("Roundtrip corrupt -> fix -> fewer issues", "repair", function(self)
    local RA = GRIPEMS.RepairAnalyzer
    if not RA then
        self:Fail("RepairAnalyzer not loaded")
        return
    end
    local sd = buildTestSequence({ steps = {} })
    sd.versions[1].stepFunction = nil
    sd.versions[1].keyPress = nil
    sd.defaultVersion = 99
    sd.icon = nil
    sd.name = nil
    local issues1 = RA:Analyze(sd, "_TS_RepairCorrupt")
    local count1 = #issues1
    for _, iss in ipairs(issues1) do
        if iss.fixable and iss.fixFn then
            iss.fixFn(sd)
        end
    end
    local issues2 = RA:Analyze(sd, "_TS_RepairCorrupt")
    local fixable2 = 0
    for _, iss in ipairs(issues2) do
        if iss.fixable then
            fixable2 = fixable2 + 1
        end
    end
    self:Assert(
        #issues2 < count1,
        "post-fix issues (" .. #issues2 .. ") should be fewer than pre-fix (" .. count1 .. ")"
    )
    if currentResult.status ~= "fail" then
        self:Pass()
    end
end)

TS:Register("ComputeHealthScore returns 0-100", "repair", function(self)
    local RA = GRIPEMS.RepairAnalyzer
    if not RA then
        self:Fail("RepairAnalyzer not loaded")
        return
    end
    -- Corrupt sequence -> score < 100
    local sd = buildTestSequence({ steps = {} })
    sd.versions[1].stepFunction = nil
    local issues = RA:Analyze(sd, "_TS_RepairScore")
    local score = RA:ComputeHealthScore(issues)
    self:Assert(type(score) == "number", "score should be number")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(score >= 0 and score <= 100, "score should be 0-100, got " .. tostring(score))
    if currentResult.status == "fail" then
        return
    end
    -- Clean sequence -> score 100
    local cleanScore = RA:ComputeHealthScore({})
    self:AssertEqual(100, cleanScore, "empty issues should score 100")
    if currentResult.status ~= "fail" then
        self:Pass()
    end
end)

TS:Register("Batch AnalyzeAll returns per-sequence results", "repair", function(self)
    if self:_SkipIfCombat() then
        return
    end
    local RA = GRIPEMS.RepairAnalyzer
    local Engine = GRIPEMS.Engine
    if not RA then
        self:Fail("RepairAnalyzer not loaded")
        return
    end
    if not Engine then
        self:Fail("Engine not loaded")
        return
    end
    local names = { "_TS_BatchClean", "_TS_BatchBad1", "_TS_BatchBad2" }
    -- Clean
    local sd1 = buildTestSequence({ steps = { "/cast Fireball" } })
    sd1.name = names[1]
    Engine:ActivateSequence(names[1], sd1)
    -- Bad 1: empty steps
    local sd2 = buildTestSequence({ steps = {} })
    sd2.name = names[2]
    Engine:ActivateSequence(names[2], sd2)
    -- Bad 2: nil stepFunction
    local sd3 = buildTestSequence({ steps = { "/cast Frostbolt" } })
    sd3.versions[1].stepFunction = nil
    sd3.name = names[3]
    Engine:ActivateSequence(names[3], sd3)
    local allIssues = RA:AnalyzeAll()
    for _, n in ipairs(names) do
        Engine:DeactivateSequence(n)
    end
    -- Verify bad sequences have issues
    local bad1Has = allIssues[names[2]] and #allIssues[names[2]] > 0
    local bad2Has = allIssues[names[3]] and #allIssues[names[3]] > 0
    self:Assert(bad1Has, "bad1 should have issues")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(bad2Has, "bad2 should have issues")
    if currentResult.status ~= "fail" then
        self:Pass()
    end
end)

TS:Register("Undo snapshot created on fix", "repair", function(self)
    local RA = GRIPEMS.RepairAnalyzer
    if not RA then
        self:Fail("RepairAnalyzer not loaded")
        return
    end
    local sd = buildTestSequence({ steps = { "/cast Fireball" } })
    sd.versions[1].stepFunction = nil
    local issues = RA:Analyze(sd, "_TS_RepairUndo")
    local originalSF = sd.versions[1].stepFunction
    local applied = false
    for _, iss in ipairs(issues) do
        if iss.fixable and iss.fixFn and iss.category == RA.CAT_STRUCTURE then
            iss.fixFn(sd)
            applied = true
            break
        end
    end
    self:Assert(applied, "should have applied at least one fix")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(sd.versions[1].stepFunction ~= originalSF, "stepFunction should have changed after fix")
    if currentResult.status ~= "fail" then
        self:Pass()
    end
end)

TS:Register("Detect + fix legacy trinket slot name", "repair", function(self)
    local RA = GRIPEMS.RepairAnalyzer
    local D = GRIPEMS.Defaults
    if not RA then
        self:Fail("RepairAnalyzer not loaded")
        return
    end
    local slotName = C_Spell and C_Spell.GetSpellName and C_Spell.GetSpellName(13)
    if not slotName or slotName == "" then
        self:Skip("C_Spell.GetSpellName(13) nil on this client")
        return
    end
    -- Step 1 carries the baked-in slot name (flagged + fixed), step 2 is a
    -- correctly stored numeric /use (control: never flagged or changed), and
    -- the action node carries the same baked-in name.
    local sd = buildTestSequence({ steps = { "/use [combat] " .. slotName, "/use 13" } })
    sd.versions[1].actions = { { type = D.ACTION_TYPE_ACTION, macro = "/use " .. slotName } }
    local issues = RA:Analyze(sd, "_TS_RepairSlotName", { surface = "repair" })
    local slotIssues = {}
    for _, iss in ipairs(issues) do
        if iss.title == "Legacy trinket slot name" then
            slotIssues[#slotIssues + 1] = iss
        end
    end
    self:Assert(#slotIssues >= 1, "expected at least one Legacy trinket slot name issue")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual(1, #slotIssues, "control '/use 13' must not be flagged (expected exactly one issue)")
    if currentResult.status == "fail" then
        return
    end
    for _, iss in ipairs(slotIssues) do
        self:Assert(iss.fixable and iss.fixFn ~= nil, "slot name issue should be fixable")
    end
    if currentResult.status == "fail" then
        return
    end
    for _, iss in ipairs(slotIssues) do
        iss.fixFn(sd)
    end
    local issues2 = RA:Analyze(sd, "_TS_RepairSlotName", { surface = "repair" })
    local remaining = 0
    for _, iss in ipairs(issues2) do
        if iss.title == "Legacy trinket slot name" then
            remaining = remaining + 1
        end
    end
    self:AssertEqual(0, remaining, "no Legacy trinket slot name issues should remain after fix")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("/use [combat] 13", sd.versions[1].steps[1], "step 1 should be rewritten to /use 13")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("/use 13", sd.versions[1].actions[1].macro, "action macro should be rewritten to /use 13")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("/use 13", sd.versions[1].steps[2], "control step '/use 13' should be unchanged")
    if currentResult.status ~= "fail" then
        self:Pass()
    end
end)

TS:Register("Legacy slot name uses true version index (multi-version active)", "repair", function(self)
    local RA = GRIPEMS.RepairAnalyzer
    if not RA then
        self:Fail("RepairAnalyzer not loaded")
        return
    end
    local slotName = C_Spell and C_Spell.GetSpellName and C_Spell.GetSpellName(13)
    if not slotName or slotName == "" then
        self:Skip("C_Spell.GetSpellName(13) nil on this client")
        return
    end
    -- Two versions: version 1 is clean, version 2 carries the baked-in slot
    -- name. defaultVersion = 2 makes version 2 active, so the badge surface
    -- (activeVersionOnly) checks it at its TRUE index 2. The old single-element
    -- { activeVer } form forced vi = 1, mislabeling the issue "V1" and pointing
    -- the fix at version 1 instead of version 2.
    local sd = buildTestSequence({ steps = { "/cast Fireball" } })
    sd.versions[2] = buildTestSequence({ steps = { "/use " .. slotName } }).versions[1]
    sd.defaultVersion = 2
    local issues = RA:Analyze(sd, "TrueIndexTest", { surface = "badge" })
    local slotIssues = {}
    for _, iss in ipairs(issues) do
        if iss.title == "Legacy trinket slot name" then
            slotIssues[#slotIssues + 1] = iss
        end
    end
    self:AssertEqual(1, #slotIssues, "expected exactly one Legacy trinket slot name issue")
    if currentResult.status == "fail" then
        return
    end
    local detail = slotIssues[1].detail or ""
    self:Assert(detail:find("V2", 1, true) ~= nil, "issue detail should reference true index V2")
    if currentResult.status == "fail" then
        return
    end
    self:Assert(detail:find("V1", 1, true) == nil, "issue detail must not reference old wrong index V1")
    if currentResult.status == "fail" then
        return
    end
    for _, iss in ipairs(slotIssues) do
        iss.fixFn(sd)
    end
    self:AssertEqual("/use 13", sd.versions[2].steps[1], "version 2 step should be rewritten to /use 13")
    if currentResult.status == "fail" then
        return
    end
    self:AssertEqual("/cast Fireball", sd.versions[1].steps[1], "version 1 must be left untouched")
    if currentResult.status ~= "fail" then
        self:Pass()
    end
end)

-- ---------------------------------------------------------------------------
-- Spell validation: CONTEXTUAL status (override / form / proc-replacement)
-- ---------------------------------------------------------------------------

-- Install or restore a function on a read-only API global (C_Spell,
-- C_SpellBook) for the duration of a single test. Routing the assignment
-- through a local parameter keeps the intentional, immediately-restored stub
-- from tripping luacheck's read-only-global-field guard.
local function SetApiField(apiTable, key, fn)
    apiTable[key] = fn
end

TS:Register("ValidateSpell override/form spell -> CONTEXTUAL", "spell-validator-contextual", function(self)
    local SV = GRIPEMS.SpellValidator
    local defaults = GRIPEMS.Defaults
    local SC = GRIPEMS.SpellCache
    if not (SV and defaults and SC) then
        self:Skip("SpellValidator/Defaults/SpellCache not loaded")
        return
    end
    local haveBookApi = C_SpellBook and Enum and Enum.SpellBookSpellBank
    if not (haveBookApi and C_Spell) then
        self:Skip("required C_SpellBook / Enum API unavailable")
        return
    end

    local name = "_TS_ContextualSpell"
    local testID = 999001

    -- Stub: not in the live spellbook snapshot, the name resolves to a test
    -- ID, and the spellbook reports it is in the player's kit (override/form).
    local origByName = SC.byName
    local origGetSpellID = SC.GetSpellID
    local origInBook = C_SpellBook.IsSpellInSpellBook
    SC.byName = {}
    SC.GetSpellID = function()
        return testID
    end
    SetApiField(C_SpellBook, "IsSpellInSpellBook", function()
        return true
    end)

    local ok, res = pcall(SV.ValidateSpell, SV, name, "cast")

    SC.byName = origByName
    SC.GetSpellID = origGetSpellID
    SetApiField(C_SpellBook, "IsSpellInSpellBook", origInBook)

    if not ok then
        self:Fail("ValidateSpell raised: " .. tostring(res))
        return
    end
    self:AssertEqual(defaults.SPELL_STATUS_CONTEXTUAL, res.status, "in-kit override spell is contextual")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("ValidateSpell wrong-spec spell -> KNOWN", "spell-validator-contextual", function(self)
    local SV = GRIPEMS.SpellValidator
    local defaults = GRIPEMS.Defaults
    local SC = GRIPEMS.SpellCache
    if not (SV and defaults and SC) then
        self:Skip("SpellValidator/Defaults/SpellCache not loaded")
        return
    end
    local haveBookApi = C_SpellBook and Enum and Enum.SpellBookSpellBank
    if not (haveBookApi and C_Spell and C_Spell.DoesSpellExist and issecretvalue) then
        self:Skip("required C_Spell / C_SpellBook / Enum API unavailable")
        return
    end

    local name = "_TS_WrongSpecSpell"
    local testID = 999002

    -- Stub: the in-kit check says NO (spellbook reports not in kit), but the
    -- spell exists in the game (talent-gated / wrong spec) -> falls to KNOWN.
    local origByName = SC.byName
    local origGetSpellID = SC.GetSpellID
    local origInBook = C_SpellBook.IsSpellInSpellBook
    local origExists = C_Spell.DoesSpellExist
    SC.byName = {}
    SC.GetSpellID = function()
        return testID
    end
    SetApiField(C_SpellBook, "IsSpellInSpellBook", function()
        return false
    end)
    SetApiField(C_Spell, "DoesSpellExist", function()
        return true
    end)

    local ok, res = pcall(SV.ValidateSpell, SV, name, "cast")

    SC.byName = origByName
    SC.GetSpellID = origGetSpellID
    SetApiField(C_SpellBook, "IsSpellInSpellBook", origInBook)
    SetApiField(C_Spell, "DoesSpellExist", origExists)

    if not ok then
        self:Fail("ValidateSpell raised: " .. tostring(res))
        return
    end
    self:AssertEqual(defaults.SPELL_STATUS_KNOWN, res.status, "exists but not in kit is known")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("ValidateSpell spellbook spell -> VALID", "spell-validator-contextual", function(self)
    local SV = GRIPEMS.SpellValidator
    local defaults = GRIPEMS.Defaults
    local SC = GRIPEMS.SpellCache
    if not (SV and defaults and SC) then
        self:Skip("SpellValidator/Defaults/SpellCache not loaded")
        return
    end

    local name = "_ts_validspell"

    -- Stub: the name is present in the live spellbook snapshot -> valid.
    local origByName = SC.byName
    SC.byName = { [name] = { spellID = 999003, iconID = 134400 } }

    local ok, res = pcall(SV.ValidateSpell, SV, name, "cast")

    SC.byName = origByName

    if not ok then
        self:Fail("ValidateSpell raised: " .. tostring(res))
        return
    end
    self:AssertEqual(defaults.SPELL_STATUS_VALID, res.status, "spellbook snapshot hit is valid")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("ValidateSpell missing spell -> UNKNOWN", "spell-validator-contextual", function(self)
    local SV = GRIPEMS.SpellValidator
    local defaults = GRIPEMS.Defaults
    local SC = GRIPEMS.SpellCache
    if not (SV and defaults and SC) then
        self:Skip("SpellValidator/Defaults/SpellCache not loaded")
        return
    end
    if not (C_Spell and C_Spell.DoesSpellExist) then
        self:Skip("C_Spell.DoesSpellExist unavailable")
        return
    end

    local name = "_TS_MissingSpell"

    -- Stub: not in the snapshot, no ID resolves, and the game reports it does
    -- not exist -> genuinely unknown.
    local origByName = SC.byName
    local origGetSpellID = SC.GetSpellID
    local origExists = C_Spell.DoesSpellExist
    SC.byName = {}
    SC.GetSpellID = function()
        return nil
    end
    SetApiField(C_Spell, "DoesSpellExist", function()
        return false
    end)

    local ok, res = pcall(SV.ValidateSpell, SV, name, "cast")

    SC.byName = origByName
    SC.GetSpellID = origGetSpellID
    SetApiField(C_Spell, "DoesSpellExist", origExists)

    if not ok then
        self:Fail("ValidateSpell raised: " .. tostring(res))
        return
    end
    self:AssertEqual(defaults.SPELL_STATUS_UNKNOWN, res.status, "no resolution is unknown")
    if currentResult.status == "fail" then
        return
    end
    self:Pass()
end)

TS:Register("external skyride bind collision report", "environment", function(self)
    local VK = GRIPEMS.VehicleKeybinds
    if not (VK and VK.GetExternalSkyrideBindCollisions) then
        self:Skip("VehicleKeybinds detector not loaded")
        return
    end
    if not (C_AddOns and C_AddOns.IsAddOnLoaded and C_AddOns.IsAddOnLoaded("GSE_QoL")) then
        self:Skip("external QoL module not loaded")
        return
    end
    local ok, hits = pcall(VK.GetExternalSkyrideBindCollisions, VK)
    if not ok then
        self:Fail("detector raised: " .. tostring(hits))
        return
    end
    if hits then
        self:Skip("contended keys: " .. table.concat(hits, ", ") .. " -- see the Keybinds tab notice")
        return
    end
    self:Pass()
end)

TS:Register("external petbattle bind collision report", "environment", function(self)
    local VK = GRIPEMS.VehicleKeybinds
    if not (VK and VK.GetExternalPetBattleBindCollisions) then
        self:Skip("pet battle detector not loaded")
        return
    end
    if not (C_AddOns and C_AddOns.IsAddOnLoaded and C_AddOns.IsAddOnLoaded("GSE_QoL")) then
        self:Skip("external QoL module not loaded")
        return
    end
    local ok, hits = pcall(VK.GetExternalPetBattleBindCollisions, VK)
    if not ok then
        self:Fail("detector raised: " .. tostring(hits))
        return
    end
    if hits then
        self:Skip("contended keys: " .. table.concat(hits, ", ") .. " -- see the Keybinds tab notice")
        return
    end
    self:Pass()
end)
