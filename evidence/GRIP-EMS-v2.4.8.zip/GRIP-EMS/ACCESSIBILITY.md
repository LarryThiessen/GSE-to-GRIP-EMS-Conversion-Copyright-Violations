# EMS Accessibility

> **Created:** 2026-04-24
> **Updated:** 2026-08-25
> **WoW Patch at last update:** 12.1.0 Midnight (Retail LIVE)
> **Version:** v2.0.0

GRIP-EMS aims to be usable for players who rely on screen readers, play one-handed, play with tremor, play with low vision, or avoid motion in the UI. Settings live under the Accessibility subpanel (`/gems settings` -> Accessibility). Design vocabulary follows AbleGamers APX (Accessible Player Experiences). The in-game panel layout is modelled on Elder Scrolls Online's Accessibility Mode: one place, grouped by population.

This document lists features that ship in v2.0.0. Structural limits (things the WoW addon API does not expose) are called out separately in section 4.

## Features

### Vision

- Screen readers via Blizzard's built-in text-to-speech (`C_VoiceChat.SpeakText`). Speaks the current step label when a sequence advances. One-shot in-game toast if no voice is configured.
- A chat-frame emitter pipes the same state messages into a user-selected chat frame (default hidden frame #9). BlindSlash, NVDA bridges, and other screen-reader relays can dock that frame and read from it.
- Editor scale slider from 0.8x to 2.0x in 0.05 steps. MainFrame drag-resize from 720x460 up to 1600x720.
- High-contrast focus ring on every focusable widget (4-edge texture, 2 px thick, 2 px outset).
- Font switch via LibSharedMedia with Atkinson Hyperlegible bundled.
- Colourblind support: three palette presets (Default, High Contrast, Deuteranopia-safe) auto-seeded from Blizzard's `colorblindMode` CVar on first login, plus an 8-type matrix (protanopia, protanomaly, deuteranopia, deuteranomaly, tritanopia, tritanomaly, achromatopsia, achromatomaly) with a 0-100% strength slider layered on top. Live 5-colour preview swatch next to the slider.
- Photosensitivity: no repeating flashes. Animations audited against WCAG 2.3.1 "Three Flashes or Below Threshold". The reduce-motion toggle below also applies.
- Flicker-safe palette: damps alpha-animation delta ranges below the WCAG threshold at the two animation sites (Tempo overlay alert pulse, Tracker HUD highlight). Auto-mirrors from Blizzard's `screenEdgeFlash` CVar on first login.
- Contrast warnings: when a class colour fails WCAG 2.2 contrast, a toast in the top-right offers Dismiss (silences the class for 30 minutes) or Auto-fix (writes a passing background colour and silences the class for 7 days). The Theming Editor lists silenced classes with per-class Unsilence buttons and a header count badge. An Unsilence all action clears every silence at once; with 4 or more silenced classes it asks for confirmation first.

### Motion and vestibular

- Reduce-motion toggle disables the two animation sites in the addon (Tempo overlay pulse, Tracker fade-in).

### Motor

- Keyboard-first navigation using Tab / Shift-Tab / Arrow / Enter / Escape. Every non-EditBox widget is reachable.
- Numbered-key hotkeys: 1..6 and Alt+1..6 jump directly to the matching editor tab.
- Resizable main window with a bottom-right drag grip.
- Spell, item, macro, and slash-command pickers (14 filter modes) so long macro strings never need manual typing.
- Large-target density mode expands click rectangles to at least 44x44 px (WCAG 2.5.5 AAA) across action buttons, checkboxes, and tab strips.
- Cursor enhancement overlay: ring or crosshair, three sizes (1.0x / 1.5x / 2.0x). Colour ties to the active contrast palette.
- Simplified Mode: a preset for switch input, eye trackers with dwell-click, sip-and-puff, head tracking, and any AT driver that emits standard keyboard or mouse events through its driver. Collapses SequenceEditor to 2 tabs plus a 3-button action column (Run / Unlock editor / Close), and locks the key set to Enter / Space / Tab / Shift-Tab / Escape. A 500 ms post-acceptance delay (250..1500 ms slider) blocks accidental double-fires. Toggle from the Accessibility subpanel, via the one-click Accessibility Mode preset, or with `/gems simplified`. A single `/reload` after the first enable produces the cleanest layout; same-session toggles apply best-effort live.
- Undo / Redo across the sequence editor, step list, popup editor, and repair frame. Ctrl+Z / Ctrl+Y / Ctrl+Shift+Z in each.

### Cognitive, new players, ESL

- Opt-in first-run tutorial. Skippable and replayable.
- Help popovers on every SequenceEditor section. A `?` icon opens a short, tooltip-anchored guide.
- Plain-language tooltip text across validation messages and slash-command output.
- Sequence metadata fields (Author, Description, Help Text, Help Link) so sequence authors can embed guidance that travels with the export.

### Audio

- Sound cues for validation errors, validation success, import-related info, and step advance. Four semantic cues routed through LibSharedMedia, so any sound installed by SharedMedia, WeakAuras, ElvUI, or similar is pickable per cue.
- Visual flash complement: an independent peer toggle to sound cues. Single fixed-position 80x80 frame at top-centre of the screen, shown for 0.6 s per cue. Per-cue colour: red error, green success, cyan info, gold step-complete. Deaf or hard-of-hearing players can have visual on with sound off, or both together. flickerSafe damps the flash to 0.3 alpha; reduceMotion damps to 0.6; default is 0.85.
- Channel selection (Master / SFX / Ambience / Dialogue).
- Cue audition: each of the four cue rows in the Accessibility settings panel has a Play button so you can hear a sound before committing to it. Useful for picking by loudness when WeakAuras, BigWigs, or similar add-ons that register sounds via LibSharedMedia are installed.
- Opt-in, off by default.

### General

- One-click Accessibility Mode preset. Turns on speech, reduce-motion, the High-Contrast palette, editor scale 1.25x, large-target density, the cursor overlay, and Simplified Mode together. Snapshot-and-restore on toggle-off: your prior state returns, not the defaults.
- First-run CVar mirror. On the first login after installation, EMS reads Blizzard's accessibility CVars (`colorblindMode`, `cameraBobbing`, gamepad-detected) and pre-applies matching EMS settings. One-shot; re-run from the Accessibility subpanel if your Blizzard settings change later.
- Accessibility subpanel under `/gems settings` groups the above by area: Display, Motion, Audio, Cursor, Feedback, Theming, Simplified Mode. Every setting is profile-scoped, so alts can differ.
- Theming: a bounded subpanel (global font, editor scale, validation-badge palette, border and background opacity, per-panel alpha) and a full per-element editor at `/gems theme`. The full editor exposes 45 element classes across Panels, Overlays, Rows, Buttons, Text, Emphasis, and Global. Five user-named preset slots, plus copy-to-all-profiles. Themes can be shared via chat link.
- Accessibility feedback panel. Four buttons link to AbleGamers APX, the Game Accessibility Guidelines, a Netflix documentary about accessible play in WoW, and the support Discord. WoW has no browser-launch API, so each button opens a static-popup edit box with the URL pre-selected for Ctrl+C copy.

#### Note on the theming taxonomy (for users looking at the 45-class tree)

The theming apply engine uses two patterns. Persistent UI (panels, singleton overlays, the focus ring) is frame-registered: EMS holds a reference to the widget and re-skins it directly when the theme changes. Transient and construction-time UI (rows, buttons, text FontStrings, emphasis state modifiers, the global addon font) is consumer-lookup: the widget reads its spec from the current theme at the moment it renders. Both patterns produce identical visible theming. Consumer-lookup classes are not "unbound" and are not reserved; they simply apply at a different point in the widget's lifecycle.

Five overlay classes are reserved in the taxonomy for features not yet shipped in v2.0.0: `overlay.toast.info`, `overlay.toast.error`, `overlay.modal.dim`, `overlay.tooltip`, `overlay.dragPreview`. Their specs are in place so future work can bind them without a taxonomy change. One panel class, `panel.profileMgr`, is a Blizzard-owned surface (the AceDBOptions profile picker); EMS cannot currently reach a frame handle for it, so its theming is deferred until that handle is exposed.

## Compatibility with other accessibility addons

| Addon | Coexists | Notes |
|---|---|---|
| BlindSlash | Yes | EMS TTS speaks step announcements. The chat-frame emitter pipes state into a dedicated chat-frame slot (default frame 9) for BlindSlash to parse. |
| ConsolePort | Yes | Detected at login via the gamepad-detected flag. The keybind UI accepts gamepad buttons without extra config. |
| DialogueUI | Yes | No shared UI surface. |
| Leatrix Plus | Yes | No shared UI surface. Leatrix's own cursor-enhancement options are a good choice for users who want more cursor textures than EMS ships. |
| ElvUI | Yes | EMS owns its own frames. Anchor MainFrame inside an ElvUI layout normally. |
| WeakAuras | Yes | No shared UI surface. No taint interaction. |
| Atkinson Hyperlegible (font addon) | Yes | EMS bundles an in-app font switch via LibSharedMedia with Atkinson Hyperlegible included. Third-party font addons still coexist. |

## What EMS cannot do

These are capabilities the addon API does not expose. They are structural limits, not deferred features.

- **Native screen-reader integration (NVDA / JAWS / VoiceOver).** WoW does not expose its UI to Windows UIAutomation, Apple Accessibility, or any assistive-technology framework. Screen readers see WoW as opaque pixels. EMS compensates with the TTS output and the chat-frame emitter above.
- **Macro-pacing slowdown.** Macro cadence is global-cooldown-bound. Slowing it below the GCD breaks the rotation.
- **Voice input / speech-to-sequence.** No WoW API for speech recognition. Users route through Dragon or Talon as keyboard bridges; EMS sees those bridges as regular keyboard input.
- **Orientation and reflow (WCAG 1.3.4, 1.4.10).** WoW is landscape-only with a fixed UI layout. The CSS-reflow concept does not map.
- **Detection of specific assistive tech** (switch controllers, eye trackers, individual screen-reader brands). Those devices emit regular keyboard or mouse events through their driver; WoW cannot tell them apart. EMS exposes what Blizzard CVars reveal (`colorblindMode`, reduced-motion proxies, gamepad-detected) and stops there.
- **AceConfig select-widget value truncation at long-translated locales.** EMS settings panels render via AceConfig-3.0; AceConfig owns truncation behaviour for select-widget value text. Long translated values may show ellipsis. Cosmetic only: the underlying setting still works. Filing an upstream AceConfig issue is the only fix path.
- **Cross-addon popups while EMS Settings is open.** While an EMS Settings subpanel is shown, ESCAPE is captured by EMS for keyboard navigation and dismissal of EMS's own dialogs. If another addon opens a popup over the EMS Settings panel, click that popup's Cancel or Close button directly. ESCAPE will not reach it until you close the EMS Settings subpanel. WoW's public StaticPopup_Hide API does not fire the dialog's OnCancel callback, so an EMS-side dismissal would skip the other addon's cleanup. Closing the EMS Settings subpanel restores ESCAPE to its normal routing.
- **ThemingEditor modal frame layout details.** `/gems theme` opens through `AceConfigDialog:Open`; AceConfig manages frame size, scrolling, and child widget layout. EMS does not have direct frame-level control over the modal's chrome. Reports of layout issues inside the modal should be reproducible against AceConfig + filed upstream.
- **FocusRing into adjacent widget at Simplified Mode.** At Simplified Mode the focus ring outset bumps from 2 px to 4 px for visibility. When two focusable widgets sit less than 4 px apart, the ring of the focused widget may visually extend into the adjacent widget. Cosmetic only: the focus target is unchanged. Affects a small number of right-anchored chains.
- **AccessibilityMode + uiScale=1.5 on small displays (1366x768 or smaller).** AccessibilityMode forces uiScale=1.5; at that scale, MainFrame's effective screen height (~690 px) exceeds the screen height of small displays. The frame remains usable but cannot drag-resize past the screen edge. EMS now prints a one-time toast when AccessibilityMode is enabled on a display that cannot accommodate the full frame. Mitigation: disable AccessibilityMode or move to a display with at least 768 native pixels of vertical resolution.

## Feedback

- **Discord:** <https://discord.gg/temptingus> is the primary support channel. Accessibility reports go in the addon thread.
- **In-game:** `/gems` -> Accessibility -> Feedback opens the same four reference links bundled into the addon.
- **External references we draw from:** AbleGamers APX (design patterns), Game Accessibility Guidelines (post-acceptance delay, contrast, target size), and WCAG 2.2.

## References

- ZeniMax ESO Accessibility Player Guide: <https://www.elderscrollsonline.com/en-us/news/post/63876>
- AbleGamers APX Design Patterns: <https://accessible.games/accessible-player-experiences/design-patterns/>
- Game Accessibility Guidelines: <https://gameaccessibilityguidelines.com/>
- WCAG 2.2 Success Criteria: 2.3.1 (Three Flashes), 2.4.7 (Focus Visible), 2.5.5 (Target Size Enhanced)

(c) 2026 Sataana. All Rights Reserved. See LICENSE.
Not licensed for AI or ML training. See LICENSE section 3.
