-- GRIP-EMS: Headless test for callback handler signature / producer arity agreement
--
-- Created:    2026-08-14
-- Updated:    2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.
--
-- Guards CALLBACK-HANDLER-SIGNATURE-OFF-BY-ONE. Five live handlers were written
-- as if CallbackHandler prepends self to a function ref. It does not:
--
--     Dispatch(events[eventname], eventname, ...)      CallbackHandler-1.0:54
--     self["method"]         leads to self["method"](self, ...)      :76
--     self with function ref leads to functionref(...)               :77
--
-- Only the STRING form gets self. A function handler receives
-- (eventname, payload...) and nothing more, so function(_, _, name) reads one
-- position late. All five were registered and running; each failed silently.
--
-- WHY THIS FILE LOADS THE REAL LIBRARY AND THE REAL MODULES. A test that calls
-- a handler body directly with hand-built arguments cannot see this bug -- it
-- re-encodes the very assumption the bug is made of, and would have passed
-- against the broken tree. So this file:
--
--   1. loads Libs/CallbackHandler-1.0/CallbackHandler-1.0.lua itself,
--   2. builds the registry on GRIPEMS exactly the way Core/Core.lua:3304 does,
--   3. loads the REAL Engine/MacroConditionalBaker.lua and Engine/OOCQueue.lua
--      and lets THEM register their own handlers,
--   4. fires with the SAME payload arity the real producers use, quoted per
--      case from the producer source.
--
-- Nothing here asserts against a handler signature. Every case asserts the
-- OBSERVABLE END STATE -- which name reached the cache invalidator, which
-- interval reached the ticker -- so the cases stay true if the signatures are
-- ever refactored again.
--
-- COVERAGE IS BY EVENT FAMILY, which is what the arity contract is keyed on.
-- MacroConditionalBaker covers VARIABLE_UPDATED (2 payload args),
-- VARIABLE_CREATED and VARIABLE_DELETED (1 payload arg each); OOCQueue covers
-- SETTING_CHANGED (2 payload args). Engine/Engine.lua's VARIABLE_UPDATED
-- handler is the same family and the same one-position fix as MCB's, and its
-- registration sits inside Core's ADDON_LOADED restore path rather than behind
-- a callable entry point, so it is covered by family here and per-site by the
-- cbsignature alllint row.
--
-- Run from the EMS root:  lua Test/test_callback_signature_arity.lua
-- Exit code 0 = all passed, 1 = at least one failure.
--
-- Cases:
--   V1  VARIABLE_UPDATED (name, value) -> the invalidator sees the NAME
--   V2  VARIABLE_CREATED (name)        -> the invalidator sees the NAME, not nil
--   V3  VARIABLE_DELETED (name)        -> the invalidator sees the NAME, not nil
--   V4  decoy: the name in the VALUE slot must NOT be what the handler reads
--   S1  SETTING_CHANGED (key, value)   -> the oocDelay value reaches the ticker
--   S2  decoy: oocDelay in the VALUE slot must not rebuild the ticker
--   S3  autoReloadAtCombatEnd ON drains the queue (the second arm of the same
--       handler, which never fired either)

local ADDON_NAME = "GRIP-EMS"

-- ---------------------------------------------------------------------------
-- Minimal assertion + runner harness.
-- ---------------------------------------------------------------------------

local tests = {}

local function test(name, fn)
    tests[#tests + 1] = { name = name, fn = fn }
end

local function assertEqual(expected, actual, msg)
    if expected ~= actual then
        error((msg or "assertEqual") .. ": expected " .. tostring(expected) .. ", got " .. tostring(actual), 2)
    end
end

local function assertTrue(cond, msg)
    if not cond then
        error(msg or "assertTrue failed", 2)
    end
end

-- ---------------------------------------------------------------------------
-- Sandbox. Wide enough to load the two real modules at file scope and no wider.
-- ---------------------------------------------------------------------------

local GRIPEMS = {}

-- Every ticker the modules create, newest last, so a case can assert which
-- interval actually reached C_Timer rather than inspecting the handler.
local tickers = {}
local deferred = {}

-- Combat state, in its own table rather than on env: a Lua constructor cannot
-- reference the local it is being assigned to, so the stub below would resolve
-- a nil global instead.
local combatState = { inCombat = false }

local locale = setmetatable({}, {
    __index = function(_, k)
        return k
    end,
})

local env = {
    GRIPEMS = GRIPEMS,
    LibStub = function(name)
        if name == "AceLocale-3.0" then
            return {
                GetLocale = function()
                    return locale
                end,
            }
        end
        return nil
    end,
    GetLocale = function()
        return "enUS"
    end,
    CreateFrame = function()
        return {
            RegisterEvent = function() end,
            UnregisterEvent = function() end,
            UnregisterAllEvents = function() end,
            SetScript = function() end,
        }
    end,
    C_Timer = {
        NewTicker = function(interval, fn)
            local t = { interval = interval, fn = fn }
            function t:Cancel()
                self.cancelled = true
            end
            tickers[#tickers + 1] = t
            return t
        end,
        -- OOCQueue defers its registration by one frame precisely so the
        -- registry exists. Collect rather than run, so the test controls when.
        After = function(_, fn)
            deferred[#deferred + 1] = fn
        end,
    },
    -- Mutable, because OOCQueue:Add runs the op immediately when out of combat
    -- (Engine/OOCQueue.lua:96) and only QUEUES under lockdown. S3 needs a real
    -- queued op to observe the drain arm, so it has to enter and leave combat.
    InCombatLockdown = function()
        return combatState.inCombat == true
    end,
    -- WoW globals the drain path touches once the handler actually reaches it.
    wipe = function(t)
        for k in pairs(t) do
            t[k] = nil
        end
        return t
    end,
    time = os.time,
    GetTime = os.clock,
    print = print,
    tostring = tostring,
    tonumber = tonumber,
    type = type,
    pairs = pairs,
    ipairs = ipairs,
    next = next,
    select = select,
    error = error,
    pcall = pcall,
    setmetatable = setmetatable,
    getmetatable = getmetatable,
    rawget = rawget,
    rawset = rawset,
    table = table,
    string = string,
    math = math,
    os = os,
    unpack = unpack,
    assert = assert,
    -- CallbackHandler captures this at file scope; in the client it is the
    -- taint-safe call wrapper, and a plain call is the faithful stand-in.
    securecallfunction = function(fn, ...)
        return fn(...)
    end,
}
env._G = env

GRIPEMS.Defaults = {
    OOC_TICKER_INTERVAL = 0.5,
    OOC_OP_GENERIC = "generic",
    OOC_OP_IMPORTMACRO = "importmacro",
    OOC_OP_SETTING = "setting",
    OOC_PRIORITY = {},
}
function GRIPEMS:Debug() end
function GRIPEMS:Print() end

-- ---------------------------------------------------------------------------
-- Load the REAL CallbackHandler and build the registry the way Core does.
-- ---------------------------------------------------------------------------

local function loadModule(candidates, ...)
    for _, path in ipairs(candidates) do
        -- loadfile is dev-harness file I/O, intentionally outside the addon WoW std.
        -- selene: allow(undefined_variable)
        local chunk = loadfile(path)
        if chunk then
            setfenv(chunk, env)
            chunk(...)
            return true
        end
    end
    return false
end

local CBH = {}
do
    local libEnv = {}
    for k, v in pairs(env) do
        libEnv[k] = v
    end
    libEnv.LibStub = {
        NewLibrary = function()
            return CBH
        end,
    }
    libEnv._G = libEnv
    local loaded = false
    for _, path in ipairs({
        "Libs/CallbackHandler-1.0/CallbackHandler-1.0.lua",
        "../Libs/CallbackHandler-1.0/CallbackHandler-1.0.lua",
        "GRIP/EMS/Libs/CallbackHandler-1.0/CallbackHandler-1.0.lua",
    }) do
        -- selene: allow(undefined_variable)
        local chunk = loadfile(path)
        if chunk then
            setfenv(chunk, libEnv)
            chunk()
            loaded = true
            break
        end
    end
    assert(loaded, "could not locate Libs/CallbackHandler-1.0 (run from the EMS root)")
end
assert(type(CBH.New) == "function", "the REAL CallbackHandler was loaded, not a stand-in")

-- Core/Core.lua:3304, verbatim in shape.
local cbRegistry = CBH:New(GRIPEMS)
function GRIPEMS:Fire(event, ...)
    cbRegistry:Fire(event, ...)
end
assert(type(GRIPEMS.RegisterCallback) == "function", "the registry published RegisterCallback onto GRIPEMS")

-- ---------------------------------------------------------------------------
-- Load the REAL modules. The registry already exists, which is the state
-- Core guarantees before either module's registration runs.
-- ---------------------------------------------------------------------------

assert(
    loadModule({
        "Engine/MacroConditionalBaker.lua",
        "../Engine/MacroConditionalBaker.lua",
        "GRIP/EMS/Engine/MacroConditionalBaker.lua",
    }, ADDON_NAME, GRIPEMS),
    "could not locate Engine/MacroConditionalBaker.lua (run from the EMS root)"
)
assert(
    loadModule({
        "Engine/OOCQueue.lua",
        "../Engine/OOCQueue.lua",
        "GRIP/EMS/Engine/OOCQueue.lua",
    }, ADDON_NAME, GRIPEMS),
    "could not locate Engine/OOCQueue.lua (run from the EMS root)"
)

local MCB = GRIPEMS.MacroConditionalBaker
local OOCQueue = GRIPEMS.OOCQueue
assert(MCB and type(MCB.Initialize) == "function", "the real MacroConditionalBaker loaded")
assert(OOCQueue and type(OOCQueue.Add) == "function", "the real OOCQueue loaded")

-- MCB registers from its own Initialize; the PLAYER_LOGIN bootstrap frame that
-- normally calls it cannot fire headless, so call the same entry point.
MCB:Initialize()
-- OOCQueue registers from the C_Timer.After(0) the module schedules at load.
for _, fn in ipairs(deferred) do
    fn()
end
deferred = {}

-- Both modules must actually have registered, or every case below is vacuous.
assert(cbRegistry.events["VARIABLE_UPDATED"], "MCB registered VARIABLE_UPDATED")
assert(cbRegistry.events["VARIABLE_CREATED"], "MCB registered VARIABLE_CREATED")
assert(cbRegistry.events["VARIABLE_DELETED"], "MCB registered VARIABLE_DELETED")
assert(cbRegistry.events["SETTING_CHANGED"], "OOCQueue registered SETTING_CHANGED")

-- ---------------------------------------------------------------------------
-- Observation points. MCB._Invalidate is a plain function field looked up at
-- call time, so replacing it records exactly what the handler passed on.
-- ---------------------------------------------------------------------------

assert(type(MCB._Invalidate) == "function", "MCB._Invalidate is the observable the handlers call")
local realInvalidate = MCB._Invalidate
local seenName
local seenCount

local function WatchInvalidate(fn)
    seenName, seenCount = nil, 0
    MCB._Invalidate = function(name)
        seenName = name
        seenCount = seenCount + 1
    end
    local ok, err = pcall(fn)
    MCB._Invalidate = realInvalidate
    if not ok then
        error(err, 0)
    end
end

-- ---------------------------------------------------------------------------
-- V-cases: the VariableStore event family.
-- ---------------------------------------------------------------------------

-- Producer: Data/VariableStore.lua:238 GRIPEMS:Fire("VARIABLE_UPDATED", name, value)
test("V1 VARIABLE_UPDATED (name, value): the invalidator receives the NAME", function()
    WatchInvalidate(function()
        GRIPEMS:Fire("VARIABLE_UPDATED", "myVar", "someValue")
    end)
    assertEqual(1, seenCount, "V1: the handler ran exactly once")
    assertEqual("myVar", seenName, "V1: the NAME reached the cache invalidator")
end)

-- Producer: Data/VariableStore.lua:235 and :345 GRIPEMS:Fire("VARIABLE_CREATED", name)
-- ONE payload arg, so the old signature bound nil and _Invalidate returned on
-- its own "if not varName" guard -- the bake cache was never invalidated at all.
test("V2 VARIABLE_CREATED (name): the invalidator receives the NAME, not nil", function()
    WatchInvalidate(function()
        GRIPEMS:Fire("VARIABLE_CREATED", "freshVar")
    end)
    assertEqual(1, seenCount, "V2: the handler ran exactly once")
    assertEqual("freshVar", seenName, "V2: the NAME reached the invalidator")
    assertTrue(seenName ~= nil, "V2: and specifically it is not nil, which is what the old shape produced")
end)

-- Producer: Data/VariableStore.lua:265 and :344 GRIPEMS:Fire("VARIABLE_DELETED", name)
test("V3 VARIABLE_DELETED (name): the invalidator receives the NAME, not nil", function()
    WatchInvalidate(function()
        GRIPEMS:Fire("VARIABLE_DELETED", "goneVar")
    end)
    assertEqual(1, seenCount, "V3: the handler ran exactly once")
    assertEqual("goneVar", seenName, "V3: the NAME reached the invalidator")
end)

-- THE DISCRIMINATOR. On the old signature this case passed and V1 failed; the
-- two together cannot both be satisfied by any single fixed offset.
test("V4 decoy: a name sitting in the VALUE slot is not what the handler reads", function()
    WatchInvalidate(function()
        GRIPEMS:Fire("VARIABLE_UPDATED", "realName", "decoyName")
    end)
    assertEqual("realName", seenName, "V4: the first payload arg wins")
    assertTrue(seenName ~= "decoyName", "V4: and the second payload arg is specifically NOT read as the name")
end)

-- ---------------------------------------------------------------------------
-- S-cases: the Settings event family, observed through the real ticker.
-- ---------------------------------------------------------------------------

-- Producer: Data/Settings.lua:257 GRIPEMS:Fire("SETTING_CHANGED", key, value)
test("S1 SETTING_CHANGED (oocDelay, value): the new interval reaches the ticker", function()
    local before = #tickers
    GRIPEMS:Fire("SETTING_CHANGED", "oocDelay", 2.25)
    assertEqual(before + 1, #tickers, "S1: exactly one new ticker was created")
    assertEqual(2.25, tickers[#tickers].interval, "S1: and it carries the value the setting was changed to")
    assertTrue(tickers[before].cancelled == true, "S1: the outgoing ticker was cancelled, not leaked")
end)

-- The other half of the same discrimination: with the old signature, key bound
-- the VALUE, so THIS shape is the one that used to reach the oocDelay arm.
test("S2 decoy: oocDelay sitting in the VALUE slot must not rebuild the ticker", function()
    local before = #tickers
    GRIPEMS:Fire("SETTING_CHANGED", "someOtherSetting", "oocDelay")
    assertEqual(before, #tickers, "S2: no ticker was created for a setting that is not oocDelay")
end)

-- The second arm of the same handler, dead for the same reason.
test("S3 SETTING_CHANGED (autoReloadAtCombatEnd, true) drains the queue", function()
    local ran = 0
    -- Queue under lockdown, which is the only state in which Add defers.
    combatState.inCombat = true
    OOCQueue:Add(function()
        ran = ran + 1
    end, GRIPEMS.Defaults.OOC_OP_GENERIC, nil)
    assertTrue(#OOCQueue.queue > 0, "S3: the op really is queued before the event")
    assertEqual(0, ran, "S3: and it has not run yet")
    -- Combat ends; the drain arm is gated on "not IsRestricted() and #queue > 0".
    combatState.inCombat = false
    GRIPEMS:Fire("SETTING_CHANGED", "autoReloadAtCombatEnd", true)
    assertEqual(1, ran, "S3: flipping the toggle ON drained the queued op")
    assertEqual(0, #OOCQueue.queue, "S3: and the queue is empty afterwards")
end)

-- ---------------------------------------------------------------------------
-- Run.
-- ---------------------------------------------------------------------------

local passed = 0
local failed = 0
for _, t in ipairs(tests) do
    local ok, err = pcall(t.fn)
    if ok then
        passed = passed + 1
        print("PASS  " .. t.name)
    else
        failed = failed + 1
        print("FAIL  " .. t.name .. " -- " .. tostring(err))
    end
end
print(string.format("RESULT %d passed, %d failed", passed, failed))
os.exit(failed > 0 and 1 or 0)
