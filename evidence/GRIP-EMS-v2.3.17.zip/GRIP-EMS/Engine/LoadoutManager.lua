-- GRIP-EMS: LoadoutManager
-- Created: 2026-05-13
-- Updated: 2026-06-21
-- Patch: 12.0.7.68256 Midnight (Retail LIVE)
-- Phase 1.5b-polish (empirical model corrections, 2026-05-13 PM AVAV):
--   * already-active check uses C_ClassTalents.GetLastSelectedSavedConfigID(specID);
--     C_ClassTalents.GetActiveConfigID() returns the player's persistent scratch
--     slot which is stable across all switches.
--   * primary success signal is UNIT_SPELLCAST_SUCCEEDED for spell 384255
--     ("Changing Talents") routed via LM:_OnCommitCastSucceeded; ACCC and PTU
--     do NOT fire for current-spec ClassTalentHelper.SwitchToLoadoutByIndex
--     switches.
--   * GetLastSelectedSavedConfigID(specID) updates server-side 5-18s AFTER the
--     USS event (empirical 2026-05-13 PM smoke); no event fires when it
--     propagates. _OnCommitCastSucceeded spawns a polling loop instead of
--     checking synchronously. Deadline extended to 25s.
--   * LM:_OnActiveCombatConfigChanged kept as defensive secondary for cross-spec
--     and future paths; same GetLastSelectedSavedConfigID fallback check.
--
-- Owns the loadout-switch popup framework, silence tables, async switch state
-- machine, ImportLoadout flow, and slash-command handlers. Parallels existing
-- Engine/MacroManager.lua and Engine/KeybindManager.lua. Switch primitive is
-- C_ClassTalents.SwitchToLoadoutByIndex; no PlayerSpellsFrame load required;
-- no UI dependency.
--
-- Phase 1.5b ships LM:Switch (9-step flow), the spec-keyed index lookup cache,
-- the _pendingSwitch state machine, and four async outcome handlers (success,
-- failed, timeout, partial). Popup, silence, and ImportLoadout surfaces remain
-- unwired pending later phases.

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

GRIPEMS.LoadoutManager = {
    _pendingSwitch = nil, -- per Section 6.3 state machine; nil = no switch in flight
    _silenceSession = {}, -- ctxKey -> true (session-scoped silences)
    _pendingImportListener = nil, -- per Section 6.4 ImportLoadout flow (future enhancement)
    _indexByConfigID = {}, -- per Section 6.2: [specID] = { [configID] = 1-based index }
    _indexCacheValid = {}, -- per Section 6.2: [specID] = true if cache fresh
}
local LM = GRIPEMS.LoadoutManager

--- Begin a switch to the target saved-loadout configID via
--- C_ClassTalents.SwitchToLoadoutByIndex(index). Async; outcome arrives via
--- _OnCommitCastSucceeded (primary success signal -- USS spell 384255),
--- _OnActiveCombatConfigChanged (defensive secondary for cross-spec / future
--- paths), _OnConfigCommitFailed (failed), or the 25s deadline timer
--- (_OnSwitchDeadline -> _CompleteSwitchTimeout).
--- See Section 6.1.2 of Research/TalentBuild_Section6_v3_2_Draft_2026-05-13.md.
--- @param targetConfigID number Target saved-loadout configID.
--- @param options table? Future-enhancement options table (Phase 1.5b ignores).
--- @return string status_code One of: switch_in_progress / already_active /
---     cannot_edit_talents / cross_spec_refused / not_in_loadout_list /
---     switch_initiated / error.
--- @return string? detail When status_code is "error", the failure detail.
function LM:Switch(targetConfigID, options)
    -- 1a. In-flight reject: do not queue concurrent switches.
    if self._pendingSwitch then
        return "switch_in_progress"
    end

    -- 1b. Resolve current spec.
    local currentSpecID = nil
    if PlayerUtil and PlayerUtil.GetCurrentSpecID then
        currentSpecID = PlayerUtil.GetCurrentSpecID()
    end
    if not currentSpecID then
        local idx = GetSpecialization and GetSpecialization()
        if idx and GetSpecializationInfo then
            currentSpecID = GetSpecializationInfo(idx)
        end
    end
    if not currentSpecID then
        return "error", "no_current_spec"
    end

    -- 1c. Already-active short-circuit. GetActiveConfigID returns the player's
    -- persistent scratch slot (stable across switches per 2026-05-13 PM empirical
    -- AVAV). The user-meaningful "current loadout" is the saved-loadout last-
    -- selected pointer, which IS what changes on switch.
    local lastSelectedConfigID = C_ClassTalents.GetLastSelectedSavedConfigID
        and C_ClassTalents.GetLastSelectedSavedConfigID(currentSpecID)
    if targetConfigID == lastSelectedConfigID then
        return "already_active"
    end

    -- 1d. Pre-flight CanEditTalents gate. Catches combat-locked, instance-
    -- restricted, loading-screen, and certain mount-state cases that would
    -- otherwise surface as a 25s deadline timeout. Blizzard's own Talent UI
    -- gates Apply on the same check (Blizzard_PlayerSpells/ClassTalents/
    -- Blizzard_ClassTalentsFrame.lua).
    if not (C_ClassTalents.CanEditTalents and C_ClassTalents.CanEditTalents()) then
        return "cannot_edit_talents"
    end

    -- 1e. Cross-spec gate: refuse in Phase 1.5b. Compare tree IDs.
    local configInfo = C_Traits and C_Traits.GetConfigInfo and C_Traits.GetConfigInfo(targetConfigID)
    local targetTreeID = configInfo and configInfo.treeIDs and configInfo.treeIDs[1] or nil
    local currentTreeID = C_ClassTalents.GetTraitTreeForSpec and C_ClassTalents.GetTraitTreeForSpec(currentSpecID)
        or nil
    if targetTreeID and currentTreeID and targetTreeID ~= currentTreeID then
        return "cross_spec_refused"
    end

    -- 2. Index lookup (Section 6.2).
    local index = self:_GetIndexFor(targetConfigID, currentSpecID)
    if not index then
        return "not_in_loadout_list"
    end

    -- 3. Set pending state + schedule deadline timer BEFORE the call so we cannot leak.
    local pending = {
        configID = targetConfigID,
        specID = currentSpecID,
        indexLookup = index,
        startedAt = GetTime(),
        deadline = GetTime() + 25.0,
        crossSpec = false, -- Phase 1.5b refuses cross-spec; this stays false
    }
    if C_Timer and C_Timer.NewTimer then
        pending.deadlineTimer = C_Timer.NewTimer(25.0, function()
            LM:_OnSwitchDeadline()
        end)
    end
    self._pendingSwitch = pending

    -- 4. Call the wrapper.
    if not (ClassTalentHelper and ClassTalentHelper.SwitchToLoadoutByIndex) then
        if pending.deadlineTimer then
            pending.deadlineTimer:Cancel()
        end
        self._pendingSwitch = nil
        return "error", "ClassTalentHelper_unavailable"
    end
    GRIPEMS:Debug("LoadoutManager:Switch -- target=%d specID=%d index=%d", targetConfigID, currentSpecID, index)
    ClassTalentHelper.SwitchToLoadoutByIndex(index)

    -- 5. Outcome arrives async via event handlers. Return immediately.
    return "switch_initiated"
end

--- @return number? 1-based index into C_ClassTalents.GetConfigIDsBySpecID(specID),
---     or nil if the configID is not in the saved-loadout list for that spec.
function LM:_GetIndexFor(configID, specID)
    if not self._indexCacheValid[specID] then
        self:_RebuildIndexCache(specID)
    end
    local specCache = self._indexByConfigID[specID]
    return specCache and specCache[configID] or nil
end

--- Rebuild the cache entry for one spec. Idempotent.
function LM:_RebuildIndexCache(specID)
    local ids = (C_ClassTalents.GetConfigIDsBySpecID and C_ClassTalents.GetConfigIDsBySpecID(specID)) or {}
    self._indexByConfigID[specID] = {}
    for i, cid in ipairs(ids) do
        self._indexByConfigID[specID][cid] = i
    end
    self._indexCacheValid[specID] = true
    GRIPEMS:Debug("LoadoutManager:_RebuildIndexCache -- specID=%d count=%d", specID, #ids)
end

--- Mark cache entries stale. nil specID invalidates all specs (cold-start path).
function LM:_InvalidateIndexCache(specID)
    if specID then
        self._indexCacheValid[specID] = false
    else
        for k in pairs(self._indexCacheValid) do
            self._indexCacheValid[k] = false
        end
    end
end

--- Success path: switch verified via the post-cast last-selected pointer match.
--- Cancel the deadline timer, clear pending state, update the last-selected pointer
--- so the Blizzard Talent UI opens to this loadout next time, and dispatch
--- OnLoadoutChanged so KeybindManager (and any future listeners) can react.
function LM:_CompleteSwitchSuccess(newConfigID)
    local pending = self._pendingSwitch
    if pending and pending.deadlineTimer then
        pending.deadlineTimer:Cancel()
    end
    self._pendingSwitch = nil
    if pending and pending.specID and newConfigID and C_ClassTalents.UpdateLastSelectedSavedConfigID then
        C_ClassTalents.UpdateLastSelectedSavedConfigID(pending.specID, newConfigID)
    end
    GRIPEMS:Debug("LoadoutManager:_CompleteSwitchSuccess -- newConfigID=%s", tostring(newConfigID))
    self:OnLoadoutChanged(newConfigID, nil, nil, nil)
end

--- Failed path: CONFIG_COMMIT_FAILED arrived with configID == pending.configID.
--- Cancel timer, clear pending, surface failure to chat.
function LM:_CompleteSwitchFailed(configID)
    local pending = self._pendingSwitch
    if pending and pending.deadlineTimer then
        pending.deadlineTimer:Cancel()
    end
    self._pendingSwitch = nil
    GRIPEMS:Print(string.format(L["GEMS_LM_FAIL_COMMIT_REJECTED"], configID or 0))
    GRIPEMS:Debug("LoadoutManager:_CompleteSwitchFailed -- configID=%s", tostring(configID))
end

--- Timeout path: 25s elapsed without the success signal (UNIT_SPELLCAST_SUCCEEDED
--- spell 384255) confirming the switch. Clear pending, surface to chat.
--- (Called from _OnSwitchDeadline; no timer to cancel.)
function LM:_CompleteSwitchTimeout()
    local pending = self._pendingSwitch
    local targetID = (pending and pending.configID) or 0
    self._pendingSwitch = nil
    GRIPEMS:Print(string.format(L["GEMS_LM_FAIL_TIMEOUT"], targetID))
    GRIPEMS:Debug("LoadoutManager:_CompleteSwitchTimeout -- targetID=%s", tostring(targetID))
end

--- Partial path: the success signal arrived but the post-cast last-selected
--- pointer ended on a different loadout than pending.configID (player took
--- manual action or an external addon interfered).
function LM:_CompleteSwitchPartial(newConfigID)
    local pending = self._pendingSwitch
    local targetID = (pending and pending.configID) or 0
    if pending and pending.deadlineTimer then
        pending.deadlineTimer:Cancel()
    end
    self._pendingSwitch = nil
    GRIPEMS:Print(string.format(L["GEMS_LM_FAIL_PARTIAL"], targetID, newConfigID or 0))
    GRIPEMS:Debug(
        "LoadoutManager:_CompleteSwitchPartial -- targetID=%s newID=%s",
        tostring(targetID),
        tostring(newConfigID)
    )
end

--- Private: invoked by the C_Timer scheduled in LM:Switch. Race-safe: bail if
--- pending was already cleared by a completing event.
function LM:_OnSwitchDeadline()
    if not self._pendingSwitch then
        return
    end
    self:_CompleteSwitchTimeout()
end

--- Import an external loadout string and switch to it. Phase 1.5a stub.
--- @param importString string The encoded loadout import string.
--- @param name string Display name for the imported loadout.
--- @param options table? Import options table.
--- @return string Always "stubbed_phase_1_5a" in Phase 1.5a.
function LM:ImportAndSwitch(importString, name, options)
    GRIPEMS:Debug("LoadoutManager:ImportAndSwitch stub -- name=%s (Phase 1.5a)", tostring(name))
    return "stubbed_phase_1_5a"
end

--- Show a recommendation popup for a (context, configID) pair. Phase 1.5a stub.
function LM:ShowRecommendation(ctxKey, configID, opts)
    GRIPEMS:Debug(
        "LoadoutManager:ShowRecommendation stub -- ctxKey=%s configID=%s (Phase 1.5a)",
        tostring(ctxKey),
        tostring(configID)
    )
end

--- Silence recommendations for a context. Session scope persists for the play session only.
--- @param ctxKey string Context key to silence.
--- @param scope string "session" or "permanent".
function LM:SilenceContext(ctxKey, scope)
    if scope == "session" then
        self._silenceSession[ctxKey] = true
    end
    GRIPEMS:Debug(
        "LoadoutManager:SilenceContext stub -- ctxKey=%s scope=%s (Phase 1.5a)",
        tostring(ctxKey),
        tostring(scope)
    )
end

--- Clear the session silence on a context.
function LM:UnsilenceContext(ctxKey)
    self._silenceSession[ctxKey] = nil
    GRIPEMS:Debug("LoadoutManager:UnsilenceContext stub -- ctxKey=%s (Phase 1.5a)", tostring(ctxKey))
end

--- @return boolean True if the context is currently silenced for this session.
function LM:IsSilenced(ctxKey)
    return self._silenceSession[ctxKey] == true
end

--- Dispatch entry: invoked when the active loadout changes (EMS-initiated
--- switch, Blizzard-UI Apply, or spec change). Triggers a debounced
--- KeybindManager reload so per-loadout overlays apply immediately.
function LM:OnLoadoutChanged(newID, newName, oldID, oldName)
    GRIPEMS:Debug("LoadoutManager:OnLoadoutChanged -- newID=%s oldID=%s", tostring(newID), tostring(oldID))
    if GRIPEMS.KeybindManager and GRIPEMS.KeybindManager.ScheduleLoadKeybinds then
        GRIPEMS.KeybindManager:ScheduleLoadKeybinds()
    end
end

--- Called when the active context changes. Phase 1.5a stub.
function LM:OnContextChanged(newCtx, oldCtx)
    GRIPEMS:Debug(
        "LoadoutManager:OnContextChanged stub -- newCtx=%s oldCtx=%s (Phase 1.5a)",
        tostring(newCtx),
        tostring(oldCtx)
    )
end

--- @return table? The current pending-switch record, or nil if no switch is in flight.
function LM:GetPendingSwitch()
    return self._pendingSwitch
end

--- Cancel a pending switch and clear state. Used by /gems force-cancel and tests.
function LM:CancelPendingSwitch()
    if self._pendingSwitch then
        if self._pendingSwitch.deadlineTimer and type(self._pendingSwitch.deadlineTimer.Cancel) == "function" then
            self._pendingSwitch.deadlineTimer:Cancel()
        end
        self._pendingSwitch = nil
        GRIPEMS:Debug("LoadoutManager:CancelPendingSwitch -- cleared pending state")
    end
end

-- Event routing handlers (called from Engine.lua's dispatcher per Section 6.0.2).
-- Phase 1.5b-polish-1: UNIT_SPELLCAST_SUCCEEDED (spell 384255) is the primary
-- success driver via _OnCommitCastSucceeded; _OnConfigCommitFailed handles CCF
-- failures; _OnActiveCombatConfigChanged is defensive secondary;
-- _OnTraitConfigCreated/_Deleted invalidate the spec-keyed index cache.

function LM:_OnActiveCombatConfigChanged(newConfigID)
    GRIPEMS:Debug("LoadoutManager:_OnActiveCombatConfigChanged -- newConfigID=%s", tostring(newConfigID))
    if not self._pendingSwitch then
        return
    end
    -- Defensive secondary signal. ACCC empirically does NOT fire for
    -- ClassTalentHelper.SwitchToLoadoutByIndex current-spec switches (2026-05-13
    -- PM AVAV). Kept for cross-spec / future paths. Primary success signal is
    -- LM:_OnCommitCastSucceeded (spell 384255). Same GetLastSelectedSavedConfigID
    -- fallback check.
    local pending = self._pendingSwitch
    local lastSelectedConfigID = C_ClassTalents.GetLastSelectedSavedConfigID
        and C_ClassTalents.GetLastSelectedSavedConfigID(pending.specID)
    if newConfigID == pending.configID or lastSelectedConfigID == pending.configID then
        self:_CompleteSwitchSuccess(pending.configID)
    else
        self:_CompleteSwitchPartial(newConfigID)
    end
end

function LM:_OnConfigCommitFailed(configID)
    GRIPEMS:Debug("LoadoutManager:_OnConfigCommitFailed -- configID=%s", tostring(configID))
    if not self._pendingSwitch then
        return
    end
    if configID == self._pendingSwitch.configID then
        self:_CompleteSwitchFailed(configID)
    end
end

function LM:_OnCommitCastSucceeded(spellID)
    GRIPEMS:Debug("LoadoutManager:_OnCommitCastSucceeded -- spellID=%s", tostring(spellID))
    if self._pendingSwitch then
        -- Primary EMS-initiated success path. UNIT_SPELLCAST_SUCCEEDED for spell
        -- 384255 ("Changing Talents") fires when the server cast completes. The
        -- saved-loadout last-selected pointer updates server-side 5-18s AFTER
        -- this event with no signaling event (empirical 2026-05-13 PM).
        -- Spawn a polling loop instead of checking synchronously.
        self:_StartLastSelPollLoop()
        return
    end
    -- Blizzard-UI Apply path: no pending switch, but the active loadout
    -- pointer may still have changed. Spawn the secondary poll loop to detect
    -- and dispatch OnLoadoutChanged. See Section 7.2 of the design doc.
    self:_StartBlizzardUIPollLoop()
end

--- Private: poll C_ClassTalents.GetLastSelectedSavedConfigID until it matches
--- the pending target or the deadline expires. Called from _OnCommitCastSucceeded
--- (post-USS) since lastSel update has 5-18s propagation lag with no event signal.
function LM:_StartLastSelPollLoop()
    local pending = self._pendingSwitch
    if not pending then
        return
    end
    local function poll()
        local current = LM._pendingSwitch
        if not current or current ~= pending then
            return -- already completed or replaced by another path
        end
        local lastSelectedConfigID = C_ClassTalents.GetLastSelectedSavedConfigID
            and C_ClassTalents.GetLastSelectedSavedConfigID(current.specID)
        if lastSelectedConfigID == current.configID then
            LM:_CompleteSwitchSuccess(current.configID)
        elseif GetTime() < current.deadline then
            if C_Timer and C_Timer.After then
                C_Timer.After(1.0, poll)
            end
        else
            LM:_CompleteSwitchPartial(lastSelectedConfigID)
        end
    end
    if C_Timer and C_Timer.After then
        C_Timer.After(0.5, poll)
    end
end

--- Private: poll C_ClassTalents.GetLastSelectedSavedConfigID after a Blizzard-UI
--- Apply commit-cast to detect a current-spec loadout switch (which fires no
--- event on its own). Compares the post-USS pointer against the BEFORE-poll
--- snapshot; on a change, dispatches OnLoadoutChanged. Mirrors _StartLastSelPollLoop
--- but has no _pendingSwitch dependency. 1Hz tick, 25-tick deadline.
--- TODO: replace with event when Blizzard exposes one for current-spec loadout switches
function LM:_StartBlizzardUIPollLoop()
    -- Capture the current spec via the same chain used in LM:Switch.
    local currentSpecID = nil
    if PlayerUtil and PlayerUtil.GetCurrentSpecID then
        currentSpecID = PlayerUtil.GetCurrentSpecID()
    end
    if not currentSpecID then
        local idx = GetSpecialization and GetSpecialization()
        if idx and GetSpecializationInfo then
            currentSpecID = GetSpecializationInfo(idx)
        end
    end
    if not currentSpecID then
        return
    end
    local beforeID = C_ClassTalents.GetLastSelectedSavedConfigID
        and C_ClassTalents.GetLastSelectedSavedConfigID(currentSpecID)
    local deadline = GetTime() + 25.0
    local function poll()
        if LM._pendingSwitch then
            -- A new EMS-initiated switch took priority; the primary path handles it.
            return
        end
        local current = C_ClassTalents.GetLastSelectedSavedConfigID
            and C_ClassTalents.GetLastSelectedSavedConfigID(currentSpecID)
        if current and current ~= beforeID then
            LM:OnLoadoutChanged(current, nil, beforeID, nil)
            return
        end
        if GetTime() < deadline then
            if C_Timer and C_Timer.After then
                C_Timer.After(1.0, poll)
            end
            return
        end
        -- Deadline reached: silent exit (the Blizzard-UI cast may have been a no-op re-apply).
    end
    if C_Timer and C_Timer.After then
        C_Timer.After(1.0, poll)
    end
end

function LM:_OnTraitConfigCreated(configInfo)
    local id = configInfo and configInfo.ID or nil
    GRIPEMS:Debug("LoadoutManager:_OnTraitConfigCreated -- configID=%s", tostring(id))
    -- New loadout in saved list: invalidate all spec caches (cheap rebuild on next use).
    self:_InvalidateIndexCache(nil)
end

function LM:_OnTraitConfigDeleted(configID)
    GRIPEMS:Debug("LoadoutManager:_OnTraitConfigDeleted -- configID=%s", tostring(configID))
    -- Removed loadout: invalidate all spec caches.
    self:_InvalidateIndexCache(nil)
    -- Prune any per-loadout keybind overlay entries for the deleted configID.
    -- isDeletion=true: this is a genuine deletion, so salvage the wiped overlay
    -- into the keybindsLKG snapshot for /gems binds restore.
    if GRIPEMS.KeybindManager and GRIPEMS.KeybindManager.PruneKeybindsForLoadout then
        GRIPEMS.KeybindManager:PruneKeybindsForLoadout(configID, true)
    end
end
