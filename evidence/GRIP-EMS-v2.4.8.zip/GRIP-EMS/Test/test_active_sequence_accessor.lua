-- GRIP-EMS: Headless test for API:GetActiveSequence (most-recently-driven sequence name)
--
-- Created:    2026-08-09
-- Updated:    2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.
--
-- Covers the REAL impl.GetActiveSequence in Core/PublicAPI.lua, reached through the REAL
-- frozen GRIPEMS.API proxy rather than through impl -- so the freeze block is on the path
-- too. The accessor is a read-only window onto Engine._lastClickedSequence, a field six
-- internal consumers already read (Sound, Settings, ExecutionTracer, TempoAdvisor,
-- TempoOverlay, SettingsPanel). This file adds a READER and pins the semantics; it must
-- never drive a writer.
--
-- The row these cases exist to defend is "most recently driven, never currently running".
-- A4 is the catcher: it deactivates the sequence through the REAL
-- Engine:DeactivateSequence and asserts the accessor STILL returns the name. An
-- implementation that gates the return on Engine.sequences[name] still existing -- the
-- tempting "currently running" misreading -- passes A1, A2 and A3 and fails only A4.
--
-- Loads the REAL modules (Data/Defaults.lua, Engine/MacroSyntax.lua,
-- Engine/ActionCompiler.lua, Engine/StepFunctions.lua, Engine/Engine.lua,
-- Core/PublicAPI.lua) via loadfile + setfenv into a no-op stub sandbox, mirroring the
-- bootstrap in test_authored_steps_domain.lua. Core/PublicAPI.lua loads last because its
-- accessor reads GRIPEMS.Engine, which Engine.lua populates. Nothing here hand-rolls a
-- fake accessor: a hand-copied fake proves only that the copy agrees with itself.
--
-- Run from the EMS root:  lua Test/test_active_sequence_accessor.lua
-- Exit code 0 = all passed, 1 = at least one failure.
--
-- Cases:
--   A1  _lastClickedSequence unset                -> nil
--   A2  _lastClickedSequence set to a name        -> that exact name
--   A3  the Engine table is absent entirely       -> nil, and no error raised
--   A4  set, then really deactivated              -> STILL the name (SABOTAGE CATCHER)

local ADDON_NAME = "GRIP-EMS"

-- ---------------------------------------------------------------------------
-- Minimal assertion + runner harness.
-- ---------------------------------------------------------------------------

local tests = {}

local function test(name, fn)
    tests[#tests + 1] = { name = name, fn = fn }
end

local function assertEqual(expected, actual, label)
    if expected ~= actual then
        error((label or "value") .. ": expected " .. tostring(expected) .. ", got " .. tostring(actual), 2)
    end
end

local function assertTrue(cond, label)
    if not cond then
        error((label or "condition") .. " failed", 2)
    end
end

-- ---------------------------------------------------------------------------
-- Sandbox: a self-referential no-op stub backs every unknown global so the real
-- modules load without a WoW client. Real stdlib falls through to _G.
-- ---------------------------------------------------------------------------

local stub = {}
setmetatable(stub, {
    __index = function()
        return stub
    end,
    __call = function()
        return stub
    end,
})

local env = setmetatable({}, {
    __index = function(_, k)
        local v = rawget(_G, k)
        if v ~= nil then
            return v
        end
        return stub
    end,
})
env._G = env

-- AceLocale stand-in: every key echoes back so any L["KEY"] format is inert.
local LOCALE = setmetatable({}, {
    __index = function(_, k)
        return k
    end,
})
env.LibStub = function()
    return {
        GetLocale = function()
            return LOCALE
        end,
    }
end
env.strlower = string.lower
env.GetTime = function()
    return 0
end

-- ---------------------------------------------------------------------------
-- GRIPEMS control table. Defaults is intentionally omitted: the REAL
-- Data/Defaults.lua populates GRIPEMS.Defaults when loaded first. OOCQueue.Add runs
-- its callback synchronously so Engine:DeactivateSequence completes inline (A4).
-- KeybindManager.UnbindSequence and MacroManager.DeleteStub exist because the real
-- deactivate path calls both; they are no-ops because A4 asserts on the accessor,
-- not on teardown side effects.
-- ---------------------------------------------------------------------------

local GRIPEMS = {
    version = "headless",
    Print = function() end,
    Debug = function() end,
    OOCQueue = {
        IsRestricted = function()
            return true
        end,
        Add = function(_, fn)
            fn()
        end,
    },
    MacroManager = {
        UpdateIcon = function() end,
        UpdateStubBody = function() end,
        DeleteStub = function() end,
    },
    KeybindManager = {
        UnbindSequence = function() end,
    },
    Popup = {
        Define = function() end,
        Show = function() end,
    },
    Fire = function() end,
}

-- ---------------------------------------------------------------------------
-- Load the REAL modules into the sandbox, in dependency order. PublicAPI comes
-- last: its accessor reads GRIPEMS.Engine, which Engine.lua installs.
-- ---------------------------------------------------------------------------

local function loadModule(candidates)
    for _, path in ipairs(candidates) do
        -- loadfile is dev-harness file I/O, intentionally outside the addon WoW std.
        -- selene: allow(undefined_variable)
        local chunk = loadfile(path)
        if chunk then
            setfenv(chunk, env)
            chunk(ADDON_NAME, GRIPEMS)
            return true
        end
    end
    return false
end

assert(
    loadModule({
        "Data/Defaults.lua",
        "../Data/Defaults.lua",
        "GRIP/EMS/Data/Defaults.lua",
    }),
    "could not locate Data/Defaults.lua (run from the EMS root)"
)
assert(
    loadModule({
        "Engine/MacroSyntax.lua",
        "../Engine/MacroSyntax.lua",
        "GRIP/EMS/Engine/MacroSyntax.lua",
    }),
    "could not locate Engine/MacroSyntax.lua (run from the EMS root)"
)
assert(
    loadModule({
        "Engine/ActionCompiler.lua",
        "../Engine/ActionCompiler.lua",
        "GRIP/EMS/Engine/ActionCompiler.lua",
    }),
    "could not locate Engine/ActionCompiler.lua (run from the EMS root)"
)
assert(
    loadModule({
        "Engine/StepFunctions.lua",
        "../Engine/StepFunctions.lua",
        "GRIP/EMS/Engine/StepFunctions.lua",
    }),
    "could not locate Engine/StepFunctions.lua (run from the EMS root)"
)
assert(
    loadModule({
        "Engine/Engine.lua",
        "../Engine/Engine.lua",
        "GRIP/EMS/Engine/Engine.lua",
    }),
    "could not locate Engine/Engine.lua (run from the EMS root)"
)
assert(
    loadModule({
        "Core/PublicAPI.lua",
        "../Core/PublicAPI.lua",
        "GRIP/EMS/Core/PublicAPI.lua",
    }),
    "could not locate Core/PublicAPI.lua (run from the EMS root)"
)

local Engine = GRIPEMS.Engine
local API = GRIPEMS.API
assert(Engine ~= nil, "Engine loaded")
assert(API ~= nil, "GRIPEMS.API loaded")
assert(type(API.GetActiveSequence) == "function", "API:GetActiveSequence defined")
assert(type(Engine.DeactivateSequence) == "function", "Engine:DeactivateSequence defined")
Engine.sequences = {}

local SEQ_NAME = "Alpha"

-- Reset both halves of the fixture between cases: the tracked field and the
-- registered-sequence table the deactivate path consumes.
local function resetEngineState()
    GRIPEMS.Engine = Engine
    Engine.sequences = {}
    Engine._lastClickedSequence = nil
end

-- ---------------------------------------------------------------------------
-- Cases.
-- ---------------------------------------------------------------------------

test("A1: _lastClickedSequence unset returns nil", function()
    -- Nothing has been driven yet. Anything other than nil here means the accessor
    -- invented a value (a hardcoded name, or a fallback to some other field).
    resetEngineState()
    assertEqual(nil, API:GetActiveSequence(), "unset field returns nil")
end)

test("A2: _lastClickedSequence set returns that exact name", function()
    -- The accessor returns the tracked value UNCHANGED -- no trimming, no lookup,
    -- no substitution of a display name.
    resetEngineState()
    Engine._lastClickedSequence = SEQ_NAME
    assertEqual(SEQ_NAME, API:GetActiveSequence(), "set field returns the name verbatim")

    -- A second read is stable and non-consuming: this is a window, not a queue.
    assertEqual(SEQ_NAME, API:GetActiveSequence(), "a second read returns the same name")
    assertEqual(SEQ_NAME, Engine._lastClickedSequence, "reading the accessor does not clear the field")
end)

test("A3: an absent Engine table returns nil without raising", function()
    -- Plugins can call the API before Engine has been installed. The accessor
    -- guards the read the way GetSequenceMacroIndex guards MacroManager; dropping
    -- that guard turns this into "attempt to index a nil value".
    resetEngineState()
    GRIPEMS.Engine = nil

    local ok, result = pcall(function()
        return API:GetActiveSequence()
    end)
    assertTrue(ok, "calling the accessor with no Engine table does not raise")
    assertEqual(nil, result, "no Engine table returns nil")

    resetEngineState()
    assertTrue(GRIPEMS.Engine ~= nil, "Engine restored for later cases")
end)

test("A4: the name survives a real deactivate (SABOTAGE CATCHER)", function()
    -- The documented contract is "most recently driven", NOT "currently running".
    -- Register the sequence, mark it driven, then tear it down through the REAL
    -- Engine:DeactivateSequence -- which removes Engine.sequences[name] and never
    -- touches _lastClickedSequence. The accessor must still report the name.
    --
    -- An accessor written as the "currently running" misreading, i.e. gated on
    -- Engine.sequences[Engine._lastClickedSequence] still being present, satisfies
    -- A1, A2 and A3 and fails only this case.
    resetEngineState()
    Engine.sequences[SEQ_NAME] = {
        data = { defaultVersion = 1, versions = { { steps = { "/cast Alpha" } } } },
    }
    Engine._lastClickedSequence = SEQ_NAME

    -- Control: the sequence really is registered before the teardown.
    assertTrue(Engine.sequences[SEQ_NAME] ~= nil, "control: sequence registered before deactivate")
    assertEqual(SEQ_NAME, API:GetActiveSequence(), "control: accessor reports the name while active")

    -- keepStub = true so the assertion is about the accessor, not stub teardown.
    Engine:DeactivateSequence(SEQ_NAME, true)

    -- Control: the teardown really happened, so the case is not vacuous.
    assertEqual(nil, Engine.sequences[SEQ_NAME], "control: deactivate removed the registered sequence")
    assertEqual(SEQ_NAME, API:GetActiveSequence(), "accessor still reports the most recently driven name")
end)

-- ---------------------------------------------------------------------------
-- Run.
-- ---------------------------------------------------------------------------

local passed = 0
local failed = 0
for _, t in ipairs(tests) do
    local ok, err = pcall(t.fn)
    if ok then
        passed = passed + 1
        print("PASS  " .. t.name)
    else
        failed = failed + 1
        print("FAIL  " .. t.name .. " -- " .. tostring(err))
    end
end
print(string.format("RESULT %d passed, %d failed", passed, failed))
os.exit(failed > 0 and 1 or 0)
