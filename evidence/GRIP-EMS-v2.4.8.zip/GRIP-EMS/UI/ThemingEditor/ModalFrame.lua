-- GRIP-EMS: Per-Element Theming editor -- standalone modal frame (Phase C)
--
-- Created:    2026-04-22
-- Updated:    2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.
--
-- Registers a second AceConfig options table ("GRIP-EMS-Theme") containing
-- only the theming editor args, then opens it via AceConfigDialog:Open so
-- AceGUI creates the draggable Frame widget for us. Re-uses
-- SettingsPanel.RestyleAceFrameExternal for identical chrome to Paradigm B
-- (settings-tree editor).
--
-- Combat lockdown: PLAYER_REGEN_DISABLED closes the modal. It does NOT
-- auto-reopen on PLAYER_REGEN_ENABLED -- the user reopens manually.

local ADDON_NAME, GRIPEMS = ...

GRIPEMS.UI = GRIPEMS.UI or {}
local UI = GRIPEMS.UI
UI.ThemingEditor = UI.ThemingEditor or {}
local TE = UI.ThemingEditor

local AceConfig = LibStub("AceConfig-3.0")
local AceConfigDialog = LibStub("AceConfigDialog-3.0")
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)
local APPNAME_MODAL = "GRIP-EMS-Theme"

---------------------------------------------------------------------------
-- BuildModalRootArgs returns the full args tree for the modal, matching
-- the IIFE body in UI/SettingsPanel.lua (themingEditor section). Reuses
-- TE.BuildPresetArgs / BuildOptionsTree / BuildSlotArgs /
-- BuildImportExportArgs / BuildFooterArgs from the Phase B files.
---------------------------------------------------------------------------
function TE.BuildModalRootArgs()
    local a = {}
    a.desc = {
        type = "description",
        name = L["ACCESS_THEMING_MODAL_DESC"] or "",
        order = 0.5,
        fontSize = "medium",
    }
    if TE.BuildPresetArgs then
        a.presetSection = {
            type = "group",
            inline = true,
            order = 1,
            name = L["ACCESS_THEMING_PRESET_HEADER"] or "Preset",
            args = TE.BuildPresetArgs(),
        }
    end
    if TE.BuildOptionsTree then
        for k, v in pairs(TE.BuildOptionsTree()) do
            a[k] = v
        end
    end
    if TE.BuildContrastSilenceArgs then
        a.contrastSilenceSection = {
            type = "group",
            inline = true,
            order = 15,
            name = function()
                local n = (TE.GetSilencedCount and TE.GetSilencedCount()) or 0
                if n > 0 then
                    return (L["ACCESS_THEMING_CONTRAST_SILENCE_HEADER_BADGE"] or "Silenced contrasts (%d)"):format(n)
                end
                return L["ACCESS_THEMING_CONTRAST_SILENCE_HEADER"] or "Silenced contrasts"
            end,
            args = TE.BuildContrastSilenceArgs(),
        }
    end
    if TE.BuildSlotArgs then
        a.slotSection = {
            type = "group",
            inline = true,
            order = 20,
            name = L["ACCESS_THEMING_SLOTS_HEADER"] or "Saved Themes",
            args = TE.BuildSlotArgs(),
        }
    end
    if TE.BuildImportExportArgs then
        a.importExportSection = {
            type = "group",
            inline = true,
            order = 30,
            name = L["ACCESS_THEMING_IMPORTEXPORT_HEADER"] or "Import / Export",
            args = TE.BuildImportExportArgs(),
        }
    end
    if TE.BuildFooterArgs then
        a.footerSection = {
            type = "group",
            inline = true,
            order = 40,
            name = L["ACCESS_THEMING_FOOTER_HEADER"] or "",
            args = TE.BuildFooterArgs(),
        }
    end
    return a
end

---------------------------------------------------------------------------
-- RegisterModalApp registers the GRIP-EMS-Theme AceConfig app once per
-- session. Guarded by UI._themeModalRegistered so repeat /gems theme
-- invocations do not re-register (AceConfig tolerates re-register but
-- every call rebuilds a new options snapshot).
---------------------------------------------------------------------------
function TE.RegisterModalApp()
    if UI._themeModalRegistered then
        return
    end
    AceConfig:RegisterOptionsTable(APPNAME_MODAL, function()
        return {
            type = "group",
            name = L["ACCESS_THEMING_MODAL_TITLE"] or "Per-Element Theming",
            args = TE.BuildModalRootArgs(),
        }
    end)
    AceConfigDialog:SetDefaultSize(APPNAME_MODAL, 900, 650)
    UI._themeModalRegistered = true
end

---------------------------------------------------------------------------
-- OpenModal shows the standalone editor. Combat-locked: taint avoidance
-- matters here because the editor touches many secure-adjacent frames via
-- Theme.ApplyElement fan-out.
--
-- scrollToClass (optional): element class key passed by Inspect Mode so
-- the editor opens scrolled to that class's options group. Wrapped in
-- pcall because the tree path may not always resolve; a mismatch falls
-- back to the default landing position.
---------------------------------------------------------------------------
function TE.OpenModal(scrollToClass)
    if InCombatLockdown() then
        GRIPEMS:Print(
            "|cFFFFAA33"
                .. (L["ACCESS_THEMING_MODAL_COMBAT_BLOCKED"] or "Theme editor is hidden during combat.")
                .. "|r"
        )
        return
    end
    TE.RegisterModalApp()
    AceConfigDialog:Open(APPNAME_MODAL)

    local widget = AceConfigDialog.OpenFrames and AceConfigDialog.OpenFrames[APPNAME_MODAL]
    if widget and GRIPEMS.SettingsPanel and GRIPEMS.SettingsPanel.RestyleAceFrameExternal then
        GRIPEMS.SettingsPanel:RestyleAceFrameExternal(widget)
    end

    if widget and widget.frame and widget.frame.GetName and widget.frame:GetName() then
        local fname = widget.frame:GetName()
        local already = false
        for i = 1, #UISpecialFrames do
            if UISpecialFrames[i] == fname then
                already = true
                break
            end
        end
        if not already then
            tinsert(UISpecialFrames, fname)
        end
    end

    -- G8-AUDIT-105: route the standalone modal canvas through the AceConfig
    -- focus shim so a keyboard user gets TAB cycle + SPACE/ENTER activation
    -- (not just ESC + mouse). The AceConfigDialog Frame is pooled -- released to
    -- the shared AceGUI Frame pool on close and possibly a different widget on
    -- the next open -- and is already shown by AceConfigDialog before this runs.
    -- EnablePooled handles both: it (re)binds to the current frame, hooks it
    -- once, and activates immediately, so first open, re-open, and
    -- reopen-after-pool-churn all land keyboard focus on the live frame.
    local Shim = GRIPEMS.UI and GRIPEMS.UI.AceConfigFocusShim
    if widget and widget.frame and Shim and Shim.EnablePooled then
        Shim:EnablePooled(APPNAME_MODAL, widget.frame)
    end

    if scrollToClass and type(scrollToClass) == "string" then
        local grp = TE._classGroup and TE._classGroup(scrollToClass) or nil
        local leaf = TE._leafKey and TE._leafKey(scrollToClass) or nil
        if grp and leaf then
            pcall(function()
                AceConfigDialog:SelectGroup(APPNAME_MODAL, grp, leaf)
            end)
        end
    end
end

---------------------------------------------------------------------------
-- CloseModal closes the standalone editor. Safe to call when not open.
---------------------------------------------------------------------------
function TE.CloseModal()
    if AceConfigDialog and AceConfigDialog.Close then
        -- G8-AUDIT-105: AceConfigDialog:Close hides the pooled frame on the
        -- next refresh tick (RefreshOnUpdate -> widget:Hide), which fires the
        -- frame-aware OnHide hook installed by Shim:EnablePooled. That hook pops
        -- the "AceConfigShim:GRIP-EMS-Theme" Focus context when this group is
        -- the active key, so no explicit shim pop is needed here.
        AceConfigDialog:Close(APPNAME_MODAL)
    end
end

---------------------------------------------------------------------------
-- Combat handler: close the modal when the player enters combat. Does not
-- re-open on PLAYER_REGEN_ENABLED -- surprise reopens would steal focus
-- from whatever the user shifts to post-combat.
---------------------------------------------------------------------------
function TE.OnEnterCombatHideModal()
    local opened = AceConfigDialog.OpenFrames and AceConfigDialog.OpenFrames[APPNAME_MODAL]
    if opened then
        TE.CloseModal()
        GRIPEMS:Print(
            "|cFFFFAA33"
                .. (L["ACCESS_THEMING_MODAL_COMBAT_BLOCKED"] or "Theme editor is hidden during combat.")
                .. "|r"
        )
    end
end

-- Combat-lockdown event hook. Separate frame (not tied to AceEvent) so the
-- listener survives even if AceConfigDialog is closed or re-registered.
local evf = CreateFrame("Frame", "GRIPEMS_ThemeModalEvents", UIParent)
evf:RegisterEvent("PLAYER_REGEN_DISABLED")
evf:SetScript("OnEvent", function()
    TE.OnEnterCombatHideModal()
end)

-- Public hand-off on the UI namespace so Core.lua slash dispatcher does
-- not need to know about TE internals.
UI.OpenThemeEditor = TE.OpenModal
UI.CloseThemeEditor = TE.CloseModal

-- end of UI/ThemingEditor/ModalFrame.lua
