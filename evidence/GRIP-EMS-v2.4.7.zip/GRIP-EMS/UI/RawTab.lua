-- GRIP-EMS: RawTab
-- Created: 2026-03-19
-- Updated: 2026-08-17
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)

-- GRIP-EMS: Raw Macrotext Editor Tab
-- Read-only/editable view of full sequence data as a Lua table

local ADDON_NAME, GRIPEMS = ...
local UI = GRIPEMS.UI
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

-- Upvalue accessor for Defaults
local function D()
    return GRIPEMS.Defaults
end

GRIPEMS.RawTab = {}
local RT = GRIPEMS.RawTab

-- Runtime state
RT.isEditing = false
RT.container = nil
RT.currentName = nil

---------------------------------------------------------------------------
-- Table serializer (human-readable Lua)
---------------------------------------------------------------------------

--- Check if a table is an array (consecutive integer keys 1..#tbl).
--- @param tbl table
--- @return boolean
local function isArray(tbl)
    local count = 0
    for _ in pairs(tbl) do
        count = count + 1
    end
    if count ~= #tbl then
        return false
    end
    for i = 1, count do
        if tbl[i] == nil then
            return false
        end
    end
    return true
end

--- Keys whose VALUE must never be rendered in the Source tab.
--- The author BattleTag is account-level PII (enables friend requests);
--- it stays in the stored sequence (local-only, already stripped at the
--- export boundary) -- this only hides it from the on-screen display.
--- Matches any key containing "BattleTag" so future *BattleTag fields are
--- covered automatically.
--- @param k any Table key
--- @return boolean true if the value should be shown as a placeholder
local function isRedactedKey(k)
    return type(k) == "string" and k:find("BattleTag", 1, true) ~= nil
end

--- Lua 5.1 reserved words -- these can never be emitted as bare table keys.
local _LUA_RESERVED = {
    ["and"] = true,
    ["break"] = true,
    ["do"] = true,
    ["else"] = true,
    ["elseif"] = true,
    ["end"] = true,
    ["false"] = true,
    ["for"] = true,
    ["function"] = true,
    ["if"] = true,
    ["in"] = true,
    ["local"] = true,
    ["nil"] = true,
    ["not"] = true,
    ["or"] = true,
    ["repeat"] = true,
    ["return"] = true,
    ["then"] = true,
    ["true"] = true,
    ["until"] = true,
    ["while"] = true,
}

--- Format a string key for emission: bare when it is a plain identifier,
--- bracketed-and-quoted otherwise. Reserved words (loop nodes carry a
--- "repeat" field) and non-identifier keys emitted bare can never
--- loadstring back.
--- @param k string Table key
--- @return string
local function serializeKey(k)
    if k:match("^[A-Za-z_][A-Za-z0-9_]*$") and _LUA_RESERVED[k] == nil then
        return k
    end
    return '["' .. k:gsub("\\", "\\\\"):gsub('"', '\\"') .. '"]'
end

--- Serialize a Lua table to human-readable Lua source.
--- Handles strings, numbers, booleans, and nested tables.
--- @param tbl table The table to serialize
--- @param indent string Current indentation (default "")
--- @return string
function RT:SerializeTable(tbl, indent)
    indent = indent or ""
    local nextIndent = indent .. "    "
    local lines = {}

    lines[#lines + 1] = "{"

    if isArray(tbl) then
        -- Array format: no explicit keys
        for i = 1, #tbl do
            local v = tbl[i]
            local vType = type(v)
            if vType == "string" then
                lines[#lines + 1] = nextIndent .. '"' .. v:gsub("\\", "\\\\"):gsub('"', '\\"'):gsub("\n", "\\n") .. '",'
            elseif vType == "number" then
                lines[#lines + 1] = nextIndent .. tostring(v) .. ","
            elseif vType == "boolean" then
                lines[#lines + 1] = nextIndent .. tostring(v) .. ","
            elseif vType == "table" then
                lines[#lines + 1] = nextIndent .. RT:SerializeTable(v, nextIndent) .. ","
            end
        end
    else
        -- Hash table format: bracketed numeric keys first, then sorted string
        -- keys. Sparse numeric keys must round-trip -- stepLabels stores a
        -- label only at each labeled index and is signed content, so dropping
        -- them here silently deleted labels on every raw Apply.
        local numKeys = {}
        local keys = {}
        for k in pairs(tbl) do
            if type(k) == "number" then
                numKeys[#numKeys + 1] = k
            elseif type(k) == "string" then
                keys[#keys + 1] = k
            end
        end
        table.sort(numKeys)
        table.sort(keys)

        for _, k in ipairs(numKeys) do
            local v = tbl[k]
            local vType = type(v)
            local prefix = nextIndent .. "[" .. tostring(k) .. "] = "
            if vType == "string" then
                lines[#lines + 1] = prefix .. '"' .. v:gsub("\\", "\\\\"):gsub('"', '\\"'):gsub("\n", "\\n") .. '",'
            elseif vType == "number" or vType == "boolean" then
                lines[#lines + 1] = prefix .. tostring(v) .. ","
            elseif vType == "table" then
                lines[#lines + 1] = prefix .. RT:SerializeTable(v, nextIndent) .. ","
            end
        end

        for _, k in ipairs(keys) do
            local v = tbl[k]
            local vType = type(v)
            if vType == "string" then
                local sv = isRedactedKey(k) and "<hidden>" or v
                lines[#lines + 1] = nextIndent
                    .. serializeKey(k)
                    .. ' = "'
                    .. sv:gsub("\\", "\\\\"):gsub('"', '\\"'):gsub("\n", "\\n")
                    .. '",'
            elseif vType == "number" then
                lines[#lines + 1] = nextIndent .. serializeKey(k) .. " = " .. tostring(v) .. ","
            elseif vType == "boolean" then
                lines[#lines + 1] = nextIndent .. serializeKey(k) .. " = " .. tostring(v) .. ","
            elseif vType == "table" then
                lines[#lines + 1] = nextIndent .. serializeKey(k) .. " = " .. RT:SerializeTable(v, nextIndent) .. ","
            end
        end
    end

    lines[#lines + 1] = indent .. "}"
    return table.concat(lines, "\n")
end

---------------------------------------------------------------------------
-- Initialization
---------------------------------------------------------------------------

--- Build the Raw tab UI inside the content area.
--- @param contentArea Frame The shared content area from SequenceEditor
function RT:Init(contentArea)
    if not contentArea then
        return
    end
    RT.container = contentArea
    local C = UI.Colors

    -- Main frame (fills content area)
    local mainFrame = CreateFrame("Frame", nil, contentArea, "BackdropTemplate")
    mainFrame:SetAllPoints(contentArea)
    UI:ApplyBackdrop(mainFrame, UI.Backdrops.panelNoBorder, C.bgMain)
    mainFrame:Hide()
    RT.mainFrame = mainFrame
    -- Phase C: expose this tab root as the mountable "source" panel.
    if GRIPEMS.RegisterMountablePanel then
        GRIPEMS:RegisterMountablePanel("source", RT.mainFrame)
    end

    -- Header row (28px)
    local headerHeight = D().RAW_HEADER_HEIGHT

    local titleLabel = mainFrame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(titleLabel, 11)
    titleLabel:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", 8, -6)
    titleLabel:SetText(L["GEMS_RAW_TITLE"])
    titleLabel:SetTextColor(C.textPrimary:GetRGBA())

    -- Mode indicator badge (next to title)
    local modeLabel = mainFrame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(modeLabel, 9)
    modeLabel:SetPoint("LEFT", titleLabel, "RIGHT", 8, 0)
    modeLabel:SetText("(Read-Only)")
    modeLabel:SetTextColor(C.textMuted:GetRGBA())
    RT.modeLabel = modeLabel

    -- Cancel button (right side, before Edit/Apply)
    local cancelBtn = UI:CreateButton(mainFrame, L["GEMS_RAW_CANCEL"], 60, 22)
    cancelBtn:SetPoint("TOPRIGHT", mainFrame, "TOPRIGHT", -8, -3)
    cancelBtn:SetScript("OnClick", function()
        RT:ExitEditMode()
    end)
    cancelBtn:SetScript("OnEnter", function(self)
        UI:ShowTooltip(self, L["GEMS_RAW_CANCEL"], L["GEMS_RAW_CANCEL_DESC"])
    end)
    cancelBtn:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)
    cancelBtn:Hide()
    RT.cancelBtn = cancelBtn

    -- Edit/Apply button (left of Cancel)
    local editBtn = UI:CreateButton(mainFrame, L["GEMS_RAW_EDIT"], 60, 22)
    editBtn:SetPoint("RIGHT", cancelBtn, "LEFT", -4, 0)
    editBtn:SetScript("OnClick", function()
        if RT.isEditing then
            RT:ApplyChanges()
        else
            RT:EnterEditMode()
        end
    end)
    editBtn:SetScript("OnEnter", function(self)
        UI:ShowTooltip(self, L["GEMS_RAW_EDIT"], L["GEMS_RAW_EDIT_DESC"])
    end)
    editBtn:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)
    RT.editBtn = editBtn

    -- Read-only hint (below title)
    local hintLabel = mainFrame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(hintLabel, 9)
    hintLabel:SetPoint("TOPLEFT", titleLabel, "BOTTOMLEFT", 0, -1)
    hintLabel:SetText(L["GEMS_RAW_READONLY_HINT"])
    hintLabel:SetTextColor(C.textMuted:GetRGBA())
    RT.hintLabel = hintLabel

    -- ScrollFrame (below header)
    local statusHeight = D().RAW_STATUS_HEIGHT
    local scrollFrame, scrollChild = UI:CreateScrollPanel(mainFrame, 400)
    scrollFrame:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", 8, -headerHeight)
    scrollFrame:SetPoint("BOTTOMRIGHT", mainFrame, "BOTTOMRIGHT", -26, statusHeight + 4)
    RT.scrollFrame = scrollFrame
    RT.scrollChild = scrollChild

    -- Update scroll child width when scrollFrame resizes
    scrollFrame:SetScript("OnSizeChanged", function(self, w)
        scrollChild:SetWidth(w)
        if RT.editBox then
            RT.editBox:SetWidth(w)
        end
    end)

    -- EditBox inside scroll child
    local editBox = CreateFrame("EditBox", nil, scrollChild)
    editBox:SetMultiLine(true)
    editBox:SetAutoFocus(false)
    editBox:SetAllPoints(scrollChild)
    local fontPath = GRIPEMS.UI:GetFontPath()
    editBox:SetFont(fontPath, 10, "")
    editBox:SetTextColor(C.textSecondary:GetRGBA())
    editBox:EnableKeyboard(false)
    editBox:EnableMouse(true)
    editBox:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
    end)
    -- Auto-resize scroll child to fit text
    editBox:SetScript("OnTextChanged", function(self)
        local height = self:GetHeight()
        if height and height > 0 then
            scrollChild:SetHeight(height)
        end
    end)
    RT.editBox = editBox
    GRIPEMS.Focus:HookEditBox(editBox)

    -- Syntax highlighting hook (Lua tokenizer)
    local SH = GRIPEMS.SyntaxHighlight
    if SH then
        SH:HookEditBox(RT.editBox, "lua")
    end

    -- Status line (bottom of main frame)
    local statusLine = mainFrame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(statusLine, 10)
    statusLine:SetPoint("BOTTOMLEFT", mainFrame, "BOTTOMLEFT", 8, 4)
    statusLine:SetPoint("BOTTOMRIGHT", mainFrame, "BOTTOMRIGHT", -8, 4)
    statusLine:SetJustifyH("LEFT")
    statusLine:SetTextColor(C.textSuccess:GetRGBA())
    statusLine:Hide()
    RT.statusLine = statusLine
end

---------------------------------------------------------------------------
-- Show / Hide
---------------------------------------------------------------------------

--- Show the Raw tab.
function RT:Show()
    if RT.mainFrame then
        RT.mainFrame:Show()
        RT:RefreshDisplay()
    end
end

--- Hide the Raw tab.
function RT:Hide()
    if RT.mainFrame then
        RT.mainFrame:Hide()
    end
    if RT.isEditing then
        RT:ExitEditMode()
    end
end

---------------------------------------------------------------------------
-- Sequence loading
---------------------------------------------------------------------------

--- Load a sequence into the Raw tab.
--- @param name string Sequence name
function RT:LoadSequence(name)
    RT.currentName = name
    RT:RefreshDisplay()
end

--- Clear the Raw tab state.
function RT:Clear()
    RT.currentName = nil
    if RT.editBox then
        RT.editBox:SetText("")
        RT.editBox._shBusy = false
    end
    if RT.mainFrame then
        RT.mainFrame:Hide()
    end
    if RT.isEditing then
        RT:ExitEditMode()
    end
end

---------------------------------------------------------------------------
-- Display refresh
---------------------------------------------------------------------------

--- Refresh the EditBox with the current sequence data.
function RT:RefreshDisplay()
    if not RT.editBox then
        return
    end

    local C = UI.Colors
    local name = RT.currentName
    if not name then
        RT.editBox:SetText(L["GEMS_RAW_NO_SEQUENCE"])
        return
    end

    local engine = GRIPEMS.Engine
    local entry = engine and engine.sequences and engine.sequences[name]
    if not entry or not entry.data then
        RT.editBox:SetText(L["GEMS_RAW_NO_SEQUENCE"])
        return
    end

    local text = RT:SerializeTable(entry.data)
    RT.editBox._shBusy = true
    RT.editBox:SetText(text)
    -- _shBusy stays true to block per-frame SH:Colorize
    -- in read-only mode. Edit mode toggle clears it.

    -- Ensure read-only appearance
    if not RT.isEditing then
        RT.editBox:EnableKeyboard(false)
        RT.editBox:SetTextColor(C.textSecondary:GetRGBA())
    end
end

---------------------------------------------------------------------------
-- Edit mode
---------------------------------------------------------------------------

--- Enter edit mode (editable, Apply/Cancel visible).
function RT:EnterEditMode()
    RT.isEditing = true
    local C = UI.Colors

    if RT.editBox then
        RT.editBox:EnableKeyboard(true)
        RT.editBox:SetTextColor(C.textPrimary:GetRGBA())
        -- Allow syntax highlighting while editing
        RT.editBox._shBusy = false
    end
    if RT.editBtn then
        RT.editBtn:SetText(L["GEMS_RAW_APPLY"])
    end
    if RT.cancelBtn then
        RT.cancelBtn:Show()
    end
    if RT.modeLabel then
        RT.modeLabel:SetText("(Editing)")
        RT.modeLabel:SetTextColor(C.textWarning:GetRGBA())
    end
    if RT.hintLabel then
        RT.hintLabel:Hide()
    end
    if RT.statusLine then
        RT.statusLine:SetText("")
        RT.statusLine:Show()
    end
end

--- Exit edit mode (read-only, revert to engine data).
function RT:ExitEditMode()
    RT.isEditing = false
    local C = UI.Colors

    if RT.editBox then
        RT.editBox:EnableKeyboard(false)
        RT.editBox:SetTextColor(C.textSecondary:GetRGBA())
        RT.editBox:ClearFocus()
        -- Block per-frame syntax highlighting in read-only mode
        RT.editBox._shBusy = true
    end
    if RT.editBtn then
        RT.editBtn:SetText(L["GEMS_RAW_EDIT"])
    end
    if RT.cancelBtn then
        RT.cancelBtn:Hide()
    end
    if RT.modeLabel then
        RT.modeLabel:SetText("(Read-Only)")
        RT.modeLabel:SetTextColor(C.textMuted:GetRGBA())
    end
    if RT.hintLabel then
        RT.hintLabel:Show()
    end
    if RT.statusLine then
        RT.statusLine:Hide()
    end

    RT:RefreshDisplay()
end

---------------------------------------------------------------------------
-- Apply changes
---------------------------------------------------------------------------

--- Validate and apply edited Lua table back to the engine.
function RT:ApplyChanges()
    if not RT.editBox then
        return
    end

    local C = UI.Colors
    local text = RT.editBox:GetText()
    -- The Apply click drops editbox focus first, so the focus-loss highlight
    -- hook has already baked colour codes into the buffer. Strip them so the
    -- parser sees plain source. Harmless when the text is already plain.
    local SH = GRIPEMS.SyntaxHighlight
    if SH then
        text = SH:Strip(text)
    end

    -- Validate Lua syntax
    local fn, err = loadstring("return " .. text)
    if not fn then
        if RT.statusLine then
            RT.statusLine:SetText(string.format(L["GEMS_RAW_INVALID"], err or "unknown"))
            RT.statusLine:SetTextColor(C.textError:GetRGBA())
        end
        return
    end

    -- Execute to get the table
    local ok, result = pcall(fn)
    if not ok or type(result) ~= "table" then
        if RT.statusLine then
            RT.statusLine:SetText(
                string.format(L["GEMS_RAW_INVALID"], not ok and tostring(result) or "Result is not a table")
            )
            RT.statusLine:SetTextColor(C.textError:GetRGBA())
        end
        return
    end

    -- Validate required fields
    if type(result.name) ~= "string" or result.name == "" then
        if RT.statusLine then
            RT.statusLine:SetText(string.format(L["GEMS_RAW_MISSING_FIELD"], "name"))
            RT.statusLine:SetTextColor(C.textError:GetRGBA())
        end
        return
    end

    -- Handle name change: ignore, override back to current
    local currentName = RT.currentName
    local nameChanged = result.name ~= currentName

    -- Merge-overlay apply (Option 1: full content editable, provenance locked).
    -- The edited text round-trips the whole sequence, so take the stored sequence
    -- as the base (every field preserved -- keyPress/keyRelease, actions,
    -- contextOverrides, privacy, and the author-protection chain) and overlay all
    -- edited content from the parsed text EXCEPT the locked identity/provenance
    -- set, which is always kept from stored. A raw edit therefore cannot forge
    -- authorship or wipe the chain, and the masked "<hidden>" BattleTag in the text
    -- is ignored (the real stored value is preserved).
    local engine = GRIPEMS.Engine
    local I = GRIPEMS.Identity
    if not I then
        if RT.statusLine then
            RT.statusLine:SetText(string.format(L["GEMS_RAW_INVALID"], "identity module unavailable"))
            RT.statusLine:SetTextColor(C.textError:GetRGBA())
        end
        return
    end
    local entry = engine and engine.sequences and engine.sequences[currentName]
    local oldData = entry and entry.data
    if not oldData then
        if RT.statusLine then
            RT.statusLine:SetText(string.format(L["GEMS_RAW_MISSING_FIELD"], "sequence"))
            RT.statusLine:SetTextColor(C.textError:GetRGBA())
        end
        return
    end

    -- Validate edited content before mutating anything.
    if result.versions and type(result.versions) == "table" and next(result.versions) then
        for i, ver in ipairs(result.versions) do
            if type(ver) ~= "table" or type(ver.steps) ~= "table" then
                if RT.statusLine then
                    RT.statusLine:SetText(string.format(L["GEMS_RAW_MISSING_FIELD"], "versions[" .. i .. "].steps"))
                    RT.statusLine:SetTextColor(C.textError:GetRGBA())
                end
                return
            end
            local sf = ver.stepFunction
            if sf ~= "Sequential" and sf ~= "Random" and sf ~= "Priority" then
                if RT.statusLine then
                    RT.statusLine:SetText(
                        string.format(L["GEMS_RAW_MISSING_FIELD"], "versions[" .. i .. "].stepFunction")
                    )
                    RT.statusLine:SetTextColor(C.textError:GetRGBA())
                end
                return
            end
        end
    elseif result.steps and type(result.steps) == "table" then
        if
            result.stepFunction ~= "Sequential"
            and result.stepFunction ~= "Random"
            and result.stepFunction ~= "Priority"
        then
            if RT.statusLine then
                RT.statusLine:SetText(string.format(L["GEMS_RAW_MISSING_FIELD"], "stepFunction"))
                RT.statusLine:SetTextColor(C.textError:GetRGBA())
            end
            return
        end
    else
        if RT.statusLine then
            RT.statusLine:SetText(string.format(L["GEMS_RAW_MISSING_FIELD"], "versions or steps"))
            RT.statusLine:SetTextColor(C.textError:GetRGBA())
        end
        return
    end

    -- Identity / provenance fields a raw edit must NEVER change. Kept from the
    -- stored sequence; every other field is taken from the edited text.
    local LOCKED = {
        name = true,
        createdAt = true,
        originalAuthor = true,
        originalAuthorIdentity = true,
        originalAuthorRealm = true,
        originalAuthorBattleTag = true,
        originalCreatedAt = true,
        originalSignature = true,
        originalSignatureV2 = true,
        currentSignature = true,
        currentSignatureV2 = true,
        signatureAlgorithm = true,
        lastModifier = true,
        lastModifierIdentity = true,
        lastModifierRealm = true,
        lastModifiedAt = true,
        modifierChain = true,
        forkedFrom = true,
        forkedFromChain = true,
        provenanceSource = true,
        privacyMode = true,
    }

    -- Base = deep copy of stored data; overlay all non-locked fields from text.
    local newSeqData = I:_DeepCopy(oldData)
    for k, v in pairs(result) do
        if not LOCKED[k] then
            newSeqData[k] = v
        end
    end
    newSeqData.name = currentName
    newSeqData.updatedAt = time()

    -- Coerce step values to strings; sanitize defaultVersion; migrate legacy flat.
    if newSeqData.versions and type(newSeqData.versions) == "table" then
        newSeqData.steps = nil
        newSeqData.stepFunction = nil
        for _, ver in ipairs(newSeqData.versions) do
            if type(ver.steps) == "table" then
                for j = 1, #ver.steps do
                    ver.steps[j] = tostring(ver.steps[j])
                end
            end
        end
        newSeqData.defaultVersion = tonumber(newSeqData.defaultVersion) or 1
        if newSeqData.defaultVersion < 1 or newSeqData.defaultVersion > #newSeqData.versions then
            newSeqData.defaultVersion = 1
        end
        -- LIVE-VERSION-QUICK-SWAP: clear an out-of-range pin on raw save so a
        -- hand-edited or stale pinnedVersion can never strand the sequence.
        if newSeqData.pinnedVersion ~= nil then
            local pv = tonumber(newSeqData.pinnedVersion)
            if not pv or pv < 1 or pv > #newSeqData.versions then
                newSeqData.pinnedVersion = nil
            end
        end
    elseif newSeqData.steps and type(newSeqData.steps) == "table" then
        newSeqData.versions = nil
        for j = 1, #newSeqData.steps do
            newSeqData.steps[j] = tostring(newSeqData.steps[j])
        end
        GRIPEMS.Engine:MigrateSequenceFormat(newSeqData)
    end

    -- Strip the locale sidecars the serialized text carried back: the raw
    -- editbox shows taggedSteps / taggedKeyPress / taggedKeyRelease /
    -- macroTagged derived from PRE-edit content, and the V2 canon prefers
    -- tagged forms over the edited plain fields -- stale sidecars would both
    -- blind the change detection below and get signed over the wrong
    -- content. The editor save path omits them the same way (allowlist
    -- rebuild); NormalizeVersionLocale regenerates them from the new
    -- content inside UpdateSequenceData, and the V2 canon's untagged
    -- fallback hashes identically to the regenerated form.
    if type(newSeqData.versions) == "table" then
        local SC = GRIPEMS.SpellCache
        for _, ver in ipairs(newSeqData.versions) do
            if type(ver) == "table" then
                ver.taggedSteps = nil
                ver.taggedKeyPress = nil
                ver.taggedKeyRelease = nil
                -- THE TYPE TEST TWO LINES UP DOES NOT COVER THIS FIELD. :671
                -- tests `ver`, the PARENT; ver.actions is a separate value and
                -- a scalar there is truthy, enters this block, and raises
                -- inside the walk. The fix is the field, not the parent --
                -- the parent test is already correct and is not the problem.
                if type(ver.actions) == "table" and SC and SC._WalkActions then
                    SC:_WalkActions(ver.actions, function(node)
                        node.macroTagged = nil
                    end)
                end
            end
        end
    end

    -- Re-stamp + re-sign only when signed content actually changed. Provenance
    -- was preserved from stored. Change detection unions both canons: the V1
    -- canon sees the scalar content fields, and the V2 signature sees the
    -- array content (versions/steps/actions) the V1 table walk is blind to --
    -- a step-only raw edit previously went unstamped, leaving the stored V2
    -- signature covering pre-edit content and badging the owner's own
    -- sequence "tampered". Symmetric with SequenceEditor/PopupEditor: the
    -- owned re-sign refreshes originalSignatureV2 (original author only, so
    -- foreign edits still surface), then AppendModifierEntry records the
    -- edit and recomputes both current signatures.
    if I.CanonicalSerialize and I.AppendModifierEntry then
        local changed = I:CanonicalSerialize(oldData) ~= I:CanonicalSerialize(newSeqData)
        if not changed and I.SignSequenceV2 then
            changed = I:SignSequenceV2(oldData) ~= I:SignSequenceV2(newSeqData)
        end
        if changed and newSeqData.originalAuthor and newSeqData.originalAuthor ~= "" then
            if I.EnsureOwnedV2Signature then
                I:EnsureOwnedV2Signature(newSeqData)
            end
            I:AppendModifierEntry(newSeqData, "edited")
        end
    end

    -- Apply to engine (persists to engine + SavedVariables immediately)
    if engine and engine.UpdateSequenceData then
        engine:UpdateSequenceData(currentName, newSeqData)
    end

    -- Sync SequenceEditor working copy from the applied data.
    -- UpdateSequenceData fires SEQUENCE_UPDATED which triggers
    -- SE:LoadSequence, but in the full-rebuild path the engine entry
    -- may still be stale (activation deferred via OOCQueue in combat).
    -- Force-sync here to prevent a subsequent Save from overwriting
    -- the raw edits with a stale working copy. (BUG-038)
    local SE = GRIPEMS.SequenceEditor
    if SE and SE.currentSequence == currentName then
        local SLV = GRIPEMS.StepListView
        if SLV and engine.GetActiveVersion then
            local newVer = engine:GetActiveVersion(newSeqData)
            SLV:LoadSteps(
                newVer and newVer.steps or {},
                newVer and newVer.actions or nil,
                newVer and newVer.stepLabels or nil
            )
        end
        -- Data is already persisted by UpdateSequenceData; no Save needed
        SE.isDirty = false
        if SE.UpdateSaveButtons then
            SE:UpdateSaveButtons()
        end
    end

    -- Exit edit mode (restores read-only appearance + calls RefreshDisplay)
    RT:ExitEditMode()

    -- Override editbox with applied data: RefreshDisplay reads from
    -- engine.sequences which may be stale in the OOCQueue path (BUG-038)
    if RT.editBox then
        RT.editBox:SetText(RT:SerializeTable(newSeqData))
    end

    -- Show success message (with name warning if applicable)
    if RT.statusLine then
        if nameChanged then
            RT.statusLine:SetText(L["GEMS_RAW_NAME_IGNORED"])
            RT.statusLine:SetTextColor(C.textWarning:GetRGBA())
        else
            RT.statusLine:SetText(L["GEMS_RAW_APPLIED"])
            RT.statusLine:SetTextColor(C.textSuccess:GetRGBA())
        end
        RT.statusLine:Show()
        -- The name-ignored warning stays on screen until the next edit
        -- session clears it; only the success message auto-hides.
        if not nameChanged and C_Timer and C_Timer.After then
            C_Timer.After(2, function()
                if RT.statusLine and not RT.isEditing then
                    RT.statusLine:Hide()
                end
            end)
        end
    end
end
