-- GRIP-EMS: Headless test for Engine:GetAuthoredStepList (authored base order)
--
-- Created:    2026-07-11
-- Updated:    2026-07-11
-- Patch: 12.0.7 Midnight (Retail LIVE)
--
-- Covers the REAL Engine:GetAuthoredStepList that backs Core/PublicAPI.lua
-- impl.GetAuthoredSteps. The authored accessor returns the AUTHORED base order:
-- interleave copies suppressed and the version-level repeatCount NOT applied,
-- with loops unrolled and IF branches flattened. Its one production caller is
-- impl.GetAuthoredSteps, and Test/public_api_spec.lua exercises only a hand-copied
-- FAKE of it -- so nothing drove the real accessor until this file. The row the
-- accessor exists to defend is "the interleave-injected compiled ver.steps must
-- never leak out as the authored array"; A1 and A2 sabotage-catch exactly that.
--
-- Loads the REAL modules (Data/Defaults.lua, Engine/MacroSyntax.lua,
-- Engine/ActionCompiler.lua, Engine/StepFunctions.lua, Engine/Engine.lua) via
-- loadfile + setfenv into a no-op stub sandbox -- the ActionCompiler bootstrap
-- from test_actioncompiler_disabled_children.lua merged with the Engine bootstrap
-- from test_stepadv_numsteps_domain.lua. Data/Defaults.lua supplies the REAL D, so
-- no compiler constants are hand-rolled here (that is how fixtures drift). There is
-- deliberately NO SpellCache: ResolveStepSnapshots is nil-safe on it, so every
-- snapshot comes back as { index = i } with nil spell fields. Cases assert on
-- COUNTS and on .index only -- never on spellID / spellName / icon.
--
-- Run from the EMS root:  lua Test/test_authored_steps_domain.lua
-- Exit code 0 = all passed, 1 = at least one failure.
--
-- Cases:
--   A1  interleave copies are stripped from the authored array (SABOTAGE CATCHER)
--   A2  the version repeatCount is NOT applied to the authored array
--   A3  importBakedSteps makes ver.steps win over the actions tree
--   A4  a legacy no-tree version falls back to ver.steps; authored != execution
--   A5  an interleave-only tree still yields its nodes as authored base steps
--   A6  the accessor never mutates ver.actions or ver.steps
--   A7  authored array shape (.index) and the no-active-version edge

local ADDON_NAME = "GRIP-EMS"

-- ---------------------------------------------------------------------------
-- Minimal assertion + runner harness.
-- ---------------------------------------------------------------------------

local tests = {}

local function test(name, fn)
    tests[#tests + 1] = { name = name, fn = fn }
end

local function assertEqual(expected, actual, label)
    if expected ~= actual then
        error((label or "value") .. ": expected " .. tostring(expected) .. ", got " .. tostring(actual), 2)
    end
end

local function assertTrue(cond, label)
    if not cond then
        error((label or "condition") .. " failed", 2)
    end
end

-- ---------------------------------------------------------------------------
-- Sandbox: a self-referential no-op stub backs every unknown global so the real
-- modules load without a WoW client. Real stdlib falls through to _G.
-- ---------------------------------------------------------------------------

local stub = {}
setmetatable(stub, {
    __index = function()
        return stub
    end,
    __call = function()
        return stub
    end,
})

local env = setmetatable({}, {
    __index = function(_, k)
        local v = rawget(_G, k)
        if v ~= nil then
            return v
        end
        return stub
    end,
})
env._G = env

-- AceLocale stand-in: every key echoes back so any L["KEY"] format is inert.
local LOCALE = setmetatable({}, {
    __index = function(_, k)
        return k
    end,
})
env.LibStub = function()
    return {
        GetLocale = function()
            return LOCALE
        end,
    }
end
env.strlower = string.lower
env.GetTime = function()
    return 0
end

-- ---------------------------------------------------------------------------
-- GRIPEMS control table. Defaults is intentionally omitted: the REAL
-- Data/Defaults.lua populates GRIPEMS.Defaults when loaded first. OOCQueue.Add
-- runs its callback synchronously; Popup:Define is a no-op (Engine.lua registers
-- a corrupt-sequence popup at module scope); Fire is unused by the read paths
-- under test but present for parity with the Engine bootstrap.
-- ---------------------------------------------------------------------------

local GRIPEMS = {
    version = "headless",
    Print = function() end,
    Debug = function() end,
    OOCQueue = {
        IsRestricted = function()
            return true
        end,
        Add = function(_, fn)
            fn()
        end,
    },
    MacroManager = {
        UpdateIcon = function() end,
        UpdateStubBody = function() end,
    },
    KeybindManager = {},
    Popup = {
        Define = function() end,
        Show = function() end,
    },
    Fire = function() end,
}

-- ---------------------------------------------------------------------------
-- Load the REAL modules into the sandbox, in dependency order:
--   Defaults      -- ActionCompiler + Engine capture local D at load
--   MacroSyntax   -- the IF compile path routes through it
--   ActionCompiler
--   StepFunctions -- Engine captures GRIPEMS.StepFunctions as a load-time upvalue
--   Engine
-- ---------------------------------------------------------------------------

local function loadModule(candidates)
    for _, path in ipairs(candidates) do
        -- loadfile is dev-harness file I/O, intentionally outside the addon WoW std.
        -- selene: allow(undefined_variable)
        local chunk = loadfile(path)
        if chunk then
            setfenv(chunk, env)
            chunk(ADDON_NAME, GRIPEMS)
            return true
        end
    end
    return false
end

assert(
    loadModule({
        "Data/Defaults.lua",
        "../Data/Defaults.lua",
        "GRIP/EMS/Data/Defaults.lua",
    }),
    "could not locate Data/Defaults.lua (run from the EMS root)"
)
assert(
    loadModule({
        "Engine/MacroSyntax.lua",
        "../Engine/MacroSyntax.lua",
        "GRIP/EMS/Engine/MacroSyntax.lua",
    }),
    "could not locate Engine/MacroSyntax.lua (run from the EMS root)"
)
assert(
    loadModule({
        "Engine/ActionCompiler.lua",
        "../Engine/ActionCompiler.lua",
        "GRIP/EMS/Engine/ActionCompiler.lua",
    }),
    "could not locate Engine/ActionCompiler.lua (run from the EMS root)"
)
assert(
    loadModule({
        "Engine/StepFunctions.lua",
        "../Engine/StepFunctions.lua",
        "GRIP/EMS/Engine/StepFunctions.lua",
    }),
    "could not locate Engine/StepFunctions.lua (run from the EMS root)"
)
assert(
    loadModule({
        "Engine/Engine.lua",
        "../Engine/Engine.lua",
        "GRIP/EMS/Engine/Engine.lua",
    }),
    "could not locate Engine/Engine.lua (run from the EMS root)"
)

local Engine = GRIPEMS.Engine
local AC = GRIPEMS.ActionCompiler
local D = GRIPEMS.Defaults
assert(D ~= nil, "Defaults loaded")
assert(GRIPEMS.MacroSyntax ~= nil, "MacroSyntax loaded")
assert(AC ~= nil, "ActionCompiler loaded")
assert(GRIPEMS.StepFunctions ~= nil, "StepFunctions loaded")
assert(Engine ~= nil, "Engine loaded")
assert(type(Engine.GetAuthoredStepList) == "function", "Engine:GetAuthoredStepList defined")
assert(type(Engine.GetActiveVersionStepList) == "function", "Engine:GetActiveVersionStepList defined")
assert(type(AC.CompileActions) == "function", "AC.CompileActions defined")
Engine.sequences = {}

-- Constants come from the loaded Defaults, never hand-coded, so the fixtures move
-- with the compiler instead of drifting from it.
local ACTION = D.ACTION_TYPE_ACTION
local INTERLEAVE = D.ACTION_INTERLEAVE_MIN
local SEQUENTIAL = D.STEP_SEQUENTIAL
local PRIORITY = D.STEP_PRIORITY

-- ---------------------------------------------------------------------------
-- Fixtures + helpers.
-- ---------------------------------------------------------------------------

local MAC_A = "/cast Alpha"
local MAC_B = "/cast Bravo"
local MAC_C = "/cast Charlie"
local MAC_D = "/cast Delta"
local MAC_E = "/cast Echo"
local MAC_F = "/cast Foxtrot"

-- An ACTION node with an optional field bag (interval, etc.). D is the Defaults
-- table, so macros use MAC_* names to avoid shadowing it.
local function action(macro, extra)
    local node = { type = ACTION, macro = macro }
    for k, v in pairs(extra or {}) do
        node[k] = v
    end
    return node
end

-- Wrap a single version into the versioned sequence-data shape GetActiveVersion
-- reads.
local function makeSeqData(ver)
    return { defaultVersion = 1, versions = { ver } }
end

-- ---------------------------------------------------------------------------
-- Cases.
-- ---------------------------------------------------------------------------

test("A1: interleave copies are stripped from the authored array (SABOTAGE CATCHER)", function()
    -- Four ACTION nodes; B is an interleave (interval == ACTION_INTERLEAVE_MIN).
    -- CompileActions weaves B's copies into the compiled ver.steps; the authored
    -- accessor must NOT -- it returns the four base nodes only. If the accessor
    -- returned ver.steps instead (the sabotage), the interleave copies come back
    -- and the count inflates past 4, failing the first assertion below.
    local ver = {
        stepFunction = SEQUENTIAL,
        actions = {
            action(MAC_A),
            action(MAC_B, { interval = INTERLEAVE }),
            action(MAC_C),
            action(MAC_D),
        },
    }
    ver.steps = AC.CompileActions(ver.actions, Engine, ver)
    local seqData = makeSeqData(ver)

    local authored = Engine:GetAuthoredStepList(seqData)
    -- Relation only -- the compiled length is read off #ver.steps, never hardcoded.
    assertEqual(4, #authored, "authored count is the 4 base nodes (interleave copies leaked in on sabotage)")
    assertTrue(#ver.steps > 4, "compiled ver.steps is interleave-inflated beyond 4")
    assertTrue(#authored < #ver.steps, "authored count sits below the inflated compiled count")
end)

test("A2: the version repeatCount is NOT applied to the authored array", function()
    -- Four plain ACTION nodes with a version repeatCount of 3. CompileActions wraps
    -- the tree in a synthetic Sequential loop and expands 4 -> 12; the authored
    -- accessor passes version = nil to CompileAuthoredActions, so that wrap never
    -- fires and the count stays 4. Returning ver.steps (the sabotage) brings the
    -- repeatCount wrap back and inflates the count to 12.
    local ver = {
        stepFunction = SEQUENTIAL,
        repeatCount = 3,
        actions = {
            action(MAC_A),
            action(MAC_B),
            action(MAC_C),
            action(MAC_D),
        },
    }
    ver.steps = AC.CompileActions(ver.actions, Engine, ver)
    local seqData = makeSeqData(ver)

    -- Control: prove the synthetic-Loop repeat wrap actually fired (4 * 3 == 12).
    assertEqual(12, #ver.steps, "control: repeatCount=3 wrapped 4 actions into a 12-step Sequential loop")
    assertEqual(4, #Engine:GetAuthoredStepList(seqData), "authored ignores the version repeatCount (version = nil)")
end)

test("A3: importBakedSteps makes ver.steps win over the actions tree", function()
    -- A baked import: the four-node tree is present but importBakedSteps routes the
    -- accessor to the DISTINCT two-entry ver.steps instead of compiling the tree.
    -- This is the only case pinning the importBakedSteps clause of the guard.
    local ver = {
        stepFunction = SEQUENTIAL,
        importBakedSteps = true,
        actions = {
            action(MAC_A),
            action(MAC_B),
            action(MAC_C),
            action(MAC_D),
        },
        steps = { MAC_E, MAC_F },
    }
    local seqData = makeSeqData(ver)
    assertEqual(2, #Engine:GetAuthoredStepList(seqData), "baked import returns ver.steps (2), never the 4-node tree")
end)

test("A4: a legacy no-tree version falls back to ver.steps; authored != execution", function()
    -- No actions tree at all: the authored array is ver.steps verbatim (4). The
    -- execution accessor expands the same 4 through a Priority step function to 10,
    -- so the two REAL accessors disagree by design -- the authored-vs-execution
    -- domain split, asserted against the real Engine rather than a fake.
    local ver = {
        stepFunction = PRIORITY,
        steps = { MAC_A, MAC_B, MAC_C, MAC_D },
    }
    local seqData = makeSeqData(ver)
    local authoredCount = #Engine:GetAuthoredStepList(seqData)
    local execCount = #Engine:GetActiveVersionStepList(seqData)
    assertEqual(4, authoredCount, "legacy no-tree authored count is ver.steps (4)")
    assertEqual(10, execCount, "Priority execution order expands 4 to 10")
    assertTrue(authoredCount ~= execCount, "authored and execution domains differ")
end)

test("A5: an interleave-only tree still yields its nodes as authored base steps", function()
    -- Both ACTION nodes are interleaves. With ignoreInterleave = true (the authored
    -- path) they compile as base steps, so the authored array is never empty -- the
    -- reason CompileAuthoredActions needs no zero-step fallback. ver.steps mirrors the
    -- real compiled result so the accessor guard's else clause has a table to fall to.
    local ver = {
        stepFunction = SEQUENTIAL,
        actions = {
            action(MAC_A, { interval = INTERLEAVE }),
            action(MAC_B, { interval = INTERLEAVE }),
        },
    }
    ver.steps = AC.CompileActions(ver.actions, Engine, ver)
    local seqData = makeSeqData(ver)
    assertEqual(2, #Engine:GetAuthoredStepList(seqData), "interleave-only tree yields both nodes as base steps")
end)

test("A6: the accessor never mutates ver.actions or ver.steps", function()
    -- A1's interleave fixture. Two calls must leave ver.actions and ver.steps
    -- byte-for-byte unchanged and return the same count each time.
    local ver = {
        stepFunction = SEQUENTIAL,
        actions = {
            action(MAC_A),
            action(MAC_B, { interval = INTERLEAVE }),
            action(MAC_C),
            action(MAC_D),
        },
    }
    ver.steps = AC.CompileActions(ver.actions, Engine, ver)
    local seqData = makeSeqData(ver)

    local actionsBefore = #ver.actions
    local stepsBefore = #ver.steps
    local stepsCopy = {}
    for i = 1, #ver.steps do
        stepsCopy[i] = ver.steps[i]
    end

    local first = #Engine:GetAuthoredStepList(seqData)
    local second = #Engine:GetAuthoredStepList(seqData)

    assertEqual(actionsBefore, #ver.actions, "ver.actions length unchanged")
    assertEqual(stepsBefore, #ver.steps, "ver.steps length unchanged")
    for i = 1, #stepsCopy do
        assertEqual(stepsCopy[i], ver.steps[i], "ver.steps[" .. i .. "] unchanged")
    end
    assertEqual(first, second, "both calls return the same count")
end)

test("A7: authored array shape (.index) and the no-active-version edge", function()
    -- Shape: indices are 1..#authored, contiguous. ver.steps mirrors the compiled
    -- result so the shape holds under both accessor branches.
    local ver = {
        stepFunction = SEQUENTIAL,
        actions = {
            action(MAC_A),
            action(MAC_B),
            action(MAC_C),
            action(MAC_D),
        },
    }
    ver.steps = AC.CompileActions(ver.actions, Engine, ver)
    local seqData = makeSeqData(ver)

    local authored = Engine:GetAuthoredStepList(seqData)
    assertTrue(#authored > 0, "authored array is non-empty")
    assertEqual(1, authored[1].index, "first entry index is 1")
    assertEqual(#authored, authored[#authored].index, "last entry index equals the length")

    -- Edge: no active version resolves -> empty array, not an error.
    local empty = Engine:GetAuthoredStepList({ defaultVersion = 1, versions = {} })
    assertEqual(0, #empty, "no active version returns an empty array")
end)

-- ---------------------------------------------------------------------------
-- Run.
-- ---------------------------------------------------------------------------

local passed = 0
local failed = 0
for _, t in ipairs(tests) do
    local ok, err = pcall(t.fn)
    if ok then
        passed = passed + 1
        print("PASS  " .. t.name)
    else
        failed = failed + 1
        print("FAIL  " .. t.name .. " -- " .. tostring(err))
    end
end
print(string.format("RESULT %d passed, %d failed", passed, failed))
os.exit(failed > 0 and 1 or 0)
