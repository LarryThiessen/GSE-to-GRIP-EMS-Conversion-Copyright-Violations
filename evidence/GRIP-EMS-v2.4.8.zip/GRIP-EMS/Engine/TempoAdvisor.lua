--------------------------------------------------------------------------------
-- TempoAdvisor.lua -- Faster, Slower: Spell Classification + Analysis Engine
-- Per-sequence click rate analysis based on spell timing classification.
-- Slash: /gems fs
-- Created: 2026-04-07 (module origin via FS Phase 1)
-- Updated: 2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.
--------------------------------------------------------------------------------
local _, GRIPEMS = ...
GRIPEMS.TempoAdvisor = {}
local TA = GRIPEMS.TempoAdvisor
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

-- Lazy module accessors (avoid load-order dependency)
local function D()
    return GRIPEMS.Defaults
end
local function SF()
    return GRIPEMS.StepFunctions
end
local function SC()
    return GRIPEMS.SpellCache
end
local function SQW()
    return GRIPEMS.SQWOptimizer
end
local function Engine()
    return GRIPEMS.Engine
end

-- Constants
local MIN_CLICK_RATE = 100 -- D.MS_CLICK_RATE_MIN (hardware/human floor)
local CLASS_GCD_FLOOR = 750 -- most classes; 1000ms for some caster GCDs
local GCD_SPELL_ID = 61304 -- canonical GCD detection spell (same as SQWOptimizer)
local CAT_OFF_GCD = "OFF_GCD"
local CAT_ON_GCD_INSTANT = "ON_GCD_INSTANT"
local CAT_ON_GCD_CAST = "ON_GCD_CAST"
local CAT_LONG_CAST = "LONG_CAST"
local CAT_CHANNEL = "CHANNEL"
local CAT_PAUSE_CLICKS = "PAUSE_CLICKS"
local CAT_UNKNOWN = "UNKNOWN"
local COMPLEXITY_RELAXED = "RELAXED"
local COMPLEXITY_STANDARD = "STANDARD"
local COMPLEXITY_DEMANDING = "DEMANDING"
local COMPLEXITY_INTENSE = "INTENSE"
-- Known off-GCD spells where GetSpellBaseCooldown returns wrong gcdMS.
-- These spells are definitively off-GCD but the API reports non-zero gcdMS.
-- Override at classification time since runtime detection cannot catch them
-- (players spam keybinds, so these spells are permanently on cooldown in combat).
local KNOWN_OFF_GCD_SPELLS = {
    [19574] = true, -- Bestial Wrath (Beast Mastery Hunter)
}
TA.spellClassCache = {}
-- debugMode now persisted via Settings ("tempoAdvisorDebug")
TA._analyzedThisSession = {}
TA._spellCacheReady = false
TA._deferredActivation = {} -- [seqName] = true; activations parked until SPELL_CACHE_REFRESHED drains them
TA._lastAnalysisTime = {} -- [seqName] = GetTime() of last analysis (debounce)
-- [specID][seqName] = GetTime() of the last analysis stored in SavedVariables.
-- Rebuilt fresh each session -- GetTime() resets on /reload so this value can
-- NEVER be written to GRIP_EMS_CHAR. The 60-second freshness gate only needs
-- to behave correctly within one session (a /reload is itself a reason to
-- re-analyse).
TA._recFreshness = {}
TA._runtimeOverrides = {} -- [spellID] = category; survives InvalidateSpellCache
TA._pendingVerification = {} -- [spellID] = true; ON_GCD_INSTANT spells to verify during GCD
TA._itemSpellIDs = {} -- [lowercase spellName] = spellID; from /use slot resolution
-- OPP-06 name-keyed spell-to-sequence index (session-scope, never persisted).
-- _spellToSequences[spellID] = { [seqName] = true, ... } forward lookup used
-- by _ScopedReanalyze to find the sequences that reference a just-reclassified
-- spell. _sequenceSpellSet[seqName] = { [spellID] = true, ... } reverse lookup
-- used on SEQUENCE_DELETED/UPDATED to tear down stale forward entries without
-- scanning every bucket. _justReclassified is a scratch set populated by
-- ReclassifyOffGCD and drained by _ScopedReanalyze each cycle.
TA._spellToSequences = {}
TA._sequenceSpellSet = {}
TA._justReclassified = {}

-- Reusable tables for AnalyzeSequence (avoid per-call garbage)
local _resolvedSteps = {}
local _stepCategories = {}
-- ENH-CATEGORY-TIGHTNESS-RANKING Option (4): parallel array sized
-- per analysis run. _stepCategories[i] holds the tightness-derived
-- category (drives ComputeTransition + transitions + recommendedMs).
-- _stepComplexityCategories[i] holds the complexity-derived category
-- (drives ComputeComplexity label + offGCDCount overlay display).
-- Mixed steps reach different categories under each lens: a utility
-- OFF_GCD spell paired with an ON_GCD damage spell classifies as
-- OFF_GCD for tightness (drives fast transition) but as ON_GCD for
-- complexity (player perceives it as a damage step, not a utility step).
local _stepComplexityCategories = {}
local _transitions = {}

-- Strip WoW "secret number" taint from a value via string round-trip.
-- tonumber() alone preserves taint. tostring() creates a new untainted
-- string via C sprintf; tonumber() then parses a clean number.
local function UntaintNumber(val)
    if val == nil then
        return nil
    end
    local ok, str = pcall(tostring, val)
    if not ok then
        return nil
    end
    return tonumber(str)
end

-- Safe wrapper for C_Spell.GetSpellCooldown that strips all taint.
-- Untaints the input spell ID (tainted IDs from addon tables produce
-- tainted API output) and all output numeric fields.
local function SafeGetSpellCooldown(sid)
    local cleanSid = UntaintNumber(sid)
    if not cleanSid then
        return false, nil
    end
    local ok, info = pcall(C_Spell.GetSpellCooldown, cleanSid)
    if not ok or not info then
        return false, nil
    end
    return true,
        {
            duration = UntaintNumber(info.duration) or 0,
            startTime = UntaintNumber(info.startTime) or 0,
            isEnabled = info.isEnabled and true or false,
            modRate = UntaintNumber(info.modRate) or 1,
        }
end

--------------------------------------------------------------------------
-- HoldModeManager: Native button routing for Hold-to-Cast mode
-- NOT a separate module -- lives inside TempoAdvisor as a subsystem
--------------------------------------------------------------------------
local HMM = {}
TA.HoldModeManager = HMM

HMM.holdBindOwner = CreateFrame("Frame", "GRIPEMS_HoldBindOwner", UIParent, "SecureHandlerBaseTemplate")
HMM.active = false
HMM.activeSequence = nil
HMM.activeKey = nil
HMM.previousPollRate = nil
HMM.previousHoldCVar = nil
HMM.nativeButton = nil

-- HTC PARKED: force-disable on load
GRIPEMS._HTC_DEV_ENABLED = false

function HMM:GetNativeButton()
    local S = GRIPEMS.Settings
    local slotName = (S and S:Get("holdModeSlot")) or D().HOLD_MODE_SLOT_DEFAULT
    local btn = _G[slotName]
    if not btn then
        local fallbacks = {
            "MultiBar7Button12",
            "MultiBar7Button1",
            "MultiBar5Button12",
            "MultiBar5Button1",
            "MultiBarBottomRightButton12",
            "MultiBarBottomRightButton1",
        }
        for _, fb in ipairs(fallbacks) do
            if fb ~= slotName and _G[fb] then
                btn = _G[fb]
                if GRIPEMS.Settings then
                    GRIPEMS.Settings:Set("holdModeSlot", fb)
                end
                GRIPEMS:Debug("TA Debug: Hold Mode fallback button: " .. fb)
                break
            end
        end
    end
    if not btn then
        print("|cFFFF6600[GRIP-EMS]|r " .. L["FS_HOLD_NO_BUTTON"] .. " (" .. slotName .. ")")
        return nil
    end
    return btn
end

-- Map button names to their Blizzard binding commands
local BUTTON_TO_BIND = {
    MultiBar7Button1 = "MULTIACTIONBAR7BUTTON1",
    MultiBar7Button12 = "MULTIACTIONBAR7BUTTON12",
    MultiBar5Button1 = "MULTIACTIONBAR5BUTTON1",
    MultiBar5Button12 = "MULTIACTIONBAR5BUTTON12",
    MultiBarBottomRightButton1 = "MULTIACTIONBAR3BUTTON1",
    MultiBarBottomRightButton12 = "MULTIACTIONBAR3BUTTON12",
}

function HMM:Activate(name, seqData, recommendedMs)
    -- HTC PARKED: architecture redesign needed (see Research/HTC/)
    if not GRIPEMS._HTC_DEV_ENABLED then
        GRIPEMS:Debug("TA Debug: HMM:Activate blocked -- HTC parked")
        return false
    end
    if HMM.active then
        HMM:Deactivate()
    end
    if InCombatLockdown() then
        GRIPEMS.OOCQueue:Add(function()
            HMM:Activate(name, seqData, recommendedMs)
        end, D().OOC_OP_GENERIC, name)
        return false
    end
    local nativeBtn = HMM:GetNativeButton()
    if not nativeBtn then
        return false
    end
    -- Conflict detection
    local conflictAddons = {
        "Dominos-HoldToCastFix",
        "ElvUI_HoldToCastFix",
        "HoldToCastFix",
        "Bartender4-HoldToCastFix",
    }
    for _, addon in ipairs(conflictAddons) do
        if C_AddOns.IsAddOnLoaded(addon) then
            print("|cFFFF6600[GRIP-EMS]|r " .. L["FS_HOLD_CONFLICT"]:format(addon))
        end
    end
    -- Store previous CVar values
    HMM.previousPollRate = C_CVar.GetCVar("UseKeyHeldSpellErrorPollTime")
    HMM.previousHoldCVar = C_CVar.GetCVar("ActionButtonUseKeyHeldSpell")
    -- Build preBody (adapted from Sequential.BuildClickBody for native button)
    -- Runs in holdBindOwner restricted env; self = nativeBtn (wrapped frame)
    local preBody = [=[
        self:CallMethod('HoldDebugDown', down and '1' or '0')
        if not down then return end
        local btn = button
        if self:GetAttribute("holdOnChannel") == "1" and PlayerIsChanneling() then
            self:SetAttribute("macro", nil)
            self:SetAttribute("unit", nil)
            local rel = ""
            if self:GetAttribute("releaseAtMax") == "1" then
                rel = self:GetAttribute("empowerRelease") or ""
            end
            self:SetAttribute("macrotext", rel)
            self:CallMethod("PostClick")
            return
        end
        local modReset = false
        if btn == "LeftButton" and self:GetAttribute("resetMod_LeftButton") then modReset = true end
        if btn == "RightButton" and self:GetAttribute("resetMod_RightButton") then modReset = true end
        if btn == "MiddleButton" and self:GetAttribute("resetMod_MiddleButton") then modReset = true end
        if btn == "Button4" and self:GetAttribute("resetMod_Button4") then modReset = true end
        if btn == "Button5" and self:GetAttribute("resetMod_Button5") then modReset = true end
        if IsLeftAltKeyDown() and self:GetAttribute("resetMod_LeftAlt") then modReset = true end
        if IsRightAltKeyDown() and self:GetAttribute("resetMod_RightAlt") then modReset = true end
        if IsAltKeyDown() and self:GetAttribute("resetMod_Alt") then modReset = true end
        if IsLeftControlKeyDown() and self:GetAttribute("resetMod_LeftControl") then modReset = true end
        if IsRightControlKeyDown() and self:GetAttribute("resetMod_RightControl") then modReset = true end
        if IsControlKeyDown() and self:GetAttribute("resetMod_Control") then modReset = true end
        if IsLeftShiftKeyDown() and self:GetAttribute("resetMod_LeftShift") then modReset = true end
        if IsRightShiftKeyDown() and self:GetAttribute("resetMod_RightShift") then modReset = true end
        if IsShiftKeyDown() and self:GetAttribute("resetMod_Shift") then modReset = true end
        if (IsAltKeyDown() or IsControlKeyDown() or IsShiftKeyDown()) and self:GetAttribute("resetMod_AnyMod") then modReset = true end
        if modReset then
            self:SetAttribute('_shouldReset', '1')
        end
        local step = self:GetAttribute('step') or 1
        step = tonumber(step)
        local shouldReset = self:GetAttribute('_shouldReset')
        if shouldReset == "1" then
            step = 1
            self:SetAttribute('_shouldReset', '0')
        end
        local numS = math.max(numSteps or 1, 1)
        local stepData = steps[step]
        if stepData then
            for k, v in pairs(stepData) do
                if k == "macrotext" then
                    self:SetAttribute("macro", nil)
                    self:SetAttribute("unit", nil)
                elseif k == "macro" then
                    self:SetAttribute("macrotext", nil)
                    self:SetAttribute("unit", nil)
                end
                self:SetAttribute(k, v)
            end
        end
        step = step % numS + 1
        self:SetAttribute('step', step)
        self:CallMethod('HoldDebugStep', step)
        self:CallMethod('UpdateIcon')
        self:CallMethod('PostClick')
    ]=]
    -- Compile steps and load into holdBindOwner restricted env
    local eng = Engine()
    local curVer = eng:GetActiveVersion(seqData)
    -- ARCH-MIGRATE Phase 1: import-baked versions keep their baked steps (flag set at legacy import).
    if curVer and curVer.actions and #curVer.actions > 0 and not curVer.importBakedSteps and GRIPEMS.ActionCompiler then
        curVer.steps, curVer.compiledLabels = GRIPEMS.ActionCompiler.CompileActions(curVer.actions, eng, curVer)
    end
    local stepsToLoad = curVer and curVer.steps or {}
    local kp = curVer and curVer.keyPress or ""
    local kr = curVer and curVer.keyRelease or ""
    local compiledSteps = eng:CompileSteps(stepsToLoad, kp, kr)
    if not compiledSteps or #compiledSteps == 0 then
        return false
    end
    local execStr = eng:BuildExecuteString(compiledSteps)
    -- nativeBtn.UpdateIcon routes into Engine:UpdateButtonIcon, so this button fires
    -- SEQUENCE_STEP_ADVANCED too and needs the same cached denominator. Hold mode compiles
    -- without expansion, so this equals the authored count -- cache it anyway so no button
    -- that can fire the event is left without the field.
    nativeBtn._numExecSteps = #compiledSteps
    nativeBtn._execSteps = compiledSteps
    -- Hold mode compiles without expansion (CompileSteps above, no step-function branch), so
    -- labels are authored-domain identity: pass no step function to skip label expansion.
    nativeBtn._execLabels =
        eng:BuildExecLabels(curVer and (curVer.compiledLabels or curVer.stepLabels), nil, #stepsToLoad)
    local execOk, execErr = pcall(HMM.holdBindOwner.Execute, HMM.holdBindOwner, execStr)
    if not execOk then
        GRIPEMS:Debug("TA Debug: HMM Execute failed: " .. tostring(execErr))
        return false
    end
    -- Apply WrapScript: header=holdBindOwner, target=nativeBtn
    SecureHandlerWrapScript(nativeBtn, "OnClick", HMM.holdBindOwner, preBody)
    -- Set initial attributes on native button
    nativeBtn:SetAttribute("type", "macro")
    local firstStep = compiledSteps[1]
    local firstMacro = firstStep and firstStep.macrotext or ""
    nativeBtn:SetAttribute("macrotext", firstMacro)
    nativeBtn:SetAttribute("step", 1)
    nativeBtn:SetAttribute("_shouldReset", "0")
    local resetTimer = curVer and curVer.resetTimer or 0
    if resetTimer > 0 then
        nativeBtn:SetAttribute("resetTimer", resetTimer)
    end
    -- Set reset modifier attributes on native button
    local seqResetMods = curVer and curVer.resetModifiers
    local resetMods
    if seqResetMods then
        resetMods = {}
        local globalMods = GRIPEMS.Settings:GetResetModifiers()
        for mod, default in pairs(globalMods) do
            if seqResetMods[mod] ~= nil then
                resetMods[mod] = seqResetMods[mod]
            else
                resetMods[mod] = default
            end
        end
    else
        resetMods = GRIPEMS.Settings:GetResetModifiers()
    end
    for mod, enabled in pairs(resetMods) do
        nativeBtn:SetAttribute("resetMod_" .. mod, enabled and "1" or nil)
    end
    -- The preBody above carries the same channel-hold early return as the two
    -- click bodies, so this button needs the attribute that gates it. Without
    -- this write the hold would be silently inert in hold mode only.
    nativeBtn:SetAttribute("holdOnChannel", curVer and curVer.holdOnChannel and "1" or nil)
    nativeBtn:SetAttribute("releaseAtMax", curVer and curVer.releaseAtMax and "1" or nil)
    nativeBtn:SetAttribute("empowerRelease", nil)
    -- Route keybind via SetOverrideBindingClick (clicks nativeBtn directly)
    -- so WrapScript preBody fires on every press for step advancement.
    -- NOTE: CVar hold-repeat does NOT work with click bindings.
    -- HTC architecture redesign needed -- see Research/HTC/
    --
    -- INVESTIGATION A, 2026-08-11: DOES HOLD MODE EVER BIND THE SAME KEY AS A
    -- SEQUENCE KEYBIND? YES -- ALWAYS, BY CONSTRUCTION. Read the block below.
    --
    --   1. specIdx comes from GetSpecialization(), and binds is
    --      GRIP_EMS_CHAR.keybinds[specIdx]. That is the SAME per-spec table
    --      Engine/KeybindManager.lua pushes its sequence bindings from -- not a
    --      parallel hold-mode table, the identical one.
    --   2. The loop gate is "if seqName == name", so the only key hold mode will
    --      ever bind is a key that ALREADY maps to this sequence in that table,
    --      i.e. a key KeybindManager has already bound to the sequence button.
    --   3. Failing to find one is fatal, not incidental: HMM.activeKey stays nil,
    --      the FS_HOLD_NO_KEYBIND message prints, the WrapScript is unwrapped and
    --      Activate returns false. Hold mode CANNOT run on a key that is not
    --      already a sequence keybind.
    --   4. The bind below passes isPriority = true precisely so it wins that
    --      contest. Wiki, API_SetOverrideBinding: priority overrides beat
    --      non-priority overrides. KeybindManager binds the same key at
    --      NON-priority (six sites: lines 98, 272, 531, 559, 585, 614), so today
    --      hold mode taking over the key is DETERMINISTIC, not a race.
    --
    -- CONSEQUENCE, and the reason this comment exists: flipping those six
    -- KeybindManager sites to priority = true would put both binders at the same
    -- precedence on the same key, and two priority overrides degenerate to
    -- last-writer-wins. Hold mode would then take over the key only when it
    -- happens to bind after KeybindManager, which is ordering-dependent and not
    -- guaranteed. It would not fail today, because TempoAdvisor is parked behind
    -- GRIPEMS._HTC_DEV_ENABLED; it would fail whenever HTC is un-parked, long
    -- after the cause was forgotten. Do NOT flip the sequence path to priority
    -- without first deciding how hold mode is meant to win that contest.
    local specIdx = GetSpecialization() or 1
    local binds = _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.keybinds and GRIP_EMS_CHAR.keybinds[specIdx]
    if binds then
        for key, seqName in pairs(binds) do
            if seqName == name then
                local btnName = nativeBtn:GetName()
                local bindCommand = BUTTON_TO_BIND[btnName] or D().HOLD_MODE_BIND_COMMAND_DEFAULT
                GRIPEMS:Debug(
                    "TA Debug: HMM binding "
                        .. tostring(key)
                        .. " -> click "
                        .. tostring(btnName)
                        .. " (mapped: "
                        .. tostring(bindCommand)
                        .. ")"
                )
                SetOverrideBindingClick(HMM.holdBindOwner, true, key, btnName, "LeftButton")
                HMM.activeKey = key
                break
            end
        end
    end
    if not HMM.activeKey then
        GRIPEMS:Debug("TA Debug: HMM no keybind found for " .. name)
        print("|cFFFF6600[GRIP-EMS]|r " .. L["FS_HOLD_NO_KEYBIND"]:format(name))
        -- Clean up partial activation
        if HMM.previousPollRate then
            C_CVar.SetCVar("UseKeyHeldSpellErrorPollTime", HMM.previousPollRate)
        end
        if HMM.previousHoldCVar then
            C_CVar.SetCVar("ActionButtonUseKeyHeldSpell", HMM.previousHoldCVar)
        end
        -- Unwrap the WrapScript we just set
        if nativeBtn then
            if SecureHandlerUnwrapScript then
                SecureHandlerUnwrapScript(nativeBtn, "OnClick")
            else
                SecureHandlerWrapScript(nativeBtn, "OnClick", HMM.holdBindOwner, "")
            end
            nativeBtn:SetAttribute("type", nil)
            nativeBtn:SetAttribute("macrotext", nil)
        end
        HMM.previousPollRate = nil
        HMM.previousHoldCVar = nil
        return false
    end
    -- Set CVars (OOC guaranteed by guard above)
    C_CVar.SetCVar("ActionButtonUseKeyHeldSpell", "1")
    local pollMs = tostring(math.max(D().HOLD_MODE_POLL_MIN_DEFAULT, recommendedMs))
    C_CVar.SetCVar("UseKeyHeldSpellErrorPollTime", pollMs)
    -- Set insecure methods on native button (before combat)
    nativeBtn.seqName = name
    nativeBtn.seqData = seqData
    nativeBtn.UpdateIcon = function(selfBtn)
        if GRIPEMS.Settings and GRIPEMS.Settings:Get("tempoAdvisorDebug") then
            GRIPEMS:Debug("TA Debug: HMM UpdateIcon called")
        end
        GRIPEMS.Engine:UpdateButtonIcon(selfBtn)
    end
    nativeBtn.HoldDebugStep = function(_selfBtn, stepNum)
        if GRIPEMS.Settings and GRIPEMS.Settings:Get("tempoAdvisorDebug") then
            GRIPEMS:Debug("TA Debug: HMM preBody step=%s", tostring(stepNum))
        end
    end
    nativeBtn.HoldDebugDown = function(_selfBtn, downStr)
        if GRIPEMS.Settings and GRIPEMS.Settings:Get("tempoAdvisorDebug") then
            GRIPEMS:Debug("TA Debug: HMM OnClick down=%s t=%.3f", tostring(downStr), GetTime())
        end
    end
    nativeBtn.PostClick = function(selfBtn)
        local stepAttr = selfBtn:GetAttribute("step") or "?"
        if GRIPEMS.Settings and GRIPEMS.Settings:Get("tempoAdvisorDebug") then
            GRIPEMS:Debug("TA Debug: HMM PostClick fired, step=%s, seq=%s", tostring(stepAttr), tostring(name))
        end
        local now = GetTime()
        local rt = selfBtn:GetAttribute("resetTimer") or 0
        if rt > 0 then
            local lastPress = selfBtn._lastPress or 0
            if lastPress > 0 and (now - lastPress) > rt then
                if not GRIPEMS.OOCQueue.IsRestricted() then
                    selfBtn:SetAttribute("_shouldReset", "1")
                end
            end
            selfBtn._lastPress = now
        end
        local EngineRef = GRIPEMS.Engine
        if EngineRef then
            EngineRef._lastClickedSequence = name
            EngineRef._lastClickTime = now
            local bpt = EngineRef._buttonPressTimes
            if bpt then
                bpt[#bpt + 1] = now
                while #bpt > 0 and (now - bpt[1]) > EngineRef.BUTTON_PRESS_WINDOW do
                    table.remove(bpt, 1)
                end
            end
        end
    end
    -- Mark active
    HMM.active = true
    HMM.activeSequence = name
    HMM.nativeButton = nativeBtn
    if GRIPEMS.Settings and GRIPEMS.Settings:Get("tempoAdvisorDebug") then
        local numC = compiledSteps and #compiledSteps or 0
        GRIPEMS:Debug(
            ("TA Debug: HMM loaded %d steps, poll=%sms, key=%s, btn=%s"):format(
                numC,
                pollMs,
                tostring(HMM.activeKey),
                tostring(nativeBtn:GetName())
            )
        )
    end
    print("|cFF00FF00[GRIP-EMS]|r " .. L["FS_HOLD_ACTIVATED"]:format(name))
    return true
end

function HMM:Deactivate()
    if not HMM.active then
        return
    end
    if InCombatLockdown() then
        GRIPEMS.OOCQueue:Add(function()
            HMM:Deactivate()
        end, D().OOC_OP_GENERIC)
        return
    end
    local nativeBtn = HMM.nativeButton
    ClearOverrideBindings(HMM.holdBindOwner)
    if nativeBtn then
        if SecureHandlerUnwrapScript then
            SecureHandlerUnwrapScript(nativeBtn, "OnClick")
        else
            SecureHandlerWrapScript(nativeBtn, "OnClick", HMM.holdBindOwner, "")
        end
        nativeBtn:SetAttribute("type", nil)
        nativeBtn:SetAttribute("macrotext", nil)
    end
    if HMM.previousPollRate then
        C_CVar.SetCVar("UseKeyHeldSpellErrorPollTime", HMM.previousPollRate)
    end
    if HMM.previousHoldCVar then
        C_CVar.SetCVar("ActionButtonUseKeyHeldSpell", HMM.previousHoldCVar)
    end
    HMM.active = false
    HMM.activeSequence = nil
    HMM.activeKey = nil
    HMM.nativeButton = nil
    HMM.previousPollRate = nil
    HMM.previousHoldCVar = nil
    print("|cFF00FF00[GRIP-EMS]|r " .. L["FS_HOLD_DEACTIVATED"])
end

function HMM:IsActiveForSequence(name)
    return self.active and self.activeSequence == name
end

function HMM:IsActive()
    return self.active
end

function TA:GetActiveMode(sequenceName)
    if sequenceName then
        return TA:IsHoldMode(sequenceName) and HMM:IsActiveForSequence(sequenceName) and "hold" or "spam"
    end
    return HMM:IsActive() and "hold" or "spam"
end

function TA:SetHoldMode(sequenceName, enabled)
    if not sequenceName then
        return
    end
    local specID = self:GetCurrentSpecID()
    if not _G.GRIP_EMS_CHAR then
        return
    end
    if not GRIP_EMS_CHAR.tempoHoldMode then
        GRIP_EMS_CHAR.tempoHoldMode = {}
    end
    if not GRIP_EMS_CHAR.tempoHoldMode[specID] then
        GRIP_EMS_CHAR.tempoHoldMode[specID] = {}
    end
    GRIP_EMS_CHAR.tempoHoldMode[specID][sequenceName] = enabled or nil
    -- If we just disabled hold mode for the active sequence, deactivate
    if not enabled and HMM:IsActiveForSequence(sequenceName) then
        HMM:Deactivate()
    end
    if GRIPEMS.Fire then
        GRIPEMS:Fire("HOLD_MODE_CHANGED", sequenceName, enabled)
    end
    -- Activate HMM for already-active sequences
    if enabled then
        local holdS = GRIPEMS.Settings
        if holdS and holdS:Get("holdModeEnabled") then
            local eng = Engine()
            if eng and eng.sequences and eng.sequences[sequenceName] then
                local entry = eng.sequences[sequenceName]
                if entry.data and entry.button then
                    local rec = TA:GetRecommendation(sequenceName)
                    local ms = rec and rec.recommendedMs or 250
                    HMM:Activate(sequenceName, entry.data, ms)
                end
            end
        end
    end
end

--- Re-key the per-spec hold-mode preference when a sequence is
--- renamed. The store is GRIP_EMS_CHAR.tempoHoldMode[specID][name];
--- without this a rename orphans the preference and the renamed
--- sequence silently reverts to spam mode. Walks EVERY spec bucket
--- (prefs may exist on non-current specs).
--- @param oldName string The name being replaced
--- @param newName string The new sequence name
function TA:RenameHoldMode(oldName, newName)
    if not oldName or not newName or oldName == newName then
        return
    end
    if not _G.GRIP_EMS_CHAR or not GRIP_EMS_CHAR.tempoHoldMode then
        return
    end
    for _, bucket in pairs(GRIP_EMS_CHAR.tempoHoldMode) do
        if bucket[oldName] ~= nil then
            bucket[newName] = bucket[oldName]
            bucket[oldName] = nil
        end
    end
end

function TA:GetHoldModePollRate()
    return tonumber(C_CVar.GetCVar("UseKeyHeldSpellErrorPollTime")) or 0
end

-- GetLiveGCD: live GCD in milliseconds, haste-scaled with floor.
-- WoW 12.0+ secret-value defense: GetHaste() returns a secret-
-- tagged number; arithmetic on it from addon-tainted code raises
-- a Lua error. pcall the formula and fall back to the no-haste
-- baseline (1500ms) when the secret tag blocks the math.
-- See reference_wow_12_0_secret_values memory + Mudds 2026-05-15 repro.
function TA:GetLiveGCD()
    local okCD, spellCD = SafeGetSpellCooldown(GCD_SPELL_ID)
    if okCD and spellCD and spellCD.duration and spellCD.duration > 0 then
        return math.max(CLASS_GCD_FLOOR, spellCD.duration * 1000)
    end
    local haste = GetHaste() or 0
    local ok, gcd = pcall(function()
        return math.max(CLASS_GCD_FLOOR, math.floor(1500 / (1 + haste / 100)))
    end)
    if ok and gcd then
        return gcd
    end
    -- Secret-value taint blocked the haste arithmetic. Return the
    -- ungated baseline (== 0% haste result), still floor-respecting
    -- via math.max with CLASS_GCD_FLOOR.
    return math.max(CLASS_GCD_FLOOR, 1500)
end

-- GetCurrentSpecID
function TA:GetCurrentSpecID()
    local si = GetSpecialization()
    return si and GetSpecializationInfo(si) or 0
end

function TA:IsHoldMode(sequenceName)
    if not _G.GRIP_EMS_CHAR or not GRIP_EMS_CHAR.tempoHoldMode then
        return false
    end
    local specID = self:GetCurrentSpecID()
    local specHold = GRIP_EMS_CHAR.tempoHoldMode[specID]
    return specHold and specHold[sequenceName] or false
end

-- ClassifySpell: determine timing category for a spell
function TA:ClassifySpell(spellNameOrID)
    if not spellNameOrID then
        return CAT_UNKNOWN
    end
    local cache = SC()
    if not cache or not cache.byName then
        return CAT_UNKNOWN
    end

    local entry
    if type(spellNameOrID) == "number" then
        for _, e in ipairs(cache.spells) do
            if e.spellID == spellNameOrID then
                entry = e
                break
            end
        end
    else
        -- Try numeric string -> spellID lookup first (e.g. "34026" from imported macrotext)
        local numID = tonumber(spellNameOrID)
        if numID then
            for _, e in ipairs(cache.spells) do
                if e.spellID == numID then
                    entry = e
                    break
                end
            end
        end
        if not entry then
            entry = cache.byName[strlower(spellNameOrID)]
        end
    end
    if not entry or not entry.spellID then
        -- Fallback: try WoW API directly for non-spellbook spells (item use-effects, consumables)
        local okInfo, spellInfo = pcall(C_Spell.GetSpellInfo, spellNameOrID)
        -- If name lookup failed, try item spell ID lookup
        if (not okInfo or not spellInfo or not spellInfo.spellID) and type(spellNameOrID) == "string" then
            local itemSpellID = self._itemSpellIDs[strlower(spellNameOrID)]
            if itemSpellID then
                okInfo, spellInfo = pcall(C_Spell.GetSpellInfo, itemSpellID)
            end
        end
        if okInfo and spellInfo and spellInfo.spellID then
            local spellID = spellInfo.spellID
            if self.spellClassCache[spellID] then
                return self.spellClassCache[spellID]
            end
            local castTime = spellInfo.castTime or 0
            local gcdMS = 0
            local okGCD, _, baseGCD = pcall(GetSpellBaseCooldown, spellID)
            if okGCD and baseGCD then
                gcdMS = baseGCD
            end
            entry = { spellID = spellID, castTime = castTime, gcdMS = gcdMS }
        else
            return CAT_UNKNOWN
        end
    end

    local spellID = entry.spellID
    if self._runtimeOverrides[spellID] then
        return self._runtimeOverrides[spellID]
    end
    if self.spellClassCache[spellID] then
        return self.spellClassCache[spellID]
    end

    local castTime = entry.castTime or 0
    local gcdMS = entry.gcdMS or 0
    -- Override gcdMS for spells known to be off-GCD despite API reporting otherwise
    if KNOWN_OFF_GCD_SPELLS[spellID] then
        gcdMS = 0
        if GRIPEMS.Settings and GRIPEMS.Settings:Get("tempoAdvisorDebug") then
            local okName, sname = pcall(C_Spell.GetSpellName, spellID)
            GRIPEMS:Debug(
                ("TA Debug: %s (%d) gcdMS override -> 0 (KNOWN_OFF_GCD)"):format(
                    okName and sname or tostring(spellID),
                    spellID
                )
            )
        end
    end
    local result

    -- Runtime GCD probe: when GCD is currently active, we can definitively
    -- detect off-GCD spells. SpellCooldownInfo does NOT have a gcdDuration
    -- field (only startTime, duration, isEnabled, modRate), so we compare
    -- the spell's cooldown against the active GCD instead.
    -- Off-GCD spells show duration=0 while the GCD is active.
    local okGCDProbe, gcdCDInfo = SafeGetSpellCooldown(GCD_SPELL_ID)
    if okGCDProbe and gcdCDInfo and gcdCDInfo.duration and gcdCDInfo.duration > 0 then
        -- GCD is currently active -- we can distinguish off-GCD spells
        local okSpellCD, spellCDInfo = SafeGetSpellCooldown(spellID)
        if okSpellCD and spellCDInfo and spellCDInfo.duration == 0 then
            -- Spell has NO cooldown while GCD is active = definitively off-GCD
            if gcdMS > 0 then
                gcdMS = 0
            end
        end
    end

    local okSub, subtext = pcall(C_Spell.GetSpellSubtext, spellID)
    if okSub and subtext and type(subtext) == "string" and subtext:find("Channeled") then
        result = CAT_CHANNEL
    elseif gcdMS == 0 and castTime == 0 then
        result = CAT_OFF_GCD
    elseif gcdMS > 0 and castTime == 0 then
        result = CAT_ON_GCD_INSTANT
    elseif gcdMS > 0 and castTime > 0 and castTime <= self:GetLiveGCD() then
        result = CAT_ON_GCD_CAST
    elseif castTime > self:GetLiveGCD() then
        result = CAT_LONG_CAST
    else
        result = CAT_UNKNOWN
    end

    self.spellClassCache[spellID] = result
    return result
end

-- ExtractSpellsFromStep: parse macro text for spell references
function TA:ExtractSpellsFromStep(macroText)
    if type(macroText) ~= "string" or macroText == "" then
        return {}
    end
    local eng = Engine()
    if eng and eng.SubstituteVariables then
        local ok, resolved = pcall(eng.SubstituteVariables, eng, macroText)
        if ok and type(resolved) == "string" then
            macroText = resolved
        end
    end
    local results = {}
    local sv = GRIPEMS.SpellValidator
    if sv and sv.ExtractAllSpells then
        for _, e in ipairs(sv:ExtractAllSpells(macroText)) do
            if e.name and e.command ~= "showtooltip" and strlower(e.name) ~= "null" then
                results[#results + 1] = e.name
            end
        end
    end

    -- Resolve /use <slot> patterns (trinket on-use effects)
    -- Slot 13 = trinket 1, slot 14 = trinket 2, etc.
    for line in macroText:gmatch("[^\n]+") do
        local slot = line:match("^/use%s+(%d+)%s*$")
        if not slot then
            slot = line:match("^/use%s+%[.-%]%s*(%d+)%s*$")
        end
        if slot then
            local slotNum = tonumber(slot)
            if slotNum then
                local itemID = GetInventoryItemID("player", slotNum)
                if itemID then
                    local okSpell, spellName, spellID = pcall(C_Item.GetItemSpell, itemID)
                    if okSpell and spellName then
                        results[#results + 1] = spellName
                        if spellID then
                            TA._itemSpellIDs[strlower(spellName)] = spellID
                        end
                    end
                end
            end
        end
        -- Also match /use <itemname> (by name, no slot number)
        local itemName = line:match("^/use%s+%[.-%]%s*([^%d].+)$")
        if not itemName then
            itemName = line:match("^/use%s+([^%d%[].+)$")
        end
        if itemName then
            itemName = strtrim(itemName)
            local okItem, itemSpellName = pcall(function()
                local _, link = C_Item.GetItemInfo(itemName)
                if link then
                    local id = tonumber(link:match("item:(%d+)"))
                    if id then
                        return C_Item.GetItemSpell(id)
                    end
                end
                return nil
            end)
            if okItem and itemSpellName then
                results[#results + 1] = itemSpellName
            end
        end
    end

    return results
end

-- Tightness ranking for picking the most constraining category per step
local CATEGORY_TIGHTNESS = {
    [CAT_OFF_GCD] = 1,
    [CAT_ON_GCD_INSTANT] = 3,
    [CAT_ON_GCD_CAST] = 4,
    [CAT_LONG_CAST] = 5,
    [CAT_CHANNEL] = 6,
    [CAT_UNKNOWN] = 3,
}

-- ENH-CATEGORY-TIGHTNESS-RANKING Option (4): complexity-contribution
-- ranking. INVERSE of CATEGORY_TIGHTNESS for OFF_GCD vs ON_GCD --
-- on-GCD spells outrank off-GCD utility for complexity classification
-- purposes. Mixed steps where a damage spell shares the step with a
-- utility passenger classify as the damage category (the player
-- perceives the step as a damage cast, not a utility cast). Long
-- casts and channels rank highest because they dominate perceived
-- complexity regardless of any utility passenger.
local CATEGORY_COMPLEXITY = {
    [CAT_LONG_CAST] = 1,
    [CAT_CHANNEL] = 2,
    [CAT_ON_GCD_CAST] = 3,
    [CAT_ON_GCD_INSTANT] = 4,
    [CAT_UNKNOWN] = 5,
    [CAT_OFF_GCD] = 6,
}

-- ComputeTransition: time in ms before next press matters
function TA:ComputeTransition(category, entry)
    if category == CAT_OFF_GCD then
        return 0
    elseif category == CAT_PAUSE_CLICKS then
        return nil -- excluded from tightestWindow per spec
    elseif category == CAT_LONG_CAST or category == CAT_CHANNEL then
        local castTime = entry and entry.castTime or 0
        return castTime > 0 and castTime or self:GetLiveGCD()
    end
    return self:GetLiveGCD() -- ON_GCD_INSTANT, ON_GCD_CAST, UNKNOWN
end

-- GetTransitionParams: SQW + latency for effective window calc
function TA:GetTransitionParams()
    local sqwOpt = SQW()
    local sqw = (sqwOpt and sqwOpt.IsActive and sqwOpt:IsActive() and sqwOpt.lastAppliedSQW)
        or tonumber(GetCVar("SpellQueueWindow"))
        or 400
    local _, _, _, lat = GetNetStats()
    lat = lat or 0
    if GRIPEMS.Settings and GRIPEMS.Settings:Get("tempoAdvisorDebug") then
        local sqwOptActive = sqwOpt and sqwOpt.IsActive and sqwOpt:IsActive()
        local sqwOptVal = sqwOpt and sqwOpt.lastAppliedSQW
        local cvarVal = GetCVar("SpellQueueWindow")
        GRIPEMS:Debug(
            ("  GetTransitionParams: sqwOpt.active=%s sqwOpt.val=%s CVar=%s => sqw=%d lat=%d"):format(
                tostring(sqwOptActive),
                tostring(sqwOptVal),
                tostring(cvarVal),
                sqw,
                lat
            )
        )
    end
    return sqw, lat
end

-- ComputeComplexity: determine sequence complexity tier
function TA:ComputeComplexity(cats)
    if not cats or #cats == 0 then
        return COMPLEXITY_STANDARD
    end
    local offGCD, onGCD, longCh, consOff, maxCons = false, false, false, 0, 0
    for _, c in ipairs(cats) do
        if c == CAT_OFF_GCD then
            offGCD = true
            consOff = consOff + 1
            if consOff > maxCons then
                maxCons = consOff
            end
        else
            consOff = 0
            if c == CAT_ON_GCD_INSTANT or c == CAT_ON_GCD_CAST then
                onGCD = true
            end
            if c == CAT_LONG_CAST or c == CAT_CHANNEL then
                longCh = true
            end
        end
    end
    if maxCons >= 2 then
        return COMPLEXITY_INTENSE
    end
    if offGCD and (onGCD or longCh) then
        return COMPLEXITY_DEMANDING
    end
    if longCh and not onGCD and not offGCD then
        return COMPLEXITY_RELAXED
    end
    return COMPLEXITY_STANDARD
end

-- AnalyzeSequence: full per-sequence timing analysis
function TA:AnalyzeSequence(name, seqData)
    if not seqData then
        return nil, "No sequence data"
    end

    -- Refuse analysis while the spell cache is empty (login-order
    -- race): every spell would classify UNKNOWN and the stored
    -- recommendation would be junk (fallback rec + huge
    -- unknownCount). Callers either defer (OnSequenceActivated)
    -- or surface this reason string.
    local scGate = SC()
    if not (scGate and scGate.ready) then
        return nil, "Spell cache not ready"
    end

    -- 2-second debounce: prevent re-analysis spam from rapid callbacks
    local now = GetTime()
    local lastTime = self._lastAnalysisTime[name] or 0
    if (now - lastTime) < 2 then
        return nil, "Debounced"
    end
    self._lastAnalysisTime[name] = now

    local eng = Engine()
    if not eng then
        return nil, "Engine not loaded"
    end

    local ver = eng:GetActiveVersion(seqData)
    if not ver then
        return nil, "No active version"
    end

    local steps = ver.steps
    if not steps or #steps == 0 then
        return nil, "No steps to analyze"
    end

    local stepFunction = ver.stepFunction or D().STEP_SEQUENTIAL
    local sqw, latency = self:GetTransitionParams()

    -- Resolve and optionally expand steps
    wipe(_resolvedSteps)
    local resolvedSteps = _resolvedSteps
    for i = 1, #steps do
        local sc = SC()
        local stepStr = (sc and sc.StepToString) and sc:StepToString(steps[i]) or tostring(steps[i])
        local resolved = eng:SubstituteVariables(stepStr)
        resolvedSteps[i] = resolved
    end

    -- Expand for Priority/ReversePriority
    local analysisSteps = resolvedSteps
    local sf = SF()
    local expandFn = nil
    if stepFunction == D().STEP_PRIORITY and sf then
        expandFn = sf.ExpandPriority
    elseif stepFunction == D().STEP_REVERSE_PRIORITY and sf then
        expandFn = sf.ExpandReversePriority
    end
    if expandFn then
        local expanded = expandFn(sf, resolvedSteps)
        analysisSteps = {}
        for _, attr in ipairs(expanded) do
            analysisSteps[#analysisSteps + 1] = attr.macrotext or ""
        end
    end
    if #analysisSteps == 0 then
        return nil, "No steps after expansion"
    end

    -- Classify each step
    wipe(_stepCategories)
    wipe(_stepComplexityCategories)
    local stepCategories = _stepCategories
    local stepComplexityCategories = _stepComplexityCategories
    local spellCategories = {} -- per-step detail
    local unknownCount = 0

    for i = 1, #analysisSteps do
        local stepText = analysisSteps[i]
        -- Pause detection: raw steps with action type pause (Sequential/Random only)
        local isPause = false
        if ver.actions and (stepFunction == D().STEP_SEQUENTIAL or stepFunction == D().STEP_RANDOM) then
            local rawStep = i <= #steps and steps[i] or nil
            if type(rawStep) == "table" and rawStep.type == D().ACTION_TYPE_PAUSE then
                isPause = true
            end
        end
        if isPause then
            stepCategories[i] = CAT_PAUSE_CLICKS
            stepComplexityCategories[i] = CAT_PAUSE_CLICKS
            spellCategories[i] = { category = CAT_PAUSE_CLICKS, spells = {} }
        else
            local spellNames = self:ExtractSpellsFromStep(stepText)
            local spellDetail = {}
            local tightest, tightRank = CAT_UNKNOWN, 999
            local complexityCategory, complexityRank = CAT_UNKNOWN, 999
            for _, sn in ipairs(spellNames) do
                local sc = self:ClassifySpell(sn)
                spellDetail[#spellDetail + 1] = { name = sn, category = sc }
                if sc == CAT_UNKNOWN then
                    unknownCount = unknownCount + 1
                end
                -- Track ON_GCD_INSTANT spells for combat GCD verification
                if sc == CAT_ON_GCD_INSTANT then
                    local verifyCache = SC()
                    local verifyEntry
                    if verifyCache and verifyCache.byName and type(sn) == "string" then
                        -- Try numeric string -> spellID lookup first (mirrors ClassifySpell S7 fix)
                        local numID = tonumber(sn)
                        if numID and verifyCache.spells then
                            for _, e in ipairs(verifyCache.spells) do
                                if e.spellID == numID then
                                    verifyEntry = e
                                    break
                                end
                            end
                        end
                        if not verifyEntry then
                            verifyEntry = verifyCache.byName[strlower(sn)]
                        end
                    end
                    if verifyEntry and verifyEntry.spellID then
                        TA._pendingVerification[verifyEntry.spellID] = true
                    end
                end
                local rank = CATEGORY_TIGHTNESS[sc] or 999
                if rank < tightRank then
                    tightRank, tightest = rank, sc
                end
                local cxRank = CATEGORY_COMPLEXITY[sc] or 999
                if cxRank < complexityRank then
                    complexityRank, complexityCategory = cxRank, sc
                end
            end
            stepCategories[i] = tightest
            stepComplexityCategories[i] = complexityCategory
            spellCategories[i] = { category = tightest, spells = spellDetail }
        end
    end

    -- Compute transitions
    wipe(_transitions)
    local transitions = _transitions
    local isRandom = (stepFunction == D().STEP_RANDOM)
    local numSteps = #analysisSteps

    local function addTransition(fromIdx, toIdx)
        local cat = stepCategories[fromIdx]
        if cat == CAT_PAUSE_CLICKS then
            return
        end
        local spellEntry = self:LookupFirstSpellEntry(analysisSteps[fromIdx])
        local trans = self:ComputeTransition(cat, spellEntry)
        if trans then
            transitions[#transitions + 1] = { from = fromIdx, to = toIdx, category = cat, ms = trans }
        end
    end

    if isRandom then
        for i = 1, numSteps do
            for j = 1, numSteps do
                if i ~= j then
                    addTransition(i, j)
                end
            end
        end
    else
        for i = 1, numSteps do
            addTransition(i, (i % numSteps) + 1)
        end
    end

    -- Compute recommended interval = min of all effective windows
    local recommendedMs = nil
    for _, t in ipairs(transitions) do
        local ew = t.category == CAT_OFF_GCD and MIN_CLICK_RATE
            or math.max(MIN_CLICK_RATE, math.floor(t.ms - sqw + latency))
        if not recommendedMs or ew < recommendedMs then
            recommendedMs = ew
        end
    end
    recommendedMs = recommendedMs or MIN_CLICK_RATE

    local complexity = self:ComputeComplexity(stepComplexityCategories)
    local theoreticalConfidence = unknownCount > 0 and "Estimated" or "Precise"

    -- Count off-GCD steps for overlay display
    local offGCDCount = 0
    for _, cat in ipairs(stepComplexityCategories) do
        if cat == CAT_OFF_GCD then
            offGCDCount = offGCDCount + 1
        end
    end

    if GRIPEMS.Settings and GRIPEMS.Settings:Get("tempoAdvisorDebug") then
        GRIPEMS:Debug("--- TA Debug: AnalyzeSequence ---")
        GRIPEMS:Debug("  Sequence: %s", name)
        GRIPEMS:Debug("  GCD (live): %.0fms", self:GetLiveGCD())
        local dbgSqw, dbgLat = self:GetTransitionParams()
        GRIPEMS:Debug("  SQW: %d  Latency: %d", dbgSqw, dbgLat)
        GRIPEMS:Debug(
            "  SQW source: optimizer=%s  CVar=%s",
            tostring(GRIPEMS.SQWOptimizer and GRIPEMS.SQWOptimizer:IsActive() and GRIPEMS.SQWOptimizer.lastAppliedSQW),
            tostring(GetCVar("SpellQueueWindow"))
        )
        GRIPEMS:Debug("  Steps: %d  Transitions: %d  Unknown: %d", #analysisSteps, #transitions, unknownCount)
        -- Per-step spell detail
        for si, sc in ipairs(spellCategories) do
            local parts = {}
            for _, s in ipairs(sc.spells or {}) do
                parts[#parts + 1] = s.name .. "(" .. s.category .. ")"
            end
            GRIPEMS:Debug(
                "  S%d: tight=%s cx=%s [%s]",
                si,
                sc.category or "?",
                stepComplexityCategories[si] or "?",
                #parts > 0 and table.concat(parts, ", ") or "no spells extracted"
            )
        end
        for ti, t in ipairs(transitions) do
            local ew = t.category == CAT_OFF_GCD and MIN_CLICK_RATE
                or math.max(MIN_CLICK_RATE, math.floor(t.ms - dbgSqw + dbgLat))
            GRIPEMS:Debug("  T%d: %s ms=%.0f ew=%d", ti, t.category, t.ms, ew)
        end
        GRIPEMS:Debug(
            "  => recommendedMs = %d  complexity = %s  confidence = %s",
            recommendedMs,
            complexity,
            theoreticalConfidence
        )
    end

    -- NOTE: transitions is aliased to module-level _transitions (reused via wipe).
    -- Currently safe: no caller retains this result across AnalyzeSequence calls.
    -- If you add result caching, deep-copy transitions first.
    local result = {
        recommendedMs = recommendedMs,
        complexity = complexity,
        transitions = transitions,
        spellCategories = spellCategories,
        unknownCount = unknownCount,
        offGCDCount = offGCDCount,
        theoreticalConfidence = theoreticalConfidence,
    }
    -- Store summary in SavedVariables (exclude large debug arrays).
    -- Freshness timestamp is kept in a module-level table, never in SVs
    -- (GetTime() resets on /reload and would corrupt cross-session deltas).
    local specID = self:GetCurrentSpecID()
    self:StoreRecommendation(specID, name, {
        recommendedMs = recommendedMs,
        theoreticalMs = recommendedMs,
        complexity = complexity,
        unknownCount = unknownCount,
        offGCDCount = offGCDCount,
        theoreticalConfidence = theoreticalConfidence,
    })
    TA._recFreshness[specID] = TA._recFreshness[specID] or {}
    TA._recFreshness[specID][name] = GetTime()
    return result
end

-- LookupFirstSpellEntry: find SpellCache entry for first spell in a step
function TA:LookupFirstSpellEntry(macroText)
    local spells = self:ExtractSpellsFromStep(macroText)
    if #spells == 0 then
        return nil
    end
    local cache = SC()
    if not cache or not cache.byName then
        return nil
    end
    return cache.byName[strlower(spells[1])]
end

-- SavedVariables: store/retrieve per-spec per-sequence recommendations
function TA:StoreRecommendation(specID, seqName, data)
    if not _G.GRIP_EMS_CHAR then
        return
    end
    GRIP_EMS_CHAR.tempoAdvisor = GRIP_EMS_CHAR.tempoAdvisor or {}
    GRIP_EMS_CHAR.tempoAdvisor[specID] = GRIP_EMS_CHAR.tempoAdvisor[specID] or {}
    local existing = GRIP_EMS_CHAR.tempoAdvisor[specID][seqName]
    if existing then
        -- Guard: if Tier3 has set a blendedMs and this update is from
        -- theoretical-only analysis (no blendedMs key), preserve the
        -- existing recommendedMs so the blend is not overwritten.
        local preserveBlend = existing.blendedMs and not data.blendedMs
        for k, v in pairs(data) do
            if not (preserveBlend and k == "recommendedMs") then
                existing[k] = v
            end
        end
    else
        GRIP_EMS_CHAR.tempoAdvisor[specID][seqName] = data
    end
end

function TA:GetEffectiveConfidence(rec)
    if not rec then
        return nil
    end
    if rec.empiricalConfidence == "Calibrated" and (rec.unknownCount or 0) == 0 then
        return "Calibrated"
    end
    return rec.theoreticalConfidence or rec.empiricalConfidence or "Unknown"
end

function TA:GetRecommendation(name)
    if not _G.GRIP_EMS_CHAR or not GRIP_EMS_CHAR.tempoAdvisor then
        return nil
    end
    local specData = GRIP_EMS_CHAR.tempoAdvisor[self:GetCurrentSpecID()]
    return specData and specData[name] or nil
end

-- InvalidateSpellCache: clear classification cache on talent/spec change
function TA:InvalidateSpellCache()
    wipe(self.spellClassCache)
    self._gcdVerified = false
    if GRIPEMS.Settings and GRIPEMS.Settings:Get("tempoAdvisorDebug") then
        GRIPEMS:Debug("TA Debug: spell classification cache cleared")
    end
end

-- InvalidateHasteDependentSpellCache: selective invalidation on UNIT_SPELL_HASTE.
-- Haste changes the castTime <-> GetLiveGCD() relationship, so cached
-- CAT_ON_GCD_CAST and CAT_LONG_CAST classifications can flip across the
-- boundary (both scale with haste at different rates; GCD floors at
-- CLASS_GCD_FLOOR while castTime keeps shrinking linearly). CAT_OFF_GCD,
-- CAT_ON_GCD_INSTANT, and CAT_CHANNEL are haste-independent (zero cast
-- time stays zero, base gcdMS stays nonzero, channel subtext metadata
-- does not change with haste). CAT_UNKNOWN is dropped defensively.
-- Also resets _gcdVerified so the GCD-probe scanner re-measures against
-- the new haste-scaled GCD on the next cast.
function TA:InvalidateHasteDependentSpellCache()
    if not self.spellClassCache then
        return
    end
    local kept, dropped = 0, 0
    for spellID, classification in pairs(self.spellClassCache) do
        if classification == CAT_ON_GCD_CAST or classification == CAT_LONG_CAST or classification == CAT_UNKNOWN then
            self.spellClassCache[spellID] = nil
            dropped = dropped + 1
        else
            kept = kept + 1
        end
    end
    self._gcdVerified = false
    if GRIPEMS.Settings and GRIPEMS.Settings:Get("tempoAdvisorDebug") then
        GRIPEMS:Debug(string.format("TA Debug: haste invalidation kept=%d dropped=%d", kept, dropped))
    end
end

-- PrintStatus: /gems fs output
function TA:PrintStatus(arg)
    local eng = Engine()
    if not eng or not eng.sequences then
        GRIPEMS:Print(L["FS_NO_SEQUENCE"])
        return
    end

    local seqName = arg and arg ~= "" and arg or eng._lastClickedSequence
    if not seqName then
        GRIPEMS:Print(L["FS_NO_SEQUENCE"])
        return
    end

    local entry = eng.sequences[seqName]
    if not entry or not entry.data then
        for sn, se in pairs(eng.sequences) do
            if strlower(sn) == strlower(seqName) then
                entry = se
                seqName = sn
                break
            end
        end
    end
    if not entry or not entry.data then
        GRIPEMS:Print(L["FS_NO_SEQUENCE"])
        return
    end

    GRIPEMS:Print(string.format(L["FS_ANALYZING"], seqName))
    local result, err = self:AnalyzeSequence(seqName, entry.data)
    if not result then
        GRIPEMS:Print(err or L["FS_NO_STEPS"])
        return
    end
    self:PrintResult(seqName, result)
end

-- PrintResult: format analysis output
local COMPLEXITY_LABELS = {
    [COMPLEXITY_RELAXED] = "FS_COMPLEXITY_RELAXED",
    [COMPLEXITY_STANDARD] = "FS_COMPLEXITY_STANDARD",
    [COMPLEXITY_DEMANDING] = "FS_COMPLEXITY_DEMANDING",
    [COMPLEXITY_INTENSE] = "FS_COMPLEXITY_INTENSE",
}

function TA:PrintResult(name, result)
    local cps = result.recommendedMs > 0 and math.floor(1000 / result.recommendedMs) or 0
    GRIPEMS:Print("--- " .. L["FS_STATUS_HEADER"] .. ": " .. name .. " ---")
    GRIPEMS:Print(string.format(L["FS_RECOMMENDED"], result.recommendedMs, cps))
    local labelKey = COMPLEXITY_LABELS[result.complexity]
    GRIPEMS:Print(string.format(L["FS_COMPLEXITY"], labelKey and L[labelKey] or result.complexity))
    if result.unknownCount > 0 then
        GRIPEMS:Print(string.format(L["FS_UNKNOWN_SPELLS"], result.unknownCount))
    end
    if self.debugMode and result.spellCategories then
        for i, sc in ipairs(result.spellCategories) do
            local parts = {}
            for _, s in ipairs(sc.spells or {}) do
                parts[#parts + 1] = s.name .. "(" .. s.category .. ")"
            end
            GRIPEMS:Print(string.format("  Step %d: %s [%s]", i, sc.category or "?", table.concat(parts, ", ")))
        end
        local sqw, lat = self:GetTransitionParams()
        GRIPEMS:Print(string.format("  GCD=%.0fms SQW=%d Lat=%d", self:GetLiveGCD(), sqw, lat))
    end
end

-- OnSequenceActivated: called by Engine:ActivateSequence after step loading
-- Runs analysis if not cached/fresh, applies auto-set if enabled, fires callback
function TA:OnSequenceActivated(name, seqData)
    if not name or not seqData then
        return
    end
    -- Defer until the spell cache is ready. At login,
    -- RestoreSavedSequences activates sequences before the first
    -- Scan completes; analyzing against an empty cache classifies
    -- every spell UNKNOWN and persists junk recommendations
    -- (observed unknownCount 61/78/402 with fallback recs). Parked
    -- names are drained by the SPELL_CACHE_REFRESHED callback.
    local scGate = SC()
    if not (scGate and scGate.ready) then
        TA._deferredActivation[name] = true
        return
    end
    TA._deferredActivation[name] = nil
    local specID = self:GetCurrentSpecID()

    -- Check if cached result is still fresh (within 60s). Freshness is
    -- tracked per session in TA._recFreshness because GetTime() resets on
    -- /reload -- a persisted timestamp would read as the current session's
    -- GetTime() minus a huge number and incorrectly look "fresh".
    local existing = self:GetRecommendation(name)
    local freshBySpec = TA._recFreshness[specID]
    local freshAt = freshBySpec and freshBySpec[name]
    if not existing or not freshAt or (GetTime() - freshAt) >= 60 then
        local result = self:AnalyzeSequence(name, seqData)
        if not result then
            return
        end
    end

    -- Apply auto-set if enabled and no manual override.
    -- Scope: only the last-clicked (in-use) sequence may drive the
    -- global msClickRate. Bulk activation passes (login restore,
    -- combat-enter reactivation, variable updates, cache refresh)
    -- previously queued one msClickRate write PER ACTIVE SEQUENCE and
    -- the last writer won (observed: 24 replaced-setting OOC queue
    -- entries in one session, profile value stomped 2383 to 1335).
    local S = GRIPEMS.Settings
    local engScope = Engine()
    local isCurrentSequence = engScope and engScope._lastClickedSequence == name
    if S and S:Get("tempoAutoSet") and isCurrentSequence then
        local rec = self:GetRecommendation(name)
        if rec and rec.recommendedMs then
            -- Check for manual override
            local hasOverride = false
            if _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.tempoManualOverride then
                local specOverrides = GRIP_EMS_CHAR.tempoManualOverride[specID]
                if specOverrides and specOverrides[name] then
                    hasOverride = true
                end
            end
            if not hasOverride then
                if InCombatLockdown() then
                    GRIPEMS.OOCQueue:Add(function()
                        S:Set("msClickRate", rec.recommendedMs)
                    end, D().OOC_OP_SETTING, "msClickRate")
                else
                    S:Set("msClickRate", rec.recommendedMs)
                end
            end
        end
    end

    -- Hold Mode: activate native button routing if enabled for this sequence
    -- HTC PARKED: holdModeEnabled is force-hidden, but belt-and-suspenders:
    local holdS = GRIPEMS.Settings
    if holdS and holdS:Get("holdModeEnabled") and TA:IsHoldMode(name) then
        if not HMM.active or HMM.activeSequence ~= name then
            local rec = self:GetRecommendation(name)
            local ms = rec and rec.recommendedMs or 250
            HMM:Activate(name, seqData, ms)
        end
    elseif HMM.active and HMM.activeSequence == name then
        -- Sequence re-activated but hold mode disabled: deactivate
        HMM:Deactivate()
    end

    -- Fire callback for UI updates
    if GRIPEMS.Fire then
        GRIPEMS:Fire("TEMPO_RECOMMENDATION_UPDATED", name)
    end
end

---------------------------------------------------------------------------
-- Tier 3: Adaptive Learning (ExecutionTracer integration)
---------------------------------------------------------------------------
TA._lastEmpiricalUpdate = 0
TA._empiricalStaleState = "stale" -- hysteresis state: "stale" or "fresh"
TA._mismatchSlowStart = 0
TA._mismatchFastStart = 0
TA._adjustedNotifyAt = TA._adjustedNotifyAt or {} -- [specID.."::"..name] = GetTime()
local STALE_ENTER_THRESHOLD = 12 -- seconds; cross to stale when empiricalAge exceeds this
local STALE_EXIT_THRESHOLD = 7 -- seconds; cross back to fresh when empiricalAge drops below this
local BLEND_SMOOTH_ALPHA = 0.3 -- new-sample weight in low-pass on blended output (0..1)
local BLEND_THEORETICAL = 0.7
local BLEND_EMPIRICAL = 0.3
local SIGNIFICANT_DIFF_RATIO = 0.20 -- 20%
local FS_ADJUSTED_COOLDOWN = 60 -- seconds
local MISMATCH_SLOW_SECONDS = 3
local MISMATCH_FAST_SECONDS = 5
local EMPIRICAL_MIN_PRESS_CPS = 0.5 -- presses/sec floor; below this the player is idle, skip empirical ingestion
local EMPIRICAL_MIN_CASTS = 3 -- min casts inside the 10s spellStats window for a valid empirical sample
local BLEND_CLAMP_RATIO = 2.0 -- blended output clamped to theoretical/ratio .. theoretical*ratio
local BLEND_ABS_CAP_MS = 2500 -- absolute ceiling on blended output (ms)
local SMOOTH_RESET_RATIO = 0.5 -- divergence ratio above which smoothed state resets to the raw blend

function TA:OnExecutionTracerUpdate(name, clickTimes, spellStats)
    local eng = Engine()
    local bpt = eng and eng._buttonPressTimes
    if not name or (not bpt or #bpt < 3) then
        return
    end

    local now = GetTime()
    local S = GRIPEMS.Settings

    -- 1) Compute actual CPS from Engine button presses (real player input rate)
    -- ET._clickTimes tracks CLEU spell output (~0.3/sec); Engine._buttonPressTimes
    -- tracks actual keybind presses (~2.8/sec). Use the latter for input rate.
    local actualCPS = eng and eng.GetButtonPressRate and eng:GetButtonPressRate() or 0

    -- 2) Compute actual casts/sec from spellStats (spells that actually fired)
    local recentCasts = 0
    for _, stat in pairs(spellStats) do
        if stat.lastCast and (now - stat.lastCast) < 10 then
            recentCasts = recentCasts + stat.casts
        end
    end
    local actualCastsPerSec = recentCasts > 0 and recentCasts / 10 or 0

    -- 3) Wasted input ratio: (totalClicks - actualCasts) / totalClicks
    local wastedRatio = 0
    if actualCPS > 0 and actualCastsPerSec > 0 then
        wastedRatio = math.max(0, (actualCPS - actualCastsPerSec) / actualCPS)
    end

    -- 4) Missed windows: gaps in clickTimes > expectedTransition + tolerance
    -- (informational only -- no action beyond debug logging)

    -- 5) Empirical optimal rate: CPS where more clicks stop producing casts
    --    Heuristic: actualCastsPerSec * 1.2 (20% headroom)
    --    Activity gate: a valid empirical sample needs real input
    --    (button presses in the rolling window) AND real output (casts
    --    in the 10s spellStats window). Idle tails previously produced
    --    tiny cast rates (1 cast / 10s = empiricalMs 8333) that
    --    persisted as Calibrated.
    local isActiveSample = actualCPS >= EMPIRICAL_MIN_PRESS_CPS and recentCasts >= EMPIRICAL_MIN_CASTS
    local empiricalCPS = isActiveSample and (actualCastsPerSec * 1.2) or 0
    local empiricalMs = empiricalCPS > 0 and math.floor(1000 / empiricalCPS) or 0

    -- 6) Blend with theoretical
    local specID = self:GetCurrentSpecID()
    if not _G.GRIP_EMS_CHAR then
        return
    end
    GRIP_EMS_CHAR.tempoAdvisor = GRIP_EMS_CHAR.tempoAdvisor or {}
    GRIP_EMS_CHAR.tempoAdvisor[specID] = GRIP_EMS_CHAR.tempoAdvisor[specID] or {}
    local data = GRIP_EMS_CHAR.tempoAdvisor[specID][name]
    if not data then
        return
    end
    -- Blend anchor: PURE theoretical only. recommendedMs must never
    -- feed the anchor: step 9 writes recommendedMs = blendedMs, so
    -- anchoring on recommendedMs feeds the blend its own output
    -- (self-referential lock-in; live proof: empiricalMs 297 vs
    -- blendedMs 1449 with no recovery). data.theoreticalMs is written
    -- only by AnalyzeSequence.
    local theoreticalMs = data.theoreticalMs or 0
    if theoreticalMs <= 0 then
        return
    end

    -- 7) Staleness detection with hysteresis + low-pass output smoothing.
    -- Asymmetric thresholds prevent oscillation near the cutoff: state only
    -- flips to stale when age exceeds STALE_ENTER_THRESHOLD, and only flips
    -- back to fresh when age drops below STALE_EXIT_THRESHOLD. The blended
    -- output is also smoothed via low-pass to dampen frame-to-frame jitter.
    local blendedMs
    local confidence
    if empiricalMs > 0 then
        self._lastEmpiricalUpdate = now
    end

    local empiricalAge = now - (self._lastEmpiricalUpdate > 0 and self._lastEmpiricalUpdate or now)
    if self._lastEmpiricalUpdate == 0 then
        self._empiricalStaleState = "stale"
    elseif self._empiricalStaleState == "stale" and empiricalAge < STALE_EXIT_THRESHOLD then
        self._empiricalStaleState = "fresh"
    elseif self._empiricalStaleState == "fresh" and empiricalAge > STALE_ENTER_THRESHOLD then
        self._empiricalStaleState = "stale"
    end

    if self._empiricalStaleState == "stale" then
        -- Empirical data stale or never collected (CLEU-restricted encounter)
        confidence = "Estimated"
        blendedMs = theoreticalMs
    elseif empiricalMs > 0 and (data.totalSamples or 0) >= 30 then
        -- Enough data to blend; apply low-pass on blended output to dampen oscillation
        local rawBlended = BLEND_THEORETICAL * theoreticalMs + BLEND_EMPIRICAL * empiricalMs
        -- Smoothed-state reset: when inherited smoothed state diverges
        -- far from the current raw blend (poisoned history, spec swap,
        -- SV heal), jump to the raw value instead of crawling toward
        -- it at ALPHA per pass behind the 20 percent notify gate.
        local smoothed = data.blendedMsSmoothed
        if smoothed and smoothed > 0 and math.abs(smoothed - rawBlended) / rawBlended > SMOOTH_RESET_RATIO then
            smoothed = nil
        end
        if smoothed and smoothed > 0 then
            blendedMs = math.floor(BLEND_SMOOTH_ALPHA * rawBlended + (1 - BLEND_SMOOTH_ALPHA) * smoothed)
        else
            blendedMs = math.floor(rawBlended)
        end
        -- Sanity clamp: keep the blend inside the theoretical
        -- neighborhood and under the absolute cap, whatever the
        -- empirical history claims.
        local clampLo = math.max(MIN_CLICK_RATE, math.floor(theoreticalMs / BLEND_CLAMP_RATIO))
        local clampHi = math.min(BLEND_ABS_CAP_MS, math.floor(theoreticalMs * BLEND_CLAMP_RATIO))
        if clampHi < clampLo then
            clampHi = clampLo
        end
        if blendedMs < clampLo then
            blendedMs = clampLo
        elseif blendedMs > clampHi then
            blendedMs = clampHi
        end
        data.blendedMsSmoothed = blendedMs
        confidence = "Calibrated"
    else
        -- Not enough data yet
        blendedMs = theoreticalMs
        confidence = data.empiricalConfidence or "Estimated"
    end

    -- 8) Update SavedVariables. Empirical fields only on active
    -- samples: idle passes must neither overwrite a real empiricalMs
    -- with 0 nor inflate totalSamples (observed 3835 mostly-idle
    -- samples persisted on one sequence).
    if isActiveSample then
        data.empiricalMs = empiricalMs
        data.totalSamples = (data.totalSamples or 0) + 1
    end
    data.blendedMs = blendedMs
    data.lastAnalyzed = now
    data.empiricalConfidence = confidence

    -- 9) If blendedMs significantly different from current (>20%), notify
    local currentMs = data.recommendedMs or theoreticalMs
    if currentMs > 0 and math.abs(blendedMs - currentMs) / currentMs > SIGNIFICANT_DIFF_RATIO then
        data.recommendedMs = blendedMs
        local key = tostring(specID) .. "::" .. tostring(name)
        local lastAt = TA._adjustedNotifyAt[key] or -math.huge
        if (now - lastAt) >= FS_ADJUSTED_COOLDOWN then
            TA._adjustedNotifyAt[key] = now
            GRIPEMS:Debug(L["FS_ADJUSTED"])
        end
    end

    -- 10) If auto-set enabled: apply blendedMs via Settings or CVar (hold mode)
    if S and S:Get("tempoAutoSet") and blendedMs > 0 then
        local isHold = TA:IsHoldMode(name)
        -- Check manual override
        local hasOverride = false
        if GRIP_EMS_CHAR.tempoManualOverride then
            local specOverrides = GRIP_EMS_CHAR.tempoManualOverride[specID]
            if specOverrides and specOverrides[name] then
                hasOverride = true
            end
        end
        if not hasOverride then
            if isHold then
                if InCombatLockdown() then
                    GRIPEMS.OOCQueue:Add(function()
                        pcall(SetCVar, "UseKeyHeldSpellErrorPollTime", blendedMs)
                    end, D().OOC_OP_SETTING, "UseKeyHeldSpellErrorPollTime")
                else
                    pcall(SetCVar, "UseKeyHeldSpellErrorPollTime", blendedMs)
                end
            else
                if InCombatLockdown() then
                    GRIPEMS.OOCQueue:Add(function()
                        S:Set("msClickRate", blendedMs)
                    end, D().OOC_OP_SETTING, "msClickRate")
                else
                    S:Set("msClickRate", blendedMs)
                end
            end
        end
    end

    -- 11) Fire callback for overlay refresh
    if GRIPEMS.Fire then
        GRIPEMS:Fire("TEMPO_RECOMMENDATION_UPDATED", name)
    end

    -- Mismatch detection: alert when actual CPS deviates from recommendation
    if S and S:Get("tempoAlertEnabled") then
        local isHoldMode = TA:IsHoldMode(name)
        if not isHoldMode and currentMs > 0 and actualCPS > 0 then
            local recommendedCPS = 1000 / currentMs
            local slowThreshold = S:Get("tempoAlertSlowThreshold") or 0.6
            local fastThreshold = S:Get("tempoAlertFastThreshold") or 2.0

            -- Too slow: actual < recommended * slowThreshold for 3+ seconds
            if actualCPS < recommendedCPS * slowThreshold then
                if self._mismatchSlowStart == 0 then
                    self._mismatchSlowStart = now
                elseif (now - self._mismatchSlowStart) >= MISMATCH_SLOW_SECONDS then
                    if S and S:Get("tempoAdvisorDebug") then
                        GRIPEMS:Debug(
                            ("TA Mismatch: SLOW actualCPS=%.1f recCPS=%.1f threshold=%.1f"):format(
                                actualCPS,
                                recommendedCPS,
                                recommendedCPS * slowThreshold
                            )
                        )
                    end
                    if GRIPEMS.Fire then
                        GRIPEMS:Fire("TEMPO_MISMATCH_SLOW")
                    end
                    self._mismatchSlowStart = 0
                end
            else
                self._mismatchSlowStart = 0
            end

            -- Too fast: actual > recommended * fastThreshold for 5+ seconds
            if actualCPS > recommendedCPS * fastThreshold then
                if self._mismatchFastStart == 0 then
                    self._mismatchFastStart = now
                elseif (now - self._mismatchFastStart) >= MISMATCH_FAST_SECONDS then
                    if S and S:Get("tempoAdvisorDebug") then
                        GRIPEMS:Debug(
                            ("TA Mismatch: FAST actualCPS=%.1f recCPS=%.1f threshold=%.1f"):format(
                                actualCPS,
                                recommendedCPS,
                                recommendedCPS * fastThreshold
                            )
                        )
                    end
                    if GRIPEMS.Fire then
                        GRIPEMS:Fire("TEMPO_MISMATCH_FAST")
                    end
                    self._mismatchFastStart = 0
                end
            else
                self._mismatchFastStart = 0
            end
        end
    end

    -- Debug output
    if S and S:Get("tempoAdvisorDebug") then
        GRIPEMS:Debug(
            ("TA Tier3: %s CPS=%.1f casts/s=%.1f wasted=%.0f%% empirical=%dms blended=%dms conf=%s samples=%d"):format(
                name,
                actualCPS,
                actualCastsPerSec,
                wastedRatio * 100,
                empiricalMs,
                blendedMs,
                confidence,
                data.totalSamples or 0
            )
        )
    end
end

-- VARIABLE_UPDATED handler with 5s debounce
-- Re-analyzes active sequences when a variable they reference changes
do
    local variableDebounceTimer = nil
    local VARIABLE_DEBOUNCE = 5.0

    function TA:OnVariableUpdated()
        -- Cancel existing debounce timer
        if variableDebounceTimer then
            variableDebounceTimer:Cancel()
        end
        if C_Timer and C_Timer.NewTimer then
            variableDebounceTimer = C_Timer.NewTimer(VARIABLE_DEBOUNCE, function()
                variableDebounceTimer = nil
                local eng = Engine()
                if not eng or not eng.sequences then
                    return
                end
                -- Re-analyze all active (non-dormant) sequences
                for sn, entry in pairs(eng.sequences) do
                    if entry.data and entry.button then
                        TA:OnSequenceActivated(sn, entry.data)
                    end
                end
            end)
        end
    end
end

-- HandleSlashCommand: /gems fs [arg]
function TA:HandleSlashCommand(args)
    local sub = (args or ""):match("^(%S+)") or ""

    if sub == "debug" then
        local S = GRIPEMS.Settings
        if S then
            local current = S:Get("tempoAdvisorDebug")
            S:Set("tempoAdvisorDebug", not current)
            GRIPEMS:Print(not current and L["FS_DEBUG_ON"] or L["FS_DEBUG_OFF"])
        end
    elseif sub == "overlay" then
        local TOV = GRIPEMS.TempoOverlay
        if TOV then
            TOV:Toggle()
        end
    elseif sub == "lock" then
        local TOV = GRIPEMS.TempoOverlay
        if TOV then
            TOV:ToggleLock()
        end
    elseif sub == "alert" then
        local S = GRIPEMS.Settings
        if S then
            local current = S:Get("tempoAlertEnabled")
            S:Set("tempoAlertEnabled", not current)
            GRIPEMS:Print(not current and L["FS_ALERT_ENABLED"] or L["FS_ALERT_DISABLED"])
        end
    elseif sub == "hold" then
        GRIPEMS:Print(L["FS_HOLD_DEV"])
    elseif sub == "holdreset" then
        wipe(self._runtimeOverrides)
        if _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.tempoOffGCD then
            local specID = self:GetCurrentSpecID()
            GRIP_EMS_CHAR.tempoOffGCD[specID] = nil
        end
        wipe(self.spellClassCache)
        wipe(self._lastAnalysisTime)
        GRIPEMS:Print(L["FS_HOLD_RESET_DONE"])
        local eng = Engine()
        if eng and eng.sequences then
            for sn, entry in pairs(eng.sequences) do
                if entry.data and entry.button then
                    self:OnSequenceActivated(sn, entry.data)
                end
            end
        end
    elseif sub == "reset" then
        wipe(self._runtimeOverrides)
        if _G.GRIP_EMS_CHAR then
            GRIP_EMS_CHAR.tempoOffGCD = {}
        end
        wipe(self.spellClassCache)
        wipe(self._lastAnalysisTime)
        GRIPEMS:Print("TempoAdvisor: all persisted off-GCD classifications cleared")
        local eng = Engine()
        if eng and eng.sequences then
            for sn, entry in pairs(eng.sequences) do
                if entry.data and entry.button then
                    self:OnSequenceActivated(sn, entry.data)
                end
            end
        end
    elseif sub == "holddiag" then
        local hmmState = HMM.active and "ACTIVE" or "INACTIVE"
        local hmmSeq = HMM.activeSequence or "none"
        local hmmKey = HMM.activeKey or "none"
        local nb = HMM.nativeButton
        local nbName = nb and nb:GetName() or "nil"
        local nbStep = nb and (nb:GetAttribute("step") or "?") or "N/A"
        local cvHeld = C_CVar.GetCVar("ActionButtonUseKeyHeldSpell") or "nil"
        local cvPoll = C_CVar.GetCVar("UseKeyHeldSpellErrorPollTime") or "nil"
        local eng = Engine()
        local numSteps = 0
        if eng and HMM.activeSequence then
            local entry = eng.sequences and eng.sequences[HMM.activeSequence]
            if entry and entry.data then
                local cv = eng:GetActiveVersion(entry.data)
                if cv and cv.steps then
                    numSteps = #cv.steps
                end
            end
        end
        GRIPEMS:Print(L["FS_HOLD_DIAG_HEADER"])
        GRIPEMS:Print(L["FS_HOLD_DIAG_STATE"]:format(hmmState, hmmSeq, hmmKey))
        GRIPEMS:Print(L["FS_HOLD_DIAG_BUTTON"]:format(nbName, tostring(nbStep)))
        GRIPEMS:Print(L["FS_HOLD_DIAG_CVAR"]:format(cvHeld, cvPoll))
        GRIPEMS:Print(L["FS_HOLD_DIAG_STEPS"]:format(numSteps))
    elseif sub == "help" then
        GRIPEMS:Print(L["FS_CMD_HELP"])
    else
        -- If sub is not a subcommand, treat full args as sequence name
        local seqArg = (args or ""):match("^%s*(.-)%s*$")
        self:PrintStatus(seqArg)
    end
end

---------------------------------------------------------------------------
-- LDB data source broker (Faster, Slower feed for LDB displays)
---------------------------------------------------------------------------
do
    local LDB = LibStub("LibDataBroker-1.1", true)
    if LDB then
        TA.broker = LDB:NewDataObject("GRIP-EMS Tempo", {
            type = "data source",
            text = L["FS_LDB_NO_SEQ"],
            icon = "Interface\\Icons\\Ability_Rogue_MasterOfSubtlety",
            label = L["FS_STATUS_HEADER"],
            OnTooltipShow = function(tooltip)
                if not tooltip then
                    return
                end
                tooltip:AddLine("|cFF00CC66GRIP|r-EMS: " .. L["FS_STATUS_HEADER"])
                tooltip:AddLine(" ")

                local eng = Engine()
                local seqName = eng and eng._lastClickedSequence
                if not seqName then
                    tooltip:AddLine(L["FS_NO_SEQUENCE"], 0.5, 0.5, 0.5)
                    tooltip:Show()
                    return
                end

                local rec = TA:GetRecommendation(seqName)
                if not rec then
                    tooltip:AddLine(seqName, 1, 1, 1)
                    tooltip:AddLine(L["FS_NO_SEQUENCE"], 0.5, 0.5, 0.5)
                    tooltip:Show()
                    return
                end

                tooltip:AddDoubleLine("Sequence", seqName, 0.8, 0.8, 0.8, 0, 0.8, 0.4)
                tooltip:AddDoubleLine("Recommended", rec.recommendedMs .. "ms", 0.8, 0.8, 0.8, 1, 1, 1)

                local cps = rec.recommendedMs > 0 and math.floor(1000 / rec.recommendedMs) or 0
                tooltip:AddDoubleLine("Click rate", cps .. "/sec", 0.8, 0.8, 0.8, 1, 1, 1)

                local complexityLabel = rec.complexity or "Standard"
                local complexityKey = "FS_COMPLEXITY_" .. string.upper(complexityLabel)
                local localized = L[complexityKey] or complexityLabel
                tooltip:AddDoubleLine("Complexity", localized, 0.8, 0.8, 0.8, 1, 0.8, 0)

                tooltip:AddDoubleLine("Confidence", TA:GetEffectiveConfidence(rec) or "Unknown", 0.8, 0.8, 0.8, 1, 1, 1)

                local isHold = TA:IsHoldMode(seqName)
                tooltip:AddDoubleLine("Mode", isHold and "Hold" or "Spam", 0.8, 0.8, 0.8, 1, 1, 1)

                tooltip:Show()
            end,
        })
    end
end

-- UpdateBroker: refresh LDB text from current state
function TA:UpdateBroker()
    if not TA.broker then
        return
    end
    local eng = Engine()
    local seqName = eng and eng._lastClickedSequence
    if not seqName then
        TA.broker.text = L["FS_LDB_NO_SEQ"]
        return
    end

    local rec = TA:GetRecommendation(seqName)
    if not rec or not rec.recommendedMs then
        TA.broker.text = L["FS_LDB_NO_SEQ"]
        return
    end

    local isHold = TA:IsHoldMode(seqName)

    if isHold then
        TA.broker.text = string.format(L["FS_LDB_HOLD"], rec.recommendedMs)
    else
        local cps = rec.recommendedMs > 0 and math.floor(1000 / rec.recommendedMs) or 0
        TA.broker.text = string.format(L["FS_LDB_SPAM"], cps, rec.recommendedMs)
    end
end

---------------------------------------------------------------------------
-- OPP-06 Name-Keyed Spell-to-Sequence Index
--
-- Forward index: TA._spellToSequences[spellID] = { [seqName] = true, ... }
-- Reverse index: TA._sequenceSpellSet[seqName]  = { [spellID] = true, ... }
--
-- Both are session-scope tables rebuilt on login and kept coherent by three
-- CallbackHandler events: SEQUENCE_CREATED, SEQUENCE_DELETED, SEQUENCE_UPDATED.
-- No GUID infrastructure, no seqGUID field, no rename hook: SequenceEditor
-- rename already fires DELETED(oldName) + CREATED(newName) in that order,
-- which hits our listeners correctly.
--
-- _ScopedReanalyze drains TA._justReclassified (populated by ReclassifyOffGCD)
-- and only re-analyses the sequences that reference the just-reclassified
-- spell IDs. Replaces the wipe(TA._lastAnalysisTime) + iterate-all pattern
-- on the UNIT_SPELLCAST_SUCCEEDED path.
---------------------------------------------------------------------------
function TA:_OnSequenceIndexed(event, name, seqData)
    if not name or not seqData then
        return
    end
    local eng = Engine()
    if not eng then
        return
    end
    local ver = eng:GetActiveVersion(seqData)
    if not ver or not ver.steps then
        return
    end
    local cache = SC()
    if not cache or not cache.byName then
        return
    end

    local spellSet
    local steps = ver.steps
    for i = 1, #steps do
        local stepText = steps[i]
        if type(stepText) == "table" then
            stepText = stepText.macrotext or ""
        end
        local names = self:ExtractSpellsFromStep(tostring(stepText))
        for _, sn in ipairs(names) do
            if type(sn) == "string" and sn ~= "" then
                local entry = cache.byName[strlower(sn)]
                local spellID = entry and entry.spellID
                if spellID then
                    local bucket = TA._spellToSequences[spellID]
                    if not bucket then
                        bucket = {}
                        TA._spellToSequences[spellID] = bucket
                    end
                    bucket[name] = true
                    spellSet = spellSet or {}
                    spellSet[spellID] = true
                end
            end
        end
    end
    if spellSet then
        TA._sequenceSpellSet[name] = spellSet
    end
end

function TA:_OnSequenceUnindexed(event, name)
    if not name then
        return
    end
    local spellSet = TA._sequenceSpellSet[name]
    if spellSet then
        for spellID in pairs(spellSet) do
            local bucket = TA._spellToSequences[spellID]
            if bucket then
                bucket[name] = nil
                if not next(bucket) then
                    TA._spellToSequences[spellID] = nil
                end
            end
        end
        TA._sequenceSpellSet[name] = nil
    end
end

function TA:_OnSequenceReindexed(event, name, seqData)
    self:_OnSequenceUnindexed(nil, name)
    self:_OnSequenceIndexed(nil, name, seqData)
end

function TA:_ScopedReanalyze()
    local touched = TA._justReclassified
    if not touched or not next(touched) then
        if touched then
            wipe(touched)
        end
        return
    end
    local eng = Engine()
    if not (eng and eng.sequences) then
        wipe(touched)
        return
    end

    -- Dedupe across multiple reclassified spells so a sequence referencing
    -- two newly-off-GCD spells only re-analyses once per cycle.
    local seen = {}
    for spellID in pairs(touched) do
        local names = TA._spellToSequences and TA._spellToSequences[spellID]
        if names then
            for sn in pairs(names) do
                if not seen[sn] then
                    seen[sn] = true
                    local entry = eng.sequences[sn]
                    if entry and entry.data and entry.button then
                        TA._lastAnalysisTime[sn] = nil
                        self:OnSequenceActivated(sn, entry.data)
                    end
                end
            end
        end
    end
    wipe(touched)
end

-- Initialize: register events and callbacks
function TA:Initialize()
    if _G.GRIP_EMS_CHAR then
        GRIP_EMS_CHAR.tempoAdvisor = GRIP_EMS_CHAR.tempoAdvisor or {}
        GRIP_EMS_CHAR.tempoOffGCD = GRIP_EMS_CHAR.tempoOffGCD or {}
        -- Patch-stamped storage: migrate legacy flat shape, wipe on patch
        -- change. Blizzard can flip a spell off-GCD <-> on-GCD between
        -- patches, so a stale classification produces wrong advice.
        -- Legacy: [specID] = { [spellID] = true, ... }
        -- Stamped: [specID] = { _patch = "X.Y.Z", spells = { [spellID] = true, ... } }
        local currentPatch = select(1, GetBuildInfo()) or ""
        for specID, entry in pairs(GRIP_EMS_CHAR.tempoOffGCD) do
            if type(entry) == "table" then
                if entry.spells == nil then
                    local migrated = {}
                    for sid, flag in pairs(entry) do
                        if type(sid) == "number" and flag == true then
                            migrated[sid] = true
                        end
                    end
                    GRIP_EMS_CHAR.tempoOffGCD[specID] = {
                        _patch = currentPatch,
                        spells = migrated,
                    }
                elseif entry._patch ~= currentPatch then
                    wipe(entry.spells)
                    entry._patch = currentPatch
                end
            end
        end
        -- One-shot scrub of legacy SV cooldown field (now in-memory
        -- via TA._adjustedNotifyAt). Idempotent: after first run,
        -- nothing to nil. Replaces per-tick scrub in
        -- OnExecutionTracerUpdate.
        for _, specTbl in pairs(GRIP_EMS_CHAR.tempoAdvisor) do
            if type(specTbl) == "table" then
                for _, seqData in pairs(specTbl) do
                    if type(seqData) == "table" and seqData._lastAdjustedNotify ~= nil then
                        seqData._lastAdjustedNotify = nil
                    end
                end
            end
        end
        -- One-shot heal (TempoAdvisor defect-cluster fix): wipe every
        -- tempoAdvisor recommendation bucket, all specs. Sessions before
        -- this fix persisted poison that field-level repair cannot
        -- untangle: idle-window empirical samples marked Calibrated,
        -- blendedMsSmoothed lock-in, junk login entries analyzed against
        -- an empty spell cache, and theoreticalMs anchors seeded from
        -- poisoned recommendedMs. Theoretical recs rebuild on the next
        -- activation; empirical re-learns in ~30 active tracer passes.
        -- tempoManualOverride and tempoOffGCD are intentionally preserved.
        if not GRIP_EMS_CHAR.tempoHealApplied then
            GRIP_EMS_CHAR.tempoAdvisor = {}
            GRIP_EMS_CHAR.tempoHealApplied = true
        end
    end
    -- v1.9.8: split legacy single-source rec.confidence into
    -- theoreticalConfidence + empiricalConfidence to stop the
    -- every-2-3s oscillation caused by two writers sharing one
    -- field. Map the legacy value onto the most plausible new
    -- field: "Calibrated" could only have come from Tier3
    -- (empirical), everything else comes from AnalyzeSequence
    -- (theoretical). Keeps the UI reading a sensible label
    -- across /reload instead of briefly showing "Unknown".
    if _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.tempoAdvisor then
        for _, specData in pairs(GRIP_EMS_CHAR.tempoAdvisor) do
            if type(specData) == "table" then
                for _, rec in pairs(specData) do
                    if type(rec) == "table" and rec.confidence ~= nil then
                        if rec.confidence == "Calibrated" then
                            rec.empiricalConfidence = rec.empiricalConfidence or rec.confidence
                        else
                            rec.theoreticalConfidence = rec.theoreticalConfidence or rec.confidence
                        end
                        rec.confidence = nil
                    end
                end
            end
        end
    end
    -- Load persisted off-GCD overrides for current spec
    do
        local specID = self:GetCurrentSpecID()
        local saved = _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.tempoOffGCD and GRIP_EMS_CHAR.tempoOffGCD[specID]
        local spells = saved and saved.spells
        if spells then
            for sid in pairs(spells) do
                self._runtimeOverrides[sid] = CAT_OFF_GCD
            end
            if GRIPEMS.Settings and GRIPEMS.Settings:Get("tempoAdvisorDebug") then
                local count = 0
                for _ in pairs(spells) do
                    count = count + 1
                end
                GRIPEMS:Debug("TA Debug: loaded %d persisted off-GCD overrides for spec %d", count, specID)
            end
        end
    end
    local frame = CreateFrame("Frame")
    self.eventFrame = frame
    frame:RegisterEvent("SPELLS_CHANGED")
    frame:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")
    frame:RegisterEvent("PLAYER_TALENT_UPDATE")
    frame:RegisterEvent("UNIT_SPELL_HASTE")
    frame:RegisterEvent("PLAYER_ENTERING_WORLD")
    frame:RegisterEvent("UNIT_ENTERED_VEHICLE")
    frame:RegisterEvent("UNIT_EXITED_VEHICLE")
    frame:RegisterEvent("PET_BATTLE_OPENING_START")
    frame:RegisterEvent("PET_BATTLE_CLOSE")
    frame:SetScript("OnEvent", function(_, event, unit)
        if event == "UNIT_SPELL_HASTE" then
            if unit ~= "player" then
                return
            end
            TA:InvalidateHasteDependentSpellCache()
        elseif event == "PLAYER_ENTERING_WORLD" then
            if _G.GRIP_EMS_CHAR then
                GRIP_EMS_CHAR.tempoAdvisor = GRIP_EMS_CHAR.tempoAdvisor or {}
                GRIP_EMS_CHAR.tempoOffGCD = GRIP_EMS_CHAR.tempoOffGCD or {}
            end
        else
            TA:InvalidateSpellCache()
        end
        if event == "PLAYER_SPECIALIZATION_CHANGED" then
            wipe(TA._runtimeOverrides)
            wipe(TA._pendingVerification)
            wipe(TA._itemSpellIDs)
            -- Reload persisted off-GCD data for new spec
            if _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.tempoOffGCD then
                local newSpec = TA:GetCurrentSpecID()
                local saved = GRIP_EMS_CHAR.tempoOffGCD[newSpec]
                local spells = saved and saved.spells
                if spells then
                    for sid in pairs(spells) do
                        TA._runtimeOverrides[sid] = CAT_OFF_GCD
                    end
                end
            end
        end
        -- HoldModeManager: vehicle and pet battle safety
        if event == "UNIT_ENTERED_VEHICLE" or event == "PET_BATTLE_OPENING_START" then
            if HMM.active then
                HMM._suspendedSequence = HMM.activeSequence
                HMM:Deactivate()
            end
        elseif event == "UNIT_EXITED_VEHICLE" or event == "PET_BATTLE_CLOSE" then
            local suspName = HMM._suspendedSequence
            HMM._suspendedSequence = nil
            if suspName then
                local eng = Engine()
                if eng and eng.sequences and eng.sequences[suspName] then
                    local holdS = GRIPEMS.Settings
                    if holdS and holdS:Get("holdModeEnabled") and TA:IsHoldMode(suspName) then
                        local seqEntry = eng.sequences[suspName]
                        local rec = TA:GetRecommendation(suspName)
                        local ms = rec and rec.recommendedMs or 250
                        HMM:Activate(suspName, seqEntry.data, ms)
                    end
                end
            end
        end
        TA:UpdateBroker()
    end)
    if GRIPEMS.RegisterCallback then
        GRIPEMS.RegisterCallback(TA, "SQW_UPDATED", function()
            TA:InvalidateSpellCache()
            TA:UpdateBroker()
        end)
        GRIPEMS.RegisterCallback(TA, "VARIABLE_UPDATED", function()
            TA:OnVariableUpdated()
        end)
        GRIPEMS.RegisterCallback(TA, "TEMPO_RECOMMENDATION_UPDATED", function()
            TA:UpdateBroker()
        end)
        -- OPP-06 spell-to-sequence index maintenance. Rename is handled
        -- implicitly: SequenceEditor:HandleNameChange fires DELETED(old)
        -- then CREATED(new), so no dedicated rename hook is required.
        GRIPEMS.RegisterCallback(TA, "SEQUENCE_CREATED", function(event, name, seqData)
            TA:_OnSequenceIndexed(event, name, seqData)
        end)
        GRIPEMS.RegisterCallback(TA, "SEQUENCE_DELETED", function(event, name)
            TA:_OnSequenceUnindexed(event, name)
        end)
        GRIPEMS.RegisterCallback(TA, "SEQUENCE_UPDATED", function(event, name, seqData)
            TA:_OnSequenceReindexed(event, name, seqData)
        end)
        -- OPP-06 cold-boot race fix: Engine:RestoreSavedSequences at PEW
        -- fires SEQUENCE_CREATED before SpellCache's debounced Scan
        -- populates SC.byName, so the per-sequence _OnSequenceIndexed
        -- calls land with an empty byName and resolve no spellIDs.
        -- Once Scan completes and fires SPELL_CACHE_REFRESHED, wipe
        -- and rebuild the index from Engine.sequences. Subsequent fires
        -- (spec change, SPELLS_CHANGED) rebuild redundantly but bounded
        -- by event frequency.
        GRIPEMS.RegisterCallback(TA, "SPELL_CACHE_REFRESHED", function()
            wipe(TA._spellToSequences)
            wipe(TA._sequenceSpellSet)
            -- One-shot scrub of pre-v1.9.9 poisoned flyout-child overrides.
            -- v1.9.8 and earlier wrote flyout children (Call Pet 1, Hunter's
            -- Mark on [nopet], Warlock summon demon variants) into
            -- _runtimeOverrides + GRIP_EMS_CHAR.tempoOffGCD because the
            -- "guard" referenced a non-existent spCache.spellData table.
            -- SpellCache is populated by now, so walk the override tables and
            -- drop any sid whose entry is a flyout child.
            local spCache = GRIPEMS.SpellCache
            if spCache and spCache.byID then
                local scrubbed = 0
                for sid in pairs(TA._runtimeOverrides) do
                    local sd = spCache.byID[sid]
                    if sd and sd.isFlyoutChild then
                        TA._runtimeOverrides[sid] = nil
                        scrubbed = scrubbed + 1
                    end
                end
                if _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.tempoOffGCD then
                    for _, specMap in pairs(GRIP_EMS_CHAR.tempoOffGCD) do
                        local spells = type(specMap) == "table" and specMap.spells
                        if spells then
                            for sid in pairs(spells) do
                                local sd = spCache.byID[sid]
                                if sd and sd.isFlyoutChild then
                                    spells[sid] = nil
                                end
                            end
                        end
                    end
                end
                if scrubbed > 0 and GRIPEMS.Settings and GRIPEMS.Settings:Get("tempoAdvisorDebug") then
                    GRIPEMS:Debug(
                        "TA Debug: scrubbed %d flyout-child false-positive overrides on cache refresh",
                        scrubbed
                    )
                end
            end
            local eng = Engine()
            if eng and eng.sequences then
                for sn, entry in pairs(eng.sequences) do
                    if entry.data then
                        TA:_OnSequenceIndexed(nil, sn, entry.data)
                    end
                end
            end
            -- Drain activations parked while the cache was not ready
            -- (login-order race). SC.ready is true before this event
            -- fires, so the re-entrant OnSequenceActivated cannot
            -- re-park (clearing keys during pairs iteration is legal;
            -- nothing adds keys mid-loop). Only active (non-dormant)
            -- entries qualify.
            if next(TA._deferredActivation) then
                for sn in pairs(TA._deferredActivation) do
                    TA._deferredActivation[sn] = nil
                    local entry = eng and eng.sequences and eng.sequences[sn]
                    if entry and entry.data and entry.button then
                        TA:OnSequenceActivated(sn, entry.data)
                    end
                end
            end
        end)
        GRIPEMS.RegisterCallback(TA, "SETTING_CHANGED", function(_, key, val)
            if key == "holdModeEnabled" then
                if val then
                    local eng = Engine()
                    if eng and eng.sequences then
                        for sn, entry in pairs(eng.sequences) do
                            if entry.data and entry.button and TA:IsHoldMode(sn) then
                                local rec = TA:GetRecommendation(sn)
                                local ms = rec and rec.recommendedMs or 250
                                HMM:Activate(sn, entry.data, ms)
                                break
                            end
                        end
                    end
                else
                    HMM:Deactivate()
                end
            end
        end)
    end

    -- Universal off-GCD combat detection (zero hardcoded spell IDs).
    -- Two complementary mechanisms:
    --
    -- 1) UNIT_SPELLCAST_SUCCEEDED with frame-timing: if a pending spell
    --    fires SUCCEEDED while the GCD is active from a PREVIOUS frame
    --    (gcdStartTime < GetTime()), it cast during an already-running GCD.
    --    WoW blocks on-GCD spells during active GCD, so success = off-GCD.
    --    Works for any player spamming faster than GCD.
    --
    -- 2) OnUpdate combat scanner: every frame during combat, if GCD is
    --    active, check all pending spells for duration=0 (spell not on
    --    any cooldown while GCD runs). Catches spells from other macro
    --    steps that have not been cast yet (sequential macros).
    --
    -- Discovered overrides persist to GRIP_EMS_CHAR.tempoOffGCD[specID]
    -- so they survive /reload and relog. Loaded in Initialize + spec change.
    self._gcdVerified = false
    local verifyFrame = CreateFrame("Frame")
    self._verifyFrame = verifyFrame

    local function ReclassifyOffGCD(sid)
        -- Flyout-child write-side guard. Defensive -- the two call-sites
        -- above already filter, but this prevents future call-sites
        -- from re-poisoning the override table.
        local spCache = GRIPEMS.SpellCache
        if spCache and spCache.byID then
            local sd = spCache.byID[sid]
            if sd and sd.isFlyoutChild then
                TA._pendingVerification[sid] = nil
                return
            end
        end
        TA._runtimeOverrides[sid] = CAT_OFF_GCD
        TA._pendingVerification[sid] = nil
        -- OPP-06: record the reclassified spellID so _ScopedReanalyze
        -- (UNIT_SPELLCAST_SUCCEEDED path) can touch only the sequences that
        -- reference it instead of iterating every active sequence.
        TA._justReclassified[sid] = true
        -- Persist to SavedVariables for current spec
        if _G.GRIP_EMS_CHAR then
            GRIP_EMS_CHAR.tempoOffGCD = GRIP_EMS_CHAR.tempoOffGCD or {}
            local specID = TA:GetCurrentSpecID()
            local entry = GRIP_EMS_CHAR.tempoOffGCD[specID]
            if not entry or entry.spells == nil then
                entry = { _patch = select(1, GetBuildInfo()) or "", spells = {} }
                GRIP_EMS_CHAR.tempoOffGCD[specID] = entry
            end
            entry.spells[sid] = true
        end
        if GRIPEMS.Settings and GRIPEMS.Settings:Get("tempoAdvisorDebug") then
            local okN, sn = pcall(C_Spell.GetSpellName, sid)
            GRIPEMS:Debug(
                ("TA Debug: reclassified %s (%d) -> OFF_GCD (combat)"):format(okN and sn or tostring(sid), sid)
            )
        end
    end

    local function ReanalyzeAll()
        wipe(TA._lastAnalysisTime)
        -- OPP-06: drain the scratch set so the next _ScopedReanalyze
        -- does not redo work already covered by this full reanalyse.
        wipe(TA._justReclassified)
        local eng = Engine()
        if eng and eng.sequences then
            for sn, entry in pairs(eng.sequences) do
                if entry.data and entry.button then
                    TA:OnSequenceActivated(sn, entry.data)
                end
            end
        end
    end

    local function ScanPendingDurationZero()
        local found = false
        for pid in pairs(TA._pendingVerification) do
            if not TA._runtimeOverrides[pid] then
                -- Skip flyout children (Call Pet 1, etc.) -- conditional no-ops
                -- produce false SUCCEEDED events during GCD
                local spCache = GRIPEMS.SpellCache
                local skipReclassify = false
                if spCache and spCache.byID then
                    local sd = spCache.byID[pid]
                    if sd and sd.isFlyoutChild then
                        skipReclassify = true
                    end
                end
                if not skipReclassify then
                    local okCD, cdInfo = SafeGetSpellCooldown(pid)
                    if okCD and cdInfo and cdInfo.duration == 0 then
                        ReclassifyOffGCD(pid)
                        found = true
                    end
                end
            end
        end
        return found
    end

    local function CheckDone()
        if not next(TA._pendingVerification) then
            TA._gcdVerified = true
            verifyFrame:SetScript("OnUpdate", nil)
            return true
        end
        return false
    end

    local function GCDScanOnUpdate()
        if TA._gcdVerified then
            verifyFrame:SetScript("OnUpdate", nil)
            return
        end
        if CheckDone() then
            return
        end
        local okGCD, gcdCD = SafeGetSpellCooldown(GCD_SPELL_ID)
        if not okGCD or not gcdCD or not gcdCD.duration or gcdCD.duration <= 0 then
            return
        end
        if ScanPendingDurationZero() then
            ReanalyzeAll()
        end
        CheckDone()
    end

    verifyFrame:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED")
    verifyFrame:RegisterEvent("PLAYER_REGEN_DISABLED")
    verifyFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
    verifyFrame:SetScript("OnEvent", function(_, event, ...)
        if event == "PLAYER_REGEN_DISABLED" then
            TA._gcdVerified = false
            verifyFrame:SetScript("OnUpdate", GCDScanOnUpdate)
            return
        elseif event == "PLAYER_REGEN_ENABLED" then
            verifyFrame:SetScript("OnUpdate", nil)
            return
        end
        -- UNIT_SPELLCAST_SUCCEEDED: unit, castGUID, spellID
        local unit, _, spellID = ...
        if unit ~= "player" then
            return
        end
        if TA._gcdVerified then
            return
        end
        local okGCD, gcdCD = SafeGetSpellCooldown(GCD_SPELL_ID)
        if not okGCD or not gcdCD or not gcdCD.duration or gcdCD.duration <= 0 then
            return
        end
        local changed = false
        -- Mechanism 1: spell succeeded during GCD from a previous frame.
        -- GCD started before this frame = spell cast during active GCD.
        -- On-GCD spells are blocked by WoW, so this must be off-GCD.
        if spellID and TA._pendingVerification[spellID] and not TA._runtimeOverrides[spellID] then
            -- Skip flyout children (Call Pet 1, etc.) -- conditional no-ops
            -- produce false SUCCEEDED events during GCD
            local spCache = GRIPEMS.SpellCache
            local skipReclassify = false
            if spCache and spCache.byID then
                local sd = spCache.byID[spellID]
                if sd and sd.isFlyoutChild then
                    skipReclassify = true
                end
            end
            if not skipReclassify then
                local now = GetTime()
                local gcdRemaining = (gcdCD.startTime + gcdCD.duration) - now
                -- Threshold: only reclassify if GCD has substantial time left.
                -- Spells queued via SQW fire at GCD boundary (remaining near 0).
                -- True off-GCD spells fire mid-GCD (remaining > 150ms).
                if gcdCD.startTime < now and gcdRemaining > 0.15 then
                    ReclassifyOffGCD(spellID)
                    changed = true
                elseif GRIPEMS.Settings and GRIPEMS.Settings:Get("tempoAdvisorDebug") then
                    local okN, sn = pcall(C_Spell.GetSpellName, spellID)
                    GRIPEMS:Debug(
                        ("TA Debug: %s (%d) succeeded near GCD boundary (remaining=%.3fs), NOT reclassified (SQW filter)"):format(
                            okN and sn or tostring(spellID),
                            spellID,
                            gcdRemaining
                        )
                    )
                end
            end
        end
        -- Mechanism 2: scan all pending for duration=0 (uncasted spells)
        if ScanPendingDurationZero() then
            changed = true
        end
        if changed then
            -- OPP-06: scope reanalyse to sequences referencing the spells
            -- that ReclassifyOffGCD just flipped. For spells no active
            -- sequence uses (the common case), the scoped helper returns
            -- immediately without touching OnSequenceActivated at all.
            TA:_ScopedReanalyze()
        end
        CheckDone()
    end)

    -- OPP-06 seed build: if sequences already exist when Initialize runs
    -- (normal case after /reload), index them now. Otherwise the per-sequence
    -- SEQUENCE_CREATED events fired during later activation will populate
    -- the index incrementally.
    local seedEng = Engine()
    if seedEng and seedEng.sequences then
        for sn, entry in pairs(seedEng.sequences) do
            if entry.data then
                TA:_OnSequenceIndexed(nil, sn, entry.data)
            end
        end
    end
end
