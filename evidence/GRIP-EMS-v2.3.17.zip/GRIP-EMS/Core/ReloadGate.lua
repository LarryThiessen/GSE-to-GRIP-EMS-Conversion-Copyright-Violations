-- GRIP-EMS: Core/ReloadGate.lua
-- Created: 2026-05-02
-- Updated: 2026-06-21
-- Patch: 12.0.7.68256 Midnight (Retail LIVE)
--
-- ReloadGate (Phase G.7 / G23): centralized reload-required notification.
-- Tracks settings changes that need a /reload to fully apply. Lights a
-- minimap pip + settings-panel header pip while changes are pending.
-- Shows a single StaticPopup on settings-panel close offering Reload Now
-- or Later (suppress this cycle). Suppression resets on each panel close.
--
-- Public API:
--   GRIPEMS.ReloadGate:Notify(causeID, count, details)
--   GRIPEMS.ReloadGate:Clear(causeID)  -- causeID nil clears all
--   GRIPEMS.ReloadGate:GetPending()  -> table
--   GRIPEMS.ReloadGate:HasPending()  -> boolean
--
-- Internal:
--   :_OnSettingsPanelClose(), :_OnLater(), :_OnReloadNow()
--   :_RefreshPips(), :_FillTooltip(tip), :_ShowPopup()
--
-- Cause taxonomy (10 IDs): AUTOFIX_LOGIN, FIX_ALL_CRITICAL,
-- FIX_ALL_SECTION, PER_ROW_FIX, PER_ROW_SET, RESET_DEFAULTS,
-- PROFILE_SWAP, PROFILE_IMPORT, OOC_QUEUED, OOC_APPLIED.

local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)
local R = {}
GRIPEMS.ReloadGate = R

R.pending = {}
R.suppressed = false
R._minimapPip = nil
R._sidebarPip = nil
R._panelHookInstalled = false

local CAUSE_LABEL_KEYS = {
    AUTOFIX_LOGIN = "RELOAD_GATE_CAUSE_AUTOFIX",
    FIX_ALL_CRITICAL = "RELOAD_GATE_CAUSE_FIX_ALL_CRIT",
    FIX_ALL_SECTION = "RELOAD_GATE_CAUSE_FIX_ALL_SEC",
    PER_ROW_FIX = "RELOAD_GATE_CAUSE_PER_ROW_FIX",
    PER_ROW_SET = "RELOAD_GATE_CAUSE_PER_ROW_SET",
    RESET_DEFAULTS = "RELOAD_GATE_CAUSE_RESET_DEFS",
    PROFILE_SWAP = "RELOAD_GATE_CAUSE_PROFILE_SWP",
    PROFILE_IMPORT = "RELOAD_GATE_CAUSE_PROFILE_IMP",
    OOC_QUEUED = "RELOAD_GATE_CAUSE_OOC_QUEUED",
    OOC_APPLIED = "RELOAD_GATE_CAUSE_OOC_APPLIED",
}

----------------------------------------------------------------
-- Public API
----------------------------------------------------------------

function R:Notify(causeID, count, details)
    if not causeID or not count or count <= 0 then
        return
    end
    -- G7-POLISH-OOC-DEDUP: when OOC_APPLIED Notify lands, clear the
    -- companion OOC_QUEUED bucket. The queued items have completed
    -- their drain; the popup body should show APPLIED count, not
    -- the duplicated QUEUED + APPLIED pair. Bucket-clear semantics
    -- accept mid-drain under-count; post-drain count is correct.
    if causeID == "OOC_APPLIED" and self.pending["OOC_QUEUED"] then
        self.pending["OOC_QUEUED"] = nil
    end
    local entry = self.pending[causeID]
    if not entry then
        entry = { count = 0, details = {} }
        self.pending[causeID] = entry
    end
    entry.count = entry.count + count
    if details then
        for _, d in ipairs(details) do
            -- G7-POLISH-DETAILS-MEMORY-UNBOUNDED: cap details length
            -- per cause at 50 entries; the popup body + tooltip read
            -- entry.count only, so details is for forensic / future
            -- /gems debug introspection use. Bounded growth.
            if #entry.details < 50 then
                table.insert(entry.details, d)
            end
        end
    end
    self:_RefreshPips()
end

function R:Clear(causeID)
    if causeID then
        self.pending[causeID] = nil
    else
        wipe(self.pending)
    end
    self:_RefreshPips()
end

function R:HasPending()
    return next(self.pending) ~= nil
end

function R:GetPending()
    return self.pending
end

----------------------------------------------------------------
-- Internal: pip rendering (pure code, no asset files)
----------------------------------------------------------------

local function CreateMinimapPip()
    local host = _G["LibDBIcon10_GRIP-EMS"]
    if not host then
        return nil
    end
    local f = CreateFrame("Frame", "GRIPEMS_ReloadGateMinimapPip", host)
    f:SetSize(14, 14)
    -- G7-POLISH-PIP-DRAG-INTERACTION: anchor outside the LDB button
    -- so the pip's mouse-event region does not overlap the parent
    -- button's drag-to-reposition gesture. Pip stays parented to the
    -- LDB button so it follows position changes. Offset (14, 14)
    -- places the 14x14 pip immediately adjacent to (above and right
    -- of) the button's top-right corner.
    f:SetPoint("BOTTOMLEFT", host, "TOPRIGHT", 0, 0)
    f:SetFrameLevel(host:GetFrameLevel() + 5)

    local bg = f:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints(f)
    local UI = GRIPEMS.UI
    local color = UI and UI.Colors and UI.Colors.reloadGateMinimap
    if color then
        bg:SetColorTexture(color:GetRGBA())
    else
        bg:SetColorTexture(1.0, 0.85, 0.0, 1.0)
    end
    f.bg = bg

    local txt = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLargeOutline")
    txt:SetPoint("CENTER", f, "CENTER", 0, 0)
    txt:SetText("!")
    txt:SetTextColor(0, 0, 0, 1)
    f.txt = txt
    if UI and UI.SetFont then
        UI:SetFont(txt, 16, "OUTLINE")
    end

    f:EnableMouse(true)
    f:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        R:_FillTooltip(GameTooltip)
        GameTooltip:Show()
    end)
    f:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)
    f:SetScript("OnMouseUp", function(self, button)
        if button == "LeftButton" then
            R:_ShowPopup()
        end
    end)
    f:Hide()
    return f
end

local function CreateSidebarPip()
    if not SettingsPanel then
        return nil
    end
    local f = CreateFrame("Frame", "GRIPEMS_ReloadGateSidebarPip", SettingsPanel)
    f:SetSize(8, 8)
    f:SetPoint("TOPRIGHT", SettingsPanel, "TOPRIGHT", -30, -45)
    f:SetFrameStrata("HIGH")

    local bg = f:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints(f)
    local UI = GRIPEMS.UI
    local color = UI and UI.Colors and UI.Colors.reloadGateSidebar
    if color then
        bg:SetColorTexture(color:GetRGBA())
    else
        bg:SetColorTexture(1.0, 0.55, 0.0, 1.0)
    end
    f.bg = bg

    f:EnableMouse(true)
    f:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        R:_FillTooltip(GameTooltip)
        GameTooltip:Show()
    end)
    f:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)
    f:SetScript("OnMouseUp", function(self, button)
        if button == "LeftButton" then
            R:_ShowPopup()
        end
    end)
    -- G.8c.4: register with the AceConfig Focus shim so TAB / ENTER routes
    -- through the pip on enabled subpanels. Idempotent: CreateSidebarPip
    -- itself only runs once (lazy on first _RefreshPips call).
    local Shim = GRIPEMS.UI and GRIPEMS.UI.AceConfigFocusShim
    if Shim and Shim.RegisterExternal then
        Shim:RegisterExternal(f, function()
            R:_ShowPopup()
        end)
    end
    if UI and UI.RegisterLargeTarget then
        UI:RegisterLargeTarget(f)
    end
    -- G7-POLISH-SIDEBAR-ANCHOR: re-resolve the pip anchor whenever the
    -- CategoryList ScrollBox recycles rows (scroll, category-list rebuild)
    -- or the SettingsPanel transitions hidden -> shown. Anchor resolution
    -- walks SettingsPanel:GetCategoryList():GetCategory(SP._blizParentCategoryID)
    -- :FindCategoryElementData -> ScrollBox:FindFrame. _GetEMSCategoryButton
    -- returns nil when the EMS row is not realized; _RefindSidebarAnchor then
    -- falls back to SettingsPanel TOPRIGHT corner so the cue stays visible.
    local catList = SettingsPanel.GetCategoryList and SettingsPanel:GetCategoryList()
    local scrollBox = catList and catList.ScrollBox
    if scrollBox and scrollBox.RegisterCallback and ScrollBoxListMixin and ScrollBoxListMixin.Event then
        scrollBox:RegisterCallback(ScrollBoxListMixin.Event.OnDataRangeChanged, function()
            R:_RefindSidebarAnchor()
        end, R)
    end
    SettingsPanel:HookScript("OnShow", function()
        R:_RefindSidebarAnchor()
    end)
    f:Hide()
    return f
end

local function _GetEMSCategoryButton()
    if not SettingsPanel or not SettingsPanel.GetCategoryList then
        return nil
    end
    local SP = GRIPEMS.SettingsPanel
    local categoryID = SP and SP._blizParentCategoryID
    if not categoryID then
        return nil
    end
    local catList = SettingsPanel:GetCategoryList()
    if not catList or not catList.ScrollBox then
        return nil
    end
    local category = catList.GetCategory and catList:GetCategory(categoryID)
    if not category then
        return nil
    end
    local elementData = catList.FindCategoryElementData and catList:FindCategoryElementData(category)
    if not elementData then
        return nil
    end
    return catList.ScrollBox.FindFrame and catList.ScrollBox:FindFrame(elementData)
end

function R:_RefindSidebarAnchor()
    if not self._sidebarPip then
        return
    end
    local pip = self._sidebarPip
    local button = _GetEMSCategoryButton()
    pip:ClearAllPoints()
    if button then
        pip:SetPoint("LEFT", button, "LEFT", -12, 0)
    elseif SettingsPanel then
        pip:SetPoint("TOPRIGHT", SettingsPanel, "TOPRIGHT", -30, -45)
    end
end

function R:_FillTooltip(tip)
    tip:SetText(L["RELOAD_GATE_TOOLTIP_TITLE"])
    if not self:HasPending() then
        tip:AddLine(L["RELOAD_GATE_TOOLTIP_NONE"], 0.7, 0.7, 0.7)
    else
        for causeID, entry in pairs(self.pending) do
            local labelKey = CAUSE_LABEL_KEYS[causeID]
            local label = (labelKey and L[labelKey]) or causeID
            tip:AddLine(string.format("%s (%d)", label, entry.count), 1, 1, 1)
        end
    end
    tip:AddLine(L["RELOAD_GATE_TOOLTIP_HINT"], 0.4, 0.7, 1.0)
end

function R:_ApplyPipColors()
    local UI = GRIPEMS.UI
    local Cs = UI and UI.Colors
    if not Cs then
        return
    end
    if self._minimapPip and self._minimapPip.bg and Cs.reloadGateMinimap then
        local r, g, b, a = Cs.reloadGateMinimap:GetRGBA()
        pcall(self._minimapPip.bg.SetColorTexture, self._minimapPip.bg, r, g, b, a)
    end
    if self._sidebarPip and self._sidebarPip.bg and Cs.reloadGateSidebar then
        local r, g, b, a = Cs.reloadGateSidebar:GetRGBA()
        pcall(self._sidebarPip.bg.SetColorTexture, self._sidebarPip.bg, r, g, b, a)
    end
end

-- G8-AUDIT-01 (Bundle D): pin / unpin the sidebar pip into the active
-- AceConfig focus-context targets array so TAB cycle reaches it.
-- Pin is idempotent (no-op when pip already in targets). Unpin removes
-- the pip and adjusts the cursor exactly the way Shim:UnregisterExternal
-- does so cycle position is preserved across the removal. Public-ish:
-- called from _RefreshPips on show/hide rising/falling edges and from
-- the cvarHealth onRewalk callback in UI/SettingsPanel.lua.

function R:_PinIntoFocusContext()
    if not self._sidebarPip then
        return
    end
    local Focus = GRIPEMS.Focus
    if not Focus or not Focus.TopContext then
        return
    end
    local top = Focus:TopContext()
    if not top or type(top.targets) ~= "table" then
        return
    end
    for i = 1, #top.targets do
        if top.targets[i] == self._sidebarPip then
            return
        end
    end
    top.targets[#top.targets + 1] = self._sidebarPip
end

function R:_UnpinFromFocusContext()
    if not self._sidebarPip then
        return
    end
    local Focus = GRIPEMS.Focus
    if not Focus or not Focus.TopContext then
        return
    end
    local top = Focus:TopContext()
    if not top or type(top.targets) ~= "table" then
        return
    end
    for i = #top.targets, 1, -1 do
        if top.targets[i] == self._sidebarPip then
            table.remove(top.targets, i)
            if top.cursor == i then
                top.cursor = nil
            elseif top.cursor and top.cursor > i then
                top.cursor = top.cursor - 1
            end
            break
        end
    end
end

function R:_RefreshPips()
    if not self._minimapPip then
        self._minimapPip = CreateMinimapPip()
    end
    if not self._sidebarPip then
        self._sidebarPip = CreateSidebarPip()
        -- G8-AUDIT-01 (Bundle D): register the pip with the FocusManager
        -- region registry so FocusRing draw-anchor lookups can find it.
        -- Idempotent at the registry level; lazy here to match pip creation.
        if self._sidebarPip and GRIPEMS.Focus and GRIPEMS.Focus.RegisterRegion then
            GRIPEMS.Focus:RegisterRegion("ReloadGateSidebarPip", self._sidebarPip)
        end
    end
    local has = self:HasPending()
    if self._minimapPip then
        if has then
            self._minimapPip:Show()
        else
            self._minimapPip:Hide()
        end
    end
    if self._sidebarPip then
        if has then
            self._sidebarPip:Show()
            self:_RefindSidebarAnchor()
        else
            self._sidebarPip:Hide()
        end
    end
    -- G8-AUDIT-01 (Bundle D): pin on rising edge so the now-visible pip
    -- becomes a TAB stop in the active context; unpin on falling edge so
    -- a hidden pip never sits as a TAB stop. The Shim:RegisterExternal
    -- path (CreateSidebarPip) covers the panel-opens-while-pip-shown
    -- case via appendExternals. These transitions cover the inverse
    -- (pip toggles while a panel is already open).
    if has and not self._wasShowing then
        self:_PinIntoFocusContext()
    elseif not has and self._wasShowing then
        self:_UnpinFromFocusContext()
    end
    -- G8-AUDIT-04: announce on rising edge (hidden -> shown) only.
    -- Falling edge stays silent (the announce-on-show is the cue).
    if has and not self._wasShowing then
        if GRIPEMS.Speech and GRIPEMS.Speech.Announce then
            GRIPEMS.Speech:Announce(L["ACCESS_ANNOUNCE_RELOAD_PENDING"])
        end
    end
    self._wasShowing = has
end

----------------------------------------------------------------
-- Internal: popup
----------------------------------------------------------------

local function BuildPopupBody()
    local total = 0
    local actionCount = 0
    local lines = {}
    for causeID, entry in pairs(R.pending) do
        local labelKey = CAUSE_LABEL_KEYS[causeID]
        local label = (labelKey and L[labelKey]) or causeID
        table.insert(lines, string.format("- %s (%d)", label, entry.count))
        total = total + entry.count
        actionCount = actionCount + 1
    end
    return total, actionCount, table.concat(lines, "\n")
end

GRIPEMS.Popup:Define("GRIPEMS_RELOAD_GATE_POPUP", {
    text = "%s",
    button1 = L["RELOAD_GATE_RELOAD_NOW"],
    button2 = L["RELOAD_GATE_LATER"],
    OnAccept = function()
        R:_OnReloadNow()
    end,
    OnCancel = function()
        R:_OnLater()
    end,
    timeout = 0,
    hideOnEscape = true,
})

function R:_ShowPopup()
    if not self:HasPending() then
        return
    end
    local total, actionCount, body = BuildPopupBody()
    local text = string.format(L["RELOAD_GATE_POPUP_BODY"], total, actionCount, body)
    GRIPEMS.Popup:Show("GRIPEMS_RELOAD_GATE_POPUP", text)
    -- G8-AUDIT-10: speak the popup body so Tier A TTS users hear it.
    if GRIPEMS.Speech and GRIPEMS.Speech.Announce then
        GRIPEMS.Speech:Announce(text)
    end
end

function R:_OnReloadNow()
    ReloadUI()
end

function R:_OnLater()
    self.suppressed = true
end

function R:_OnSettingsPanelClose()
    if not self:HasPending() then
        return
    end
    if self.suppressed then
        self.suppressed = false
        return
    end
    self:_ShowPopup()
end

----------------------------------------------------------------
-- Boot: hook SettingsPanel close once it exists.
----------------------------------------------------------------

local function InstallPanelHook()
    if R._panelHookInstalled then
        return
    end
    if not _G.SettingsPanel then
        return
    end
    _G.SettingsPanel:HookScript("OnHide", function()
        R:_OnSettingsPanelClose()
    end)
    R._panelHookInstalled = true
end

local readyFrame = _G["GRIPEMS_ReloadGateReady"] or CreateFrame("Frame", "GRIPEMS_ReloadGateReady")
readyFrame:UnregisterAllEvents()
readyFrame:RegisterEvent("PLAYER_LOGIN")
readyFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
readyFrame:SetScript("OnEvent", function(self, event)
    InstallPanelHook()
    R:_RefreshPips()
    if not R._paletteListenerRegistered and GRIPEMS.UI and GRIPEMS.UI.OnPaletteChanged then
        GRIPEMS.UI:OnPaletteChanged(function()
            R:_ApplyPipColors()
        end)
        R._paletteListenerRegistered = true
    end
    if event == "PLAYER_ENTERING_WORLD" then
        self:UnregisterEvent("PLAYER_ENTERING_WORLD")
    end
end)
