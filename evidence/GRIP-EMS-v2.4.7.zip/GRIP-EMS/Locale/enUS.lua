-- GRIP-EMS: English Locale (Default)
-- All user-facing strings. L["key"] = true means display text equals the key.
-- Created: 2026-03-31
-- Updated: 2026-08-17
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)

local L = LibStub("AceLocale-3.0"):NewLocale("GRIP-EMS", "enUS", true)
if not L then
    return
end

-- General
L["GRIP - Enhanced Macro Sequencer"] = true

-- Slash command help
L["GEMS_HELP_HEADER"] = "Available commands:"
L["GEMS_HELP_NONE"] = "  /gems - Open the main window (or show help if the window is not ready)"
L["GEMS_HELP_HELP"] = "  /gems help - This help message"
L["GEMS_HELP_CREATE"] = "  /gems create [name] - Create a test sequence (default: TestSeq)"
L["GEMS_HELP_DELETE"] = "  /gems delete <name> - Delete a sequence and its macro stub"
L["GEMS_HELP_LIST"] = "  /gems list - List all active sequences"
L["GEMS_HELP_TEST"] = "  /gems test <name> - Advance step manually (debug)"
L["GEMS_HELP_RESET"] = "  /gems reset <name> - Reset sequence to step 1"
L["GEMS_HELP_DEBUG"] = "  /gems debug - Toggle debug mode"
L["GEMS_HELP_STATUS"] = "  /gems status - Show what's running"
L["GEMS_HELP_TESTLOCALE"] = "  /gems testlocale - Test locale translation"
L["GEMS_HELP_TESTSPELLID"] = "  /gems testspellid - Test spell ID resolution"

-- Slash command responses
L["GEMS_VERSION"] = "|cFF00CC66GRIP|r - Enhanced Macro Sequencer |cFFAAAAAAv%s|r"
L["GEMS_DEBUG_ENABLED"] = "Debug mode |cFF00FF00enabled|r."
L["GEMS_DEBUG_DISABLED"] = "Debug mode |cFFFF4444disabled|r."
L["GEMS_UNKNOWN_CMD"] = "Unknown command '%s'. Type /gems help for available commands."

-- Sequence creation/deletion
L["GEMS_CREATED"] = "Sequence |cFF00FF00'%s'|r created with %d steps (%s)."
L["GEMS_DELETED"] = "Sequence |cFF00FF00'%s'|r deleted."
L["GEMS_ALREADY_EXISTS"] = "Sequence '%s' already exists. Delete it first with /gems delete %s"
L["GEMS_NOT_FOUND"] = "Sequence '%s' not found."
L["GEMS_DELETE_NEED_NAME"] = "Usage: /gems delete <name>"

-- Sequence list
L["GEMS_LIST_HEADER"] = "Active sequences (%d):"
L["GEMS_LIST_ENTRY"] = "  |cFF00FF00%s|r - %d steps, step %d/%d (%s)"
L["GEMS_LIST_EMPTY"] = "No active sequences. Use /gems create to make one."

-- Sequence test/reset
L["GEMS_TEST_NEED_NAME"] = "Usage: /gems test <name>"
L["GEMS_TEST_ADVANCED"] = "|cFF00FF00%s|r: advanced to step %d/%d."
L["GEMS_RESET_NEED_NAME"] = "Usage: /gems reset <name>"
L["GEMS_RESET_DONE"] = "|cFF00FF00%s|r: reset to step 1."

-- Status
L["GEMS_STATUS_HEADER"] = "--- GRIP-EMS Status ---"
L["GEMS_STATUS_SEQUENCES"] = "Active sequences: %d"
L["GEMS_STATUS_MACROS"] = "Macro slots: %d/%d per-character used"
L["GEMS_STATUS_KEYDOWN"] = "ActionButtonUseKeyDown: %s (buttons override: true)"
L["GEMS_STATUS_SQW"] = "SpellQueueWindow: %s ms"
L["GEMS_STATUS_OOC"] = "OOC queue: %d pending"
L["GEMS_STATUS_LOADOUT"] = "  Saved loadout: %d (%s)"
L["GEMS_STATUS_LOADOUT_NONE"] = "  Saved loadout: not selected yet"
L["GEMS_STATUS_PENDING_ACTIVE"] = "  Pending switch: target %d, elapsed %.1fs"
L["GEMS_STATUS_PENDING_NONE"] = "  Pending switch: no switch in progress"
L["GEMS_LM_FAIL_COMMIT_REJECTED"] = "Loadout switch failed: server rejected commit for build %d."
L["GEMS_LM_FAIL_TIMEOUT"] = "Loadout switch timed out after 15 seconds for build %d."
L["GEMS_LM_FAIL_PARTIAL"] = "Loadout switch ended with a different build active (target %d, got %d)."
L["GEMS_LM_FAIL_CANNOT_EDIT_TALENTS"] = "Cannot switch loadouts right now (in combat or restricted)."

-- Step function descriptions
L["GEMS_STEPFUNC_SEQUENTIAL_DESC"] = "Cycles through steps in order: 1, 2, 3, ..., N, 1, ..."
L["GEMS_STEPFUNC_RANDOM_DESC"] = "Picks a random step each press"
L["GEMS_STEPFUNC_PRIORITY_DESC"] = "Higher-numbered steps fire more often than lower ones (weighted)"
L["GEMS_STEPFUNC_REVERSEPRIORITY_DESC"] =
    "Inverted priority: later steps (bottom of list) fire more often than earlier ones"

-- Validation errors
L["GEMS_STEP_TOO_LONG"] = "Step %d is too long (%d chars, max %d)."
L["GEMS_STEP_NIL"] = "Step %d is missing."
L["GEMS_ERR_NO_NAME"] = "Sequence name is required."

-- Macro manager
L["GEMS_ERR_NO_MACRO_SLOTS"] = "No free macro slots (%d/%d slots used on this character)."
L["GEMS_ERR_MACRO_CREATE_FAILED"] = "Failed to create the macro for sequence '%s'."
L["GEMS_MACRO_CREATED"] = "Macro stub '%s' created (slot %d)."
L["GEMS_MACROS_SCANNED"] = "Reclaimed %d existing GRIP-EMS macro stubs."
L["GEMS_WARN_KP_LINES_TRIMMED"] = "Key Press: %d of %d lines fit in the step macro (255-char limit)"
L["GEMS_WARN_KR_LINES_TRIMMED"] = "Key Release: %d of %d lines fit in the step macro (255-char limit)"
L["GEMS_WARN_KP_STEP_OVERFLOW"] =
    "Key Press: fits in %d of %d steps (%d steps run without Key Press because of the 255-char limit)"
L["GEMS_KP_STATUS_ALL_FIT"] = "Fits in all %d steps"
L["GEMS_KP_STATUS_PARTIAL"] = "Fits in %d/%d steps (255-char limit)"
L["GEMS_KP_STATUS_NONE"] = "Too long for any step (0/%d)"

-- OOC Queue
L["GEMS_OOC_QUEUED"] = "Operation queued for out-of-combat processing."
L["GEMS_OOC_PROCESSED"] = "Processed %d queued operations."
L["GEMS_OOC_REPLACED"] = "OOC Queue: replaced %s for %s"
L["GEMS_OOC_PRIORITY_PROCESSED"] = "OOC Queue: processed %d items (priority order)"

-- Keybind manager
L["GEMS_HELP_BIND"] = "  /gems bind <name> <key> - Bind a key to fire a sequence (e.g. CTRL-F12)"
L["GEMS_HELP_UNBIND"] = "  /gems unbind <name> - Remove keybinding from a sequence"
L["GEMS_HELP_BINDS"] = "  /gems binds - List all keybindings for current spec"
L["GEMS_HELP_SWAP"] = "  /gems swap <name> <n> - Pin the running version to version n (until unpinned)"
L["GEMS_HELP_UNPIN"] = "  /gems unpin <name> - Clear the pin; use the context or default version"
L["GEMS_BIND_SUCCESS"] = "Bound |cFF00FF00'%s'|r to |cFFFFFF00%s|r. Press the key to fire the sequence."
L["GEMS_BIND_NEED_ARGS"] = "Usage: /gems bind <name> <key> (e.g. /gems bind TestSeq CTRL-F12)"
L["GEMS_UNBIND_SUCCESS"] = "Unbound |cFF00FF00'%s'|r."
L["GEMS_UNBIND_NO_BIND"] = "Sequence '%s' has no keybinding."
L["GEMS_UNBIND_NEED_NAME"] = "Usage: /gems unbind <name>"
L["GEMS_BINDS_HEADER"] = "Keybindings (spec %d):"
L["GEMS_BINDS_ENTRY"] = "  |cFFFFFF00%s|r -> |cFF00FF00%s|r"
L["GEMS_BINDS_EMPTY"] = "No keybindings set. Use /gems bind <name> <key>."
-- Version quick-swap / pin
L["GEMS_SWAP_USAGE"] = "Usage: /gems swap <sequence> <version#>"
L["GEMS_UNPIN_USAGE"] = "Usage: /gems unpin <sequence>"
L["GEMS_SWAP_DONE"] = "%s is now running version %d."
L["GEMS_SWAP_DONE_COMBAT"] = "%s will switch to version %d when combat ends."
L["GEMS_UNPIN_DONE"] = "%s is back to its context or default version."
L["GEMS_KEYBINDS_LOADED"] = "Loaded %d keybindings for spec %d."
L["GEMS_KEYBINDS_LOST_WARN"] = "Your sequence keybinds didn't load this time, but your saved binds are still here."
L["GEMS_KEYBINDS_LOST_HINT"] = "Type /gems binds restore to put them back."
L["GEMS_KEYBINDS_RESTORE_DONE"] = "Restored %d keybind(s)."
L["GEMS_KEYBINDS_RESTORE_NONE"] = "Nothing saved to restore from yet."
L["GEMS_KEYBINDS_PRUNED_NOTICE"] =
    "Removed %d keybind(s) from a deleted loadout. Type /gems binds restore to get them back."
L["GEMS_KEYBINDS_CLEARED_NOTICE"] = "Cleared %d keybind(s) from that loadout."
L["GEMS_VEHICLE_EXT_COLLISION"] = "Sky riding binds from %s also use: %s"
L["GEMS_STATUS_KEYBINDS"] = "Keybindings: %d for current spec"

-- IF action node UI surfaces (spec section 10)
L["GEMS_IF_COND_HINT"] = "e.g. mod:shift, combat, harm"
L["GEMS_IF_COND_TOOLTIP_TITLE"] = "Macro condition"
L["GEMS_IF_COND_TOOLTIP_BODY"] =
    "Type a WoW macro conditional. Comma-separated values are AND'd. Multiple bracket forms (e.g. [a][b]) are OR'd. Full reference: warcraft.wiki.gg/wiki/Macro_conditionals"
L["GEMS_IF_COND_INVALID"] = "Invalid condition"
L["GEMS_IF_PATH_SINGLE"] = "Single line"
L["GEMS_IF_PATH_TWO_LINE"] = "Two-line split"
L["GEMS_IF_PATH_PER_STEP"] = "Per-step"
L["GEMS_IF_PATH_FALL_THROUGH"] = "Fall-through"
L["GEMS_IF_PREVIEW_HEADER"] = "Compiled output"
L["GEMS_IF_PREVIEW_NEG_LABEL"] = "neg"
L["GEMS_IF_PREVIEW_EMPTY"] = "(no compiled output)"
L["GEMS_IF_LEN_WARN"] = "Approaching 255-char limit (%d)"
L["GEMS_IF_LEN_ERROR"] = "Exceeds 255-char limit (%d)"

-- IF action node combat-blocked command lint (spec section 10.8, 11.6, Phase H2)
L["GEMS_IF_LINT_COMBAT_BLOCKED_MARKER"] = "combat-blocked: %s"
L["GEMS_IF_LINT_COMBAT_BLOCKED_TOOLTIP_HEADER"] = "Combat-blocked commands:"
L["GEMS_IF_LINT_COMBAT_BLOCKED_HARD"] = "%s -- blocked in combat"
L["GEMS_IF_LINT_COMBAT_BLOCKED_PARTIAL"] = "%s -- partially blocked in combat"
L["GEMS_IF_LINT_COMBAT_BLOCKED_TOOLTIP_HINT"] = "Gate with [nocombat] in the Cond box, or move to an OOC sequence."
L["GEMS_IF_LINT_COMBAT_BLOCKED_VALIDATE_FMT"] = "Node %s: compiled step contains combat-blocked command %s"
L["GEMS_INTERLEAVE_OVERFLOW_LOOP_FMT"] =
    "Node %s: interval %s exceeds this loop's %s compiled steps. Clamped to %s so it still fires. Set the loop's Repeat to %s for an exact interval of %s."
L["GEMS_INTERLEAVE_OVERFLOW_ROOT_FMT"] =
    "Node %s: interval %s exceeds the sequence's %s base steps. Clamped to %s so it still fires; lower the interval to that or less for an exact interval."
L["GEMS_INTERLEAVE_BUDGET_FMT"] =
    "Node %s: the interleave copy budget (%s) is spent. This action emits %s of its %s copies. Lower an interval or remove an interleave."

-- IF action node conditional picker (spec section 10.7, Phase H1)
L["GEMS_IF_PICKER_TITLE"] = "Conditional picker"
L["GEMS_IF_PICKER_TAB_COMBAT"] = "Combat-relevant"
L["GEMS_IF_PICKER_TAB_GENERAL"] = "General-purpose"
L["GEMS_IF_PICKER_TAB_UI"] = "UI-state"
L["GEMS_IF_PICKER_APPLY"] = "Apply"
L["GEMS_IF_PICKER_CANCEL"] = "Cancel"
L["GEMS_IF_PICKER_NEGATE"] = "not"
L["GEMS_IF_PICKER_NEGATE_TOOLTIP"] =
    "Negate this conditional. mod:shift becomes nomod:shift, harm becomes noharm, etc. Spec section 5.2 (DeMorgan)."
L["GEMS_IF_PICKER_OR_GROUP_WARNING"] =
    "Multi-bracket OR groups not editable in picker (Phase H4). Use Cancel to keep the current value, or empty the Cond box and re-pick if you want a single-clause condition."

-- Combat-relevant rows
L["GEMS_IF_PICKER_COMBAT_LABEL"] = "combat"
L["GEMS_IF_PICKER_COMBAT_TOOLTIP"] =
    "True while you are in combat. Use to gate burst cooldowns or lockout-only abilities."
L["GEMS_IF_PICKER_NOCOMBAT_LABEL"] = "nocombat"
L["GEMS_IF_PICKER_NOCOMBAT_TOOLTIP"] =
    "True while you are out of combat. Use for pre-pull buffs, mount casts, or reset behaviours."
L["GEMS_IF_PICKER_HARM_LABEL"] = "harm"
L["GEMS_IF_PICKER_HARM_TOOLTIP"] = "True when your target is hostile. Pair with help in mixed friend/foe macros."
L["GEMS_IF_PICKER_HELP_LABEL"] = "help"
L["GEMS_IF_PICKER_HELP_TOOLTIP"] = "True when your target is friendly. Use for heals in mixed damage/heal macros."
L["GEMS_IF_PICKER_DEAD_LABEL"] = "dead"
L["GEMS_IF_PICKER_DEAD_TOOLTIP"] =
    "True when the target unit is dead. Use to swap to a resurrection spell or skip the cast."
L["GEMS_IF_PICKER_STEALTH_LABEL"] = "stealth"
L["GEMS_IF_PICKER_STEALTH_TOOLTIP"] =
    "True while in Stealth, Prowl, or Shadowmeld. Use for opener vs continuation branching."
L["GEMS_IF_PICKER_PVPCOMBAT_LABEL"] = "pvpcombat"
L["GEMS_IF_PICKER_PVPCOMBAT_TOOLTIP"] = "True while flagged for PvP combat. Use to swap PvP vs PvE talents or trinkets."
L["GEMS_IF_PICKER_CHANNELING_LABEL"] = "channelling"
L["GEMS_IF_PICKER_CHANNELING_TOOLTIP"] =
    "True while you are channelling a spell. Use to skip casts that would interrupt the channel."
L["GEMS_IF_PICKER_PET_LABEL"] = "pet"
L["GEMS_IF_PICKER_PET_TOOLTIP"] =
    "True when a pet (matching the optional name or family) is active. Leave the field empty to match any pet."
L["GEMS_IF_PICKER_NOPET_LABEL"] = "nopet"
L["GEMS_IF_PICKER_NOPET_TOOLTIP"] =
    "True when no pet is active. Used by the Hunter pattern to substitute a self-cast when soloing."
L["GEMS_IF_PICKER_PETBATTLE_LABEL"] = "petbattle"
L["GEMS_IF_PICKER_PETBATTLE_TOOLTIP"] = "True while in a pet battle. Use to swap to pet-battle abilities."
L["GEMS_IF_PICKER_MOD_LABEL"] = "mod:<key>"
L["GEMS_IF_PICKER_MOD_TOOLTIP"] =
    "True when the chosen modifier key is held. Pick shift, ctrl, alt, or an L/R variant for AoE vs single-target swaps."
L["GEMS_IF_PICKER_BUTTON_LABEL"] = "button:N"
L["GEMS_IF_PICKER_BUTTON_TOOLTIP"] =
    "True when the macro fired from the chosen mouse button or bind index. 1=left, 2=right, 3=middle, 4 and 5 are side buttons."
L["GEMS_IF_PICKER_PARTY_LABEL"] = "party"
L["GEMS_IF_PICKER_PARTY_TOOLTIP"] =
    "True while in a party. Use for group-only utility such as Battle Resurrection or party-target buffs."
L["GEMS_IF_PICKER_RAID_LABEL"] = "raid"
L["GEMS_IF_PICKER_RAID_TOOLTIP"] = "True while in a raid. Use for raid-only burst windows or cooldown alignment."
L["GEMS_IF_PICKER_EXISTS_LABEL"] = "exists"
L["GEMS_IF_PICKER_EXISTS_TOOLTIP"] =
    "True when the target unit exists. Pair with @focus or @mouseover so the macro has a fallback when the unit is gone."
L["GEMS_IF_PICKER_UNITVEHICLE_LABEL"] = "unithasvehicleui"
L["GEMS_IF_PICKER_UNITVEHICLE_TOOLTIP"] =
    "True when the unit is presenting a vehicle UI. Use to skip casts that would target the driver instead of the vehicle."

-- General-purpose rows
L["GEMS_IF_PICKER_MOUNTED_LABEL"] = "mounted"
L["GEMS_IF_PICKER_MOUNTED_TOOLTIP"] =
    "True while you are mounted. Common pattern: dismount in the true branch, cast a mount in the false branch."
L["GEMS_IF_PICKER_SWIMMING_LABEL"] = "swimming"
L["GEMS_IF_PICKER_SWIMMING_TOOLTIP"] = "True while you are swimming. Use to swap to a swim-form mount or aquatic spell."
L["GEMS_IF_PICKER_FLYING_LABEL"] = "flying"
L["GEMS_IF_PICKER_FLYING_TOOLTIP"] =
    "True while you are airborne on a flying mount. Use to skip ground-only casts mid-flight."
L["GEMS_IF_PICKER_FLYABLE_LABEL"] = "flyable"
L["GEMS_IF_PICKER_FLYABLE_TOOLTIP"] =
    "True in zones where standard flying is allowed. Pair with mount toggles for ground vs air swaps."
L["GEMS_IF_PICKER_ADVFLYABLE_LABEL"] = "advflyable"
L["GEMS_IF_PICKER_ADVFLYABLE_TOOLTIP"] =
    "True in zones where Skyriding is allowed. Use for sky vs ground mount swaps in modern zones."
L["GEMS_IF_PICKER_INDOORS_LABEL"] = "indoors"
L["GEMS_IF_PICKER_INDOORS_TOOLTIP"] =
    "True while indoors (mount-blocked area). Use to skip mount casts that would error or to fall back to a teleport."
L["GEMS_IF_PICKER_OUTDOORS_LABEL"] = "outdoors"
L["GEMS_IF_PICKER_OUTDOORS_TOOLTIP"] = "True while outdoors. Mirror of indoors; use for mount or ground-spell branches."
L["GEMS_IF_PICKER_RESTING_LABEL"] = "resting"
L["GEMS_IF_PICKER_RESTING_TOOLTIP"] =
    "True while resting in an inn or capital. Use for free-cast buffs or hearthstone shortcuts."
L["GEMS_IF_PICKER_GROUP_LABEL"] = "group"
L["GEMS_IF_PICKER_GROUP_TOOLTIP"] = "True while in any group (party or raid). Quick group-vs-solo branch."
L["GEMS_IF_PICKER_NOGROUP_LABEL"] = "nogroup"
L["GEMS_IF_PICKER_NOGROUP_TOOLTIP"] = "True when soloing. Use for solo burst that would be wasteful in a group context."
L["GEMS_IF_PICKER_SPEC_LABEL"] = "spec:N"
L["GEMS_IF_PICKER_SPEC_TOOLTIP"] =
    "True when the chosen specialisation slot (1-4) is active. Pair with utility branches per spec."
L["GEMS_IF_PICKER_FORM_LABEL"] = "form:N"
L["GEMS_IF_PICKER_FORM_TOOLTIP"] =
    "True when the chosen shapeshift or stance form is active. Druid, Warrior, and Rogue stance branches."
L["GEMS_IF_PICKER_STANCE_LABEL"] = "stance:N"
L["GEMS_IF_PICKER_STANCE_TOOLTIP"] = "Alias for form. Same semantics; kept for legacy macro compatibility."
L["GEMS_IF_PICKER_EQUIPPED_LABEL"] = "equipped:type"
L["GEMS_IF_PICKER_EQUIPPED_TOOLTIP"] =
    "True when the chosen item type is equipped (e.g. Sword, Shield, Polearm). Use for weapon-aware swaps."
L["GEMS_IF_PICKER_WORN_LABEL"] = "worn:type"
L["GEMS_IF_PICKER_WORN_TOOLTIP"] = "Alias for equipped. Same semantics."
L["GEMS_IF_PICKER_KNOWN_LABEL"] = "known:spell"
L["GEMS_IF_PICKER_KNOWN_TOOLTIP"] =
    "True when the chosen spell is known. Replaces the removed talent: conditional; type the spell name into the field."
L["GEMS_IF_PICKER_CANEXITVEHICLE_LABEL"] = "canexitvehicle"
L["GEMS_IF_PICKER_CANEXITVEHICLE_TOOLTIP"] =
    "True while in a vehicle that allows exiting. Pair with /run VehicleExit() guards."

-- UI-state rows
L["GEMS_IF_PICKER_BONUSBAR_LABEL"] = "bonusbar:N"
L["GEMS_IF_PICKER_BONUSBAR_TOOLTIP"] =
    "True when the chosen bonus action bar (1-10) is active. Pair with stance or form toggles."
L["GEMS_IF_PICKER_OVERRIDEBAR_LABEL"] = "overridebar"
L["GEMS_IF_PICKER_OVERRIDEBAR_TOOLTIP"] =
    "True when the override action bar is active (vehicle, possess, or quest override)."
L["GEMS_IF_PICKER_POSSESSBAR_LABEL"] = "possessbar"
L["GEMS_IF_PICKER_POSSESSBAR_TOOLTIP"] = "True when the possess bar is active (mind control or certain quests)."
L["GEMS_IF_PICKER_VEHICLEUI_LABEL"] = "vehicleui"
L["GEMS_IF_PICKER_VEHICLEUI_TOOLTIP"] =
    "True when the vehicle UI is active. Use when driving a mount-style vehicle with its own action bar."
L["GEMS_IF_PICKER_EXTRABAR_LABEL"] = "extrabar"
L["GEMS_IF_PICKER_EXTRABAR_TOOLTIP"] = "True when the extra action button is visible (boss fight or quest button)."
L["GEMS_IF_PICKER_CURSOR_LABEL"] = "cursor"
L["GEMS_IF_PICKER_CURSOR_TOOLTIP"] =
    "True when an item or spell is on the cursor. Use to skip casts that would consume the pickup."
L["GEMS_IF_PICKER_ACTIONBAR_LABEL"] = "actionbar:N"
L["GEMS_IF_PICKER_ACTIONBAR_TOOLTIP"] =
    "True when the chosen action bar page (1-12) is active. Pair with stance or form macros."
L["GEMS_IF_PICKER_BAR_LABEL"] = "bar:N"
L["GEMS_IF_PICKER_BAR_TOOLTIP"] = "Alias for actionbar. Same semantics; commonly used in older macros."
L["GEMS_IF_PICKER_SHAPESHIFT_LABEL"] = "shapeshift"
L["GEMS_IF_PICKER_SHAPESHIFT_TOOLTIP"] = "True when in any shapeshift form. Use for caster vs animal-form branching."
L["GEMS_IF_PICKER_HOUSE_LABEL"] = "house:where"
L["GEMS_IF_PICKER_HOUSE_TOOLTIP"] =
    "True when at the chosen housing location (inside, plot, editor, or neighbourhood). Use for housing toy macros."
L["GEMS_IF_PICKER_SEARCH_SPELL_HINT"] = "Search spell..."
L["GEMS_IF_PICKER_PETMODE_FAMILY"] = "F"
L["GEMS_IF_PICKER_PETMODE_NAME"] = "N"
L["GEMS_IF_PICKER_PETMODE_TOOLTIP"] = "Toggle: F = pick from family list, N = type a literal pet name"

-- IF action node conditional picker Custom tab (Phase H1.7)
L["GEMS_IF_PICKER_CUSTOM_TAB"] = "Custom"
L["GEMS_IF_PICKER_CUSTOM_HEADER"] = "Custom spell reference"
L["GEMS_IF_PICKER_CUSTOM_HINT"] = "Enter a spell ID or name. Either field fills the other when validated."
L["GEMS_IF_PICKER_CUSTOM_ID_LABEL"] = "Spell ID"
L["GEMS_IF_PICKER_CUSTOM_NAME_LABEL"] = "Name"
L["GEMS_IF_PICKER_CUSTOM_RESOLVED"] = "Resolved: %s (ID %s)"
L["GEMS_IF_PICKER_CUSTOM_UNRESOLVED"] = "Spell not in cache (will use raw value)"
L["GEMS_IF_PICKER_CUSTOM_FOUND"] = "Found %d matches"

-- Phase H1.9a: SpellPicker Spec filter sub-scope dropdown
L["GEMS_SPELLPICKER_SPEC_SCOPE_LABEL"] = "Scope:"
L["GEMS_SPELLPICKER_SPEC_SCOPE_CURRENT"] = "Current spec"
L["GEMS_SPELLPICKER_SPEC_SCOPE_ALL"] = "All specs"

-- Phase H1.9b: SpellPicker All Classes filter tab + class scope dropdown
L["GEMS_SPELLPICKER_ALLCLASSES"] = "All Classes"
L["GEMS_SPELLPICKER_CLASS_SCOPE_ALL"] = "All classes"
L["GEMS_SPELL_CACHE_UNRESOLVED"] =
    "GRIP-EMS: Unrecognised spell(s) after rescan: %s. If these are valid in your current talent loadout, run /reload."
L["GEMS_SPELL_CATALOG_DRIFT"] =
    "Spell catalogue last refreshed for build %s; you are on %s. Browsing may show outdated or missing entries."
L["GEMS_SETTING_UNRESOLVED_WARN_LABEL"] = "Warn in chat about unrecognised spells"
L["GEMS_SETTING_UNRESOLVED_WARN_DESC"] =
    "Print a chat message when a sequence references a spell name that does not resolve in your current spellbook. Off by default. Affected sequences are always flagged with an icon in the list."

-- Phase H4b: Conditional builder modal chrome
L["GEMS_IF_BUILDER_TITLE"] = "Conditional builder"
L["GEMS_IF_BUILDER_CLAUSE_HEADER"] = "OR clause %d"
L["GEMS_IF_BUILDER_ADD_OR_CLAUSE"] = "+ Add OR clause"
L["GEMS_IF_BUILDER_REMOVE_CLAUSE"] = "Remove"
L["GEMS_IF_BUILDER_APPLY"] = "Apply"
L["GEMS_IF_BUILDER_CANCEL"] = "Cancel"
L["GEMS_IF_BUILDER_PREVIEW"] = "Preview: %s"
-- Phase H4c: interactive multi-clause builder + picker escalation
L["GEMS_IF_BUILDER_CONVERT_TO_OR"] = "Convert to OR group"
L["GEMS_IF_BUILDER_EMPTY_CLAUSE_WARN"] = "Add a condition or remove this clause"
-- Phase H4d: targeting tab
L["GEMS_IF_BUILDER_TARGETING_TAB"] = "Targeting"
L["GEMS_IF_BUILDER_TARGETING_NONE"] = "(none)"
L["GEMS_IF_BUILDER_TARGETING_UNIT_HINT"] = "Custom unit (e.g. raid1, party2, arena1)"

-- Import/Export
L["GEMS_HELP_IMPORT"] = "  /gems import - Open import window (paste export strings)"
L["GEMS_HELP_EXPORT"] = "  /gems export <name> - Export a sequence as GRIP string"
L["GEMS_IMPORT_ENTRY"] = "  - '%s' (%d steps)"
L["GEMS_IMPORT_FAILED"] = "Import failed: %s"
L["GEMS_IMPORT_WARNING"] = "Warning: %s"
L["GEMS_IMPORT_USAGE"] = "Usage: /gems import (opens paste window for export strings)"
L["GEMS_EXPORT_USAGE"] = "Usage: /gems export <name>"
L["GEMS_EXPORT_RESULT"] = "Export: %s"
L["GEMS_EXPORT_FAILED"] = "Export failed: %s"
L["GEMS_IMPORT_PASTE_INSTRUCTIONS"] = "Paste an export string below, then click Import."
L["GEMS_IMPORT_PASTE_LABEL"] = "Export String"
L["GEMS_IMPORT_CLEAR"] = "Clear"
L["GEMS_IMPORT_SHORT_STRING"] = "Hint: Use /gems import (no args) to open the paste window for long strings."
L["GEMS_IMPORT_USE_FRAME"] =
    "Tip: The string may have been truncated. Use |cFFFFFF00/gems import|r to open the paste window."
L["GEMS_IMPORT_UNKNOWN_FORMAT"] = "Unknown import format"
L["GEMS_IMPORT_ACTION_SKIPPED"] = "Skipped action: %s"
L["GEMS_IMPORT_EMBED_SKIPPED"] = "Embedded sequence '%s' skipped (not available)"
L["GEMS_IMPORT_PAUSE_CONVERTED"] = "Pause converted to %d empty step(s)"
L["GEMS_IMPORT_INTERVAL_PRESERVED"] = "Preserved %d interleave action(s)"
L["GEMS_IMPORT_EMPTY_CASTSEQ_STRIPPED"] = "Removed %d empty cast sequence line(s) (they error on every press in-game)"
L["GEMS_ACTION_INTERLEAVE_EVERY"] = "Every:"
L["GEMS_ACTION_INTERLEAVE_STEPS"] = "steps"
L["GEMS_INTERLEAVE_TOOLTIP_TITLE"] = "Interleave"
L["GEMS_INTERLEAVE_TOOLTIP_DESC"] =
    "When enabled, this action only fires every N key presses instead of every press. Useful for long-cooldown buffs alongside your main rotation."
L["GEMS_INTERLEAVE_NOBASE_WARN"] =
    "All actions are set to Interleave, so there is no base step to interleave into. Compiled them as a normal rotation instead. Turn off Interleave on at least one action to set your base rotation."
L["GEMS_ADD_ACTION_INTERLEAVE"] = "Action (Interleave)"

-- Layer 4: Macro action type (editor-side picker + drift UI)
L["GEMS_ADD_ACTION_MACRO"] = "Macro"
L["GEMS_MACRO_PICKER_TITLE"] = "Pick a Macro"
L["GEMS_MACRO_PICKER_SEARCH"] = "Search..."
L["GEMS_MACRO_PICKER_SOURCE_WOW"] = "WoW only"
L["GEMS_MACRO_PICKER_SOURCE_EMS"] = "EMS only"
L["GEMS_MACRO_PICKER_SOURCE_BOTH"] = "Both"
L["GEMS_MACRO_PICKER_EMPTY"] = "No macros found."
L["GEMS_MACROREF_NAME"] = "Macro:"
L["GEMS_MACROREF_DRIFT_INDICATOR"] = "stored body differs from /macro"
L["GEMS_MACROREF_SOURCE_MISSING"] = "source macro missing -- re-pick from picker"
L["GEMS_MACROREF_REFRESH"] = "Refresh from /macro"
L["GEMS_MACROREF_AUTOREFRESH"] = "Auto-refresh macro-reference steps"
L["GEMS_MACROREF_AUTOREFRESH_DESC"] =
    "When on, a step built from one of your macros updates itself after you edit that macro, so you do not have to open the step and refresh it. Off by default. Only steps you built or refreshed on this character update automatically; an imported step is left alone until you refresh it once."
L["GEMS_MACROREF_AUTOREFRESH_DEBUG"] = "Auto-refreshed macro-reference bodies in %d sequence(s)"

-- Auxiliary-macro import (audit Layer 1: closes the bare-name macro gap)
L["GEMS_IMPORT_MACRO_LINE"] = "Macro %s was imported."
L["GEMS_IMPORT_MACROS_IMPORTED"] = "%d macro(s) imported."
L["GEMS_IMPORT_MACROS_SKIPPED"] = "%d macro(s) skipped."
L["GEMS_IMPORT_MACROS_OVERFLOW"] =
    "Macro '%s' could not be created -- macro slots full (%d/%d). Delete unused /macro entries and re-import."
L["GEMS_IMPORT_MACRO_NOT_OURS"] = "Macro '%s' already exists and was not created by EMS, so it was left alone."
    .. " Rename your macro or the one in the import, then import again."
L["GEMS_IMPORT_MACROS_SECTION_HEADING"] = "Macros"
L["GEMS_IMPORT_MACROS_BADGE_NEW"] = "(New)"
L["GEMS_IMPORT_MACROS_BADGE_UPDATE"] = "(Update)"
L["GEMS_IMPORT_MACRO_DEP_MISSING"] = "%s: references macro '%s' which is not in the import payload and not in your saved macros."
    .. " The step will type '%s' into chat at runtime."
L["GEMS_IMPORT_SEQUENCE_DEP_MISSING"] =
    "%s: embeds sequence '%s' which is not in the import payload and not in your saved sequences."

-- UI strings (Phase 3)
L["GEMS_HELP_OPEN"] = "  /gems open - Open/close the main window"
L["GEMS_UI_TITLE"] = "GRIP-EMS"
L["GEMS_UI_SELECT_SEQUENCE"] = "Select a sequence to edit"
L["GEMS_UI_SEQUENCE_LIST_PLACEHOLDER"] = "Sequence list loading..."
L["GEMS_UI_NO_SEQUENCES"] = "No sequences found. Create one or import."
L["GEMS_UI_RESIZE"] = "Resize"
L["GEMS_UI_RESIZE_DESC"] = "Drag to resize the window"
L["GEMS_UI_MINIMAP_LEFT"] = "Left-click: Open/Close"
L["GEMS_UI_MINIMAP_RIGHT"] = "Right-click: Quick menu"
L["GEMS_UI_MINIMAP_RIGHTCLICK_SOON"] = "Right-click quick menu coming soon."
L["GEMS_UI_MINIMAP_OOC_QUEUE"] = "OOC Queue"
L["GEMS_UI_MINIMAP_OOC_PENDING"] = "%d pending"
L["GEMS_UI_MINIMAP_PARTY_USERS"] = "Party Users"
L["GEMS_UI_MINIMAP_PARTY_NONE"] = "none detected"

-- UI strings (Phase 3A-2): Search
L["GEMS_UI_SEARCH"] = "Search..."
L["GEMS_UI_SEARCH_DESC"] = "Filter sequences by name"

-- UI strings (Phase 3A-2): Buttons
L["GEMS_UI_NEW"] = "New"
L["GEMS_UI_NEW_DESC"] = "Create a new sequence"
L["GEMS_UI_IMPORT_BTN"] = "Import"
L["GEMS_UI_IMPORT_BTN_DESC"] = "Import a sequence from an export string"

-- UI strings (Phase 3A-2): Context menu
L["GEMS_UI_DUPLICATE"] = "Duplicate"
L["GEMS_UI_DELETE"] = "Delete"
L["GEMS_UI_EXPORT_CTX"] = "Export"
L["GEMS_UI_RENAME"] = "Rename"
L["GEMS_UI_REPAIR"] = "Repair"
L["GEMS_UI_REPAIR_ALL"] = "Fix All"

-- Repair module strings
L["GEMS_REPAIR_USAGE"] = "Usage: /gems repair <name> (or select a sequence first)"
L["GEMS_REPAIR_NOT_LOADED"] = "Repair module not loaded"
L["GEMS_REPAIR_SEQ_NOT_FOUND"] = "Sequence not found: %s"
L["GEMS_REPAIR_NONE"] = "No issues found (health: %d)"
L["GEMS_REPAIR_ALL_HEALTHY"] = "All sequences healthy!"
L["GEMS_REPAIR_IMPORT_ISSUES"] = "Imported %s. Found %d issues -- use /gems repair %s to review."
L["GEMS_REPAIR_EXPORT_WARN"] =
    "%d issues found across selected sequences. Recipients may see broken behaviour. Export anyway?"
L["GEMS_REPAIR_EXPORT_ACCEPT"] = "Export Anyway"
L["GEMS_REPAIR_SEND_WARN"] = "%d issues found. Recipients may see broken behaviour. Send anyway?"
L["GEMS_REPAIR_SEND_ACCEPT"] = "Send Anyway"

-- UI strings (Phase 3A-2): Editor header
L["GEMS_UI_SEQ_ICON"] = "Icon"
L["GEMS_UI_STEP_FUNCTION"] = "Step Function"
L["GEMS_UI_RESET_COMBAT"] = "Reset on Combat End"
L["GEMS_UI_RESET_COMBAT_DESC"] = "Reset step counter when combat ends"
L["GEMS_UI_RESET_TARGET"] = "Reset on Target Change"
L["GEMS_UI_RESET_TARGET_DESC"] = "Reset step counter when target changes (out of combat only)"
L["GEMS_UI_RESET_GEAR"] = "Equipment Change"
L["GEMS_UI_RESET_GEAR_DESC"] = "Reset step counter when equipment changes (out of combat only)"
L["GEMS_UI_RESET_SPEC"] = "Spec Change"
L["GEMS_UI_RESET_SPEC_DESC"] = "Reset step counter when specialisation changes"
L["GEMS_UI_RESET_TIMER"] = "Timer (sec)"
L["GEMS_UI_RESET_TIMER_DESC"] = "Reset the step counter after this many seconds of inactivity (0 to disable)"
L["GEMS_UI_REPEAT_COUNT"] = "Repeat"
L["GEMS_UI_REPEAT_COUNT_DESC"] =
    "Number of times to run the full sequence before cycling back to step 1. Use 1 (default) for infinite cycling. Best paired with the Sequential step function -- Priority/Reverse Priority combinations expand the weighted distribution across the repeats."
L["GEMS_UI_HOLD_ON_CHANNEL"] = "Hold While Channeling"
L["GEMS_UI_HOLD_ON_CHANNEL_DESC"] =
    "Off advances the step counter normally. Hold cursor stops the counter while you are channeling: the press casts nothing and the sequence stays put. Hold + release at max adds one thing on top, and it only ever fires on an empowered spell. Once max rank is reached the next press ends the cast right there instead of letting the last second of the hold window run out. The check reads live channel state rather than a macro conditional, so it covers the tail of an empowered cast that a conditional has already stopped seeing. The hold itself works for any channel from any source; only this control is limited to characters who have an empowered spell."
L["GEMS_UI_CHANNEL_HOLD_OFF"] = "Off"
L["GEMS_UI_CHANNEL_HOLD_HOLD"] = "Hold cursor"
L["GEMS_UI_CHANNEL_HOLD_RELEASE"] = "Hold + release at max"
L["GEMS_UI_KEYPRESS"] = "Key Press"
L["GEMS_UI_KEYPRESS_DESC"] =
    "Commands that run on key-down, before each step fires (e.g. /stopmacro [channeling]). Combined into each step's macro when the total fits within 255 characters. Steps that exceed the limit run without the key-down commands -- check the Preview tab to see which steps fit."
L["GEMS_UI_KEYRELEASE"] = "Key Release"
L["GEMS_UI_KEYRELEASE_DESC"] =
    "Commands that run on key-up, after each step fires. Combined into each step's macro when the total fits within 255 characters. Steps that exceed the limit run without the key-up commands -- check the Preview tab to see which steps fit."

-- UI strings: Metadata section
L["GEMS_EDITOR_METADATA"] = "Metadata"
L["GEMS_EDITOR_METADATA_AUTHOR"] = "Author"
L["GEMS_EDITOR_METADATA_DESCRIPTION"] = "Description"
L["GEMS_EDITOR_METADATA_HELP"] = "Help Text"
L["GEMS_EDITOR_METADATA_HELPLINK"] = "Help Link"
L["GEMS_EDITOR_METADATA_CLASS"] = "Class"
L["GEMS_EDITOR_METADATA_SPEC"] = "Spec"
L["GEMS_EDITOR_METADATA_CREATED"] = "Created"
L["GEMS_EDITOR_METADATA_UPDATED"] = "Updated"
L["GEMS_EDITOR_METADATA_CHANGELOG"] = "Changelog"
-- Per-sequence sound cue overrides (Phase 4 item 22 Phase 2)
L["GEMS_EDITOR_SEQ_SOUND_HEADER"] = "Sequence sound cues (optional)"
L["GEMS_EDITOR_SEQ_SOUND_DESC"] =
    "Override the global cue sound for this sequence. Leave empty to use the global setting."
L["GEMS_EDITOR_SEQ_SOUND_ERROR"] = "Error cue"
L["GEMS_EDITOR_SEQ_SOUND_SUCCESS"] = "Success cue"
L["GEMS_EDITOR_SEQ_SOUND_INFO"] = "Info cue"
L["GEMS_EDITOR_SEQ_SOUND_STEP"] = "Step cue"
L["GEMS_EDITOR_SEQ_SOUND_NONE"] = "(global default)"

-- UI strings: Dependencies section
L["GEMS_DEPS_HEADER"] = "Dependencies"
L["GEMS_DEPS_VARIABLES"] = "Variables"
L["GEMS_DEPS_SEQUENCES"] = "Sequences"
L["GEMS_DEPS_EMBEDDED_BY"] = "Embedded By"
L["GEMS_DEPS_NONE"] = "(none)"
L["GEMS_DEPS_NOT_EMBEDDED"] = "Not embedded by any sequence"
L["GEMS_DEPS_MACROS"] = "Macros"
L["GEMS_UI_MACRO_DEPS_SECTION"] = "Macro Dependencies"
L["GEMS_UI_MACRO_DEPS_HINT"] = "Tag macros this sequence uses so they auto-include on export."
L["GEMS_UI_MACRO_DEPS_EMPTY"] = "No macros found. Use /macro to create one."

-- UI strings (Phase 3A-2): Tabs
L["GEMS_UI_TAB_STEPS"] = "Steps"
L["GEMS_UI_TAB_KEYBIND"] = "Keybind"
L["GEMS_UI_TAB_VARIABLES"] = "Variables"
L["GEMS_UI_TAB_VARIANTS"] = "Variants"
L["GEMS_UI_TAB_RAW"] = "Source"
L["GEMS_UI_TAB_COMING_SOON"] = "Coming soon"

-- UI strings (Phase 3A-2): Step list
L["GEMS_UI_STEP_NUM"] = "#%d"
L["GEMS_UI_NO_STEPS"] = "No steps defined."
L["GEMS_UI_ADD_STEP_HINT"] = "No steps. Click '+ Add' to create one."

-- UI strings (Phase 3A-2): Dialogues
L["GEMS_UI_NEW_SEQ_DESC"] = "Enter a name for the new sequence:"
L["GEMS_UI_DELETE_CONFIRM"] = "Are you sure you want to delete '%s'? This cannot be undone."
L["GEMS_UI_DUP_DESC"] = "Enter a name for the duplicate:"
L["GEMS_UI_RENAME_DESC"] = "Enter the new name:"
L["GEMS_UI_NAME_EXISTS"] = "A sequence named '%s' already exists."
L["GEMS_UI_RENAME_PLUGIN_OWNED"] = "Cannot rename '%s': it is managed by plugin '%s'."
L["GEMS_UI_NAME_EMPTY"] = "Sequence name cannot be empty."

-- UI strings (Phase 3A-2): Status text in rows
L["GEMS_UI_ROW_SUBTITLE"] = "%s | %d steps"

-- UI strings (Phase 3A-2): Sort
L["GEMS_UI_SORT_ALPHA"] = "A-Z"
L["GEMS_UI_SORT_CLASS"] = "Class"
L["GEMS_UI_SORT_UPDATED"] = "Recent"
L["GEMS_UI_SORT_ALPHA_TIP"] = "Alphabetical"
L["GEMS_UI_SORT_CLASS_TIP"] = "By Class"
L["GEMS_UI_SORT_UPDATED_TIP"] = "Recently Updated"
L["GEMS_UI_SORT_HINT"] = "Sort"
L["GEMS_UI_SORT_CYCLE"] = "Click to cycle sort mode"
L["GEMS_UI_FILTER_CLASS"] = "Current class only"
L["GEMS_UI_FILTER_CLASS_TIP"] = "Hide sequences that belong to other classes"

-- Cross-character sequence visibility (v2.3.18 Phase 3)
L["GEMS_UI_FILTER_OTHERCHARS"] = "Other characters"
L["GEMS_UI_FILTER_OTHERCHARS_TIP"] = "Also show sequences saved on your other characters. They are read-only here."
L["GEMS_UI_OTHERCHAR_BADGE"] = "on %s"
L["GEMS_UI_OTHERCHAR_READONLY"] = "This sequence is saved on %s. Log in to that character to edit or copy it."
L["GEMS_UI_COPY_TO_CHAR"] = "Copy to character"
L["GEMS_UI_COPY_TO_CHAR_TIP"] =
    "Send a copy of this sequence to one of your other characters. It appears there at next login."
L["GEMS_UI_COPY_TO_CHAR_NONE"] = "No other characters known yet"
L["GEMS_UI_COPY_STAGED"] = "Copied %s to %s. It appears there at next login."
L["GEMS_UI_COPY_CLAIMED"] = "Received %d sequence(s) copied from another character."
L["GEMS_UI_COPY_RENAMED"] = "Received %s as %s because that name was already taken."
L["GEMS_UI_FILTER_OTHERCHARS_EMPTY"] =
    "No other characters have logged in yet. Log in on another character once and its sequences appear here."

-- Spell validation (v1.1.0)
L["GEMS_SPELL_WARN_BANNER"] = "%d spell(s) may be invalid in this sequence"
L["GEMS_SPELL_VALIDATE_SUMMARY"] = "%d sequence(s) checked: %d clean, %d with warnings"
L["GEMS_SPELL_VALIDATE_CLEAN"] = "All sequences validated -- no issues found"
L["GEMS_SPELL_VALIDATE_SEQ"] = "  %s: %d unknown, %d talent-gated"
L["GEMS_SPELL_STATUS_LABEL"] = "%d spell(s) may be invalid"
L["GEMS_SPELL_INFO_LABEL"] = "%d known but unlearned"
L["GEMS_IMPORT_FREEFORM_WARN"] =
    "'%s': %d step(s) contain raw macro commands. They will not auto-translate to other locales."
L["GEMS_IMPORT_FREEFORM_LABEL"] = "%d freeform"
L["GEMS_IMPORT_ICON_AUTO"] = "(auto-detected)"
L["GEMS_IMPORT_PICK_AUTO"] = "[auto]"
L["GEMS_IMPORT_PICK_VAR_DEPS"] = "Uses %d vars"
L["GEMS_SPELL_TOOLTIP_UNKNOWN"] = "Not found: %s"
L["GEMS_SPELL_TOOLTIP_KNOWN"] = "Not in spellbook: %s"
L["GEMS_SPELL_TOOLTIP_CONTEXTUAL"] = "Castable in the right form or state: %s"
L["GEMS_SPELL_TOOLTIP_COSMETIC"] = "|cff888888#showtooltip: %s|r"

-- Rotation Preview (v1.1.0)
L["GEMS_PLUGIN_LOADED"] = "Plugin sequences loaded for: %s"
L["GEMS_PLUGIN_NOT_FOUND"] = "Unknown plugin: %s"
L["GEMS_PLUGIN_REGISTERED"] = "Plugin registered: %s v%s (%d sequences)"
L["GEMS_PLUGIN_SKIP_EXISTS"] = "Plugin %s: skipping '%s' (user version exists)"

L["GEMS_PREVIEW_ICONS"] = "Icons"
L["GEMS_PREVIEW_TEXT"] = "Text"
L["GEMS_PREVIEW_TOGGLE_TIP"] = "Switch preview mode"
L["GEMS_PREVIEW_RANDOM_HINT"] = "Random -- any of these may fire"
L["GEMS_PREVIEW_STEP_TOOLTIP"] = "Step %d: %s"
L["GEMS_PREVIEW_SPELL_TOOLTIP"] = "Spell: %s"
L["GEMS_PREVIEW_COMPILED"] = "Compiled"
L["GEMS_PREVIEW_COMPILED_TIP"] = "Show the compiled macro per step (what WoW runs)"
L["GEMS_PREVIEW_KP_FIT"] = "%d/%d steps fit Key Press + Key Release"
L["GEMS_PREVIEW_KP_DROPPED"] = "Steps in red had Key Press/Key Release dropped (too long for the 255-char limit)"
L["GEMS_PREVIEW_COPY"] = "Copy"
L["GEMS_PREVIEW_COPY_TIP"] = "Copy the rotation preview to clipboard"
L["GEMS_PREVIEW_COPY_HEADER"] = "Rotation preview"
L["GEMS_PREVIEW_COPY_HINT"] = "Press Ctrl+C to copy."
L["GEMS_PREVIEW_COPY_TITLE"] = "GRIP-EMS: Rotation Preview"

-- UI strings (Phase 3A-2): Editor misc
L["GEMS_UI_ICON_HINT"] = "Click to change icon"
L["GEMS_UI_DUPLICATE_FAILED"] = "Duplicate failed."
L["GEMS_UI_COPY_SUFFIX"] = "_copy"

-- UI strings (Phase 3A-2): Step function labels
L["GEMS_UI_SF_SEQUENTIAL"] = "Sequential"
L["GEMS_UI_SF_RANDOM"] = "Random"
L["GEMS_UI_SF_PRIORITY"] = "Priority"
L["GEMS_UI_SF_REVERSEPRIORITY"] = "Rev. Priority"

-- UI strings (Phase 3B-1): Step editor
L["GEMS_UI_ADD_STEP"] = "+ Add"
L["GEMS_UI_ADD_STEP_DESC"] = "Add a new empty step below the selected one"
L["GEMS_UI_DUP_STEP"] = "Dup"
L["GEMS_UI_DUP_STEP_DESC"] = "Duplicate the selected step"
L["GEMS_UI_MOVE_UP"] = "Up"
L["GEMS_UI_MOVE_UP_DESC"] = "Move the selected step up"
L["GEMS_UI_MOVE_DOWN"] = "Down"
L["GEMS_UI_MOVE_DOWN_DESC"] = "Move the selected step down"
L["GEMS_UI_DEL_STEP"] = "Del"
L["GEMS_UI_DEL_STEP_DESC"] = "Delete the selected step"
L["GEMS_UI_STEP_HEADER"] = "Step %d:"
L["GEMS_UI_SELECT_STEP"] = "Select a step to edit"
L["GEMS_UI_DELETE_STEP_CONFIRM"] = "Delete step %d? This cannot be undone."
L["GEMS_UI_CTX_DUP_STEP"] = "Duplicate Step"
L["GEMS_UI_CTX_MOVE_UP"] = "Move Up"
L["GEMS_UI_CTX_MOVE_DOWN"] = "Move Down"
L["GEMS_UI_CTX_DELETE_STEP"] = "Delete Step"
L["GEMS_UI_CTX_DUP_SELECTED"] = "Duplicate Selected (%d)"
L["GEMS_UI_CTX_DELETE_SELECTED"] = "Delete Selected (%d)"
L["GEMS_UI_STEPS_SELECTED"] = "%d steps selected"
L["GEMS_UI_DELETE_STEPS_CONFIRM"] = "Delete %d steps? This cannot be undone."
L["GEMS_UI_CTX_DISABLE_STEP"] = "Disable Step"
L["GEMS_UI_CTX_ENABLE_STEP"] = "Enable Step"
L["GEMS_UI_STEP_DISABLED_PREFIX"] = "(off) "
L["GEMS_UI_STEP_DISABLE_CONVERTED"] = "This sequence is now an action sequence. Undo to revert."
L["GEMS_UI_DRAG_HANDLE_DESC"] = "Drag to reorder"
L["GEMS_UI_EXPORT_BTN_EDITOR"] = "Export"
L["GEMS_UI_EXPORT_BTN_EDITOR_DESC"] = "Export this sequence as a GRIP-EMS string"
L["GEMS_UI_NAME_TOOLTIP"] = "Sequence Name"
L["GEMS_UI_NAME_EDIT_HINT"] = "Click to rename. Press Enter to confirm, Escape to cancel."
L["GEMS_UI_SAVE_PROMPT"] = "Save changes to '%s'?"
L["GEMS_UI_SAVE"] = "Save"
L["GEMS_UI_SAVE_BTN_DESC"] = "Save changes to this sequence"
L["GEMS_UI_DISCARD"] = "Discard"
L["GEMS_UI_DISCARD_BTN_DESC"] = "Discard changes and go back to the last saved version"
L["GEMS_UI_SAVE_COMBAT"] = "Unavailable during combat"
L["GEMS_UI_ENABLE"] = "Enable"
L["GEMS_UI_DISABLE"] = "Disable"
L["GEMS_UI_ENABLE_BTN_DESC"] = "Re-enable this sequence (turns the button and keybind back on)"
L["GEMS_UI_DISABLE_BTN_DESC"] = "Disable this sequence (removes the button and keybind, keeps the data)"
L["GEMS_UI_DISABLED_BADGE"] = "[Disabled]"

-- Version bar (UX-4)
L["GEMS_VERSION_OF"] = "Version %d of %d"
L["GEMS_VERSION_LABEL"] = "Version %d"
L["GEMS_VERSION_DEFAULT_SUFFIX"] = " (Default)"
L["GEMS_VERSION_DEFAULT_MARKER"] = " (*)"
L["GEMS_VERSION_LIVE_BADGE"] = "Live: V%d"
L["GEMS_VERSION_LIVE_MARKER"] = " (Live)"
L["GEMS_VERSION_PINNED_BADGE"] = "Live: V%d (pinned)"
L["GEMS_VERSION_PIN_ACTION"] = "Make live (pin)"
L["GEMS_VERSION_UNPIN_ACTION"] = "Unpin (use context)"
L["GEMS_VERSION_PIN_COMBAT_NOTE"] = " -- applies after combat"
L["GEMS_VERSION_TOOLTIP_LIVE_HINT"] =
    "This selects which version you edit. The live version your keybind runs is shown by the Live badge and can differ by content type."
L["GEMS_VERSION_TOOLTIP_TITLE"] = "Version"
L["GEMS_VERSION_TOOLTIP_DESC"] = "Select which version to edit"
L["GEMS_VERSION_ADD_TITLE"] = "Add Version"
L["GEMS_VERSION_ADD_DESC"] = "Create a new empty version"
L["GEMS_VERSION_DUP_TITLE"] = "Duplicate Version"
L["GEMS_VERSION_DUP_DESC"] = "Copy current version to a new version"
L["GEMS_VERSION_DEL_TITLE"] = "Delete Version"
L["GEMS_VERSION_DEL_DESC"] = "Remove current version"
L["GEMS_VERSION_DEFAULT_TITLE"] = "Set Default"
L["GEMS_VERSION_DEFAULT_DESC"] = "Mark this version as the default for execution"

-- Phase 3B-2: Keybind tab
L["GEMS_UI_CURRENT_KEYBIND"] = "Current Keybind"
L["GEMS_UI_KEYBIND_DISPLAY_NONE"] = "None"
L["GEMS_UI_SET_KEYBIND"] = "Set Keybind"
L["GEMS_UI_CHANGE_KEYBIND"] = "Change"
L["GEMS_UI_CLEAR_KEYBIND"] = "Clear"
L["GEMS_UI_PRESS_KEY"] = "Press a key..."
L["GEMS_UI_KEYBIND_HINT"] =
    "Keybinds are saved per spec in your GRIP-EMS profile. They do not change your normal WoW keybinds."
L["GEMS_UI_CAPTURE_COMBAT"] = "Cannot capture keybinds during combat."
L["GEMS_UI_SPEC_KEYBINDS"] = "Keybinds by Spec"
L["GEMS_UI_CURRENT_SPEC"] = "(current)"
L["GEMS_UI_LOADOUT_COMING_SOON"] = "Per-talent-loadout keybinds: coming soon"
L["GEMS_UI_CAPTURE_ESC_HINT"] = "(Press ESC to cancel)"
L["GEMS_UI_KEYBIND_CONFLICT"] = "%s was bound to '%s'. Now bound to this sequence."
L["GEMS_UI_KEYBIND_CP_CONFLICT"] =
    "%s is bound to '%s' in ConsolePort. EMS will override that binding while sequences are active."
L["GEMS_KEYBIND_MOUSE_NEEDS_MODIFIER"] = "Mouse1 and Mouse2 require a modifier (Alt, Ctrl, or Shift) to bind."
L["GEMS_UI_GAMEPAD_HINT"] = "Controller detected -- you can bind gamepad buttons."
L["GEMS_UI_SIMPLIFIED_LOCKED_HINT"] =
    "Simplified Mode is on. Click Unlock editor to edit this sequence, or turn Simplified Mode off in Settings."

-- Phase 3B-2: Macros tab
L["GEMS_UI_TAB_MACROS"] = "Macros"
L["GEMS_UI_MACRO_STUB_SECTION"] = "Macro Stub"
L["GEMS_UI_STUB_INFO"] = "%s (slot %d)"
L["GEMS_UI_STUB_NONE"] = "No macro stub"
L["GEMS_UI_SLOTS_USED"] = "%d of %d per-character macro slots used"
L["GEMS_UI_REFRESH_STUBS"] = "Refresh"
L["GEMS_UI_REFRESH_STUBS_DESC"] = "Re-scan for existing GRIP-EMS macro stubs"
L["GEMS_UI_CLEAN_ORPHANS"] = "Clean Orphans"
L["GEMS_UI_CLEAN_ORPHANS_DESC"] = "Delete macro stubs for sequences that no longer exist"
L["GEMS_UI_CLEAN_CONFIRM"] = "Delete %d orphan macro stub(s)? This cannot be undone."
L["GEMS_UI_ORPHANS_CLEANED"] = "Cleaned %d orphan macro stub(s)."
L["GEMS_UI_NO_ORPHANS"] = "No orphan stubs found."
L["GEMS_UI_STUB_LIST_HEADER"] = "All Stubs (%d)"
L["GEMS_UI_NO_STUBS"] = "No macro stubs found."
L["GEMS_UI_STUBS_MORE"] = "%d more stub(s) not shown"

-- Phase 3B-2: Priority preview

-- Phase 3C-1: Spell autocomplete

-- Phase 3C-2: Icon picker
L["GEMS_UI_ICON_PICKER_TITLE"] = "Choose Icon"
L["GEMS_UI_AUTO_DETECT"] = "Auto-Detect"
L["GEMS_UI_AUTO_DETECT_DESC"] = "Automatically detect icon from the first /cast spell"

-- Context version selection (T2-1)
L["GEMS_CONTEXT_CHANGED"] = "Context changed: %s"
L["GEMS_CONTEXT_NONE_LABEL"] = "None"
L["GEMS_CONTEXT_RELOAD"] = "Switched context: reloaded %d sequence(s)"

-- Context tab (T2-1b)
L["GEMS_UI_TAB_CONTEXT"] = "Conditions"
L["GEMS_CONTEXT_DEFAULT_LABEL"] = "Default Version: %d"
L["GEMS_CONTEXT_CURRENT_INFO"] = "Current Context: %s"
L["GEMS_CONTEXT_VIEWING"] = "Assignments for Version %d"
L["GEMS_CONTEXT_NO_VERSIONS"] = "Add a second version to set up context overrides."
L["GEMS_CONTEXT_HINT"] =
    "Check the content types where this version should be active. Unchecked contexts fall back to broader categories (e.g. Mythic+ falls back to Dungeon, then Default)."
L["GEMS_CONTEXT_CONFLICT_MSG"] = "%s is assigned to Version %d.\nReassign to Version %d?"
L["GEMS_CONTEXT_CONFLICT_MULTI_MSG"] =
    "%d contexts in this group are assigned to other versions.\nReassign them all to Version %d?"
L["GEMS_CONTEXT_SELECT_ALL_TIP"] =
    "Assign every context in this group to the version you are viewing. Contexts already assigned to another version ask for one confirmation."
L["GEMS_CONTEXT_CLEAR_ALL_TIP"] =
    "Clear this group's assignments for the version you are viewing. Assignments belonging to other versions are left alone."
L["GEMS_CONTEXT_DEFAULT_TIP_TITLE"] = "Default Version"
L["GEMS_CONTEXT_DEFAULT_TIP_TEXT"] = "The version used when no context override matches."
L["GEMS_CONTEXT_ASSIGNED_OTHER"] = "(Version %d)"
L["GEMS_CONTEXT_GROUP_RAIDS"] = "Raids"
L["GEMS_CONTEXT_GROUP_DUNGEONS"] = "Dungeons"
L["GEMS_CONTEXT_GROUP_PVP"] = "PvP"
L["GEMS_CONTEXT_GROUP_ARENA_MAPS"] = "Arena Maps"
L["GEMS_CONTEXT_GROUP_BG_MAPS"] = "Battleground Maps"
L["GEMS_CONTEXT_GROUP_OTHER"] = "Other"
L["GEMS_CONTEXT_WRONG_VERSION"] = "%s is assigned to Version %d. Switch to that version to modify it."

-- Context group buttons and fallback chain (v1.2.0 S19)
L["GEMS_CONTEXT_SELECT_ALL"] = "All"
L["GEMS_CONTEXT_CLEAR_ALL"] = "None"
L["GEMS_CONTEXT_FALLBACK_NONE"] = "No active context -- Default Version %d"
L["GEMS_CONTEXT_FALLBACK_MATCH"] = " (v%d)"
L["GEMS_CONTEXT_FALLBACK_DEFAULT"] = "Default"
L["GEMS_CONTEXT_FALLBACK_SEP"] = " > "
L["GEMS_SETTINGS_CONTEXT_HEADER"] = "Context Detection"
L["GEMS_SETTINGS_CONTEXT_DESC"] =
    "Choose how the addon picks the right version automatically based on what content you are doing."
L["GEMS_SETTINGS_MPLUS_MID"] = "Mythic+ Mid Tier"
L["GEMS_SETTINGS_MPLUS_MID_DESC"] = "The key level where Mythic+ content type changes from Low to Mid."
L["GEMS_SETTINGS_MPLUS_HIGH"] = "Mythic+ High Tier"
L["GEMS_SETTINGS_MPLUS_HIGH_DESC"] = "The key level where Mythic+ content type changes from Mid to High."
L["GEMS_SETTINGS_DELVES_HIGH"] = "Delves High Tier"
L["GEMS_SETTINGS_DELVES_HIGH_DESC"] = "The Delve tier where the content type changes from Low to High."

-- Context migration (T2-3)

-- Phase 2B: Migration
L["GEMS_HELP_MIGRATE"] = "  /gems migrate - Migrate sequences from another sequencer"
L["GEMS_UI_MIGRATE_BTN"] = "Migrate"
L["GEMS_UI_MIGRATE_BTN_DESC"] = "Import all sequences from another sequencer"
L["GEMS_MIGRATE_NO_SOURCE"] = "No compatible sequencer found."
L["GEMS_MIGRATE_SOURCE_DISABLED"] =
    "A compatible sequencer is installed but disabled. Enable it in the AddOns list, then /reload to migrate."
L["GEMS_MIGRATE_FAILED"] = "Migration failed: %s"
L["GEMS_MIGRATE_ALL_CLASSES"] = "All Classes"
L["GEMS_MIGRATE_CURRENT_CLASS"] = "Current Class Only"
L["GEMS_MIGRATE_CONFIRM"] =
    "Migrate all sequences from your previous sequencer?\n\nFound %d sequences. Existing sequences with the same name will be skipped."
L["GEMS_DELETE_COMBAT"] = "Cannot delete sequences during combat."
L["GEMS_MIGRATE_COMBAT"] = "Cannot migrate during combat. Try again after combat."
L["GEMS_MIGRATE_EMPTY"] = "No sequences found in source library."
L["GEMS_MIGRATE_SKIPPED"] = "%s (already exists, skipped)"
L["GEMS_MIGRATE_KEYBINDS"] = "Keybinds: %d migrated, %d skipped, %d conflicts"
L["GEMS_MIGRATE_AO_WARNING"] =
    "%d action bar binds did not migrate. EMS binds keys, not action bar slots. Use /gems bind to set them up."

-- Phase 2C: Export frame
L["GEMS_EXPORT_FRAME_LABEL"] = "Exported: %s"
L["GEMS_EXPORT_FRAME_HINT"] = "Press Ctrl+C to copy, then paste into another player's import window."

-- Phase 3C-3: Variable system
L["GEMS_VAR_EVAL_ERROR"] = "Variable '%s' evaluation failed: %s"
L["GEMS_VAR_SANDBOX_BLOCKED"] = "Variable '%s': global '%s' is not on the sandbox whitelist; resolved to nil."
L["GEMS_VAR_INVALID_NAME"] = "Variable name must use only letters, numbers, or underscore (a-z, 0-9, _)."
L["GEMS_VAR_NAME_TOO_LONG"] = "Variable name exceeds %d characters"
L["GEMS_VAR_FUNC_TOO_LONG"] = "Variable function exceeds %d characters"
L["GEMS_VAR_NAME_EMPTY"] = "Variable name cannot be empty"
L["GEMS_VAR_NAME_EXISTS"] = "Variable '%s' already exists"
L["GEMS_VAR_DELETED"] = "Variable '%s' deleted"
L["GEMS_VAR_SAVED"] = "Variable '%s' saved"
L["GEMS_VAR_IMPORT_PAUSE"] = "Pause with variable converted to comment"
L["GEMS_VAR_IMPORT_SKIPPED"] = "Skipped %d variable(s) (already exist)."
L["GEMS_VAR_RECOMPILE"] = "Recompiling '%s' (variable changed)"

-- Phase 3C-3b: Variables Tab UI
L["GEMS_VAR_TAB_EMPTY"] = "No variables defined. Click New to create one."
L["GEMS_VAR_NEW"] = "New Variable"
L["GEMS_VAR_NAME_LABEL"] = "Name"
L["GEMS_VAR_FUNC_LABEL"] = "Function Body"
L["GEMS_VAR_FUNC_PLACEHOLDER"] = "return GetHaste() > 20"
L["GEMS_VAR_EVENTS_LABEL"] = "Events (comma-separated)"
L["GEMS_VAR_EVENTS_PLACEHOLDER"] = "SPELL_CAST_SUCCESS, UNIT_AURA"
L["GEMS_VAR_COMMENTS_LABEL"] = "Comments"
L["GEMS_VAR_DISABLED_LABEL"] = "Disabled"
L["GEMS_VAR_SAVE"] = "Save"
L["GEMS_VAR_TEST"] = "Test"
L["GEMS_VAR_TEST_RESULT"] = "Variable '%s' = %s"
L["GEMS_VAR_TEST_ERROR"] = "Variable '%s' error: %s"
L["GEMS_VAR_VALID"] = "Valid"
L["GEMS_VAR_INVALID"] = "Error: %s"
L["GEMS_VAR_USED_BY"] = "Used by: %s"
L["GEMS_VAR_NOT_USED"] = "Not used by any sequence"
L["GEMS_VAR_DELETE_CONFIRM"] = "Delete variable '%s'?"
L["GEMS_VAR_DELETE_REFS_WARN"] = "This variable is used by %d sequence(s). Delete it anyway?"
L["GEMS_VAR_RENAME"] = "Rename Variable"
L["GEMS_VAR_EVENTS_BROWSE"] = "Browse Events"
L["GEMS_VAR_NEW_DESC"] = "Create a new variable"
L["GEMS_VAR_SAVE_DESC"] = "Save changes to this variable"
L["GEMS_VAR_TEST_DESC"] = "Run the function and show the result"
L["GEMS_VAR_DELETE_DESC"] = "Delete this variable permanently"
L["GEMS_VAR_EVENTS_BROWSE_TIP"] = "Click to browse available events"
L["GEMS_VAR_EVENTS_ENABLED_DESC"] =
    "When unchecked, this variable stops listening to events. The event list is kept for when you turn it back on."
L["GEMS_VAR_LOCALE_WARN"] = "Variable returns the spell name '%s'. For locale safety, use: %s"
L["GEMS_VAR_PRIVATE_AURA_WARN"] =
    "Variable returns spell '%s' (ID %d) whose aura is marked private; addon detection (UnitAura) will return nil."
L["GEMS_VAR_FUNC_HELP"] =
    "Available helpers (12.0+ safe in combat):\n  GRIPEMS.HasBuff(spellID, unit) - true if unit has the buff\n  GRIPEMS.HasDebuff(spellID, unit) - true if unit has the debuff\n  GRIPEMS.SpellReady(spellID) - true if the spell is currently usable\n  GRIPEMS.SpellOnCooldown(spellID) - true if the spell is on cooldown\n  GRIPEMS.SpellEnabled(spellID) - true if the spell is enabled\n  GRIPEMS.IsRestricted() - true if any addon-action restriction is active\nunit defaults to 'player'. All helpers return false on missing spells.\n\nPrivate aura note: Some 12.0+ auras are flagged Private and hidden from addon iteration. HasBuff and HasDebuff cannot detect these. If you see a buff in-game but the helper returns false, it may be a Private aura.\n\nFor locale-safe spell names, use C_Spell.GetSpellName(spellID). Example: C_Spell.GetSpellName(133) instead of 'Fireball'."
L["GEMS_VAR_INSERT_HELPER"] = "Insert Helper"
L["GEMS_VAR_INSERT_HELPER_TIP"] = "Insert a condition helper at the cursor position"
L["GEMS_VAR_INSERT_HASBUFF_PLAYER_DESC"] = "True if the player has the buff"
L["GEMS_VAR_INSERT_HASBUFF_TARGET_DESC"] = "True if the target has the buff"
L["GEMS_VAR_INSERT_HASDEBUFF_PLAYER_DESC"] = "True if the player has the debuff"
L["GEMS_VAR_INSERT_HASDEBUFF_TARGET_DESC"] = "True if the target has the debuff"
L["GEMS_VAR_INSERT_SPELLREADY_DESC"] = "True if the spell is currently usable"
L["GEMS_VAR_INSERT_SPELLONCD_DESC"] = "True if the spell is on cooldown"
L["GEMS_VAR_INSERT_SPELLENABLED_DESC"] = "True if the spell is enabled"
L["GEMS_VAR_INSERT_ISRESTRICTED_DESC"] = "True if any addon-action restriction is active"

-- Smart Keybind Group variants (IC-VAR-02 Phase 1)
L["GEMS_VARIANT_ADDED"] = "Added variant '%s' to %s (modifier: %s)."
L["GEMS_VARIANT_BAD_MODIFIER"] = "Invalid modifier '%s'. Must be one of: shift, ctrl, alt."
L["GEMS_VARIANT_DUP_MODIFIER"] = "Cannot add variant: modifier '%s' already exists on %s."
L["GEMS_VARIANT_LIST_HEADER"] = "Variants for %s:"
L["GEMS_VARIANT_LIST_NONE"] = "%s has no variant overrides (single variant only)."
L["GEMS_VARIANT_LIST_ROW"] = "  v%d %s (modifier: %s, %d steps)"
L["GEMS_VARIANT_MAX_REACHED"] = "Cannot add variant: %s already has the maximum of %d overrides."
L["GEMS_VARIANT_NOT_FOUND"] = "Sequence %s has no variant with modifier '%s'."
L["GEMS_VARIANT_REMOVED"] = "Removed variant on %s (modifier: %s)."

-- Variant indicator strip (IC-VAR-08 Phase 3)
L["GEMS_VARIANT_INDICATOR_LABEL_PLAIN"] = "1"
L["GEMS_VARIANT_INDICATOR_LABEL_SHIFT"] = "S"
L["GEMS_VARIANT_INDICATOR_LABEL_CTRL"] = "C"
L["GEMS_VARIANT_INDICATOR_LABEL_ALT"] = "A"
L["GEMS_VARIANT_INDICATOR_TOOLTIP"] = "Variant: %s  Modifier: %s  Bind: %s"
L["GEMS_SETTINGS_VARIANT_INDICATORS_TRACKER"] = "TrackerHUD variant indicators"
L["GEMS_SETTINGS_VARIANT_INDICATORS_TRACKER_DESC"] =
    "Show coloured status icons, cooldown rings, and a pulsing border for each variant of a Smart Keybind Group sequence inside the Tracker HUD."
L["GEMS_SETTINGS_VARIANT_INDICATORS_BAR"] = "Action bar variant indicators"
L["GEMS_SETTINGS_VARIANT_INDICATORS_BAR_DESC"] =
    "Overlay the same variant indicators on action bar buttons that run /click GRIPEMS_<seq>_v<N>."

-- Variants subtab UI (IC-VAR-02 Phase 2)
L["GEMS_VARIANTS_SEQ_RECOMMEND"] = "Sequence-level recommend function"
L["GEMS_VARIANTS_SEQ_RECOMMEND_TT"] =
    "Lua function returning one of: plain, shift, ctrl, alt. Falls back per-version if version-level is set."
L["GEMS_VARIANTS_VER_RECOMMEND"] = "Per-version recommend function"
L["GEMS_VARIANTS_VER_RECOMMEND_EMPTY"] = "Using sequence default"
L["GEMS_VARIANTS_VER_TARGET_LIVE"] = "Rows edit version %d (live)"
L["GEMS_VARIANTS_VER_TARGET_NOT_LIVE"] = "Rows edit version %d (NOT live)"
L["GEMS_VARIANTS_MOD_PLAIN_ROW"] = "Plain (base)"
L["GEMS_VARIANTS_MOD_SHIFT_ROW"] = "Shift"
L["GEMS_VARIANTS_MOD_CTRL_ROW"] = "Ctrl"
L["GEMS_VARIANTS_MOD_ALT_ROW"] = "Alt"
L["GEMS_VARIANTS_ADD"] = "Add"
L["GEMS_VARIANTS_REMOVE"] = "Remove"
L["GEMS_VARIANTS_UNSAFE_API_WARN"] = "Recommend function references restricted API. Run OOC only."
L["GEMS_VARIANTS_COMPILE_ERROR"] = "Recommend function did not compile: %s"

-- Raw tab
L["GEMS_RAW_TITLE"] = "Raw Data"
L["GEMS_RAW_EDIT"] = "Edit"
L["GEMS_RAW_APPLY"] = "Apply"
L["GEMS_RAW_CANCEL"] = "Cancel"
L["GEMS_RAW_INVALID"] = "Invalid: %s"
L["GEMS_RAW_MISSING_FIELD"] = "Missing required field: %s"
L["GEMS_RAW_APPLIED"] = "Changes applied"
L["GEMS_RAW_NAME_IGNORED"] = "Name change ignored. Use Rename from context menu."
L["GEMS_RAW_NO_SEQUENCE"] = "No sequence selected"
L["GEMS_RAW_READONLY_HINT"] = "Click Edit to modify. Changes are checked before applying."
L["GEMS_RAW_CANCEL_DESC"] = "Close without applying changes"
L["GEMS_RAW_EDIT_DESC"] = "Parse and apply the Lua table as sequence data"

-- Step action bar (Save + hint)
L["GEMS_STEP_SAVE"] = "Save"
L["GEMS_STEP_SAVE_DESC"] = "Save all step changes to the sequence"
L["GEMS_STEP_UNSAVED_HINT"] = "Unsaved changes"

-- Engine debug
L["GEMS_SEQ_ACTIVATED"] = "Sequence '%s' activated (%d steps)."
L["GEMS_SEQ_DEACTIVATED"] = "Sequence '%s' deactivated."
L["GEMS_SEQUENCE_REFRESH_FAILED"] = "GRIP-EMS: Sequence '%s' edit did not apply. Run /reload to retry."
L["GEMS_STEP_RESET"] = "Sequence '%s' step reset to 1."
L["GEMS_STEP_ADVANCED"] = "Sequence '%s' step advanced to %d/%d."
L["GEMS_COMBAT_RESET"] = "Sequence '%s' reset (combat drop)."
L["GEMS_TARGET_RESET"] = "Sequence '%s' reset (target change)."
L["GEMS_GEAR_RESET"] = "%s: reset on gear change (was step %d, slot %d)."
L["GEMS_SPEC_RESET"] = "%s: reset on spec change (was step %d)."
L["GEMS_RESTORED"] = "Restored %d saved sequence(s)."
L["GEMS_RESTRICTED_PAUSED"] =
    "%d sequence(s) paused while protected actions are restricted (combat, arena, Mythic+, or raid encounter). They re-arm automatically when the restriction lifts."

-- Compiler messages
L["GEMS_COMPILE_DEPTH_EXCEEDED"] =
    "Max sequence nesting depth (%d) exceeded -- a Loop or other nested node was dropped from the compiled steps. Reduce nesting in the Steps tab."
L["GEMS_ADD_MENU_DEPTH_CAP_HINT"] =
    "Max nesting depth (%d) reached -- add disabled here. Reduce nesting in a parent container to enable additions."
L["GEMS_REPARENT_DEPTH_REJECT"] =
    "Cannot drop here -- that would exceed the max nesting depth (%d). Move it into a shallower loop."

-- Settings panel (T1-1 + T1-7)
L["GEMS_HELP_SETTINGS"] = "  /gems settings|config|options - Open settings panel"
L["GEMS_SETTINGS_HEADER_DESC"] = "Settings for how GRIP - Enhanced Macro Sequencer behaves and looks."
L["GEMS_OVERVIEW_NAME"] = "Overview"
L["GEMS_OVERVIEW_VERSION_LABEL"] = "Version: %s"
L["GEMS_OVERVIEW_NAVIGATE_HINT"] = "Use the tree on the left to navigate to a settings category."
L["GEMS_OVERVIEW_DISCORD_BUTTON"] = "Join Discord"
L["GEMS_OVERVIEW_AUTHOR_LINE"] = "Created by Sataana"
L["GEMS_SETTINGS_GENERAL"] = "General"
L["GEMS_SETTINGS_PLUGINS"] = "Plugins"
L["GEMS_SETTINGS_OOC_DELAY"] = "OOC Queue Delay (sec)"
L["GEMS_SETTINGS_OOC_DELAY_DESC"] =
    "How long to wait after combat ends before running queued tasks. Lower numbers run them faster. Default is 7 seconds. Reload UI to apply a new value."
L["GEMS_SETTINGS_RESET_OOC"] = "Reset on Combat End (default)"
L["GEMS_SETTINGS_RESET_OOC_DESC"] =
    "Sets the starting value of 'Reset on Combat End' for any new sequence you make. Sequences you already made stay the way they are."
L["GEMS_SETTINGS_AUTO_RELOAD"] = "Auto-reload sequences at combat end"
L["GEMS_SETTINGS_AUTO_RELOAD_DESC"] =
    "When ON, EMS auto-applies queued sequence operations (recompile, activate, deactivate, imports) when combat ends. When OFF, queued operations wait until you run /gems apply. Default is ON."
L["GEMS_SETTINGS_SHOW_VARIANTS_TAB"] = "Show Variants tab in Sequence Editor"
L["GEMS_SETTINGS_SHOW_VARIANTS_TAB_DESC"] =
    "Adds a Variants subtab to the Sequence Editor for managing per-modifier variant overrides and the recommend function."
L["GEMS_APPLY_DRAINED"] = "Applied %d queued operation(s)."
L["GEMS_APPLY_NOTHING_QUEUED"] = "Nothing queued."
L["GEMS_APPLY_IN_COMBAT"] =
    "Cannot apply queued operations during combat. Wait for combat to end or run /gems apply afterwards."
L["GEMS_HELP_APPLY"] = "  /gems apply - Apply queued sequence operations (when Auto-reload is OFF)"
L["GEMS_HELP_VARIANTS"] = "  /gems variants - List and manage Smart Keybind Group variants"
L["GEMS_SETTINGS_UI"] = "Display"
L["GEMS_SETTINGS_HIDE_LOGIN"] = "Hide Login Message"
L["GEMS_SETTINGS_HIDE_LOGIN_DESC"] = "Hide the 'GRIP-EMS vX.X' line that prints in chat at login."
L["GEMS_SETTINGS_DEBUG"] = "Debug Mode"
L["GEMS_SETTINGS_DEBUG_DESC"] =
    "Print extra technical messages in chat. You can also turn this on or off with /gems debug."
L["GEMS_SETTINGS_INFO"] = "Info"
L["GEMS_SETTINGS_VERSION_INFO"] = "GRIP-EMS v%s | %d active sequence(s)"

-- Accessibility panel (v2.0.0 Phase 1A)
L["ACCESS_PANEL_NAME"] = "Accessibility"
L["ACCESS_GENERAL_TAB"] = "General"
L["ACCESS_THEMING_OVERVIEW_TAB"] = "Overview"
L["ACCESS_THEMING_CUSTOMIZE_TAB"] = "Customise"
L["ACCESS_SECTION_DISPLAY"] = "Display"
L["ACCESS_SECTION_DISPLAY_DESC"] = "Size and layout options"
L["ACCESS_SECTION_MOTION"] = "Motion"
L["ACCESS_SECTION_MOTION_DESC"] = "Animation options"
L["ACCESS_SECTION_AUDIO"] = "Audio"
L["ACCESS_SECTION_AUDIO_DESC"] = "Speech and sound options"
L["ACCESS_REDUCE_MOTION_LABEL"] = "Reduce motion"
L["ACCESS_REDUCE_MOTION_DESC"] = "Turn off pulse, fade, and flash animations. Final colours and icons still show."
L["ACCESS_FLICKER_SAFE_LABEL"] = "Flicker-safe mode"
L["ACCESS_FLICKER_SAFE_DESC"] =
    "Mute alpha pulses on tempo and tracker animations for photosensitive users. Auto-detected from your Blizzard accessibility settings on first run."
L["ACCESS_SPEECH_ENABLED_LABEL"] = "Speak step changes"
L["ACCESS_SPEECH_ENABLED_DESC"] =
    "Use Blizzard text-to-speech to announce step advances and warnings. Requires voice chat enabled in Blizzard settings."
L["ACCESS_SPEECH_RATE_LABEL"] = "Speech rate"
L["ACCESS_SPEECH_RATE_DESC"] = "Faster or slower speech. 0 is Blizzard default."
L["ACCESS_SPEECH_VOLUME_LABEL"] = "Speech volume"
L["ACCESS_SPEECH_VOLUME_DESC"] = "How loud the speech plays."
L["ACCESS_SPEECH_NO_VOICE_TOAST"] = "Enable Blizzard voice chat in the Social menu to hear step announcements."
L["ACCESS_SPEECH_STEP_FORMAT"] = "Step %d of %d"
L["ACCESS_CHAT_EMITTER_ENABLED_LABEL"] = "Emit state to chat window"
L["ACCESS_CHAT_EMITTER_ENABLED_DESC"] =
    "Send every sequence state change to a chat window. Local-only -- never sent over the network. Screen-reader bridges (BlindSlash, NVDA) can dock the chosen window and read the messages aloud. Pairs with the speech setting above."
L["ACCESS_CHAT_EMITTER_FRAME_LABEL"] = "Chat window slot"
L["ACCESS_CHAT_EMITTER_FRAME_DESC"] =
    "Which of the 10 chat windows receives state messages. Default is window 9, which is typically hidden -- ideal for a screen-reader bridge. Avoid window 2 (Combat Log)."
L["ACCESS_CHAT_EMITTER_PREFIX"] = "[EMS] "
L["ACCESS_CHAT_EMITTER_INVALID_TOAST"] = "Chat window %d is not available. Using the default chat window instead."
L["ACCESS_STEP_LABEL_LABEL"] = "Step label"
L["ACCESS_STEP_LABEL_DESC"] = "Optional short name read aloud when speech is enabled and shown next to the step number."
L["ACCESS_STEP_LABEL_PLACEHOLDER"] = "Label (optional)"
L["ACCESS_MODE_SECTION_NAME"] = "Accessibility Mode"
L["ACCESS_MODE_SECTION_DESC"] =
    "One-click preset that turns on speech, high contrast, reduced motion, and a larger editor. You can fine-tune any of these settings afterward."
L["ACCESS_MODE_TOGGLE_LABEL"] = "Turn on Accessibility Mode"
L["ACCESS_MODE_TOGGLE_DESC"] =
    "Enables speech, high-contrast colours, reduced motion, and 1.25x editor scale in one step. Turn off to restore stock defaults."
L["ACCESS_MODE_TOAST_APPLIED"] = "Accessibility Mode on. Reload UI for full effect."
L["ACCESS_MODE_TOAST_REVERTED"] = "Accessibility Mode off. Stock defaults restored. Reload UI for full effect."
L["ACCESS_MODE_SMALL_DISPLAY_WARNING"] =
    "EMS: Accessibility Mode is on but your display is small at this UI scale. MainFrame may not fully fit. Consider disabling Accessibility Mode or moving to a larger display."
L["ACCESS_CVAR_MIRROR_SECTION_NAME"] = "CVar auto-mirror"
L["ACCESS_CVAR_MIRROR_SECTION_DESC"] =
    "On first login, copies your Blizzard accessibility settings into EMS. Settings you have already changed in EMS are kept."
L["ACCESS_CVAR_MIRROR_REDETECT_LABEL"] = "Re-detect accessibility settings"
L["ACCESS_CVAR_MIRROR_REDETECT_DESC"] =
    "Re-check your Blizzard colourblind, camera motion, and gamepad settings and re-apply the matching EMS defaults. Settings you have already changed in EMS are kept."
L["ACCESS_CVAR_MIRROR_TOAST_APPLIED"] = "GRIP-EMS: copied %d Blizzard accessibility setting(s) into EMS."
L["ACCESS_CVAR_MIRROR_TOAST_NOOP"] = "GRIP-EMS: no accessibility settings needed to be copied."
L["ACCESS_FONT_LABEL"] = "UI font"
L["ACCESS_FONT_DESC"] =
    "Choose the font used for EMS panels and editors. Atkinson Hyperlegible is bundled for dyslexia-friendly readability (Latin scripts only; other scripts fall back to the default game font)."
L["ACCESS_FONT_RELOAD_NOTICE"] = "Reload UI for the new font to apply everywhere."
L["ACCESS_THEME_SECTION_NAME"] = "Theming"
L["ACCESS_THEME_SECTION_DESC"] =
    "Fine-tune background and border opacity, per-panel alpha, and a global UI scale that affects every EMS panel. Tempo and Tracker overlays use fixed brand colours -- the opacity sliders do not change those colours, but the overlay alpha slider still fades them."
L["ACCESS_THEME_UI_SCALE_LABEL"] = "UI scale (all EMS panels)"
L["ACCESS_THEME_UI_SCALE_DESC"] = "Scales every EMS panel and overlay. 1.0 is native size."
L["ACCESS_THEME_BG_OPACITY_LABEL"] = "Background opacity"
L["ACCESS_THEME_BG_OPACITY_DESC"] = "Multiplier on panel background transparency. 1.0 keeps the theme default."
L["ACCESS_THEME_BORDER_OPACITY_LABEL"] = "Border opacity"
L["ACCESS_THEME_BORDER_OPACITY_DESC"] = "Multiplier on panel border transparency. 1.0 keeps the theme default."
L["ACCESS_THEME_PANEL_ALPHA_LABEL"] = "Panel alpha"
L["ACCESS_THEME_PANEL_ALPHA_DESC"] =
    "Overall transparency of main EMS panels -- the main window, editors, and dialogue boxes."
L["ACCESS_THEME_OVERLAY_ALPHA_LABEL"] = "Overlay alpha"
L["ACCESS_THEME_OVERLAY_ALPHA_DESC"] =
    "Overall transparency of overlays (Tempo, Tracker HUD, Floating menu, What's New)."
L["ACCESS_THEME_RESET_LABEL"] = "Reset Theming to defaults"
L["ACCESS_THEME_RESET_DESC"] = "Return all Theming sliders to 1.0."
L["ACCESS_COLORBLIND_SECTION_NAME"] = "Colour vision"
L["ACCESS_COLORBLIND_SECTION_DESC"] =
    "If you have a colour vision deficiency, pick the closest match below and tune the correction strength. EMS will shift its own colours so errors, warnings, and highlights stay distinguishable."
L["ACCESS_COLORBLIND_TYPE_LABEL"] = "Colour vision deficiency"
L["ACCESS_COLORBLIND_TYPE_DESC"] = "Applies on top of the contrast preset. Picking None disables the correction."
L["ACCESS_COLORBLIND_TYPE_NONE"] = "None"
L["ACCESS_COLORBLIND_TYPE_PROTANOMALY"] = "Protanomaly (reduced red response)"
L["ACCESS_COLORBLIND_TYPE_PROTANOPIA"] = "Protanopia (no red response)"
L["ACCESS_COLORBLIND_TYPE_DEUTERANOMALY"] = "Deuteranomaly (reduced green response)"
L["ACCESS_COLORBLIND_TYPE_DEUTERANOPIA"] = "Deuteranopia (no green response)"
L["ACCESS_COLORBLIND_TYPE_TRITANOMALY"] = "Tritanomaly (reduced blue response)"
L["ACCESS_COLORBLIND_TYPE_TRITANOPIA"] = "Tritanopia (no blue response)"
L["ACCESS_COLORBLIND_TYPE_ACHROMATOMALY"] = "Achromatomaly (partial colour loss)"
L["ACCESS_COLORBLIND_TYPE_ACHROMATOPSIA"] = "Achromatopsia (full colour loss)"
L["ACCESS_COLORBLIND_STRENGTH_LABEL"] = "Correction strength"
L["ACCESS_COLORBLIND_STRENGTH_DESC"] =
    "Zero leaves EMS colours untouched. One hundred applies the full correction for the selected deficiency."
L["ACCESS_COLORBLIND_ACHROMAT_HINT"] =
    "At full strength, Achromatopsia collapses EMS colours to greyscale. If you prefer label-based cues over colour, pair the High Contrast preset with None here."
L["ACCESS_COLORBLIND_PREVIEW_LABEL"] = "Preview:"
L["ACCESS_COLORBLIND_STACK_WARN"] =
    "The selected preset is already tuned for this deficiency. Stacking may over-correct -- try the Default preset or lower the strength."

-- Accessibility Tour (v2.0.0 Phase 3 item 10)
L["ACCESS_TOUR_WELCOME_TITLE"] = "Welcome to GRIP-EMS"
L["ACCESS_TOUR_WELCOME_BODY"] = "This short tour shows you around the sequence editor. You can skip it any time."
L["ACCESS_TOUR_LIST_TITLE"] = "Your sequences"
L["ACCESS_TOUR_LIST_BODY"] = "This panel lists every sequence you have. Click one to edit it."
L["ACCESS_TOUR_STEPS_TITLE"] = "Steps tab"
L["ACCESS_TOUR_STEPS_BODY"] = "Write the macro steps for your sequence here. One step per macro line."
L["ACCESS_TOUR_MACROS_TITLE"] = "Macros tab"
L["ACCESS_TOUR_MACROS_BODY"] = "This tab shows the generated macro slots. You can pin them to your action bars."
L["ACCESS_TOUR_KEYBIND_TITLE"] = "Keybind tab"
L["ACCESS_TOUR_KEYBIND_BODY"] = "Bind a key to the sequence here. Capture new binds or pick from the list."
L["ACCESS_TOUR_TEST_TITLE"] = "Test and disable"
L["ACCESS_TOUR_TEST_BODY"] = "Use this button to disable the sequence without deleting it. Safe during combat."
L["ACCESS_TOUR_IMPORT_TITLE"] = "Import and export"
L["ACCESS_TOUR_IMPORT_BODY"] = "Paste a sequence string here to import. Export yours to share with other players."
L["ACCESS_TOUR_DONE_TITLE"] = "You are ready"
L["ACCESS_TOUR_DONE_BODY"] =
    "Open the Accessibility settings for scale, contrast, and speech options. Run the tour again any time with /gems tour."
L["ACCESS_TOUR_BACK"] = "Back"
L["ACCESS_TOUR_SKIP"] = "Skip"
L["ACCESS_TOUR_NEXT"] = "Next"
L["ACCESS_TOUR_DONE"] = "Done"
L["ACCESS_TOUR_RESET_TOAST"] = "Tutorial reset. It will show on your next login."

-- Accessibility: Help popovers (Phase 3 #11)
L["ACCESS_HELP_BUTTON_LABEL"] = "?"
L["ACCESS_HELP_BUTTON_TOOLTIP"] = "Help"
L["ACCESS_HELP_CLOSE"] = "Close"
L["ACCESS_HELP_TITLE_STEPS"] = "Steps tab"
L["ACCESS_HELP_BODY_STEPS"] =
    "Each row is one step in the sequence. The Add buttons let you insert a spell, item, macro, or nested action. Drag rows to reorder. When the list has keyboard focus, use the arrow keys to move between rows."
L["ACCESS_HELP_TITLE_KEYBIND"] = "Keybind tab"
L["ACCESS_HELP_BODY_KEYBIND"] =
    "Set the key that triggers this sequence. Modifier keys (Shift, Ctrl, Alt) and mouse buttons are supported. Only one keybind per sequence. Conflicts with existing bindings are flagged inline."
L["ACCESS_HELP_TITLE_MACROS"] = "Macros tab"
L["ACCESS_HELP_BODY_MACROS"] =
    "Write helper macro lines that run alongside the sequence. Use them for targeting, stop-cast, or anything that does not need its own step. They run with every step the sequence fires."
L["ACCESS_HELP_TITLE_CONTEXT"] = "Context tab"
L["ACCESS_HELP_BODY_CONTEXT"] =
    "Not yet available. This tab will let you gate a sequence by zone, difficulty, spec, or other in-game context."
L["ACCESS_HELP_TITLE_VARIABLES"] = "Variables tab"
L["ACCESS_HELP_BODY_VARIABLES"] =
    "Not yet available. This tab will let you define reusable values that steps can reference by name."
L["ACCESS_HELP_TITLE_RAW"] = "Raw tab"
L["ACCESS_HELP_BODY_RAW"] =
    "Not yet available. This tab will show the fully generated macro text for the sequence, useful for debugging."
L["ACCESS_HELP_TITLE_DEFAULT"] = "Sequence Editor"
L["ACCESS_HELP_BODY_DEFAULT"] =
    "Pick a tab above to switch sections. The button row at the top right handles save, discard, export, disable, record, and send. The ? button opens help for the active tab."
L["ACCESS_HELP_TITLE_PICKER"] = "Spell / Item / Macro Picker"
L["ACCESS_HELP_BODY_PICKER"] = "Search across spells, items, macros, "
    .. "and slash commands. Use the left rail to filter by category. "
    .. "Click a row to insert it into the step. Conditional buttons "
    .. "at the bottom add modifier prefixes. ESC closes."

-- About info (T1-5)
L["GEMS_ABOUT_AUTHOR"] = "Author: Sataana (MrSataana)"
L["GEMS_ABOUT_LINKS"] =
    "Guide: jesperlive.github.io/grip-ems-guide/\nCurseForge: curseforge.com/wow/addons/grip-enhanced-macro-sequencer\nWago: addons.wago.io/addons/qGZODqNd\nWoWInterface: wowinterface.com/downloads/info27081"
L["GEMS_ABOUT_KEYBINDS"] = "Active keybinds: %d"
L["GEMS_ABOUT_OOC_QUEUE"] = "OOC queue: %d pending"
L["GEMS_ABOUT_SOURCE_STATUS"] = "Migration source: %s"
L["GEMS_ABOUT_MACRO_SLOTS"] = "Macro slots: %d / %d (per character)"
L["GEMS_UI_ACTIVE_SEQUENCES_LABEL"] = "Active sequences"
L["GEMS_UI_CONTEXT_LABEL"] = "Context"
L["GEMS_LOGIN_ACTIVE"] = "|cFF888888  %d active sequence(s)|r"
L["GEMS_UI_SETTINGS_BTN"] = "Settings"
L["GEMS_UI_SETTINGS_BTN_DESC"] = "Open GRIP-EMS settings panel"

-- Migration report (T1-9)
L["GEMS_REPORT_HEADER_MIGRATE"] = "--- GRIP-EMS Migration Report ---"
L["GEMS_REPORT_HEADER_IMPORT"] = "--- GRIP-EMS Import Report ---"
L["GEMS_REPORT_IMPORTED"] = "Imported: %d sequence(s), %d variable(s)"
L["GEMS_REPORT_DORMANT"] = "  (%d stored for other classes, activated on login)"
L["GEMS_REPORT_SKIPPED"] = "Skipped: %d (already exist)"
L["GEMS_REPORT_SEQ_ENTRY"] = "  + %s (%d steps, %s)"
L["GEMS_REPORT_LIMITATIONS"] = "Known limitations:"
L["GEMS_REPORT_VERSIONS_DROPPED"] = "  - %d extra version(s) not imported (only default version supported)"
L["GEMS_REPORT_PAUSES_CONVERTED"] = "  - %d pause action(s) converted to %d empty step(s)"
L["GEMS_REPORT_EMBEDS_SKIPPED"] = "  - %d embedded sequence ref(s) skipped (not yet supported)"
L["GEMS_REPORT_TRUNCATED"] = "  - %d step(s) were too long and got cut off (WoW limits macros to 255 characters)"
L["GEMS_REPORT_ENCRYPTED_SKIPPED"] = "  - %d encrypted item(s) skipped (protected content, cannot be imported)"
L["GEMS_REPORT_TIP_VERIFY"] = "Tip: Open each migrated sequence and verify steps look correct."
L["GEMS_REPORT_TIP_VERSIONS"] = "Use /gems to open the editor and configure context version overrides."

-- Guide (T1-10)
L["GEMS_GUIDE_TITLE"] = "GRIP-EMS Interactive Guide"
L["GEMS_GUIDE_PATH"] = "Copy this URL and open it in your browser:"
L["GEMS_GUIDE_TIP"] = "Local file: Interface/AddOns/GRIP-EMS/Guide/GRIP-EMS_Guide.html"
L["GEMS_GUIDE_URL"] = "https://jesperlive.github.io/grip-ems-guide/"
L["GEMS_GUIDE_CLICK"] = "|cff4ecca3|HGRIPEMSguide|h[Click here to open GRIP-EMS Guide]|h|r"
L["GEMS_HELP_GUIDE"] = "  /gems guide - GRIP-EMS Interactive Guide"

-- Import preview (T2-4)
L["GEMS_IMPORT_PREVIEW_TITLE"] = "Import Preview"
L["GEMS_IMPORT_PREVIEW_SEQ_HEADER"] = "Sequences (%d)"
L["GEMS_IMPORT_PREVIEW_VAR_HEADER"] = "Variables (%d)"
L["GEMS_IMPORT_PREVIEW_NEW"] = "New"
L["GEMS_IMPORT_PREVIEW_EXISTS"] = "Exists"
L["GEMS_IMPORT_PREVIEW_IDENTICAL"] = "Identical"
L["GEMS_IMPORT_PREVIEW_DIFFERENT"] = "Different"
L["GEMS_IMPORT_PREVIEW_IMPORT_SELECTED"] = "Import Selected (%d)"
L["GEMS_IMPORT_PREVIEW_CANCEL"] = "Cancel"
L["GEMS_IMPORT_PREVIEW_SELECT_ALL"] = "Select All"
L["GEMS_IMPORT_PREVIEW_DESELECT_ALL"] = "Deselect All"
L["GEMS_IMPORT_PREVIEW_EMPTY"] = "No sequences or variables found in this string."
L["GEMS_IMPORT_PREVIEW_STEPS_MALFORMED"] = "'%s': steps field is malformed, no steps could be read."
L["GEMS_IMPORT_PREVIEW_DESC"] = "Read the pasted text and show importable sequences"
L["GEMS_IMPORT_CLEAR_DESC"] = "Clear the paste box"
L["GEMS_IMPORT_SELECT_ALL_DESC"] = "Select all sequences for import"
L["GEMS_IMPORT_DESELECT_ALL_DESC"] = "Deselect all sequences"
L["GEMS_IMPORT_CANCEL_DESC"] = "Go back to the paste step"
L["GEMS_IMPORT_COMMIT_DESC"] = "Import the selected sequences"
L["GEMS_IMPORT_PREVIEW_SUMMARY"] = "Imported %d sequence(s), %d variable(s)"
L["GEMS_IMPORT_PREVIEW_BTN"] = "Preview"
L["GEMS_IMPORT_PREVIEW_HEADER"] = "%d sequences, %d variables"
L["GEMS_IMPORT_PREVIEW_NEW_COUNT"] = "%d new"
L["GEMS_IMPORT_PREVIEW_EXISTING_COUNT"] = "%d existing"
L["GEMS_IMPORT_PREVIEW_INFO"] = "%d versions, %d steps"
L["GEMS_IMPORT_PREVIEW_ACTION_SKIP"] = "Skip"
L["GEMS_IMPORT_PREVIEW_ACTION_REPLACE"] = "Replace"
L["GEMS_IMPORT_PREVIEW_ACTION_RENAME"] = "Rename"

-- Advanced Export (T2-12)
L["GEMS_EXPORT_PICK_TITLE"] = "Export Sequences"
L["GEMS_EXPORT_PICK_HEADER"] = "%d sequences, %d variables, %d macros available"
L["GEMS_EXPORT_PICK_SEQ_HEADER"] = "Sequences (%d)"
L["GEMS_EXPORT_PICK_VAR_HEADER"] = "Variables (%d)"
L["GEMS_EXPORT_PICK_MACRO_HEADER"] = "Macros (%d)"
L["GEMS_EXPORT_PICK_MACRO_DEPS"] = "(+%d macros)"
L["GEMS_EXPORT_PICK_MACRO_SCOPE_ACCOUNT"] = "account"
L["GEMS_EXPORT_PICK_MACRO_SCOPE_CHARACTER"] = "char"
L["GEMS_EXPORT_PICK_INFO"] = "%d versions, %d steps"
L["GEMS_EXPORT_PICK_VAR_DEPS"] = "(+%d vars)"
L["GEMS_EXPORT_PICK_USED_BY"] = "used by: %s"
L["GEMS_EXPORT_PICK_AUTO"] = "auto"
L["GEMS_EXPORT_PICK_SELECT_ALL"] = "Select All"
L["GEMS_EXPORT_PICK_DESELECT_ALL"] = "Deselect All"
L["GEMS_EXPORT_PICK_EXPORT_SELECTED"] = "Export Selected (%d)"
L["GEMS_EXPORT_PICK_BACK"] = "Back"
L["GEMS_EXPORT_PICK_DISPLAY_HEADER"] = "Exported %d sequences, %d variables, %d macros"
L["GEMS_EXPORT_PICK_EMBEDDED_WARN"] = "%s uses %s (not selected)"
L["GEMS_EXPORT_PICK_LOCALE_WARN"] =
    "Variables that depend on locale-specific spell names may not work for players using other game languages"
L["GEMS_EXPORT_COPY_TEXT"] = "Copy as Text"
L["GEMS_EXPORT_COPY_TEXT_DESC"] = "Copy a readable summary to clipboard"
L["GEMS_EXPORT_META_TITLE"] = "Export Metadata"
L["GEMS_EXPORT_META_SUBTITLE"] = "Review and customise before exporting %d sequences"
L["GEMS_EXPORT_META_NAME"] = "Collection Name"
L["GEMS_EXPORT_META_AUTHOR"] = "Author"
L["GEMS_EXPORT_META_DESC"] = "Description"
L["GEMS_EXPORT_META_URL"] = "URL / Link"
L["GEMS_EXPORT_META_TALENT"] = "Talent Loadout"
L["GEMS_EXPORT_META_INCLUDE_AUTHOR"] = "Include author"
L["GEMS_EXPORT_META_INCLUDE_DESC"] = "Include description"
L["GEMS_EXPORT_META_INCLUDE_TALENT"] = "Include talent string"
L["GEMS_EXPORT_META_INCLUDE_URL"] = "Include URL"
L["GEMS_EXPORT_META_GENERATE"] = "Generate Export String"
L["GEMS_EXPORT_META_BACK"] = "Back to Selection"
L["GEMS_EXPORT_META_FORMAT_LABEL"] = "Format:"
L["GEMS_EXPORT_FORMAT_BUILTIN"] = "GRIP-EMS"
L["GEMS_IMPORT_COLLECTION_HEADER"] = "Collection: %s by %s"
L["GEMS_UI_EXPORT_MULTI"] = "Export Multiple..."
L["GEMS_HELP_EXPORTALL"] = "  /gems exportall - Open multi-select export window"
L["GEMS_EXPORT_GENERATE_DESC"] = "Generate the export string from selected sequences"
L["GEMS_EXPORT_COPY_DESC"] = "Copy the export string to clipboard"
L["GEMS_EXPORT_SELECT_ALL_DESC"] = "Select all sequences for export"
L["GEMS_EXPORT_DESELECT_ALL_DESC"] = "Deselect all sequences"
L["GEMS_EXPORT_BACK_DESC"] = "Return to selection"
L["GEMS_EXPORT_CLOSE_DESC"] = "Close export window"

-- Transmission (T2-9)
L["GEMS_HELP_SEND"] = "  /gems send <name> <player> - Send a sequence to another player"
L["GEMS_HELP_ACCEPT"] = "  /gems accept - Accept the latest incoming sequence"
L["GEMS_HELP_VALIDATE"] = "  /gems validate - Validate all sequences for stale/invalid spells"
L["GEMS_SEND_USAGE"] = "Usage: /gems send <name> <player>"
L["GEMS_SEND_SUCCESS"] = "Sent '%s' to %s"
L["GEMS_SEND_FAILED"] = "Send failed: %s"
L["GEMS_SEND_DISABLED"] = "P2P sharing is disabled in settings."
L["GEMS_SEND_NO_SEQ"] = "No sequence named '%s' found."
L["GEMS_EXPORT_NO_REDISTRIBUTE"] = "Sequence '%s' is marked do-not-share by its author; sharing is refused."
L["GEMS_RECEIVE_ANNOUNCE"] = "Received sequence from %s. Opening import..."
L["GEMS_RECEIVE_AUTO"] = "Auto-imported '%s' from %s (friend)."
L["GEMS_REQUEST_SENT"] = "Requesting '%s' from %s..."
L["GEMS_REQUEST_FULFILLED"] = "Sent '%s' to %s (requested)."
L["GEMS_VERSION_ANNOUNCE"] = "GRIP-EMS user detected: %s (v%s)"
L["GEMS_ACCEPT_USAGE"] = "No pending sequences to accept."
L["GEMS_UI_SEND_PLAYER"] = "Send to Player"
L["GEMS_UI_SEND_BTN"] = "Send"
L["GEMS_UI_SEND_BTN_DESC"] = "Send this sequence to another player"
L["GEMS_SEND_DIALOG_TEXT"] = "Send '%s' to:"
L["GEMS_SEND_DIALOG_ACCEPT"] = "Send"
L["GEMS_SEND_DIALOG_KNOWN"] = "Known users:"
L["GEMS_META_SENT"] = "Metadata sync request sent for '%s'."
L["GEMS_META_NEWER"] = "Newer version of '%s' available from %s, requesting..."
L["GEMS_META_CURRENT"] = "Local '%s' is up to date (remote from %s)."
L["GEMS_SPELLCACHE_SENT"] = "Spell cache broadcast sent to group."
L["GEMS_SPELLCACHE_MERGED"] = "Merged %d spell cache entries from %s."
L["GEMS_P2P_ENABLED"] = "Enable P2P Sharing"
L["GEMS_P2P_ENABLED_DESC"] = "Send and receive sequences with other players who use this addon."
L["GEMS_P2P_AUTO_FRIENDS"] = "Auto-Accept from Friends"
L["GEMS_P2P_AUTO_FRIENDS_DESC"] = "Save sequences sent by friends without asking you first."
L["GEMS_P2P_ANNOUNCE"] = "Announce Received"
L["GEMS_P2P_ANNOUNCE_DESC"] = "Print a chat line when you receive a sequence from another player."
L["GEMS_IMPORT_FROM"] = "Import from %s"

-- Block list (T2-9)
L["GEMS_BLOCK_ADDED"] = "Blocked %s from P2P transmission."
L["GEMS_BLOCK_REMOVED"] = "Unblocked %s."
L["GEMS_BLOCK_NOT_FOUND"] = "%s is not blocked."
L["GEMS_BLOCK_LIST_EMPTY"] = "No players blocked."
L["GEMS_BLOCK_LIST_HEADER"] = "Blocked players:"
L["GEMS_SETTINGS_BLOCKED_PLAYERS"] = "Blocked Players"
L["GEMS_SETTINGS_BLOCKED_PLAYERS_DESC"] = "Players on this list cannot send you sequences."
L["GEMS_HELP_BLOCK"] = "  /gems block <player> - Block a player from sending you sequences"
L["GEMS_HELP_UNBLOCK"] = "  /gems unblock <player> - Unblock a player"
L["GEMS_HELP_BLOCKLIST"] = "  /gems blocklist - List all blocked players"

-- Tracker HUD (T2-7)
L["GEMS_TRACKER_TOGGLE"] = "Tracker HUD %s."
L["GEMS_TRACKER_LOCKED"] = "Tracker locked."
L["GEMS_TRACKER_UNLOCKED"] = "Tracker unlocked."
L["GEMS_TRACKER_HEADER"] = "Tracker HUD"
L["GEMS_TRACKER_ICONSIZE_DESC"] = "Set the size of each sequence icon in pixels."
L["GEMS_TRACKER_ORIENTATION_DESC"] = "Stack the icons in a row or in a column."
L["GEMS_TRACKER_SHOWNAME_DESC"] = "Show the sequence name under each icon."
L["GEMS_TRACKER_SHOWMODS_DESC"] = "Show which modifier keys are currently held (Alt, Shift, or Ctrl)."
L["GEMS_TRACKER_LOCK_DESC"] = "Lock the Tracker HUD in place so you cannot drag it."
L["GEMS_TRACKER_SHOWMODE_DESC"] = "Choose when the Tracker HUD shows on your screen."
L["GEMS_TRACKER_MODE_ALWAYS"] = "Always"
L["GEMS_TRACKER_MODE_COMBAT"] = "In Combat"
L["GEMS_TRACKER_MODE_TARGET"] = "Has Target"
L["GEMS_TRACKER_MODE_NEVER"] = "Never"
L["GEMS_TRACKER_SCALE_DESC"] = "Change the overall size of the Tracker HUD."
L["GEMS_TRACKER_PREVIEW_HINT"] = "Preview shows what the HUD looks like now. Combat values may differ."
L["GEMS_HELP_TRACKER"] = "  /gems tracker [lock] - Toggle tracker HUD"

-- Debug window (T1-6)
L["GEMS_HELP_DEBUGWINDOW"] = "  /gems debugwindow - Toggle debug message window"
L["GEMS_DEBUG_WINDOW_TITLE"] = "GRIP-EMS Debug"
L["GEMS_DEBUG_CLEAR"] = "Clear"
L["GEMS_DEBUG_COPY"] = "Copy"
L["GEMS_DEBUG_COPY_HINT"] = "Use /gems export or Ctrl+C from the export frame to copy debug output."
L["GEMS_UI_WHATSNEW_DISMISS"] = "Don't show again"
L["GEMS_WHATSNEW_DISMISS_DESC"] = "Don't show this again for this version"
L["GEMS_DEBUG_CLOSE_DESC"] = "Close debug window"
L["GEMS_DEBUG_CLEAR_DESC"] = "Clear all debug messages"
L["GEMS_DEBUG_COPY_DESC"] = "Copy all messages to clipboard"

-- Locale Phase 2e
L["GEMS_HELP_REVALIDATE"] = "  /gems revalidate - Update all sequences with current spell IDs"

-- Click rate (v1.2.0 S01)
L["GEMS_SETTINGS_CLICK_RATE"] = "Click Rate (ms)"
L["GEMS_SETTINGS_CLICK_RATE_DESC"] =
    "Your press speed for sequences, in milliseconds. EMS advances one step per key press and does not cap how fast you press; this value guides the Faster, Slower recommendation and the timing of imported pauses. Default is 250ms."
L["GEMS_SETTINGS_CHAR_OVERRIDES"] = "Character Overrides"
L["GEMS_SETTINGS_CHAR_CLICK_RATE"] = "Per-Character Click Rate (ms)"
L["GEMS_SETTINGS_CHAR_CLICK_RATE_DESC"] =
    "Use a different click rate on this character only. Set to 0 to use the shared value instead."

L["GEMS_SETTINGS_CHAR_CLICK_RATE_WARN"] = "Your setting: %dms (%dms faster than the %dms human/hardware floor)"
L["GEMS_STATUS_CLICK_RATE"] = "Click Rate: %dms (effective)"
L["GEMS_STATUS_CVAR_PENDING_LINE"] = "%d pending CVar changes:"
L["GEMS_STATUS_CVAR_CAUSE_LINE"] = "  %d %s"

-- Macro reset modifiers (v1.2.0 S01)
L["GEMS_SETTINGS_MACRO_RESET"] = "Macro Reset"
L["GEMS_RESET_MOD_DESC"] = "Reset the step counter to 1 when this modifier is held during a key press."
L["GEMS_UI_RESET_MODS_HEADER"] = "Modifier Reset (Per Sequence)"
L["GEMS_UI_RESET_MODS_ENABLE"] = "Use per-sequence overrides"
L["GEMS_UI_RESET_MODS_GLOBAL"] = "(using global settings)"
L["GEMS_RESET_MOD_LEFTBUTTON"] = "Left Click"
L["GEMS_RESET_MOD_RIGHTBUTTON"] = "Right Click"
L["GEMS_RESET_MOD_MIDDLEBUTTON"] = "Middle Click"
L["GEMS_RESET_MOD_BUTTON4"] = "Mouse Button 4"
L["GEMS_RESET_MOD_BUTTON5"] = "Mouse Button 5"
L["GEMS_RESET_MOD_LEFTALT"] = "Left Alt"
L["GEMS_RESET_MOD_RIGHTALT"] = "Right Alt"
L["GEMS_RESET_MOD_ALT"] = "Any Alt"
L["GEMS_RESET_MOD_LEFTCONTROL"] = "Left Control"
L["GEMS_RESET_MOD_RIGHTCONTROL"] = "Right Control"
L["GEMS_RESET_MOD_CONTROL"] = "Any Control"
L["GEMS_RESET_MOD_LEFTSHIFT"] = "Left Shift"
L["GEMS_RESET_MOD_RIGHTSHIFT"] = "Right Shift"
L["GEMS_RESET_MOD_SHIFT"] = "Any Shift"
L["GEMS_RESET_MOD_ANYMOD"] = "Any Modifier"
L["GEMS_RESET_MOD_MOUSE_HEADER"] = "Mouse Buttons"
L["GEMS_RESET_MOD_ALT_HEADER"] = "Alt Keys"
L["GEMS_RESET_MOD_CONTROL_HEADER"] = "Control Keys"
L["GEMS_RESET_MOD_SHIFT_HEADER"] = "Shift Keys"
L["GEMS_RESET_MOD_ANY_HEADER"] = "Combination"

-- Hold to freeze (v2.1.8)
L["GEMS_HOLD_FREEZE_HEADER"] = "Hold to Freeze"
L["GEMS_HOLD_FREEZE_ENABLE"] = "Enable hold-to-freeze"
L["GEMS_HOLD_FREEZE_ENABLE_DESC"] =
    "Hold a modifier to pause the active sequence on its current step. It does not advance or cast while held, and picks up where it left off when you release."
L["GEMS_HOLD_FREEZE_MODIFIER"] = "Freeze modifier"
L["GEMS_HOLD_FREEZE_MODIFIER_DESC"] =
    "Which modifier freezes the sequence while held. If a sequence uses the same modifier for a variant, the variant runs there instead. If you also reset on this modifier, freeze takes priority while it is held."
L["GEMS_HOLD_FREEZE_MOD_SHIFT"] = "Shift"
L["GEMS_HOLD_FREEZE_MOD_CTRL"] = "Control"
L["GEMS_HOLD_FREEZE_MOD_ALT"] = "Alt"
L["GEMS_HOLD_FREEZE_CONFLICT_RESET"] =
    "Hold-to-freeze: you also reset on %s. While that modifier is held, freeze takes priority over reset."
L["GEMS_HOLD_FREEZE_CONFLICT_VARIANT"] =
    "Hold-to-freeze: sequence %s uses %s for a variant, so the variant runs there instead of freezing."

-- Corrupt sequence recovery
L["GEMS_CORRUPT_TITLE"] = "Corrupt Sequence Detected"
L["GEMS_CORRUPT_TEXT"] = "The sequence '%s' could not be loaded.\n\nError: %s\n\nChoose an action:"
L["GEMS_CORRUPT_DELETE"] = "Delete"
L["GEMS_CORRUPT_SKIP"] = "Skip"
L["GEMS_CORRUPT_EXPORT"] = "Export Raw"
L["GEMS_CORRUPT_SUMMARY"] = "Corrupt sequences: %d deleted, %d skipped, %d exported"
L["GEMS_CORRUPT_NONE"] = "No corrupt sequences found."

-- Execution Tracer (v1.2.0 S03-B)
L["GEMS_TRACE_CAST"] = "[Trace] %s (ID: %d)%s"
L["GEMS_TRACE_STARTED"] = "Execution tracing started"
L["GEMS_TRACE_STOPPED"] = "Execution tracing stopped"
L["GEMS_TRACE_STATUS"] = "Execution tracer: %s (%.2f CPS)."
L["GEMS_TRACE_STATE_ON"] = "on"
L["GEMS_TRACE_STATE_OFF"] = "off"
L["GEMS_TRACE_UNAVAILABLE"] = "Execution tracer is not available."

-- CVar health (v1.2.0 S01)
L["GEMS_SETTINGS_CVAR_HEALTH"] = "CVar Health"
L["GEMS_SETTINGS_CVAR_DESC"] =
    "Game variables across %d categories (%d CVars). Green = optimal, yellow = suboptimal, red = critical, grey = informational."
L["GEMS_SETTINGS_CVAR_AUTOFIX"] = "Auto-Fix CVars on Login"
L["GEMS_SETTINGS_CVAR_AUTOFIX_DESC"] = "Set the suggested CVar values for you each time you log in."
L["GEMS_SETTINGS_CVAR_FIX"] = "Fix"

-- CVar Dashboard UI strings
L["GEMS_CVAR_FIX_ALL"] = "Fix All"
L["GEMS_CVAR_FIX_ALL_CRITICAL"] = "Fix All Critical"
L["GEMS_CVAR_FIX_ALL_SECTION"] = "Fix All in Section"
L["GEMS_CVAR_AUTOFIX_ENTRY"] = "Auto-fix on login"
L["GEMS_CVAR_AUTOFIX_ENTRY_GATED"] =
    "Master Auto-Fix must be enabled first. Turn on Auto-fix recommended values above to use per-CVar opt-in."
L["GEMS_CVAR_AUTOFIX_SECTION_GATED"] =
    "Master Auto-fix is off. Turn on Auto-fix recommended values above to choose per-CVar opt-ins."
L["GEMS_CVAR_AUTOFIX_PIN_OVERRIDE"] = "Pinned -- auto-fix is overridden until you unpin."
L["GEMS_CVAR_AUTOFIX_COUNT"] = "GEMS: Auto-fixed %d CVars on login."
L["GEMS_CVAR_HEALTH_SCORE"] = "CVar Health: %d/100"
L["GEMS_CVAR_SCORE_HISTORY_HEADER"] = "Score history"
L["GEMS_CVAR_SCORE_HISTORY_EMPTY"] = "No history yet -- entries record at login."
L["GEMS_CVAR_SCORE_HISTORY_RANGE"] = "low %d / high %d"
L["GEMS_CVAR_SECTION_HEALTH"] = "%s %s"
L["GEMS_CVAR_HEALTH_EXPLAIN_HEADER"] = "Why this score:"
L["GEMS_CVAR_HEALTH_EXPLAIN_PERFECT"] = "All recommended values are applied. Nothing to fix."
L["GEMS_CVAR_HEALTH_EXPLAIN_OFFENDER"] = "  - %s: %s -> %s (weight %d)"
L["GEMS_CVAR_HEALTH_EXPLAIN_SQW_CREDIT"] = "  - SpellQueueWindow: managed by SQW Optimiser (auto-credited)"
L["GEMS_CVAR_HEALTH_EXPLAIN_MORE"] = "  ... and %d more (open the relevant section to see all)."
L["GEMS_CVAR_COMBAT_DISABLED"] = "Cannot change secure CVars in combat."
L["GEMS_CVAR_YOUR_CHOICE"] = "(your choice)"
L["GEMS_CVAR_WILL_CHANGE"] = "Will change from %s to %s."
L["GEMS_CVAR_SET_VALUE"] = "Set Value"
L["GEMS_CVAR_UNDO"] = "Undo"
L["GEMS_CVAR_UNDO_DESC"] =
    "Restore the previous value of this CVar (the value before the last EMS-driven change). Disabled while the CVar is pinned -- unpin first."
L["GEMS_CVAR_UNDO_TO"] = "Undo to %s"
L["GEMS_CVAR_REDO"] = "Redo"
L["GEMS_CVAR_REDO_DESC"] =
    "Reapply the value that was undone by the last Undo. Disabled while the CVar is pinned -- unpin first."
L["GEMS_CVAR_REDO_TO"] = "Redo to %s"
L["GEMS_CVAR_PIN"] = "Pin My Choice"
L["GEMS_CVAR_PIN_DESC"] =
    "Mark this value as your intentional choice. EMS will not modify it via Fix actions, profile swaps, or Auto-fix on login. The CVar Health score will count it as optimal."
L["GEMS_CVAR_PIN_PINNED"] = "Pinned -- EMS will not change this CVar."
L["GEMS_CVAR_OPTION_RECOMMENDED"] = "%s (Recommended)"

-- L372 G.3b first wave -- options + descLong for 6 cvars

L["GEMS_CVAR_MACRO_LOCKBARS_DESCLONG"] =
    "Locks action bar buttons in place so you cannot drag them off the bar by accident. Recommended on (1) once you have your bars set up the way you want -- accidentally dragging a spell off mid-fight is a frustrating way to die. Turn it off (0) when you actively want to rearrange spells."

L["GEMS_CVAR_NAMEPLATES_SHOWENEMY_DESCLONG"] =
    "Master toggle for showing nameplates above enemy units. Recommended on (1) for anyone who plays in groups or PvP -- you need them to read incoming damage and target priority. Off (0) only makes sense for solo overworld questing where the screen is already cluttered."

L["GEMS_CVAR_FCT_ENABLE_DESCLONG"] =
    "Master toggle for the floating numbers that pop up when you deal or take damage. Recommended on (1) -- the numbers are how most players read combat tempo and gauge how hard a hit landed. Off (0) cleans the screen but you lose the per-hit feedback that healers and DPS both lean on."

L["GEMS_CVAR_MACRO_SELFCAST_DESCLONG"] =
    "Lets the game cast certain friendly spells on you when you have no target. Recommended on (1) -- without it, healing spells with no target either silently fail or pop a no-target error. With it on, you save a modifier-key tap for self-heals. Off (0) is for players who use macros that already encode their self-cast intent."

L["GEMS_CVAR_MACRO_AUTOPUSH_DESCLONG"] =
    "When you learn a new spell, the game automatically places it on your first empty action bar slot. Recommended off (0) -- for players running organised bars, which is most EMS users, the auto-place behaviour scatters newly learned spells into random slots you then have to find and remove. Off lets you place spells where you want them."

L["GEMS_CVAR_MACRO_MULTIBARS_OPT_0"] = "0 (None)"
L["GEMS_CVAR_MACRO_MULTIBARS_OPT_1"] = "1 (Action Bar 2)"
L["GEMS_CVAR_MACRO_MULTIBARS_OPT_3"] = "3 (Action Bars 2 + 3)"
L["GEMS_CVAR_MACRO_MULTIBARS_OPT_12"] = "12 (Right Action Bars 1 + 2)"
L["GEMS_CVAR_MACRO_MULTIBARS_OPT_15"] = "15 (All four extra bars)"
L["GEMS_CVAR_MACRO_MULTIBARS_DESCLONG"] =
    "Picks which extra action bars are visible on top of your main action bar. WoW exposes four extra bars and stores your selection as a 4-bit mask: bit 1 (value 1) shows Action Bar 2 (Bottom Left), bit 2 (value 2) shows Action Bar 3 (Bottom Right), bit 4 (value 4) shows Right Action Bar 1, bit 8 (value 8) shows Right Action Bar 2. The dropdown exposes five common combinations: 0=None, 1=Action Bar 2 only, 3=Action Bars 2+3 (both bottom), 12=Right Action Bars 1+2 (both right), 15=all four. For mixed combinations not in the list (e.g. bottom-left + right only = 5), use the in-game ActionBars settings panel (Settings > ActionBars) which exposes per-bar checkboxes, or run /console set enableMultiActionBars N where N is your chosen bitmask sum. EMS does not auto-set this value because bar-layout is a personal UX choice -- pick what matches your playstyle. This setting is per-character (each alt has its own bar visibility)."

L["GEMS_CVAR_MACRO_HELDPOLL_DESCLONG"] =
    "Controls how often the WoW engine retries casting a held-key spell after a failed cast attempt -- the spell-error poll interval in milliseconds. Default 500 ms means the engine polls roughly twice per second; lower values poll faster (more responsive when the cast becomes available) but consume slightly more client CPU. Higher values reduce polling overhead at the cost of a brief delay before the spell actually fires once it becomes castable. The Blizzard engine clamps any chosen value to the 100-10000 ms range. NOTE: Blizzard documents this as Internal-only -- advanced users only. Changing it rarely helps in practice and may cause unexpected interactions with other addons that rely on the default polling cadence. EMS recommends staying at 500 (Blizzard default) unless you have a specific reason to tune it."

-- L372 G.3b second wave -- options + descLong for 3 numeric-range cvars
L["GEMS_CVAR_NAMEPLATES_MAXDIST_DESCLONG"] =
    "Sets how far away enemy nameplates stay visible, in yards. 20 keeps the screen uncluttered in solo overworld content but loses visibility on ranged threats in groups. 60 is the modern raid and M+ sweet spot -- you see every relevant enemy without the screen drowning in plates. 80-100 maxes out the range for ranged DPS who want to spot casters at extreme distance, at the cost of more screen noise. 41 is the legacy Classic cap, harmless on Retail but rarely the right choice."

L["GEMS_CVAR_FPS_MAXFPS_DESCLONG"] =
    "Caps your in-game frame rate when the window is focused. 0 (uncapped) is fine on high-end hardware but causes coil whine and runs the GPU hot. Matching your monitor's refresh rate (60, 120, 144, or 240) gives smooth scrolling and saves power without any visible loss. Set lower than your refresh rate only if you're hitting thermal limits or want quieter fans."

L["GEMS_CVAR_MACRO_SPELLQUEUE_OPT_0"] = "0 ms (no queue)"
L["GEMS_CVAR_MACRO_SPELLQUEUE_OPT_100"] = "100 ms (Retail default)"
L["GEMS_CVAR_MACRO_SPELLQUEUE_OPT_200"] = "200 ms (relaxed)"
L["GEMS_CVAR_MACRO_SPELLQUEUE_OPT_400"] = "400 ms (max)"
L["GEMS_CVAR_MACRO_SPELLQUEUE_DESCLONG"] =
    "The time window in milliseconds after a global cooldown finishes during which a queued spell fires on its own. EMS needs 400 (the engine maximum) so macro sequence steps don't drop when GCDs finish a tick later than expected. Lower values (0, 100, 200) work for hand-cast play where you time inputs precisely, but they cause EMS sequences to skip clicks on variable latency. Set this to 400 for any EMS work."

-- L372 G.3b third wave -- options + descLong for 3 tiered-quality cvars
L["GEMS_CVAR_VISUAL_SHADOWS_DESCLONG"] =
    "Sets the resolution and depth of shadow maps under units, trees, and structures. Low and Fair save GPU memory and frame time, which helps on integrated graphics or a laptop on battery. Medium and High sit in the middle -- soft shadow edges and reasonable draw distance without dropping frames on mid-range cards. Ultra and Ultra High raise the shadow-map resolution and cascade depth for pristine screenshots, at a cost of 5-15 FPS on most cards for marginal in-motion gain. The default is High."

L["GEMS_CVAR_FPS_PARTICLES_DESCLONG"] =
    "Controls how many spell and environmental particle effects the game draws. Disabled removes them completely -- the biggest GPU saving, but it also strips some combat visual cues, so you can miss effects firing around you. Low through High trade detail for frame rate; Ultra keeps every spark and flame, which looks best solo but can bury the ground effects you need to dodge in 20-player raids and busy M+ pulls. The Blizzard default is High."

L["GEMS_CVAR_VISUAL_TEXRES_DESCLONG"] =
    "Sets the resolution of in-game texture maps for terrain, buildings, armour, and weapons, on Blizzard's three tiers: Low, Fair, High. Low and Fair compress textures to save VRAM, which gives older or low-VRAM cards a usable game but leaves armour and walls looking soft. High is the top tier and the default: it loads full-resolution textures that stay sharp at typical viewing distances. Drop to Fair or Low only if you are VRAM-limited (4 GB or less) and see texture stutter during raid bosses."

-- L372 G.3b fourth wave -- options + descLong for 14 floatingCombatText 0/1 toggle cvars
L["GEMS_CVAR_FCT_DAMAGE_DESCLONG"] =
    "Shows the damage numbers that float up from enemies you hit with spells and abilities. Recommended on (1) -- this is the headline DPS feedback most players rely on to read combat tempo. Off (0) hides every damage number and leaves only debuff/buff feedback."

L["GEMS_CVAR_FCT_AUTOS_DESCLONG"] =
    "Shows damage numbers for every auto-attack swing, not just abilities. Recommended on (1) for melee specs where auto damage is a noticeable share of total damage -- you can read auto cadence visually. Off (0) hides the auto trickle and only shows ability hits, which cleans the screen for caster specs that don't auto-attack much."

L["GEMS_CVAR_FCT_HEALING_DESCLONG"] =
    "Shows healing numbers that float up when you or allies receive healing in combat. Recommended on (1) -- healers read team health recovery from these numbers, and DPS see when they're being topped off. Off (0) hides all healing feedback in combat."

L["GEMS_CVAR_FCT_ABSSELF_DESCLONG"] =
    "Shows absorb numbers when your own shields (Power Word: Shield, Ice Barrier, similar) soak incoming damage. Recommended on (1) -- you can see how much your defensive cooldowns are mitigating versus the boss's hit size. Off (0) hides the absorb feedback even though the shield still works."

L["GEMS_CVAR_FCT_ABSTARGET_DESCLONG"] =
    "Shows absorb numbers when your shields soak damage on a friendly target you're shielding. Recommended on (1) for healers and tank-shielding specs (Disc Priest, Brewmaster) who need to see if their bubbles are landing. Off (0) is fine for DPS who do not cast absorbs."

L["GEMS_CVAR_FCT_PERIODIC_DESCLONG"] =
    "Shows damage/healing tick numbers for periodic effects (DoTs, HoTs) from the combat log. Recommended on (1) -- visible DoT ticks help you confirm bleeds and DoTs are still ticking on the target. Off (0) hides every tick but the spell is still working in the background."

L["GEMS_CVAR_FCT_DODGEMISS_DESCLONG"] =
    "Shows MISS / DODGE / PARRY markers when your attacks fail to land. Recommended on (1) -- you can see at a glance whether you're hitting from the wrong angle or whether the boss is parrying everything. Off (0) hides the miss feedback even though the attack still misses."

L["GEMS_CVAR_FCT_LOWRES_DESCLONG"] =
    "Shows the floating warning when your health or resource pool drops below the danger threshold. Recommended on (1) -- this is your last-second visual cue to pop a defensive or healing potion before you die. Off (0) hides the warning and you rely on bar UI alone."

L["GEMS_CVAR_FCT_PETMELEE_DESCLONG"] =
    "Shows damage numbers for your pet's auto-attacks. Recommended on (1) for Hunters, Warlocks, and Unholy DKs where pet damage is a noticeable share of the meter. Off (0) is fine for specs without a permanent pet, where the toggle does nothing anyway."

L["GEMS_CVAR_FCT_PETSPELL_DESCLONG"] =
    "Shows damage numbers for your pet's ability casts (Kill Command, Felhunter Spell Lock, etc.). Recommended on (1) for any pet-spec where the pet's ability output is part of the rotation. Off (0) keeps the pet's contribution invisible in the visual stream."

L["GEMS_CVAR_FCT_REACTIVES_DESCLONG"] =
    "Shows the floating notification when a reactive ability becomes usable (Overpower after dodge, Riposte after parry, Counterstrike). Recommended on (1) -- the popup is how you know a procced ability is available before it falls off. Off (0) hides the proc indicator and you watch the bar instead."

-- L372 G.3b fifth wave -- options + descLong for 15 raid-cluster 0/1 toggle cvars
L["GEMS_CVAR_RAIDING_AGGRO_DESCLONG"] =
    "Highlights raid frame portraits red when a unit pulls aggro from the boss. Recommended on (1) -- healers and off-tanks read aggro at a glance from this colour cue. Off (0) hides the red flash even when a squishy is about to die from boss attention."

L["GEMS_CVAR_RAIDING_RDEBUFFS_DESCLONG"] =
    "Shows debuff icons on raid frame portraits so you can see who needs cleansing. Recommended on (1) -- healers and dispellers track who has bleeds, magic debuffs, or curses without needing a separate addon. Off (0) hides all debuff icons and you watch the chat log instead."

L["GEMS_CVAR_RAIDING_HEALPRED_DESCLONG"] =
    "Shows an incoming-heal overlay on raid frame health bars when an ally has cast a heal but it has not landed yet. Recommended on (1) for healers running multiple casters together -- you can see if another healer's heal is already inbound and avoid overhealing. Off (0) hides the prediction and you rely on call-outs."

L["GEMS_CVAR_RAIDING_POWERBARS_DESCLONG"] =
    "Shows mana, energy, rage, or focus bars under raid frame portraits. Recommended off (0) by default -- reclaims vertical space on every raid frame which matters in 20-40 player groups. On (1) is useful for healers (mana visibility on other healers) and for tanks (rage visibility on co-tank)."

L["GEMS_CVAR_RAIDING_RCLASSCOLOR_DESCLONG"] =
    "Colours raid frame health bars by class colour (Mage blue, Warrior brown, etc.) instead of green-to-red health gradient. Recommended on (1) -- you can identify who is who at a glance, especially in mixed groups. Off (0) uses the threat-level gradient instead, which some players prefer for at-a-glance health reading."

L["GEMS_CVAR_RAIDING_DISPONLY_DESCLONG"] =
    "Filters raid frame debuff icons so only debuffs your class can dispel are shown. Recommended off (0) by default -- shows every debuff regardless of dispel kit, useful for understanding what's happening across the raid. On (1) for dispelling classes (Priest/Druid/Shaman/Paladin/Monk healers, Mage Spellsteal) cuts visual noise to only actionable debuffs."

L["GEMS_CVAR_RAIDING_ROLEDEBUFF_DESCLONG"] =
    "Renders certain role-specific debuff icons (boss mechanics, tank busters, healer-action-required debuffs) larger than normal so they stand out. Recommended on (1) -- the size difference makes major mechanics impossible to miss versus background noise. Off (0) renders every debuff at uniform size."

L["GEMS_CVAR_RAIDING_BIGDEF_DESCLONG"] =
    "Centres large defensive-cooldown icons on raid frame portraits when a tank or DPS is using a major defensive (Shield Wall, Icebound Fortitude, etc.). Recommended on (1) for healers -- you can see when the tank already mitigated incoming damage and adjust healing priority. Off (0) hides the defensive indicator entirely."

L["GEMS_CVAR_RAIDING_TIMELINE_DESCLONG"] =
    "Shows the in-game encounter timeline UI that lists upcoming boss abilities. Recommended on (1) -- the timeline helps new raiders learn fight sequences without external addons. Off (0) hides the timeline; you rely on DBM, BigWigs, or voice calls instead."

L["GEMS_CVAR_RAIDING_TIMEROLE_DESCLONG"] =
    "Filters the encounter timeline to show only abilities that affect your role. Recommended on (1) -- DPS players don't need to see healer-specific timeline notes and vice versa. Off (0) shows the full timeline including notes targeted at other roles."

L["GEMS_CVAR_RAIDING_WARNINGS_DESCLONG"] =
    "Shows large screen warnings for major boss mechanics (Targeted-by-Beam, Move-Away, etc.). Recommended on (1) for raiders without DBM or BigWigs -- the in-engine warning is the only call-out you'll get. Off (0) hides the warnings; useful if you use addons that fire competing warnings."

L["GEMS_CVAR_RAIDING_WARNHIDE_DESCLONG"] =
    "Filters encounter warnings to show only mechanics specifically targeting you. Recommended off (0) by default -- shows every encounter warning regardless of target, important for healers tracking group-wide mechanics. On (1) cuts visual noise on mechanics that don't require your action."

L["GEMS_CVAR_RAIDING_THREATNUM_DESCLONG"] =
    "Shows numeric threat percentage on target frame instead of just the threat colour band. Recommended on (1) for tanks -- you can read exact threat lead over the second-highest player and plan taunts. Off (0) shows the colour band only (green / yellow / orange / red)."

L["GEMS_CVAR_RAIDING_THREATSOUND_DESCLONG"] =
    "Plays an audio cue when you pull or lose threat. Recommended on (1) for tanks who pay attention to ears more than eyes -- the sound is faster than reading the bar colour. Off (0) makes threat purely visual, which matters if you raid with VoIP on speakers."

L["GEMS_CVAR_RAIDING_THREATTEXT_DESCLONG"] =
    "Shows a floating PULLED THREAT text in the screen middle when you pull aggro you shouldn't have. Recommended on (1) for DPS -- the warning is your last-second cue to drop threat or stop casting. Off (0) keeps the in-engine threat warnings purely on the unit frame."

-- L372 G.3b sixth wave -- options + descLong for 14 combat_targeting 0/1 toggle cvars
L["GEMS_CVAR_COMBAT_SOFTFORCE_DESCLONG"] =
    "Forces soft-targeting on units even when a hard target is already locked. Recommended on (1) -- this is how the modern WoW soft-target system smoothly hands off between manually picked targets and contextual soft-targets. Off (0) hides the soft-target indicator whenever a hard target is set, which is the legacy pre-Dragonflight behaviour."

L["GEMS_CVAR_COMBAT_SOFTFRIEND_OPT_0"] = "Off"
L["GEMS_CVAR_COMBAT_SOFTFRIEND_OPT_1"] = "Gamepad only"
L["GEMS_CVAR_COMBAT_SOFTFRIEND_DESCLONG"] =
    "Sets the soft-target highlight for friendly units -- the ghosted unit frame that appears when you face a player or NPC ally. Off (the default, and the EMS recommendation) suppresses it, which most healers prefer because they pick frames directly. Gamepad only enables it for controller binds. Mouse and keyboard only restricts it to KBM. Always shows it for both input modes. Healers and tanks who use click-targeting tend to leave this off so the soft-target overlay does not interfere with mouse picks."

L["GEMS_CVAR_COMBAT_TABNEW_DESCLONG"] =
    "Uses the modern target-nearest algorithm (introduced in Dragonflight) instead of the legacy alphabetical-by-name tab-target order. Recommended on (1) -- the modern algorithm picks based on screen position, which is what 99% of players actually want when they hit TAB. Off (0) reverts to the legacy algorithm which can feel random."

L["GEMS_CVAR_COMBAT_COMBATLOCK_DESCLONG"] =
    "Locks tab-target priority to your current target's combat-engagement set while you are in combat. Recommended on (1) -- prevents accidentally tabbing onto a non-combat NPC or summon when you're mid-pull. Off (0) lets TAB cycle through any unit in range regardless of combat state."

L["GEMS_CVAR_COMBAT_LOCKRELAX_DESCLONG"] =
    "Allows tab-target priority lock to relax when no valid combat target remains nearby (e.g. last enemy died, you stepped out of combat). Recommended on (1) -- the relaxation prevents getting stuck with no tab-targetable unit after a pull ends. Off (0) keeps the lock active until combat explicitly ends, which can leave you without a tab target if combat is still technically active."

L["GEMS_CVAR_COMBAT_PVPPRIO_DESCLONG"] =
    "Treats hostile players as higher priority than NPCs when picking tab-targets in PvP zones. Recommended on (1) for any open-world PvP play -- you want to tab onto the human threatening you, not the wolf next to them. Off (0) treats players and NPCs at equal priority, which is fine for purely PvE play."

L["GEMS_CVAR_COMBAT_ATTACKER_DESCLONG"] =
    "Auto-targets the enemy that just attacked you if you have no current target. Recommended on (1) for casters and ranged classes -- the auto-target gives you something to retaliate against without losing a global cooldown to manual targeting. Off (0) is for players who want full manual control even in unexpected combat."

L["GEMS_CVAR_COMBAT_AUTOENEMY_DESCLONG"] =
    "Auto-targets the nearest enemy when you start attacking with no target selected. Recommended on (1) -- the auto-pick is the fastest way to begin a melee engagement when you're walking into a pull. Off (0) means autoattack does nothing without a manual target first."

L["GEMS_CVAR_COMBAT_DESELECT_DESCLONG"] =
    "Drops your current target when you click in empty space. Recommended off (0) by default -- accidental click-drops in the middle of a fight are a common cause of losing a kick-target or boss tab-target. On (1) for players who specifically want click-deselect as a quick way to clear targeting."

L["GEMS_CVAR_COMBAT_LEFTCLICK_DESCLONG"] =
    "Allows left-click to interact with NPCs (talk, loot, vendor) instead of needing right-click. Recommended on (1) -- the modern Retail default since left-click is faster and matches every other game's interaction model. Off (0) reverts to the legacy right-click-to-interact behaviour."

L["GEMS_CVAR_COMBAT_HIGHLIGHT_DESCLONG"] =
    "Highlights the unit that the AI assist system suggests you target next. Recommended off (0) by default -- the assist suggestions are noisy in busy fights and most experienced players ignore them. On (1) for new players learning a class who want the suggestion overlay as a training aid."

L["GEMS_CVAR_COMBAT_PROCS_DESCLONG"] =
    "Shows the screen-edge flash overlay when a procced spell becomes castable (Hot Streak, Snipe, Sudden Death, etc.). Recommended on (1) -- the proc flash is how most rotations communicate cast this now to the player. Off (0) leaves you reading the bar manually, which is fine if you use WeakAura-style addons for procs."

L["GEMS_CVAR_COMBAT_LOC_DESCLONG"] =
    "Shows the large screen overlay when you are stunned, silenced, feared, or otherwise loss-of-control'd. Recommended on (1) -- the overlay tells you what specifically is preventing you from acting and how long it lasts. Off (0) hides the overlay; you read your debuff bar instead."

L["GEMS_CVAR_COMBAT_MOUSEOVER_DESCLONG"] =
    "Lets you cast targeted spells on whatever unit you're hovering over with the cursor, without changing your hard target. No recommended value -- mouseover casting is a healer-style technique that requires custom macros and isn't a universal default. On (1) enables the feature engine-wide; off (0) keeps cursor hover purely cosmetic."

L["GEMS_CVAR_FCT_ENERGY_DESCLONG"] =
    "Shows the floating numbers when you gain energy, rage, focus, or runic power outside of regen ticks (e.g. procced resource refunds). Recommended off (0) -- the gains are already visible on the resource bar, and the floating numbers add screen clutter. Turn on (1) only if you specifically want to track refund procs visually."

L["GEMS_CVAR_FCT_AURAS_DESCLONG"] =
    "Shows the floating notification when buffs or debuffs appear or fall off. Recommended off (0) -- BuffFrame and aura addons already display this with better positioning and grouping. Turn on (1) only if you don't use a buff addon and want the in-engine feedback."

L["GEMS_CVAR_FCT_HEALERS_DESCLONG"] =
    "Shows a marker over friendly healers in PvP combat so allies can see who is healing them. Recommended off (0) -- the engine implementation is unreliable on modern Retail and most arena UIs already track healers better through party frames. Turn on (1) if you specifically want the in-engine cue and don't use a focused PvP UI."

-- L372 G.3b seventh wave -- options + descLong for 12 solo_play 0/1 toggle cvars
L["GEMS_CVAR_SOLO_AUTOLOOT_DESCLONG"] =
    "When you loot a corpse, every item lands in your bags automatically without the per-slot click prompt. Recommended on (1) -- the manual click prompt was the default 15 years ago and exists today only for nostalgia. Off (0) is for players who specifically want to see each item before accepting it, useful when sharing loot in old-world group play."

L["GEMS_CVAR_SOLO_LOOTMOUSE_DESCLONG"] =
    "Spawns the loot window directly under your cursor instead of in a fixed screen position. Recommended on (1) -- you don't have to drag the cursor across the screen to right-click items. Off (0) puts the window in a fixed location, easier to predict but slower to click through."

L["GEMS_CVAR_SOLO_AELOOT_DESCLONG"] =
    "Disables area-of-effect looting (one Shift-click loots every corpse in range). Recommended off (0) by default -- AE looting is the modern default and saves hundreds of clicks per session in mob-grinding content. Turn on (1) only if you want forced one-corpse-at-a-time looting for nostalgia or for picking through specific item drops."

L["GEMS_CVAR_SOLO_DISMOUNT_DESCLONG"] =
    "Automatically dismounts you when you try to cast a spell or attack while mounted. Recommended on (1) -- the alternative is the cast silently failing because mounted players cannot cast. Off (0) forces you to dismount manually before casting, which is fine for players who treat casting-while-mounted as a mistake worth blocking."

L["GEMS_CVAR_SOLO_DISMOUNTFLY_DESCLONG"] =
    "Automatically dismounts you from flying mounts even when in flight. Recommended off (0) by default -- dismounting at flight altitude drops you several hundred yards and almost always kills you. On (1) for players who fly low and want consistency with the ground-mount auto-dismount behaviour."

L["GEMS_CVAR_SOLO_TOT_DESCLONG"] =
    "Shows a small target-of-target frame near the main target frame so you can see who your target is targeting. Recommended on (1) for tanks (am I being attacked?) and healers (who is my tank healing?). Off (0) reclaims a small chunk of screen space, fine if you rely on raid frames or addons for the same info."

L["GEMS_CVAR_SOLO_TCASTBAR_DESCLONG"] =
    "Shows a castbar on the target frame for enemies and friendlies that are casting spells. Recommended on (1) -- the castbar tells you what the enemy is about to do and when to interrupt. Off (0) only makes sense for players who rely on dedicated nameplate or boss-mod castbar addons."

L["GEMS_CVAR_SOLO_QUESTWATCH_DESCLONG"] =
    "Automatically adds newly accepted quests to the visible quest tracker on the right side of the screen. Recommended on (1) -- accepting a quest implies you want to see how to do it. Off (0) is for players who manage the tracker manually and prefer a clean default state."

L["GEMS_CVAR_SOLO_QUESTPOI_DESCLONG"] =
    "Shows quest objectives as numbered icons on the world map and minimap. Recommended on (1) -- the POI icons are how modern WoW shows you where to go for any active quest. Off (0) reverts to text-only objective lists, useful only for players who specifically want a no-map exploration experience."

L["GEMS_CVAR_SOLO_PARTYPETS_DESCLONG"] =
    "Shows party-member pets in your party frame list (separate small bars under each party member). Recommended off (0) by default -- party pet bars clutter the party UI and most players read pet health through nameplates instead. On (1) for healers who explicitly want pet visibility, especially in Hunter-heavy or Warlock-heavy groups where pet damage tanking is part of the strategy."

L["GEMS_CVAR_SOLO_INTERICON_DESCLONG"] =
    "Shows the soft-target interact icon (the floating cursor-like glyph) on units you can interact with while in range. Recommended on (1) -- the icon tells you at a glance whether the NPC in front of you is talkable or just decoration. Off (0) hides the icon and you rely on cursor hover to discover interactable units."

L["GEMS_CVAR_SOLO_AUTOINTER_DESCLONG"] =
    "Auto-triggers the interact action on the soft-targeted unit when you walk into interact range. Recommended off (0) by default -- auto-interact is aggressive and triggers any time you walk past an NPC you didn't mean to talk to. On (1) is a controller or streamlined-UI preference for players who use the interact key as a primary input."

-- L372 G.3b eighth wave -- options + descLong for 17 dungeons + raid-leftover 0/1 toggle cvars
L["GEMS_CVAR_RAIDING_COMBATWARN_DESCLONG"] =
    "Master toggle for all engine-level in-combat screen warnings (pull timers, role calls, encounter start). Recommended on (1) -- the master toggle gates every per-feature warning below it. Off (0) suppresses combat warnings engine-wide, useful only if you fully rely on an addon stack for raid feedback."

L["GEMS_CVAR_DUNGEON_DPSRESET_DESCLONG"] =
    "Resets the in-engine damage meter when you zone into a new dungeon or raid instance. Recommended on (1) -- the meter should show numbers for this pull, not lifetime totals from previous content. Off (0) keeps a running tally across instances, mostly useful only if you don't use Details or Skada for proper metering."

L["GEMS_CVAR_DUNGEON_ENTRANCE_DESCLONG"] =
    "Shows dungeon and raid entrance markers on the world map and minimap. Recommended on (1) -- the markers help locate dungeon entrances when running into-instance from outside (M+ pulls, weekly chest visits). Off (0) hides the markers; you navigate by memory or by group leader's coordinates."

L["GEMS_CVAR_DUNGEON_CLUTTER_DESCLONG"] =
    "Restricts the unit-clutter visual cleanup (transparent friendly players in dense areas) to inside instances only. Recommended on (1) -- the cleanup helps see boss mechanics in raids without affecting overworld visibility. Off (0) extends the clutter cleanup to overworld content too, which can hide players in capital cities."

L["GEMS_CVAR_DUNGEON_ENEMYCAST_DESCLONG"] =
    "Shows enemy castbars on Arena UI enemy frames. Recommended on (1) for arena PvP -- you need to see enemy casts to interrupt or counter them, and the Arena UI is often the cleanest source of that info. Off (0) hides the castbars; only fine if you use a dedicated PvP enemy-cast addon."

L["GEMS_CVAR_DUNGEON_LOGFILE_DESCLONG"] =
    "Appends a timestamp to each combat log file so new logs don't overwrite old ones. Recommended on (1) -- separate files per session are how Warcraft Logs uploaders find each raid night's data. Off (0) reuses one filename and overwrites, useful only if you don't archive combat logs."

L["GEMS_CVAR_DUNGEON_DIMINISH_DESCLONG"] =
    "Shows diminishing-returns indicators on enemy nameplates in PvP combat (stun, fear, root, etc.). Recommended on (1) for any PvP play -- you can see whether your next CC will be reduced-duration or completely immune. Off (0) hides the DR icons; you track DRs in your head."

L["GEMS_CVAR_RAIDING_COMBATLOG_DESCLONG"] =
    "Enables high-detail combat logging (per-event metadata, more granular timestamps). Recommended on (1) for any raider running parses through Warcraft Logs -- the advanced log fields are required for accurate parse uploading. Off (0) writes a slimmer log that uploads fail to parse correctly."

L["GEMS_CVAR_RAIDING_KEEPGRP_DESCLONG"] =
    "When sorting raid frames, keeps the original sub-group (Group 1, Group 2) ordering instead of merging across groups. Recommended off (0) by default -- modern role-sort is more useful than group-sort for healing. On (1) for raid leaders who use group composition as a tactical assignment (e.g. group 1 = ranged, group 2 = melee)."

L["GEMS_CVAR_RAIDING_TANKASSIST_DESCLONG"] =
    "Shows the Main Tank and Main Assist callouts visually on raid frames. Recommended on (1) -- the visual marker helps the raid identify who to follow for kill order and who to look at for taunt swaps. Off (0) hides the markers; fine only if your raid doesn't use the MA/MT system."

L["GEMS_CVAR_RAIDING_FINDSELF_DESCLONG"] =
    "Highlights your own raid frame more strongly than others. Recommended on (1) -- in a 30-person raid with similar-looking frames, you need to know which one is YOU at a glance. Off (0) treats your frame identically to everyone else's, which can cause confusion when self-healing or self-buffing."

L["GEMS_CVAR_RAIDING_CASTBUFFS_DESCLONG"] =
    "Shows buffs you can cast on raid frame portraits (your own Power Word: Shield, Innervate, etc.). Recommended off (0) by default -- the buff icons clutter raid frames and most players track their own cooldowns via the action bar. On (1) for buff-class healers who want visual confirmation of who has their HoT or shield active."

L["GEMS_CVAR_RAIDING_DISPDEBUFFS_DESCLONG"] =
    "Shows debuffs you can dispel on raid frame portraits (your Mass Dispel, Cure Disease, Decurse, etc.). Recommended on (1) for dispelling specs -- the highlight is how you spot which raid member needs the dispel without scanning the whole frame. Off (0) hides the highlight; you read raw debuff icons instead."

L["GEMS_CVAR_RAIDING_RAIDSETTINGS_DESCLONG"] =
    "Enables the raid-specific UI profile (alternate raid frame layout, larger nameplates, etc.) when you enter a raid instance. Recommended on (1) -- the raid profile is designed for 20-40 player groups and looks better than the party profile at that scale. Off (0) uses your party profile in raids, fine for players who explicitly want one consistent UI."

L["GEMS_CVAR_RAIDING_RAIDCLUTTER_OPT_0"] = "0 (none, dev-only)"
L["GEMS_CVAR_RAIDING_RAIDCLUTTER_OPT_1"] = "1 (minimum, recommended)"
L["GEMS_CVAR_RAIDING_RAIDCLUTTER_OPT_2"] = "2 (reduced, default)"
L["GEMS_CVAR_RAIDING_RAIDCLUTTER_OPT_3"] = "3 (performance)"
L["GEMS_CVAR_RAIDING_RAIDCLUTTER_OPT_4"] = "4 (full)"
L["GEMS_CVAR_RAIDING_RAIDCLUTTER_DESCLONG"] =
    "Raid instances use this raid-specific mirror instead of the regular Spell Visual Density whenever raid-specific graphics settings are enabled -- which EMS recommends above. EMS recommends 1 for the same reason as the main setting: minimum spell clutter keeps boss mechanics and ground effects readable in packed fights. The Blizzard default for the raid mirror is 2, so without this row your raid nights quietly run at more clutter than your recommended everyday setting."

L["GEMS_CVAR_RAIDING_NOFILTER_DESCLONG"] =
    "Disables the default filtering of buffs and debuffs on the target frame (shows every buff/debuff regardless of source). Recommended off (0) by default -- the filter hides irrelevant buffs from the target frame which keeps it readable. Turn on (1) for tanks and theorycrafters who need full debuff visibility regardless of source."

L["GEMS_CVAR_RAIDING_MYSPELLS_DESCLONG"] =
    "Makes your own spell effects render more prominently than other players' effects on screen. Recommended on (1) -- you need to see whether your ground effect (Healing Rain, Death and Decay, Consecration) landed where you placed it, distinct from teammates' similar effects. Off (0) renders every player's spell effects at uniform intensity."

-- L372 G.3b ninth wave -- options + descLong for 2 string-enum cvars (raid frames health-text + sort mode)
L["GEMS_CVAR_RAIDING_HEALTHTEXT_OPT_NONE"] = "None"
L["GEMS_CVAR_RAIDING_HEALTHTEXT_OPT_PERC"] = "Percentage"
L["GEMS_CVAR_RAIDING_HEALTHTEXT_OPT_HEALTH"] = "Health value"
L["GEMS_CVAR_RAIDING_HEALTHTEXT_OPT_LOSTHEALTH"] = "Lost health"
L["GEMS_CVAR_RAIDING_HEALTHTEXT_DESCLONG"] =
    "Sets what text appears on raid frame health bars. None (the default) keeps bars clean and lets you focus on the bar fill alone. Percentage shows XX% which is the most readable at-a-glance health gauge. Health shows the raw health value (e.g. 347000 / 480000), useful for tanks tracking specific HP thresholds for defensive cooldowns. Lost health shows the missing-HP number (e.g. -133000), useful for healers matching incoming heal sizes to actual deficits."

L["GEMS_CVAR_RAIDING_SORTMODE_OPT_ROLE"] = "By role (tank / heal / DPS)"
L["GEMS_CVAR_RAIDING_SORTMODE_OPT_GROUP"] = "By group number"
L["GEMS_CVAR_RAIDING_SORTMODE_DESCLONG"] =
    "Sets the sort order for raid frames. Role (the default) groups tanks at the top, then healers, then DPS -- matches the priority-of-attention order most players want. Group keeps Group 1 / Group 2 / Group N groupings intact, useful for raid leaders who use group composition as tactical assignment."

L["GEMS_CVAR_FIX_ALL_BUSY"] = "GEMS: Fixing %d CVars..."
L["GEMS_CVAR_FIX_ALL_DONE"] = "GEMS: Fixed %d CVars."
L["GEMS_CVAR_FIX_ALL_DONE_PARTIAL"] = "GEMS: Fixed %d of %d CVars (%d pinned or combat-locked)."
L["GEMS_CVAR_RESET_DEFAULTS"] = "Reset All to Blizzard Defaults"
L["GEMS_CVAR_RESET_DEFAULTS_DESC"] =
    "Reset every recommended CVar to its Blizzard-shipped default. Pinned CVars and entries managed by the SQW Optimiser (Spell Queue Window) are skipped. Each row has an Undo button to revert it. Auto-fix-on-login opt-ins are also cleared -- re-toggle them after the reset if you want EMS to manage them again."
L["GEMS_CVAR_RESET_DEFAULTS_CONFIRM"] =
    "Reset %d CVars to their Blizzard defaults? Pinned CVars and entries managed by the SQW Optimiser (Spell Queue Window) are skipped. You can Undo each reverted CVar individually."
L["GEMS_CVAR_RESET_DEFAULTS_BUSY"] = "GEMS: Resetting %d CVars to Blizzard defaults..."
L["GEMS_CVAR_RESET_DEFAULTS_DONE"] = "GEMS: Reset %d CVars. Each row has Undo. Auto-fix-on-login opt-ins were cleared."
L["GEMS_CVAR_RESET_DEFAULTS_DONE_PARTIAL"] =
    "GEMS: Reset %d of %d CVars (%d pinned or combat-locked). Each row has Undo. Auto-fix-on-login opt-ins were cleared."
L["GEMS_CVAR_ONBOARDING_BODY"] =
    "EMS scans %d game settings (CVars) and shows you which ones match recommended values. Green dots are matched. Red are critical mismatches. Yellow are suboptimal.\n\nClick Fix on any row to apply the recommendation, or use the buttons up top to fix several at once. Pin My Choice tells EMS to leave a CVar alone, for when you want to keep your own value."

-- CVar Section Headers
L["GEMS_CVAR_SECTION_MACRO"] = "Macro Sequencing"
L["GEMS_CVAR_SECTION_COMBAT"] = "Combat & Targeting"
L["GEMS_CVAR_SECTION_NAMEPLATES"] = "Nameplates"
L["GEMS_CVAR_SECTION_RAIDING"] = "Raiding"
L["GEMS_CVAR_SECTION_DUNGEON"] = "Dungeons & M+"
L["GEMS_CVAR_SECTION_SOLO"] = "Solo Play & Open World"
L["GEMS_CVAR_SECTION_UI"] = "UI & Quality of Life"
L["GEMS_CVAR_SECTION_FPS"] = "FPS & Performance"
L["GEMS_CVAR_SECTION_VISUAL"] = "Visual Quality"
L["GEMS_CVAR_SECTION_SOUND"] = "Sound"
L["GEMS_CVAR_SECTION_FCT"] = "Floating Combat Text"
L["GEMS_CVAR_SECTION_ACCESS"] = "Accessibility"
L["GEMS_CVAR_SECTION_DRAGON"] = "Dragonriding & Advanced Flying"
L["GEMS_CVAR_SECTION_COMBATAUDIO"] = "Combat Audio"

-- CVar Section: Macro Sequencing
L["GEMS_CVAR_MACRO_KEYHELD"] = "Hold to Cast"
L["GEMS_CVAR_MACRO_KEYHELD_DESC"] =
    "Press-and-hold auto-repeats the ability. Only works on native Blizzard action buttons, not addon-created buttons. Hold Mode manages this setting for you when active. Preference-based -- no recommendation either way."
L["GEMS_CVAR_MACRO_SPELLQUEUE"] = "Spell Queue Window"
L["GEMS_CVAR_MACRO_SPELLQUEUE_DESC"] =
    "Milliseconds before GCD ends that the next spell can be queued. 400ms is optimal for most players."
L["GEMS_CVAR_MACRO_LOCKBARS"] = "Lock Action Bars"
L["GEMS_CVAR_MACRO_LOCKBARS_DESC"] = "Prevents accidental drag-off of macro stubs from action bars during combat."
L["GEMS_CVAR_MACRO_MULTIBARS"] = "Multi Action Bars"
L["GEMS_CVAR_MACRO_MULTIBARS_DESC"] =
    "Pick which extra action bars to enable (0=none, 15=all). More bars = more room for macro stubs."
L["GEMS_CVAR_MACRO_AUTOPUSH"] = "Auto Push Spells"
L["GEMS_CVAR_MACRO_AUTOPUSH_DESC"] =
    "Auto-places new spells on bars. Recommend OFF -- new spells from levelling push macro stubs off the bar."
L["GEMS_CVAR_MACRO_SELFCAST"] = "Auto Self Cast"
L["GEMS_CVAR_MACRO_SELFCAST_DESC"] =
    "Auto-cast beneficial spells on self when no valid target. Important for macro steps with self-heals."
L["GEMS_CVAR_MACRO_AUTOSTAND"] = "Auto Stand"
L["GEMS_CVAR_MACRO_AUTOSTAND_DESC"] =
    "Auto-stand when casting. Without this, macro sequences fail silently while sitting."
L["GEMS_CVAR_MACRO_AUTOUNSHIFT"] = "Auto Unshift"
L["GEMS_CVAR_MACRO_AUTOUNSHIFT_DESC"] =
    "Auto-leave shapeshift/stealth when casting incompatible spells. Without this, Druid/Rogue macro steps fail silently."
L["GEMS_CVAR_MACRO_STOPATTACK"] = "Stop Attack on Switch"
L["GEMS_CVAR_MACRO_STOPATTACK_DESC"] =
    "Keep auto-attacking when switching targets. If 1, target-switching mid-sequence stops melee auto-attacks."
L["GEMS_CVAR_MACRO_ICONRATE"] = "Icon Update Rate"
L["GEMS_CVAR_MACRO_ICONRATE_DESC"] =
    "How often action bar icons refresh (seconds). 0.05 = 20 updates/sec, smoother than default 0.1."
L["GEMS_CVAR_MACRO_CDCOUNT"] = "Cooldown Countdown"
L["GEMS_CVAR_MACRO_CDCOUNT_DESC"] =
    "Show numeric cooldown timers on action buttons. Critical for seeing exact remaining cooldown on the sequence button."
L["GEMS_CVAR_MACRO_SECTOGGLE"] = "Secure Ability Toggle"
L["GEMS_CVAR_MACRO_SECTOGGLE_DESC"] =
    "Prevents double-click toggling abilities off. Protects against rapid keypresses deactivating toggle abilities."
L["GEMS_CVAR_MACRO_EMPTAP"] = "Empower Tap Controls"
L["GEMS_CVAR_MACRO_EMPTAP_DESC"] =
    "Tap-tap vs hold-release for empowered spells. Hold-release works better with sequences."
L["GEMS_CVAR_MACRO_EMPHOLD"] = "Empower Hold Stage"
L["GEMS_CVAR_MACRO_EMPHOLD_DESC"] = "Percentage of first empower stage required before auto-release [0.0-1.0]."
L["GEMS_CVAR_MACRO_EMPTAPTHRESHOLD"] = "Empower Tap Release Delay"
L["GEMS_CVAR_MACRO_EMPTAPTHRESHOLD_DESC"] =
    "Milliseconds before a second tap can release an empowered cast. Needs Empower Tap Controls on."
L["GEMS_CVAR_MACRO_HELDPOLL"] = "Held Spell Poll Time"
L["GEMS_CVAR_MACRO_HELDPOLL_DESC"] =
    "Milliseconds between retry attempts when held-spell casting fails. Lower = faster retry, more responsive."
L["GEMS_CVAR_MACRO_PRECAST"] = "Preemptive Cast"
L["GEMS_CVAR_MACRO_PRECAST_DESC"] =
    "Show the cast animation slightly before the spell actually fires. Undocumented Blizzard feature."

-- CVar Section: Combat & Targeting
L["GEMS_CVAR_COMBAT_SOFTENEMY"] = "Soft Target Enemy"
L["GEMS_CVAR_COMBAT_SOFTENEMY_DESC"] =
    "When soft targeting activates for enemies. 0=off, 1=gamepad, 2=KBM, 3=always. Recommend 3 for auto-acquire."
L["GEMS_CVAR_COMBAT_SOFTARC"] = "Soft Target Arc"
L["GEMS_CVAR_COMBAT_SOFTARC_DESC"] =
    "Directional constraint for enemy soft target. 0=must face directly, 1=front arc, 2=anywhere."
L["GEMS_CVAR_COMBAT_SOFTRANGE"] = "Soft Target Range"
L["GEMS_CVAR_COMBAT_SOFTRANGE_DESC"] =
    "Max range for soft target enemy detection (yards). 45yd covers most ranged abilities."
L["GEMS_CVAR_COMBAT_SOFTFORCE"] = "Soft Target Force"
L["GEMS_CVAR_COMBAT_SOFTFORCE_DESC"] =
    "Lock onto the soft target automatically. Without this, soft targeting shows the target but spells fire at nothing."
L["GEMS_CVAR_COMBAT_SOFTFRIEND"] = "Soft Target Friend"
L["GEMS_CVAR_COMBAT_SOFTFRIEND_DESC"] =
    "Soft targeting for friendlies. 0=off. Healers may want 3 (always). DPS should leave at 0."
L["GEMS_CVAR_COMBAT_SOFTLOCKED"] = "Soft With Locked"
L["GEMS_CVAR_COMBAT_SOFTLOCKED_DESC"] =
    "Allow soft target while having a hard-locked target. 2=always allows soft target preview."
L["GEMS_CVAR_COMBAT_SOFTMATCH"] = "Soft Match Locked"
L["GEMS_CVAR_COMBAT_SOFTMATCH_DESC"] =
    "Match soft target to locked target. Keeps the soft target indicator synced with your actual target."
L["GEMS_CVAR_COMBAT_TABNEW"] = "New Tab Targeting"
L["GEMS_CVAR_COMBAT_TABNEW_DESC"] =
    "Use modern (7.2+) tab-targeting algorithm. Prioritises enemies in front of you and in combat."
L["GEMS_CVAR_COMBAT_COMBATLOCK"] = "Combat Target Lock"
L["GEMS_CVAR_COMBAT_COMBATLOCK_DESC"] =
    "Lock tab-target to in-combat enemies. Prevents jumping to distant mobs not yet pulled."
L["GEMS_CVAR_COMBAT_LOCKRELAX"] = "Lock Relaxation"
L["GEMS_CVAR_COMBAT_LOCKRELAX_DESC"] = "Smart relaxation of combat lock when no in-combat targets are available."
L["GEMS_CVAR_COMBAT_PVPPRIO"] = "PvP Target Priority"
L["GEMS_CVAR_COMBAT_PVPPRIO_DESC"] = "In PvP, prioritise players and important PvP targets. 1=players first."
L["GEMS_CVAR_COMBAT_ATTACKER"] = "Target Attacker"
L["GEMS_CVAR_COMBAT_ATTACKER_DESC"] = "Auto-target enemies that attack you. Essential for solo play where mobs aggro."
L["GEMS_CVAR_COMBAT_AUTOENEMY"] = "Auto Target Enemy"
L["GEMS_CVAR_COMBAT_AUTOENEMY_DESC"] =
    "Auto-target nearest enemy when casting offensive spells with no target. Ensures macros fire."
L["GEMS_CVAR_COMBAT_DESELECT"] = "Deselect on Click"
L["GEMS_CVAR_COMBAT_DESELECT_DESC"] =
    "Clear target when clicking terrain. If 1, clicking ground mid-fight drops your target."
L["GEMS_CVAR_COMBAT_LEFTCLICK"] = "Interact Left Click"
L["GEMS_CVAR_COMBAT_LEFTCLICK_DESC"] = "Left-click interacts with NPCs. Standard behaviour most players expect."
L["GEMS_CVAR_COMBAT_HIGHLIGHT"] = "Combat Highlight"
L["GEMS_CVAR_COMBAT_HIGHLIGHT_DESC"] =
    "Next-spell-to-cast highlight. Competes visually with sequence tracking. Recommend OFF."
L["GEMS_CVAR_COMBAT_PROCS"] = "Proc Overlays"
L["GEMS_CVAR_COMBAT_PROCS_DESC"] =
    "Show proc/spell alert overlays (glowing borders). Important for seeing procs that affect macro priority."
L["GEMS_CVAR_COMBAT_PROCOPACITY"] = "Proc Overlay Opacity"
L["GEMS_CVAR_COMBAT_PROCOPACITY_DESC"] =
    "Opacity of spell alert overlays. Default 0.65 is good. Increase to 0.8-1.0 if hard to see."
L["GEMS_CVAR_COMBAT_LOC"] = "Loss of Control"
L["GEMS_CVAR_COMBAT_LOC_DESC"] =
    "Show loss-of-control banner when stunned/silenced. Helps understand why a macro sequence appears stuck."
L["GEMS_CVAR_COMBAT_MOUSEOVER"] = "Mouseover Casting"
L["GEMS_CVAR_COMBAT_MOUSEOVER_DESC"] = "Cast on the unit under your cursor without changing target. Huge for healers."
L["GEMS_CVAR_COMBAT_FRIENDARC"] = "Friend Soft Arc"
L["GEMS_CVAR_COMBAT_FRIENDARC_DESC"] =
    "Directional limit for friendly soft target. Same idea as the enemy arc setting. Only matters if Soft Target Friend is on."
L["GEMS_CVAR_COMBAT_FRIENDRANGE"] = "Friend Soft Range"
L["GEMS_CVAR_COMBAT_FRIENDRANGE_DESC"] = "Max range for soft target friend detection. 45yd covers all healing spells."
-- CVar Section: Combat & Targeting -- Loss of Control per-type displays (3b)
L["GEMS_CVAR_COMBAT_LOCFULL"] = "Loss of Control: Full"
L["GEMS_CVAR_COMBAT_LOCFULL_DESC"] = "Banner display for full loss of control: stuns, fears, charms and sleeps."
L["GEMS_CVAR_COMBAT_LOCFULL_OPT_0"] = "Off"
L["GEMS_CVAR_COMBAT_LOCFULL_OPT_1"] = "Only Alert"
L["GEMS_CVAR_COMBAT_LOCFULL_OPT_2"] = "Show Full Duration"
L["GEMS_CVAR_COMBAT_LOCFULL_DESCLONG"] =
    "Controls the on-screen banner for effects that take control away completely, such as stuns, fears, charms and sleeps. Show Full Duration is the client default and what EMS recommends, because the banner keeps a countdown on screen for as long as the effect lasts. That countdown is the quickest way to tell whether a sequence stopped because a step failed or because you cannot act at all. Only Alert flashes the effect name once and fades, so you get the name but not the time left. Off hides it. The Loss of Control row above is the master switch for all five of these, so they do nothing while it is off. This setting is saved per character, so each alt keeps its own choice."
L["GEMS_CVAR_COMBAT_LOCSILENCE"] = "Loss of Control: Silence"
L["GEMS_CVAR_COMBAT_LOCSILENCE_DESC"] = "Banner display for silence effects that block spell casts."
L["GEMS_CVAR_COMBAT_LOCSILENCE_OPT_0"] = "Off"
L["GEMS_CVAR_COMBAT_LOCSILENCE_OPT_1"] = "Only Alert"
L["GEMS_CVAR_COMBAT_LOCSILENCE_OPT_2"] = "Show Full Duration"
L["GEMS_CVAR_COMBAT_LOCSILENCE_DESCLONG"] =
    "Controls the banner for silence effects, which block your spell casts but leave you free to move and use physical abilities. Show Full Duration is the client default and what EMS recommends. A silenced caster sequence looks the same as a broken one from the outside: nothing fires and the keybind seems dead. The countdown tells you it is a lockout and when it ends. Only Alert names the effect once and fades. Off hides it. Needs the Loss of Control master row above to be on. This setting is saved per character."
L["GEMS_CVAR_COMBAT_LOCINTERRUPT"] = "Loss of Control: Interrupt"
L["GEMS_CVAR_COMBAT_LOCINTERRUPT_DESC"] = "Banner display for school lockouts caused by an interrupt."
L["GEMS_CVAR_COMBAT_LOCINTERRUPT_OPT_0"] = "Off"
L["GEMS_CVAR_COMBAT_LOCINTERRUPT_OPT_1"] = "Only Alert"
L["GEMS_CVAR_COMBAT_LOCINTERRUPT_OPT_2"] = "Show Full Duration"
L["GEMS_CVAR_COMBAT_LOCINTERRUPT_DESCLONG"] =
    "Controls the banner for school lockouts from an interrupt, where one school of magic is locked and the rest still work. Show Full Duration is the client default and what EMS recommends, because the banner names the locked school and counts it down. Partial lockouts matter more to a sequence than the other types: some steps fire and others do not, so the sequence advances but skips, which reads as a priority bug rather than a lockout. Only Alert names the school once and fades. Off hides it. Needs the Loss of Control master row above to be on. This setting is saved per character."
L["GEMS_CVAR_COMBAT_LOCROOT"] = "Loss of Control: Root"
L["GEMS_CVAR_COMBAT_LOCROOT_DESC"] = "Banner display for root effects that stop movement."
L["GEMS_CVAR_COMBAT_LOCROOT_OPT_0"] = "Off"
L["GEMS_CVAR_COMBAT_LOCROOT_OPT_1"] = "Only Alert"
L["GEMS_CVAR_COMBAT_LOCROOT_OPT_2"] = "Show Full Duration"
L["GEMS_CVAR_COMBAT_LOCROOT_DESCLONG"] =
    "Controls the banner for root effects, which pin you in place while leaving your abilities available. Show Full Duration is the client default and what EMS recommends. Roots rarely stop a sequence outright, so the value here is the timer: it tells you how long until you can move again, which decides whether you hold a repositioning step or spend it now. Only Alert names the effect once and fades. Off hides it. Needs the Loss of Control master row above to be on. This setting is saved per character."
L["GEMS_CVAR_COMBAT_LOCDISARM"] = "Loss of Control: Disarm"
L["GEMS_CVAR_COMBAT_LOCDISARM_DESC"] = "Banner display for disarms that strip your weapon."
L["GEMS_CVAR_COMBAT_LOCDISARM_OPT_0"] = "Off"
L["GEMS_CVAR_COMBAT_LOCDISARM_OPT_1"] = "Only Alert"
L["GEMS_CVAR_COMBAT_LOCDISARM_OPT_2"] = "Show Full Duration"
L["GEMS_CVAR_COMBAT_LOCDISARM_DESCLONG"] =
    "Controls the banner for disarms, which strip your weapon and block anything that needs it. Show Full Duration is the client default and what EMS recommends. A disarm is the easiest of the five to misread, because casts keep working and only the weapon abilities fail, so a hybrid sequence half runs. The countdown tells you which half is blocked and for how long. Only Alert names the effect once and fades. Off hides it. Needs the Loss of Control master row above to be on. This setting is saved per character."
-- CVar Section: Combat & Targeting -- targeting and assist singles (3c)
L["GEMS_CVAR_COMBAT_AUTOFRIEND"] = "Auto Target Friend"
L["GEMS_CVAR_COMBAT_AUTOFRIEND_DESC"] =
    "Lets a helpful single-target spell pick its own friendly target. Friendly half of Auto Target Enemy."
L["GEMS_CVAR_COMBAT_AUTOFRIEND_DESCLONG"] =
    "When you cast a single-target helpful spell, the game can choose the friendly target for you instead of failing the cast for want of one. This is the friendly half of the pair whose enemy half is the Auto Target Enemy row above. On (1) is the client default and what EMS recommends, because a heal or dispel step inside a sequence does nothing at all with no target selected, and that is a whole global cooldown spent on nothing. Off (0) means every helpful cast waits for you to pick someone first. This setting is saved per character."
L["GEMS_CVAR_COMBAT_AUTOLOCK"] = "Lock Auto Targets"
L["GEMS_CVAR_COMBAT_AUTOLOCK_DESC"] =
    "Keeps a target the game picked for you instead of letting it change on its own. Off by default."
L["GEMS_CVAR_COMBAT_AUTOLOCK_DESCLONG"] =
    "When the game picks a target for you, this decides whether that pick sticks. Off (0) is the client default and what EMS recommends, because an auto-pick that stays locked can hold you on a unit after your aim has already moved, and a sequence keeps firing at whatever is still selected. On (1) suits players who want the game's choice to stay put until they clear it by hand. This setting is saved per character."
L["GEMS_CVAR_COMBAT_ASSISTATTACK"] = "Attack on Assist"
L["GEMS_CVAR_COMBAT_ASSISTATTACK_DESC"] = "Start auto-attacking after you assist someone. Off by default."
L["GEMS_CVAR_COMBAT_ASSISTATTACK_DESCLONG"] =
    "After you assist another player and inherit their target, this decides whether you also start swinging at it. Off (0) is the client default and what EMS recommends, because assisting is often just a way to see what the tank is holding, and swinging at it can pull something you did not mean to touch. On (1) saves a step for melee players who assist as their normal way of picking up a target. This setting is saved per character."
L["GEMS_CVAR_COMBAT_CAMFOLLOWCOMBAT"] = "Follow Target In Combat Only"
L["GEMS_CVAR_COMBAT_CAMFOLLOWCOMBAT_DESC"] = "Limits the camera's follow-the-target behaviour to combat. On by default."
L["GEMS_CVAR_COMBAT_CAMFOLLOWCOMBAT_DESCLONG"] =
    "The client can swing the camera to keep your locked target in view. This row decides whether it only does that while you are in combat. On (1) is the client default and what EMS recommends, because camera movement you did not ask for is much less welcome while you are travelling or parked in a city than it is mid-pull. Off (0) lifts the combat restriction. The follow behaviour itself lives in the client's camera code rather than in the settings panel, so if you notice no difference either way, camera follow is not running for you to begin with. This setting is saved account-wide, so it persists across sessions once you set it."
L["GEMS_CVAR_COMBAT_REDUCEHIGHLIGHTS"] = "Reduce Assistant Highlights"
L["GEMS_CVAR_COMBAT_REDUCEHIGHLIGHTS_DESC"] =
    "Dims proc alert art on rotation spells while a one-button assistant sits on a bar. EMS turns this off."
L["GEMS_CVAR_COMBAT_REDUCEHIGHLIGHTS_DESCLONG"] =
    "With a one-button assistant on an action bar, the client dims the proc alert art on the spells that assistant would recommend. On (1) is the client default. EMS recommends off (0), because the Proc Overlays and Proc Overlay Opacity rows above exist to make those flashes readable and this setting takes them back for exactly the spells you are most likely to be watching. It only changes anything while the Combat Highlight row above is off and you have an assistant button on a bar; with Combat Highlight on, the client dims that art no matter what you set here. This setting is saved per character."

-- CVar Section: Nameplates
L["GEMS_CVAR_NAMEPLATES_SHOWALL"] = "Show All Nameplates"
L["GEMS_CVAR_NAMEPLATES_SHOWALL_DESC"] =
    "Show ALL nameplates (enemies, friendly NPCs, pets). Master toggle. Most combat players want this on."
L["GEMS_CVAR_NAMEPLATES_SHOWENEMY"] = "Show Enemy Nameplates"
L["GEMS_CVAR_NAMEPLATES_SHOWENEMY_DESC"] = "Show enemy nameplates. Must be on for any combat awareness."
L["GEMS_CVAR_NAMEPLATES_SHOWSELF"] = "Show Self Nameplate"
L["GEMS_CVAR_NAMEPLATES_SHOWSELF_DESC"] =
    "Show personal resource display (health/mana bar under your character). Many players don't know this exists."
L["GEMS_CVAR_NAMEPLATES_MAXDIST"] = "Max Distance"
L["GEMS_CVAR_NAMEPLATES_MAXDIST_DESC"] =
    "Max nameplate render distance. 60yd is the cap and default. Lower values save GPU but lose awareness."
L["GEMS_CVAR_NAMEPLATES_PLAYERDIST"] = "Player Max Distance"
L["GEMS_CVAR_NAMEPLATES_PLAYERDIST_DESC"] =
    "Max distance for player nameplates specifically. Keep equal to nameplateMaxDistance."
L["GEMS_CVAR_NAMEPLATES_MINALPHA"] = "Min Opacity"
L["GEMS_CVAR_NAMEPLATES_MINALPHA_DESC"] =
    "Minimum opacity for distant nameplates. Default 0.6 makes far nameplates hard to see. 0.8 is better."
L["GEMS_CVAR_NAMEPLATES_MAXALPHA"] = "Max Opacity"
L["GEMS_CVAR_NAMEPLATES_MAXALPHA_DESC"] =
    "Maximum opacity for nearby nameplates. 1.0 = fully opaque. No reason to lower."
L["GEMS_CVAR_NAMEPLATES_MINSCALE"] = "Min Scale"
L["GEMS_CVAR_NAMEPLATES_MINSCALE_DESC"] =
    "Minimum scale for distant nameplates. Lower values make far nameplates too small to read."
L["GEMS_CVAR_NAMEPLATES_MAXSCALE"] = "Max Scale"
L["GEMS_CVAR_NAMEPLATES_MAXSCALE_DESC"] = "Maximum scale for nearby nameplates."
L["GEMS_CVAR_NAMEPLATES_SELSCALE"] = "Selected Scale"
L["GEMS_CVAR_NAMEPLATES_SELSCALE_DESC"] =
    "Scale multiplier for your current target's nameplate. Default 1.2 makes the target visually distinct."
L["GEMS_CVAR_NAMEPLATES_OCCLUDED"] = "Occluded Opacity"
L["GEMS_CVAR_NAMEPLATES_OCCLUDED_DESC"] =
    "Opacity for nameplates behind walls/objects. Default 0.4 is nearly invisible. 0.6 keeps them readable."
L["GEMS_CVAR_NAMEPLATES_OVERLAPH"] = "Horizontal Overlap"
L["GEMS_CVAR_NAMEPLATES_OVERLAPH_DESC"] =
    "Horizontal stacking overlap. Lower = more spread. 0.8 is the default stacking behaviour."
L["GEMS_CVAR_NAMEPLATES_OVERLAPV"] = "Vertical Overlap"
L["GEMS_CVAR_NAMEPLATES_OVERLAPV_DESC"] =
    "Vertical stacking overlap. Controls how nameplates stack vertically in AoE packs."
L["GEMS_CVAR_NAMEPLATES_CASTBARS"] = "Nameplate Cast Bars"
L["GEMS_CVAR_NAMEPLATES_CASTBARS_DESC"] = "Show cast bars on nameplates. Essential for interrupting."
L["GEMS_CVAR_NAMEPLATES_CLASSCOLOR"] = "Class Colour Bars"
L["GEMS_CVAR_NAMEPLATES_CLASSCOLOR_DESC"] =
    "Colour enemy nameplate health bars by class. Important for PvP target identification."
L["GEMS_CVAR_NAMEPLATES_DEBUFFS"] = "Friendly Debuffs"
L["GEMS_CVAR_NAMEPLATES_DEBUFFS_DESC"] = "Show debuffs on friendly nameplates. Useful for healers and dispellers."
L["GEMS_CVAR_NAMEPLATES_MINIONS"] = "Enemy Minions"
L["GEMS_CVAR_NAMEPLATES_MINIONS_DESC"] =
    "Show minion nameplates. Off by default to reduce clutter. Enable in M+ if minion health matters."
L["GEMS_CVAR_NAMEPLATES_MINUS"] = "Trivial Enemies"
L["GEMS_CVAR_NAMEPLATES_MINUS_DESC"] =
    "Show nameplates for trivial (minus) enemies. Useful in open world for seeing all mobs."
L["GEMS_CVAR_NAMEPLATES_TOTEMS"] = "Enemy Totems"
L["GEMS_CVAR_NAMEPLATES_TOTEMS_DESC"] = "Show enemy totem nameplates. Important in PvP -- totems are kill targets."
L["GEMS_CVAR_NAMEPLATES_FRIENDLY"] = "Friendly Players"
L["GEMS_CVAR_NAMEPLATES_FRIENDLY_DESC"] =
    "Show friendly player nameplates. Off in PvE to reduce clutter. On in PvP for awareness."
L["GEMS_CVAR_NAMEPLATES_AURASCALE"] = "Aura Icon Scale"
L["GEMS_CVAR_NAMEPLATES_AURASCALE_DESC"] =
    "Scale multiplier for buff/debuff icons on nameplates. 1.2 makes DoT tracking easier at a glance."
L["GEMS_CVAR_NAMEPLATES_NAMEONLY"] = "Name Only Friendly"
L["GEMS_CVAR_NAMEPLATES_NAMEONLY_DESC"] =
    "Strip friendly nameplates to name-only (no health bar). Reduces visual noise in raids."
L["GEMS_CVAR_NAMEPLATES_ATBASE"] = "Position at Base"
L["GEMS_CVAR_NAMEPLATES_ATBASE_DESC"] =
    "Position non-target nameplates at base of character instead of overhead. 0=overhead (standard)."
L["GEMS_CVAR_NAMEPLATES_OFFSCREEN"] = "Show Offscreen"
L["GEMS_CVAR_NAMEPLATES_OFFSCREEN_DESC"] = "Show nameplates for off-screen targets. Can be useful but also cluttery."
L["GEMS_CVAR_NAMEPLATES_RADIAL"] = "Radial Position"
L["GEMS_CVAR_NAMEPLATES_RADIAL_DESC"] = "Show target nameplate radially around screen edge when off-screen. 0=off."
L["GEMS_CVAR_NAMEPLATES_SOFTNP"] = "Soft Target Nameplate"
L["GEMS_CVAR_NAMEPLATES_SOFTNP_DESC"] = "Always show nameplate for soft-targeted enemy."
L["GEMS_CVAR_NAMEPLATES_SOFTSIZE"] = "Soft Target Size"
L["GEMS_CVAR_NAMEPLATES_SOFTSIZE_DESC"] =
    "Size of the soft target indicator on nameplates. Default 19 can be hard to see. 25 is better."
L["GEMS_CVAR_NAMEPLATES_DEBUFFPAD"] = "Debuff Padding"
L["GEMS_CVAR_NAMEPLATES_DEBUFFPAD_DESC"] = "Padding between debuff list and health bar. 0 = compact."
L["GEMS_CVAR_NAMEPLATES_STACKING"] = "Nameplate Stacking"
L["GEMS_CVAR_NAMEPLATES_STACKING_DESC"] = "Which nameplates stack apart instead of overlapping."
L["GEMS_CVAR_NAMEPLATES_THREATDISP"] = "Threat Display"
L["GEMS_CVAR_NAMEPLATES_THREATDISP_DESC"] = "How threat is shown on enemy nameplates."
L["GEMS_CVAR_NAMEPLATES_INFODISP"] = "Nameplate Info"
L["GEMS_CVAR_NAMEPLATES_INFODISP_DESC"] = "Extra info shown on nameplates."
L["GEMS_CVAR_NAMEPLATES_CASTBARDISP"] = "Cast Bar Info"
L["GEMS_CVAR_NAMEPLATES_CASTBARDISP_DESC"] = "What nameplate cast bars show."
L["GEMS_CVAR_NAMEPLATES_AURAENEMYPLAYER"] = "Enemy Player Auras"
L["GEMS_CVAR_NAMEPLATES_AURAENEMYPLAYER_DESC"] = "Buffs, debuffs, and loss of control on enemy player nameplates."
L["GEMS_CVAR_NAMEPLATES_AURAENEMYNPC"] = "Enemy NPC Auras"
L["GEMS_CVAR_NAMEPLATES_AURAENEMYNPC_DESC"] = "Buffs, debuffs, and crowd control on enemy NPC nameplates."
L["GEMS_CVAR_NAMEPLATES_AURAFRIENDPLAYER"] = "Friendly Player Auras"
L["GEMS_CVAR_NAMEPLATES_AURAFRIENDPLAYER_DESC"] = "Buffs, debuffs, and loss of control on friendly player nameplates."

-- CVar Section: Raiding
L["GEMS_CVAR_RAIDING_COMBATLOG"] = "Advanced Combat Logging"
L["GEMS_CVAR_RAIDING_COMBATLOG_DESC"] =
    "Enable advanced combat logging (extra event data). Required for accurate Warcraft Logs uploads."
L["GEMS_CVAR_RAIDING_THREATWARN"] = "Threat Warning"
L["GEMS_CVAR_RAIDING_THREATWARN_DESC"] = "Threat warning display. 0=off, 1=dungeons, 2=party, 3=always."
L["GEMS_CVAR_RAIDING_THREATNUM"] = "Numeric Threat"
L["GEMS_CVAR_RAIDING_THREATNUM_DESC"] =
    "Show numeric threat values on target/focus frames. Useful for tanks and threat-conscious DPS."
L["GEMS_CVAR_RAIDING_THREATSOUND"] = "Threat Sounds"
L["GEMS_CVAR_RAIDING_THREATSOUND_DESC"] = "Play sounds on threat transitions (aggro gain/loss)."
L["GEMS_CVAR_RAIDING_THREATTEXT"] = "Threat World Text"
L["GEMS_CVAR_RAIDING_THREATTEXT_DESC"] = "Show threat floaters in combat (the aggro text)."
L["GEMS_CVAR_RAIDING_TIMELINE"] = "Encounter Timeline"
L["GEMS_CVAR_RAIDING_TIMELINE_DESC"] = "Enable the boss encounter timeline. Shows upcoming boss abilities."
L["GEMS_CVAR_RAIDING_TIMEROLE"] = "Timeline Role Filter"
L["GEMS_CVAR_RAIDING_TIMEROLE_DESC"] =
    "Hide encounter timeline events irrelevant to your role. Reduces noise for DPS/healers."
L["GEMS_CVAR_RAIDING_WARNINGS"] = "Encounter Warnings"
L["GEMS_CVAR_RAIDING_WARNINGS_DESC"] = "Show encounter warning messages (boss ability alerts)."
L["GEMS_CVAR_RAIDING_WARNHIDE"] = "Hide Non-Target Warns"
L["GEMS_CVAR_RAIDING_WARNHIDE_DESC"] =
    "Hide boss warnings not targeting you. 0=show all (safer). 1=less noise for experienced raiders."
L["GEMS_CVAR_RAIDING_AGGRO"] = "Aggro Highlight"
L["GEMS_CVAR_RAIDING_AGGRO_DESC"] = "Highlight raid frames when that player has aggro."
L["GEMS_CVAR_RAIDING_RDEBUFFS"] = "Raid Frame Debuffs"
L["GEMS_CVAR_RAIDING_RDEBUFFS_DESC"] = "Show debuffs on raid frames. Essential for healers and dispellers."
L["GEMS_CVAR_RAIDING_HEALPRED"] = "Incoming Heals"
L["GEMS_CVAR_RAIDING_HEALPRED_DESC"] = "Show incoming heal predictions on raid frames."
L["GEMS_CVAR_RAIDING_POWERBARS"] = "Raid Power Bars"
L["GEMS_CVAR_RAIDING_POWERBARS_DESC"] = "Show mana/rage/energy bars on raid frames. Off by default to save space."
L["GEMS_CVAR_RAIDING_RCLASSCOLOR"] = "Raid Class Colours"
L["GEMS_CVAR_RAIDING_RCLASSCOLOR_DESC"] =
    "Colour raid frame health bars by class. Makes it easier to identify players at a glance."
L["GEMS_CVAR_RAIDING_DISPONLY"] = "Dispellable Only"
L["GEMS_CVAR_RAIDING_DISPONLY_DESC"] = "Filter to only show debuffs you can dispel. 0=show all."
L["GEMS_CVAR_RAIDING_ROLEDEBUFF"] = "Role Debuff Size"
L["GEMS_CVAR_RAIDING_ROLEDEBUFF_DESC"] =
    "Show role-relevant debuffs at a larger size. Tanks see tank debuffs bigger, healers see healer debuffs bigger."
L["GEMS_CVAR_RAIDING_BIGDEF"] = "Centre Big Defensives"
L["GEMS_CVAR_RAIDING_BIGDEF_DESC"] =
    "Show big defensive cooldowns (Ironbark, Pain Suppression) centred on the raid frame."
L["GEMS_CVAR_RAIDING_DISPTYPE"] = "Dispel Indicator"
L["GEMS_CVAR_RAIDING_DISPTYPE_DESC"] = "Dispel indicator style. 0=none, 1=icon, 2=icon+highlight."
L["GEMS_CVAR_RAIDING_HEALTHTEXT"] = "Health Text Mode"
L["GEMS_CVAR_RAIDING_HEALTHTEXT_DESC"] =
    "Health text display mode. none, health, losthealth, or perc. Preference-based."
L["GEMS_CVAR_RAIDING_SORTMODE"] = "Raid Sort Mode"
L["GEMS_CVAR_RAIDING_SORTMODE_DESC"] = "Raid frame sort mode. role (tanks/healers/DPS) or group."
L["GEMS_CVAR_RAIDING_KEEPGRP"] = "Keep Groups Together"
L["GEMS_CVAR_RAIDING_KEEPGRP_DESC"] = "Keep raid groups visually separated. 0=intermix, 1=group blocks."
L["GEMS_CVAR_RAIDING_TANKASSIST"] = "Tank and Assist"
L["GEMS_CVAR_RAIDING_TANKASSIST_DESC"] = "Show main tank and main assist units in raid frames."
L["GEMS_CVAR_RAIDING_FINDSELF"] = "Find Yourself"
L["GEMS_CVAR_RAIDING_FINDSELF_DESC"] = "Highlight your own character in raid frames."
L["GEMS_CVAR_RAIDING_CASTBUFFS"] = "Castable Buffs"
L["GEMS_CVAR_RAIDING_CASTBUFFS_DESC"] = "Show only buffs you can cast (raid only). 0=show all."
L["GEMS_CVAR_RAIDING_DISPDEBUFFS"] = "Show Dispel Debuffs"
L["GEMS_CVAR_RAIDING_DISPDEBUFFS_DESC"] = "Show only debuffs you can dispel (raid only)."
L["GEMS_CVAR_RAIDING_RAIDSETTINGS"] = "Raid Graphics Settings"
L["GEMS_CVAR_RAIDING_RAIDSETTINGS_DESC"] =
    "Enable separate graphics settings for raids. Biggest single raid FPS improvement. Many players miss this."
L["GEMS_CVAR_RAIDING_RAIDCLUTTER"] = "Raid Spell Density"
L["GEMS_CVAR_RAIDING_RAIDCLUTTER_DESC"] =
    "Spell visual density used inside raid instances while raid-specific settings are on."
L["GEMS_CVAR_RAIDING_NOFILTER"] = "No Buff/Debuff Filter"
L["GEMS_CVAR_RAIDING_NOFILTER_DESC"] =
    "Disable ALL buff/debuff filtering on target frame. 0=normal filtering. 1=see everything."
L["GEMS_CVAR_RAIDING_MYSPELLS"] = "Emphasise My Spells"
L["GEMS_CVAR_RAIDING_MYSPELLS_DESC"] =
    "Tone down other players' spell effects while keeping yours at full. Essential in 20-man raids."
L["GEMS_CVAR_RAIDING_COMBATWARN"] = "Combat Warnings"
L["GEMS_CVAR_RAIDING_COMBATWARN_DESC"] = "Master toggle for combat warning UI (boss timeline + warnings)."
-- CVar Section: Raiding -- encounter timeline queued countdowns (3e)
L["GEMS_CVAR_RAIDING_HIDEQUEUED"] = "Hide Queued Countdowns"
L["GEMS_CVAR_RAIDING_HIDEQUEUED_DESC"] = "Hides queued countdowns from the encounter timeline. Off by default."

-- CVar Section: Dungeons & M+
L["GEMS_CVAR_DUNGEON_DPSRESET"] = "DPS Meter Reset"
L["GEMS_CVAR_DUNGEON_DPSRESET_DESC"] =
    "Auto-reset damage meter on new instance entry. Clean data per dungeon without manual reset."
L["GEMS_CVAR_DUNGEON_ENTRANCE"] = "Dungeon Entrances"
L["GEMS_CVAR_DUNGEON_ENTRANCE_DESC"] = "Show dungeon entrance icons on the world map."
L["GEMS_CVAR_DUNGEON_CLUTTER"] = "Unit Clutter Filter"
L["GEMS_CVAR_DUNGEON_CLUTTER_DESC"] = "Limit unit clutter (NPC stacking reduction) to instances only."
L["GEMS_CVAR_DUNGEON_ENEMYCAST"] = "Enemy Cast Bars"
L["GEMS_CVAR_DUNGEON_ENEMYCAST_DESC"] = "Show enemy cast bars on arena frames. Also affects M+ party awareness."
L["GEMS_CVAR_DUNGEON_LOGTIME"] = "Log Retention Time"
L["GEMS_CVAR_DUNGEON_LOGTIME_DESC"] =
    "Seconds to keep combat log entries. 300s default. Increase to 600 for long M+ pulls."
L["GEMS_CVAR_DUNGEON_LOGFILE"] = "Unique Log Filenames"
L["GEMS_CVAR_DUNGEON_LOGFILE_DESC"] = "Use timestamped combat log filenames. Prevents overwriting previous logs."
L["GEMS_CVAR_DUNGEON_DIMINISH"] = "CC Diminishing Returns"
L["GEMS_CVAR_DUNGEON_DIMINISH_DESC"] = "Show crowd control diminishing returns on enemy frames."

-- CVar Section: Solo Play & Open World
L["GEMS_CVAR_SOLO_AUTOLOOT"] = "Auto Loot"
L["GEMS_CVAR_SOLO_AUTOLOOT_DESC"] =
    "Auto-loot items. Default OFF means clicking each item individually. Almost every player wants this ON."
L["GEMS_CVAR_SOLO_LOOTRATE"] = "Loot Speed"
L["GEMS_CVAR_SOLO_LOOTRATE_DESC"] =
    "Milliseconds between auto-loot ticks. Default 150ms feels sluggish. 50ms loots almost instantly."
L["GEMS_CVAR_SOLO_LOOTMOUSE"] = "Loot at Cursor"
L["GEMS_CVAR_SOLO_LOOTMOUSE_DESC"] = "Open loot window at mouse cursor. Saves mouse travel."
L["GEMS_CVAR_SOLO_AELOOT"] = "AoE Looting"
L["GEMS_CVAR_SOLO_AELOOT_DESC"] =
    "Disable area-of-effect looting. 0=AoE loot enabled (loot all nearby corpses at once)."
L["GEMS_CVAR_SOLO_DISMOUNT"] = "Auto Dismount"
L["GEMS_CVAR_SOLO_DISMOUNT_DESC"] = "Auto-dismount when casting."
L["GEMS_CVAR_SOLO_DISMOUNTFLY"] = "Dismount While Flying"
L["GEMS_CVAR_SOLO_DISMOUNTFLY_DESC"] = "Auto-dismount while flying (you will fall). Default OFF is sane."
L["GEMS_CVAR_SOLO_TOT"] = "Target of Target"
L["GEMS_CVAR_SOLO_TOT_DESC"] = "Show target-of-target frame. Essential for tanks (see what the boss targets) and DPS."
L["GEMS_CVAR_SOLO_TCASTBAR"] = "Target Cast Bar"
L["GEMS_CVAR_SOLO_TCASTBAR_DESC"] = "Show your target's cast bar. Essential for interrupting."
L["GEMS_CVAR_SOLO_QUESTWATCH"] = "Auto Quest Watch"
L["GEMS_CVAR_SOLO_QUESTWATCH_DESC"] = "Auto-track quests in the objective tracker when obtained."
L["GEMS_CVAR_SOLO_QUESTPOI"] = "Quest POI on Map"
L["GEMS_CVAR_SOLO_QUESTPOI_DESC"] = "Show quest points of interest on the world map."
L["GEMS_CVAR_SOLO_PARTYPETS"] = "Show Party Pets"
L["GEMS_CVAR_SOLO_PARTYPETS_DESC"] = "Show pet frames in party UI. Off by default to save screen space."
L["GEMS_CVAR_SOLO_INTERACT"] = "Soft Interact"
L["GEMS_CVAR_SOLO_INTERACT_DESC"] =
    "Soft targeting for interactive objects. 0=off, 1=gamepad, 3=always. Big quality-of-life win for questing."
L["GEMS_CVAR_SOLO_INTERARC"] = "Interact Arc"
L["GEMS_CVAR_SOLO_INTERARC_DESC"] =
    "Directional constraint for interact soft target. 0=must face directly, 1=front arc, 2=anywhere."
L["GEMS_CVAR_SOLO_INTERRANGE"] = "Interact Range"
L["GEMS_CVAR_SOLO_INTERRANGE_DESC"] = "Max range for soft interact detection (yards). 10 is the default and cap."
L["GEMS_CVAR_SOLO_INTERICON"] = "Interact Icon"
L["GEMS_CVAR_SOLO_INTERICON_DESC"] = "Show icon indicator for soft interact targets. Keep on for visual feedback."
L["GEMS_CVAR_SOLO_AUTOINTER"] = "Auto Move to Interact"
L["GEMS_CVAR_SOLO_AUTOINTER_DESC"] = "Auto-move to interact target. Can be disorienting in combat areas."
L["GEMS_CVAR_SOLO_QUESTITEMS"] = "Quest Item Interact"
L["GEMS_CVAR_SOLO_QUESTITEMS_DESC"] =
    "Allow quest item use as an interaction. Lets you use quest items straight from the soft-interact key."
L["GEMS_CVAR_SOLO_QUESTITEMS_DESCLONG"] =
    "Enables quest items to participate in soft-target interaction. Recommended on (1) -- quest items become eligible for soft-target highlighting and interaction alongside NPCs and objects, which matches how the rest of the modern open-world interaction system works. Off (0) excludes quest items from the soft-target system; you click them manually like in older expansions."
-- CVar Section: Solo Play & Open World -- quest tracker updates (3e)
L["GEMS_CVAR_SOLO_QUESTPROGRESS"] = "Auto Watch Updated Quests"
L["GEMS_CVAR_SOLO_QUESTPROGRESS_DESC"] = "Adds quests to the tracker when their progress changes. On by default."

-- CVar Section: UI & Quality of Life
L["GEMS_CVAR_UI_TUTORIALS"] = "Tutorial Popups"
L["GEMS_CVAR_UI_TUTORIALS_DESC"] =
    "Display tutorial popups. Experienced players should disable -- tutorials interrupt gameplay."
L["GEMS_CVAR_UI_NPE"] = "New Player Tutorials"
L["GEMS_CVAR_UI_NPE_DESC"] = "Display New Player Experience tutorials. Disable for experienced players."
L["GEMS_CVAR_UI_LOADTIPS"] = "Loading Screen Tips"
L["GEMS_CVAR_UI_LOADTIPS_DESC"] = "Show tips on loading screens. Low-cost, occasionally useful."
L["GEMS_CVAR_UI_COMPARE"] = "Compare Items"
L["GEMS_CVAR_UI_COMPARE_DESC"] = "Always show item comparison tooltips when hovering gear."
L["GEMS_CVAR_UI_TOOLTIPS"] = "Detailed Tooltips"
L["GEMS_CVAR_UI_TOOLTIPS_DESC"] = "Show verbose/detailed tooltips with stats."
L["GEMS_CVAR_UI_TRANSMOG"] = "Missing Transmog Source"
L["GEMS_CVAR_UI_TRANSMOG_DESC"] = "Show if you are missing a transmog appearance source. Hidden gem for collectors."
L["GEMS_CVAR_UI_SSFORMAT"] = "Screenshot Format"
L["GEMS_CVAR_UI_SSFORMAT_DESC"] = "Screenshot file format. TGA is lossless, JPEG saves disk space but looks worse."
L["GEMS_CVAR_UI_SSQUALITY"] = "Screenshot Quality"
L["GEMS_CVAR_UI_SSQUALITY_DESC"] = "JPEG quality (1-10). Default 3 is very low. If using JPEG, use 10."
L["GEMS_CVAR_UI_ZOOM"] = "Camera Zoom Distance"
L["GEMS_CVAR_UI_ZOOM_DESC"] =
    "Max camera zoom-out multiplier. Default 1.9 feels close. 2.6 gives more battlefield awareness."
L["GEMS_CVAR_UI_EDGEFLASH"] = "Screen Edge Flash"
L["GEMS_CVAR_UI_EDGEFLASH_DESC"] = "Red flash at screen edges while in combat with map open. Safety reminder."
L["GEMS_CVAR_UI_BUBBLES"] = "Chat Bubbles"
L["GEMS_CVAR_UI_BUBBLES_DESC"] = "Show in-game speech bubbles."
L["GEMS_CVAR_UI_BIGNUMS"] = "Break Up Numbers"
L["GEMS_CVAR_UI_BIGNUMS_DESC"] = "Use commas in large numbers (1,000,000 vs 1000000)."
L["GEMS_CVAR_UI_BUFFDUR"] = "Buff Durations"
L["GEMS_CVAR_UI_BUFFDUR_DESC"] = "Show remaining duration on buff icons."
L["GEMS_CVAR_UI_COMBOPT"] = "Combo Point Location"
L["GEMS_CVAR_UI_COMBOPT_DESC"] = "Combo point display. 1=on target frame, 2=on self (below personal resource display)."
L["GEMS_CVAR_UI_FSTACK"] = "Frame Stack Debug"
L["GEMS_CVAR_UI_FSTACK_DESC"] =
    "Enable frame stack tooltip (developer tool). Shows frame names on hover. Useful for debugging."
L["GEMS_CVAR_UI_RAWMOUSE"] = "Raw Mouse Input"
L["GEMS_CVAR_UI_RAWMOUSE_DESC"] = "Raw mouse input mode. Broken since 2024 patches -- leaving this on does nothing."
L["GEMS_CVAR_UI_TAINT"] = "Taint Log"
L["GEMS_CVAR_UI_TAINT_DESC"] =
    "Taint debugging log. 0=off, 1=log to file, 2=log+chat. Addon developers set to 1 for debugging."
L["GEMS_CVAR_UI_BAGS"] = "Combined Bags"
L["GEMS_CVAR_UI_BAGS_DESC"] =
    "Display all bags as one combined inventory view. Added in Dragonflight. Much cleaner management."
L["GEMS_CVAR_UI_ROTATEMM"] = "Rotate Minimap"
L["GEMS_CVAR_UI_ROTATEMM_DESC"] =
    "Rotate minimap to match player facing direction instead of fixed north-up. Preference-based."
-- CVar Section: UI & Quality of Life -- status text, cast bar and chat bubble children (3d)
L["GEMS_CVAR_UI_STATUSTEXT"] = "Status Bar Text"
L["GEMS_CVAR_UI_STATUSTEXT_DESC"] = "Shows health and power as text on unit frames. Off by default."
L["GEMS_CVAR_UI_STATUSTEXTMODE"] = "Status Bar Text Format"
L["GEMS_CVAR_UI_STATUSTEXTMODE_DESC"] = "Raw values, percentage, or both. Needs Status Bar Text on."
L["GEMS_CVAR_UI_STATUSTEXTMODE_OPT_NUMERIC"] = "Numeric Value"
L["GEMS_CVAR_UI_STATUSTEXTMODE_OPT_PERCENT"] = "Percentage"
L["GEMS_CVAR_UI_STATUSTEXTMODE_OPT_BOTH"] = "Both"
L["GEMS_CVAR_UI_STATUSTEXTMODE_OPT_NONE"] = "None"
L["GEMS_CVAR_UI_VKEYCASTBAR"] = "Enemy Cast Bar"
L["GEMS_CVAR_UI_VKEYCASTBAR_DESC"] = "Adds the enemy cast bar to the V key target display. On by default."
L["GEMS_CVAR_UI_VKEYSPELLNAME"] = "Cast Bar Spell Name"
L["GEMS_CVAR_UI_VKEYSPELLNAME_DESC"] = "Puts the spell name on the V key cast bar. On by default."
L["GEMS_CVAR_UI_VKEYONLYTARGET"] = "Cast Bar On Target Only"
L["GEMS_CVAR_UI_VKEYONLYTARGET_DESC"] = "Limits the V key cast bar to your current target. Off by default."
L["GEMS_CVAR_UI_BUBBLESRAID"] = "Raid Chat Bubbles"
L["GEMS_CVAR_UI_BUBBLESRAID_DESC"] = "Speech bubbles for raid chat. Off by default. Needs Chat Bubbles on."
L["GEMS_CVAR_UI_BUBBLESPARTY"] = "Party Chat Bubbles"
L["GEMS_CVAR_UI_BUBBLESPARTY_DESC"] = "Speech bubbles for party chat. On by default. Needs Chat Bubbles on."
-- CVar Section: UI & Quality of Life -- cooldown viewer, minimap, ping and mouse singles (3e)
L["GEMS_CVAR_UI_CDVIEWER"] = "Cooldown Viewer"
L["GEMS_CVAR_UI_CDVIEWER_DESC"] = "The client's own cooldown tracking bar. Off by default."
L["GEMS_CVAR_UI_MMCLOSEST"] = "Closest Tracked Icon Only"
L["GEMS_CVAR_UI_MMCLOSEST_DESC"] = "Shows only the nearest tracked minimap icon per type. On by default."
L["GEMS_CVAR_UI_PINGMODE"] = "Ping Mode"
L["GEMS_CVAR_UI_PINGMODE_DESC"] = "How the ping key behaves. Quick Ping by default. Needs pings on."
L["GEMS_CVAR_UI_PINGMODE_OPT_0"] = "Quick Ping"
L["GEMS_CVAR_UI_PINGMODE_OPT_1"] = "Relaxed Ping"
L["GEMS_CVAR_UI_MOUSESPEEDON"] = "Custom Mouse Sensitivity"
L["GEMS_CVAR_UI_MOUSESPEEDON_DESC"] = "Lets the game override your system mouse sensitivity. Off by default."
L["GEMS_CVAR_UI_MOUSESPEED"] = "Mouse Sensitivity"
L["GEMS_CVAR_UI_MOUSESPEED_DESC"] = "Sensitivity multiplier, 0.5 to 1.4. Needs Custom Mouse Sensitivity on."

-- CVar Section: FPS & Performance
L["GEMS_CVAR_FPS_MAXFPS"] = "Max FPS"
L["GEMS_CVAR_FPS_MAXFPS_DESC"] = "FPS cap. Should match your monitor's refresh rate. Going higher wastes GPU."
L["GEMS_CVAR_FPS_BGFPS"] = "Background FPS"
L["GEMS_CVAR_FPS_BGFPS_DESC"] =
    "Background FPS cap (game not focused). 30 saves power/heat. Lower to 8 for maximum savings."
L["GEMS_CVAR_FPS_LOADFPS"] = "Loading Screen FPS"
L["GEMS_CVAR_FPS_LOADFPS_DESC"] = "Loading screen FPS cap. Low is fine -- no gameplay during loads."
L["GEMS_CVAR_FPS_USEMAXFPS"] = "Enable FPS Cap"
L["GEMS_CVAR_FPS_USEMAXFPS_DESC"] = "Enable the FPS cap. Default OFF means uncapped FPS (wastes GPU, causes heat)."
L["GEMS_CVAR_FPS_VSYNC"] = "Vertical Sync"
L["GEMS_CVAR_FPS_VSYNC_DESC"] =
    "Prevents screen tearing but adds input lag. For competitive play, disable and use FPS cap instead."
L["GEMS_CVAR_FPS_TARGETFPS"] = "Target FPS"
L["GEMS_CVAR_FPS_TARGETFPS_DESC"] = "Target FPS for dynamic quality scaling. Game auto-lowers settings to hit this."
L["GEMS_CVAR_FPS_USETARGET"] = "Use Target FPS"
L["GEMS_CVAR_FPS_USETARGET_DESC"] =
    "Enable target FPS system. Can cause jarring quality fluctuations. Prefer static settings."
L["GEMS_CVAR_FPS_LATENCY"] = "GPU Frame Latency"
L["GEMS_CVAR_FPS_LATENCY_DESC"] =
    "Max frames CPU can queue ahead of GPU. Default 3 = ~50ms lag at 60fps. 1 = ~16ms, worth it for macros."
L["GEMS_CVAR_FPS_RSCALE"] = "Render Scale"
L["GEMS_CVAR_FPS_RSCALE_DESC"] =
    "Render resolution multiplier. 1.0 = native. Below 1.0 = blurry but faster. Above 1.0 = supersampling."
L["GEMS_CVAR_FPS_DYNSCALE"] = "Dynamic Render Scale"
L["GEMS_CVAR_FPS_DYNSCALE_DESC"] =
    "Auto-lower render scale when GPU-bound. Beta feature -- can cause hitching. Leave off unless needed."
L["GEMS_CVAR_FPS_LOWLAT"] = "Low Latency Mode"
L["GEMS_CVAR_FPS_LOWLAT_DESC"] =
    "Low latency rendering. 0=none, 2=Reflex (NVIDIA), 4=XeLL (Intel). AMD users leave at 0."
L["GEMS_CVAR_FPS_MULTITHREAD"] = "Multi-Thread Rendering"
L["GEMS_CVAR_FPS_MULTITHREAD_DESC"] =
    "Multi-threaded rendering. Disabling significantly reduces framerate. Never set to 0."
L["GEMS_CVAR_FPS_SPELLCLUTTER"] = "Spell Visual Density"
L["GEMS_CVAR_FPS_SPELLCLUTTER_DESC"] =
    "Global spell visual density. 1=essential only, 4=everything. Lower = max FPS gain."
L["GEMS_CVAR_FPS_PARTICLES"] = "Particle Density"
L["GEMS_CVAR_FPS_PARTICLES_DESC"] =
    "Particle effect detail. Lower tiers cut GPU load in particle-heavy fights; Disabled turns particles off entirely (and hides some combat cues)."
L["GEMS_CVAR_FPS_WEATHER"] = "Weather Density"
L["GEMS_CVAR_FPS_WEATHER_DESC"] = "Weather effect density. Reducing removes rain/snow particles."
L["GEMS_CVAR_FPS_ANIMLOD"] = "Animation Frame Skip"
L["GEMS_CVAR_FPS_ANIMLOD_DESC"] = "Skip animation frames for distant characters. Saves CPU with no visible impact."
L["GEMS_CVAR_FPS_VFXDENSITY"] = "VFX Density Filter"
L["GEMS_CVAR_FPS_VFXDENSITY_DESC"] =
    "Alternative spell visual density control. Works alongside spellClutter as a second-pass filter."
L["GEMS_CVAR_COMBATAUDIO_ENABLE"] = "Combat Audio Alerts"
L["GEMS_CVAR_COMBATAUDIO_ENABLE_DESC"] = "Master switch for the game's spoken combat alerts."
L["GEMS_CVAR_COMBATAUDIO_ENABLE_DESCLONG"] =
    "Turns on the game's built-in spoken combat alerts. Every other row in this section only does something while this is on. It is off by default; turn it on if you want callouts for casts, interrupts, and target changes without watching the screen."
L["GEMS_CVAR_COMBATAUDIO_TARGETNAME"] = "Speak Target Name"
L["GEMS_CVAR_COMBATAUDIO_TARGETNAME_DESC"] = "Say the target's name when you switch targets."
L["GEMS_CVAR_COMBATAUDIO_TARGETNAME_DESCLONG"] =
    "Reads out each new target's name as you tab or click onto it. On by default once combat audio is enabled. Useful for confirming your target without looking at the target frame."
L["GEMS_CVAR_COMBATAUDIO_COMBATSTART"] = "Announce Combat Start"
L["GEMS_CVAR_COMBATAUDIO_COMBATSTART_DESC"] = "Say a line when you enter combat."
L["GEMS_CVAR_COMBATAUDIO_COMBATSTART_DESCLONG"] =
    "Speaks a short line the moment you enter combat. On by default. A cue that a pull has started when you are looking away from the screen."
L["GEMS_CVAR_COMBATAUDIO_COMBATEND"] = "Announce Combat End"
L["GEMS_CVAR_COMBATAUDIO_COMBATEND_DESC"] = "Say a line when you leave combat."
L["GEMS_CVAR_COMBATAUDIO_COMBATEND_DESCLONG"] =
    "Speaks a short line when combat ends. On by default. Pairs with the combat-start callout to bracket each fight."
L["GEMS_CVAR_COMBATAUDIO_TARGETCAST"] = "Target Cast Alerts"
L["GEMS_CVAR_COMBATAUDIO_TARGETCAST_DESC"] = "Speak when your target starts or finishes a cast."
L["GEMS_CVAR_COMBATAUDIO_TARGETCAST_OPT_0"] = "Off"
L["GEMS_CVAR_COMBATAUDIO_TARGETCAST_OPT_1"] = "Cast Start"
L["GEMS_CVAR_COMBATAUDIO_TARGETCAST_OPT_2"] = "Cast End"
L["GEMS_CVAR_COMBATAUDIO_TARGETCAST_DESCLONG"] =
    "Reads out your target's casts. Off by default. Cast Start speaks as the cast begins, which gives you the most warning for an interrupt. Cast End speaks as it finishes. Off keeps the audio quiet."
L["GEMS_CVAR_COMBATAUDIO_TARGETCASTMIN"] = "Target Cast Minimum Length"
L["GEMS_CVAR_COMBATAUDIO_TARGETCASTMIN_DESC"] = "Only speak target casts at least this long."
L["GEMS_CVAR_COMBATAUDIO_TARGETCASTMIN_DESCLONG"] =
    "Filters which target casts get read out by length. The default is 1.5 seconds, so very short casts stay quiet and only slower ones are announced. All Casts reads every cast, which gets noisy in dungeons. Raise it if you only care about long, dangerous casts."
L["GEMS_CVAR_COMBATAUDIO_PLAYERCAST"] = "Your Cast Alerts"
L["GEMS_CVAR_COMBATAUDIO_PLAYERCAST_DESC"] = "Speak when you start or finish a cast."
L["GEMS_CVAR_COMBATAUDIO_PLAYERCAST_OPT_0"] = "Off"
L["GEMS_CVAR_COMBATAUDIO_PLAYERCAST_OPT_1"] = "Cast Start"
L["GEMS_CVAR_COMBATAUDIO_PLAYERCAST_OPT_2"] = "Cast End"
L["GEMS_CVAR_COMBATAUDIO_PLAYERCAST_DESCLONG"] =
    "Reads out your own casts. Off by default. Cast Start speaks as you begin casting, Cast End as it lands. Mostly for accessibility, or for confirming a cast fired without watching the cast bar."
L["GEMS_CVAR_COMBATAUDIO_INTERRUPT"] = "Announce Interruptible Casts"
L["GEMS_CVAR_COMBATAUDIO_INTERRUPT_DESC"] = "Speak when the target begins something you can interrupt."
L["GEMS_CVAR_COMBATAUDIO_INTERRUPT_DESCLONG"] =
    "Speaks a cue when your target starts a cast that can be interrupted. Off by default. A hands-free prompt to use your kick, which pairs well with a sequencer keybind."
L["GEMS_CVAR_COMBATAUDIO_INTERRUPTOK"] = "Announce Interrupt Success"
L["GEMS_CVAR_COMBATAUDIO_INTERRUPTOK_DESC"] = "Speak when the target's cast is interrupted."
L["GEMS_CVAR_COMBATAUDIO_INTERRUPTOK_DESCLONG"] =
    "Speaks a cue when your target's cast gets interrupted. Off by default. Confirms the kick landed so you are not lining up a second one for a cast that already stopped."
L["GEMS_CVAR_COMBATAUDIO_VOLUME"] = "Alert Volume"
L["GEMS_CVAR_COMBATAUDIO_VOLUME_DESC"] = "How loud the combat audio alerts are."
L["GEMS_CVAR_COMBATAUDIO_VOLUME_DESCLONG"] =
    "Sets the volume of the spoken combat alerts, separate from your other sound sliders. Full volume by default. Lower it if the callouts drown out game sound, or mute it to keep the feature configured but silent."
L["GEMS_CVAR_ACCESS_SHAKECAM"] = "Camera Shake Strength"
L["GEMS_CVAR_ACCESS_SHAKECAM_DESC"] = "How much combat and spell effects shake the camera."
L["GEMS_CVAR_ACCESS_SHAKECAM_DESCLONG"] =
    "Scales how much screen effects shake the 3D camera. Full is the default. Lower it, or set it to None, if camera shake causes motion discomfort. This is a common motion-sickness aid."
L["GEMS_CVAR_ACCESS_SHAKEUI"] = "UI Shake Strength"
L["GEMS_CVAR_ACCESS_SHAKEUI_DESC"] = "How much effects shake the 2D interface."
L["GEMS_CVAR_ACCESS_SHAKEUI_DESCLONG"] =
    "Scales how much screen effects shake the flat UI layer, separate from the camera. Full is the default. Lower it if on-screen shake bothers you but you still want the camera effect, or set both shake rows down together."
L["GEMS_CVAR_ACCESS_CBSIM"] = "Colourblind Filter"
L["GEMS_CVAR_ACCESS_CBSIM_DESC"] = "Which type of colourblindness the colour filter is tuned for."
L["GEMS_CVAR_ACCESS_CBSIM_OPT_0"] = "None (default)"
L["GEMS_CVAR_ACCESS_CBSIM_OPT_1"] = "Protanopia (red)"
L["GEMS_CVAR_ACCESS_CBSIM_OPT_2"] = "Deuteranopia (green)"
L["GEMS_CVAR_ACCESS_CBSIM_OPT_3"] = "Tritanopia (blue)"
L["GEMS_CVAR_ACCESS_CBSIM_DESCLONG"] =
    "Selects the type of colourblindness the game's colour filter is tuned for. None is the default, which leaves the screen unchanged. Pick a type here to turn the filter on; the strength row below sets how far it shifts. This is separate from the Colourblind Mode toggle above, which adds colourblind-friendly text labels rather than filtering the screen."
L["GEMS_CVAR_ACCESS_CBWEAK"] = "Colourblind Strength"
L["GEMS_CVAR_ACCESS_CBWEAK_DESC"] = "How strongly the colourblind filter shifts colours."
L["GEMS_CVAR_ACCESS_CBWEAK_DESCLONG"] =
    "Sets how strongly the colourblind filter shifts colours, from none at 0 to full at 1. The default is 0.5. Only does anything when a colourblind filter type is selected above."
L["GEMS_CVAR_ACCESS_CURSORSIZE"] = "Cursor Size"
L["GEMS_CVAR_ACCESS_CURSORSIZE_DESC"] = "Size of the mouse cursor."
L["GEMS_CVAR_ACCESS_CURSORSIZE_OPT_AUTO"] = "Auto (by monitor)"
L["GEMS_CVAR_ACCESS_CURSORSIZE_OPT_0"] = "Small (32px)"
L["GEMS_CVAR_ACCESS_CURSORSIZE_OPT_1"] = "Medium (48px)"
L["GEMS_CVAR_ACCESS_CURSORSIZE_OPT_2"] = "Large (64px)"
L["GEMS_CVAR_ACCESS_CURSORSIZE_OPT_3"] = "Extra Large (96px)"
L["GEMS_CVAR_ACCESS_CURSORSIZE_OPT_4"] = "Huge (128px)"
L["GEMS_CVAR_ACCESS_CURSORSIZE_DESCLONG"] =
    "Sets the mouse cursor size. Auto picks a size from your monitor resolution and is the default. The fixed sizes make the cursor easier to track on a busy screen or a large display."
L["GEMS_CVAR_ACCESS_CLIPCURSOR"] = "Lock Cursor to Window"
L["GEMS_CVAR_ACCESS_CLIPCURSOR_DESC"] = "Keep the mouse cursor inside the game window."
L["GEMS_CVAR_ACCESS_CLIPCURSOR_DESCLONG"] =
    "Stops the mouse from leaving the game window. Off is the default. Turn it on for windowed play across multiple monitors so the cursor does not slip onto another screen mid-fight."
L["GEMS_CVAR_ACCESS_TTS"] = "Chat Text to Speech"
L["GEMS_CVAR_ACCESS_TTS_DESC"] = "Read chat messages out loud."
L["GEMS_CVAR_ACCESS_TTS_DESCLONG"] =
    "Reads incoming chat out loud using the system voice. Off is the default. This is separate from the combat audio alerts in their own section; this row is for chat channels."
L["GEMS_CVAR_ACCESS_STT"] = "Voice Transcription"
L["GEMS_CVAR_ACCESS_STT_DESC"] = "Show on-screen text for spoken words in voice chat."
L["GEMS_CVAR_ACCESS_STT_DESCLONG"] =
    "Transcribes other players' voice chat into on-screen text. Off is the default. Useful if you are in a voice channel but cannot hear it clearly or at all."
L["GEMS_CVAR_ACCESS_TTSCHAR"] = "Per-Character Voice Settings"
L["GEMS_CVAR_ACCESS_TTSCHAR_DESC"] = "Use separate text-to-speech settings for this character."
L["GEMS_CVAR_ACCESS_TTSCHAR_DESCLONG"] =
    "When on, this character keeps its own text-to-speech voice and options instead of sharing the account-wide set. On is the default. Turn it off to use one shared voice setup across every character."
L["GEMS_CVAR_SEARCH"] = "Find a CVar"
L["GEMS_CVAR_SEARCH_DESC"] =
    "Type part of a CVar name or its label. Up to eight matches appear below; click one to jump to its section page."
L["GEMS_CVAR_SEARCH_NOMATCH"] = "No matching CVar."
L["GEMS_CVAR_FILTER_ISSUES"] = "Show only issues"
L["GEMS_CVAR_FILTER_ISSUES_DESC"] =
    "Hide rows that already match the recommendation and hide sections with nothing to fix. Rows you marked as your choice count as fine and are hidden too. Session-only; the filter resets on reload."

-- CVar registry Tier 1 family completions (v2.3.13)
L["GEMS_CVAR_FPS_USEMAXFPSBK"] = "Use Background Cap"
L["GEMS_CVAR_FPS_USEMAXFPSBK_DESC"] = "Turns the background FPS limit on or off when the game window loses focus."
L["GEMS_CVAR_FPS_USEMAXFPSBK_DESCLONG"] =
    "Works together with Background FPS. When enabled, the client drops to the Background FPS value while you are tabbed out, cutting GPU load and heat. Disable only if you record or stream the game window in the background."
L["GEMS_CVAR_FPS_DYNSCALEMIN"] = "Dynamic Scale Floor"
L["GEMS_CVAR_FPS_DYNSCALEMIN_DESC"] = "Lowest render scale the dynamic scaler is allowed to reach."
L["GEMS_CVAR_FPS_DYNSCALEMIN_DESCLONG"] =
    "Only matters while Dynamic Render Scale is enabled. The default 33% floor keeps FPS stable at a heavy image-quality cost; raise the floor to keep the image sharper in exchange for smaller FPS savings."
L["GEMS_CVAR_VISUAL_RESAMPLEQ"] = "Resample Quality"
L["GEMS_CVAR_VISUAL_RESAMPLEQ_DESC"] = "Upscaling filter used when Render Scale is not 100%."
L["GEMS_CVAR_VISUAL_RESAMPLEQ_OPT_0"] = "Point (fastest)"
L["GEMS_CVAR_VISUAL_RESAMPLEQ_OPT_1"] = "Bilinear"
L["GEMS_CVAR_VISUAL_RESAMPLEQ_OPT_2"] = "Bicubic"
L["GEMS_CVAR_VISUAL_RESAMPLEQ_OPT_3"] = "FidelityFX Super Resolution (default, recommended)"
L["GEMS_CVAR_VISUAL_RESAMPLEQ_DESCLONG"] =
    "Only applies while Render Scale differs from 100%. FidelityFX Super Resolution gives the cleanest upscale on modern GPUs; Point and Bilinear are cheaper fallbacks for very old hardware."
L["GEMS_CVAR_DUNGEON_UNITCLUTTER"] = "Unit Clutter Reduction"
L["GEMS_CVAR_DUNGEON_UNITCLUTTER_DESC"] = "Master toggle for the system that thins out stacked NPCs and pets."
L["GEMS_CVAR_DUNGEON_UNITCLUTTER_DESCLONG"] =
    "Master switch for unit clutter reduction. Keep it on so crowded scenes stay readable; the instances-only setting scopes where it applies and the player threshold controls how many nearby players it takes to kick in."
L["GEMS_CVAR_DUNGEON_CLUTTERTHRESH"] = "Clutter Player Threshold"
L["GEMS_CVAR_DUNGEON_CLUTTERTHRESH_DESC"] = "Nearby players required before clutter reduction kicks in."
L["GEMS_CVAR_DUNGEON_CLUTTERTHRESH_DESCLONG"] =
    "Lower values start hiding cosmetic units earlier, which helps framerate in busy hubs and raids. The default of 9 is a solid middle ground; raise it if you only want clutter reduction in very large groups."
L["GEMS_CVAR_COMBAT_SOFTICONENEMY"] = "Enemy Soft Target Icon"
L["GEMS_CVAR_COMBAT_SOFTICONENEMY_DESC"] = "Show an icon above the enemy action targeting has picked."
L["GEMS_CVAR_COMBAT_SOFTICONENEMY_DESCLONG"] =
    "With enemy soft targeting active, this icon marks exactly which enemy your next cast will hit. Recommended for sequence users: you see what the engine sees before the button press."
L["GEMS_CVAR_COMBAT_SOFTICONFRIEND"] = "Friendly Soft Target Icon"
L["GEMS_CVAR_COMBAT_SOFTICONFRIEND_DESC"] = "Show an icon above your current friendly soft target."
L["GEMS_CVAR_COMBAT_SOFTICONFRIEND_DESCLONG"] =
    "Only relevant when friendly soft targeting is enabled, which the registry recommends leaving off. Keep the icon off unless you have turned friendly soft targeting on for support play."
L["GEMS_CVAR_SOLO_INTERHARDRANGE"] = "Hard Interact Range Cutoff"
L["GEMS_CVAR_SOLO_INTERHARDRANGE_DESC"] = "Treat the interact range as a hard cutoff in every case."
L["GEMS_CVAR_SOLO_INTERHARDRANGE_DESCLONG"] =
    "Off keeps the forgiving behaviour: an object already in interact range stays targetable at the edge. On drops the soft target the moment it leaves the configured range. Leave off unless you want strict range discipline."
L["GEMS_CVAR_SOLO_INTERICONGO"] = "Object Interact Icon"
L["GEMS_CVAR_SOLO_INTERICONGO_DESC"] = "Show an icon on usable objects that cannot normally be targeted."
L["GEMS_CVAR_SOLO_INTERICONGO_DESCLONG"] =
    "Extends the interact icon to chests, levers, and other world objects without a real target frame. Pairs with the interact icon and range settings above so every usable object is flagged before you press interact."
L["GEMS_CVAR_SOLO_LOWPRIOICONS"] = "Low-Priority Interact Icons"
L["GEMS_CVAR_SOLO_LOWPRIOICONS_DESC"] = "Show interact icons on objects quest or loot effects already mark."
L["GEMS_CVAR_SOLO_LOWPRIOICONS_DESCLONG"] =
    "Off keeps the screen quieter by letting quest sparkles and loot glows stand alone. Turn it on if you want the interact icon visible on every usable object regardless of other markers."
L["GEMS_CVAR_NAMEPLATES_SOFTNPFRIEND"] = "Friendly Soft Target Nameplate"
L["GEMS_CVAR_NAMEPLATES_SOFTNPFRIEND_DESC"] = "Always show a nameplate for your current friendly soft target."
L["GEMS_CVAR_NAMEPLATES_SOFTNPFRIEND_DESCLONG"] =
    "Only relevant when friendly soft targeting is enabled, which the registry recommends leaving off. Leave disabled to keep friendly nameplates uncluttered."
L["GEMS_CVAR_NAMEPLATES_SOFTNPINTERACT"] = "Interact Target Nameplate"
L["GEMS_CVAR_NAMEPLATES_SOFTNPINTERACT_DESC"] = "Always show a nameplate for your current soft interact target."
L["GEMS_CVAR_NAMEPLATES_SOFTNPINTERACT_DESCLONG"] =
    "Puts a nameplate on the NPC or object your interact key is pointed at, which makes the pick unambiguous in crowded quest hubs. Pairs with the interact icons for full interact visibility."
L["GEMS_CVAR_FPS_USEMAXFPS_DESCLONG"] =
    "Master switch for the FPS limit. EMS recommends 1 because uncapped frames can spike to 300+ in light scenes (e.g. open-world solo play), spinning your GPU up to high power draw for no visible benefit on a 60-144Hz monitor. Setting a cap reduces fan noise, lowers GPU temperature, and prevents the framerate-cliff sensation when you enter dense content. Pair this with maxFPS at your monitor refresh rate. Set to 0 if you specifically want uncapped frames for input-latency reasons (high-refresh competitive PvP). This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_FPS_VSYNC_DESCLONG"] =
    "Vertical sync, synchronising frame output to your monitor refresh rate. EMS recommends 0 because vsync adds input latency (typically one full frame, 8-16ms on a 60-120Hz monitor) which is noticeable during reactive play -- interrupt windows feel mushier and dragonriding inputs feel delayed. Modern high-refresh-rate monitors generally handle tearing well without vsync. Set to 1 only if you see visible tearing artefacts that bother you and your monitor lacks G-Sync or FreeSync support. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_FPS_USETARGET_DESCLONG"] =
    "Enables the dynamic-FPS-adjustment system: WoW lowers render scale, particle density, and other quality settings on the fly when actual FPS drops below targetFPS. EMS recommends 0 because the dynamic adjustments cause visible quality shifts mid-fight (textures pop, shadows fade in and out) which is more distracting than a stable lower framerate. Set quality manually to a level your hardware sustains and accept the framerate that produces. Set to 1 if you specifically prefer the dynamic-quality tradeoff. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_FPS_DYNSCALE_DESCLONG"] =
    "Lowers render scale dynamically if GPU-bound to hit targetFPS. EMS recommends 0 (match-default) because Blizzard marks this as BETA with known issues (May cause hitching. May behave poorly with vsync on). The trade-off is visible: text and UI go subtly blurry when DynamicRenderScale kicks in, which is more distracting than a stable lower framerate. Set to 1 only if you specifically want dynamic GPU-bound adjustment. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_FPS_MULTITHREAD_DESCLONG"] =
    "Multi-threaded command list compatibility mode. Default 1 is correct -- disabling this significantly reduces framerate per Blizzard's own description, particularly on multi-core CPUs (which is every modern system). Only set to 0 if you experience specific multi-threaded rendering bugs that disabling solves; this is rare. Critical setting -- changes take effect on the next graphics reset (logout + login, or /console gxRestart). This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_FPS_ANIMLOD_DESCLONG"] =
    "Skips animation frames for distant units to save CPU. EMS recommends 1 because crowded scenes (raid, capital city, mass PvP) can have dozens of off-screen or far-away animated units whose animation updates burn CPU cycles you do not see. Frame-skipping at distance is visually imperceptible at 30+ yards (the units are too small to notice their reduced anim cadence) and frees CPU for the units that matter (the boss, your party, the unit you target). Set to 0 if you want full animation fidelity at all distances. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_FPS_LATENCY_OPT_1"] = "1 (recommended, lowest input lag)"
L["GEMS_CVAR_FPS_LATENCY_OPT_2"] = "2 (balanced)"
L["GEMS_CVAR_FPS_LATENCY_OPT_3"] = "3 (default, smoothest frame pacing)"
L["GEMS_CVAR_FPS_LATENCY_DESCLONG"] =
    "Maximum number of frames the CPU can render ahead of the GPU (input-to-display pipeline depth). EMS recommends 1 because the Blizzard default 3 adds substantial input latency (each queued frame is one frame of delay between keypress and on-screen action). Setting to 1 cuts the pipeline to the minimum, reducing input lag noticeably for reactive play (interrupt windows, dodge mechanics, dragonriding). Trade-off: on a CPU-bottlenecked system, lower values can cause minor frame pacing inconsistency. Increase to 2 or 3 if you see hitching. Critical setting -- changes take effect on the next graphics reset (logout + login, or /console gxRestart). This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_FPS_WEATHER_OPT_0"] = "0 (off)"
L["GEMS_CVAR_FPS_WEATHER_OPT_1"] = "1 (light, recommended)"
L["GEMS_CVAR_FPS_WEATHER_OPT_2"] = "2 (full, default)"
L["GEMS_CVAR_FPS_WEATHER_DESCLONG"] =
    "Density of weather particle effects (rain, snow, sandstorm). EMS recommends 1 because the Blizzard default 2 (full) renders thousands of weather particles in outdoor zones -- the FPS cost runs 10-20% in dense storms with little gameplay benefit. Setting to 1 (light) keeps the atmospheric feel but cuts the particle count to a level that does not tank framerate during outdoor combat. Set to 0 if you want zero weather rendering (max FPS in storms). This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_FPS_VFXDENSITY_OPT_1"] = "1 (minimum, recommended)"
L["GEMS_CVAR_FPS_VFXDENSITY_OPT_2"] = "2 (reduced)"
L["GEMS_CVAR_FPS_VFXDENSITY_OPT_3"] = "3 (performance)"
L["GEMS_CVAR_FPS_VFXDENSITY_OPT_4"] = "4 (full, default)"
L["GEMS_CVAR_FPS_VFXDENSITY_DESCLONG"] =
    "Filters out overlapping spell visuals (SVKs) in dense scenes. EMS recommends 1 (minimum) because the Blizzard default 4 (full) renders every spell visual in raid scenes which causes catastrophic FPS drops in 20+ player encounters with multiple AoE effects (think Mythic raid bosses with overlapping ground effects). Minimum mode drops less-important visuals first while keeping your own spell cues clear. Increase to 2 (reduced) or 3 (performance) only if you have headroom; the FPS difference between settings is dramatic in dense raid content. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_FPS_BGFPS_DESCLONG"] =
    "Background FPS limit -- the cap applied when WoW is not the focused window (Alt-Tab to browser, Discord). Default 30 is correct because backgrounded WoW still consumes some CPU/GPU and capping it at 30 lets the focused application (your browser, Discord) have full performance headroom. Lower to 8 (minimum) if you want WoW to use almost no resources when backgrounded. Raise to 60+ if you stream WoW from a backgrounded source. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_FPS_LOADFPS_DESCLONG"] =
    "FPS cap during loading screens. Default 10 is correct because loading screens are static visuals; rendering them at 200 FPS only loads the GPU for no benefit. Lower to 5 if you want the absolute minimum power draw during loads. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_FPS_TARGETFPS_DESCLONG"] =
    "Target FPS for the dynamic adjustment system (only used when useTargetFPS is On). Default 60 is the standard target for stable play on a 60Hz monitor. Set to your monitor refresh rate if higher (120 for 120Hz, 144 for 144Hz). Lower targets accept worse quality to maintain framerate; higher targets reduce quality more aggressively. This setting only matters when useTargetFPS is enabled. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_FPS_LOWLAT_OPT_0"] = "0 None (default, safe)"
L["GEMS_CVAR_FPS_LOWLAT_OPT_1"] = "1 BuiltIn (works on any GPU)"
L["GEMS_CVAR_FPS_LOWLAT_OPT_2"] = "2 Reflex (NVIDIA RTX only)"
L["GEMS_CVAR_FPS_LOWLAT_OPT_3"] = "3 Reflex+Boost (NVIDIA RTX only)"
L["GEMS_CVAR_FPS_LOWLAT_OPT_4"] = "4 XeLL (Intel Arc only)"
L["GEMS_CVAR_FPS_LOWLAT_DESCLONG"] =
    "Hardware-specific frame latency reduction. Default 0 (None) is universally safe. Options: 0=None (no vendor-specific path); 1=BuiltIn (Blizzard's generic latency reduction, works on any GPU); 2=Reflex (NVIDIA Reflex, requires RTX GPU and updated NVIDIA driver); 3=Reflex+Boost (NVIDIA Reflex with Boost, RTX GPU only); 4=XeLL (Intel Xe Low Latency, requires Intel Arc GPU and updated Intel driver). Pick the option matching your hardware: NVIDIA RTX owners use 2 or 3, Intel Arc owners use 4, all others use 1 (BuiltIn) for moderate gains or 0 (safe default). Note: setting an unsupported mode (e.g. Reflex on an AMD GPU) is harmless -- the driver simply ignores the request. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_FPS_SPELLCLUTTER_OPT_0"] = "0 (none, dev-only)"
L["GEMS_CVAR_FPS_SPELLCLUTTER_OPT_1"] = "1 (minimum, recommended)"
L["GEMS_CVAR_FPS_SPELLCLUTTER_OPT_2"] = "2 (reduced)"
L["GEMS_CVAR_FPS_SPELLCLUTTER_OPT_3"] = "3 (performance)"
L["GEMS_CVAR_FPS_SPELLCLUTTER_OPT_4"] = "4 (full, default)"
L["GEMS_CVAR_FPS_SPELLCLUTTER_DESCLONG"] =
    "Legacy Spell Density CVar paired with spellVisualDensityFilterSetting (same 0-4 enum where 0=none dev-only, 1=minimum, 2=reduced, 3=performance, 4=full). EMS recommends 1 for the same reason as spellVisualDensityFilterSetting: at 4 (full) raid scenes can drop FPS by 50%+ during overlapping AoE effects. Keep both cvars at 1 for consistent spell-density behaviour. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_FPS_RSCALE_DESCLONG"] =
    "Render scale: 1.0 is native resolution, values above 1.0 supersample (render at higher resolution then downscale, sharper image, more GPU cost), values below 1.0 undersample (render at lower resolution, blurrier, less GPU cost). Default 1.0 is correct for almost every player. Set to 1.25 or 1.5 only if you have substantial GPU headroom and want sharper visuals at 1080p/1440p. Set to 0.9 or 0.75 if you need FPS gains and can accept a softer image. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."

-- CVar Section: Visual Quality
L["GEMS_CVAR_VISUAL_QUALITY"] = "Graphics Quality"
L["GEMS_CVAR_VISUAL_QUALITY_DESC"] = "Master graphics quality preset (1-10). Changes all sub-settings at once."
L["GEMS_CVAR_VISUAL_SHADOWS"] = "Shadow Quality"
L["GEMS_CVAR_VISUAL_SHADOWS_DESC"] =
    "Shadow quality (0-5). Shadows are GPU-expensive; lowering to Low or Fair gives significant FPS gains."
L["GEMS_CVAR_VISUAL_SSAO"] = "Ambient Occlusion"
L["GEMS_CVAR_VISUAL_SSAO_DESC"] =
    "Screen-space ambient occlusion quality. Adds depth to shadows. 0=off (fastest), 4=highest."
L["GEMS_CVAR_VISUAL_VIEWDIST"] = "View Distance"
L["GEMS_CVAR_VISUAL_VIEWDIST_DESC"] =
    "View distance (1-10). Lowering to 5 saves GPU with little visual impact in instanced content."
L["GEMS_CVAR_VISUAL_GROUND"] = "Ground Clutter"
L["GEMS_CVAR_VISUAL_GROUND_DESC"] =
    "Grass/ground detail density (1-10). Pure cosmetic -- lowering has zero gameplay impact and saves FPS."
L["GEMS_CVAR_VISUAL_TEXRES"] = "Texture Resolution"
L["GEMS_CVAR_VISUAL_TEXRES_DESC"] = "Texture resolution quality (0-2). Affects VRAM usage. Lower if VRAM-limited."
L["GEMS_CVAR_VISUAL_LIQUID"] = "Water Quality"
L["GEMS_CVAR_VISUAL_LIQUID_DESC"] = "Water rendering quality. Lower = less reflective water, better FPS near water."
L["GEMS_CVAR_VISUAL_PROJTEX"] = "Projected Textures"
L["GEMS_CVAR_VISUAL_PROJTEX_DESC"] =
    "Spell ground effects (Healing Rain, Consecration). MUST be on -- without it, boss mechanics are invisible."
L["GEMS_CVAR_VISUAL_OUTLINE"] = "Outline Mode"
L["GEMS_CVAR_VISUAL_OUTLINE_DESC"] =
    "Character/NPC outline quality. 0=Disabled, 1=Medium, 2=High. Helps with visibility."
L["GEMS_CVAR_VISUAL_AA"] = "Anti-Aliasing"
L["GEMS_CVAR_VISUAL_AA_DESC"] =
    "Anti-aliasing mode. 0=none, 1=FXAA low, 2=FXAA high, 3=CMAA. CMAA is best quality-to-cost ratio."
L["GEMS_CVAR_VISUAL_GLOW"] = "Glow Effect"
L["GEMS_CVAR_VISUAL_GLOW_DESC"] = "Full-screen glow effect. Subtle but adds atmosphere."
L["GEMS_CVAR_VISUAL_DEATH"] = "Death Effect"
L["GEMS_CVAR_VISUAL_DEATH_DESC"] = "Death desaturation effect. Greyscale when dead."
L["GEMS_CVAR_VISUAL_SHARPEN"] = "Sharpening Pass"
L["GEMS_CVAR_VISUAL_SHARPEN_DESC"] =
    "Enable sharpening even without FSR upscaling. Makes the image crisper at native resolution. Not exposed in the standard graphics menu."
L["GEMS_CVAR_VISUAL_SHARPNESS"] = "Sharpening Strength"
L["GEMS_CVAR_VISUAL_SHARPNESS_DESC"] =
    "Sharpening strength (0.0-2.0). Only does anything when sharpening is enabled or FSR is on."
L["GEMS_CVAR_VISUAL_FARCLIP"] = "Far Clip Plane"
L["GEMS_CVAR_VISUAL_FARCLIP_DESC"] =
    "Max render distance in world units. Lower = less distant geometry = better FPS. 800 is sufficient."
-- CVar Section: Visual Quality -- Raid and Battleground mirrors (2d)
L["GEMS_CVAR_VISUAL_RAIDSHADOWS"] = "Raid Shadow Quality"
L["GEMS_CVAR_VISUAL_RAIDSHADOWS_DESC"] =
    "Shadow tier for the raid and battleground graphics profile (0-5). Lower it for FPS in big group content; your open-world shadows stay untouched."
L["GEMS_CVAR_VISUAL_RAIDSHADOWS_DESCLONG"] =
    "WoW keeps a separate graphics profile for raids and battlegrounds so you can run lighter settings where framerate matters most. This is the shadow tier for that profile, on Blizzard's scale from Low up to Ultra High. Shadows are one of the heaviest GPU settings, so dropping raid shadows to Low or Fair frees the most frames in a 20-player pull or a packed battleground, and everywhere else keeps full shadows. The live raid default is High. Drop it if raids stutter, keep it up if your GPU has room. This setting resets each session and does not persist across logouts; EMS re-applies your choice on every login."
L["GEMS_CVAR_VISUAL_RAIDSSAO"] = "Raid Ambient Occlusion"
L["GEMS_CVAR_VISUAL_RAIDSSAO_DESC"] =
    "Ambient occlusion tier for the raid and battleground profile (0 off, 4 highest). Cheaper than shadows; leave at default unless you need every frame."
L["GEMS_CVAR_VISUAL_RAIDSSAO_DESCLONG"] =
    "Screen-space ambient occlusion is the soft contact shadow where objects meet the ground. This is the raid and battleground copy of that setting, separate from your open-world value, with tiers running Disabled, Low, Medium, High, Ultra. It costs less GPU than shadow quality, so most people leave it at the default High and only drop to Low or Disabled when a dense pull needs the frames. The live raid default is High. This setting resets each session and does not persist across logouts; EMS re-applies your choice on every login."
L["GEMS_CVAR_VISUAL_RAIDGROUND"] = "Raid Ground Clutter"
L["GEMS_CVAR_VISUAL_RAIDGROUND_DESC"] =
    "Grass and ground-detail density in raids and battlegrounds (1-10). Cosmetic, so lowering it costs nothing in gameplay."
L["GEMS_CVAR_VISUAL_RAIDGROUND_DESCLONG"] =
    "Density of small ground objects like grass, pebbles, and leaves while you are in a raid or battleground, kept separate from your open-world value. It is purely cosmetic: clutter never hides a unit or a ground effect, so trimming it is free FPS. The recommended value matches the live raid default of 6, which is fairly dense; most raid bosses sit indoors where you barely see grass, so dropping to 1 through 3 is a safe cut if you want a few more frames. This setting resets each session and does not persist across logouts; EMS re-applies your choice on every login."
L["GEMS_CVAR_VISUAL_RAIDPROJTEX"] = "Raid Projected Textures"
L["GEMS_CVAR_VISUAL_RAIDPROJTEX_DESC"] =
    "Spell ground effects (swirls, void zones) inside raids and battlegrounds. Keep it on; off hides boss telegraphs."
L["GEMS_CVAR_VISUAL_RAIDPROJTEX_DESCLONG"] =
    "Projected textures are the ground-effect decals for raid mechanics: AoE swirls, void zones, fire patches, healing circles. This is the raid and battleground copy of the setting, separate from your open-world value. Keep it on (1), because with it off those indicators do not draw and you cannot see where a mechanic is about to land, in exactly the content where that gets you killed. Turn it off only if you have a real GPU bottleneck and run a third-party addon that draws its own markers. This setting resets each session and does not persist across logouts; EMS re-applies your choice on every login."
L["GEMS_CVAR_VISUAL_PROJTEX_DESCLONG"] =
    "Projected textures for ground-effect indicators (AoE markers, void zones, fire patches, healing circles). Default 1 is correct because turning this off removes the visible ground indicators for raid mechanics -- you cannot see where the swirly is. Critical setting -- changes take effect on the next graphics reset (logout + login, or /console gxRestart). Set to 0 only if you have a specific GPU-bottleneck issue and use a third-party addon that draws its own AoE markers. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_VISUAL_GLOW_DESCLONG"] =
    "Full-screen glow effect -- the soft bloom on bright surfaces (light sources, magic spells, sun glare). Default 1 is correct because bloom is a small visual flourish with negligible FPS cost on modern hardware. Set to 0 if you find bloom distracting in dark zones or if you specifically prefer a flatter visual style. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_VISUAL_DEATH_DESCLONG"] =
    "Full-screen death desaturation effect -- the grey-out filter applied when your character dies. Default 1 is correct because the desat is a useful visual cue confirming your death state (vs a screen freeze or disconnect). Set to 0 if you find the grey-out disorienting during PvP corpse runs. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_VISUAL_SHARPEN_DESCLONG"] =
    "Forces the sharpness pass to run even when AMD FSR upscaling is disabled. EMS recommends 1 because the default 0 means sharpening only applies during FSR upscaling, which most players are not using -- the result is a soft, slightly washed-out image at native resolution. Setting to 1 enables the sharpness pass regardless, giving you crisper text and UI at all resolutions. ResampleSharpness controls the strength (see below). Set to 0 if you prefer the softer default look. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_VISUAL_OUTLINE_DESCLONG"] =
    "Character outline rendering quality on Blizzard's three tiers: 0=Disabled (no outlines), 1=Medium, 2=High (crispest outlines). Default 2 is correct because outlines help you parse character positions in dense scenes (raid stacking, crowded PvP). Set to 0 to turn outlines off for a flatter look, or 1 for a lighter outline pass. This setting resets each session and does not persist across logouts; EMS re-applies your choice on every login."
L["GEMS_CVAR_VISUAL_SSAO_DESCLONG"] =
    "Screen-space ambient occlusion -- the soft contact shadow where objects meet surfaces. Blizzard's tiers run Disabled, Low, Medium, High, Ultra. High (the default) is a sensible stop: SSAO is a cheap way to keep characters looking grounded instead of floating above the terrain, and the frame cost from Disabled up to High is small on modern GPUs. Go to Ultra for the cleanest contact shadows, or drop it only if you need every frame for competitive play. This setting resets each session and does not persist across logouts; EMS re-applies your choice on every login."
L["GEMS_CVAR_VISUAL_LIQUID_DESCLONG"] =
    "Water and lava surface rendering on Blizzard's four tiers: 0=Low (flat coloured surface), 1=Fair (basic ripples), 2=Medium (reflections, refraction), 3=High (caustics, volumetric depth). EMS recommends 1 because the Blizzard default 2 renders full reflections on every water surface which costs noticeable FPS in zones with large water areas (Suramar, Nazjatar, Azshara, the Plunderstorm coastline). Setting to 1 keeps the surface looking like water without the expensive reflection pass. Set to 2 or 3 if you specifically enjoy water visuals and have GPU headroom. This setting resets each session and does not persist across logouts; EMS re-applies your choice on every login."
L["GEMS_CVAR_VISUAL_VIEWDIST_DESCLONG"] =
    "How far the engine renders distant terrain, buildings, and props on Blizzard's 1-10 scale. EMS recommends 5 because the Blizzard default 6 renders enough distance that outdoor zones with many distant objects (Boralus, Valdrakken, Dornogal skyline) cost FPS for environment your camera barely catches. Setting to 5 keeps the playable horizon visible but trims the far-distance prop count. Set to 7 or higher if you specifically want maximum draw distance for screenshots or extended Skyriding flight planning. Set to 1-3 only if you need aggressive FPS gains. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_VISUAL_GROUND_DESCLONG"] =
    "Density of small ground objects: grass, pebbles, leaves, flowers, debris. EMS recommends 3 because the Blizzard default 6 fills outdoor zones with thousands of grass and flower tiles that cost FPS without contributing to gameplay -- you cannot interact with them, they do not hide units, and at typical camera angles you mostly see the top surface. Setting to 3 keeps the ground looking varied without the high-density particle cost. Set to 5+ if you specifically enjoy the dense vegetation look in outdoor zones. Set to 1 for maximum FPS in dense outdoor content. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_VISUAL_AA_OPT_0"] = "0 (Disabled, default)"
L["GEMS_CVAR_VISUAL_AA_OPT_1"] = "1 (FXAA Low)"
L["GEMS_CVAR_VISUAL_AA_OPT_2"] = "2 (FXAA High)"
L["GEMS_CVAR_VISUAL_AA_OPT_3"] = "3 (CMAA, recommended)"
L["GEMS_CVAR_VISUAL_AA_OPT_4"] = "4 (CMAA2, sharpest)"
L["GEMS_CVAR_VISUAL_AA_DESCLONG"] =
    "Post-process anti-aliasing technique. EMS recommends 3 (CMAA) because the Blizzard default 0 leaves pixel edges jagged at every resolution, while CMAA gives clean edges with no temporal smearing and very low FPS cost on modern hardware. Options: 0=Disabled, 1=FXAA Low (blurry, cheap), 2=FXAA High (less blurry, slightly more expensive), 3=CMAA (sharp, well-balanced), 4=CMAA2 (sharpest, slightly more expensive than CMAA). Pick CMAA2 if you have GPU headroom and want the cleanest edges, FXAA Low if you need maximum FPS, or Disabled if you specifically prefer pixel-perfect rendering. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_VISUAL_FARCLIP_DESCLONG"] =
    "Maximum render distance in yards for the world far-clipping plane. EMS recommends 800 because the Blizzard default 1000 renders an extra 200 yards of distant terrain and props you rarely visually engage with -- the FPS cost is real in outdoor zones with long sightlines (Suramar overlooks, Plunderstorm coast, Skyriding mid-altitude). Setting to 800 trims the horizon to the practical play distance. Set to 1500 or 2500 if you take landscape screenshots or want maximum visibility for long-range Skyriding flight planning. Set to 500 only if you need aggressive FPS gains in outdoor content. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_VISUAL_QUALITY_DESCLONG"] =
    "Master video-quality slider on Blizzard's 1-10 preset scale (1=Low, 3=Fair, 6=Good (default), 8=High, 10=Ultra). Default 6 (Good) is correct for balanced play on modern hardware. WARNING: changing this value cascades to all other graphics CVars (shadowQuality, viewDistance, groundClutter, liquidDetail, textureResolution, SSAO, projectedTextures, outlineMode, AA, glow, death, sharpen, sharpness, farclip) -- the preset rewrites every per-cvar tuning you made in the panel above. If you have tuned individual graphics cvars in EMS to specific values, picking a different preset here will OVERWRITE those tunings to the preset's defaults. Recommended workflow: leave this at 6 (Good) and tune individual cvars above for fine-grained control. Pick a different preset only if you want to reset all graphics cvars to Blizzard's preset values. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_VISUAL_SHARPNESS_DESCLONG"] =
    "FSR upscaling sharpness strength on a 0.0-2.0 scale where 0.0 is full strength, 2.0 is minimum, and -1 disables. Default 0.2 is correct -- slightly off full strength to avoid over-sharpening text artefacts. Pairs with ResampleAlwaysSharpen above (which controls whether sharpening runs at all). Set to 0.0 for maximum sharpening (slightly more aliasing artefacts on text). Set to 0.5 or 1.0 for a softer look. Set to -1 to fully disable the sharpness pass regardless of ResampleAlwaysSharpen. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."

-- CVar Section: Sound
L["GEMS_CVAR_SOUND_MASTER"] = "Master Sound Toggle"
L["GEMS_CVAR_SOUND_MASTER_DESC"] = "Master sound toggle. Must be on for any audio."
L["GEMS_CVAR_SOUND_MASTERVOL"] = "Master Volume"
L["GEMS_CVAR_SOUND_MASTERVOL_DESC"] = "Master volume (0.0-1.0). 0.8 gives headroom for Discord/Spotify alongside WoW."
L["GEMS_CVAR_SOUND_SFX"] = "SFX Volume"
L["GEMS_CVAR_SOUND_SFX_DESC"] = "Sound effects volume. Keep at 1.0 for combat audio cues."
L["GEMS_CVAR_SOUND_MUSIC"] = "Music Volume"
L["GEMS_CVAR_SOUND_MUSIC_DESC"] = "Music volume. Lower during raids/dungeons to hear boss ability audio cues."
L["GEMS_CVAR_SOUND_AMBIENCE"] = "Ambience Volume"
L["GEMS_CVAR_SOUND_AMBIENCE_DESC"] =
    "Ambient sound volume. Lower in raids -- ambient noise can mask important combat audio."
L["GEMS_CVAR_SOUND_DIALOG"] = "Dialogue Volume"
L["GEMS_CVAR_SOUND_DIALOG_DESC"] = "Voice/dialogue volume (boss VO, quest narration)."
L["GEMS_CVAR_SOUND_BGAUDIO"] = "Background Audio"
L["GEMS_CVAR_SOUND_BGAUDIO_DESC"] =
    "Play sound when WoW is in background. Important for queue pops and ready checks while alt-tabbed."
L["GEMS_CVAR_SOUND_ENCWARN"] = "Encounter Warning Sounds"
L["GEMS_CVAR_SOUND_ENCWARN_DESC"] = "Play sounds for encounter/boss warnings."
L["GEMS_CVAR_SOUND_ENCVOL"] = "Encounter Warning Volume"
L["GEMS_CVAR_SOUND_ENCVOL_DESC"] = "Volume for encounter warning sounds (0.0-1.0)."
L["GEMS_CVAR_SOUND_ERRSPEECH"] = "Error Speech"
L["GEMS_CVAR_SOUND_ERRSPEECH_DESC"] =
    "Error voice (not enough mana, etc). Disable -- macro sequences hitting cooldowns trigger this rapidly."
L["GEMS_CVAR_SOUND_GAMEPLAY"] = "Gameplay SFX"
L["GEMS_CVAR_SOUND_GAMEPLAY_DESC"] = "Enable gameplay sound effects (combat, abilities, NPCs)."
L["GEMS_CVAR_SOUND_NUMCHANNELS"] = "Sound Channels"
L["GEMS_CVAR_SOUND_NUMCHANNELS_DESC"] =
    "Maximum simultaneous audio channels (20-128). Raise to 128 so busy fights stop cutting combat cues."
L["GEMS_CVAR_SOUND_PINGSOUNDS"] = "Ping Sounds"
L["GEMS_CVAR_SOUND_PINGSOUNDS_DESC"] = "Play the audio cue when someone pings a target, location, or warning."
L["GEMS_CVAR_SOUND_PINGVOL"] = "Ping Volume"
L["GEMS_CVAR_SOUND_PINGVOL_DESC"] = "Volume for ping audio cues (0.0-1.0)."
L["GEMS_CVAR_SOUND_LISTENER"] = "Listener At Character"
L["GEMS_CVAR_SOUND_LISTENER_DESC"] = "Place the audio listener at your character instead of the camera."
L["GEMS_CVAR_SOUND_LOWPASS"] = "Distance Filtering"
L["GEMS_CVAR_SOUND_LOWPASS_DESC"] = "Muffle sounds that are behind you or far away."
L["GEMS_CVAR_SOUND_MASTER_DESCLONG"] =
    "Master switch for all WoW audio output. On is the default and the right answer for almost every player. Turn Off if you want to play silent (during a stream where you have separate music, or to switch to Discord-only voice). Note: when Off, in-game UI ping sounds disappear too, including ready check and trade requests. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_SOUND_MASTERVOL_DESCLONG"] =
    "Overall game volume across every audio channel. EMS recommends 0.8 because at 1.0 the game audio sits at the same level as Discord, music apps, and OS notifications, which forces you to constantly rebalance them in Windows Volume Mixer. 0.8 gives voice chat and music headroom to sit above ambience without manual ducking on every raid pull. Lower it further if you stream and want game audio to clearly sit below your mic. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_SOUND_SFX_DESCLONG"] =
    "Combat sound effects channel: spell impacts, weapon swings, ability cast clicks, environmental SFX. Default 1.0 is correct for almost every player because SFX carries the audio cues you need for reactive play (interrupt windows, AoE markers, channelled-cast endings). Lower only if you find combat noise fatiguing during very long sessions. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_SOUND_MUSIC_DESCLONG"] =
    "Background music channel. EMS recommends 0.2 because at the Blizzard default 0.4 the soundtrack competes with combat SFX during raid mechanics -- you can miss a Sated cast bar because the zone music swell drowned the cue. 0.2 keeps the soundtrack as ambient mood without burying spell audio. Set to 0.0 if you prefer Spotify for background music. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_SOUND_AMBIENCE_DESCLONG"] =
    "Zone ambience channel: waterfalls, wind, crowd noise, weather. EMS recommends 0.3 because at the Blizzard default 0.6 zone ambience often sits louder than combat audio during raid mechanics, especially in outdoor encounters with weather sound layers. 0.3 keeps the zone atmosphere readable without competing with mechanic cues. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_SOUND_DIALOG_DESCLONG"] =
    "NPC dialogue and voice-over channel: questgiver speech, boss in-fight callouts, lore voice cues. Default 1.0 is correct because boss callouts often carry mechanic timing information you want clearly audible above music and ambience. Lower if you find quest-NPC chatter fatiguing during long levelling sessions. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_SOUND_BGAUDIO_DESCLONG"] =
    "Keeps WoW audio running when the game window is in the background (Alt-Tab to browser, Discord, Spotify). EMS recommends 1 because the Blizzard default 0 silences the game the moment you tab out, which means you can miss queue pops, raid pulls, AH bid wars, and group invites while reading a guide in another window. Set to 0 if you specifically want WoW quiet when not focused (streaming with shared audio devices, sharing the room with someone working). This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_SOUND_ENCWARN_DESCLONG"] =
    "In-game warning sounds for boss encounter callouts (the alarm tone that plays alongside a boss yell). Default 1 is correct because these sounds carry mechanic timing for fights where the visual on-screen text is easy to miss in raid chaos. Turn Off only if you use a third-party boss mod that plays its own warning audio and you want to avoid the doubled audio cue. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_SOUND_ENCVOL_DESCLONG"] =
    "Volume for the encounter warning sound channel above. Default 1.0 is the safe answer because boss warnings need to cut through music and combat SFX clearly. Lower only if you find the warning tone uncomfortably loud relative to the rest of the audio mix. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_SOUND_ERRSPEECH_DESCLONG"] =
    "Spoken error voice lines from your character (the cannot-do-that-yet and not-enough-rage style audio). EMS recommends 0 because the on-screen red text already tells you the same information, the voice lines get repetitive in a long session (you hear the same six clips dozens of times), and many players find them immersion-breaking. Set to 1 if you specifically like the auditory cue distinct from reading the red text. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_SOUND_GAMEPLAY_DESCLONG"] =
    "Gameplay-specific sound effects (separate from the SFXVolume channel) -- includes click feedback for action bar buttons and secondary UI sounds. Default 1 is correct because action bar clicks help confirm an input registered, especially during high-APM rotations. Turn Off only if you prefer fully silent action bar feedback. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_SOUND_NUMCHANNELS_DESCLONG"] =
    "How many sounds the client will play at the same time before it starts cutting some off. EMS recommends 128, the client maximum, because the default 64 runs out during raid pulls and busy M+ packs, and what gets cut tends to be a short combat cue rather than the music bed underneath it. The Combat Audio rows in this registry depend on those cues actually reaching you. Raising the ceiling costs a little memory and no meaningful CPU. Lower it toward the 20 minimum only if you are chasing an audio driver problem and want to rule out channel exhaustion. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_SOUND_PINGSOUNDS_DESCLONG"] =
    "The audio that goes with group ping markers (attack, warning, on my way, assist). Default 1 is correct because the sound is what makes a ping register when your eyes are on your action bars mid-rotation rather than on the ping itself. Turn Off if your group spams pings and the audio becomes noise, although dropping Ping Volume below and keeping the markers on screen is usually the better trade. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_SOUND_PINGVOL_DESCLONG"] =
    "Volume for the ping sounds above, on its own channel separate from SFX. Default 1.0 is the safe answer because a ping is a deliberate signal from another player and has to cut through combat audio to be worth anything. Lower it to around 0.5 if you play with a group that pings constantly and the full volume cue gets grating. Setting it to 0.0 leaves the markers visible with no audio, which is the same result as turning ping sounds off. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_SOUND_LISTENER_DESCLONG"] =
    "Decides where the game listens from when it places sound in 3D. Default 1 puts the listener on your character, so what you hear matches where you are standing. Set to 0 and the listener sits at the camera instead, which means zooming out moves your ears away from your body and a cast behind you can seem to come from somewhere else. EMS recommends 1 because positional audio only helps you react to things off screen if it agrees with your actual position. Players running a heavily zoomed out or top down camera sometimes prefer 0 for a wider soundstage. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_SOUND_LOWPASS_DESCLONG"] =
    "Applies a low pass filter so sounds coming from behind you or from a distance arrive duller than sounds in front and close. Blizzard exposes this as Distance Filtering in the Audio settings. Default 1 is correct because that filtering is what lets you tell front from back and near from far by ear, which is the entire value of positional audio during a pull. Set to 0 for a flatter mix where everything sounds equally present, which some players prefer for music and ambience but which costs you directional information in combat. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."

-- CVar Section: Floating Combat Text
L["GEMS_CVAR_FCT_ENABLE"] = "Floating Combat Text"
L["GEMS_CVAR_FCT_ENABLE_DESC"] =
    "Master toggle for floating combat text. Off by default! Enable to see damage/healing numbers."
L["GEMS_CVAR_FCT_DAMAGE"] = "Damage Numbers"
L["GEMS_CVAR_FCT_DAMAGE_DESC"] = "Show damage numbers on hostile targets."
L["GEMS_CVAR_FCT_AUTOS"] = "Auto-Attack Numbers"
L["GEMS_CVAR_FCT_AUTOS_DESC"] = "Show ALL auto-attack numbers (not just crits/procs)."
L["GEMS_CVAR_FCT_HEALING"] = "Healing Numbers"
L["GEMS_CVAR_FCT_HEALING_DESC"] = "Show healing numbers on targets."
L["GEMS_CVAR_FCT_ABSSELF"] = "Self Absorbs"
L["GEMS_CVAR_FCT_ABSSELF_DESC"] = "Show shield/absorb amounts applied to yourself."
L["GEMS_CVAR_FCT_ABSTARGET"] = "Target Absorbs"
L["GEMS_CVAR_FCT_ABSTARGET_DESC"] = "Show shield/absorb amounts applied to your target."
L["GEMS_CVAR_FCT_PERIODIC"] = "Periodic Damage"
L["GEMS_CVAR_FCT_PERIODIC_DESC"] = "Show DoT/HoT tick numbers."
L["GEMS_CVAR_FCT_DODGEMISS"] = "Dodge/Parry/Miss"
L["GEMS_CVAR_FCT_DODGEMISS_DESC"] = "Show dodge/parry/miss text. Useful for seeing when abilities are avoided."
L["GEMS_CVAR_FCT_LOWRES"] = "Low Resource Warning"
L["GEMS_CVAR_FCT_LOWRES_DESC"] = "Show low mana/health warnings."
L["GEMS_CVAR_FCT_FLOATMODE"] = "Float Direction"
L["GEMS_CVAR_FCT_FLOATMODE_DESC"] = "Float direction. 1=up, 2=down, 3=arc. 1 (up) is standard."
L["GEMS_CVAR_FCT_FLOATMODE_OPT_1"] = "Scroll Up"
L["GEMS_CVAR_FCT_FLOATMODE_OPT_2"] = "Scroll Down"
L["GEMS_CVAR_FCT_FLOATMODE_OPT_3"] = "Fountain"
L["GEMS_CVAR_FCT_FLOATMODE_DESCLONG"] =
    "Direction floating combat text travels from the engagement point. Scroll Up (1, recommended) rises from the target -- the long-standing default that players expect. Scroll Down (2) falls from the target -- some players prefer this for reduced overlap with target buffs above the unit. Fountain (3) arcs outward in a fountain pattern, a more visual style. All three values are documented Blizzard CVar settings; the in-engine fallback for any non-1/non-2 input is fountain."
L["GEMS_CVAR_FCT_DIRSCALE"] = "Directional Scale"
L["GEMS_CVAR_FCT_DIRSCALE_DESC"] = "Directional damage number movement scale. 0=no directional movement. 1.0=default."
L["GEMS_CVAR_FCT_PETMELEE"] = "Pet Melee Damage"
L["GEMS_CVAR_FCT_PETMELEE_DESC"] =
    "Show pet melee damage numbers. Important for pet-class macros (BM Hunter, Demo Warlock)."
L["GEMS_CVAR_FCT_PETSPELL"] = "Pet Spell Damage"
L["GEMS_CVAR_FCT_PETSPELL_DESC"] = "Show pet spell damage numbers."
L["GEMS_CVAR_FCT_REACTIVES"] = "Reactive Procs"
L["GEMS_CVAR_FCT_REACTIVES_DESC"] =
    "Show reactive ability procs (Overpower, Revenge). Helps spot procs macro sequences should react to."
L["GEMS_CVAR_FCT_ENERGY"] = "Energy Gains"
L["GEMS_CVAR_FCT_ENERGY_DESC"] = "Show energy/rage/mana gain numbers. Off by default -- can be very spammy."
L["GEMS_CVAR_FCT_AURAS"] = "Buff/Debuff Text"
L["GEMS_CVAR_FCT_AURAS_DESC"] = "Show buff/debuff application text. Off by default -- very spammy in group content."
L["GEMS_CVAR_FCT_HEALERS"] = "Healer Names"
L["GEMS_CVAR_FCT_HEALERS_DESC"] = "Show name of healer who healed you."

-- CVar Section: Accessibility
L["GEMS_CVAR_ACCESS_COLORBLIND"] = "Colourblind Mode"
L["GEMS_CVAR_ACCESS_COLORBLIND_DESC"] =
    "Colourblind mode. Adds colourblind-friendly text labels to tooltips and other interfaces."
L["GEMS_CVAR_ACCESS_CENTERED"] = "Keep Centred"
L["GEMS_CVAR_ACCESS_CENTERED_DESC"] =
    "Keep character head at screen centre as a motion reference point. Reduces motion sickness."
L["GEMS_CVAR_ACCESS_REDUCEMOVE"] = "Reduce Movement"
L["GEMS_CVAR_ACCESS_REDUCEMOVE_DESC"] =
    "Reduce automatic camera movement. Helps with motion sickness but can feel unresponsive."
L["GEMS_CVAR_ACCESS_FOCAL"] = "Focal Circle"
L["GEMS_CVAR_ACCESS_FOCAL_DESC"] = "Show a focal circle when mounted. Reduces motion sickness during fast movement."
L["GEMS_CVAR_ACCESS_TEXTCONTRAST"] = "Quest Text Contrast"
L["GEMS_CVAR_ACCESS_TEXTCONTRAST_DESC"] = "Increase text contrast in quest UIs. Helps with readability."
L["GEMS_CVAR_ACCESS_COLORBLIND_DESCLONG"] =
    "Enables colourblind accessibility features across the WoW UI. Default 0 (Off) is the safe baseline for non-colourblind players. Set to 1 if you have any form of colour vision deficiency -- this adds gold/silver/copper text labels next to coin icons, debuff type prefixes on aura tooltips, talent button icons that do not rely solely on colour, gem colour text in the socketing UI, mail error text without coin-colour indicators, and many other accessibility helpers. EMS does not auto-detect your accessibility needs; pick the value that matches your vision. (The Protanopia/Deuteranopia/Tritanopia screen filter is the separate Colourblind Filter row below.)"
L["GEMS_CVAR_ACCESS_CENTERED_DESCLONG"] =
    "Motion-sickness control: keeps your character's head fixed at the centre of the screen as a stable reference point, reducing the visual drift sensation during fast camera movement. Default 1 (On) is the right answer for almost every player because the stable head anchor helps with motion sickness during dragonriding, fast camera turns, and mounted travel. Set to 0 if you specifically prefer the unanchored cinematic camera and have no motion-sickness sensitivity."
L["GEMS_CVAR_ACCESS_REDUCEMOVE_DESCLONG"] =
    "Motion-sickness control: reduces camera movement that happens without your direct input (autocamera adjustments during combat, terrain bumps, ledge edges). Default 0 (Off) is the baseline because the autocamera adjustments are usually helpful for tracking action. Set to 1 if you experience motion sickness from camera-without-input movements -- this is often paired with CameraKeepCharacterCentered=1 for full motion-sickness accommodation."
L["GEMS_CVAR_ACCESS_FOCAL_DESCLONG"] =
    "Motion-sickness control: shows a small visual focal circle in the centre of your screen while mounted to give your eyes a fixed point to focus on. Default 0 (Off) is the baseline. Set to 1 if you experience motion sickness during mount travel or Skyriding flights -- a static focal point reduces the brain's confusion when the world rushes past."
L["GEMS_CVAR_ACCESS_TEXTCONTRAST_DESCLONG"] =
    "Increases the contrast of text in quest UI windows (questgiver dialogues, quest log details, objective tracker). Default 0 (Off) preserves the standard parchment-style appearance. Set to 1 if you find quest text difficult to read against the textured backgrounds -- the high-contrast mode darkens the parchment and brightens the text. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."

-- CVar Section: Dragonriding & Advanced Flying
L["GEMS_CVAR_DRAGON_DYNFOV"] = "Dynamic FOV"
L["GEMS_CVAR_DRAGON_DYNFOV_DESC"] =
    "Dynamic field-of-view based on gliding speed. Creates a sense of speed. Disable if motion sickness."
L["GEMS_CVAR_DRAGON_MAXPITCH"] = "Max Pitch Rate"
L["GEMS_CVAR_DRAGON_MAXPITCH_DESC"] =
    "Maximum pitch rate for keyboard dragonriding. Default 5 can feel sluggish. 6-7 is more responsive."
L["GEMS_CVAR_DRAGON_MAXTURN"] = "Max Turn Rate"
L["GEMS_CVAR_DRAGON_MAXTURN_DESC"] =
    "Maximum turn rate for keyboard dragonriding. Default 8 can feel slow. 10 improves manoeuvrability."
L["GEMS_CVAR_DRAGON_MINPITCH"] = "Min Pitch Rate"
L["GEMS_CVAR_DRAGON_MINPITCH_DESC"] =
    "Minimum pitch rate. Affects fine-grained pitch control. Slightly higher gives more precise control."
L["GEMS_CVAR_DRAGON_PITCHCTRL"] = "Pitch Control Mode"
L["GEMS_CVAR_DRAGON_PITCHCTRL_DESC"] =
    "How forward/back inputs affect pitch. 3=toggle. Most comfortable for keyboard players."
-- CVar Section: Dragonriding & Advanced Flying -- comfort toggles (2e)
L["GEMS_CVAR_DRAGON_NOFSFX"] = "Disable Full-Screen Flight Effects"
L["GEMS_CVAR_DRAGON_NOFSFX_DESC"] =
    "Turns off the full-screen speed blur and vignette during Skyriding. Unchecked by default; tick it if they bother you."
L["GEMS_CVAR_DRAGON_NOFSFX_DESCLONG"] =
    "The advanced-flying full-screen effects are the speed blur and edge vignette that wash across the screen while you Skyride at pace. This setting disables them: unchecked (the default) keeps the effects on, ticked turns them off. EMS recommends leaving it unchecked because the blur and vignette are part of the intended sense-of-speed feedback, but tick it if they trigger motion sickness or you want a cleaner view on long flights. This setting is saved account-wide, so it persists across sessions once you set it."
L["GEMS_CVAR_DRAGON_NOVELVFX"] = "Disable Flight Velocity Effects"
L["GEMS_CVAR_DRAGON_NOVELVFX_DESC"] =
    "Turns off the streaking speed-line particles during Skyriding. Unchecked by default; tick it for a calmer view."
L["GEMS_CVAR_DRAGON_NOVELVFX_DESCLONG"] =
    "The velocity VFX are the streaking speed-line particles that trail past the camera as your Skyriding speed climbs. This setting disables them: unchecked (the default) keeps them on, ticked turns them off. EMS recommends leaving it unchecked since the speed lines reinforce the feel of fast flight, but tick it if the particles distract you or add to motion discomfort. This setting is saved account-wide, so it persists across sessions once you set it."
L["GEMS_CVAR_DRAGON_LOOKAHEAD"] = "Dynamic Flight Look-Ahead"
L["GEMS_CVAR_DRAGON_LOOKAHEAD_DESC"] =
    "Leans the camera into your direction of travel for a more dynamic flight feel. Off by default."
L["GEMS_CVAR_DRAGON_LOOKAHEAD_DESCLONG"] =
    "When enabled, the game makes more dynamic attitude adjustments while you fly, leaning the view into your direction of travel so the horizon tilts with your manoeuvres. It is off by default. Turn it on for a livelier flight camera that leans with you; leave it off if you prefer a steady horizon or find the extra motion uncomfortable. This setting resets each session and does not persist across logouts; EMS re-applies your choice on every login."

-- Comparison Frame (v1.2.0 S04-B)
L["GEMS_IMPORT_COMPARE"] = "Compare"
L["GEMS_UI_COMPARE_WITH"] = "Compare with..."
L["GEMS_COMPARE_TITLE"] = "Sequence Comparison"
L["GEMS_COMPARE_LEFT_LABEL"] = "Existing"
L["GEMS_COMPARE_RIGHT_LABEL"] = "Incoming"
L["GEMS_COMPARE_STEPS"] = "%d steps"
L["GEMS_COMPARE_NO_STEPS"] = "No steps"
L["GEMS_COMPARE_CLOSE_DESC"] = "Close comparison view"

-- Sequence autocomplete (v1.2.0 S07b)
L["GEMS_AUTOCOMPLETE_SEQUENCES"] = "Sequences"
L["GEMS_AUTOCOMPLETE_CLICK_INSERT"] = "/click GRIPEMS_%s"

-- Popup Editor (v1.2.0 S07a)
L["GEMS_UI_OPEN_NEW_WINDOW"] = "Open in New Window"
L["GEMS_UI_POPUP_TITLE"] = "GRIP-EMS Editor"
L["GEMS_UI_POPUP_CLOSE_DIRTY"] = "This editor has unsaved changes.\nSave before closing?"
L["GEMS_UI_POPUP_MAX_REACHED"] = "You have hit the editor window limit (%d)."
L["GEMS_UI_POPUP_TREE_READONLY"] = "This sequence is built from an action tree. Edit its steps in the main editor."

-- Editor Colours (v1.2.0 S08a)
L["GEMS_SETTINGS_EDITOR_COLOURS"] = "Editor Colours"
L["GEMS_SETTINGS_SYNTAX_COMMAND"] = "Slash Commands"
L["GEMS_SETTINGS_SYNTAX_COMMAND_DESC"] = "The colour used for slash commands like /cast, /use, and /click."
L["GEMS_SETTINGS_SYNTAX_CONDITIONAL"] = "Conditionals"
L["GEMS_SETTINGS_SYNTAX_CONDITIONAL_DESC"] = "The colour used for macro conditions like [mod:shift] or [talent:X]."
L["GEMS_SETTINGS_SYNTAX_VARIABLE"] = "Variables"
L["GEMS_SETTINGS_SYNTAX_VARIABLE_DESC"] = "The colour used for macro sequence variables written as ~name~."
L["GEMS_SETTINGS_SYNTAX_COMMENT"] = "Comments"
L["GEMS_SETTINGS_SYNTAX_COMMENT_DESC"] = "The colour used for comment lines that start with two dashes."
L["GEMS_SETTINGS_SYNTAX_RESET"] = "Reset Conditions"
L["GEMS_SETTINGS_SYNTAX_RESET_DESC"] = "The colour used for reset rules like reset=target, reset=combat, or reset=5."
L["GEMS_SETTINGS_SYNTAX_NUMBER"] = "Numbers"
L["GEMS_SETTINGS_SYNTAX_NUMBER_DESC"] = "The colour used for numbers inside macro text."

-- Floating Menu (v1.2.0 S09a)
L["GEMS_FLOATING_HEADER"] = "Floating Menu"
L["GEMS_FLOATING_SHOW_DESC"] = "Show the floating quick-access menu on screen."
L["GEMS_FLOATING_DIRECTION_DESC"] = "Which direction the menu buttons open from the main button."
L["GEMS_FLOATING_LOCK_DESC"] = "Lock the floating menu in place so you cannot drag it."
L["GEMS_FLOATING_SCALE_DESC"] = "Change the overall size of the floating menu."
L["GEMS_FLOATING_LOCKED"] = "Floating menu locked."
L["GEMS_FLOATING_UNLOCKED"] = "Floating menu unlocked."
L["GEMS_FLOATING_BTN_SEQUENCES"] = "Sequences"
L["GEMS_FLOATING_BTN_IMPORT"] = "Import"
L["GEMS_FLOATING_BTN_EXPORT"] = "Export"
L["GEMS_FLOATING_BTN_VARIABLES"] = "Variables"
L["GEMS_FLOATING_BTN_TRACKER"] = "Tracker"
L["GEMS_FLOATING_BTN_OPTIONS"] = "Options"
L["GEMS_FLOATING_BTN_COLLAPSE"] = "Collapse"
L["GEMS_FLOATING_BTN_EXPAND"] = "Expand"
L["GEMS_FLOATING_BTN_CLOSE"] = "Close"
L["GEMS_FLOATING_DIR_UP"] = "Up"
L["GEMS_FLOATING_DIR_DOWN"] = "Down"
L["GEMS_FLOATING_DIR_LEFT"] = "Left"
L["GEMS_FLOATING_DIR_RIGHT"] = "Right"
L["GEMS_HELP_MENU"] = "  /gems menu - Toggle floating menu bar"

-- Support tab (v1.2.0 S10-B)
L["GEMS_SETTINGS_SUPPORT"] = "Support"
L["GEMS_SUPPORT_CREDITS"] = "Created by Sataana (MrSataana / JesperLive)"
L["GEMS_SUPPORT_DISCORD"] = "Discord: discord.gg/temptingus"
L["GEMS_SUPPORT_SYSTEM_HEADER"] = "System Info"
L["GEMS_SUPPORT_CREDITS_HEADER"] = "Credits"
L["GEMS_SUPPORT_DISCORD_HEADER"] = "Community"
L["GEMS_HELP_COMPRESS"] = "  /gems compress <name> - Encode sequence (dev)"
L["GEMS_HELP_DECOMPRESS"] = "  /gems decompress <string> - Decode string (dev)"

-- Remote Browser (v1.2.0 S13b)
L["GEMS_UI_REMOTE_BROWSER_TITLE"] = "Remote Macro Browser"
L["GEMS_UI_REMOTE_PLAYERS_HEADER"] = "Players with EMS"
L["GEMS_UI_REMOTE_REFRESH"] = "Refresh"
L["GEMS_UI_REMOTE_SEQUENCES_FROM"] = "Sequences from %s"
L["GEMS_UI_REMOTE_WAITING"] = "Waiting for response..."
L["GEMS_UI_REMOTE_NO_PLAYERS"] = "No EMS users found. Join a group to discover players."
L["GEMS_UI_REMOTE_NO_SEQUENCES"] = "No sequences available from this player."
L["GEMS_UI_REMOTE_IMPORT"] = "Import"
L["GEMS_UI_REMOTE_REQUEST_SENT"] = "Requested %s from %s"
L["GEMS_UI_REMOTE_LIST_RECEIVED"] = "Received sequence list from %s (%d sequences)"
L["GEMS_HELP_BROWSE"] = "  /gems browse - Open remote sequence browser"
L["GEMS_BROWSE_REFRESH_DESC"] = "Refresh the list of party members and their sequences"
L["GEMS_BROWSE_IMPORT_DESC"] = "Import this sequence to your library"
L["GEMS_BROWSE_CLOSE_DESC"] = "Close the browser"

-- Recorder
L["GEMS_UI_RECORD"] = "Record"
L["GEMS_UI_RECORDING"] = "Recording..."
L["GEMS_UI_RECORDING_COUNT"] = "Recording (%d)"
L["GEMS_RECORDER_MAX_REACHED"] = "Recording stopped: hit the step limit."
L["GEMS_RECORDER_STARTED"] = "Macro recorder: started."
L["GEMS_RECORDER_STOPPED"] = "Recording stopped: %d spells captured."
L["GEMS_RECORDER_UNAVAILABLE"] = "Macro recorder is not available."
L["GEMS_RECORDER_CREATE_CONFIRM"] = "Recording captured %d spells. Create a new sequence from this recording?"
L["GEMS_RECORDER_CREATE_YES"] = "Create Sequence"
L["GEMS_RECORDER_CREATE_NO"] = "Discard"
L["GEMS_RECORDER_EMPTY"] = "No spells were recorded."
L["GEMS_SETTINGS_RECORDER_HEADER"] = "Recorder"
L["GEMS_SETTINGS_RECORDER_DEDUP"] = "Combine repeated casts into one step"
L["GEMS_SETTINGS_RECORDER_DEDUP_DESC"] =
    "When turned on, the recorder joins back-to-back casts of the same spell into one step."

-- Spell Cache Viewer (v1.2.0 S16)
L["GEMS_SPELLCACHE_TITLE"] = "Spell Cache"
L["GEMS_SPELLCACHE_TAB_SPELLS"] = "Spells"
L["GEMS_SPELLCACHE_TAB_ITEMS"] = "Items"
L["GEMS_SPELLCACHE_TAB_TOYS"] = "Toys"
L["GEMS_SPELLCACHE_SEARCH"] = "Search..."
L["GEMS_SPELLCACHE_REFRESH"] = "Refresh"
L["GEMS_SPELLCACHE_CLEAR_OVERRIDES"] = "Clear Overrides"
L["GEMS_SPELLCACHE_CLEAR_CONFIRM"] = "Remove all spell name overrides? This cannot be undone."
L["GEMS_SPELLCACHE_SHOWING"] = "Showing %d of %d"
L["GEMS_SPELLCACHE_SCANNING"] = "Scanning..."
L["GEMS_SPELLCACHE_NOT_AVAILABLE"] = "Spell Cache viewer not available."
L["GEMS_SPELLCACHE_OVERRIDE_CLEARED"] = "Spell name overrides cleared."
L["GEMS_HELP_SPELLCACHE"] = "|cFF00CC66/gems spellcache|r -- Open spell cache viewer"
L["GEMS_HELP_MAPINFO"] = "|cFF00CC66/gems mapinfo|r -- Show current map/instance IDs"

-- Inline string localisation (v1.2.0 S22-D)
L["GEMS_UI_STUB_PREVIEW"] = "Macro Stub Preview"
L["GEMS_UI_EMPTY_HINT"] = "Import or create a sequence to get started"
L["GEMS_UI_KEYBIND_TOOLTIP"] = "Keybind: %s"

-- Vehicle / Pet Battle Keybinds (v1.2.0 S23)
L["GEMS_VEHICLE_KEYBINDS_HEADER"] = "Vehicle / Override Bar Keybinds"
L["GEMS_PET_BATTLE_KEYBINDS_HEADER"] = "Pet Battle Keybinds"
L["GEMS_VEHICLE_SLOT"] = "Slot %d"
L["GEMS_VEHICLE_KEYBINDS_APPLIED"] = "Vehicle keybinds applied: %d binding(s)"
L["GEMS_VEHICLE_KEYBINDS_CLEARED"] = "Vehicle keybinds cleared"
L["GEMS_PET_BATTLE_KEYBINDS_APPLIED"] = "Pet battle keybinds applied: %d binding(s)"
L["GEMS_PET_BATTLE_KEYBINDS_CLEARED"] = "Pet battle keybinds cleared"
L["GEMS_PET_BATTLE_ABILITY"] = "Ability %d"
L["GEMS_PET_BATTLE_SWAP"] = "Swap Pet"
L["GEMS_PET_BATTLE_PASS"] = "Pass Turn"
L["GEMS_PET_BATTLE_FORFEIT"] = "Forfeit"
L["GEMS_BAR_INTEGRATION_HEADER"] = "Action Bar Integration"
L["GEMS_BAR_INTEGRATION_DESC"] = "Show sequence icons on top of action bar buttons that hold a sequence."
L["GEMS_BAR_INTEGRATION_TRACKED"] = "Bar integration: %d buttons tracked (%s)"
L["GEMS_UI_NOT_BOUND"] = "Not bound"

-- Feature: Click Rate Diagnostics (/gems diag)
L["GEMS_DIAG_HEADER"] = "--- Execution Diagnostics ---"
L["GEMS_DIAG_CPS"] = "Real-time CPS: %.1f"
L["GEMS_DIAG_CONFIGURED"] = "Configured click rate: %dms (effective)"
L["GEMS_DIAG_TOTAL"] = "Total casts tracked: %d"
L["GEMS_DIAG_TRACER"] = "Tracer: %s"
L["GEMS_DIAG_TRACER_ON"] = "active"
L["GEMS_DIAG_TRACER_OFF"] = "inactive"
L["GEMS_DIAG_TOP_SPELLS"] = "Top spells:"
L["GEMS_DIAG_SPELL_ROW"] = "  %d. %s (ID: %d) -- %d casts"
L["GEMS_DIAG_NO_DATA"] = "No cast data yet. Use a sequence first."
L["GEMS_HELP_DIAG"] = "Show execution diagnostics (CPS, top spells)"
L["GEMS_HELP_MEMCHECK"] = "Memory diagnostics (GC, table sizes, heap)"
L["GEMS_HELP_PERF"] = "Performance profiling (OnUpdate, frames, timings)"
L["GEMS_HELP_MONITOR"] = "300-frame continuous profiler (hooks key functions)"

-- Feature: Optimal MS Advisor (/gems msadvisor)
L["GEMS_MSADVISOR_HEADER"] = "--- MS Advisor%s ---"
L["GEMS_MSADVISOR_GCD"] = "Base GCD: %dms (%.1f%% haste)"
L["GEMS_MSADVISOR_LAG"] = "World latency: %dms"
L["GEMS_MSADVISOR_SQW"] = "Spell Queue Window: %dms"
L["GEMS_MSADVISOR_RECOMMEND"] = "Recommended click rate: %dms"
L["GEMS_MSADVISOR_CURRENT"] = "Current configured: %dms"
L["GEMS_MSADVISOR_DELTA"] = "Delta: %+dms (%s)"
L["GEMS_MSADVISOR_FASTER"] = "you could click faster"
L["GEMS_MSADVISOR_SLOWER"] = "you are clicking faster than GCD allows"
L["GEMS_MSADVISOR_GOOD"] = "well-matched"
L["GEMS_MSADVISOR_ROTATION"] = "Sequence '%s': %d steps, full rotation ~%dms"
L["GEMS_MSADVISOR_NOT_FOUND"] = "Sequence '%s' not found."
L["GEMS_HELP_MSADVISOR"] = "Recommend optimal click rate based on haste"

-- Feature: Dormant Sequence Lazy Loading
L["GEMS_DORMANT_LOADED"] = "  %d sequence(s) loaded as dormant (different class)"
L["GEMS_DORMANT_LABEL"] = "(dormant)"
L["GEMS_HELP_LOADCLASS"] = "Activate dormant sequences for a class ID"
L["GEMS_HELP_REPAIR"] = "/gems repair <name> -- Analyse and repair a sequence"
L["GEMS_HELP_REPAIRALL"] = "/gems repairall -- Analyse and repair all sequences"
L["GEMS_HELP_RECORD"] = "/gems record -- Toggle the macro recorder (captures spells into a sequence)."
L["GEMS_HELP_TRACE"] = "/gems trace [on|off|status] -- Toggle the execution tracer."
L["GEMS_HELP_RESETUI"] = "/gems resetui -- Reset window to default size and position"
L["GEMS_RESETUI_DONE"] = "UI reset to default size and position."
L["GEMS_LOADCLASS_ALREADY"] = "Class %d sequences are already loaded."
L["GEMS_LOADCLASS_DONE"] = "Activated %d dormant sequence(s) for class %d."
L["GEMS_LOADCLASS_USAGE"] = "Usage: /gems loadclass <classID> (1=Warrior, 2=Paladin, ...)"
L["GEMS_UI_ACTIVATE"] = "Activate"

-- Feature: Raw Macrotext Import
L["GEMS_RAWIMPORT_DETECTED"] = "Found raw macro text. Parsing %d lines..."
L["GEMS_RAWIMPORT_RESULT"] = "Parsed %d steps from raw macro text."
L["GEMS_RAWIMPORT_NAME"] = "Imported Macro"
L["GEMS_RAWIMPORT_NO_SPELLS"] = "No castable lines found in pasted text."

-- Feature: Step Spell Picker
L["GEMS_SPELLPICKER_TITLE"] = "Spell Picker"
L["GEMS_SPELLPICKER_SEARCH"] = "Search spells..."
L["GEMS_SPELLPICKER_ALL"] = "All"
L["GEMS_SPELLPICKER_CLASS"] = "Class"
L["GEMS_SPELLPICKER_PET"] = "Pet Abilities"
L["GEMS_SPELLPICKER_ITEMS"] = "Items"
L["GEMS_SPELLPICKER_GEAR"] = "Gear"
L["GEMS_SPELLPICKER_CONSUMABLES"] = "Consumables"
L["GEMS_SPELLPICKER_TOYS"] = "Toys"
L["GEMS_SPELLPICKER_SPEC"] = "Spec"
L["GEMS_SPELLPICKER_RACE"] = "Race"
L["GEMS_SPELLPICKER_GENERAL"] = "General"
L["GEMS_SPELLPICKER_PROF"] = "Prof"
L["GEMS_SPELLPICKER_OTHER"] = "Other"
L["GEMS_SPELLPICKER_MOUNTS"] = "Mounts"
L["GEMS_SPELLPICKER_COMPANIONS"] = "Companions"
L["GEMS_SPELLPICKER_CONDITIONALS"] = "Conditionals"
L["GEMS_SPELLPICKER_CUSTOM"] = "Custom:"
L["GEMS_SPELLPICKER_INSERT"] = "Insert"
L["GEMS_SPELLPICKER_NO_RESULTS"] = "No matching spells"
L["GEMS_SPELLPICKER_FAVORITES"] = "Favourites"
L["GEMS_SPELLPICKER_WARBANK_NOTE"] = "Warbank items only visible at a banker"
L["GEMS_SPELLPICKER_MACROS"] = "Macros"
L["GEMS_SPELLPICKER_SLASH"] = "Slash"
L["GEMS_HELP_SPELLPICKER"] = "Click the icon button on any step to open the spell picker."

-- Feature: Gear-Aware Variables
L["GEMS_GEAR_VAR_HEADER"] = "Gear variables (auto-detected use-effects):"
L["GEMS_GEAR_VAR_ROW"] = "  ~%s~ = %s"
L["GEMS_GEAR_VAR_NONE"] = "No equipped use-effects detected."
L["GEMS_GEAR_VAR_UPDATED"] = "Gear variables updated (%d use-effects detected)."

-- Feature: CVar Profiles & Context-Aware Switching (Phase 2)
L["GEMS_CVAR_PROFILE_GENERAL"] = "General (Default)"
L["GEMS_CVAR_PROFILE_RAID"] = "Raid"
L["GEMS_CVAR_PROFILE_RAID_DESC"] = "Tuned for raid encounters: shorter nameplate range, stacked nameplate layout."
L["GEMS_CVAR_PROFILE_MPLUS"] = "Mythic+"
L["GEMS_CVAR_PROFILE_MPLUS_DESC"] = "Tuned for Mythic+ dungeons: enemy minion nameplates on, shorter range."
L["GEMS_CVAR_PROFILE_SOLO"] = "Solo / Open World"
L["GEMS_CVAR_PROFILE_SOLO_DESC"] = "Tuned for solo content: full visuals, wider interact arc, nameplates off."
L["GEMS_CVAR_PROFILE_DELVES"] = "Delves"
L["GEMS_CVAR_PROFILE_DELVES_DESC"] =
    "Tuned for Delves: enemy minion nameplates on, shorter nameplate range, wider interact arc."
L["GEMS_CVAR_PROFILE_PVP"] = "PvP"
L["GEMS_CVAR_PROFILE_PVP_DESC"] =
    "Tuned for PvP: friendly nameplates on, enemy minion nameplates on, stacked nameplate layout."
L["GEMS_CVAR_PROFILE_ACTIVE"] = "Active Profile: %s"
L["GEMS_CVAR_PROFILE_SELECT"] = "Select Profile"
L["GEMS_CVAR_PROFILE_AUTO"] = "Auto (context-aware)"
L["GEMS_CVAR_PROFILE_AUTOSWITCH"] = "Auto-switch by context"
L["GEMS_CVAR_PROFILE_AUTOSWITCH_DESC"] =
    "Switch CVar profile for you when you enter a raid, dungeon, PvP match, or the open world."
L["GEMS_CVAR_PROFILE_MANAGE"] = "Manage Profiles..."
L["GEMS_CVAR_PROFILE_MANAGE_DESC"] = "Create and manage custom CVar profiles with per-CVar overrides."
L["GEMS_CVAR_PROFILE_CREATE"] = "Create Profile"
L["GEMS_CVAR_PROFILE_CREATE_NAME"] = "Profile Name:"
L["GEMS_CVAR_PROFILE_CLONE_FROM"] = "Clone From:"
L["GEMS_CVAR_PROFILE_DELETE"] = "Delete Profile"
L["GEMS_CVAR_PROFILE_DELETE_CONFIRM"] = 'Delete custom profile "%s"? This cannot be undone.'
L["GEMS_CVAR_PROFILE_OVERRIDE"] = "Profile Override"
L["GEMS_CVAR_PROFILE_OVERRIDE_NONE"] = "No override (use General)"
L["GEMS_CVAR_PROFILE_ADD_OVERRIDE"] = "Add Override..."
L["GEMS_CVAR_PROFILE_SWITCHED"] = "CVar profile switched to: %s"
L["GEMS_CVAR_PROFILE_QUEUED"] = "%d secure CVars queued (applied out of combat)"
L["GEMS_CVAR_CHANGES_DETECTED"] = "%d CVars changed since last session"
L["GEMS_CVAR_CHANGES_INSESSION"] = "%d CVars changed in this session"
L["GEMS_CVAR_SESSION_NOTICE"] = "Announce in-session CVar changes"
L["GEMS_CVAR_SESSION_NOTICE_DESC"] =
    "When on, EMS prints a chat line for each CVar that changes during your session, with what changed it. Off by default; review them any time with /gems cvar changes."
L["GEMS_CVAR_NOTICE_TOGGLED"] = "CVar session notices: %s"
L["GEMS_CVAR_CHANGES_CAUSE_PATCH"] = "Likely: game patch reset"
L["GEMS_CVAR_CHANGES_CAUSE_ADDON"] = "Likely: changed by addon/UI"
L["GEMS_CVAR_CHANGES_CAUSE_AUTOFIX"] = "Auto-fixed by EMS"
L["GEMS_CVAR_CHANGES_CAUSE_PROFILE"] = "Profile swap"
L["GEMS_CVAR_CHANGES_CAUSE_UNKNOWN"] = "Changed since last session"
L["GEMS_CVAR_CHANGES_BULK_SUMMARY"] = "%d CVars %s -- open /gems options -> CVar Health to review"
L["GEMS_CVAR_PROFILE_NOT_FOUND"] = "Unknown profile: %s"
L["GEMS_CVAR_AUTO_TOGGLED"] = "CVar auto-switch: %s"
L["GEMS_CVAR_NO_CHANGES"] = "No CVar changes detected since last session"
L["GEMS_CVAR_PROFILE_RENAME"] = "Rename"
L["GEMS_CVAR_PROFILE_OVERRIDES"] = "Overrides (%d)"
L["GEMS_CVAR_PROFILE_NO_OVERRIDES"] = "No overrides"
L["GEMS_CVAR_PROFILE_TRIGGERED_BY"] = "Triggered by: %s"
L["GEMS_CVAR_PROFILE_TRIGGER_MANUAL"] = "Manual selection"
L["GEMS_CVAR_PROFILE_TRIGGER_AUTO"] = "Auto-switch (%s)"
L["GEMS_CVAR_PROFILE_TRIGGER_AUTO_NO_CONTEXT"] = "Auto-switch (no active context)"
L["GEMS_CVAR_PROFILE_TRIGGER_DISABLED"] = "Auto-switch off (last selection retained)"

-- Profile Diff (G19)
L["GEMS_CVAR_DIFF_TAB"] = "Compare Profiles"
L["GEMS_CVAR_DIFF_DESC"] =
    "Pick two profiles to see which CVars they override and where they differ. Colour codes: red means both profiles override the CVar with different values, yellow means only one profile overrides it, green means both override it with the same value."
L["GEMS_CVAR_DIFF_LEFT"] = "Left Profile"
L["GEMS_CVAR_DIFF_RIGHT"] = "Right Profile"
L["GEMS_CVAR_DIFF_SHOW_DIFFS_ONLY"] = "Show only differences"
L["GEMS_CVAR_DIFF_HEADER"] = "Comparing %s with %s:"
L["GEMS_CVAR_DIFF_NO_DIFFERENCES"] = "No overrides to compare. Pick two profiles with custom CVar values."
L["GEMS_CVAR_DIFF_LEFT_ONLY"] = "%s: %s | (none)"
L["GEMS_CVAR_DIFF_RIGHT_ONLY"] = "%s: (none) | %s"
L["GEMS_CVAR_DIFF_BOTH_DIFFER"] = "%s: %s | %s"
L["GEMS_CVAR_DIFF_BOTH_SAME"] = "%s: %s"

-- Profile Export/Import (G20)
L["GEMS_CVAR_PROFILE_EXPORT"] = "Export"
L["GEMS_CVAR_PROFILE_EXPORT_DESC"] =
    "Generate a paste-string for this profile. Share it with another character or another player to copy the override set."
L["GEMS_CVAR_PROFILE_EXPORT_RESULT"] =
    "Export string for %s. Press Ctrl+C to copy, then paste it into the Import box on another character."
L["GEMS_CVAR_PROFILE_EXPORT_ERROR_NOT_FOUND"] = "Profile not found."
L["GEMS_CVAR_PROFILE_IMPORT"] = "Import Profile"
L["GEMS_CVAR_PROFILE_IMPORT_DESC"] =
    "Paste an export string from another character to add it as a new custom profile here."
L["GEMS_CVAR_PROFILE_IMPORT_INPUT"] = "Paste export string"
L["GEMS_CVAR_PROFILE_IMPORT_LABEL"] = "New profile name (optional)"
L["GEMS_CVAR_PROFILE_IMPORT_LABEL_DESC"] =
    "Override the imported profile name. Leave blank to use the name embedded in the export string."
L["GEMS_CVAR_PROFILE_IMPORT_BUTTON"] = "Import"
L["GEMS_CVAR_PROFILE_IMPORT_SUCCESS"] = "GEMS: Imported profile %s with %d overrides."
L["GEMS_CVAR_PROFILE_IMPORT_ERROR"] = "GEMS: Import failed: %s"
L["GEMS_CVAR_PROFILE_IMPORT_ERROR_FORMAT"] = "Empty or invalid input."
L["GEMS_CVAR_PROFILE_IMPORT_ERROR_DECODE"] = "Decode failed -- not a GEMSCP1 export string."
L["GEMS_CVAR_PROFILE_IMPORT_ERROR_PAYLOAD"] = "Export payload is malformed or unsupported version."

L["GEMS_CVAR_MAP_HEADER"] = "Context Profile Map"
L["GEMS_CVAR_MAP_DESC"] = "Choose which CVar profile applies for each context"
L["GEMS_CVAR_MAP_DEFAULT"] = "Default (%s)"
L["GEMS_CVAR_MAP_NONE"] = "General (no profile)"

-- SQW Optimiser
L["GEMS_SQW_OPTIMIZER"] = "Dynamic SQW Optimiser"
L["GEMS_SQW_OPTIMIZER_LINK"] =
    "When enabled, this manages the SpellQueueWindow CVar in the Macro Sequencing section automatically."
L["GEMS_SQW_OPTIMIZER_DESC"] = "Set the Spell Queue Window (SQW) automatically based on your network lag."
L["GEMS_SQW_BUFFER"] = "Safety Buffer (ms)"
L["GEMS_SQW_BUFFER_DESC"] =
    "Extra time padding added to the Spell Queue Window (SQW). Higher values lose fewer presses; lower values feel more responsive. The suggested value is 100 milliseconds."
L["GEMS_SQW_LIVE"] = "SQW: %dms (latency: %dms + buffer: %dms)"
L["GEMS_SQW_ADVISORY"] = "Recommended click rate: %dms"
L["GEMS_SQW_ADVISORY_DETAIL"] = "GCD: %dms, SQW: %dms, Latency: %dms"
L["GEMS_SQW_ADVISORY_DELTA"] = "Your setting: %dms (%dms %s than the recommendation)"
L["GEMS_SQW_MANAGED"] = "Managed by SQW Optimiser"
L["GEMS_SQW_ENABLED"] = "SQW Optimiser enabled"
L["GEMS_SQW_DISABLED"] = "SQW Optimiser disabled (SQW reset to %d)"
L["GEMS_SQW_STATUS"] = "SQW: %dms | Latency: %dms | Buffer: %dms | Advisory: %dms"
L["GEMS_SQW_HISTORY_HEADER"] = "Latency trend"
L["GEMS_SQW_HISTORY_EMPTY"] = "No latency samples yet -- samples record while the optimiser runs."
L["GEMS_SQW_HISTORY_RANGE"] = "low %d / high %d ms"
L["GEMS_SQW_BUFFER_SET"] = "SQW buffer set to %dms"
L["GEMS_SQW_BUFFER_RANGE"] = "Buffer must be between 50 and 200"
L["GEMS_SQW_SLOWER"] = "slower"
L["GEMS_SQW_FASTER"] = "faster"

-- Faster, Slower (TempoAdvisor)
L["FS_CMD_HELP"] = "Usage: /gems fs [name] - Analyse sequence click rate"
L["FS_STATUS_HEADER"] = "Faster, Slower"
L["FS_COMPLEXITY_RELAXED"] = "Relaxed"
L["FS_COMPLEXITY_STANDARD"] = "Standard"
L["FS_COMPLEXITY_DEMANDING"] = "Demanding"
L["FS_COMPLEXITY_INTENSE"] = "Intense"
L["FS_CONFIDENCE_ESTIMATED"] = "Estimated"
L["FS_CONFIDENCE_PRECISE"] = "Precise"
L["FS_CONFIDENCE_CALIBRATED"] = "Calibrated"
L["FS_UNKNOWN_SPELLS"] = "%d unknown spells - using generic estimate"
L["FS_RECOMMENDED"] = "Recommended: %d ms (%d/sec)"
L["FS_COMPLEXITY"] = "Complexity: %s"
L["FS_NO_SEQUENCE"] = "No active sequence"
L["FS_NO_STEPS"] = "No steps to analyse"
L["FS_ANALYZING"] = "Analysing %s..."
L["FS_DEBUG_ON"] = "Faster, Slower debug enabled"
L["FS_DEBUG_OFF"] = "Faster, Slower debug disabled"
L["FS_HOLD_DEV"] = "Hold Mode is under development. See /gems fs for available commands."
L["FS_HOLD_RESET_DONE"] = "Hold mode off-GCD overrides reset. Re-checking now..."
L["FS_HOLD_DIAG_HEADER"] = "--- Hold Mode Diagnostics ---"
L["FS_HOLD_DIAG_STATE"] = "  active=%s  seq=%s  key=%s"
L["FS_HOLD_DIAG_BUTTON"] = "  button=%s  step=%s"
L["FS_HOLD_DIAG_CVAR"] = "  CVar held=%s  poll=%s"
L["FS_HOLD_DIAG_STEPS"] = "  compiled steps=%d"

-- Faster, Slower Phase 2: Settings + Auto-Set
L["FS_AUTO_SET"] = "Auto-adjust click rate per sequence"
L["FS_AUTO_SET_DESC"] = "Click rate adjusts for each sequence when you activate it."
L["FS_SPARKLINE"] = "Show CPS sparkline"
L["FS_ALERT_ENABLED"] = "Enable mismatch alerts"
L["FS_ALERT_VISUAL"] = "Visual alerts"
L["FS_ALERT_AUDIO"] = "Audio alerts"
L["FS_ALERT_SOUND_SLOW"] = "Slow alert sound"
L["FS_ALERT_SOUND_FAST"] = "Fast alert sound"
L["FS_ALERT_CHANNEL"] = "Audio channel"
L["FS_ALERT_TEST"] = "Test"
L["FS_ALERT_SLOW"] = "Slow threshold"
L["FS_ALERT_FAST"] = "Fast threshold"
L["FS_AUTO_LABEL"] = "Auto: %dms (%s)"
L["FS_MANUAL_OVERRIDE"] = "Manual Override"
L["FS_CLEAR_OVERRIDE"] = "Clear Override"
L["FS_OVERRIDE_SET"] = "Manual override set to %dms for %s"
L["FS_OVERRIDE_CLEARED"] = "Override cleared for %s"
L["FS_RATE_WILL_UPDATE"] = "Click rate will update when you leave combat"
L["FS_OVERLAY_TITLE"] = "Faster, Slower"
L["FS_OVERLAY_LOCKED"] = "Overlay locked"
L["FS_OVERLAY_UNLOCKED"] = "Overlay unlocked"
L["FS_OVERLAY_SHOWN"] = "Show click rate overlay"
L["FS_LDB_NO_SEQ"] = "-- /sec"
L["FS_LDB_SPAM"] = "%.1f/sec . %dms"
L["FS_LDB_HOLD"] = "Hold . %dms"
L["FS_ALERT_TOO_SLOW"] = "Clicking too slow!"
L["FS_ALERT_TOO_FAST"] = "Clicking too fast"
L["FS_HOLD_AUTOTUNED"] = "Auto-tuned . poll %dms"
L["FS_HOLD_CONFLICT"] = "Hold Mode conflicts with %s. Both addons manage hold-to-cast."
L["FS_HOLD_ACTIVATED"] = "Hold Mode activated for %s"
L["FS_HOLD_DEACTIVATED"] = "Hold Mode deactivated"
L["FS_HOLD_NO_BUTTON"] = "Hold Mode: native button not found"
L["FS_HOLD_NO_KEYBIND"] = "Hold Mode: No keybind assigned for '%s' -- assign one in the Keybind tab first."
L["FS_HOLD_ENABLED"] = "Enable Hold Mode"
L["FS_HOLD_ENABLED_DESC"] =
    "Hold your key instead of spamming it. EMS uses a native action button and tunes the repeat rate for you."
L["FS_HOLD_SLOT"] = "Native button slot"
L["FS_HOLD_SLOT_DESC"] =
    "Which native action bar button EMS will use (default: MultiBar7Button12 -- Bar 7, Slot 12). Leave this slot empty on your action bars."
L["FS_HOLD_POLL_MIN"] = "Minimum poll rate (ms)"
L["FS_HOLD_POLL_MIN_DESC"] =
    "Lower limit for the hold-poll rate. Smaller values are more responsive but may miss inputs."
L["FS_HOLD_NOTE"] =
    "Hold Mode uses an unused native button so you can hold a key to repeat. Turn it on per sequence in the Sequence Editor."
L["FS_HOLD_TOGGLED_ON"] = "Hold Mode enabled for %s"
L["FS_HOLD_TOGGLED_OFF"] = "Hold Mode disabled for %s"
L["FS_HOLD_SEQ_TOGGLE"] = "Hold Mode"
L["FS_HOLD_SEQ_TOGGLE_DESC"] =
    "Use hold-to-cast instead of spam clicking for this sequence. Requires Hold Mode enabled in Faster, Slower settings."
L["FS_TEMPO_JUST_RIGHT"] = "Just Right"
L["FS_TEMPO_FASTER"] = "Faster"
L["FS_TEMPO_FASTER_URGENT"] = "Faster!"
L["FS_ALERT_DISABLED"] = "Mismatch alerts disabled"
L["FS_ADJUSTED"] = "Adjusted recommendation based on your play data"
L["FS_WASTED_CLICKS"] = "%d of %d clicks/sec wasted"

-- Phase 4 item 21 Phase B per-element theming editor
L["ACCESS_THEMING_EDITOR_NAME"] = "Per-Element Theming"
L["ACCESS_THEMING_EDITOR_DESC"] = "Fine-tune colours, alpha, font, and size for each UI element class."
L["ACCESS_THEMING_SWATCH_ADVANCED"] = "Swatch"
L["ACCESS_THEMING_FIELD_BG"] = "Background colour"
L["ACCESS_THEMING_FIELD_BORDER"] = "Border colour"
L["ACCESS_THEMING_FIELD_TEXT"] = "Text colour"
L["ACCESS_THEMING_FIELD_ALPHA"] = "Alpha"
L["ACCESS_THEMING_FIELD_FONT"] = "Font"
L["ACCESS_THEMING_FIELD_FONT_DESC"] =
    "Picking a font here pins this text element to the chosen font and size, bypassing both Blizzard's UIFontSize CVar and EMS's UI scale. Other EMS text continues to scale with both."
L["ACCESS_THEMING_FIELD_SIZE"] = "Size"
L["ACCESS_THEMING_FIELD_BG_TEXTURE"] = "Background texture"
L["ACCESS_THEMING_FIELD_BG_TEXTURE_DESC"] = "Pick a tiled background image. Leave blank to keep the solid colour fill."
L["ACCESS_THEMING_FIELD_BORDER_TEXTURE"] = "Border texture"
L["ACCESS_THEMING_FIELD_BORDER_TEXTURE_DESC"] = "Pick a border style. Leave blank to keep the thin default border."
L["ACCESS_THEMING_RESET_CLASS"] = "Reset"
L["ACCESS_THEMING_RESET_CLASS_DESC"] = "Remove overrides for this element and fall back to the preset."
L["ACCESS_THEMING_GROUP_PANELS"] = "Panels"
L["ACCESS_THEMING_GROUP_OVERLAYS"] = "Overlays"
L["ACCESS_THEMING_GROUP_ROWS"] = "Rows"
L["ACCESS_THEMING_GROUP_BUTTONS"] = "Buttons"
L["ACCESS_THEMING_GROUP_TEXT"] = "Text"
L["ACCESS_THEMING_GROUP_EMPHASIS"] = "Emphasis"
L["ACCESS_THEMING_GROUP_GLOBAL"] = "Global"
L["ACCESS_THEMING_SLOTS_HEADER"] = "Saved Themes"
L["ACCESS_THEMING_SLOTS_DESC"] = "Save up to five themes and swap between them."
L["ACCESS_THEMING_SLOT_NAME"] = "Name"
L["ACCESS_THEMING_SLOT_SAVE"] = "Save"
L["ACCESS_THEMING_SLOT_LOAD"] = "Load"
L["ACCESS_THEMING_SLOT_RENAME"] = "Rename"
L["ACCESS_THEMING_SLOT_CLEAR"] = "Clear"
L["ACCESS_THEMING_SLOT_CLEAR_CONFIRM"] = "Clear this slot?"
L["ACCESS_THEMING_SLOT_EMPTY"] = "(empty)"
L["ACCESS_THEMING_SLOT_DEFAULT_NAME"] = "Theme %d"
L["ACCESS_THEMING_SLOT_OVERWRITE_CONFIRM"] = "Overwrite slot %d (%s)?"
L["ACCESS_THEMING_IMPORTEXPORT_HEADER"] = "Import / Export"
L["ACCESS_THEMING_EXPORT_LABEL"] = "Export"
L["ACCESS_THEMING_IMPORT_LABEL"] = "Import"
L["ACCESS_THEMING_IMPORT_APPLY"] = "Apply Import"
L["ACCESS_THEMING_IMPORT_OK"] = "Theme imported."
L["ACCESS_THEMING_IMPORT_FAIL"] = "Import failed"
L["ACCESS_THEMING_PRESET_HEADER"] = "Preset"
L["ACCESS_THEMING_PRESET_LABEL"] = "Preset"
L["ACCESS_THEMING_PRESET_DEFAULT"] = "Default"
L["ACCESS_THEMING_PRESET_HIGH_CONTRAST"] = "High Contrast"
L["ACCESS_THEMING_PRESET_CUSTOM"] = "Custom"
L["ACCESS_THEMING_RESET_ALL"] = "Reset All"
L["ACCESS_THEMING_RESET_ALL_DESC"] = "Clear every per-element override and restore the selected preset."
L["ACCESS_THEMING_RESET_ALL_CONFIRM"] = "Reset every theming override to defaults?"
L["ACCESS_THEMING_COPY_ALL_PROFILES"] = "Copy to All Profiles"
L["ACCESS_THEMING_COPY_ALL_PROFILES_DESC"] = "Apply the current theme to every EMS profile."
L["ACCESS_THEMING_COPY_ALL_CONFIRM"] = "Copy current theme to every profile?"
L["ACCESS_THEMING_FOOTER_HEADER"] = ""
L["ACCESS_THEMING_MODAL_TITLE"] = "GRIP-EMS Per-Element Theming"
L["ACCESS_THEMING_MODAL_DESC"] =
    "Customise every EMS panel, button, row, text, and overlay class. Changes apply live and save per profile."
L["ACCESS_THEMING_MODAL_COMBAT_BLOCKED"] = "Theme editor is hidden during combat."
L["ACCESS_THEMING_SLASH_HINT"] = "Open the per-element theming editor."
L["ACCESS_THEMING_CONTRAST_WARN_TITLE"] = "Contrast warning"
L["ACCESS_THEMING_CONTRAST_WARN_TEXT"] =
    "Text %s on %s is %.1f:1 (AA requires %.1f:1). Users with low vision may not read this."
L["ACCESS_THEMING_CONTRAST_WARN_UI"] = "UI %s against %s is %.1f:1 (3:1 required)."
L["ACCESS_THEMING_CONTRAST_LOW_ALPHA"] = "Low alpha: %s is %.2f (below 0.3, may be invisible)."
L["ACCESS_THEMING_CONTRAST_TEXTURE_UNKNOWN"] = "Contrast check disabled for %s -- %s uses a custom background texture."
L["ACCESS_THEMING_TEXTURE_MISSING"] = "EMS: theme texture '%s' is not available. Falling back to the default texture."
L["ACCESS_THEMING_CONTRAST_DISMISS"] = "Dismiss (30 min)"
L["ACCESS_THEMING_CONTRAST_AUTOFIX"] = "Auto-fix background"
L["ACCESS_THEMING_CONTRAST_BADGE_PASS"] = "|TInterface\\RAIDFRAME\\ReadyCheck-Ready:12:12|t"
L["ACCESS_THEMING_CONTRAST_BADGE_FAIL"] = "|TInterface\\RAIDFRAME\\ReadyCheck-NotReady:12:12|t"
L["ACCESS_THEMING_CONTRAST_QUEUE_MORE"] = "+%d more"
L["ACCESS_THEMING_CONTRAST_SILENCE_HEADER"] = "Silenced contrasts"
L["ACCESS_THEMING_CONTRAST_SILENCE_HEADER_BADGE"] = "Silenced contrasts (%d)"
L["ACCESS_THEMING_CONTRAST_SILENCE_EMPTY"] = "No contrast warnings are currently silenced."
L["ACCESS_THEMING_CONTRAST_SILENCE_REMAINING"] = "%s -- %d minutes remaining"
L["ACCESS_THEMING_CONTRAST_SILENCE_UNSILENCE"] = "Unsilence"
L["ACCESS_THEMING_CONTRAST_SILENCE_UNSILENCE_ALL"] = "Unsilence all"
L["ACCESS_THEMING_CONTRAST_SILENCE_UNSILENCE_ALL_CONFIRM"] =
    "Clear silence for all %d silenced classes? They will warn again on the next theme apply or /reload."
L["ACCESS_THEMING_CHATLINK_INSERT"] = "Insert chat link"
L["ACCESS_THEMING_CHATLINK_INSERT_DESC"] =
    "Insert a clickable theme link into the active chat edit box. The receiver clicks it to preview and apply."
L["ACCESS_THEMING_CHATLINK_NO_EDITBOX"] = "Open a chat edit box first, then click Insert chat link."
L["ACCESS_THEMING_CHATLINK_NO_RECEIVER"] = "%s does not have EMS installed."
L["ACCESS_THEMING_CHATLINK_OWN_LINK"] = "That is your own theme link. Share it with another player to send."
L["ACCESS_THEMING_CHATLINK_RECEIVE_PROMPT"] = "Accept theme from %s?"
L["ACCESS_THEMING_CHATLINK_TIMEOUT"] = "Theme transfer timed out."
L["ACCESS_THEMING_CHATLINK_VERSION_MISMATCH"] = "This theme is from a newer EMS version. Update EMS and try again."
L["ACCESS_THEMING_CHATLINK_DOS_BLOCK"] = "EMS: theme transfer rejected. Sender claimed too many chunks."
L["ACCESS_THEMING_CHATLINK_REALM_BLOCK"] = "EMS: theme link sender is on an unconnected realm. Click ignored."
L["ACCESS_THEMING_CHATLINK_RATE_LIMIT"] = "EMS: too many recent theme requests to that player. Try again in a moment."
L["ACCESS_THEMING_INSPECT_ENTER_HINT"] =
    "Inspect mode on. Hover any EMS frame to see its theme class. Press Escape to exit."
L["ACCESS_THEMING_INSPECT_NO_CLASS"] = "No EMS class on this frame."
L["ACCESS_THEMING_INSPECT_MODE_BUTTON"] = "Inspect mode"
L["ACCESS_THEMING_INSPECT_TOOLTIP_HINT"] = "Click a themed EMS frame to open the editor scrolled to that class."

-- Sound cues (item 14)
L["ACCESS_SOUND_SECTION_NAME"] = "Sound cues"
L["ACCESS_SOUND_SECTION_DESC"] =
    "Short audio cues for validation outcomes and sequence firing. Any sound registered with SharedMedia by other addons appears in the dropdowns below. Disabled by default."
L["ACCESS_SOUND_ENABLED_LABEL"] = "Enable sound cues"
L["ACCESS_SOUND_ENABLED_DESC"] =
    "Turn on to play short audio cues on validation errors, successes, info toasts, and sequence steps."
L["ACCESS_SOUND_CHANNEL_LABEL"] = "Sound channel"
L["ACCESS_SOUND_CHANNEL_DESC"] =
    "Which Blizzard audio channel plays the cues. Volume follows your in-game channel slider."
L["ACCESS_SOUND_CUE_ERROR_LABEL"] = "Error cue"
L["ACCESS_SOUND_CUE_ERROR_DESC"] = "Plays when something fails -- a bad import, a broken sequence, or an invalid spec."
L["ACCESS_SOUND_CUE_SUCCESS_LABEL"] = "Success cue"
L["ACCESS_SOUND_CUE_SUCCESS_DESC"] = "Plays on successful saves, imports, and validation passes."
L["ACCESS_SOUND_CUE_INFO_LABEL"] = "Info cue"
L["ACCESS_SOUND_CUE_INFO_DESC"] = "Plays on informational toasts -- first-run notices, checkpoint messages."
L["ACCESS_SOUND_CUE_STEP_LABEL"] = "Step cue"
L["ACCESS_SOUND_CUE_STEP_DESC"] =
    "Plays when a sequence advances to the next step. Capped at one play per half-second so fast sequences don't spam the audio."
L["ACCESS_SOUND_PREVIEW_LABEL"] = "Play"
L["ACCESS_SOUND_VISUAL_LABEL"] = "Visual flash for sound cues"
L["ACCESS_SOUND_VISUAL_DESC"] =
    "Show a brief central flash when a sound cue fires. Independent of the audio toggle, so Deaf and Hard-of-Hearing users can use the visual without the sound. The flash colour tells you which cue: red for error, green for success, cyan for info, gold for step-complete."
-- Per-cue Blizzard channel routing (Phase 4 item 22 Phase 2)
L["ACCESS_SOUND_CHANNEL_PER_CUE_DESC"] =
    "Pick a Blizzard audio channel for this specific cue. Volume follows the channel slider in WoW Sound options."
L["ACCESS_SOUND_CHANNEL_ERROR_LABEL"] = "Error channel"
L["ACCESS_SOUND_CHANNEL_SUCCESS_LABEL"] = "Success channel"
L["ACCESS_SOUND_CHANNEL_INFO_LABEL"] = "Info channel"
L["ACCESS_SOUND_CHANNEL_STEP_LABEL"] = "Step channel"

-- Cursor overlay (item 15)
L["ACCESS_CURSOR_SECTION_NAME"] = "Cursor overlay"
L["ACCESS_CURSOR_SECTION_DESC"] =
    "Draws a coloured ring or crosshair around the mouse cursor so it is easier to find. Colour follows the active contrast preset."
L["ACCESS_CURSOR_ENABLED_LABEL"] = "Enable cursor overlay"
L["ACCESS_CURSOR_ENABLED_DESC"] = "Turn the cursor overlay on or off."
L["ACCESS_CURSOR_MODE_LABEL"] = "Overlay shape"
L["ACCESS_CURSOR_MODE_DESC"] = "Pick ring or crosshair."
L["ACCESS_CURSOR_MODE_RING"] = "Ring"
L["ACCESS_CURSOR_MODE_CROSSHAIR"] = "Crosshair"
L["ACCESS_CURSOR_SIZE_LABEL"] = "Overlay size"
L["ACCESS_CURSOR_SIZE_DESC"] = "Pick 1x, 1.5x, or 2x the default size."
L["ACCESS_CURSOR_SIZE_1X"] = "1x"
L["ACCESS_CURSOR_SIZE_15X"] = "1.5x"
L["ACCESS_CURSOR_SIZE_2X"] = "2x"
L["ACCESS_CURSOR_COLOR_INFO"] = "The overlay colour follows the focus-ring colour of the active contrast preset."

-- Feedback and accessibility resources (item 17 / A11Y-DEFER-16)
L["ACCESS_FEEDBACK_SECTION_NAME"] = "Accessibility resources and feedback"
L["ACCESS_FEEDBACK_SECTION_DESC"] =
    "Links to accessibility standards, a WoW community memorial, and the place to report issues or share feedback."
L["ACCESS_FEEDBACK_APX_LABEL"] = "AbleGamers APX"
L["ACCESS_FEEDBACK_APX_DESC"] = "AbleGamers Accessible Player Experiences framework. Opens a copyable link."
L["ACCESS_FEEDBACK_GAG_LABEL"] = "Game Accessibility Guidelines"
L["ACCESS_FEEDBACK_GAG_DESC"] = "Community framework for making games accessible. Opens a copyable link."
L["ACCESS_FEEDBACK_IBELIN_LABEL"] = "In memory of Ibelin"
L["ACCESS_FEEDBACK_IBELIN_DESC"] =
    "Mats Steen 1989-2014. Tribute site for the WoW player whose story reframed what this game can mean. Opens a copyable link."
L["ACCESS_FEEDBACK_DISCORD_LABEL"] = "Report an accessibility issue"
L["ACCESS_FEEDBACK_DISCORD_DESC"] =
    "Opens a copyable link to the GRIP Discord, where you can report accessibility issues or share feedback."
L["ACCESS_FEEDBACK_POPUP_TEXT"] = "Copy this link to open in your browser:"
L["ACCESS_GUIDE_SECTION_NAME"] = "Accessibility Guide"
L["ACCESS_GUIDE_SECTION_DESC"] =
    "The full accessibility documentation is in ACCESSIBILITY.md at the addon root. The Interactive Guide has a summary online under the Accessibility section."
L["ACCESS_GUIDE_BUTTON_LABEL"] = "Open Interactive Guide"
L["ACCESS_GUIDE_BUTTON_DESC"] = "Opens a popup that shows the Interactive Guide link so you can copy it with Ctrl+C."

-- Large-target density (item 16 / A11Y-DEFER-14)
L["ACCESS_DENSITY_SECTION_NAME"] = "Large interactive targets"
L["ACCESS_DENSITY_SECTION_DESC"] =
    "Makes clickable targets like buttons, checkboxes, and tabs easier to click. Grows the click area to the WCAG 2.5.5 minimum of 44 by 44 pixels without changing visual size."
L["ACCESS_DENSITY_TOGGLE_LABEL"] = "Enlarge click areas"
L["ACCESS_DENSITY_TOGGLE_DESC"] =
    "Grows the click area of tabs, checkboxes, and dialogue buttons. Visual size stays the same. Applies immediately to open windows."
L["ACCESS_DENSITY_RELOAD_HINT"] =
    "The click-area boost applies immediately. Some sequence-editor rows only pick up changes after you close and reopen the editor."

-- Simplified Mode (item 18 / A11Y-DEFER-17)
L["ACCESS_SIMPLIFIED_SECTION_NAME"] = "Simplified Mode"
L["ACCESS_SIMPLIFIED_SECTION_DESC"] =
    "Collapses the editor to a minimal surface for switch, eye tracker, and single-button users."
L["ACCESS_SIMPLIFIED_TOGGLE_LABEL"] = "Enable Simplified Mode"
L["ACCESS_SIMPLIFIED_TOGGLE_DESC"] =
    "Reduces the editor to four Tab-reachable controls -- the steps tab, the action bar, the title bar, and a run button. Best with Large density and UI Scale 1.25 or higher."
L["ACCESS_SIMPLIFIED_DELAY_LABEL"] = "Post-acceptance delay (ms)"
L["ACCESS_SIMPLIFIED_DELAY_DESC"] =
    "Cool-down between activations. 500 ms matches Game Accessibility Guidelines Motor Advanced. Raise for stronger tremor or switch bounce."
L["ACCESS_SIMPLIFIED_FIRST_ENABLE_HINT"] =
    "Simplified Mode is active. Use Tab, Shift+Tab, Enter, Space, and Escape to navigate."
L["ACCESS_SIMPLIFIED_RELOAD_HINT"] = "Simplified Mode applied. For best results, type /reload after toggling."
L["ACCESS_SIMPLIFIED_DENSITY_REJECT"] = "Simplified Mode requires Large targets. Turn off Simplified Mode first."
L["ACCESS_SIMPLIFIED_SCALE_REJECT"] =
    "Simplified Mode requires UI Scale 1.25 or higher. Turn off Simplified Mode to go lower."
L["ACCESS_SIMPLIFIED_UNLOCK_BUTTON"] = "Unlock editor"
L["ACCESS_SIMPLIFIED_RUN_BUTTON"] = "Run sequence"

-- Phase G.7 (G23): ReloadGate
L["RELOAD_GATE_POPUP_TITLE"] = "EMS - reload to fully apply"
L["RELOAD_GATE_POPUP_BODY"] =
    "%d setting changes applied in %d actions. Reload now for changes to fully take effect, or continue without reloading.\n\n%s"
L["RELOAD_GATE_RELOAD_NOW"] = "Reload Now"
L["RELOAD_GATE_LATER"] = "Later"
L["RELOAD_GATE_TOOLTIP_TITLE"] = "EMS - pending changes"
L["RELOAD_GATE_TOOLTIP_NONE"] = "No pending changes."
L["RELOAD_GATE_TOOLTIP_HINT"] = "Click for details"
L["RELOAD_GATE_CAUSE_AUTOFIX"] = "Auto-fix on login"
L["RELOAD_GATE_CAUSE_FIX_ALL_CRIT"] = "Fix All Critical"
L["RELOAD_GATE_CAUSE_FIX_ALL_SEC"] = "Fix All in Section"
L["RELOAD_GATE_CAUSE_PER_ROW_FIX"] = "Fix individual setting"
L["RELOAD_GATE_CAUSE_PER_ROW_SET"] = "Set custom value"
L["RELOAD_GATE_CAUSE_RESET_DEFS"] = "Reset to Defaults"
L["RELOAD_GATE_CAUSE_PROFILE_SWP"] = "Profile swap"
L["RELOAD_GATE_CAUSE_PROFILE_IMP"] = "Profile import"
L["RELOAD_GATE_CAUSE_OOC_QUEUED"] = "Queued (combat)"
L["RELOAD_GATE_CAUSE_OOC_APPLIED"] = "Applied (post-combat)"

-- G8-AUDIT-04 / -10 / -14 / -19 / -27 / -36 / -50 (G.8c.2 TTS coverage)
-- These strings are spoken aloud by TTS and emitted to chat. Plain
-- language only. No marketing tone. No em dashes. Short sentences.
L["ACCESS_ANNOUNCE_RELOAD_PENDING"] = "Reload pending"
L["ACCESS_ANNOUNCE_S18_EXPORT_READY"] = "Export ready for %s. Press Control C to copy."
L["ACCESS_ANNOUNCE_S18_IMPORT_OK"] = "Profile imported as %s. %d settings."
L["ACCESS_ANNOUNCE_S18_IMPORT_ERROR"] = "Import failed. %s"
L["ACCESS_ANNOUNCE_S18_DELETE_CONFIRM"] = "Delete %s? Confirm or cancel."
L["ACCESS_ANNOUNCE_CVAR_FIX"] = "Fixed %s to %s"
L["ACCESS_ANNOUNCE_CVAR_SET"] = "%s set to %s"
L["ACCESS_ANNOUNCE_CVAR_UNDO"] = "%s reverted to %s"
L["ACCESS_ANNOUNCE_CVAR_REDO"] = "%s reapplied to %s"
L["ACCESS_ANNOUNCE_CVAR_PIN_ON"] = "%s pinned"
L["ACCESS_ANNOUNCE_CVAR_PIN_OFF"] = "%s unpinned"
L["ACCESS_ANNOUNCE_CVAR_AUTOFIX_ON"] = "Auto-fix on for %s"
L["ACCESS_ANNOUNCE_CVAR_AUTOFIX_OFF"] = "Auto-fix off for %s"
L["ACCESS_ANNOUNCE_CVAR_FIXALL_BUSY"] = "Fixing %d settings"
L["ACCESS_ANNOUNCE_CVAR_FIXALL_DONE"] = "Fixed %d settings"
L["ACCESS_ANNOUNCE_TOGGLE_REDUCE_MOTION_ON"] = "Reduce motion on"
L["ACCESS_ANNOUNCE_TOGGLE_REDUCE_MOTION_OFF"] = "Reduce motion off"
L["ACCESS_ANNOUNCE_TOGGLE_FLICKER_SAFE_ON"] = "Flicker-safe mode on"
L["ACCESS_ANNOUNCE_TOGGLE_FLICKER_SAFE_OFF"] = "Flicker-safe mode off"
L["ACCESS_ANNOUNCE_TOGGLE_SPEECH_ENABLED_ON"] = "Speech on"
L["ACCESS_ANNOUNCE_TOGGLE_SPEECH_ENABLED_OFF"] = "Speech off"
L["ACCESS_ANNOUNCE_TOGGLE_CHAT_EMITTER_ON"] = "Chat emit on"
L["ACCESS_ANNOUNCE_TOGGLE_CHAT_EMITTER_OFF"] = "Chat emit off"
L["ACCESS_ANNOUNCE_SIMPLIFIED_RUN"] = "Running %s"
L["ACCESS_ANNOUNCE_SIMPLIFIED_UNLOCKED"] = "Editing unlocked"
L["ACCESS_ANNOUNCE_SIMPLIFIED_LOCKED"] = "Editing locked"
L["ACCESS_ANNOUNCE_SIMPLIFIED_CLOSED"] = "Window closed"
-- G.9: cvarHealth numbered-key + skip-to-issues nav announcements.
L["ACCESS_ANNOUNCE_SECTION_JUMP"] = "Section %d of %d: %s"
L["ACCESS_ANNOUNCE_ISSUE_JUMP"] = "Issue %d of %d: %s"

-- v2.1.0 Authorship Integrity (Phase A): Original Author lock + provenance display.
-- Branding-rule note: legacy-format provenance strings avoid the source-sequencer
-- name; the key suffix is internal-only and follows the existing schema.
L["GEMS_AUTHOR_LOCKED_TOOLTIP"] =
    "Original Author is set on creation and cannot be changed. Use Fork to create your own version."
L["GEMS_AUTHOR_ORIGINAL_LABEL"] = "Original Author"
L["GEMS_AUTHOR_LAST_MODIFIED_LABEL"] = "Last modified by"
L["GEMS_AUTHOR_CREATED_AT"] = "Created"
L["GEMS_AUTHOR_LAST_MODIFIED_VALUE"] = "%s on %s"
L["GEMS_PROVENANCE_UNKNOWN"] = "Provenance unknown"
L["GEMS_PROVENANCE_UNKNOWN_TOOLTIP"] =
    "No signature on file. Sequence predates v2.1.0 or was imported from a source without provenance."
L["GEMS_PROVENANCE_LEGACY_IMPORT"] = "Legacy import"
L["GEMS_PROVENANCE_LEGACY_IMPORT_TOOLTIP"] = "Imported from a legacy format. Original author: %s (unverified)."
L["GEMS_PROVENANCE_FORGE_IMPORT"] = "Forge import"
L["GEMS_PROVENANCE_FORGE_IMPORT_TOOLTIP"] = "Built with GRIP Forge. Attribution: %s (unverified)."

-- v2.1.0 Authorship Integrity (Phase B): SHA-256 signature verification states.
L["GEMS_PROVENANCE_VERIFIED"] = "Verified"
L["GEMS_PROVENANCE_VERIFIED_TOOLTIP"] = "Signature matches. This is the unmodified original."
L["GEMS_PROVENANCE_MODIFIED"] = "Modified"
L["GEMS_PROVENANCE_MODIFIED_TOOLTIP"] = "Original signature intact. Modifier chain has %d entries."
L["GEMS_PROVENANCE_TAMPERED"] = "Tampered"
L["GEMS_PROVENANCE_TAMPERED_TOOLTIP"] = "Signature mismatch. Provenance fields may have been edited outside the addon."
L["GEMS_PROVENANCE_DAMAGED"] = "Damaged"
L["GEMS_PROVENANCE_DAMAGED_TOOLTIP"] =
    "Provenance fields present but signature missing. SavedVariables file may be partially corrupted."
L["GEMS_PROVENANCE_FORKED_BADGE"] = "Forked"
L["GEMS_PROVENANCE_FORKED_TOOLTIP"] = "This sequence was forked from another author. See chain for details."
L["GEMS_AUTHOR_MODIFIER_CHAIN_HEADER"] = "Modification chain"

-- v2.1.0 Authorship Integrity (Phase C): Fork mechanism + tampered-import gate.
L["GEMS_FORK_BUTTON"] = "Fork"
L["GEMS_FORK_TOOLTIP"] =
    "Create a new sequence based on this one, with you as the Original Author. The original sequence is unchanged."
L["GEMS_FORK_DIALOG_TITLE"] = "Fork sequence"
L["GEMS_FORK_DIALOG_BODY"] =
    "Forking '%s' creates a new sequence with you as the Original Author. Enter a name for the fork:"
L["GEMS_FORK_CONFIRM"] = "Fork '%s' as a new sequence?"
L["GEMS_PROVENANCE_SHOW_ALL_CHAIN"] = "Show all (%d)"

-- v2.1.0 Authorship Integrity (Phase C polish): multi-hop fork lineage in
-- the SequenceEditor metadata pane and the import-preview chain frame.
L["GEMS_AUTHOR_FORKED_FROM_LABEL"] = "Forked from"
L["GEMS_AUTHOR_FORKED_FROM_VALUE"] = "%s on %s"
L["GEMS_AUTHOR_FORKED_FROM_CHAIN_TRUNCATE"] = "(+%d more)"
L["GEMS_AUTHOR_FORK_LINEAGE_HEADER"] = "Fork lineage"

-- v2.1.0 Authorship Integrity (Phase D): privacy modes (public, pseudonymous,
-- private) wired through Settings panel + per-sequence dropdown + export
-- pipeline scrub. See research doc Section 5.4.
L["GEMS_PRIVACY_GROUP_NAME"] = "Authorship Privacy"
L["GEMS_PRIVACY_MODE_LABEL"] = "Privacy mode"
L["GEMS_PRIVACY_MODE_PUBLIC"] = "Public"
L["GEMS_PRIVACY_MODE_PSEUDONYMOUS"] = "Pseudonymous"
L["GEMS_PRIVACY_MODE_PRIVATE"] = "Private"
L["GEMS_PRIVACY_DEFAULT_LABEL"] = "Default privacy mode for new sequences"
L["GEMS_PRIVACY_DEFAULT_DESC"] = "New sequences inherit this privacy mode unless overridden per-sequence."
L["GEMS_PRIVACY_PSEUDONYM_LABEL"] = "Pseudonym"
L["GEMS_PRIVACY_PSEUDONYM_DESC"] =
    "Display name used in pseudonymous-mode exports. Identity hash is preserved so receivers can link sequences from the same author."
L["GEMS_PRIVACY_SHOW_BADGES_LABEL"] = "Show provenance badges in sequence list"
L["GEMS_PRIVACY_SHOW_BADGES_DESC"] = "Render the small verification badge next to each sequence row."

-- ===========================================================================
-- L372 Wave 10a+10b: 14 CVar option labels + descLong (2026-05-19)
-- ===========================================================================

L["GEMS_CVAR_COMBAT_SOFTENEMY_OPT_0"] = "Off"
L["GEMS_CVAR_COMBAT_SOFTENEMY_OPT_1"] = "Gamepad only"
L["GEMS_CVAR_COMBAT_SOFTENEMY_OPT_2"] = "Mouse and keyboard only"
L["GEMS_CVAR_COMBAT_SOFTENEMY_OPT_3"] = "Always (gamepad and KBM)"
L["GEMS_CVAR_COMBAT_SOFTENEMY_DESCLONG"] =
    "Sets the soft-target highlight for enemies -- the ghosted unit frame that appears when you face an enemy without clicking it. Off disables it. Gamepad only lights it up when a controller is bound. Mouse and keyboard only restricts it to KBM input, an unusual pick. Always (the EMS recommendation) shows it for both input modes, which gives KBM players the same on-the-fly target hint controller players already get."

L["GEMS_CVAR_COMBAT_SOFTFRIEND_OPT_2"] = "Mouse and keyboard only"
L["GEMS_CVAR_COMBAT_SOFTFRIEND_OPT_3"] = "Always (gamepad and KBM)"

L["GEMS_CVAR_SOLO_INTERACT_OPT_0"] = "Off"
L["GEMS_CVAR_SOLO_INTERACT_OPT_1"] = "Gamepad only"
L["GEMS_CVAR_SOLO_INTERACT_OPT_2"] = "Mouse and keyboard only"
L["GEMS_CVAR_SOLO_INTERACT_OPT_3"] = "Always (gamepad and KBM)"
L["GEMS_CVAR_SOLO_INTERACT_DESCLONG"] =
    "Sets the soft-target highlight for interactable objects -- NPCs, mailboxes, ore nodes, herbs, quest items. Off disables it. Gamepad only lights up the nearest interactable when a controller is bound. Mouse and keyboard only restricts it to KBM input. Always (the EMS recommendation) shows it for both input modes, which keeps controller and KBM behaviour the same and helps you spot quest objects you might otherwise click past."

L["GEMS_CVAR_RAIDING_THREATWARN_OPT_0"] = "Off"
L["GEMS_CVAR_RAIDING_THREATWARN_OPT_1"] = "Progressive (warning text)"
L["GEMS_CVAR_RAIDING_THREATWARN_OPT_2"] = "Flashing health bar"
L["GEMS_CVAR_RAIDING_THREATWARN_OPT_3"] = "Tinted health bar"
L["GEMS_CVAR_RAIDING_THREATWARN_DESCLONG"] =
    "Sets how nameplates warn you about threat. Off hides the warning entirely. Progressive shows a warning text overlay when your threat ramps. Flashing health bar pulses the nameplate red as a strong visual cue. Tinted health bar (the default, and the EMS recommendation) tints the nameplate fill from yellow through orange to red as your threat percentage climbs -- the same data as flashing but at a glance, without the eye strain."

L["GEMS_CVAR_RAIDING_DISPTYPE_OPT_0"] = "Hidden"
L["GEMS_CVAR_RAIDING_DISPTYPE_OPT_1"] = "Only ones I can dispel"
L["GEMS_CVAR_RAIDING_DISPTYPE_OPT_2"] = "All dispellable debuffs"
L["GEMS_CVAR_RAIDING_DISPTYPE_DESCLONG"] =
    "Sets which dispellable debuffs show on raid frames. Hidden suppresses the indicator entirely. Only ones I can dispel filters to the debuff types your spec can actually remove, which is the cleanest look for non-healer roles. All dispellable debuffs (the default, and the EMS recommendation) shows everything someone in the group could remove, which is what healers want so they can see which categories their off-healers should be covering."

L["GEMS_CVAR_COMBAT_SOFTLOCKED_DESCLONG"] =
    "Controls whether the soft-target overlay stays visible while you have a hard target locked. Off suppresses the soft overlay when something is locked, reducing visual noise. On (the default, and the EMS recommendation) keeps the soft-target ghost visible alongside your locked target, which is what you usually want for fast target swaps without re-acquiring."

L["GEMS_CVAR_COMBAT_SOFTMATCH_DESCLONG"] =
    "Controls how the soft-target picks a candidate when you already have a hard target locked. Off lets the soft target choose freely based on your aim cone. On (the default, and the EMS recommendation) biases the soft target towards whatever you have locked, which keeps your soft and hard targets aligned for actions that prefer the hard target while leaving room to glance at others nearby."

L["GEMS_CVAR_COMBAT_SOFTRANGE_DESCLONG"] =
    "Sets the maximum distance for the enemy soft-target pick. Lower values keep the soft target focused on the closest enemies and ignore distant mobs you cannot reach. 45 yards (the default, and the EMS recommendation) matches the standard spell range for most ranged DPS specs, so soft target picks the same mobs your finishers can actually hit. Raise it for hunters or balance druids who want to acquire targets at long range; lower it for melee specs who do not want to lock onto far-away mobs."

L["GEMS_CVAR_COMBAT_FRIENDRANGE_DESCLONG"] =
    "Sets the maximum distance for the friendly soft-target pick. Lower values keep the soft target on nearby allies; higher values let the soft target reach distant party members. 45 yards (the default, and the EMS recommendation) matches the standard heal range, which is the most useful value for healers who lean on soft targeting. Raise it for druids or priests with longer-range heals; drop it for melee healers who only care about the immediate group cluster."

L["GEMS_CVAR_SOLO_INTERRANGE_DESCLONG"] =
    "Sets the maximum distance the soft-target picker uses for interactable objects -- ore nodes, herbs, mailboxes, NPCs, quest items. 10 yards (the default, and the EMS recommendation) matches the actual interact range the game enforces, so the soft target only lights up when you can actually reach the object. Raising it gives you an earlier visual hint that something is nearby but you still need to walk into actual interact range to use it; useful for quest hubs or gathering zones where you want a heads-up. Lower it if soft targeting is grabbing too many objects in dense areas."

L["GEMS_CVAR_COMBAT_PROCOPACITY_DESCLONG"] =
    "Sets the opacity of the spell-activation glow -- the coloured aura that lights up around your action bars when a proc is ready (Tidal Waves, Hot Streak, Spotlight, and so on). 65% (the default, and the EMS recommendation) is bright enough to catch your eye without overpowering the action-bar icons. Lower it if the glow is distracting; raise it if you keep missing procs on a busy UI."

L["GEMS_CVAR_FCT_DIRSCALE_DESCLONG"] =
    "Sets how much the floating-combat-text numbers grow when damage comes from a specific direction. 100% (the default, and the EMS recommendation) shows numbers at their normal size. Lower values tamp down the directional emphasis if combat text is cluttering your view. Higher values exaggerate hits from your front and sides, useful for tanks who use damage direction as a positional cue."

L["GEMS_CVAR_SOLO_LOOTRATE_DESCLONG"] =
    "Sets the polling interval for auto-loot in milliseconds. Lower values process loot pickups faster but check the loot system more often. 50 ms (the EMS recommendation) makes auto-loot feel near-instant on a single corpse and matters most during mass mob clears where you skim past dozens of bodies. 150 ms is the Blizzard default and is fine for normal play. Higher values are mainly useful if you are hunting CPU savings on a weak machine."

L["GEMS_CVAR_DUNGEON_LOGTIME_DESCLONG"] =
    "Sets how long the in-memory combat log keeps events before discarding them. 5 minutes (the default, and the EMS recommendation) covers most boss fights with margin for trash before. Raise it for long fights where you want to scrub back through several pulls worth of events; drop it on weaker hardware where the in-memory log is causing FPS dips during heavy AoE."

L["GEMS_CVAR_UI_TUTORIALS_DESCLONG"] =
    "Controls whether Blizzard's tutorial pop-ups appear as you play. Off (the EMS recommendation) hides them entirely, which is what most players past their first character want. On (the default) shows the standard tutorial prompts Blizzard added to teach UI features."

L["GEMS_CVAR_UI_NPE_DESCLONG"] =
    "Controls whether the New Player Experience overlays appear during early-level questing. Off (the EMS recommendation) hides the NPE prompts, which are aimed at brand-new accounts and feel intrusive on alts. On (the default) shows the full NPE walkthrough Blizzard ships for first-time players."

L["GEMS_CVAR_UI_LOADTIPS_DESCLONG"] =
    "Shows helpful tips on the loading screen while you wait for a zone to finish loading. Off leaves the loading bar blank. On (the default, and the EMS recommendation) shows rotating tips and lore snippets, which makes loading screens less dead time. This setting resets each time you log in and does not persist across sessions."

L["GEMS_CVAR_UI_COMPARE_DESCLONG"] =
    "Controls whether item tooltips automatically show a side-by-side comparison with whatever you currently have equipped. Off requires Shift while hovering to bring up the compare panel. On (the default, and the EMS recommendation) always shows comparisons, which saves a keypress every time you loot or browse the auction house."

L["GEMS_CVAR_UI_TOOLTIPS_DESCLONG"] =
    "Controls how much detail item and ability tooltips show. Off uses a stripped-down tooltip with only the basics. On (the default, and the EMS recommendation) shows full stats, item level, slot type, and set-bonus information, which is what every modern UI relies on."

L["GEMS_CVAR_UI_TRANSMOG_DESCLONG"] =
    "Highlights items whose appearance you have not yet collected for transmog. Off (the default) gives no indication. On (the EMS recommendation) tags missing-appearance gear directly in item tooltips, which is what transmog collectors want when running old content. This is a per-character setting, since alts can be at different points in the collection."

L["GEMS_CVAR_UI_EDGEFLASH_DESCLONG"] =
    "Controls the red flash around the screen edges when you take heavy damage or your health drops low. Off removes the flash entirely. On (the default, and the EMS recommendation) keeps the visual cue, which is a useful low-attention warning when you are focused on your rotation instead of your health bar."

L["GEMS_CVAR_UI_BUBBLES_DESCLONG"] =
    "Controls whether NPC and player chat appears as floating speech bubbles over their heads in addition to the chat frame. Off only shows messages in the chat window. On (the default, and the EMS recommendation) adds the floating bubbles, which makes it easier to follow conversations in busy areas without watching the chat log."

L["GEMS_CVAR_UI_BIGNUMS_DESCLONG"] =
    "Adds thousand separators (commas or periods, depending on locale) to large numbers in tooltips and the UI. Off shows raw digit strings like 1234567. On (the default, and the EMS recommendation) shows 1,234,567, which is much easier to read at a glance for damage numbers, gold totals, and item stats."

L["GEMS_CVAR_UI_BUFFDUR_DESCLONG"] =
    "Shows the seconds remaining on buff and debuff icons in the default UI. Off shows only the icon and stack count. On (the default, and the EMS recommendation) overlays a countdown timer, which is what you want for tracking cooldown durations, stack timers, and time-sensitive buffs."

L["GEMS_CVAR_UI_FSTACK_DESCLONG"] =
    "Toggles the frame stack debug overlay, a tool that shows which UI frame is under your mouse cursor. Off (the default, and the EMS recommendation) is what every player wants. On is a developer aid for troubleshooting an addon UI bug. This resets each session and does not persist."

L["GEMS_CVAR_UI_RAWMOUSE_DESCLONG"] =
    "Toggles raw mouse input mode, which bypasses Windows pointer acceleration and reads input directly from the device. Off (the default, and the EMS recommendation) uses the standard mouse path, which is what nearly every player wants. On is a niche option for players who prefer a 1:1 input feel and have already disabled OS acceleration. This resets each session."

L["GEMS_CVAR_UI_TAINT_DESCLONG"] =
    "Toggles taint logging, which writes UI taint events to a file for addon debugging. Off (the default, and the EMS recommendation) keeps taint logging silent. On is for addon authors investigating taint chains and adds disk I/O. This resets each session."

L["GEMS_CVAR_UI_BAGS_DESCLONG"] =
    "Controls whether the bag UI shows as a single combined window or as separate panels per bag. Off (the default) gives you four separate bag frames. On (the EMS recommendation) merges everything into one combined window, which is the modern bag UI Blizzard added in Dragonflight."

L["GEMS_CVAR_UI_ROTATEMM_DESCLONG"] =
    "Controls whether the minimap rotates as you turn your character or stays fixed with north at the top. Off (the default, and the EMS recommendation) keeps north pinned, which makes the minimap behave like a map you would read on a table. On rotates it so the top always points the direction you face, which some players find more intuitive but most experienced players find disorienting."

-- CVar Section: UI & Quality of Life -- status text, cast bar and chat bubble children (3d)
L["GEMS_CVAR_UI_STATUSTEXT_DESCLONG"] =
    "Controls whether the health and power bars on unit frames carry a text readout at all. Off (0) is the client default; EMS recommends on (1), because a sequence step that needs a set amount of power is guesswork when the only readout is a bar length. The Status Bar Text Format row below decides what that text says and does nothing while this row is off, so the two are set together or not at all. Blizzard exposes them as a single dropdown in its own options panel rather than as two rows, which is why turning only the row below on appears to do nothing. This setting is saved account-wide, so it persists across sessions once you set it."

L["GEMS_CVAR_UI_STATUSTEXTMODE_DESCLONG"] =
    "Picks what the unit frame bar text reads once the Status Bar Text row above is on. Numeric Value shows the raw number, Percentage shows the share of the maximum, Both shows the two together, and None shows nothing. None is the client default, which lines up with the master row above defaulting to off. EMS recommends Both, because the raw number is what tells you whether the next step in a sequence has the power to fire while the percentage is what tells you how a target is doing, and the only cost of carrying both is bar width. Nothing here shows up while the row above is off. This setting is saved account-wide, so it persists across sessions once you set it."

L["GEMS_CVAR_UI_VKEYCASTBAR_DESCLONG"] =
    "The V key brings up a display over enemies in the game field showing their health bar. This row adds the cast bar to that display. On (1) is the client default and what EMS recommends, because a cast you can see is a cast you can interrupt, and an interrupt step fired blind is a cooldown spent on nothing. Off (0) leaves the health bar without the cast bar. The two rows below refine what that cast bar shows. This setting is saved account-wide, so it persists across sessions once you set it."

L["GEMS_CVAR_UI_VKEYSPELLNAME_DESCLONG"] =
    "The name says this puts the spell name on the V key cast bar alongside the cast progress. On (1) is the client default and what EMS recommends, because a bar with no name tells you something is being cast but not whether it is worth an interrupt. The client ships no help text for this variable and no settings panel exposes it, so what it does is read off the variable name and the parent row above rather than from anything Blizzard documents. If you see no difference either way, the V key display is not up for you to begin with. This setting is saved per character."

L["GEMS_CVAR_UI_VKEYONLYTARGET_DESCLONG"] =
    "The name says this limits the V key cast bar to the unit you currently have targeted. Off (0) is the client default and what EMS recommends, since off cannot show you less than on does, and the casts worth reacting to are often on something you have not targeted yet. The client ships no help text for this variable and no settings panel exposes it, so what it narrows is read off the variable name rather than from anything Blizzard documents. The parent row's own help already describes the cast bar as following your current target, so this row may cut something finer than that; if you see no difference either way, that is the likely reason. This setting is saved per character."

L["GEMS_CVAR_UI_BUBBLESRAID_DESCLONG"] =
    "Decides whether raid chat also appears as a floating speech bubble over the speaker, on top of the chat frame. Off (0) is the client default and what EMS recommends, because twenty people talking during a pull covers the part of the screen you need to read, and raid callouts are what a raid warning is for. On (1) suits smaller groups that treat raid chat the way they treat party chat. Needs the Chat Bubbles row above to be on, and that row is on by default. This setting is saved account-wide, so it persists across sessions once you set it."

L["GEMS_CVAR_UI_BUBBLESPARTY_DESCLONG"] =
    "Decides whether party chat also appears as a floating speech bubble over the speaker, on top of the chat frame. On (1) is the client default and what EMS recommends, because party chat in a dungeon is low enough volume to read at a glance and a bubble is easier to catch mid-pull than a line scrolling past in the chat frame. Off (0) keeps party chat in the chat frame only. Needs the Chat Bubbles row above to be on, and that row is on by default. This setting is saved account-wide, so it persists across sessions once you set it."

-- L372 Wave 12: Section 7 non-toggle CVars + WAVE10c SoftTargetArc trio (2026-05-19)
L["GEMS_CVAR_UI_SSFORMAT_OPT_JPEG"] = "JPEG (small files, lossy)"
L["GEMS_CVAR_UI_SSFORMAT_OPT_PNG"] = "PNG (lossless, mid size)"
L["GEMS_CVAR_UI_SSFORMAT_OPT_TGA"] = "TGA (lossless, large files)"
L["GEMS_CVAR_UI_SSFORMAT_DESCLONG"] =
    "File format the game writes to your Screenshots folder. JPEG keeps file size down at the cost of compression artefacts. TGA and PNG are lossless. EMS picks TGA because guides and transmog comparisons need pixel-accurate screenshots."
L["GEMS_CVAR_UI_SSQUALITY_DESCLONG"] =
    "JPEG compression quality, 1 to 10. Lower values produce smaller files with more visible artefacts. Has no effect when screenshotFormat is set to TGA or PNG, since those formats are already lossless. If you stay on JPEG, 10 is the right pick."
L["GEMS_CVAR_UI_ZOOM_DESCLONG"] =
    "Multiplier on the camera's max zoom-out distance. The engine caps at 2.6, which gives roughly 39 yards out from the player. The default 1.9 (28.5 yards) feels cramped on melee classes trying to see swirly mechanics at the edge of the screen. EMS picks the max."
L["GEMS_CVAR_UI_COMBOPT_OPT_1"] = "On target"
L["GEMS_CVAR_UI_COMBOPT_OPT_2"] = "On player (below resource bar)"
L["GEMS_CVAR_UI_COMBOPT_DESCLONG"] =
    "Where the combo-point UI element draws. Set to 1 to show points above the targeted unit's nameplate; 2 (the default) shows them on the player below the personal resource display. EMS keeps the default."
L["GEMS_CVAR_COMBAT_SOFTARC_OPT_0"] = "Straight ahead only"
L["GEMS_CVAR_COMBAT_SOFTARC_OPT_1"] = "Front arc"
L["GEMS_CVAR_COMBAT_SOFTARC_OPT_2"] = "Anywhere in tab area"
L["GEMS_CVAR_COMBAT_SOFTARC_DESCLONG"] =
    "How wide the yaw arc is for picking a soft-target enemy. 0 only selects mobs directly in front of you. 1 selects within a narrow front arc. 2 selects anywhere in the tab-target search area. Default and recommended is 2 for the widest catch."
L["GEMS_CVAR_COMBAT_FRIENDARC_OPT_0"] = "Straight ahead only"
L["GEMS_CVAR_COMBAT_FRIENDARC_OPT_1"] = "Front arc"
L["GEMS_CVAR_COMBAT_FRIENDARC_OPT_2"] = "Anywhere in targeting area"
L["GEMS_CVAR_COMBAT_FRIENDARC_DESCLONG"] =
    "How wide the yaw arc is for picking a soft-target friendly. Mirrors the enemy version: 0 directly ahead, 1 narrow front arc, 2 anywhere in the targeting area. Default and recommended is 2."
L["GEMS_CVAR_SOLO_INTERARC_OPT_0"] = "Straight ahead only"
L["GEMS_CVAR_SOLO_INTERARC_OPT_1"] = "Front arc"
L["GEMS_CVAR_SOLO_INTERARC_OPT_2"] = "Anywhere in targeting area"
L["GEMS_CVAR_SOLO_INTERARC_DESCLONG"] =
    "How wide the yaw arc is for the interact (Tab-to-loot, NPC click) softtarget. The default 0 only catches things directly in front, which often misses corpses or NPCs at a slight angle. EMS picks 1 (the narrow front arc), wider than the default but narrow enough to avoid accidental selection."
L["GEMS_CVAR_MACRO_KEYHELD_DESCLONG"] =
    "Activates the press-and-hold cast option on key-down. When On, holding the key past the cast triggers an error-retry path some macros use for repeat-cast behaviour. Default Off works for almost everyone."
L["GEMS_CVAR_MACRO_AUTOSTAND_DESCLONG"] =
    "Automatically stands your character when you cast a spell that requires standing. With this Off you have to /stand by hand before any seated cast works. Leave On unless you want strict seated control."
L["GEMS_CVAR_MACRO_AUTOUNSHIFT_DESCLONG"] =
    "Automatically leaves your shapeshift form (Druid form, Warrior stance, Evoker hover) when you cast a spell that cannot be cast in the current form. With this Off the cast fails and you have to shift out by hand. Leave On for normal play."
L["GEMS_CVAR_MACRO_STOPATTACK_DESCLONG"] =
    "Stops your auto-attack when you switch targets. With this On a target swap makes you stop swinging; you have to re-engage with /startattack. The default Off keeps you swinging through target swaps. This is a per-character setting."
L["GEMS_CVAR_MACRO_ICONRATE_DESCLONG"] =
    "How often the assisted-combat action-bar icon refreshes, in seconds. Lower values are more responsive but cost a small amount of CPU each frame; higher values save CPU at the cost of a slightly slower icon swap. EMS recommends 0.05 which keeps the icon snappy without measurable overhead."
L["GEMS_CVAR_MACRO_CDCOUNT_DESCLONG"] =
    "Replaces the spinning radial cooldown overlay on action buttons with a numeric countdown. The Blizzard default is the radial swipe; EMS recommends the number countdown because it is easier to read at a glance while watching a sequence run."
L["GEMS_CVAR_MACRO_SECTOGGLE_DESCLONG"] =
    "Protects you from accidentally double-clicking a toggle ability (Shadow Form, Skirmisher, etc.) and turning it back off. With this Off a fast double-click can deactivate the toggle; the default On treats the second click as a no-op. Leave On for normal play."
L["GEMS_CVAR_MACRO_EMPTAP_DESCLONG"] =
    "Applies to empowered spells. Changes how they trigger. Default Off uses press-hold-release: hold the key to charge stages, release to fire. On switches to a tap-tap scheme where one press starts the charge and a second press ends it. Turning this on removes release-on-key-up everywhere, not just in macros: with it on, letting the key up no longer releases an empowered spell anywhere in the interface, including on the default action bars. Pick the scheme that matches how you play. This is a per-character setting."
L["GEMS_CVAR_MACRO_EMPHOLD_DESCLONG"] =
    "Applies to empowered spells. Sets the minimum portion of an Empower spell's first stage you must hold before a release is accepted. The default 1.00 requires the full first stage to elapse before any release fires; lower values let you release earlier at the cost of accidental misfires. Tune this if Empower macros feel like they release too early or too late."
L["GEMS_CVAR_MACRO_EMPTAPTHRESHOLD_DESCLONG"] =
    "Only does anything while the Empower Tap Controls row above is on, and EMS recommends that master off, so most players will never see this take effect. With the tap scheme selected, one press starts an empowered charge and a second press ends it. This is how long the client ignores further taps after the press that began the cast, in milliseconds, so a fast double input does not end the cast the instant it starts. Blizzard documents the accepted range as 0 to 1000 with 300 as the default, and EMS leaves it at 300 because the right number depends on your latency rather than on anything the addon can measure. Raise it if a tap-scheme empowered cast keeps releasing at rank one; lower it if you tap deliberately and 300ms feels sluggish. This setting is saved account-wide, so it persists across sessions once you set it."
L["GEMS_CVAR_MACRO_PRECAST_DESCLONG"] =
    "Enables preemptive cast visuals: the cast animation can begin before the spell release timing fully confirms. This resets each session and does not persist across logouts. Leave Off unless you are testing visual latency."
L["GEMS_CVAR_NAMEPLATES_SHOWALL_DESCLONG"] =
    "Turns on every nameplate category at once: enemies, friendly NPCs, pets, guardians, and totems. The individual category toggles below still apply -- this is the master switch. EMS recommends On because nameplates are the primary mechanic-tracking surface in modern WoW; the Blizzard default Off was set when nameplates were a niche feature."
L["GEMS_CVAR_NAMEPLATES_SHOWSELF_DESCLONG"] =
    "Shows the personal resource display: a nameplate floating below your character with your own health and resource. EMS recommends On because resource-gated rotations are easier to read off the personal plate than the unit frame. This is a per-character setting."
L["GEMS_CVAR_NAMEPLATES_CASTBARS_DESCLONG"] =
    "Shows cast bars under each unit nameplate so you can see what mob is casting and when. On is the default and the right answer for almost every player; Off only makes sense if you have a dedicated cast tracker that draws over the nameplates. This is a per-character setting."
L["GEMS_CVAR_NAMEPLATES_CLASSCOLOR_DESCLONG"] =
    "Colours enemy player nameplate health bars by class so you can spot a Mage vs a Warrior at a glance. On is the default. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_NAMEPLATES_DEBUFFS_DESCLONG"] =
    "Shows debuff icons on friendly nameplates so you can see who needs a dispel or a cleanse. On is the default. Turn Off only if you run a dedicated raid frame that already surfaces these debuffs. This is a per-character setting."
L["GEMS_CVAR_NAMEPLATES_MINIONS_DESCLONG"] =
    "Shows nameplates for enemy minions (Warlock pets, Hunter pets, Death Knight pets, mage water-elemental, etc.). Off is the default and keeps PvE clutter down. Turn On for PvP where you may want to focus a pet to cleave its owner."
L["GEMS_CVAR_NAMEPLATES_MINUS_DESCLONG"] =
    "Shows nameplates for trash mobs marked as weaker than you (the minus-sign mobs in the world). On is the default and you want it on for any AoE-tagging or open-world farming."
L["GEMS_CVAR_NAMEPLATES_TOTEMS_DESCLONG"] =
    "Shows nameplates for enemy totems. EMS recommends On because hostile totems carry mechanic-critical information (Storm Totem damage, Healing Stream Totem healing, Capacitor Totem stun timer); the Blizzard default Off hides them behind the totem 3D model."
L["GEMS_CVAR_NAMEPLATES_FRIENDLY_DESCLONG"] =
    "Shows nameplates for friendly players (your raid, your party, your guild). Off is the default and the right answer in raids -- friendly nameplates carry an FPS cost because each plate processes aura updates whether the plate is visible or not. Turn On only in BG/Arena where you want to track friendly positions."
L["GEMS_CVAR_NAMEPLATES_NAMEONLY_DESCLONG"] =
    "When On, friendly player nameplates collapse to just the name (no health bar, no resource bar). Pairs naturally with friendly-nameplates being On. Off is the default. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_NAMEPLATES_ATBASE_DESCLONG"] =
    "Positions nameplates at the unit's feet (On) rather than over its head (Off, default). Some players prefer base-positioned plates because they line up with ground swirls and AoE markers, but the default overhead position keeps the plate clear of ground effects."
L["GEMS_CVAR_NAMEPLATES_OFFSCREEN_DESCLONG"] =
    "Keeps a nameplate visible at the edge of your screen when its owner is in combat with you or with someone in your group, even if the unit itself is off-screen. Off is the default. On is useful in fights where you must track a mob you cannot see (back-camera bosses, ranged adds)."
L["GEMS_CVAR_NAMEPLATES_SOFTNP_DESCLONG"] =
    "Forces a nameplate to always be visible on your soft enemy target (the auto-acquired target you have not hard-clicked yet). On is the default and pairs with the soft-targeting system from the Combat section."
L["GEMS_CVAR_NAMEPLATES_RADIAL_OPT_0"] = "Off"
L["GEMS_CVAR_NAMEPLATES_RADIAL_OPT_1"] = "Target Only"
L["GEMS_CVAR_NAMEPLATES_RADIAL_OPT_2"] = "All In Combat"
L["GEMS_CVAR_NAMEPLATES_RADIAL_DESCLONG"] =
    "When a unit is off-screen, this setting decides whether to draw its nameplate radially around the edges of your screen instead of hiding it. Off (default) hides off-screen plates. Target Only draws a plate at the edge for your current target. All In Combat draws plates at the edges for every unit you are fighting -- useful when you must track several mobs at once but can be visually busy."
L["GEMS_CVAR_NAMEPLATES_THREATDISP_OPT_OFF"] = "Off"
L["GEMS_CVAR_NAMEPLATES_THREATDISP_OPT_PROGRESSIVE"] = "Progressive"
L["GEMS_CVAR_NAMEPLATES_THREATDISP_OPT_FLASH"] = "Aggro Flash"
L["GEMS_CVAR_NAMEPLATES_THREATDISP_OPT_HBCOLOR"] = "Health Bar Colour"
L["GEMS_CVAR_NAMEPLATES_THREATDISP_OPT_ALL"] = "All"
L["GEMS_CVAR_NAMEPLATES_THREATDISP_DESCLONG"] =
    "Off matches the default. Progressive fills a threat meter on the plate, Aggro Flash warns when you gain or lose aggro, and Health Bar Colour tints the health bar by threat state. Tanks get the most from Health Bar Colour."
L["GEMS_CVAR_NAMEPLATES_INFODISP_OPT_OFF"] = "Off"
L["GEMS_CVAR_NAMEPLATES_INFODISP_OPT_RARITY"] = "Rarity Icon"
L["GEMS_CVAR_NAMEPLATES_INFODISP_OPT_PCT"] = "Health Percent"
L["GEMS_CVAR_NAMEPLATES_INFODISP_OPT_PCTRARITY"] = "Health Percent + Rarity"
L["GEMS_CVAR_NAMEPLATES_INFODISP_OPT_ALL"] = "Everything"
L["GEMS_CVAR_NAMEPLATES_INFODISP_DESCLONG"] =
    "Rarity Icon matches the default: rare and elite mobs get a marker on their plate. The percent options add a health number readout. Everything shows percent, exact value, and the rarity marker at once."
L["GEMS_CVAR_NAMEPLATES_CASTBARDISP_OPT_OFF"] = "Off"
L["GEMS_CVAR_NAMEPLATES_CASTBARDISP_OPT_NAMEICON"] = "Name + Icon"
L["GEMS_CVAR_NAMEPLATES_CASTBARDISP_OPT_HIGHLIGHTS"] = "Name, Icon + Highlights"
L["GEMS_CVAR_NAMEPLATES_CASTBARDISP_OPT_ALL"] = "Everything"
L["GEMS_CVAR_NAMEPLATES_CASTBARDISP_DESCLONG"] =
    "Name, Icon + Highlights matches the default: spell name and icon, plus a highlight for important casts and for casts aimed at you. Everything adds the cast target name so you can see who the mob is casting at. Off hides cast bar extras."
L["GEMS_CVAR_NAMEPLATES_AURAENEMYPLAYER_OPT_OFF"] = "Off"
L["GEMS_CVAR_NAMEPLATES_AURAENEMYPLAYER_OPT_DEBUFFS"] = "Debuffs Only"
L["GEMS_CVAR_NAMEPLATES_AURAENEMYPLAYER_OPT_BUFFSDEBUFFS"] = "Buffs + Debuffs"
L["GEMS_CVAR_NAMEPLATES_AURAENEMYPLAYER_OPT_ALL"] = "Buffs, Debuffs + Loss of Control"
L["GEMS_CVAR_NAMEPLATES_AURAENEMYPLAYER_DESCLONG"] =
    "The recommended setting adds loss of control markers, so you can tell when an enemy player is stunned, feared, or silenced straight from their plate. The game default leaves those markers off."
L["GEMS_CVAR_NAMEPLATES_AURAENEMYNPC_OPT_OFF"] = "Off"
L["GEMS_CVAR_NAMEPLATES_AURAENEMYNPC_OPT_DEBUFFS"] = "Debuffs Only"
L["GEMS_CVAR_NAMEPLATES_AURAENEMYNPC_OPT_BUFFSDEBUFFS"] = "Buffs + Debuffs"
L["GEMS_CVAR_NAMEPLATES_AURAENEMYNPC_OPT_ALL"] = "Buffs, Debuffs + Crowd Control"
L["GEMS_CVAR_NAMEPLATES_AURAENEMYNPC_DESCLONG"] =
    "The default shows all three. Crowd control markers on NPC plates show which mobs are already locked down, so the group does not stack CC on the same target in dungeons."
L["GEMS_CVAR_NAMEPLATES_AURAFRIENDPLAYER_OPT_OFF"] = "Off"
L["GEMS_CVAR_NAMEPLATES_AURAFRIENDPLAYER_OPT_DEBUFFS"] = "Debuffs Only"
L["GEMS_CVAR_NAMEPLATES_AURAFRIENDPLAYER_OPT_BUFFSDEBUFFS"] = "Buffs + Debuffs"
L["GEMS_CVAR_NAMEPLATES_AURAFRIENDPLAYER_OPT_ALL"] = "Buffs, Debuffs + Loss of Control"
L["GEMS_CVAR_NAMEPLATES_AURAFRIENDPLAYER_DESCLONG"] =
    "Buffs + Debuffs matches the default. Add loss of control if you play healer and want to see which teammates are stunned or silenced without staring at raid frames."
L["GEMS_CVAR_NAMEPLATES_STACKING_OPT_NONE"] = "Off"
L["GEMS_CVAR_NAMEPLATES_STACKING_OPT_ENEMY"] = "Enemy"
L["GEMS_CVAR_NAMEPLATES_STACKING_OPT_FRIENDLY"] = "Friendly"
L["GEMS_CVAR_NAMEPLATES_STACKING_OPT_BOTH"] = "Enemy + Friendly"
L["GEMS_CVAR_NAMEPLATES_STACKING_DESCLONG"] =
    "Controls which nameplates stack apart when they would overlap, so you can read them in a pack. Enemy keeps enemy plates separated for target selection in dungeons and raids. Friendly does the same for friendly plates. EMS recommends Enemy because the Blizzard default is no stacking at all, which lets enemy plates pile on top of each other in dungeon packs; enemy stacking keeps each plate selectable. The PvP profile applies Enemy + Friendly automatically, since it also turns friendly player plates on."
L["GEMS_CVAR_NAMEPLATES_MINALPHA_DESCLONG"] =
    "Sets the minimum opacity (alpha) of nameplates as they fade with distance. A nameplate fades from MaxAlpha at the close range down to MinAlpha at the far edge. EMS recommends 0.8 because the Blizzard default 0.6 lets distant plates drop to a hard-to-read 60% opacity; 0.8 keeps the text legible at every range while preserving the visual distance cue. This is a per-character setting."
L["GEMS_CVAR_NAMEPLATES_MAXALPHA_DESCLONG"] =
    "Sets the maximum opacity (alpha) of nameplates at close range. The default 1.0 is fully opaque and the right choice for almost everyone. Lower values bake in a permanent see-through look that pairs with very low MinAlpha for an art-style preference; there is no gameplay reason to drop it. This is a per-character setting."
L["GEMS_CVAR_NAMEPLATES_MINSCALE_DESCLONG"] =
    "Sets the minimum size of distant nameplates. The default 0.8 shrinks far plates to 80% of MaxScale so they read as smaller in the depth cue. Setting MinScale equal to MaxScale (e.g. both 1.0) disables the depth-scaling entirely so every plate is the same size at every range. This is a per-character setting."
L["GEMS_CVAR_NAMEPLATES_MAXSCALE_DESCLONG"] =
    "Sets the maximum size of nameplates at close range. The default 1.0 is the baseline. Larger values make close plates more readable at the cost of more screen real estate; smaller values keep the screen cleaner but cost some legibility. This is a per-character setting."
L["GEMS_CVAR_NAMEPLATES_SELSCALE_DESCLONG"] =
    "Sets the scale multiplier applied to the currently selected unit's nameplate. The default 1.2 enlarges your target's plate to 120% so it stands out in a crowd. Setting this to 1.0 disables the bump entirely; higher values make the target plate even more prominent. This is a per-character setting."
L["GEMS_CVAR_NAMEPLATES_OCCLUDED_DESCLONG"] =
    "Alpha multiplier applied to nameplates of targets behind walls or terrain (occluded line-of-sight). The Blizzard default 0.4 fades occluded plates down to 40% which is hard to track. EMS recommends 0.6 because tracking a mob you cannot directly see is exactly when you need its plate readable -- think peeling adds around a pillar, or a healer hiding behind a doorway in PvP. Setting this to 1.0 disables the fade entirely if you want full visibility. This is a per-character setting."
L["GEMS_CVAR_NAMEPLATES_AURASCALE_DESCLONG"] =
    "Sets the size multiplier for the buff and debuff icons that show on each nameplate. EMS recommends 1.2 because the default 1.0 icons can vanish behind the unit name when several auras stack, and 1.2 keeps each icon legible without dominating the plate. Push higher (1.4 or 1.6) if you raid on a 4K display where the default reads small."
L["GEMS_CVAR_NAMEPLATES_PLAYERDIST_DESCLONG"] =
    "Maximum distance at which friendly-player nameplates are drawn. The default 60 yards is the right answer for almost every situation. Raid scenes use 41 yards to match the in-combat range cap, and short-range setups (5-man, PvP) can drop to 20 yards to declutter the screen. The 80 / 100 yard values are useful for outdoor world play or large pulls where you want to spot a friend at extreme range. This is a per-character setting."
L["GEMS_CVAR_NAMEPLATES_OVERLAPH_DESCLONG"] =
    "Horizontal-overlap factor that controls how aggressively the nameplate engine spreads adjacent plates apart along the X axis. Lower values let plates sit closer together (tighter packing, more overlap); higher values force more horizontal separation. The default 0.8 is a balanced middle ground. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_NAMEPLATES_OVERLAPV_DESCLONG"] =
    "Vertical-overlap factor that controls how aggressively the nameplate engine spreads adjacent plates apart along the Y axis. Lower values let plates sit closer together; higher values force more vertical separation. The default 1.1 leaves a small visual gap between stacked plates. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_NAMEPLATES_SOFTSIZE_DESCLONG"] =
    "Size in pixels of the soft-target marker icon that overlays the current soft-target's nameplate. EMS recommends 25 because the Blizzard default 19 reads small on modern displays, especially in dense raid scenes; 25 makes the marker visible at a glance without dominating the plate. Set to 0 to disable the icon entirely if your nameplate addon draws its own target indicator."
L["GEMS_CVAR_NAMEPLATES_DEBUFFPAD_DESCLONG"] =
    "Padding in pixels between the debuff icon row and the health bar on each nameplate. The default 0 packs the row directly against the bar (compact). Higher values insert a gap so the debuffs read as a separate strip; useful on large nameplate scales or 4K displays where the debuff icons sit visually too close to the bar text."
L["GEMS_CVAR_DRAGON_DYNFOV_DESCLONG"] =
    "Widens the camera field of view as your gliding speed increases. On is the default and the right answer for almost every player -- the FOV stretch sells the sensation of speed during a dive. Turn Off if you find the dynamic FOV motion-sickening or if you prefer a fixed-frame look during long flights. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."
L["GEMS_CVAR_DRAGON_MAXPITCH_DESCLONG"] =
    "Maximum pitch rate when steering Skyriding / Dragonriding with the keyboard. EMS recommends 6.0 because the Blizzard default 5.0 feels sluggish during reactive manoeuvres (avoiding map geometry, chasing a friend's slipstream); 6.0 gives the keyboard pitch parity with a mid-sensitivity mouse without overshooting on small inputs. Lower values give finer precision at the cost of slower turns."
L["GEMS_CVAR_DRAGON_MAXTURN_DESCLONG"] =
    "Maximum turn rate when steering Skyriding / Dragonriding with the keyboard. EMS recommends 10.0 because the Blizzard default 8.0 caps your yaw rate below what the dragon can actually execute; 10.0 lets you carve tighter holding patterns around treasure spawns and pull off the half-cobra reversal during PvP duels. Lower values feel safer but cost time on every turn."
L["GEMS_CVAR_DRAGON_MINPITCH_DESCLONG"] =
    "Minimum pitch rate -- the floor that small keyboard taps produce. EMS recommends 3.0 because the Blizzard default 2.5 makes light corrective taps feel mushy; 3.0 gives every tap a noticeable nose change so you can fine-tune your dive angle without overcommitting. Lower values feel more cinematic; higher values feel snappier."
L["GEMS_CVAR_DRAGON_PITCHCTRL_OPT_1"] = "1 (Forward/Up)"
L["GEMS_CVAR_DRAGON_PITCHCTRL_OPT_2"] = "2 (Backward/Up)"
L["GEMS_CVAR_DRAGON_PITCHCTRL_OPT_3"] = "3 (Default, recommended)"
L["GEMS_CVAR_DRAGON_PITCHCTRL_DESCLONG"] =
    "Helps with hand motor function during Skyriding by remapping which keyboard input pitches your dragon up. Default 3 (Default) uses Blizzard's standard pitch behaviour -- pitch follows mouse and spacebar, forward and backward inputs are used purely for thrust. Set to 1 (Forward/Up) if you want the Move Forward key to also pitch the dragon up (and Move Backward to pitch down) -- useful for players who find combined mouse+forward inputs physically demanding. Set to 2 (Backward/Up) for the inverse mapping (Move Backward pitches up, Move Forward pitches down). Blizzard's official description: \"Helps to address hand motor function while skyriding.\" EMS does not auto-detect your accessibility needs; pick the option that matches your physical comfort."

-- CVar Section: UI & Quality of Life, Raiding and Solo Play -- Tier 3 QoL singles (3e)
L["GEMS_CVAR_UI_CDVIEWER_DESCLONG"] =
    "Turns on the client's own cooldown tracking bar, which draws your tracked spell cooldowns as a row of icons. Off (0) is the client default; EMS recommends on (1), because a sequence step that fires into a cooldown is a press that does nothing, and this is the client's own readout of what is actually ready. Blizzard gates the setting behind an availability check, so on a client where the viewer is not available the row will not take effect whatever it is set to. This setting is saved per character."

L["GEMS_CVAR_UI_MMCLOSEST_DESCLONG"] =
    "Limits certain tracked minimap icon types to the closest one rather than drawing every match at once. On (1) is the client default and what EMS recommends, because a minimap carpeted with identical icons tells you less than a single icon pointing at the nearest one. Off (0) draws them all, which helps when you are looking for a cluster rather than a destination. No settings panel exposes this variable and it appears nowhere in Blizzard's own interface code, so which icon types it covers is read off the variable's own help text rather than from anything Blizzard documents. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."

L["GEMS_CVAR_UI_PINGMODE_DESCLONG"] =
    "Picks how the ping system answers the ping key. Quick Ping (0) is the client default and what EMS recommends: the ping fires on key down, so it costs one press. Relaxed Ping (1) opens the wheel and lets you drag to pick a ping type, which is more deliberate and slower. On a keyboard already carrying sequence keybinds, the one-press version is the one that does not compete for time mid-pull. Needs the client's Enable Pings setting to be on, and that is on by default. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."

L["GEMS_CVAR_UI_MOUSESPEEDON_DESCLONG"] =
    "Hands mouse sensitivity to the game instead of leaving it to your operating system and mouse driver. Off (0) is the client default and what EMS recommends, because most players have already tuned sensitivity once at the driver level, and a second multiplier stacked on top of it is a setting you forget about and get confused by later. On (1) activates the Mouse Sensitivity row below, which does nothing at all while this row is off. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."

L["GEMS_CVAR_UI_MOUSESPEED_DESCLONG"] =
    "Only does anything while the Custom Mouse Sensitivity row above is on, and EMS recommends that master off, so most players will never see this take effect. The range here is lifted from the client's own sensitivity slider, which runs 0.5 to 1.4 in steps of 0.05 and labels that span as 1 to 10. The client default of 0.025 sits below the bottom of that slider, so it is not a value the settings panel can show at all, which is why EMS recommends 1.0 instead: it falls inside the range the client exposes, it lands exactly on a step, and it reads as 6 on that 1-to-10 scale. Raise it for a faster turn, lower it for finer aim. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login."

L["GEMS_CVAR_RAIDING_HIDEQUEUED_DESCLONG"] =
    "Removes queued countdowns from the encounter timeline, leaving only the ones already counting down. Off (0) is the client default and what EMS recommends, because a queued countdown is advance warning and advance warning is most of what the timeline is for: it tells you whether to start a sequence now or hold it for the mechanic landing in six seconds. On (1) trims the timeline for players who find the queue column noisy. Needs the Encounter Timeline row above to be on, and that row is on by default. This setting is saved account-wide, so it persists across sessions once you set it."

L["GEMS_CVAR_SOLO_QUESTPROGRESS_DESCLONG"] =
    "Adds a quest to the objective tracker whenever its progress changes, so whatever you just made progress on moves into view by itself. On (1) is the client default and what EMS recommends. It is the sibling of the Auto Quest Watch row above, which does the same job at the moment you accept a quest rather than when one updates, and the two together keep the tracker current without manual pinning. Off (0) leaves the tracker exactly as you set it by hand. No settings panel exposes this one, but it is documented outside the client as a 0/1 setting present since patch 1.12. This setting is saved account-wide, so it persists across sessions once you set it."

-- ExportAsText labels (POLISH-EXPORTASTEXT-LOCALE, Backlog L97)
L["GEMS_EXPORTTEXT_SEQUENCE_LABEL"] = "Sequence: "
L["GEMS_EXPORTTEXT_AUTHOR_LABEL"] = "Author: "
L["GEMS_EXPORTTEXT_AUTHOR_UNKNOWN"] = "(unknown)"
L["GEMS_EXPORTTEXT_SPEC_LABEL"] = "Spec: "
L["GEMS_EXPORTTEXT_STEPFUNCTION_LABEL"] = "Step Function: "
L["GEMS_EXPORTTEXT_ICON_LABEL"] = "Icon: "
L["GEMS_EXPORTTEXT_VERSIONS_LABEL"] = "Versions: "
L["GEMS_EXPORTTEXT_VARIABLES_HEADING"] = "Variables:"
L["GEMS_EXPORTTEXT_MACROS_HEADING"] = "Macros:"
L["GEMS_EXPORTTEXT_VARIABLE_EVENT_SUFFIX"] = " (Event: %s)"
L["GEMS_EXPORTTEXT_VERSION_HEADING"] = "Version %d:"
L["GEMS_EXPORTTEXT_VERSION_HEADING_DEFAULT"] = "Version %d (Default):"
L["GEMS_EXPORTTEXT_RESET_LABEL"] = "  Reset: "
L["GEMS_EXPORTTEXT_STEPS_HEADING"] = "  Steps:"
L["GEMS_EXPORTTEXT_STEPS_NONE"] = "    (none)"
L["GEMS_EXPORTTEXT_ACTIONS_HEADING"] = "  Actions:"
L["GEMS_EXPORTTEXT_KEYPRESS_LABEL"] = "  Key Press: "
L["GEMS_EXPORTTEXT_KEYRELEASE_LABEL"] = "  Key Release: "
L["GEMS_EXPORTTEXT_CLASS_LABEL"] = "Class: "
L["GEMS_EXPORTTEXT_DESC_LABEL"] = "Description: "
L["GEMS_EXPORTTEXT_TALENT_LABEL"] = "Talents: "
L["GEMS_EXPORTTEXT_URL_LABEL"] = "Link: "
L["GEMS_EXPORTTEXT_CREATEDBY"] = "Created by: %s"
L["GEMS_EXPORTTEXT_FOOTER"] = "Exported from GRIP-EMS v%s (WoW %s)"

-- v2.1.6 Author Picker: labels for the SequenceEditor author dropdown
-- (pseudonym + BattleNet roster). The %s is the chosen displayName; the
-- alt form takes an additional %s for the realm.
L["GEMS_AUTHOR_PICKER_PSEUDONYM"] = "%s (pseudonym)"
L["GEMS_AUTHOR_PICKER_CURRENT"] = "%s (this character)"
L["GEMS_AUTHOR_PICKER_ALT"] = "%s (%s)"

-- v2.2.0 Per-loadout keybinds (L127)
L["GEMS_KEYBINDS_PER_LOADOUT_TOGGLE"] = "Per-loadout keybinds"
L["GEMS_KEYBINDS_PER_LOADOUT_TOGGLE_TOOLTIP"] =
    "When on, new keybinds bind to the currently active talent loadout. Per-spec keybinds set previously stay as a fallback for loadouts with no override."
L["GEMS_KEYBINDS_SUPPRESS_IN_LOADOUT"] = "Suppress in this loadout"
L["GEMS_KEYBINDS_SUPPRESS_IN_LOADOUT_TOOLTIP"] =
    "Hide this per-spec binding while this loadout is active. The binding stays active in other loadouts of this spec."
L["GEMS_KEYBINDS_ACTIVE_LOADOUT_LABEL"] = "Active loadout: %s"
L["GEMS_KEYBINDS_NO_ACTIVE_LOADOUT"] = "No active loadout (per-spec bindings only)."
L["GEMS_KEYBINDS_FALLBACK_NOTICE"] = "Showing per-spec fallback bindings."
L["GEMS_KEYBINDS_COPY_BUTTON"] = "Copy bindings from another loadout"
L["GEMS_KEYBINDS_MANAGE_ALL"] = "Manage all loadouts"
L["GEMS_KEYBINDS_LOADOUT_BINDING_COUNT"] = "%s: %d binding(s)"
L["GEMS_HELP_BIND_LOADOUT_FLAG"] =
    "  /gems bind <name> <key> [--loadout <id-or-name>] - bind to a specific loadout (default: active loadout if per-loadout mode is on)"
L["GEMS_BIND_LOADOUT_NOT_FOUND"] = "Loadout '%s' not found for current spec."
L["GEMS_KEYBINDS_LOADOUT_OVERRIDES_HINT"] = "  + %d loadout(s) with overrides"
L["GEMS_RESERVED_NAME"] = "Sequence name '%s' is reserved and cannot be used."

-- v2.4.0 Keybind conflict panel (Phase 3). Every key here is looked up through
-- KCH.CopyKeyFor rather than as a literal in the panel source, so
-- audit-locale-references cannot see them; Test/test_keybind_conflict_panel.lua
-- is what proves each one exists.
L["GEMS_KC_TITLE"] = "Keybind Conflicts"
L["GEMS_KC_OPEN_BUTTON"] = "Check Conflicts"
L["GEMS_KC_REFRESH"] = "Refresh"
L["GEMS_KC_HELP_KEYS"] = "  /gems keys - Check your keybinds for conflicts"

-- Verdict and layer statuses. Short, because they sit in a badge next to a row.
L["GEMS_KC_STATUS_CLEAR"] = "Clear"
L["GEMS_KC_STATUS_CONFLICT"] = "Conflict"
L["GEMS_KC_STATUS_UNKNOWN"] = "Could not check"
L["GEMS_KC_STATUS_MASKED"] = "Covered"
L["GEMS_KC_STATUS_UNRECOGNISED"] = "Unrecognised status"

-- The five places a key can be taken, named the way a player would describe them
-- rather than the way the API does.
L["GEMS_KC_LAYER_BASE"] = "Saved key bindings"
L["GEMS_KC_LAYER_EFFECTIVE"] = "What the keypress actually reaches"
L["GEMS_KC_LAYER_MODIFIER"] = "Modified-click actions"
L["GEMS_KC_LAYER_CLICKBIND"] = "Click bindings"
L["GEMS_KC_LAYER_UNRECOGNISED"] = "Unrecognised layer"

-- Findings. Each one says what was found and what it costs, including when the
-- answer is that it costs nothing today.
L["GEMS_KC_NOTE_MASKED"] =
    "A saved binding sits underneath this key. It costs you nothing right now, because your sequence holds the key. If that override ever fails to apply, the key falls through to the command shown instead."
L["GEMS_KC_NOTE_BASE_OWNER"] =
    "A saved key binding owns this key. Clear it in the game's Key Bindings panel to hand the key back."
L["GEMS_KC_NOTE_CAST_REDIRECT"] =
    "A modifier on this key is set to redirect casts. The sequence still fires, and every spell in it goes to yourself, your focus or your mouseover instead of your target."
L["GEMS_KC_NOTE_CLICK_OWNER"] = "A click binding already holds this mouse button."
L["GEMS_KC_NOTE_OTHER"] = "This layer reported a conflict."
L["GEMS_KC_NOTE_UNRECOGNISED"] = "This finding has no description yet."
L["GEMS_KC_ROW_INVALID_KEY"] = "That is not a key the game recognises."
L["GEMS_KC_ROW_LAYER_ACTION"] = "Currently: %s"
L["GEMS_KC_ROW_ATTRIBUTION"] = "Bound by %s, in %s line %d"
L["GEMS_KC_ROW_ATTRIBUTION_UNNAMED"] = "Bound by an addon that could not be named"
L["GEMS_KC_ROW_ATTRIBUTION_RELEASED"] = "%s bound this key and has since released it"

-- What the panel cannot see. These are shown together at the bottom, always, not
-- only when something goes wrong.
L["GEMS_KC_CONTEXT_HEADER"] = "What this check cannot see"
L["GEMS_KC_LIMIT_HOOKS_AT_LOAD"] =
    "Addon names are only recorded for bindings made after GRIP-EMS loaded. An addon that bound a key while it was loading is still detected here, but cannot be named."
L["GEMS_KC_LIMIT_SECURE_HANDLER"] =
    "Some addons bind keys through a protected path that cannot be watched. Those bindings are still detected; only the addon name is missing. GRIP-EMS binds its own sequence keys this way."
L["GEMS_KC_LIMIT_ATTEMPTS_NOT_OWNERSHIP"] =
    "A recorded name proves who asked for a key, not who got it. The layer rows above are the authority on who holds it."
L["GEMS_KC_LIMIT_DEDUP_FIRST_CALLER"] =
    "When one addon rebinds the same key over and over, the first call is the one kept and the count shows how often it repeated."
L["GEMS_KC_LIMIT_KEY_BUDGET"] =
    "The name recorder is full. Keys bound after it filled up are still detected, but cannot be named."
L["GEMS_KC_LIMIT_UNRECOGNISED"] = "This limit has no description yet."
L["GEMS_KC_ADDONS_UNLOADED"] =
    "%d installed addon(s) are not loaded. Their bindings are not registered yet, so any keys they would claim cannot be listed here. This check runs again when one of them loads."
L["GEMS_KC_CAPABILITY_MISSING"] = "Some checks could not run in this game build: %s"
L["GEMS_KC_NO_FINDINGS"] = "No keybinds to check. Bind a sequence to a key first."

-- Severity, used on the filter chips. The badge text itself stays as CRIT, ERR,
-- WARN and INFO, shared with the repair panel.
L["GEMS_KC_SEVERITY_CRITICAL"] = "Critical"
L["GEMS_KC_SEVERITY_ERROR"] = "The keypress does not reach your sequence"
L["GEMS_KC_SEVERITY_WARNING"] = "Real, and not costing you the keypress"
L["GEMS_KC_SEVERITY_INFO"] = "Context, nothing wrong"
L["GEMS_KC_SEVERITY_UNRECOGNISED"] = "Unrecognised severity"

-- Sections, one per source of keybinds.
L["GEMS_KC_SECTION_SEQUENCE"] = "Sequence keybinds"
L["GEMS_KC_SECTION_VEHICLE"] = "Vehicle keybinds"
L["GEMS_KC_SECTION_PETBATTLE"] = "Pet battle keybinds"
L["GEMS_KC_SECTION_PROBE"] = "Key check"
L["GEMS_KC_SECTION_UNRECOGNISED"] = "Other keybinds"

-- The probe row.
L["GEMS_KC_PROBE_LABEL"] = "Check a key:"
L["GEMS_KC_PROBE_HINT"] = "Type a key such as SHIFT-F1 and press Enter."
L["GEMS_KC_PROBE_CANONICAL"] = "Checked as: %s"

-- Fix buttons. Since v2.4.0 Phase 4 this panel WRITES to the client's binding
-- registry, so these are live controls rather than labels. Which rows expose an
-- enabled button is decided in the keybind conflict UI, not here. The two manual
-- instructions below cover the findings the addon cannot take back for you.
L["GEMS_KC_FIX_BUTTON"] = "Fix"
L["GEMS_KC_FIX_ALL_BUTTON"] = "Fix All"
L["GEMS_KC_FIX_ALL_TOOLTIP"] =
    "Clears every conflict in this list that can be fixed from here. You will be asked to confirm the exact number first."
L["GEMS_KC_FIX_UNAVAILABLE_TOOLTIP"] = "There is no supported way for an addon to take this key back for you."
L["GEMS_KC_FIX_MANUAL_BASE"] =
    "Open the game menu, choose Options then Keybindings, find the command named above and clear it. Then refresh this panel."
L["GEMS_KC_FIX_MANUAL_CAST_REDIRECT"] =
    "Open the game menu, choose Options then Combat, and set the modified-click action named above to None."
L["GEMS_KC_UNRECOGNISED"] = "Unrecognised value"

-- v2.4.0 Phase 4 keybind conflict resolution. The panel now WRITES to the
-- client's binding registry, so most of these exist to say exactly what happened
-- or exactly why nothing happened. A fix that silently does nothing is worse than
-- one that refuses out loud.
L["GEMS_KC_FIX_APPLIED"] = "Fixed"
L["GEMS_KC_FIX_QUEUED"] = "Queued until you leave combat"
L["GEMS_KC_FIX_QUEUED_MANUAL"] =
    "Queued. Automatic changes after combat are turned off, so run /gems apply when you are out of combat."
L["GEMS_KC_FIX_FAILED"] = "Could not change this binding"
L["GEMS_KC_FIX_STALE"] = "Nothing changed, this key moved since the check"
L["GEMS_KC_FIX_ALL_CONFIRM"] = "Change keybindings?"
L["GEMS_KC_FIX_ALL_CONFIRM_BODY"] =
    "This will change %d keybinding(s) in your game settings. You can undo the last one from this panel."
L["GEMS_KC_FIX_ALL_NONE_TOOLTIP"] = "Nothing in this list can be fixed from here."
L["GEMS_KC_UNDO_BUTTON"] = "Undo"
L["GEMS_KC_UNDO_TOOLTIP"] = "Put back the last binding this panel changed."
L["GEMS_KC_UNDO_NONE_TOOLTIP"] = "This panel has not changed anything yet."
L["GEMS_KC_UNDO_REFUSED"] = "Left %s alone: something has claimed that key since the fix."
L["GEMS_KC_PLAN_REJECT_BASE_CHANGED"] = "%s no longer carries the binding that was found, so nothing was changed."
L["GEMS_KC_PLAN_REJECT_MODIFIER_CHANGED"] = "%s no longer redirects casts the way it did, so nothing was changed."
L["GEMS_KC_PLAN_REJECT_KEY_NOW_FREE"] = "%s is held by something else now, so it was left alone."
L["GEMS_KC_UNRECOGNISED_PLAN_REJECT"] = "Nothing was changed, and the reason was not recognised."

-- v2.4.0 Severity chip labels, shared by UI/RepairFrame.lua and
-- UI/KeybindConflictPanel.lua through UI.SEVERITY_LABELS. Rendered inside
-- 60-pixel chip buttons in both panels: keep every translation short enough to
-- fit, because it clips rather than wraps.
L["GEMS_SEV_CRIT"] = "CRIT"
L["GEMS_SEV_ERR"] = "ERR"
L["GEMS_SEV_WARN"] = "WARN"
L["GEMS_SEV_INFO"] = "INFO"
