# GSE

## [3.3.22](https://github.com/TimothyLuke/GSE-Advanced-Macro-Compiler/tree/3.3.22) (2026-06-16)
[Full Changelog](https://github.com/TimothyLuke/GSE-Advanced-Macro-Compiler/compare/3.3.21...3.3.22) [Previous Releases](https://github.com/TimothyLuke/GSE-Advanced-Macro-Compiler/releases)

- #1920 Fix Actionbar Overrides in Dominos.  
    Note: The user needs to show hidden buttons to set an Actionbar Override via a right click for a Dominos button but once set the button will no longer hide.  
- #1931 Change LAB detection to capability based  
- #1931 change LAB detection to capability based  
- #1914 Add empty statics to public proxy for old plugin compatability  
- #1931 Fix Override regression  
- Fixe #1954 - Mouse Button 4 and 5 mappings  
    #1954 FIX: Mouse buttons 4/5 keybinds do nothing in game  
- FIX #1931 ABO combat taint block on Bartender4 State Config bars  
    FIX #1931: ABO combat taint block on Bartender4 State Config bars  
- Merge pull request #1952 from LarryThiessen/master  
    FIX: ABO works in all forms incl. Prowl on Bartender4 and stock bars  
- #1954 FIX: Mouse buttons 4/5 keybinds do nothing in game  
    The keybind capture widget stored mouse buttons 4/5 using the WoW  
    frame-script names ("Button4"/"Button5") instead of valid binding names  
    ("BUTTON4"/"BUTTON5"). SetBindingClick rejected those keys and returned  
    nil, so the bind saved in GSE but never fired in game. Only the middle  
    button worked because it had an explicit MiddleButton -> BUTTON3 map.  
    - NativeUI: normalize Button4/Button5 to BUTTON4/BUTTON5 on capture,  
      matching the existing MiddleButton -> BUTTON3 handling.  
    - Events: add normalizeBindKey() applied at both SetBindingClick call  
      sites so already-saved btn4/5 binds (incl. modifier combos like  
      SHIFT-Button4) are migrated on load and fire without re-binding.  
    Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>  
- FIX: #1931 ABO combat taint block on Bartender4 State Config bars  
    GSE armed native action-bar overrides by writing the secure attributes  
    gse-button/type/clickbutton onto the Blizzard button from insecure Lua,  
    which taints those values. The secure BAR\_SWAP snippets then read the  
    tainted gse-button flag; on a bar that Bartender4 "State Configuration"  
    pages (it drives actionpage via a secure state driver), that taint rides  
    into Blizzard's ActionButton:UpdatePressAndHoldAction and its protected  
    SetAttribute("pressAndHoldAction") is blocked in combat -- the  
    "MultiBarBottomLeftButton12 ... SetAttribute" error blamed on Bartender4.  
    Fix: a secure snippet must never read an insecurely-written value.  
    - Add a secure boolean gate `gse-secure`, set ONLY from inside the  
      SecureHandler (SHBT:Execute) via new secureArmGSEButton /  
      secureYieldGSEButton / secureDisarmGSEButton helpers.  
    - BAR\_SWAP\_OAC / BAR\_SWAP\_ONCLICK and the third-party OnEnter wrap now  
      gate on `gse-secure` instead of the insecure `gse-button` string.  
    - Arm type/clickbutton through the secure handler too; the `gse-button`  
      string stays (set insecurely) but is read only by non-secure icon/  
      tooltip/yield hooks, so its taint is inert.  
    - LAB bars (BT4Button/ElvUI/NDui/CPB) are untouched -- they use SetState.  
    Verified in-game (MoP Classic 5.5, Bartender4 State Config on, override  
    on MultiBarBottomLeftButton12, spammed in combat): taintLog 2 shows zero  
    GSE-sourced taint and no pressAndHoldAction block; the button still fires  
    the sequence normally.  
    Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>  
- Merge remote-tracking branch 'upstream/master'  
- FIX: ABO works in all forms incl. Prowl on Bartender4 and stock bars  
    - getButtonEffectiveSlot: read the resolved .action field so the yield check  
      evaluates the bonus-bar slot the button actually fires (Cat/Prowl/Bear), not  
      base slot 1 -- stops the Single-Button Assistant on slot 1 from hijacking the  
      override.  
    - ActionBarSlotHasForeignAction: keep the override only for confirmed GSE  
      sequence macros; yield to any other macro/spell/item on the slot.  
    - LAB bars (BT4/ElvUI/NDui/CPB): register the override on every LAB state so the  
      bar's stance/form paging (Prowl = its own state) can't strand it.  
    Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>  
- Merge pull request #1949 from LarryThiessen/fixes-batch-1935-1948  
    Tracker / skin / debugger / options fixes & enhancements (#1935-#1948)  
- #1951  Only perform LINT tests on Pull Requests and dont include debug code in production builds  
- #1948 FIX: Actionbar Overrides icon missing  
    Statics.Icons.Button pointed at a misspelled path (actionoride.png) with no asset; add the actionoverride.png asset and correct the path.  
    Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>  
- #1947 FIX: Settings dropdowns render behind the options panel  
    Stop forcing SettingsPanel to FULLSCREEN\_DIALOG strata; rely on the stock Settings.OpenToCategory to open and layer the panel so its dropdown popouts appear in front. Remove the dead BringSettingsPanelForward helper.  
    Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>  
- #1946 FIX: Pause-toggle reload prompts did nothing  
    Shift/Alt/Ctrl pause toggles called the retired StaticPopup\_Show(GSE\_ConfirmReloadUIDialog) which is no longer registered; switch to the migrated GSE.GUICall(GUIConfirmReloadUI).  
    Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>  
- #1945 EHN: Skin swap prompts reload and defers all changes until reload  
    Selecting a skin only saves the choice and prompts a reload; nothing swaps live, so the whole skin changes together on reload. Declining keeps the session on the current skin.  
    Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>  
- #1944 FIX: Remove obsolete tracker icon options  
    Remove the Single Icon checkbox and Preview Icon Count slider from Tools & Diagnostic; the tracker is locked to a single icon.  
    Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>  
- #1943 EHN: GSE windows follow the active global font (skin-aware)  
    GSE text adopts the active font by skin mode: Native = stock Blizzard default (forced even when ElvUI/EUI replaced the globals), Modern = STANDARD\_TEXT\_FONT, Addon = ElvUI normFont / EllesmereUI font. Face-only (size/flags preserved), applied across all GSE windows, the tree, debugger rows and the tracker.  
    Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>  
- #1942 EHN: Remove class-colour outline on Native-skin windows  
    Remove the 4-side class-colour band around Native-skin windows; the accent still applies to button/checkbox text and the slim scrollbar. Modern borders unaffected.  
    Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>  
- #1941 EHN: Live-resize throttling (Editor + Debugger)  
    Throttled ~50fps OnUpdate resize pump with a whole-pixel coalesce and a settle on mouse-up, on the Editor and the Debugger main and side windows.  
    Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>  
- #1940 EHN: ElvUI skin parity  
    Add GSE.Skin.HostAccentColor and union the external-provider gating so GSE widgets (scrollbar, close button, dropdown chrome/list/chevron, icons) fully skin under ElvUI/EllesmereUI.  
    Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>  
- #1939 EHN: Dropdown max-visible cap  
    Cap visible rows (default 20) so a long uncapped list scrolls in a bounded popup instead of growing off-screen; explicit SetMaxVisibleItems still wins.  
    Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>  
- #1938 EHN: Debugger chrome, side-window strata and re-snap  
    Side windows ride with the main window's strata, re-snap to the main on drag, the stray side close button is removed, and GSE.RefreshDebuggerSkin repaints on a live skin change.  
    Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>  
- #1937 FIX: Import window transparent under Modern skin  
    Mix in BackdropTemplateMixin and paint a GSEImportBodyFill texture so the import window renders solid under the modern skin.  
    Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>  
- #1936 EHN: Tracker font follows the active skin  
    Tracker text uses GameFontHighlightSmall + a subtle drop shadow from the live font global instead of GameTooltipText + heavy OUTLINE, so it adopts skin fonts.  
    Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>  
- #1935 EHN: Player Status tracker line  
    Toggleable Combat/No-Combat status line in the tracker text panel (default on) with an Options checkbox. Initialises safely from saved vars on fresh install and upgrade.  
    Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>  
