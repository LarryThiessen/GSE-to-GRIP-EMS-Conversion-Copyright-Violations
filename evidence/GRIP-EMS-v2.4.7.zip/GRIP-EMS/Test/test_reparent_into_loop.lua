-- GRIP-EMS: Headless test for drag-a-step-into-a-loop (reparent)
--
-- Created:    2026-06-21
-- Updated:    2026-08-17
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
--
-- Standalone (Lua 5.1) test for UI/StepListView.lua's reparent operations
-- (SLV:_reparentNodeIntoLoop / SLV:_reparentNodeIntoContainer) and the
-- reparentSubtreeHeight depth helper.
-- EMS ships its in-game tests as *_spec.lua files run via /gems test; there is
-- no in-client-independent runner, so this loads the REAL StepListView module
-- via loadfile + setfenv into a sandbox. Any WoW global the module touches at
-- load resolves to a self-referential no-op stub, so only the table-manipulating
-- reparent path actually executes. _markDirty / RefreshAll / _renderDetailPane
-- are overridden as no-ops after load; GRIPEMS.UndoStack is a recording stub.
--
-- Run from the EMS root:  lua Test/test_reparent_into_loop.lua
-- Exit code 0 = all passed, 1 = at least one failure.
--
-- Cases:
--   a   leaf reparented into a top-level loop: count -1, child appended last
--   b   target is not a loop (If) -> false,"type"; tree unchanged
--   c   src == loopIdx -> false,"self"
--   d   depth cap exceeded -> false,"depth"; tree unchanged
--   d2  depth exactly at MAX -> allowed (boundary)
--   e   undo restores the node; redo re-applies the reparent
--   f   else-only If's deep false branch counted by the depth gate (no bypass)
--   g   _computeNodeDepth locates nodes incl. else-only If false branches
--   h   into-container by reference (Loop): count -1, child appended last
--   i   into-container If active branch: lands in children[2], not children[1]
--   j   into-container cycle: container inside the dragged node -> false,"cycle"
--   k   into-container non-container target (Pause) -> false,"type"; unchanged
--   l   into-container depth cap exceeded -> false,"depth"; tree unchanged
--   m   into-container undo restores top-level slot; redo re-applies

local ADDON_NAME = "GRIP-EMS"

-- ---------------------------------------------------------------------------
-- Minimal assertion + runner harness.
-- ---------------------------------------------------------------------------

local tests = {}

local function test(name, fn)
    tests[#tests + 1] = { name = name, fn = fn }
end

local function assertEqual(expected, actual, label)
    if expected ~= actual then
        error((label or "value") .. ": expected " .. tostring(expected) .. ", got " .. tostring(actual), 2)
    end
end

local function assertTrue(cond, label)
    if not cond then
        error((label or "condition") .. " failed", 2)
    end
end

-- ---------------------------------------------------------------------------
-- Sandbox: a self-referential no-op stub backs every unknown global, so the
-- large UI module loads without a real WoW UI. Real stdlib falls through to _G.
-- ---------------------------------------------------------------------------

local stub = {}
setmetatable(stub, {
    __index = function()
        return stub
    end,
    __call = function()
        return stub
    end,
})

local env = setmetatable({}, {
    __index = function(_, k)
        local v = rawget(_G, k)
        if v ~= nil then
            return v
        end
        return stub
    end,
})
env._G = env

-- Recording UndoStack: captures the undo/redo closures of the last Push.
local recordedUndo, recordedRedo, recordedLabel
local function resetUndo()
    recordedUndo = nil
    recordedRedo = nil
    recordedLabel = nil
end

local GRIPEMS = {
    UI = stub,
    Defaults = {
        ACTION_TYPE_ACTION = "action",
        ACTION_TYPE_LOOP = "loop",
        ACTION_TYPE_IF = "if",
        ACTION_MAX_DEPTH = 10,
    },
    UndoStack = {
        Push = function(_, undoFn, redoFn, label)
            recordedUndo = undoFn
            recordedRedo = redoFn
            recordedLabel = label
        end,
    },
}

-- ---------------------------------------------------------------------------
-- Load the REAL StepListView module into the sandbox.
-- ---------------------------------------------------------------------------

local function loadStepListView()
    local candidates = {
        "UI/StepListView.lua",
        "../UI/StepListView.lua",
        "GRIP/EMS/UI/StepListView.lua",
    }
    for _, path in ipairs(candidates) do
        -- loadfile is dev-harness file I/O, intentionally outside the addon WoW std.
        -- selene: allow(undefined_variable)
        local chunk = loadfile(path)
        if chunk then
            setfenv(chunk, env)
            chunk(ADDON_NAME, GRIPEMS)
            return
        end
    end
    error("could not locate UI/StepListView.lua (run from the EMS root)")
end

loadStepListView()

local SLV = GRIPEMS.StepListView
assertTrue(SLV ~= nil, "StepListView loaded")
assertTrue(type(SLV._reparentNodeIntoLoop) == "function", "_reparentNodeIntoLoop defined")
assertTrue(type(SLV._computeNodeDepth) == "function", "_computeNodeDepth defined")

-- Replace the UI-touching methods with no-ops so the reparent path stays pure.
SLV._markDirty = function() end
SLV.RefreshAll = function() end
SLV._renderDetailPane = function() end
SLV.hasActions = true
SLV._suppressUndo = false
SLV._detailOpen = false

-- ---------------------------------------------------------------------------
-- Fixtures.
-- ---------------------------------------------------------------------------

local function makeLeaf(macro)
    return { type = "action", macro = macro or "/cast Test" }
end

local function makeLoop(children)
    return { type = "loop", children = children or {} }
end

local function makeIf(trueArr, falseArr)
    return { type = "if", children = { trueArr or {}, falseArr or {} } }
end

-- A node whose reparentSubtreeHeight == height: nested loops over a leaf.
local function makeChain(height)
    if height <= 0 then
        return makeLeaf("/cast Bottom")
    end
    return makeLoop({ makeChain(height - 1) })
end

-- ---------------------------------------------------------------------------
-- Cases.
-- ---------------------------------------------------------------------------

test("a: reparent a leaf into a top-level loop", function()
    local leaf = makeLeaf("/cast Fireball")
    local loop = makeLoop({})
    SLV.workingActions = { leaf, loop }
    resetUndo()
    local ok = SLV:_reparentNodeIntoLoop(1, 2)
    assertTrue(ok, "reparent succeeded")
    assertEqual(1, #SLV.workingActions, "workingActions count -1")
    assertEqual(loop, SLV.workingActions[1], "loop remains the only top-level node")
    assertEqual(1, #loop.children, "loop.children count +1")
    assertEqual(leaf, loop.children[#loop.children], "moved node appended last")
end)

test("b: target is not a loop (If) -> false,'type'; tree unchanged", function()
    local leaf = makeLeaf()
    local ifNode = makeIf({ makeLeaf() }, {})
    SLV.workingActions = { leaf, ifNode }
    resetUndo()
    local ok, reason = SLV:_reparentNodeIntoLoop(1, 2)
    assertEqual(false, ok, "rejected")
    assertEqual("type", reason, "reason is type")
    assertEqual(2, #SLV.workingActions, "tree unchanged (count)")
    assertEqual(leaf, SLV.workingActions[1], "leaf still at index 1")
    assertTrue(recordedUndo == nil, "no undo pushed on rejection")
end)

test("c: src == loopIdx -> false,'self'", function()
    local loop = makeLoop({})
    SLV.workingActions = { loop }
    resetUndo()
    local ok, reason = SLV:_reparentNodeIntoLoop(1, 1)
    assertEqual(false, ok, "rejected")
    assertEqual("self", reason, "reason is self")
    assertEqual(1, #SLV.workingActions, "tree unchanged")
end)

test("d: depth cap exceeded -> false,'depth'; tree unchanged", function()
    -- Top-level loop sits at compile-depth 1. Moving a subtree of height 9 puts
    -- its deepest leaf at 1 + 1 + 9 = 11 > ACTION_MAX_DEPTH (10) -> reject.
    local tall = makeChain(9)
    local loop = makeLoop({})
    SLV.workingActions = { tall, loop }
    resetUndo()
    local ok, reason = SLV:_reparentNodeIntoLoop(1, 2)
    assertEqual(false, ok, "rejected")
    assertEqual("depth", reason, "reason is depth")
    assertEqual(2, #SLV.workingActions, "tree unchanged (count)")
    assertEqual(0, #loop.children, "loop.children untouched")
end)

test("d2: depth exactly at MAX is allowed (boundary)", function()
    -- 1 + 1 + 8 = 10 == ACTION_MAX_DEPTH -> allowed (gate uses strictly greater).
    local tall = makeChain(8)
    local loop = makeLoop({})
    SLV.workingActions = { tall, loop }
    resetUndo()
    local ok = SLV:_reparentNodeIntoLoop(1, 2)
    assertTrue(ok, "boundary depth allowed")
    assertEqual(1, #loop.children, "moved into loop at the boundary")
end)

test("e: undo restores the node; redo re-applies", function()
    local leaf = makeLeaf("/cast Frostbolt")
    local loop = makeLoop({})
    SLV.workingActions = { leaf, loop }
    resetUndo()
    local ok = SLV:_reparentNodeIntoLoop(1, 2)
    assertTrue(ok, "reparent ok")
    assertEqual("Reparent step into loop", recordedLabel, "undo label recorded")
    assertTrue(type(recordedUndo) == "function", "undo closure recorded")

    recordedUndo()
    assertEqual(2, #SLV.workingActions, "undo: workingActions restored")
    assertEqual(0, #loop.children, "undo: loop.children restored")
    assertEqual(leaf, SLV.workingActions[1], "undo: leaf back at index 1")

    assertTrue(type(recordedRedo) == "function", "redo closure recorded")
    recordedRedo()
    assertEqual(1, #SLV.workingActions, "redo: removed from top-level")
    assertEqual(1, #loop.children, "redo: re-appended to loop")
    assertEqual(leaf, loop.children[1], "redo: same node back in loop")
end)

test("f: depth gate counts an else-only If's deep false branch (no bypass)", function()
    -- If with an EMPTY true branch and a false branch nested 8 loops deep over a
    -- leaf: true subtree height = 1 (If->branch) + 8 = 9. Into a top-level loop:
    -- 1 + 1 + 9 = 11 > ACTION_MAX_DEPTH (10) -> must reject. A children[1][1]
    -- shape heuristic under-counts this to height 1 and would wrongly allow it.
    local elseHeavyIf = makeIf({}, { makeChain(8) })
    local loop = makeLoop({})
    SLV.workingActions = { elseHeavyIf, loop }
    resetUndo()
    local ok, reason = SLV:_reparentNodeIntoLoop(1, 2)
    assertEqual(false, ok, "rejected")
    assertEqual("depth", reason, "reason is depth")
    assertEqual(2, #SLV.workingActions, "tree unchanged (count)")
    assertEqual(0, #loop.children, "loop.children untouched")
end)

test("f2: else-only If at the depth boundary is allowed", function()
    -- Empty true branch, false branch 7 deep: height = 1 + 7 = 8.
    -- 1 + 1 + 8 = 10 == ACTION_MAX_DEPTH -> allowed (gate is strictly greater).
    local elseIf = makeIf({}, { makeChain(7) })
    local loop = makeLoop({})
    SLV.workingActions = { elseIf, loop }
    resetUndo()
    local ok = SLV:_reparentNodeIntoLoop(1, 2)
    assertTrue(ok, "else-only If at boundary allowed")
    assertEqual(1, #loop.children, "moved into loop at the boundary")
end)

-- ---------------------------------------------------------------------------
-- SLV:_reparentNodeIntoContainer: the cross-pane drop (drag a top-level node
-- into the OPEN detail container BY REFERENCE). A Loop appends to its flat
-- children; an If appends to the active branch (default _detailSelectedBranch).
-- Same depth gate as the loop-row path, plus a cycle guard -- never drop a node
-- into its own subtree.
-- ---------------------------------------------------------------------------

test("h: into a Loop by reference -- count -1, child appended last", function()
    local leaf = makeLeaf("/cast Pyroblast")
    local loop = makeLoop({})
    SLV.workingActions = { leaf, loop }
    resetUndo()
    local ok = SLV:_reparentNodeIntoContainer(1, loop)
    assertTrue(ok, "reparent into container succeeded")
    assertEqual(1, #SLV.workingActions, "workingActions count -1")
    assertEqual(loop, SLV.workingActions[1], "loop remains the only top-level node")
    assertEqual(1, #loop.children, "loop.children count +1")
    assertEqual(leaf, loop.children[#loop.children], "moved node appended last")
end)

test("i: into an If's active branch lands in children[2], not children[1]", function()
    local leaf = makeLeaf("/cast Renew")
    local ifNode = makeIf({}, {})
    SLV.workingActions = { leaf, ifNode }
    SLV._detailSelectedBranch = 2
    resetUndo()
    local ok = SLV:_reparentNodeIntoContainer(1, ifNode)
    assertTrue(ok, "reparent into If active branch succeeded")
    assertEqual(1, #SLV.workingActions, "workingActions count -1")
    assertEqual(0, #ifNode.children[1], "true branch untouched")
    assertEqual(1, #ifNode.children[2], "false branch +1")
    assertEqual(leaf, ifNode.children[2][1], "moved node in the active (false) branch")
    SLV._detailSelectedBranch = nil
end)

test("j: cycle -- container is a descendant of the dragged node -> false,'cycle'", function()
    local innerLoop = makeLoop({})
    local outerLoop = makeLoop({ innerLoop })
    SLV.workingActions = { outerLoop }
    resetUndo()
    local ok, reason = SLV:_reparentNodeIntoContainer(1, innerLoop)
    assertEqual(false, ok, "rejected")
    assertEqual("cycle", reason, "reason is cycle")
    assertEqual(1, #SLV.workingActions, "tree unchanged (count)")
    assertEqual(outerLoop, SLV.workingActions[1], "outer loop still top-level")
    assertEqual(1, #outerLoop.children, "outer loop children unchanged")
    assertTrue(recordedUndo == nil, "no undo pushed on rejection")
end)

test("k: non-container target (Pause) -> false,'type'; tree unchanged", function()
    local leaf = makeLeaf()
    local pause = { type = "pause" }
    SLV.workingActions = { leaf, pause }
    resetUndo()
    local ok, reason = SLV:_reparentNodeIntoContainer(1, pause)
    assertEqual(false, ok, "rejected")
    assertEqual("type", reason, "reason is type")
    assertEqual(2, #SLV.workingActions, "tree unchanged (count)")
    assertEqual(leaf, SLV.workingActions[1], "leaf still at index 1")
    assertTrue(recordedUndo == nil, "no undo pushed on rejection")
end)

test("l: depth cap exceeded via the container -> false,'depth'; tree unchanged", function()
    -- Loop sits at compile-depth 1; a subtree of height 9 -> 1 + 1 + 9 = 11 > MAX.
    local tall = makeChain(9)
    local loop = makeLoop({})
    SLV.workingActions = { tall, loop }
    resetUndo()
    local ok, reason = SLV:_reparentNodeIntoContainer(1, loop)
    assertEqual(false, ok, "rejected")
    assertEqual("depth", reason, "reason is depth")
    assertEqual(2, #SLV.workingActions, "tree unchanged (count)")
    assertEqual(0, #loop.children, "loop.children untouched")
end)

test("m: undo restores the node to its top-level slot; redo re-applies", function()
    local leaf = makeLeaf("/cast Heal")
    local loop = makeLoop({})
    SLV.workingActions = { leaf, loop }
    resetUndo()
    local ok = SLV:_reparentNodeIntoContainer(1, loop)
    assertTrue(ok, "reparent ok")
    assertEqual("Reparent step into container", recordedLabel, "undo label recorded")
    assertTrue(type(recordedUndo) == "function", "undo closure recorded")

    recordedUndo()
    assertEqual(2, #SLV.workingActions, "undo: workingActions restored")
    assertEqual(0, #loop.children, "undo: loop.children restored")
    assertEqual(leaf, SLV.workingActions[1], "undo: leaf back at index 1")

    assertTrue(type(recordedRedo) == "function", "redo closure recorded")
    recordedRedo()
    assertEqual(1, #SLV.workingActions, "redo: removed from top-level")
    assertEqual(1, #loop.children, "redo: re-appended to container")
    assertEqual(leaf, loop.children[1], "redo: same node back in container")
end)

-- ---------------------------------------------------------------------------
-- _computeNodeDepth: locate a node and return its compile-depth. Drives the
-- + Add menu depth gate (_showAddMenu). The same If-shape misclassification
-- that broke reparentSubtreeHeight also broke this walker: an else-only If
-- (empty true branch, populated false branch) was treated as a flat node
-- array, so a target inside the false branch was never found and the walker
-- returned nil -- skipping the depth gate and admitting an over-depth add.
-- ---------------------------------------------------------------------------

test("g: _computeNodeDepth finds a node in an else-only If's false branch", function()
    -- Empty true branch, target leaf directly in the false branch.
    -- depth: workingActions (1) -> If branch array (2). Expected 2.
    local target = makeLeaf("/cast Smite")
    local elseIf = makeIf({}, { target })
    SLV.workingActions = { elseIf }
    assertEqual(2, SLV:_computeNodeDepth(target), "else-only If false-branch leaf at depth 2")
end)

test("g2: _computeNodeDepth descends a loop nested in an else-only If's false branch", function()
    -- Empty true branch -> false branch holds a loop -> target leaf inside it.
    -- depth: actions (1) -> If branch (2) -> loop children (3). Expected 3.
    local target = makeLeaf()
    local innerLoop = makeLoop({ target })
    local elseIf = makeIf({}, { innerLoop })
    SLV.workingActions = { elseIf }
    assertEqual(3, SLV:_computeNodeDepth(target), "leaf under loop in else-only If at depth 3")
end)

test("g3: _computeNodeDepth still finds a node in a populated true branch (regression)", function()
    local target = makeLeaf()
    local ifNode = makeIf({ target }, {})
    SLV.workingActions = { ifNode }
    assertEqual(2, SLV:_computeNodeDepth(target), "true-branch leaf at depth 2")
end)

test("g4: _computeNodeDepth finds a false-branch node when the true branch is also populated", function()
    local target = makeLeaf("/cast Shadow Word: Pain")
    local ifNode = makeIf({ makeLeaf("/cast Smite") }, { target })
    SLV.workingActions = { ifNode }
    assertEqual(2, SLV:_computeNodeDepth(target), "false-branch leaf at depth 2 (true branch populated)")
end)

test("g5: _computeNodeDepth descends a plain loop (regression)", function()
    local target = makeLeaf()
    local loop = makeLoop({ target })
    SLV.workingActions = { loop }
    assertEqual(2, SLV:_computeNodeDepth(target), "leaf inside loop at depth 2")
end)

test("g6: _computeNodeDepth returns 1 for a top-level node and nil for an absent node", function()
    local target = makeLeaf()
    local other = makeLeaf()
    SLV.workingActions = { target }
    assertEqual(1, SLV:_computeNodeDepth(target), "top-level node at depth 1")
    assertEqual(nil, SLV:_computeNodeDepth(other), "absent node returns nil")
end)

-- ---------------------------------------------------------------------------
-- Run.
-- ---------------------------------------------------------------------------

local passed = 0
local failed = 0
for _, t in ipairs(tests) do
    local ok, err = pcall(t.fn)
    if ok then
        passed = passed + 1
        print("PASS  " .. t.name)
    else
        failed = failed + 1
        print("FAIL  " .. t.name .. " -- " .. tostring(err))
    end
end
print(string.format("RESULT %d passed, %d failed", passed, failed))
os.exit(failed > 0 and 1 or 0)
