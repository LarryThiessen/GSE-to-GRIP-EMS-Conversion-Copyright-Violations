-- GRIP-EMS: Sequence List
-- Left panel: search box, scrollable sequence list, bottom button bar

local ADDON_NAME, GRIPEMS = ...
local UI = GRIPEMS.UI
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS")

-- Upvalue accessor for Defaults (loaded before UI/)
local function D() return GRIPEMS.Defaults end

GRIPEMS.SequenceList = {}
local SL = GRIPEMS.SequenceList

-- Runtime state
SL.searchText = ""
SL.sortMode = "alpha"
SL.pendingSelect = nil

---------------------------------------------------------------------------
-- Initialization (called from UI:InitPanels)
---------------------------------------------------------------------------

--- Build the sequence list UI inside the left panel.
--- @param parentPanel Frame The MainFrame.leftPanel
function SL:Init(parentPanel)
    if not parentPanel then return end
    local C = UI.Colors

    -- Remove the placeholder text
    local mainFrame = GRIPEMS_MainFrame
    if mainFrame and mainFrame.leftPlaceholder then
        mainFrame.leftPlaceholder:Hide()
        mainFrame.leftPlaceholder:SetText("")
    end

    -----------------------------------------------------------------------
    -- Search box
    -----------------------------------------------------------------------
    local searchBox = CreateFrame("EditBox", nil, parentPanel, "SearchBoxTemplate")
    searchBox:SetHeight(D().SEARCH_BOX_HEIGHT)
    searchBox:SetPoint("TOPLEFT", parentPanel, "TOPLEFT", 6, -6)
    searchBox:SetPoint("TOPRIGHT", parentPanel, "TOPRIGHT", -6, -6)
    searchBox:SetAutoFocus(false)
    searchBox:SetScript("OnTextChanged", function(self)
        SearchBoxTemplate_OnTextChanged(self)
        SL.searchText = self:GetText() or ""
        SL:RefreshDataProvider()
    end)
    searchBox:SetScript("OnEnter", function(self)
        UI:ShowTooltip(self, L["GEMS_UI_SEARCH"], L["GEMS_UI_SEARCH_DESC"])
    end)
    searchBox:SetScript("OnLeave", function()
        UI:HideTooltip()
    end)
    SL.searchBox = searchBox

    -----------------------------------------------------------------------
    -- Button bar (bottom)
    -----------------------------------------------------------------------
    local buttonBar = CreateFrame("Frame", nil, parentPanel)
    buttonBar:SetHeight(D().BUTTON_BAR_HEIGHT)
    buttonBar:SetPoint("BOTTOMLEFT", parentPanel, "BOTTOMLEFT", 4, 4)
    buttonBar:SetPoint("BOTTOMRIGHT", parentPanel, "BOTTOMRIGHT", -4, 4)
    SL.buttonBar = buttonBar

    local newBtn = UI:CreateButton(buttonBar, L["GEMS_UI_NEW"], 80, 26)
    newBtn:SetPoint("LEFT", buttonBar, "LEFT", 2, 0)
    newBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.bgRowHover:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
        UI:ShowTooltip(self, L["GEMS_UI_NEW"], L["GEMS_UI_NEW_DESC"])
    end)
    newBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
        UI:HideTooltip()
    end)
    newBtn:SetScript("OnClick", function()
        SL:ShowNewSequenceDialog()
    end)

    local importBtn = UI:CreateButton(buttonBar, L["GEMS_UI_IMPORT_BTN"], 80, 26)
    importBtn:SetPoint("LEFT", newBtn, "RIGHT", 4, 0)
    importBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.bgRowHover:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
        UI:ShowTooltip(self, L["GEMS_UI_IMPORT_BTN"], L["GEMS_UI_IMPORT_BTN_DESC"])
    end)
    importBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
        UI:HideTooltip()
    end)
    importBtn:SetScript("OnClick", function()
        if GRIPEMS.ImportFrame then
            GRIPEMS.ImportFrame:Show()
        end
    end)

    -- Migrate button (only if migration module exists and a source sequencer is detected)
    local GM = GRIPEMS.GSEMigrate
    if GM then
        local gseStatus = GM.GetGSEStatus()
        if gseStatus ~= "none" then
            local migrateBtn = UI:CreateButton(buttonBar,
                L["GEMS_UI_MIGRATE_BTN"], 80, 26)
            migrateBtn:SetPoint("LEFT", importBtn, "RIGHT", 4, 0)

            if gseStatus == "active" then
                migrateBtn:SetScript("OnEnter", function(self)
                    self:SetBackdropColor(C.bgRowHover:GetRGBA())
                    self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
                    UI:ShowTooltip(self, L["GEMS_UI_MIGRATE_BTN"],
                        L["GEMS_UI_MIGRATE_BTN_DESC"])
                end)
                migrateBtn:SetScript("OnLeave", function(self)
                    self:SetBackdropColor(C.bgButton:GetRGBA())
                    self:SetBackdropBorderColor(C.border:GetRGBA())
                    UI:HideTooltip()
                end)
                migrateBtn:SetScript("OnClick", function()
                    SL:ShowMigrateConfirm()
                end)
            else
                -- Source disabled: gray out, tooltip instructs user
                migrateBtn:SetAlpha(0.5)
                migrateBtn:SetScript("OnEnter", function(self)
                    UI:ShowTooltip(self, L["GEMS_UI_MIGRATE_BTN"],
                        L["GEMS_MIGRATE_GSE_DISABLED"])
                end)
                migrateBtn:SetScript("OnLeave", function()
                    UI:HideTooltip()
                end)
                migrateBtn:SetScript("OnClick", function()
                    GRIPEMS:Print(L["GEMS_MIGRATE_GSE_DISABLED"])
                end)
            end
        end
    end

    -----------------------------------------------------------------------
    -- ScrollBox + ScrollBar + ScrollView
    -----------------------------------------------------------------------
    local scrollBox = CreateFrame("Frame", nil, parentPanel, "WowScrollBoxList")
    scrollBox:SetPoint("TOPLEFT", searchBox, "BOTTOMLEFT", 0, -4)
    scrollBox:SetPoint("BOTTOMRIGHT", buttonBar, "TOPRIGHT", -18, 4)
    SL.scrollBox = scrollBox

    local scrollBar = CreateFrame("EventFrame", nil, parentPanel, "MinimalScrollBar")
    scrollBar:SetPoint("TOPLEFT", scrollBox, "TOPRIGHT", 2, 0)
    scrollBar:SetPoint("BOTTOMLEFT", scrollBox, "BOTTOMRIGHT", 2, 0)
    SL.scrollBar = scrollBar

    local scrollView = CreateScrollBoxListLinearView()
    scrollView:SetElementExtent(D().ROW_HEIGHT)
    SL.scrollView = scrollView

    -- Element initializer: "Button" frame type gives click/hover natively
    scrollView:SetElementInitializer("Button", function(button, data)
        SL:InitRow(button, data)
    end)

    ScrollUtil.InitScrollBoxListWithScrollBar(scrollBox, scrollBar, scrollView)

    -- Initial empty DataProvider
    local dataProvider = CreateDataProvider()
    scrollBox:SetDataProvider(dataProvider)
    SL.dataProvider = dataProvider

    -- Empty state label (shown when no sequences)
    local emptyLabel = parentPanel:CreateFontString(nil, "OVERLAY")
    UI:SetFont(emptyLabel, 11)
    emptyLabel:SetPoint("CENTER", scrollBox, "CENTER", 0, 0)
    emptyLabel:SetText(L["GEMS_UI_NO_SEQUENCES"])
    emptyLabel:SetTextColor(C.textMuted:GetRGBA())
    emptyLabel:Hide()
    SL.emptyLabel = emptyLabel

    -----------------------------------------------------------------------
    -- Register callbacks
    -----------------------------------------------------------------------
    if GRIPEMS.RegisterCallback then
        GRIPEMS.RegisterCallback(SL, "SEQUENCE_CREATED", "OnSequenceChanged")
        GRIPEMS.RegisterCallback(SL, "SEQUENCE_DELETED", "OnSequenceChanged")
        GRIPEMS.RegisterCallback(SL, "SEQUENCE_UPDATED", "OnSequenceChanged")
        GRIPEMS.RegisterCallback(SL, "SEQUENCE_IMPORTED", "OnSequenceChanged")
        GRIPEMS.RegisterCallback(SL, "KEYBIND_CHANGED", "OnSequenceChanged")
    end
end

--- Callback handler for any sequence data change.
function SL:OnSequenceChanged()
    GRIPEMS:Debug("SL:OnSequenceChanged triggered")
    self:RefreshDataProvider()
end

---------------------------------------------------------------------------
-- Row initializer (called for each visible row by ScrollBox)
---------------------------------------------------------------------------

--- Initialize or refresh a row button with sequence data.
--- ScrollBox reuses frames; all child elements must be created once, then refreshed.
--- @param button Button The reusable row frame
--- @param data table Row data { name, icon, stepFunction, stepCount, keybind, ... }
function SL:InitRow(button, data)
    local C = UI.Colors

    -- Set button size
    button:SetHeight(D().ROW_HEIGHT)

    -- Create child elements once, then reuse
    if not button._gripInit then
        if not button.SetBackdrop then
            Mixin(button, BackdropTemplateMixin)
        end

        button:SetBackdrop(UI.Backdrops.panel)
        button:RegisterForClicks("LeftButtonUp", "RightButtonUp")

        -- Icon texture
        button.icon = button:CreateTexture(nil, "ARTWORK")
        button.icon:SetSize(28, 28)
        button.icon:SetPoint("LEFT", button, "LEFT", 4, 0)

        -- Name text
        button.nameText = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(button.nameText, 13)
        button.nameText:SetPoint("TOPLEFT", button.icon, "TOPRIGHT", 6, -1)
        button.nameText:SetPoint("RIGHT", button, "RIGHT", -60, 0)
        button.nameText:SetJustifyH("LEFT")
        button.nameText:SetWordWrap(false)

        -- Subtitle text
        button.subtitleText = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(button.subtitleText, 10)
        button.subtitleText:SetPoint("BOTTOMLEFT", button.icon, "BOTTOMRIGHT", 6, 1)
        button.subtitleText:SetPoint("RIGHT", button, "RIGHT", -60, 0)
        button.subtitleText:SetJustifyH("LEFT")
        button.subtitleText:SetWordWrap(false)

        -- Keybind text
        button.keybindText = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(button.keybindText, 11)
        button.keybindText:SetPoint("RIGHT", button, "RIGHT", -6, 0)
        button.keybindText:SetJustifyH("RIGHT")

        button._gripInit = true
    end

    -- Populate from data (type-aware icon resolution)
    if type(data.icon) == "number" then
        button.icon:SetTexture(data.icon)
    elseif type(data.icon) == "string" and data.icon ~= "" then
        button.icon:SetTexture("Interface\\Icons\\" .. data.icon)
    else
        button.icon:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
    end
    button.nameText:SetText(data.name or "")
    button.nameText:SetTextColor(C.textPrimary:GetRGBA())

    local subtitle = string.format(L["GEMS_UI_ROW_SUBTITLE"],
        data.stepFunction or "Sequential", data.stepCount or 0)
    button.subtitleText:SetText(subtitle)
    button.subtitleText:SetTextColor(C.textSecondary:GetRGBA())

    local keybind = data.keybind or ""
    button.keybindText:SetText(keybind)
    if keybind ~= "" then
        button.keybindText:SetTextColor(C.keybindGold:GetRGBA())
    else
        button.keybindText:SetTextColor(C.textMuted:GetRGBA())
    end

    -- Selection state
    local isSelected = (data.name == UI.selectedSequence)
    if isSelected then
        button:SetBackdropColor(C.bgRowSelected:GetRGBA())
        button:SetBackdropBorderColor(C.borderFocus:GetRGBA())
    else
        button:SetBackdropColor(C.bgPanel:GetRGBA())
        button:SetBackdropBorderColor(C.border:GetRGBA())
    end

    -- Store data ref for click handlers
    button._seqData = data

    -- Hover
    button:SetScript("OnEnter", function(self)
        if self._seqData and self._seqData.name ~= UI.selectedSequence then
            self:SetBackdropColor(C.bgRowHover:GetRGBA())
        end
        if self._seqData and self._seqData.description
            and self._seqData.description ~= "" then
            UI:ShowTooltip(self, self._seqData.name, self._seqData.description)
        end
    end)
    button:SetScript("OnLeave", function(self)
        if self._seqData and self._seqData.name ~= UI.selectedSequence then
            self:SetBackdropColor(C.bgPanel:GetRGBA())
            self:SetBackdropBorderColor(C.border:GetRGBA())
        end
        UI:HideTooltip()
    end)

    -- Click
    button:SetScript("OnClick", function(self, mouseButton)
        if not self._seqData then return end
        if mouseButton == "RightButton" then
            SL:ShowContextMenu(self, self._seqData)
        else
            SL:SelectSequence(self._seqData.name)
        end
    end)
end

---------------------------------------------------------------------------
-- Data provider management
---------------------------------------------------------------------------

--- Rebuild the DataProvider from Engine.sequences, applying search filter and sort.
function SL:RefreshDataProvider()
    if not SL.scrollView then return end

    local entries = {}
    local engine = GRIPEMS.Engine
    if engine and engine.sequences then
        local KM = GRIPEMS.KeybindManager
        for name, entry in pairs(engine.sequences) do
            local seqData = entry.data
            if seqData then
                -- Apply search filter
                local searchLower = SL.searchText:lower()
                if searchLower == "" or
                    name:lower():find(searchLower, 1, true) then
                    -- Get active version for display data
                    local ver = GRIPEMS.Engine:GetActiveVersion(seqData)
                    local verSteps = ver and ver.steps or {}
                    local verStepFunc = ver and ver.stepFunction or "Sequential"

                    -- Resolve display icon using same priority chain as editor
                    local displayIcon
                    if seqData.autoIcon == false and type(seqData.icon) == "number" then
                        -- Manual numeric pick
                        displayIcon = seqData.icon
                    else
                        -- Auto-detect from step content
                        local SC = GRIPEMS.SpellCache
                        if SC and #verSteps > 0 then
                            local text
                            if verStepFunc == "Priority" then
                                text = table.concat(verSteps, "\n")
                            else
                                text = verSteps[1]
                            end
                            local spellName = SC:ParseSpellFromMacrotext(text)
                            if spellName then
                                displayIcon = SC:GetIcon(spellName)
                            end
                        end
                    end
                    -- Fall back to legacy string icon or question mark
                    if not displayIcon then
                        displayIcon = seqData.icon or "INV_Misc_QuestionMark"
                    end

                    table.insert(entries, {
                        name = name,
                        icon = displayIcon,
                        stepFunction = verStepFunc,
                        stepCount = #verSteps,
                        keybind = (KM and KM.GetKeybind)
                            and KM:GetKeybind(name) or "",
                        classID = seqData.classID or 0,
                        updatedAt = seqData.updatedAt or 0,
                        description = seqData.description or "",
                    })
                end
            end
        end
    end

    GRIPEMS:Debug("SL:RefreshDataProvider: " .. #entries .. " entries")

    -- Sort
    if SL.sortMode == "alpha" then
        table.sort(entries, function(a, b)
            return (a.name or ""):lower() < (b.name or ""):lower()
        end)
    elseif SL.sortMode == "class" then
        table.sort(entries, function(a, b)
            if a.classID ~= b.classID then
                return (a.classID or 0) < (b.classID or 0)
            end
            return (a.name or ""):lower() < (b.name or ""):lower()
        end)
    elseif SL.sortMode == "updated" then
        table.sort(entries, function(a, b)
            return (a.updatedAt or 0) > (b.updatedAt or 0)
        end)
    end

    -- Create new DataProvider (no Flush method exists)
    local dp = CreateDataProvider()
    dp:InsertTable(entries)
    SL.scrollBox:SetDataProvider(dp)
    SL.dataProvider = dp
    GRIPEMS:Debug("SL:RefreshDataProvider: SetDataProvider done")
    if SL.scrollBox.ForceLayout then
        SL.scrollBox:ForceLayout()
    end

    -- Empty state
    if SL.emptyLabel then
        if #entries == 0 then
            SL.emptyLabel:Show()
        else
            SL.emptyLabel:Hide()
        end
    end
end

---------------------------------------------------------------------------
-- Selection
---------------------------------------------------------------------------

--- Select a sequence by name. If the editor has unsaved changes, prompt first.
--- @param name string|nil Sequence name to select
function SL:SelectSequence(name)
    local SE = GRIPEMS.SequenceEditor
    if SE and SE.isDirty then
        SL.pendingSelect = name
        SE:PromptSave()
        return  -- popup callbacks handle the actual load
    end
    SL:DoSelectSequence(name)
end

--- Perform the actual sequence selection (no dirty-state check).
--- @param name string|nil Sequence name to select
function SL:DoSelectSequence(name)
    UI.selectedSequence = name
    SL:RefreshDataProvider()
    if GRIPEMS.SequenceEditor then
        GRIPEMS.SequenceEditor:LoadSequence(name)
    end
end

---------------------------------------------------------------------------
-- Context menu
---------------------------------------------------------------------------

--- Show a right-click context menu for a sequence row.
--- @param button Button The row frame (menu anchor)
--- @param data table Row data
function SL:ShowContextMenu(button, data)
    if not data or not data.name then return end
    MenuUtil.CreateContextMenu(button, function(ownerRegion, rootDescription)
        rootDescription:CreateTitle(data.name)
        rootDescription:CreateButton(L["GEMS_UI_DUPLICATE"], function()
            SL:ShowDuplicateDialog(data.name)
        end)
        rootDescription:CreateButton(L["GEMS_UI_EXPORT_CTX"], function()
            local GE = GRIPEMS.GRIPExport
            if not GE then return end
            local ok, result = GE.Export(data.name)
            if ok then
                local EF = GRIPEMS.ExportFrame
                if EF then
                    EF:Show(data.name, result)
                else
                    GRIPEMS:Print(string.format(L["GEMS_EXPORT_RESULT"], result))
                end
            else
                GRIPEMS:Print(string.format(L["GEMS_EXPORT_FAILED"],
                    tostring(result)))
            end
        end)
        rootDescription:CreateButton(L["GEMS_UI_SEND_PLAYER"], function()
            if GRIPEMS.Transmission then
                GRIPEMS.Transmission:ShowSendDialog(data.name)
            end
        end)
        rootDescription:CreateButton(L["GEMS_UI_EXPORT_MULTI"], function()
            GRIPEMS.ExportFrame:Show()
        end)
        rootDescription:CreateButton(L["GEMS_UI_RENAME"], function()
            SL:ShowRenameDialog(data.name)
        end)
        rootDescription:CreateButton("|cFFFF4444" .. L["GEMS_UI_DELETE"] .. "|r",
            function()
                SL:ShowDeleteConfirm(data.name)
            end)
    end)
end

---------------------------------------------------------------------------
-- Dialogs
---------------------------------------------------------------------------

--- Show the "New Sequence" dialog.
function SL:ShowNewSequenceDialog()
    StaticPopupDialogs["GRIPEMS_NEW_SEQUENCE"] = {
        text = L["GEMS_UI_NEW_SEQ_DESC"],
        button1 = ACCEPT,
        button2 = CANCEL,
        hasEditBox = true,
        editBoxWidth = 250,
        OnAccept = function(self)
            local name = self.EditBox:GetText():trim()
            if name == "" then
                GRIPEMS:Print(L["GEMS_UI_NAME_EMPTY"])
                return
            end
            if GRIPEMS.Engine and GRIPEMS.Engine.sequences
                and GRIPEMS.Engine.sequences[name] then
                GRIPEMS:Print(string.format(L["GEMS_UI_NAME_EXISTS"], name))
                return
            end
            local defaults = D()
            local seqData = {
                name = name,
                icon = defaults.NewSequence.icon,
                defaultVersion = 1,
                versions = {
                    [1] = {
                        stepFunction = defaults.NewVersion.stepFunction,
                        steps = {},
                        resetOnCombat = defaults.NewVersion.resetOnCombat,
                        resetOnTarget = defaults.NewVersion.resetOnTarget,
                        resetOnGear = defaults.NewVersion.resetOnGear,
                        resetOnSpec = defaults.NewVersion.resetOnSpec,
                        resetTimer = defaults.NewVersion.resetTimer,
                    },
                },
                author = UnitName("player") or "",
                version = "1",
                description = "",
                classID = select(3, UnitClass("player")) or 0,
                specID = nil,
                createdAt = time(),
                updatedAt = time(),
            }
            GRIPEMS.Engine:ActivateSequence(name, seqData)
            C_Timer.After(0.1, function()
                SL:SelectSequence(name)
            end)
        end,
        OnShow = function(self)
            self.EditBox:SetText("")
            self.EditBox:SetFocus()
        end,
        timeout = 0,
        whileDead = true,
        hideOnEscape = true,

    }
    StaticPopup_Show("GRIPEMS_NEW_SEQUENCE")
end

--- Show a delete confirmation dialog.
--- @param name string Sequence name to delete
function SL:ShowDeleteConfirm(name)
    StaticPopupDialogs["GRIPEMS_DELETE_CONFIRM"] = {
        text = string.format(L["GEMS_UI_DELETE_CONFIRM"], name),
        button1 = ACCEPT,
        button2 = CANCEL,
        OnAccept = function()
            -- Block delete during combat (protected APIs required)
            if InCombatLockdown() then
                GRIPEMS:Print(L["GEMS_DELETE_COMBAT"])
                return
            end
            -- Clear UI state BEFORE engine cleanup so RefreshDataProvider
            -- sees clean selectedSequence during the SEQUENCE_DELETED callback
            if UI.selectedSequence == name then
                UI.selectedSequence = nil
                if GRIPEMS.SequenceEditor then
                    GRIPEMS.SequenceEditor:Clear()
                end
            end
            -- Purge saved keybind data across ALL specs (permanent delete)
            local KM = GRIPEMS.KeybindManager
            if KM and KM.PurgeKeybinds then
                KM:PurgeKeybinds(name)
            end
            -- Engine teardown: unbind live key, hide button, remove from
            -- engine.sequences + SavedVariables, delete macro stub,
            -- fire SEQUENCE_DELETED (triggers RefreshDataProvider via callback)
            GRIPEMS.Engine:DeactivateSequence(name)
            -- Safety-net refresh in case ScrollBox deferred its layout pass
            if SL.RefreshDataProvider then
                SL:RefreshDataProvider()
            end
        end,
        timeout = 0,
        whileDead = true,
        hideOnEscape = true,
    }
    StaticPopup_Show("GRIPEMS_DELETE_CONFIRM")
end

--- Show the duplicate sequence dialog.
--- @param sourceName string Source sequence name
function SL:ShowDuplicateDialog(sourceName)
    StaticPopupDialogs["GRIPEMS_DUPLICATE_SEQ"] = {
        text = L["GEMS_UI_DUP_DESC"],
        button1 = ACCEPT,
        button2 = CANCEL,
        hasEditBox = true,
        editBoxWidth = 250,
        OnAccept = function(self)
            local newName = self.EditBox:GetText():trim()
            if newName == "" then
                GRIPEMS:Print(L["GEMS_UI_NAME_EMPTY"])
                return
            end
            local ok, err = GRIPEMS.Engine:DuplicateSequence(sourceName, newName)
            if not ok then
                GRIPEMS:Print(err or L["GEMS_UI_DUPLICATE_FAILED"])
            else
                C_Timer.After(0.1, function()
                    SL:SelectSequence(newName)
                end)
            end
        end,
        OnShow = function(self)
            self.EditBox:SetText(sourceName .. L["GEMS_UI_COPY_SUFFIX"])
            self.EditBox:HighlightText()
            self.EditBox:SetFocus()
        end,
        timeout = 0,
        whileDead = true,
        hideOnEscape = true,

    }
    StaticPopup_Show("GRIPEMS_DUPLICATE_SEQ")
end

--- Show the rename dialog.
--- @param oldName string Current sequence name
function SL:ShowRenameDialog(oldName)
    StaticPopupDialogs["GRIPEMS_RENAME_SEQ"] = {
        text = L["GEMS_UI_RENAME_DESC"],
        button1 = ACCEPT,
        button2 = CANCEL,
        hasEditBox = true,
        editBoxWidth = 250,
        OnAccept = function(self)
            local newName = self.EditBox:GetText():trim()
            if newName == "" then
                GRIPEMS:Print(L["GEMS_UI_NAME_EMPTY"])
                return
            end
            if newName == oldName then return end
            local engine = GRIPEMS.Engine
            if not engine or not engine.sequences then return end
            if engine.sequences[newName] then
                GRIPEMS:Print(string.format(L["GEMS_UI_NAME_EXISTS"], newName))
                return
            end

            -- Get old data and keybind
            local oldEntry = engine.sequences[oldName]
            if not oldEntry or not oldEntry.data then return end
            local oldData = oldEntry.data
            local KM = GRIPEMS.KeybindManager
            local oldKey = KM and KM:GetKeybind(oldName)

            -- Deep-copy the data with new name (version-aware)
            local newData = {
                name = newName,
                icon = oldData.icon,
                autoIcon = oldData.autoIcon,
                defaultVersion = oldData.defaultVersion or 1,
                versions = {},
                author = oldData.author or "",
                version = oldData.version or "1",
                description = oldData.description or "",
                classID = oldData.classID or 0,
                specID = oldData.specID,
                createdAt = oldData.createdAt or time(),
                updatedAt = time(),
            }
            -- Deep copy all versions
            if oldData.versions then
                for i, ver in ipairs(oldData.versions) do
                    newData.versions[i] = {
                        stepFunction = ver.stepFunction,
                        steps = {},
                        resetOnCombat = ver.resetOnCombat,
                        resetOnTarget = ver.resetOnTarget,
                        resetOnGear = ver.resetOnGear,
                        resetOnSpec = ver.resetOnSpec,
                        resetTimer = ver.resetTimer,
                    }
                    for j, step in ipairs(ver.steps) do
                        newData.versions[i].steps[j] = step
                    end
                end
            end

            -- Deactivate old, activate new
            GRIPEMS.Engine:DeactivateSequence(oldName)
            GRIPEMS.Engine:ActivateSequence(newName, newData)

            -- Re-apply keybind to new name
            if oldKey and KM then
                C_Timer.After(0.15, function()
                    KM:SetKeybind(newName, oldKey)
                end)
            end

            C_Timer.After(0.1, function()
                SL:SelectSequence(newName)
            end)
        end,
        OnShow = function(self)
            self.EditBox:SetText(oldName)
            self.EditBox:HighlightText()
            self.EditBox:SetFocus()
        end,
        timeout = 0,
        whileDead = true,
        hideOnEscape = true,

    }
    StaticPopup_Show("GRIPEMS_RENAME_SEQ")
end

--- Show the migration confirmation dialog.
function SL:ShowMigrateConfirm()
    local GM = GRIPEMS.GSEMigrate
    if not GM then return end
    local count = GM.GetGSESequenceCount()
    StaticPopupDialogs["GRIPEMS_MIGRATE_CONFIRM"] = {
        text = string.format(L["GEMS_MIGRATE_CONFIRM"], count),
        button1 = ACCEPT,
        button2 = CANCEL,
        OnAccept = function()
            local ok, results = GM.MigrateAll(false)
            if ok then
                if GRIPEMS.PrintMigrationReport then
                    GRIPEMS:PrintMigrationReport(results, "migrate")
                end
                SL:RefreshDataProvider()
            else
                GRIPEMS:Print(string.format(L["GEMS_MIGRATE_FAILED"],
                    tostring(results)))
            end
        end,
        timeout = 0,
        whileDead = true,
        hideOnEscape = true,
    }
    StaticPopup_Show("GRIPEMS_MIGRATE_CONFIRM")
end
