-- GRIP-EMS: Legacy Import Parser
-- Legacy format parser and flat action compiler for importing external sequences

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS")
local D = GRIPEMS.Defaults
local S = GRIPEMS.Serialization
local VS = GRIPEMS.VariableStore

GRIPEMS.GSEImport = {}
local GI = GRIPEMS.GSEImport

-- Legacy MetaData context fields that map 1:1 to GRIP-EMS context keys
local GSE_CONTEXT_FIELDS = {
    "Raid", "Arena", "PVP", "Mythic", "MythicPlus",
    "Heroic", "Dungeon", "Timewalking", "Party", "Scenario",
}

--- Import one or more sequences from an encoded legacy or GRIP1 string.
--- Detects payload format (COLLECTION, simple array, command) and processes
--- each sequence found: compile macro version, build sequenceData, activate.
--- @param encodedString string The full encoded string (with prefix)
--- @return boolean success
--- @return table|string result Import results table on success, error on failure
function GI.Import(encodedString)
    if not encodedString or encodedString == "" then
        return false, "No import string provided"
    end

    -- Check if this is a GRIP1 native format
    local format = S.DetectFormat(encodedString)
    if format == "GRIP1" then
        local ok, name, seqData = GRIPEMS.GRIPExport.ImportNative(encodedString)
        if ok then
            GRIPEMS.Engine:ActivateSequence(name, seqData)
            if GRIPEMS.Fire then
                GRIPEMS:Fire("SEQUENCE_IMPORTED", { count = 1, names = { name } })
            end
            local ver = GRIPEMS.Engine:GetActiveVersion(seqData)
            return true, { names = { name }, warnings = {}, count = 1,
                stepCounts = { [name] = ver and #ver.steps or 0 },
                stepFunctions = { [name] = ver and ver.stepFunction or "Sequential" },
                varsImported = 0, varsSkipped = 0,
                versionsDropped = 0, pausesSkipped = 0,
                embedsSkipped = 0, truncatedSteps = 0 }
        else
            return false, name  -- name is the error message in failure case
        end
    end

    -- Decode the string
    local ok, decoded = S.Decode(encodedString)
    if not ok then
        return false, decoded
    end

    local results = { names = {}, warnings = {}, count = 0, stepCounts = {},
        varsImported = 0, varsSkipped = 0, contextOverridesImported = 0,
        versionsDropped = 0, pausesSkipped = 0, embedsSkipped = 0,
        truncatedSteps = 0, stepFunctions = {} }

    -- Detect payload format and extract sequences
    if type(decoded) == "table" and decoded.type == "COLLECTION" then
        -- COLLECTION format (clipboard exports)
        local payload = decoded.payload
        if not payload or not payload.Sequences then
            return false, "COLLECTION has no Sequences"
        end

        local seqCount = 0
        for _ in pairs(payload.Sequences) do
            seqCount = seqCount + 1
        end

        for seqName, seqValue in pairs(payload.Sequences) do
            if type(seqValue) == "string" then
                -- Double-encoded: decode the inner encoded string
                local innerOk, innerDecoded = S.Decode(seqValue)
                if innerOk and type(innerDecoded) == "table"
                    and type(innerDecoded[1]) == "string"
                    and type(innerDecoded[2]) == "table" then
                    local importOk, importErr = GI.ProcessSequence(
                        innerDecoded[1], innerDecoded[2], results)
                    if not importOk then
                        results.warnings[#results.warnings + 1] =
                            string.format("'%s': %s", tostring(innerDecoded[1]), tostring(importErr))
                    end
                else
                    results.warnings[#results.warnings + 1] =
                        string.format("'%s': failed to decode inner sequence", tostring(seqName))
                end
            elseif type(seqValue) == "table" then
                -- Raw table (12.0.1+ style) - process directly
                local importOk, importErr = GI.ProcessSequence(seqName, seqValue, results)
                if not importOk then
                    results.warnings[#results.warnings + 1] =
                        string.format("'%s': %s", tostring(seqName), tostring(importErr))
                end
            end
        end

        -- Import variables from COLLECTION payload
        if payload.Variables and type(payload.Variables) == "table" then
            for varName, varValue in pairs(payload.Variables) do
                if type(varValue) == "string" then
                    -- Double-encoded variable (user selected in source export GUI)
                    local varOk, varDecoded = S.Decode(varValue)
                    if varOk and type(varDecoded) == "table" then
                        if type(varDecoded[1]) == "string"
                            and type(varDecoded[2]) == "table" then
                            local gripVar = GI.MapGSEVariable(
                                varDecoded[1], varDecoded[2])
                            GI.ImportVariable(varDecoded[1], gripVar, results)
                        else
                            local gripVar = GI.MapGSEVariable(
                                varName, varDecoded)
                            GI.ImportVariable(varName, gripVar, results)
                        end
                    else
                        results.warnings[#results.warnings + 1] =
                            "Variable '" .. varName .. "': failed to decode"
                    end
                elseif type(varValue) == "table" then
                    -- Raw table: auto-included from source dependency resolver
                    local gripVar = GI.MapGSEVariable(varName, varValue)
                    GI.ImportVariable(varName, gripVar, results)
                end
            end
        end

    elseif type(decoded) == "table" and decoded.Command then
        -- Command format (addon chat transmission) -- not supported
        return false, "Command format (addon transmission) is not supported"

    elseif type(decoded) == "table"
        and type(decoded[1]) == "string"
        and type(decoded[2]) == "table" then
        -- Simple array format: { name, sequence }
        local seqName = decoded[1]
        local sequence = decoded[2]
        local importOk, importErr = GI.ProcessSequence(seqName, sequence, results)
        if not importOk then
            return false, importErr
        end

    else
        return false, L["Unknown import format"]
    end

    if results.count == 0 then
        return false, "No sequences could be imported"
    end

    -- Notify listeners
    if GRIPEMS.Fire then
        GRIPEMS:Fire("SEQUENCE_IMPORTED", results)
    end

    return true, results
end

--- Map legacy MetaData context version fields into GRIP-EMS contextOverrides.
--- Source format stores integer version indices on MetaData (Raid, Arena, PVP, etc.).
--- If a context version equals the default, it means "use default" and is skipped.
--- @param metadata table|nil Imported sequence MetaData table
--- @param numVersions number Total number of imported versions (for bounds check)
--- @return table contextOverrides { ctxKey = versionIndex } (empty if no overrides)
function GI.MapGSEContextOverrides(metadata, numVersions)
    local overrides = {}
    if not metadata or type(metadata) ~= "table" then
        return overrides
    end
    local defaultIdx = tonumber(metadata.Default) or 1
    for _, field in ipairs(GSE_CONTEXT_FIELDS) do
        local idx = tonumber(metadata[field])
        if idx and idx >= 1 and idx <= numVersions and idx ~= defaultIdx then
            overrides[field] = idx
        end
    end
    return overrides
end

--- Process a single imported sequence: pick the default macro version, compile it,
--- build a GRIP-EMS sequenceData table, and activate it.
--- @param seqName string Sequence name
--- @param sequence table Imported sequence object
--- @param results table Import results accumulator
--- @param opts table|nil Optional metadata overrides (author, description, specID, updatedAt, classID, icon)
--- @return boolean success
--- @return string|nil error Error message on failure
function GI.ProcessSequence(seqName, sequence, results, opts)
    if not seqName or not sequence then
        return false, "Missing name or sequence data"
    end

    local macros = sequence.Macros or sequence.MacroVersions or sequence.Versions
    if not macros or #macros == 0 then
        return false, "No macro versions found"
    end

    -- Pick the default macro version index
    local defaultIdx = 1
    if sequence.MetaData and sequence.MetaData.Default then
        defaultIdx = tonumber(sequence.MetaData.Default) or 1
    end
    if defaultIdx < 1 or defaultIdx > #macros then
        defaultIdx = 1
    end

    -- Import ALL versions (T2-2a: no longer dropping non-default versions)
    local versions = {}
    local anySteps = false
    for i, macroVersion in ipairs(macros) do
        -- Reset compile stats before each version
        GI._compileStats = { pauses = 0, embeds = 0, truncated = 0 }

        local compiled = GI.CompileMacroVersion(macroVersion)

        -- Accumulate compile stats into results
        results.pausesSkipped = (results.pausesSkipped or 0) + GI._compileStats.pauses
        results.embedsSkipped = (results.embedsSkipped or 0) + GI._compileStats.embeds
        results.truncatedSteps = (results.truncatedSteps or 0) + GI._compileStats.truncated

        -- Merge warnings
        if compiled.warnings then
            for _, w in ipairs(compiled.warnings) do
                results.warnings[#results.warnings + 1] = seqName .. ": " .. w
            end
        end

        -- Map step function: check Step first, then StepFunction, default Sequential
        local stepFunc = D.STEP_SEQUENTIAL
        if macroVersion.Step then
            local s = macroVersion.Step
            if s == "Sequential" or s == "Priority" or s == "Random" then
                if s == "Priority" then
                    GRIPEMS:Debug("Priority mapped to Sequential (priority encoded in step order)")
                    stepFunc = D.STEP_SEQUENTIAL
                else
                    stepFunc = s
                end
            end
        elseif macroVersion.StepFunction then
            local s = macroVersion.StepFunction
            if s == "Sequential" or s == "Priority" or s == "Random" then
                if s == "Priority" then
                    GRIPEMS:Debug("Priority mapped to Sequential (priority encoded in step order)")
                    stepFunc = D.STEP_SEQUENTIAL
                else
                    stepFunc = s
                end
            end
        end

        -- Inherit step function from inner Loop if macro version has none
        if stepFunc == D.STEP_SEQUENTIAL and compiled.innerStepFunc then
            stepFunc = compiled.innerStepFunc
        end

        -- Map reset conditions from InbuiltVariables
        local resetOnCombat = false
        if macroVersion.InbuiltVariables and type(macroVersion.InbuiltVariables) == "table" then
            if macroVersion.InbuiltVariables.Combat then
                resetOnCombat = true
            end
        end

        versions[i] = {
            stepFunction = stepFunc,
            steps = compiled.steps or {},
            keyPress = compiled.keyPress or "",
            keyRelease = compiled.keyRelease or "",
            resetOnCombat = resetOnCombat,
            resetOnTarget = false,
            resetOnGear = false,
            resetOnSpec = false,
            resetTimer = 0,
        }

        if compiled.steps and #compiled.steps > 0 then
            anySteps = true
        end
    end

    if not anySteps then
        return false, "No steps after compilation"
    end

    -- Track step function per sequence for report (from default version)
    results.stepFunctions = results.stepFunctions or {}
    results.stepFunctions[seqName] = versions[defaultIdx].stepFunction

    -- Build GRIP-EMS sequenceData with versioned format
    local seqData = {
        name = seqName,
        icon = D.QUESTION_MARK_ICON,
        defaultVersion = defaultIdx,
        contextOverrides = GI.MapGSEContextOverrides(sequence.MetaData, #versions),
        versions = versions,
        author = "",
        version = "1",
        description = "",
        classID = select(3, UnitClass("player")) or 0,
        specID = nil,
        createdAt = time(),
        updatedAt = time(),
    }

    -- Count context overrides for import report
    local ctxCount = 0
    for _ in pairs(seqData.contextOverrides) do ctxCount = ctxCount + 1 end
    results.contextOverridesImported = (results.contextOverridesImported or 0) + ctxCount

    -- Merge optional metadata overrides (from migration or enhanced import)
    if opts then
        if opts.author then seqData.author = opts.author end
        if opts.description then seqData.description = opts.description end
        if opts.specID then seqData.specID = opts.specID end
        if opts.updatedAt then seqData.updatedAt = opts.updatedAt end
        if opts.classID ~= nil then seqData.classID = opts.classID end
        if opts.icon then seqData.icon = opts.icon end
    end

    -- Activate the sequence through the engine
    GRIPEMS.Engine:ActivateSequence(seqName, seqData)

    results.names[#results.names + 1] = seqName
    results.stepCounts = results.stepCounts or {}
    results.stepCounts[seqName] = #versions[defaultIdx].steps
    results.count = results.count + 1

    return true
end

--- Compile a single imported macro version into an array of flat macrotext strings.
--- Prepends KeyPress and appends KeyRelease to each compiled action step.
--- @param macroVersion table Imported macro version { KeyPress, KeyRelease, Step, Actions }
--- @return table { steps = { ... }, warnings = { ... } }
function GI.CompileMacroVersion(macroVersion)
    local warnings = {}
    local steps = {}

    if not macroVersion then
        return { steps = steps, warnings = { "Nil macro version" } }
    end

    -- Build KeyPress/KeyRelease blocks
    local keyPress = ""
    if macroVersion.KeyPress and #macroVersion.KeyPress > 0 then
        keyPress = table.concat(macroVersion.KeyPress, "\n")
    end

    local keyRelease = ""
    if macroVersion.KeyRelease and #macroVersion.KeyRelease > 0 then
        keyRelease = table.concat(macroVersion.KeyRelease, "\n")
    end

    -- Compile each action
    local actions = macroVersion.Actions
    if not actions then
        return { steps = steps, warnings = { "No actions in macro version" } }
    end

    -- Detect Repeat actions at edges of Actions array.
    -- Legacy format encodes KeyPress as a Repeat at Actions[1] and KeyRelease
    -- as a Repeat at Actions[#Actions]. Promote their macro content
    -- into keyPress/keyRelease and exclude them from step compilation.
    local actionsStart = 1
    local actionsEnd = #actions
    if actions[1] and actions[1].Type == "Repeat" then
        local repeatMacro = actions[1].macro or ""
        if repeatMacro ~= "" then
            if keyPress ~= "" then
                keyPress = keyPress .. "\n" .. repeatMacro
            else
                keyPress = repeatMacro
            end
        end
        actionsStart = 2
    end
    if actionsEnd >= actionsStart and actions[actionsEnd]
        and actions[actionsEnd].Type == "Repeat" then
        local repeatMacro = actions[actionsEnd].macro or ""
        if repeatMacro ~= "" then
            if keyRelease ~= "" then
                keyRelease = keyRelease .. "\n" .. repeatMacro
            else
                keyRelease = repeatMacro
            end
        end
        actionsEnd = actionsEnd - 1
    end

    -- Resolve spell IDs in KeyPress/KeyRelease strings
    -- (after edge Repeat promotion so promoted content is also resolved)
    if keyPress ~= "" then
        keyPress = GI.ResolveSpellIDsInMacrotext(keyPress)
    end
    if keyRelease ~= "" then
        keyRelease = GI.ResolveSpellIDsInMacrotext(keyRelease)
    end

    local innerStepFunc = nil
    for actionIdx = actionsStart, actionsEnd do
        local action = actions[actionIdx]
        -- Capture StepFunction from inner Loop actions
        if action.Type == "Loop" and action.StepFunction then
            local s = action.StepFunction
            if s == "Sequential" or s == "Priority" or s == "Random" then
                if s == "Priority" then
                    GRIPEMS:Debug("Priority mapped to Sequential (innerStepFunc, priority encoded in step order)")
                    innerStepFunc = D.STEP_SEQUENTIAL
                else
                    innerStepFunc = s
                end
            end
        end
        local compiled, actionWarnings = GI.CompileAction(action)
        if actionWarnings then
            for _, w in ipairs(actionWarnings) do
                warnings[#warnings + 1] = w
            end
        end

        for _, stepText in ipairs(compiled) do
            -- Raw step (no KP/KR wrapping -- Engine handles wrapping based
            -- on step function: Sequential/Random wrap per-step, Priority
            -- wraps once at top/bottom)
            local raw = stepText:match("^%s*(.-)%s*$") or ""
            if raw ~= "" then
                raw = GI.ResolveSpellIDsInMacrotext(raw)
                steps[#steps + 1] = raw
            end
        end
    end

    return { steps = steps, keyPress = keyPress, keyRelease = keyRelease,
        warnings = warnings, innerStepFunc = innerStepFunc }
end

--- Compile a single imported action into macrotext string(s).
--- @param action table Imported action { Type, Spell, unit, Condition, Actions, ... }
--- @return table Array of macrotext strings (usually 1; Loop expands to N)
--- @return table|nil Array of warning strings
function GI.CompileAction(action)
    if not action or not action.Type then
        return {}, { "Action with no Type skipped" }
    end

    -- Skip disabled actions silently
    if action.Disabled then
        return {}, nil
    end

    local actionType = action.Type
    local warnings = {}

    if actionType == "Action" then
        -- Modern legacy action format
        local subType = action.type  -- lowercase t: "macro", "spell", "item"
        if subType == "macro" and action.macro then
            return { GI.ResolveSpellIDsInMacrotext(action.macro) }
        elseif subType == "spell" then
            local spell = GI.ResolveSpell(action.Spell or action.macro)
            if not spell or spell == "" then
                return {}, { "Action/spell with no spell reference skipped" }
            end
            if action.unit and action.unit ~= "" then
                return { "/cast [@" .. action.unit .. "] " .. spell }
            else
                return { "/cast " .. spell }
            end
        elseif subType == "item" then
            local item = tostring(action.Spell or action.macro or "")
            if item == "" then
                return {}, { "Action/item with no item reference skipped" }
            end
            if action.unit and action.unit ~= "" then
                return { "/use [@" .. action.unit .. "] " .. item }
            else
                return { "/use " .. item }
            end
        else
            -- Unknown subtype, try macro field as fallback
            if action.macro and action.macro ~= "" then
                return { action.macro }
            end
            return {}, { "Action with unknown subtype: " .. tostring(subType) }
        end

    elseif actionType == "spell" then
        local spell = GI.ResolveSpell(action.Spell)
        if not spell or spell == "" then
            return {}, { "Spell action with no spell name skipped" }
        end
        local text
        if action.unit and action.unit ~= "" then
            text = "/cast [@" .. action.unit .. "] " .. spell
        else
            text = "/cast " .. spell
        end
        return { text }

    elseif actionType == "item" then
        local item = tostring(action.Spell or "")
        if item == "" then
            return {}, { "Item action with no item name skipped" }
        end
        local text
        if action.unit and action.unit ~= "" then
            text = "/use [@" .. action.unit .. "] " .. item
        else
            text = "/use " .. item
        end
        return { text }

    elseif actionType == "macro" then
        local text = tostring(action.Spell or "")
        if text == "" then
            return {}, { "Macro action with empty text skipped" }
        end
        return { GI.ResolveSpellIDsInMacrotext(text) }

    elseif actionType == "Pause" then
        if GI._compileStats then
            GI._compileStats.pauses = GI._compileStats.pauses + 1
        end
        if action.Variable and action.Variable ~= "" then
            -- Convert pause-with-variable to a comment step referencing the variable
            local step = "/run -- PAUSE: ~" .. tostring(action.Variable) .. "~"
            return { step }, { L["GEMS_VAR_IMPORT_PAUSE"] }
        end
        return {}, { L["Pause action skipped (not supported)"] }

    elseif actionType == "If" then
        local result, ifWarnings = GI.CompileConditional(action)
        return result, ifWarnings

    elseif actionType == "Repeat" then
        -- Repeat: a per-press macro wrapper (KeyPress/KeyRelease
        -- equivalent). Content is in action.macro, not sub-actions.
        -- CompileMacroVersion promotes edge Repeat actions to
        -- keyPress/keyRelease blocks; mid-array Repeats compile as steps.
        if action.macro and action.macro ~= "" then
            return { GI.ResolveSpellIDsInMacrotext(action.macro) }
        elseif action.Spell then
            local spell = GI.ResolveSpell(action.Spell)
            if spell and spell ~= "" then
                return { "/cast " .. spell }
            end
        end
        return {}, nil

    elseif actionType == "Loop" then
        local loopCount = tonumber(action.Repeat) or tonumber(action.Count) or 1
        if loopCount < 1 then loopCount = 1 end
        if loopCount > 50 then loopCount = 50 end  -- safety cap

        -- Extract sub-actions: numbered keys (int or string) OR Actions array
        local subActions = {}
        if action.Actions and type(action.Actions) == "table" then
            -- Old format: Actions array
            for _, sa in ipairs(action.Actions) do
                subActions[#subActions + 1] = sa
            end
        else
            -- Modern format: numbered keys [1], [2], ... or ["1"], ["2"], ...
            local idx = 1
            while action[idx] or action[tostring(idx)] do
                subActions[#subActions + 1] = action[idx] or action[tostring(idx)]
                idx = idx + 1
            end
        end

        if #subActions == 0 then
            return {}, { "Loop with no sub-actions skipped" }
        end

        local expanded = {}
        for _ = 1, loopCount do
            for _, subAction in ipairs(subActions) do
                if not subAction.Disabled then
                    local compiled, subWarnings = GI.CompileAction(subAction)
                    if subWarnings then
                        for _, w in ipairs(subWarnings) do
                            warnings[#warnings + 1] = w
                        end
                    end
                    for _, step in ipairs(compiled) do
                        expanded[#expanded + 1] = step
                    end
                end
            end
        end
        return expanded, (#warnings > 0) and warnings or nil

    elseif actionType == "Embed" then
        if GI._compileStats then
            GI._compileStats.embeds = GI._compileStats.embeds + 1
        end
        local embedName = tostring(action.Sequence or action.Spell or "?")
        warnings[#warnings + 1] = string.format(
            L["Embedded sequence '%s' skipped (not available)"], embedName)
        return {}, warnings

    elseif actionType == "Comment" then
        return {}

    else
        warnings[#warnings + 1] = string.format(
            L["Skipped action: %s"], tostring(actionType))
        return {}, warnings
    end
end

--- Resolve a spell reference to a string name.
--- If spellRef is a number (spell ID), tries C_Spell.GetSpellName to get
--- the localized name; falls back to tostring if unavailable.
--- @param spellRef string|number Spell name or spell ID
--- @return string Spell name as a string
function GI.ResolveSpell(spellRef)
    if spellRef == nil then
        return ""
    end

    if type(spellRef) == "number" then
        -- Try to resolve spell ID to localized name
        local name = C_Spell.GetSpellName(spellRef)
        if name and name ~= "" then
            return name
        end
        -- Fallback: spell ID as string (may not work for /cast in modern WoW)
        return tostring(spellRef)
    end

    return tostring(spellRef)
end

--- Post-process macrotext to resolve numeric spell IDs in /cast and /castsequence lines.
--- Modern WoW requires spell names, not numeric IDs, in /cast commands.
--- @param text string Raw macrotext (may be multi-line)
--- @return string Processed macrotext with spell IDs resolved in /cast and /castsequence
function GI.ResolveSpellIDsInMacrotext(text)
    if not text or text == "" then return text end

    --- Consume all leading [condition] blocks from a string.
    --- Returns the concatenated conditions (with trailing space) and the remainder.
    --- @param str string Input after command keyword
    --- @return string conditions All [...] blocks concatenated (empty string if none)
    --- @return string remainder Text after the last condition block
    local function consumeConditions(str)
        local conditions = ""
        local remainder = str
        while true do
            local bracket, rest = remainder:match("^(%b[])%s*(.*)")
            if bracket then
                conditions = conditions .. bracket .. " "
                remainder = rest
            else
                break
            end
        end
        -- Trim trailing space from conditions
        conditions = conditions:match("^(.-)%s*$") or conditions
        return conditions, remainder
    end

    local lines = {}
    for line in text:gmatch("[^\n]+") do
        local lineLower = line:lower()
        if (lineLower:match("^/cast%s") or lineLower:match("^/use%s"))
                and not lineLower:match("^/castsequence") then
            -- /cast or /use line: resolve numeric spell IDs to names
            -- Pattern: /cast [optional conditions] SpellRef; SpellRef
            -- /use is a WoW alias for /cast, takes identical syntax
            local cmd, rest = line:match("^(/%a+%s+)(.*)")
            if cmd and rest and rest ~= "" then
                -- Consume all leading [condition] blocks
                local conditions, spellPart = consumeConditions(rest)
                if spellPart and spellPart ~= "" then
                    -- Split by semicolons (fallback casts)
                    local resolved = {}
                    for ref in spellPart:gmatch("[^;]+") do
                        ref = ref:match("^%s*(.-)%s*$")  -- trim
                        -- Each segment may have its own [condition] blocks
                        local segCond, segSpell = consumeConditions(ref)
                        local numericID = tonumber(segSpell)
                        if numericID and tostring(numericID) == segSpell then
                            local name = C_Spell.GetSpellName(numericID)
                            if name and name ~= "" then
                                segSpell = name
                            end
                        end
                        if segCond ~= "" then
                            resolved[#resolved + 1] = segCond .. " " .. segSpell
                        else
                            resolved[#resolved + 1] = segSpell
                        end
                    end
                    if conditions ~= "" then
                        line = cmd .. conditions .. " " .. table.concat(resolved, "; ")
                    else
                        line = cmd .. table.concat(resolved, "; ")
                    end
                end
            end
        elseif lineLower:match("^/castsequence") then
            -- Consume all leading [condition] blocks after the command
            local cmdPart, rest = line:match("^(/[cC][aA][sS][tT][sS][eE][qQ][uU][eE][nN][cC][eE]%s+)(.*)")
            if cmdPart then
                local conditions, spellList = consumeConditions(rest)
                local prefix
                if conditions ~= "" then
                    prefix = cmdPart .. conditions .. " "
                else
                    prefix = cmdPart
                end
                if spellList and spellList ~= "" then
                    -- Handle reset= prefix within the spell list
                    -- e.g. "reset=target/combat 217200, 34026"
                    local resetPrefix, remainder = spellList:match("^(reset=%S+%s+)(.*)")
                    if resetPrefix then
                        prefix = prefix .. resetPrefix
                        spellList = remainder
                    end
                    -- Split spell list by comma, resolve each numeric entry
                    local resolved = {}
                    for entry in spellList:gmatch("[^,]+") do
                        entry = entry:match("^%s*(.-)%s*$")  -- trim
                        local numericID = tonumber(entry)
                        if numericID then
                            local name = C_Spell.GetSpellName(numericID)
                            if name and name ~= "" then
                                resolved[#resolved + 1] = name
                            else
                                -- Can't resolve, keep as-is (will error but no worse than before)
                                resolved[#resolved + 1] = entry
                            end
                        else
                            -- Already a name or complex expression, keep as-is
                            resolved[#resolved + 1] = entry
                        end
                    end
                    line = prefix .. table.concat(resolved, ", ")
                end
            end
            -- if cmdPart was nil, line stays unchanged (no-op)
        end
        lines[#lines + 1] = line
    end
    return table.concat(lines, "\n")
end

--- Map a legacy variable definition to GRIP-EMS varDef format.
--- @param gseVarName string Variable name from source
--- @param gseVarDef table Legacy variable definition table
--- @return table GRIP-EMS varDef table
function GI.MapGSEVariable(gseVarName, gseVarDef)
    local events = ""
    if gseVarDef.eventEnabled and gseVarDef.eventNames
        and type(gseVarDef.eventNames) == "table"
        and #gseVarDef.eventNames > 0 then
        events = table.concat(gseVarDef.eventNames, ", ")
    end

    local ts = gseVarDef.LastUpdated or time()

    return {
        name = gseVarName,
        funct = gseVarDef.funct or "",
        events = events,
        author = gseVarDef.Author or "",
        version = "1",
        description = gseVarDef.comments or "",
        createdAt = ts,
        updatedAt = ts,
        disabled = false,
    }
end

--- Import a single mapped variable into the VariableStore.
--- Validates name and function body; skips if variable already exists.
--- @param name string Variable name
--- @param varDef table Mapped GRIP-EMS varDef
--- @param results table Import results accumulator
--- @return boolean success
--- @return string|nil error Error message on failure
function GI.ImportVariable(name, varDef, results)
    -- Validate name
    local validName, nameErr = VS:ValidateName(name)
    if not validName then
        results.warnings[#results.warnings + 1] =
            "Variable '" .. tostring(name) .. "': " .. tostring(nameErr)
        return false, nameErr
    end

    -- Skip if already exists
    if VS:Get(name) then
        results.varsSkipped = results.varsSkipped + 1
        return true
    end

    -- Validate function body (warn but still save)
    local validFunc, funcErr = VS:ValidateFunction(varDef.funct)
    if not validFunc then
        results.warnings[#results.warnings + 1] =
            "Variable '" .. name .. "': invalid function body - " .. tostring(funcErr)
    end

    VS:Set(name, varDef)
    results.varsImported = results.varsImported + 1
    return true
end

--- Compile an If action into WoW conditional macro syntax.
--- @param action table Imported If action { Condition, Actions, ElseActions }
--- @return table Array of macrotext strings
--- @return table|nil Array of warning strings
function GI.CompileConditional(action)
    if not action then
        return {}, { "Nil conditional action" }
    end

    local condition = action.Condition or ""
    local warnings = {}

    -- Get the primary spell from Actions[1]
    local primarySpell = nil
    if action.Actions and action.Actions[1] then
        local subAction = action.Actions[1]
        if subAction.Spell then
            primarySpell = GI.ResolveSpell(subAction.Spell)
        elseif subAction.Type == "If" then
            -- Nested If: flatten recursively
            local nested, nWarnings = GI.CompileConditional(subAction)
            if nWarnings then
                for _, w in ipairs(nWarnings) do
                    warnings[#warnings + 1] = w
                end
            end
            return nested, (#warnings > 0) and warnings or nil
        end
    end

    if not primarySpell or primarySpell == "" then
        return {}, { "If action with no spell skipped" }
    end

    -- Check for ElseActions
    local elseSpell = nil
    if action.ElseActions and action.ElseActions[1] then
        local elseAction = action.ElseActions[1]
        if elseAction.Spell then
            elseSpell = GI.ResolveSpell(elseAction.Spell)
        end
    end

    local text
    if elseSpell and elseSpell ~= "" then
        -- /cast [condition] spell1; spell2
        text = "/cast [" .. condition .. "] " .. primarySpell .. "; " .. elseSpell
    else
        -- /cast [condition] spell1
        text = "/cast [" .. condition .. "] " .. primarySpell
    end

    return { text }, (#warnings > 0) and warnings or nil
end
