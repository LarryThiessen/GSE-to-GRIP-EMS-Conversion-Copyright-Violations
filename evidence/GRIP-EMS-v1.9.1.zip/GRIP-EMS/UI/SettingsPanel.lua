-- GRIP-EMS: Settings Panel
-- AceConfig options table + Blizzard Settings integration + AceDBOptions profiles

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS")
local function D()
    return GRIPEMS.Defaults
end

GRIPEMS.SettingsPanel = {}
local SP = GRIPEMS.SettingsPanel

---------------------------------------------------------------------------
-- Dark-theme restyle for AceConfigDialog frames
---------------------------------------------------------------------------
-- FRAGILE: This function depends on AceConfigDialog-3.0 internal frame
-- structure (children layout, title region, close button). If the library
-- updates its frame hierarchy, this restyle may break silently.
-- Tested against AceConfigDialog-3.0 r1286. Review on lib updates.
---------------------------------------------------------------------------
local function RestyleAceFrame(widget)
    if not widget then
        return
    end
    -- Idempotent guard on the widget table
    if widget._gripRestyled then
        return
    end
    widget._gripRestyled = true

    local ok, err = pcall(function()
        local frame = widget.frame
        if not frame then
            return
        end

        local UI = GRIPEMS.UI
        local C = UI.Colors

        -- Main frame backdrop (must mixin BackdropTemplateMixin first)
        if not frame.SetBackdrop then
            Mixin(frame, BackdropTemplateMixin)
        end
        UI:ApplyBackdrop(frame, UI.Backdrops.panel, C.bgMain, C.border)

        -- Content area backdrop
        local content = widget.content
        if content then
            if not content.SetBackdrop then
                Mixin(content, BackdropTemplateMixin)
            end
            UI:ApplyBackdrop(content, UI.Backdrops.panel, C.bgPanel, C.border)
        end

        -- Title text color
        local titleText = widget.titletext
        if titleText and titleText.SetTextColor then
            local text = titleText:GetText()
            if text and text:find(ADDON_NAME) then
                titleText:SetTextColor(C.gripGreen:GetRGBA())
            else
                titleText:SetTextColor(C.textPrimary:GetRGBA())
            end
        end

        -- Move title text down into the frame (was floating above due to
        -- hidden ornamental banner anchoring)
        if titleText then
            titleText:ClearAllPoints()
            titleText:SetPoint("TOP", frame, "TOP", 0, -8)
        end

        -- Hide ornamental title bar textures (texture ID 131080)
        if widget.titlebg then
            widget.titlebg:SetAlpha(0)
        end
        for _, region in pairs({ frame:GetRegions() }) do
            if region.GetTexture and region:GetTexture() == 131080 then
                region:SetAlpha(0)
            end
        end

        -- Hide the status bar (serves no purpose in settings)
        if widget.statustext then
            local statusBar = widget.statustext:GetParent()
            if statusBar then
                statusBar:Hide()
            end
            widget.statustext:Hide()
        end

        -- Expand content area into reclaimed status bar space
        if widget.content then
            widget.content:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -17, 17)
        end

        -- Walk actual Frame children for close button and tab buttons
        for _, child in pairs({ frame:GetChildren() }) do
            if child:GetObjectType() == "Button" and child.GetText then
                local btnText = child:GetText()
                if btnText == CLOSE then
                    -- Strip UIPanelButtonTemplate textures to prevent double borders
                    if child.SetNormalTexture then
                        child:SetNormalTexture("")
                    end
                    if child.SetHighlightTexture then
                        child:SetHighlightTexture("")
                    end
                    if child.SetPushedTexture then
                        child:SetPushedTexture("")
                    end
                    if child.SetDisabledTexture then
                        child:SetDisabledTexture("")
                    end
                    -- Apply dark theme backdrop
                    if not child.SetBackdrop then
                        Mixin(child, BackdropTemplateMixin)
                    end
                    UI:ApplyBackdrop(child, UI.Backdrops.panel, C.bgButton, C.border)
                    -- Raise above content area
                    child:SetFrameLevel(frame:GetFrameLevel() + 10)
                    -- Restyle text
                    local fs = child:GetFontString()
                    if fs then
                        fs:SetTextColor(C.textPrimary:GetRGBA())
                    end
                elseif btnText and btnText ~= "" then
                    -- Tab buttons
                    if not child.SetBackdrop then
                        Mixin(child, BackdropTemplateMixin)
                    end
                    UI:ApplyBackdrop(child, UI.Backdrops.panel, C.bgButton, C.border)
                    local fs = child:GetFontString()
                    if fs then
                        fs:SetTextColor(C.textPrimary:GetRGBA())
                    end
                end
            end
        end

        GRIPEMS:Debug("SettingsPanel: Applied dark theme to AceConfigDialog frame")
    end)
    if not ok then
        GRIPEMS:Debug("RestyleAceFrame failed: " .. tostring(err))
    end
end

--- Initialize the settings panel. Registers AceConfig options and adds
--- to the Blizzard Settings panel. Called from Core.lua PLAYER_LOGIN.
function SP:Initialize()
    local AceConfig = LibStub("AceConfig-3.0")
    local AceConfigDialog = LibStub("AceConfigDialog-3.0")
    local AceDBOptions = LibStub("AceDBOptions-3.0")
    local S = GRIPEMS.Settings

    GRIPEMS:Debug("SettingsPanel:Initialize() - db exists: " .. tostring(S:GetDB() ~= nil))

    local options = {
        type = "group",
        name = "GRIP-EMS",
        childGroups = "tab",
        args = {
            headerDesc = {
                type = "description",
                name = L["GEMS_SETTINGS_HEADER_DESC"],
                order = 1,
                fontSize = "medium",
            },
            general = {
                type = "group",
                name = L["GEMS_SETTINGS_GENERAL"],
                order = 10,
                args = {
                    oocDelay = {
                        type = "range",
                        name = L["GEMS_SETTINGS_OOC_DELAY"],
                        desc = L["GEMS_SETTINGS_OOC_DELAY_DESC"],
                        order = 1,
                        min = 1,
                        max = 60,
                        step = 1,
                        get = function()
                            return S:Get("oocDelay")
                        end,
                        set = function(_, v)
                            S:Set("oocDelay", v)
                        end,
                        width = "double",
                    },
                    resetOOC = {
                        type = "toggle",
                        name = L["GEMS_SETTINGS_RESET_OOC"],
                        desc = L["GEMS_SETTINGS_RESET_OOC_DESC"],
                        order = 3,
                        get = function()
                            return S:Get("resetOOC")
                        end,
                        set = function(_, v)
                            S:Set("resetOOC", v)
                        end,
                        width = "full",
                    },
                    msClickRate = {
                        type = "range",
                        name = function()
                            if S:Get("tempoAutoSet") and GRIPEMS.TempoAdvisor then
                                local eng = GRIPEMS.Engine
                                local activeSeq = eng and eng._lastClickedSequence
                                if activeSeq then
                                    local rec = GRIPEMS.TempoAdvisor:GetRecommendation(activeSeq)
                                    local ms = rec and (rec.blendedMs or rec.recommendedMs)
                                    if ms then
                                        return string.format(L["FS_AUTO_LABEL"], ms, activeSeq)
                                    end
                                end
                            end
                            return L["GEMS_SETTINGS_CLICK_RATE"]
                        end,
                        desc = L["GEMS_SETTINGS_CLICK_RATE_DESC"],
                        order = 5,
                        min = D().MS_CLICK_RATE_MIN,
                        max = D().MS_CLICK_RATE_MAX,
                        step = D().MS_CLICK_RATE_STEP,
                        get = function()
                            return S:Get("msClickRate")
                        end,
                        set = function(_, v)
                            S:Set("msClickRate", v)
                        end,
                        width = "double",
                    },
                    charClickRateHeader = {
                        type = "header",
                        name = L["GEMS_SETTINGS_CHAR_OVERRIDES"],
                        order = 6,
                    },
                    charClickRate = {
                        type = "range",
                        name = L["GEMS_SETTINGS_CHAR_CLICK_RATE"],
                        desc = L["GEMS_SETTINGS_CHAR_CLICK_RATE_DESC"],
                        order = 7,
                        min = 0,
                        max = D().MS_CLICK_RATE_MAX,
                        step = D().MS_CLICK_RATE_STEP,
                        get = function()
                            if GRIP_EMS_CHAR and GRIP_EMS_CHAR.msClickRate then
                                return GRIP_EMS_CHAR.msClickRate
                            end
                            return 0
                        end,
                        set = function(_, v)
                            S:SetCharClickRate(v)
                        end,
                        width = "double",
                    },
                    barIntegration = {
                        type = "toggle",
                        name = L["GEMS_BAR_INTEGRATION_HEADER"],
                        desc = L["GEMS_BAR_INTEGRATION_DESC"],
                        order = 9,
                        get = function()
                            return S:Get("barIntegration")
                        end,
                        set = function(_, v)
                            S:Set("barIntegration", v)
                        end,
                        width = "full",
                    },
                },
            },
            ui = {
                type = "group",
                name = L["GEMS_SETTINGS_UI"],
                order = 20,
                args = {
                    hideLoginMsg = {
                        type = "toggle",
                        name = L["GEMS_SETTINGS_HIDE_LOGIN"],
                        desc = L["GEMS_SETTINGS_HIDE_LOGIN_DESC"],
                        order = 1,
                        get = function()
                            return S:Get("hideLoginMsg")
                        end,
                        set = function(_, v)
                            S:Set("hideLoginMsg", v)
                        end,
                        width = "full",
                    },
                    debug = {
                        type = "toggle",
                        name = L["GEMS_SETTINGS_DEBUG"],
                        desc = L["GEMS_SETTINGS_DEBUG_DESC"],
                        order = 2,
                        get = function()
                            return S:Get("debug")
                        end,
                        set = function(_, v)
                            S:Set("debug", v)
                        end,
                        width = "full",
                    },
                },
            },
            recorder = {
                type = "group",
                name = L["GEMS_SETTINGS_RECORDER_HEADER"],
                order = 29,
                args = {
                    recorderDedup = {
                        type = "toggle",
                        name = L["GEMS_SETTINGS_RECORDER_DEDUP"],
                        desc = L["GEMS_SETTINGS_RECORDER_DEDUP_DESC"],
                        order = 1,
                        get = function()
                            return S:Get("recorderDedup")
                        end,
                        set = function(_, v)
                            S:Set("recorderDedup", v)
                        end,
                        width = "full",
                    },
                },
            },
            editorColours = {
                type = "group",
                name = L["GEMS_SETTINGS_EDITOR_COLOURS"],
                order = 30,
                args = {
                    syntaxCommandColor = {
                        type = "color",
                        name = L["GEMS_SETTINGS_SYNTAX_COMMAND"],
                        desc = L["GEMS_SETTINGS_SYNTAX_COMMAND_DESC"],
                        hasAlpha = false,
                        order = 1,
                        get = function()
                            local c = S:Get("syntaxCommandColor")
                            return c[1], c[2], c[3]
                        end,
                        set = function(_, r, g, b)
                            S:Set("syntaxCommandColor", { r, g, b })
                        end,
                    },
                    syntaxConditionalColor = {
                        type = "color",
                        name = L["GEMS_SETTINGS_SYNTAX_CONDITIONAL"],
                        desc = L["GEMS_SETTINGS_SYNTAX_CONDITIONAL_DESC"],
                        hasAlpha = false,
                        order = 2,
                        get = function()
                            local c = S:Get("syntaxConditionalColor")
                            return c[1], c[2], c[3]
                        end,
                        set = function(_, r, g, b)
                            S:Set("syntaxConditionalColor", { r, g, b })
                        end,
                    },
                    syntaxVariableColor = {
                        type = "color",
                        name = L["GEMS_SETTINGS_SYNTAX_VARIABLE"],
                        desc = L["GEMS_SETTINGS_SYNTAX_VARIABLE_DESC"],
                        hasAlpha = false,
                        order = 3,
                        get = function()
                            local c = S:Get("syntaxVariableColor")
                            return c[1], c[2], c[3]
                        end,
                        set = function(_, r, g, b)
                            S:Set("syntaxVariableColor", { r, g, b })
                        end,
                    },
                    syntaxCommentColor = {
                        type = "color",
                        name = L["GEMS_SETTINGS_SYNTAX_COMMENT"],
                        desc = L["GEMS_SETTINGS_SYNTAX_COMMENT_DESC"],
                        hasAlpha = false,
                        order = 4,
                        get = function()
                            local c = S:Get("syntaxCommentColor")
                            return c[1], c[2], c[3]
                        end,
                        set = function(_, r, g, b)
                            S:Set("syntaxCommentColor", { r, g, b })
                        end,
                    },
                    syntaxResetColor = {
                        type = "color",
                        name = L["GEMS_SETTINGS_SYNTAX_RESET"],
                        desc = L["GEMS_SETTINGS_SYNTAX_RESET_DESC"],
                        hasAlpha = false,
                        order = 5,
                        get = function()
                            local c = S:Get("syntaxResetColor")
                            return c[1], c[2], c[3]
                        end,
                        set = function(_, r, g, b)
                            S:Set("syntaxResetColor", { r, g, b })
                        end,
                    },
                    syntaxNumberColor = {
                        type = "color",
                        name = L["GEMS_SETTINGS_SYNTAX_NUMBER"],
                        desc = L["GEMS_SETTINGS_SYNTAX_NUMBER_DESC"],
                        hasAlpha = false,
                        order = 6,
                        get = function()
                            local c = S:Get("syntaxNumberColor")
                            return c[1], c[2], c[3]
                        end,
                        set = function(_, r, g, b)
                            S:Set("syntaxNumberColor", { r, g, b })
                        end,
                    },
                },
            },
            sharing = {
                type = "group",
                name = L["GEMS_P2P_ENABLED"],
                order = 25,
                args = {
                    p2pEnabled = {
                        type = "toggle",
                        name = L["GEMS_P2P_ENABLED"],
                        desc = L["GEMS_P2P_ENABLED_DESC"],
                        order = 1,
                        get = function()
                            return S:Get("p2pEnabled")
                        end,
                        set = function(_, v)
                            S:Set("p2pEnabled", v)
                        end,
                        width = "full",
                    },
                    p2pAutoAcceptFriends = {
                        type = "toggle",
                        name = L["GEMS_P2P_AUTO_FRIENDS"],
                        desc = L["GEMS_P2P_AUTO_FRIENDS_DESC"],
                        order = 2,
                        get = function()
                            return S:Get("p2pAutoAcceptFriends")
                        end,
                        set = function(_, v)
                            S:Set("p2pAutoAcceptFriends", v)
                        end,
                        width = "full",
                    },
                    p2pAnnounceReceive = {
                        type = "toggle",
                        name = L["GEMS_P2P_ANNOUNCE"],
                        desc = L["GEMS_P2P_ANNOUNCE_DESC"],
                        order = 3,
                        get = function()
                            return S:Get("p2pAnnounceReceive")
                        end,
                        set = function(_, v)
                            S:Set("p2pAnnounceReceive", v)
                        end,
                        width = "full",
                    },
                },
            },
            blockedPlayers = {
                type = "group",
                name = L["GEMS_SETTINGS_BLOCKED_PLAYERS"],
                order = 26,
                args = {
                    desc = {
                        type = "description",
                        name = L["GEMS_SETTINGS_BLOCKED_PLAYERS_DESC"],
                        order = 1,
                        fontSize = "medium",
                    },
                    addPlayer = {
                        type = "input",
                        name = L["GEMS_BLOCK_ADDED"]:gsub(" from P2P transmission%.", ""),
                        desc = L["GEMS_HELP_BLOCK"],
                        order = 2,
                        width = "full",
                        set = function(_, v)
                            if v and v ~= "" then
                                local T = GRIPEMS.Transmission
                                if T then
                                    T:BlockPlayer(v)
                                end
                            end
                        end,
                        get = function()
                            return ""
                        end,
                    },
                    list = {
                        type = "description",
                        name = function()
                            local T = GRIPEMS.Transmission
                            if not T then
                                return ""
                            end
                            local blocked = T:GetBlockedList()
                            if #blocked == 0 then
                                return "\n" .. L["GEMS_BLOCK_LIST_EMPTY"]
                            end
                            local lines = { "\n" .. L["GEMS_BLOCK_LIST_HEADER"] }
                            for _, n in ipairs(blocked) do
                                lines[#lines + 1] = "  " .. Ambiguate(n, "none")
                            end
                            return table.concat(lines, "\n")
                        end,
                        order = 3,
                        fontSize = "medium",
                    },
                    removePlayer = {
                        type = "input",
                        name = L["GEMS_BLOCK_REMOVED"]:gsub("%.", ""),
                        desc = L["GEMS_HELP_UNBLOCK"],
                        order = 4,
                        width = "full",
                        set = function(_, v)
                            if v and v ~= "" then
                                local T = GRIPEMS.Transmission
                                if T then
                                    T:UnblockPlayer(v)
                                end
                            end
                        end,
                        get = function()
                            return ""
                        end,
                    },
                },
            },
            macroReset = {
                type = "group",
                name = L["GEMS_SETTINGS_MACRO_RESET"],
                order = 15,
                args = (function()
                    local args = {}
                    -- Mouse buttons
                    args.mouseHeader = {
                        type = "header",
                        name = L["GEMS_RESET_MOD_MOUSE_HEADER"],
                        order = 1,
                    }
                    local mouseKeys = { "LeftButton", "RightButton", "MiddleButton", "Button4", "Button5" }
                    for i, mod in ipairs(mouseKeys) do
                        args["reset_" .. mod] = {
                            type = "toggle",
                            name = L["GEMS_RESET_MOD_" .. strupper(mod)],
                            desc = L["GEMS_RESET_MOD_DESC"],
                            order = 1 + i,
                            get = function()
                                local mods = S:GetResetModifiers()
                                return mods[mod]
                            end,
                            set = function(_, v)
                                S:SetResetModifier(mod, v)
                            end,
                            width = "normal",
                        }
                    end
                    -- Alt keys
                    args.altHeader = {
                        type = "header",
                        name = L["GEMS_RESET_MOD_ALT_HEADER"],
                        order = 7,
                    }
                    local altKeys = { "LeftAlt", "RightAlt", "Alt" }
                    for i, mod in ipairs(altKeys) do
                        args["reset_" .. mod] = {
                            type = "toggle",
                            name = L["GEMS_RESET_MOD_" .. strupper(mod)],
                            desc = L["GEMS_RESET_MOD_DESC"],
                            order = 7 + i,
                            get = function()
                                local mods = S:GetResetModifiers()
                                return mods[mod]
                            end,
                            set = function(_, v)
                                S:SetResetModifier(mod, v)
                            end,
                            width = "normal",
                        }
                    end
                    -- Control keys
                    args.controlHeader = {
                        type = "header",
                        name = L["GEMS_RESET_MOD_CONTROL_HEADER"],
                        order = 11,
                    }
                    local ctrlKeys = { "LeftControl", "RightControl", "Control" }
                    for i, mod in ipairs(ctrlKeys) do
                        args["reset_" .. mod] = {
                            type = "toggle",
                            name = L["GEMS_RESET_MOD_" .. strupper(mod)],
                            desc = L["GEMS_RESET_MOD_DESC"],
                            order = 11 + i,
                            get = function()
                                local mods = S:GetResetModifiers()
                                return mods[mod]
                            end,
                            set = function(_, v)
                                S:SetResetModifier(mod, v)
                            end,
                            width = "normal",
                        }
                    end
                    -- Shift keys
                    args.shiftHeader = {
                        type = "header",
                        name = L["GEMS_RESET_MOD_SHIFT_HEADER"],
                        order = 15,
                    }
                    local shiftKeys = { "LeftShift", "RightShift", "Shift" }
                    for i, mod in ipairs(shiftKeys) do
                        args["reset_" .. mod] = {
                            type = "toggle",
                            name = L["GEMS_RESET_MOD_" .. strupper(mod)],
                            desc = L["GEMS_RESET_MOD_DESC"],
                            order = 15 + i,
                            get = function()
                                local mods = S:GetResetModifiers()
                                return mods[mod]
                            end,
                            set = function(_, v)
                                S:SetResetModifier(mod, v)
                            end,
                            width = "normal",
                        }
                    end
                    -- Any modifier
                    args.anyHeader = {
                        type = "header",
                        name = L["GEMS_RESET_MOD_ANY_HEADER"],
                        order = 19,
                    }
                    args.reset_AnyMod = {
                        type = "toggle",
                        name = L["GEMS_RESET_MOD_ANYMOD"],
                        desc = L["GEMS_RESET_MOD_DESC"],
                        order = 20,
                        get = function()
                            local mods = S:GetResetModifiers()
                            return mods["AnyMod"]
                        end,
                        set = function(_, v)
                            S:SetResetModifier("AnyMod", v)
                        end,
                        width = "normal",
                    }
                    return args
                end)(),
            },
            tracker = {
                type = "group",
                name = L["GEMS_TRACKER_HEADER"],
                order = 27,
                args = {
                    trackerShowMode = {
                        type = "select",
                        name = L["GEMS_TRACKER_HEADER"],
                        desc = L["GEMS_TRACKER_SHOWMODE_DESC"],
                        order = 1,
                        values = {
                            ALWAYS = L["GEMS_TRACKER_MODE_ALWAYS"],
                            COMBAT = L["GEMS_TRACKER_MODE_COMBAT"],
                            TARGET = L["GEMS_TRACKER_MODE_TARGET"],
                            NEVER = L["GEMS_TRACKER_MODE_NEVER"],
                        },
                        get = function()
                            return S:Get("trackerShowMode")
                        end,
                        set = function(_, v)
                            S:Set("trackerShowMode", v)
                        end,
                        width = "double",
                    },
                    trackerIconSize = {
                        type = "range",
                        name = L["GEMS_TRACKER_ICONSIZE_DESC"],
                        desc = L["GEMS_TRACKER_ICONSIZE_DESC"],
                        order = 2,
                        min = 20,
                        max = 80,
                        step = 2,
                        get = function()
                            return S:Get("trackerIconSize")
                        end,
                        set = function(_, v)
                            S:Set("trackerIconSize", v)
                        end,
                        width = "double",
                    },
                    trackerOrientation = {
                        type = "select",
                        name = L["GEMS_TRACKER_ORIENTATION_DESC"],
                        desc = L["GEMS_TRACKER_ORIENTATION_DESC"],
                        order = 3,
                        values = {
                            HORIZONTAL = "Horizontal",
                            VERTICAL = "Vertical",
                        },
                        get = function()
                            return S:Get("trackerOrientation")
                        end,
                        set = function(_, v)
                            S:Set("trackerOrientation", v)
                        end,
                        width = "normal",
                    },
                    trackerShowName = {
                        type = "toggle",
                        name = L["GEMS_TRACKER_SHOWNAME_DESC"],
                        desc = L["GEMS_TRACKER_SHOWNAME_DESC"],
                        order = 4,
                        get = function()
                            return S:Get("trackerShowName")
                        end,
                        set = function(_, v)
                            S:Set("trackerShowName", v)
                        end,
                        width = "full",
                    },
                    trackerShowModifiers = {
                        type = "toggle",
                        name = L["GEMS_TRACKER_SHOWMODS_DESC"],
                        desc = L["GEMS_TRACKER_SHOWMODS_DESC"],
                        order = 5,
                        get = function()
                            return S:Get("trackerShowModifiers")
                        end,
                        set = function(_, v)
                            S:Set("trackerShowModifiers", v)
                        end,
                        width = "full",
                    },
                    trackerLocked = {
                        type = "toggle",
                        name = L["GEMS_TRACKER_LOCK_DESC"],
                        desc = L["GEMS_TRACKER_LOCK_DESC"],
                        order = 6,
                        get = function()
                            return S:Get("trackerLocked")
                        end,
                        set = function(_, v)
                            S:Set("trackerLocked", v)
                        end,
                        width = "full",
                    },
                    trackerScale = {
                        type = "range",
                        name = L["GEMS_TRACKER_SCALE_DESC"],
                        desc = L["GEMS_TRACKER_SCALE_DESC"],
                        order = 7,
                        min = 0.5,
                        max = 2.0,
                        step = 0.05,
                        isPercent = true,
                        get = function()
                            return S:Get("trackerScale")
                        end,
                        set = function(_, v)
                            S:Set("trackerScale", v)
                        end,
                        width = "double",
                    },
                },
            },
            floatingMenu = {
                type = "group",
                name = L["GEMS_FLOATING_HEADER"],
                order = 28,
                args = {
                    floatingMenuShow = {
                        type = "toggle",
                        name = L["GEMS_FLOATING_HEADER"],
                        desc = L["GEMS_FLOATING_SHOW_DESC"],
                        order = 1,
                        get = function()
                            return S:Get("floatingMenuShow")
                        end,
                        set = function(_, v)
                            S:Set("floatingMenuShow", v)
                        end,
                        width = "full",
                    },
                    floatingMenuDirection = {
                        type = "select",
                        name = L["GEMS_FLOATING_DIRECTION_DESC"],
                        desc = L["GEMS_FLOATING_DIRECTION_DESC"],
                        order = 2,
                        values = {
                            UP = L["GEMS_FLOATING_DIR_UP"],
                            DOWN = L["GEMS_FLOATING_DIR_DOWN"],
                            LEFT = L["GEMS_FLOATING_DIR_LEFT"],
                            RIGHT = L["GEMS_FLOATING_DIR_RIGHT"],
                        },
                        get = function()
                            return S:Get("floatingMenuDirection")
                        end,
                        set = function(_, v)
                            S:Set("floatingMenuDirection", v)
                        end,
                        width = "normal",
                    },
                    floatingMenuLocked = {
                        type = "toggle",
                        name = L["GEMS_FLOATING_LOCK_DESC"],
                        desc = L["GEMS_FLOATING_LOCK_DESC"],
                        order = 3,
                        get = function()
                            return S:Get("floatingMenuLocked")
                        end,
                        set = function(_, v)
                            S:Set("floatingMenuLocked", v)
                        end,
                        width = "full",
                    },
                    floatingMenuScale = {
                        type = "range",
                        name = L["GEMS_FLOATING_SCALE_DESC"],
                        desc = L["GEMS_FLOATING_SCALE_DESC"],
                        order = 4,
                        min = 0.5,
                        max = 2.0,
                        step = 0.1,
                        isPercent = true,
                        get = function()
                            return S:Get("floatingMenuScale")
                        end,
                        set = function(_, v)
                            S:Set("floatingMenuScale", v)
                        end,
                        width = "double",
                    },
                },
            },
            fasterSlower = {
                type = "group",
                name = L["FS_STATUS_HEADER"],
                order = 34,
                args = {
                    tempoAutoSet = {
                        type = "toggle",
                        name = L["FS_AUTO_SET"],
                        desc = L["FS_AUTO_SET_DESC"],
                        order = 1,
                        get = function()
                            return S:Get("tempoAutoSet")
                        end,
                        set = function(_, v)
                            S:Set("tempoAutoSet", v)
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIPEMS")
                        end,
                        width = "full",
                    },
                    tempoOverlayShown = {
                        type = "toggle",
                        name = L["FS_OVERLAY_SHOWN"],
                        order = 2,
                        get = function()
                            return S:Get("tempoOverlayShown")
                        end,
                        set = function(_, v)
                            S:Set("tempoOverlayShown", v)
                        end,
                        width = "full",
                    },
                    tempoSparkline = {
                        type = "toggle",
                        name = L["FS_SPARKLINE"],
                        order = 3,
                        get = function()
                            return S:Get("tempoSparkline")
                        end,
                        set = function(_, v)
                            S:Set("tempoSparkline", v)
                        end,
                        width = "full",
                    },
                    alertHeader = {
                        type = "header",
                        name = "",
                        order = 10,
                    },
                    tempoAlertEnabled = {
                        type = "toggle",
                        name = L["FS_ALERT_ENABLED"],
                        order = 11,
                        get = function()
                            return S:Get("tempoAlertEnabled")
                        end,
                        set = function(_, v)
                            S:Set("tempoAlertEnabled", v)
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIPEMS")
                        end,
                        width = "full",
                    },
                    tempoAlertVisual = {
                        type = "toggle",
                        name = "  " .. L["FS_ALERT_VISUAL"],
                        order = 12,
                        get = function()
                            return S:Get("tempoAlertVisual")
                        end,
                        set = function(_, v)
                            S:Set("tempoAlertVisual", v)
                        end,
                        hidden = function()
                            return not S:Get("tempoAlertEnabled")
                        end,
                        width = "full",
                    },
                    tempoAlertAudio = {
                        type = "toggle",
                        name = "  " .. L["FS_ALERT_AUDIO"],
                        order = 13,
                        get = function()
                            return S:Get("tempoAlertAudio")
                        end,
                        set = function(_, v)
                            S:Set("tempoAlertAudio", v)
                        end,
                        hidden = function()
                            return not S:Get("tempoAlertEnabled")
                        end,
                        width = "full",
                    },
                    tempoAlertSoundSlow = {
                        type = "select",
                        name = "  " .. L["FS_ALERT_SOUND_SLOW"],
                        order = 14,
                        values = {
                            [43505] = "Raid Warning",
                            [37666] = "Toast Notification",
                            [8959] = "Ready Check",
                        },
                        get = function()
                            return S:Get("tempoAlertSoundSlow")
                        end,
                        set = function(_, v)
                            S:Set("tempoAlertSoundSlow", v)
                        end,
                        hidden = function()
                            return not S:Get("tempoAlertEnabled") or not S:Get("tempoAlertAudio")
                        end,
                        width = "normal",
                    },
                    tempoAlertTestSlow = {
                        type = "execute",
                        name = L["FS_ALERT_TEST"],
                        order = 14.1,
                        func = function()
                            local channel = S:Get("tempoAlertChannel") or "Master"
                            PlaySound(S:Get("tempoAlertSoundSlow") or 43505, channel)
                        end,
                        hidden = function()
                            return not S:Get("tempoAlertEnabled") or not S:Get("tempoAlertAudio")
                        end,
                        width = "half",
                    },
                    tempoAlertSoundFast = {
                        type = "select",
                        name = "  " .. L["FS_ALERT_SOUND_FAST"],
                        order = 15,
                        values = {
                            [43505] = "Raid Warning",
                            [37666] = "Toast Notification",
                            [8959] = "Ready Check",
                        },
                        get = function()
                            return S:Get("tempoAlertSoundFast")
                        end,
                        set = function(_, v)
                            S:Set("tempoAlertSoundFast", v)
                        end,
                        hidden = function()
                            return not S:Get("tempoAlertEnabled") or not S:Get("tempoAlertAudio")
                        end,
                        width = "normal",
                    },
                    tempoAlertTestFast = {
                        type = "execute",
                        name = L["FS_ALERT_TEST"],
                        order = 15.1,
                        func = function()
                            local channel = S:Get("tempoAlertChannel") or "Master"
                            PlaySound(S:Get("tempoAlertSoundFast") or 37666, channel)
                        end,
                        hidden = function()
                            return not S:Get("tempoAlertEnabled") or not S:Get("tempoAlertAudio")
                        end,
                        width = "half",
                    },
                    tempoAlertChannel = {
                        type = "select",
                        name = "  " .. L["FS_ALERT_CHANNEL"],
                        order = 16,
                        values = {
                            Master = "Master",
                            SFX = "Sound Effects",
                            Music = "Music",
                            Ambience = "Ambience",
                            Dialog = "Dialog",
                        },
                        get = function()
                            return S:Get("tempoAlertChannel")
                        end,
                        set = function(_, v)
                            S:Set("tempoAlertChannel", v)
                        end,
                        hidden = function()
                            return not S:Get("tempoAlertEnabled") or not S:Get("tempoAlertAudio")
                        end,
                        width = "normal",
                    },
                    tempoAlertSlowThreshold = {
                        type = "range",
                        name = L["FS_ALERT_SLOW"],
                        order = 20,
                        min = 0.3,
                        max = 0.9,
                        step = 0.1,
                        isPercent = true,
                        get = function()
                            return S:Get("tempoAlertSlowThreshold")
                        end,
                        set = function(_, v)
                            S:Set("tempoAlertSlowThreshold", v)
                        end,
                        hidden = function()
                            return not S:Get("tempoAlertEnabled")
                        end,
                        width = "double",
                    },
                    tempoAlertFastThreshold = {
                        type = "range",
                        name = L["FS_ALERT_FAST"],
                        order = 21,
                        min = 1.5,
                        max = 3.0,
                        step = 0.1,
                        get = function()
                            return S:Get("tempoAlertFastThreshold")
                        end,
                        set = function(_, v)
                            S:Set("tempoAlertFastThreshold", v)
                        end,
                        hidden = function()
                            return not S:Get("tempoAlertEnabled")
                        end,
                        width = "double",
                    },
                    holdHeader = {
                        type = "header",
                        name = "",
                        order = 30,
                        hidden = true,
                    },
                    holdModeEnabled = {
                        type = "toggle",
                        name = L["FS_HOLD_ENABLED"],
                        desc = L["FS_HOLD_ENABLED_DESC"],
                        order = 31,
                        hidden = true,
                        get = function()
                            return S:Get("holdModeEnabled")
                        end,
                        set = function(_, v)
                            S:Set("holdModeEnabled", v)
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIPEMS")
                        end,
                        width = "full",
                    },
                    holdModeSlot = {
                        type = "input",
                        name = L["FS_HOLD_SLOT"],
                        desc = L["FS_HOLD_SLOT_DESC"],
                        order = 32,
                        get = function()
                            return S:Get("holdModeSlot")
                        end,
                        set = function(_, v)
                            S:Set("holdModeSlot", v)
                        end,
                        hidden = function()
                            return not S:Get("holdModeEnabled")
                        end,
                        width = "double",
                    },
                    holdModePollRateMin = {
                        type = "range",
                        name = L["FS_HOLD_POLL_MIN"],
                        desc = L["FS_HOLD_POLL_MIN_DESC"],
                        order = 33,
                        min = 25,
                        max = 200,
                        step = 5,
                        get = function()
                            return S:Get("holdModePollRateMin")
                        end,
                        set = function(_, v)
                            S:Set("holdModePollRateMin", v)
                        end,
                        hidden = function()
                            return not S:Get("holdModeEnabled")
                        end,
                        width = "double",
                    },
                    holdModeNote = {
                        type = "description",
                        name = L["FS_HOLD_NOTE"],
                        order = 34,
                        fontSize = "small",
                        hidden = function()
                            return not S:Get("holdModeEnabled")
                        end,
                    },
                },
            },
            cvarHealth = {
                type = "group",
                name = L["GEMS_SETTINGS_CVAR_HEALTH"],
                order = 35,
                args = (function()
                    local args = {}
                    local CPM = GRIPEMS.CvarProfileManager
                    local function CleanNumber(val)
                        if val == nil then
                            return "?"
                        end
                        local num = tonumber(val)
                        if num then
                            local s = string.format("%.4f", num)
                            s = s:gsub("%.?0+$", "")
                            return s
                        end
                        return val
                    end
                    local function GetEffective(cvarName)
                        if CPM then
                            return CPM:GetEffectiveRecommendation(cvarName)
                        end
                        -- Fallback to General if CPM not loaded
                        for _, sec in ipairs(D().CVAR_SECTIONS) do
                            for _, rec in ipairs(sec.cvars) do
                                if rec.cvar == cvarName then
                                    return rec.recommended
                                end
                            end
                        end
                        return nil
                    end
                    args.desc = {
                        type = "description",
                        name = L["GEMS_SETTINGS_CVAR_DESC"],
                        order = 1,
                        fontSize = "medium",
                    }
                    args.autoFix = {
                        type = "toggle",
                        name = L["GEMS_SETTINGS_CVAR_AUTOFIX"],
                        desc = L["GEMS_SETTINGS_CVAR_AUTOFIX_DESC"],
                        order = 2,
                        get = function()
                            return S:Get("autoFixCVars")
                        end,
                        set = function(_, v)
                            S:Set("autoFixCVars", v)
                        end,
                        width = "full",
                    }
                    args.fixAllCritical = {
                        type = "execute",
                        name = L["GEMS_CVAR_FIX_ALL_CRITICAL"],
                        order = 3,
                        func = function()
                            local entries = S:Get("cvarAutoFixEntries") or {}
                            for _, section in ipairs(D().CVAR_SECTIONS) do
                                for _, rec in ipairs(section.cvars) do
                                    if rec.critical then
                                        local eff = GetEffective(rec.cvar)
                                        if eff then
                                            if not (rec.cvar == "SpellQueueWindow" and GRIPEMS.SQWOptimizer and GRIPEMS.SQWOptimizer:IsActive()) then
                                                if not D().CvarMatch(GetCVar(rec.cvar), eff) then
                                                    SetCVar(rec.cvar, eff)
                                                end
                                            end
                                            entries[rec.cvar] = true
                                        end
                                    end
                                end
                            end
                            S:Set("cvarAutoFixEntries", entries)
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIPEMS")
                        end,
                        disabled = function()
                            return InCombatLockdown()
                        end,
                        width = "double",
                    }
                    args.healthScore = {
                        type = "description",
                        order = 4,
                        fontSize = "medium",
                        name = function()
                            local totalWeight, matchWeight = 0, 0
                            local SQWO = GRIPEMS.SQWOptimizer
                            local sqwManaged = SQWO and SQWO:IsActive()
                            for _, section in ipairs(D().CVAR_SECTIONS) do
                                for _, rec in ipairs(section.cvars) do
                                    local eff = GetEffective(rec.cvar)
                                    if eff ~= nil then
                                        local w = rec.critical and 3 or 1
                                        totalWeight = totalWeight + w
                                        if rec.cvar == "SpellQueueWindow" and sqwManaged then
                                            matchWeight = matchWeight + w
                                        elseif D().CvarMatch(GetCVar(rec.cvar) or "", eff) then
                                            matchWeight = matchWeight + w
                                        end
                                    end
                                end
                            end
                            local score = totalWeight > 0 and math.floor(matchWeight / totalWeight * 100 + 0.5) or 100
                            local color = score >= 80 and "|cFF00FF00" or (score >= 50 and "|cFFFFFF00" or "|cFFFF0000")
                            return color .. string.format(L["GEMS_CVAR_HEALTH_SCORE"], score) .. "|r"
                        end,
                    }
                    args.profileSelect = {
                        type = "select",
                        name = L["GEMS_CVAR_PROFILE_SELECT"],
                        order = 5,
                        values = function()
                            local v = {}
                            v["__general"] = L["GEMS_CVAR_PROFILE_GENERAL"]
                            v["__auto"] = L["GEMS_CVAR_PROFILE_AUTO"]
                            for _, p in ipairs(D().CVAR_PROFILES) do
                                v[p.key] = p.label
                            end
                            local custom = S:Get("cvarProfiles") or {}
                            for key, prof in pairs(custom) do
                                v[key] = prof.label or key
                            end
                            return v
                        end,
                        sorting = function()
                            local order = { "__auto", "__general" }
                            for _, p in ipairs(D().CVAR_PROFILES) do
                                table.insert(order, p.key)
                            end
                            local custom = S:Get("cvarProfiles") or {}
                            for key in pairs(custom) do
                                table.insert(order, key)
                            end
                            return order
                        end,
                        get = function()
                            if CPM and not S:Get("cvarManualOverride") and S:Get("cvarAutoSwitchEnabled") then
                                return "__auto"
                            end
                            return S:Get("cvarActiveProfile") or "__general"
                        end,
                        set = function(_, val)
                            if not CPM then
                                return
                            end
                            if val == "__auto" then
                                CPM:ClearManualOverride()
                                S:Set("cvarAutoSwitchEnabled", true)
                            elseif val == "__general" then
                                CPM:SetManualProfile(nil)
                            else
                                CPM:SetManualProfile(val)
                            end
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIPEMS")
                        end,
                        disabled = function()
                            return InCombatLockdown()
                        end,
                        width = "normal",
                    }
                    args.autoSwitch = {
                        type = "toggle",
                        name = L["GEMS_CVAR_PROFILE_AUTOSWITCH"],
                        desc = L["GEMS_CVAR_PROFILE_AUTOSWITCH_DESC"],
                        order = 6,
                        get = function()
                            return S:Get("cvarAutoSwitchEnabled")
                        end,
                        set = function(_, v)
                            S:Set("cvarAutoSwitchEnabled", v)
                            if v and CPM then
                                CPM:ClearManualOverride()
                            end
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIPEMS")
                        end,
                        disabled = function()
                            return InCombatLockdown()
                        end,
                        width = "full",
                    }
                    args.whatChanged = {
                        type = "execute",
                        name = function()
                            local changes = CPM and CPM.pendingChanges
                            if changes and #changes > 0 then
                                return "|cFFFFAA00" .. string.format(L["GEMS_CVAR_CHANGES_DETECTED"], #changes) .. "|r"
                            end
                            return ""
                        end,
                        order = 7,
                        func = function()
                            if not CPM or not CPM.pendingChanges then
                                return
                            end
                            for _, c in ipairs(CPM.pendingChanges) do
                                local arrow = c.was .. " -> " .. (c.now or "?")
                                GRIPEMS:Print(tostring(c.label) .. ": " .. arrow)
                            end
                            CPM.pendingChanges = nil
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIPEMS")
                        end,
                        hidden = function()
                            return not CPM or not CPM.pendingChanges or #CPM.pendingChanges == 0
                        end,
                        width = "full",
                    }
                    args.sqwToggle = {
                        type = "toggle",
                        name = L["GEMS_SQW_OPTIMIZER"],
                        desc = L["GEMS_SQW_OPTIMIZER_DESC"],
                        order = 8,
                        get = function()
                            return S:Get("sqwOptimizerEnabled")
                        end,
                        set = function(_, v)
                            S:Set("sqwOptimizerEnabled", v)
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIPEMS")
                        end,
                        width = "full",
                    }
                    args.sqwBuffer = {
                        type = "range",
                        name = L["GEMS_SQW_BUFFER"],
                        desc = L["GEMS_SQW_BUFFER_DESC"],
                        order = 9,
                        min = 50,
                        max = 200,
                        step = 10,
                        bigStep = 10,
                        get = function()
                            return S:Get("sqwBuffer") or 100
                        end,
                        set = function(_, v)
                            S:Set("sqwBuffer", v)
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIPEMS")
                        end,
                        hidden = function()
                            return not S:Get("sqwOptimizerEnabled")
                        end,
                        width = "double",
                        disabled = function()
                            return InCombatLockdown()
                        end,
                    }
                    args.sqwLive = {
                        type = "description",
                        order = 10,
                        fontSize = "medium",
                        name = function()
                            local SQWO = GRIPEMS.SQWOptimizer
                            if not SQWO or not SQWO:IsActive() then return "" end
                            local st = SQWO:GetState()
                            if not st.sqw then return "" end
                            return "|cFF00CCFF" .. string.format(L["GEMS_SQW_LIVE"],
                                st.sqw, math.floor(st.latency or 0), st.buffer) .. "|r"
                        end,
                        hidden = function()
                            return not S:Get("sqwOptimizerEnabled")
                        end,
                        width = "full",
                    }
                    args.sqwAdvisory = {
                        type = "description",
                        order = 11,
                        fontSize = "medium",
                        name = function()
                            local SQWO = GRIPEMS.SQWOptimizer
                            if not SQWO or not SQWO:IsActive() then return "" end
                            local st = SQWO:GetState()
                            if not st.advisoryMs then return "" end
                            local line1 = string.format(L["GEMS_SQW_ADVISORY"], st.advisoryMs)
                            local line2 = string.format(L["GEMS_SQW_ADVISORY_DETAIL"],
                                math.floor(st.gcd or 0), st.sqw or 0, math.floor(st.latency or 0))
                            local effectiveMS = S:GetEffectiveClickRate() or 250
                            local delta = effectiveMS - st.advisoryMs
                            local word = delta > 0 and L["GEMS_SQW_SLOWER"] or L["GEMS_SQW_FASTER"]
                            local absDelta = math.abs(delta)
                            local deltaColor
                            if absDelta <= 50 then deltaColor = "|cFF00FF00"
                            elseif absDelta <= 100 then deltaColor = "|cFFFFFF00"
                            else deltaColor = "|cFFFF0000" end
                            local line3 = deltaColor .. string.format(L["GEMS_SQW_ADVISORY_DELTA"],
                                effectiveMS, absDelta, word) .. "|r"
                            return line1 .. "\n" .. line2 .. "\n" .. line3
                        end,
                        hidden = function()
                            return not S:Get("sqwOptimizerEnabled")
                        end,
                        width = "full",
                    }
                    for _, section in ipairs(D().CVAR_SECTIONS) do
                        local sectionArgs = {}
                        sectionArgs.fixAll = {
                            type = "execute",
                            name = L["GEMS_CVAR_FIX_ALL_SECTION"],
                            order = 1,
                            func = function()
                                for _, rec in ipairs(section.cvars) do
                                    local eff = GetEffective(rec.cvar)
                                    if eff then
                                        if not (rec.cvar == "SpellQueueWindow" and GRIPEMS.SQWOptimizer and GRIPEMS.SQWOptimizer:IsActive()) then
                                            if not D().CvarMatch(GetCVar(rec.cvar) or "", eff) then
                                                SetCVar(rec.cvar, eff)
                                            end
                                        end
                                    end
                                end
                                LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIPEMS")
                            end,
                            disabled = function()
                                return InCombatLockdown()
                            end,
                            width = "full",
                        }
                        for idx, rec in ipairs(section.cvars) do
                            local r = rec
                            local baseOrder = 10 + (idx - 1) * 3
                            sectionArgs["cvar_status_" .. r.cvar] = {
                                type = "description",
                                order = baseOrder,
                                fontSize = "medium",
                                name = function()
                                    local SQWO = GRIPEMS.SQWOptimizer
                                    if r.cvar == "SpellQueueWindow" and SQWO and SQWO:IsActive() then
                                        local st = SQWO:GetState()
                                        local val = st.sqw or tonumber(GetCVar("SpellQueueWindow")) or 400
                                        return "|cFF00CCFF" .. r.label .. ": " .. val .. "ms  " .. L["GEMS_SQW_MANAGED"] .. "|r"
                                    end
                                    local current = GetCVar(r.cvar) or "?"
                                    local cleanCurrent = CleanNumber(current)
                                    local eff = GetEffective(r.cvar)
                                    local match = D().CvarMatch(current, eff)
                                    local color
                                    if r.recommended == nil then
                                        color = "|cFF888888"
                                    elseif match then
                                        color = "|cFF00FF00"
                                    elseif r.critical then
                                        color = "|cFFFF0000"
                                    else
                                        color = "|cFFFFFF00"
                                    end
                                    if r.recommended == nil then
                                        return color
                                            .. r.label
                                            .. "|r: "
                                            .. cleanCurrent
                                            .. "  "
                                            .. L["GEMS_CVAR_YOUR_CHOICE"]
                                    elseif match then
                                        return color .. r.label .. "|r: " .. cleanCurrent
                                    else
                                        return color
                                            .. r.label
                                            .. "|r: "
                                            .. cleanCurrent
                                            .. "  -->  "
                                            .. CleanNumber(eff)
                                    end
                                end,
                                width = "double",
                            }
                            sectionArgs["cvar_fix_" .. r.cvar] = {
                                type = "execute",
                                name = L["GEMS_SETTINGS_CVAR_FIX"],
                                order = baseOrder + 1,
                                desc = function()
                                    local current = GetCVar(r.cvar) or "?"
                                    local eff = GetEffective(r.cvar)
                                    local lines = r.desc
                                    if r.cvar == "SpellQueueWindow" then
                                        local SQWO = GRIPEMS.SQWOptimizer
                                        if SQWO and SQWO:IsActive() then
                                            return r.desc .. "\n\n" .. L["GEMS_SQW_MANAGED"]
                                        end
                                    end
                                    if CPM.IsCVarSecure(r.cvar) and InCombatLockdown() then
                                        lines = lines .. "\n\n" .. L["GEMS_CVAR_COMBAT_DISABLED"]
                                    elseif eff and not D().CvarMatch(current, eff) then
                                        lines = lines
                                            .. "\n\n"
                                            .. string.format(
                                                L["GEMS_CVAR_WILL_CHANGE"],
                                                CleanNumber(current),
                                                CleanNumber(eff)
                                            )
                                    end
                                    return lines
                                end,
                                func = function()
                                    local eff = GetEffective(r.cvar)
                                    if eff then
                                        SetCVar(r.cvar, eff)
                                    end
                                    LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIPEMS")
                                end,
                                disabled = function()
                                    if r.cvar == "SpellQueueWindow" then
                                        local SQWO = GRIPEMS.SQWOptimizer
                                        if SQWO and SQWO:IsActive() then return true end
                                    end
                                    if r.recommended == nil then
                                        return true
                                    end
                                    local eff = GetEffective(r.cvar)
                                    if eff and D().CvarMatch(GetCVar(r.cvar) or "", eff) then
                                        return true
                                    end
                                    if CPM.IsCVarSecure(r.cvar) and InCombatLockdown() then
                                        return true
                                    end
                                    return false
                                end,
                                width = "half",
                                hidden = function()
                                    return r.recommended == nil
                                end,
                            }
                            sectionArgs["cvar_auto_" .. r.cvar] = {
                                type = "toggle",
                                name = L["GEMS_CVAR_AUTOFIX_ENTRY"],
                                order = baseOrder + 2,
                                get = function()
                                    return (S:Get("cvarAutoFixEntries") or {})[r.cvar]
                                end,
                                set = function(_, v)
                                    local entries = S:Get("cvarAutoFixEntries") or {}
                                    entries[r.cvar] = v or nil
                                    S:Set("cvarAutoFixEntries", entries)
                                end,
                                width = "half",
                                hidden = function()
                                    return not S:Get("autoFixCVars") or r.recommended == nil
                                end,
                            }
                            if r.recommended == nil then
                                sectionArgs["cvar_info_" .. r.cvar] = {
                                    type = "description",
                                    order = baseOrder + 1,
                                    fontSize = "small",
                                    name = "|cFF888888" .. r.desc .. "|r",
                                    width = "full",
                                }
                                sectionArgs["cvar_set_" .. r.cvar] = {
                                    type = "input",
                                    name = L["GEMS_CVAR_SET_VALUE"],
                                    desc = r.desc,
                                    order = baseOrder + 2,
                                    get = function()
                                        return GetCVar(r.cvar) or ""
                                    end,
                                    set = function(_, val)
                                        if val and val ~= "" then
                                            SetCVar(r.cvar, val)
                                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIPEMS")
                                        end
                                    end,
                                    disabled = function()
                                        return CPM.IsCVarSecure(r.cvar) and InCombatLockdown()
                                    end,
                                    width = "half",
                                }
                            end
                            sectionArgs["cvar_spacer_" .. r.cvar] = {
                                type = "description",
                                name = " ",
                                order = baseOrder + 2.9,
                                fontSize = "small",
                                width = "full",
                            }
                        end
                        args["cvarSection_" .. section.key] = {
                            type = "group",
                            name = section.label,
                            order = 10 + section.order,
                            inline = false,
                            args = sectionArgs,
                        }
                    end
                    if GRIPEMS.RegisterCallback then
                        GRIPEMS.RegisterCallback("SettingsPanel_CVar", "CVAR_PROFILE_CHANGED", function()
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIPEMS")
                        end)
                        GRIPEMS.RegisterCallback("SettingsPanel_SQW", "SQW_UPDATED", function()
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIPEMS")
                        end)
                        GRIPEMS.RegisterCallback("SettingsPanel_SQWState", "SQW_OPTIMIZER_STATE", function()
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIPEMS")
                        end)
                    end
                    return args
                end)(),
            },
            contextDetection = {
                type = "group",
                name = L["GEMS_SETTINGS_CONTEXT_HEADER"],
                order = 36,
                args = {
                    desc = {
                        type = "description",
                        name = L["GEMS_SETTINGS_CONTEXT_DESC"],
                        order = 1,
                        fontSize = "medium",
                    },
                    mythicPlusMid = {
                        type = "range",
                        name = L["GEMS_SETTINGS_MPLUS_MID"],
                        desc = L["GEMS_SETTINGS_MPLUS_MID_DESC"],
                        order = 2,
                        min = 2,
                        max = 20,
                        step = 1,
                        get = function()
                            return S:Get("mythicPlusTierMid")
                        end,
                        set = function(_, v)
                            local high = S:Get("mythicPlusTierHigh")
                            if v >= high then
                                v = high - 1
                            end
                            S:Set("mythicPlusTierMid", v)
                            local Engine = GRIPEMS.Engine
                            if Engine and Engine.UpdateContext then
                                Engine:UpdateContext()
                            end
                        end,
                        width = "double",
                    },
                    mythicPlusHigh = {
                        type = "range",
                        name = L["GEMS_SETTINGS_MPLUS_HIGH"],
                        desc = L["GEMS_SETTINGS_MPLUS_HIGH_DESC"],
                        order = 3,
                        min = 3,
                        max = 30,
                        step = 1,
                        get = function()
                            return S:Get("mythicPlusTierHigh")
                        end,
                        set = function(_, v)
                            local mid = S:Get("mythicPlusTierMid")
                            if v <= mid then
                                v = mid + 1
                            end
                            S:Set("mythicPlusTierHigh", v)
                            local Engine = GRIPEMS.Engine
                            if Engine and Engine.UpdateContext then
                                Engine:UpdateContext()
                            end
                        end,
                        width = "double",
                    },
                    delvesTierHigh = {
                        type = "range",
                        name = L["GEMS_SETTINGS_DELVES_HIGH"],
                        desc = L["GEMS_SETTINGS_DELVES_HIGH_DESC"],
                        order = 4,
                        min = 2,
                        max = 11,
                        step = 1,
                        get = function()
                            return S:Get("delvesTierHigh")
                        end,
                        set = function(_, v)
                            S:Set("delvesTierHigh", v)
                            local Engine = GRIPEMS.Engine
                            if Engine and Engine.UpdateContext then
                                Engine:UpdateContext()
                            end
                        end,
                        width = "double",
                    },
                },
            },
            info = {
                type = "group",
                name = L["GEMS_SETTINGS_SUPPORT"],
                order = 32,
                args = {
                    version = {
                        type = "description",
                        name = function()
                            return string.format(
                                L["GEMS_SETTINGS_VERSION_INFO"],
                                GRIPEMS.version or "dev",
                                GRIPEMS.Engine and GRIPEMS.Engine:GetActiveCount() or 0
                            )
                        end,
                        order = 1,
                        fontSize = "medium",
                    },
                    author = {
                        type = "description",
                        name = L["GEMS_ABOUT_AUTHOR"],
                        order = 2,
                    },
                    links = {
                        type = "description",
                        name = L["GEMS_ABOUT_LINKS"],
                        order = 3,
                    },
                    creditsHeader = {
                        type = "header",
                        name = L["GEMS_SUPPORT_CREDITS_HEADER"],
                        order = 5,
                    },
                    credits = {
                        type = "description",
                        name = L["GEMS_SUPPORT_CREDITS"],
                        order = 6,
                    },
                    systemHeader = {
                        type = "header",
                        name = L["GEMS_SUPPORT_SYSTEM_HEADER"],
                        order = 10,
                    },
                    systemInfo = {
                        type = "description",
                        name = function()
                            local ver, _, _, iface = GetBuildInfo()
                            local locale = GetLocale()
                            UpdateAddOnMemoryUsage()
                            local mem = GetAddOnMemoryUsage("GRIP-EMS")
                            return string.format(
                                "WoW: %s | Interface: %s | Locale: %s | Memory: %.1f KB",
                                ver or "?",
                                tostring(iface or "?"),
                                locale or "?",
                                mem or 0
                            )
                        end,
                        order = 11,
                        fontSize = "medium",
                    },
                    discordHeader = {
                        type = "header",
                        name = L["GEMS_SUPPORT_DISCORD_HEADER"],
                        order = 15,
                    },
                    discordLink = {
                        type = "description",
                        name = L["GEMS_SUPPORT_DISCORD"],
                        order = 16,
                    },
                    statusHeader = {
                        type = "header",
                        name = "",
                        order = 20,
                    },
                    status = {
                        type = "description",
                        name = function()
                            local lines = {}
                            -- Keybind count
                            local bindCount = 0
                            local KM = GRIPEMS.KeybindManager
                            if KM then
                                local binds = KM:GetAllKeybinds()
                                if binds then
                                    for _ in pairs(binds) do
                                        bindCount = bindCount + 1
                                    end
                                end
                            end
                            table.insert(lines, string.format(L["GEMS_ABOUT_KEYBINDS"], bindCount))
                            -- OOC queue
                            local oocCount = 0
                            if GRIPEMS.OOCQueue then
                                oocCount = GRIPEMS.OOCQueue:GetCount()
                            end
                            table.insert(lines, string.format(L["GEMS_ABOUT_OOC_QUEUE"], oocCount))
                            -- Migration source status
                            local sourceStatus = "Not detected"
                            if GRIPEMS.LegacyMigrate then
                                local gs = GRIPEMS.LegacyMigrate.GetSourceStatus()
                                if gs == "active" then
                                    sourceStatus = "Active (migration available)"
                                elseif gs == "disabled" then
                                    sourceStatus = "Disabled"
                                end
                            end
                            table.insert(lines, string.format(L["GEMS_ABOUT_SOURCE_STATUS"], sourceStatus))
                            -- Macro slots
                            local _, perChar = GetNumMacros()
                            table.insert(
                                lines,
                                string.format(L["GEMS_ABOUT_MACRO_SLOTS"], perChar, D().MAX_PER_CHAR_MACROS)
                            )
                            return table.concat(lines, "\n")
                        end,
                        order = 21,
                        fontSize = "medium",
                    },
                },
            },
            manageProfiles = {
                type = "group",
                name = L["GEMS_CVAR_PROFILE_MANAGE"],
                order = 38,
                args = (function()
                    local CPM = GRIPEMS.CvarProfileManager
                    local manageArgs = {}
                    local cloneFromVal = "__none"

                    -- StaticPopup for delete confirmation
                    if not StaticPopupDialogs["GRIPEMS_DELETE_CVAR_PROFILE"] then
                        StaticPopupDialogs["GRIPEMS_DELETE_CVAR_PROFILE"] = {
                            text = L["GEMS_CVAR_PROFILE_DELETE_CONFIRM"],
                            button1 = YES,
                            button2 = NO,
                            OnAccept = function(self)
                                local key = self.data
                                if key and GRIPEMS.CvarProfileManager then
                                    GRIPEMS.CvarProfileManager:DeleteProfile(key)
                                    LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIPEMS")
                                end
                            end,
                            timeout = 0,
                            whileDead = true,
                            hideOnEscape = true,
                            preferredIndex = 3,
                        }
                    end

                    manageArgs.desc = {
                        type = "description",
                        name = "Create and manage custom CVar profiles with per-CVar overrides.",
                        order = 1,
                        fontSize = "medium",
                    }
                    manageArgs.createName = {
                        type = "input",
                        name = L["GEMS_CVAR_PROFILE_CREATE_NAME"],
                        order = 2,
                        set = function(_, val)
                            if not val or val == "" or not CPM then
                                return
                            end
                            local src = cloneFromVal ~= "__none" and cloneFromVal or nil
                            CPM:CreateProfile(val, src)
                            cloneFromVal = "__none"
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIPEMS")
                        end,
                        get = function()
                            return ""
                        end,
                        width = "double",
                    }
                    manageArgs.cloneFrom = {
                        type = "select",
                        name = L["GEMS_CVAR_PROFILE_CLONE_FROM"],
                        order = 3,
                        values = function()
                            local v = { ["__none"] = L["GEMS_CVAR_PROFILE_GENERAL"] }
                            for _, p in ipairs(D().CVAR_PROFILES) do
                                v[p.key] = p.label
                            end
                            local custom = S:Get("cvarProfiles") or {}
                            for key, prof in pairs(custom) do
                                v[key] = prof.label or key
                            end
                            return v
                        end,
                        get = function()
                            return cloneFromVal
                        end,
                        set = function(_, val)
                            cloneFromVal = val
                        end,
                        width = "normal",
                    }

                    -- Rebuild dynamic entries (custom + built-in profile subgroups)
                    local function RebuildDynamic()
                        for k in pairs(manageArgs) do
                            if k:find("^cp_") or k:find("^bp_") then
                                manageArgs[k] = nil
                            end
                        end

                        -- Custom profiles (editable)
                        local custom = S:Get("cvarProfiles") or {}
                        local cpOrder = 10
                        for key, prof in pairs(custom) do
                            cpOrder = cpOrder + 1
                            local subArgs = {}
                            subArgs.rename = {
                                type = "input",
                                name = L["GEMS_CVAR_PROFILE_RENAME"],
                                order = 1,
                                get = function()
                                    local c = S:Get("cvarProfiles") or {}
                                    return c[key] and c[key].label or ""
                                end,
                                set = function(_, val)
                                    if CPM then
                                        CPM:RenameProfile(key, val)
                                        LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIPEMS")
                                    end
                                end,
                                width = "double",
                            }
                            subArgs.delete = {
                                type = "execute",
                                name = L["GEMS_CVAR_PROFILE_DELETE"],
                                order = 2,
                                func = function()
                                    local lbl = prof.label or key
                                    local dlg = StaticPopup_Show("GRIPEMS_DELETE_CVAR_PROFILE", lbl)
                                    if dlg then
                                        dlg.data = key
                                    end
                                end,
                                width = "half",
                                confirm = false,
                            }

                            -- Override count header
                            local overrides = prof.overrides or {}
                            local ovCount = 0
                            for _ in pairs(overrides) do
                                ovCount = ovCount + 1
                            end
                            subArgs.overridesHeader = {
                                type = "header",
                                name = ovCount > 0 and string.format(L["GEMS_CVAR_PROFILE_OVERRIDES"], ovCount)
                                    or L["GEMS_CVAR_PROFILE_NO_OVERRIDES"],
                                order = 3,
                            }

                            -- Per-override rows
                            local oOrder = 10
                            for cvarName, val in pairs(overrides) do
                                oOrder = oOrder + 1
                                local genVal = CPM and CPM:GetGeneralRecommendation(cvarName) or "?"
                                subArgs["ov_" .. cvarName] = {
                                    type = "input",
                                    name = cvarName,
                                    desc = "General: " .. tostring(genVal),
                                    order = oOrder,
                                    get = function()
                                        local c = S:Get("cvarProfiles") or {}
                                        if c[key] and c[key].overrides then
                                            return c[key].overrides[cvarName] or ""
                                        end
                                        return ""
                                    end,
                                    set = function(_, v)
                                        if CPM then
                                            CPM:SetProfileOverride(key, cvarName, v ~= "" and v or nil)
                                            RebuildDynamic()
                                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIPEMS")
                                        end
                                    end,
                                    width = "double",
                                }
                                subArgs["rm_" .. cvarName] = {
                                    type = "execute",
                                    name = "X",
                                    desc = L["GEMS_CVAR_PROFILE_OVERRIDE_NONE"],
                                    order = oOrder + 0.5,
                                    func = function()
                                        if CPM then
                                            CPM:SetProfileOverride(key, cvarName, nil)
                                            RebuildDynamic()
                                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIPEMS")
                                        end
                                    end,
                                    width = "half",
                                }
                            end

                            -- Add Override dropdown
                            subArgs.addOverride = {
                                type = "select",
                                name = L["GEMS_CVAR_PROFILE_ADD_OVERRIDE"],
                                order = 100,
                                values = function()
                                    local v = { ["__none"] = "" }
                                    local c = S:Get("cvarProfiles") or {}
                                    local existing = c[key] and c[key].overrides or {}
                                    for _, section in ipairs(D().CVAR_SECTIONS) do
                                        for _, rec in ipairs(section.cvars) do
                                            if not existing[rec.cvar] then
                                                v[rec.cvar] = rec.label or rec.cvar
                                            end
                                        end
                                    end
                                    return v
                                end,
                                get = function()
                                    return "__none"
                                end,
                                set = function(_, val)
                                    if val == "__none" or not CPM then
                                        return
                                    end
                                    local genVal = CPM:GetGeneralRecommendation(val) or "1"
                                    CPM:SetProfileOverride(key, val, genVal)
                                    RebuildDynamic()
                                    LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIPEMS")
                                end,
                                width = "double",
                            }

                            manageArgs["cp_" .. key] = {
                                type = "group",
                                name = prof.label or key,
                                order = cpOrder,
                                inline = false,
                                args = subArgs,
                            }
                        end

                        -- Built-in profiles (read-only)
                        for i, p in ipairs(D().CVAR_PROFILES) do
                            local bArgs = {}
                            local bOverrides = p.overrides or {}
                            local bCount = 0
                            for _ in pairs(bOverrides) do
                                bCount = bCount + 1
                            end
                            bArgs.overridesHeader = {
                                type = "header",
                                name = bCount > 0 and string.format(L["GEMS_CVAR_PROFILE_OVERRIDES"], bCount)
                                    or L["GEMS_CVAR_PROFILE_NO_OVERRIDES"],
                                order = 1,
                            }
                            local bOrder = 2
                            for cvarName, val in pairs(bOverrides) do
                                bOrder = bOrder + 1
                                local genVal = CPM and CPM:GetGeneralRecommendation(cvarName) or "?"
                                bArgs["ov_" .. cvarName] = {
                                    type = "description",
                                    name = cvarName
                                        .. ": "
                                        .. tostring(val)
                                        .. "  (General: "
                                        .. tostring(genVal)
                                        .. ")",
                                    order = bOrder,
                                    fontSize = "medium",
                                }
                            end
                            manageArgs["bp_" .. p.key] = {
                                type = "group",
                                name = p.label .. " (built-in)",
                                order = 50 + i,
                                inline = false,
                                args = bArgs,
                            }
                        end
                    end

                    RebuildDynamic()

                    if GRIPEMS.RegisterCallback then
                        GRIPEMS.RegisterCallback("SettingsPanel_Manage", "CVAR_PROFILE_CHANGED", function()
                            RebuildDynamic()
                        end)
                    end

                    return manageArgs
                end)(),
            },
            profileMap = {
                type = "group",
                name = L["GEMS_CVAR_MAP_HEADER"],
                order = 39,
                args = (function()
                    local CPM = GRIPEMS.CvarProfileManager
                    local mapArgs = {}
                    mapArgs.desc = {
                        type = "description",
                        name = L["GEMS_CVAR_MAP_DESC"],
                        order = 1,
                        fontSize = "medium",
                    }
                    local gOrder = 2
                    for gi, group in ipairs(D().CONTEXT_GROUPS) do
                        gOrder = gOrder + 1
                        mapArgs["grpHeader_" .. gi] = {
                            type = "header",
                            name = group.name,
                            order = gOrder,
                        }
                        for _, ctxKey in ipairs(group.keys) do
                            gOrder = gOrder + 1
                            -- Resolve built-in default for desc label
                            local biKey = D().CVAR_PROFILE_MAP[ctxKey]
                            if not biKey then
                                local chain = D().CONTEXT_FALLBACKS and D().CONTEXT_FALLBACKS[ctxKey]
                                if chain then
                                    for _, fb in ipairs(chain) do
                                        if D().CVAR_PROFILE_MAP[fb] then
                                            biKey = D().CVAR_PROFILE_MAP[fb]
                                            break
                                        end
                                    end
                                end
                            end
                            local biLabel
                            if biKey then
                                for _, p in ipairs(D().CVAR_PROFILES) do
                                    if p.key == biKey then
                                        biLabel = p.label
                                        break
                                    end
                                end
                            end
                            mapArgs["ctx_" .. ctxKey] = {
                                type = "select",
                                name = ctxKey,
                                desc = biLabel and string.format(L["GEMS_CVAR_MAP_DEFAULT"], biLabel) or nil,
                                order = gOrder,
                                values = function()
                                    local v = { ["__none"] = L["GEMS_CVAR_MAP_NONE"] }
                                    for _, p in ipairs(D().CVAR_PROFILES) do
                                        v[p.key] = p.label
                                    end
                                    local custom = S:Get("cvarProfiles") or {}
                                    for key, prof in pairs(custom) do
                                        v[key] = prof.label or key
                                    end
                                    return v
                                end,
                                get = function()
                                    local userMap = S:Get("cvarProfileMap") or {}
                                    if userMap[ctxKey] then
                                        return userMap[ctxKey]
                                    end
                                    if CPM then
                                        local resolved = CPM:ResolveProfile(ctxKey)
                                        if resolved then
                                            return resolved
                                        end
                                    end
                                    return "__none"
                                end,
                                set = function(_, val)
                                    if not CPM then
                                        return
                                    end
                                    if val == "__none" then
                                        CPM:SetContextMapping(ctxKey, nil)
                                    else
                                        CPM:SetContextMapping(ctxKey, val)
                                    end
                                    LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIPEMS")
                                end,
                                width = "double",
                            }
                        end
                    end
                    return mapArgs
                end)(),
            },
        },
    }

    -- Add Profiles tab via AceDBOptions
    local db = S:GetDB()
    if db then
        options.args.profiles = AceDBOptions:GetOptionsTable(db)
        options.args.profiles.order = 40
    else
        GRIPEMS:Debug("SettingsPanel: AceDB not available for profiles tab")
    end

    -- Register with AceConfig
    AceConfig:RegisterOptionsTable("GRIP-EMS", options)

    -- Register with Blizzard Settings panel
    local blizFrame = AceConfigDialog:AddToBlizOptions("GRIP-EMS", "|cFF00CC66GRIP|r-EMS")

    -- Hook OnShow to restyle when user first opens ESC > Options > AddOns
    -- Zero-delay timer ensures AceConfigDialog's FeedToBlizPanel callback
    -- has populated content before we restyle.
    if blizFrame then
        blizFrame:HookScript("OnShow", function()
            C_Timer.After(0, function()
                SP:RestyleBlizPanel()
            end)
        end)
    end
end

--- Open the settings panel programmatically.
function SP:Open()
    local AceConfigDialog = LibStub("AceConfigDialog-3.0")
    AceConfigDialog:Open("GRIP-EMS")

    -- Apply dark theme after AceConfigDialog creates/shows the widget
    local widget = AceConfigDialog.OpenFrames and AceConfigDialog.OpenFrames["GRIP-EMS"]
    RestyleAceFrame(widget)
end

--- Restyle the Blizzard Settings (ESC -> Options -> Addons) embedded frame.
--- Called from Initialize after AddToBlizOptions creates the embedded panel.
function SP:RestyleBlizPanel()
    local AceConfigDialog = LibStub("AceConfigDialog-3.0")
    local blizEntry = AceConfigDialog.BlizOptions and AceConfigDialog.BlizOptions["GRIP-EMS"]
    if not blizEntry then
        return
    end
    -- BlizOptions entry is {widget, ...} or {frame=widget}
    local widget = blizEntry[1] or blizEntry.frame
    if not widget then
        return
    end
    -- If this is a raw frame (no .frame property), wrap it
    if not widget.frame and widget.GetObjectType then
        widget = { frame = widget, _gripRestyled = false }
    end
    RestyleAceFrame(widget)
end
