-- GRIP-EMS: ExecutionTracer
-- Created: 2026-04-03
-- Updated: 2026-08-17
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)

-- GRIP-EMS: Execution Tracer
-- Records spell casts, tracks per-spell statistics, and feeds debug output.
-- Separate event frame to avoid taint with Engine's secure frames.

local ADDON_NAME, GRIPEMS = ...

GRIPEMS.ExecutionTracer = {}
local ET = GRIPEMS.ExecutionTracer
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

---------------------------------------------------------------------------
-- External cast callback registry
---------------------------------------------------------------------------
ET._callbacks = {}

--- Register a callback to be notified on each spell cast.
--- @param id string Unique identifier for this callback
--- @param fn function Callback receiving (spellID, spellName, timestamp)
function ET:RegisterCastCallback(id, fn)
    ET._callbacks[id] = fn
end

--- Unregister a previously registered cast callback.
--- @param id string Identifier used during registration
function ET:UnregisterCastCallback(id)
    ET._callbacks[id] = nil
end

---------------------------------------------------------------------------
-- Ring buffer for trace history
---------------------------------------------------------------------------
ET.history = {}
ET.MAX_HISTORY = 200
ET._head = 0
ET._count = 0

---------------------------------------------------------------------------
-- Per-spell stats table
---------------------------------------------------------------------------
ET.spellStats = {}
-- [spellID] = { casts = 0, name = "", lastCast = 0 }

---------------------------------------------------------------------------
-- Click rate tracking (rolling window of cast timestamps)
---------------------------------------------------------------------------
ET._clickTimes = {}
ET.CLICK_RATE_WINDOW = 10 -- seconds to track

---------------------------------------------------------------------------
-- Private event frame (named for /reload reuse, separate from Engine to avoid taint)
---------------------------------------------------------------------------
local eventFrame = _G["GRIPEMS_TracerEvent"] or CreateFrame("Frame", "GRIPEMS_TracerEvent")
eventFrame:UnregisterAllEvents()

---------------------------------------------------------------------------
-- UNIT_SPELLCAST_SUCCEEDED handler
---------------------------------------------------------------------------
eventFrame:SetScript("OnEvent", function(self, event, unit, castGUID, spellID)
    if unit ~= "player" then
        return
    end

    -- Filter: nil/zero spellID, Auto Attack (6603), Auto Shot (75)
    if not spellID or spellID == 0 then
        return
    end
    if spellID == 6603 or spellID == 75 then
        return
    end

    local spellName = C_Spell.GetSpellName(spellID)
    if not spellName then
        return
    end

    local now = GetTime()
    local Engine = GRIPEMS.Engine

    -- Determine associated sequence (if any)
    local seqName = nil
    if Engine and Engine._lastClickedSequence then
        -- Associate if cast is within 1.5s of last button click
        local elapsed = now - (Engine._lastClickTime or 0)
        if elapsed < 1.5 then
            seqName = Engine._lastClickedSequence
            ET._activeSequenceName = seqName
        end
    end

    -- Record to history ring buffer
    ET._head = (ET._head % ET.MAX_HISTORY) + 1
    ET.history[ET._head] = {
        spellID = spellID,
        spellName = spellName,
        timestamp = now,
        sequenceName = seqName,
    }
    if ET._count < ET.MAX_HISTORY then
        ET._count = ET._count + 1
    end

    -- Update per-spell stats
    local stat = ET.spellStats[spellID]
    if not stat then
        stat = { casts = 0, name = spellName, lastCast = 0 }
        ET.spellStats[spellID] = stat
    end
    stat.casts = stat.casts + 1
    stat.lastCast = now

    -- Click rate tracking: add timestamp, prune old entries
    ET._clickTimes[#ET._clickTimes + 1] = now
    while #ET._clickTimes > 0 and (now - ET._clickTimes[1]) > ET.CLICK_RATE_WINDOW do
        table.remove(ET._clickTimes, 1)
    end

    -- Feed to debug window
    local DW = GRIPEMS.DebugWindow
    if DW then
        local seqStr = seqName and (" [" .. seqName .. "]") or ""
        local msg = string.format(L["GEMS_TRACE_CAST"], spellName, spellID, seqStr)
        DW:AddMessage(msg)
    end

    -- Notify registered cast callbacks
    for _, cb in pairs(ET._callbacks) do
        cb(spellID, spellName, now)
    end

    -- Throttled callback to TempoAdvisor (2s minimum between calls)
    if GRIPEMS.TempoAdvisor and GetTime() - (ET._lastTACallback or 0) > 2 then
        ET._lastTACallback = GetTime()
        GRIPEMS.TempoAdvisor:OnExecutionTracerUpdate(ET._activeSequenceName, ET._clickTimes, ET.spellStats)
    end
end)

---------------------------------------------------------------------------
-- Public methods
---------------------------------------------------------------------------

--- Start listening for spell cast events.
function ET:Start()
    eventFrame:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED")
end

--- Stop listening for spell cast events.
function ET:Stop()
    eventFrame:UnregisterEvent("UNIT_SPELLCAST_SUCCEEDED")
end

--- Check if the tracer is currently active.
--- @return boolean
function ET:IsActive()
    return eventFrame:IsEventRegistered("UNIT_SPELLCAST_SUCCEEDED")
end

--- Reset all trace data (history, stats, click times).
function ET:Reset()
    ET.history = {}
    ET._head = 0
    ET._count = 0
    ET.spellStats = {}
    ET._clickTimes = {}
end

--- Get actual casts per second over the tracking window.
--- @return number Casts per second (0 if fewer than 2 samples)
function ET:GetClickRate()
    local now = GetTime()
    while #ET._clickTimes > 0 and (now - ET._clickTimes[1]) > ET.CLICK_RATE_WINDOW do
        table.remove(ET._clickTimes, 1)
    end
    if #ET._clickTimes < 2 then
        return 0
    end
    local span = ET._clickTimes[#ET._clickTimes] - ET._clickTimes[1]
    if span <= 0 then
        return 0
    end
    return (#ET._clickTimes - 1) / span
end

--- Get the top N spells by cast count.
--- @param count number|nil Max results (default 5)
--- @return table Array of { spellID, name, casts }
function ET:GetTopSpells(count)
    count = count or 5
    local sorted = {}
    for id, stat in pairs(ET.spellStats) do
        sorted[#sorted + 1] = {
            spellID = id,
            name = stat.name,
            casts = stat.casts,
        }
    end
    table.sort(sorted, function(a, b)
        return a.casts > b.casts
    end)
    local result = {}
    for i = 1, math.min(count, #sorted) do
        result[i] = sorted[i]
    end
    return result
end
