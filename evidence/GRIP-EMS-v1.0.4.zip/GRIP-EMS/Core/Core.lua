-- GRIP-EMS: Core Bootstrap
-- Addon table, version, state initialization, slash command registration

local ADDON_NAME, GRIPEMS = ...

-- Make addon table global for SavedVariables access
_G.GRIPEMS = GRIPEMS

-- Version info
local rawVersion = C_AddOns.GetAddOnMetadata(ADDON_NAME, "Version")
GRIPEMS.version = (rawVersion and not rawVersion:find("@", 1, true))
    and rawVersion or "dev"
GRIPEMS.addonName = ADDON_NAME

-- Runtime state (cleared on reload)
GRIPEMS.state = {
    initialized = false,
}

-- Localization
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS")

-- Logging

--- Print a user-facing message with the GRIP-EMS green prefix.
--- @param msg string Message to display
function GRIPEMS:Print(msg)
    DEFAULT_CHAT_FRAME:AddMessage("|cff00cc66GRIP-EMS:|r " .. tostring(msg))
end

--- Print a debug message (gray prefix). Chat output only when debug mode is on.
--- Always buffers to DebugWindow regardless of debug setting.
--- @param msg string Debug message
function GRIPEMS:Debug(msg)
    local S = GRIPEMS.Settings
    local isDebug = S and S:Get("debug")
    -- Always buffer to debug window (even if chat output is off)
    local DW = GRIPEMS.DebugWindow
    if DW then
        local timestamp = date("%H:%M:%S")
        local formatted = timestamp .. " " .. tostring(msg)
        DW:AddMessage(formatted)
    end
    -- Chat output only when debug mode is on
    if isDebug then
        DEFAULT_CHAT_FRAME:AddMessage("|cff666666GRIP-EMS:|r " .. tostring(msg))
    end
end

-- Slash command helpers

--- Parse slash command input into command and argument parts.
--- @param input string Raw slash command input
--- @return string cmd The first word (lowercased)
--- @return string arg The remainder after the first word (untrimmed case preserved)
local function ParseSlashInput(input)
    local trimmed = (input or ""):trim()
    local cmd, arg = trimmed:match("^(%S+)%s*(.*)")
    if not cmd then
        return "", ""
    end
    return cmd:lower(), arg or ""
end

--- Show all available slash commands with descriptions.
local function ShowHelp()
    GRIPEMS:Print(L["GEMS_HELP_HEADER"])
    GRIPEMS:Print(L["GEMS_HELP_NONE"])
    GRIPEMS:Print(L["GEMS_HELP_OPEN"])
    GRIPEMS:Print(L["GEMS_HELP_HELP"])
    GRIPEMS:Print(L["GEMS_HELP_CREATE"])
    GRIPEMS:Print(L["GEMS_HELP_DELETE"])
    GRIPEMS:Print(L["GEMS_HELP_LIST"])
    GRIPEMS:Print(L["GEMS_HELP_TEST"])
    GRIPEMS:Print(L["GEMS_HELP_RESET"])
    GRIPEMS:Print(L["GEMS_HELP_BIND"])
    GRIPEMS:Print(L["GEMS_HELP_UNBIND"])
    GRIPEMS:Print(L["GEMS_HELP_BINDS"])
    GRIPEMS:Print(L["GEMS_HELP_IMPORT"])
    GRIPEMS:Print(L["GEMS_HELP_EXPORT"])
    GRIPEMS:Print(L["GEMS_HELP_EXPORTALL"])
    GRIPEMS:Print(L["GEMS_HELP_MIGRATE"])
    GRIPEMS:Print(L["GEMS_HELP_GUIDE"])
    GRIPEMS:Print(L["GEMS_HELP_DEBUG"])
    GRIPEMS:Print(L["GEMS_HELP_DEBUGWINDOW"])
    GRIPEMS:Print(L["GEMS_HELP_STATUS"])
    GRIPEMS:Print(L["GEMS_HELP_TESTLOCALE"])
    GRIPEMS:Print(L["GEMS_HELP_SETTINGS"])
    GRIPEMS:Print(L["GEMS_HELP_SEND"])
    GRIPEMS:Print(L["GEMS_HELP_ACCEPT"])
end

--- Handle /gems create [name]: create and activate a test sequence.
--- @param arg string Optional sequence name (defaults to TestSeq)
local function HandleCreate(arg)
    local D = GRIPEMS.Defaults
    local seqName = (arg ~= "") and arg or D.TestSequence.name

    -- Check if sequence already exists
    if GRIPEMS.Engine.sequences[seqName] then
        GRIPEMS:Print(string.format(L["GEMS_ALREADY_EXISTS"], seqName, seqName))
        return
    end

    -- Build sequence data from the test template (versioned format)
    local testVer = D.TestSequence.versions[1]
    local seqData = {
        name = seqName,
        icon = D.TestSequence.icon,
        defaultVersion = 1,
        contextOverrides = {},
        versions = {
            [1] = {
                stepFunction = testVer.stepFunction,
                steps = {},
                resetOnCombat = testVer.resetOnCombat,
                resetOnTarget = testVer.resetOnTarget,
                resetOnGear = testVer.resetOnGear,
                resetOnSpec = testVer.resetOnSpec,
                resetTimer = testVer.resetTimer,
            },
        },
        author = UnitName("player") or "",
        version = "1",
        description = "",
        classID = select(3, UnitClass("player")) or 0,
        specID = nil,
        createdAt = time(),
        updatedAt = time(),
    }
    -- Copy steps from test template
    for i, step in ipairs(testVer.steps) do
        seqData.versions[1].steps[i] = step
    end

    GRIPEMS.Engine:ActivateSequence(seqName, seqData)
    local ver = GRIPEMS.Engine:GetActiveVersion(seqData)
    GRIPEMS:Print(string.format(L["GEMS_CREATED"], seqName,
        ver and #ver.steps or 0, ver and ver.stepFunction or "Sequential"))
end

--- Handle /gems delete <name>: deactivate a sequence and delete its macro stub.
--- @param arg string Sequence name (required)
local function HandleDelete(arg)
    if arg == "" then
        GRIPEMS:Print(L["GEMS_DELETE_NEED_NAME"])
        return
    end
    if not GRIPEMS.Engine.sequences[arg] then
        GRIPEMS:Print(string.format(L["GEMS_NOT_FOUND"], arg))
        return
    end
    GRIPEMS.Engine:DeactivateSequence(arg)
    GRIPEMS:Print(string.format(L["GEMS_DELETED"], arg))
end

--- Handle /gems list: print all active sequences with step info.
local function HandleList()
    local list = GRIPEMS.Engine:GetSequenceList()
    if #list == 0 then
        GRIPEMS:Print(L["GEMS_LIST_EMPTY"])
        return
    end
    GRIPEMS:Print(string.format(L["GEMS_LIST_HEADER"], #list))
    for _, entry in ipairs(list) do
        GRIPEMS:Print(string.format(L["GEMS_LIST_ENTRY"],
            entry.name, entry.stepCount, entry.currentStep,
            entry.stepCount, entry.stepFunction))
    end
end

--- Handle /gems test <name>: manually advance step for debugging.
--- @param arg string Sequence name (required)
local function HandleTest(arg)
    if arg == "" then
        GRIPEMS:Print(L["GEMS_TEST_NEED_NAME"])
        return
    end
    if not GRIPEMS.Engine.sequences[arg] then
        GRIPEMS:Print(string.format(L["GEMS_NOT_FOUND"], arg))
        return
    end
    GRIPEMS.Engine:AdvanceStep(arg)
    local step = GRIPEMS.Engine:GetCurrentStep(arg)
    local ver = GRIPEMS.Engine:GetActiveVersion(GRIPEMS.Engine.sequences[arg].data)
    local stepCount = ver and #ver.steps or 0
    GRIPEMS:Print(string.format(L["GEMS_TEST_ADVANCED"], arg, step, stepCount))
end

--- Handle /gems reset <name>: reset sequence to step 1.
--- @param arg string Sequence name (required)
local function HandleReset(arg)
    if arg == "" then
        GRIPEMS:Print(L["GEMS_RESET_NEED_NAME"])
        return
    end
    if not GRIPEMS.Engine.sequences[arg] then
        GRIPEMS:Print(string.format(L["GEMS_NOT_FOUND"], arg))
        return
    end
    GRIPEMS.Engine:ResetStep(arg)
    GRIPEMS:Print(string.format(L["GEMS_RESET_DONE"], arg))
end

--- Handle /gems debug [subcommand]: toggle debug mode or dispatch subcommands.
--- @param arg string Optional subcommand (e.g. "rowrefresh")
local function HandleDebug(arg)
    local sub = (arg or ""):lower():trim()

    if sub == "rowrefresh" then
        local SLV = GRIPEMS.StepListView
        if SLV and SLV.ToggleDebugRowRefresh then
            local state = SLV:ToggleDebugRowRefresh()
            GRIPEMS:Print("RefreshCurrentRow: " .. (state and "DISABLED" or "ENABLED"))
        else
            GRIPEMS:Print("StepListView not loaded")
        end
        return
    end

    -- Default: toggle debug mode (existing behavior)
    local S = GRIPEMS.Settings
    if not S then return end
    local current = S:Get("debug")
    S:Set("debug", not current)
    -- Auto-show/hide debug window when toggling debug mode
    local DW = GRIPEMS.DebugWindow
    if DW then
        if S:Get("debug") then
            DW:Show()
        end
    end
    if S:Get("debug") then
        GRIPEMS:Print(L["GEMS_DEBUG_ENABLED"])
    else
        GRIPEMS:Print(L["GEMS_DEBUG_DISABLED"])
    end
end

--- Handle /gems status: display engine diagnostics.
local function HandleStatus()
    local D = GRIPEMS.Defaults
    local activeCount = GRIPEMS.Engine:GetActiveCount()
    local _, perChar = GetNumMacros()
    local keyDown = GetCVar("ActionButtonUseKeyDown") or "?"
    local sqw = GetCVar("SpellQueueWindow") or "?"
    local oocCount = GRIPEMS.OOCQueue:GetCount()

    GRIPEMS:Print(L["GEMS_STATUS_HEADER"])
    GRIPEMS:Print(string.format(L["GEMS_STATUS_SEQUENCES"], activeCount))
    GRIPEMS:Print(string.format(L["GEMS_STATUS_MACROS"], perChar,
        D.MAX_PER_CHAR_MACROS))
    GRIPEMS:Print(string.format(L["GEMS_STATUS_KEYDOWN"], keyDown))
    GRIPEMS:Print(string.format(L["GEMS_STATUS_SQW"], sqw))
    GRIPEMS:Print(string.format(L["GEMS_STATUS_OOC"], oocCount))

    local KM = GRIPEMS.KeybindManager
    local bindCount = 0
    local binds = KM and KM:GetAllKeybinds()
    if binds then
        for _ in pairs(binds) do bindCount = bindCount + 1 end
    end
    GRIPEMS:Print(string.format(L["GEMS_STATUS_KEYBINDS"], bindCount))
end

--- Handle /gems bind <name> <key>: bind a key to fire a sequence.
--- @param arg string "seqName key" (e.g. "TestSeq CTRL-F12")
local function HandleBind(arg)
    if arg == "" then
        GRIPEMS:Print(L["GEMS_BIND_NEED_ARGS"])
        return
    end
    -- First word = seqName, rest = key
    local seqName, key = arg:match("^(%S+)%s+(.+)")
    if not seqName or not key then
        GRIPEMS:Print(L["GEMS_BIND_NEED_ARGS"])
        return
    end
    key = key:upper():trim()
    if not GRIPEMS.Engine.sequences[seqName] then
        GRIPEMS:Print(string.format(L["GEMS_NOT_FOUND"], seqName))
        return
    end
    GRIPEMS.KeybindManager:SetKeybind(seqName, key)
end

--- Handle /gems unbind <name>: remove keybinding from a sequence.
--- @param arg string Sequence name
local function HandleUnbind(arg)
    if arg == "" then
        GRIPEMS:Print(L["GEMS_UNBIND_NEED_NAME"])
        return
    end
    local seqName = arg:trim()
    if not GRIPEMS.Engine.sequences[seqName] then
        GRIPEMS:Print(string.format(L["GEMS_NOT_FOUND"], seqName))
        return
    end
    GRIPEMS.KeybindManager:ClearKeybind(seqName)
end

--- Handle /gems binds: list all keybindings for the current spec.
local function HandleBinds()
    local KM = GRIPEMS.KeybindManager
    local spec = KM:GetCurrentSpec()
    local binds = KM:GetAllKeybinds()
    if not binds or not next(binds) then
        GRIPEMS:Print(L["GEMS_BINDS_EMPTY"])
        return
    end
    GRIPEMS:Print(string.format(L["GEMS_BINDS_HEADER"], spec))
    for key, seqName in pairs(binds) do
        GRIPEMS:Print(string.format(L["GEMS_BINDS_ENTRY"], key, seqName))
    end
end

--- Handle /gems import [string]: open paste frame, or direct-import if arg given.
--- With no arg, opens the AceGUI paste frame (recommended for long strings).
--- With an arg, attempts direct import as fallback for short/programmatic strings.
--- @param arg string Optional encoded import string
local function HandleImport(arg)
    if arg == "" then
        -- No arg: open paste frame
        GRIPEMS.ImportFrame:Show()
        return
    end

    -- If arg is short, warn that paste frame is recommended for real imports
    if #arg < 100 then
        GRIPEMS:Print(L["GEMS_IMPORT_SHORT_STRING"])
    end

    local GI = GRIPEMS.GSEImport
    local ok, result = GI.Import(arg)
    if ok then
        GRIPEMS:PrintMigrationReport(result, "import")
    else
        GRIPEMS:Print(string.format(L["GEMS_IMPORT_FAILED"], tostring(result)))
        -- If direct import failed and it looks like truncation, suggest paste frame
        if #arg > 200 then
            GRIPEMS:Print(L["GEMS_IMPORT_USE_FRAME"])
        end
    end
end

--- Handle /gems export <name>: encode an active sequence as a GRIP string.
--- @param arg string Sequence name
local function HandleExport(arg)
    if arg == "" then
        GRIPEMS:Print(L["GEMS_EXPORT_USAGE"])
        return
    end

    local GE = GRIPEMS.GRIPExport
    local ok, result = GE.Export(arg)
    if ok then
        local EF = GRIPEMS.ExportFrame
        if EF then
            EF:Show(arg, result)
        else
            GRIPEMS:Print(string.format(L["GEMS_EXPORT_RESULT"], result))
        end
    else
        GRIPEMS:Print(string.format(L["GEMS_EXPORT_FAILED"], tostring(result)))
    end
end

--- Handle /gems migrate: bulk-import all sequences from a compatible sequencer.
local function HandleMigrate()
    if not GRIPEMS.GSEMigrate then
        GRIPEMS:Print("Migration module not loaded")
        return
    end
    local status = GRIPEMS.GSEMigrate.GetGSEStatus()
    if status == "none" then
        GRIPEMS:Print(L["GEMS_MIGRATE_NO_GSE"])
        return
    elseif status == "disabled" then
        GRIPEMS:Print(L["GEMS_MIGRATE_GSE_DISABLED"])
        return
    end
    local ok, results = GRIPEMS.GSEMigrate.MigrateAll(false)
    if ok then
        GRIPEMS:PrintMigrationReport(results, "migrate")
    else
        GRIPEMS:Print(string.format(L["GEMS_MIGRATE_FAILED"],
            tostring(results)))
    end
end

--- Print a structured migration/import report to chat and debug window.
--- @param results table Import results table from import or migration modules
--- @param source string "import" or "migrate"
function GRIPEMS:PrintMigrationReport(results, source)
    if not results then return end

    local function report(msg)
        GRIPEMS:Print(msg)
        GRIPEMS:Debug(msg)
    end

    -- 1) Header
    if source == "migrate" then
        report("|cFF00FF00" .. L["GEMS_REPORT_HEADER_MIGRATE"] .. "|r")
    else
        report("|cFF00FF00" .. L["GEMS_REPORT_HEADER_IMPORT"] .. "|r")
    end

    -- 2) Summary line
    local seqCount = results.count or 0
    local varCount = results.varsImported or 0
    report(string.format(L["GEMS_REPORT_IMPORTED"], seqCount, varCount))

    local skipped = results.skipped or 0
    local varsSkipped = results.varsSkipped or 0
    if skipped > 0 then
        report(string.format(L["GEMS_REPORT_SKIPPED"], skipped))
    end
    if varsSkipped > 0 then
        report(string.format(L["GEMS_VAR_IMPORT_SKIPPED"], varsSkipped))
    end

    -- 3) Sequence list
    if results.names and #results.names > 0 then
        for _, name in ipairs(results.names) do
            local stepCount = results.stepCounts and results.stepCounts[name] or 0
            local stepFunc = results.stepFunctions and results.stepFunctions[name]
                or "Sequential"
            report(string.format(L["GEMS_REPORT_SEQ_ENTRY"], name, stepCount, stepFunc))
        end
    end

    -- 4) Known limitations (only print lines where count > 0)
    local versionsDropped = results.versionsDropped or 0
    local pausesSkipped = results.pausesSkipped or 0
    local embedsSkipped = results.embedsSkipped or 0
    local truncatedSteps = results.truncatedSteps or 0

    if versionsDropped > 0 or pausesSkipped > 0
        or embedsSkipped > 0 or truncatedSteps > 0 then
        report("|cFFFFFF00" .. L["GEMS_REPORT_LIMITATIONS"] .. "|r")
        if versionsDropped > 0 then
            report(string.format(L["GEMS_REPORT_VERSIONS_DROPPED"], versionsDropped))
        end
        if pausesSkipped > 0 then
            report(string.format(L["GEMS_REPORT_PAUSES_SKIPPED"], pausesSkipped))
        end
        if embedsSkipped > 0 then
            report(string.format(L["GEMS_REPORT_EMBEDS_SKIPPED"], embedsSkipped))
        end
        if truncatedSteps > 0 then
            report(string.format(L["GEMS_REPORT_TRUNCATED"], truncatedSteps))
        end
    end

    -- 5) Warnings (per-sequence detail)
    if results.warnings and #results.warnings > 0 then
        for _, w in ipairs(results.warnings) do
            report(string.format(L["GEMS_IMPORT_WARNING"], w))
        end
    end

    -- 6) Post-migration guidance (migrate only)
    if source == "migrate" then
        report("|cFF888888" .. L["GEMS_REPORT_TIP_VERIFY"] .. "|r")
        report("|cFF888888" .. L["GEMS_REPORT_TIP_VERSIONS"] .. "|r")
    end
end

--- Handle /gems testlocale: automated round-trip test of locale translation.
--- Translates spell names to IDs and back, reports pass/fail for each case.
local function HandleTestLocale()
    local SC = GRIPEMS.SpellCache
    if not SC then
        GRIPEMS:Print("|cFFFF4444SpellCache module not available.|r")
        return
    end

    if not SC.ready then
        GRIPEMS:Print("|cFFFFFF00Warning: Spell cache has not loaded yet."
            .. " Results may be incomplete.|r")
    end

    -- Auto-open debug window and clear it for clean test output
    local DW = GRIPEMS.DebugWindow
    if DW then
        DW:Show()
        DW:Clear()
    end
    -- Helper: output to both chat and debug window
    local function Out(msg)
        GRIPEMS:Print(msg)
        if DW then DW:AddMessage(msg) end
    end

    local tests = {
        { label = "Simple /cast",
          input = "/cast Kill Command" },
        { label = "/cast with ! prefix",
          input = "/cast !Barbed Shot" },
        { label = "/castsequence with reset",
          input = "/castsequence reset=target Barbed Shot, Cobra Shot,"
              .. " Kill Command" },
        { label = "/cast with conditional + fallback",
          input = "/cast [mod:alt] Bestial Wrath; Kill Command" },
        { label = "/cancelaura",
          input = "/cancelaura Aspect of the Cheetah" },
        { label = "Conditional on each fallback branch",
          input = "/cast [talent:1/1] Kill Shot; [talent:1/2] Cobra Shot" },
        { label = "Multi-line macrotext (passthrough test)",
          input = "/stopmacro [channeling]\n/cast Kill Command" },
        { label = "/use with item (passthrough)",
          input = "/use 13" },
        { label = "/castsequence with conditionals",
          input = "/castsequence [mod:shift] reset=combat Barbed Shot,"
              .. " Multi-Shot" },
    }

    local passed = 0
    local total = #tests

    Out("--- Locale Round-Trip Test ---")

    for i, t in ipairs(tests) do
        local idVersion = SC:TranslateMacrotext(t.input, "toIDs")
        local roundTripped = SC:TranslateMacrotext(idVersion, "toNames")

        -- Show intermediate ID-tagged version (grey)
        local idDisplay = idVersion:gsub("\n", "\\n")
        Out(string.format("  [%d] IDs: |cFF888888%s|r", i, idDisplay))

        if roundTripped == t.input then
            passed = passed + 1
            Out(string.format(
                "  [%d] |cFF00FF00PASS|r %s", i, t.label))
        else
            local origDisplay = t.input:gsub("\n", "\\n")
            local rtDisplay = roundTripped:gsub("\n", "\\n")
            Out(string.format(
                "  [%d] |cFFFF4444FAIL|r %s", i, t.label))
            Out(string.format(
                "       Original:     %s", origDisplay))
            Out(string.format(
                "       Round-tripped: %s", rtDisplay))
        end
    end

    Out(string.format("--- %d/%d tests passed ---", passed, total))
    if DW then
        Out("|cFF888888Use the Copy button in the Debug Window to copy results.|r")
    end
end

-- Slash command registration
SLASH_GRIPEMS1 = "/gems"
SLASH_GRIPEMS2 = "/gripems"
SlashCmdList["GRIPEMS"] = function(input)
    local cmd, arg = ParseSlashInput(input)

    if cmd == "" then
        -- Open main frame if UI is loaded, otherwise show help
        if GRIPEMS.UI and GRIPEMS_MainFrame then
            GRIPEMS.UI:ToggleMainFrame()
        else
            ShowHelp()
        end
    elseif cmd == "help" then
        ShowHelp()
    elseif cmd == "open" then
        if GRIPEMS.UI then
            GRIPEMS.UI:ToggleMainFrame()
        end
    elseif cmd == "create" then
        HandleCreate(arg)
    elseif cmd == "delete" then
        HandleDelete(arg)
    elseif cmd == "list" then
        HandleList()
    elseif cmd == "test" then
        HandleTest(arg)
    elseif cmd == "reset" then
        HandleReset(arg)
    elseif cmd == "debugwindow" or cmd == "dw" then
        if GRIPEMS.DebugWindow then
            GRIPEMS.DebugWindow:Toggle()
        end
    elseif cmd == "debug" then
        HandleDebug(arg)
    elseif cmd == "bind" then
        HandleBind(arg)
    elseif cmd == "unbind" then
        HandleUnbind(arg)
    elseif cmd == "binds" then
        HandleBinds()
    elseif cmd == "import" then
        HandleImport(arg)
    elseif cmd == "export" then
        HandleExport(arg)
    elseif cmd == "exportall" then
        GRIPEMS.ExportFrame:Show()
    elseif cmd == "migrate" then
        HandleMigrate()
    elseif cmd == "guide" or cmd == "tutorial" then
        GRIPEMS:Print(L["GEMS_GUIDE_CLICK"])
        GRIPEMS:Print("|cFF8899aa" .. L["GEMS_GUIDE_TIP"] .. "|r")
    elseif cmd == "send" then
        local seqName, target = arg:match("^(%S+)%s+(%S+)")
        if not seqName or not target then
            GRIPEMS:Print(L["GEMS_SEND_USAGE"])
        elseif GRIPEMS.Transmission then
            GRIPEMS.Transmission:SendSequence(seqName, target)
        end
    elseif cmd == "accept" then
        if GRIPEMS.Transmission then
            GRIPEMS.Transmission:AcceptPending()
        end
    elseif cmd == "settings" or cmd == "config" or cmd == "options" then
        if GRIPEMS.SettingsPanel then
            GRIPEMS.SettingsPanel:Open()
        end
    elseif cmd == "status" then
        HandleStatus()
    elseif cmd == "testlocale" then
        HandleTestLocale()
    else
        GRIPEMS:Print(string.format(L["GEMS_UNKNOWN_CMD"], cmd))
    end
end

--- Migrate existing sequences to include fields added in Phase 3A-2.
--- Called once at ADDON_LOADED after SavedVariables are initialized.
--- Fills in any missing schema fields with sensible defaults.
local function MigrateSequenceSchema()
    if not _G.GRIP_EMS_CHAR or not GRIP_EMS_CHAR.sequences then return end
    local playerClassID = select(3, UnitClass("player")) or 0
    for name, seqData in pairs(GRIP_EMS_CHAR.sequences) do
        if type(seqData) == "table" then
            -- Sequence-level metadata defaults
            seqData.name = seqData.name or name
            seqData.author = seqData.author or ""
            seqData.version = seqData.version or "1"
            seqData.description = seqData.description or ""
            seqData.classID = seqData.classID or playerClassID
            -- seqData.specID: leave nil if nil (means "all specs")
            seqData.createdAt = seqData.createdAt or time()
            seqData.updatedAt = seqData.updatedAt or time()
            -- Migrate flat format to versioned (T2-2a)
            GRIPEMS.Engine:MigrateSequenceFormat(seqData)
            -- Ensure contextOverrides exists (T2-1)
            seqData.contextOverrides = seqData.contextOverrides or {}
            GRIP_EMS_CHAR.sequences[name] = seqData
        end
    end
end

---------------------------------------------------------------------------
-- Guide URL popup (shown from /gems guide clickable link)
---------------------------------------------------------------------------
function GRIPEMS:ShowGuidePopup()
    if not self.guideFrame then
        local C = GRIPEMS.UI and GRIPEMS.UI.Colors
        local frame = CreateFrame("Frame", "GRIPEMSGuideFrame", UIParent, "BackdropTemplate")
        frame:SetSize(440, 150)
        frame:SetPoint("CENTER")
        frame:SetFrameStrata("DIALOG")
        frame:SetFrameLevel(200)

        -- Backdrop (match addon dark theme)
        if C then
            frame:SetBackdrop(GRIPEMS.UI.Backdrops.panel)
            frame:SetBackdropColor(C.bgDeep:GetRGBA())
            frame:SetBackdropBorderColor(C.border:GetRGBA())
        else
            frame:SetBackdrop({
                bgFile = "Interface/Tooltips/UI-Tooltip-Background",
                edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
                edgeSize = 16,
                insets = { left = 4, right = 4, top = 4, bottom = 4 },
            })
            frame:SetBackdropColor(0.08, 0.08, 0.16, 0.95)
            frame:SetBackdropBorderColor(0.3, 0.3, 0.5, 0.8)
        end

        -- Close button
        local closeBtn = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
        closeBtn:SetPoint("TOPRIGHT", -2, -2)

        -- Title
        local title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        title:SetPoint("TOP", 0, -14)
        title:SetTextColor(1, 0.96, 0.26)
        title:SetText(L["GEMS_GUIDE_TITLE"])

        -- Subtitle
        local subtitle = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        subtitle:SetPoint("TOP", title, "BOTTOM", 0, -6)
        subtitle:SetTextColor(0.53, 0.6, 0.67)
        subtitle:SetText(L["GEMS_GUIDE_PATH"])

        -- EditBox (read-only URL)
        local editBox = CreateFrame("EditBox", nil, frame, "InputBoxTemplate")
        editBox:SetSize(400, 22)
        editBox:SetPoint("TOP", subtitle, "BOTTOM", 0, -8)
        editBox:SetAutoFocus(false)
        editBox:SetText(L["GEMS_GUIDE_URL"])
        editBox:SetScript("OnEditFocusGained", function(self)
            self:HighlightText()
        end)
        editBox:SetScript("OnEscapePressed", function(self)
            self:ClearFocus()
        end)
        -- Keep read-only: reset text if user types
        local guideURL = L["GEMS_GUIDE_URL"]
        editBox:SetScript("OnChar", function(self)
            self:SetText(guideURL)
            self:HighlightText()
        end)
        editBox:SetScript("OnTextChanged", function(self, userInput)
            if userInput then
                self:SetText(guideURL)
                self:HighlightText()
            end
        end)

        -- Local path hint
        local hint = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        hint:SetPoint("TOP", editBox, "BOTTOM", 0, -6)
        hint:SetTextColor(0.53, 0.6, 0.67)
        hint:SetText(L["GEMS_GUIDE_TIP"])

        -- ESC-closeable
        tinsert(UISpecialFrames, "GRIPEMSGuideFrame")

        frame.editBox = editBox
        self.guideFrame = frame
    end

    self.guideFrame:Show()
    self.guideFrame.editBox:SetText(L["GEMS_GUIDE_URL"])
    self.guideFrame.editBox:HighlightText()
    self.guideFrame.editBox:SetFocus()
end

-- Event frame
local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("ADDON_LOADED")
eventFrame:RegisterEvent("PLAYER_LOGIN")

eventFrame:SetScript("OnEvent", function(self, event, ...)
    if event == "ADDON_LOADED" and ... == ADDON_NAME then
        -- Initialize SavedVariables
        _G.GRIP_EMS_DB = _G.GRIP_EMS_DB or {}
        _G.GRIP_EMS_CHAR = _G.GRIP_EMS_CHAR or {}
        GRIP_EMS_CHAR.config = GRIP_EMS_CHAR.config or {}
        GRIP_EMS_CHAR.sequences = GRIP_EMS_CHAR.sequences or {}
        GRIP_EMS_CHAR.keybinds = GRIP_EMS_CHAR.keybinds or {}

        -- UI state SavedVariables
        GRIP_EMS_CHAR.ui = GRIP_EMS_CHAR.ui or {}
        GRIP_EMS_CHAR.ui.mainFrame = GRIP_EMS_CHAR.ui.mainFrame or {}

        -- Account-wide variables store
        GRIP_EMS_DB.variables = GRIP_EMS_DB.variables or {}

        -- Account-wide UI settings
        GRIP_EMS_DB.config = GRIP_EMS_DB.config or {}

        -- Initialize CallbackHandler message bus (before Settings so
        -- GRIPEMS:Fire() is available during initialization)
        LibStub("CallbackHandler-1.0"):New(GRIPEMS)

        -- Initialize settings (AceDB profile system)
        if GRIPEMS.Settings then
            GRIPEMS.Settings:Initialize()
        end

        -- Migrate sequence schema (add fields missing from older saves)
        MigrateSequenceSchema()

        GRIPEMS.state.initialized = true
        GRIPEMS:Debug("SavedVariables initialized.")

        -- Initialize minimap button (LibDBIcon)
        if GRIPEMS.UI and GRIPEMS.UI.InitMinimapButton then
            GRIPEMS.UI:InitMinimapButton()
        end

        -- Hook SetItemRef for clickable guide hyperlink
        local origSetItemRef = SetItemRef
        function SetItemRef(link, text, button, chatFrame)
            if link == "GRIPEMSguide" then
                GRIPEMS:ShowGuidePopup()
                return
            end
            return origSetItemRef(link, text, button, chatFrame)
        end

        -- Wago Analytics (optional, pcall-wrapped)
        pcall(function()
            LibStub("WagoAnalytics"):Register(ADDON_NAME)
        end)

    elseif event == "PLAYER_LOGIN" then
        local S = GRIPEMS.Settings
        if not (S and S:Get("hideLoginMsg")) then
            GRIPEMS:Print(string.format(L["GEMS_VERSION"], GRIPEMS.version))
            local activeCount = GRIPEMS.Engine and GRIPEMS.Engine:GetActiveCount() or 0
            if activeCount > 0 then
                GRIPEMS:Print(string.format(L["GEMS_LOGIN_ACTIVE"], activeCount))
            end
        end

        -- Initialize VariableStore (after SavedVariables, before UI)
        if GRIPEMS.VariableStore then
            GRIPEMS.VariableStore:Initialize()
        end

        -- Initialize settings panel (Blizzard Settings registration)
        if GRIPEMS.SettingsPanel then
            GRIPEMS.SettingsPanel:Initialize()
        end

        -- Restore main frame position/size from SavedVariables
        if GRIPEMS.UI and GRIPEMS.UI.RestoreMainFramePosition then
            GRIPEMS.UI:RestoreMainFramePosition()
        end

        -- Initialize list and editor panels (after SV init and position restore)
        if GRIPEMS.UI and GRIPEMS.UI.InitPanels then
            GRIPEMS.UI:InitPanels()
        end

        -- Initialize P2P transmission (after all modules, needs AceComm)
        if GRIPEMS.Transmission then
            GRIPEMS.Transmission:Initialize()
        end

        self:UnregisterEvent("ADDON_LOADED")
    end
end)
