-- GRIP-EMS: Theme dispatcher (Phase A foundation, Phase C contrast)
--
-- Created:    2026-04-22
-- Updated:    2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.
--
-- Implements the per-element theming dispatch layer described in
-- ThemingEditor_Design_2026-04-22.md sections 4-5 and the Phase C
-- contrast-check layer (section 10). Exports ApplyElement / ApplyTheme
-- / ApplyPreset / ValidateSpec / ResolveClassSpec / RequestApply (Phase
-- A) plus CheckContrast / CheckAndWarn (Phase C). Chat-link transport
-- remains Phase D.
--
-- Phase A invariant: a profile with profile.theming.elements = {} (empty)
-- renders pixel-identical to pre-v2.0.0 B.3. This module enforces that by
-- only invoking APPLY_FN for classes that carry an explicit user override;
-- default-only classes fall back to the v1.9.9 render path unchanged.
--
-- ColorMixin identity preservation (design 4.3): UI._cachedColors[class].bg
-- and similar refs are mutated in place via ColorMixin:SetRGBA so widget
-- references survive palette changes.
--
-- Loaded AFTER Data/Theme.lua and BEFORE Core/Core.lua via GRIP-EMS.toc.

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

GRIPEMS.UI = GRIPEMS.UI or {}
local UI = GRIPEMS.UI

UI._elementClasses = UI._elementClasses or {}
UI._classWidgets = UI._classWidgets or {}
UI._cachedColors = UI._cachedColors or {}

local Theme = {}
GRIPEMS.Theme = Theme

-- Dirty-set coalescer. RequestApply(class) marks _dirty[class] and schedules
-- one C_Timer.After(0, Flush) per frame. Multiple edits to the same class in
-- one frame only trigger one applyFn fan-out (design section 5.3).
Theme._dirty = {}
Theme._flushScheduled = false

---------------------------------------------------------------------------
-- Internal helpers
---------------------------------------------------------------------------

-- Return the group prefix of a class name, e.g. "panel" for "panel.main",
-- "overlay" for "overlay.toast.info", "global" for "global.addonFont".
local function groupOf(class)
    if type(class) ~= "string" then
        return nil
    end
    local dot = class:find("%.")
    if not dot then
        return class
    end
    return class:sub(1, dot - 1)
end

-- Resolve the live B.3 multipliers. Missing Util globals fall back to 1.0
-- so Theme.ApplyTheme stays callable before UI:ApplyLiveAlphas initializes.
local function b3Multipliers()
    return {
        panelAlpha = (UI.GetPanelAlpha and UI:GetPanelAlpha()) or 1.0,
        overlayAlpha = (UI.GetOverlayAlpha and UI:GetOverlayAlpha()) or 1.0,
        bgOpacity = (UI.GetBgOpacity and UI:GetBgOpacity()) or 1.0,
        borderOpacity = (UI.GetBorderOpacity and UI:GetBorderOpacity()) or 1.0,
        uiScale = (UI.GetUIScale and UI:GetUIScale()) or 1.0,
    }
end

-- Fetch the user override for `class` from AceDB, or nil if not present.
local function profileOverride(class)
    local S = GRIPEMS.Settings
    if not (S and S.db and S.db.profile and S.db.profile.theming) then
        return nil
    end
    local elements = S.db.profile.theming.elements
    if type(elements) ~= "table" then
        return nil
    end
    return elements[class]
end

---------------------------------------------------------------------------
-- Public API
---------------------------------------------------------------------------

--- Resolve a class to its effective spec: profile override merged on top of
--- UI.DEFAULT_THEME[class]. Never mutates profile data; returns a transient
--- spec table the caller may read but must not store.
--- @param class string One of UI.ELEMENT_CLASSES
--- @return table|nil spec Merged spec, or nil if class is unknown
function Theme.ResolveClassSpec(class)
    local def = UI.DEFAULT_THEME and UI.DEFAULT_THEME[class]
    if not def then
        return nil
    end
    local override = profileOverride(class)
    if not override then
        return def
    end
    local resolved = {}
    for k, v in pairs(def) do
        resolved[k] = v
    end
    for k, v in pairs(override) do
        resolved[k] = v
    end
    return resolved
end

--- Validate a theme spec for schema, whitelist, and range compliance.
--- Used on import (design section 7.3) and on every set/save path to reject
--- malformed input before it reaches saved variables.
--- @param spec table Candidate {version, elements = {[class] = {...}, ...}}
--- @return boolean ok
--- @return string|nil errMessage Human-readable failure reason, localized later
function Theme.ValidateSpec(spec)
    if type(spec) ~= "table" then
        return false, "spec must be a table"
    end
    if spec.version ~= nil and spec.version ~= 1 then
        return false, "unsupported spec.version"
    end
    local elements = spec.elements
    if elements == nil then
        return true
    end
    if type(elements) ~= "table" then
        return false, "elements must be a table"
    end
    local whitelist = UI.ELEMENT_CLASS_SET or {}
    for class, entry in pairs(elements) do
        if not whitelist[class] then
            return false, "unknown class: " .. tostring(class)
        end
        if type(entry) ~= "table" then
            return false, "entry for " .. class .. " must be a table"
        end
        for _, key in ipairs({ "bg", "border", "text", "color" }) do
            local c = entry[key]
            if c ~= nil then
                if type(c) ~= "table" or #c < 3 or #c > 4 then
                    return false, class .. "." .. key .. " must be {r,g,b[,a]}"
                end
                for i = 1, 4 do
                    if c[i] ~= nil and (type(c[i]) ~= "number" or c[i] < 0 or c[i] > 1) then
                        return false, class .. "." .. key .. "[" .. i .. "] out of [0,1]"
                    end
                end
            end
        end
        if entry.alpha ~= nil then
            if type(entry.alpha) ~= "number" or entry.alpha < 0 or entry.alpha > 1 then
                return false, class .. ".alpha out of [0,1]"
            end
        end
        if entry.fontSize ~= nil then
            if type(entry.fontSize) ~= "number" or entry.fontSize < 8 or entry.fontSize > 32 then
                return false, class .. ".fontSize out of [8,32]"
            end
        end
        if entry.bgTexture ~= nil then
            if type(entry.bgTexture) ~= "string" then
                return false, class .. ".bgTexture must be a string"
            end
            if class:sub(1, 6) ~= "panel." then
                return false, class .. ".bgTexture only allowed on panel.* classes"
            end
        end
        if entry.borderTexture ~= nil then
            if type(entry.borderTexture) ~= "string" then
                return false, class .. ".borderTexture must be a string"
            end
            if class:sub(1, 6) ~= "panel." then
                return false, class .. ".borderTexture only allowed on panel.* classes"
            end
        end
    end
    return true
end

--- Ensure UI._cachedColors[class] has ColorMixin refs. Mutates in place on
--- repeat calls so widget references survive (design section 4.3).
--- @param class string
--- @param spec table Resolved spec from ResolveClassSpec
local function seedCachedColors(class, spec)
    local cache = UI._cachedColors[class]
    if not cache then
        cache = {}
        UI._cachedColors[class] = cache
    end
    local fields = { "bg", "border", "text", "color" }
    for i = 1, #fields do
        local key = fields[i]
        local c = spec[key]
        if type(c) == "table" then
            if cache[key] then
                if cache[key].SetRGBA then
                    cache[key]:SetRGBA(c[1] or 0, c[2] or 0, c[3] or 0, c[4] == nil and 1 or c[4])
                end
            elseif CreateColor then
                cache[key] = CreateColor(c[1] or 0, c[2] or 0, c[3] or 0, c[4] == nil and 1 or c[4])
            end
        end
    end
end

--- Apply one class. Resolves spec, refreshes the cached ColorMixin, and
--- fans out to every widget in UI._classWidgets[class] via the group
--- applyFn. In Phase A this is a no-op for classes with no override so
--- existing B.3 rendering stays pixel-identical.
--- @param class string
function Theme.ApplyElement(class)
    if not (UI.ELEMENT_CLASS_SET and UI.ELEMENT_CLASS_SET[class]) then
        return
    end
    local spec = Theme.ResolveClassSpec(class)
    if not spec then
        return
    end
    seedCachedColors(class, spec)
    local override = profileOverride(class)
    if not override then
        -- Phase A invariant preserved for most classes. Exception: when a
        -- panel.* class has a widget flagged _emsTexturedState, fall through
        -- to the fan-out so applyPanel's restore branch can revert the
        -- snapshot captured at UI:RegisterElement time. See backlog entry
        -- A11Y-THEME-TEXTURE-RESET-NOREVERT.
        local group = groupOf(class)
        if group ~= "panel" then
            return
        end
        local widgets = UI._classWidgets[class]
        if type(widgets) ~= "table" then
            return
        end
        local needsRestore = false
        for i = 1, #widgets do
            local w = widgets[i]
            if w and w._emsTexturedState then
                needsRestore = true
                break
            end
        end
        if not needsRestore then
            return
        end
    end
    local group = groupOf(class)
    local fn = UI.APPLY_FN and UI.APPLY_FN[group]
    if not fn then
        return
    end
    local mult = b3Multipliers()
    local hasSpecTextures = spec.bgTexture or spec.borderTexture
    local widgets = UI._classWidgets[class]
    if not widgets then
        return
    end
    for i = 1, #widgets do
        local w = widgets[i]
        if w then
            -- Default render path with no spec textures and a widget that was
            -- never textured produces a no-op apply -- skip it. Closes
            -- A11Y-THEME-APPLYELEMENT-WIDENED-GATE-FANOUT perf gap on Reset
            -- and ApplyPreset("default").
            if override ~= nil or hasSpecTextures or w._emsTexturedState then
                pcall(fn, w, spec, mult)
            end
        end
    end
    -- Phase C: contrast check is fire-and-forget. Wrapped in pcall so any
    -- failure in CheckAndWarn cannot break the theme-apply pipeline and
    -- violate pixel-identity invariants on default-only classes.
    if UI.ThemingEditor and UI.ThemingEditor.ShowContrastWarning and Theme.CheckAndWarn then
        pcall(Theme.CheckAndWarn, class)
    end
end

--- Full re-apply. Walks every class in UI.ELEMENT_CLASSES and invokes
--- ApplyElement. Called on preset swap, slot load, B.3 global change,
--- profile switch, and reloadui (design section 5.4).
function Theme.ApplyTheme()
    local classes = UI.ELEMENT_CLASSES
    if not classes then
        return
    end
    for i = 1, #classes do
        Theme.ApplyElement(classes[i])
    end
end

--- Coalesced flush. Applies each class that has been marked dirty since
--- the last frame, then clears the set. Slider drag callbacks should call
--- RequestApply rather than ApplyElement directly (design section 13.3).
function Theme.Flush()
    Theme._flushScheduled = false
    local dirty = Theme._dirty
    Theme._dirty = {}
    for class in pairs(dirty) do
        Theme.ApplyElement(class)
    end
end

--- Mark a class dirty and schedule a deferred Flush. Idempotent within one
--- frame -- a single C_Timer.After(0) is scheduled regardless of call count.
--- @param class string
function Theme.RequestApply(class)
    if not (UI.ELEMENT_CLASS_SET and UI.ELEMENT_CLASS_SET[class]) then
        return
    end
    Theme._dirty[class] = true
    if Theme._flushScheduled then
        return
    end
    Theme._flushScheduled = true
    if C_Timer and C_Timer.After then
        C_Timer.After(0, function()
            Theme.Flush()
        end)
    else
        -- Fallback: apply immediately if the timer API is unavailable.
        Theme.Flush()
    end
end

--- Apply a named preset. Phase A supports only "default" (clear overrides,
--- re-apply). Phase B widens the preset table.
--- @param name string Preset key
function Theme.ApplyPreset(name)
    local S = GRIPEMS.Settings
    if not (S and S.db and S.db.profile) then
        return
    end
    S.db.profile.theming = S.db.profile.theming or { preset = "default", elements = {}, savedThemes = {} }
    S.db.profile.theming.preset = name or "default"
    -- "default" clears all overrides so every class resolves back to UI.DEFAULT_THEME.
    if name == nil or name == "default" then
        S.db.profile.theming.elements = {}
    end
    Theme.ApplyTheme()
end

---------------------------------------------------------------------------
-- Phase C: WCAG 2.2 contrast checking
---------------------------------------------------------------------------

-- sRGB companding inverse: gamma-decode an 8-bit-normalized channel.
local function srgbToLinear(c)
    if type(c) ~= "number" then
        return 0
    end
    if c <= 0.03928 then
        return c / 12.92
    end
    return ((c + 0.055) / 1.055) ^ 2.4
end

-- Premultiply a single channel onto mid-gray (0.5) by the given alpha.
local function premultiplyOnGray(ch, alpha)
    ch = ch or 0
    alpha = (alpha == nil) and 1 or alpha
    return ch * alpha + 0.5 * (1 - alpha)
end

-- Relative luminance of an {r,g,b[,a]} color composed onto mid-gray.
local function luminance(color, alpha)
    if type(color) ~= "table" then
        return 0
    end
    local a = alpha
    if a == nil then
        a = (color[4] == nil) and 1 or color[4]
    end
    local r = premultiplyOnGray(color[1] or 0, a)
    local g = premultiplyOnGray(color[2] or 0, a)
    local b = premultiplyOnGray(color[3] or 0, a)
    return 0.2126 * srgbToLinear(r) + 0.7152 * srgbToLinear(g) + 0.0722 * srgbToLinear(b)
end

-- WCAG contrast ratio between two colors (each optionally with alpha).
local function contrastRatio(c1, a1, c2, a2)
    local L1 = luminance(c1, a1)
    local L2 = luminance(c2, a2)
    local lighter = (L1 > L2) and L1 or L2
    local darker = (L1 > L2) and L2 or L1
    return (lighter + 0.05) / (darker + 0.05)
end

-- Bisection: shift the background toward black or white (whichever
-- direction increases contrast against the given text color) and return
-- the minimal-change {r,g,b,a} that meets the threshold. 12 iterations
-- upper bound; early-exits as soon as the ratio clears threshold.
local function proposeFix(textColor, textAlpha, bgColor, bgAlpha, threshold)
    if type(textColor) ~= "table" or type(bgColor) ~= "table" then
        return nil
    end
    local Lt = luminance(textColor, textAlpha)
    -- Direction: if text is dark (low luminance) push bg toward white,
    -- else push toward black. Whichever extreme is further from Lt.
    local target = (Lt < 0.5) and 1 or 0
    local bgA = (bgAlpha == nil) and ((bgColor[4] == nil) and 1 or bgColor[4]) or bgAlpha
    local startR, startG, startB = bgColor[1] or 0, bgColor[2] or 0, bgColor[3] or 0

    local function mix(t)
        return {
            startR + (target - startR) * t,
            startG + (target - startG) * t,
            startB + (target - startB) * t,
            bgA,
        }
    end

    -- Binary search for the smallest t in [0,1] such that the ratio
    -- meets threshold. low = not-yet-enough, high = already-enough.
    local low, high = 0, 1
    local last = mix(1)
    if contrastRatio(textColor, textAlpha, last, bgA) < threshold then
        -- Even pushing all the way to the extreme doesn't reach threshold.
        -- Return the extreme anyway -- it's the best we can do.
        return last
    end
    for _ = 1, 12 do
        local mid = (low + high) * 0.5
        local cand = mix(mid)
        local r = contrastRatio(textColor, textAlpha, cand, bgA)
        if r >= threshold then
            high = mid
            last = cand
        else
            low = mid
        end
        if (high - low) < 0.01 then
            break
        end
    end
    return last
end

-- Field resolver helpers for class-type dispatch.
local function specOf(class)
    return Theme.ResolveClassSpec(class)
end

local function panelMainBg()
    local s = specOf("panel.main")
    if s and type(s.bg) == "table" then
        return s.bg
    end
    return { 0, 0, 0, 1 }
end

local function textFieldName(spec, group)
    if group == "text" and type(spec.color) == "table" then
        return "color"
    end
    if (group == "overlay" or group == "button" or group == "emphasis") and type(spec.text) == "table" then
        return "text"
    end
    return nil
end

-- Class-to-panel mapping for text.* contrast checks. text.body is the
-- most-common SequenceEditor body text; text.log is the DebugWindow
-- ScrollingMessageFrame; text.heading and text.muted default to
-- panel.main since they appear panel-agnostic. See backlog entry
-- A11Y-THEME-CONTRAST-NON-MAIN-PANEL-BLOCKER.
local TEXT_CLASS_PANEL = {
    ["text.body"] = "panel.sequenceEditor",
    ["text.heading"] = "panel.main",
    ["text.muted"] = "panel.main",
    ["text.log"] = "panel.logs",
}

local function panelForTextClass(class)
    return TEXT_CLASS_PANEL[class] or "panel.main"
end

-- Detect whether the effective background surface for `class` comes
-- from a spec with a non-nil bgTexture. When an LSM texture is
-- installed the rendered luminance is dominated by the texture and
-- the color-only math in CheckContrast cannot produce a valid
-- verdict. Decorative borderTextures (1-2 px edges) do not materially
-- affect WCAG verdicts and are not blockers; only background textures
-- dominate luminance. Returns the blocker class name (used in the
-- advisory message) or nil when the background is pure color. See
-- backlog entries A11Y-THEME-TEXTURE-CONTRAST and
-- A11Y-THEME-CONTRAST-BORDERTEXTURE-OVERBLOCKS.
local function textureBlockerClass(class)
    local group = groupOf(class)
    if group == "text" then
        local panelClass = panelForTextClass(class)
        local ps = specOf(panelClass)
        if ps and ps.bgTexture then
            return panelClass
        end
        return nil
    end
    if class == "emphasis.focusRing" or class == "row.default" then
        local ps = specOf("panel.main")
        if ps and ps.bgTexture then
            return "panel.main"
        end
        return nil
    end
    if group == "row" then
        local rs = specOf("row.default")
        if rs and rs.bgTexture then
            return "row.default"
        end
        return nil
    end
    local s = specOf(class)
    if s and s.bgTexture then
        return class
    end
    return nil
end

--- Contrast check. Computes WCAG 2.2 relative-luminance ratio for the
--- given class against the appropriate backing surface and returns the
--- pass/fail verdict plus a minimal-change proposed fix if the ratio
--- falls below threshold.
---
--- @param class string One of UI.ELEMENT_CLASSES
--- @return boolean ok           Threshold met (or no check applies)
--- @return number|nil ratio     Computed ratio, or nil when no check runs
--- @return string|nil warnKind  "text_aa" | "text_aa_large" | "nontext_ui" | "low_alpha" | "texture_unknown" | "translucent_skip" | nil
--- @return table|nil proposedFix {r,g,b,a} bg shift to reach threshold, or nil
--- @return table|nil fixTarget {class, field} pair indicating which
---                             AceDB slot the auto-fix color should be written to
function Theme.CheckContrast(class)
    if not (UI.ELEMENT_CLASS_SET and UI.ELEMENT_CLASS_SET[class]) then
        return true, nil, nil, nil, nil
    end
    local spec = specOf(class)
    if not spec then
        return true, nil, nil, nil, nil
    end
    local blocker = textureBlockerClass(class)
    if blocker then
        return true, nil, "texture_unknown", nil, { class = blocker }
    end
    local group = groupOf(class)

    -- Case 1: text.*  (fg = spec.color, bg = panelForTextClass(class))
    if group == "text" then
        if type(spec.color) ~= "table" then
            return true, nil, nil, nil, nil
        end
        local txt = spec.color
        local ta = (txt[4] == nil) and 1 or txt[4]
        if ta < 0.3 then
            return false, ta, "low_alpha", nil, nil
        end
        local panelClass = panelForTextClass(class)
        local panelSpec = specOf(panelClass)
        local bg = (panelSpec and type(panelSpec.bg) == "table") and panelSpec.bg or { 0, 0, 0, 1 }
        local ba = (bg[4] == nil) and 1 or bg[4]
        local size = spec.fontSize or 12
        local threshold = (size >= 18) and 3.0 or 4.5
        local kind = (size >= 18) and "text_aa_large" or "text_aa"
        local r = contrastRatio(txt, ta, bg, ba)
        if r >= threshold then
            return true, r, nil, nil, nil
        end
        local fix = proposeFix(txt, ta, bg, ba, threshold)
        return false, r, kind, fix, { class = panelClass, field = "bg" }
    end

    -- Case 2: emphasis.focusRing (ring vs panel.main, 3:1)
    if class == "emphasis.focusRing" then
        local ring = spec.bg or spec.color or spec.border
        if type(ring) ~= "table" then
            return true, nil, nil, nil, nil
        end
        local ra = (ring[4] == nil) and 1 or ring[4]
        if ra < 0.3 then
            return false, ra, "low_alpha", nil, nil
        end
        local bg = panelMainBg()
        local ba = (bg[4] == nil) and 1 or bg[4]
        local threshold = 3.0
        local r = contrastRatio(ring, ra, bg, ba)
        if r >= threshold then
            return true, r, nil, nil, nil
        end
        local fix = proposeFix(ring, ra, bg, ba, threshold)
        return false, r, "nontext_ui", fix, { class = class, field = "bg" }
    end

    -- Case 3: row.*  (compare this row's bg to row.default.bg)
    if group == "row" then
        if type(spec.bg) ~= "table" then
            return true, nil, nil, nil, nil
        end
        local rb = spec.bg
        local ra = (rb[4] == nil) and 1 or rb[4]
        if ra < 0.3 then
            return false, ra, "low_alpha", nil, nil
        end
        local sibling = (class == "row.default") and panelMainBg()
            or (specOf("row.default") and specOf("row.default").bg)
        if type(sibling) ~= "table" then
            return true, nil, nil, nil, nil
        end
        local sa = (sibling[4] == nil) and 1 or sibling[4]
        local threshold = 3.0
        local r = contrastRatio(rb, ra, sibling, sa)
        if r >= threshold then
            return true, r, nil, nil, nil
        end
        local fix = proposeFix(sibling, sa, rb, ra, threshold)
        return false, r, "nontext_ui", fix, { class = class, field = "bg" }
    end

    -- Case 4: overlay / button / emphasis with text field -> text vs own bg
    local tf = textFieldName(spec, group)
    if tf then
        local txt = spec[tf]
        local ta = (txt[4] == nil) and 1 or txt[4]
        if ta < 0.3 then
            return false, ta, "low_alpha", nil, nil
        end
        local bg = spec.bg or panelMainBg()
        local ba = (bg[4] == nil) and 1 or bg[4]
        local size = spec.fontSize or 12
        local threshold = (size >= 18) and 3.0 or 4.5
        local kind = (size >= 18) and "text_aa_large" or "text_aa"
        local r = contrastRatio(txt, ta, bg, ba)
        if r >= threshold then
            return true, r, nil, nil, nil
        end
        local fix = proposeFix(txt, ta, bg, ba, threshold)
        return false, r, kind, fix, { class = class, field = "bg" }
    end

    -- Case 5: default (borders on everything else) -> border vs own bg
    if type(spec.border) == "table" and type(spec.bg) == "table" then
        local brd = spec.border
        local ba_brd = (brd[4] == nil) and 1 or brd[4]
        if ba_brd < 0.3 then
            return false, ba_brd, "low_alpha", nil, nil
        end
        local bg = spec.bg
        local ba = (bg[4] == nil) and 1 or bg[4]
        -- Translucent panel: the bg composites over the live game world (an unknown
        -- surface), so border-vs-bg contrast is indeterminate. Skip the check rather
        -- than emit an unwinnable warning -- mirrors the textured-bg bail above.
        if ba < 1 then
            return true, nil, "translucent_skip", nil, nil
        end
        local threshold = 3.0
        local r = contrastRatio(brd, ba_brd, bg, ba)
        if r >= threshold then
            return true, r, nil, nil, nil
        end
        local fix = proposeFix(brd, ba_brd, bg, ba, threshold)
        return false, r, "nontext_ui", fix, { class = class, field = "bg" }
    end

    return true, nil, nil, nil, nil
end

-- Build a localized warning message for the toast. Kept internal so the
-- toast module stays oblivious to threshold constants.
local function buildWarnMessage(class, warnKind, ratio)
    local TE = UI.ThemingEditor
    local label = (TE and TE.FormatClassLabel and TE.FormatClassLabel(class)) or class
    if warnKind == "low_alpha" then
        local fmt = L["ACCESS_THEMING_CONTRAST_LOW_ALPHA"] or "Low alpha: %s is %.2f"
        return string.format(fmt, label, ratio or 0)
    elseif warnKind == "text_aa" then
        local fmt = L["ACCESS_THEMING_CONTRAST_WARN_TEXT"] or "Text %s on %s is %.1f:1 (AA requires %.1f:1)."
        return string.format(fmt, label, "panel", ratio or 0, 4.5)
    elseif warnKind == "text_aa_large" then
        local fmt = L["ACCESS_THEMING_CONTRAST_WARN_TEXT"] or "Text %s on %s is %.1f:1 (AA requires %.1f:1)."
        return string.format(fmt, label, "panel", ratio or 0, 3.0)
    else
        local fmt = L["ACCESS_THEMING_CONTRAST_WARN_UI"] or "UI %s against %s is %.1f:1 (3:1 required)."
        return string.format(fmt, label, "bg", ratio or 0)
    end
end

Theme._lastBlocker = Theme._lastBlocker or {}

--- CheckAndWarn is the toast-wiring wrapper around CheckContrast. Keeps
--- CheckContrast pure (testable) and the UI coupling isolated to this
--- function. Fire-and-forget: never errors the theme-apply pipeline.
---
--- Per-class state in Theme._lastBlocker dedupes the texture-unknown
--- advisory: when the same class repeatedly reports the same blocker
--- across consecutive ApplyTheme passes, only the first emits a toast.
--- Transitions (blocker changes or a blocker is cleared) reset silence
--- so new verdicts get a fresh chance to surface.
--- @param class string
function Theme.CheckAndWarn(class)
    local TE = UI.ThemingEditor
    if not TE then
        return
    end
    local ok, ratio, warnKind, proposedFix, fixTarget = Theme.CheckContrast(class)

    if warnKind == "texture_unknown" then
        local blocker = (type(fixTarget) == "table" and fixTarget.class) or nil
        if Theme._lastBlocker[class] == blocker then
            return
        end
        Theme._lastBlocker[class] = blocker
        if TE.ClearContrastSilence then
            TE.ClearContrastSilence(class)
        end
        if TE.ShowContrastWarning then
            local fmt = L["ACCESS_THEMING_CONTRAST_TEXTURE_UNKNOWN"]
                or "Contrast check disabled for %s -- %s uses a custom background texture."
            local label = (TE.FormatClassLabel and TE.FormatClassLabel(class)) or class
            local blockerLabel = (TE.FormatClassLabel and blocker and TE.FormatClassLabel(blocker)) or blocker or "?"
            TE.ShowContrastWarning(class, string.format(fmt, label, blockerLabel), nil, nil)
        end
        return
    end

    if Theme._lastBlocker[class] ~= nil then
        Theme._lastBlocker[class] = nil
        if TE.ClearContrastSilence then
            TE.ClearContrastSilence(class)
        end
    end

    if ok then
        if TE.ClearContrastSilence then
            TE.ClearContrastSilence(class)
        end
        return
    end

    if TE.ShowContrastWarning then
        local msg = buildWarnMessage(class, warnKind, ratio)
        TE.ShowContrastWarning(class, msg, proposedFix, fixTarget)
    end
end

---------------------------------------------------------------------------
-- AceGUI acquire/release helper. Pooled widget objects reuse
-- _emsElementClass from a prior role, which would paint them with the wrong
-- class on the next acquire. Call ClassifyAcquired at every AceGUI:Create /
-- Acquire site (design section 18.1). In Phase A the hot callers are
-- Import/ImportFrame.lua and Import/ExportFrame.lua; other UI files rely on
-- CreateFrame which does not pool.
---------------------------------------------------------------------------
function Theme.ClassifyAcquired(frame, class)
    if not frame then
        return
    end
    if UI.RegisterElement then
        UI:RegisterElement(frame, class)
    end
end

-- end of Core/Theme.lua
