-- GRIP-EMS: Tracker HUD
-- Movable overlay showing active sequence icons with step advancement feedback

local ADDON_NAME, GRIPEMS = ...

GRIPEMS.TrackerHUD = {}
local TH = GRIPEMS.TrackerHUD
local UI = GRIPEMS.UI
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS")

-- Upvalue accessors (modules load before UI/)
local function S()
    return GRIPEMS.Settings
end
local function Engine()
    return GRIPEMS.Engine
end
local function SC()
    return GRIPEMS.SpellCache
end

---------------------------------------------------------------------------
-- Constants
---------------------------------------------------------------------------
local QUESTION_MARK_ICON = 134400 -- Interface\Icons\INV_Misc_QuestionMark
local ICON_PADDING = 4
local NAME_HEIGHT = 12
local STEP_FONT_SIZE = 10
local NAME_FONT_SIZE = 9
local FRAME_PADDING = 6
local DEFAULT_POS = { "BOTTOMRIGHT", nil, "BOTTOMRIGHT", -200, 200 }

---------------------------------------------------------------------------
-- Restriction state label
---------------------------------------------------------------------------
local function GetRestrictionLabel()
    local r = GRIPEMS.restrictions
    if not r then
        return nil
    end
    if r[2] == 2 then
        return "M+"
    end
    if r[1] == 2 then
        return "Encounter"
    end
    if r[3] == 2 then
        return "PvP"
    end
    return nil
end

---------------------------------------------------------------------------
-- Visibility evaluator
---------------------------------------------------------------------------
local function ShouldBeVisible()
    local mode = S():Get("trackerShowMode") or "NEVER"
    if mode == "ALWAYS" then
        return true
    end
    if mode == "NEVER" then
        return false
    end
    if mode == "COMBAT" then
        return InCombatLockdown()
    end
    if mode == "TARGET" then
        return UnitExists("target")
    end
    return false
end

---------------------------------------------------------------------------
-- Frame creation (lazy, called once from Init)
---------------------------------------------------------------------------
local function CreateHUDFrame()
    local C = UI.Colors

    local frame = UI:ReclaimFrame("GRIPEMS_TrackerHUD", "Frame", UIParent, "BackdropTemplate")
    frame:SetSize(60, 60)
    frame:SetFrameStrata("MEDIUM")
    frame:SetFrameLevel(100)
    frame:SetBackdrop(UI.Backdrops.panel)
    frame:SetBackdropColor(0.12, 0.12, 0.14, 0.85)
    frame:SetBackdropBorderColor(0.3, 0.3, 0.35, 1)
    frame:SetClampedToScreen(true)
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", function(self)
        if not S():Get("trackerLocked") then
            self:StartMoving()
        end
    end)
    frame:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        TH:SavePosition()
    end)
    frame:Hide()

    -- Modifier key overlay text (top-left corner)
    local modText = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(modText, 9, "OUTLINE")
    modText:SetPoint("BOTTOMLEFT", frame, "TOPLEFT", 4, 12)
    modText:SetTextColor(C.keybindGold:GetRGBA())
    modText:SetText("")
    frame.modText = modText

    -- Restriction state overlay text (top-right corner)
    local restrictText = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(restrictText, 9, "OUTLINE")
    restrictText:SetPoint("BOTTOMRIGHT", frame, "TOPRIGHT", -4, 12)
    restrictText:SetTextColor(0.95, 0.65, 0.15, 1) -- amber/orange
    restrictText:SetText("")
    restrictText:Hide()
    frame.restrictText = restrictText

    return frame
end

---------------------------------------------------------------------------
-- Position save / restore
---------------------------------------------------------------------------
function TH:SavePosition()
    if not TH.frame then
        return
    end
    local point, _, relPoint, x, y = TH.frame:GetPoint(1)
    if not _G.GRIP_EMS_CHAR then
        return
    end
    GRIP_EMS_CHAR.trackerPos = { point, "UIParent", relPoint, x, y }
end

function TH:RestorePosition()
    if not TH.frame then
        return
    end
    local pos = _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.trackerPos
    if pos and pos[1] then
        TH.frame:ClearAllPoints()
        TH.frame:SetPoint(pos[1], UIParent, pos[3], pos[4], pos[5])
    else
        TH.frame:ClearAllPoints()
        TH.frame:SetPoint(DEFAULT_POS[1], UIParent, DEFAULT_POS[3], DEFAULT_POS[4], DEFAULT_POS[5])
    end
end

---------------------------------------------------------------------------
-- Icon entry creation
---------------------------------------------------------------------------
local function CreateIconEntry(parent, index)
    local C = UI.Colors
    local iconSize = S():Get("trackerIconSize") or 40

    local iconFrame = CreateFrame("Frame", nil, parent, "BackdropTemplate")
    iconFrame:SetSize(iconSize, iconSize)
    iconFrame:SetBackdrop(UI.Backdrops.panel)
    iconFrame:SetBackdropColor(0.08, 0.08, 0.10, 0.9)
    iconFrame:SetBackdropBorderColor(0.3, 0.3, 0.35, 1)

    -- Spell icon texture
    local tex = iconFrame:CreateTexture(nil, "ARTWORK")
    tex:SetPoint("TOPLEFT", 1, -1)
    tex:SetPoint("BOTTOMRIGHT", -1, 1)
    tex:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    tex:SetTexture(QUESTION_MARK_ICON)

    -- Step counter (bottom-right corner overlay)
    local stepText = iconFrame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(stepText, STEP_FONT_SIZE, "OUTLINE")
    stepText:SetPoint("BOTTOMRIGHT", iconFrame, "BOTTOMRIGHT", -2, 2)
    stepText:SetTextColor(C.textPrimary:GetRGBA())
    stepText:SetText("")

    -- Name label (below icon, optional)
    local nameText = iconFrame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(nameText, NAME_FONT_SIZE)
    nameText:SetPoint("TOP", iconFrame, "BOTTOM", 0, -1)
    nameText:SetTextColor(C.textSecondary:GetRGBA())
    nameText:SetText("")
    nameText:SetWordWrap(false)
    nameText:SetMaxLines(1)

    -- Highlight animation group (alpha pulse on step advance)
    local highlightTex = iconFrame:CreateTexture(nil, "OVERLAY")
    highlightTex:SetAllPoints(iconFrame)
    highlightTex:SetColorTexture(1, 0.84, 0, 0.3)
    highlightTex:SetAlpha(0)

    local animGroup = highlightTex:CreateAnimationGroup()
    local fadeIn = animGroup:CreateAnimation("Alpha")
    fadeIn:SetFromAlpha(0)
    fadeIn:SetToAlpha(0.5)
    fadeIn:SetDuration(0.15)
    fadeIn:SetOrder(1)
    local fadeOut = animGroup:CreateAnimation("Alpha")
    fadeOut:SetFromAlpha(0.5)
    fadeOut:SetToAlpha(0)
    fadeOut:SetDuration(0.15)
    fadeOut:SetOrder(2)
    animGroup:SetScript("OnFinished", function()
        highlightTex:SetAlpha(0)
    end)

    iconFrame:SetScript("OnEnter", function(self)
        local entry
        for _, e in ipairs(TH.icons) do
            if e.frame == self then
                entry = e
                break
            end
        end
        if entry and entry.seqName then
            GameTooltip:SetOwner(self, "ANCHOR_TOP")
            GameTooltip:AddLine(entry.seqName, 0, 0.8, 0.4)
            GameTooltip:AddLine(entry.stepText:GetText() or "", 0.8, 0.8, 0.8)
            GameTooltip:AddLine(L["GEMS_TRACKER_PREVIEW_HINT"], 0.5, 0.5, 0.5, true)
            GameTooltip:Show()
        end
    end)
    iconFrame:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)

    return {
        frame = iconFrame,
        texture = tex,
        stepText = stepText,
        nameText = nameText,
        highlightTex = highlightTex,
        animGroup = animGroup,
        seqName = nil,
    }
end

---------------------------------------------------------------------------
-- Icon management
---------------------------------------------------------------------------
TH.icons = {}
TH.activeSeqName = nil

function TH:Rebuild()
    if not TH.frame then
        return
    end

    local eng = Engine()
    if not eng or not eng.sequences then
        TH.frame:Hide()
        return
    end

    -- Collect only sequences with an active keybind, sorted for stable ordering
    local KM = GRIPEMS.KeybindManager
    local sorted = {}
    for name, _ in pairs(eng.sequences) do
        if KM and KM:GetKeybind(name) then
            sorted[#sorted + 1] = name
        end
    end
    table.sort(sorted)

    -- Skip rebuild if sequence list unchanged
    if TH._lastSorted then
        local same = (#sorted == #TH._lastSorted)
        if same then
            for i = 1, #sorted do
                if sorted[i] ~= TH._lastSorted[i] then
                    same = false
                    break
                end
            end
        end
        if same then
            -- Still update step counters and icons without full rebuild
            for _, entry in ipairs(TH.icons) do
                if entry.seqName and entry.frame:IsShown() then
                    local seqEntry = eng.sequences[entry.seqName]
                    if seqEntry then
                        local ver = eng:GetActiveVersion(seqEntry.data)
                        local steps = ver and ver.steps or {}
                        TH:UpdateIcon(
                            entry.seqName,
                            tonumber(seqEntry.button and seqEntry.button:GetAttribute("step")) or 1,
                            #steps
                        )
                    end
                end
            end
            TH:UpdateVisibility()
            return
        end
    end
    TH._lastSorted = sorted

    -- Hide all existing icons
    for _, entry in ipairs(TH.icons) do
        entry.frame:Hide()
        entry.seqName = nil
    end

    local iconSize = S():Get("trackerIconSize") or 40
    local showName = S():Get("trackerShowName")
    local orientation = S():Get("trackerOrientation") or "HORIZONTAL"

    GRIPEMS:Debug(string.format("TrackerHUD: Rebuild (%d bound sequences)", #sorted))

    if #sorted == 0 then
        TH.frame:Hide()
        return
    end

    -- Create or reuse icon entries
    for i, seqName in ipairs(sorted) do
        local entry = TH.icons[i]
        if not entry then
            entry = CreateIconEntry(TH.frame, i)
            TH.icons[i] = entry
        end

        entry.seqName = seqName
        entry.frame:SetSize(iconSize, iconSize)
        entry.frame:Show()

        -- Name label
        if showName then
            local displayName = seqName
            if #displayName > 8 then
                displayName = displayName:sub(1, 6) .. ".."
            end
            entry.nameText:SetText(displayName)
            entry.nameText:SetWidth(iconSize + 4)
            entry.nameText:Show()
        else
            entry.nameText:Hide()
        end

        -- Resolve sequence icon and step info
        local seqEntry = eng.sequences[seqName]
        local seqData = seqEntry and seqEntry.data
        local btn = seqEntry and seqEntry.button

        -- Dynamic icon: resolve current step's spell via SpellCache
        local iconID = nil
        local sc = SC()
        if btn then
            local curStep = tonumber(btn:GetAttribute("step")) or 1
            local ver = eng:GetActiveVersion(seqData)
            local steps = ver and ver.steps
            if steps and #steps > 0 then
                local stepText = steps[curStep] or steps[1]
                if stepText and sc then
                    local spellName = sc:ParseSpellFromMacrotext(stepText)
                    if spellName then
                        iconID = sc:GetIcon(spellName)
                    end
                end
            end
        end
        -- Fallback: sequence icon, then question mark
        if not iconID then
            iconID = seqData and seqData.icon
        end
        if type(iconID) == "string" then
            iconID = tonumber(iconID) or QUESTION_MARK_ICON
        end
        if not iconID or iconID == "" or iconID == "INV_Misc_QuestionMark" then
            iconID = QUESTION_MARK_ICON
        end
        entry.texture:SetTexture(iconID)

        -- Step counter
        local step = 1
        local numSteps = 0
        if btn then
            step = tonumber(btn:GetAttribute("step")) or 1
        end
        local ver = eng:GetActiveVersion(seqData)
        if ver and ver.steps then
            numSteps = #ver.steps
        end
        entry.stepText:SetText(step .. "/" .. numSteps)

        -- Layout position
        entry.frame:ClearAllPoints()
        if i == 1 then
            entry.frame:SetPoint("TOPLEFT", TH.frame, "TOPLEFT", FRAME_PADDING, -FRAME_PADDING)
        else
            local prev = TH.icons[i - 1].frame
            if orientation == "VERTICAL" then
                local offset = showName and (NAME_HEIGHT + ICON_PADDING) or ICON_PADDING
                entry.frame:SetPoint("TOPLEFT", prev, "BOTTOMLEFT", 0, -offset)
            else
                entry.frame:SetPoint("TOPLEFT", prev, "TOPRIGHT", ICON_PADDING, 0)
            end
        end
    end

    -- Resize parent frame to fit all icons
    local count = #sorted
    local nameExtra = showName and (NAME_HEIGHT + 2) or 0
    local totalW, totalH

    if orientation == "VERTICAL" then
        totalW = iconSize + (FRAME_PADDING * 2)
        totalH = (count * iconSize) + ((count - 1) * (ICON_PADDING + nameExtra)) + (FRAME_PADDING * 2) + nameExtra
    else
        totalW = (count * iconSize) + ((count - 1) * ICON_PADDING) + (FRAME_PADDING * 2)
        totalH = iconSize + (FRAME_PADDING * 2) + nameExtra
    end

    TH.frame:SetSize(math.max(totalW, 30), math.max(totalH, 30))

    -- Restore active highlight
    if TH.activeSeqName then
        for _, entry in ipairs(TH.icons) do
            if entry.seqName == TH.activeSeqName then
                entry.frame:SetBackdropBorderColor(1, 0.84, 0, 1)
                break
            end
        end
    end

    -- Apply scale
    local scale = S():Get("trackerScale") or 1.0
    TH.frame:SetScale(scale)

    TH:UpdateRestrictionLabel()
    TH:UpdateVisibility()
end

function TH:UpdateIcon(seqName, step, numSteps)
    for _, entry in ipairs(TH.icons) do
        if entry.seqName == seqName then
            entry.stepText:SetText(step .. "/" .. numSteps)

            -- Dynamic icon: resolve current step's spell via SpellCache
            local iconID = nil
            local eng = Engine()
            local sc = SC()
            if eng and sc and eng.sequences[seqName] then
                local seqEntry = eng.sequences[seqName]
                local btn = seqEntry.button
                if btn then
                    local ver = eng:GetActiveVersion(seqEntry.data)
                    if ver and ver.steps and ver.steps[step] then
                        local spellName = sc:ParseSpellFromMacrotext(ver.steps[step])
                        if spellName then
                            iconID = sc:GetIcon(spellName)
                        end
                    end
                end
                -- Fallback: sequence icon, then question mark
                if not iconID then
                    iconID = seqEntry.data and seqEntry.data.icon
                end
                if type(iconID) == "string" then
                    iconID = tonumber(iconID) or QUESTION_MARK_ICON
                end
                if not iconID or iconID == "" or iconID == "INV_Misc_QuestionMark" then
                    iconID = QUESTION_MARK_ICON
                end
                entry.texture:SetTexture(iconID)
            end

            -- Flash highlight
            entry.animGroup:Stop()
            entry.highlightTex:SetAlpha(0)
            entry.animGroup:Play()

            -- Persistent gold border on active sequence
            if TH.activeSeqName and TH.activeSeqName ~= seqName then
                for _, other in ipairs(TH.icons) do
                    if other.seqName == TH.activeSeqName then
                        other.frame:SetBackdropBorderColor(0.3, 0.3, 0.35, 1)
                        break
                    end
                end
            end
            TH.activeSeqName = seqName
            entry.frame:SetBackdropBorderColor(1, 0.84, 0, 1)
            return
        end
    end
end

---------------------------------------------------------------------------
-- Restriction label management
---------------------------------------------------------------------------
function TH:UpdateRestrictionLabel()
    if not TH.frame or not TH.frame.restrictText then
        return
    end
    local label = GetRestrictionLabel()
    if label then
        TH.frame.restrictText:SetText(label)
        TH.frame.restrictText:Show()
    else
        TH.frame.restrictText:SetText("")
        TH.frame.restrictText:Hide()
    end
end

---------------------------------------------------------------------------
-- Visibility management
---------------------------------------------------------------------------
function TH:UpdateVisibility()
    if not TH.frame then
        return
    end
    if ShouldBeVisible() then
        TH.frame:Show()
    else
        TH.frame:Hide()
    end
end

---------------------------------------------------------------------------
-- Modifier key display
---------------------------------------------------------------------------
local function UpdateModifierDisplay()
    if not TH.frame or not TH.frame:IsShown() then
        return
    end
    if not S():Get("trackerShowModifiers") then
        TH.frame.modText:SetText("")
        return
    end

    local parts = {}
    if IsShiftKeyDown() then
        parts[#parts + 1] = "[S]"
    end
    if IsAltKeyDown() then
        parts[#parts + 1] = "[A]"
    end
    if IsControlKeyDown() then
        parts[#parts + 1] = "[C]"
    end

    TH.frame.modText:SetText(table.concat(parts, " "))
end

---------------------------------------------------------------------------
-- Callback handlers
---------------------------------------------------------------------------
function TH:OnStepAdvanced(_, seqName, step, numSteps)
    TH:UpdateIcon(seqName, step, numSteps)
end

function TH:OnSequenceChanged()
    TH:Rebuild()
end

function TH:OnSettingChanged(_, key, value)
    if not key or not tostring(key):match("^tracker") then
        return
    end
    GRIPEMS:Debug(string.format("TrackerHUD: setting %s = %s", tostring(key), tostring(value)))
    if key == "trackerShowMode" then
        if value == "NEVER" then
            if TH.frame then
                TH.frame:Hide()
            end
        else
            if not TH.frame then
                TH.frame = CreateHUDFrame()
                TH:RestorePosition()
            end
            TH:Rebuild()
        end
    elseif key == "trackerScale" then
        if TH.frame then
            TH.frame:SetScale(value or 1.0)
        end
    elseif key == "trackerIconSize" then
        TH:Rebuild()
    elseif key == "trackerOrientation" then
        TH:Rebuild()
    elseif key == "trackerShowName" then
        TH:Rebuild()
    elseif key == "trackerLocked" then
        -- no-op: lock state checked dynamically in OnDragStart
        return
    elseif key == "trackerShowModifiers" then
        if value then
            if not TH.modFrame then
                local modFrame = _G["GRIPEMS_TrackerMod"] or CreateFrame("Frame", "GRIPEMS_TrackerMod", UIParent)
                modFrame:UnregisterAllEvents()
                modFrame:RegisterEvent("MODIFIER_STATE_CHANGED")
                modFrame:SetScript("OnEvent", UpdateModifierDisplay)
                TH.modFrame = modFrame
            end
            UpdateModifierDisplay()
        else
            if TH.modFrame then
                TH.modFrame:UnregisterAllEvents()
                TH.modFrame:SetScript("OnEvent", nil)
                TH.modFrame:Hide()
                TH.modFrame = nil
            end
            if TH.frame and TH.frame.modText then
                TH.frame.modText:SetText("")
            end
        end
    end
end

---------------------------------------------------------------------------
-- Public API
---------------------------------------------------------------------------
function TH:Toggle()
    local current = S():Get("trackerShowMode") or "NEVER"
    local order = { "NEVER", "ALWAYS", "COMBAT", "TARGET" }
    local modeNames = {
        NEVER = L["GEMS_TRACKER_MODE_NEVER"],
        ALWAYS = L["GEMS_TRACKER_MODE_ALWAYS"],
        COMBAT = L["GEMS_TRACKER_MODE_COMBAT"],
        TARGET = L["GEMS_TRACKER_MODE_TARGET"],
    }
    local nextIdx = 1
    for i, mode in ipairs(order) do
        if mode == current then
            nextIdx = (i % #order) + 1
            break
        end
    end
    local newMode = order[nextIdx]
    S():Set("trackerShowMode", newMode)
    GRIPEMS:Print(string.format(L["GEMS_TRACKER_TOGGLE"], modeNames[newMode] or newMode))
end

function TH:ToggleLock()
    local current = S():Get("trackerLocked")
    S():Set("trackerLocked", not current)
    if not current then
        GRIPEMS:Print(L["GEMS_TRACKER_LOCKED"])
    else
        GRIPEMS:Print(L["GEMS_TRACKER_UNLOCKED"])
    end
end

---------------------------------------------------------------------------
-- Initialization
---------------------------------------------------------------------------
function TH:Init()
    -- Create the frame
    TH.frame = CreateHUDFrame()
    TH:RestorePosition()
    GRIPEMS:Debug("TrackerHUD: Init complete")

    -- Register callbacks
    if GRIPEMS.RegisterCallback then
        GRIPEMS.RegisterCallback(TH, "SEQUENCE_STEP_ADVANCED", "OnStepAdvanced")
        GRIPEMS.RegisterCallback(TH, "SEQUENCE_CREATED", "OnSequenceChanged")
        GRIPEMS.RegisterCallback(TH, "SEQUENCE_DELETED", "OnSequenceChanged")
        GRIPEMS.RegisterCallback(TH, "SEQUENCE_UPDATED", "OnSequenceChanged")
        GRIPEMS.RegisterCallback(TH, "SETTING_CHANGED", "OnSettingChanged")
        GRIPEMS.RegisterCallback(TH, "KEYBIND_CHANGED", "OnSequenceChanged")
    end

    -- Restriction state event frame
    local restrictFrame = _G["GRIPEMS_TrackerRestrict"] or CreateFrame("Frame", "GRIPEMS_TrackerRestrict", UIParent)
    restrictFrame:UnregisterAllEvents()
    if C_RestrictedActions and C_RestrictedActions.IsAddOnRestrictionActive then
        restrictFrame:RegisterEvent("ADDON_RESTRICTION_STATE_CHANGED")
    end
    restrictFrame:SetScript("OnEvent", function()
        TH:UpdateRestrictionLabel()
    end)
    TH.restrictFrame = restrictFrame

    -- Visibility event frame (combat/target state changes)
    local visFrame = _G["GRIPEMS_TrackerVis"] or CreateFrame("Frame", "GRIPEMS_TrackerVis", UIParent)
    visFrame:UnregisterAllEvents()
    visFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
    visFrame:RegisterEvent("PLAYER_REGEN_DISABLED")
    visFrame:RegisterEvent("PLAYER_TARGET_CHANGED")
    visFrame:SetScript("OnEvent", function()
        if ShouldBeVisible() and TH.frame and not TH.frame:IsShown() then
            TH:Rebuild()
        else
            TH:UpdateVisibility()
        end
    end)
    TH.visFrame = visFrame

    -- Modifier key event frame
    if S():Get("trackerShowModifiers") then
        local modFrame = _G["GRIPEMS_TrackerMod"] or CreateFrame("Frame", "GRIPEMS_TrackerMod", UIParent)
        modFrame:UnregisterAllEvents()
        modFrame:RegisterEvent("MODIFIER_STATE_CHANGED")
        modFrame:SetScript("OnEvent", UpdateModifierDisplay)
        TH.modFrame = modFrame
    end

    -- Initial build + visibility check
    TH:Rebuild()
    TH:UpdateVisibility()
end
