-- GRIP-EMS: MacroSyntax
-- Created: 2026-05-10
-- Updated: 2026-08-17
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)

-- Pure-data parser/serializer/negator/merger for WoW secure command options.
-- Single source of truth for IF action node compile transformations.
-- See Hub/GRIP/Hub/Projects/EMS/Research/IF_Node_Complete_Spec.md for the
-- full grammar (section 3), conditional catalog (section 4), DeMorgan rules
-- (section 5), and per-line injection algorithm (section 8).

local ADDON_NAME, GRIPEMS = ...
GRIPEMS.MacroSyntax = {}
local MS = GRIPEMS.MacroSyntax

-- ===========================================================================
-- Conditional catalog (spec section 4 -- 12.0.5)
-- ===========================================================================

MS.CONDITIONAL_CATALOG = {
    -- 4.1 Target-evaluated (default @target)
    target = {
        exists = true,
        help = true,
        harm = true,
        dead = true,
        party = true,
        raid = true,
        unithasvehicleui = true,
    },
    -- 4.2 Player-evaluated (always @player)
    player = {
        combat = true,
        stealth = true,
        mounted = true,
        swimming = true,
        flying = true,
        indoors = true,
        outdoors = true,
        flyable = true,
        advflyable = true,
        form = true,
        stance = true,
        spec = true,
        equipped = true,
        worn = true,
        channeling = true,
        known = true,
        pet = true,
        petbattle = true,
        pvpcombat = true,
        resting = true,
        group = true,
        canexitvehicle = true,
    },
    -- 4.3 UI-evaluated
    ui = {
        mod = true,
        modifier = true,
        button = true,
        btn = true,
        actionbar = true,
        bar = true,
        bonusbar = true,
        overridebar = true,
        possessbar = true,
        vehicleui = true,
        extrabar = true,
        shapeshift = true,
        cursor = true,
        house = true,
    },
    -- 4.5 REMOVED in modern WoW (validate-time warn). Value = replacement hint.
    removed = {
        talent = "known:",
    },
}

-- ===========================================================================
-- Conditional-accepting commands (spec section 6 -- O(1) lookup)
-- ===========================================================================

MS.CONDITIONAL_COMMANDS = {
    -- 6.1 Casting
    ["/cast"] = true,
    ["/castrandom"] = true,
    ["/castsequence"] = true,
    ["/use"] = true,
    ["/usetalents"] = true,
    ["/useshapeshift"] = true,
    -- 6.2 Cancel
    ["/cancelaura"] = true,
    ["/cancelform"] = true,
    ["/stopcasting"] = true,
    ["/stopattack"] = true,
    -- 6.3 Equipment
    ["/equip"] = true,
    ["/equipslot"] = true,
    ["/equipset"] = true,
    -- 6.4 Targeting
    ["/target"] = true,
    ["/targetenemy"] = true,
    ["/targetfriend"] = true,
    ["/focus"] = true,
    ["/clearfocus"] = true,
    ["/assist"] = true,
    ["/cleartarget"] = true,
    -- 6.5 Pet
    ["/petattack"] = true,
    ["/petfollow"] = true,
    ["/petstay"] = true,
    ["/petpassive"] = true,
    ["/petdefensive"] = true,
    ["/petaggressive"] = true,
    ["/petautocaston"] = true,
    ["/petautocastoff"] = true,
    ["/summonpet"] = true,
    ["/dismount"] = true,
    -- 6.6 UI
    ["/click"] = true,
    ["/show"] = true,
    ["/showtooltip"] = true,
    ["/startattack"] = true,
    ["/stopmacro"] = true,
}

--- Return true iff the given command token (with leading slash) accepts
--- secure command options per spec section 6.
--- @param cmd string Command token, e.g. "/cast"
--- @return boolean
function MS.IsCommandConditional(cmd)
    if not cmd then
        return false
    end
    return MS.CONDITIONAL_COMMANDS[cmd] == true
end

-- ===========================================================================
-- String helpers (local, not exposed)
-- ===========================================================================

local function trim(s)
    if not s then
        return ""
    end
    local r = s:gsub("^%s+", "")
    r = r:gsub("%s+$", "")
    return r
end

-- ===========================================================================
-- Parser (spec section 3 grammar)
-- ===========================================================================

-- Parse one conditional inside a bracket, e.g. "mod:shift", "no harm",
-- "@focus", "target=focus". Returns
--   { key = string|nil, neg = bool, args = array, target = string|nil }
-- Targeting prefixes (@unit, target=unit) get key=nil and a non-nil target.
local function parseConditional(s)
    s = trim(s)
    if s == "" then
        return nil
    end
    -- Targeting prefix: @unit
    if s:sub(1, 1) == "@" then
        return { key = nil, neg = false, args = {}, target = s }
    end
    -- Targeting prefix: target=unit
    if s:sub(1, 7) == "target=" then
        return { key = nil, neg = false, args = {}, target = s }
    end
    -- Negation prefix: "no..."
    local neg = false
    if #s > 2 and s:sub(1, 2) == "no" then
        neg = true
        s = s:sub(3)
    end
    -- Split key:arg/arg
    local colonPos = s:find(":", 1, true)
    if not colonPos then
        return { key = s, neg = neg, args = {}, target = nil }
    end
    local key = s:sub(1, colonPos - 1)
    local argStr = s:sub(colonPos + 1)
    local args = {}
    for arg in argStr:gmatch("[^/]+") do
        args[#args + 1] = arg
    end
    return { key = key, neg = neg, args = args, target = nil }
end

-- Parse the contents of one bracket pair (comma-separated conditionals).
-- Returns { conditionals = array }
local function parseCondition(inner)
    local conditionals = {}
    for token in inner:gmatch("[^,]+") do
        local c = parseConditional(token)
        if c then
            conditionals[#conditionals + 1] = c
        end
    end
    return { conditionals = conditionals }
end

-- Parse a single clause: zero or more brackets followed by an optional value.
-- Returns { conditions = array, value = string }
local function parseClause(s, errors)
    local conditions = {}
    local pos = 1
    local len = #s
    -- Eat leading whitespace
    while pos <= len and s:sub(pos, pos):match("%s") do
        pos = pos + 1
    end
    -- Parse zero or more brackets
    while pos <= len and s:sub(pos, pos) == "[" do
        local closePos = s:find("]", pos + 1, true)
        if not closePos then
            errors[#errors + 1] = "unbalanced bracket"
            return { conditions = conditions, value = trim(s:sub(pos)) }
        end
        local inner = s:sub(pos + 1, closePos - 1)
        conditions[#conditions + 1] = parseCondition(inner)
        pos = closePos + 1
        -- Eat whitespace between brackets
        while pos <= len and s:sub(pos, pos):match("%s") do
            pos = pos + 1
        end
    end
    -- Remainder is the value
    local value = trim(s:sub(pos))
    return { conditions = conditions, value = value }
end

--- Parse a full secure command options string into an AST.
--- Robust: missing brackets, unbalanced brackets, empty input do not throw.
--- Returns { clauses = array, parse_errors = array of strings }.
--- @param optionsString string|nil Macro options string (post-command remainder)
--- @return table ast
function MS.Parse(optionsString)
    optionsString = optionsString or ""
    local ast = { clauses = {}, parse_errors = {} }
    local errors = ast.parse_errors
    if optionsString == "" then
        return ast
    end
    -- Split on semicolons at depth 0
    local clauses = {}
    local pos = 1
    local len = #optionsString
    local depth = 0
    local clauseStart = 1
    while pos <= len do
        local ch = optionsString:sub(pos, pos)
        if ch == "[" then
            depth = depth + 1
        elseif ch == "]" then
            depth = depth - 1
        elseif ch == ";" and depth == 0 then
            clauses[#clauses + 1] = optionsString:sub(clauseStart, pos - 1)
            clauseStart = pos + 1
        end
        pos = pos + 1
    end
    if clauseStart <= len then
        clauses[#clauses + 1] = optionsString:sub(clauseStart)
    end
    for _, clauseStr in ipairs(clauses) do
        ast.clauses[#ast.clauses + 1] = parseClause(clauseStr, errors)
    end
    return ast
end

-- ===========================================================================
-- Serializer (spec section 3 canonical form)
-- ===========================================================================

local function serializeConditional(c)
    if c.target then
        return c.target
    end
    local s = c.neg and "no" or ""
    s = s .. (c.key or "")
    if c.args and #c.args > 0 then
        s = s .. ":" .. table.concat(c.args, "/")
    end
    return s
end

local function serializeCondition(cond)
    local parts = {}
    for _, c in ipairs(cond.conditionals) do
        parts[#parts + 1] = serializeConditional(c)
    end
    return "[" .. table.concat(parts, ",") .. "]"
end

local function serializeClause(clause)
    local s = ""
    for _, cond in ipairs(clause.conditions) do
        s = s .. serializeCondition(cond)
    end
    if clause.value and clause.value ~= "" then
        if s ~= "" then
            s = s .. " " .. clause.value
        else
            s = clause.value
        end
    end
    return s
end

--- Serialize an AST back to canonical string form.
--- No whitespace inside brackets; one space after each cluster of brackets;
--- semicolons between clauses with no surrounding whitespace.
--- @param ast table AST as returned by MS.Parse
--- @return string
function MS.Serialize(ast)
    if not ast or not ast.clauses then
        return ""
    end
    local parts = {}
    for _, clause in ipairs(ast.clauses) do
        parts[#parts + 1] = serializeClause(clause)
    end
    return table.concat(parts, "; ")
end

-- ===========================================================================
-- DeMorgan negation (spec section 5)
-- ===========================================================================

-- Negate one boolean conditional (flip neg). Targeting passes through
-- unchanged at the call site.
local function negateConditional(c)
    local newArgs = {}
    if c.args then
        for i, a in ipairs(c.args) do
            newArgs[i] = a
        end
    end
    return { key = c.key, neg = not c.neg, args = newArgs, target = nil }
end

local function copyConditional(c)
    local newArgs = {}
    if c.args then
        for i, a in ipairs(c.args) do
            newArgs[i] = a
        end
    end
    return { key = c.key, neg = c.neg, args = newArgs, target = c.target }
end

-- Two conditionals compare equal when they have the same key (or both nil
-- for targeting), same neg flag, same args list (length + element-wise
-- string equality), and the same target string when present. Used by
-- injectConditionList to skip duplicate prepends (idempotence guarantee
-- for MS.InjectIntoOptions, spec section 8.1).
local function conditionalsEquivalent(a, b)
    if not a or not b then
        return false
    end
    if a.key ~= b.key then
        return false
    end
    if (a.neg and true or false) ~= (b.neg and true or false) then
        return false
    end
    if a.target ~= b.target then
        return false
    end
    local aArgs = a.args or {}
    local bArgs = b.args or {}
    if #aArgs ~= #bArgs then
        return false
    end
    for i = 1, #aArgs do
        if aArgs[i] ~= bArgs[i] then
            return false
        end
    end
    return true
end

--- DeMorgan-negate a condition list.
--- Input is a list of conditions in OR form (multi-bracket).
---   [A,B] negates to [noA][noB] (single bracket AND -> multi OR).
---   [A][B] negates to [noA,noB] (multi OR -> single bracket AND).
---   [A,B][C,D] negates to cartesian product of negated picks.
--- Targeting prefixes (@unit, target=unit) pass through to every
--- output clause unchanged (spec 5.1).
--- Combinatorial cap at 8 output clauses (spec 5.4).
--- @param conditionList table Array of conditions
--- @return table Negated condition list
function MS.Negate(conditionList)
    if not conditionList or #conditionList == 0 then
        return {}
    end

    -- Split each clause into (booleans, targets).
    local clauses = {}
    for _, cond in ipairs(conditionList) do
        local booleans = {}
        local targets = {}
        for _, c in ipairs(cond.conditionals) do
            if c.target then
                targets[#targets + 1] = c
            else
                booleans[#booleans + 1] = c
            end
        end
        clauses[#clauses + 1] = { booleans = booleans, targets = targets }
    end

    local function copyArr(t)
        local r = {}
        for i, v in ipairs(t) do
            r[i] = v
        end
        return r
    end

    local out = {}
    local function recurse(idx, picked, pickedTargets)
        if idx > #clauses then
            local conditionals = {}
            for _, t in ipairs(pickedTargets) do
                conditionals[#conditionals + 1] = copyConditional(t)
            end
            for _, c in ipairs(picked) do
                conditionals[#conditionals + 1] = negateConditional(c)
            end
            out[#out + 1] = { conditionals = conditionals }
            return
        end
        local clause = clauses[idx]
        local newTargets = copyArr(pickedTargets)
        for _, t in ipairs(clause.targets) do
            newTargets[#newTargets + 1] = t
        end
        if #clause.booleans == 0 then
            -- NOT(unconditional) is unsat; this branch contributes nothing.
            return
        end
        for _, c in ipairs(clause.booleans) do
            local newPicked = copyArr(picked)
            newPicked[#newPicked + 1] = c
            recurse(idx + 1, newPicked, newTargets)
        end
    end
    recurse(1, {}, {})

    -- Combinatorial cap (section 5.4): cap at 8, log a debug warn.
    if #out > 8 then
        if GRIPEMS and GRIPEMS.Debug then
            GRIPEMS:Debug("MacroSyntax.Negate: combinatorial cap exceeded (" .. tostring(#out) .. " > 8); capped")
        end
        local capped = {}
        for i = 1, 8 do
            capped[i] = out[i]
        end
        return capped
    end

    return out
end

-- ===========================================================================
-- Cond box input (spec section 9)
-- ===========================================================================

--- Parse a Cond box input string. Accepts a bare conditional list, a single
--- bracket, or a multi-bracket OR form. Strips outer brackets, rejects
--- semicolons (spec 9.2), rejects empty, rejects [].
--- Returns { ast = parsed AST, errors = array of strings }.
--- @param text string|nil Cond box raw input
--- @return table
function MS.ParseCondBoxInput(text)
    local result = { ast = { clauses = {} }, errors = {} }
    text = trim(text or "")
    if text == "" then
        result.errors[#result.errors + 1] = "empty condition"
        return result
    end
    if text:find(";", 1, true) then
        result.errors[#result.errors + 1] = "semicolons forbidden in cond box"
        return result
    end
    local clause = { conditions = {}, value = "" }
    if text:sub(1, 1) == "[" then
        -- Bracketed input: parse as zero or more brackets
        local pos = 1
        local len = #text
        while pos <= len and text:sub(pos, pos) == "[" do
            local closePos = text:find("]", pos + 1, true)
            if not closePos then
                result.errors[#result.errors + 1] = "unbalanced bracket"
                return result
            end
            local inner = trim(text:sub(pos + 1, closePos - 1))
            if inner == "" then
                result.errors[#result.errors + 1] =
                    "empty bracket [] is always-true; use a real condition or remove the IF"
                return result
            end
            clause.conditions[#clause.conditions + 1] = parseCondition(inner)
            pos = closePos + 1
            while pos <= len and text:sub(pos, pos):match("%s") do
                pos = pos + 1
            end
        end
        if pos <= len then
            result.errors[#result.errors + 1] = "unexpected content after brackets"
            return result
        end
    else
        -- Bare condition (no brackets). Reject any stray "[" or "]" up front:
        -- a malformed bracket character in bare-input mode is unbalanced by
        -- definition (no opening "[" to balance against). Catches inputs like
        -- "mod:shift][combat" or "mod:shift]" that would otherwise parse
        -- silently into a malformed clause.
        if text:find("[", 1, true) or text:find("]", 1, true) then
            result.errors[#result.errors + 1] = "unbalanced bracket in bare input"
            return result
        end
        -- Bare condition (no brackets). Treat as one condition with comma-AND.
        clause.conditions[#clause.conditions + 1] = parseCondition(text)
    end
    result.ast.clauses[1] = clause
    return result
end

-- ===========================================================================
-- Validation (spec section 4 catalog lookup)
-- ===========================================================================

--- Validate a single conditional key against the spec section 4 catalog.
--- Targeting prefixes (key=nil) always return known=true.
--- Removed keys (talent:) return removed=true with replacement hint.
--- Returns { known = bool, removed = bool, replacement = string|nil }.
--- @param key string|nil Conditional key (e.g. "mod", "harm")
--- @param args table|nil Argument list (currently unused by validation)
--- @return table
function MS.ValidateConditional(key, args)
    if not key then
        return { known = true, removed = false, replacement = nil }
    end
    local cat = MS.CONDITIONAL_CATALOG
    if cat.removed[key] then
        return { known = false, removed = true, replacement = cat.removed[key] }
    end
    local known = (cat.target[key] or cat.player[key] or cat.ui[key]) and true or false
    return { known = known, removed = false, replacement = nil }
end

--- Walk every conditional in an AST, returning a list of warning strings
--- for unknown or removed keys. Pure-data, no side effects.
--- @param ast table AST as returned by MS.Parse or MS.ParseCondBoxInput
--- @return table Array of warning strings
function MS.ValidateAst(ast)
    local warnings = {}
    if not ast or not ast.clauses then
        return warnings
    end
    for _, clause in ipairs(ast.clauses) do
        for _, cond in ipairs(clause.conditions) do
            for _, c in ipairs(cond.conditionals) do
                if c.key then
                    local result = MS.ValidateConditional(c.key, c.args)
                    if result.removed then
                        warnings[#warnings + 1] = c.key .. ": removed in 10.0.0, use " .. (result.replacement or "")
                    elseif not result.known then
                        warnings[#warnings + 1] = c.key .. ": unknown conditional"
                    end
                end
            end
        end
    end
    return warnings
end

-- ===========================================================================
-- Injection (spec section 8)
-- ===========================================================================

-- Inject a parsed condition list into every clause of an options string.
-- Single-bracket cond merges into the existing first bracket of each clause.
-- Multi-bracket cond prepends all brackets before existing brackets.
local function injectConditionList(optionsString, condList)
    local ast = MS.Parse(optionsString or "")
    if #ast.clauses == 0 then
        ast.clauses = { { conditions = {}, value = "" } }
    end
    for _, clause in ipairs(ast.clauses) do
        local origConditions = clause.conditions
        clause.conditions = {}
        if #condList == 0 then
            for _, c in ipairs(origConditions) do
                clause.conditions[#clause.conditions + 1] = c
            end
        elseif #condList == 1 then
            local condBracket = condList[1]
            if #origConditions == 0 then
                clause.conditions[1] = { conditionals = {} }
                for _, c in ipairs(condBracket.conditionals) do
                    clause.conditions[1].conditionals[#clause.conditions[1].conditionals + 1] = c
                end
            else
                -- Idempotence: skip prepending any cond conditional that is
                -- already present in origConditions[1].conditionals.
                local merged = { conditionals = {} }
                for _, c in ipairs(condBracket.conditionals) do
                    local dup = false
                    for _, existing in ipairs(origConditions[1].conditionals) do
                        if conditionalsEquivalent(c, existing) then
                            dup = true
                            break
                        end
                    end
                    if not dup then
                        merged.conditionals[#merged.conditionals + 1] = c
                    end
                end
                for _, c in ipairs(origConditions[1].conditionals) do
                    merged.conditionals[#merged.conditionals + 1] = c
                end
                clause.conditions[1] = merged
                for i = 2, #origConditions do
                    clause.conditions[#clause.conditions + 1] = origConditions[i]
                end
            end
        else
            -- Multi-bracket OR: prepend all cond brackets, keep existing after.
            for _, b in ipairs(condList) do
                clause.conditions[#clause.conditions + 1] = b
            end
            for _, c in ipairs(origConditions) do
                clause.conditions[#clause.conditions + 1] = c
            end
        end
    end
    return MS.Serialize(ast)
end

--- Inject a Cond-box-style condition into every clause of an options string.
--- mode "and" prepends the condition into every clause's first bracket
--- (or wraps a bare value in a new bracket).
--- mode "negated_and" applies MS.Negate to the condition first (DeMorgan).
--- Idempotent: calling with the same args twice produces identical output
--- when the cond is already present.
--- @param optionsString string|nil Existing options remainder (no command)
--- @param condText string Cond box text (bare, single bracket, or multi-OR)
--- @param mode string "and" | "negated_and"
--- @return string
function MS.InjectIntoOptions(optionsString, condText, mode)
    local condInput = MS.ParseCondBoxInput(condText)
    if #condInput.errors > 0 then
        return optionsString or ""
    end
    local condList = {}
    if condInput.ast.clauses[1] then
        for _, c in ipairs(condInput.ast.clauses[1].conditions) do
            condList[#condList + 1] = c
        end
    end
    if mode == "negated_and" then
        condList = MS.Negate(condList)
    end
    return injectConditionList(optionsString or "", condList)
end

-- ===========================================================================
-- Preview helpers (UI surface support, spec section 10.4)
-- ===========================================================================

--- Return char count of a single emitted macrotext line.
--- Used by the UI 200/255 char warning and error checks.
--- @param line string|nil
--- @return number
function MS.PreviewLength(line)
    return #(line or "")
end
