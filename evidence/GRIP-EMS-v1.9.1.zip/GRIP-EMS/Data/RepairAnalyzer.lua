-- GRIP-EMS: Repair Analyzer
-- Sequence analysis and auto-fix backend for the Repair Module.
-- 13 diagnostic categories with per-issue fix closures.

local _, GRIPEMS = ...
local D = GRIPEMS.Defaults

GRIPEMS.RepairAnalyzer = {}
local RA = GRIPEMS.RepairAnalyzer

local SV, VS, AC, E, MM, KM, S, DW, SC
local function ResolveDeps()
    if SV then return end
    SV, VS = GRIPEMS.SpellValidator, GRIPEMS.VariableStore
    AC, E = GRIPEMS.ActionCompiler, GRIPEMS.Engine
    MM, KM = GRIPEMS.MacroManager, GRIPEMS.KeybindManager
    S = GRIPEMS.Settings
    DW = GRIPEMS.DebugWindow
    SC = GRIPEMS.SpellCache
end

-- Constants
RA.SEVERITY_CRITICAL = "critical"
RA.SEVERITY_ERROR    = "error"
RA.SEVERITY_WARNING  = "warning"
RA.SEVERITY_INFO     = "info"
RA.CAT_SPELLS     = "SPELLS"
RA.CAT_STRUCTURE  = "STRUCTURE"
RA.CAT_LIMITS     = "LIMITS"
RA.CAT_VARIABLES  = "VARIABLES"
RA.CAT_ACTIONS    = "ACTIONS"
RA.CAT_STUBS      = "STUBS"
RA.CAT_CONFIG     = "CONFIG"
RA.CAT_LOCALE     = "LOCALE"
RA.CAT_READINESS  = "READINESS"
RA.CAT_POST_SUB   = "POST_SUB"
RA.CAT_STATE_SYNC = "STATE_SYNC"
RA.CAT_CROSS_SEQ  = "CROSS_SEQ"
RA.CAT_CONCURRENT = "CONCURRENT"

-- Helpers
local SEVERITY_ORDER = { critical = 1, error = 2, warning = 3, info = 4 }
local idCounters = {}
local function NextID(pfx)
    idCounters[pfx] = (idCounters[pfx] or 0) + 1
    return string.format("%s_%03d", pfx, idCounters[pfx])
end
local function ResetIDs() wipe(idCounters) end
local function LogFix(sn, d) if DW then DW:AddMessage("[Repair] " .. (sn or "?") .. ": " .. d) end end

local function I(t, pfx, cat, sev, title, detail, fixable, fixFn)
    t[#t + 1] = { id = NextID(pfx), category = cat, severity = sev,
        title = title, detail = detail, fixable = fixable or false, fixFn = fixFn }
end

local contextKeySet
local function GetContextKeySet()
    if contextKeySet then return contextKeySet end
    contextKeySet = {}
    for _, k in ipairs(D.CONTEXT_KEYS) do contextKeySet[k] = true end
    return contextKeySet
end

local function StubFix(fn, seqName)
    return function(sd)
        if InCombatLockdown() then
            GRIPEMS.OOCQueue:Add(function() fn(sd); LogFix(seqName, "Stub fix (queued)") end,
                D.OOC_OP_GENERIC, seqName)
            return "queued"
        end
        fn(sd); return true
    end
end

-- Cat 1: Spells
function RA:CheckSpells(seqData, issues)
    for vi, ver in ipairs(seqData.versions or {}) do
        local texts = {}
        for si, step in ipairs(ver.steps or {}) do
            texts[#texts + 1] = { text = step, label = string.format("V%d step %d", vi, si) }
        end
        if ver.keyPress and ver.keyPress ~= "" then
            texts[#texts + 1] = { text = ver.keyPress, label = "V" .. vi .. " keyPress" }
        end
        if ver.keyRelease and ver.keyRelease ~= "" then
            texts[#texts + 1] = { text = ver.keyRelease, label = "V" .. vi .. " keyRelease" }
        end
        for _, entry in ipairs(texts) do
            local result = SV:ValidateStep(entry.text)
            for _, spell in ipairs(result.spells) do
                if spell.status == D.SPELL_STATUS_UNKNOWN then
                    local detail = entry.label .. ": '" .. spell.name .. "'"
                    if SC and SC.ready then
                        local hits = SC:PrefixSearch(spell.name:sub(1, 3), 3)
                        if hits and #hits > 0 then
                            local names = {}
                            for _, h in ipairs(hits) do names[#names + 1] = h.name end
                            detail = detail .. " (try: " .. table.concat(names, ", ") .. ")"
                        end
                    end
                    I(issues, "SPELL", RA.CAT_SPELLS, RA.SEVERITY_ERROR, "Unknown spell",
                        detail)
                elseif spell.status == D.SPELL_STATUS_KNOWN then
                    I(issues, "SPELL", RA.CAT_SPELLS, RA.SEVERITY_WARNING, "Spell not learned",
                        entry.label .. ": '" .. spell.name .. "'")
                end
            end
            for _, spell in ipairs(result.tooltipSpells or {}) do
                if spell.status == D.SPELL_STATUS_TOOLTIP_STALE then
                    I(issues, "SPELL", RA.CAT_SPELLS, RA.SEVERITY_INFO, "Stale tooltip",
                        entry.label .. ": '" .. spell.name .. "'")
                end
            end
            for _, ex in ipairs(SV:ExtractAllSpells(entry.text)) do
                if ex.command ~= "use" and SV:ValidateSpell(ex.name, "use").status == D.SPELL_STATUS_ITEM then
                    I(issues, "SPELL", RA.CAT_SPELLS, RA.SEVERITY_WARNING,
                        "Item in non-/use command", entry.label .. ": '" .. ex.name .. "'")
                end
            end
        end
    end
end

-- Cat 2: Structure
function RA:CheckStructure(seqData, issues)
    local n = RA._currentName
    if type(seqData.versions) ~= "table" or #seqData.versions == 0 then
        I(issues, "STRUCT", RA.CAT_STRUCTURE, RA.SEVERITY_CRITICAL, "Missing versions",
            "No versions table or empty", true, function(sd)
                sd.versions = { { stepFunction = D.STEP_SEQUENTIAL, steps = {},
                    keyPress = D.NewVersion.keyPress, keyRelease = "",
                    resetOnCombat = false, resetOnTarget = false,
                    resetOnGear = false, resetOnSpec = false, resetTimer = 0 } }
                LogFix(n, "Stamped default version"); return true
            end)
        return
    end
    for vi, ver in ipairs(seqData.versions) do
        if not ver.steps or #ver.steps == 0 then
            I(issues, "STRUCT", RA.CAT_STRUCTURE, RA.SEVERITY_ERROR, "Empty steps array",
                "V" .. vi)
        end
        if ver.stepFunction == nil then
            I(issues, "STRUCT", RA.CAT_STRUCTURE, RA.SEVERITY_ERROR, "Missing stepFunction",
                "V" .. vi, true, function(sd) sd.versions[vi].stepFunction = D.STEP_SEQUENTIAL; LogFix(n, "stepFunction V" .. vi); return true end)
        end
        if ver.keyPress == nil then
            I(issues, "STRUCT", RA.CAT_STRUCTURE, RA.SEVERITY_WARNING, "Nil keyPress",
                "V" .. vi, true, function(sd) sd.versions[vi].keyPress = ""; LogFix(n, "keyPress V" .. vi); return true end)
        end
        if ver.keyRelease == nil then
            I(issues, "STRUCT", RA.CAT_STRUCTURE, RA.SEVERITY_WARNING, "Nil keyRelease",
                "V" .. vi, true, function(sd) sd.versions[vi].keyRelease = ""; LogFix(n, "keyRelease V" .. vi); return true end)
        end
        if ver.taggedSteps and ver.steps and #ver.taggedSteps ~= #ver.steps then
            I(issues, "STRUCT", RA.CAT_STRUCTURE, RA.SEVERITY_WARNING, "Orphaned taggedSteps",
                string.format("V%d: %d tagged vs %d steps", vi, #ver.taggedSteps, #ver.steps), true,
                function(sd) sd.versions[vi].taggedSteps = nil; sd.versions[vi].stepsLocale = nil; LogFix(n, "Cleared V" .. vi); return true end)
        end
    end
    if seqData.name == nil or seqData.name == "" then
        I(issues, "STRUCT", RA.CAT_STRUCTURE, RA.SEVERITY_ERROR, "Missing name", "nil/empty", true,
            function(sd) sd.name = n; LogFix(n, "Set name"); return true end)
    end
    if seqData.icon == nil then
        I(issues, "STRUCT", RA.CAT_STRUCTURE, RA.SEVERITY_INFO, "Missing icon", "nil", true,
            function(sd) sd.icon = D.QUESTION_MARK_ICON; LogFix(n, "Set icon"); return true end)
    end
    local dv = seqData.defaultVersion or 0
    if dv < 1 or dv > #seqData.versions then
        I(issues, "STRUCT", RA.CAT_STRUCTURE, RA.SEVERITY_ERROR, "defaultVersion out of range",
            "dv=" .. dv, true, function(sd) sd.defaultVersion = math.min(math.max(sd.defaultVersion or 1, 1), #sd.versions); LogFix(n, "Clamped dv"); return true end)
    end
    if seqData.contextOverrides then
        local ckSet = GetContextKeySet()
        for key, idx in pairs(seqData.contextOverrides) do
            if type(idx) == "number" and idx > #seqData.versions then
                I(issues, "STRUCT", RA.CAT_STRUCTURE, RA.SEVERITY_ERROR, "Stale context override",
                    key .. " -> V" .. idx, true, function(sd) sd.contextOverrides[key] = nil; LogFix(n, "Removed " .. key); return true end)
            end
            if not ckSet[key] then
                I(issues, "STRUCT", RA.CAT_STRUCTURE, RA.SEVERITY_WARNING, "Unknown context key",
                    key, true, function(sd) sd.contextOverrides[key] = nil; LogFix(n, "Removed " .. key); return true end)
            end
        end
    end
    local cid = seqData.classID
    if cid == nil or type(cid) ~= "number" or cid < 1 or cid > 13 then
        I(issues, "STRUCT", RA.CAT_STRUCTURE, RA.SEVERITY_WARNING, "Invalid classID",
            tostring(cid), true, function(sd) sd.classID = select(3, UnitClass("player")); LogFix(n, "Stamped classID"); return true end)
    end
    for _, field in ipairs({ "author", "version", "description" }) do
        if seqData[field] == nil then
            I(issues, "STRUCT", RA.CAT_STRUCTURE, RA.SEVERITY_INFO, "Missing " .. field,
                "nil", true, function(sd) sd[field] = ""; LogFix(n, "Set " .. field); return true end)
        end
    end
end

-- Cat 3: Limits
function RA:CheckLimits(seqData, issues)
    local n = RA._currentName
    for vi, ver in ipairs(seqData.versions or {}) do
        local kp, kr = ver.keyPress or "", ver.keyRelease or ""
        for si, step in ipairs(ver.steps or {}) do
            if #step > D.MAX_MACROTEXT_LENGTH then
                I(issues, "LIMIT", RA.CAT_LIMITS, RA.SEVERITY_ERROR, "Step exceeds 255 chars",
                    string.format("V%d s%d: %d", vi, si, #step), true, function(sd)
                        local s = sd.versions[vi].steps[si]
                        local parts = {}
                        for part in s:gmatch("[^;]+") do parts[#parts + 1] = part end
                        if #parts > 1 then
                            sd.versions[vi].steps[si] = parts[1]
                            for p = 2, #parts do table.insert(sd.versions[vi].steps, si + p - 1, parts[p]) end
                            LogFix(n, "Split V" .. vi .. "s" .. si); return true
                        end
                        return "partial"
                    end)
            end
            if step ~= "" and (kp ~= "" or kr ~= "") then
                local c = #step + (kp ~= "" and #kp + 1 or 0) + (kr ~= "" and #kr + 1 or 0)
                if c > D.MAX_MACROTEXT_LENGTH then
                    I(issues, "LIMIT", RA.CAT_LIMITS, RA.SEVERITY_WARNING, "kp/kr overflow",
                        string.format("V%d s%d: %d", vi, si, c))
                end
            end
        end
        if kp ~= "" and MM and MM.stubs and MM.stubs[n] then
            local body = MM:BuildStubBody(D.BUTTON_PREFIX .. E:SanitizeName(n), kp, kr)
            local total, fitted, inKp = 0, 0, false
            for _ in kp:gmatch("[^\n]+") do total = total + 1 end
            for line in body:gmatch("[^\n]+") do
                if line:match("^#showtooltip") then inKp = true
                elseif line:match("^/click") then inKp = false
                elseif inKp then fitted = fitted + 1 end
            end
            if fitted < total then
                I(issues, "LIMIT", RA.CAT_LIMITS, RA.SEVERITY_WARNING, "kp lines trimmed",
                    string.format("V%d: %d/%d fit", vi, fitted, total), true, function(sd)
                        local v = sd.versions[vi]
                        local lines = {}
                        for line in (v.keyPress or ""):gmatch("[^\n]+") do lines[#lines + 1] = line end
                        while #lines > 0 do
                            v.keyPress = table.concat(lines, "\n")
                            local bd = MM:BuildStubBody(D.BUTTON_PREFIX .. E:SanitizeName(n), v.keyPress, v.keyRelease or "")
                            local tl, ft, ip = 0, 0, false
                            for _ in v.keyPress:gmatch("[^\n]+") do tl = tl + 1 end
                            for ln in bd:gmatch("[^\n]+") do
                                if ln:match("^#showtooltip") then ip = true
                                elseif ln:match("^/click") then ip = false
                                elseif ip then ft = ft + 1 end
                            end
                            if ft >= tl then break end
                            table.remove(lines)
                        end
                        LogFix(n, "Trimmed kp lines V" .. vi)
                        return #lines > 0 and true or "partial"
                    end)
            end
        end
    end
end

-- Cat 4: Variables
function RA:CheckVariables(seqData, issues)
    local n = RA._currentName
    local used = {}
    for _, ver in ipairs(seqData.versions or {}) do
        for _, step in ipairs(ver.steps or {}) do
            for vn in step:gmatch(D.VAR_PATTERN) do used[vn] = true end
        end
        if ver.keyPress then for vn in ver.keyPress:gmatch(D.VAR_PATTERN) do used[vn] = true end end
        if ver.keyRelease then for vn in ver.keyRelease:gmatch(D.VAR_PATTERN) do used[vn] = true end end
    end
    for vn in pairs(used) do
        local vd = VS:Get(vn)
        if not vd then
            I(issues, "VAR", RA.CAT_VARIABLES, RA.SEVERITY_ERROR, "Non-existent variable",
                "~" .. vn .. "~", true, function()
                    VS:Set(vn, { funct = "", events = "" }); LogFix(n, "Created " .. vn); return true
                end)
        else
            local valid, pErr = VS:ValidateFunction(vd.funct)
            if not valid then
                I(issues, "VAR", RA.CAT_VARIABLES, RA.SEVERITY_ERROR, "Parse error", vn .. ": " .. (pErr or "?"))
            end
            if VS:GetLocaleRisk(vn) then
                I(issues, "VAR", RA.CAT_VARIABLES, RA.SEVERITY_WARNING, "Locale risk",
                    vn .. " -> '" .. VS:GetLocaleRisk(vn).spellName .. "'")
            end
            if VS:Evaluate(vn) == "" then
                I(issues, "VAR", RA.CAT_VARIABLES, RA.SEVERITY_INFO, "Evaluates to empty", vn)
            end
        end
    end
    local deps = {}
    for vn in pairs(used) do
        deps[vn] = {}
        local vd = VS:Get(vn)
        if vd and vd.funct then for ref in vd.funct:gmatch(D.VAR_PATTERN) do deps[vn][ref] = true end end
    end
    local function hasCycle(vn, path)
        if path[vn] then return true end
        if not deps[vn] then return false end
        path[vn] = true
        for dep in pairs(deps[vn]) do if hasCycle(dep, path) then return true end end
        path[vn] = nil; return false
    end
    for vn in pairs(used) do
        if VS:Get(vn) and hasCycle(vn, {}) then
            I(issues, "VAR", RA.CAT_VARIABLES, RA.SEVERITY_ERROR, "Circular reference", vn)
        end
    end
end

-- Cat 5: Actions
local function WalkActions(actions, issues, vi, depth)
    if not actions then return end
    if depth > D.ACTION_MAX_DEPTH then
        I(issues, "ACT", RA.CAT_ACTIONS, RA.SEVERITY_ERROR, "Nesting exceeds max depth",
            string.format("V%d: depth %d (max %d)", vi, depth, D.ACTION_MAX_DEPTH))
        return
    end
    for _, node in ipairs(actions) do
        if node and node.type then
            if node.type == D.ACTION_TYPE_EMBED then
                if node.sequence and node.sequence ~= "" and E.sequences and not E.sequences[node.sequence] then
                    I(issues, "ACT", RA.CAT_ACTIONS, RA.SEVERITY_ERROR, "EMBED target missing",
                        "V" .. vi .. ": '" .. node.sequence .. "'")
                end
            elseif node.type == D.ACTION_TYPE_PAUSE then
                local c = node.clicks or 0
                if c < 1 or c > 100 then
                    I(issues, "ACT", RA.CAT_ACTIONS, RA.SEVERITY_WARNING, "Invalid PAUSE clicks",
                        string.format("V%d: %d", vi, c))
                end
            elseif node.type == D.ACTION_TYPE_LOOP then
                local r = node["repeat"] or 0
                if r < 1 or r > D.ACTION_LOOP_MAX_REPEAT then
                    I(issues, "ACT", RA.CAT_ACTIONS, RA.SEVERITY_ERROR, "Invalid LOOP count",
                        string.format("V%d: %d (max %d)", vi, r, D.ACTION_LOOP_MAX_REPEAT))
                end
            elseif node.type == D.ACTION_TYPE_ACTION then
                if node.macro == nil or node.macro == "" then
                    I(issues, "ACT", RA.CAT_ACTIONS, RA.SEVERITY_ERROR, "Empty action macro", "V" .. vi)
                end
            elseif node.type == D.ACTION_TYPE_IF then
                local tb = node.children and node.children[1] or {}
                local fb = node.children and node.children[2] or {}
                if node.variable == nil or node.variable == "" then
                    I(issues, "ACT", RA.CAT_ACTIONS, RA.SEVERITY_ERROR, "IF missing variable", "V" .. vi)
                end
                if #tb > 1 and #fb > 0 then
                    I(issues, "ACT", RA.CAT_ACTIONS, RA.SEVERITY_WARNING, "Complex IF false discarded", "V" .. vi)
                end
                WalkActions(tb, issues, vi, depth + 1)
                WalkActions(fb, issues, vi, depth + 1)
            end
        end
        if node and node.type and node.type ~= D.ACTION_TYPE_IF and node.children then
            WalkActions(node.children, issues, vi, depth + 1)
        end
    end
end

function RA:CheckActions(seqData, issues)
    for vi, ver in ipairs(seqData.versions or {}) do
        if ver.actions and type(ver.actions) == "table" and #ver.actions > 0 then
            local isValid, errors = AC.ValidateActions(ver.actions)
            if not isValid then
                for _, err in ipairs(errors) do
                    I(issues, "ACT", RA.CAT_ACTIONS, RA.SEVERITY_ERROR, "Action tree error", "V" .. vi .. ": " .. err)
                end
            end
            WalkActions(ver.actions, issues, vi, 1)
        end
    end
end

-- Cat 6: Stubs
function RA:CheckStubs(seqData, seqName, issues)
    if not MM then return end
    if MM.stubs[seqName] then
        local _, _, curBody = GetMacroInfo(MM.stubs[seqName])
        local ver = E:GetActiveVersion(seqData)
        if ver and curBody then
            local expected = MM:BuildStubBody(D.BUTTON_PREFIX .. E:SanitizeName(seqName), ver.keyPress, ver.keyRelease)
            if curBody ~= expected then
                I(issues, "STUB", RA.CAT_STUBS, RA.SEVERITY_WARNING, "Stub body out of sync",
                    "Macro body differs", true, StubFix(function(sd)
                        MM:DeleteStub(seqName)
                        local v = E:GetActiveVersion(sd)
                        MM:CreateStub(seqName, v and v.keyPress, v and v.keyRelease)
                        LogFix(seqName, "Recreated stub")
                    end, seqName))
            end
        end
    else
        I(issues, "STUB", RA.CAT_STUBS, RA.SEVERITY_INFO, "No macro stub", "No stub exists")
    end
end

-- Cat 7: Config
function RA:CheckConfig(seqData, issues)
    local n = RA._currentName
    for vi, ver in ipairs(seqData.versions or {}) do
        if ver.resetTimer and (ver.resetTimer < 0 or ver.resetTimer > 3600) then
            I(issues, "CFG", RA.CAT_CONFIG, RA.SEVERITY_WARNING, "resetTimer out of range",
                "V" .. vi .. ": " .. tostring(ver.resetTimer), true, function(sd)
                    sd.versions[vi].resetTimer = math.min(math.max(sd.versions[vi].resetTimer or 0, 0), 3600)
                    LogFix(n, "Clamped resetTimer V" .. vi); return true
                end)
        end
        if ver.resetModifiers and type(ver.resetModifiers) == "table" then
            for mod in pairs(ver.resetModifiers) do
                if D.MACRO_RESET_MODIFIER_DEFAULTS[mod] == nil then
                    I(issues, "CFG", RA.CAT_CONFIG, RA.SEVERITY_WARNING, "Invalid reset modifier", "V" .. vi .. ": " .. tostring(mod))
                end
            end
        end
        if ver.resetOnSpec and seqData.specID then
            I(issues, "CFG", RA.CAT_CONFIG, RA.SEVERITY_INFO, "resetOnSpec on spec-locked", "V" .. vi)
        end
    end
end

-- Cat 8: Locale
function RA:CheckLocale(seqData, issues)
    local n, loc = RA._currentName, GetLocale()
    for vi, ver in ipairs(seqData.versions or {}) do
        if ver.taggedSteps then
            if ver.stepsLocale and ver.stepsLocale ~= loc then
                I(issues, "LOC", RA.CAT_LOCALE, RA.SEVERITY_WARNING, "Locale mismatch",
                    string.format("V%d: %s vs %s", vi, ver.stepsLocale, loc), true,
                    function() E:HealLocaleSteps(); LogFix(n, "Healed locale"); return true end)
            end
            if ver.steps and #ver.taggedSteps ~= #ver.steps then
                I(issues, "LOC", RA.CAT_LOCALE, RA.SEVERITY_ERROR, "taggedSteps count mismatch",
                    string.format("V%d: %d vs %d", vi, #ver.taggedSteps, #ver.steps), true,
                    function(sd) sd.versions[vi].taggedSteps = nil; sd.versions[vi].stepsLocale = nil; LogFix(n, "Cleared V" .. vi); return true end)
            end
        elseif ver.steps and #ver.steps > 0 then
            I(issues, "LOC", RA.CAT_LOCALE, RA.SEVERITY_INFO, "Missing taggedSteps", "V" .. vi)
        end
    end
end

-- Cat 9: Readiness
function RA:CheckReadiness(seqData, seqName, issues)
    local hasBind = KM and KM:GetKeybind(seqName) ~= nil
    local hasStub = MM and MM.stubs[seqName] ~= nil
    if not hasBind and not hasStub then
        I(issues, "RDY", RA.CAT_READINESS, RA.SEVERITY_CRITICAL, "No keybind and no stub",
            "Sequence cannot fire", true, StubFix(function(sd)
                local v = E:GetActiveVersion(sd)
                MM:CreateStub(seqName, v and v.keyPress, v and v.keyRelease)
                LogFix(seqName, "Created stub")
            end, seqName))
    elseif not hasBind and hasStub then
        local anyBind = false
        if _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.keybinds then
            for _, binds in pairs(GRIP_EMS_CHAR.keybinds) do
                for _, bs in pairs(binds) do
                    if bs == seqName then anyBind = true; break end
                end
                if anyBind then break end
            end
        end
        if anyBind then
            I(issues, "RDY", RA.CAT_READINESS, RA.SEVERITY_WARNING, "Keybind on different spec",
                "Bind exists but not for current spec")
        end
    end
    local castPat, usePat = "/[Cc][Aa][Ss][Tt]%s", "/[Uu][Ss][Ee]%s"
    for vi, ver in ipairs(seqData.versions or {}) do
        local steps = ver.steps or {}
        if #steps == 0 then
            for _, fld in ipairs({ "keyPress", "keyRelease" }) do
                local txt = ver[fld]
                if txt and (txt:match(castPat) or txt:match(usePat)) then
                    I(issues, "RDY", RA.CAT_READINESS, RA.SEVERITY_ERROR, "Content in " .. fld .. " not steps",
                        "V" .. vi, true, function(sd)
                            sd.versions[vi].steps[1] = sd.versions[vi][fld]; sd.versions[vi][fld] = ""
                            LogFix(seqName, "Moved " .. fld .. "->step V" .. vi); return true
                        end)
                end
            end
        elseif #steps > 0 then
            local allEmpty = true
            for _, step in ipairs(steps) do if step:match("%S") then allEmpty = false; break end end
            if allEmpty then
                I(issues, "RDY", RA.CAT_READINESS, RA.SEVERITY_ERROR, "All steps empty",
                    "V" .. vi, true, function(sd)
                        local cl = {}
                        for _, step in ipairs(sd.versions[vi].steps) do
                            if step:match("%S") then cl[#cl + 1] = step end
                        end
                        sd.versions[vi].steps = cl; LogFix(seqName, "Cleaned V" .. vi); return true
                    end)
            end
        end
    end
    if #seqData.versions == 1 then
        local ver = seqData.versions[1]
        if (not ver.steps or #ver.steps == 0) and
           (ver.keyPress == "/stopmacro [channeling]" or ver.keyPress == "" or ver.keyPress == nil) then
            I(issues, "RDY", RA.CAT_READINESS, RA.SEVERITY_CRITICAL, "Unedited template", "Only version empty/default")
        end
    end
    if S and S:GetEffectiveClickRate() == 0 then
        I(issues, "RDY", RA.CAT_READINESS, RA.SEVERITY_ERROR, "Click rate is 0", "Nothing will fire", true,
            function() S:SetCharClickRate(0); S:Set("msClickRate", 250); LogFix(seqName, "Reset click rate"); return true end)
    end
    local _, _, pCID = UnitClass("player")
    if seqData.classID and pCID and seqData.classID ~= pCID then
        I(issues, "RDY", RA.CAT_READINESS, RA.SEVERITY_WARNING, "Class mismatch",
            "seq=" .. seqData.classID .. " player=" .. pCID)
    end
end

-- Cat 10: Post-Substitution
function RA:CheckPostSub(seqData, issues)
    for vi, ver in ipairs(seqData.versions or {}) do
        for si, step in ipairs(ver.steps or {}) do
            if step:match(D.VAR_PATTERN) then
                local resolved = E:SubstituteVariables(step)
                if #resolved > D.MAX_MACROTEXT_LENGTH then
                    I(issues, "PSUB", RA.CAT_POST_SUB, RA.SEVERITY_CRITICAL, "Post-sub overflow",
                        string.format("V%d s%d: %d chars", vi, si, #resolved))
                end
                for vn in step:gmatch(D.VAR_PATTERN) do
                    if VS:GetLocaleRisk(vn) then
                        I(issues, "PSUB", RA.CAT_POST_SUB, RA.SEVERITY_WARNING, "Post-sub locale risk",
                            string.format("V%d s%d: ~%s~ resolves spell '%s'", vi, si, vn, VS:GetLocaleRisk(vn).spellName))
                    end
                end
            end
        end
    end
end

-- Cat 11: State Sync
function RA:CheckStateSync(seqData, seqName, issues)
    local SE = GRIPEMS.SequenceEditor
    if SE and SE.currentSequence == seqName then
        I(issues, "SYNC", RA.CAT_STATE_SYNC, RA.SEVERITY_ERROR, "Open in editor", "May conflict with repair")
    end
    local PE = GRIPEMS.PopupEditor
    if PE and PE.pool then
        for _, inst in ipairs(PE.pool) do
            if inst.seqName == seqName and inst.frame and inst.frame:IsShown() then
                I(issues, "SYNC", RA.CAT_STATE_SYNC, RA.SEVERITY_WARNING, "Popup editor open", "Shows this sequence")
                break
            end
        end
    end
    local TH = GRIPEMS.TrackerHUD
    if TH and TH.activeSeqName == seqName then
        I(issues, "SYNC", RA.CAT_STATE_SYNC, RA.SEVERITY_WARNING, "Active in TrackerHUD", "HUD tracking this sequence")
    end
    if SE and SE.currentSequence == seqName then
        I(issues, "SYNC", RA.CAT_STATE_SYNC, RA.SEVERITY_WARNING, "UndoStack may be stale",
            "Destructive repair invalidates undo closures")
    end
    local hasVars = false
    for _, ver in ipairs(seqData.versions or {}) do
        for _, step in ipairs(ver.steps or {}) do
            if step:match(D.VAR_PATTERN) then hasVars = true; break end
        end
        if hasVars then break end
        if ver.keyPress and ver.keyPress:match(D.VAR_PATTERN) then hasVars = true end
        if ver.keyRelease and ver.keyRelease:match(D.VAR_PATTERN) then hasVars = true end
    end
    if hasVars and VS then
        I(issues, "SYNC", RA.CAT_STATE_SYNC, RA.SEVERITY_WARNING, "VS cache active",
            "Variable fixes require cache invalidation")
    end
end

-- Cat 12: Cross-Sequence (AnalyzeAll only)
function RA:CheckCrossSeq(allIssues)
    if not E or not E.sequences then return end
    local function groupBy(keyFn)
        local map = {}
        for sn in pairs(E.sequences) do
            local k = keyFn(sn)
            map[k] = map[k] or {}
            map[k][#map[k] + 1] = sn
        end
        return map
    end
    -- Stub name truncation collisions
    for _, names in pairs(groupBy(function(sn) return MM:TruncateName(sn) end)) do
        if #names > 1 then
            local d = table.concat(names, ", ")
            for _, sn in ipairs(names) do
                allIssues[sn] = allIssues[sn] or {}
                I(allIssues[sn], "XSEQ", RA.CAT_CROSS_SEQ, RA.SEVERITY_ERROR, "Stub name collision", d)
            end
        end
    end
    -- Case-insensitive duplicate names
    for _, names in pairs(groupBy(function(sn) return strlower(sn) end)) do
        if #names > 1 then
            local d = table.concat(names, ", ")
            for _, sn in ipairs(names) do
                allIssues[sn] = allIssues[sn] or {}
                I(allIssues[sn], "XSEQ", RA.CAT_CROSS_SEQ, RA.SEVERITY_WARNING, "Duplicate name (case)", d)
            end
        end
    end
    -- Orphaned stubs
    for stubSeq in pairs(MM.stubs) do
        if not E.sequences[stubSeq] then
            allIssues[stubSeq] = allIssues[stubSeq] or {}
            I(allIssues[stubSeq], "XSEQ", RA.CAT_CROSS_SEQ, RA.SEVERITY_WARNING, "Orphaned macro stub",
                "Sequence deleted", true, StubFix(function()
                    MM:DeleteStub(stubSeq); LogFix(stubSeq, "Deleted orphaned stub")
                end, stubSeq))
        end
    end
    -- Broken EMBED chains (recursive)
    local function scanEmbeds(actions, owner, visited)
        if not actions then return end
        for _, node in ipairs(actions) do
            if node and node.type == D.ACTION_TYPE_EMBED and node.sequence then
                if not E.sequences[node.sequence] then
                    allIssues[owner] = allIssues[owner] or {}
                    I(allIssues[owner], "XSEQ", RA.CAT_CROSS_SEQ, RA.SEVERITY_ERROR,
                        "Broken EMBED chain", "'" .. node.sequence .. "' missing")
                elseif not visited[node.sequence] then
                    visited[node.sequence] = true
                    local t = E.sequences[node.sequence]
                    if t and t.data then
                        for _, tv in ipairs(t.data.versions or {}) do
                            if tv.actions then scanEmbeds(tv.actions, owner, visited) end
                        end
                    end
                end
            end
            if node and node.children then
                if node.type == D.ACTION_TYPE_IF then
                    scanEmbeds(node.children[1] or {}, owner, visited)
                    scanEmbeds(node.children[2] or {}, owner, visited)
                else
                    scanEmbeds(node.children, owner, visited)
                end
            end
        end
    end
    for sn, entry in pairs(E.sequences) do
        if entry.data then
            for _, ver in ipairs(entry.data.versions or {}) do
                if ver.actions then scanEmbeds(ver.actions, sn, { [sn] = true }) end
            end
        end
    end
    -- Variables referenced by multiple seqs but missing from store
    local varRefs = {}
    for sn, entry in pairs(E.sequences) do
        if entry.data then
            for _, ver in ipairs(entry.data.versions or {}) do
                for _, step in ipairs(ver.steps or {}) do
                    for vn in step:gmatch(D.VAR_PATTERN) do
                        varRefs[vn] = varRefs[vn] or {}
                        varRefs[vn][sn] = true
                    end
                end
                if ver.keyPress then
                    for vn in ver.keyPress:gmatch(D.VAR_PATTERN) do
                        varRefs[vn] = varRefs[vn] or {}
                        varRefs[vn][sn] = true
                    end
                end
                if ver.keyRelease then
                    for vn in ver.keyRelease:gmatch(D.VAR_PATTERN) do
                        varRefs[vn] = varRefs[vn] or {}
                        varRefs[vn][sn] = true
                    end
                end
            end
        end
    end
    for vn, seqs in pairs(varRefs) do
        if not VS:Get(vn) then
            local names = {}
            for sn in pairs(seqs) do names[#names + 1] = sn end
            if #names > 1 then
                for _, sn in ipairs(names) do
                    allIssues[sn] = allIssues[sn] or {}
                    I(allIssues[sn], "XSEQ", RA.CAT_CROSS_SEQ, RA.SEVERITY_ERROR,
                        "Shared variable deleted", "~" .. vn .. "~ used by " .. #names .. " seqs")
                end
            end
        end
    end
end

-- Cat 13: Concurrent
function RA:CheckConcurrent(issues)
    if InCombatLockdown() then
        I(issues, "CONC", RA.CAT_CONCURRENT, RA.SEVERITY_WARNING, "In combat lockdown", "Stub fixes queued")
    end
    local RF = GRIPEMS.RepairFrame
    if RF and RF.frame and RF.frame:IsShown() then
        I(issues, "CONC", RA.CAT_CONCURRENT, RA.SEVERITY_ERROR, "RepairFrame already open", "Another session active")
    end
    local OQ = GRIPEMS.OOCQueue
    if OQ and OQ:GetCount() > 0 then
        I(issues, "CONC", RA.CAT_CONCURRENT, RA.SEVERITY_WARNING, "Queued OOC repairs pending",
            "Don't /reload until queued repairs complete (" .. OQ:GetCount() .. " pending)")
    end
end

-- Public API
function RA:Analyze(seqData, seqName, opts)
    ResolveDeps()
    ResetIDs()
    self._currentName = seqName or ""
    local issues = {}
    self:CheckSpells(seqData, issues)
    self:CheckStructure(seqData, issues)
    self:CheckLimits(seqData, issues)
    self:CheckVariables(seqData, issues)
    self:CheckActions(seqData, issues)
    self:CheckStubs(seqData, seqName, issues)
    self:CheckConfig(seqData, issues)
    self:CheckLocale(seqData, issues)
    self:CheckReadiness(seqData, seqName, issues)
    self:CheckPostSub(seqData, issues)
    if not (opts and opts.fromRepairFrame) then
        self:CheckStateSync(seqData, seqName, issues)
        self:CheckConcurrent(issues)
    end
    table.sort(issues, function(a, b)
        return (SEVERITY_ORDER[a.severity] or 99) < (SEVERITY_ORDER[b.severity] or 99)
    end)
    return issues
end

function RA:AnalyzeAll()
    ResolveDeps()
    if not E or not E.sequences then return {} end
    local allIssues = {}
    for seqName, entry in pairs(E.sequences) do
        if entry.data then allIssues[seqName] = self:Analyze(entry.data, seqName) end
    end
    ResetIDs()
    self:CheckCrossSeq(allIssues)
    for _, issues in pairs(allIssues) do
        table.sort(issues, function(a, b)
            return (SEVERITY_ORDER[a.severity] or 99) < (SEVERITY_ORDER[b.severity] or 99)
        end)
    end
    return allIssues
end

function RA:ComputeHealthScore(issues)
    if not issues or #issues == 0 then return 100 end
    local penalty = 0
    for _, issue in ipairs(issues) do
        local sev = issue.severity
        if sev == RA.SEVERITY_CRITICAL then penalty = penalty + 30
        elseif sev == RA.SEVERITY_ERROR then penalty = penalty + 10
        elseif sev == RA.SEVERITY_WARNING then penalty = penalty + 3
        elseif sev == RA.SEVERITY_INFO then penalty = penalty + 1 end
    end
    return math.max(0, 100 - penalty)
end
