-- GRIP-EMS: Settings
-- Created: 2025 (pre-stamping)
-- Updated: 2026-06-23
-- Patch: 12.0.7.68275 Midnight (Retail LIVE)
-- AceDB-3.0 profile-based settings with migration from legacy storage

local ADDON_NAME, GRIPEMS = ...

GRIPEMS.Settings = {}
local S = GRIPEMS.Settings
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

-- AceDB defaults (profile-scoped)
S.defaults = {
    profile = {
        oocDelay = 7, -- seconds for OOC fallback ticker (1-60)
        resetOOC = true, -- default resetOnCombat for new sequences
        autoReloadAtCombatEnd = true, -- IC-VAR-03: ON drains OOCQueue at combat end + restriction lift + ticker. OFF requires manual /gems apply.
        showVariantsTab = false, -- IC-VAR-02 Phase 2: D.SETTINGS_SHOW_VARIANTS_TAB_DEFAULT. Hidden by default; user opts in to see the Variants subtab in SequenceEditor.
        debug = false, -- debug logging to chat
        hideLoginMsg = false, -- suppress login banner
        showUnresolvedSpellWarnings = false, -- chat notice for unresolved spell names (off by default; per-name once per session when on)
        p2pEnabled = true, -- enable/disable P2P transmission
        p2pAutoAcceptFriends = false, -- auto-import from friends (no prompt)
        p2pAnnounceReceive = true, -- print chat message on receive
        trackerShowMode = "NEVER", -- ALWAYS, COMBAT, TARGET, NEVER
        trackerIconSize = 40, -- icon pixel size (20-80)
        trackerOrientation = "HORIZONTAL", -- HORIZONTAL or VERTICAL
        trackerShowName = true, -- show sequence name below icon
        trackerShowModifiers = false, -- show active modifier keys
        trackerLocked = false, -- lock tracker frame position
        trackerScale = 1.0, -- HUD frame scale (0.5-2.0)
        trackerVariantIndicators = true, -- IC-VAR-08: show per-variant indicator strip in TrackerHUD
        barVariantIndicators = true, -- IC-VAR-08: extend BarIntegration overlays to per-variant indicators
        listSortMode = "alpha", -- sequence list sort: alpha, class, updated
        listCurrentClassOnly = false, -- sequence list filter: show only current-class + class-neutral sequences (opt-in)
        previewMode = "icons", -- rotation preview: icons or text
        uiLayout = "classic", -- Plugin API Tier 3 layout provider id: "classic" (default) or "modern"
        msClickRate = 250, -- minimum ms between key presses
        sqwOptimizerEnabled = false, -- dynamic SQW optimizer toggle
        sqwBuffer = 100, -- SQW optimizer safety buffer (ms)
        sqwShowAdvisory = true, -- show SQW click rate advisory
        mythicPlusTierMid = 8, -- M+ key level: Low -> Mid threshold
        mythicPlusTierHigh = 12, -- M+ key level: Mid -> High threshold
        delvesTierHigh = 5, -- Delve tier: Low -> High threshold
        macroResetModifiers = {}, -- empty = all false (defaults from D.MACRO_RESET_MODIFIER_DEFAULTS)
        autoFixCVars = false, -- auto-set recommended CVars on login
        cvarAutoFixEntries = {}, -- per-CVar auto-fix opt-in: {["CvarName"] = true}
        cvarSnapshot = {}, -- last-known CVar values for What Changed detection
        cvarSnapshotBuild = nil, -- WoW interface build at last snapshot (G14: PATCH cause heuristic input)
        cvarPreviousValues = {}, -- per-CVar previous value cache (G7 Undo): {[cvarName] = previousValueString}
        cvarRedoValues = {}, -- per-CVar redo value cache (G.3a-OPTION-B): {[cvarName] = preUndoValueString} -- mirrors cvarPreviousValues, captures live value at Undo time so user can Redo back to it
        cvarPinned = {}, -- per-CVar Pin My Choice flag (G17): {[cvarName] = true} marks intentional user override
        cvarSectionCollapsed = {}, -- collapsed state per section key
        cvarProfiles = {}, -- custom user-created CVar profiles
        cvarProfileMap = {}, -- user overrides: {[contextKey] = profileKey}
        cvarAutoSwitchEnabled = false, -- master toggle for context auto-switching
        cvarActiveProfile = nil, -- currently active profile key (nil = General)
        cvarManualOverride = false, -- true if user manually selected a profile
        cvarSessionChangeNotice = false, -- chat notice for the 5-min in-session CVar-change detection (default off; What Changed button + /gems cvar changes still surface them)
        macroRefAutoRefresh = false, -- opt-in: auto-pull a macro-reference step's body when its source /macro changes (provenance-guarded; never clobbers imported or in-editor bodies)
        syntaxCommandColor = { 0.306, 0.788, 0.690 }, -- #4EC9B0 teal
        syntaxConditionalColor = { 0.773, 0.525, 0.753 }, -- #C586C0 purple
        syntaxVariableColor = { 0.863, 0.863, 0.667 }, -- #DCDCAA gold
        syntaxCommentColor = { 0.416, 0.600, 0.333 }, -- #6A9955 green-grey
        syntaxResetColor = { 0.808, 0.569, 0.471 }, -- #CE9178 orange
        syntaxNumberColor = { 0.710, 0.808, 0.659 }, -- #B5CEA8 light green
        recorderDedup = false, -- deduplicate consecutive identical casts
        floatingMenuShow = false,
        floatingMenuDirection = "DOWN",
        floatingMenuLocked = false,
        floatingMenuScale = 1.0,
        spellOverrides = {},
        contextGroupCollapsed = {}, -- collapsed state per context group header
        barIntegration = true, -- show sequence icons on action bar buttons
        tempoAutoSet = true, -- auto-adjust click rate per sequence
        tempoAlertEnabled = false, -- mismatch alerts off by default
        tempoAlertVisual = true, -- visual alerts when alerts enabled
        tempoAlertAudio = true, -- audio alerts when alerts enabled
        tempoAlertSoundSlow = 43505, -- Raid Warning
        tempoAlertSoundFast = 37666, -- Toast Notification
        tempoAlertChannel = "Master", -- audio channel for alerts
        tempoAlertSlowThreshold = 0.6, -- slow CPS threshold ratio
        tempoAlertFastThreshold = 2.0, -- fast CPS threshold ratio
        tempoSparkline = false, -- CPS sparkline off by default
        tempoOverlayShown = false, -- popout overlay hidden by default
        tempoOverlay = {
            position = { point = "TOPRIGHT", relPoint = "TOPRIGHT", x = -200, y = -200 },
        },
        tempoAdvisorDebug = false, -- TA verbose debug output
        sqwDebug = false, -- SQW optimizer debug output
        holdModeEnabled = false, -- master toggle for hold-to-cast mode
        holdModeSlot = "MultiBar7Button12", -- native button to hijack
        holdModePollRateMin = 50, -- ms floor for poll rate CVar
        mainFrame = {
            size = { width = 800, height = 500 },
        },
        contrastPreset = "auto", -- color palette: auto, Default, HighContrast, DeuteranopiaSafe
        contrastSilence = {}, -- [class] = GetServerTime() expiry epoch for contrast-warning dismissals
        accessibility = {
            reduceMotion = false,
            flickerSafe = false, -- photosensitivity damping; mirrors screenEdgeFlash CVar
            speechEnabled = false,
            speechRate = 0,
            speechVolume = 100,
            speechFirstEnableShown = false,
            tutorialSeen = false,
            accessibilityPresetOn = false,
            editorScale = 1.0,
            fontName = "Friz Quadrata TT", -- LSM font key; default matches Blizz UI font
            chatEmitterEnabled = false,
            chatEmitterFrame = 9,
            bgOpacity = 1.0,
            borderOpacity = 1.0,
            panelAlpha = 1.0,
            overlayAlpha = 1.0,
            uiScale = 1.0,
            colorblindType = "none", -- CVD type: none / protanomaly / protanopia /
            --   deuteranomaly / deuteranopia / tritanomaly /
            --   tritanopia / achromatomaly / achromatopsia
            colorblindStrength = 1.0, -- 0.0-1.0 float; displayed as 0-100 percent in UI.
            --   Zero or type=="none" = identity (no color shift).
            soundCuesEnabled = false,
            soundCuesVisualComplement = false, -- Deaf/HoH visual flash alongside the sound cue
            soundCuesChannel = "Master", -- legacy global channel; orphaned post Phase 4 item 22 Phase 2
            soundCueError = "GRIPEMS Error",
            soundCueSuccess = "GRIPEMS Success",
            soundCueInfo = "GRIPEMS Info",
            soundCueStepComplete = "GRIPEMS Step Complete",
            -- Per-cue channel routing (Phase 4 item 22 Phase 2)
            soundCueErrorChannel = "Master",
            soundCueSuccessChannel = "Master",
            soundCueInfoChannel = "Master",
            soundCueStepCompleteChannel = "Master",
            _soundCueChannelMigrated = false, -- one-shot migration gate; copies legacy soundCuesChannel into the four per-cue keys

            migratedEditorScaleToUiScale = false,
            cursorOverlayEnabled = false,
            cursorOverlayMode = "ring",
            cursorOverlaySize = 1.5,
            density = "normal", -- "normal" | "large" -- A11Y-DEFER-14 large-target mode
            simplifiedMode = false, -- bool master toggle. Profile-scoped.
            simplifiedDelay = 500, -- ms. Post-acceptance delay. Range 250..1500.
            simplifiedToastShown = false, -- bool. Session-scoped. Reset on /reload.
            _accessibilityPresetSimplifiedSnapshot = nil, -- table or nil. Internal. Pre-preset state.
        },
    },
    global = {
        cvarFirstRunMirrorDone = false,
        cvarHealthOnboardingShown = false, -- G22 first-run onboarding popup gate (true once user has seen it). Migrated from profile-scope 2026-05-18 (was re-firing on new profile creation).
        cvarScoreHistory = {}, -- health-score ring buffer, cap 60, oldest first; { t = server epoch, s = score, c = character }. Account-global: the score is machine-state, not per-profile.
    },
}

--- Initialize the AceDB instance and migrate legacy settings.
--- Called from Core.lua ADDON_LOADED after raw SavedVariables init.
function S:Initialize()
    local ok, db = pcall(function()
        return LibStub("AceDB-3.0"):New("GRIP_EMS_Settings", self.defaults, true)
    end)
    if not ok or not db then
        GRIPEMS:Debug("Settings: AceDB init failed -- using defaults only")
        return
    end
    self.db = db

    -- Migration: debug flag from per-char config
    if
        _G.GRIP_EMS_CHAR
        and GRIP_EMS_CHAR.config
        and GRIP_EMS_CHAR.config.debug == true
        and self.db.profile.debug == false
    then
        self.db.profile.debug = true
    end
    if _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.config then
        GRIP_EMS_CHAR.config = nil
    end

    -- Migration: legacy GRIP_EMS_DB.settings (previous dev builds)
    if _G.GRIP_EMS_DB and GRIP_EMS_DB.settings then
        for k, v in pairs(GRIP_EMS_DB.settings) do
            if self.defaults.profile[k] ~= nil then
                self.db.profile[k] = v
            end
        end
        GRIP_EMS_DB.settings = nil
    end

    -- One-shot migration: copy legacy global accessibility.soundCuesChannel into
    -- the four per-cue channel keys when the profile predates Phase 4 item 22 Phase 2.
    -- Runs only once per profile; gate flag _soundCueChannelMigrated prevents replays.
    -- Idempotent: re-running the migration is a no-op once the gate is set, so future
    -- schema bumps do not re-trigger it. Only copies into per-cue keys still at the
    -- "Master" default so a player who already customized a per-cue key keeps their value.
    local accessibility = self.db.profile.accessibility
    if accessibility and not accessibility._soundCueChannelMigrated then
        local legacy = accessibility.soundCuesChannel
        if legacy and legacy ~= "Master" then
            if accessibility.soundCueErrorChannel == "Master" then
                accessibility.soundCueErrorChannel = legacy
            end
            if accessibility.soundCueSuccessChannel == "Master" then
                accessibility.soundCueSuccessChannel = legacy
            end
            if accessibility.soundCueInfoChannel == "Master" then
                accessibility.soundCueInfoChannel = legacy
            end
            if accessibility.soundCueStepCompleteChannel == "Master" then
                accessibility.soundCueStepCompleteChannel = legacy
            end
        end
        accessibility._soundCueChannelMigrated = true
    end

    -- Register profile callbacks so UI updates on profile switch
    self.db.RegisterCallback(self, "OnProfileChanged", "OnProfileChanged")
    self.db.RegisterCallback(self, "OnProfileCopied", "OnProfileChanged")
    self.db.RegisterCallback(self, "OnProfileReset", "OnProfileChanged")
end

--- Callback for profile switch/copy/reset. Fires SETTING_CHANGED for all keys.
function S:OnProfileChanged()
    if not GRIPEMS.Fire then
        return
    end
    for key in pairs(self.defaults.profile) do
        GRIPEMS:Fire("SETTING_CHANGED", key, self:Get(key))
    end
    -- holdToFreeze is not a defaults.profile key, so the fan-out above does not
    -- cover it. Re-arm freeze explicitly on profile switch (RearmFreezeAll is
    -- OOC-gated, so this is combat-safe).
    if GRIPEMS.Engine and GRIPEMS.Engine.RearmFreezeAll then
        GRIPEMS.Engine:RearmFreezeAll()
    end
end

--- Get a setting value from the active profile, with defaults fallback.
--- @param key string Setting key
--- @return any value
function S:Get(key)
    if self.db and self.db.profile[key] ~= nil then
        return self.db.profile[key]
    end
    return self.defaults.profile[key]
end

--- Set a setting value in the active profile and fire a callback.
--- @param key string Setting key
--- @param value any New value
function S:Set(key, value)
    if self.db then
        self.db.profile[key] = value
    end
    if GRIPEMS.Fire then
        GRIPEMS:Fire("SETTING_CHANGED", key, value)
    end
end

--- Get the AceDB instance (used by SettingsPanel for AceDBOptions).
--- @return table AceDB instance
function S:GetDB()
    return self.db
end

--- Get the effective click rate: TA auto-set, per-character override, then profile default.
--- @return number Click rate in milliseconds
function S:GetEffectiveClickRate()
    -- Faster, Slower auto-set: use TempoAdvisor recommendation for active sequence
    if self:Get("tempoAutoSet") and GRIPEMS.TempoAdvisor then
        local ta = GRIPEMS.TempoAdvisor
        local eng = GRIPEMS.Engine
        local activeSeq = eng and eng._lastClickedSequence
        if activeSeq then
            local rec = ta:GetRecommendation(activeSeq)
            if rec and rec.blendedMs then
                return rec.blendedMs
            elseif rec and rec.recommendedMs then
                return rec.recommendedMs
            end
        end
    end
    -- Per-character override
    if _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.msClickRate and GRIP_EMS_CHAR.msClickRate > 0 then
        return GRIP_EMS_CHAR.msClickRate
    end
    return self:Get("msClickRate")
end

--- Set per-character click rate override.
--- @param value number Click rate in ms (0 = use global)
function S:SetCharClickRate(value)
    if not _G.GRIP_EMS_CHAR then
        _G.GRIP_EMS_CHAR = {}
    end
    GRIP_EMS_CHAR.msClickRate = value
    if GRIPEMS.Fire then
        GRIPEMS:Fire("SETTING_CHANGED", "msClickRate", value)
    end
end

--- Get merged reset modifier table (defaults + profile overrides).
--- @return table Modifier name -> boolean
function S:GetResetModifiers()
    local D = GRIPEMS.Defaults
    local result = {}
    for mod, default in pairs(D.MACRO_RESET_MODIFIER_DEFAULTS) do
        result[mod] = default
    end
    local saved = self:Get("macroResetModifiers")
    if saved and type(saved) == "table" then
        for mod, enabled in pairs(saved) do
            result[mod] = enabled
        end
    end
    return result
end

--- Set a single reset modifier and persist.
--- @param modifier string Modifier key name
--- @param enabled boolean Whether enabled
function S:SetResetModifier(modifier, enabled)
    local current = self:Get("macroResetModifiers")
    if not current or type(current) ~= "table" then
        current = {}
    end
    current[modifier] = enabled
    self:Set("macroResetModifiers", current)
end

--- Get merged hold-to-freeze settings (D.HOLD_TO_FREEZE_DEFAULTS + saved overrides).
--- Mirrors GetResetModifiers: default-merge over the saved "holdToFreeze" table.
--- @return table { enabled = boolean, modifier = string }
function S:GetHoldToFreeze()
    local D = GRIPEMS.Defaults
    local result = {
        enabled = D.HOLD_TO_FREEZE_DEFAULTS.enabled,
        modifier = D.HOLD_TO_FREEZE_DEFAULTS.modifier,
    }
    local saved = self:Get("holdToFreeze")
    if type(saved) == "table" then
        if saved.enabled ~= nil then
            result.enabled = saved.enabled
        end
        if saved.modifier ~= nil then
            result.modifier = saved.modifier
        end
    end
    return result
end

--- Set hold-to-freeze settings and re-arm live buttons. Persists with the same
--- self:Set accessor SetResetModifier uses. nil args leave that field unchanged.
--- @param enabled boolean|nil New enabled state (nil = leave unchanged)
--- @param modifier string|nil New freeze modifier "shift"|"ctrl"|"alt" (nil = unchanged)
function S:SetHoldToFreeze(enabled, modifier)
    local cur = self:Get("holdToFreeze") or {}
    if enabled ~= nil then
        cur.enabled = enabled and true or false
    end
    if modifier ~= nil then
        cur.modifier = modifier
    end
    self:Set("holdToFreeze", cur)
    if GRIPEMS.Engine and GRIPEMS.Engine.RearmFreezeAll then
        GRIPEMS.Engine:RearmFreezeAll()
    end
end

--- Inform the player when the freeze modifier overlaps a reset modifier or a
--- sequence variant modifier. Informational only -- never blocks or changes the
--- setting. Freeze and those features coexist with defined precedence: freeze wins
--- over reset while the modifier is held, and a matching per-sequence variant wins
--- over freeze for that one sequence.
function S:WarnFreezeConflicts()
    local htf = self:GetHoldToFreeze()
    if not htf.enabled then
        return
    end
    local fm = htf.modifier
    local fmLabel = L["GEMS_HOLD_FREEZE_MOD_" .. fm:upper()] or fm
    -- Reset-modifier overlap. Map the freeze modifier to the reset-mod keys that
    -- share that physical modifier (plus AnyMod, which matches all).
    local resetKeys = {
        shift = { "Shift", "LeftShift", "RightShift" },
        ctrl = { "Control", "LeftControl", "RightControl" },
        alt = { "Alt", "LeftAlt", "RightAlt" },
    }
    local rmods = self:GetResetModifiers()
    local hitReset = rmods.AnyMod or false
    for _, k in ipairs(resetKeys[fm] or {}) do
        if rmods[k] then
            hitReset = true
        end
    end
    if hitReset then
        GRIPEMS:Print(string.format(L["GEMS_HOLD_FREEZE_CONFLICT_RESET"], fmLabel))
    end
    -- Variant overlap (per sequence). Variants live on the active version.
    local eng = GRIPEMS.Engine
    if eng and eng.sequences then
        for name, entry in pairs(eng.sequences) do
            local ver = entry.data and eng:GetActiveVersion(entry.data)
            local ovs = ver and ver.variantOverrides
            if ovs then
                for _, ov in ipairs(ovs) do
                    if ov.modifier == fm then
                        GRIPEMS:Print(string.format(L["GEMS_HOLD_FREEZE_CONFLICT_VARIANT"], tostring(name), fmLabel))
                        break
                    end
                end
            end
        end
    end
end
