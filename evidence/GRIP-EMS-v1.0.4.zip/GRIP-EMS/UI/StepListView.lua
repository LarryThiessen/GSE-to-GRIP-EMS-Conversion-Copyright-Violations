-- GRIP-EMS: Step List View
-- Editable step list with ScrollBox, action buttons, and per-step EditBox

local ADDON_NAME, GRIPEMS = ...
local UI = GRIPEMS.UI
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS")

-- Upvalue accessor for Defaults
local function D() return GRIPEMS.Defaults end

GRIPEMS.StepListView = {}
local SLV = GRIPEMS.StepListView

-- Runtime state
SLV.workingSteps = {}
SLV.originalSteps = {}
SLV.selectedIndex = nil
SLV._lastLineCount = 0

-- Debug: when true, RefreshCurrentRow is skipped (flicker diagnostic)
local debugSkipRowRefresh = false

---------------------------------------------------------------------------
-- Tab-press autocomplete helpers
---------------------------------------------------------------------------

--- Extract the word under the cursor from an EditBox.
--- Walks back from cursor to the nearest word boundary (space, newline, or
--- start of string). "/" and "#" are NOT boundaries (macro command prefixes).
--- @param editBox EditBox The EditBox to read
--- @return string word The extracted word
--- @return number wordStart Start position of the word (1-based)
--- @return number cursorPos Cursor position
local function extractWordUnderCursor(editBox)
    local text = editBox:GetText() or ""
    local cursorPos = editBox:GetCursorPosition()
    local wordStart = cursorPos
    while wordStart > 0 do
        local ch = text:sub(wordStart, wordStart)
        if ch == " " or ch == "\n" then
            wordStart = wordStart + 1
            break
        end
        wordStart = wordStart - 1
    end
    if wordStart <= 0 then wordStart = 1 end
    local word = text:sub(wordStart, cursorPos)
    return word, wordStart, cursorPos
end

--- Handle Tab keypress in a step EditBox: attempt spell autocomplete.
--- Falls back to ClearFocus if no matches or spell cache unavailable.
--- @param editBox EditBox The EditBox that received the Tab press
local function handleTabAutocomplete(editBox)
    -- If dropdown is already shown, dismiss it and defocus
    if SLV.autocompleteDropdown and SLV.autocompleteDropdown:IsShown() then
        SLV.autocompleteDropdown:Hide()
        editBox:ClearFocus()
        return
    end

    local SC = GRIPEMS.SpellCache
    if not SC or not SC.ready then
        editBox:ClearFocus()
        return
    end

    local word, wordStart, cursorPos = extractWordUnderCursor(editBox)

    -- Variable autocomplete: check if character before wordStart is "~"
    local text = editBox:GetText() or ""
    local charBefore = (wordStart > 1) and text:sub(wordStart - 1, wordStart - 1) or ""
    local isVarComplete = (charBefore == "~")
    -- Also trigger if word itself starts with ~ (cursor right after ~)
    if not isVarComplete and word:sub(1, 1) == "~" then
        isVarComplete = true
        -- Strip the leading ~ from the word; adjust wordStart to include it
        word = word:sub(2)
        -- wordStart already includes the ~ position
    end

    if isVarComplete then
        local VS = GRIPEMS.VariableStore
        if not VS then editBox:ClearFocus(); return end
        local store = VS:GetAll()
        local varMatches = {}
        local prefix = word:lower()
        for varName in pairs(store) do
            if prefix == "" or varName:lower():sub(1, #prefix) == prefix then
                varMatches[#varMatches + 1] = { name = varName }
            end
        end
        table.sort(varMatches, function(a, b) return a.name < b.name end)
        if #varMatches > D().AUTOCOMPLETE_MAX_RESULTS then
            local trimmed = {}
            for i = 1, D().AUTOCOMPLETE_MAX_RESULTS do
                trimmed[i] = varMatches[i]
            end
            varMatches = trimmed
        end
        if #varMatches == 0 then
            editBox:ClearFocus()
            return
        end
        -- For variable autocomplete, the replacement range starts at the ~
        local tildeStart = charBefore == "~" and (wordStart - 1) or wordStart
        SLV:ShowVarAutocompleteMenu(editBox, varMatches, tildeStart, cursorPos)
        return
    end

    local firstChar = word:sub(1, 1)
    local isCommand = (firstChar == "/" or firstChar == "#")
    local minChars = isCommand and D().AUTOCOMPLETE_MIN_CHARS
        or D().AUTOCOMPLETE_MIN_SPELL_CHARS
    if #word < minChars then
        editBox:ClearFocus()
        return
    end

    -- Dual-path: macro commands (starts with / or #) or spell names
    local matches
    if isCommand then
        matches = SC:MacroCommandSearch(word, D().AUTOCOMPLETE_MAX_RESULTS)
    else
        matches = SC:PrefixSearch(word, D().AUTOCOMPLETE_MAX_RESULTS)
    end
    if #matches == 0 then
        editBox:ClearFocus()
        return
    end

    -- Show autocomplete popup
    SLV:ShowAutocompleteMenu(editBox, matches, wordStart, cursorPos)
end

---------------------------------------------------------------------------
-- Initialization
---------------------------------------------------------------------------

--- Build the editable step list inside the given parent frame (tab content area).
--- @param parentFrame Frame The content area that hosts the step list
function SLV:Init(parentFrame)
    if not parentFrame then return end
    local C = UI.Colors

    SLV.container = parentFrame

    ---------------------------------------------------------------------------
    -- Edit area (bottom section: header line + EditBox)
    ---------------------------------------------------------------------------
    local editArea = CreateFrame("Frame", nil, parentFrame)
    editArea:SetHeight(D().STEP_EDIT_HEIGHT_MAX + 20)
    editArea:SetPoint("BOTTOMLEFT", parentFrame, "BOTTOMLEFT", 4, 4)
    editArea:SetPoint("BOTTOMRIGHT", parentFrame, "BOTTOMRIGHT", -4, 4)
    editArea:Hide()
    SLV.editArea = editArea

    -- Step header: "Step N:" left-aligned, char count right-aligned
    local editHeader = editArea:CreateFontString(nil, "OVERLAY")
    UI:SetFont(editHeader, 11)
    editHeader:SetPoint("TOPLEFT", editArea, "TOPLEFT", 2, 0)
    editHeader:SetText("")
    editHeader:SetTextColor(C.textSecondary:GetRGBA())
    SLV.editHeader = editHeader

    local editCharCount = editArea:CreateFontString(nil, "OVERLAY")
    UI:SetFont(editCharCount, 10)
    editCharCount:SetPoint("TOPRIGHT", editArea, "TOPRIGHT", -2, 0)
    editCharCount:SetText("")
    editCharCount:SetTextColor(C.textSuccess:GetRGBA())
    SLV.editCharCount = editCharCount

    -- EditBox
    local editBox = CreateFrame("EditBox", nil, editArea, "BackdropTemplate")
    editBox:SetPoint("TOPLEFT", editHeader, "BOTTOMLEFT", 0, -4)
    editBox:SetPoint("RIGHT", editArea, "RIGHT", -2, 0)
    editBox:SetHeight(D().STEP_EDIT_HEIGHT_MIN)
    editBox:SetMultiLine(true)
    editBox:SetMaxBytes(1023)
    editBox:SetAutoFocus(false)
    editBox:SetBackdrop(UI.Backdrops.panel)
    editBox:SetBackdropColor(C.bgInput:GetRGBA())
    editBox:SetBackdropBorderColor(C.border:GetRGBA())
    editBox:SetTextInsets(6, 6, 4, 4)

    local fontPath = GameFontNormal:GetFont()
    editBox:SetFont(fontPath, 11, "")
    editBox:SetTextColor(C.textPrimary:GetRGBA())

    editBox:SetScript("OnTextChanged", function(self, userInput)
        if not userInput then return end
        if not SLV.selectedIndex then return end
        local text = self:GetText() or ""
        SLV.workingSteps[SLV.selectedIndex] = text

        -- Update char count display
        SLV:UpdateEditCharCount(#text)

        -- Set dirty flag on editor
        local SE = GRIPEMS.SequenceEditor
        if SE then SE.isDirty = true; SE:UpdateSaveButtons() end

        -- Auto-height: only call SetHeight when hard newline count changes
        local numLines = select(2, text:gsub("\n", "")) + 1
        if numLines ~= SLV._lastLineCount then
            SLV._lastLineCount = numLines
            local lineHeight = 14
            local desiredH = math.max(D().STEP_EDIT_HEIGHT_MIN,
                math.min(D().STEP_EDIT_HEIGHT_MAX, numLines * lineHeight + 8))
            self:SetHeight(desiredH)
        end

        -- Refresh scroll row (lightweight, no DataProvider rebuild)
        SLV:RefreshCurrentRow()

        -- Live-filter autocomplete if dropdown is visible
        SLV:RefreshAutocomplete(self)
    end)
    editBox:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
    end)
    editBox:SetScript("OnTabPressed", function(self)
        handleTabAutocomplete(self)
    end)
    editBox:SetScript("OnEditFocusGained", function(self)
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
    end)
    editBox:SetScript("OnEditFocusLost", function(self)
        self:SetBackdropBorderColor(C.border:GetRGBA())
    end)
    SLV.editBox = editBox

    -- Unsaved changes hint (below editBox, subtle yellow)
    local unsavedHint = editArea:CreateFontString(nil, "OVERLAY")
    UI:SetFont(unsavedHint, 9)
    unsavedHint:SetPoint("BOTTOMLEFT", editArea, "BOTTOMLEFT", 4, 0)
    unsavedHint:SetText(L["GEMS_STEP_UNSAVED_HINT"])
    unsavedHint:SetTextColor(C.textWarning:GetRGBA())
    unsavedHint:SetAlpha(0.8)
    unsavedHint:Hide()
    SLV.unsavedHint = unsavedHint

    ---------------------------------------------------------------------------
    -- Action button bar (above edit area)
    ---------------------------------------------------------------------------
    local actionBar = CreateFrame("Frame", nil, parentFrame)
    actionBar:SetHeight(D().STEP_ACTION_BAR_HEIGHT)
    actionBar:SetPoint("BOTTOMLEFT", editArea, "TOPLEFT", 0, 4)
    actionBar:SetPoint("BOTTOMRIGHT", editArea, "TOPRIGHT", 0, 4)
    SLV.actionBar = actionBar

    -- Build action buttons
    local btnDefs = {
        { key = "add",  label = L["GEMS_UI_ADD_STEP"],  desc = L["GEMS_UI_ADD_STEP_DESC"],  fn = function() SLV:AddStep() end },
        { key = "dup",  label = L["GEMS_UI_DUP_STEP"],  desc = L["GEMS_UI_DUP_STEP_DESC"],  fn = function() SLV:DuplicateStep() end },
        { key = "up",   label = L["GEMS_UI_MOVE_UP"],    desc = L["GEMS_UI_MOVE_UP_DESC"],    fn = function() SLV:MoveStepUp() end },
        { key = "down", label = L["GEMS_UI_MOVE_DOWN"],  desc = L["GEMS_UI_MOVE_DOWN_DESC"],  fn = function() SLV:MoveStepDown() end },
        { key = "del",  label = L["GEMS_UI_DEL_STEP"],  desc = L["GEMS_UI_DEL_STEP_DESC"],  fn = function() SLV:DeleteStep() end },
    }
    SLV.actionButtons = {}
    local prevBtn
    for _, def in ipairs(btnDefs) do
        local btn = UI:CreateButton(actionBar, def.label,
            D().STEP_BUTTON_WIDTH, D().STEP_BUTTON_HEIGHT)
        if prevBtn then
            btn:SetPoint("LEFT", prevBtn, "RIGHT", 4, 0)
        else
            btn:SetPoint("LEFT", actionBar, "LEFT", 0, 0)
        end

        btn:SetScript("OnClick", def.fn)
        btn:SetScript("OnEnter", function(self)
            self:SetBackdropColor(C.bgRowHover:GetRGBA())
            self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
            UI:ShowTooltip(self, def.label, def.desc)
        end)
        btn:SetScript("OnLeave", function(self)
            SLV:UpdateButtonStates()
            UI:HideTooltip()
        end)

        SLV.actionButtons[def.key] = btn
        prevBtn = btn
    end

    -- Save button (right-aligned, shown only when dirty)
    local saveBtn = UI:CreateButton(actionBar, L["GEMS_STEP_SAVE"],
        60, D().STEP_BUTTON_HEIGHT)
    saveBtn:SetPoint("RIGHT", actionBar, "RIGHT", 0, 0)
    saveBtn:SetBackdropColor(C.bgSave:GetRGBA())
    saveBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.bgSaveHover:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
        UI:ShowTooltip(self, L["GEMS_STEP_SAVE"], L["GEMS_STEP_SAVE_DESC"])
    end)
    saveBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgSave:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
        UI:HideTooltip()
    end)
    saveBtn:SetScript("OnClick", function()
        local SE = GRIPEMS.SequenceEditor
        if SE then SE:SaveSequence() end
    end)
    saveBtn:Hide()
    SLV.saveBtn = saveBtn

    ---------------------------------------------------------------------------
    -- ScrollBox (top section, above action bar)
    ---------------------------------------------------------------------------
    local scrollBox = CreateFrame("Frame", nil, parentFrame, "WowScrollBoxList")
    scrollBox:SetPoint("TOPLEFT", parentFrame, "TOPLEFT", 4, -4)
    scrollBox:SetPoint("RIGHT", parentFrame, "RIGHT", -18, 0)
    scrollBox:SetPoint("BOTTOM", actionBar, "TOP", 0, 4)
    SLV.scrollBox = scrollBox

    local scrollBar = CreateFrame("EventFrame", nil, parentFrame, "MinimalScrollBar")
    scrollBar:SetPoint("TOPLEFT", scrollBox, "TOPRIGHT", 2, 0)
    scrollBar:SetPoint("BOTTOMLEFT", scrollBox, "BOTTOMRIGHT", 2, 0)
    SLV.scrollBar = scrollBar

    local scrollView = CreateScrollBoxListLinearView()
    scrollView:SetElementExtent(D().STEP_ROW_HEIGHT)
    SLV.scrollView = scrollView

    scrollView:SetElementInitializer("Button", function(button, data)
        SLV:InitRow(button, data)
    end)

    ScrollUtil.InitScrollBoxListWithScrollBar(scrollBox, scrollBar, scrollView)

    local dp = CreateDataProvider()
    scrollBox:SetDataProvider(dp)
    SLV.dataProvider = dp

    ---------------------------------------------------------------------------
    -- Empty / placeholder labels
    ---------------------------------------------------------------------------
    local emptyLabel = parentFrame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(emptyLabel, 11)
    emptyLabel:SetPoint("CENTER", scrollBox, "CENTER", 0, 10)
    emptyLabel:SetText(L["GEMS_UI_NO_STEPS"])
    emptyLabel:SetTextColor(C.textMuted:GetRGBA())
    SLV.emptyLabel = emptyLabel

    local hintLabel = parentFrame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(hintLabel, 9)
    hintLabel:SetPoint("TOP", emptyLabel, "BOTTOM", 0, -6)
    hintLabel:SetText(L["GEMS_UI_ADD_STEP_HINT"])
    hintLabel:SetTextColor(C.textMuted:GetRGBA())
    hintLabel:SetWidth(220)
    hintLabel:SetJustifyH("CENTER")
    SLV.hintLabel = hintLabel

    -- Placeholder for when no step is selected
    local selectLabel = parentFrame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(selectLabel, 10)
    selectLabel:SetPoint("CENTER", editArea, "CENTER", 0, 0)
    selectLabel:SetText(L["GEMS_UI_SELECT_STEP"])
    selectLabel:SetTextColor(C.textMuted:GetRGBA())
    selectLabel:Hide()
    SLV.selectLabel = selectLabel
end

---------------------------------------------------------------------------
-- Row initializer
---------------------------------------------------------------------------

--- Initialize or refresh a step row. ScrollBox reuses frames.
--- @param button Button The reusable row frame
--- @param data table { index, text, charCount }
function SLV:InitRow(button, data)
    local C = UI.Colors

    button:SetHeight(D().STEP_ROW_HEIGHT)

    -- Create child elements once
    if not button._gripInit then
        if not button.SetBackdrop then
            Mixin(button, BackdropTemplateMixin)
        end

        button:SetBackdrop(UI.Backdrops.panelNoBorder)
        button:EnableMouse(true)
        button:RegisterForClicks("LeftButtonUp", "RightButtonUp")

        -- Step number
        button.stepNum = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(button.stepNum, 10)
        button.stepNum:SetPoint("LEFT", button, "LEFT", 4, 0)
        button.stepNum:SetWidth(30)
        button.stepNum:SetJustifyH("LEFT")

        -- Step text
        button.stepText = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(button.stepText, 11)
        button.stepText:SetPoint("LEFT", button.stepNum, "RIGHT", 4, 0)
        button.stepText:SetPoint("RIGHT", button, "RIGHT", -55, 0)
        button.stepText:SetJustifyH("LEFT")
        button.stepText:SetWordWrap(false)

        -- Char count
        button.charCount = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(button.charCount, 10)
        button.charCount:SetPoint("RIGHT", button, "RIGHT", -4, 0)
        button.charCount:SetJustifyH("RIGHT")

        button._gripInit = true
    end

    -- Populate
    button.stepNum:SetText(string.format(L["GEMS_UI_STEP_NUM"], data.index or 0))
    button.stepNum:SetTextColor(C.textSecondary:GetRGBA())

    button.stepText:SetText(data.text or "")
    button.stepText:SetTextColor(C.textPrimary:GetRGBA())

    local count = data.charCount or 0
    local defaults = D()
    button.charCount:SetText(string.format("%d/%d", count, defaults.CHAR_COUNT_DANGER))

    -- Color the char count based on thresholds
    if count >= defaults.CHAR_COUNT_DANGER then
        button.charCount:SetTextColor(C.textError:GetRGBA())
    elseif count > defaults.CHAR_COUNT_WARNING then
        button.charCount:SetTextColor(C.textWarning:GetRGBA())
    else
        button.charCount:SetTextColor(C.textSuccess:GetRGBA())
    end

    -- Selection state
    local isSelected = (data.index == SLV.selectedIndex)
    if isSelected then
        button:SetBackdropColor(C.bgRowSelected:GetRGBA())
    elseif data.index and data.index % 2 == 0 then
        button:SetBackdropColor(C.bgPanel:GetRGBA())
    else
        button:SetBackdropColor(C.bgMain:GetRGBA())
    end

    -- Store data ref
    button._stepData = data

    -- Tooltip: show full step text
    button:SetScript("OnEnter", function(self)
        if not isSelected then
            self:SetBackdropColor(C.bgRowHover:GetRGBA())
        end
        if data.text and data.text ~= "" then
            UI:ShowTooltip(self,
                string.format(L["GEMS_UI_STEP_NUM"], data.index or 0),
                data.text)
        end
    end)
    button:SetScript("OnLeave", function(self)
        if not isSelected then
            if data.index and data.index % 2 == 0 then
                self:SetBackdropColor(C.bgPanel:GetRGBA())
            else
                self:SetBackdropColor(C.bgMain:GetRGBA())
            end
        end
        UI:HideTooltip()
    end)

    -- Click: select step or show context menu
    button:SetScript("OnClick", function(self, mouseButton)
        if mouseButton == "RightButton" then
            SLV:ShowContextMenu(self, data)
        else
            SLV.selectedIndex = data.index
            SLV._lastLineCount = 0
            SLV:RefreshAll()
        end
    end)
end

---------------------------------------------------------------------------
-- Context menu for step rows
---------------------------------------------------------------------------

--- Show a right-click context menu for a step row.
--- @param button Button The row frame (menu anchor)
--- @param data table Row data { index, text, charCount }
function SLV:ShowContextMenu(button, data)
    if not data or not data.index then return end

    MenuUtil.CreateContextMenu(button, function(ownerRegion, rootDescription)
        rootDescription:CreateButton(L["GEMS_UI_CTX_DUP_STEP"], function()
            SLV.selectedIndex = data.index
            SLV:DuplicateStep()
        end)

        local moveUpBtn = rootDescription:CreateButton(L["GEMS_UI_CTX_MOVE_UP"], function()
            SLV.selectedIndex = data.index
            SLV:MoveStepUp()
        end)
        moveUpBtn:SetEnabled(data.index > 1)

        local moveDownBtn = rootDescription:CreateButton(L["GEMS_UI_CTX_MOVE_DOWN"], function()
            SLV.selectedIndex = data.index
            SLV:MoveStepDown()
        end)
        moveDownBtn:SetEnabled(data.index < #SLV.workingSteps)

        rootDescription:CreateDivider()

        rootDescription:CreateButton("|cFFFF4444" .. L["GEMS_UI_CTX_DELETE_STEP"] .. "|r", function()
            SLV.selectedIndex = data.index
            SLV:DeleteStep()
        end)
    end)
end

---------------------------------------------------------------------------
-- Autocomplete menu
---------------------------------------------------------------------------

--- Show an autocomplete dropdown anchored below the EditBox.
--- Uses a create-once reusable frame with pooled button rows.
--- @param editBox EditBox The EditBox to anchor the dropdown to
--- @param matches table Array of { name, spellID, iconID } entries
--- @param wordStart number Start position of the word being completed
--- @param cursorPos number Cursor position when Tab was pressed
function SLV:ShowAutocompleteMenu(editBox, matches, wordStart, cursorPos)
    if not editBox or not matches or #matches == 0 then return end

    local C = UI.Colors
    local ROW_HEIGHT = 22

    -- Lazy-init: create the dropdown frame once
    local dropdown = SLV.autocompleteDropdown
    if not dropdown then
        dropdown = CreateFrame("Frame", "GRIPEMS_AutocompleteDropdown", UIParent, "BackdropTemplate")
        dropdown:SetFrameStrata("DIALOG")
        dropdown:SetBackdrop(UI.Backdrops.panel)
        dropdown:SetBackdropColor(C.bgPanel:GetRGBA())
        dropdown:SetBackdropBorderColor(C.border:GetRGBA())
        dropdown:SetClampedToScreen(true)
        dropdown:EnableKeyboard(true)
        dropdown:SetScript("OnKeyDown", function(self, key)
            if key == "ESCAPE" then
                self:Hide()
                self:SetPropagateKeyboardInput(false)
            else
                self:SetPropagateKeyboardInput(true)
            end
        end)
        dropdown._rows = {}
        SLV.autocompleteDropdown = dropdown
    end

    -- Hide all existing rows first
    for _, row in ipairs(dropdown._rows) do
        row:Hide()
    end

    -- Size the dropdown
    local ddWidth = math.max(editBox:GetWidth(), 200)
    dropdown:SetSize(ddWidth, #matches * ROW_HEIGHT)
    dropdown:ClearAllPoints()
    dropdown:SetPoint("TOPLEFT", editBox, "BOTTOMLEFT", 0, -2)

    -- Create or reuse button rows
    for i, match in ipairs(matches) do
        local row = dropdown._rows[i]
        if not row then
            row = CreateFrame("Button", nil, dropdown, "BackdropTemplate")
            row:SetBackdrop(UI.Backdrops.panelNoBorder)
            row:SetBackdropColor(0, 0, 0, 0)

            -- Icon texture
            row.icon = row:CreateTexture(nil, "ARTWORK")
            row.icon:SetSize(16, 16)
            row.icon:SetPoint("LEFT", row, "LEFT", 4, 0)

            -- Label
            row.label = row:CreateFontString(nil, "OVERLAY")
            UI:SetFont(row.label, 12)
            row.label:SetTextColor(C.textPrimary:GetRGBA())

            -- Hover highlight
            row:SetScript("OnEnter", function(self)
                self:SetBackdropColor(C.bgRowHover:GetRGBA())
            end)
            row:SetScript("OnLeave", function(self)
                self:SetBackdropColor(0, 0, 0, 0)
            end)

            dropdown._rows[i] = row
        end

        row:SetSize(ddWidth, ROW_HEIGHT)
        row:ClearAllPoints()
        row:SetPoint("TOPLEFT", dropdown, "TOPLEFT", 0, -((i - 1) * ROW_HEIGHT))

        -- Icon: show if match has iconID, hide otherwise
        if match.iconID then
            row.icon:SetTexture(match.iconID)
            row.icon:Show()
            row.label:SetPoint("LEFT", row.icon, "RIGHT", 4, 0)
        else
            row.icon:Hide()
            row.label:ClearAllPoints()
            row.label:SetPoint("LEFT", row, "LEFT", 4, 0)
        end
        row.label:SetText(match.name)

        -- OnClick: do text replacement, hide dropdown
        row:SetScript("OnClick", function()
            local text = editBox:GetText() or ""
            local before = text:sub(1, wordStart - 1)
            local after = text:sub(cursorPos + 1)
            local insertion = match.name
            -- Macro commands get trailing space for convenience
            local firstCh = insertion:sub(1, 1)
            if (firstCh == "/" or firstCh == "#") and after == "" then
                insertion = insertion .. " "
            end
            local newText = before .. insertion .. after
            editBox:SetText(newText)
            editBox:SetCursorPosition(wordStart - 1 + #insertion)

            -- Update working copy and dirty state
            local idx = SLV.selectedIndex
            if idx then
                SLV.workingSteps[idx] = newText
                SLV:UpdateEditCharCount(#newText)
                local SE = GRIPEMS.SequenceEditor
                if SE then SE.isDirty = true; SE:UpdateSaveButtons() end
                SLV:RefreshCurrentRow()
            end

            dropdown:Hide()
        end)

        row:Show()
    end

    dropdown:Show()
end

---------------------------------------------------------------------------
-- Variable autocomplete menu
---------------------------------------------------------------------------

--- Show a variable autocomplete dropdown (no icons, inserts ~name~).
--- Reuses the same dropdown frame as spell autocomplete.
--- @param editBox EditBox The EditBox to anchor the dropdown to
--- @param matches table Array of { name = string } entries
--- @param tildeStart number Position of the leading ~ (1-based)
--- @param cursorPos number Cursor position when Tab was pressed
function SLV:ShowVarAutocompleteMenu(editBox, matches, tildeStart, cursorPos)
    if not editBox or not matches or #matches == 0 then return end

    local C = UI.Colors
    local ROW_HEIGHT = 22

    -- Lazy-init: reuse the same dropdown frame
    local dropdown = SLV.autocompleteDropdown
    if not dropdown then
        dropdown = CreateFrame("Frame", "GRIPEMS_AutocompleteDropdown",
            UIParent, "BackdropTemplate")
        dropdown:SetFrameStrata("DIALOG")
        dropdown:SetBackdrop(UI.Backdrops.panel)
        dropdown:SetBackdropColor(C.bgPanel:GetRGBA())
        dropdown:SetBackdropBorderColor(C.border:GetRGBA())
        dropdown:SetClampedToScreen(true)
        dropdown:EnableKeyboard(true)
        dropdown:SetScript("OnKeyDown", function(self, key)
            if key == "ESCAPE" then
                self:Hide()
                self:SetPropagateKeyboardInput(false)
            else
                self:SetPropagateKeyboardInput(true)
            end
        end)
        dropdown._rows = {}
        SLV.autocompleteDropdown = dropdown
    end

    -- Hide all existing rows
    for _, row in ipairs(dropdown._rows) do
        row:Hide()
    end

    -- Size the dropdown
    local ddWidth = math.max(editBox:GetWidth(), 200)
    dropdown:SetSize(ddWidth, #matches * ROW_HEIGHT)
    dropdown:ClearAllPoints()
    dropdown:SetPoint("TOPLEFT", editBox, "BOTTOMLEFT", 0, -2)

    for i, match in ipairs(matches) do
        local row = dropdown._rows[i]
        if not row then
            row = CreateFrame("Button", nil, dropdown, "BackdropTemplate")
            row:SetBackdrop(UI.Backdrops.panelNoBorder)
            row:SetBackdropColor(0, 0, 0, 0)

            row.icon = row:CreateTexture(nil, "ARTWORK")
            row.icon:SetSize(16, 16)
            row.icon:SetPoint("LEFT", row, "LEFT", 4, 0)

            row.label = row:CreateFontString(nil, "OVERLAY")
            UI:SetFont(row.label, 12)
            row.label:SetTextColor(C.textPrimary:GetRGBA())

            row:SetScript("OnEnter", function(self)
                self:SetBackdropColor(C.bgRowHover:GetRGBA())
            end)
            row:SetScript("OnLeave", function(self)
                self:SetBackdropColor(0, 0, 0, 0)
            end)

            dropdown._rows[i] = row
        end

        row:SetSize(ddWidth, ROW_HEIGHT)
        row:ClearAllPoints()
        row:SetPoint("TOPLEFT", dropdown, "TOPLEFT", 0,
            -((i - 1) * ROW_HEIGHT))

        -- No icon for variable autocomplete
        row.icon:Hide()
        row.label:ClearAllPoints()
        row.label:SetPoint("LEFT", row, "LEFT", 4, 0)
        row.label:SetText("~" .. match.name .. "~")

        -- OnClick: replace from tildeStart to cursorPos with ~name~
        row:SetScript("OnClick", function()
            local text = editBox:GetText() or ""
            local before = text:sub(1, tildeStart - 1)
            local after = text:sub(cursorPos + 1)
            local insertion = "~" .. match.name .. "~"
            local newText = before .. insertion .. after
            editBox:SetText(newText)
            editBox:SetCursorPosition(tildeStart - 1 + #insertion)

            -- Update working copy and dirty state
            local idx = SLV.selectedIndex
            if idx then
                SLV.workingSteps[idx] = newText
                SLV:UpdateEditCharCount(#newText)
                local SE = GRIPEMS.SequenceEditor
                if SE then SE.isDirty = true; SE:UpdateSaveButtons() end
                SLV:RefreshCurrentRow()
            end

            dropdown:Hide()
        end)

        row:Show()
    end

    dropdown:Show()
end

---------------------------------------------------------------------------
-- Live-filter autocomplete (called from OnTextChanged)
---------------------------------------------------------------------------

--- Re-filter the autocomplete dropdown while the user types.
--- Called from OnTextChanged when the dropdown is already visible.
--- Hides the dropdown if the word shrinks below min chars or no matches.
--- @param editBox EditBox The EditBox being edited
function SLV:RefreshAutocomplete(editBox)
    if not SLV.autocompleteDropdown
        or not SLV.autocompleteDropdown:IsShown() then
        return
    end

    local SC = GRIPEMS.SpellCache
    if not SC or not SC.ready then
        SLV.autocompleteDropdown:Hide()
        return
    end

    local word, wordStart, cursorPos = extractWordUnderCursor(editBox)
    local firstChar = word:sub(1, 1)
    local isCommand = (firstChar == "/" or firstChar == "#")
    local minChars = isCommand and D().AUTOCOMPLETE_MIN_CHARS
        or D().AUTOCOMPLETE_MIN_SPELL_CHARS

    if #word < minChars then
        SLV.autocompleteDropdown:Hide()
        return
    end

    local matches
    if isCommand then
        matches = SC:MacroCommandSearch(word, D().AUTOCOMPLETE_MAX_RESULTS)
    else
        matches = SC:PrefixSearch(word, D().AUTOCOMPLETE_MAX_RESULTS)
    end

    if #matches == 0 then
        SLV.autocompleteDropdown:Hide()
        return
    end

    -- Re-populate the dropdown with updated matches
    SLV:ShowAutocompleteMenu(editBox, matches, wordStart, cursorPos)
end

---------------------------------------------------------------------------
-- Data flow methods
---------------------------------------------------------------------------

--- Load an array of step strings into the step list.
--- Deep-copies into workingSteps and originalSteps.
--- @param steps table|nil Array of macro text strings
function SLV:LoadSteps(steps)
    if not SLV.scrollView then return end

    SLV.workingSteps = {}
    SLV.originalSteps = {}
    SLV.selectedIndex = nil
    SLV._lastLineCount = 0

    if steps then
        for i, step in ipairs(steps) do
            SLV.workingSteps[i] = step
            SLV.originalSteps[i] = step
        end
    end

    SLV:RefreshAll()
end

--- Return the current edited steps array.
--- @return table workingSteps
function SLV:GetWorkingSteps()
    return SLV.workingSteps
end

--- Compare working steps against original to detect changes.
--- @return boolean hasChanges
function SLV:HasChanges()
    if #SLV.workingSteps ~= #SLV.originalSteps then return true end
    for i = 1, #SLV.workingSteps do
        if SLV.workingSteps[i] ~= SLV.originalSteps[i] then
            return true
        end
    end
    return false
end

--- Rebuild DataProvider, update button states, update edit area.
function SLV:RefreshAll()
    if SLV.autocompleteDropdown then SLV.autocompleteDropdown:Hide() end
    if not SLV.scrollView then return end

    -- Rebuild DataProvider
    local dp = CreateDataProvider()
    if #SLV.workingSteps > 0 then
        for i, step in ipairs(SLV.workingSteps) do
            dp:Insert({
                index = i,
                text = step,
                charCount = #step,
            })
        end
        if SLV.emptyLabel then SLV.emptyLabel:Hide() end
        if SLV.hintLabel then SLV.hintLabel:Hide() end
    else
        if SLV.emptyLabel then SLV.emptyLabel:Show() end
        if SLV.hintLabel then SLV.hintLabel:Show() end
    end
    SLV.scrollBox:SetDataProvider(dp)
    SLV.dataProvider = dp

    -- Update action button states
    SLV:UpdateButtonStates()

    -- Update edit area
    SLV:UpdateEditArea()
end

--- Clear the step list to empty state.
function SLV:Clear()
    SLV.workingSteps = {}
    SLV.originalSteps = {}
    SLV.selectedIndex = nil
    SLV._lastLineCount = 0

    if SLV.scrollView then
        local dp = CreateDataProvider()
        SLV.scrollBox:SetDataProvider(dp)
        SLV.dataProvider = dp
    end

    if SLV.emptyLabel then SLV.emptyLabel:Show() end
    if SLV.hintLabel then SLV.hintLabel:Show() end
    if SLV.editArea then SLV.editArea:Hide() end
    if SLV.selectLabel then SLV.selectLabel:Hide() end
end

---------------------------------------------------------------------------
-- Button state management
---------------------------------------------------------------------------

--- Update enabled/disabled state of action buttons.
function SLV:UpdateButtonStates()
    if SLV._updatingButtons then return end
    SLV._updatingButtons = true

    local C = UI.Colors
    local sel = SLV.selectedIndex
    local count = #SLV.workingSteps

    local function setEnabled(btn, enabled)
        if not btn then return end
        if enabled then
            btn:Enable()
            btn.label:SetTextColor(C.textPrimary:GetRGBA())
            btn:SetBackdropColor(C.bgButton:GetRGBA())
            btn:SetBackdropBorderColor(C.border:GetRGBA())
        else
            btn:Disable()
            btn.label:SetTextColor(C.textMuted:GetRGBA())
            btn:SetBackdropColor(C.bgDeep:GetRGBA())
            btn:SetBackdropBorderColor(C.border:GetRGBA())
        end
    end

    -- Add is always enabled
    setEnabled(SLV.actionButtons["add"], true)
    -- Dup/Del need selection
    setEnabled(SLV.actionButtons["dup"], sel ~= nil)
    setEnabled(SLV.actionButtons["del"], sel ~= nil)
    -- Up needs selection and not first
    setEnabled(SLV.actionButtons["up"], sel ~= nil and sel > 1)
    -- Down needs selection and not last
    setEnabled(SLV.actionButtons["down"], sel ~= nil and sel < count)

    SLV._updatingButtons = false
end

---------------------------------------------------------------------------
-- Edit area management
---------------------------------------------------------------------------

--- Update the edit area based on current selection.
function SLV:UpdateEditArea()
    if SLV.autocompleteDropdown then SLV.autocompleteDropdown:Hide() end
    if not SLV.editArea then return end

    if #SLV.workingSteps == 0 then
        -- No steps at all
        SLV.editArea:Hide()
        if SLV.selectLabel then SLV.selectLabel:Hide() end
        return
    end

    if not SLV.selectedIndex then
        -- Steps exist but none selected
        SLV.editArea:Show()
        if SLV.editBox then SLV.editBox:Hide() end
        if SLV.editHeader then SLV.editHeader:SetText("") end
        if SLV.editCharCount then SLV.editCharCount:SetText("") end
        if SLV.selectLabel then
            SLV.selectLabel:Show()
        end
        return
    end

    -- Step is selected
    SLV.editArea:Show()
    if SLV.selectLabel then SLV.selectLabel:Hide() end
    if SLV.editBox then SLV.editBox:Show() end

    local idx = SLV.selectedIndex
    local text = SLV.workingSteps[idx] or ""

    if SLV.editHeader then
        SLV.editHeader:SetText(string.format(L["GEMS_UI_STEP_HEADER"], idx))
    end

    -- Update char count
    SLV:UpdateEditCharCount(#text)

    -- Set EditBox text without triggering OnTextChanged
    if SLV.editBox then
        SLV.editBox:SetScript("OnTextChanged", nil)
        SLV.editBox:SetText(text)
        SLV._lastLineCount = select(2, text:gsub("\n", "")) + 1

        -- Restore handler
        SLV.editBox:SetScript("OnTextChanged", function(self, userInput)
            if not userInput then return end
            if not SLV.selectedIndex then return end
            local newText = self:GetText() or ""
            SLV.workingSteps[SLV.selectedIndex] = newText
            SLV:UpdateEditCharCount(#newText)
            local SE = GRIPEMS.SequenceEditor
            if SE then SE.isDirty = true; SE:UpdateSaveButtons() end

            local numLines = select(2, newText:gsub("\n", "")) + 1
            if numLines ~= SLV._lastLineCount then
                SLV._lastLineCount = numLines
                local lineHeight = 14
                local desiredH = math.max(D().STEP_EDIT_HEIGHT_MIN,
                    math.min(D().STEP_EDIT_HEIGHT_MAX, numLines * lineHeight + 8))
                self:SetHeight(desiredH)
            end

            SLV:RefreshCurrentRow()

            -- Live-filter autocomplete if dropdown is visible
            SLV:RefreshAutocomplete(self)
        end)
    end
end

--- Update the char count display in the edit area.
--- @param count number Character count
function SLV:UpdateEditCharCount(count)
    if not SLV.editCharCount then return end
    local C = UI.Colors
    local defaults = D()

    SLV.editCharCount:SetText(string.format("%d/%d", count, defaults.CHAR_COUNT_DANGER))

    if count >= defaults.CHAR_COUNT_DANGER then
        SLV.editCharCount:SetTextColor(C.textError:GetRGBA())
    elseif count > defaults.CHAR_COUNT_WARNING then
        SLV.editCharCount:SetTextColor(C.textWarning:GetRGBA())
    else
        SLV.editCharCount:SetTextColor(C.textSuccess:GetRGBA())
    end
end

---------------------------------------------------------------------------
-- Lightweight row refresh (flicker-free keystroke updates)
---------------------------------------------------------------------------

--- Lightweight refresh: update only the scroll row matching the
--- selected step. Does NOT rebuild the DataProvider or touch the
--- EditBox. Use this from OnTextChanged to avoid flicker.
function SLV:RefreshCurrentRow()
    if debugSkipRowRefresh then return end
    if not SLV.selectedIndex or not SLV.scrollBox then return end
    local idx = SLV.selectedIndex
    local text = SLV.workingSteps[idx] or ""

    -- GetChildren returns all child frames; scroll box children
    -- include the visible row frames managed by the DataProvider.
    for _, frame in pairs({ SLV.scrollBox:GetChildren() }) do
        if frame._stepData and frame._stepData.index == idx then
            -- Update displayed text and char count
            if frame.stepText then
                frame.stepText:SetText(text)
            end
            local count = #text
            if frame.charCount then
                local C = UI.Colors
                local defaults = D()
                frame.charCount:SetText(string.format(
                    "%d/%d", count, defaults.CHAR_COUNT_DANGER))
                if count >= defaults.CHAR_COUNT_DANGER then
                    frame.charCount:SetTextColor(C.textError:GetRGBA())
                elseif count > defaults.CHAR_COUNT_WARNING then
                    frame.charCount:SetTextColor(C.textWarning:GetRGBA())
                else
                    frame.charCount:SetTextColor(C.textSuccess:GetRGBA())
                end
            end
            -- Update stored data reference
            frame._stepData.text = text
            frame._stepData.charCount = count
            break  -- found our frame, stop iterating
        end
    end
end

--- Toggle the debugSkipRowRefresh flag (flicker diagnostic).
--- @return boolean New state (true = RefreshCurrentRow is DISABLED)
function SLV:ToggleDebugRowRefresh()
    debugSkipRowRefresh = not debugSkipRowRefresh
    return debugSkipRowRefresh
end

---------------------------------------------------------------------------
-- Step operations
---------------------------------------------------------------------------

--- Add a new empty step after the selected step (or at end).
function SLV:AddStep()
    local pos = (SLV.selectedIndex or #SLV.workingSteps) + 1
    table.insert(SLV.workingSteps, pos, "")
    SLV.selectedIndex = pos

    local SE = GRIPEMS.SequenceEditor
    if SE then SE.isDirty = true; SE:UpdateSaveButtons() end

    SLV:RefreshAll()

    -- Focus the EditBox after a frame delay
    C_Timer.After(0, function()
        if SLV.editBox then
            SLV.editBox:SetFocus()
        end
    end)
end

--- Duplicate the selected step.
function SLV:DuplicateStep()
    if not SLV.selectedIndex then return end
    local copy = SLV.workingSteps[SLV.selectedIndex]
    table.insert(SLV.workingSteps, SLV.selectedIndex + 1, copy)
    SLV.selectedIndex = SLV.selectedIndex + 1

    local SE = GRIPEMS.SequenceEditor
    if SE then SE.isDirty = true; SE:UpdateSaveButtons() end

    SLV:RefreshAll()
end

--- Move the selected step up.
function SLV:MoveStepUp()
    if not SLV.selectedIndex or SLV.selectedIndex <= 1 then return end
    local i = SLV.selectedIndex
    SLV.workingSteps[i], SLV.workingSteps[i - 1] =
        SLV.workingSteps[i - 1], SLV.workingSteps[i]
    SLV.selectedIndex = i - 1

    local SE = GRIPEMS.SequenceEditor
    if SE then SE.isDirty = true; SE:UpdateSaveButtons() end

    SLV:RefreshAll()
end

--- Move the selected step down.
function SLV:MoveStepDown()
    if not SLV.selectedIndex or SLV.selectedIndex >= #SLV.workingSteps then
        return
    end
    local i = SLV.selectedIndex
    SLV.workingSteps[i], SLV.workingSteps[i + 1] =
        SLV.workingSteps[i + 1], SLV.workingSteps[i]
    SLV.selectedIndex = i + 1

    local SE = GRIPEMS.SequenceEditor
    if SE then SE.isDirty = true; SE:UpdateSaveButtons() end

    SLV:RefreshAll()
end

--- Delete the selected step (with confirmation).
function SLV:DeleteStep()
    if not SLV.selectedIndex then return end
    local idx = SLV.selectedIndex

    StaticPopupDialogs["GRIPEMS_DELETE_STEP"] = {
        text = string.format(L["GEMS_UI_DELETE_STEP_CONFIRM"], idx),
        button1 = ACCEPT,
        button2 = CANCEL,
        OnAccept = function()
            table.remove(SLV.workingSteps, idx)
            if idx > #SLV.workingSteps then
                SLV.selectedIndex = #SLV.workingSteps > 0
                    and #SLV.workingSteps or nil
            end

            local SE = GRIPEMS.SequenceEditor
            if SE then SE.isDirty = true; SE:UpdateSaveButtons() end

            SLV:RefreshAll()
        end,
        timeout = 0,
        whileDead = true,
        hideOnEscape = true,
    }
    StaticPopup_Show("GRIPEMS_DELETE_STEP")
end
