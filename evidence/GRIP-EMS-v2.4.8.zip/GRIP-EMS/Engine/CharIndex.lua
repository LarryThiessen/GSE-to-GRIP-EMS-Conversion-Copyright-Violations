-- GRIP-EMS: Cross-Character Sequence Index
-- Created: 2026-08-03
-- Updated: 2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.
--
-- Sequences live in GRIP_EMS_CHAR.sequences, which the TOC declares
-- SavedVariablesPerCharacter. WoW loads ONLY the logged-in character's
-- per-character file, so another character's sequences are never in memory and
-- cannot be read at runtime. Cross-character visibility is therefore a PUBLISH
-- model: every character writes a small metadata index into account scope
-- (GRIP_EMS_DB.charIndex) at its own login, and a copy to an alt is STAGED into
-- an outbox (GRIP_EMS_DB.charOutbox) that the target character claims at its
-- next login. Storage stays per character; nothing is migrated.
--
-- Account-scope shapes owned by this module (both created lazily):
--   GRIP_EMS_DB.charIndex[charKey] = {
--       name, realm, classID, publishedAt,
--       seqs = { [seqName] = { classID, icon, stepFunction, stepCount,
--                              versionCount, updatedAt, description } },
--   }
--   GRIP_EMS_DB.charOutbox[targetCharKey] = {
--       [seqName] = { from = charKey, data = <deep copy of seqData> },
--   }
--
-- The index is METADATA ONLY -- never steps, versions, actions or macrotext.
-- The outbox is the only place a full payload lives and it is cleared on claim.

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

GRIPEMS.CharIndex = {}
local CI = GRIPEMS.CharIndex

---------------------------------------------------------------------------
-- Internals
---------------------------------------------------------------------------

--- Recursive copy for the outbox payload. Deliberately NOT
--- Engine:DuplicateSequence, which re-stamps fork identity -- a copy sent to
--- your own alt is the same sequence, not a fork. Drops _recommendFunc (the
--- compiled recommendation closure cached on a version table at activation)
--- and any other function value, because SavedVariables cannot serialize them.
--- @param src any
--- @return any
local function _deepCopy(src)
    if type(src) ~= "table" then
        return src
    end
    local out = {}
    for k, v in pairs(src) do
        if k ~= "_recommendFunc" and type(v) ~= "function" then
            out[k] = _deepCopy(v)
        end
    end
    return out
end

--- Lazily create and return an account-scoped sub-table of GRIP_EMS_DB.
--- @param field string "charIndex" or "charOutbox"
--- @return table|nil
local function _accountTable(field)
    if not _G.GRIP_EMS_DB then
        return nil
    end
    if type(GRIP_EMS_DB[field]) ~= "table" then
        GRIP_EMS_DB[field] = {}
    end
    return GRIP_EMS_DB[field]
end

--- Character-name portion of a "Name-Realm" charKey (first segment before the
--- separating dash). Used for the collision-rename suffix.
--- @param key string|nil
--- @return string
local function _charNameFromKey(key)
    if type(key) ~= "string" or key == "" then
        return "?"
    end
    local name = key:match("^([^-]+)")
    if name and name ~= "" then
        return name
    end
    return key
end

---------------------------------------------------------------------------
-- Public API
---------------------------------------------------------------------------

--- Account-unique key for the current character, "DisplayName-Realm".
--- @return string|nil nil when identity is unavailable or the name is empty
function CI:GetCharKey()
    local I = GRIPEMS.Identity
    if not I or not I.GetCurrent then
        return nil
    end
    local me = I:GetCurrent()
    if not me or not me.displayName or me.displayName == "" then
        return nil
    end
    return me.displayName .. "-" .. (me.realm or "")
end

--- Rebuild this character's metadata index entry from GRIP_EMS_CHAR.sequences.
--- The whole entry is overwritten so a deleted sequence disappears.
function CI:Publish()
    local key = CI:GetCharKey()
    if not key then
        return
    end
    local index = _accountTable("charIndex")
    if not index then
        return
    end
    local me = GRIPEMS.Identity:GetCurrent()
    local entry = {
        name = me.displayName,
        realm = me.realm or "",
        classID = select(3, UnitClass("player")) or 0,
        publishedAt = time(),
        seqs = {},
    }
    local stored = _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.sequences
    if type(stored) == "table" then
        local Engine = GRIPEMS.Engine
        for name, seqData in pairs(stored) do
            if type(name) == "string" and name ~= "" and type(seqData) == "table" then
                local ver = Engine and Engine:GetActiveVersion(seqData)
                local steps = (ver and type(ver.steps) == "table") and ver.steps or {}
                -- type(), not truthiness: a scalar .versions raises on a bare
                -- length operator (same defensive form as SequenceList).
                local versionCount = (type(seqData.versions) == "table" and #seqData.versions) or 1
                local updatedAt = 0
                if GRIPEMS.NormalizeUpdatedAt then
                    updatedAt = GRIPEMS.NormalizeUpdatedAt(seqData.updatedAt) or 0
                end
                entry.seqs[name] = {
                    classID = seqData.classID or 0,
                    icon = seqData.icon,
                    stepFunction = (ver and ver.stepFunction) or nil,
                    stepCount = #steps,
                    versionCount = versionCount,
                    updatedAt = updatedAt,
                    description = seqData.description or "",
                }
            end
        end
    end
    index[key] = entry
end

--- Flat array of read-only row tables for every character that is NOT the
--- current one. Shape is the sequence-list row shape plus foreign/ownerChar/
--- ownerRealm; own-row-only fields (keybind, active, liveVersion) are absent
--- by design and every consumer nil-guards them.
--- @return table
function CI:GetForeignRows()
    local rows = {}
    local index = _G.GRIP_EMS_DB and GRIP_EMS_DB.charIndex
    if type(index) ~= "table" then
        return rows
    end
    local myKey = CI:GetCharKey()
    for key, entry in pairs(index) do
        if key ~= myKey and type(entry) == "table" and type(entry.seqs) == "table" then
            for name, meta in pairs(entry.seqs) do
                if type(name) == "string" and name ~= "" and type(meta) == "table" then
                    rows[#rows + 1] = {
                        name = name,
                        icon = meta.icon,
                        stepFunction = meta.stepFunction,
                        stepCount = meta.stepCount or 0,
                        versionCount = meta.versionCount or 1,
                        classID = meta.classID or 0,
                        updatedAt = meta.updatedAt or 0,
                        description = meta.description or "",
                        foreign = true,
                        ownerChar = entry.name or _charNameFromKey(key),
                        ownerRealm = entry.realm or "",
                    }
                end
            end
        end
    end
    return rows
end

--- Stage a copy of one of THIS character's sequences for a target character.
--- The payload lands on the target at its next login (see CI:ClaimInbox).
--- @param seqName string
--- @param targetCharKey string
--- @return boolean ok, string|nil reason
function CI:StageCopy(seqName, targetCharKey)
    if type(seqName) ~= "string" or seqName == "" then
        return false, "no sequence name"
    end
    if type(targetCharKey) ~= "string" or targetCharKey == "" then
        return false, "no target character"
    end
    local myKey = CI:GetCharKey()
    if not myKey then
        return false, "identity unavailable"
    end
    if targetCharKey == myKey then
        return false, "target is the current character"
    end
    local stored = _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.sequences
    local seqData = (type(stored) == "table") and stored[seqName] or nil
    if type(seqData) ~= "table" then
        return false, "sequence not found"
    end
    local outbox = _accountTable("charOutbox")
    if not outbox then
        return false, "account store unavailable"
    end
    if type(outbox[targetCharKey]) ~= "table" then
        outbox[targetCharKey] = {}
    end
    outbox[targetCharKey][seqName] = { from = myKey, data = _deepCopy(seqData) }
    return true
end

--- Claim everything staged for this character and clear its outbox slot.
--- Collisions are checked against GRIP_EMS_CHAR.sequences, NOT Engine.sequences,
--- because this runs before the restore loop populates the engine.
--- @return number claimed, table renames Array of { from, to }
function CI:ClaimInbox()
    local renames = {}
    local myKey = CI:GetCharKey()
    if not myKey or not _G.GRIP_EMS_CHAR then
        return 0, renames
    end
    local outbox = GRIP_EMS_DB and GRIP_EMS_DB.charOutbox
    local staged = (type(outbox) == "table") and outbox[myKey] or nil
    if type(staged) ~= "table" then
        return 0, renames
    end
    if type(GRIP_EMS_CHAR.sequences) ~= "table" then
        GRIP_EMS_CHAR.sequences = {}
    end
    local target = GRIP_EMS_CHAR.sequences
    local claimed = 0
    for seqName, parcel in pairs(staged) do
        local payload = (type(parcel) == "table") and parcel.data or nil
        if type(seqName) == "string" and seqName ~= "" and type(payload) == "table" then
            local finalName = seqName
            if target[finalName] ~= nil then
                local base = seqName .. " (" .. _charNameFromKey(parcel.from) .. ")"
                finalName = base
                local suffix = 2
                while target[finalName] ~= nil do
                    finalName = base .. " " .. suffix
                    suffix = suffix + 1
                end
                renames[#renames + 1] = { from = seqName, to = finalName }
            end
            payload.name = finalName
            target[finalName] = payload
            claimed = claimed + 1
        end
    end
    outbox[myKey] = nil
    if claimed > 0 then
        GRIPEMS:Print(string.format(L["GEMS_UI_COPY_CLAIMED"], claimed))
        for _, r in ipairs(renames) do
            GRIPEMS:Print(string.format(L["GEMS_UI_COPY_RENAMED"], r.from, r.to))
        end
    end
    return claimed, renames
end
