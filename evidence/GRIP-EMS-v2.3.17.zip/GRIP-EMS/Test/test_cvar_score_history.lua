-- GRIP-EMS: Headless test for the CVar health score history ring
--
-- Created:    2026-07-19
-- Updated:    2026-07-19
-- Patch: 12.0.7 Midnight (Retail LIVE)
--
-- Standalone (Lua 5.1) test for the score-history capture path: the pure ring
-- helper CPM._ScoreHistoryPush and the capture method CPM:RecordHealthScore
-- (cap 60, account-global cvarScoreHistory, "resnapshot" dedupe vs "login"
-- always-record). Drives the REAL Data/Defaults.lua +
-- Data/CvarProfileManager.lua via loadfile + setfenv, the same technique as
-- test_spellcache_overrides.lua; ComputeHealthScore is stubbed for the
-- capture cases so scores are controlled.
--
-- Run from the EMS root:  lua Test/test_cvar_score_history.lua
-- Exit code 0 = all passed, 1 = at least one failure.
--
-- Cases:
--   T1  _ScoreHistoryPush appends under cap and preserves order
--   T2  _ScoreHistoryPush trims oldest-first once past cap 60; newest survives
--   T3  RecordHealthScore("resnapshot") skips when the newest entry has the
--       same score and records when it differs
--   T4  RecordHealthScore("login") records even when the score is unchanged
--   T5  the extracted ComputeHealthScore runs headless and returns
--       score 0-100 plus matchWeight/totalWeight

local ADDON_NAME = "GRIP-EMS"

-- ---------------------------------------------------------------------------
-- Minimal assertion + runner harness (mirrors TestSuite Pass/Fail semantics).
-- ---------------------------------------------------------------------------

local tests = {}

local function test(name, fn)
    tests[#tests + 1] = { name = name, fn = fn }
end

local function assertEqual(expected, actual, label)
    if expected ~= actual then
        error((label or "value") .. ": expected " .. tostring(expected) .. ", got " .. tostring(actual), 2)
    end
end

local function assertTrue(cond, label)
    if not cond then
        error((label or "condition") .. ": expected true", 2)
    end
end

-- ---------------------------------------------------------------------------
-- Sandbox: a self-referential no-op stub backs every unknown global so the
-- real modules load without a WoW client. Real stdlib falls through to _G.
-- ---------------------------------------------------------------------------

local stub = {}
setmetatable(stub, {
    __index = function()
        return stub
    end,
    __call = function()
        return stub
    end,
})

local env = setmetatable({}, {
    __index = function(_, k)
        local v = rawget(_G, k)
        if v ~= nil then
            return v
        end
        return stub
    end,
})
env._G = env

-- AceLocale stand-in: every key echoes back so any L["KEY"] format is inert.
local LOCALE = setmetatable({}, {
    __index = function(_, k)
        return k
    end,
})
env.LibStub = function()
    return {
        GetLocale = function()
            return LOCALE
        end,
    }
end
env.strlower = string.lower

-- Deterministic time + identity for history entries.
local fakeEpoch = 1000
env.GetServerTime = function()
    fakeEpoch = fakeEpoch + 1
    return fakeEpoch
end
env.UnitName = function()
    return "TestChar"
end
-- Raw CVar surface: reads resolve to nil / mask 0 so ComputeHealthScore has
-- a stable (mostly-mismatched) input in T5.
env.GetCVar = function()
    return nil
end
env.SetCVar = function() end
env.Settings = {
    GetCVarMask = function()
        return 0
    end,
}
env.Enum = { NamePlateStackType = { None = 0, Enemy = 1, Friendly = 2 } }
env.InCombatLockdown = function()
    return false
end

local svStore = {}
local globalStore = { cvarScoreHistory = {} }
local GRIPEMS = {
    version = "headless",
    Print = function() end,
    Debug = function() end,
    Fire = function() end,
    Settings = {
        db = { global = globalStore },
        Get = function(_, key)
            return svStore[key]
        end,
        Set = function(_, key, value)
            svStore[key] = value
        end,
    },
}

-- ---------------------------------------------------------------------------
-- Load the REAL modules into the sandbox, in dependency order.
-- ---------------------------------------------------------------------------

local function loadModule(candidates)
    for _, path in ipairs(candidates) do
        -- loadfile is dev-harness file I/O, intentionally outside the addon WoW std.
        -- selene: allow(undefined_variable)
        local chunk = loadfile(path)
        if chunk then
            setfenv(chunk, env)
            chunk(ADDON_NAME, GRIPEMS)
            return true
        end
    end
    return false
end

assert(
    loadModule({
        "Data/Defaults.lua",
        "../Data/Defaults.lua",
        "GRIP/EMS/Data/Defaults.lua",
    }),
    "could not locate Data/Defaults.lua (run from the EMS root)"
)
assert(
    loadModule({
        "Data/CvarProfileManager.lua",
        "../Data/CvarProfileManager.lua",
        "GRIP/EMS/Data/CvarProfileManager.lua",
    }),
    "could not locate Data/CvarProfileManager.lua (run from the EMS root)"
)

local CPM = GRIPEMS.CvarProfileManager
assert(CPM and CPM._ScoreHistoryPush and CPM.RecordHealthScore and CPM.ComputeHealthScore, "CPM score API missing")

local realComputeHealthScore = CPM.ComputeHealthScore
local fakeScore = 80

local function reset()
    for k in pairs(svStore) do
        svStore[k] = nil
    end
    globalStore.cvarScoreHistory = {}
    fakeScore = 80
    CPM.ComputeHealthScore = function()
        return fakeScore, 0, 0
    end
end

local function history()
    return globalStore.cvarScoreHistory
end

-- ---------------------------------------------------------------------------
-- Cases.
-- ---------------------------------------------------------------------------

test("T1 _ScoreHistoryPush appends under cap, preserves order", function()
    local ring = {}
    CPM._ScoreHistoryPush(ring, { s = 1 }, 60)
    CPM._ScoreHistoryPush(ring, { s = 2 }, 60)
    CPM._ScoreHistoryPush(ring, { s = 3 }, 60)
    assertEqual(3, #ring, "entry count")
    assertEqual(1, ring[1].s, "oldest first")
    assertEqual(2, ring[2].s, "middle preserved")
    assertEqual(3, ring[3].s, "newest last")
end)

test("T2 _ScoreHistoryPush trims oldest-first past cap 60", function()
    local ring = {}
    for i = 1, 65 do
        CPM._ScoreHistoryPush(ring, { s = i }, 60)
    end
    assertEqual(60, #ring, "capped at 60")
    assertEqual(6, ring[1].s, "five oldest trimmed")
    assertEqual(65, ring[60].s, "newest survives")
end)

test("T3 resnapshot dedupes same score, records changed score", function()
    reset()
    CPM:RecordHealthScore("resnapshot")
    assertEqual(1, #history(), "first resnapshot records into an empty ring")
    CPM:RecordHealthScore("resnapshot")
    assertEqual(1, #history(), "unchanged score is skipped")
    fakeScore = 90
    CPM:RecordHealthScore("resnapshot")
    assertEqual(2, #history(), "changed score records")
    local newest = history()[2]
    assertEqual(90, newest.s, "entry score")
    assertEqual("TestChar", newest.c, "entry character")
    assertEqual("number", type(newest.t), "entry time is numeric")
end)

test("T4 login records even when the score is unchanged", function()
    reset()
    CPM:RecordHealthScore("login")
    CPM:RecordHealthScore("login")
    CPM:RecordHealthScore("login")
    assertEqual(3, #history(), "every login records")
    assertEqual(80, history()[3].s, "unchanged score still recorded")
    assertTrue(history()[3].t > history()[1].t, "timestamps advance")
end)

test("T5 extracted ComputeHealthScore runs headless", function()
    reset()
    CPM.ComputeHealthScore = realComputeHealthScore
    local score, matchWeight, totalWeight = CPM:ComputeHealthScore()
    assertEqual("number", type(score), "score type")
    assertTrue(score >= 0 and score <= 100, "score in range")
    assertEqual("number", type(matchWeight), "matchWeight type")
    assertEqual("number", type(totalWeight), "totalWeight type")
    assertTrue(totalWeight > 0, "catalog yields scoreable rows")
    assertTrue(matchWeight <= totalWeight, "matchWeight bounded by totalWeight")
end)

-- ---------------------------------------------------------------------------
-- Run.
-- ---------------------------------------------------------------------------

local passed = 0
local failed = 0
for _, t in ipairs(tests) do
    local ok, err = pcall(t.fn)
    if ok then
        passed = passed + 1
        print("PASS  " .. t.name)
    else
        failed = failed + 1
        print("FAIL  " .. t.name .. " -- " .. tostring(err))
    end
end
print(string.format("RESULT %d passed, %d failed", passed, failed))
os.exit(failed > 0 and 1 or 0)
