-- GRIP-EMS: Import Frame (Two-Stage)
-- Stage 1: AceGUI paste window for import export strings
-- Stage 2: Native-frame picker with ScrollBox for selective import

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS")
local AceGUI = LibStub("AceGUI-3.0")

-- Upvalue accessor for Defaults
local function D()
    return GRIPEMS.Defaults
end

GRIPEMS.ImportFrame = {}
local IF = GRIPEMS.ImportFrame

local frame = nil -- lazy-created native Frame, reused
local pasteStage = nil -- native Frame for stage 1
local pickStage = nil -- native Frame for stage 2
local previewData = nil -- result from LI.Preview()

-- Pick stage sub-references
local pickScrollBox, pickScrollBar, pickScrollView, pickDataProvider
local pickHeaderLabel, pickSummaryLine, pickImportBtn

---------------------------------------------------------------------------
-- UpdateImportCount: refresh the Import Selected button label + state
---------------------------------------------------------------------------
local function UpdateImportCount()
    if not pickDataProvider or not pickImportBtn then
        return
    end

    local count = 0
    for _, entry in pickDataProvider:EnumerateEntireRange() do
        if
            (entry.type == "sequence" or entry.type == "variable")
            and entry.entry
            and entry.entry.conflictAction ~= "skip"
        then
            count = count + 1
        end
    end

    pickImportBtn.label:SetText(string.format(L["GEMS_IMPORT_PREVIEW_IMPORT_SELECTED"], count))
    if count == 0 then
        pickImportBtn:Disable()
        pickImportBtn:SetAlpha(0.5)
    else
        pickImportBtn:Enable()
        pickImportBtn:SetAlpha(1.0)
    end
end

---------------------------------------------------------------------------
-- Variable auto-select: re-resolve deps and refresh picker rows
---------------------------------------------------------------------------

local function ResolveAndRefreshVarDeps()
    if not previewData or not pickDataProvider or not pickScrollBox then
        return
    end
    local LI = GRIPEMS.LegacyImport
    if LI and LI.ResolveImportVariableDeps then
        LI.ResolveImportVariableDeps(previewData)
    end
    -- Refresh visible variable rows
    pickScrollBox:ForEachFrame(function(btn)
        if btn._importRefresh then
            btn._importRefresh()
        end
    end)
    UpdateImportCount()
end

---------------------------------------------------------------------------
-- Row initializer for pick stage ScrollBox
---------------------------------------------------------------------------

--- Initialize or refresh a pick-stage row.
--- @param button Button The reusable row frame
--- @param data table Row data with type, index, entry fields
local function InitPickRow(button, data)
    local UI = GRIPEMS.UI
    local C = UI.Colors
    local rowHeight = D().IMPORT_PICKER_ROW_HEIGHT

    button:SetHeight(rowHeight)

    -- Ensure sub-elements created once
    if not button._pickInit then
        button._pickInit = true

        -- Background
        local bg = button:CreateTexture(nil, "BACKGROUND")
        bg:SetAllPoints()
        bg:SetColorTexture(0, 0, 0, 0)
        button._bg = bg

        -- CheckButton
        local cb = CreateFrame("CheckButton", nil, button, "UICheckButtonTemplate")
        cb:SetSize(18, 18)
        cb:SetPoint("LEFT", button, "LEFT", 4, 0)
        cb:SetHitRectInsets(0, 0, 0, 0)
        button._checkBtn = cb

        -- Icon texture
        local icon = button:CreateTexture(nil, "ARTWORK")
        icon:SetSize(20, 20)
        icon:SetPoint("LEFT", cb, "RIGHT", 4, 0)
        button._icon = icon

        -- Name label
        local nameLabel = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(nameLabel, 11)
        nameLabel:SetPoint("LEFT", icon, "RIGHT", 6, 0)
        nameLabel:SetJustifyH("LEFT")
        nameLabel:SetWordWrap(false)
        button._nameLabel = nameLabel

        -- Info label (versions/steps)
        local infoLabel = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(infoLabel, 10)
        infoLabel:SetJustifyH("LEFT")
        infoLabel:SetWordWrap(false)
        button._infoLabel = infoLabel

        -- Source version label (legacy format version stamp)
        local sourceLabel = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(sourceLabel, 9)
        sourceLabel:SetJustifyH("LEFT")
        sourceLabel:SetWordWrap(false)
        button._sourceLabel = sourceLabel

        -- Status badge
        local statusLabel = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(statusLabel, 10)
        statusLabel:SetJustifyH("RIGHT")
        button._statusLabel = statusLabel

        -- Action button (for existing sequences)
        local actionBtn = UI:CreateButton(button, "", 70, 20)
        actionBtn:SetPoint("RIGHT", button, "RIGHT", -4, 0)
        button._actionBtn = actionBtn

        -- Section header label (for header rows)
        local headerText = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(headerText, 11, "OUTLINE")
        headerText:SetPoint("LEFT", button, "LEFT", 8, 0)
        headerText:SetJustifyH("LEFT")
        button._headerText = headerText

        -- Auto-select badge (for variable rows)
        local autoBadge = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(autoBadge, 9)
        autoBadge:SetJustifyH("RIGHT")
        button._autoBadge = autoBadge
    end

    -- Reset visibility
    button._checkBtn:Hide()
    button._icon:Hide()
    button._nameLabel:Hide()
    button._infoLabel:Hide()
    button._sourceLabel:Hide()
    button._statusLabel:Hide()
    button._actionBtn:Hide()
    button._headerText:Hide()
    button._autoBadge:Hide()
    button._bg:SetColorTexture(0, 0, 0, 0)

    -----------------------------------------------------------------------
    -- Section header rows
    -----------------------------------------------------------------------
    if data.type == "seqHeader" or data.type == "varHeader" then
        button._headerText:Show()
        button._headerText:SetTextColor(C.textSecondary:GetRGBA())
        button._bg:SetColorTexture(C.bgPanel:GetRGB())
        button._bg:SetAlpha(0.3)
        if data.type == "seqHeader" then
            button._headerText:SetText(string.format(L["GEMS_IMPORT_PREVIEW_SEQ_HEADER"], data.count or 0))
        else
            button._headerText:SetText(string.format(L["GEMS_IMPORT_PREVIEW_VAR_HEADER"], data.count or 0))
        end
        button:SetScript("OnClick", nil)
        return
    end

    -----------------------------------------------------------------------
    -- Sequence rows
    -----------------------------------------------------------------------
    if data.type == "sequence" then
        local entry = data.entry

        -- CheckButton
        button._checkBtn:Show()
        button._checkBtn:SetChecked(entry.conflictAction ~= "skip")
        button._checkBtn:SetScript("OnClick", function(self)
            if self:GetChecked() then
                if entry._wasRename then
                    entry.conflictAction = "rename"
                    entry._wasRename = nil
                else
                    entry.conflictAction = "import"
                end
            else
                if entry.conflictAction == "rename" then
                    entry._wasRename = true
                end
                entry.conflictAction = "skip"
            end
            ResolveAndRefreshVarDeps()
        end)

        -- Icon
        button._icon:Show()
        button._icon:SetTexture(UI:ResolveIcon(entry.icon))

        -- Name
        button._nameLabel:Show()
        button._nameLabel:SetText(entry.name or "")
        button._nameLabel:SetTextColor(C.textPrimary:GetRGBA())
        button._nameLabel:SetWidth(200)

        -- Info: "N versions, N steps"
        button._infoLabel:Show()
        button._infoLabel:SetPoint("LEFT", button._nameLabel, "RIGHT", 8, 0)
        button._infoLabel:SetText(
            string.format(L["GEMS_IMPORT_PREVIEW_INFO"], entry.versionCount or 1, entry.stepCount or 0)
        )
        button._infoLabel:SetTextColor(C.textSecondary:GetRGBA())

        -- Spell warning count (appended to info label)
        if entry.spellWarnCount and entry.spellWarnCount > 0 then
            local infoText = button._infoLabel:GetText() or ""
            infoText = infoText
                .. "  |cFFFF6600"
                .. string.format(L["GEMS_SPELL_STATUS_LABEL"], entry.spellWarnCount)
                .. "|r"
            button._infoLabel:SetText(infoText)
        end

        -- Spell info count (known but unlearned, informational)
        if entry.spellInfoCount and entry.spellInfoCount > 0 then
            local infoText = button._infoLabel:GetText() or ""
            infoText = infoText
                .. "  |cFF4499DD"
                .. string.format(L["GEMS_SPELL_INFO_LABEL"], entry.spellInfoCount)
                .. "|r"
            button._infoLabel:SetText(infoText)
        end

        -- Freeform step count (raw macro commands, informational)
        if entry.freeformCount and entry.freeformCount > 0 then
            local infoText = button._infoLabel:GetText() or ""
            infoText = infoText
                .. "  |cFF9999BB"
                .. string.format(L["GEMS_IMPORT_FREEFORM_LABEL"], entry.freeformCount)
                .. "|r"
            button._infoLabel:SetText(infoText)
        end

        -- Source version stamp (legacy format metadata)
        if entry.sourceVersion and entry.sourceVersion ~= "" then
            button._sourceLabel:Show()
            button._sourceLabel:SetPoint("LEFT", button._infoLabel, "RIGHT", 8, 0)
            button._sourceLabel:SetText(string.format("(exported from v%s)", entry.sourceVersion))
            button._sourceLabel:SetTextColor(C.textSecondary:GetRGBA())
        end

        -- Status badge
        button._statusLabel:Show()
        if entry.status == "new" then
            button._statusLabel:SetText(L["GEMS_IMPORT_PREVIEW_NEW"])
            button._statusLabel:SetTextColor(C.textSuccess:GetRGBA())
        elseif entry.status == "identical" then
            button._statusLabel:SetText(L["GEMS_IMPORT_PREVIEW_IDENTICAL"])
            button._statusLabel:SetTextColor(C.textSecondary:GetRGBA())
        else
            button._statusLabel:SetText(L["GEMS_IMPORT_PREVIEW_DIFFERENT"])
            button._statusLabel:SetTextColor(C.textWarning:GetRGBA())
        end

        -- Action dropdown (for identical and different sequences)
        if entry.status ~= "new" then
            button._actionBtn:Show()
            button._statusLabel:SetPoint("RIGHT", button._actionBtn, "LEFT", -6, 0)

            -- Update action button label
            local actionLabel = L["GEMS_IMPORT_PREVIEW_ACTION_SKIP"]
            if entry.conflictAction == "import" then
                actionLabel = L["GEMS_IMPORT_PREVIEW_ACTION_REPLACE"]
            elseif entry.conflictAction == "rename" then
                actionLabel = L["GEMS_IMPORT_PREVIEW_ACTION_RENAME"]
            end
            button._actionBtn.label:SetText(actionLabel)

            button._actionBtn:SetScript("OnClick", function(self)
                MenuUtil.CreateContextMenu(self, function(_, rootDescription)
                    -- Compare option (only for sequences with differences)
                    if entry.status == "different" then
                        rootDescription:CreateButton(L["GEMS_IMPORT_COMPARE"], function()
                            local LI = GRIPEMS.LegacyImport
                            local Engine = GRIPEMS.Engine

                            -- Incoming steps: compile default version from seqObj
                            local incomingSteps = {}
                            if entry.seqObj then
                                local macros = entry.seqObj.Macros
                                    or entry.seqObj.MacroVersions
                                    or entry.seqObj.Versions
                                if macros and #macros > 0 then
                                    local defaultIdx = 1
                                    if entry.seqObj.MetaData and entry.seqObj.MetaData.Default then
                                        defaultIdx = tonumber(entry.seqObj.MetaData.Default) or 1
                                    end
                                    if defaultIdx < 1 or defaultIdx > #macros then
                                        defaultIdx = 1
                                    end
                                    local compiled = LI.CompileMacroVersion(macros[defaultIdx])
                                    if compiled and compiled.steps then
                                        incomingSteps = compiled.steps
                                    end
                                end
                            end

                            -- Existing steps: active version from Engine
                            local existingSteps = {}
                            if Engine and Engine.sequences and Engine.sequences[entry.name] then
                                local seqEntry = Engine.sequences[entry.name]
                                if seqEntry.data then
                                    local ver = Engine:GetActiveVersion(seqEntry.data)
                                    if ver and ver.steps then
                                        existingSteps = ver.steps
                                    end
                                end
                            end

                            local CF = GRIPEMS.ComparisonFrame
                            if CF then
                                CF:Show(
                                    entry.name .. " (" .. L["GEMS_COMPARE_LEFT_LABEL"] .. ")",
                                    existingSteps,
                                    entry.name .. " (" .. L["GEMS_COMPARE_RIGHT_LABEL"] .. ")",
                                    incomingSteps
                                )
                            end
                        end)
                    end
                    rootDescription:CreateButton(L["GEMS_IMPORT_PREVIEW_ACTION_SKIP"], function()
                        entry.conflictAction = "skip"
                        entry._wasRename = nil
                        button._checkBtn:SetChecked(false)
                        button._actionBtn.label:SetText(L["GEMS_IMPORT_PREVIEW_ACTION_SKIP"])
                        ResolveAndRefreshVarDeps()
                    end)
                    rootDescription:CreateButton(L["GEMS_IMPORT_PREVIEW_ACTION_REPLACE"], function()
                        entry.conflictAction = "import"
                        entry._wasRename = nil
                        button._checkBtn:SetChecked(true)
                        button._actionBtn.label:SetText(L["GEMS_IMPORT_PREVIEW_ACTION_REPLACE"])
                        ResolveAndRefreshVarDeps()
                    end)
                    rootDescription:CreateButton(L["GEMS_IMPORT_PREVIEW_ACTION_RENAME"], function()
                        entry.conflictAction = "rename"
                        entry._wasRename = nil
                        button._checkBtn:SetChecked(true)
                        button._actionBtn.label:SetText(L["GEMS_IMPORT_PREVIEW_ACTION_RENAME"])
                        ResolveAndRefreshVarDeps()
                    end)
                end)
            end)
        else
            button._statusLabel:SetPoint("RIGHT", button, "RIGHT", -8, 0)
        end

        button:SetScript("OnClick", nil)
        return
    end

    -----------------------------------------------------------------------
    -- Variable rows
    -----------------------------------------------------------------------
    if data.type == "variable" then
        local entry = data.entry

        -- CheckButton
        button._checkBtn:Show()
        button._checkBtn:SetChecked(entry.conflictAction ~= "skip")
        button._checkBtn:SetScript("OnClick", function(self)
            if self:GetChecked() then
                entry.conflictAction = "import"
                entry.manualSelect = true
                entry.manualDeselect = nil
            else
                entry.conflictAction = "skip"
                entry.manualDeselect = true
                entry.manualSelect = nil
                entry.autoSelected = false
            end
            UpdateImportCount()
        end)

        -- Name
        button._nameLabel:Show()
        button._nameLabel:SetPoint("LEFT", button._checkBtn, "RIGHT", 6, 0)
        button._nameLabel:SetText(entry.name or "")
        button._nameLabel:SetTextColor(C.textPrimary:GetRGBA())

        -- Auto badge
        if entry.autoSelected then
            button._autoBadge:Show()
            button._autoBadge:SetPoint("RIGHT", button._statusLabel, "LEFT", -6, 0)
            button._autoBadge:SetText(L["GEMS_IMPORT_PICK_AUTO"])
            button._autoBadge:SetTextColor(C.keybindGold:GetRGBA())
        end

        -- Refresh callback for auto-select updates
        button._importRefresh = function()
            button._checkBtn:SetChecked(entry.conflictAction ~= "skip")
            if entry.autoSelected then
                button._autoBadge:Show()
                button._autoBadge:SetPoint("RIGHT", button._statusLabel, "LEFT", -6, 0)
                button._autoBadge:SetText(L["GEMS_IMPORT_PICK_AUTO"])
                button._autoBadge:SetTextColor(C.keybindGold:GetRGBA())
            else
                button._autoBadge:Hide()
            end
        end

        -- Status badge
        button._statusLabel:Show()
        button._statusLabel:SetPoint("RIGHT", button, "RIGHT", -8, 0)
        if entry.status == "new" then
            button._statusLabel:SetText(L["GEMS_IMPORT_PREVIEW_NEW"])
            button._statusLabel:SetTextColor(C.textSuccess:GetRGBA())
        elseif entry.status == "identical" then
            button._statusLabel:SetText(L["GEMS_IMPORT_PREVIEW_IDENTICAL"])
            button._statusLabel:SetTextColor(C.textSecondary:GetRGBA())
        else
            button._statusLabel:SetText(L["GEMS_IMPORT_PREVIEW_DIFFERENT"])
            button._statusLabel:SetTextColor(C.textWarning:GetRGBA())
        end

        button:SetScript("OnClick", nil)
        return
    end
end

---------------------------------------------------------------------------
-- ShowPickStage: transition from paste to pick
---------------------------------------------------------------------------

local function ShowPickStage()
    if not previewData or not previewData.ok then
        return
    end
    if not pasteStage or not pickStage or not frame then
        return
    end

    pasteStage:Hide()
    pickStage:Show()

    -- Update frame title
    frame.titleText:SetText("GRIP-EMS: " .. L["GEMS_IMPORT_PREVIEW_TITLE"])

    -- Header: use collection metadata if available, else generic count
    local meta = previewData.exportMeta
    if meta and meta.collectionName and meta.collectionName ~= "" and meta.author and meta.author ~= "" then
        pickHeaderLabel:SetText(string.format(L["GEMS_IMPORT_COLLECTION_HEADER"], meta.collectionName, meta.author))
    elseif meta and meta.collectionName and meta.collectionName ~= "" then
        pickHeaderLabel:SetText(meta.collectionName)
    else
        pickHeaderLabel:SetText(
            string.format(
                L["GEMS_IMPORT_PREVIEW_HEADER"],
                previewData.totalSequences or 0,
                previewData.totalVariables or 0
            )
        )
    end

    -- Summary: "N new, N existing"
    local parts = {}
    local newCount = previewData.newSequences or 0
    local existCount = previewData.existingSequences or 0
    if newCount > 0 then
        parts[#parts + 1] = string.format(L["GEMS_IMPORT_PREVIEW_NEW_COUNT"], newCount)
    end
    if existCount > 0 then
        parts[#parts + 1] = string.format(L["GEMS_IMPORT_PREVIEW_EXISTING_COUNT"], existCount)
    end
    pickSummaryLine:SetText(table.concat(parts, ", "))

    -- Build flat data array for ScrollBox
    local flatData = {}

    if previewData.totalSequences > 0 then
        flatData[#flatData + 1] = {
            type = "seqHeader",
            count = previewData.totalSequences,
        }
        for i, entry in ipairs(previewData.sequences) do
            flatData[#flatData + 1] = {
                type = "sequence",
                index = i,
                entry = entry,
            }
        end
    end

    if previewData.totalVariables > 0 then
        flatData[#flatData + 1] = {
            type = "varHeader",
            count = previewData.totalVariables,
        }
        for i, entry in ipairs(previewData.variables) do
            flatData[#flatData + 1] = {
                type = "variable",
                index = i,
                entry = entry,
            }
        end
    end

    -- Populate DataProvider
    pickDataProvider = CreateDataProvider()
    for _, rowData in ipairs(flatData) do
        pickDataProvider:Insert(rowData)
    end
    pickScrollBox:SetDataProvider(pickDataProvider)

    -- Auto-select variables referenced by selected sequences
    ResolveAndRefreshVarDeps()
end

---------------------------------------------------------------------------
-- ShowPasteStage: transition back to paste
---------------------------------------------------------------------------

local function ShowPasteStage()
    if not pickStage or not pasteStage or not frame then
        return
    end
    pickStage:Hide()
    pasteStage:Show()
    previewData = nil
    frame.titleText:SetText("GRIP-EMS: Import")
end

---------------------------------------------------------------------------
-- CreatePickStage: builds the native-frame picker UI (once)
---------------------------------------------------------------------------

local function CreatePickStage(rawFrame)
    local UI = GRIPEMS.UI
    local C = UI.Colors

    pickStage = CreateFrame("Frame", nil, rawFrame)
    pickStage:SetPoint("TOPLEFT", rawFrame, "TOPLEFT", 10, -32)
    pickStage:SetPoint("BOTTOMRIGHT", rawFrame, "BOTTOMRIGHT", -10, 4)
    pickStage:Hide()

    -- Header label
    pickHeaderLabel = pickStage:CreateFontString(nil, "OVERLAY")
    UI:SetFont(pickHeaderLabel, 13)
    pickHeaderLabel:SetPoint("TOPLEFT", pickStage, "TOPLEFT", 4, -4)
    pickHeaderLabel:SetTextColor(C.textPrimary:GetRGBA())

    -- Summary line
    pickSummaryLine = pickStage:CreateFontString(nil, "OVERLAY")
    UI:SetFont(pickSummaryLine, 10)
    pickSummaryLine:SetPoint("TOPLEFT", pickHeaderLabel, "BOTTOMLEFT", 0, -4)
    pickSummaryLine:SetTextColor(C.textSecondary:GetRGBA())

    -------------------------------------------------------------------
    -- Bottom bar (36px)
    -------------------------------------------------------------------
    local bottomBar = CreateFrame("Frame", nil, pickStage)
    bottomBar:SetHeight(D().BUTTON_BAR_HEIGHT)
    bottomBar:SetPoint("BOTTOMLEFT", pickStage, "BOTTOMLEFT", 0, 0)
    bottomBar:SetPoint("BOTTOMRIGHT", pickStage, "BOTTOMRIGHT", 0, 0)

    -- Select All
    local selectAllBtn = UI:CreateButton(bottomBar, L["GEMS_IMPORT_PREVIEW_SELECT_ALL"], 90, 26)
    selectAllBtn:SetPoint("LEFT", bottomBar, "LEFT", 4, 0)
    selectAllBtn:SetScript("OnEnter", function(self)
        UI:ShowTooltip(self, L["GEMS_IMPORT_PREVIEW_SELECT_ALL"], L["GEMS_IMPORT_SELECT_ALL_DESC"])
    end)
    selectAllBtn:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)
    selectAllBtn:SetScript("OnClick", function()
        if not pickDataProvider then
            return
        end
        for _, entry in pickDataProvider:EnumerateEntireRange() do
            if entry.type == "sequence" or entry.type == "variable" then
                entry.entry.conflictAction = "import"
                entry.entry._wasRename = nil
                entry.entry.manualSelect = nil
                entry.entry.manualDeselect = nil
                entry.entry.autoSelected = false
            end
        end
        pickScrollBox:ForEachFrame(function(btn)
            if btn._checkBtn and btn._checkBtn:IsShown() then
                btn._checkBtn:SetChecked(true)
            end
            if btn._actionBtn and btn._actionBtn:IsShown() then
                btn._actionBtn.label:SetText(L["GEMS_IMPORT_PREVIEW_ACTION_REPLACE"])
            end
        end)
        ResolveAndRefreshVarDeps()
    end)

    -- Deselect All
    local deselectAllBtn = UI:CreateButton(bottomBar, L["GEMS_IMPORT_PREVIEW_DESELECT_ALL"], 100, 26)
    deselectAllBtn:SetPoint("LEFT", selectAllBtn, "RIGHT", 6, 0)
    deselectAllBtn:SetScript("OnEnter", function(self)
        UI:ShowTooltip(self, L["GEMS_IMPORT_PREVIEW_DESELECT_ALL"], L["GEMS_IMPORT_DESELECT_ALL_DESC"])
    end)
    deselectAllBtn:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)
    deselectAllBtn:SetScript("OnClick", function()
        if not pickDataProvider then
            return
        end
        for _, entry in pickDataProvider:EnumerateEntireRange() do
            if entry.type == "sequence" or entry.type == "variable" then
                entry.entry.conflictAction = "skip"
                entry.entry._wasRename = nil
                entry.entry.manualSelect = nil
                entry.entry.manualDeselect = nil
                entry.entry.autoSelected = false
            end
        end
        pickScrollBox:ForEachFrame(function(btn)
            if btn._checkBtn and btn._checkBtn:IsShown() then
                btn._checkBtn:SetChecked(false)
            end
            if btn._actionBtn and btn._actionBtn:IsShown() then
                btn._actionBtn.label:SetText(L["GEMS_IMPORT_PREVIEW_ACTION_SKIP"])
            end
            if btn._autoBadge then
                btn._autoBadge:Hide()
            end
        end)
        UpdateImportCount()
    end)

    -- Import Selected (right-aligned, green-tinted)
    pickImportBtn = UI:CreateButton(bottomBar, "", 160, 26)
    pickImportBtn:SetPoint("RIGHT", bottomBar, "RIGHT", -4, 0)
    pickImportBtn:SetBackdropColor(C.bgSave:GetRGBA())
    pickImportBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.bgSaveHover:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
    end)
    pickImportBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgSave:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
    end)
    pickImportBtn:SetScript("OnClick", function()
        if not previewData then
            return
        end

        -- Build selections table
        local selections = { sequences = {}, variables = {} }
        if pickDataProvider then
            for _, rowData in pickDataProvider:EnumerateEntireRange() do
                if rowData.type == "sequence" then
                    selections.sequences[rowData.index] = {
                        selected = rowData.entry.conflictAction ~= "skip",
                        action = rowData.entry.conflictAction,
                    }
                elseif rowData.type == "variable" then
                    selections.variables[rowData.index] = {
                        selected = rowData.entry.conflictAction ~= "skip",
                        action = rowData.entry.conflictAction,
                    }
                end
            end
        end

        local LI = GRIPEMS.LegacyImport
        local ok, results = LI.CommitSelected(previewData, selections)
        if ok then
            -- Print summary
            local seqCount = results.count or 0
            local varCount = results.varsImported or 0
            GRIPEMS:Print(string.format(L["GEMS_IMPORT_PREVIEW_SUMMARY"], seqCount, varCount))
            for _, name in ipairs(results.names or {}) do
                local stepCount = results.stepCounts and results.stepCounts[name] or 0
                GRIPEMS:Print(string.format(L["GEMS_IMPORT_ENTRY"], name, stepCount))
            end
            if results.warnings then
                for _, w in ipairs(results.warnings) do
                    GRIPEMS:Print(string.format(L["GEMS_IMPORT_WARNING"], w))
                end
            end
            -- Post-import repair check (inform only, do not auto-open RepairFrame)
            local RA = GRIPEMS.RepairAnalyzer
            if RA and results.names then
                for _, iName in ipairs(results.names) do
                    local seqEntry = GRIPEMS.Engine and GRIPEMS.Engine.sequences and GRIPEMS.Engine.sequences[iName]
                    if seqEntry and seqEntry.data then
                        local issues = RA:Analyze(seqEntry.data, iName)
                        if #issues > 0 then
                            GRIPEMS:Print(string.format(L["GEMS_REPAIR_IMPORT_ISSUES"], iName, #issues, iName))
                        end
                    end
                end
            end
            if frame then
                frame:Hide()
            end
        else
            GRIPEMS:Print(string.format(L["GEMS_IMPORT_FAILED"], tostring(results)))
        end
    end)

    -- Cancel (left of Import Selected)
    local cancelBtn = UI:CreateButton(bottomBar, L["GEMS_IMPORT_PREVIEW_CANCEL"], 80, 26)
    cancelBtn:SetPoint("RIGHT", pickImportBtn, "LEFT", -6, 0)
    cancelBtn:SetScript("OnEnter", function(self)
        UI:ShowTooltip(self, L["GEMS_IMPORT_PREVIEW_CANCEL"], L["GEMS_IMPORT_CANCEL_DESC"])
    end)
    cancelBtn:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)
    cancelBtn:SetScript("OnClick", function()
        ShowPasteStage()
    end)

    -------------------------------------------------------------------
    -- ScrollBox (between summary and bottom bar)
    -------------------------------------------------------------------
    pickScrollBox = CreateFrame("Frame", nil, pickStage, "WowScrollBoxList")
    pickScrollBox:SetPoint("TOPLEFT", pickSummaryLine, "BOTTOMLEFT", 0, -8)
    pickScrollBox:SetPoint("BOTTOMRIGHT", bottomBar, "TOPRIGHT", -18, 4)

    pickScrollBar = CreateFrame("EventFrame", nil, pickStage, "MinimalScrollBar")
    pickScrollBar:SetPoint("TOPLEFT", pickScrollBox, "TOPRIGHT", 2, 0)
    pickScrollBar:SetPoint("BOTTOMLEFT", pickScrollBox, "BOTTOMRIGHT", 2, 0)

    pickScrollView = CreateScrollBoxListLinearView()
    pickScrollView:SetElementExtent(D().IMPORT_PICKER_ROW_HEIGHT)

    pickScrollView:SetElementInitializer("Button", function(button, data)
        InitPickRow(button, data)
    end)

    ScrollUtil.InitScrollBoxListWithScrollBar(pickScrollBox, pickScrollBar, pickScrollView)

    -- Dark backdrop behind scroll area
    local scrollBg = CreateFrame("Frame", nil, pickStage, "BackdropTemplate")
    scrollBg:SetPoint("TOPLEFT", pickScrollBox, "TOPLEFT", 0, 0)
    scrollBg:SetPoint("BOTTOMRIGHT", pickScrollBar, "BOTTOMRIGHT", 0, 0)
    scrollBg:SetFrameLevel(pickStage:GetFrameLevel())
    UI:ApplyBackdrop(scrollBg, UI.Backdrops.panel, C.bgInput, C.border)

    pickDataProvider = CreateDataProvider()
    pickScrollBox:SetDataProvider(pickDataProvider)
end

---------------------------------------------------------------------------
-- IF:Show() -- main entry point (creates frame on first call)
---------------------------------------------------------------------------

--- Show the import frame. Creates the frame on first call, reuses after.
--- Always resets to paste stage on show.
function IF:Show()
    if not frame then
        local C = GRIPEMS.UI.Colors
        local UI = GRIPEMS.UI

        frame = CreateFrame("Frame", "GRIPEMS_ImportFrame", UIParent, "BackdropTemplate")
        frame:SetSize(D().IMPORT_PICKER_WIDTH, D().IMPORT_PICKER_HEIGHT)
        frame:SetPoint("CENTER")
        frame:SetFrameStrata("DIALOG")
        frame:SetClampedToScreen(true)
        UI:ApplyBackdrop(frame, UI.Backdrops.panel, C.bgMain, C.border)
        frame:SetMovable(true)
        frame:Hide()

        -- ESC to close (intercept before MainFrame sees it)
        frame:EnableKeyboard(true)
        frame:SetPropagateKeyboardInput(true)
        frame:SetScript("OnKeyDown", function(self, key)
            if key == "ESCAPE" then
                self:SetPropagateKeyboardInput(false)
                self:Hide()
            else
                self:SetPropagateKeyboardInput(true)
            end
        end)

        -- Title bar (30px)
        local titleBar = CreateFrame("Frame", nil, frame, "BackdropTemplate")
        titleBar:SetHeight(30)
        titleBar:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, 0)
        titleBar:SetPoint("TOPRIGHT", frame, "TOPRIGHT", 0, 0)
        UI:ApplyBackdrop(titleBar, UI.Backdrops.panelNoBorder, C.bgDeep)

        titleBar:EnableMouse(true)
        titleBar:RegisterForDrag("LeftButton")
        titleBar:SetScript("OnDragStart", function()
            frame:StartMoving()
        end)
        titleBar:SetScript("OnDragStop", function()
            frame:StopMovingOrSizing()
        end)

        -- Title text
        local titleText = titleBar:CreateFontString(nil, "OVERLAY")
        UI:SetFont(titleText, 13, "OUTLINE")
        titleText:SetPoint("LEFT", titleBar, "LEFT", 12, 0)
        titleText:SetText("GRIP-EMS: Import")
        titleText:SetTextColor(C.gripGreen:GetRGBA())
        frame.titleText = titleText

        -- Close button (themed dark-UI X)
        local titleCloseBtn = CreateFrame("Button", nil, titleBar, "BackdropTemplate")
        titleCloseBtn:SetSize(24, 24)
        titleCloseBtn:SetPoint("TOPRIGHT", titleBar, "TOPRIGHT", -6, -3)
        UI:ApplyBackdrop(titleCloseBtn, UI.Backdrops.panel, C.bgButton, C.border)
        local closeLbl = titleCloseBtn:CreateFontString(nil, "OVERLAY")
        UI:SetFont(closeLbl, 14)
        closeLbl:SetPoint("CENTER", 0, 1)
        closeLbl:SetText("X")
        closeLbl:SetTextColor(C.textSecondary:GetRGBA())
        titleCloseBtn:SetScript("OnClick", function()
            frame:Hide()
        end)
        titleCloseBtn:SetScript("OnEnter", function(self)
            self:SetBackdropColor(C.accent:GetRGBA())
            self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
            closeLbl:SetTextColor(C.textPrimary:GetRGBA())
        end)
        titleCloseBtn:SetScript("OnLeave", function(self)
            self:SetBackdropColor(C.bgButton:GetRGBA())
            self:SetBackdropBorderColor(C.border:GetRGBA())
            closeLbl:SetTextColor(C.textSecondary:GetRGBA())
        end)

        local rawFrame = frame

        -------------------------------------------------------------------
        -- Stage 1: Paste
        -------------------------------------------------------------------
        pasteStage = CreateFrame("Frame", nil, rawFrame)
        pasteStage:SetPoint("TOPLEFT", rawFrame, "TOPLEFT", 10, -32)
        pasteStage:SetPoint("BOTTOMRIGHT", rawFrame, "BOTTOMRIGHT", -10, 4)

        -- Instructions label
        local instrLabel = pasteStage:CreateFontString(nil, "OVERLAY")
        GRIPEMS.UI:SetFont(instrLabel, 11)
        instrLabel:SetPoint("TOPLEFT", pasteStage, "TOPLEFT", 4, -4)
        instrLabel:SetText(L["GEMS_IMPORT_PASTE_INSTRUCTIONS"])
        instrLabel:SetTextColor(GRIPEMS.UI.Colors.textSecondary:GetRGBA())
        instrLabel:SetWidth(D().IMPORT_PICKER_WIDTH - 40)
        instrLabel:SetJustifyH("LEFT")
        instrLabel:SetWordWrap(true)

        -- Use AceGUI MultiLineEditBox for paste (proven, handles large text)
        local editbox = AceGUI:Create("MultiLineEditBox")
        editbox:SetLabel(L["GEMS_IMPORT_PASTE_LABEL"])
        editbox:SetNumLines(15)
        editbox:DisableButton(true)
        editbox.frame:SetParent(pasteStage)
        editbox.frame:SetPoint("TOPLEFT", instrLabel, "BOTTOMLEFT", -2, -6)
        editbox.frame:SetPoint("BOTTOMRIGHT", pasteStage, "BOTTOMRIGHT", -4, 40)
        editbox.frame:Show()

        -- Dark theme for paste editbox
        editbox.scrollBG:SetBackdrop(UI.Backdrops.panel)
        editbox.scrollBG:SetBackdropColor(C.bgInput:GetRGBA())
        editbox.scrollBG:SetBackdropBorderColor(C.border:GetRGBA())
        editbox.editBox:SetTextColor(C.textPrimary:GetRGBA())
        if editbox.label then
            editbox.label:SetTextColor(C.textSecondary:GetRGBA())
        end

        frame.editbox = editbox

        -- Button bar for paste stage
        local pasteBtnBar = CreateFrame("Frame", nil, pasteStage)
        pasteBtnBar:SetHeight(32)
        pasteBtnBar:SetPoint("BOTTOMLEFT", pasteStage, "BOTTOMLEFT", 4, 4)
        pasteBtnBar:SetPoint("BOTTOMRIGHT", pasteStage, "BOTTOMRIGHT", -4, 4)

        -- Preview button (was "Import")
        local previewBtn = GRIPEMS.UI:CreateButton(pasteBtnBar, L["GEMS_IMPORT_PREVIEW_BTN"], 150, 26)
        previewBtn:SetPoint("LEFT", pasteBtnBar, "LEFT", 0, 0)
        previewBtn:SetScript("OnEnter", function(self)
            UI:ShowTooltip(self, L["GEMS_IMPORT_PREVIEW_BTN"], L["GEMS_IMPORT_PREVIEW_DESC"])
        end)
        previewBtn:SetScript("OnLeave", function()
            GameTooltip:Hide()
        end)
        previewBtn:SetScript("OnClick", function()
            local text = editbox:GetText()
            if not text or text:trim() == "" then
                GRIPEMS:Print(L["GEMS_IMPORT_USAGE"])
                return
            end

            -- Raw macro detection (BEFORE whitespace strip -- newlines matter)
            local RI = GRIPEMS.RawImport
            if RI and RI:IsRawMacro(text) then
                local rawPreview = RI:Parse(text)
                if rawPreview and rawPreview.ok then
                    previewData = rawPreview
                    ShowPickStage()
                    return
                end
                -- If parse failed, fall through to encoded import
            end

            -- Strip whitespace/newlines (for encoded strings only)
            text = text:gsub("%s+", "")

            local LI = GRIPEMS.LegacyImport
            local preview = LI.Preview(text)
            if preview and preview.ok then
                previewData = preview
                ShowPickStage()
            else
                local errMsg = preview and preview.error or "Unknown preview error"
                GRIPEMS:Print(string.format(L["GEMS_IMPORT_FAILED"], errMsg))
            end
        end)

        -- Clear button
        local clearBtn = GRIPEMS.UI:CreateButton(pasteBtnBar, L["GEMS_IMPORT_CLEAR"], 100, 26)
        clearBtn:SetPoint("LEFT", previewBtn, "RIGHT", 8, 0)
        clearBtn:SetScript("OnEnter", function(self)
            UI:ShowTooltip(self, L["GEMS_IMPORT_CLEAR"], L["GEMS_IMPORT_CLEAR_DESC"])
        end)
        clearBtn:SetScript("OnLeave", function()
            GameTooltip:Hide()
        end)
        clearBtn:SetScript("OnClick", function()
            editbox:SetText("")
            editbox:SetFocus()
        end)

        -------------------------------------------------------------------
        -- Stage 2: Pick (created once, hidden initially)
        -------------------------------------------------------------------
        CreatePickStage(rawFrame)
    end

    -- Always reset to paste stage on show
    if not pickStage or not pasteStage or not frame then
        return
    end
    pickStage:Hide()
    pasteStage:Show()
    previewData = nil
    frame.titleText:SetText("GRIP-EMS: Import")
    frame:Show()
    frame.editbox:SetText("")
    frame.editbox:SetFocus()
end

---------------------------------------------------------------------------
-- IF:ShowFromTransmission() -- entry point for P2P received sequences
---------------------------------------------------------------------------

--- Show the import frame pre-loaded with a P2P transmission string.
--- Skips the paste stage and goes directly to the pick stage.
--- @param encodedString string The GRIP1-encoded export string
--- @param senderName string The player who sent the sequence
function IF:ShowFromTransmission(encodedString, senderName)
    if not encodedString or encodedString == "" then
        return
    end

    local LI = GRIPEMS.LegacyImport
    local preview = LI.Preview(encodedString)
    if not preview or not preview.ok then
        local errMsg = preview and preview.error or "Unknown error"
        GRIPEMS:Print(string.format(L["GEMS_IMPORT_FAILED"], errMsg))
        return
    end

    -- Ensure the frame is created (call Show first, then override stage)
    IF:Show()

    -- Store preview and switch to pick stage
    previewData = preview
    ShowPickStage()

    -- Override frame title with sender info
    if frame then
        frame.titleText:SetText("GRIP-EMS: " .. string.format(L["GEMS_IMPORT_FROM"], senderName))
    end
end

--- Hide the import frame if shown.
function IF:Hide()
    if frame then
        frame:Hide()
    end
end

--- Check if the import frame is currently shown.
--- @return boolean
function IF:IsShown()
    return frame and frame:IsShown()
end
