-- GRIP-EMS: Sequence List
-- Created: 2025 (pre-stamping)
-- Updated: 2026-07-28
-- Patch: 12.0.7.68275 Midnight (Retail LIVE)
--
-- Left panel: search box, scrollable sequence list, bottom button bar.
-- Phase 2 #7: registers row widgets with GRIPEMS.Focus on every data refresh
-- (UpdateListTargets) so MainFrame's OnKeyDown can walk rows via UP / DOWN
-- and delete via DELETE. Row mouse-clicks also set Focus list cursor so the
-- keyboard ring follows mouse interactions.

local ADDON_NAME, GRIPEMS = ...
local UI = GRIPEMS.UI
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

-- Upvalue accessor for Defaults (loaded before UI/)
local function D()
    return GRIPEMS.Defaults
end

GRIPEMS.SequenceList = {}
local SL = GRIPEMS.SequenceList

-- Runtime state
SL.searchText = ""
SL._dataDirty = true
SL._spellValidationCache = {}
SL.sortMode = "alpha"
SL.currentClassOnly = false
SL.pendingSelect = nil

-- Sort mode cycle order and display labels
local SORT_MODES = { "alpha", "class", "updated" }
local SORT_LABELS = {
    alpha = L["GEMS_UI_SORT_ALPHA"],
    class = L["GEMS_UI_SORT_CLASS"],
    updated = L["GEMS_UI_SORT_UPDATED"],
}
local SORT_TOOLTIPS = {
    alpha = L["GEMS_UI_SORT_ALPHA_TIP"],
    class = L["GEMS_UI_SORT_CLASS_TIP"],
    updated = L["GEMS_UI_SORT_UPDATED_TIP"],
}

---------------------------------------------------------------------------
-- Initialization (called from UI:InitPanels)
---------------------------------------------------------------------------

--- Build the sequence list UI inside the left panel.
--- @param parentPanel Frame The MainFrame.leftPanel
function SL:Init(parentPanel)
    if not parentPanel then
        return
    end

    -- Phase C: wrap all content in a single mountable root that fills the panel.
    -- A modern layout provider mounts SL.root into its own host; classic renders
    -- identically because root SetAllPoints the real panel.
    local root = CreateFrame("Frame", nil, parentPanel)
    root:SetAllPoints(parentPanel)
    SL.root = root
    parentPanel = root

    local C = UI.Colors

    -- Restore persisted sort mode from SavedVariables
    local S = GRIPEMS.Settings
    if S and S.db then
        local saved = S:Get("listSortMode")
        if saved and SORT_LABELS[saved] then
            SL.sortMode = saved
        else
            SL.sortMode = "alpha"
        end
        SL.currentClassOnly = S:Get("listCurrentClassOnly") and true or false
    end

    -- Remove the placeholder text
    local mainFrame = GRIPEMS_MainFrame
    if mainFrame and mainFrame.leftPlaceholder then
        mainFrame.leftPlaceholder:Hide()
        mainFrame.leftPlaceholder:SetText("")
    end

    -----------------------------------------------------------------------
    -- Search box
    -----------------------------------------------------------------------
    local searchBox = CreateFrame("EditBox", nil, parentPanel, "SearchBoxTemplate")
    searchBox:SetHeight(D().SEARCH_BOX_HEIGHT)
    searchBox:SetPoint("TOPLEFT", parentPanel, "TOPLEFT", 6, -6)
    searchBox:SetPoint("TOPRIGHT", parentPanel, "TOPRIGHT", -6, -6)
    searchBox:SetAutoFocus(false)
    searchBox:SetScript("OnTextChanged", function(self)
        SearchBoxTemplate_OnTextChanged(self)
        SL.searchText = self:GetText() or ""
        SL._dataDirty = true
        SL:RefreshDataProvider()
    end)
    searchBox:SetScript("OnEnter", function(self)
        UI:ShowTooltip(self, L["GEMS_UI_SEARCH"], L["GEMS_UI_SEARCH_DESC"])
    end)
    searchBox:SetScript("OnLeave", function()
        UI:HideTooltip()
    end)
    SL.searchBox = searchBox
    GRIPEMS.Focus:HookEditBox(searchBox)

    -----------------------------------------------------------------------
    -- Current-class filter (opt-in). Header-row checkbox above the list;
    -- mirrors listSortMode persistence. Lives here, not in the button bar,
    -- because the 280px bar is full once the Migrate button is present.
    -----------------------------------------------------------------------
    local classFilterCheck = CreateFrame("CheckButton", nil, parentPanel, "UICheckButtonTemplate")
    classFilterCheck:SetSize(24, 24)
    classFilterCheck:SetPoint("TOPLEFT", searchBox, "BOTTOMLEFT", 0, -4)
    classFilterCheck:SetChecked(SL.currentClassOnly)
    classFilterCheck:SetScript("OnClick", function(self)
        SL:SetCurrentClassOnly(self:GetChecked() and true or false)
    end)
    classFilterCheck:SetScript("OnEnter", function(self)
        UI:ShowTooltip(self, L["GEMS_UI_FILTER_CLASS"], L["GEMS_UI_FILTER_CLASS_TIP"])
    end)
    classFilterCheck:SetScript("OnLeave", function()
        UI:HideTooltip()
    end)
    local classFilterLabel = classFilterCheck:CreateFontString(nil, "OVERLAY")
    UI:SetFont(classFilterLabel, 11)
    classFilterLabel:SetPoint("LEFT", classFilterCheck, "RIGHT", 2, 0)
    classFilterLabel:SetText(L["GEMS_UI_FILTER_CLASS"])
    classFilterLabel:SetTextColor(C.textSecondary:GetRGBA())
    SL.classFilterCheck = classFilterCheck

    -----------------------------------------------------------------------
    -- Button bar (bottom)
    -----------------------------------------------------------------------
    local buttonBar = CreateFrame("Frame", nil, parentPanel)
    buttonBar:SetHeight(D().BUTTON_BAR_HEIGHT)
    buttonBar:SetPoint("BOTTOMLEFT", parentPanel, "BOTTOMLEFT", 4, 4)
    buttonBar:SetPoint("BOTTOMRIGHT", parentPanel, "BOTTOMRIGHT", -4, 4)
    SL.buttonBar = buttonBar

    local newBtn = UI:CreateButton(buttonBar, L["GEMS_UI_NEW"], 66, 26)
    newBtn:SetPoint("LEFT", buttonBar, "LEFT", 2, 0)
    newBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.bgRowHover:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
        UI:ShowTooltip(self, L["GEMS_UI_NEW"], L["GEMS_UI_NEW_DESC"])
    end)
    newBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
        UI:HideTooltip()
    end)
    newBtn:SetScript("OnClick", function()
        SL:ShowNewSequenceDialog()
    end)

    local importBtn = UI:CreateButton(buttonBar, L["GEMS_UI_IMPORT_BTN"], 66, 26)
    importBtn:SetPoint("LEFT", newBtn, "RIGHT", 4, 0)
    importBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.bgRowHover:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
        UI:ShowTooltip(self, L["GEMS_UI_IMPORT_BTN"], L["GEMS_UI_IMPORT_BTN_DESC"])
    end)
    importBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
        UI:HideTooltip()
    end)
    importBtn:SetScript("OnClick", function()
        if GRIPEMS.ImportFrame then
            GRIPEMS.ImportFrame:Show()
        end
    end)

    -- Sort cycle button (right-anchored)
    local sortBtn = UI:CreateButton(buttonBar, SORT_LABELS[SL.sortMode] or L["GEMS_UI_SORT_ALPHA"], 52, 26)
    sortBtn:SetPoint("RIGHT", buttonBar, "RIGHT", -2, 0)
    sortBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.bgRowHover:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
        UI:ShowTooltip(
            self,
            L["GEMS_UI_SORT_HINT"] .. ": " .. (SORT_TOOLTIPS[SL.sortMode] or L["GEMS_UI_SORT_ALPHA_TIP"]),
            L["GEMS_UI_SORT_CYCLE"]
        )
    end)
    sortBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
        UI:HideTooltip()
    end)
    sortBtn:SetScript("OnClick", function()
        local cur = SL.sortMode
        local nextMode = SORT_MODES[1]
        for i, m in ipairs(SORT_MODES) do
            if m == cur and SORT_MODES[i + 1] then
                nextMode = SORT_MODES[i + 1]
                break
            end
        end
        SL:SetSortMode(nextMode)
    end)
    SL.sortBtn = sortBtn

    -- Migrate button (only if migration module exists and a source sequencer is detected)
    local LM = GRIPEMS.LegacyMigrate
    if LM then
        local sourceStatus = LM.GetSourceStatus()
        if sourceStatus ~= "none" then
            local migrateBtn = UI:CreateButton(buttonBar, L["GEMS_UI_MIGRATE_BTN"], 66, 26)
            migrateBtn:SetPoint("LEFT", importBtn, "RIGHT", 4, 0)

            if sourceStatus == "active" then
                migrateBtn:SetScript("OnEnter", function(self)
                    self:SetBackdropColor(C.bgRowHover:GetRGBA())
                    self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
                    UI:ShowTooltip(self, L["GEMS_UI_MIGRATE_BTN"], L["GEMS_UI_MIGRATE_BTN_DESC"])
                end)
                migrateBtn:SetScript("OnLeave", function(self)
                    self:SetBackdropColor(C.bgButton:GetRGBA())
                    self:SetBackdropBorderColor(C.border:GetRGBA())
                    UI:HideTooltip()
                end)
                migrateBtn:SetScript("OnClick", function()
                    SL:ShowMigrateConfirm()
                end)
            else
                -- Source disabled: gray out, tooltip instructs user
                migrateBtn:SetAlpha(0.5)
                migrateBtn:SetScript("OnEnter", function(self)
                    UI:ShowTooltip(self, L["GEMS_UI_MIGRATE_BTN"], L["GEMS_MIGRATE_SOURCE_DISABLED"])
                end)
                migrateBtn:SetScript("OnLeave", function()
                    UI:HideTooltip()
                end)
                migrateBtn:SetScript("OnClick", function()
                    GRIPEMS:Print(L["GEMS_MIGRATE_SOURCE_DISABLED"])
                end)
            end
        end
    end

    -----------------------------------------------------------------------
    -- ScrollBox + ScrollBar + ScrollView
    -----------------------------------------------------------------------
    local scrollBox = CreateFrame("Frame", nil, parentPanel, "WowScrollBoxList")
    scrollBox:SetPoint("TOPLEFT", classFilterCheck, "BOTTOMLEFT", 0, -4)
    scrollBox:SetPoint("BOTTOMRIGHT", buttonBar, "TOPRIGHT", -18, 4)
    SL.scrollBox = scrollBox

    local scrollBar = CreateFrame("EventFrame", nil, parentPanel, "MinimalScrollBar")
    scrollBar:SetPoint("TOPLEFT", scrollBox, "TOPRIGHT", 2, 0)
    scrollBar:SetPoint("BOTTOMLEFT", scrollBox, "BOTTOMRIGHT", 2, 0)
    SL.scrollBar = scrollBar

    local scrollView = CreateScrollBoxListLinearView()
    scrollView:SetElementExtent(D().ROW_HEIGHT)
    SL.scrollView = scrollView

    -- Element initializer: "Button" frame type gives click/hover natively
    scrollView:SetElementInitializer("Button", function(button, data)
        SL:InitRow(button, data)
    end)

    ScrollUtil.InitScrollBoxListWithScrollBar(scrollBox, scrollBar, scrollView)

    -- Initial empty DataProvider
    local dataProvider = CreateDataProvider()
    scrollBox:SetDataProvider(dataProvider)
    SL.dataProvider = dataProvider

    -- Empty state icon (shown when no sequences)
    local emptyIcon = parentPanel:CreateTexture(nil, "OVERLAY")
    emptyIcon:SetSize(48, 48)
    emptyIcon:SetPoint("CENTER", scrollBox, "CENTER", 0, 24)
    emptyIcon:SetTexture(134400)
    emptyIcon:SetAlpha(0.3)
    emptyIcon:Hide()
    SL.emptyIcon = emptyIcon

    -- Empty state label (shown when no sequences)
    local emptyLabel = parentPanel:CreateFontString(nil, "OVERLAY")
    UI:SetFont(emptyLabel, 11)
    emptyLabel:SetPoint("CENTER", scrollBox, "CENTER", 0, -16)
    emptyLabel:SetText(L["GEMS_UI_NO_SEQUENCES"])
    emptyLabel:SetTextColor(C.textMuted:GetRGBA())
    emptyLabel:Hide()
    SL.emptyLabel = emptyLabel

    -- Empty state hint
    local emptyHint = parentPanel:CreateFontString(nil, "OVERLAY")
    UI:SetFont(emptyHint, 10)
    emptyHint:SetPoint("TOP", emptyLabel, "BOTTOM", 0, -4)
    emptyHint:SetText(L["GEMS_UI_EMPTY_HINT"])
    emptyHint:SetTextColor(C.textMuted.r, C.textMuted.g, C.textMuted.b, 0.7)
    emptyHint:SetWidth(220)
    emptyHint:SetJustifyH("CENTER")
    emptyHint:Hide()
    SL.emptyHint = emptyHint

    -----------------------------------------------------------------------
    -- Register callbacks
    -----------------------------------------------------------------------
    if GRIPEMS.RegisterCallback then
        GRIPEMS.RegisterCallback(SL, "SEQUENCE_CREATED", "OnSequenceChanged")
        GRIPEMS.RegisterCallback(SL, "SEQUENCE_DELETED", "OnSequenceChanged")
        GRIPEMS.RegisterCallback(SL, "SEQUENCE_UPDATED", "OnSequenceChanged")
        GRIPEMS.RegisterCallback(SL, "SEQUENCE_IMPORTED", "OnSequenceChanged")
        GRIPEMS.RegisterCallback(SL, "KEYBIND_CHANGED", "OnSequenceChanged")
        GRIPEMS.RegisterCallback(SL, "SPELL_VALIDATION_UPDATED", "OnSpellValidationUpdated")
    end

    -- Phase 2 #7: route DELETE key (dispatched by MainFrame OnKeyDown via
    -- Focus:Delete) to the existing confirm-dialog path. Focus tracks the
    -- currently selected list row and passes it to the handler.
    if GRIPEMS.Focus and GRIPEMS.Focus.SetListDeleteHandler then
        GRIPEMS.Focus:SetListDeleteHandler(function(widget)
            if widget and widget._seqData and widget._seqData.name then
                SL:ShowDeleteConfirm(widget._seqData.name)
            end
        end)
    end

    -- Phase C: expose the content root as the mountable "sequenceList" panel.
    if GRIPEMS.RegisterMountablePanel then
        GRIPEMS:RegisterMountablePanel("sequenceList", SL.root)
    end
end

--- Callback handler for any sequence data change.
--- @param event string Callback event name (SEQUENCE_CREATED, SEQUENCE_DELETED, ...)
--- @param name string|nil Sequence name the event applies to
function SL:OnSequenceChanged(event, name)
    GRIPEMS:Debug("SL:OnSequenceChanged triggered")
    SL._dataDirty = true
    SL._spellValidationCache = {}
    SL._healthScoreCache = {}
    self:RefreshDataProvider()

    -- Deferred-activation repair: an in-combat New Sequence queues the whole
    -- activation closure, so the dialog's deferred SelectSequence ran before
    -- the engine entry existed -- the list row highlighted but the editor
    -- load hit the missing-entry guard and cleared instead. When the queued
    -- activation lands (this event fires when combat ends), reload the editor
    -- for the still-selected name so the keybind tab gets its sequence.
    -- Dormant guard: RegisterSequenceOnly fires this event too (disabled or
    -- dormant registrations, button still nil). Repairing those re-enters
    -- SE:LoadSequence's dormant auto-activate, which re-registers and re-fires
    -- synchronously before SE.currentSequence is assigned -- an unbounded
    -- recursion for a selected disabled row. The intended flow always lands
    -- via doActivate, which registers the button BEFORE firing, so a fully
    -- active entry is the precise signature of the case being repaired.
    if event == "SEQUENCE_CREATED" and name and UI.selectedSequence == name then
        local SE = GRIPEMS.SequenceEditor
        if
            SE
            and SE.currentSequence ~= name
            and not SE._activatingDormant
            and not GRIPEMS.Engine:IsSequenceDormant(name)
        then
            SE:LoadSequence(name)
        end
    end
end

--- Callback handler for spell validation refresh (cache invalidated by SpellValidator).
function SL:OnSpellValidationUpdated()
    SL._spellValidationCache = {}
    SL._healthScoreCache = {}
    self:RefreshDataProvider()
end

--- Unregister all callbacks and clear caches to prevent leaks.
function SL:Cleanup()
    if GRIPEMS.UnregisterCallback then
        GRIPEMS.UnregisterCallback(SL, "SEQUENCE_CREATED")
        GRIPEMS.UnregisterCallback(SL, "SEQUENCE_DELETED")
        GRIPEMS.UnregisterCallback(SL, "SEQUENCE_UPDATED")
        GRIPEMS.UnregisterCallback(SL, "SEQUENCE_IMPORTED")
        GRIPEMS.UnregisterCallback(SL, "KEYBIND_CHANGED")
        GRIPEMS.UnregisterCallback(SL, "SPELL_VALIDATION_UPDATED")
    end
    SL._spellValidationCache = {}
end

---------------------------------------------------------------------------
-- Row initializer (called for each visible row by ScrollBox)
---------------------------------------------------------------------------

--- Initialize or refresh a row button with sequence data.
--- ScrollBox reuses frames; all child elements must be created once, then refreshed.
--- @param button Button The reusable row frame
--- @param data table Row data { name, icon, stepFunction, stepCount, keybind, ... }
function SL:InitRow(button, data)
    local C = UI.Colors

    -- Set button size
    button:SetHeight(D().ROW_HEIGHT)

    -- Create child elements once, then reuse
    if not button._gripInit then
        if not button.SetBackdrop then
            Mixin(button, BackdropTemplateMixin)
        end

        button:SetBackdrop(UI.Backdrops.panel)
        button:RegisterForClicks("LeftButtonUp", "RightButtonUp")

        -- Icon texture
        button.icon = button:CreateTexture(nil, "ARTWORK")
        button.icon:SetSize(28, 28)
        button.icon:SetPoint("LEFT", button, "LEFT", 4, 0)

        -- Name text
        button.nameText = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(button.nameText, 13)
        button.nameText:SetPoint("TOPLEFT", button.icon, "TOPRIGHT", 6, -1)
        button.nameText:SetPoint("RIGHT", button, "RIGHT", -60, 0)
        button.nameText:SetJustifyH("LEFT")
        button.nameText:SetWordWrap(false)

        -- Subtitle text
        button.subtitleText = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(button.subtitleText, 10)
        button.subtitleText:SetPoint("BOTTOMLEFT", button.icon, "BOTTOMRIGHT", 6, 1)
        button.subtitleText:SetPoint("RIGHT", button, "RIGHT", -60, 0)
        button.subtitleText:SetJustifyH("LEFT")
        button.subtitleText:SetWordWrap(false)

        -- Keybind text
        button.keybindText = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(button.keybindText, 11)
        button.keybindText:SetPoint("RIGHT", button, "RIGHT", -6, 0)
        button.keybindText:SetJustifyH("RIGHT")

        -- Spell warning overlay icon
        button.spellWarnIcon = button:CreateTexture(nil, "OVERLAY")
        button.spellWarnIcon:SetSize(14, 14)
        button.spellWarnIcon:SetPoint("BOTTOMRIGHT", button.icon, "BOTTOMRIGHT", 2, -2)
        button.spellWarnIcon:SetTexture("Interface\\DialogFrame\\UI-Dialog-Icon-AlertNew")
        button.spellWarnIcon:Hide()

        -- Health score overlay (numeric, top-left of icon)
        button.healthIcon = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(button.healthIcon, 9)
        button.healthIcon:SetPoint("TOPLEFT", button.icon, "TOPLEFT", -2, 2)
        button.healthIcon:Hide()

        button._gripInit = true
    end

    -- Populate from data (type-aware icon resolution)
    if type(data.icon) == "number" then
        button.icon:SetTexture(data.icon)
    elseif type(data.icon) == "string" and data.icon ~= "" then
        button.icon:SetTexture("Interface\\Icons\\" .. data.icon)
    else
        button.icon:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark")
    end
    if data.disabled then
        button.nameText:SetText("|cFF666666" .. (data.name or "") .. "  [Disabled]|r")
    else
        button.nameText:SetText(data.name or "")
    end
    button.nameText:SetTextColor(C.textPrimary:GetRGBA())

    -- Store data ref EARLY so OnClick still works if a later block errors
    button._seqData = data

    -- Dim dormant, disabled, or non-activated sequences
    local shouldDim = data.disabled or data.active == false
    if shouldDim then
        button.nameText:SetTextColor(C.textMuted:GetRGBA())
        button.icon:SetDesaturated(true)
        button.icon:SetAlpha(data.disabled and 0.3 or 0.5)
    else
        button.icon:SetDesaturated(false)
        button.icon:SetAlpha(1.0)
    end

    local subtitle = string.format(L["GEMS_UI_ROW_SUBTITLE"], data.stepFunction or "Sequential", data.stepCount or 0)
    -- Read-only LIVE tag: which version the keybind fires. Only shown when the
    -- sequence has more than one version (single-version rows stay unchanged).
    if data.versionCount and data.versionCount > 1 and data.liveVersion then
        subtitle = subtitle .. "  " .. string.format(L["GEMS_VERSION_LIVE_BADGE"], data.liveVersion)
    end
    button.subtitleText:SetText(subtitle)
    if shouldDim then
        button.subtitleText:SetTextColor(C.textMuted:GetRGBA())
    else
        button.subtitleText:SetTextColor(C.textSecondary:GetRGBA())
    end

    -- Spell validation warning icon (cached per sequence, cleared on change)
    local SV = GRIPEMS.SpellValidator
    local SC = GRIPEMS.SpellCache
    if button.spellWarnIcon then
        if SC and SC.ready and SV and data.name then
            local cached = SL._spellValidationCache[data.name]
            if cached == nil then
                local seqEntry = GRIPEMS.Engine and GRIPEMS.Engine.sequences and GRIPEMS.Engine.sequences[data.name]
                if seqEntry and seqEntry.data then
                    local ok, valResult = pcall(SV.ValidateSequence, SV, seqEntry.data)
                    if ok and type(valResult) == "table" then
                        cached = valResult.staleCount or 0
                    else
                        cached = 0
                        GRIPEMS:Debug(
                            "InitRow: ValidateSequence failed for '"
                                .. tostring(data.name)
                                .. "': "
                                .. tostring(valResult)
                        )
                    end
                else
                    cached = 0
                end
                SL._spellValidationCache[data.name] = cached
            end
            if cached > 0 then
                button.spellWarnIcon:Show()
            else
                button.spellWarnIcon:Hide()
            end
        else
            button.spellWarnIcon:Hide()
        end
    end

    -- Health score overlay (cached per sequence)
    if button.healthIcon then
        local RA = GRIPEMS.RepairAnalyzer
        if RA then
            SL._healthScoreCache = SL._healthScoreCache or {}
            local cached = SL._healthScoreCache[data.name]
            if cached == nil then
                local seqEntry = GRIPEMS.Engine and GRIPEMS.Engine.sequences and GRIPEMS.Engine.sequences[data.name]
                if seqEntry and seqEntry.data then
                    local ok, issues = pcall(RA.Analyze, RA, seqEntry.data, data.name, { surface = "badge" })
                    if ok and issues ~= nil then
                        local ok2, score = pcall(RA.ComputeHealthScore, RA, issues)
                        cached = (ok2 and type(score) == "number") and score or 100
                        if not ok2 then
                            GRIPEMS:Debug(
                                "InitRow: ComputeHealthScore failed for '"
                                    .. tostring(data.name)
                                    .. "': "
                                    .. tostring(score)
                            )
                        end
                    else
                        cached = 100
                        GRIPEMS:Debug(
                            "InitRow: RA:Analyze failed for '" .. tostring(data.name) .. "': " .. tostring(issues)
                        )
                    end
                else
                    cached = 100
                end
                SL._healthScoreCache[data.name] = cached
            end
            if cached < 100 then
                button.healthIcon:SetText(cached)
                if cached >= 80 then
                    button.healthIcon:SetTextColor(0.2, 0.9, 0.2)
                elseif cached >= 50 then
                    button.healthIcon:SetTextColor(0.9, 0.9, 0.2)
                else
                    button.healthIcon:SetTextColor(0.9, 0.2, 0.2)
                end
                button.healthIcon:Show()
            else
                button.healthIcon:Hide()
            end
        else
            button.healthIcon:Hide()
        end
    end

    local keybind = data.keybind or ""
    button.keybindText:SetText(keybind)
    if keybind ~= "" then
        button.keybindText:SetTextColor(C.keybindGold:GetRGBA())
    else
        button.keybindText:SetTextColor(C.textMuted:GetRGBA())
    end

    -- Selection state
    local isSelected = (data.name == UI.selectedSequence)
    if isSelected then
        button:SetBackdropColor(C.bgRowSelected:GetRGBA())
        button:SetBackdropBorderColor(C.borderFocus:GetRGBA())
    else
        button:SetBackdropColor(C.bgPanel:GetRGBA())
        button:SetBackdropBorderColor(C.border:GetRGBA())
    end

    -- Hover
    button:SetScript("OnEnter", function(self)
        if self._seqData and self._seqData.name ~= UI.selectedSequence then
            self:SetBackdropColor(C.bgRowHover:GetRGBA())
        end
    end)
    button:SetScript("OnLeave", function(self)
        if self._seqData and self._seqData.name ~= UI.selectedSequence then
            self:SetBackdropColor(C.bgPanel:GetRGBA())
            self:SetBackdropBorderColor(C.border:GetRGBA())
        end
    end)

    -- Click
    button:SetScript("OnClick", function(self, mouseButton)
        if not self._seqData then
            return
        end
        if mouseButton == "RightButton" then
            -- Simplified Mode (Phase S2): suppress the sequence context menu.
            local acc = GRIPEMS.Settings
                and GRIPEMS.Settings.db
                and GRIPEMS.Settings.db.profile
                and GRIPEMS.Settings.db.profile.accessibility
            if acc and acc.simplifiedMode then
                return
            end
            SL:ShowContextMenu(self, self._seqData)
        else
            SL:SelectSequence(self._seqData.name)
            -- Follow mouse selection with keyboard cursor (Phase 2 #7).
            if GRIPEMS.Focus and GRIPEMS.Focus.SetListCurrent then
                GRIPEMS.Focus:SetListCurrent(self)
            end
        end
    end)
end

---------------------------------------------------------------------------
-- Data provider management
---------------------------------------------------------------------------

--- Set the active sort mode, persist it, update button text, and refresh.
--- @param mode string One of "alpha", "class", "updated"
function SL:SetSortMode(mode)
    if not SORT_LABELS[mode] then
        mode = "alpha"
    end
    SL.sortMode = mode
    GRIPEMS.Settings:Set("listSortMode", mode)
    if SL.sortBtn then
        SL.sortBtn.label:SetText(SORT_LABELS[mode] or L["GEMS_UI_SORT_ALPHA"])
        if SL.sortBtn:IsMouseOver() then
            UI:ShowTooltip(
                SL.sortBtn,
                L["GEMS_UI_SORT_HINT"] .. ": " .. (SORT_TOOLTIPS[mode] or L["GEMS_UI_SORT_ALPHA_TIP"]),
                L["GEMS_UI_SORT_CYCLE"]
            )
        end
    end
    SL._dataDirty = true
    SL:RefreshDataProvider()
end

--- Toggle the current-class-only list filter, persist it, sync the checkbox, and refresh.
--- @param enabled boolean
function SL:SetCurrentClassOnly(enabled)
    SL.currentClassOnly = enabled and true or false
    GRIPEMS.Settings:Set("listCurrentClassOnly", SL.currentClassOnly)
    if SL.classFilterCheck then
        SL.classFilterCheck:SetChecked(SL.currentClassOnly)
    end
    SL._dataDirty = true
    SL:RefreshDataProvider()
end

--- Rebuild the DataProvider from Engine.sequences, applying search filter and sort.
function SL:RefreshDataProvider()
    if not SL.scrollView then
        return
    end
    if not SL._dataDirty then
        return
    end

    local entries = {}
    local playerClassID = select(3, UnitClass("player")) or 0
    local engine = GRIPEMS.Engine
    if engine and engine.sequences then
        local KM = GRIPEMS.KeybindManager
        for name, entry in pairs(engine.sequences) do
            local seqData = entry.data
            if seqData then
                -- Current-class filter (opt-in): keep class-neutral (0) and the
                -- player's class; hide sequences stamped to other classes.
                local cid = seqData.classID or 0
                local passClass = (not SL.currentClassOnly) or cid == 0 or cid == playerClassID
                -- Apply search filter
                local searchLower = SL.searchText:lower()
                if passClass and (searchLower == "" or name:lower():find(searchLower, 1, true)) then
                    -- Get active version for display data
                    local ver = GRIPEMS.Engine:GetActiveVersion(seqData)
                    local verSteps = ver and ver.steps or {}
                    local verStepFunc = ver and ver.stepFunction or "Sequential"
                    -- Live version + count for the read-only "Live: Vn" row tag.
                    -- Reuse the resolved version table; no second resolver.
                    local liveIdx = GRIPEMS.Engine:GetActiveVersionIndex(seqData, ver)
                    -- type(), not truthiness. The Engine:GetActiveVersion call
                    -- two lines above is guarded and returns nil for a scalar
                    -- .versions -- but that guard does NOT cover this line,
                    -- which re-reads the RAW field. Under bare truthiness the
                    -- Engine fix only RELOCATED the raise out of the Engine and
                    -- into this list builder: a number or boolean raises
                    -- "attempt to get length of field 'versions'" right here,
                    -- and a string fabricates a count from its characters.
                    local versionCount = (type(seqData.versions) == "table" and #seqData.versions) or 1

                    -- Resolve display icon using same priority chain as editor
                    local displayIcon
                    if seqData.autoIcon == false and type(seqData.icon) == "number" then
                        -- Manual numeric pick
                        displayIcon = seqData.icon
                    else
                        -- Auto-detect from step content
                        local SC = GRIPEMS.SpellCache
                        if SC and #verSteps > 0 then
                            local text
                            if verStepFunc == "Priority" then
                                local lines = {}
                                for i = 1, #verSteps do
                                    local s = SC:StepToString(verSteps[i])
                                    if s ~= "" then
                                        lines[#lines + 1] = s
                                    end
                                end
                                text = table.concat(lines, "\n")
                            else
                                text = SC:StepToString(verSteps[1])
                            end
                            local spellName = SC:ParseSpellFromMacrotext(text)
                            if spellName then
                                displayIcon = SC:GetIcon(spellName)
                            end
                        end
                    end
                    -- Fall back to legacy string icon or question mark
                    if not displayIcon then
                        displayIcon = seqData.icon or "INV_Misc_QuestionMark"
                    end

                    table.insert(entries, {
                        name = name,
                        icon = displayIcon,
                        stepFunction = verStepFunc,
                        stepCount = #verSteps,
                        keybind = (KM and KM.GetKeybind) and KM:GetKeybind(name) or "",
                        classID = seqData.classID or 0,
                        updatedAt = GRIPEMS.NormalizeUpdatedAt(seqData.updatedAt) or 0,
                        description = seqData.description or "",
                        active = (entry.button ~= nil),
                        disabled = seqData.disabled or false,
                        liveVersion = liveIdx,
                        versionCount = versionCount,
                    })
                end
            end
        end
    end

    GRIPEMS:Debug("SL:RefreshDataProvider: " .. #entries .. " entries")

    -- Sort
    if SL.sortMode == "alpha" then
        table.sort(entries, function(a, b)
            return (a.name or ""):lower() < (b.name or ""):lower()
        end)
    elseif SL.sortMode == "class" then
        table.sort(entries, function(a, b)
            if a.classID ~= b.classID then
                return (a.classID or 0) < (b.classID or 0)
            end
            return (a.name or ""):lower() < (b.name or ""):lower()
        end)
    elseif SL.sortMode == "updated" then
        table.sort(entries, function(a, b)
            return (a.updatedAt or 0) > (b.updatedAt or 0)
        end)
    end

    -- Create new DataProvider (no Flush method exists)
    local dp = CreateDataProvider()
    dp:InsertTable(entries)
    SL.scrollBox:SetDataProvider(dp, ScrollBoxConstants.RetainScrollPosition)
    SL.dataProvider = dp
    GRIPEMS:Debug("SL:RefreshDataProvider: SetDataProvider done")
    if SL.scrollBox.ForceLayout then
        SL.scrollBox:ForceLayout()
    end

    -- Phase 2 #7: register currently visible row widgets with Focus so UP/DOWN
    -- can walk them. Deferred by one frame so ScrollBox has time to acquire
    -- frames after the new DataProvider is applied. The sync pass covers the
    -- steady-state case where frames are already cached from a prior layout.
    local function UpdateFocusRows()
        if not SL.scrollBox then
            return
        end
        if not (GRIPEMS.Focus and GRIPEMS.Focus.UpdateListTargets) then
            return
        end
        local rows = {}
        if SL.scrollBox.ForEachFrame then
            SL.scrollBox:ForEachFrame(function(frame)
                rows[#rows + 1] = frame
            end)
        end
        GRIPEMS.Focus:UpdateListTargets(rows)
    end
    UpdateFocusRows()
    if C_Timer and C_Timer.After then
        C_Timer.After(0, UpdateFocusRows)
    end

    -- Empty state
    if #entries == 0 then
        if SL.emptyIcon then
            SL.emptyIcon:Show()
        end
        if SL.emptyLabel then
            SL.emptyLabel:Show()
        end
        if SL.emptyHint then
            SL.emptyHint:Show()
        end
    else
        if SL.emptyIcon then
            SL.emptyIcon:Hide()
        end
        if SL.emptyLabel then
            SL.emptyLabel:Hide()
        end
        if SL.emptyHint then
            SL.emptyHint:Hide()
        end
    end

    SL._dataDirty = false
end

---------------------------------------------------------------------------
-- Selection
---------------------------------------------------------------------------

--- Select a sequence by name. If the editor has unsaved changes, prompt first.
--- @param name string|nil Sequence name to select
function SL:SelectSequence(name)
    local SE = GRIPEMS.SequenceEditor
    if SE and SE.isDirty then
        SL.pendingSelect = name
        SE:PromptSave()
        return -- popup callbacks handle the actual load
    end
    SL:DoSelectSequence(name)
end

--- Perform the actual sequence selection (no dirty-state check).
--- @param name string|nil Sequence name to select
function SL:DoSelectSequence(name)
    UI.selectedSequence = name
    SL._dataDirty = true
    SL:RefreshDataProvider()
    if GRIPEMS.SequenceEditor then
        GRIPEMS.SequenceEditor:LoadSequence(name)
    end
    -- Plugin API v2 (Phase D): announce the selection to plugins after the editor
    -- loads it. Nil-guarded like the other in-core fires; payload is the sequence
    -- name and MAY be nil (a deselect).
    if GRIPEMS.Fire then
        GRIPEMS:Fire("GEMS_SEQUENCE_SELECTED", name)
    end
end

---------------------------------------------------------------------------
-- Context menu
---------------------------------------------------------------------------

--- Show a right-click context menu for a sequence row.
--- @param button Button The row frame (menu anchor)
--- @param data table Row data
function SL:ShowContextMenu(button, data)
    if not data or not data.name then
        return
    end
    MenuUtil.CreateContextMenu(button, function(ownerRegion, rootDescription)
        rootDescription:CreateTitle(data.name)
        if GRIPEMS.Engine:IsSequenceDormant(data.name) then
            rootDescription:CreateButton(L["GEMS_UI_ACTIVATE"], function()
                GRIPEMS.Engine:ActivateDormantSequence(data.name)
            end)
            rootDescription:CreateDivider()
        end
        do
            local forkBtn = rootDescription:CreateButton(L["GEMS_FORK_BUTTON"], function()
                SL:ShowForkDialog(data.name)
            end)
            if forkBtn and forkBtn.SetTooltip then
                forkBtn:SetTooltip(function(tooltip, elementDescription)
                    GameTooltip_AddNormalLine(tooltip, L["GEMS_FORK_BUTTON"])
                    GameTooltip_AddBlankLineToTooltip(tooltip)
                    GameTooltip_AddNormalLine(tooltip, L["GEMS_FORK_TOOLTIP"])
                end)
            end
        end
        rootDescription:CreateButton(L["GEMS_UI_EXPORT_CTX"], function()
            local GE = GRIPEMS.GRIPExport
            if not GE then
                return
            end
            local deps = GE.ResolveVariableDeps({ data.name })
            if next(deps) then
                local EF = GRIPEMS.ExportFrame
                if EF then
                    EF:Show(data.name)
                end
            else
                local ok, result = GE.Export(data.name)
                if ok then
                    local EF = GRIPEMS.ExportFrame
                    if EF then
                        EF:Show(data.name, result)
                    else
                        GRIPEMS:Print(string.format(L["GEMS_EXPORT_RESULT"], result))
                    end
                else
                    GRIPEMS:Print(string.format(L["GEMS_EXPORT_FAILED"], tostring(result)))
                end
            end
        end)
        rootDescription:CreateButton(L["GEMS_UI_SEND_PLAYER"], function()
            if GRIPEMS.Transmission then
                GRIPEMS.Transmission:ShowSendDialog(data.name)
            end
        end)
        rootDescription:CreateButton(L["GEMS_UI_EXPORT_MULTI"], function()
            GRIPEMS.ExportFrame:Show()
        end)
        rootDescription:CreateButton(L["GEMS_UI_OPEN_NEW_WINDOW"], function()
            if GRIPEMS.PopupEditor then
                GRIPEMS.PopupEditor:Open(data.name)
            end
        end)
        -- Compare with... submenu
        local Engine = GRIPEMS.Engine
        if Engine and Engine.sequences then
            local compareSubmenu = rootDescription:CreateButton(L["GEMS_UI_COMPARE_WITH"])
            for seqName, _ in pairs(Engine.sequences) do
                if seqName ~= data.name then
                    compareSubmenu:CreateButton(seqName, function()
                        local sourceSteps = {}
                        local targetSteps = {}
                        local srcMeta, tgtMeta

                        -- Source steps + metadata
                        local srcEntry = Engine.sequences[data.name]
                        if srcEntry and srcEntry.data then
                            local srcData = srcEntry.data
                            local ver = Engine:GetActiveVersion(srcData)
                            if ver then
                                sourceSteps = ver.steps or {}
                                srcMeta = {
                                    stepFunction = ver.stepFunction or "Sequential",
                                    resetConditions = D().BuildResetString(ver) or "",
                                    icon = srcData.icon or srcData.Icon,
                                    contextVersions = srcData.versions and #srcData.versions or 0,
                                }
                            end
                        end

                        -- Target steps + metadata
                        local tgtEntry = Engine.sequences[seqName]
                        if tgtEntry and tgtEntry.data then
                            local tgtData = tgtEntry.data
                            local ver = Engine:GetActiveVersion(tgtData)
                            if ver then
                                targetSteps = ver.steps or {}
                                tgtMeta = {
                                    stepFunction = ver.stepFunction or "Sequential",
                                    resetConditions = D().BuildResetString(ver) or "",
                                    icon = tgtData.icon or tgtData.Icon,
                                    contextVersions = tgtData.versions and #tgtData.versions or 0,
                                }
                            end
                        end

                        local CF = GRIPEMS.ComparisonFrame
                        if CF then
                            CF:Show(data.name, sourceSteps, seqName, targetSteps, nil, nil, srcMeta, tgtMeta)
                        end
                    end)
                end
            end
        end
        rootDescription:CreateButton(L["GEMS_UI_REPAIR"], function()
            local RA = GRIPEMS.RepairAnalyzer
            local seqEntry = GRIPEMS.Engine and GRIPEMS.Engine.sequences and GRIPEMS.Engine.sequences[data.name]
            if RA and seqEntry and seqEntry.data then
                local issues = RA:Analyze(seqEntry.data, data.name, { surface = "repair" })
                if #issues == 0 then
                    GRIPEMS:Print(string.format(L["GEMS_REPAIR_NONE"], 100))
                else
                    local RF = GRIPEMS.RepairFrame
                    if RF then
                        RF:Show(seqEntry.data, issues, data.name)
                    end
                end
            end
        end)
        -- Disable/Enable toggle
        local seqEntry = GRIPEMS.Engine and GRIPEMS.Engine.sequences and GRIPEMS.Engine.sequences[data.name]
        if seqEntry and seqEntry.data then
            local isDisabled = seqEntry.data.disabled
            local label = isDisabled and L["GEMS_UI_ENABLE"] or L["GEMS_UI_DISABLE"]
            rootDescription:CreateButton(label, function()
                GRIPEMS.Engine:ToggleSequenceDisabled(data.name)
                SL:RefreshDataProvider()
            end)
        end
        rootDescription:CreateButton(L["GEMS_UI_RENAME"], function()
            SL:ShowRenameDialog(data.name)
        end)
        rootDescription:CreateButton("|cFFFF4444" .. L["GEMS_UI_DELETE"] .. "|r", function()
            SL:ShowDeleteConfirm(data.name)
        end)
    end)
end

---------------------------------------------------------------------------
-- Dialogs
---------------------------------------------------------------------------

--- Show the "New Sequence" dialog.
function SL:ShowNewSequenceDialog()
    GRIPEMS.Popup:Define("GRIPEMS_NEW_SEQUENCE", {
        text = L["GEMS_UI_NEW_SEQ_DESC"],
        button1 = ACCEPT,
        button2 = CANCEL,
        hasEditBox = true,
        editBoxWidth = 250,
        OnAccept = function(self)
            local name = self.EditBox:GetText():trim()
            if name == "" then
                GRIPEMS:Print(L["GEMS_UI_NAME_EMPTY"])
                return
            end
            if GRIPEMS.Engine and GRIPEMS.Engine.sequences and GRIPEMS.Engine.sequences[name] then
                GRIPEMS:Print(string.format(L["GEMS_UI_NAME_EXISTS"], name))
                return
            end
            local defaults = D()
            local seqData = {
                name = name,
                icon = defaults.NewSequence.icon,
                defaultVersion = 1,
                versions = {
                    [1] = {
                        stepFunction = defaults.NewVersion.stepFunction,
                        steps = {},
                        resetOnCombat = defaults.NewVersion.resetOnCombat,
                        resetOnTarget = defaults.NewVersion.resetOnTarget,
                        resetOnGear = defaults.NewVersion.resetOnGear,
                        resetOnSpec = defaults.NewVersion.resetOnSpec,
                        resetTimer = defaults.NewVersion.resetTimer,
                    },
                },
                author = UnitName("player") or "",
                version = "1",
                description = "",
                classID = select(3, UnitClass("player")) or 0,
                specID = nil,
                createdAt = time(),
                updatedAt = time(),
            }
            GRIPEMS.Engine:ActivateSequence(name, seqData)
            if C_Timer and C_Timer.After then
                C_Timer.After(0.1, function()
                    SL:SelectSequence(name)
                end)
            end
        end,
        OnShow = function(self)
            self.EditBox:SetText("")
            self.EditBox:SetFocus()
        end,
        timeout = 0,
        hideOnEscape = true,
    })
    GRIPEMS.Popup:Show("GRIPEMS_NEW_SEQUENCE")
end

--- Show a delete confirmation dialog.
--- @param name string Sequence name to delete
function SL:ShowDeleteConfirm(name)
    -- Migrated from _G.StaticPopupDialogs to GRIPEMS.Popup to avoid
    -- the table-taint chain that gets blamed on EMS for CancelLogout.
    -- See Backlog BUG-TAINT-CANCELLOGOUT.
    if not GRIPEMS.Popup:GetDef("GRIPEMS_DELETE_CONFIRM") then
        GRIPEMS.Popup:Define("GRIPEMS_DELETE_CONFIRM", {
            text = "",
            button1 = ACCEPT,
            button2 = CANCEL,
            OnAccept = function(_, data)
                local seqName = data and data.name
                if not seqName then
                    return
                end
                if GRIPEMS.OOCQueue.IsRestricted() then
                    GRIPEMS:Print(L["GEMS_DELETE_COMBAT"])
                    return
                end
                if UI.selectedSequence == seqName then
                    UI.selectedSequence = nil
                    if GRIPEMS.SequenceEditor then
                        GRIPEMS.SequenceEditor:Clear()
                    end
                end
                local KM = GRIPEMS.KeybindManager
                if KM and KM.PurgeKeybinds then
                    KM:PurgeKeybinds(seqName)
                end
                GRIPEMS.Engine:DeactivateSequence(seqName)
            end,
            timeout = 0,
            hideOnEscape = true,
        })
    end
    local text = string.format(L["GEMS_UI_DELETE_CONFIRM"], name)
    local def = GRIPEMS.Popup:GetDef("GRIPEMS_DELETE_CONFIRM")
    def.text = text
    GRIPEMS.Popup:Show("GRIPEMS_DELETE_CONFIRM", nil, nil, { name = name })
end

--- Show the fork sequence dialog. v2.1.0 Phase C: replaces the prior
--- ShowDuplicateDialog. Forking re-stamps the duplicating user as the
--- new Original Author and records the source's lineage in
--- newSeq.forkedFrom (handled by Engine:DuplicateSequence calling
--- Identity:StampForked).
--- @param sourceName string Source sequence name
function SL:ShowForkDialog(sourceName)
    GRIPEMS.Popup:Define("GRIPEMS_FORK_SEQ", {
        text = L["GEMS_FORK_DIALOG_TITLE"] .. "\n\n" .. string.format(L["GEMS_FORK_DIALOG_BODY"], sourceName),
        button1 = L["GEMS_FORK_BUTTON"],
        button2 = CANCEL,
        hasEditBox = true,
        editBoxWidth = 250,
        OnAccept = function(self)
            local newName = self.EditBox:GetText():trim()
            if newName == "" then
                GRIPEMS:Print(L["GEMS_UI_NAME_EMPTY"])
                return
            end
            local ok, err = GRIPEMS.Engine:DuplicateSequence(sourceName, newName)
            if not ok then
                GRIPEMS:Print(err or L["GEMS_UI_DUPLICATE_FAILED"])
            else
                if C_Timer and C_Timer.After then
                    C_Timer.After(0.1, function()
                        SL:SelectSequence(newName)
                    end)
                end
            end
        end,
        OnShow = function(self)
            self.EditBox:SetText(sourceName .. L["GEMS_UI_COPY_SUFFIX"])
            self.EditBox:HighlightText()
            self.EditBox:SetFocus()
        end,
        timeout = 0,
        hideOnEscape = true,
    })
    GRIPEMS.Popup:Show("GRIPEMS_FORK_SEQ")
end

--- Show the rename dialog.
--- @param oldName string Current sequence name
function SL:ShowRenameDialog(oldName)
    GRIPEMS.Popup:Define("GRIPEMS_RENAME_SEQ", {
        text = L["GEMS_UI_RENAME_DESC"],
        button1 = ACCEPT,
        button2 = CANCEL,
        hasEditBox = true,
        editBoxWidth = 250,
        OnAccept = function(self)
            local newName = self.EditBox:GetText():trim()
            if newName == "" then
                GRIPEMS:Print(L["GEMS_UI_NAME_EMPTY"])
                return
            end
            if newName == oldName then
                return
            end
            local engine = GRIPEMS.Engine
            if not engine or not engine.sequences then
                return
            end
            if engine.sequences[newName] then
                GRIPEMS:Print(string.format(L["GEMS_UI_NAME_EXISTS"], newName))
                return
            end

            -- Get old data and keybind
            local oldEntry = engine.sequences[oldName]
            if not oldEntry or not oldEntry.data then
                return
            end
            local oldData = oldEntry.data

            -- Plugin-owned sequences are lifecycle-managed by their plugin
            -- (ownership journal is keyed by name); a user rename would
            -- orphan the journal and break DisablePlugin teardown.
            if oldData.ownerPlugin then
                GRIPEMS:Print(string.format(L["GEMS_UI_RENAME_PLUGIN_OWNED"], oldName, tostring(oldData.ownerPlugin)))
                return
            end

            local KM = GRIPEMS.KeybindManager
            local oldKey = KM and KM:GetKeybind(oldName)

            -- Settle any pending quick-edit re-sign under the old name
            -- BEFORE copying: the rename carries the signature verbatim
            -- (valid only for signed content), and the orphaned timer
            -- would no-op once the old key is gone.
            local SEd = GRIPEMS.SequenceEditor
            if SEd and SEd._quickResignGen and SEd._quickResignGen[oldName] and SEd._FlushQuickResign then
                SEd:_CancelQuickResign(oldName)
                SEd:_FlushQuickResign(oldName)
            end

            -- Deep-copy the data with new name (version-aware)
            local newData = {
                name = newName,
                icon = oldData.icon,
                autoIcon = oldData.autoIcon,
                defaultVersion = oldData.defaultVersion or 1,
                contextOverrides = {},
                versions = {},
                author = oldData.author or "",
                version = oldData.version or "1",
                description = oldData.description or "",
                help = oldData.help or "",
                helplink = oldData.helplink or "",
                -- v2.3.4: carry the fields the editor-side rename carries so a
                -- list rename stops silently discarding them (disabled also
                -- kept a disabled sequence from being re-enabled by rename).
                changelog = oldData.changelog,
                talentString = oldData.talentString,
                url = oldData.url,
                importMeta = oldData.importMeta,
                disabled = oldData.disabled,
                classID = oldData.classID or 0,
                specID = oldData.specID,
                recommendSource = oldData.recommendSource,
                createdAt = oldData.createdAt or time(),
                updatedAt = time(),
            }
            -- v2.3.4 Phase 4: a list rename previously wiped every
            -- Conditions-tab version assignment.
            if oldData.contextOverrides then
                for k, v in pairs(oldData.contextOverrides) do
                    newData.contextOverrides[k] = v
                end
            end
            -- Deep copy all versions
            if type(oldData.versions) == "table" then
                for i, ver in ipairs(oldData.versions) do
                    newData.versions[i] = D().CopyVersion(ver)
                end
            end

            -- v2.3.4 Phase 4: rename must not strip identity -- carry
            -- provenance, privacyMode, MetaData dep tags, and soundCues.
            GRIPEMS.Defaults.CarrySequenceIdentity(newData, oldData)

            -- Deactivate old, activate new
            GRIPEMS.Engine:DeactivateSequence(oldName)
            GRIPEMS.Engine:ActivateSequence(newName, newData)

            -- Re-key the per-spec hold-mode preference to the new name
            if GRIPEMS.TempoAdvisor and GRIPEMS.TempoAdvisor.RenameHoldMode then
                GRIPEMS.TempoAdvisor:RenameHoldMode(oldName, newName)
            end

            -- Re-apply keybind to new name
            if oldKey and KM then
                if C_Timer and C_Timer.After then
                    C_Timer.After(0.15, function()
                        KM:SetKeybind(newName, oldKey)
                    end)
                end
            end

            if C_Timer and C_Timer.After then
                C_Timer.After(0.1, function()
                    SL:SelectSequence(newName)
                end)
            end
        end,
        OnShow = function(self)
            self.EditBox:SetText(oldName)
            self.EditBox:HighlightText()
            self.EditBox:SetFocus()
        end,
        timeout = 0,
        hideOnEscape = true,
    })
    GRIPEMS.Popup:Show("GRIPEMS_RENAME_SEQ")
end

--- Show the migration confirmation dialog. Three choices: All Classes (button1),
--- Current Class Only (button3), Cancel (button2). GRIPEMS.Popup has no checkbox
--- support, so the scope choice is expressed with the framework's third button.
function SL:ShowMigrateConfirm()
    local LM = GRIPEMS.LegacyMigrate
    if not LM then
        return
    end
    local count = LM.GetSourceSequenceCount()
    local function RunMigrate(currentClassOnly)
        local ok, results = LM.MigrateAll(false, currentClassOnly)
        if ok then
            if GRIPEMS.PrintMigrationReport then
                GRIPEMS:PrintMigrationReport(results, "migrate")
            end
            SL._dataDirty = true
            SL:RefreshDataProvider()
        else
            GRIPEMS:Print(string.format(L["GEMS_MIGRATE_FAILED"], tostring(results)))
        end
    end
    GRIPEMS.Popup:Define("GRIPEMS_MIGRATE_CONFIRM", {
        text = string.format(L["GEMS_MIGRATE_CONFIRM"], count),
        button1 = L["GEMS_MIGRATE_ALL_CLASSES"],
        button2 = CANCEL,
        button3 = L["GEMS_MIGRATE_CURRENT_CLASS"],
        OnAccept = function()
            RunMigrate(false)
        end,
        OnAlt = function()
            RunMigrate(true)
        end,
        timeout = 0,
        hideOnEscape = true,
    })
    GRIPEMS.Popup:Show("GRIPEMS_MIGRATE_CONFIRM")
end
