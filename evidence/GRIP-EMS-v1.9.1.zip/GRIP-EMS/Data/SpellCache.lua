-- GRIP-EMS: Spell Cache
-- Runtime spell name cache built from C_SpellBook API for autocomplete and validation

local ADDON_NAME, GRIPEMS = ...
-- Upvalue accessor for Defaults
local function D()
    return GRIPEMS.Defaults
end

GRIPEMS.SpellCache = {}
local SC = GRIPEMS.SpellCache

-- Cache structure (runtime only, never saved to SavedVariables)
SC.spells = {} -- sorted array of { name, spellID, iconID [, isPet], castTime, gcdMS }
SC.byName = {} -- lowercase name -> entry lookup
SC.ready = false -- true after first successful scan

-- Item cache: lowercase name -> itemID (from bags + equipped)
SC.itemByName = {}
-- Toy cache: lowercase name -> itemID (from collection)
SC.toyByName = {}
-- Mount cache: sorted array of { name, spellID, iconID, mountID }
SC.mounts = {}
-- Companion cache: sorted array of { name, spellID, iconID, petID }
SC.companions = {}

-- Debounce timer handle (cancelled/replaced on re-trigger)
local debounceTimer = nil

---------------------------------------------------------------------------
-- Scan
---------------------------------------------------------------------------

--- Scan the player's spellbook and build the sorted spell cache.
--- Clears and rebuilds spells array and byName lookup from scratch.
function SC:Scan()
    wipe(self.spells)
    wipe(self.byName)

    -- Guard: some spellbook entries return actionID values outside the
    -- signed 32-bit range that FindSpellOverrideByID rejects.
    local function SafeOverrideID(actionID)
        if not actionID or type(actionID) ~= "number" then
            return actionID
        end
        if actionID > 2147483647 or actionID < 0 then
            return actionID
        end
        return FindSpellOverrideByID(actionID) or actionID
    end

    local numSkillLines = C_SpellBook.GetNumSpellBookSkillLines()
    if not numSkillLines then
        self.ready = true
        GRIPEMS:Debug("SpellCache: no skill lines available")
        return
    end

    -- Categorization context (computed once, applied per skill line)
    local currentSpecIndex = GetSpecialization()
    local currentSpecID = currentSpecIndex and GetSpecializationInfo(currentSpecIndex) or nil
    local _, classEn = UnitClass("player")
    local _, raceEn = UnitRace("player")

    -- Build profession name set from GetProfessions indices
    local profIndices = { GetProfessions() }
    local profNames = {}
    for _, idx in ipairs(profIndices) do
        if idx then
            local profInfo = C_SpellBook.GetSpellBookSkillLineInfo(idx)
            if profInfo and profInfo.name then
                profNames[strlower(profInfo.name)] = true
            end
        end
    end
    -- Hardcoded fallback for known profession names (12.0 index safety net)
    local KNOWN_PROFESSIONS = {
        "herbalism",
        "mining",
        "engineering",
        "enchanting",
        "alchemy",
        "tailoring",
        "leatherworking",
        "blacksmithing",
        "jewelcrafting",
        "inscription",
        "skinning",
        "cooking",
        "fishing",
        "archaeology",
        "first aid",
    }

    -- Scan player spellbook tabs
    for i = 1, numSkillLines do
        local info = C_SpellBook.GetSpellBookSkillLineInfo(i)
        if info then
            GRIPEMS:Debug(
                string.format(
                    "SpellCache: skill line [%d] %s: shouldHide=%s, spells=%d",
                    i,
                    info.name or "?",
                    tostring(info.shouldHide),
                    info.numSpellBookItems or 0
                )
            )
            -- Skip guild and off-spec tabs (shouldHide removed: cache needs
            -- ALL castable spells including hidden skill lines like Pet Utility)
            if not info.isGuild and not info.offSpecID then
                -- Determine category for this skill line
                local nameLower = strlower(info.name or "")
                local category = "other" -- default fallback
                if info.specID and currentSpecID and info.specID == currentSpecID then
                    category = "spec"
                elseif info.specID then
                    -- Off-spec: already filtered by offSpecID above, but guard
                    category = "spec"
                elseif strlower(classEn or "") == nameLower then
                    category = "class"
                elseif nameLower == "general" then
                    category = "general"
                elseif strlower(raceEn or "") == nameLower then
                    category = "racial"
                elseif profNames[nameLower] then
                    category = "profession"
                else
                    -- Hardcoded profession name fallback
                    for _, pn in ipairs(KNOWN_PROFESSIONS) do
                        if nameLower == pn then
                            category = "profession"
                            break
                        end
                    end
                end
                GRIPEMS:Debug(
                    string.format("SpellCache: skill line [%d] %s -> category=%s", i, info.name or "?", category)
                )
                local offset = info.itemIndexOffset or 0
                local count = info.numSpellBookItems or 0

                for slot = offset + 1, offset + count do
                    local itemInfo = C_SpellBook.GetSpellBookItemInfo(slot, Enum.SpellBookSpellBank.Player)
                    if itemInfo then
                        -- Skip passives, off-spec, and non-castable types
                        if
                            not itemInfo.isPassive
                            and not itemInfo.isOffSpec
                            and (
                                itemInfo.itemType == Enum.SpellBookItemType.Spell
                                or itemInfo.itemType == Enum.SpellBookItemType.Flyout
                            )
                        then
                            -- actionID is the BASE slot ID, but name is the OVERRIDE name.
                            -- Resolve to the override spell ID so name<->ID stay consistent.
                            -- e.g. BM Hunter: actionID=56641 (Steady Shot base), but name="Barbed Shot"
                            -- FindSpellOverrideByID(56641) -> 217200 (Barbed Shot) -> matches name.
                            local resolvedID = SafeOverrideID(itemInfo.actionID)
                            local okSI, spellInfo = pcall(C_Spell.GetSpellInfo, resolvedID)
                            local castTime = (okSI and spellInfo and spellInfo.castTime) or 0
                            local okGCD, gcdMS
                            okGCD, _, gcdMS = pcall(GetSpellBaseCooldown, resolvedID)
                            if not okGCD then
                                gcdMS = 0
                            end
                            gcdMS = gcdMS or 0
                            local entry = {
                                name = itemInfo.name,
                                spellID = resolvedID,
                                iconID = itemInfo.iconID,
                                category = category,
                                castTime = castTime,
                                gcdMS = gcdMS,
                            }
                            -- Skip flyout parents (Call Pet, Pet Utility etc)
                            -- They are not castable; only their children are useful
                            if itemInfo.itemType ~= Enum.SpellBookItemType.Flyout then
                                -- Racial detection: in 12.0 racials live inside "General"
                                if category == "general" and entry.spellID then
                                    local subtext = C_Spell.GetSpellSubtext(entry.spellID)
                                    if subtext and subtext ~= "" and subtext:find("^Racial") then
                                        entry.category = "racial"
                                        GRIPEMS:Debug(
                                            string.format("SpellCache: %s subtext=%s -> racial", entry.name, subtext)
                                        )
                                    end
                                end
                                table.insert(self.spells, entry)
                            end

                            -- Flyout children: iterate slots to cache each
                            -- child spell (e.g. Call Pet 1-5, Summon Imp, etc.)
                            -- Uses C_Spell.GetSpellName for castable base name
                            -- (NOT the pet/demon display name from itemInfo)
                            if itemInfo.itemType == Enum.SpellBookItemType.Flyout then
                                local flyoutID = itemInfo.actionID
                                if flyoutID then
                                    local _, _, numSlots, isKnown = GetFlyoutInfo(flyoutID)
                                    if isKnown and numSlots then
                                        for fi = 1, numSlots do
                                            local childSpellID, _, childIsKnown = GetFlyoutSlotInfo(flyoutID, fi)
                                            if childSpellID and childIsKnown then
                                                local childName = C_Spell.GetSpellName(childSpellID)
                                                if childName and childName ~= "" then
                                                    local childIcon = C_Spell.GetSpellTexture(childSpellID)
                                                    local childCat = category
                                                    if childCat == "general" then
                                                        local cSub = C_Spell.GetSpellSubtext(childSpellID)
                                                        if cSub and cSub ~= "" and cSub:find("^Racial") then
                                                            childCat = "racial"
                                                            GRIPEMS:Debug(
                                                                string.format(
                                                                    "SpellCache: %s subtext=%s -> racial",
                                                                    childName,
                                                                    cSub
                                                                )
                                                            )
                                                        end
                                                    end
                                                    local okCSI, childSpellInfo =
                                                        pcall(C_Spell.GetSpellInfo, childSpellID)
                                                    local childCastTime = (
                                                        okCSI
                                                        and childSpellInfo
                                                        and childSpellInfo.castTime
                                                    ) or 0
                                                    local okCGCD, childGcdMS
                                                    okCGCD, _, childGcdMS = pcall(GetSpellBaseCooldown, childSpellID)
                                                    if not okCGCD then
                                                        childGcdMS = 0
                                                    end
                                                    childGcdMS = childGcdMS or 0
                                                    local childEntry = {
                                                        name = childName,
                                                        spellID = childSpellID,
                                                        iconID = childIcon,
                                                        isFlyoutChild = true,
                                                        category = childCat,
                                                        castTime = childCastTime,
                                                        gcdMS = childGcdMS,
                                                    }
                                                    table.insert(self.spells, childEntry)
                                                end
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end

    -- Scan pet spells if applicable (Hunter, Warlock, etc.)
    local numPetSpells = C_SpellBook.HasPetSpells()
    if numPetSpells then
        for i = 1, numPetSpells do
            local petInfo = C_SpellBook.GetSpellBookItemInfo(i, Enum.SpellBookSpellBank.Pet)
            if petInfo and not petInfo.isPassive then
                local petResolvedID = SafeOverrideID(petInfo.actionID)
                local okPSI, petSpellInfo = pcall(C_Spell.GetSpellInfo, petResolvedID)
                local petCastTime = (okPSI and petSpellInfo and petSpellInfo.castTime) or 0
                local okPGCD, petGcdMS
                okPGCD, _, petGcdMS = pcall(GetSpellBaseCooldown, petResolvedID)
                if not okPGCD then
                    petGcdMS = 0
                end
                petGcdMS = petGcdMS or 0
                local entry = {
                    name = petInfo.name,
                    spellID = petResolvedID,
                    iconID = petInfo.iconID,
                    isPet = true,
                    category = "pet",
                    castTime = petCastTime,
                    gcdMS = petGcdMS,
                }
                table.insert(self.spells, entry)
            end
        end
    end

    -- Scan profession spells via GetProfessionInfo spelloffset
    -- In 12.0 professions are not in skill line tabs; use GetProfessions indices
    local profSlots = { GetProfessions() }
    for pi = 1, 5 do
        local profIdx = profSlots[pi]
        if profIdx then
            local profName, _, _, _, numAbilities, spelloffset = GetProfessionInfo(profIdx)
            if profName and numAbilities and spelloffset then
                GRIPEMS:Debug(
                    string.format(
                        "SpellCache: profession %s: %d abilities from offset %d",
                        profName,
                        numAbilities,
                        spelloffset
                    )
                )
                for slot = spelloffset + 1, spelloffset + numAbilities do
                    local pInfo = C_SpellBook.GetSpellBookItemInfo(slot, Enum.SpellBookSpellBank.Player)
                    if pInfo and not pInfo.isPassive and pInfo.itemType == Enum.SpellBookItemType.Spell then
                        local pEntry = {
                            name = pInfo.name,
                            spellID = SafeOverrideID(pInfo.actionID),
                            iconID = pInfo.iconID,
                            category = "profession",
                        }
                        table.insert(self.spells, pEntry)
                    end
                end
            end
        end
    end

    -- Sort alphabetically by name (case-insensitive, pre-computed keys)
    for _, entry in ipairs(self.spells) do
        entry._lower = strlower(entry.name)
    end
    table.sort(self.spells, function(a, b)
        return a._lower < b._lower
    end)
    for _, entry in ipairs(self.spells) do
        entry._lower = nil
    end

    -- Build byName lookup (player spells win over pet spells on collision)
    for _, entry in ipairs(self.spells) do
        local key = strlower(entry.name)
        local existing = self.byName[key]
        if not existing or (not entry.isPet and existing.isPet) then
            self.byName[key] = entry
        end
    end

    self.ready = true

    -- Apply spell name overrides from user profile
    local db = GRIPEMS.Settings and GRIPEMS.Settings.db
    local overrides = db and db.profile and db.profile.spellOverrides
    if overrides then
        for spellID, customName in pairs(overrides) do
            for _, entry in ipairs(self.spells) do
                if entry.spellID == spellID then
                    local oldKey = strlower(entry.name)
                    self.byName[oldKey] = nil
                    entry.name = customName
                    self.byName[strlower(customName)] = entry
                    break
                end
            end
        end
    end

    GRIPEMS:Debug(string.format("SpellCache: scanned %d spells", #self.spells))

    -- Build item, toy, mount, and companion caches alongside spell cache
    self:BuildItemCache()
    self:BuildToyCache()
    self:BuildMountCache()
    self:BuildCompanionCache()

    if GRIPEMS.Fire then
        GRIPEMS:Fire("SPELL_CACHE_REFRESHED")
    end
end

---------------------------------------------------------------------------
-- Prefix Search
---------------------------------------------------------------------------

--- Search for spells whose name starts with the given prefix.
--- Returns up to maxResults matches from the sorted cache.
--- @param prefix string The prefix to match against spell names
--- @param maxResults number|nil Maximum results to return (default from Defaults)
--- @return table Array of matching { name, spellID, iconID } entries
function SC:PrefixSearch(prefix, maxResults)
    if not prefix then
        return {}
    end
    prefix = strlower(prefix)
    maxResults = maxResults or D().AUTOCOMPLETE_MAX_RESULTS

    -- Caller enforces min-chars threshold (see handleTabAutocomplete)

    local results = {}
    local prefixLen = #prefix
    for _, entry in ipairs(self.spells) do
        if strlower(entry.name):sub(1, prefixLen) == prefix then
            table.insert(results, entry)
            if #results >= maxResults then
                break
            end
        end
    end

    return results
end

---------------------------------------------------------------------------
-- Icon Lookup
---------------------------------------------------------------------------

--- Get the icon ID for a spell by name.
--- Checks the cache first (fast), falls back to C_Spell.GetSpellTexture.
--- @param spellName string The spell name to look up
--- @return number|nil iconID The file ID of the spell icon, or nil
function SC:GetIcon(spellName)
    if not spellName then
        return nil
    end

    local entry = self.byName[strlower(spellName)]
    if entry then
        return entry.iconID
    end

    -- Fallback: try the API directly (handles spells not in spellbook)
    local iconID = C_Spell.GetSpellTexture(spellName)
    return iconID
end

---------------------------------------------------------------------------
-- Spell ID Lookup
---------------------------------------------------------------------------

--- Get the spell ID for a spell by name.
--- Checks cache first (fast), falls back to C_Spell.GetSpellInfo.
--- @param spellName string The spell name to look up
--- @return number|nil spellID The spell ID, or nil if not found
function SC:GetSpellID(spellName)
    if not spellName then
        return nil
    end

    local entry = self.byName[strlower(spellName)]
    if entry then
        return entry.spellID
    end

    -- Fallback: WoW API (handles spells not in spellbook)
    local info = C_Spell.GetSpellInfo(spellName)
    return info and info.spellID or nil
end

--- Normalize a spell ID to its base (talent-portable) form.
--- Strips talent overrides so stored ID works across talent changes.
--- @param spellID number The spell ID to normalize
--- @return number|nil baseID The base spell ID, or nil if input is nil
function SC:GetBaseSpellID(spellID)
    if not spellID then
        return nil
    end
    local baseID = C_SpellBook.FindBaseSpellByID(spellID)
    if baseID then
        return baseID
    end
    -- Hardcoded fallback for spells where the API returns nil
    local fallback = D().BASE_SPELL_TABLE[spellID]
    return fallback or spellID
end

---------------------------------------------------------------------------
-- Remote Cache Merge (P2P spell cache sharing)
---------------------------------------------------------------------------

--- Merge spell entries received from a remote player into the local cache.
--- Only adds entries not already present. Entries are keyed by lowercase name.
--- @param entries table Remote cache: spellName -> spellID
--- @return number merged Count of newly merged entries
function SC:MergeRemoteCache(entries)
    if type(entries) ~= "table" then
        return 0
    end
    local merged = 0
    for name, id in pairs(entries) do
        local key = strlower(name)
        if not self.byName[key] then
            local entry = {
                name = name,
                spellID = id,
                iconID = nil,
            }
            self.byName[key] = entry
            table.insert(self.spells, entry)
            merged = merged + 1
        end
    end
    return merged
end

---------------------------------------------------------------------------
-- Locale Tagging (Phase 2 dual-store)
---------------------------------------------------------------------------

--- Tag an array of macro steps with spell ID tokens.
--- Thin wrapper over TranslateMacrotext for batch tagging.
--- @param steps table Array of macro text strings
--- @return table tagged Array of tagged strings with {spell:ID} tokens
function SC:TagSteps(steps)
    local tagged = {}
    for i, step in ipairs(steps) do
        tagged[i] = self:TranslateMacrotext(step, "toIDs")
    end
    return tagged
end

---------------------------------------------------------------------------
-- Item and Toy Caches (Phase 2d)
---------------------------------------------------------------------------

--- Build item name -> ID lookup from bags and equipped items.
--- Called after spell scan and on BAG_UPDATE_DELAYED / PLAYER_EQUIPMENT_CHANGED.
function SC:BuildItemCache()
    wipe(self.itemByName)
    local pendingIDs = {}
    -- Scan bags (0 = Backpack, 1-4 = bags, 5 = ReagentBag)
    for bag = 0, 5 do
        local numSlots = C_Container.GetContainerNumSlots(bag)
        for slot = 1, numSlots do
            local info = C_Container.GetContainerItemInfo(bag, slot)
            if info and info.itemID then
                local name = C_Item.GetItemInfo(info.itemID)
                if name then
                    self.itemByName[strlower(name)] = info.itemID
                else
                    pendingIDs[info.itemID] = true
                end
            end
        end
    end
    -- Scan equipped items (slots 1-19)
    for slot = 1, 19 do
        local itemID = GetInventoryItemID("player", slot)
        if itemID then
            local name = C_Item.GetItemInfo(itemID)
            if name then
                self.itemByName[strlower(name)] = itemID
            else
                pendingIDs[itemID] = true
            end
        end
    end
    -- Scan warbank tabs (account bank, may be nil when not at banker)
    if Enum.BagIndex and Enum.BagIndex.AccountBankTab_1 then
        for tab = Enum.BagIndex.AccountBankTab_1, Enum.BagIndex.AccountBankTab_5 do
            local numSlots = C_Container.GetContainerNumSlots(tab)
            for slot = 1, numSlots do
                local wbInfo = C_Container.GetContainerItemInfo(tab, slot)
                if wbInfo and wbInfo.itemID then
                    local name = C_Item.GetItemInfo(wbInfo.itemID)
                    if name then
                        self.itemByName[strlower(name)] = wbInfo.itemID
                    else
                        pendingIDs[wbInfo.itemID] = true
                    end
                end
            end
        end
    end
    -- Request missing item data and schedule a single retry
    if next(pendingIDs) and not SC._itemRetryScheduled then
        for itemID in pairs(pendingIDs) do
            C_Item.RequestLoadItemDataByID(itemID)
        end
        SC._itemRetryScheduled = true
        C_Timer.After(2, function()
            SC._itemRetryScheduled = nil
            SC:BuildItemCache()
        end)
    end
end

--- Build toy name -> ID lookup from toy collection.
--- Only indexes toys the player has collected.
--- Called once after spell scan (toys are account-wide, rarely change).
function SC:BuildToyCache()
    wipe(self.toyByName)
    for i = 1, C_ToyBox.GetNumToys() do
        local itemID = C_ToyBox.GetToyFromIndex(i)
        if itemID and itemID > 0 and PlayerHasToy(itemID) then
            local _, toyName = C_ToyBox.GetToyInfo(itemID)
            if toyName and toyName ~= "" then
                self.toyByName[strlower(toyName)] = itemID
            end
        end
    end
end

--- Build mount cache from collected mounts.
--- Sorted array of { name, spellID, iconID, mountID }.
function SC:BuildMountCache()
    wipe(self.mounts)
    local mountIDs = C_MountJournal.GetMountIDs()
    if not mountIDs then
        return
    end
    for _, mountID in ipairs(mountIDs) do
        local name, spellID, icon, _, _, _, _, _, _, _, isCollected = C_MountJournal.GetMountInfoByID(mountID)
        if isCollected and name then
            table.insert(self.mounts, {
                name = name,
                spellID = spellID,
                iconID = icon,
                mountID = mountID,
            })
        end
    end
    table.sort(self.mounts, function(a, b)
        return a.name:lower() < b.name:lower()
    end)
end

--- Build companion (battle pet) cache from collected pets.
--- Sorted array of { name, spellID, iconID, petID }, deduplicated by speciesID.
function SC:BuildCompanionCache()
    wipe(self.companions)
    -- Clear journal filters so we see all owned pets
    C_PetJournal.ClearSearchFilter()
    C_PetJournal.SetAllPetSourcesChecked(true)
    C_PetJournal.SetAllPetTypesChecked(true)

    local numPets = C_PetJournal.GetNumPets()
    if not numPets or numPets == 0 then
        return
    end
    local seenSpecies = {}
    for i = 1, numPets do
        local petID, speciesID, owned, _, _, _, _, speciesName, icon = C_PetJournal.GetPetInfoByIndex(i)
        if owned and speciesName and speciesID and not seenSpecies[speciesID] then
            seenSpecies[speciesID] = true
            table.insert(self.companions, {
                name = speciesName,
                spellID = speciesID,
                iconID = icon,
                petID = petID,
            })
        end
    end
    table.sort(self.companions, function(a, b)
        return a.name:lower() < b.name:lower()
    end)
end

--- Look up an item ID by name from the item cache.
--- @param itemName string The item name to look up
--- @return number|nil itemID The item ID, or nil if not found
function SC:GetItemID(itemName)
    if not itemName or itemName == "" then
        return nil
    end
    return self.itemByName[strlower(itemName)]
end

--- Look up a toy item ID by name from the toy cache.
--- @param toyName string The toy name to look up
--- @return number|nil itemID The toy's item ID, or nil if not found
function SC:GetToyID(toyName)
    if not toyName or toyName == "" then
        return nil
    end
    return self.toyByName[strlower(toyName)]
end

---------------------------------------------------------------------------
-- Macro Text Translation (locale-safe export/import)
---------------------------------------------------------------------------

-- Commands whose arguments need locale translation
local TRANSLATABLE_COMMANDS = {
    ["/cast"] = true,
    ["/use"] = true,
    ["/castsequence"] = true,
    ["/castrandom"] = true,
    ["/userandom"] = true,
    ["/cancelaura"] = true,
    ["/usetoy"] = true,
    ["/equip"] = true,
    ["/equipslot"] = true,
}

--- Consume all leading [conditional] blocks from a string.
--- Returns the conditionals prefix and the remaining text.
--- @param text string Text that may start with [cond] blocks
--- @return string condPrefix All consumed [cond] blocks with trailing space
--- @return string rest Remaining text after conditionals
local function ConsumeConditionals(text)
    local condParts = {}
    local pos = 1
    local len = #text

    while pos <= len do
        -- Skip whitespace
        while pos <= len and text:sub(pos, pos) == " " do
            pos = pos + 1
        end
        -- Check for opening bracket
        if pos <= len and text:sub(pos, pos) == "[" then
            -- Find the balanced close bracket
            local close = text:find("%]", pos + 1)
            if close then
                condParts[#condParts + 1] = text:sub(pos, close)
                pos = close + 1
            else
                break -- unbalanced bracket, stop
            end
        else
            break
        end
    end

    if #condParts == 0 then
        return "", text
    end

    local condPrefix = table.concat(condParts, " ")
    local rest = text:sub(pos)
    -- Preserve any space between last conditional and spell list
    condPrefix = condPrefix .. " "
    if rest:sub(1, 1) == " " then
        rest = rest:sub(2)
    end

    return condPrefix, rest
end

--- Translate a single spell reference between name and ID tag.
--- @param ref string A spell name or {spell:ID} tag
--- @param direction string "toIDs" or "toNames"
--- @return string translated The translated reference
local function TranslateSpellRef(ref, direction)
    -- Trim whitespace
    local trimmed = ref:match("^%s*(.-)%s*$")
    if not trimmed or trimmed == "" then
        return ref
    end

    if direction == "toIDs" then
        -- Already a tag? keep as-is
        if trimmed:match("^{spell:%d+}$") then
            return ref
        end
        -- Already numeric? keep as-is
        if tonumber(trimmed) then
            return ref
        end
        -- Check for ! prefix (e.g. !Steady Shot)
        local bangPrefix = ""
        local lookupName = trimmed
        if trimmed:sub(1, 1) == "!" then
            bangPrefix = "!"
            lookupName = trimmed:sub(2)
        end
        -- Check for (Rank N) suffix
        local rankSuffix = ""
        local baseName = lookupName
        local nameNoRank, rank = lookupName:match("^(.-)(%s*%(Rank%s+%d+%))$")
        if nameNoRank then
            baseName = nameNoRank
            rankSuffix = rank
        end
        -- Look up spell ID
        local spellID = SC:GetSpellID(baseName)
        if spellID then
            -- NOTE: Do NOT normalize to base spell ID here. FindBaseSpellByID
            -- walks the full replacement chain (e.g. Barbed Shot -> Steady Shot)
            -- which loses the actual spell identity. WoW /cast handles talent
            -- overrides natively, so the spell's own ID is correct for export.
            -- Preserve leading whitespace from original ref
            local leading = ref:match("^(%s*)")
            return leading .. bangPrefix .. "{spell:" .. spellID .. "}" .. rankSuffix
        end
        -- Try item lookup (Phase 2d)
        local itemID = SC:GetItemID(baseName)
        if itemID then
            local leading = ref:match("^(%s*)")
            return leading .. bangPrefix .. "{item:" .. itemID .. "}"
        end
        -- Try toy lookup (Phase 2d)
        local toyID = SC:GetToyID(baseName)
        if toyID then
            local leading = ref:match("^(%s*)")
            return leading .. bangPrefix .. "{toy:" .. toyID .. "}"
        end
        -- Lookup failed (unknown name) -- keep original
        return ref
    elseif direction == "toNames" then
        local leading = ref:match("^(%s*)") or ""
        local hasBang = false
        local inner = trimmed

        -- Strip ! prefix if present
        if inner:sub(1, 1) == "!" then
            hasBang = true
            inner = inner:sub(2)
        end

        -- Try {spell:ID}
        local spellId = inner:match("^{spell:(%d+)}$")
        if spellId then
            local sname = C_Spell.GetSpellName(tonumber(spellId))
            if sname then
                return leading .. (hasBang and "!" or "") .. sname
            end
            return ref
        end

        -- Try {item:ID} (Phase 2d)
        local itemId = inner:match("^{item:(%d+)}$")
        if itemId then
            local iname = C_Item.GetItemInfo(tonumber(itemId))
            if iname then
                return leading .. (hasBang and "!" or "") .. iname
            end
            return ref
        end

        -- Try {toy:ID} (Phase 2d)
        local toyId = inner:match("^{toy:(%d+)}$")
        if toyId then
            local _, tname = C_ToyBox.GetToyInfo(tonumber(toyId))
            if tname then
                return leading .. (hasBang and "!" or "") .. tname
            end
            return ref
        end

        -- Not a recognized tag, pass through
        return ref
    end

    return ref
end

--- Translate macrotext between localized names and spell ID tags.
--- Used at export/import boundaries for locale-safe sharing.
--- @param macrotext string The macro text to translate
--- @param direction string "toIDs" (export) or "toNames" (import)
--- @return string translated The translated macrotext
function SC:TranslateMacrotext(macrotext, direction)
    if not macrotext or macrotext == "" then
        return macrotext
    end

    local lines = {}
    for line in (macrotext .. "\n"):gmatch("([^\n]*)\n") do
        lines[#lines + 1] = line
    end

    for i, line in ipairs(lines) do
        -- Match command: leading whitespace + /command + space + rest
        local prefix, cmd, sep, rest = line:match("^(%s*)(/%a+)(%s+)(.*)")
        if cmd and TRANSLATABLE_COMMANDS[cmd:lower()] then
            -- Consume [conditional] blocks from rest
            local condPrefix, spellPart = ConsumeConditionals(rest)

            -- For /castsequence: consume reset=... clause
            local resetClause = ""
            if cmd:lower() == "/castsequence" then
                local reset, afterReset = spellPart:match("^(reset=%S+%s*)(.*)")
                if reset then
                    resetClause = reset
                    spellPart = afterReset
                end
            end

            -- For /equipslot: consume leading slot number (Phase 2d)
            local slotPrefix = ""
            if cmd:lower() == "/equipslot" then
                local slot, remainder = spellPart:match("^(%d+%s+)(.*)")
                if slot then
                    slotPrefix = slot
                    spellPart = remainder
                end
            end

            -- Determine delimiter: /castsequence uses comma, others use semicolon
            local delimiter
            if cmd:lower() == "/castsequence" then
                delimiter = ","
            else
                delimiter = ";"
            end

            -- Split spell references by delimiter
            local refs = {}
            local pos = 1
            local spLen = #spellPart
            while pos <= spLen do
                local delimPos = spellPart:find(delimiter, pos, true)
                if delimPos then
                    refs[#refs + 1] = spellPart:sub(pos, delimPos - 1)
                    pos = delimPos + 1
                else
                    refs[#refs + 1] = spellPart:sub(pos)
                    pos = spLen + 1
                end
            end

            -- For non-castsequence commands, each semicolon-delimited ref
            -- may itself contain comma-separated spells (e.g. /castrandom A, B; C)
            -- But actually /cast and friends use semicolons for fallback casts only.
            -- /castsequence uses commas. Keep it simple: one delimiter per command type.

            -- Translate each ref
            for j, ref in ipairs(refs) do
                -- For /castsequence: each comma-delimited entry is one spell
                -- For others: each semicolon-delimited entry may have conditionals
                if cmd:lower() ~= "/castsequence" and ref:find("%[") then
                    -- This ref has its own conditionals (fallback with conditions)
                    -- Preserve leading whitespace (e.g. space after ; delimiter)
                    local leading = ref:match("^(%s*)") or ""
                    local innerCond, innerSpell = ConsumeConditionals(ref)
                    innerSpell = TranslateSpellRef(innerSpell, direction)
                    refs[j] = leading .. innerCond .. innerSpell
                else
                    refs[j] = TranslateSpellRef(ref, direction)
                end
            end

            -- Reassemble
            lines[i] = prefix .. cmd .. sep .. condPrefix .. resetClause .. slotPrefix .. table.concat(refs, delimiter)
        end
        -- Non-translatable lines pass through unchanged
    end

    return table.concat(lines, "\n")
end

---------------------------------------------------------------------------
-- Macro Command Autocomplete
---------------------------------------------------------------------------

-- WoW macro commands for autocomplete (source: warcraft.wiki.gg/Macro_commands)
-- Includes all combat, targeting, pet, character, chat, system, and
-- metacommands that users might write in macro sequences.
SC.macroCommands = {
    -- Metacommands (# prefix)
    "#show",
    "#showtooltip",
    -- Battle pets
    "/dismisspet",
    "/randomfavoritepet",
    "/randompet",
    "/summonpet",
    -- Character / movement
    "/dismount",
    "/equip",
    "/equipset",
    "/equipslot",
    "/follow",
    "/leavevehicle",
    -- Chat (commonly used in macros)
    "/emote",
    "/guild",
    "/officer",
    "/party",
    "/raid",
    "/reply",
    "/rw",
    "/say",
    "/tell",
    "/whisper",
    "/yell",
    -- Combat
    "/cancelaura",
    "/cancelform",
    "/cancelqueuedspell",
    "/cast",
    "/castrandom",
    "/castsequence",
    "/changeactionbar",
    "/click",
    "/startattack",
    "/stopattack",
    "/stopcasting",
    "/stopmacro",
    "/stopspelltarget",
    "/swapactionbar",
    "/use",
    "/userandom",
    "/usetoy",
    -- Pet
    "/petassist",
    "/petattack",
    "/petautocastoff",
    "/petautocaston",
    "/petautocasttoggle",
    "/petdefensive",
    "/petdismiss",
    "/petfollow",
    "/petmoveto",
    "/petpassive",
    "/petstay",
    -- PvP
    "/duel",
    "/forfeit",
    "/pvp",
    -- Raid / party
    "/clearworldmarker",
    "/invite",
    "/readycheck",
    "/targetmarker",
    "/worldmarker",
    -- System
    "/dump",
    "/logout",
    "/played",
    "/random",
    "/reload",
    "/run",
    "/script",
    -- Targeting
    "/assist",
    "/clearfocus",
    "/cleartarget",
    "/focus",
    "/target",
    "/targetenemy",
    "/targetenemyplayer",
    "/targetexact",
    "/targetfriend",
    "/targetfriendplayer",
    "/targetlastenemy",
    "/targetlastfriend",
    "/targetlasttarget",
    "/targetparty",
    "/targetraid",
}

--- Search macro commands by prefix.
--- Handles both "/" and "#" prefixed commands.
--- @param prefix string The prefix to match (must start with "/" or "#")
--- @param maxResults number|nil Maximum results (default from Defaults)
--- @return table Array of { name } entries matching the prefix
function SC:MacroCommandSearch(prefix, maxResults)
    if not prefix then
        return {}
    end
    local firstChar = prefix:sub(1, 1)
    if firstChar ~= "/" and firstChar ~= "#" then
        return {}
    end
    prefix = strlower(prefix)
    maxResults = maxResults or D().AUTOCOMPLETE_MAX_RESULTS

    local results = {}
    for _, cmd in ipairs(self.macroCommands) do
        if strlower(cmd):sub(1, #prefix) == prefix then
            table.insert(results, { name = cmd })
            if #results >= maxResults then
                break
            end
        end
    end
    return results
end

---------------------------------------------------------------------------
-- Macro Text Spell Extraction
---------------------------------------------------------------------------

--- Extract the most relevant castable spell name from a macro text string.
--- Prefers rotation spells ([combat] or unconditional) over housekeeping
--- (conditional utility lines). Returns the last preferred match, or the
--- first conditional match as fallback.
--- Handles /cast, /use, /castrandom, /castsequence with conditionals,
--- reset= clauses, rank syntax, and multi-line text.
--- @param macrotext string The macro text to parse
--- @return string|nil spellName The most relevant spell name found, or nil
function SC:ParseSpellFromMacrotext(macrotext)
    if not macrotext or macrotext == "" then
        return nil
    end

    -- Commands that don't cast spells -- skip these lines
    local skipPrefixes = D().SKIP_SPELL_PREFIXES

    local preferred = nil
    local fallback = nil

    for line in macrotext:gmatch("[^\r\n]+") do
        -- Check if this line should be skipped
        local skip = false
        local lineLower = line:lower()
        for _, pat in ipairs(skipPrefixes) do
            if lineLower:match(pat) then
                skip = true
                break
            end
        end

        if not skip then
            -- Match /cast, /use, /castrandom, /castsequence (case-insensitive)
            local cmdMatch = line:match("^%s*/[Cc][Aa][Ss][Tt]%s")
                or line:match("^%s*/[Uu][Ss][Ee]%s")
                or line:match("^%s*/[Cc][Aa][Ss][Tt][Rr][Aa][Nn][Dd][Oo][Mm]%s")
                or line:match("^%s*/[Cc][Aa][Ss][Tt][Ss][Ee][Qq][Uu][Ee][Nn][Cc][Ee]%s")

            if cmdMatch then
                -- Classify: check for conditionals and [combat] token
                local hasConditionals = line:match("%[.-%]") ~= nil
                local hasCombat = false
                if hasConditionals then
                    for condBlock in lineLower:gmatch("%[(.-)%]") do
                        for token in condBlock:gmatch("[^,]+") do
                            token = token:match("^%s*(.-)%s*$")
                            if token == "combat" then
                                hasCombat = true
                                break
                            end
                        end
                        if hasCombat then
                            break
                        end
                    end
                end

                -- Strip the command prefix
                local rest = line:match("^%s*/[%a]+%s+(.*)")
                if rest then
                    -- Strip [conditionals] blocks
                    rest = rest:gsub("%[.-%]", "")
                    -- Strip reset=... clause (for /castsequence)
                    rest = rest:gsub("reset=%S+%s*", "")
                    -- Trim leading/trailing whitespace
                    rest = rest:match("^%s*(.-)%s*$")

                    if rest and rest ~= "" then
                        -- For /castsequence: take only the first spell (before comma)
                        local spell = rest:match("^([^,;]+)")
                        if spell then
                            spell = spell:match("^%s*(.-)%s*$")
                            -- Strip "(Rank N)" suffix
                            spell = spell:gsub("%s*%(Rank%s+%d+%)%s*$", "")
                            -- Strip trailing semicolons
                            spell = spell:gsub(";+%s*$", "")
                            spell = spell:match("^%s*(.-)%s*$")
                            if spell and spell ~= "" then
                                -- Skip /use inventory slots (pure numeric)
                                local isUseCmd = lineLower:match("^%s*/use%s")
                                local isSlot = isUseCmd and tonumber(spell)
                                if not isSlot then
                                    if not hasConditionals or hasCombat then
                                        preferred = spell -- last preferred wins
                                    elseif not fallback then
                                        fallback = spell -- first fallback preserved
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end

    return preferred or fallback
end

---------------------------------------------------------------------------
-- Event-Driven Refresh with Debounce
---------------------------------------------------------------------------

--- Schedule a debounced cache rescan. Cancels any pending timer.
local function ScheduleRescan()
    if debounceTimer then
        debounceTimer:Cancel()
        debounceTimer = nil
    end
    local delay = InCombatLockdown() and D().SPELL_CACHE_COMBAT_DEBOUNCE or D().SPELL_CACHE_DEBOUNCE
    debounceTimer = C_Timer.NewTimer(delay, function()
        debounceTimer = nil
        SC:Scan()
    end)
end

---------------------------------------------------------------------------
-- One-Time Migration: generate taggedSteps for existing sequences (Phase 2a)
---------------------------------------------------------------------------

--- Generate taggedSteps for all sequences that lack them.
--- Called once after SpellCache first reports ready, if pendingTagMigration is set.
--- After completion, clears the flag so it never runs again.
local function RunPendingTagMigration()
    if not SC.ready then
        return
    end
    if not _G.GRIP_EMS_DB or not GRIP_EMS_DB.pendingTagMigration then
        return
    end
    if not _G.GRIP_EMS_CHAR or not GRIP_EMS_CHAR.sequences then
        return
    end

    local count = 0
    for name, seqData in pairs(GRIP_EMS_CHAR.sequences) do
        if type(seqData) == "table" then
            for _, version in ipairs(seqData.versions or {}) do
                if not version.taggedSteps then
                    version.taggedSteps = SC:TagSteps(version.steps or {})
                    version.taggedKeyPress = SC:TranslateMacrotext(version.keyPress or "", "toIDs")
                    version.taggedKeyRelease = SC:TranslateMacrotext(version.keyRelease or "", "toIDs")
                    version.stepsLocale = GetLocale()
                    count = count + 1
                end
            end
        end
    end

    GRIP_EMS_DB.pendingTagMigration = nil
    GRIP_EMS_DB.taggedStepsMigrated = true
    if count > 0 then
        local GE = GRIPEMS
        GE:Print(string.format("Locale protection added to %d sequence versions.", count))
    end
end

-- Hook into SPELL_CACHE_REFRESHED to trigger migration
if GRIPEMS.RegisterCallback then
    GRIPEMS:RegisterCallback("SPELL_CACHE_REFRESHED", RunPendingTagMigration)
end

--- Register events that trigger spell cache refresh.
--- Called once during addon initialization.
function SC:RegisterEvents()
    -- Named for /reload reuse -- prevents orphan C++ frame objects
    local eventFrame = _G["GRIPEMS_SpellCacheEvent"] or CreateFrame("Frame", "GRIPEMS_SpellCacheEvent")
    eventFrame:UnregisterAllEvents()
    eventFrame:RegisterEvent("SPELLS_CHANGED")
    eventFrame:RegisterEvent("TRAIT_CONFIG_UPDATED")
    eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
    eventFrame:RegisterEvent("UNIT_PET")
    eventFrame:RegisterEvent("PET_BAR_UPDATE")

    eventFrame:RegisterEvent("BAG_UPDATE_DELAYED")
    eventFrame:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")

    eventFrame:SetScript("OnEvent", function(_, event, arg1)
        -- Item/equipment events: rebuild item cache only (not full scan)
        if event == "BAG_UPDATE_DELAYED" or event == "PLAYER_EQUIPMENT_CHANGED" then
            if SC.ready then
                SC:BuildItemCache()
            end
            return
        end
        if event == "UNIT_PET" and arg1 ~= "player" then
            return
        end
        ScheduleRescan()
    end)

    SC.eventFrame = eventFrame
end

-- Auto-register events when file loads (Core.lua has already created GRIPEMS)
SC:RegisterEvents()
