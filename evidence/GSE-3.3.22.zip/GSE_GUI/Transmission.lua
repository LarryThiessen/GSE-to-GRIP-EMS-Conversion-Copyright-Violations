local _, ns = ...
ns.deferred = ns.deferred or {}

local function setup()
local GSE = ns.GSE
local Statics = GSE.Static
local L = GSE.L

function GSE.GUIShowTransmissionGui(inckey, editframe)
  local UI = GSE.UI

  local transauthor = GetUnitName("player", true) .. "@" .. GetRealmName()

  local transmissionFrame = UI:Create("Frame")
  transmissionFrame.frame:SetFrameStrata("MEDIUM")
  transmissionFrame.frame:SetClampedToScreen(true)

  --[==[@debug@
  GSE.PrintDebugMessage("GSE Version " .. GSE.VersionString, Statics.SourceTransmission)
  --@end-debug@]==]

  local transSequencevalue = ""

  transmissionFrame:SetTitle(L["Send To"])
  transmissionFrame:SetCallback(
    "OnClose",
    function(widget)
      transmissionFrame:Hide()
    end
  )
  transmissionFrame:SetLayout("List")
  transmissionFrame:SetWidth(290)
  transmissionFrame:SetHeight(190)
  transmissionFrame:Hide()

  local SequenceListbox = UI:Create("Dropdown")
  --SequenceListbox:SetLabel(L["Load Sequence"])
  SequenceListbox:SetWidth(250)
  SequenceListbox:SetCallback(
    "OnValueChanged",
    function(obj, event, key)
      transSequencevalue = key
    end
  )
  transmissionFrame.SequenceListbox = SequenceListbox
  transmissionFrame:AddChild(SequenceListbox)

  local playereditbox = UI:Create("EditBoxExampleAll")
  playereditbox:SetLabel(L["Send To"])
  playereditbox:SetWidth(250)
  playereditbox:DisableButton(true)
  transmissionFrame:AddChild(playereditbox)

  local sendbutton = UI:Create("Button")
  sendbutton:SetText(L["Send"])
  sendbutton:SetWidth(250)
  sendbutton:SetCallback(
    "OnClick",
    function()
      GSE.TransmitSequence(transSequencevalue, "WHISPER", playereditbox:GetText(), transmissionFrame)
    end
  )
  transmissionFrame:AddChild(sendbutton)

  if editframe then
    -- editframe:GetPoint() returns are unused; dropped

    transmissionFrame:ClearAllPoints()
    transmissionFrame:SetPoint("TOPLEFT", editframe.frame, editframe.Width + 10, 0)
  end

  local allNames = GSE.GetSequenceNames()
  local names = {}
  for k, v in pairs(allNames) do
    local txElements = GSE.split(k, ",")
    local txClassId = tonumber(txElements[1])
    local txSeqName = txElements[3]
    GSE.EnsureSequenceLoaded(txClassId, txSeqName)
    local txSeq = GSE.Library[txClassId] and GSE.Library[txClassId][txSeqName]
    if not (txSeq and txSeq.MetaData and txSeq.MetaData.noExport) then
      names[k] = v
    end
  end
  transmissionFrame.SequenceListbox:SetList(names)
  if not GSE.isEmpty(inckey) then
    transmissionFrame.SequenceListbox:SetValue(inckey)
    transSequencevalue = inckey
  end
  transmissionFrame:Show()
  if transmissionFrame.frame and GSE.RegisterUIScaleFrame then GSE.RegisterUIScaleFrame(transmissionFrame.frame) end
end
end
table.insert(ns.deferred, setup)
