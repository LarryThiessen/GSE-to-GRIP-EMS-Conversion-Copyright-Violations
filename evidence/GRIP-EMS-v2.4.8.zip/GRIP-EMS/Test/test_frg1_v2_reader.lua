-- GRIP-EMS: Headless test for the FRG1 v2 Forge-envelope reader
--
-- Created:    2026-07-26
-- Updated:    2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.
--
-- Standalone (Lua 5.1) test for the FRG1 v2 envelope reader: the payload-kind
-- discriminator in Import/LegacyImport.lua (LI.ValidateForgeEnvelope), the
-- native preview + commit rails in Import/ImportPreview.lua, and the legacy
-- envelope rail that must keep behaving exactly as it did before v2. Loads
-- the REAL modules via loadfile + setfenv into a sandbox, in TOC order:
-- Data/Defaults.lua, Engine/Identity.lua, Import/LegacyImport.lua,
-- Import/ImportPreview.lua.
--
-- Serialization is stubbed with a registry-backed pass-through encoder.
-- Libs/ is gitignored and the CI job fetches only LibStub and
-- CallbackHandler, so the real S.Encode / S.Decode (C_EncodingUtil-backed)
-- are not available headless. Encode parks the envelope table in a registry
-- and hands back a prefixed handle; Decode looks the table up and reports
-- the format its prefix maps to, longest-prefix-first like the real
-- detector.
--
-- The native payload fixture mirrors GE.BuildCollectionPayload
-- (Import/ExportPreview.lua): every field that builder sets unconditionally
-- is present, so the reader is proven against the shape the emitter really
-- sends rather than a trimmed subset.
--
-- Run from the EMS root:  lua Test/test_frg1_v2_reader.lua
-- Exit code 0 = all passed, 1 = at least one failure.
--
-- Cases:
--   A1   v2 envelope carrying a native payload reports payloadKind native
--   A2   v1 envelope carrying a legacy payload reports payloadKind legacy
--   A3   v1 envelope carrying a NATIVE payload still reports native
--        (the discriminator reads payload shape, never formatVersion)
--   A4   v2 envelope carrying a LEGACY payload still reports legacy
--   A5   formatVersion above D.FRG1_FORMAT_VERSION is refused, and the
--        refusal returns no payload kind
--   A6   a payload that is neither native-shaped nor a COLLECTION is refused
--        with the payload-is-not-a-COLLECTION message
--   A7   Preview(v2 native) -> ok, format FRG1, payloadKind native, count
--   A8   every native preview entry carries the forge attribution family
--   A9   Preview(v1 legacy) -> format FRG1 and payloadKind legacy
--   A10  Preview(native string) -> format GRIP1 and NO payloadKind
--   A11  Import(v2 native) routes the native rail and names the sequences
--   A12  Import(v1 legacy) unchanged: same names, count, forge stamp
--   A13  Preview(v2 native SINGLE-sequence) -> FRG1, native, one stamped
--        entry (the native branch keys on shape, never on payload.type)
--   A14  Import(v2 native SINGLE-sequence) lands with the forge stamp
--   A15  Preview(v2 native SINGLE-sequence + variables) counts, lists and
--        name-sorts the bundled variables
--   A16  Preview(v2 native COLLECTION + variables) does the same, which is
--        what proves the single-sequence tail really mirrors the
--        COLLECTION branch rather than only claiming to in a comment
--   A17  bundled variables carry new / identical / different plus the
--        default conflict action each status implies
--   A18  Import(v2 native SINGLE-sequence + variables) drives the commit
--        rail: one variable stored, one skipped because it already exists
--   A19  the commit rail's two reject branches: an invalid name is
--        refused outright and never stored, an invalid function body is
--        warned about but still saved
--   A20  the REAL Data/VariableStore.lua validators, loaded into the same
--        sandbox: both length caps at their boundaries, the charset rule
--        and the loadstring compile stage
--   A21  fake-versus-real parity: the harness fake and the real validator
--        return the same verdict for every input in a shared table, so the
--        fake cannot drift away from the contract it stands in for
--   A22  a payload with a non-text variable name previews cleanly instead
--        of crashing the sort comparator, and the entry is dropped
--   A23  a payload with a non-text function body imports with a warning
--        instead of crashing the commit rail
--   A24  the COLLECTION branch's own non-text-name guard, which A22 does
--        NOT reach because A22 is a single-sequence payload
--   A25  a legacy payload whose variable key is a table warns instead of
--        crashing the failed-to-decode message
--   A26  the same for a legacy payload whose MACRO key is a table
--   A27  a legacy payload with a non-text variable name drops the entry
--        with a warning rather than listing an unrenderable name
--   A28  the same for a non-text SEQUENCE name
--   A29  a non-text macro name is dropped while a well-formed one beside
--        it still lists, which also proves the macro walk is reachable
--   A30  the native COLLECTION SEQUENCES walk drops a non-text name, the
--        one key-consuming walk the first two hardening passes missed
--   A31  a native single-sequence payload whose name is not text is
--        refused rather than previewed with an unrenderable name
--   A32  both failed-to-decode lines coerce a BOOLEAN and a NUMBER key,
--        not just the table key A25 and A26 already pin
--   A33  the COMMIT rail's two failed-to-decode lines coerce a non-text
--        key instead of crashing after sequences have already committed
--   A34  a non-text SEQUENCE name is refused by the commit rail instead of
--        being persisted into the Engine under a number key
--   A35  a non-text MACRO name counts as skipped, not imported, and is
--        never enqueued for creation
--   A36  a Variable action whose Variable field is not text is compiled
--        without crashing the concatenation
--   A37  the conditional-action compiler drops a non-text condition with
--        a warning instead of erroring on the concatenation
--   A38  the migrate fallback walk's decode-failure warning coerces a
--        non-text sequence key instead of erroring on it
--   A39  an If action with NO condition still compiles unconditionally,
--        which is long-standing behaviour, but now says so
--   A40  an If action whose Variable field is not text is stored as text
--        on the node, so the export text builder cannot fail on it
--   A41  an Action/spell or Action/item whose unit field is not text
--        falls back to the untargeted macro instead of erroring
--   A42  an Action/macro whose macro field is not text is dropped instead
--        of erroring inside the spell-ID resolver
--   A43  CompileMacroVersion accepts a STRING KeyPress block, drops a
--        number or boolean, and keeps the good lines out of a mixed array
--   A44  MapLegacyVariable skips non-text eventNames entries instead of
--        losing the whole variable to table.concat
--   A45  a malformed (non-table) steps field previews with a warning rather
--        than a well-formed-looking zero, and non-table chain fields are
--        tolerated by the ipairs walks
--   A46  the commit rail's step count guards ver.steps as well as ver: an
--        absent steps field raised, and a string one fabricated a count
--   A47  the action-tree entry points absorb a scalar: a number or boolean
--        Actions field yields an empty tree instead of raising on "#", and a
--        scalar action element maps to no node instead of raising on .Type
--        (nil and a Comment action are pinned as unchanged behaviour, so the
--        case cannot pass by returning nil for everything)
--   A48  the ELEMENT-level scalar sites absorb too, on both the tree walk and
--        the flat compiler: the six raise sites A47 did not reach, including
--        the string Actions field that survives "#" and dies one level down,
--        with the good-neighbour control proving a bad element is reported
--        rather than swallowed
--   A49  the CompileMacroVersion head absorbs a scalar macroVersion (a number
--        and a boolean raised at the first dereference; nil and a string were
--        already absorbed and are pinned unchanged), and the substitute-versus-
--        drop pair is proved: { REPEAT, GOOD } warns 0 with the Frostbolt
--        present, { 5, REPEAT, GOOD } warns 2 with it absent, and row one is
--        exactly what a DROP implementation would have produced for row two

local ADDON_NAME = "GRIP-EMS"

-- ---------------------------------------------------------------------------
-- Minimal assertion + runner harness.
-- ---------------------------------------------------------------------------

local tests = {}

local function test(name, fn)
    tests[#tests + 1] = { name = name, fn = fn }
end

local function assertEqual(expected, actual, label)
    if expected ~= actual then
        error((label or "value") .. ": expected " .. tostring(expected) .. ", got " .. tostring(actual), 2)
    end
end

local function assertTrue(cond, label)
    if not cond then
        error((label or "condition") .. " failed", 2)
    end
end

-- ---------------------------------------------------------------------------
-- Sandbox: a self-referential no-op stub backs every unknown global, so the
-- modules load without a real WoW client. Real stdlib falls through to _G.
-- ---------------------------------------------------------------------------

local stub = {}
setmetatable(stub, {
    __index = function()
        return stub
    end,
    __call = function()
        return stub
    end,
})

-- Every WoW global this harness's loaded modules actually read, recorded by
-- instrumenting the catch-all and running the suite (pass 11 EDIT 7 steps a-c,
-- driver at outputs/pass11_unknown_globals.lua). Fourteen distinct names.
--
-- With the list explicit, the catch-all below returns nil rather than the
-- self-referential stub, so "if SomeGlobal then" stops being unconditionally
-- TRUE and a newly-read global fails loudly by name.
--
-- The three sibling-addon globals are deliberately absent (nil): "the other
-- addon is not installed" is the realistic default, and it is the branch the
-- migrate fallback in A38 exercises.
local WOW_GLOBALS = {
    MAX_ACCOUNT_MACROS = 120,
    MAX_CHARACTER_MACROS = 18,
    VIDEO_OPTIONS_DISABLED = "Disabled",
    VIDEO_OPTIONS_FAIR = "Fair",
    VIDEO_OPTIONS_HIGH = "High",
    VIDEO_OPTIONS_LOW = "Low",
    VIDEO_OPTIONS_MEDIUM = "Medium",
    VIDEO_OPTIONS_ULTRA = "Ultra",
    VIDEO_OPTIONS_ULTRA_HIGH = "Ultra High",
    C_AddOns = {
        IsAddOnLoaded = function()
            return false
        end,
    },
    CreateFrame = function()
        return {
            SetScript = function() end,
            RegisterEvent = function() end,
            Hide = function() end,
            Show = function() end,
        }
    end,
}

local UNKNOWN_GLOBALS = {}
local env = setmetatable({}, {
    __index = function(_, k)
        local v = rawget(_G, k)
        if v ~= nil then
            return v
        end
        if WOW_GLOBALS[k] ~= nil then
            return WOW_GLOBALS[k]
        end
        UNKNOWN_GLOBALS[k] = (UNKNOWN_GLOBALS[k] or 0) + 1
        return nil
    end,
})
_G.__EMS_UNKNOWN_GLOBALS = UNKNOWN_GLOBALS
env._G = env

-- Real locale values, loaded from Locale/enUS.lua below rather than
-- hand-copied. The echo fallback alone returns the KEY, which carries no %s
-- or %d, so string.format silently ignores its arguments and can never raise
-- -- any fixture whose behaviour depends on a specifier is inert and looks
-- green. A hand-maintained list of "the keys that matter" is the same drift
-- problem one level up.
local LOADED_LOCALE = {}

local LOCALE = setmetatable({}, {
    __index = function(_, k)
        -- Echo fallback is kept deliberately: a key absent from enUS.lua must
        -- return the key, not nil, or unrelated cases fail on a nil index.
        return LOADED_LOCALE[k] or k
    end,
})

env.LibStub = function()
    return {
        GetLocale = function()
            return LOCALE
        end,
        -- Locale/enUS.lua writes its strings through NewLocale, so handing it
        -- LOADED_LOCALE is what fills the real values in.
        NewLocale = function()
            return LOADED_LOCALE
        end,
    }
end

-- Real string helpers: the stub fallback would hand back a table, and the
-- import paths format names and macro text with these.
env.format = string.format
env.strlower = string.lower
env.strupper = string.upper
env.strmatch = string.match
env.strfind = string.find
env.strtrim = function(s)
    return (s:gsub("^%s+", ""):gsub("%s+$", ""))
end

-- Deterministic clock + character surface. Nothing under test reads these
-- for a decision; they only have to return the right TYPE.
env.time = os.time
env.GetTime = function()
    return 0
end
env.GetLocale = function()
    return "enUS"
end
env.GetRealmName = function()
    return "TestRealm"
end
env.UnitName = function()
    return "Tester", "TestRealm"
end
env.UnitClass = function()
    return "Mage", "MAGE", 8
end
env.BNGetInfo = function()
    return nil, nil
end
env.GetBuildInfo = function()
    return "12.0.7", "68256", nil, 120007
end
-- Without this the catch-all stub hands back a TABLE and the macro walk's
-- "slot > 0" comparison errors for EVERY key, well-formed ones included,
-- which makes the whole walk untestable. 0 means "no such macro", so the
-- walk takes the create branch.
env.GetMacroIndexByName = function()
    return 0
end

local charDB = { sequences = {} }
env.GRIP_EMS_DB = {}
env.GRIP_EMS_CHAR = charDB

-- ---------------------------------------------------------------------------
-- Addon table. Data/Defaults.lua fills in GRIPEMS.Defaults on load; the
-- Engine / SpellCache / Serialization surfaces the preview and commit rails
-- reach for are stubbed to the minimum those rails touch.
-- ---------------------------------------------------------------------------

local GRIPEMS = {}
function GRIPEMS:Debug() end
function GRIPEMS:Print() end
GRIPEMS.version = "2.3.14"

GRIPEMS.Engine = {
    sequences = {},
    ActivateSequence = function(self, name, seqData)
        self.sequences[name] = { data = seqData }
    end,
    RegisterSequenceOnly = function(self, name, seqData)
        self.sequences[name] = { data = seqData }
    end,
    DeactivateSequence = function(self, name)
        self.sequences[name] = nil
        charDB.sequences[name] = nil
    end,
    GetActiveVersion = function(_, seqData)
        if not seqData or not seqData.versions then
            return nil
        end
        return seqData.versions[seqData.defaultVersion or 1] or seqData.versions[1]
    end,
    MigrateSequenceFormat = function() end,
}

-- The preview variable walk resolves each incoming variable against the
-- store to classify it. Two known definitions make identical and different
-- reachable; every other name resolves new.
local varStore = {
    _A17_SAME = { value = "1", funct = "", events = "", disabled = false },
    _A17_DIFF = { value = "9", funct = "", events = "", disabled = false },
    _A18_EXISTING = { value = "1", funct = "", events = "", disabled = false },
}
-- Get alone covers the preview walk. The commit rail also calls
-- ValidateName, ValidateFunction and Set with no nil guard
-- (LegacyImport.lua:2060-2081), so a Get-only stub makes LI.Import on a
-- variables-bearing envelope die with "attempt to call method
-- 'ValidateName' (a nil value)". ValidateName mirrors the real
-- "^[%w_]+$" contract that D.VAR_PATTERN is documented against
-- (Data/Defaults.lua:1019). Both validators mirror the real control flow
-- in Data/VariableStore.lua:433 and :450, including the two length caps
-- and the loadstring compile check, so a case pinning a reject branch is
-- pinning the product's contract rather than the fake's convenience.
GRIPEMS.VariableStore = {
    Get = function(_, name)
        return varStore[name]
    end,
    Set = function(_, name, varDef)
        varStore[name] = varDef
    end,
    ValidateName = function(_, name)
        if not name or name == "" then
            return false, "variable name is empty"
        end
        if type(name) ~= "string" then
            return false, "variable name is not text"
        end
        if #name > GRIPEMS.Defaults.VAR_MAX_NAME then
            return false, "variable name is too long"
        end
        if not name:match("^[%w_]+$") then
            return false, "variable name has invalid characters"
        end
        return true
    end,
    ValidateFunction = function(_, funcStr)
        if not funcStr or funcStr == "" then
            return true
        end
        if type(funcStr) ~= "string" then
            return false, "function body must be a string"
        end
        if #funcStr > GRIPEMS.Defaults.VAR_MAX_FUNC then
            return false, "function body is too long"
        end
        -- selene: allow(undefined_variable)
        local fn, err = loadstring("return " .. funcStr)
        if not fn then
            return false, err
        end
        return true
    end,
}

-- The v3+ preview translation pass runs over every payload it previews.
GRIPEMS.SpellCache = {
    ready = true,
    RecoverHandleTokensInText = function(_, text)
        return text
    end,
    TranslateMacrotext = function(_, text)
        return text
    end,
    NormalizeVersionLocale = function() end,
}

-- Registry-backed Serialization stub. Encode parks the table and returns
-- "<prefix>#<index>"; Decode resolves the index back to the parked table.
-- Prefixes are probed longest-first, matching the real detector's order, so
-- the 7-char encrypted legacy prefix cannot be shadowed by the 6-char one.
local REGISTRY = {}
local PREFIX_ORDER = {
    "GEMSCP1_PREFIX",
    "GRIP1_PREFIX",
    "GSE3_ENCRYPTED_PREFIX",
    "FRG1_PREFIX",
    "EMS1_PREFIX",
    "GSE3_PREFIX",
}
local FORMAT_OF = {
    GEMSCP1_PREFIX = "GEMSCP1",
    GRIP1_PREFIX = "GRIP1",
    GSE3_ENCRYPTED_PREFIX = "GSE3ENC",
    FRG1_PREFIX = "FRG1",
    EMS1_PREFIX = "EMS1",
    GSE3_PREFIX = "GSE3",
}

local function matchPrefix(str)
    local D = GRIPEMS.Defaults
    for _, key in ipairs(PREFIX_ORDER) do
        local prefix = D and D[key]
        if prefix and str:sub(1, #prefix) == prefix then
            return key, prefix
        end
    end
    return nil
end

GRIPEMS.Serialization = {
    Encode = function(tbl, prefix)
        REGISTRY[#REGISTRY + 1] = tbl
        return true, prefix .. "#" .. tostring(#REGISTRY)
    end,
    Decode = function(str)
        local key, prefix = matchPrefix(str)
        if not key then
            return false, "Unknown format"
        end
        local idx = tonumber(str:sub(#prefix + 2))
        local tbl = idx and REGISTRY[idx]
        if not tbl then
            return false, "Decode failed"
        end
        return true, tbl, FORMAT_OF[key]
    end,
    DetectFormat = function(str)
        local key = matchPrefix(str)
        return key and FORMAT_OF[key] or nil
    end,
}

-- ---------------------------------------------------------------------------
-- Load the REAL modules into the sandbox, in TOC order.
-- ---------------------------------------------------------------------------

local function loadModule(candidates)
    for _, path in ipairs(candidates) do
        -- loadfile is dev-harness file I/O, intentionally outside the addon WoW std.
        -- selene: allow(undefined_variable)
        local chunk = loadfile(path)
        if chunk then
            setfenv(chunk, env)
            chunk(ADDON_NAME, GRIPEMS)
            return true
        end
    end
    return false
end

local function loadRelative(relPath)
    return loadModule({
        relPath,
        "../" .. relPath,
        "GRIP/EMS/" .. relPath,
    })
end

-- The real locale first: every module below captures L at file scope, and
-- loading enUS.lua the same way real modules are loaded covers all 3290 keys
-- instead of a hand-copied subset.
assertTrue(loadRelative("Locale/enUS.lua"), "could not locate Locale/enUS.lua (run from the EMS root)")
assertTrue(loadRelative("Data/Defaults.lua"), "could not locate Data/Defaults.lua (run from the EMS root)")
assertTrue(loadRelative("Engine/Identity.lua"), "could not locate Engine/Identity.lua (run from the EMS root)")
assertTrue(loadRelative("Import/LegacyImport.lua"), "could not locate Import/LegacyImport.lua (run from the EMS root)")
assertTrue(
    loadRelative("Import/ImportPreview.lua"),
    "could not locate Import/ImportPreview.lua (run from the EMS root)"
)

local D = GRIPEMS.Defaults
local S = GRIPEMS.Serialization
local LI = GRIPEMS.LegacyImport
local Engine = GRIPEMS.Engine

assertTrue(D ~= nil, "Defaults loaded")
assertTrue(LI ~= nil, "LegacyImport loaded")
assertTrue(type(LI.ValidateForgeEnvelope) == "function", "ValidateForgeEnvelope defined")
assertTrue(type(LI.Preview) == "function", "Preview defined")
assertTrue(type(LI.CommitSelected) == "function", "CommitSelected defined")
assertTrue(type(LI.Import) == "function", "Import defined")
assertTrue(type(LI._PreviewNativePayload) == "function", "_PreviewNativePayload defined (the v2 native rail)")
assertTrue(type(LI._PreviewGRIP1) == "function", "_PreviewGRIP1 still defined (the native-string rail)")
assertTrue((tonumber(D.FRG1_FORMAT_VERSION) or 0) >= 2, "FRG1_FORMAT_VERSION is at least 2")

-- ---------------------------------------------------------------------------
-- Fixtures.
--
-- nativePayload mirrors GE.BuildCollectionPayload's unconditional fields:
-- format, version, addonVersion, type, locale, exportedAt, schemaRev,
-- sequences, variables, Macros. nativeSinglePayload is its single-sequence
-- counterpart. legacyPayload is the legacy-shaped COLLECTION the v1
-- envelope wraps.
-- ---------------------------------------------------------------------------

local FIXED_EXPORTED_AT = 1780000000

local function nativePayload(names, vars)
    local payload = {
        format = "GRIP-EMS",
        version = D.GRIP_FORMAT_VERSION,
        addonVersion = GRIPEMS.version,
        type = "COLLECTION",
        locale = "enUS",
        exportedAt = FIXED_EXPORTED_AT,
        schemaRev = D.EMS_EXPORT_SCHEMA_REV,
        sequences = {},
        variables = vars or {},
        Macros = {},
    }
    for _, name in ipairs(names) do
        payload.sequences[name] = {
            versions = { [1] = { steps = { "/cast Fireball" }, stepFunction = D.STEP_SEQUENTIAL } },
            defaultVersion = 1,
            author = "Forged",
        }
    end
    return payload
end

-- The single-sequence counterpart to nativePayload, built from the shape
-- GE.ExportSequence emits (Import/GRIPExport.lua): name + sequence instead
-- of a sequences table, and NO type field at all. The v2 discriminator keys
-- on format alone, so this still reaches the native rail.
local function nativeSinglePayload(name, vars)
    return {
        format = "GRIP-EMS",
        version = D.GRIP_FORMAT_VERSION,
        addonVersion = GRIPEMS.version,
        locale = "enUS",
        exportedAt = FIXED_EXPORTED_AT,
        schemaRev = D.EMS_EXPORT_SCHEMA_REV,
        variables = vars,
        name = name,
        sequence = {
            icon = D.QUESTION_MARK_ICON,
            versions = { [1] = { steps = { "/cast Fireball" }, stepFunction = D.STEP_SEQUENTIAL } },
            defaultVersion = 1,
            contextOverrides = {},
            author = "Forged",
            description = "",
            createdAt = FIXED_EXPORTED_AT,
        },
    }
end

local function legacyPayload(name)
    return {
        type = "COLLECTION",
        payload = {
            Sequences = {
                [name] = {
                    MacroVersions = {
                        [1] = {
                            StepFunction = "Sequential",
                            KeyPress = {},
                            KeyRelease = {},
                            Actions = { [1] = { Type = "Action", type = "macro", macro = "/cast Fireball" } },
                        },
                    },
                    MetaData = { Default = 1, Author = "MrSataana" },
                },
            },
        },
    }
end

-- Legacy COLLECTION payload with extra sibling tables (Variables, Macros, or a
-- replacement Sequences) merged into payload.payload. A separate helper rather
-- than a wider legacyPayload signature, so the six existing legacy cases are
-- untouched.
local function legacyPayloadWith(name, extra)
    local p = legacyPayload(name)
    for k, v in pairs(extra or {}) do
        p.payload[k] = v
    end
    return p
end

local function envelope(formatVersion, payload)
    return {
        type = "FORGE_EXPORT",
        formatVersion = formatVersion,
        forge = { author = "MrSataana", exportedAt = "20260610120000" },
        payload = payload,
    }
end

local function encode(tbl, prefix)
    local ok, str = S.Encode(tbl, prefix or D.FRG1_PREFIX)
    assertTrue(ok, "fixture encode failed")
    return str
end

-- Preview entry order follows pairs() over the payload's sequences table, so
-- names are compared as a set, never positionally.
local function nameSet(entries)
    local set = {}
    for _, entry in ipairs(entries or {}) do
        set[entry.name or entry] = true
    end
    return set
end

local function storedData(name)
    local entry = Engine.sequences[name]
    return entry and entry.data or nil
end

-- ---------------------------------------------------------------------------
-- Cases.
-- ---------------------------------------------------------------------------

test("A1: v2 envelope carrying a native payload reports payloadKind native", function()
    local forge, err, kind = LI.ValidateForgeEnvelope(envelope(2, nativePayload({ "_A1_ONE" })))
    assertTrue(forge ~= nil, "envelope validates")
    assertEqual(nil, err, "no error")
    assertEqual("MrSataana", forge.author, "forge block returned")
    assertEqual("native", kind, "payloadKind")
end)

test("A2: v1 envelope carrying a legacy payload reports payloadKind legacy", function()
    local forge, err, kind = LI.ValidateForgeEnvelope(envelope(1, legacyPayload("_A2_ONE")))
    assertTrue(forge ~= nil, "envelope validates")
    assertEqual(nil, err, "no error")
    assertEqual("legacy", kind, "payloadKind")
end)

test("A3: v1 envelope carrying a NATIVE payload still reports native", function()
    -- The discriminator reads the payload SHAPE. A v1 envelope built by an
    -- older emitter that happens to carry a native COLLECTION must still
    -- reach the native rail.
    local forge, err, kind = LI.ValidateForgeEnvelope(envelope(1, nativePayload({ "_A3_ONE" })))
    assertTrue(forge ~= nil, "envelope validates")
    assertEqual(nil, err, "no error")
    assertEqual("native", kind, "payloadKind ignores formatVersion 1")
end)

test("A4: v2 envelope carrying a LEGACY payload still reports legacy", function()
    -- Mirror of A3 in the other direction: a v2 envelope wrapping a
    -- legacy-shaped COLLECTION must still reach the legacy walk.
    local forge, err, kind = LI.ValidateForgeEnvelope(envelope(2, legacyPayload("_A4_ONE")))
    assertTrue(forge ~= nil, "envelope validates")
    assertEqual(nil, err, "no error")
    assertEqual("legacy", kind, "payloadKind ignores formatVersion 2")
end)

test("A5: a formatVersion above FRG1_FORMAT_VERSION is refused with no payload kind", function()
    local future = D.FRG1_FORMAT_VERSION + 1
    local forge, err, kind = LI.ValidateForgeEnvelope(envelope(future, nativePayload({ "_A5_ONE" })))
    assertEqual(nil, forge, "no forge block on refusal")
    assertTrue(type(err) == "string", "refusal carries a message")
    assertTrue(err:find("Update GRIP-EMS", 1, true) ~= nil, "update message kept: " .. tostring(err))
    assertEqual(nil, kind, "refusal reports no payloadKind")

    -- The same refusal must survive the full Preview rail.
    local refused = LI.Preview(encode(envelope(future, nativePayload({ "_A5_TWO" }))))
    assertTrue(refused ~= nil and refused.ok == false, "preview refuses the newer envelope")
    assertEqual(nil, refused.payloadKind, "refused preview reports no payloadKind")
    assertTrue(refused.error:find("Update GRIP-EMS", 1, true) ~= nil, "preview keeps the update message")
end)

test("A6: a payload that is neither native-shaped nor a COLLECTION is refused", function()
    local bad = envelope(2, { type = "NOT_A_COLLECTION", sequences = {} })
    local forge, err, kind = LI.ValidateForgeEnvelope(bad)
    assertEqual(nil, forge, "no forge block on refusal")
    assertEqual("Forge export: payload is not a COLLECTION", err, "refusal message")
    assertEqual(nil, kind, "refusal reports no payloadKind")
end)

test("A7: Preview of a v2 native envelope is ok / FRG1 / native with both sequences", function()
    local preview = LI.Preview(encode(envelope(2, nativePayload({ "_A7_ONE", "_A7_TWO" }))))
    assertTrue(preview ~= nil and preview.ok, "preview ok: " .. tostring(preview and preview.error))
    assertEqual("FRG1", preview.format, "preview format")
    assertEqual("native", preview.payloadKind, "preview payloadKind")
    assertEqual(2, #preview.sequences, "both native sequences listed")
    assertEqual(2, preview.totalSequences, "totalSequences matches the entry count")
    assertEqual(0, preview.totalVariables, "totalVariables matches the empty variables table")
    local names = nameSet(preview.sequences)
    assertTrue(names["_A7_ONE"], "_A7_ONE previewed")
    assertTrue(names["_A7_TWO"], "_A7_TWO previewed")
    assertTrue(preview.sequences[1].isCollection == true, "entries carry the native collection shape")
end)

test("A8: every native preview entry carries the forge attribution family", function()
    local preview = LI.Preview(encode(envelope(2, nativePayload({ "_A8_ONE", "_A8_TWO" }))))
    assertTrue(preview ~= nil and preview.ok, "preview ok: " .. tostring(preview and preview.error))
    assertEqual("MrSataana", preview.forge and preview.forge.author, "result carries the forge block")
    for i, entry in ipairs(preview.sequences) do
        local at = "entry " .. i .. " "
        assertEqual("MrSataana", entry.forge and entry.forge.author, at .. "forge.author")
        local prov = entry.opts and entry.opts.forgeProvenance
        assertEqual("MrSataana", prov and prov.author, at .. "opts.forgeProvenance.author")
        assertEqual("forge-import", entry.provenance and entry.provenance.provenanceSource, at .. "provenanceSource")
        assertEqual("GRIP Forge", entry.provenance and entry.provenance.originalAuthor, at .. "originalAuthor")
    end
end)

test("A9: Preview of a v1 legacy envelope is FRG1 and now carries payloadKind legacy", function()
    local preview = LI.Preview(encode(envelope(1, legacyPayload("_A9_ONE"))))
    assertTrue(preview ~= nil and preview.ok, "preview ok: " .. tostring(preview and preview.error))
    assertEqual("FRG1", preview.format, "preview format unchanged")
    assertEqual("legacy", preview.payloadKind, "preview payloadKind")
    assertEqual(1, #preview.sequences, "one entry")
    -- The legacy walk computes the same counts (ImportPreview.lua:417),
    -- and the unguarded ImportFrame.lua:962 / :976 comparisons read them
    -- on this path too, so pin both fields as A7 and A13 do natively.
    assertEqual(1, preview.totalSequences, "legacy walk totalSequences")
    assertEqual(0, preview.totalVariables, "legacy walk totalVariables")
    local entry = preview.sequences[1]
    assertEqual("_A9_ONE", entry.name, "entry name")
    assertEqual("MrSataana", entry.forge and entry.forge.author, "legacy entry keeps forge attribution")
    local prov = entry.opts and entry.opts.forgeProvenance
    assertEqual("MrSataana", prov and prov.author, "legacy entry opts.forgeProvenance.author")
    assertEqual("forge-import", entry.provenance and entry.provenance.provenanceSource, "legacy provenanceSource")
end)

test("A10: Preview of a native string is GRIP1 and sets NO payloadKind", function()
    -- The FRG1 stamping must not leak onto the plain native-string rail.
    local preview = LI.Preview(encode(nativePayload({ "_A10_ONE" }), D.EMS1_PREFIX))
    assertTrue(preview ~= nil and preview.ok, "preview ok: " .. tostring(preview and preview.error))
    assertEqual("GRIP1", preview.format, "native string previews as GRIP1")
    assertEqual(nil, preview.payloadKind, "no payloadKind on the string rail")
    assertEqual(1, #preview.sequences, "one entry")
    assertEqual(nil, preview.forge, "no forge block on the string rail")
    assertEqual(nil, preview.sequences[1].forge, "no per-entry forge attribution")
end)

test("A11: Import of a v2 native envelope routes the native rail and names the sequences", function()
    local ok, results = LI.Import(encode(envelope(2, nativePayload({ "_A11_ONE", "_A11_TWO" }))))
    assertTrue(ok == true, "import succeeded: " .. tostring(results))
    assertTrue(type(results) == "table", "native rail returns the results table")
    assertEqual(2, results.count, "native rail counts both imports")
    local names = nameSet(results.names)
    assertTrue(names["_A11_ONE"], "_A11_ONE reported")
    assertTrue(names["_A11_TWO"], "_A11_TWO reported")

    for _, name in ipairs({ "_A11_ONE", "_A11_TWO" }) do
        local stored = storedData(name)
        assertTrue(type(stored) == "table", name .. " registered")
        assertEqual("forge-import", stored.provenanceSource, name .. " provenanceSource")
        assertEqual("GRIP Forge", stored.originalAuthor, name .. " originalAuthor")
        local forge = stored.importMeta and stored.importMeta.forge
        assertEqual("MrSataana", forge and forge.author, name .. " importMeta.forge.author")
        local ver = Engine:GetActiveVersion(stored)
        assertEqual(1, ver and ver.steps and #ver.steps, name .. " keeps its native step")
        Engine:DeactivateSequence(name)
    end
end)

test("A12: Import of a v1 legacy envelope is unchanged: names, count, forge stamp", function()
    local ok, results = LI.Import(encode(envelope(1, legacyPayload("_A12_ONE"))))
    assertTrue(ok == true, "import succeeded: " .. tostring(results))
    assertTrue(type(results) == "table", "legacy rail returns the results table")
    assertEqual(1, results.count, "legacy rail counts one import")
    assertEqual("_A12_ONE", results.names[1], "legacy rail names the sequence")

    local stored = storedData("_A12_ONE")
    assertTrue(type(stored) == "table", "legacy sequence registered")
    assertEqual("forge-import", stored.provenanceSource, "legacy provenanceSource")
    assertEqual("GRIP Forge", stored.originalAuthor, "legacy originalAuthor")
    local ver = Engine:GetActiveVersion(stored)
    assertEqual(1, ver and ver.steps and #ver.steps, "legacy sequence keeps its compiled step")
    Engine:DeactivateSequence("_A12_ONE")
end)

test("A13: Preview of a v2 native SINGLE-sequence envelope is FRG1 / native / one entry", function()
    -- Pins the shape-only discriminator. The native branch never inspects
    -- payload.type, so a native payload that carries no type field at all is
    -- accepted, falls past the COLLECTION branch, and lands in the
    -- single-sequence preview branch (name + sequence).
    local preview = LI.Preview(encode(envelope(2, nativeSinglePayload("_A13_ONE"))))
    assertTrue(preview ~= nil and preview.ok, "preview ok: " .. tostring(preview and preview.error))
    assertEqual("FRG1", preview.format, "preview format")
    assertEqual("native", preview.payloadKind, "preview payloadKind")
    assertEqual(1, #preview.sequences, "exactly one entry")
    -- The single-sequence tail computes counts too (ImportPreview.lua:665).
    -- ImportFrame.lua:962 and :976 compare both fields against 0 with no nil
    -- guard, so a nil here raises "attempt to compare nil with number".
    assertEqual(1, preview.totalSequences, "single-sequence path totalSequences")
    assertEqual(0, preview.totalVariables, "single-sequence path totalVariables")
    local names = nameSet(preview.sequences)
    assertTrue(names["_A13_ONE"], "_A13_ONE previewed")

    local entry = preview.sequences[1]
    assertEqual("MrSataana", entry.forge and entry.forge.author, "entry forge.author")
    local prov = entry.opts and entry.opts.forgeProvenance
    assertEqual("MrSataana", prov and prov.author, "entry opts.forgeProvenance.author")
    assertEqual("forge-import", entry.provenance and entry.provenance.provenanceSource, "provenanceSource")
    assertEqual("GRIP Forge", entry.provenance and entry.provenance.originalAuthor, "originalAuthor")
end)

test("A14: Import of a v2 native SINGLE-sequence envelope lands with the forge stamp", function()
    local ok, results = LI.Import(encode(envelope(2, nativeSinglePayload("_A14_ONE"))))
    assertTrue(ok == true, "import succeeded: " .. tostring(results))
    assertTrue(type(results) == "table", "native rail returns the results table")
    assertEqual(1, results.count, "one import counted")
    local names = nameSet(results.names)
    assertTrue(names["_A14_ONE"], "_A14_ONE reported")

    local stored = storedData("_A14_ONE")
    assertTrue(type(stored) == "table", "sequence registered")
    assertEqual("forge-import", stored.provenanceSource, "provenanceSource")
    assertEqual("GRIP Forge", stored.originalAuthor, "originalAuthor")
    local forge = stored.importMeta and stored.importMeta.forge
    assertEqual("MrSataana", forge and forge.author, "importMeta.forge.author")
    local ver = Engine:GetActiveVersion(stored)
    assertEqual(1, ver and ver.steps and #ver.steps, "active version kept its step")
    Engine:DeactivateSequence("_A14_ONE")
end)

test("A15: A v2 native SINGLE-sequence envelope counts its bundled variables", function()
    local preview = LI.Preview(encode(envelope(
        2,
        nativeSinglePayload("_A15_ONE", {
            _A15_BETA = { value = "2" },
            _A15_ALPHA = { value = "1" },
        })
    )))
    assertTrue(preview ~= nil and preview.ok, "preview ok: " .. tostring(preview and preview.error))
    assertEqual("native", preview.payloadKind, "preview payloadKind")
    assertEqual(1, preview.totalSequences, "one sequence")
    assertEqual(2, preview.totalVariables, "both bundled variables counted")
    assertEqual(2, #preview.variables, "both bundled variables listed")
    assertEqual("_A15_ALPHA", preview.variables[1].name, "variables sorted by name")
    assertEqual("_A15_BETA", preview.variables[2].name, "variables sorted by name")
    assertEqual("new", preview.variables[1].status, "unknown variable is new")
    assertTrue(preview.variables[1].selected, "new variable is selected")
end)

test("A16: A v2 native COLLECTION envelope counts its bundled variables", function()
    local preview = LI.Preview(encode(envelope(
        2,
        nativePayload({ "_A16_ONE" }, {
            _A16_BETA = { value = "2" },
            _A16_ALPHA = { value = "1" },
        })
    )))
    assertTrue(preview ~= nil and preview.ok, "preview ok: " .. tostring(preview and preview.error))
    assertEqual("native", preview.payloadKind, "preview payloadKind")
    assertEqual(1, preview.totalSequences, "one sequence")
    assertEqual(2, preview.totalVariables, "both bundled variables counted")
    assertEqual(2, #preview.variables, "both bundled variables listed")
    assertEqual("_A16_ALPHA", preview.variables[1].name, "variables sorted by name")
    assertEqual("_A16_BETA", preview.variables[2].name, "variables sorted by name")
end)

test("A17: Bundled variables carry new / identical / different and a conflict action", function()
    local preview = LI.Preview(encode(envelope(
        2,
        nativeSinglePayload("_A17_ONE", {
            _A17_NEW = { value = "1" },
            _A17_SAME = { value = "1", funct = "", events = "", disabled = false },
            _A17_DIFF = { value = "1" },
        })
    )))
    assertTrue(preview ~= nil and preview.ok, "preview ok: " .. tostring(preview and preview.error))
    assertEqual(3, preview.totalVariables, "all three variables counted")
    assertEqual("_A17_DIFF", preview.variables[1].name, "sorted first")
    assertEqual("different", preview.variables[1].status, "a changed definition is different")
    assertEqual("skip", preview.variables[1].conflictAction, "different defaults to skip")
    assertEqual("_A17_NEW", preview.variables[2].name, "sorted second")
    assertEqual("new", preview.variables[2].status, "an unknown definition is new")
    assertEqual("import", preview.variables[2].conflictAction, "new defaults to import")
    assertEqual("_A17_SAME", preview.variables[3].name, "sorted third")
    assertEqual("identical", preview.variables[3].status, "a matching definition is identical")
    assertEqual("skip", preview.variables[3].conflictAction, "identical defaults to skip")
end)

test("A18: Import of a v2 native SINGLE-sequence envelope drives the variable commit rail", function()
    -- PreviewCommitAll auto-selects every previewed variable for import
    -- (LegacyImport.lua:201-203), so LI.Import reaches LI.ImportVariable
    -- through LI.CommitSelected (ImportPreview.lua:1311). Nothing else in
    -- the corpus exercises that rail.
    local ok, results = LI.Import(encode(envelope(
        2,
        nativeSinglePayload("_A18_ONE", {
            _A18_NEW = { value = "1" },
            _A18_EXISTING = { value = "1", funct = "", events = "", disabled = false },
        })
    )))
    assertTrue(ok == true, "import succeeded: " .. tostring(results))
    assertEqual(1, results.count, "one sequence imported")
    assertEqual(1, results.varsImported, "the unknown variable is imported")
    assertEqual(1, results.varsSkipped, "the already-stored variable is skipped")
    assertEqual(0, #results.warnings, "no warnings on the clean path")
    assertTrue(varStore._A18_NEW ~= nil, "the imported variable reached the store")
    assertEqual("1", varStore._A18_NEW.value, "the stored definition is the incoming one")
    varStore._A18_NEW = nil
    Engine:DeactivateSequence("_A18_ONE")
end)

test("A19: The commit rail refuses a bad variable name and warns on a bad function body", function()
    -- LI.ImportVariable rejects an invalid name outright (LegacyImport.lua:2062)
    -- but only WARNS on an invalid function body and saves the variable anyway
    -- (:2074-2079). Both are product decisions and neither was pinned.
    local ok, results = LI.Import(encode(envelope(
        2,
        nativeSinglePayload("_A19_ONE", {
            ["_A19 BAD"] = { value = "1" },
            _A19_BADFUNC = { value = "1", funct = "1 +" },
            _A19_OK = { value = "1", funct = "1 + 1" },
        })
    )))
    assertTrue(ok == true, "import succeeded: " .. tostring(results))
    assertEqual(2, results.varsImported, "the bad name is refused, the other two are stored")
    assertEqual(0, results.varsSkipped, "nothing was already in the store")
    assertEqual(2, #results.warnings, "one warning per reject branch")
    assertTrue(varStore["_A19 BAD"] == nil, "a refused name never reaches the store")
    assertTrue(varStore._A19_BADFUNC ~= nil, "a bad function body warns but still saves")
    assertTrue(varStore._A19_OK ~= nil, "the clean variable is stored")
    varStore._A19_BADFUNC = nil
    varStore._A19_OK = nil
    Engine:DeactivateSequence("_A19_ONE")
end)

-- Loading the real module rebinds GRIPEMS.VariableStore, so the fake is
-- held and put straight back. Import/ImportPreview.lua and
-- Import/LegacyImport.lua captured the fake at their own load time and keep
-- it either way. The sandbox LibStub stub is all the module needs to load.
local function loadRealVariableStore()
    local held = GRIPEMS.VariableStore
    local loaded = loadRelative("Data/VariableStore.lua")
    local real = GRIPEMS.VariableStore
    GRIPEMS.VariableStore = held
    return loaded and real or nil
end

-- Each row is { label, input, expectedVerdict }. A label is carried because
-- a 1024-character input makes an unreadable failure message, and because a
-- nil input cannot be recovered from the row otherwise. A20 and A21 both
-- read these tables, which is what makes the parity claim meaningful.
local NAME_CASES = {
    { "nil", nil, false },
    { "empty", "", false },
    { "good_name", "good_name", true },
    { "alnum", "MyVar123", true },
    { "cap boundary 32", string.rep("x", 32), true },
    { "over cap 33", string.rep("x", 33), false },
    { "space", "bad name", false },
    { "dash", "has-dash", false },
    { "number", 5, false },
    { "table", {}, false },
    { "boolean", true, false },
}

local FUNC_CASES = {
    { "nil", nil, true },
    { "empty", "", true },
    { "valid expression", "1 + 1", true },
    { "truncated expression", "1 +", false },
    { "syntax error", "1 + ) 2", false },
    { "cap boundary 1024 compiles", string.rep("z", 1024), true },
    { "over cap 1025", string.rep("z", 1025), false },
    { "number", 5, false },
    { "table", {}, false },
    { "boolean", true, false },
}

test("A20: The REAL VariableStore validators enforce both caps, the charset and the compile stage", function()
    local realVS = loadRealVariableStore()
    assertTrue(realVS ~= nil, "the real Data/VariableStore.lua loaded into the sandbox")
    assertTrue(realVS ~= GRIPEMS.VariableStore, "the fake is still installed after the load")
    for _, row in ipairs(NAME_CASES) do
        local verdict = realVS:ValidateName(row[2]) and true or false
        assertEqual(row[3], verdict, "real ValidateName " .. row[1])
    end
    for _, row in ipairs(FUNC_CASES) do
        local verdict = realVS:ValidateFunction(row[2]) and true or false
        assertEqual(row[3], verdict, "real ValidateFunction " .. row[1])
    end
end)

test("A21: The harness fake returns the same verdict as the real validator on every input", function()
    -- The fake exists so the commit rail is reachable headlessly. The moment
    -- it disagrees with the product it stops standing in for anything, and
    -- cases written against it start passing for the wrong reason.
    local realVS = loadRealVariableStore()
    assertTrue(realVS ~= nil, "the real Data/VariableStore.lua loaded into the sandbox")
    local fake = GRIPEMS.VariableStore
    for _, row in ipairs(NAME_CASES) do
        local fakeVerdict = fake:ValidateName(row[2]) and true or false
        local realVerdict = realVS:ValidateName(row[2]) and true or false
        assertEqual(realVerdict, fakeVerdict, "ValidateName parity on " .. row[1])
    end
    for _, row in ipairs(FUNC_CASES) do
        local fakeVerdict = fake:ValidateFunction(row[2]) and true or false
        local realVerdict = realVS:ValidateFunction(row[2]) and true or false
        assertEqual(realVerdict, fakeVerdict, "ValidateFunction parity on " .. row[1])
    end
end)

test("A22: A payload with a non-text variable name previews without crashing the sort", function()
    -- Before the guard this died at ImportPreview.lua:662 with
    -- "attempt to compare string with number", because a numeric key reached
    -- result.variables and the comparator compared it against a string name.
    -- It takes a MIX to trigger: all-numeric keys sort fine against each other.
    local payload = nativeSinglePayload("_A22_ONE")
    payload.variables = { _A22_STR = { value = "1" }, [5] = { value = "2" } }
    local preview = LI.Preview(encode(envelope(2, payload)))
    assertTrue(preview ~= nil and preview.ok, "preview ok: " .. tostring(preview and preview.error))
    assertEqual(1, preview.totalVariables, "only the text-named variable is listed")
    assertEqual("_A22_STR", preview.variables[1].name, "the surviving entry is the text-named one")
    assertTrue(#preview.warnings > 0, "the dropped variable is reported as a warning")
end)

test("A23: A payload with a non-text function body imports with a warning, not a crash", function()
    -- Before the guard this died inside VS:ValidateFunction. The rail's
    -- contract for a bad function body is warn-and-save, which A19 pins for
    -- a syntax error; this pins the same contract for a wrong TYPE.
    local ok, results = LI.Import(encode(envelope(
        2,
        nativeSinglePayload("_A23_ONE", {
            _A23_BADTYPE = { value = "1", funct = 5 },
        })
    )))
    assertTrue(ok == true, "import succeeded: " .. tostring(results))
    assertEqual(1, results.varsImported, "warn-and-save applies to a wrong-typed body too")
    assertEqual(1, #results.warnings, "one warning for the wrong-typed body")
    assertTrue(varStore._A23_BADTYPE ~= nil, "the variable is still stored")
    varStore._A23_BADTYPE = nil
    Engine:DeactivateSequence("_A23_ONE")
end)

test("A24: The COLLECTION branch drops a non-text variable name on its own guard", function()
    -- A22 covers the single-sequence tail only. Cowork measured that
    -- disabling the COLLECTION copy's guard leaves all 23 cases green,
    -- then drove this exact payload against the disabled guard and got
    -- ImportPreview.lua:559 "attempt to compare string with number".
    -- This case is what makes that guard visible to the suite.
    local preview = LI.Preview(
        encode(envelope(2, nativePayload({ "_A24_ONE" }, { _A24_STR = { value = "1" }, [5] = { value = "2" } })))
    )
    assertTrue(preview ~= nil and preview.ok, "preview ok: " .. tostring(preview and preview.error))
    assertEqual(1, preview.totalVariables, "only the text-named variable is listed")
    assertEqual("_A24_STR", preview.variables[1].name, "the surviving entry is the text-named one")
    assertTrue(#preview.warnings > 0, "the dropped variable is reported as a warning")
    Engine:DeactivateSequence("_A24_ONE")
end)

test("A25: A legacy payload with a table variable key warns instead of crashing", function()
    -- Before EDIT 1 this died at ImportPreview.lua:376 with
    -- "attempt to concatenate local 'varName' (a table value)". The value
    -- must be a STRING that fails to decode, because that is the only
    -- branch that reaches the concatenation.
    local preview = LI.Preview(
        encode(envelope(1, legacyPayloadWith("_A25_ONE", { Variables = { [{}] = "GARBAGE_NOT_DECODABLE" } })))
    )
    assertTrue(preview ~= nil and preview.ok, "preview ok: " .. tostring(preview and preview.error))
    assertEqual(0, preview.totalVariables, "nothing was listed")
    assertTrue(#preview.warnings > 0, "the undecodable variable is reported")
    Engine:DeactivateSequence("_A25_ONE")
end)

test("A26: A legacy payload with a table macro key warns instead of crashing", function()
    -- Before EDIT 2 this died at ImportPreview.lua:394, the macro twin
    -- of A25's crash.
    local preview =
        LI.Preview(encode(envelope(1, legacyPayloadWith("_A26_ONE", { Macros = { [{}] = "GARBAGE_NOT_DECODABLE" } }))))
    assertTrue(preview ~= nil and preview.ok, "preview ok: " .. tostring(preview and preview.error))
    assertEqual(0, preview.totalMacros or 0, "nothing was listed")
    assertTrue(#preview.warnings > 0, "the undecodable macro is reported")
    Engine:DeactivateSequence("_A26_ONE")
end)

test("A27: A legacy payload with a non-text variable name drops it with a warning", function()
    -- Measured before EDIT 3: listed as number(5) with ZERO warnings, and
    -- that name reaches ImportFrame.lua:544 SetText. No crash on this rail
    -- because the legacy walk never sorts result.variables -- which is
    -- exactly why the native fix did not cover it.
    local preview =
        LI.Preview(encode(envelope(1, legacyPayloadWith("_A27_ONE", { Variables = { [5] = { funct = "return 1" } } }))))
    assertTrue(preview ~= nil and preview.ok, "preview ok: " .. tostring(preview and preview.error))
    assertEqual(0, preview.totalVariables, "the non-text-named variable is not listed")
    assertTrue(#preview.warnings > 0, "the dropped variable is reported as a warning")
    Engine:DeactivateSequence("_A27_ONE")
end)

test("A28: A legacy payload with a non-text sequence name drops it with a warning", function()
    -- Measured before EDIT 4: listed as number(5) with ZERO warnings.
    local preview = LI.Preview(encode(envelope(
        1,
        legacyPayloadWith("_A28_ONE", {
            Sequences = {
                [5] = {
                    MacroVersions = {
                        [1] = {
                            StepFunction = "Sequential",
                            KeyPress = {},
                            KeyRelease = {},
                            Actions = { [1] = { Type = "Action", type = "macro", macro = "/cast Fireball" } },
                        },
                    },
                    MetaData = { Default = 1, Author = "MrSataana" },
                },
            },
        })
    )))
    assertTrue(preview ~= nil and preview.ok, "preview ok: " .. tostring(preview and preview.error))
    assertEqual(0, preview.totalSequences, "the non-text-named sequence is not listed")
    assertTrue(#preview.warnings > 0, "the dropped sequence is reported as a warning")
end)

test("A29: A non-text macro name is dropped while a well-formed one beside it lists", function()
    -- The second half is the point: it proves EDIT 6's GetMacroIndexByName
    -- stub actually made the macro walk reachable, so A26 and this case are
    -- testing the guard rather than sitting behind a harness error.
    local preview = LI.Preview(encode(envelope(
        1,
        legacyPayloadWith("_A29_ONE", {
            Macros = {
                _A29_GOOD = { name = "_A29_GOOD", text = "/cast Fireball" },
                [5] = { name = "bad", text = "/cast Frostbolt" },
            },
        })
    )))
    assertTrue(preview ~= nil and preview.ok, "preview ok: " .. tostring(preview and preview.error))
    assertEqual(1, preview.totalMacros, "only the text-named macro is listed")
    assertEqual("_A29_GOOD", preview.macros[1].name, "the surviving entry is the text-named one")
    assertTrue(#preview.warnings > 0, "the dropped macro is reported as a warning")
    Engine:DeactivateSequence("_A29_ONE")
end)

test("A30: The native COLLECTION sequences walk drops a non-text name", function()
    -- Measured against the pre-fix tree: this exact payload died at
    -- ImportPreview.lua:558 "attempt to compare string with number", the
    -- sequences twin of the crash A22 and A24 pin on the variables lists.
    -- It takes a MIX; all-numeric keys sort against each other fine.
    local payload = nativePayload({ "_A30_STR" })
    payload.sequences[5] = payload.sequences._A30_STR
    local preview = LI.Preview(encode(envelope(2, payload)))
    assertTrue(preview ~= nil and preview.ok, "preview ok: " .. tostring(preview and preview.error))
    assertEqual(1, preview.totalSequences, "only the text-named sequence is listed")
    assertEqual("_A30_STR", preview.sequences[1].name, "the surviving entry is the text-named one")
    assertTrue(#preview.warnings > 0, "the dropped sequence is reported as a warning")
    Engine:DeactivateSequence("_A30_STR")
end)

test("A31: A native single-sequence payload with a non-text name is refused", function()
    -- Measured before EDIT 2: ok=true, totalSequences=1, and the entry's
    -- name field was a TABLE, which reaches ImportFrame.lua:544 SetText.
    -- No crash in preview because a one-element table.sort never calls its
    -- comparator, which is exactly why no earlier pass caught it.
    local payload = nativeSinglePayload("_A31_ONE")
    payload.name = {}
    local preview = LI.Preview(encode(envelope(2, payload)))
    assertTrue(preview ~= nil, "a result table came back")
    assertEqual(false, preview.ok, "the payload is refused, not previewed")
    assertEqual("Payload has no sequence name", preview.error, "the existing error is reused")
end)

test("A32: Both failed-to-decode lines coerce boolean and number keys too", function()
    -- A25 and A26 pin the TABLE key only. Boolean was the other type that
    -- actually crashed pre-fix; number never did, because Lua coerces a
    -- number into a concatenation. Pinning both closes the half of each
    -- tostring fix that no case reached.
    local boolVars = LI.Preview(
        encode(envelope(1, legacyPayloadWith("_A32_ONE", { Variables = { [true] = "GARBAGE_NOT_DECODABLE" } })))
    )
    assertTrue(boolVars ~= nil and boolVars.ok, "bool var preview ok")
    assertEqual(0, boolVars.totalVariables, "nothing listed for the boolean key")
    assertTrue(#boolVars.warnings > 0, "the boolean-keyed variable is reported")
    Engine:DeactivateSequence("_A32_ONE")

    local numVars = LI.Preview(
        encode(envelope(1, legacyPayloadWith("_A32_TWO", { Variables = { [5] = "GARBAGE_NOT_DECODABLE" } })))
    )
    assertTrue(numVars ~= nil and numVars.ok, "number var preview ok")
    assertEqual(0, numVars.totalVariables, "nothing listed for the number key")
    assertTrue(#numVars.warnings > 0, "the number-keyed variable is reported")
    Engine:DeactivateSequence("_A32_TWO")

    local boolMacs = LI.Preview(
        encode(envelope(1, legacyPayloadWith("_A32_THREE", { Macros = { [true] = "GARBAGE_NOT_DECODABLE" } })))
    )
    assertTrue(boolMacs ~= nil and boolMacs.ok, "bool macro preview ok")
    assertEqual(0, boolMacs.totalMacros or 0, "nothing listed for the boolean macro key")
    assertTrue(#boolMacs.warnings > 0, "the boolean-keyed macro is reported")
    Engine:DeactivateSequence("_A32_THREE")
end)

test("A33: The commit rail's failed-to-decode lines coerce a non-text key", function()
    -- Measured pre-fix: LegacyImport.lua:340 "attempt to concatenate local
    -- 'varName' (a table value)", and :361 for macName. Both fire AFTER the
    -- sequence loop has committed, so the user was left with sequences
    -- imported, an error thrown and no results summary.
    local okVar, resVar = LI.Import(
        encode(envelope(1, legacyPayloadWith("_A33_ONE", { Variables = { [{}] = "GARBAGE_NOT_DECODABLE" } })))
    )
    assertTrue(okVar == true, "the variable-side import survived: " .. tostring(resVar))
    assertTrue(#resVar.warnings > 0, "the undecodable variable is reported")
    Engine:DeactivateSequence("_A33_ONE")

    local okMac, resMac =
        LI.Import(encode(envelope(1, legacyPayloadWith("_A33_TWO", { Macros = { [{}] = "GARBAGE_NOT_DECODABLE" } }))))
    assertTrue(okMac == true, "the macro-side import survived: " .. tostring(resMac))
    assertTrue(#resMac.warnings > 0, "the undecodable macro is reported")
    Engine:DeactivateSequence("_A33_TWO")
end)

test("A34: A non-text sequence name is refused rather than persisted", function()
    -- Measured pre-fix: the Engine ended up holding number(5) alongside the
    -- text-named sequence. That is a SavedVariables write, not a render
    -- glitch, which is what makes this rail worse than the preview one.
    local payload = legacyPayload("_A34_ONE")
    payload.payload.Sequences[5] = payload.payload.Sequences._A34_ONE
    local ok, results = LI.Import(encode(envelope(1, payload)))
    assertTrue(ok == true, "import survived: " .. tostring(results))
    assertTrue(Engine.sequences["_A34_ONE"] ~= nil, "the text-named sequence still lands")
    assertTrue(Engine.sequences[5] == nil, "the number-named sequence is NOT persisted")
    assertTrue(#results.warnings > 0, "the refusal is reported to the user")
    Engine:DeactivateSequence("_A34_ONE")
end)

test("A35: A non-text macro name counts as skipped, not imported", function()
    -- Measured pre-fix: ok=true, macrosImported=1, warnings=0. A macro named
    -- 5 was enqueued for real creation and the summary told the user one
    -- macro imported.
    local ok, results = LI.Import(
        encode(envelope(1, legacyPayloadWith("_A35_ONE", { Macros = { [5] = { text = "/cast Fireball" } } })))
    )
    assertTrue(ok == true, "import survived: " .. tostring(results))
    assertEqual(0, results.macrosImported or 0, "the non-text-named macro is not counted as imported")
    assertEqual(1, results.macrosSkipped or 0, "it is counted as skipped instead")
    Engine:DeactivateSequence("_A35_ONE")
end)

test("A36: A Variable action with a non-text Variable field does not crash", function()
    -- Measured pre-fix: LegacyImport.lua:1749 "attempt to concatenate local
    -- 'varName' (a table value)", and the same for a boolean. The guard three
    -- lines up tests varName == "", which a table passes. The Embed branch
    -- immediately above already wrote tostring; this branch did not.
    local function seqWithVarAction(variableField)
        return {
            MacroVersions = {
                [1] = {
                    StepFunction = "Sequential",
                    KeyPress = {},
                    KeyRelease = {},
                    Actions = { [1] = { Type = "Variable", Variable = variableField } },
                },
            },
            MetaData = { Default = 1, Author = "MrSataana" },
        }
    end

    local payload = legacyPayload("_A36_KEEP")
    payload.payload.Sequences = { _A36_ONE = seqWithVarAction({}) }
    local okTable = pcall(function()
        return LI.Import(encode(envelope(1, payload)))
    end)
    assertTrue(okTable == true, "a table Variable field does not raise a Lua error")
    Engine:DeactivateSequence("_A36_ONE")

    local payload2 = legacyPayload("_A36_KEEP2")
    payload2.payload.Sequences = { _A36_TWO = seqWithVarAction(true) }
    local okBool = pcall(function()
        return LI.Import(encode(envelope(1, payload2)))
    end)
    assertTrue(okBool == true, "a boolean Variable field does not raise a Lua error")
    Engine:DeactivateSequence("_A36_TWO")
end)

test("A37: The conditional compiler drops a non-text condition", function()
    -- Measured pre-fix: LegacyImport.lua:2151 "attempt to concatenate local
    -- 'condition' (a table value)", and the same for a boolean. A string
    -- condition compiled fine, so the crash is type-driven, not fixture
    -- noise. Reachable at :1658, which dispatches actionType == "If" with
    -- the decoded action, and recursively at :2122.
    local okTable, warnTable = LI.CompileConditional({
        Condition = {},
        Actions = { { Type = "Action", Spell = "Fireball" } },
        ElseActions = {},
    })
    assertTrue(type(okTable) == "table", "a table condition compiles to a step list")
    assertTrue(okTable[1] ~= nil and okTable[1]:find("Fireball", 1, true) ~= nil, "the spell survives")
    assertTrue(okTable[1]:find("table:", 1, true) == nil, "the condition is dropped, not stringified into the macro")
    assertTrue(warnTable ~= nil and #warnTable > 0, "the dropped condition is reported")

    local okBool = LI.CompileConditional({
        Condition = true,
        Actions = { { Type = "Action", Spell = "Fireball" } },
        ElseActions = {},
    })
    assertTrue(type(okBool) == "table", "a boolean condition compiles to a step list")

    local okStr = LI.CompileConditional({
        Condition = "combat",
        Actions = { { Type = "Action", Spell = "Fireball" } },
        ElseActions = {},
    })
    assertTrue(okStr[1]:find("[combat]", 1, true) ~= nil, "a well-formed condition still lands in the macro")
end)

-- Import/LegacyMigrate.lua is not in the harness TOC block, so it is loaded on
-- demand here. Its fallback walk reads the sibling addon's SavedVariables
-- global directly, which the sandbox does not stub; one table is enough to
-- reach the decode-failure branch.
local function loadLegacyMigrate()
    local loaded = loadRelative("Import/LegacyMigrate.lua")
    return loaded and GRIPEMS.LegacyMigrate or nil
end

test("A38: The migrate decode-failure warning coerces a non-text sequence key", function()
    -- LegacyMigrate.lua:212 bare-concatenated the loop key of the fallback
    -- walk. Phase 4 fixed :214 in the SAME loop over the SAME variable and
    -- left this one, because a line scan only matched concatenations
    -- sandwiched between two string literals.
    local LM = loadLegacyMigrate()
    assertTrue(LM ~= nil, "Import/LegacyMigrate.lua loaded into the sandbox")
    assertTrue(type(LM.MigrateAll) == "function", "MigrateAll defined")

    -- Scoped to this case: adding OOCQueue to the addon table for the whole
    -- run would make ImportMacro start enqueueing, which A35 and A29 do not
    -- expect. MigrateAll's first guard needs IsRestricted to answer false.
    local heldQueue = GRIPEMS.OOCQueue
    GRIPEMS.OOCQueue = {
        IsRestricted = function()
            return false
        end,
        Enqueue = function() end,
    }
    env.GSESequences = { [0] = { [{}] = "NOT_A_DECODABLE_STRING" } }
    local ok, err = pcall(function()
        return LM.MigrateAll(false, false)
    end)
    env.GSESequences = nil
    GRIPEMS.OOCQueue = heldQueue
    assertTrue(ok == true, "a non-text key in the fallback walk does not raise a Lua error: " .. tostring(err))
end)

test("A39: A conditional action with no condition warns that it fires unconditionally", function()
    -- Measured on the pre-pass tree: Condition = nil produced
    -- "/cast [] Fireball" with ZERO warnings. The macro conditional docs are
    -- explicit that "[], containing no conditionals, is always considered
    -- satisfied", so that cast is unconditional. Behaviour is unchanged
    -- here; the silence is what changed.
    local steps, warns = LI.CompileConditional({
        Actions = { { Type = "Action", Spell = "Fireball" } },
        ElseActions = {},
    })
    assertTrue(type(steps) == "table" and steps[1] ~= nil, "it still compiles to a step")
    assertTrue(steps[1]:find("Fireball", 1, true) ~= nil, "the spell survives")
    assertTrue(warns ~= nil and #warns > 0, "the missing condition is now reported")
    assertTrue(
        tostring(warns[1]):find("unconditionally", 1, true) ~= nil,
        "the warning names the consequence, not just the absence"
    )

    -- And the non-text case still reports the OTHER message, so the two
    -- branches are distinguishable to anyone reading the warnings.
    local _, warnsTable = LI.CompileConditional({
        Condition = {},
        Actions = { { Type = "Action", Spell = "Fireball" } },
        ElseActions = {},
    })
    assertTrue(warnsTable ~= nil and #warnsTable > 0, "the non-text case still warns")
    assertTrue(
        tostring(warnsTable[1]):find("dropped", 1, true) ~= nil,
        "the non-text warning is distinct from the nil warning"
    )
end)

test("A40: An If action with a non-text Variable field is coerced on the node", function()
    -- A36 covers Type = "Variable", which reaches a different branch that
    -- has been guarded since an earlier pass. This is Type = "If", whose
    -- variable field was stored raw and concatenated bare by the export
    -- text builder in GRIPExport. "or" only rescues nil and false, so a
    -- table and a boolean true both got through.
    local tree = LI.MapLegacyActionsToTree({
        { Type = "If", Variable = {}, Actions = { { Type = "Action", Spell = "Fireball" } } },
    })
    assertTrue(type(tree) == "table" and tree[1] ~= nil, "the If action still maps to a node")
    assertEqual("string", type(tree[1].variable), "a table Variable field is stored as text")

    local boolTree = LI.MapLegacyActionsToTree({
        { Type = "If", Variable = true, Actions = { { Type = "Action", Spell = "Fireball" } } },
    })
    assertEqual("string", type(boolTree[1].variable), "a boolean Variable field is stored as text")

    -- Condition is the second arm of the same "or" chain and reaches the
    -- same assignment when Variable is absent.
    local condTree = LI.MapLegacyActionsToTree({
        { Type = "If", Condition = {}, Actions = { { Type = "Action", Spell = "Fireball" } } },
    })
    assertEqual("string", type(condTree[1].variable), "a table Condition field is stored as text")

    -- The well-formed case is unchanged: tostring is identity on a string.
    local okTree = LI.MapLegacyActionsToTree({
        { Type = "If", Variable = "_A40_VAR", Actions = { { Type = "Action", Spell = "Fireball" } } },
    })
    assertEqual("_A40_VAR", okTree[1].variable, "a text Variable field passes through unchanged")
end)

test("A41: A non-text unit field falls back to the untargeted macro", function()
    -- The guard was "if action.unit and action.unit ~= ''", a truthiness test.
    -- Every table and boolean true clears both halves and then fails the
    -- concatenation one line below, raising out of the import itself -- there
    -- is no pcall on this path. Twelve sites share the shape; this covers the
    -- spell head at :1103 and the item sibling at :1113 so a one-site revert
    -- cannot pass.
    local function macroOf(action)
        local tree = LI.MapLegacyActionsToTree({ action })
        return tree and tree[1] and tree[1].macro
    end

    assertEqual("/cast Fireball", macroOf({ Type = "Action", type = "spell", Spell = "Fireball", unit = {} }))
    assertEqual("/cast Fireball", macroOf({ Type = "Action", type = "spell", Spell = "Fireball", unit = true }))
    assertEqual("/use Healthstone", macroOf({ Type = "Action", type = "item", Spell = "Healthstone", unit = {} }))
    assertEqual("/use Healthstone", macroOf({ Type = "Action", type = "item", Spell = "Healthstone", unit = true }))

    -- Well-formed input is untouched, on both paths.
    assertEqual(
        "/cast [@focus] Fireball",
        macroOf({ Type = "Action", type = "spell", Spell = "Fireball", unit = "focus" }),
        "a text unit still targets"
    )
    assertEqual(
        "/use [@focus] Healthstone",
        macroOf({ Type = "Action", type = "item", Spell = "Healthstone", unit = "focus" }),
        "a text unit still targets on the item path"
    )
    -- A NUMBER stays accepted: Lua concatenates it and "/cast [@42]" is what
    -- the payload asked for. Narrowing to string only would be a behaviour
    -- change, not a hardening fix.
    assertEqual(
        "/cast [@42] Fireball",
        macroOf({ Type = "Action", type = "spell", Spell = "Fireball", unit = 42 }),
        "a numeric unit is still accepted"
    )
end)

test("A42: A non-text macro field is dropped instead of erroring in the resolver", function()
    -- Not a concatenation at all: LI.ResolveSpellIDsInMacrotext calls
    -- text:gmatch on a payload field, so it raises before any concat is
    -- reached. Neither the arc's bare-identifier scan nor its generalisation
    -- to concat operands could have found this shape.
    local function macroTypeOf(macroField)
        local tree = LI.MapLegacyActionsToTree({ { Type = "Action", type = "macro", macro = macroField } })
        return tree and tree[1] and type(tree[1].macro) or "<no node>"
    end

    assertEqual("string", macroTypeOf({}), "a table macro field yields a text macro")
    assertEqual("string", macroTypeOf(true), "a boolean macro field yields a text macro")

    -- The resolver's own contract is unchanged for well-formed input.
    assertEqual("/cast Fireball", LI.ResolveSpellIDsInMacrotext("/cast Fireball"), "text passes through")
    assertEqual("", LI.ResolveSpellIDsInMacrotext(""), "empty string still returns empty")
    assertEqual(nil, LI.ResolveSpellIDsInMacrotext(nil), "nil still returns nil")
end)

test("A43: CompileMacroVersion tolerates every KeyPress block shape", function()
    -- The old code was "if macroVersion.KeyPress and #... > 0 then
    -- table.concat(...)": a truthiness guard, then a length operator, then
    -- table.concat -- three assumptions and no type check. A plain STRING is
    -- the realistic bad shape, not a table: a hand-written or older-format
    -- payload carries the block as one string, and that took the import down
    -- with "bad argument #1 to 'concat'".
    local function keyPressOf(kp)
        local res = LI.CompileMacroVersion({
            StepFunction = "Sequential",
            KeyPress = kp,
            KeyRelease = {},
            Actions = { { Type = "Action", type = "macro", macro = "/cast Fireball" } },
        })
        return res and res.keyPress
    end

    -- A string block is ACCEPTED, not dropped: it carries real user content.
    assertEqual("/cast Alpha", keyPressOf("/cast Alpha"), "a string KeyPress becomes the block text")
    -- A number or boolean carries nothing usable.
    assertEqual("", keyPressOf(42), "a number KeyPress yields no block")
    assertEqual("", keyPressOf(true), "a boolean KeyPress yields no block")
    -- One bad entry must not lose the good ones.
    assertEqual(
        "/cast Alpha\n/cast Beta",
        keyPressOf({ "/cast Alpha", {}, "/cast Beta" }),
        "non-string entries are skipped, the rest survive"
    )
    -- Well-formed input is unchanged.
    assertEqual("/cast Alpha", keyPressOf({ "/cast Alpha" }), "a well-formed array is unchanged")
    assertEqual("/cast Alpha\n/cast Beta", keyPressOf({ "/cast Alpha", "/cast Beta" }), "multi-line unchanged")
    assertEqual("", keyPressOf(nil), "an absent KeyPress still yields no block")
end)

test("A44: MapLegacyVariable skips non-text eventNames entries", function()
    -- The array was type-checked, its ELEMENTS were not, so table.concat
    -- raised on the first non-string and aborted the whole variable import.
    -- The mixed row is the sharp one: one bad element used to lose the good
    -- element with it.
    local function eventsOf(eventNames)
        local res = LI.MapLegacyVariable("_A44_VAR", { eventNames = eventNames, funct = "return 1" })
        return res and res.events
    end

    assertEqual("A, B", eventsOf({ "A", "B" }), "a well-formed array is unchanged")
    assertEqual("", eventsOf({ {} }), "a table element is skipped")
    assertEqual("", eventsOf({ true }), "a boolean element is skipped")
    assertEqual("A", eventsOf({ "A", {} }), "a mixed array keeps the good entry")
    assertEqual("", eventsOf("A"), "a string eventNames still yields empty")
    assertEqual("", eventsOf(nil), "an absent eventNames still yields empty")
end)

test("A45: a malformed steps field warns, and chain fields survive the ipairs walks", function()
    -- Pass 10 made a non-table steps field yield stepCount 0 instead of
    -- raising. 0 is the right count, but a well-formed-looking zero hides the
    -- fact that the payload was malformed, so the preview now says so.
    local function previewSingle(sequence)
        local payload = nativeSinglePayload("_A45_ONE")
        payload.sequence = sequence
        return LI.Preview(encode(envelope(2, payload)))
    end

    local bad = previewSingle({ steps = 42, defaultVersion = 1 })
    assertTrue(bad ~= nil and bad.ok, "a malformed steps field still previews: " .. tostring(bad and bad.error))
    assertEqual(0, bad.sequences[1].stepCount, "the count is zero, which is correct")
    assertTrue(#bad.warnings > 0, "the malformed steps field is reported as a warning")
    assertTrue(
        tostring(bad.warnings[1]):find("malformed", 1, true) ~= nil,
        "the warning names the field as malformed rather than merely empty"
    )

    -- A well-formed payload gains no such warning.
    local good = previewSingle({ versions = { { steps = { "/cast Fireball" } } }, defaultVersion = 1 })
    assertTrue(good ~= nil and good.ok, "the control previews ok")
    assertEqual(1, good.sequences[1].stepCount, "the control still counts its step")
    for _, w in ipairs(good.warnings) do
        assertTrue(tostring(w):find("malformed", 1, true) == nil, "no malformed warning on a clean payload")
    end

    -- ipairs raises on a STRING too, unlike the length operator, so all three
    -- non-table shapes are live for the chain walks.
    for _, shape in ipairs({ 42, true, "text" }) do
        local p = previewSingle({
            versions = { { steps = { "/cast Fireball" } } },
            defaultVersion = 1,
            modifierChain = shape,
            forkedFromChain = shape,
        })
        assertTrue(p ~= nil and p.ok, "chain shape " .. type(shape) .. " previews: " .. tostring(p and p.error))
    end

    -- LI.ProcessSequence is the LEGACY rail's own copy of the same two ipairs
    -- walks. It is a different function in a different file from the preview
    -- walks above, so it needs its own coverage or its guard is unpinned.
    for _, shape in ipairs({ 42, true, "text" }) do
        local results = { names = {}, warnings = {}, count = 0, stepCounts = {} }
        local ok, err = pcall(LI.ProcessSequence, "_A45_PS", {
            MacroVersions = {
                {
                    StepFunction = "Sequential",
                    KeyPress = {},
                    KeyRelease = {},
                    Actions = { { Type = "Action", type = "macro", macro = "/cast Fireball" } },
                },
            },
            MetaData = { Default = 1, Author = "MrSataana" },
            -- The chain walks sit behind "elseif sequence.originalAuthor and
            -- sequence.originalAuthor ~= ''", so without a non-empty
            -- originalAuthor the whole provenance block is skipped and the
            -- fixture never reaches the guard it is meant to pin.
            originalAuthor = "Someone",
            modifierChain = shape,
            forkedFromChain = shape,
        }, results, {})
        assertTrue(ok, "ProcessSequence raised on chain shape " .. type(shape) .. ": " .. tostring(err))
        Engine:DeactivateSequence("_A45_PS")
    end
end)

test("A46: the commit step count guards ver.steps, not just ver", function()
    -- ImportPreview:1288 read "ver and #ver.steps": it guarded ver but NOT
    -- ver.steps, unlike :1245 and :1297 which guard both. Measured before the
    -- fix: an ABSENT steps field raised "attempt to get length of field
    -- 'steps' (a nil value)" -- a live defect independent of shape corruption
    -- -- and a STRING steps field did not raise at all, fabricating a count of
    -- 4 from the characters in "text".
    local function stepCountOf(sequence)
        local entry = { name = "_A46_ONE", seqObj = { sequence = sequence } }
        local preview = { ok = true, format = "GRIP1", sequences = { entry }, variables = {} }
        local sel = { sequences = { { selected = true, action = "import" } }, variables = {} }
        local ok, commitOk, res = pcall(LI.CommitSelected, preview, sel)
        assertTrue(ok, "CommitSelected raised: " .. tostring(commitOk))
        assertTrue(commitOk, "CommitSelected refused: " .. tostring(res))
        Engine:DeactivateSequence("_A46_ONE")
        return res.stepCounts["_A46_ONE"]
    end

    assertEqual(0, stepCountOf({ versions = { { stepFunction = "Sequential" } }, defaultVersion = 1 }))
    assertEqual(0, stepCountOf({ versions = { { steps = 42 } }, defaultVersion = 1 }))
    assertEqual(0, stepCountOf({ versions = { { steps = true } }, defaultVersion = 1 }))
    -- The string case is the one a crash-only sweep misses entirely.
    assertEqual(0, stepCountOf({ versions = { { steps = "text" } }, defaultVersion = 1 }), "no fabricated count")

    -- Control, asserted on a non-zero observable so it can fail.
    assertEqual(
        1,
        stepCountOf({ versions = { { steps = { "/cast Fireball" } } }, defaultVersion = 1 }),
        "a well-formed single step still counts as one"
    )
    assertEqual(0, stepCountOf({ versions = { { steps = {} } }, defaultVersion = 1 }), "an empty array counts zero")
end)

test("A47: the action-tree entry points absorb a scalar instead of raising", function()
    -- THE ARC'S FIRST BEHAVIOURALLY PROVEN GUARD. Every hardening pass before
    -- this one was source-only: the scan proved the SHAPE was gone from the
    -- text, not that the function survived the input. Both entry points are
    -- reachable from this file with no stubbing, so both are exercised for
    -- real.
    --
    -- The two hazards are different and neither is covered by the other:
    --   * MapLegacyActionsToTree took "not legacyActions or #legacyActions",
    --     and the call site passes "macroVersion.Actions or {}" off a decoded
    --     payload. "or" substitutes for nil and false ONLY, so a number or a
    --     boolean true went straight to the "#", which raises on both.
    --   * _MapActionToNode's inner mapper took "not action or not
    --     action.Type". Callers that shape-test only the CONTAINER still hand
    --     the ELEMENT in, so Actions = { 5 } arrived here as a number and the
    --     guard line itself raised on "action.Type".
    --
    -- The two unchanged-behaviour rows are deliberate. Without them this case
    -- cannot tell "the guard works" from "the function returns nil for
    -- everything", which is the failure mode a nil-only assertion invites.
    local function treeOf(input)
        local ok, res = pcall(LI.MapLegacyActionsToTree, input)
        assertTrue(ok, "MapLegacyActionsToTree raised: " .. tostring(res))
        return res
    end

    for _, scalar in ipairs({ 5, true }) do
        local tree = treeOf(scalar)
        assertEqual("table", type(tree), "a scalar Actions field still yields a table: " .. tostring(scalar))
        assertEqual(0, #tree, "a scalar Actions field yields an EMPTY tree: " .. tostring(scalar))
    end

    -- Unchanged behaviour, pinned: nil was already absorbed by the old "not"
    -- guard and must keep behaving exactly as an empty array does.
    local nilTree = treeOf(nil)
    assertEqual("table", type(nilTree), "nil still yields a table")
    assertEqual(0, #nilTree, "nil still yields an empty tree")

    local function nodeOf(input)
        local ok, res = pcall(LI._MapActionToNode, input)
        assertTrue(ok, "_MapActionToNode raised: " .. tostring(res))
        return res
    end

    assertEqual(nil, nodeOf(5), "a number element maps to no node")
    assertEqual(nil, nodeOf(true), "a boolean element maps to no node")
    -- Unchanged behaviour, pinned: a well-formed Comment action has always
    -- mapped to nil, and it proves the nil above is a verdict and not a
    -- blanket.
    assertEqual(nil, nodeOf({ Type = "Comment" }), "a Comment action still maps to no node")

    -- Control on a non-zero observable, so this case can fail: a well-formed
    -- action still builds a node, through both entry points.
    local okTree = treeOf({ { Type = "Action", type = "spell", Spell = "Fireball" } })
    assertEqual(1, #okTree, "a well-formed action still maps to one node")
    assertEqual("/cast Fireball", okTree[1].macro, "and the node still carries its macro")
    local okNode = nodeOf({ Type = "Action", type = "spell", Spell = "Fireball" })
    assertTrue(okNode ~= nil, "_MapActionToNode still maps a well-formed action")
    assertEqual("/cast Fireball", okNode.macro, "and that node carries its macro too")
end)

test("A48: the element-level scalar sites absorb, on both walks, not just the entry points", function()
    -- WHAT A47 COULD NOT REACH. A47 proved the two ENTRY POINTS absorb a
    -- scalar: the Actions CONTAINER handed to MapLegacyActionsToTree, and an
    -- element handed straight into _MapActionToNode. Six live raise sites
    -- survived that pass, and not one of them is visible to the census that has
    -- driven this whole arc -- every one is a bare LOCAL bound out of a censused
    -- field, so the raising line carries no field name at all and no field-keyed
    -- pattern can match it. That is a structural blind spot, not a tuning
    -- problem, and no tenth pattern would close it. This case is the
    -- behavioural answer to a scan that cannot look here.
    --
    -- THE SHAPE THAT TAUGHT THE MOST is a STRING Actions field. "#" does NOT
    -- raise on a string, so a string used to survive the length operator in
    -- CompileMacroVersion, report a length of 2 for "xy", and then die one level
    -- down when the loop body indexed it and got nil. Absorbed one level up,
    -- lethal one level down -- the reason a container guard is not an element
    -- guard, demonstrated by a single input.
    --
    -- MEASURED RED, PER ROW, at HEAD fa88d31. Each guard was reverted on its
    -- own, this case was run, the raise was recorded, and the guard restored:
    --   MapLegacyActionsToTree({ 5 })
    --     LegacyImport.lua:1048: attempt to index local 'action' (a number value)
    --   MapLegacyActionsToTree({ true })
    --     LegacyImport.lua:1048: attempt to index local 'action' (a boolean value)
    --   CompileMacroVersion{ Actions = 5 }
    --     LegacyImport.lua:1495: attempt to get length of local 'actions' (a number value)
    --   CompileMacroVersion{ Actions = true }
    --     LegacyImport.lua:1495: attempt to get length of local 'actions' (a boolean value)
    --   CompileMacroVersion{ Actions = { 5 } }
    --     LegacyImport.lua:1500: attempt to index local 'action' (a number value)
    --   CompileMacroVersion{ Actions = "xy" }
    --     LegacyImport.lua:1500: attempt to index local 'action' (a NIL value)
    --   CompileAction(5)
    --     LegacyImport.lua:1587: attempt to index local 'action' (a number value)
    --   CompileAction(true)
    --     LegacyImport.lua:1587: attempt to index local 'action' (a boolean value)
    --   CompileAction{ Type = "Loop", Actions = { 5 } }
    --     LegacyImport.lua:1781: attempt to index local 'subAction' (a number value)
    --   CompileAction{ Type = "Loop", [1] = 5 }
    --     LegacyImport.lua:1781: attempt to index local 'subAction' (a number value)
    --
    -- READ THE STRING ROW AGAIN -- it is the only one that names a NIL value
    -- rather than the type that was actually passed in. The string never
    -- reached line 1500 as a string: it cleared the container test, cleared
    -- "#" with a length of 2, and then actions[1] on a string returned nil, so
    -- the loop dereferenced nil. That is why "attempt to index a nil value"
    -- appears for an input that contains no nil anywhere.
    --
    -- The two Loop rows raise at the SAME line from two different fill paths,
    -- which is the measurement behind putting one guard on the shared loop
    -- rather than one in each branch.
    --
    -- The unchanged-behaviour rows and the four non-zero controls below are
    -- what stop this case passing by returning nothing for everything. The last
    -- control is the important one: a mixed array must still compile its GOOD
    -- neighbour AND still tell the user the other slot was malformed, which is
    -- the whole argument for substituting an empty table instead of skipping.
    local GOOD = { Type = "Action", type = "spell", Spell = "Fireball" }

    local function treeOf(input)
        local ok, res = pcall(LI.MapLegacyActionsToTree, input)
        assertTrue(ok, "MapLegacyActionsToTree raised: " .. tostring(res))
        return res
    end

    local function versionOf(actionsField)
        local ok, res = pcall(LI.CompileMacroVersion, { Actions = actionsField })
        assertTrue(ok, "CompileMacroVersion raised: " .. tostring(res))
        return res
    end

    local function compiledOf(action)
        local ok, res, warns = pcall(LI.CompileAction, action)
        assertTrue(ok, "CompileAction raised: " .. tostring(res))
        return res, warns
    end

    -- SITE A -- the top-level tree walk dereferences the element before the
    -- wrapper is called, so the 15q callee guard never got a turn here.
    for _, scalar in ipairs({ 5, true }) do
        local tree = treeOf({ scalar })
        assertEqual("table", type(tree), "a scalar ELEMENT still yields a table: " .. tostring(scalar))
        assertEqual(0, #tree, "a scalar ELEMENT yields an EMPTY tree: " .. tostring(scalar))
    end
    -- Unchanged behaviour, pinned: a string element was ALREADY absorbed before
    -- this pass, because indexing a string is legal and .Type simply reads nil.
    -- It must keep behaving exactly as the number and boolean now do.
    local strTree = treeOf({ "x" })
    assertEqual("table", type(strTree), "a string element still yields a table")
    assertEqual(0, #strTree, "a string element still yields an empty tree")

    -- SITE B and SITE C -- the flat compiler's own container test, and the
    -- element bound out of it. Every scalar container takes the pre-existing
    -- early return; a scalar ELEMENT is substituted and reported.
    for _, bad in ipairs({ 5, true, "xy" }) do
        local res = versionOf(bad)
        assertEqual("table", type(res.steps), "a scalar Actions field still returns a steps table: " .. tostring(bad))
        assertEqual(0, #res.steps, "a scalar Actions field compiles zero steps: " .. tostring(bad))
        assertEqual(1, #res.warnings, "and says so once: " .. tostring(bad))
    end
    local elemRes = versionOf({ 5 })
    assertEqual(0, #elemRes.steps, "a scalar ELEMENT in a real array compiles zero steps")
    assertEqual(1, #elemRes.warnings, "and is reported rather than swallowed")

    -- Unchanged behaviour, pinned: an EMPTY Actions array is a table, so it goes
    -- down the real compile path and NOT the early return. The zero-warning
    -- assertion is what distinguishes the two, so this row cannot be satisfied
    -- by the scalar branch above.
    local emptyRes = versionOf({})
    assertEqual(0, #emptyRes.steps, "an empty Actions array still compiles zero steps")
    assertEqual(0, #emptyRes.warnings, "and takes the real path, not the no-actions early return")

    -- SITE D -- the flat action compiler's own head guard.
    for _, scalar in ipairs({ 5, true }) do
        local res, warns = compiledOf(scalar)
        assertEqual(0, #res, "a scalar action compiles to no steps: " .. tostring(scalar))
        assertTrue(warns ~= nil and #warns == 1, "and carries one warning: " .. tostring(scalar))
        assertEqual("Action with no Type skipped", warns[1], "the existing no-Type verdict: " .. tostring(scalar))
    end
    -- Unchanged behaviour, pinned: a string action was already absorbed by the
    -- old truthiness guard and must land on the SAME verdict, not a new one.
    local strRes, strWarns = compiledOf("x")
    assertEqual(0, #strRes, "a string action still compiles to no steps")
    assertEqual("Action with no Type skipped", strWarns and strWarns[1], "and still gets the no-Type verdict")

    -- SITE E -- both sub-action fill paths converge on one loop, so both are
    -- driven here: the Actions array branch and the numbered-key walk.
    local loopArr = compiledOf({ Type = "Loop", Actions = { 5 } })
    assertEqual(0, #loopArr, "a scalar loop child from the Actions array compiles to no steps")
    local loopNum = compiledOf({ Type = "Loop", [1] = 5 })
    assertEqual(0, #loopNum, "a scalar loop child from a numbered key compiles to no steps")

    -- Controls on non-zero observables, all four measured identical before and
    -- after this fix set, which is the point of including them.
    local goodVer = versionOf({ GOOD })
    assertEqual(1, #goodVer.steps, "a well-formed action still compiles to one step")
    assertEqual("/cast Fireball", goodVer.steps[1], "and that step is still the cast")

    local goodAct = compiledOf(GOOD)
    assertEqual(1, #goodAct, "CompileAction still returns one entry for a well-formed action")
    assertEqual("/cast Fireball", goodAct[1], "and that entry is still the cast")

    local goodLoop = compiledOf({ Type = "Loop", Actions = { GOOD } })
    assertEqual(1, #goodLoop, "a well-formed loop child still compiles to one step")
    assertEqual("/cast Fireball", goodLoop[1], "and that step is still the cast")

    -- THE EDIT 3 CONTROL. Substituting an empty table for the bad element keeps
    -- the good neighbour compiling while still reporting the bad slot; skipping
    -- the element instead would have moved the edge-in-place arithmetic that
    -- reads actionIdx against the action count.
    local mixed = versionOf({ 5, GOOD })
    assertEqual(1, #mixed.steps, "the good neighbour still compiles in a mixed array")
    assertEqual("/cast Fireball", mixed.steps[1], "and it is still the cast")
    assertEqual(1, #mixed.warnings, "while the malformed slot is reported exactly once")
end)

test("A49: the CompileMacroVersion head absorbs a scalar, and substitute-not-drop is proved", function()
    -- TWO CLAIMS, ONE CASE, and they are here together because both are about
    -- the SAME function and both were left unmeasured by the previous pass.
    --
    -- ======================= CLAIM ONE: SITE G ==========================
    --
    -- LI.CompileMacroVersion used to open with "if not macroVersion then". That
    -- absorbed nil and false and let every other shape through to the first
    -- dereference roughly a dozen lines below, at type(macroVersion.KeyPress).
    --
    -- MEASURED RED by reverting the guard to its old "if not macroVersion then"
    -- form, running this case, recording the raise and restoring. Quoted from
    -- the runs, not from a plan -- one run per row, because the runner aborts a
    -- case at its first failed assertion and the two rows were swapped between
    -- runs to observe each on its own:
    --   FAIL  A49: ... -- Test/test_frg1_v2_reader.lua:1969:
    --     CompileMacroVersion(number) raised: Import/LegacyImport.lua:1503:
    --     attempt to index local 'macroVersion' (a number value)
    --   FAIL  A49: ... -- Test/test_frg1_v2_reader.lua:1969:
    --     CompileMacroVersion(boolean) raised: Import/LegacyImport.lua:1503:
    --     attempt to index local 'macroVersion' (a boolean value)
    -- RESULT 48 passed, 1 failed, on both runs.
    --
    -- ON THOSE TWO NUMBERS, AND ON THE TWO THEY REPLACE. :1969 is the
    -- assertTrue at the head of the SITE G loop; :1503 is the first
    -- dereference, type(macroVersion.KeyPress). Both were re-measured at
    -- 914109d by reverting the guard to "if not macroVersion then" in place,
    -- a two-line swap that shifts no line numbers, and reading the runner's
    -- own output.
    --
    -- The numbers this replaces were :1945 and :1493, and they were wrong in
    -- a way worth recording rather than quietly correcting. :1945 is a
    -- comment line inside this very case; :1493 is the "end" of the guard.
    -- They came from arithmetic: 1456, the raise the 15s prompt measured on
    -- a clean dc172f1 tree, plus 37 for "the comment this pass added above
    -- the guard". The comment 15s added is 47 lines, not 37, and 1456 + 47
    -- is 1503, which is what the run prints. A derived number wearing the
    -- costume of an observed one is harder to catch than an obviously
    -- missing one, because the paragraph around it argues for its own
    -- accuracy. If a line number in this file was not copied out of a
    -- runner's output, it does not belong in a block labelled MEASURED.
    --
    -- WHY THE GUARD IS AT THE CALLEE HEAD HERE AND WAS NOT AT SITE A. There are
    -- exactly three PRODUCTION call sites, all reachable, all handing over a value
    -- that came off a decoded payload, and NONE of them reads a field off the
    -- value before calling:
    --   LegacyImport.lua:576   for i, macroVersion in ipairs(macros) do, and
    --                          :580 passes the element straight in, off a
    --                          decoded payload with no shape test upstream.
    --   ImportPreview.lua:766  "if defaultMacro then" is a truthiness gate only,
    --                          and :771 passes the value straight in.
    --   ImportFrame.lua:640    bounds-checks the INDEX only, then :643 passes
    --                          macros[defaultIdx] inline.
    -- Because the callee owns the first dereference on all three paths, ONE test
    -- at the callee head covers all three, and this case can drive the callee
    -- directly and still be evidence about the callers.
    --
    -- A FOURTH CALLER EXISTS AND IS ALSO SHIPPED, and it is named here rather than
    -- omitted: Test/TestSuite.lua is listed in GRIP-EMS.toc:160 and therefore
    -- loads in game. Its thirteen call sites all hand over a LITERAL table
    -- constructor written into the call expression, so nothing payload-derived
    -- reaches the function from there. The guard covers them trivially and they
    -- are evidence for nothing, which is exactly why the three above are counted
    -- separately from them.
    --
    -- That is the OPPOSITE verdict from SITE A in A48, and the reason is the
    -- CALLER, not the callee: there the caller read action.Type one statement
    -- before the call, so the element had already raised by the time control
    -- reached the callee and a callee-head guard was unreachable. Same lesson --
    -- put the guard wherever the FIRST dereference lives -- opposite placement.
    --
    -- The nil and string rows are pinned as UNCHANGED behaviour. Both were
    -- already absorbed before this pass: nil by the old truthiness test, and a
    -- string by accident, because indexing a string is legal through its
    -- metatable so macroVersion.KeyPress simply read nil and the function ran on
    -- to its no-actions return. They must keep behaving as they did, which is
    -- what stops this case passing by way of a guard that swallows everything.
    --
    -- ============ CLAIM TWO: SUBSTITUTE, NOT DROP -- A PROOF ============
    --
    -- A48's last control ends with a comment asserting that substituting an
    -- empty table for a malformed element "preserves the edge-in-place
    -- arithmetic" where dropping it would not. 15r labelled that source review
    -- only. It is not: it is one PAIR OF ROWS, and the pair is measurable with
    -- shipped code.
    --
    -- MEASURED at dc172f1, with GOOD and REPEAT as defined below:
    --   Actions = { REPEAT, GOOD }        steps 2, "/cast Frostbolt" then
    --                                     "/cast Fireball", warnings 0
    --   Actions = { 5, REPEAT, GOOD }     steps 1, "/cast Fireball", warnings 2
    --   Actions = { GOOD, REPEAT, GOOD }  steps 2, "/cast Fireball" twice,
    --                                     warnings 1
    --   Actions = { 5, REPEAT }           steps 1, "/cast Frostbolt", warnings 1
    --
    -- READ THE FIRST TWO ROWS TOGETHER. That is what makes them a proof rather
    -- than two observations. If the malformed element were DROPPED instead of
    -- substituted, { 5, REPEAT, GOOD } would compact to { REPEAT, GOOD }: the
    -- Repeat would land at index 1 of 2, the edge-in-place test would fire, and
    -- the result would be row one EXACTLY -- 2 steps, Frostbolt present, ZERO
    -- warnings. Under substitution the Repeat sits at index 2 of 3, is not an
    -- edge, is routed to the interleave path instead, and the result is row two.
    -- So the two implementations are distinguishable by output, and row one is
    -- the oracle for what the wrong one would have printed.
    --
    -- THE WARNING COUNT LEADS, 2 versus 0, because it is the
    -- harness-independent half of the difference. The step-count half also
    -- depends on ActionCompiler.ApplyInterleaving being absent in this harness:
    -- the interleave path degrades to a single step here where in-game it would
    -- weave. Asserting the warning count first means a harness that later gains
    -- a real ApplyInterleaving cannot silently turn this proof into a
    -- coincidence.
    --
    -- AND THE PAIR IS NOW MEASURED, NOT ONLY ARGUED. The paragraph above is
    -- a correct argument and it was the whole of the evidence until 914109d,
    -- when the wrong implementation was actually built and run. A drop was
    -- simulated by compacting the Actions array ahead of the flat loop --
    -- every non-table element removed rather than replaced by an empty table
    -- -- and the suite was re-run:
    --   FAIL  A49 ... -- Test/test_frg1_v2_reader.lua:1995: a malformed slot
    --     ahead of the Repeat warns twice, not zero: expected 2, got 0
    --   FAIL  A48 ... -- Test/test_frg1_v2_reader.lua:1795: and is reported
    --     rather than swallowed: expected 1, got 0
    --   RESULT 47 passed, 2 failed.
    -- Row two collapsed onto row one's output under the drop, which is what
    -- the argument said would happen. A48 reddening alongside it is the part
    -- the argument did not predict: A48's substitution claim is load-bearing
    -- against a drop implementation too, and 15r labelled that one source
    -- review as well.
    --
    -- WHY THIS IS WORTH THE SIX LINES. "Row one is the oracle for what the
    -- wrong implementation would have printed" is a claim about a program
    -- that does not exist. Building it costs one loop and one run, and it
    -- converts the case from a reader having to follow the reasoning into a
    -- reader being able to reproduce the number. A reason for believing
    -- something is a claim, and it gets measured like any other.
    local GOOD = { Type = "Action", type = "spell", Spell = "Fireball" }
    local REPEAT = { Type = "Repeat", Spell = "Frostbolt" }

    local function versionOf(actionsField)
        local ok, res = pcall(LI.CompileMacroVersion, { Actions = actionsField })
        assertTrue(ok, "CompileMacroVersion raised: " .. tostring(res))
        return res
    end

    local function stepsHave(res, needle)
        for _, step in ipairs(res.steps or {}) do
            if type(step) == "string" and step:find(needle, 1, true) then
                return true
            end
        end
        return false
    end

    -- ---- SITE G: the two shapes that raised -------------------------------
    for _, row in ipairs({ { label = "number", value = 5 }, { label = "boolean", value = true } }) do
        local ok, res = pcall(LI.CompileMacroVersion, row.value)
        assertTrue(ok, "CompileMacroVersion(" .. row.label .. ") raised: " .. tostring(res))
        assertEqual("table", type(res), "a scalar macroVersion still returns a table: " .. row.label)
        assertEqual("table", type(res.steps), "and a steps table: " .. row.label)
        assertEqual(0, #res.steps, "and compiles zero steps: " .. row.label)
        assertEqual(1, #res.warnings, "and says so exactly once: " .. row.label)
    end

    -- ---- SITE G: the two shapes that were ALREADY absorbed ----------------
    local nilOk, nilRes = pcall(LI.CompileMacroVersion, nil)
    assertTrue(nilOk, "CompileMacroVersion(nil) raised: " .. tostring(nilRes))
    assertEqual("table", type(nilRes.steps), "nil still returns a steps table")
    assertEqual(0, #nilRes.steps, "nil still compiles zero steps")
    assertEqual(1, #nilRes.warnings, "nil still carries exactly one warning")

    local strOk, strRes = pcall(LI.CompileMacroVersion, "x")
    assertTrue(strOk, "CompileMacroVersion(string) raised: " .. tostring(strRes))
    assertEqual("table", type(strRes.steps), "a string macroVersion still returns a steps table")
    assertEqual(0, #strRes.steps, "a string macroVersion still compiles zero steps")

    -- ---- SUBSTITUTE-NOT-DROP: the discriminating pair ---------------------
    -- Warning count first, for the harness reason above.
    local keptEdge = versionOf({ REPEAT, GOOD })
    assertEqual(0, #keptEdge.warnings, "a clean { REPEAT, GOOD } array warns not at all")
    assertTrue(stepsHave(keptEdge, "/cast Frostbolt"), "the edge-in-place Repeat emitted its cast")

    local movedOff = versionOf({ 5, REPEAT, GOOD })
    assertEqual(2, #movedOff.warnings, "a malformed slot ahead of the Repeat warns twice, not zero")
    assertTrue(
        not stepsHave(movedOff, "/cast Frostbolt"),
        "the Repeat is no longer an edge, so its cast is NOT emitted -- which is exactly what a DROP "
            .. "implementation could not produce, because dropping would reproduce the row above"
    )
end)

-- ---------------------------------------------------------------------------
-- Run.
-- ---------------------------------------------------------------------------

local passed = 0
local failed = 0
for _, t in ipairs(tests) do
    local ok, err = pcall(t.fn)
    if ok then
        passed = passed + 1
        print("PASS  " .. t.name)
    else
        failed = failed + 1
        print("FAIL  " .. t.name .. " -- " .. tostring(err))
    end
end
print(string.format("RESULT %d passed, %d failed", passed, failed))
os.exit(failed > 0 and 1 or 0)
