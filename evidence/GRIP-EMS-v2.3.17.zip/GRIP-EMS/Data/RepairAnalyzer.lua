-- GRIP-EMS: RepairAnalyzer
-- Created: 2026-04-07
-- Updated: 2026-07-28
-- Patch: 12.0.7.68453 Midnight (Retail LIVE)

-- GRIP-EMS: Repair Analyzer
-- Sequence analysis and auto-fix backend for the Repair Module.
-- 13 diagnostic categories with per-issue fix closures.

local _, GRIPEMS = ...
local D = GRIPEMS.Defaults

GRIPEMS.RepairAnalyzer = {}
local RA = GRIPEMS.RepairAnalyzer

local SV, VS, AC, E, MM, KM, S, DW, SC
local function ResolveDeps()
    if SV then
        return
    end
    SV, VS = GRIPEMS.SpellValidator, GRIPEMS.VariableStore
    AC, E = GRIPEMS.ActionCompiler, GRIPEMS.Engine
    MM, KM = GRIPEMS.MacroManager, GRIPEMS.KeybindManager
    S = GRIPEMS.Settings
    DW = GRIPEMS.DebugWindow
    SC = GRIPEMS.SpellCache
end

-- Constants
RA.SEVERITY_CRITICAL = "critical"
RA.SEVERITY_ERROR = "error"
RA.SEVERITY_WARNING = "warning"
RA.SEVERITY_INFO = "info"
RA.CAT_SPELLS = "SPELLS"
RA.CAT_STRUCTURE = "STRUCTURE"
RA.CAT_LIMITS = "LIMITS"
RA.CAT_VARIABLES = "VARIABLES"
RA.CAT_ACTIONS = "ACTIONS"
RA.CAT_STUBS = "STUBS"
RA.CAT_CONFIG = "CONFIG"
RA.CAT_LOCALE = "LOCALE"
RA.CAT_READINESS = "READINESS"
RA.CAT_POST_SUB = "POST_SUB"
RA.CAT_STATE_SYNC = "STATE_SYNC"
RA.CAT_CROSS_SEQ = "CROSS_SEQ"
RA.CAT_CONCURRENT = "CONCURRENT"

-- Helpers
local SEVERITY_ORDER = { critical = 1, error = 2, warning = 3, info = 4 }
local idCounters = {}
local function NextID(pfx)
    idCounters[pfx] = (idCounters[pfx] or 0) + 1
    return string.format("%s_%03d", pfx, idCounters[pfx])
end
local function ResetIDs()
    wipe(idCounters)
end
local function LogFix(sn, d)
    if DW then
        DW:AddMessage("[Repair] " .. (sn or "?") .. ": " .. d)
    end
end

-- Coerce a possibly-table step / keypress / keyrelease value to a safe string
-- for pattern matching. Mirrors the SubstituteVariables type guard at the
-- analyzer layer so a single bad sequence cannot raise during RA:Analyze.
local function asTextStr(v)
    if SC and SC.StepToString then
        return SC:StepToString(v)
    end
    return (type(v) == "string") and v or ""
end

local function I(t, pfx, cat, sev, title, detail, fixable, fixFn)
    t[#t + 1] = {
        id = NextID(pfx),
        category = cat,
        severity = sev,
        title = title,
        detail = detail,
        fixable = fixable or false,
        fixFn = fixFn,
    }
end

local contextKeySet
local function GetContextKeySet()
    if contextKeySet then
        return contextKeySet
    end
    contextKeySet = {}
    for _, k in ipairs(D.CONTEXT_KEYS) do
        contextKeySet[k] = true
    end
    return contextKeySet
end

local function StubFix(fn, seqName)
    return function(sd)
        if InCombatLockdown() then
            GRIPEMS.OOCQueue:Add(function()
                fn(sd)
                LogFix(seqName, "Stub fix (queued)")
            end, D.OOC_OP_GENERIC, seqName)
            return "queued"
        end
        fn(sd)
        return true
    end
end

---------------------------------------------------------------------
-- Surface configurations (Phase 1-polish-5)
--
-- Each Analyze caller picks an opts.surface = "badge" | "repair" |
-- "audit" that bundles state-sync + version-scope + spell-class
-- gates. New axes added later are wired into these tables without
-- touching callers. New surfaces are added by adding a constant and
-- a SURFACES table entry.
--
-- Default when opts is nil or surface is unrecognized = SURFACE_AUDIT.
-- This preserves pre-polish-5 behavior for callers (AnalyzeAll loop,
-- Transmission pre-send, Import post-import, Export pre-export, the
-- TestSuite suite) that currently pass no opts at all.
---------------------------------------------------------------------
local SURFACE_BADGE = {
    skipStateSync = true,
    activeVersionOnly = true,
    skipNotLearned = true,
}
local SURFACE_REPAIR = {
    skipStateSync = true,
    activeVersionOnly = false,
    skipNotLearned = false,
}
local SURFACE_AUDIT = {
    skipStateSync = false,
    activeVersionOnly = false,
    skipNotLearned = false,
}
local SURFACES = {
    badge = SURFACE_BADGE,
    repair = SURFACE_REPAIR,
    audit = SURFACE_AUDIT,
}

local function ResolveSurface(opts)
    if type(opts) ~= "table" then
        return SURFACE_AUDIT
    end
    if opts.surface and SURFACES[opts.surface] then
        return SURFACES[opts.surface]
    end
    return SURFACE_AUDIT
end

-- Cat 1: Spells
function RA:CheckSpells(seqData, issues, surface)
    surface = surface or SURFACE_AUDIT
    -- NOTE: keeps the index-losing { activeVer } form below. Safe ONLY because
    -- CheckSpells issues have no fixFn, so nothing is rewritten and the wrong
    -- "V" .. vi label is never surfaced under the badge surface. Before adding ANY
    -- fixFn to a CheckSpells issue, switch to the true-index pick used in
    -- RA:CheckLegacySlotNames or the fix will target the wrong version.
    -- .steps IS THE SAME DEFECT CLASS AS .versions, AND IT IS LIVE (pass 15l).
    -- The .versions guards this module carries all read `type(x) == "table"`
    -- because "or {}" substitutes for nil and false and NOT for a scalar. Every
    -- `ver.steps` read below is now written the same way for the same reason:
    -- a corrupt import or a hand-edited SavedVariables can leave steps = 5 on
    -- an otherwise WELL-FORMED version, the versions guard on the next line
    -- passes that table straight through, and the walk below then handed a
    -- number to ipairs(). Measured, not assumed: the unguarded form raised
    -- "Data/RepairAnalyzer.lua:191: bad argument #1 to 'ipairs' (table
    -- expected, got number)" through RA:Analyze in
    -- Test/test_malformed_entry_guards.lua case W27. The analyzer whose JOB is
    -- reporting corrupt sequences crashed on the corruption -- the same
    -- ordering defect the .versions arc fixed, one field over.
    local versionsToCheck
    if surface.activeVersionOnly then
        local activeVer = E and E:GetActiveVersion(seqData)
        if activeVer then
            versionsToCheck = { activeVer }
        else
            versionsToCheck = {}
        end
    else
        versionsToCheck = type(seqData.versions) == "table" and seqData.versions or {}
    end
    for vi, ver in ipairs(versionsToCheck) do
        local texts = {}
        for si, step in ipairs(type(ver.steps) == "table" and ver.steps or {}) do
            texts[#texts + 1] = { text = step, label = string.format("V%d step %d", vi, si) }
        end
        if ver.keyPress and ver.keyPress ~= "" then
            texts[#texts + 1] = { text = ver.keyPress, label = "V" .. vi .. " keyPress" }
        end
        if ver.keyRelease and ver.keyRelease ~= "" then
            texts[#texts + 1] = { text = ver.keyRelease, label = "V" .. vi .. " keyRelease" }
        end
        for _, entry in ipairs(texts) do
            local result = SV:ValidateStep(entry.text)
            for _, spell in ipairs(result.spells) do
                if spell.status == D.SPELL_STATUS_UNKNOWN then
                    local detail = entry.label .. ": '" .. spell.name .. "'"
                    if SC and SC.ready then
                        local hits = SC:PrefixSearch(spell.name:sub(1, 3), 3)
                        if hits and #hits > 0 then
                            local names = {}
                            for _, h in ipairs(hits) do
                                names[#names + 1] = h.name
                            end
                            detail = detail .. " (try: " .. table.concat(names, ", ") .. ")"
                        end
                    end
                    I(issues, "SPELL", RA.CAT_SPELLS, RA.SEVERITY_ERROR, "Unknown spell", detail)
                elseif spell.status == D.SPELL_STATUS_KNOWN then
                    if not surface.skipNotLearned then
                        I(
                            issues,
                            "SPELL",
                            RA.CAT_SPELLS,
                            RA.SEVERITY_WARNING,
                            "Spell not learned",
                            entry.label .. ": '" .. spell.name .. "'"
                        )
                    end
                end
            end
            for _, spell in ipairs(result.tooltipSpells or {}) do
                if spell.status == D.SPELL_STATUS_TOOLTIP_STALE then
                    I(
                        issues,
                        "SPELL",
                        RA.CAT_SPELLS,
                        RA.SEVERITY_INFO,
                        "Stale tooltip",
                        entry.label .. ": '" .. spell.name .. "'"
                    )
                end
            end
            for _, ex in ipairs(SV:ExtractAllSpells(entry.text)) do
                if ex.command ~= "use" and SV:ValidateSpell(ex.name, "use").status == D.SPELL_STATUS_ITEM then
                    I(
                        issues,
                        "SPELL",
                        RA.CAT_SPELLS,
                        RA.SEVERITY_WARNING,
                        "Item in non-/use command",
                        entry.label .. ": '" .. ex.name .. "'"
                    )
                end
            end
        end
    end
end

-- Cat 1b: Legacy trinket slot names
-- A pre-fix importer ran "/use <number>" arguments through the spell-name
-- resolver, baking trinket slot numbers into stored sequences as spell
-- names (slot 13 stored the name of spell 13, slot 14 the name of spell
-- 14). In game such a step fires nothing: the player owns no item by that
-- name, so the trinket never triggers. This detector reads the raw stored
-- macrotext only -- never a display-resolved string -- flags any
-- "/use <slot-name>" whose argument is not a real item, and offers a
-- one-click rewrite back to the numeric slot. A correctly stored "/use 13"
-- carries a number, not a name, so it is left untouched. The rewrite is
-- idempotent: it no-ops once the name is gone, so Fix-All re-application is
-- safe.
function RA:CheckLegacySlotNames(seqData, issues, surface)
    surface = surface or SURFACE_AUDIT
    local n = RA._currentName

    -- Map the localized name the buggy importer baked in back to the slot
    -- number it should have been. Built once per run.
    local SLOT_SET = { 13, 14 }
    local slotNameMap = {}
    for _, slotNum in ipairs(SLOT_SET) do
        local nm = C_Spell and C_Spell.GetSpellName and C_Spell.GetSpellName(slotNum)
        if nm and nm ~= "" then
            slotNameMap[nm] = slotNum
        end
    end
    if not next(slotNameMap) then
        return
    end

    -- Bare argument of a "/use ..." line (case-insensitive command), with
    -- leading [conditional] blocks, a leading "!", a trailing ";", and
    -- surrounding whitespace stripped. nil when the line is not a /use line.
    local function bareArg(line)
        if not line:lower():match("^%s*/use%s") then
            return nil
        end
        local rest = line:match("^%s*/[uU][sS][eE]%s+(.*)")
        if not rest then
            return nil
        end
        rest = rest:gsub("^%s+", "")
        while true do
            local stripped = rest:gsub("^%[[^%]]*%]%s*", "")
            if stripped == rest then
                break
            end
            rest = stripped
        end
        rest = rest:gsub("^!", "")
        rest = rest:gsub(";%s*$", "")
        rest = rest:gsub("^%s+", ""):gsub("%s+$", "")
        return rest
    end

    -- Record any /use line whose bare argument is a known slot name and is
    -- not a real item. Reads raw stored text, never a resolved string.
    local function collectNames(macrotext, outSet)
        if type(macrotext) ~= "string" then
            return
        end
        for line in macrotext:gmatch("[^\r\n]+") do
            local arg = bareArg(line)
            if
                arg
                and slotNameMap[arg]
                and not (C_Item and C_Item.GetItemInfoInstant and C_Item.GetItemInfoInstant(arg))
            then
                outSet[arg] = true
            end
        end
    end

    -- Rewrite every /use line whose bare argument equals name so the name
    -- becomes the slot number, preserving the /use prefix, any
    -- [conditionals], and all other lines (with their line endings). A plain
    -- substring replace keeps parentheses in the name literal. Returns the
    -- original string unchanged when nothing matches.
    local function rewriteOne(macrotext, name, slot)
        if type(macrotext) ~= "string" or macrotext == "" then
            return macrotext
        end
        local out, changed, pos, len = {}, false, 1, #macrotext
        while pos <= len do
            local s, e = macrotext:find("\r?\n", pos)
            local line, term
            if s then
                line, term, pos = macrotext:sub(pos, s - 1), macrotext:sub(s, e), e + 1
            else
                line, term, pos = macrotext:sub(pos), "", len + 1
            end
            if bareArg(line) == name then
                local idx = line:find(name, 1, true)
                if idx then
                    line = line:sub(1, idx - 1) .. tostring(slot) .. line:sub(idx + #name)
                    changed = true
                end
            end
            out[#out + 1] = line .. term
        end
        if not changed then
            return macrotext
        end
        return table.concat(out)
    end

    -- Walk an action tree (mirrors WalkActions: ACTION nodes carry
    -- node.macro; IF nodes hold branches in children[1]/[2]; other nodes
    -- have a flat node.children), calling fn on every ACTION node. Depth
    -- guarded by D.ACTION_MAX_DEPTH.
    local function walkActionMacros(actions, depth, fn)
        if type(actions) ~= "table" or depth > D.ACTION_MAX_DEPTH then
            return
        end
        for _, node in ipairs(actions) do
            if type(node) == "table" and node.type then
                if node.type == D.ACTION_TYPE_ACTION then
                    fn(node)
                elseif node.type == D.ACTION_TYPE_IF then
                    walkActionMacros(node.children and node.children[1], depth + 1, fn)
                    walkActionMacros(node.children and node.children[2], depth + 1, fn)
                end
                if node.type ~= D.ACTION_TYPE_IF and node.children then
                    walkActionMacros(node.children, depth + 1, fn)
                end
            end
        end
    end

    -- Pick versions by their TRUE seqData.versions index so vi always matches
    -- sd.versions[vi] in the fixFn and the "V" .. vi label is accurate. Under
    -- activeVersionOnly we keep only the active version but preserve its real
    -- index. The old { activeVer } single-element form made vi always 1, so on a
    -- multi-version sequence the fixFn (sd.versions[vi]) and the V-label could
    -- target the wrong version. E:GetActiveVersion returns a reference to an
    -- element of seqData.versions, so the identity compare below is exact.
    local versionsToCheck = {}
    if surface.activeVersionOnly then
        local activeVer = E and E:GetActiveVersion(seqData)
        if activeVer then
            for i, v in ipairs(type(seqData.versions) == "table" and seqData.versions or {}) do
                if v == activeVer then
                    versionsToCheck[#versionsToCheck + 1] = { idx = i, ver = v }
                end
            end
        end
    else
        for i, v in ipairs(type(seqData.versions) == "table" and seqData.versions or {}) do
            versionsToCheck[#versionsToCheck + 1] = { idx = i, ver = v }
        end
    end

    for _, entry in ipairs(versionsToCheck) do
        local vi, ver = entry.idx, entry.ver
        local found = {}
        for _, step in ipairs(type(ver.steps) == "table" and ver.steps or {}) do
            if type(step) == "string" then
                collectNames(step, found)
            end
        end
        if type(ver.keyPress) == "string" then
            collectNames(ver.keyPress, found)
        end
        if type(ver.keyRelease) == "string" then
            collectNames(ver.keyRelease, found)
        end
        walkActionMacros(ver.actions, 1, function(node)
            if type(node.macro) == "string" then
                collectNames(node.macro, found)
            end
        end)
        for name in pairs(found) do
            local slot = slotNameMap[name]
            I(
                issues,
                "SLOTNAME",
                RA.CAT_SPELLS,
                RA.SEVERITY_WARNING,
                "Legacy trinket slot name",
                "V" .. vi .. ": '/use " .. name .. "' should be '/use " .. slot .. "'",
                true,
                function(sd)
                    local v = type(sd.versions) == "table" and sd.versions[vi] or nil
                    if not v then
                        return true
                    end
                    if type(v.steps) == "table" then
                        for si = 1, #v.steps do
                            if type(v.steps[si]) == "string" then
                                v.steps[si] = rewriteOne(v.steps[si], name, slot)
                            end
                        end
                    end
                    if type(v.keyPress) == "string" then
                        v.keyPress = rewriteOne(v.keyPress, name, slot)
                    end
                    if type(v.keyRelease) == "string" then
                        v.keyRelease = rewriteOne(v.keyRelease, name, slot)
                    end
                    walkActionMacros(v.actions, 1, function(node)
                        if type(node.macro) == "string" then
                            node.macro = rewriteOne(node.macro, name, slot)
                        end
                    end)
                    LogFix(n, "Slot name '" .. name .. "' -> /use " .. slot .. " V" .. vi)
                    return true
                end
            )
        end
    end
end

-- Cat 2: Structure
function RA:CheckStructure(seqData, issues)
    local n = RA._currentName
    if type(seqData.versions) ~= "table" or #seqData.versions == 0 then
        I(
            issues,
            "STRUCT",
            RA.CAT_STRUCTURE,
            RA.SEVERITY_CRITICAL,
            "Missing versions",
            "No versions table or empty",
            true,
            function(sd)
                sd.versions = {
                    {
                        stepFunction = D.STEP_SEQUENTIAL,
                        steps = {},
                        keyPress = D.NewVersion.keyPress,
                        keyRelease = "",
                        resetOnCombat = false,
                        resetOnTarget = false,
                        resetOnGear = false,
                        resetOnSpec = false,
                        resetTimer = 0,
                    },
                }
                LogFix(n, "Stamped default version")
                return true
            end
        )
        return
    end
    for vi, ver in ipairs(seqData.versions) do
        -- NOT in the pass-15l brief's list of eleven, and fixed anyway because
        -- the W27 probe walks straight into it: the census patterns look for
        -- "X.steps and #" and for "not X.steps then", and this line is
        -- "not X.steps OR #", which matches neither. `not 5` is false, so the
        -- length operator runs on the scalar and raises. A scalar steps now
        -- REPORTS "Empty steps array" -- which is what it is -- instead of
        -- taking the whole analysis down two checks before CheckStructure got
        -- to say so.
        if type(ver.steps) ~= "table" or #ver.steps == 0 then
            if
                ver.actions
                and AC
                and AC.CompilesEmptyDueToInterleave
                and AC.CompilesEmptyDueToInterleave(ver.actions)
            then
                I(
                    issues,
                    "STRUCT",
                    RA.CAT_STRUCTURE,
                    RA.SEVERITY_ERROR,
                    "Empty steps array",
                    "V" .. vi .. " (all actions interleave)",
                    true,
                    function(sd)
                        -- type() guards: the prerequisite walks skip
                        -- malformed non-table entries, so this fix can be
                        -- offered on a tree that still contains them and
                        -- must not raise when it walks the same tree.
                        local function clearIL(nodes)
                            if type(nodes) ~= "table" then
                                return
                            end
                            for _, node in ipairs(nodes) do
                                if type(node) == "table" then
                                    if node.type == D.ACTION_TYPE_ACTION then
                                        node.interval = nil
                                    end
                                    if type(node.children) == "table" then
                                        if node.type == D.ACTION_TYPE_IF then
                                            clearIL(node.children[1] or {})
                                            clearIL(node.children[2] or {})
                                        else
                                            clearIL(node.children)
                                        end
                                    end
                                end
                            end
                        end
                        clearIL(sd.versions[vi].actions or {})
                        sd.versions[vi].steps = AC.CompileActions(sd.versions[vi].actions, E, sd.versions[vi])
                        LogFix(n, "Cleared interleave flags V" .. vi)
                        return true
                    end
                )
            else
                I(issues, "STRUCT", RA.CAT_STRUCTURE, RA.SEVERITY_ERROR, "Empty steps array", "V" .. vi)
            end
        end
        if ver.stepFunction == nil then
            I(
                issues,
                "STRUCT",
                RA.CAT_STRUCTURE,
                RA.SEVERITY_ERROR,
                "Missing stepFunction",
                "V" .. vi,
                true,
                function(sd)
                    sd.versions[vi].stepFunction = D.STEP_SEQUENTIAL
                    LogFix(n, "stepFunction V" .. vi)
                    return true
                end
            )
        end
        if ver.keyPress == nil then
            I(issues, "STRUCT", RA.CAT_STRUCTURE, RA.SEVERITY_WARNING, "Nil keyPress", "V" .. vi, true, function(sd)
                sd.versions[vi].keyPress = ""
                LogFix(n, "keyPress V" .. vi)
                return true
            end)
        end
        if ver.keyRelease == nil then
            I(issues, "STRUCT", RA.CAT_STRUCTURE, RA.SEVERITY_WARNING, "Nil keyRelease", "V" .. vi, true, function(sd)
                sd.versions[vi].keyRelease = ""
                LogFix(n, "keyRelease V" .. vi)
                return true
            end)
        end
        -- BOTH fields, not just steps. taggedSteps is a SIBLING of steps with
        -- the same provenance -- both are written onto the version by the
        -- locale-tagging path and both survive a hand-edited SavedVariables --
        -- so a scalar taggedSteps reaches #ver.taggedSteps exactly as easily as
        -- a scalar steps reaches #ver.steps. Guarding half the line would leave
        -- the raise on the other half.
        if type(ver.taggedSteps) == "table" and type(ver.steps) == "table" and #ver.taggedSteps ~= #ver.steps then
            I(
                issues,
                "STRUCT",
                RA.CAT_STRUCTURE,
                RA.SEVERITY_WARNING,
                "Orphaned taggedSteps",
                string.format("V%d: %d tagged vs %d steps", vi, #ver.taggedSteps, #ver.steps),
                true,
                function(sd)
                    sd.versions[vi].taggedSteps = nil
                    sd.versions[vi].stepsLocale = nil
                    LogFix(n, "Cleared V" .. vi)
                    return true
                end
            )
        end
    end
    if seqData.name == nil or seqData.name == "" then
        I(issues, "STRUCT", RA.CAT_STRUCTURE, RA.SEVERITY_ERROR, "Missing name", "nil/empty", true, function(sd)
            sd.name = n
            LogFix(n, "Set name")
            return true
        end)
    end
    if seqData.icon == nil then
        I(issues, "STRUCT", RA.CAT_STRUCTURE, RA.SEVERITY_INFO, "Missing icon", "nil", true, function(sd)
            sd.icon = D.QUESTION_MARK_ICON
            LogFix(n, "Set icon")
            return true
        end)
    end
    local dv = seqData.defaultVersion or 0
    if dv < 1 or dv > #seqData.versions then
        I(
            issues,
            "STRUCT",
            RA.CAT_STRUCTURE,
            RA.SEVERITY_ERROR,
            "defaultVersion out of range",
            "dv=" .. dv,
            true,
            function(sd)
                sd.defaultVersion = math.min(math.max(sd.defaultVersion or 1, 1), #sd.versions)
                LogFix(n, "Clamped dv")
                return true
            end
        )
    end
    -- LIVE-VERSION-QUICK-SWAP: an out-of-range pin is ignored by the resolver,
    -- but clear it as a fixable repair so the stored data stays clean. nil (no
    -- pin) is the normal state and is never flagged.
    local pv = seqData.pinnedVersion
    if pv ~= nil and (type(pv) ~= "number" or pv < 1 or pv > #seqData.versions) then
        I(
            issues,
            "STRUCT",
            RA.CAT_STRUCTURE,
            RA.SEVERITY_ERROR,
            "pinnedVersion out of range",
            "pin=" .. tostring(pv),
            true,
            function(sd)
                sd.pinnedVersion = nil
                LogFix(n, "Cleared pin")
                return true
            end
        )
    end
    if seqData.contextOverrides then
        local ckSet = GetContextKeySet()
        for key, idx in pairs(seqData.contextOverrides) do
            if type(idx) == "number" and idx > #seqData.versions then
                I(
                    issues,
                    "STRUCT",
                    RA.CAT_STRUCTURE,
                    RA.SEVERITY_ERROR,
                    "Stale context override",
                    key .. " -> V" .. idx,
                    true,
                    function(sd)
                        sd.contextOverrides[key] = nil
                        LogFix(n, "Removed " .. key)
                        return true
                    end
                )
            end
            if not ckSet[key] then
                I(
                    issues,
                    "STRUCT",
                    RA.CAT_STRUCTURE,
                    RA.SEVERITY_WARNING,
                    "Unknown context key",
                    key,
                    true,
                    function(sd)
                        sd.contextOverrides[key] = nil
                        LogFix(n, "Removed " .. key)
                        return true
                    end
                )
            end
        end
    end
    local cid = seqData.classID
    if cid == nil or type(cid) ~= "number" or cid < 1 or cid > 13 then
        I(issues, "STRUCT", RA.CAT_STRUCTURE, RA.SEVERITY_WARNING, "Invalid classID", tostring(cid), true, function(sd)
            sd.classID = select(3, UnitClass("player"))
            LogFix(n, "Stamped classID")
            return true
        end)
    end
    for _, field in ipairs({ "author", "version", "description" }) do
        if seqData[field] == nil then
            I(issues, "STRUCT", RA.CAT_STRUCTURE, RA.SEVERITY_INFO, "Missing " .. field, "nil", true, function(sd)
                sd[field] = ""
                LogFix(n, "Set " .. field)
                return true
            end)
        end
    end
end

-- Cat 3: Limits
function RA:CheckLimits(seqData, issues)
    local n = RA._currentName
    for vi, ver in ipairs(type(seqData.versions) == "table" and seqData.versions or {}) do
        local kp = (type(ver.keyPress) == "string") and ver.keyPress or ""
        local kr = (type(ver.keyRelease) == "string") and ver.keyRelease or ""
        for si, step in ipairs(type(ver.steps) == "table" and ver.steps or {}) do
            -- Length math runs on the coerced text: steps are legitimately
            -- strings, attribute tables, or line arrays (SC:StepToString),
            -- and # on a junk scalar (corrupt import / hand-edited SV)
            -- raises in Lua 5.1. Junk gets its own report instead of a
            -- silent skip; the coerced "" keeps the length checks inert.
            local stepText = asTextStr(step)
            if type(step) ~= "string" and type(step) ~= "table" then
                I(
                    issues,
                    "LIMIT",
                    RA.CAT_LIMITS,
                    RA.SEVERITY_ERROR,
                    "Malformed step entry",
                    string.format("V%d s%d: %s", vi, si, type(step)),
                    true,
                    function(sd)
                        -- Stale-proof for batch apply: a lower-index split
                        -- fix can shift this slot before we run, so act only
                        -- when the slot still holds junk (the split-fix
                        -- precedent); re-analysis re-flags the survivor.
                        local cur = sd.versions[vi].steps[si]
                        if type(cur) == "string" or type(cur) == "table" then
                            return "partial"
                        end
                        sd.versions[vi].steps[si] = ""
                        LogFix(n, "Cleared junk V" .. vi .. "s" .. si)
                        return true
                    end
                )
            end
            if #stepText > D.MAX_MACROTEXT_LENGTH then
                I(
                    issues,
                    "LIMIT",
                    RA.CAT_LIMITS,
                    RA.SEVERITY_ERROR,
                    "Step exceeds 255 chars",
                    string.format("V%d s%d: %d", vi, si, #stepText),
                    true,
                    function(sd)
                        local s = asTextStr(sd.versions[vi].steps[si])
                        local parts = {}
                        for part in s:gmatch("[^;]+") do
                            parts[#parts + 1] = part
                        end
                        if #parts > 1 then
                            sd.versions[vi].steps[si] = parts[1]
                            for p = 2, #parts do
                                table.insert(sd.versions[vi].steps, si + p - 1, parts[p])
                            end
                            LogFix(n, "Split V" .. vi .. "s" .. si)
                            return true
                        end
                        return "partial"
                    end
                )
            end
            if stepText ~= "" and (kp ~= "" or kr ~= "") then
                local c = #stepText + (kp ~= "" and #kp + 1 or 0) + (kr ~= "" and #kr + 1 or 0)
                if c > D.MAX_MACROTEXT_LENGTH then
                    I(
                        issues,
                        "LIMIT",
                        RA.CAT_LIMITS,
                        RA.SEVERITY_WARNING,
                        "kp/kr overflow",
                        string.format("V%d s%d: %d", vi, si, c)
                    )
                end
            end
        end
        if
            kp ~= ""
            and MM
            and MM.stubs
            and MM.stubs[n]
            and E
            and E.AllStepsBakeKpKr
            and not E:AllStepsBakeKpKr(ver.steps, kp, kr)
        then
            local body = MM:BuildStubBody(D.BUTTON_PREFIX .. E:SanitizeName(n), kp, kr, ver.steps)
            local total, fitted, inKp = 0, 0, false
            for _ in kp:gmatch("[^\n]+") do
                total = total + 1
            end
            for line in body:gmatch("[^\n]+") do
                if line:match("^#showtooltip") then
                    inKp = true
                elseif line:match("^/click") then
                    inKp = false
                elseif inKp then
                    fitted = fitted + 1
                end
            end
            if fitted < total then
                I(
                    issues,
                    "LIMIT",
                    RA.CAT_LIMITS,
                    RA.SEVERITY_WARNING,
                    "kp lines trimmed",
                    string.format("V%d: %d/%d fit", vi, fitted, total),
                    true,
                    function(sd)
                        local v = sd.versions[vi]
                        local lines = {}
                        local vkp = (type(v.keyPress) == "string") and v.keyPress or ""
                        for line in vkp:gmatch("[^\n]+") do
                            lines[#lines + 1] = line
                        end
                        while #lines > 0 do
                            v.keyPress = table.concat(lines, "\n")
                            local bd = MM:BuildStubBody(
                                D.BUTTON_PREFIX .. E:SanitizeName(n),
                                v.keyPress,
                                v.keyRelease or "",
                                v.steps
                            )
                            local tl, ft, ip = 0, 0, false
                            for _ in v.keyPress:gmatch("[^\n]+") do
                                tl = tl + 1
                            end
                            for ln in bd:gmatch("[^\n]+") do
                                if ln:match("^#showtooltip") then
                                    ip = true
                                elseif ln:match("^/click") then
                                    ip = false
                                elseif ip then
                                    ft = ft + 1
                                end
                            end
                            if ft >= tl then
                                break
                            end
                            table.remove(lines)
                        end
                        LogFix(n, "Trimmed kp lines V" .. vi)
                        return #lines > 0 and true or "partial"
                    end
                )
            end
        end
    end
end

-- Cat 4: Variables
function RA:CheckVariables(seqData, issues)
    local n = RA._currentName
    local used = {}
    for _, ver in ipairs(type(seqData.versions) == "table" and seqData.versions or {}) do
        for _, step in ipairs(type(ver.steps) == "table" and ver.steps or {}) do
            for vn in asTextStr(step):gmatch(D.VAR_PATTERN) do
                used[vn] = true
            end
        end
        if type(ver.keyPress) == "string" then
            for vn in ver.keyPress:gmatch(D.VAR_PATTERN) do
                used[vn] = true
            end
        end
        if type(ver.keyRelease) == "string" then
            for vn in ver.keyRelease:gmatch(D.VAR_PATTERN) do
                used[vn] = true
            end
        end
    end
    for vn in pairs(used) do
        local vd = VS:Get(vn)
        if not vd then
            I(
                issues,
                "VAR",
                RA.CAT_VARIABLES,
                RA.SEVERITY_ERROR,
                "Non-existent variable",
                "~" .. vn .. "~",
                true,
                function()
                    VS:Set(vn, { funct = "", events = "" })
                    LogFix(n, "Created " .. vn)
                    return true
                end
            )
        else
            local valid, pErr = VS:ValidateFunction(vd.funct)
            if not valid then
                I(issues, "VAR", RA.CAT_VARIABLES, RA.SEVERITY_ERROR, "Parse error", vn .. ": " .. (pErr or "?"))
            end
            if VS:GetLocaleRisk(vn) then
                I(
                    issues,
                    "VAR",
                    RA.CAT_VARIABLES,
                    RA.SEVERITY_WARNING,
                    "Locale risk",
                    vn .. " -> '" .. VS:GetLocaleRisk(vn).spellName .. "'"
                )
            end
            if VS:Evaluate(vn) == "" then
                I(issues, "VAR", RA.CAT_VARIABLES, RA.SEVERITY_INFO, "Evaluates to empty", vn)
            end
        end
    end
    local deps = {}
    for vn in pairs(used) do
        deps[vn] = {}
        local vd = VS:Get(vn)
        if vd and vd.funct then
            for ref in vd.funct:gmatch(D.VAR_PATTERN) do
                deps[vn][ref] = true
            end
        end
    end
    local function hasCycle(vn, path)
        if path[vn] then
            return true
        end
        if not deps[vn] then
            return false
        end
        path[vn] = true
        for dep in pairs(deps[vn]) do
            if hasCycle(dep, path) then
                return true
            end
        end
        path[vn] = nil
        return false
    end
    for vn in pairs(used) do
        if VS:Get(vn) and hasCycle(vn, {}) then
            I(issues, "VAR", RA.CAT_VARIABLES, RA.SEVERITY_ERROR, "Circular reference", vn)
        end
    end
end

-- Cat 5: Actions
local function WalkActions(actions, issues, vi, depth)
    if type(actions) ~= "table" then
        return
    end
    if depth > D.ACTION_MAX_DEPTH then
        I(
            issues,
            "ACT",
            RA.CAT_ACTIONS,
            RA.SEVERITY_ERROR,
            "Nesting exceeds max depth",
            string.format("V%d: depth %d (max %d)", vi, depth, D.ACTION_MAX_DEPTH)
        )
        return
    end
    for _, node in ipairs(actions) do
        if type(node) == "table" and node.type then
            if node.type == D.ACTION_TYPE_EMBED then
                if node.sequence and node.sequence ~= "" and E.sequences and not E.sequences[node.sequence] then
                    I(
                        issues,
                        "ACT",
                        RA.CAT_ACTIONS,
                        RA.SEVERITY_ERROR,
                        "EMBED target missing",
                        "V" .. vi .. ": '" .. node.sequence .. "'"
                    )
                end
            elseif node.type == D.ACTION_TYPE_PAUSE then
                local c = tonumber(node.clicks) or 0
                if c < 1 or c > 100 then
                    I(
                        issues,
                        "ACT",
                        RA.CAT_ACTIONS,
                        RA.SEVERITY_WARNING,
                        "Invalid PAUSE clicks",
                        string.format("V%d: %d", vi, c)
                    )
                end
            elseif node.type == D.ACTION_TYPE_LOOP then
                local r = tonumber(node["repeat"]) or 0
                if r < 1 or r > D.ACTION_LOOP_MAX_REPEAT then
                    I(
                        issues,
                        "ACT",
                        RA.CAT_ACTIONS,
                        RA.SEVERITY_ERROR,
                        "Invalid LOOP count",
                        string.format("V%d: %d (max %d)", vi, r, D.ACTION_LOOP_MAX_REPEAT)
                    )
                end
            elseif node.type == D.ACTION_TYPE_ACTION then
                if node.macro == nil or node.macro == "" then
                    I(issues, "ACT", RA.CAT_ACTIONS, RA.SEVERITY_ERROR, "Empty action macro", "V" .. vi)
                end
            elseif node.type == D.ACTION_TYPE_IF then
                local kids = type(node.children) == "table" and node.children or {}
                local tb = type(kids[1]) == "table" and kids[1] or {}
                local fb = type(kids[2]) == "table" and kids[2] or {}
                if node.variable == nil or node.variable == "" then
                    I(issues, "ACT", RA.CAT_ACTIONS, RA.SEVERITY_ERROR, "IF missing variable", "V" .. vi)
                end
                if #tb > 1 and #fb > 0 then
                    I(issues, "ACT", RA.CAT_ACTIONS, RA.SEVERITY_WARNING, "Complex IF false discarded", "V" .. vi)
                end
                WalkActions(tb, issues, vi, depth + 1)
                WalkActions(fb, issues, vi, depth + 1)
            end
        end
        if type(node) == "table" and node.type and node.type ~= D.ACTION_TYPE_IF and node.children then
            WalkActions(node.children, issues, vi, depth + 1)
        end
    end
end

function RA:CheckActions(seqData, issues)
    for vi, ver in ipairs(type(seqData.versions) == "table" and seqData.versions or {}) do
        if ver.actions and type(ver.actions) == "table" and #ver.actions > 0 then
            local isValid, errors = AC.ValidateActions(ver.actions)
            if not isValid then
                for _, err in ipairs(errors) do
                    I(issues, "ACT", RA.CAT_ACTIONS, RA.SEVERITY_ERROR, "Action tree error", "V" .. vi .. ": " .. err)
                end
            end
            WalkActions(ver.actions, issues, vi, 1)
        end
    end
end

-- Cat 6: Stubs
function RA:CheckStubs(seqData, seqName, issues)
    if not MM then
        return
    end
    if MM.stubs[seqName] then
        local _, _, curBody = GetMacroInfo(MM.stubs[seqName])
        local ver = E:GetActiveVersion(seqData)
        if ver and curBody then
            local expected =
                MM:BuildStubBody(D.BUTTON_PREFIX .. E:SanitizeName(seqName), ver.keyPress, ver.keyRelease, ver.steps)
            if curBody ~= expected then
                I(
                    issues,
                    "STUB",
                    RA.CAT_STUBS,
                    RA.SEVERITY_WARNING,
                    "Stub body out of sync",
                    "Macro body differs",
                    true,
                    StubFix(function(sd)
                        MM:DeleteStub(seqName)
                        local v = E:GetActiveVersion(sd)
                        MM:CreateStub(seqName, v and v.keyPress, v and v.keyRelease, v and v.steps)
                        LogFix(seqName, "Recreated stub")
                    end, seqName)
                )
            end
        end
    else
        I(issues, "STUB", RA.CAT_STUBS, RA.SEVERITY_INFO, "No macro stub", "No stub exists")
    end
end

-- Cat 7: Config
function RA:CheckConfig(seqData, issues)
    local n = RA._currentName
    for vi, ver in ipairs(type(seqData.versions) == "table" and seqData.versions or {}) do
        if ver.resetTimer and (ver.resetTimer < 0 or ver.resetTimer > 3600) then
            I(
                issues,
                "CFG",
                RA.CAT_CONFIG,
                RA.SEVERITY_WARNING,
                "resetTimer out of range",
                "V" .. vi .. ": " .. tostring(ver.resetTimer),
                true,
                function(sd)
                    sd.versions[vi].resetTimer = math.min(math.max(sd.versions[vi].resetTimer or 0, 0), 3600)
                    LogFix(n, "Clamped resetTimer V" .. vi)
                    return true
                end
            )
        end
        if ver.resetModifiers and type(ver.resetModifiers) == "table" then
            for mod in pairs(ver.resetModifiers) do
                if D.MACRO_RESET_MODIFIER_DEFAULTS[mod] == nil then
                    I(
                        issues,
                        "CFG",
                        RA.CAT_CONFIG,
                        RA.SEVERITY_WARNING,
                        "Invalid reset modifier",
                        "V" .. vi .. ": " .. tostring(mod)
                    )
                end
            end
        end
        if ver.resetOnSpec and seqData.specID then
            I(issues, "CFG", RA.CAT_CONFIG, RA.SEVERITY_INFO, "resetOnSpec on spec-locked", "V" .. vi)
        end
    end
end

-- Cat 8: Locale
function RA:CheckLocale(seqData, issues)
    local n, loc = RA._currentName, GetLocale()
    for vi, ver in ipairs(type(seqData.versions) == "table" and seqData.versions or {}) do
        if ver.taggedSteps then
            if ver.stepsLocale and ver.stepsLocale ~= loc then
                I(
                    issues,
                    "LOC",
                    RA.CAT_LOCALE,
                    RA.SEVERITY_WARNING,
                    "Locale mismatch",
                    string.format("V%d: %s vs %s", vi, ver.stepsLocale, loc),
                    true,
                    function()
                        E:HealLocaleSteps()
                        LogFix(n, "Healed locale")
                        return true
                    end
                )
            end
            -- taggedSteps is guarded here too even though the enclosing
            -- `if ver.taggedSteps then` already proved it TRUTHY: truthy is not
            -- table, and 5 is truthy. The outer gate is deliberately left as a
            -- truthiness test so a scalar taggedSteps still reaches the locale
            -- mismatch report above -- only the length comparison needs a table.
            if type(ver.taggedSteps) == "table" and type(ver.steps) == "table" and #ver.taggedSteps ~= #ver.steps then
                I(
                    issues,
                    "LOC",
                    RA.CAT_LOCALE,
                    RA.SEVERITY_ERROR,
                    "taggedSteps count mismatch",
                    string.format("V%d: %d vs %d", vi, #ver.taggedSteps, #ver.steps),
                    true,
                    function(sd)
                        sd.versions[vi].taggedSteps = nil
                        sd.versions[vi].stepsLocale = nil
                        LogFix(n, "Cleared V" .. vi)
                        return true
                    end
                )
            end
        elseif type(ver.steps) == "table" and #ver.steps > 0 then
            I(issues, "LOC", RA.CAT_LOCALE, RA.SEVERITY_INFO, "Missing taggedSteps", "V" .. vi)
        end
    end
end

-- Cat 9: Readiness
function RA:CheckReadiness(seqData, seqName, issues)
    local hasBind = KM and KM:GetKeybind(seqName) ~= nil
    local hasStub = MM and MM.stubs[seqName] ~= nil
    if not hasBind and not hasStub then
        I(
            issues,
            "RDY",
            RA.CAT_READINESS,
            RA.SEVERITY_CRITICAL,
            "No keybind and no stub",
            "Sequence cannot fire",
            true,
            StubFix(function(sd)
                local v = E:GetActiveVersion(sd)
                MM:CreateStub(seqName, v and v.keyPress, v and v.keyRelease, v and v.steps)
                LogFix(seqName, "Created stub")
            end, seqName)
        )
    elseif not hasBind and hasStub then
        local anyBind = false
        if _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.keybinds then
            for _, binds in pairs(GRIP_EMS_CHAR.keybinds) do
                for _, bs in pairs(binds) do
                    if bs == seqName then
                        anyBind = true
                        break
                    end
                end
                if anyBind then
                    break
                end
            end
        end
        if anyBind then
            I(
                issues,
                "RDY",
                RA.CAT_READINESS,
                RA.SEVERITY_WARNING,
                "Keybind on different spec",
                "Bind exists but not for current spec"
            )
        end
    end
    local castPat, usePat = "/[Cc][Aa][Ss][Tt]%s", "/[Uu][Ss][Ee]%s"
    for vi, ver in ipairs(type(seqData.versions) == "table" and seqData.versions or {}) do
        -- Guarded AT THE BINDING, not at each use: `steps` is read three times
        -- below (#steps here, #steps at the elseif, ipairs(steps) inside it), so
        -- a per-use guard would be three chances to miss one. See the .steps
        -- note at CheckSpells.
        local steps = type(ver.steps) == "table" and ver.steps or {}
        if #steps == 0 then
            for _, fld in ipairs({ "keyPress", "keyRelease" }) do
                local txt = ver[fld]
                if txt and (txt:match(castPat) or txt:match(usePat)) then
                    I(
                        issues,
                        "RDY",
                        RA.CAT_READINESS,
                        RA.SEVERITY_ERROR,
                        "Content in " .. fld .. " not steps",
                        "V" .. vi,
                        true,
                        function(sd)
                            -- THE ANALYSIS RAN ON THE SANITISED LOCAL; THE FIX
                            -- RUNS ON THE RAW FIELD. This branch is entered
                            -- precisely when #steps == 0, and `steps` is the
                            -- normalised local bound at the top of the loop --
                            -- it was already substituted with {} for anything
                            -- that was not a table. So the very condition that
                            -- brings us here is satisfied by a raw ver.steps
                            -- that is nil, a number, a boolean or a string, and
                            -- only the empty-table case arrives here intact.
                            --
                            -- The closure then WRITES through that raw field, so
                            -- it cannot lean on the read-tolerance a scalar gets
                            -- elsewhere: indexing a string for a read is legal
                            -- via its metatable, but assigning into one is not,
                            -- so even the string shape died here. Normalising to
                            -- a fresh table first makes every corrupt shape land
                            -- on the same repair the empty table already got.
                            --
                            -- Note what was and was not broken: the analyzer
                            -- detected the corruption correctly for every shape
                            -- and reported this issue as it should. Only APPLYING
                            -- the repair raised, which put the error in front of
                            -- the user at the moment they clicked Fix.
                            local v = sd.versions[vi]
                            if type(v.steps) ~= "table" then
                                v.steps = {}
                            end
                            v.steps[1] = v[fld]
                            v[fld] = ""
                            LogFix(seqName, "Moved " .. fld .. "->step V" .. vi)
                            return true
                        end
                    )
                end
            end
        elseif #steps > 0 then
            local allEmpty = true
            for _, step in ipairs(steps) do
                if asTextStr(step):match("%S") then
                    allEmpty = false
                    break
                end
            end
            if allEmpty then
                I(issues, "RDY", RA.CAT_READINESS, RA.SEVERITY_ERROR, "All steps empty", "V" .. vi, true, function(sd)
                    local cl = {}
                    for _, step in ipairs(sd.versions[vi].steps) do
                        if asTextStr(step):match("%S") then
                            cl[#cl + 1] = step
                        end
                    end
                    sd.versions[vi].steps = cl
                    LogFix(seqName, "Cleaned V" .. vi)
                    return true
                end)
            end
        end
    end
    if type(seqData.versions) == "table" and #seqData.versions == 1 then
        local ver = seqData.versions[1]
        if
            -- Same "not X.steps OR #" shape the census cannot see, same fix as
            -- CheckStructure's. An unedited template has an EMPTY steps array;
            -- a scalar is not one, but it is equally "not a usable rotation",
            -- so treating it as empty keeps the report honest and the read safe.
            (type(ver.steps) ~= "table" or #ver.steps == 0)
            and (ver.keyPress == "/stopmacro [channeling]" or ver.keyPress == "" or ver.keyPress == nil)
        then
            I(issues, "RDY", RA.CAT_READINESS, RA.SEVERITY_CRITICAL, "Unedited template", "Only version empty/default")
        end
    end
    if S and S:GetEffectiveClickRate() == 0 then
        I(issues, "RDY", RA.CAT_READINESS, RA.SEVERITY_ERROR, "Click rate is 0", "Nothing will fire", true, function()
            S:SetCharClickRate(0)
            S:Set("msClickRate", 250)
            LogFix(seqName, "Reset click rate")
            return true
        end)
    end
    local _, _, pCID = UnitClass("player")
    if seqData.classID and pCID and seqData.classID ~= pCID then
        I(
            issues,
            "RDY",
            RA.CAT_READINESS,
            RA.SEVERITY_WARNING,
            "Class mismatch",
            "seq=" .. seqData.classID .. " player=" .. pCID
        )
    end
end

-- Cat 10: Post-Substitution
function RA:CheckPostSub(seqData, issues)
    for vi, ver in ipairs(type(seqData.versions) == "table" and seqData.versions or {}) do
        for si, step in ipairs(type(ver.steps) == "table" and ver.steps or {}) do
            local spellCache = GRIPEMS.SpellCache
            local stepText = (spellCache and spellCache.StepToString) and spellCache:StepToString(step)
                or (type(step) == "string" and step or "")
            if stepText:match(D.VAR_PATTERN) then
                local resolved = E:SubstituteVariables(stepText)
                if #resolved > D.MAX_MACROTEXT_LENGTH then
                    I(
                        issues,
                        "PSUB",
                        RA.CAT_POST_SUB,
                        RA.SEVERITY_CRITICAL,
                        "Post-sub overflow",
                        string.format("V%d s%d: %d chars", vi, si, #resolved)
                    )
                end
                for vn in stepText:gmatch(D.VAR_PATTERN) do
                    if VS:GetLocaleRisk(vn) then
                        I(
                            issues,
                            "PSUB",
                            RA.CAT_POST_SUB,
                            RA.SEVERITY_WARNING,
                            "Post-sub locale risk",
                            string.format(
                                "V%d s%d: ~%s~ resolves spell '%s'",
                                vi,
                                si,
                                vn,
                                VS:GetLocaleRisk(vn).spellName
                            )
                        )
                    end
                end
            end
        end
    end
end

-- Cat 11: State Sync
function RA:CheckStateSync(seqData, seqName, issues)
    local SE = GRIPEMS.SequenceEditor
    if SE and SE.currentSequence == seqName then
        I(issues, "SYNC", RA.CAT_STATE_SYNC, RA.SEVERITY_ERROR, "Open in editor", "May conflict with repair")
    end
    local PE = GRIPEMS.PopupEditor
    if PE and PE.pool then
        for _, inst in ipairs(PE.pool) do
            if inst.seqName == seqName and inst.frame and inst.frame:IsShown() then
                I(issues, "SYNC", RA.CAT_STATE_SYNC, RA.SEVERITY_WARNING, "Popup editor open", "Shows this sequence")
                break
            end
        end
    end
    local TH = GRIPEMS.TrackerHUD
    if TH and TH.activeSeqName == seqName then
        I(issues, "SYNC", RA.CAT_STATE_SYNC, RA.SEVERITY_WARNING, "Active in TrackerHUD", "HUD tracking this sequence")
    end
    if SE and SE.currentSequence == seqName then
        I(
            issues,
            "SYNC",
            RA.CAT_STATE_SYNC,
            RA.SEVERITY_WARNING,
            "UndoStack may be stale",
            "Destructive repair invalidates undo closures"
        )
    end
    local hasVars = false
    for _, ver in ipairs(type(seqData.versions) == "table" and seqData.versions or {}) do
        for _, step in ipairs(type(ver.steps) == "table" and ver.steps or {}) do
            if asTextStr(step):match(D.VAR_PATTERN) then
                hasVars = true
                break
            end
        end
        if hasVars then
            break
        end
        if type(ver.keyPress) == "string" and ver.keyPress:match(D.VAR_PATTERN) then
            hasVars = true
        end
        if type(ver.keyRelease) == "string" and ver.keyRelease:match(D.VAR_PATTERN) then
            hasVars = true
        end
    end
    if hasVars and VS then
        I(
            issues,
            "SYNC",
            RA.CAT_STATE_SYNC,
            RA.SEVERITY_WARNING,
            "VS cache active",
            "Variable fixes require cache invalidation"
        )
    end
end

-- Cat 12: Cross-Sequence (AnalyzeAll only)
function RA:CheckCrossSeq(allIssues)
    if not E or not E.sequences then
        return
    end
    local function groupBy(keyFn)
        local map = {}
        for sn in pairs(E.sequences) do
            local k = keyFn(sn)
            map[k] = map[k] or {}
            map[k][#map[k] + 1] = sn
        end
        return map
    end
    -- Stub name truncation collisions
    for _, names in
        pairs(groupBy(function(sn)
            return MM:TruncateName(sn)
        end))
    do
        if #names > 1 then
            local d = table.concat(names, ", ")
            for _, sn in ipairs(names) do
                allIssues[sn] = allIssues[sn] or {}
                I(allIssues[sn], "XSEQ", RA.CAT_CROSS_SEQ, RA.SEVERITY_ERROR, "Stub name collision", d)
            end
        end
    end
    -- Case-insensitive duplicate names
    for _, names in
        pairs(groupBy(function(sn)
            return strlower(sn)
        end))
    do
        if #names > 1 then
            local d = table.concat(names, ", ")
            for _, sn in ipairs(names) do
                allIssues[sn] = allIssues[sn] or {}
                I(allIssues[sn], "XSEQ", RA.CAT_CROSS_SEQ, RA.SEVERITY_WARNING, "Duplicate name (case)", d)
            end
        end
    end
    -- Orphaned stubs
    for stubSeq in pairs(MM.stubs) do
        if not E.sequences[stubSeq] then
            allIssues[stubSeq] = allIssues[stubSeq] or {}
            I(
                allIssues[stubSeq],
                "XSEQ",
                RA.CAT_CROSS_SEQ,
                RA.SEVERITY_WARNING,
                "Orphaned macro stub",
                "Sequence deleted",
                true,
                StubFix(function()
                    MM:DeleteStub(stubSeq)
                    LogFix(stubSeq, "Deleted orphaned stub")
                end, stubSeq)
            )
        end
    end
    -- Broken EMBED chains (recursive)
    local function scanEmbeds(actions, owner, visited)
        -- type() guards throughout: corrupt data can leave non-table entries
        -- (or a non-table children field) anywhere in the tree, and the
        -- cross-sequence scan must survive what WalkActions already survives.
        if type(actions) ~= "table" then
            return
        end
        for _, node in ipairs(actions) do
            if type(node) == "table" and node.type == D.ACTION_TYPE_EMBED and node.sequence then
                if not E.sequences[node.sequence] then
                    allIssues[owner] = allIssues[owner] or {}
                    I(
                        allIssues[owner],
                        "XSEQ",
                        RA.CAT_CROSS_SEQ,
                        RA.SEVERITY_ERROR,
                        "Broken EMBED chain",
                        "'" .. node.sequence .. "' missing"
                    )
                elseif not visited[node.sequence] then
                    visited[node.sequence] = true
                    local t = E.sequences[node.sequence]
                    if t and t.data then
                        for _, tv in ipairs(type(t.data.versions) == "table" and t.data.versions or {}) do
                            if tv.actions then
                                scanEmbeds(tv.actions, owner, visited)
                            end
                        end
                    end
                end
            end
            if type(node) == "table" and type(node.children) == "table" then
                if node.type == D.ACTION_TYPE_IF then
                    scanEmbeds(node.children[1] or {}, owner, visited)
                    scanEmbeds(node.children[2] or {}, owner, visited)
                else
                    scanEmbeds(node.children, owner, visited)
                end
            end
        end
    end
    for sn, entry in pairs(E.sequences) do
        if entry.data then
            for _, ver in ipairs(type(entry.data.versions) == "table" and entry.data.versions or {}) do
                if ver.actions then
                    scanEmbeds(ver.actions, sn, { [sn] = true })
                end
            end
        end
    end
    -- Variables referenced by multiple seqs but missing from store
    local varRefs = {}
    for sn, entry in pairs(E.sequences) do
        if entry.data then
            for _, ver in ipairs(type(entry.data.versions) == "table" and entry.data.versions or {}) do
                for _, step in ipairs(type(ver.steps) == "table" and ver.steps or {}) do
                    for vn in asTextStr(step):gmatch(D.VAR_PATTERN) do
                        varRefs[vn] = varRefs[vn] or {}
                        varRefs[vn][sn] = true
                    end
                end
                if type(ver.keyPress) == "string" then
                    for vn in ver.keyPress:gmatch(D.VAR_PATTERN) do
                        varRefs[vn] = varRefs[vn] or {}
                        varRefs[vn][sn] = true
                    end
                end
                if type(ver.keyRelease) == "string" then
                    for vn in ver.keyRelease:gmatch(D.VAR_PATTERN) do
                        varRefs[vn] = varRefs[vn] or {}
                        varRefs[vn][sn] = true
                    end
                end
            end
        end
    end
    for vn, seqs in pairs(varRefs) do
        if not VS:Get(vn) then
            local names = {}
            for sn in pairs(seqs) do
                names[#names + 1] = sn
            end
            if #names > 1 then
                for _, sn in ipairs(names) do
                    allIssues[sn] = allIssues[sn] or {}
                    I(
                        allIssues[sn],
                        "XSEQ",
                        RA.CAT_CROSS_SEQ,
                        RA.SEVERITY_ERROR,
                        "Shared variable deleted",
                        "~" .. vn .. "~ used by " .. #names .. " seqs"
                    )
                end
            end
        end
    end
end

-- Cat 13: Concurrent
function RA:CheckConcurrent(issues)
    if InCombatLockdown() then
        I(issues, "CONC", RA.CAT_CONCURRENT, RA.SEVERITY_WARNING, "In combat lockdown", "Stub fixes queued")
    end
    local RF = GRIPEMS.RepairFrame
    if RF and RF.frame and RF.frame:IsShown() then
        I(issues, "CONC", RA.CAT_CONCURRENT, RA.SEVERITY_ERROR, "RepairFrame already open", "Another session active")
    end
    local OQ = GRIPEMS.OOCQueue
    if OQ and OQ:GetCount() > 0 then
        I(
            issues,
            "CONC",
            RA.CAT_CONCURRENT,
            RA.SEVERITY_WARNING,
            "Queued OOC repairs pending",
            "Don't /reload until queued repairs complete (" .. OQ:GetCount() .. " pending)"
        )
    end
end

-- Public API
function RA:Analyze(seqData, seqName, opts)
    ResolveDeps()
    ResetIDs()
    self._currentName = seqName or ""
    local surface = ResolveSurface(opts)
    local issues = {}
    self:CheckSpells(seqData, issues, surface)
    self:CheckLegacySlotNames(seqData, issues, surface)
    self:CheckStructure(seqData, issues)
    self:CheckLimits(seqData, issues)
    self:CheckVariables(seqData, issues)
    self:CheckActions(seqData, issues)
    self:CheckStubs(seqData, seqName, issues)
    self:CheckConfig(seqData, issues)
    self:CheckLocale(seqData, issues)
    self:CheckReadiness(seqData, seqName, issues)
    self:CheckPostSub(seqData, issues)
    if not surface.skipStateSync then
        self:CheckStateSync(seqData, seqName, issues)
        self:CheckConcurrent(issues)
    end
    table.sort(issues, function(a, b)
        return (SEVERITY_ORDER[a.severity] or 99) < (SEVERITY_ORDER[b.severity] or 99)
    end)
    return issues
end

function RA:AnalyzeAll()
    ResolveDeps()
    if not E or not E.sequences then
        return {}
    end
    local allIssues = {}
    for seqName, entry in pairs(E.sequences) do
        if entry.data then
            allIssues[seqName] = self:Analyze(entry.data, seqName)
        end
    end
    ResetIDs()
    self:CheckCrossSeq(allIssues)
    for _, issues in pairs(allIssues) do
        table.sort(issues, function(a, b)
            return (SEVERITY_ORDER[a.severity] or 99) < (SEVERITY_ORDER[b.severity] or 99)
        end)
    end
    return allIssues
end

function RA:ComputeHealthScore(issues)
    if not issues or #issues == 0 then
        return 100
    end
    local penalty = 0
    for _, issue in ipairs(issues) do
        local sev = issue.severity
        if sev == RA.SEVERITY_CRITICAL then
            penalty = penalty + 30
        elseif sev == RA.SEVERITY_ERROR then
            penalty = penalty + 10
        elseif sev == RA.SEVERITY_WARNING then
            penalty = penalty + 3
        elseif sev == RA.SEVERITY_INFO then
            penalty = penalty + 1
        end
    end
    return math.max(0, 100 - penalty)
end
