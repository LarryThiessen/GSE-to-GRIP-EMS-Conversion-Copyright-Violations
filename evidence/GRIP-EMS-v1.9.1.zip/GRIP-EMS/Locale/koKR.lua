-- GRIP-EMS: Korean Locale (Machine Translated, Needs Review)
-- All user-facing strings. L["key"] = translated value

local L = LibStub("AceLocale-3.0"):NewLocale("GRIP-EMS", "koKR")
if not L then
    return
end

-- General
L["GRIP - Enhanced Macro Sequencer"] = "GRIP - 향상된 매크로 시퀀서" -- MT

-- Slash command help
L["GEMS_HELP_HEADER"] = "사용 가능한 명령:" -- MT
L["GEMS_HELP_NONE"] = "  /gems - 메인 윈도우 열기 (또는 UI가 로드되지 않으면 도움말 표시)" -- MT
L["GEMS_HELP_HELP"] = "  /gems help - 이 도움말 메시지" -- MT
L["GEMS_HELP_CREATE"] = "  /gems create [이름] - 테스트 시퀸스 만들기 (기본값: TestSeq)" -- MT
L["GEMS_HELP_DELETE"] = "  /gems delete <이름> - 시퀸스 및 매크로 스텁 삭제" -- MT
L["GEMS_HELP_LIST"] = "  /gems list - 활성 시퀸스 목록" -- MT
L["GEMS_HELP_TEST"] = "  /gems test <이름> - 스텝 수동 진행 (디버그)" -- MT
L["GEMS_HELP_RESET"] = "  /gems reset <이름> - 시퀸스를 스텝 1로 리셋" -- MT
L["GEMS_HELP_DEBUG"] = "  /gems debug - 디버그 모드 토글" -- MT
L["GEMS_HELP_STATUS"] = "  /gems status - 엔진 상태 표시" -- MT
L["GEMS_HELP_TESTLOCALE"] = "  /gems testlocale - 지역화 번역 왕복 테스트 실행" -- MT
L["GEMS_HELP_TESTSPELLID"] = "  /gems testspellid - 스펠 ID 해석 테스트 실행" -- MT

-- Slash command responses
L["GEMS_VERSION"] = "|cFF00CC66GRIP|r - 향상된 매크로 시퀨서 |cFFAAAAAAv%s|r" -- MT
L["GEMS_DEBUG_ENABLED"] = "디버그 모드 |cFF00FF00활성화됨|r." -- MT
L["GEMS_DEBUG_DISABLED"] = "디버그 모드 |cFFFF4444비활성화됨|r." -- MT
L["GEMS_UNKNOWN_CMD"] = "알 수 없는 명령 '%s'. 사용 가능한 명령은 /gems help를 입력하세요." -- MT

-- Sequence creation/deletion
L["GEMS_CREATED"] = "시퀨스 |cFF00FF00'%s'|r이 %d개 스텝으로 생성되었습니다 (%s)." -- MT
L["GEMS_DELETED"] = "시퀨스 |cFF00FF00'%s'|r이 삭제되었습니다." -- MT
L["GEMS_ALREADY_EXISTS"] = "시퀨스 '%s'이 이미 존재합니다. 먼저 /gems delete %s로 삭제하세요" -- MT
L["GEMS_NOT_FOUND"] = "시퀨스 '%s'을 찾을 수 없습니다." -- MT
L["GEMS_DELETE_NEED_NAME"] = "사용법: /gems delete <이름>" -- MT

-- Sequence list
L["GEMS_LIST_HEADER"] = "활성 시퀨스 (%d):" -- MT
L["GEMS_LIST_ENTRY"] = "  |cFF00FF00%s|r - %d 스텝, 스텝 %d/%d (%s)" -- MT
L["GEMS_LIST_EMPTY"] = "활성 시퀨스 없음. /gems create를 사용하여 생성하세요." -- MT

-- Sequence test/reset
L["GEMS_TEST_NEED_NAME"] = "사용법: /gems test <이름>" -- MT
L["GEMS_TEST_ADVANCED"] = "|cFF00FF00%s|r: 스텝 %d/%d로 진행했습니다." -- MT
L["GEMS_RESET_NEED_NAME"] = "사용법: /gems reset <이름>" -- MT
L["GEMS_RESET_DONE"] = "|cFF00FF00%s|r: 스텝 1로 리셋되었습니다." -- MT

-- Status
L["GEMS_STATUS_HEADER"] = "--- GRIP-EMS 상태 ---" -- MT
L["GEMS_STATUS_SEQUENCES"] = "활성 시퀨스: %d" -- MT
L["GEMS_STATUS_MACROS"] = "매크로 슬롯: %d/%d 캐릭터별 사용 중" -- MT
L["GEMS_STATUS_KEYDOWN"] = "ActionButtonUseKeyDown: %s (버튼 오버라이드: true)" -- MT
L["GEMS_STATUS_SQW"] = "SpellQueueWindow: %s ms" -- MT
L["GEMS_STATUS_OOC"] = "OOC 큐: %d 대기 중" -- MT

-- Step function descriptions
L["GEMS_STEPFUNC_SEQUENTIAL_DESC"] = "순서대로 스텝을 순환: 1, 2, 3, ..., N, 1, ..." -- MT
L["GEMS_STEPFUNC_RANDOM_DESC"] = "각 누름마다 무작위 스텝 선택" -- MT
L["GEMS_STEPFUNC_PRIORITY_DESC"] = "사전 확장 우선순위: 높은 스텝이 더 자주 나타남 (가중치 라운드 로빈)" -- MT
L["GEMS_STEPFUNC_REVERSEPRIORITY_DESC"] =
    "반전된 우선순위: 나중의 스텝 (목록 하단)이 이전의 스텝보다 더 자주 실행됨" -- MT

-- Validation errors
L["GEMS_STEP_TOO_LONG"] = "스텝 %d이 매크로텍스트 제한을 초과했습니다 (%d자, 최대 %d)." -- MT
L["GEMS_STEP_NIL"] = "스텝 %d이 nil입니다." -- MT
L["GEMS_ERR_NO_NAME"] = "시퀨스 이름이 필요합니다." -- MT

-- Macro manager
L["GEMS_ERR_NO_MACRO_SLOTS"] = "사용 가능한 매크로 슬롯이 없습니다 (%d/%d 캐릭터별 매크로 사용 중)." -- MT
L["GEMS_ERR_MACRO_CREATE_FAILED"] = "시퀨스 '%s'에 대한 매크로 스텁 생성 실패." -- MT
L["GEMS_MACRO_CREATED"] = "매크로 스텁 '%s'이 생성되었습니다 (슬롯 %d)." -- MT
L["GEMS_MACROS_SCANNED"] = "%d개의 기존 GRIP-EMS 매크로 스텁을 회수했습니다." -- MT
L["GEMS_WARN_KP_LINES_TRIMMED"] = "keyPress: %d / %d 줄이 매크로 스텁에 맞음 (255자 제한)" -- MT
L["GEMS_WARN_KR_LINES_TRIMMED"] = "keyRelease: %d / %d 줄이 매크로 스텁에 맞음 (255자 제한)" -- MT
L["GEMS_WARN_KP_STEP_OVERFLOW"] = "keyPress: %d/%d 스텝에 맞음 (%d 스텝이 255자 제한으로 인해 keyPress 없이 실행됨)" -- MT
L["GEMS_KP_STATUS_ALL_FIT"] = "모든 %d 스텝에 맞음" -- MT
L["GEMS_KP_STATUS_PARTIAL"] = "%d/%d 스텝에 맞음 (255자 제한)" -- MT
L["GEMS_KP_STATUS_NONE"] = "어떤 스텝에도 너무 김 (0/%d)" -- MT

-- OOC Queue
L["GEMS_OOC_QUEUED"] = "작업이 전투 외 처리를 위해 큐에 추가되었습니다." -- MT
L["GEMS_OOC_PROCESSED"] = "%d개의 큐 작업을 처리했습니다." -- MT
L["GEMS_OOC_REPLACED"] = "OOC 큐: %s을(를) %s으로(로) 교체" -- MT
L["GEMS_OOC_PRIORITY_PROCESSED"] = "OOC 큐: %d개 항목 처리 (우선순위 순서)" -- MT

-- Keybind manager
L["GEMS_HELP_BIND"] = "  /gems bind <이름> <키> - 시퀨스를 키에 바인딩 (예: CTRL-F12)" -- MT
L["GEMS_HELP_UNBIND"] = "  /gems unbind <이름> - 시퀨스에서 키바인드 제거" -- MT
L["GEMS_HELP_BINDS"] = "  /gems binds - 현재 전문화의 모든 키바인드 목록" -- MT
L["GEMS_BIND_SUCCESS"] = "|cFF00FF00'%s'|r을(를) |cFFFFFF00%s|r에 바인드했습니다. 시퀨스를 실행하려면 키를 누르세요." -- MT
L["GEMS_BIND_NEED_ARGS"] = "사용법: /gems bind <이름> <키> (예: /gems bind TestSeq CTRL-F12)" -- MT
L["GEMS_UNBIND_SUCCESS"] = "|cFF00FF00'%s'|r의 바인드를 해제했습니다." -- MT
L["GEMS_UNBIND_NO_BIND"] = "시퀨스 '%s'에 키바인드가 없습니다." -- MT
L["GEMS_UNBIND_NEED_NAME"] = "사용법: /gems unbind <이름>" -- MT
L["GEMS_BINDS_HEADER"] = "키바인드 (전문화 %d):" -- MT
L["GEMS_BINDS_ENTRY"] = "  |cFFFFFF00%s|r -> |cFF00FF00%s|r" -- MT
L["GEMS_BINDS_EMPTY"] = "설정된 키바인드 없음. /gems bind <이름> <키>를 사용하세요." -- MT
L["GEMS_KEYBINDS_LOADED"] = "전문화 %d의 %d개 키바인드가 로드되었습니다." -- MT
L["GEMS_STATUS_KEYBINDS"] = "키바인드: 현재 전문화를 위한 %d" -- MT

-- Import/Export
L["GEMS_HELP_IMPORT"] = "  /gems import - 임포트 윈도우 열기 (내보내기 문자열 붙여넣기)" -- MT
L["GEMS_HELP_EXPORT"] = "  /gems export <이름> - 시퀨스를 GRIP 문자열로 내보내기" -- MT
L["GEMS_IMPORT_ENTRY"] = "  - '%s' (%d 스텝)" -- MT
L["GEMS_IMPORT_FAILED"] = "임포트 실패: %s" -- MT
L["GEMS_IMPORT_WARNING"] = "경고: %s" -- MT
L["GEMS_IMPORT_USAGE"] = "사용법: /gems import (내보내기 문자열에 대한 붙여넣기 윈도우 열기)" -- MT
L["GEMS_EXPORT_USAGE"] = "사용법: /gems export <이름>" -- MT
L["GEMS_EXPORT_RESULT"] = "내보내기: %s" -- MT
L["GEMS_EXPORT_FAILED"] = "내보내기 실패: %s" -- MT
L["GEMS_IMPORT_PASTE_INSTRUCTIONS"] = "아래에 내보내기 문자열을 붙여넣은 후 임포트를 클릭하세요." -- MT
L["GEMS_IMPORT_PASTE_LABEL"] = "내보내기 문자열" -- MT
L["GEMS_IMPORT_CLEAR"] = "지우기" -- MT
L["GEMS_IMPORT_SHORT_STRING"] = "힌트: /gems import (인수 없음)를 사용하여 긴 문자열에 대한 붙여넣기 윈도우를 열세요." -- MT
L["GEMS_IMPORT_USE_FRAME"] =
    "팁: 문자열이 잘려있을 수 있습니다. |cFFFFFF00/gems import|r를 사용하여 붙여넣기 윈도우를 열세요." -- MT
L["GEMS_IMPORT_UNKNOWN_FORMAT"] = "알 수 없는 임포트 형식" -- MT
L["GEMS_IMPORT_ACTION_SKIPPED"] = "건너뛴 작업: %s" -- MT
L["GEMS_IMPORT_EMBED_SKIPPED"] = "포함된 시퀨스 '%s' 건너뜀 (사용 불가)" -- MT
L["GEMS_IMPORT_PAUSE_CONVERTED"] = "일시 중지가 %d개의 빈 스텝으로 변환됨" -- MT
L["GEMS_IMPORT_INTERVAL_PRESERVED"] = "Preserved %d interleave action(s)" -- MT
L["GEMS_ACTION_INTERLEAVE_EVERY"] = "Every:" -- MT
L["GEMS_ACTION_INTERLEAVE_STEPS"] = "steps" -- MT

-- UI strings (Phase 3)
L["GEMS_HELP_OPEN"] = "  /gems open - 메인 윈도우 열기/닫기" -- MT
L["GEMS_UI_TITLE"] = "GRIP-EMS" -- MT
L["GEMS_UI_SELECT_SEQUENCE"] = "편집할 시퀨스 선택" -- MT
L["GEMS_UI_SEQUENCE_LIST_PLACEHOLDER"] = "시퀨스 목록 로드 중..." -- MT
L["GEMS_UI_NO_SEQUENCES"] = "시퀨스를 찾을 수 없습니다. 생성하거나 임포트하세요." -- MT
L["GEMS_UI_RESIZE"] = "크기 조정" -- MT
L["GEMS_UI_RESIZE_DESC"] = "드래그하여 윈도우 크기 조정" -- MT
L["GEMS_UI_MINIMAP_LEFT"] = "왼쪽 클릭: 열기/닫기" -- MT
L["GEMS_UI_MINIMAP_RIGHT"] = "오른쪽 클릭: 빠른 메뉴" -- MT
L["GEMS_UI_MINIMAP_RIGHTCLICK_SOON"] = "오른쪽 클릭 빠른 메뉴가 곧 추가됩니다." -- MT
L["GEMS_UI_MINIMAP_OOC_QUEUE"] = "OOC 큐" -- MT
L["GEMS_UI_MINIMAP_OOC_PENDING"] = "%d 대기 중" -- MT
L["GEMS_UI_MINIMAP_PARTY_USERS"] = "파티 사용자" -- MT
L["GEMS_UI_MINIMAP_PARTY_NONE"] = "감지된 것 없음" -- MT

-- UI strings (Phase 3A-2): Search
L["GEMS_UI_SEARCH"] = "검색..." -- MT
L["GEMS_UI_SEARCH_DESC"] = "이름으로 시퀨스 필터링" -- MT

-- UI strings (Phase 3A-2): Buttons
L["GEMS_UI_NEW"] = "새로 만들기" -- MT
L["GEMS_UI_NEW_DESC"] = "새 시퀨스 생성" -- MT
L["GEMS_UI_IMPORT_BTN"] = "임포트" -- MT
L["GEMS_UI_IMPORT_BTN_DESC"] = "내보내기 문자열에서 시퀨스 임포트" -- MT

-- UI strings (Phase 3A-2): Context menu
L["GEMS_UI_DUPLICATE"] = "복제" -- MT
L["GEMS_UI_DELETE"] = "삭제" -- MT
L["GEMS_UI_EXPORT_CTX"] = "내보내기" -- MT
L["GEMS_UI_RENAME"] = "이름 바꾸기" -- MT

-- UI strings (Phase 3A-2): Editor header
L["GEMS_UI_SEQ_ICON"] = "아이콘" -- MT
L["GEMS_UI_STEP_FUNCTION"] = "스텝 함수" -- MT
L["GEMS_UI_RESET_COMBAT"] = "전투 종료 시 리셋" -- MT
L["GEMS_UI_RESET_COMBAT_DESC"] = "전투가 종료되면 스텝 카운터를 리셋" -- MT
L["GEMS_UI_RESET_TARGET"] = "대상 변경 시 리셋" -- MT
L["GEMS_UI_RESET_TARGET_DESC"] = "대상이 변경되면 스텝 카운터를 리셋 (전투 외만)" -- MT
L["GEMS_UI_RESET_GEAR"] = "장비 변경" -- MT
L["GEMS_UI_RESET_GEAR_DESC"] = "장비가 변경되면 스텝 카운터를 리셋 (전투 외만)" -- MT
L["GEMS_UI_RESET_SPEC"] = "전문화 변경" -- MT
L["GEMS_UI_RESET_SPEC_DESC"] = "전문화가 변경되면 스텝 카운터를 리셋" -- MT
L["GEMS_UI_RESET_TIMER"] = "타이머 (초)" -- MT
L["GEMS_UI_RESET_TIMER_DESC"] = "이 초 후 스텝 카운터를 리셋 (0 = 비활성화)" -- MT
L["GEMS_UI_KEYPRESS"] = "KeyPress" -- MT
L["GEMS_UI_KEYPRESS_DESC"] =
    "각 스텝을 실행하기 전에 키 다운에서 실행되는 명령 (예: /stopmacro [channeling]). 전체가 255자 이내일 때 각 스텝의 매크로텍스트에 결합됩니다. 제한을 초과하는 스텝은 KeyPress 없이 실행됩니다 -- 프리뷰 탭에서 어떤 스텝이 맞는지 확인하세요." -- MT
L["GEMS_UI_KEYRELEASE"] = "KeyRelease" -- MT
L["GEMS_UI_KEYRELEASE_DESC"] =
    "각 스텝을 실행한 후 키 업에서 실행되는 명령. 전체가 255자 이내일 때 각 스텝의 매크로텍스트에 결합됩니다. 제한을 초과하는 스텝은 KeyRelease 없이 실행됩니다 -- 프리뷰 탭에서 어떤 스텝이 맞는지 확인하세요." -- MT

-- UI strings: Metadata section
L["GEMS_EDITOR_METADATA"] = "메타데이터" -- MT
L["GEMS_EDITOR_METADATA_AUTHOR"] = "작성자" -- MT
L["GEMS_EDITOR_METADATA_DESCRIPTION"] = "설명" -- MT
L["GEMS_EDITOR_METADATA_HELP"] = "도움말 텍스트" -- MT
L["GEMS_EDITOR_METADATA_HELPLINK"] = "도움말 링크" -- MT
L["GEMS_EDITOR_METADATA_CLASS"] = "클래스" -- MT
L["GEMS_EDITOR_METADATA_SPEC"] = "전문화" -- MT
L["GEMS_EDITOR_METADATA_CREATED"] = "생성됨" -- MT
L["GEMS_EDITOR_METADATA_UPDATED"] = "업데이트됨" -- MT

-- UI strings: Dependencies section
L["GEMS_DEPS_HEADER"] = "의존성" -- MT
L["GEMS_DEPS_VARIABLES"] = "변수" -- MT
L["GEMS_DEPS_SEQUENCES"] = "시퀨스" -- MT
L["GEMS_DEPS_EMBEDDED_BY"] = "포함된 것:" -- MT
L["GEMS_DEPS_NONE"] = "(없음)" -- MT
L["GEMS_DEPS_NOT_EMBEDDED"] = "어떤 시퀨스에 포함되지 않음" -- MT

-- UI strings (Phase 3A-2): Tabs
L["GEMS_UI_TAB_STEPS"] = "스텝" -- MT
L["GEMS_UI_TAB_KEYBIND"] = "키바인드" -- MT
L["GEMS_UI_TAB_VARIABLES"] = "변수" -- MT
L["GEMS_UI_TAB_RAW"] = "원본" -- MT
L["GEMS_UI_TAB_COMING_SOON"] = "곧 출시 예정" -- MT

-- UI strings (Phase 3A-2): Step list
L["GEMS_UI_STEP_NUM"] = "#%d" -- MT
L["GEMS_UI_NO_STEPS"] = "정의된 스텝 없음." -- MT
L["GEMS_UI_ADD_STEP_HINT"] = "스텝 없음. '+ 추가'를 클릭하여 생성하세요." -- MT

-- UI strings (Phase 3A-2): Dialogs
L["GEMS_UI_NEW_SEQ_DESC"] = "새 시퀨스의 이름을 입력하세요:" -- MT
L["GEMS_UI_DELETE_CONFIRM"] = "'%s'을(를) 삭제하시겠습니까? 이는 취소할 수 없습니다." -- MT
L["GEMS_UI_DUP_DESC"] = "복제본의 이름을 입력하세요:" -- MT
L["GEMS_UI_RENAME_DESC"] = "새 이름을 입력하세요:" -- MT
L["GEMS_UI_NAME_EXISTS"] = "'%s'이라는 시퀨스가 이미 존재합니다." -- MT
L["GEMS_UI_NAME_EMPTY"] = "시퀨스 이름은 비워둘 수 없습니다." -- MT

-- UI strings (Phase 3A-2): Status text in rows
L["GEMS_UI_ROW_SUBTITLE"] = "%s | %d 스텝" -- MT

-- UI strings (Phase 3A-2): Sort
L["GEMS_UI_SORT_ALPHA"] = "A-Z" -- MT
L["GEMS_UI_SORT_CLASS"] = "클래스" -- MT
L["GEMS_UI_SORT_UPDATED"] = "최근" -- MT
L["GEMS_UI_SORT_ALPHA_TIP"] = "알파벳순" -- MT
L["GEMS_UI_SORT_CLASS_TIP"] = "클래스별" -- MT
L["GEMS_UI_SORT_UPDATED_TIP"] = "최근 업데이트됨" -- MT
L["GEMS_UI_SORT_HINT"] = "정렬" -- MT
L["GEMS_UI_SORT_CYCLE"] = "클릭하여 정렬 모드 순환" -- MT

-- Spell validation (v1.1.0)
L["GEMS_SPELL_WARN_BANNER"] = "이 시퀨스에서 %d개의 스펠이 유효하지 않을 수 있습니다" -- MT
L["GEMS_SPELL_VALIDATE_SUMMARY"] = "%d개 시퀨스 확인됨: %d개 정상, %d개 경고 있음" -- MT
L["GEMS_SPELL_VALIDATE_CLEAN"] = "모든 시퀨스가 검증됨 -- 문제 없음" -- MT
L["GEMS_SPELL_VALIDATE_SEQ"] = "  %s: %d개 알 수 없음, %d개 특성 게이트됨" -- MT
L["GEMS_SPELL_STATUS_LABEL"] = "%d개 스펠이 유효하지 않을 수 있음" -- MT
L["GEMS_SPELL_INFO_LABEL"] = "%d개 알려짐 하지만 학습되지 않음" -- MT
L["GEMS_IMPORT_FREEFORM_WARN"] =
    "'%s': %d개 스텝에 지역화 간 자동 변환할 수 없는 원본 매크로 명령 포함" -- MT
L["GEMS_IMPORT_FREEFORM_LABEL"] = "%d개 자유형" -- MT
L["GEMS_IMPORT_ICON_AUTO"] = "(자동 감지됨)" -- MT
L["GEMS_IMPORT_PICK_AUTO"] = "[자동]" -- MT
L["GEMS_IMPORT_PICK_VAR_DEPS"] = "%d개 변수 사용" -- MT
L["GEMS_SPELL_TOOLTIP_UNKNOWN"] = "찾을 수 없음: %s" -- MT
L["GEMS_SPELL_TOOLTIP_KNOWN"] = "주문서에 없음: %s" -- MT
L["GEMS_SPELL_TOOLTIP_COSMETIC"] = "|cff888888#showtooltip: %s|r" -- MT

-- Rotation Preview (v1.1.0)
L["GEMS_PLUGIN_LOADED"] = "플러그인 시퀨스가 로드되었습니다: %s" -- MT
L["GEMS_PLUGIN_NOT_FOUND"] = "플러그인이 등록되지 않았습니다: %s" -- MT
L["GEMS_PLUGIN_REGISTERED"] = "플러그인 등록됨: %s v%s (%d 시퀨스)" -- MT
L["GEMS_PLUGIN_SKIP_EXISTS"] = "플러그인 %s: '%s' 건너뜀 (사용자 버전 존재)" -- MT

L["GEMS_PREVIEW_ICONS"] = "아이콘" -- MT
L["GEMS_PREVIEW_TEXT"] = "텍스트" -- MT
L["GEMS_PREVIEW_TOGGLE_TIP"] = "프리뷰 모드 전환" -- MT
L["GEMS_PREVIEW_RANDOM_HINT"] = "무작위 -- 이 중 하나가 실행될 수 있습니다" -- MT
L["GEMS_PREVIEW_STEP_TOOLTIP"] = "스텝 %d: %s" -- MT
L["GEMS_PREVIEW_SPELL_TOOLTIP"] = "스펠: %s" -- MT
L["GEMS_PREVIEW_COMPILED"] = "컴파일됨" -- MT
L["GEMS_PREVIEW_COMPILED_TIP"] = "스텝별 컴파일된 매크로텍스트 표시 (WoW가 실행하는 것)" -- MT
L["GEMS_PREVIEW_KP_FIT"] = "%d/%d 스텝이 keyPress+keyRelease에 맞음" -- MT
L["GEMS_PREVIEW_KP_DROPPED"] = "빨간 스텝은 keyPress/keyRelease이 드롭됨 (오버플로우)" -- MT
L["GEMS_PREVIEW_COPY"] = "복사" -- MT
L["GEMS_PREVIEW_COPY_TIP"] = "로테이션 프리뷰를 클립보드에 복사" -- MT

-- UI strings (Phase 3A-2): Editor misc
L["GEMS_UI_ICON_HINT"] = "클릭하여 아이콘 변경" -- MT
L["GEMS_UI_DUPLICATE_FAILED"] = "복제 실패." -- MT
L["GEMS_UI_COPY_SUFFIX"] = "_사본" -- MT

-- UI strings (Phase 3A-2): Step function labels
L["GEMS_UI_SF_SEQUENTIAL"] = "순차" -- MT
L["GEMS_UI_SF_RANDOM"] = "무작위" -- MT
L["GEMS_UI_SF_PRIORITY"] = "우선순위" -- MT
L["GEMS_UI_SF_REVERSEPRIORITY"] = "역순 우선순위" -- MT

-- UI strings (Phase 3B-1): Step editor
L["GEMS_UI_ADD_STEP"] = "+ 추가" -- MT
L["GEMS_UI_ADD_STEP_DESC"] = "선택된 스텝 다음에 새 빈 스텝 추가" -- MT
L["GEMS_UI_DUP_STEP"] = "복제" -- MT
L["GEMS_UI_DUP_STEP_DESC"] = "선택된 스텝 복제" -- MT
L["GEMS_UI_MOVE_UP"] = "위로" -- MT
L["GEMS_UI_MOVE_UP_DESC"] = "선택된 스텝을 위로 이동" -- MT
L["GEMS_UI_MOVE_DOWN"] = "아래로" -- MT
L["GEMS_UI_MOVE_DOWN_DESC"] = "선택된 스텝을 아래로 이동" -- MT
L["GEMS_UI_DEL_STEP"] = "삭제" -- MT
L["GEMS_UI_DEL_STEP_DESC"] = "선택된 스텝 삭제" -- MT
L["GEMS_UI_STEP_HEADER"] = "스텝 %d:" -- MT
L["GEMS_UI_SELECT_STEP"] = "편집할 스텝 선택" -- MT
L["GEMS_UI_DELETE_STEP_CONFIRM"] = "스텝 %d을 삭제하시겠습니까? 이는 취소할 수 없습니다." -- MT
L["GEMS_UI_CTX_DUP_STEP"] = "스텝 복제" -- MT
L["GEMS_UI_CTX_MOVE_UP"] = "위로 이동" -- MT
L["GEMS_UI_CTX_MOVE_DOWN"] = "아래로 이동" -- MT
L["GEMS_UI_CTX_DELETE_STEP"] = "스텝 삭제" -- MT
L["GEMS_UI_DRAG_HANDLE_DESC"] = "드래그하여 재정렬" -- MT
L["GEMS_UI_EXPORT_BTN_EDITOR"] = "내보내기" -- MT
L["GEMS_UI_EXPORT_BTN_EDITOR_DESC"] = "이 시퀨스를 GRIP 문자열로 내보내기" -- MT
L["GEMS_UI_NAME_TOOLTIP"] = "시퀨스 이름" -- MT
L["GEMS_UI_NAME_EDIT_HINT"] = "클릭하여 이름 바꾸기. Enter를 눌러 확인, Escape를 눌러 취소." -- MT
L["GEMS_UI_SAVE_PROMPT"] = "'%s'에 변경 사항을 저장하시겠습니까?" -- MT
L["GEMS_UI_SAVE"] = "저장" -- MT
L["GEMS_UI_SAVE_BTN_DESC"] = "이 시퀨스에 변경 사항 저장" -- MT
L["GEMS_UI_DISCARD"] = "폐기" -- MT
L["GEMS_UI_DISCARD_BTN_DESC"] = "변경 사항을 폐기하고 마지막으로 저장한 상태로 되돌리기" -- MT
L["GEMS_UI_SAVE_COMBAT"] = "전투 중에는 사용할 수 없음" -- MT

-- Version bar (UX-4)
L["GEMS_VERSION_OF"] = "버전 %d / %d" -- MT
L["GEMS_VERSION_LABEL"] = "버전 %d" -- MT
L["GEMS_VERSION_DEFAULT_SUFFIX"] = " (기본값)" -- MT
L["GEMS_VERSION_DEFAULT_MARKER"] = " (*)" -- MT
L["GEMS_VERSION_TOOLTIP_TITLE"] = "버전" -- MT
L["GEMS_VERSION_TOOLTIP_DESC"] = "편집할 버전 선택" -- MT
L["GEMS_VERSION_ADD_TITLE"] = "버전 추가" -- MT
L["GEMS_VERSION_ADD_DESC"] = "새 빈 버전 생성" -- MT
L["GEMS_VERSION_DUP_TITLE"] = "버전 복제" -- MT
L["GEMS_VERSION_DUP_DESC"] = "현재 버전을 새 버전으로 복사" -- MT
L["GEMS_VERSION_DEL_TITLE"] = "버전 삭제" -- MT
L["GEMS_VERSION_DEL_DESC"] = "현재 버전 제거" -- MT
L["GEMS_VERSION_DEFAULT_TITLE"] = "기본값 설정" -- MT
L["GEMS_VERSION_DEFAULT_DESC"] = "현재 버전을 실행의 기본값으로 설정" -- MT

-- Phase 3B-2: Keybind tab
L["GEMS_UI_CURRENT_KEYBIND"] = "현재 키바인드" -- MT
L["GEMS_UI_KEYBIND_DISPLAY_NONE"] = "없음" -- MT
L["GEMS_UI_SET_KEYBIND"] = "키바인드 설정" -- MT
L["GEMS_UI_CHANGE_KEYBIND"] = "변경" -- MT
L["GEMS_UI_CLEAR_KEYBIND"] = "지우기" -- MT
L["GEMS_UI_PRESS_KEY"] = "키를 누르세요..." -- MT
L["GEMS_UI_KEYBIND_HINT"] =
    "키바인드는 GRIP-EMS 프로필에 저장된 전문화별 오버라이드 바인드입니다. WoW 키바인드 설정을 수정하지 않습니다." -- MT
L["GEMS_UI_CAPTURE_COMBAT"] = "전투 중에는 키바인드를 캡처할 수 없습니다." -- MT
L["GEMS_UI_SPEC_KEYBINDS"] = "전문화별 키바인드" -- MT
L["GEMS_UI_CURRENT_SPEC"] = "(현재)" -- MT
L["GEMS_UI_LOADOUT_COMING_SOON"] = "특성 로드아웃별 키바인드: 곧 출시 예정" -- MT
L["GEMS_UI_CAPTURE_ESC_HINT"] = "(ESC를 눌러 취소)" -- MT
L["GEMS_UI_KEYBIND_CONFLICT"] = "%s이 '%s'에 바인드되어 있었고 재할당되었습니다." -- MT
L["GEMS_UI_KEYBIND_CP_CONFLICT"] = "%s이 ConsolePort에서 '%s'에 바인드되어 있습니다. 활성 시퀨스 중에 오버라이드됩니다." -- MT
L["GEMS_UI_GAMEPAD_HINT"] = "컨트롤러 감지됨 -- 캡처에서 게임패드 버튼 지원" -- MT

-- Phase 3B-2: Macros tab
L["GEMS_UI_TAB_MACROS"] = "매크로" -- MT
L["GEMS_UI_MACRO_STUB_SECTION"] = "매크로 스텁" -- MT
L["GEMS_UI_STUB_INFO"] = "%s (슬롯 %d)" -- MT
L["GEMS_UI_STUB_NONE"] = "매크로 스텁 없음" -- MT
L["GEMS_UI_SLOTS_USED"] = "%d/%d 캐릭터별 매크로 슬롯 사용 중" -- MT
L["GEMS_UI_REFRESH_STUBS"] = "새로고침" -- MT
L["GEMS_UI_REFRESH_STUBS_DESC"] = "기존 GRIP-EMS 매크로 스텁 다시 스캔" -- MT
L["GEMS_UI_CLEAN_ORPHANS"] = "고아 정리" -- MT
L["GEMS_UI_CLEAN_ORPHANS_DESC"] = "더 이상 존재하지 않는 시퀨스의 매크로 스텁 삭제" -- MT
L["GEMS_UI_CLEAN_CONFIRM"] = "%d개 고아 매크로 스텁을 삭제하시겠습니까? 이는 취소할 수 없습니다." -- MT
L["GEMS_UI_ORPHANS_CLEANED"] = "%d개 고아 매크로 스텁을 정리했습니다." -- MT
L["GEMS_UI_NO_ORPHANS"] = "고아 스텁을 찾을 수 없습니다." -- MT
L["GEMS_UI_STUB_LIST_HEADER"] = "모든 스텁 (%d)" -- MT
L["GEMS_UI_NO_STUBS"] = "매크로 스텁을 찾을 수 없습니다." -- MT
L["GEMS_UI_STUBS_MORE"] = "%d개 이상의 스텁이 표시되지 않음" -- MT

-- Phase 3B-2: Priority preview

-- Phase 3C-1: Spell autocomplete

-- Phase 3C-2: Icon picker
L["GEMS_UI_ICON_PICKER_TITLE"] = "아이콘 선택" -- MT
L["GEMS_UI_AUTO_DETECT"] = "자동 감지" -- MT
L["GEMS_UI_AUTO_DETECT_DESC"] = "첫 번째 /cast 스펠에서 아이콘 자동 감지" -- MT

-- Context version selection (T2-1)
L["GEMS_CONTEXT_CHANGED"] = "컨텍스트 변경됨: %s" -- MT
L["GEMS_CONTEXT_NONE_LABEL"] = "없음" -- MT
L["GEMS_CONTEXT_RELOAD"] = "컨텍스트 전환이 %d개 시퀨스를 다시 로드했습니다" -- MT

-- Context tab (T2-1b)
L["GEMS_UI_TAB_CONTEXT"] = "컨텍스트" -- MT
L["GEMS_CONTEXT_DEFAULT_LABEL"] = "기본값 버전: %d" -- MT
L["GEMS_CONTEXT_CURRENT_INFO"] = "현재 컨텍스트: %s" -- MT
L["GEMS_CONTEXT_VIEWING"] = "버전 %d에 대한 할당" -- MT
L["GEMS_CONTEXT_NO_VERSIONS"] = "컨텍스트 오버라이드를 구성하려면 두 번째 버전을 추가하세요." -- MT
L["GEMS_CONTEXT_HINT"] =
    "이 버전이 활성화되어야 하는 컨텐츠 유형을 확인하세요. 선택되지 않은 컨텍스트는 더 광범위한 카테고리로 돌아갑니다 (예: Mythic+는 던전으로, 그 다음 기본값으로 돌아감)." -- MT
L["GEMS_CONTEXT_CONFLICT_MSG"] = "%s이 현재 버전 %d에 할당되어 있습니다.\n버전 %d으로 재할당하시겠습니까?" -- MT
L["GEMS_CONTEXT_ASSIGNED_OTHER"] = "(버전 %d)" -- MT
L["GEMS_CONTEXT_GROUP_RAIDS"] = "레이드" -- MT
L["GEMS_CONTEXT_GROUP_DUNGEONS"] = "던전" -- MT
L["GEMS_CONTEXT_GROUP_PVP"] = "PvP" -- MT
L["GEMS_CONTEXT_GROUP_ARENA_MAPS"] = "경기장 맵" -- MT
L["GEMS_CONTEXT_GROUP_BG_MAPS"] = "전장 맵" -- MT
L["GEMS_CONTEXT_GROUP_OTHER"] = "기타" -- MT
L["GEMS_CONTEXT_WRONG_VERSION"] = "%s이 버전 %d에 할당되어 있습니다. 수정하려면 해당 버전으로 전환하세요." -- MT

-- Context group buttons and fallback chain (v1.2.0 S19)
L["GEMS_CONTEXT_SELECT_ALL"] = "모두" -- MT
L["GEMS_CONTEXT_CLEAR_ALL"] = "없음" -- MT
L["GEMS_CONTEXT_FALLBACK_NONE"] = "활성 컨텍스트 없음 -- 기본값 버전 %d" -- MT
L["GEMS_CONTEXT_FALLBACK_MATCH"] = " (v%d)" -- MT
L["GEMS_CONTEXT_FALLBACK_DEFAULT"] = "기본값" -- MT
L["GEMS_CONTEXT_FALLBACK_SEP"] = " > " -- MT
L["GEMS_SETTINGS_CONTEXT_HEADER"] = "컨텍스트 감지" -- MT
L["GEMS_SETTINGS_CONTEXT_DESC"] = "자동 버전 전환을 위한 컨텐츠 유형을 감지하는 방법을 구성하세요." -- MT
L["GEMS_SETTINGS_MPLUS_MID"] = "Mythic+ 중간 티어" -- MT
L["GEMS_SETTINGS_MPLUS_MID_DESC"] = "Mythic+ 컨텍스트가 저 티어에서 중간 티어로 전환되는 키 레벨." -- MT
L["GEMS_SETTINGS_MPLUS_HIGH"] = "Mythic+ 높은 티어" -- MT
L["GEMS_SETTINGS_MPLUS_HIGH_DESC"] = "Mythic+ 컨텍스트가 중간 티어에서 높은 티어로 전환되는 키 레벨." -- MT
L["GEMS_SETTINGS_DELVES_HIGH"] = "Delves 높은 티어" -- MT
L["GEMS_SETTINGS_DELVES_HIGH_DESC"] = "컨텍스트가 저 티어에서 높은 티어로 전환되는 Delve 티어." -- MT

-- Context migration (T2-3)

-- Phase 2B: Migration
L["GEMS_HELP_MIGRATE"] = "  /gems migrate - 다른 시퀨서에서 시퀨스 마이그레이션" -- MT
L["GEMS_UI_MIGRATE_BTN"] = "마이그레이션" -- MT
L["GEMS_UI_MIGRATE_BTN_DESC"] = "다른 시퀨서에서 모든 시퀨스 임포트" -- MT
L["GEMS_MIGRATE_NO_SOURCE"] = "마이그레이션을 위한 호환 시퀨서를 찾을 수 없습니다." -- MT
L["GEMS_MIGRATE_SOURCE_DISABLED"] =
    "호환 시퀨서를 찾았지만 비활성화되어 있습니다. 애드온 목록에서 활성화하고 /reload하여 마이그레이션하세요." -- MT
L["GEMS_MIGRATE_FAILED"] = "마이그레이션 실패: %s" -- MT
L["GEMS_MIGRATE_CONFIRM"] =
    "이전 시퀨서에서 모든 시퀨스를 마이그레이션하시겠습니까?\n\n%d개 시퀨스를 찾았습니다. 같은 이름의 기존 시퀨스는 건너뜁니다." -- MT
L["GEMS_DELETE_COMBAT"] = "전투 중에는 시퀨스를 삭제할 수 없습니다." -- MT
L["GEMS_MIGRATE_COMBAT"] = "전투 중에는 마이그레이션할 수 없습니다. 전투 후에 다시 시도하세요." -- MT
L["GEMS_MIGRATE_EMPTY"] = "소스 라이브러리에서 찾은 시퀨스가 없습니다." -- MT
L["GEMS_MIGRATE_SKIPPED"] = "%s (이미 존재, 건너뜀)" -- MT
L["GEMS_MIGRATE_KEYBINDS"] = "키바인드: %d 마이그레이션됨, %d 건너뜀, %d 충돌" -- MT
L["GEMS_MIGRATE_AO_WARNING"] =
    "%d개 액션바 오버라이드를 찾았지만 마이그레이션하지 않았습니다. EMS는 키바인드 오버라이드를 사용합니다. /gems bind를 통해 이 시퀨스를 다시 바인드하세요." -- MT

-- Phase 2C: Export frame
L["GEMS_EXPORT_FRAME_LABEL"] = "내보냄: %s" -- MT
L["GEMS_EXPORT_FRAME_HINT"] = "Ctrl+C를 눌러 복사한 후 다른 플레이어의 임포트 윈도우에 붙여넣으세요." -- MT

-- Phase 3C-3: Variable system
L["GEMS_VAR_EVAL_ERROR"] = "변수 '%s' 평가 실패: %s" -- MT
L["GEMS_VAR_INVALID_NAME"] = "변수 이름은 영숫자여야 합니다 (a-z, 0-9, 언더스코어)" -- MT
L["GEMS_VAR_NAME_TOO_LONG"] = "변수 이름이 %d자를 초과합니다" -- MT
L["GEMS_VAR_FUNC_TOO_LONG"] = "변수 함수가 %d자를 초과합니다" -- MT
L["GEMS_VAR_NAME_EMPTY"] = "변수 이름은 비워둘 수 없습니다" -- MT
L["GEMS_VAR_NAME_EXISTS"] = "변수 '%s'이 이미 존재합니다" -- MT
L["GEMS_VAR_DELETED"] = "변수 '%s'이 삭제되었습니다" -- MT
L["GEMS_VAR_SAVED"] = "변수 '%s'이 저장되었습니다" -- MT
L["GEMS_VAR_IMPORT_PAUSE"] = "일시 중지가 변수로 변환되어 주석 처리됨" -- MT
L["GEMS_VAR_IMPORT_SKIPPED"] = "%d개 변수를 건너뜀 (이미 존재)." -- MT
L["GEMS_VAR_RECOMPILE"] = "'%s' 다시 컴파일 중 (변수 변경됨)" -- MT

-- Phase 3C-3b: Variables Tab UI
L["GEMS_VAR_TAB_EMPTY"] = "정의된 변수 없음. 새로 만들기를 클릭하여 생성하세요." -- MT
L["GEMS_VAR_NEW"] = "새 변수" -- MT
L["GEMS_VAR_NAME_LABEL"] = "이름" -- MT
L["GEMS_VAR_FUNC_LABEL"] = "함수 본문" -- MT
L["GEMS_VAR_FUNC_PLACEHOLDER"] = "return GetHaste() > 20" -- MT
L["GEMS_VAR_EVENTS_LABEL"] = "이벤트 (쉼표로 구분)" -- MT
L["GEMS_VAR_EVENTS_PLACEHOLDER"] = "SPELL_CAST_SUCCESS, UNIT_AURA" -- MT
L["GEMS_VAR_COMMENTS_LABEL"] = "댓글" -- MT
L["GEMS_VAR_DISABLED_LABEL"] = "비활성화됨" -- MT
L["GEMS_VAR_SAVE"] = "저장" -- MT
L["GEMS_VAR_TEST"] = "테스트" -- MT
L["GEMS_VAR_TEST_RESULT"] = "변수 '%s' = %s" -- MT
L["GEMS_VAR_TEST_ERROR"] = "변수 '%s' 오류: %s" -- MT
L["GEMS_VAR_VALID"] = "유효함" -- MT
L["GEMS_VAR_INVALID"] = "오류: %s" -- MT
L["GEMS_VAR_USED_BY"] = "사용된 것: %s" -- MT
L["GEMS_VAR_NOT_USED"] = "어떤 시퀨스에서도 참조되지 않음" -- MT
L["GEMS_VAR_DELETE_CONFIRM"] = "변수 '%s'을 삭제하시겠습니까?" -- MT
L["GEMS_VAR_DELETE_REFS_WARN"] = "이 변수는 %d개 시퀨스에서 사용됩니다. 계속 삭제하시겠습니까?" -- MT
L["GEMS_VAR_RENAME"] = "변수 이름 바꾸기" -- MT
L["GEMS_VAR_EVENTS_BROWSE"] = "이벤트 찾아보기" -- MT
L["GEMS_VAR_NEW_DESC"] = "새 변수 생성" -- MT
L["GEMS_VAR_SAVE_DESC"] = "이 변수에 변경 사항 저장" -- MT
L["GEMS_VAR_TEST_DESC"] = "함수를 평가하고 결과를 표시" -- MT
L["GEMS_VAR_DELETE_DESC"] = "이 변수를 영구 삭제" -- MT
L["GEMS_VAR_EVENTS_BROWSE_TIP"] = "클릭하여 사용 가능한 이벤트 찾아보기" -- MT
L["GEMS_VAR_EVENTS_ENABLED_DESC"] =
    "선택 취소된 경우, 이 변수의 이벤트 트리거가 일시 중지됩니다. 이벤트 목록은 보존됩니다." -- MT
L["GEMS_VAR_LOCALE_WARN"] = "변수가 스펠 이름 '%s'로 평가됩니다. 지역화 안전성을 위해 다음을 사용하세요: %s" -- MT
L["GEMS_VAR_FUNC_HELP"] =
    "지역화 안전 변수의 경우, 하드코딩된 스펠 이름 문자열 대신 C_Spell.GetSpellName(spellID)을 사용하세요. 예: '불덩이' 대신 C_Spell.GetSpellName(133)을 사용하세요." -- MT

-- Raw tab
L["GEMS_RAW_TITLE"] = "원본 데이터" -- MT
L["GEMS_RAW_EDIT"] = "편집" -- MT
L["GEMS_RAW_APPLY"] = "적용" -- MT
L["GEMS_RAW_CANCEL"] = "취소" -- MT
L["GEMS_RAW_INVALID"] = "유효하지 않음: %s" -- MT
L["GEMS_RAW_MISSING_FIELD"] = "필수 필드 누락: %s" -- MT
L["GEMS_RAW_APPLIED"] = "변경 사항이 적용되었습니다" -- MT
L["GEMS_RAW_NAME_IGNORED"] = "이름 변경이 무시되었습니다. 컨텍스트 메뉴에서 이름 바꾸기를 사용하세요." -- MT
L["GEMS_RAW_NO_SEQUENCE"] = "선택된 시퀨스 없음" -- MT
L["GEMS_RAW_READONLY_HINT"] = "편집하려면 편집을 클릭하세요. 변경 사항은 적용 전에 검증됩니다." -- MT
L["GEMS_RAW_CANCEL_DESC"] = "변경 사항을 적용하지 않고 닫기" -- MT
L["GEMS_RAW_EDIT_DESC"] = "Lua 테이블을 시퀨스 데이터로 구문 분석하고 적용" -- MT

-- Step action bar (Save + hint)
L["GEMS_STEP_SAVE"] = "저장" -- MT
L["GEMS_STEP_SAVE_DESC"] = "모든 스텝 변경 사항을 시퀨스에 저장" -- MT
L["GEMS_STEP_UNSAVED_HINT"] = "저장되지 않은 변경 사항" -- MT

-- Engine debug
L["GEMS_SEQ_ACTIVATED"] = "시퀨스 '%s'이 활성화되었습니다 (%d 스텝)." -- MT
L["GEMS_SEQ_DEACTIVATED"] = "시퀨스 '%s'이 비활성화되었습니다." -- MT
L["GEMS_STEP_RESET"] = "시퀨스 '%s'이 스텝 1로 리셋되었습니다." -- MT
L["GEMS_STEP_ADVANCED"] = "시퀨스 '%s'이 스텝 %d/%d로 진행했습니다." -- MT
L["GEMS_COMBAT_RESET"] = "시퀨스 '%s'이 리셋되었습니다 (전투 중단)." -- MT
L["GEMS_TARGET_RESET"] = "시퀨스 '%s'이 리셋되었습니다 (대상 변경)." -- MT
L["GEMS_GEAR_RESET"] = "%s: 장비 변경 시 리셋 (스텝 %d, 슬롯 %d)." -- MT
L["GEMS_SPEC_RESET"] = "%s: 전문화 변경 시 리셋 (스텝 %d)." -- MT
L["GEMS_RESTORED"] = "%d개의 저장된 시퀨스를 복원했습니다." -- MT
L["GEMS_KEYBINDS_SUSPENDED"] = "키바인드 일시 중지됨: %s" -- MT
L["GEMS_KEYBINDS_RESTORED"] = "키바인드 복원됨: %s" -- MT

-- Settings panel (T1-1 + T1-7)
L["GEMS_HELP_SETTINGS"] = "  /gems settings|config|options - 설정 패널 열기" -- MT
L["GEMS_SETTINGS_HEADER_DESC"] = "GRIP - 향상된 매크로 시퀨서 동작 및 표시를 구성하세요." -- MT
L["GEMS_SETTINGS_GENERAL"] = "일반" -- MT
L["GEMS_SETTINGS_OOC_DELAY"] = "OOC 큐 지연 (초)" -- MT
L["GEMS_SETTINGS_OOC_DELAY_DESC"] =
    "전투 외 큐 폴링 간의 초. 낮을수록 = 전투 후 큐 작업 처리 더 빠름. /reload 후에 적용됩니다. 기본값: 7초." -- MT
L["GEMS_SETTINGS_RESET_OOC"] = "전투 종료 시 리셋 (기본값)" -- MT
L["GEMS_SETTINGS_RESET_OOC_DESC"] =
    "새 시퀨스 생성 시 '전투 종료 시 리셋'의 기본값. 기존 시퀨스는 영향을 받지 않습니다." -- MT
L["GEMS_SETTINGS_UI"] = "표시" -- MT
L["GEMS_SETTINGS_HIDE_LOGIN"] = "로그인 메시지 숨기기" -- MT
L["GEMS_SETTINGS_HIDE_LOGIN_DESC"] = "로그인 시 'GRIP-EMS vX.X' 메시지 억제." -- MT
L["GEMS_SETTINGS_DEBUG"] = "Debug 모드" -- MT
L["GEMS_SETTINGS_DEBUG_DESC"] = "채팅에 디버그 메시지를 표시합니다. /gems debug를 통해 토글할 수도 있습니다." -- MT
L["GEMS_SETTINGS_INFO"] = "정보" -- MT
L["GEMS_SETTINGS_VERSION_INFO"] = "GRIP-EMS v%s | %d개 활성 시퀨스" -- MT

-- About info (T1-5)
L["GEMS_ABOUT_AUTHOR"] = "작성자: Sataana (MrSataana)" -- MT
L["GEMS_ABOUT_LINKS"] =
    "가이드: jesperlive.github.io/grip-ems-guide/\nCurseForge: curseforge.com/wow/addons/grip-enhanced-macro-sequencer\nWago: addons.wago.io/addons/qGZODqNd\nWoWInterface: wowinterface.com/downloads/info27081" -- MT
L["GEMS_ABOUT_KEYBINDS"] = "활성 키바인드: %d" -- MT
L["GEMS_ABOUT_OOC_QUEUE"] = "OOC 큐: %d 대기 중" -- MT
L["GEMS_ABOUT_SOURCE_STATUS"] = "마이그레이션 소스: %s" -- MT
L["GEMS_ABOUT_MACRO_SLOTS"] = "매크로 슬롯: %d / %d 캐릭터별" -- MT
L["GEMS_UI_ACTIVE_SEQUENCES_LABEL"] = "활성 시퀨스" -- MT
L["GEMS_UI_CONTEXT_LABEL"] = "컨텍스트" -- MT
L["GEMS_LOGIN_ACTIVE"] = "|cFF888888  %d개 활성 시퀨스|r" -- MT
L["GEMS_UI_SETTINGS_BTN"] = "설정" -- MT
L["GEMS_UI_SETTINGS_BTN_DESC"] = "GRIP-EMS 설정 패널 열기" -- MT

-- Migration report (T1-9)
L["GEMS_REPORT_HEADER_MIGRATE"] = "--- GRIP-EMS 마이그레이션 보고서 ---" -- MT
L["GEMS_REPORT_HEADER_IMPORT"] = "--- GRIP-EMS 임포트 보고서 ---" -- MT
L["GEMS_REPORT_IMPORTED"] = "임포트됨: %d개 시퀨스, %d개 변수" -- MT
L["GEMS_REPORT_SKIPPED"] = "건너뜀: %d (이미 존재)" -- MT
L["GEMS_REPORT_SEQ_ENTRY"] = "  + %s (%d 스텝, %s)" -- MT
L["GEMS_REPORT_LIMITATIONS"] = "알려진 제한 사항:" -- MT
L["GEMS_REPORT_VERSIONS_DROPPED"] = "  - %d개 추가 버전이 임포트되지 않음 (기본 버전만 지원)" -- MT
L["GEMS_REPORT_PAUSES_CONVERTED"] = "  - %d개 일시 중지 작업이 %d개 빈 스텝으로 변환됨" -- MT
L["GEMS_REPORT_EMBEDS_SKIPPED"] = "  - %d개 포함된 시퀨스 참조가 건너뜀 (아직 지원하지 않음)" -- MT
L["GEMS_REPORT_TRUNCATED"] = "  - %d개 스텝이 255자를 초과하여 잘림" -- MT
L["GEMS_REPORT_TIP_VERIFY"] = "팁: 각 마이그레이션된 시퀨스를 열어 스텝이 올바르게 표시되는지 확인하세요." -- MT
L["GEMS_REPORT_TIP_VERSIONS"] = "/gems를 사용하여 편집기를 열고 컨텍스트 버전 오버라이드를 구성하세요." -- MT

-- Guide (T1-10)
L["GEMS_GUIDE_TITLE"] = "GRIP-EMS 대화형 가이드" -- MT
L["GEMS_GUIDE_PATH"] = "이 URL을 복사하여 브라우저에서 열기:" -- MT
L["GEMS_GUIDE_TIP"] = "로컬 파일: Interface/AddOns/GRIP-EMS/Guide/GRIP-EMS_Guide.html" -- MT
L["GEMS_GUIDE_URL"] = "https://jesperlive.github.io/grip-ems-guide/" -- MT
L["GEMS_GUIDE_CLICK"] = "|cff4ecca3|HGRIPEMSguide|h[GRIP-EMS 가이드 열기를 클릭하세요]|h|r" -- MT
L["GEMS_HELP_GUIDE"] = "  /gems guide - GRIP-EMS 대화형 가이드" -- MT

-- Import preview (T2-4)
L["GEMS_IMPORT_PREVIEW_TITLE"] = "임포트 미리보기" -- MT
L["GEMS_IMPORT_PREVIEW_SEQ_HEADER"] = "시퀨스 (%d)" -- MT
L["GEMS_IMPORT_PREVIEW_VAR_HEADER"] = "변수 (%d)" -- MT
L["GEMS_IMPORT_PREVIEW_NEW"] = "새로 만들기" -- MT
L["GEMS_IMPORT_PREVIEW_EXISTS"] = "존재함" -- MT
L["GEMS_IMPORT_PREVIEW_IDENTICAL"] = "동일함" -- MT
L["GEMS_IMPORT_PREVIEW_DIFFERENT"] = "다름" -- MT
L["GEMS_IMPORT_PREVIEW_IMPORT_SELECTED"] = "선택한 항목 임포트 (%d)" -- MT
L["GEMS_IMPORT_PREVIEW_CANCEL"] = "취소" -- MT
L["GEMS_IMPORT_PREVIEW_SELECT_ALL"] = "모두 선택" -- MT
L["GEMS_IMPORT_PREVIEW_DESELECT_ALL"] = "모두 선택 해제" -- MT
L["GEMS_IMPORT_PREVIEW_EMPTY"] = "이 문자열에서 시퀨스 또는 변수를 찾을 수 없습니다." -- MT
L["GEMS_IMPORT_PREVIEW_DESC"] = "붙여넣은 텍스트를 구문 분석하고 임포트 가능한 시퀨스를 표시" -- MT
L["GEMS_IMPORT_CLEAR_DESC"] = "붙여넣기 상자 지우기" -- MT
L["GEMS_IMPORT_SELECT_ALL_DESC"] = "임포트할 모든 시퀨스 선택" -- MT
L["GEMS_IMPORT_DESELECT_ALL_DESC"] = "모든 시퀨스 선택 해제" -- MT
L["GEMS_IMPORT_CANCEL_DESC"] = "붙여넣기 단계로 돌아가기" -- MT
L["GEMS_IMPORT_COMMIT_DESC"] = "선택한 시퀨스 임포트" -- MT
L["GEMS_IMPORT_PREVIEW_SUMMARY"] = "%d개 시퀨스, %d개 변수 임포트됨" -- MT
L["GEMS_IMPORT_PREVIEW_BTN"] = "미리보기" -- MT
L["GEMS_IMPORT_PREVIEW_HEADER"] = "%d개 시퀨스, %d개 변수" -- MT
L["GEMS_IMPORT_PREVIEW_NEW_COUNT"] = "%d개 새로 만들기" -- MT
L["GEMS_IMPORT_PREVIEW_EXISTING_COUNT"] = "%d개 존재" -- MT
L["GEMS_IMPORT_PREVIEW_INFO"] = "%d개 버전, %d개 스텝" -- MT
L["GEMS_IMPORT_PREVIEW_ACTION_SKIP"] = "건너뛰기" -- MT
L["GEMS_IMPORT_PREVIEW_ACTION_REPLACE"] = "교체" -- MT
L["GEMS_IMPORT_PREVIEW_ACTION_RENAME"] = "이름 바꾸기" -- MT

-- Advanced Export (T2-12)
L["GEMS_EXPORT_PICK_TITLE"] = "시퀨스 내보내기" -- MT
L["GEMS_EXPORT_PICK_HEADER"] = "%d개 시퀨스, %d개 변수 사용 가능" -- MT
L["GEMS_EXPORT_PICK_SEQ_HEADER"] = "시퀨스 (%d)" -- MT
L["GEMS_EXPORT_PICK_VAR_HEADER"] = "변수 (%d)" -- MT
L["GEMS_EXPORT_PICK_INFO"] = "%d개 버전, %d개 스텝" -- MT
L["GEMS_EXPORT_PICK_VAR_DEPS"] = "(+%d개 변수)" -- MT
L["GEMS_EXPORT_PICK_USED_BY"] = "사용된 것: %s" -- MT
L["GEMS_EXPORT_PICK_AUTO"] = "자동" -- MT
L["GEMS_EXPORT_PICK_SELECT_ALL"] = "모두 선택" -- MT
L["GEMS_EXPORT_PICK_DESELECT_ALL"] = "모두 선택 해제" -- MT
L["GEMS_EXPORT_PICK_EXPORT_SELECTED"] = "선택한 항목 내보내기 (%d)" -- MT
L["GEMS_EXPORT_PICK_BACK"] = "뒤로" -- MT
L["GEMS_EXPORT_PICK_DISPLAY_HEADER"] = "%d개 시퀨스, %d개 변수 내보냄" -- MT
L["GEMS_EXPORT_PICK_EMBEDDED_WARN"] = "%s이 %s을(를) 사용합니다 (선택되지 않음)" -- MT
L["GEMS_EXPORT_PICK_LOCALE_WARN"] = "지역화 종속 스펠 이름을 가진 변수는 다른 게임 언어에서 작동하지 않을 수 있습니다" -- MT
L["GEMS_EXPORT_COPY_TEXT"] = "텍스트로 복사" -- MT
L["GEMS_EXPORT_COPY_TEXT_DESC"] = "읽을 수 있는 요약본을 클립보드에 복사" -- MT
L["GEMS_EXPORT_META_TITLE"] = "메타데이터 내보내기" -- MT
L["GEMS_EXPORT_META_SUBTITLE"] = "%d개 시퀨스를 내보내기 전에 검토 및 사용자 정의" -- MT
L["GEMS_EXPORT_META_NAME"] = "컬렉션 이름" -- MT
L["GEMS_EXPORT_META_AUTHOR"] = "작성자" -- MT
L["GEMS_EXPORT_META_DESC"] = "설명" -- MT
L["GEMS_EXPORT_META_URL"] = "URL / 링크" -- MT
L["GEMS_EXPORT_META_TALENT"] = "특성 로드아웃" -- MT
L["GEMS_EXPORT_META_INCLUDE_AUTHOR"] = "작성자 포함" -- MT
L["GEMS_EXPORT_META_INCLUDE_DESC"] = "설명 포함" -- MT
L["GEMS_EXPORT_META_INCLUDE_TALENT"] = "특성 문자열 포함" -- MT
L["GEMS_EXPORT_META_INCLUDE_URL"] = "URL 포함" -- MT
L["GEMS_EXPORT_META_GENERATE"] = "내보내기 문자열 생성" -- MT
L["GEMS_EXPORT_META_BACK"] = "선택 항목으로 돌아가기" -- MT
L["GEMS_IMPORT_COLLECTION_HEADER"] = "컬렉션: %s (작성자: %s)" -- MT
L["GEMS_UI_EXPORT_MULTI"] = "여러 항목 내보내기..." -- MT
L["GEMS_HELP_EXPORTALL"] = "  /gems exportall - 다중 선택 내보내기 윈도우 열기" -- MT
L["GEMS_EXPORT_GENERATE_DESC"] = "선택한 시퀨스에서 내보내기 문자열 생성" -- MT
L["GEMS_EXPORT_COPY_DESC"] = "내보내기 문자열을 클립보드에 복사" -- MT
L["GEMS_EXPORT_SELECT_ALL_DESC"] = "내보낼 모든 시퀨스 선택" -- MT
L["GEMS_EXPORT_DESELECT_ALL_DESC"] = "모든 시퀨스 선택 해제" -- MT
L["GEMS_EXPORT_BACK_DESC"] = "선택 항목으로 돌아가기" -- MT
L["GEMS_EXPORT_CLOSE_DESC"] = "내보내기 윈도우 닫기" -- MT

-- Transmission (T2-9)
L["GEMS_HELP_SEND"] = "  /gems send <이름> <플레이어> - 다른 플레이어에게 시퀨스 전송" -- MT
L["GEMS_HELP_ACCEPT"] = "  /gems accept - 가장 최근에 받은 시퀨스 수락" -- MT
L["GEMS_HELP_VALIDATE"] = "  /gems validate - 모든 시퀨스를 오래되었거나 유효하지 않은 스펠에 대해 검증" -- MT
L["GEMS_SEND_USAGE"] = "사용법: /gems send <이름> <플레이어>" -- MT
L["GEMS_SEND_SUCCESS"] = "'%s'을(를) %s에게 전송했습니다" -- MT
L["GEMS_SEND_FAILED"] = "전송 실패: %s" -- MT
L["GEMS_SEND_DISABLED"] = "P2P 공유가 설정에서 비활성화되어 있습니다." -- MT
L["GEMS_SEND_NO_SEQ"] = "'%s'이라는 시퀨스를 찾을 수 없습니다." -- MT
L["GEMS_RECEIVE_ANNOUNCE"] = "%s에서 시퀨스를 받았습니다. 임포트를 열고 있습니다..." -- MT
L["GEMS_RECEIVE_AUTO"] = "'%s'을(를) %s에서 자동 임포트했습니다 (친구)." -- MT
L["GEMS_REQUEST_SENT"] = "%s에서 '%s' 요청 중..." -- MT
L["GEMS_REQUEST_FULFILLED"] = "'%s'을(를) %s에게 전송했습니다 (요청됨)." -- MT
L["GEMS_VERSION_ANNOUNCE"] = "GRIP-EMS 사용자 감지: %s (v%s)" -- MT
L["GEMS_ACCEPT_USAGE"] = "수락할 대기 중인 시퀨스 없음." -- MT
L["GEMS_UI_SEND_PLAYER"] = "플레이어에게 전송" -- MT
L["GEMS_UI_SEND_BTN"] = "전송" -- MT
L["GEMS_UI_SEND_BTN_DESC"] = "이 시퀨스를 다른 플레이어에게 전송" -- MT
L["GEMS_SEND_DIALOG_TEXT"] = "'%s'을(를) 다음에게 전송:" -- MT
L["GEMS_SEND_DIALOG_ACCEPT"] = "전송" -- MT
L["GEMS_SEND_DIALOG_KNOWN"] = "알려진 사용자:" -- MT
L["GEMS_META_SENT"] = "'%s'에 대한 메타데이터 동기화 요청이 전송되었습니다." -- MT
L["GEMS_META_NEWER"] = "'%s'의 최신 버전을 %s에서 사용 가능합니다. 요청 중..." -- MT
L["GEMS_META_CURRENT"] = "로컬 '%s'이 최신 상태입니다 (%s의 원격)." -- MT
L["GEMS_SPELLCACHE_SENT"] = "스펠 캐시 방송이 그룹에 전송되었습니다." -- MT
L["GEMS_SPELLCACHE_MERGED"] = "%s에서 %d개 스펠 캐시 항목을 병합했습니다." -- MT
L["GEMS_P2P_ENABLED"] = "P2P 공유 활성화" -- MT
L["GEMS_P2P_ENABLED_DESC"] = "다른 GRIP-EMS 사용자와 시퀨스를 보내고 받을 수 있습니다." -- MT
L["GEMS_P2P_AUTO_FRIENDS"] = "친구로부터 자동 수락" -- MT
L["GEMS_P2P_AUTO_FRIENDS_DESC"] = "친구로부터 받은 시퀨스를 프롬프트 없이 자동으로 임포트합니다." -- MT
L["GEMS_P2P_ANNOUNCE"] = "수신 공지" -- MT
L["GEMS_P2P_ANNOUNCE_DESC"] = "다른 플레이어로부터 시퀨스를 받을 때 채팅 메시지 인쇄." -- MT
L["GEMS_IMPORT_FROM"] = "%s에서 임포트" -- MT

-- Block list (T2-9)
L["GEMS_BLOCK_ADDED"] = "%s을(를) P2P 전송에서 차단했습니다." -- MT
L["GEMS_BLOCK_REMOVED"] = "%s의 차단을 해제했습니다." -- MT
L["GEMS_BLOCK_NOT_FOUND"] = "%s은(는) 차단되지 않습니다." -- MT
L["GEMS_BLOCK_LIST_EMPTY"] = "차단된 플레이어 없음." -- MT
L["GEMS_BLOCK_LIST_HEADER"] = "차단된 플레이어:" -- MT
L["GEMS_SETTINGS_BLOCKED_PLAYERS"] = "차단된 플레이어" -- MT
L["GEMS_SETTINGS_BLOCKED_PLAYERS_DESC"] = "이 목록의 플레이어는 시퀨스를 보낼 수 없습니다." -- MT
L["GEMS_HELP_BLOCK"] = "  /gems block <플레이어> - P2P 전송에서 플레이어 차단" -- MT
L["GEMS_HELP_UNBLOCK"] = "  /gems unblock <플레이어> - 플레이어 차단 해제" -- MT
L["GEMS_HELP_BLOCKLIST"] = "  /gems blocklist - 차단된 모든 플레이어 목록" -- MT

-- Tracker HUD (T2-7)
L["GEMS_TRACKER_TOGGLE"] = "Tracker HUD %s." -- MT
L["GEMS_TRACKER_LOCKED"] = "Tracker 잠금 설정." -- MT
L["GEMS_TRACKER_UNLOCKED"] = "Tracker 잠금 해제." -- MT
L["GEMS_TRACKER_HEADER"] = "Tracker HUD" -- MT
L["GEMS_TRACKER_ICONSIZE_DESC"] = "각 시퀨스 아이콘의 크기 설정 (픽셀)" -- MT
L["GEMS_TRACKER_ORIENTATION_DESC"] = "아이콘을 수평 또는 수직으로 쌓기" -- MT
L["GEMS_TRACKER_SHOWNAME_DESC"] = "각 아이콘 아래 시퀨스 이름 표시" -- MT
L["GEMS_TRACKER_SHOWMODS_DESC"] = "활성 수정자 키 표시 (Alt/Shift/Ctrl)" -- MT
L["GEMS_TRACKER_LOCK_DESC"] = "Tracker 프레임 위치 잠금" -- MT
L["GEMS_TRACKER_SHOWMODE_DESC"] = "Tracker HUD를 표시할 시기 선택" -- MT
L["GEMS_TRACKER_MODE_ALWAYS"] = "항상" -- MT
L["GEMS_TRACKER_MODE_COMBAT"] = "전투 중" -- MT
L["GEMS_TRACKER_MODE_TARGET"] = "대상 있음" -- MT
L["GEMS_TRACKER_MODE_NEVER"] = "절대" -- MT
L["GEMS_TRACKER_SCALE_DESC"] = "Tracker HUD 프레임 규모 조정" -- MT
L["GEMS_TRACKER_PREVIEW_HINT"] = "미리보기는 현재 상태를 표시합니다. 전투 변수는 다를 수 있습니다." -- MT
L["GEMS_HELP_TRACKER"] = "  /gems tracker [lock] - Tracker HUD 토글" -- MT

-- Debug window (T1-6)
L["GEMS_HELP_DEBUGWINDOW"] = "  /gems debugwindow - 디버그 메시지 윈도우 토글" -- MT
L["GEMS_DEBUG_WINDOW_TITLE"] = "GRIP-EMS Debug" -- MT
L["GEMS_DEBUG_CLEAR"] = "지우기" -- MT
L["GEMS_DEBUG_COPY"] = "복사" -- MT
L["GEMS_DEBUG_COPY_HINT"] = "/gems export를 사용하거나 내보내기 프레임에서 Ctrl+C를 사용하여 디버그 출력을 복사하세요." -- MT
L["GEMS_UI_WHATSNEW_DISMISS"] = "다시 표시하지 않기" -- MT
L["GEMS_WHATSNEW_DISMISS_DESC"] = "이 버전에 대해 다시 표시하지 않음" -- MT
L["GEMS_DEBUG_CLOSE_DESC"] = "디버그 윈도우 닫기" -- MT
L["GEMS_DEBUG_CLEAR_DESC"] = "모든 디버그 메시지 지우기" -- MT
L["GEMS_DEBUG_COPY_DESC"] = "모든 메시지를 클립보드에 복사" -- MT

-- Locale Phase 2e
L["GEMS_HELP_REVALIDATE"] = "  /gems revalidate - 모든 시퀨스를 스펠 ID로 강제 다시 태그" -- MT

-- Click rate (v1.2.0 S01)
L["GEMS_SETTINGS_CLICK_RATE"] = "클릭 속도 (ms)" -- MT
L["GEMS_SETTINGS_CLICK_RATE_DESC"] =
    "키 누름 사이의 최소 밀리초. 낮을수록 = 더 빠른 시퀨싱. 기본값: 250ms." -- MT
L["GEMS_SETTINGS_CHAR_OVERRIDES"] = "캐릭터 오버라이드" -- MT
L["GEMS_SETTINGS_CHAR_CLICK_RATE"] = "캐릭터별 클릭 속도 (ms)" -- MT
L["GEMS_SETTINGS_CHAR_CLICK_RATE_DESC"] =
    "이 캐릭터에만 클릭 속도를 오버라이드합니다. 전역 값을 사용하려면 0으로 설정하세요." -- MT
L["GEMS_STATUS_CLICK_RATE"] = "클릭 속도: %dms (유효)" -- MT

-- Macro reset modifiers (v1.2.0 S01)
L["GEMS_SETTINGS_MACRO_RESET"] = "매크로 리셋" -- MT
L["GEMS_RESET_MOD_DESC"] = "키 누름 중에 이 수정자를 누르고 있으면 스텝 카운터를 1로 리셋." -- MT
L["GEMS_UI_RESET_MODS_HEADER"] = "리셋 수정자 오버라이드" -- MT
L["GEMS_UI_RESET_MODS_ENABLE"] = "시퀨스별 오버라이드 사용" -- MT
L["GEMS_UI_RESET_MODS_GLOBAL"] = "(전역 설정 사용 중)" -- MT
L["GEMS_RESET_MOD_LEFTBUTTON"] = "왼쪽 클릭" -- MT
L["GEMS_RESET_MOD_RIGHTBUTTON"] = "오른쪽 클릭" -- MT
L["GEMS_RESET_MOD_MIDDLEBUTTON"] = "중간 클릭" -- MT
L["GEMS_RESET_MOD_BUTTON4"] = "마우스 버튼 4" -- MT
L["GEMS_RESET_MOD_BUTTON5"] = "마우스 버튼 5" -- MT
L["GEMS_RESET_MOD_LEFTALT"] = "왼쪽 Alt" -- MT
L["GEMS_RESET_MOD_RIGHTALT"] = "오른쪽 Alt" -- MT
L["GEMS_RESET_MOD_ALT"] = "모든 Alt" -- MT
L["GEMS_RESET_MOD_LEFTCONTROL"] = "왼쪽 Ctrl" -- MT
L["GEMS_RESET_MOD_RIGHTCONTROL"] = "오른쪽 Ctrl" -- MT
L["GEMS_RESET_MOD_CONTROL"] = "모든 Ctrl" -- MT
L["GEMS_RESET_MOD_LEFTSHIFT"] = "왼쪽 Shift" -- MT
L["GEMS_RESET_MOD_RIGHTSHIFT"] = "오른쪽 Shift" -- MT
L["GEMS_RESET_MOD_SHIFT"] = "모든 Shift" -- MT
L["GEMS_RESET_MOD_ANYMOD"] = "모든 수정자" -- MT
L["GEMS_RESET_MOD_MOUSE_HEADER"] = "마우스 버튼" -- MT
L["GEMS_RESET_MOD_ALT_HEADER"] = "Alt 키" -- MT
L["GEMS_RESET_MOD_CONTROL_HEADER"] = "Ctrl 키" -- MT
L["GEMS_RESET_MOD_SHIFT_HEADER"] = "Shift 키" -- MT
L["GEMS_RESET_MOD_ANY_HEADER"] = "조합" -- MT

-- Corrupt sequence recovery
L["GEMS_CORRUPT_TITLE"] = "손상된 시퀨스 감지됨" -- MT
L["GEMS_CORRUPT_TEXT"] = "시퀨스 '%s'을(를) 로드할 수 없습니다.\n\n오류: %s\n\n작업을 선택하세요:" -- MT
L["GEMS_CORRUPT_DELETE"] = "삭제" -- MT
L["GEMS_CORRUPT_SKIP"] = "건너뛰기" -- MT
L["GEMS_CORRUPT_EXPORT"] = "원본 내보내기" -- MT
L["GEMS_CORRUPT_SUMMARY"] = "손상된 시퀨스: %d개 삭제됨, %d개 건너뜀, %d개 내보냄" -- MT
L["GEMS_CORRUPT_NONE"] = "손상된 시퀨스를 찾을 수 없습니다." -- MT

-- Execution Tracer (v1.2.0 S03-B)
L["GEMS_TRACE_CAST"] = "[Trace] %s (ID: %d)%s" -- MT
L["GEMS_TRACE_STARTED"] = "실행 추적 시작됨" -- MT
L["GEMS_TRACE_STOPPED"] = "실행 추적 중지됨" -- MT

-- CVar health (v1.2.0 S01)
L["GEMS_SETTINGS_CVAR_HEALTH"] = "CVar 상태" -- MT
L["GEMS_SETTINGS_CVAR_DESC"] =
    "매크로 시퀨서 성능에 영향을 주는 게임 변수. 초록색 = 최적, 노란색 = 저하됨, 빨간색 = 심각." -- MT
L["GEMS_SETTINGS_CVAR_AUTOFIX"] = "로그인 시 CVar 자동 수정" -- MT
L["GEMS_SETTINGS_CVAR_AUTOFIX_DESC"] = "로그인 시 권장 CVar 값을 자동으로 설정합니다." -- MT
L["GEMS_SETTINGS_CVAR_FIX"] = "수정" -- MT

-- Comparison Frame (v1.2.0 S04-B)
L["GEMS_IMPORT_COMPARE"] = "비교" -- MT
L["GEMS_UI_COMPARE_WITH"] = "다음과 비교..." -- MT
L["GEMS_COMPARE_TITLE"] = "시퀨스 비교" -- MT
L["GEMS_COMPARE_LEFT_LABEL"] = "기존" -- MT
L["GEMS_COMPARE_RIGHT_LABEL"] = "수신" -- MT
L["GEMS_COMPARE_STEPS"] = "%d 스텝" -- MT
L["GEMS_COMPARE_NO_STEPS"] = "스텝 없음" -- MT
L["GEMS_COMPARE_CLOSE_DESC"] = "비교 보기 닫기" -- MT

-- Sequence autocomplete (v1.2.0 S07b)
L["GEMS_AUTOCOMPLETE_SEQUENCES"] = "시퀨스" -- MT
L["GEMS_AUTOCOMPLETE_CLICK_INSERT"] = "/click GRIPEMS_%s" -- MT

-- Popup Editor (v1.2.0 S07a)
L["GEMS_UI_OPEN_NEW_WINDOW"] = "새 윈도우에서 열기" -- MT
L["GEMS_UI_POPUP_TITLE"] = "GRIP-EMS 편집기" -- MT
L["GEMS_UI_POPUP_CLOSE_DIRTY"] = "이 편집기에 저장되지 않은 변경 사항이 있습니다.\n닫기 전에 저장하시겠습니까?" -- MT
L["GEMS_UI_POPUP_MAX_REACHED"] = "최대 편집기 윈도우 도달 (%d)." -- MT

-- Editor Colours (v1.2.0 S08a)
L["GEMS_SETTINGS_EDITOR_COLOURS"] = "편집기 색상" -- MT
L["GEMS_SETTINGS_SYNTAX_COMMAND"] = "슬래시 명령" -- MT
L["GEMS_SETTINGS_SYNTAX_COMMAND_DESC"] = "/cast, /use, /click 등의 색상." -- MT
L["GEMS_SETTINGS_SYNTAX_CONDITIONAL"] = "조건문" -- MT
L["GEMS_SETTINGS_SYNTAX_CONDITIONAL_DESC"] = "[mod:shift], [talent:X] 등의 색상." -- MT
L["GEMS_SETTINGS_SYNTAX_VARIABLE"] = "변수" -- MT
L["GEMS_SETTINGS_SYNTAX_VARIABLE_DESC"] = "~variable~ 참조의 색상." -- MT
L["GEMS_SETTINGS_SYNTAX_COMMENT"] = "주석" -- MT
L["GEMS_SETTINGS_SYNTAX_COMMENT_DESC"] = "-- 주석 줄의 색상." -- MT
L["GEMS_SETTINGS_SYNTAX_RESET"] = "리셋 조건" -- MT
L["GEMS_SETTINGS_SYNTAX_RESET_DESC"] = "reset=target/combat/5의 색상." -- MT
L["GEMS_SETTINGS_SYNTAX_NUMBER"] = "숫자" -- MT
L["GEMS_SETTINGS_SYNTAX_NUMBER_DESC"] = "숫자 값의 색상." -- MT

-- Floating Menu (v1.2.0 S09a)
L["GEMS_FLOATING_HEADER"] = "떠 있는 메뉴" -- MT
L["GEMS_FLOATING_SHOW_DESC"] = "떠 있는 빠른 액세스 메뉴 표시줄 표시" -- MT
L["GEMS_FLOATING_DIRECTION_DESC"] = "버튼이 앵커에서 확장되는 방향" -- MT
L["GEMS_FLOATING_LOCK_DESC"] = "떠 있는 메뉴 위치 잠금" -- MT
L["GEMS_FLOATING_SCALE_DESC"] = "떠 있는 메뉴 프레임 규모 조정" -- MT
L["GEMS_FLOATING_LOCKED"] = "떠 있는 메뉴 잠금 설정." -- MT
L["GEMS_FLOATING_UNLOCKED"] = "떠 있는 메뉴 잠금 해제." -- MT
L["GEMS_FLOATING_BTN_SEQUENCES"] = "시퀨스" -- MT
L["GEMS_FLOATING_BTN_IMPORT"] = "임포트" -- MT
L["GEMS_FLOATING_BTN_EXPORT"] = "내보내기" -- MT
L["GEMS_FLOATING_BTN_VARIABLES"] = "변수" -- MT
L["GEMS_FLOATING_BTN_TRACKER"] = "Tracker" -- MT
L["GEMS_FLOATING_BTN_OPTIONS"] = "옵션" -- MT
L["GEMS_FLOATING_BTN_COLLAPSE"] = "축소" -- MT
L["GEMS_FLOATING_BTN_EXPAND"] = "확장" -- MT
L["GEMS_FLOATING_BTN_CLOSE"] = "닫기" -- MT
L["GEMS_FLOATING_DIR_UP"] = "위로" -- MT
L["GEMS_FLOATING_DIR_DOWN"] = "아래로" -- MT
L["GEMS_FLOATING_DIR_LEFT"] = "왼쪽" -- MT
L["GEMS_FLOATING_DIR_RIGHT"] = "오른쪽" -- MT
L["GEMS_HELP_MENU"] = "  /gems menu - 떠 있는 메뉴 표시줄 토글" -- MT

-- Support tab (v1.2.0 S10-B)
L["GEMS_SETTINGS_SUPPORT"] = "지원" -- MT
L["GEMS_SUPPORT_CREDITS"] = "제작: Sataana (MrSataana / JesperLive)" -- MT
L["GEMS_SUPPORT_DISCORD"] = "Discord: discord.gg/grip-ems" -- MT
L["GEMS_SUPPORT_SYSTEM_HEADER"] = "시스템 정보" -- MT
L["GEMS_SUPPORT_CREDITS_HEADER"] = "크레딧" -- MT
L["GEMS_SUPPORT_DISCORD_HEADER"] = "커뮤니티" -- MT
L["GEMS_HELP_COMPRESS"] = "  /gems compress <이름> - 시퀨스 인코딩 (개발)" -- MT
L["GEMS_HELP_DECOMPRESS"] = "  /gems decompress <문자열> - 문자열 디코딩 (개발)" -- MT

-- Remote Browser (v1.2.0 S13b)
L["GEMS_UI_REMOTE_BROWSER_TITLE"] = "원격 매크로 브라우저" -- MT
L["GEMS_UI_REMOTE_PLAYERS_HEADER"] = "EMS 사용자" -- MT
L["GEMS_UI_REMOTE_REFRESH"] = "새로고침" -- MT
L["GEMS_UI_REMOTE_SEQUENCES_FROM"] = "%s의 시퀨스" -- MT
L["GEMS_UI_REMOTE_WAITING"] = "응답 대기 중..." -- MT
L["GEMS_UI_REMOTE_NO_PLAYERS"] = "EMS 사용자 감지 안 됨. 플레이어를 발견하려면 그룹에 참여하세요." -- MT
L["GEMS_UI_REMOTE_NO_SEQUENCES"] = "이 플레이어로부터 사용 가능한 시퀨스 없음." -- MT
L["GEMS_UI_REMOTE_IMPORT"] = "임포트" -- MT
L["GEMS_UI_REMOTE_REQUEST_SENT"] = "%s에서 %s을(를) 요청했습니다" -- MT
L["GEMS_UI_REMOTE_LIST_RECEIVED"] = "%s에서 시퀨스 목록을 받았습니다 (%d개 시퀨스)" -- MT
L["GEMS_HELP_BROWSE"] = "  /gems browse - 원격 시퀨스 브라우저 열기" -- MT
L["GEMS_BROWSE_REFRESH_DESC"] = "파티 멤버 목록 및 해당 시퀨스 새로고침" -- MT
L["GEMS_BROWSE_IMPORT_DESC"] = "이 시퀨스를 라이브러리로 임포트" -- MT
L["GEMS_BROWSE_CLOSE_DESC"] = "브라우저 닫기" -- MT

-- Recorder
L["GEMS_UI_RECORD"] = "녹음" -- MT
L["GEMS_UI_RECORDING"] = "녹음 중..." -- MT
L["GEMS_UI_RECORDING_COUNT"] = "녹음 중 (%d)" -- MT
L["GEMS_RECORDER_MAX_REACHED"] = "녹음 중지됨: 최대 스텝 제한 도달." -- MT
L["GEMS_RECORDER_STOPPED"] = "녹음 중지됨: %d개 스펠 캡처됨." -- MT
L["GEMS_RECORDER_CREATE_CONFIRM"] = "녹음이 %d개 스펠을 캡처했습니다. 이 녹음에서 새 시퀨스를 만드시겠습니까?" -- MT
L["GEMS_RECORDER_CREATE_YES"] = "시퀨스 만들기" -- MT
L["GEMS_RECORDER_CREATE_NO"] = "폐기" -- MT
L["GEMS_RECORDER_EMPTY"] = "녹음된 스펠이 없습니다." -- MT
L["GEMS_SETTINGS_RECORDER_HEADER"] = "레코더" -- MT
L["GEMS_SETTINGS_RECORDER_DEDUP"] = "연속된 동일한 캐스트 중복 제거" -- MT
L["GEMS_SETTINGS_RECORDER_DEDUP_DESC"] =
    "활성화되면 동일한 스펠의 연속 캐스트가 단일 스텝으로 축소됩니다." -- MT

-- Spell Cache Viewer (v1.2.0 S16)
L["GEMS_SPELLCACHE_TITLE"] = "스펠 캐시" -- MT
L["GEMS_SPELLCACHE_TAB_SPELLS"] = "스펠" -- MT
L["GEMS_SPELLCACHE_TAB_ITEMS"] = "아이템" -- MT
L["GEMS_SPELLCACHE_TAB_TOYS"] = "장난감" -- MT
L["GEMS_SPELLCACHE_SEARCH"] = "검색..." -- MT
L["GEMS_SPELLCACHE_REFRESH"] = "새로고침" -- MT
L["GEMS_SPELLCACHE_CLEAR_OVERRIDES"] = "오버라이드 지우기" -- MT
L["GEMS_SPELLCACHE_CLEAR_CONFIRM"] = "모든 스펠 이름 오버라이드를 제거하시겠습니까? 이는 취소할 수 없습니다." -- MT
L["GEMS_SPELLCACHE_SHOWING"] = "%d / %d 표시 중" -- MT
L["GEMS_SPELLCACHE_SCANNING"] = "스캔 중..." -- MT
L["GEMS_SPELLCACHE_NOT_AVAILABLE"] = "스펠 캐시 뷰어를 사용할 수 없습니다." -- MT
L["GEMS_SPELLCACHE_OVERRIDE_CLEARED"] = "스펠 이름 오버라이드가 지워졌습니다." -- MT
L["GEMS_HELP_SPELLCACHE"] = "|cFF00CC66/gems spellcache|r -- 스펠 캐시 뷰어 열기" -- MT
L["GEMS_HELP_MAPINFO"] = "|cFF00CC66/gems mapinfo|r -- 현재 맵/던전 ID 표시" -- MT

-- Inline string localization (v1.2.0 S22-D)
L["GEMS_UI_STUB_PREVIEW"] = "매크로 스텁 미리보기" -- MT
L["GEMS_UI_EMPTY_HINT"] = "시작하려면 시퀨스를 임포트하거나 생성하세요" -- MT
L["GEMS_UI_KEYBIND_TOOLTIP"] = "키바인드: %s" -- MT

-- Vehicle / Pet Battle Keybinds (v1.2.0 S23)
L["GEMS_VEHICLE_KEYBINDS_HEADER"] = "탈것 / 오버라이드 바 키바인드" -- MT
L["GEMS_PET_BATTLE_KEYBINDS_HEADER"] = "펫 배틀 키바인드" -- MT
L["GEMS_VEHICLE_SLOT"] = "슬롯 %d" -- MT
L["GEMS_VEHICLE_KEYBINDS_APPLIED"] = "탈것 키바인드 적용됨: %d개 바인드" -- MT
L["GEMS_VEHICLE_KEYBINDS_CLEARED"] = "탈것 키바인드 지워짐" -- MT
L["GEMS_PET_BATTLE_KEYBINDS_APPLIED"] = "펫 배틀 키바인드 적용됨: %d개 바인드" -- MT
L["GEMS_PET_BATTLE_KEYBINDS_CLEARED"] = "펫 배틀 키바인드 지워짐" -- MT
L["GEMS_PET_BATTLE_ABILITY"] = "능력 %d" -- MT
L["GEMS_PET_BATTLE_SWAP"] = "펫 교체" -- MT
L["GEMS_PET_BATTLE_PASS"] = "턴 패스" -- MT
L["GEMS_PET_BATTLE_FORFEIT"] = "항복" -- MT
L["GEMS_BAR_INTEGRATION_HEADER"] = "액션 바 통합" -- MT
L["GEMS_BAR_INTEGRATION_DESC"] = "액션 바 버튼에 시퀨스 아이콘 표시" -- MT
L["GEMS_BAR_INTEGRATION_TRACKED"] = "바 통합: %d개 버튼 추적 중 (%s)" -- MT
L["GEMS_UI_NOT_BOUND"] = "바인드되지 않음" -- MT

-- Feature: Click Rate Diagnostics (/gems diag)
L["GEMS_DIAG_HEADER"] = "--- 실행 진단 ---" -- MT
L["GEMS_DIAG_CPS"] = "실시간 CPS: %.1f" -- MT
L["GEMS_DIAG_CONFIGURED"] = "구성된 클릭 속도: %dms (유효)" -- MT
L["GEMS_DIAG_TOTAL"] = "추적된 총 캐스트: %d" -- MT
L["GEMS_DIAG_TRACER"] = "추적기: %s" -- MT
L["GEMS_DIAG_TRACER_ON"] = "활성" -- MT
L["GEMS_DIAG_TRACER_OFF"] = "비활성" -- MT
L["GEMS_DIAG_TOP_SPELLS"] = "상위 스펠:" -- MT
L["GEMS_DIAG_SPELL_ROW"] = "  %d. %s (ID: %d) -- %d 캐스트" -- MT
L["GEMS_DIAG_NO_DATA"] = "아직 캐스트 데이터 없음. 먼저 시퀨스를 사용하세요." -- MT
L["GEMS_HELP_DIAG"] = "실행 진단 표시 (CPS, 상위 스펠)" -- MT
L["GEMS_HELP_MEMCHECK"] = "메모리 진단 (GC, 테이블 크기, 힙)" -- MT
L["GEMS_HELP_PERF"] = "성능 프로파일링 (OnUpdate, 프레임, 타이밍)" -- MT
L["GEMS_HELP_MONITOR"] = "300 프레임 연속 프로파일러 (주요 함수 후킹)" -- MT

-- Feature: Optimal MS Advisor (/gems msadvisor)
L["GEMS_MSADVISOR_HEADER"] = "--- MS Advisor%s ---" -- MT
L["GEMS_MSADVISOR_GCD"] = "기본 GCD: %dms (%.1f%% 가속도)" -- MT
L["GEMS_MSADVISOR_LAG"] = "세계 지연: %dms" -- MT
L["GEMS_MSADVISOR_SQW"] = "스펠 큐 윈도우: %dms" -- MT
L["GEMS_MSADVISOR_RECOMMEND"] = "권장 클릭 속도: %dms" -- MT
L["GEMS_MSADVISOR_CURRENT"] = "현재 구성됨: %dms" -- MT
L["GEMS_MSADVISOR_DELTA"] = "델타: %+dms (%s)" -- MT
L["GEMS_MSADVISOR_FASTER"] = "더 빨리 클릭할 수 있습니다" -- MT
L["GEMS_MSADVISOR_SLOWER"] = "GCD가 허용하는 것보다 더 빨리 클릭하고 있습니다" -- MT
L["GEMS_MSADVISOR_GOOD"] = "잘 일치함" -- MT
L["GEMS_MSADVISOR_ROTATION"] = "시퀨스 '%s': %d 스텝, 전체 로테이션 ~%dms" -- MT
L["GEMS_MSADVISOR_NOT_FOUND"] = "시퀨스 '%s'을 찾을 수 없습니다." -- MT
L["GEMS_HELP_MSADVISOR"] = "가속도를 기반으로 최적의 클릭 속도 추천" -- MT

-- Feature: Dormant Sequence Lazy Loading
L["GEMS_DORMANT_LOADED"] = "  %d개 시퀨스가 휴면으로 등록됨 (다른 클래스)" -- MT
L["GEMS_DORMANT_LABEL"] = "(휴면)" -- MT
L["GEMS_HELP_LOADCLASS"] = "클래스 ID에 대한 휴면 시퀨스 활성화" -- MT
L["GEMS_LOADCLASS_ALREADY"] = "클래스 %d 시퀨스가 이미 로드되었습니다." -- MT
L["GEMS_LOADCLASS_DONE"] = "클래스 %d에 대해 %d개의 휴면 시퀨스를 활성화했습니다." -- MT
L["GEMS_LOADCLASS_USAGE"] = "사용법: /gems loadclass <classID> (1=전사, 2=팔라딘, ...)" -- MT
L["GEMS_UI_ACTIVATE"] = "활성화" -- MT

-- Feature: Raw Macrotext Import
L["GEMS_RAWIMPORT_DETECTED"] = "원본 매크로 텍스트 감지됨. %d줄 구문 분석 중..." -- MT
L["GEMS_RAWIMPORT_RESULT"] = "원본 매크로 텍스트에서 %d개 스텝을 구문 분석했습니다." -- MT
L["GEMS_RAWIMPORT_NAME"] = "임포트된 매크로" -- MT
L["GEMS_RAWIMPORT_NO_SPELLS"] = "붙여넣은 텍스트에서 캐스트 가능한 줄을 찾을 수 없습니다." -- MT

-- Feature: Step Spell Picker
L["GEMS_SPELLPICKER_TITLE"] = "스펠 선택기" -- MT
L["GEMS_SPELLPICKER_SEARCH"] = "스펠 검색..." -- MT
L["GEMS_SPELLPICKER_ALL"] = "모두" -- MT
L["GEMS_SPELLPICKER_CLASS"] = "클래스" -- MT
L["GEMS_SPELLPICKER_PET"] = "펫 능력" -- MT
L["GEMS_SPELLPICKER_ITEMS"] = "아이템" -- MT
L["GEMS_SPELLPICKER_GEAR"] = "장비" -- MT
L["GEMS_SPELLPICKER_CONSUMABLES"] = "소비품" -- MT
L["GEMS_SPELLPICKER_TOYS"] = "장난감" -- MT
L["GEMS_SPELLPICKER_SPEC"] = "전문화" -- MT
L["GEMS_SPELLPICKER_RACE"] = "종족" -- MT
L["GEMS_SPELLPICKER_GENERAL"] = "일반" -- MT
L["GEMS_SPELLPICKER_PROF"] = "전문직" -- MT
L["GEMS_SPELLPICKER_OTHER"] = "기타" -- MT
L["GEMS_SPELLPICKER_MOUNTS"] = "탈것" -- MT
L["GEMS_SPELLPICKER_COMPANIONS"] = "동료" -- MT
L["GEMS_SPELLPICKER_CONDITIONALS"] = "조건문" -- MT
L["GEMS_SPELLPICKER_CUSTOM"] = "사용자 정의:" -- MT
L["GEMS_SPELLPICKER_INSERT"] = "삽입" -- MT
L["GEMS_SPELLPICKER_NO_RESULTS"] = "일치하는 스펠 없음" -- MT
L["GEMS_SPELLPICKER_FAVORITES"] = "즐겨찾기" -- MT
L["GEMS_SPELLPICKER_WARBANK_NOTE"] = "은행에서만 보이는 창고 아이템" -- MT
L["GEMS_HELP_SPELLPICKER"] = "각 스텝의 아이콘 버튼을 통해 스펠 선택기를 사용 가능" -- MT

-- Feature: Gear-Aware Variables
L["GEMS_GEAR_VAR_HEADER"] = "장비 변수 (자동 감지 사용 효과):" -- MT
L["GEMS_GEAR_VAR_ROW"] = "  ~%s~ = %s" -- MT
L["GEMS_GEAR_VAR_NONE"] = "장착된 사용 효과가 감지되지 않습니다." -- MT
L["GEMS_GEAR_VAR_UPDATED"] = "장비 변수 업데이트됨 (%d개 사용 효과 감지됨)." -- MT


-- CVar Health Dashboard (v1.9.0)
L["GEMS_CVAR_FIX_ALL"] = "Fix All"  -- MT
L["GEMS_CVAR_FIX_ALL_CRITICAL"] = "Fix All Critical"  -- MT
L["GEMS_CVAR_FIX_ALL_SECTION"] = "Fix All in Section"  -- MT
L["GEMS_CVAR_AUTOFIX_ENTRY"] = "Auto-fix on login"  -- MT
L["GEMS_CVAR_AUTOFIX_COUNT"] = "GEMS: Auto-fixed %d CVars on login."  -- MT
L["GEMS_CVAR_HEALTH_SCORE"] = "CVar Health: %d/100"  -- MT
L["GEMS_CVAR_SECURE_TAG"] = " (secure)"  -- MT
L["GEMS_CVAR_COMBAT_DISABLED"] = "Cannot change secure CVars in combat."  -- MT
L["GEMS_CVAR_INFORMATIONAL"] = " (informational)"  -- MT
L["GEMS_CVAR_YOUR_CHOICE"] = "(your choice)"  -- MT
L["GEMS_CVAR_WILL_CHANGE"] = "Will change from %s to %s."  -- MT
L["GEMS_CVAR_SET_VALUE"] = "Set Value"  -- MT
L["GEMS_CVAR_SECTION_MACRO"] = "Macro Sequencing"  -- MT
L["GEMS_CVAR_SECTION_COMBAT"] = "Combat & Targeting"  -- MT
L["GEMS_CVAR_SECTION_NAMEPLATES"] = "Nameplates"  -- MT
L["GEMS_CVAR_SECTION_RAIDING"] = "Raiding"  -- MT
L["GEMS_CVAR_SECTION_DUNGEON"] = "Dungeons & M+"  -- MT
L["GEMS_CVAR_SECTION_SOLO"] = "Solo Play & Open World"  -- MT
L["GEMS_CVAR_SECTION_UI"] = "UI & Quality of Life"  -- MT
L["GEMS_CVAR_SECTION_FPS"] = "FPS & Performance"  -- MT
L["GEMS_CVAR_SECTION_VISUAL"] = "Visual Quality"  -- MT
L["GEMS_CVAR_SECTION_SOUND"] = "Sound"  -- MT
L["GEMS_CVAR_SECTION_FCT"] = "Floating Combat Text"  -- MT
L["GEMS_CVAR_SECTION_ACCESS"] = "Accessibility"  -- MT
L["GEMS_CVAR_SECTION_DRAGON"] = "Dragonriding & Advanced Flying"  -- MT
L["GEMS_CVAR_MACRO_KEYDOWN"] = "Key Down Casting"  -- MT
L["GEMS_CVAR_MACRO_KEYDOWN_DESC"] = "Fire abilities on key press, not release. If 0, every macro keypress has 50-100ms extra delay. Mandatory for sequencing."  -- MT
L["GEMS_CVAR_MACRO_KEYHELD"] = "Hold to Cast"  -- MT
L["GEMS_CVAR_MACRO_KEYHELD_DESC"] = "Press-and-hold auto-repeats the ability. Preference-based, not a blanket recommendation. Informational."  -- MT
L["GEMS_CVAR_MACRO_SPELLQUEUE"] = "Spell Queue Window"  -- MT
L["GEMS_CVAR_MACRO_SPELLQUEUE_DESC"] = "Milliseconds before GCD ends that the next spell can be queued. 400ms is optimal for most players."  -- MT
L["GEMS_CVAR_MACRO_LOCKBARS"] = "Lock Action Bars"  -- MT
L["GEMS_CVAR_MACRO_LOCKBARS_DESC"] = "Prevents accidental drag-off of macro stubs from action bars during combat."  -- MT
L["GEMS_CVAR_MACRO_MULTIBARS"] = "Multi Action Bars"  -- MT
L["GEMS_CVAR_MACRO_MULTIBARS_DESC"] = "Bitfield for additional action bars (0=none, 15=all). More bars = more room for macro stubs. Informational."  -- MT
L["GEMS_CVAR_MACRO_AUTOPUSH"] = "Auto Push Spells"  -- MT
L["GEMS_CVAR_MACRO_AUTOPUSH_DESC"] = "Auto-places new spells on bars. Recommend OFF -- new spells from leveling push macro stubs off the bar."  -- MT
L["GEMS_CVAR_MACRO_SELFCAST"] = "Auto Self Cast"  -- MT
L["GEMS_CVAR_MACRO_SELFCAST_DESC"] = "Auto-cast beneficial spells on self when no valid target. Important for macro steps with self-heals."  -- MT
L["GEMS_CVAR_MACRO_AUTOSTAND"] = "Auto Stand"  -- MT
L["GEMS_CVAR_MACRO_AUTOSTAND_DESC"] = "Auto-stand when casting. Without this, macro sequences fail silently while sitting."  -- MT
L["GEMS_CVAR_MACRO_AUTOUNSHIFT"] = "Auto Unshift"  -- MT
L["GEMS_CVAR_MACRO_AUTOUNSHIFT_DESC"] = "Auto-leave shapeshift/stealth when casting incompatible spells. Without this, Druid/Rogue macro steps fail silently."  -- MT
L["GEMS_CVAR_MACRO_STOPATTACK"] = "Stop Attack on Switch"  -- MT
L["GEMS_CVAR_MACRO_STOPATTACK_DESC"] = "Keep auto-attacking when switching targets. If 1, target-switching mid-sequence stops melee auto-attacks."  -- MT
L["GEMS_CVAR_MACRO_ICONRATE"] = "Icon Update Rate"  -- MT
L["GEMS_CVAR_MACRO_ICONRATE_DESC"] = "How often action bar icons refresh (seconds). 0.05 = 20 updates/sec, smoother than default 0.1."  -- MT
L["GEMS_CVAR_MACRO_CDCOUNT"] = "Cooldown Countdown"  -- MT
L["GEMS_CVAR_MACRO_CDCOUNT_DESC"] = "Show numeric cooldown timers on action buttons. Critical for seeing exact remaining cooldown on the sequence button."  -- MT
L["GEMS_CVAR_MACRO_SECTOGGLE"] = "Secure Ability Toggle"  -- MT
L["GEMS_CVAR_MACRO_SECTOGGLE_DESC"] = "Prevents double-click toggling abilities off. Protects against rapid keypresses deactivating toggle abilities."  -- MT
L["GEMS_CVAR_MACRO_EMPTAP"] = "Empower Tap Controls"  -- MT
L["GEMS_CVAR_MACRO_EMPTAP_DESC"] = "Tap-tap vs hold-release for empowered spells (Evoker). Hold-release works better with sequences."  -- MT
L["GEMS_CVAR_MACRO_EMPHOLD"] = "Empower Hold Stage"  -- MT
L["GEMS_CVAR_MACRO_EMPHOLD_DESC"] = "Percentage of first empower stage required before auto-release [0.0-1.0]. Evoker-specific."  -- MT
L["GEMS_CVAR_MACRO_HELDPOLL"] = "Held Spell Poll Time"  -- MT
L["GEMS_CVAR_MACRO_HELDPOLL_DESC"] = "Milliseconds between retry attempts when held-spell casting fails. Lower = faster retry, more responsive."  -- MT
L["GEMS_CVAR_MACRO_PRECAST"] = "Preemptive Cast"  -- MT
L["GEMS_CVAR_MACRO_PRECAST_DESC"] = "Preemptive cast visual triggering based on spell release timing. Undocumented visual feature."  -- MT
L["GEMS_CVAR_COMBAT_SOFTENEMY"] = "Soft Target Enemy"  -- MT
L["GEMS_CVAR_COMBAT_SOFTENEMY_DESC"] = "When soft targeting activates for enemies. 0=off, 1=gamepad, 2=KBM, 3=always. Recommend 3 for auto-acquire."  -- MT
L["GEMS_CVAR_COMBAT_SOFTARC"] = "Soft Target Arc"  -- MT
L["GEMS_CVAR_COMBAT_SOFTARC_DESC"] = "Directional constraint for enemy soft target. 0=must face directly, 1=front arc, 2=anywhere."  -- MT
L["GEMS_CVAR_COMBAT_SOFTRANGE"] = "Soft Target Range"  -- MT
L["GEMS_CVAR_COMBAT_SOFTRANGE_DESC"] = "Max range for soft target enemy detection (yards). 45yd covers most ranged abilities."  -- MT
L["GEMS_CVAR_COMBAT_SOFTFORCE"] = "Soft Target Force"  -- MT
L["GEMS_CVAR_COMBAT_SOFTFORCE_DESC"] = "Auto-hardlock soft target. Without this, soft targeting shows the target but spells fire at nothing."  -- MT
L["GEMS_CVAR_COMBAT_SOFTFRIEND"] = "Soft Target Friend"  -- MT
L["GEMS_CVAR_COMBAT_SOFTFRIEND_DESC"] = "Soft targeting for friendlies. 0=off. Healers may want 3 (always). DPS should leave at 0."  -- MT
L["GEMS_CVAR_COMBAT_SOFTLOCKED"] = "Soft With Locked"  -- MT
L["GEMS_CVAR_COMBAT_SOFTLOCKED_DESC"] = "Allow soft target while having a hard-locked target. 2=always allows soft target preview."  -- MT
L["GEMS_CVAR_COMBAT_SOFTMATCH"] = "Soft Match Locked"  -- MT
L["GEMS_CVAR_COMBAT_SOFTMATCH_DESC"] = "Match soft target to locked target. Keeps the soft target indicator synced with your actual target."  -- MT
L["GEMS_CVAR_COMBAT_TABNEW"] = "New Tab Targeting"  -- MT
L["GEMS_CVAR_COMBAT_TABNEW_DESC"] = "Use modern (7.2+) tab-targeting algorithm. Prioritizes enemies in front of you and in combat."  -- MT
L["GEMS_CVAR_COMBAT_COMBATLOCK"] = "Combat Target Lock"  -- MT
L["GEMS_CVAR_COMBAT_COMBATLOCK_DESC"] = "Lock tab-target to in-combat enemies. Prevents jumping to distant mobs not yet pulled."  -- MT
L["GEMS_CVAR_COMBAT_LOCKRELAX"] = "Lock Relaxation"  -- MT
L["GEMS_CVAR_COMBAT_LOCKRELAX_DESC"] = "Smart relaxation of combat lock when no in-combat targets are available."  -- MT
L["GEMS_CVAR_COMBAT_PVPPRIO"] = "PvP Target Priority"  -- MT
L["GEMS_CVAR_COMBAT_PVPPRIO_DESC"] = "In PvP, prioritize players and important PvP targets. 1=players first."  -- MT
L["GEMS_CVAR_COMBAT_ATTACKER"] = "Target Attacker"  -- MT
L["GEMS_CVAR_COMBAT_ATTACKER_DESC"] = "Auto-target enemies that attack you. Essential for solo play where mobs aggro."  -- MT
L["GEMS_CVAR_COMBAT_AUTOENEMY"] = "Auto Target Enemy"  -- MT
L["GEMS_CVAR_COMBAT_AUTOENEMY_DESC"] = "Auto-target nearest enemy when casting offensive spells with no target. Ensures macros fire."  -- MT
L["GEMS_CVAR_COMBAT_DESELECT"] = "Deselect on Click"  -- MT
L["GEMS_CVAR_COMBAT_DESELECT_DESC"] = "Clear target when clicking terrain. If 1, clicking ground mid-fight drops your target."  -- MT
L["GEMS_CVAR_COMBAT_LEFTCLICK"] = "Interact Left Click"  -- MT
L["GEMS_CVAR_COMBAT_LEFTCLICK_DESC"] = "Left-click interacts with NPCs. Standard behavior most players expect."  -- MT
L["GEMS_CVAR_COMBAT_HIGHLIGHT"] = "Combat Highlight"  -- MT
L["GEMS_CVAR_COMBAT_HIGHLIGHT_DESC"] = "Next-spell-to-cast highlight. Competes visually with sequence tracking. Recommend OFF."  -- MT
L["GEMS_CVAR_COMBAT_PROCS"] = "Proc Overlays"  -- MT
L["GEMS_CVAR_COMBAT_PROCS_DESC"] = "Show proc/spell alert overlays (glowing borders). Important for seeing procs that affect macro priority."  -- MT
L["GEMS_CVAR_COMBAT_PROCOPACITY"] = "Proc Overlay Opacity"  -- MT
L["GEMS_CVAR_COMBAT_PROCOPACITY_DESC"] = "Opacity of spell alert overlays. Default 0.65 is good. Increase to 0.8-1.0 if hard to see."  -- MT
L["GEMS_CVAR_COMBAT_LOC"] = "Loss of Control"  -- MT
L["GEMS_CVAR_COMBAT_LOC_DESC"] = "Show loss-of-control banner when stunned/silenced. Helps understand why a macro sequence appears stuck."  -- MT
L["GEMS_CVAR_COMBAT_MOUSEOVER"] = "Mouseover Casting"  -- MT
L["GEMS_CVAR_COMBAT_MOUSEOVER_DESC"] = "Cast on unit under cursor without targeting. Huge for healers. Informational, not auto-fix."  -- MT
L["GEMS_CVAR_COMBAT_FRIENDARC"] = "Friend Soft Arc"  -- MT
L["GEMS_CVAR_COMBAT_FRIENDARC_DESC"] = "Directional constraint for friendly soft target. Mirrors SoftTargetEnemyArc. Only if SoftTargetFriend is on."  -- MT
L["GEMS_CVAR_COMBAT_FRIENDRANGE"] = "Friend Soft Range"  -- MT
L["GEMS_CVAR_COMBAT_FRIENDRANGE_DESC"] = "Max range for soft target friend detection. 45yd covers all healing spells."  -- MT
L["GEMS_CVAR_NAMEPLATES_SHOWALL"] = "Show All Nameplates"  -- MT
L["GEMS_CVAR_NAMEPLATES_SHOWALL_DESC"] = "Show ALL nameplates (enemies, friendly NPCs, pets). Master toggle. Most combat players want this on."  -- MT
L["GEMS_CVAR_NAMEPLATES_SHOWENEMY"] = "Show Enemy Nameplates"  -- MT
L["GEMS_CVAR_NAMEPLATES_SHOWENEMY_DESC"] = "Show enemy nameplates. Must be on for any combat awareness."  -- MT
L["GEMS_CVAR_NAMEPLATES_SHOWSELF"] = "Show Self Nameplate"  -- MT
L["GEMS_CVAR_NAMEPLATES_SHOWSELF_DESC"] = "Show personal resource display (health/mana bar under your character). Many players don't know this exists."  -- MT
L["GEMS_CVAR_NAMEPLATES_MAXDIST"] = "Max Distance"  -- MT
L["GEMS_CVAR_NAMEPLATES_MAXDIST_DESC"] = "Max nameplate render distance. 60yd is the cap and default. Lower values save GPU but lose awareness."  -- MT
L["GEMS_CVAR_NAMEPLATES_PLAYERDIST"] = "Player Max Distance"  -- MT
L["GEMS_CVAR_NAMEPLATES_PLAYERDIST_DESC"] = "Max distance for player nameplates specifically. Keep equal to nameplateMaxDistance."  -- MT
L["GEMS_CVAR_NAMEPLATES_MINALPHA"] = "Min Opacity"  -- MT
L["GEMS_CVAR_NAMEPLATES_MINALPHA_DESC"] = "Minimum opacity for distant nameplates. Default 0.6 makes far nameplates hard to see. 0.8 is better."  -- MT
L["GEMS_CVAR_NAMEPLATES_MAXALPHA"] = "Max Opacity"  -- MT
L["GEMS_CVAR_NAMEPLATES_MAXALPHA_DESC"] = "Maximum opacity for nearby nameplates. 1.0 = fully opaque. No reason to lower."  -- MT
L["GEMS_CVAR_NAMEPLATES_MINSCALE"] = "Min Scale"  -- MT
L["GEMS_CVAR_NAMEPLATES_MINSCALE_DESC"] = "Minimum scale for distant nameplates. Lower values make far nameplates too small to read."  -- MT
L["GEMS_CVAR_NAMEPLATES_MAXSCALE"] = "Max Scale"  -- MT
L["GEMS_CVAR_NAMEPLATES_MAXSCALE_DESC"] = "Maximum scale for nearby nameplates."  -- MT
L["GEMS_CVAR_NAMEPLATES_SELSCALE"] = "Selected Scale"  -- MT
L["GEMS_CVAR_NAMEPLATES_SELSCALE_DESC"] = "Scale multiplier for your current target's nameplate. Default 1.2 makes the target visually distinct."  -- MT
L["GEMS_CVAR_NAMEPLATES_OCCLUDED"] = "Occluded Opacity"  -- MT
L["GEMS_CVAR_NAMEPLATES_OCCLUDED_DESC"] = "Opacity for nameplates behind walls/objects. Default 0.4 is nearly invisible. 0.6 keeps them readable."  -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPH"] = "Horizontal Overlap"  -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPH_DESC"] = "Horizontal stacking overlap. Lower = more spread. 0.8 is the default stacking behavior."  -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPV"] = "Vertical Overlap"  -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPV_DESC"] = "Vertical stacking overlap. Controls how nameplates stack vertically in AoE packs."  -- MT
L["GEMS_CVAR_NAMEPLATES_CASTBARS"] = "Nameplate Cast Bars"  -- MT
L["GEMS_CVAR_NAMEPLATES_CASTBARS_DESC"] = "Show cast bars on nameplates. Essential for interrupting."  -- MT
L["GEMS_CVAR_NAMEPLATES_CLASSCOLOR"] = "Class Color Bars"  -- MT
L["GEMS_CVAR_NAMEPLATES_CLASSCOLOR_DESC"] = "Color enemy nameplate health bars by class. Important for PvP target identification."  -- MT
L["GEMS_CVAR_NAMEPLATES_DEBUFFS"] = "Friendly Debuffs"  -- MT
L["GEMS_CVAR_NAMEPLATES_DEBUFFS_DESC"] = "Show debuffs on friendly nameplates. Useful for healers and dispellers."  -- MT
L["GEMS_CVAR_NAMEPLATES_MINIONS"] = "Enemy Minions"  -- MT
L["GEMS_CVAR_NAMEPLATES_MINIONS_DESC"] = "Show minion nameplates. Off by default to reduce clutter. Enable in M+ if minion health matters."  -- MT
L["GEMS_CVAR_NAMEPLATES_MINUS"] = "Trivial Enemies"  -- MT
L["GEMS_CVAR_NAMEPLATES_MINUS_DESC"] = "Show nameplates for trivial (minus) enemies. Useful in open world for seeing all mobs."  -- MT
L["GEMS_CVAR_NAMEPLATES_TOTEMS"] = "Enemy Totems"  -- MT
L["GEMS_CVAR_NAMEPLATES_TOTEMS_DESC"] = "Show enemy totem nameplates. Important in PvP -- totems are kill targets."  -- MT
L["GEMS_CVAR_NAMEPLATES_FRIENDLY"] = "Friendly Players"  -- MT
L["GEMS_CVAR_NAMEPLATES_FRIENDLY_DESC"] = "Show friendly player nameplates. Off in PvE to reduce clutter. On in PvP for awareness."  -- MT
L["GEMS_CVAR_NAMEPLATES_AURASCALE"] = "Aura Icon Scale"  -- MT
L["GEMS_CVAR_NAMEPLATES_AURASCALE_DESC"] = "Scale multiplier for buff/debuff icons on nameplates. 1.2 makes DoT tracking easier at a glance."  -- MT
L["GEMS_CVAR_NAMEPLATES_NAMEONLY"] = "Name Only Friendly"  -- MT
L["GEMS_CVAR_NAMEPLATES_NAMEONLY_DESC"] = "Strip friendly nameplates to name-only (no health bar). Reduces visual noise in raids."  -- MT
L["GEMS_CVAR_NAMEPLATES_ATBASE"] = "Position at Base"  -- MT
L["GEMS_CVAR_NAMEPLATES_ATBASE_DESC"] = "Position non-target nameplates at base of character instead of overhead. 0=overhead (standard)."  -- MT
L["GEMS_CVAR_NAMEPLATES_OFFSCREEN"] = "Show Offscreen"  -- MT
L["GEMS_CVAR_NAMEPLATES_OFFSCREEN_DESC"] = "Show nameplates for off-screen targets. Can be useful but also cluttery."  -- MT
L["GEMS_CVAR_NAMEPLATES_RADIAL"] = "Radial Position"  -- MT
L["GEMS_CVAR_NAMEPLATES_RADIAL_DESC"] = "Show target nameplate radially around screen edge when off-screen. 0=off."  -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTNP"] = "Soft Target Nameplate"  -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTNP_DESC"] = "Always show nameplate for soft-targeted enemy."  -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTSIZE"] = "Soft Target Size"  -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTSIZE_DESC"] = "Size of the soft target indicator on nameplates. Default 19 can be hard to see. 25 is better."  -- MT
L["GEMS_CVAR_NAMEPLATES_DEBUFFPAD"] = "Debuff Padding"  -- MT
L["GEMS_CVAR_NAMEPLATES_DEBUFFPAD_DESC"] = "Padding between debuff list and health bar. 0 = compact."  -- MT
L["GEMS_CVAR_NAMEPLATES_MOTION"] = "Stacking Behavior"  -- MT
L["GEMS_CVAR_NAMEPLATES_MOTION_DESC"] = "Nameplate stacking. 0=overlapping, 1=stacking (vertical column), 2=spreading (default fan-out)."  -- MT
L["GEMS_CVAR_NAMEPLATES_MOTIONSPD"] = "Stacking Speed"  -- MT
L["GEMS_CVAR_NAMEPLATES_MOTIONSPD_DESC"] = "Animation speed for nameplates moving into stacked/spread positions. Higher = faster snapping."  -- MT
L["GEMS_CVAR_RAIDING_COMBATLOG"] = "Advanced Combat Logging"  -- MT
L["GEMS_CVAR_RAIDING_COMBATLOG_DESC"] = "Enable advanced combat logging (CLEU extra data). Required for accurate Warcraft Logs analysis."  -- MT
L["GEMS_CVAR_RAIDING_THREATWARN"] = "Threat Warning"  -- MT
L["GEMS_CVAR_RAIDING_THREATWARN_DESC"] = "Threat warning display. 0=off, 1=dungeons, 2=party, 3=always."  -- MT
L["GEMS_CVAR_RAIDING_THREATNUM"] = "Numeric Threat"  -- MT
L["GEMS_CVAR_RAIDING_THREATNUM_DESC"] = "Show numeric threat values on target/focus frames. Useful for tanks and threat-conscious DPS."  -- MT
L["GEMS_CVAR_RAIDING_THREATSOUND"] = "Threat Sounds"  -- MT
L["GEMS_CVAR_RAIDING_THREATSOUND_DESC"] = "Play sounds on threat transitions (aggro gain/loss)."  -- MT
L["GEMS_CVAR_RAIDING_THREATTEXT"] = "Threat World Text"  -- MT
L["GEMS_CVAR_RAIDING_THREATTEXT_DESC"] = "Show threat floaters in combat (the aggro text)."  -- MT
L["GEMS_CVAR_RAIDING_TIMELINE"] = "Encounter Timeline"  -- MT
L["GEMS_CVAR_RAIDING_TIMELINE_DESC"] = "Enable the boss encounter timeline. Shows upcoming boss abilities."  -- MT
L["GEMS_CVAR_RAIDING_TIMEROLE"] = "Timeline Role Filter"  -- MT
L["GEMS_CVAR_RAIDING_TIMEROLE_DESC"] = "Hide encounter timeline events irrelevant to your role. Reduces noise for DPS/healers."  -- MT
L["GEMS_CVAR_RAIDING_WARNINGS"] = "Encounter Warnings"  -- MT
L["GEMS_CVAR_RAIDING_WARNINGS_DESC"] = "Show encounter warning messages (boss ability alerts)."  -- MT
L["GEMS_CVAR_RAIDING_WARNHIDE"] = "Hide Non-Target Warns"  -- MT
L["GEMS_CVAR_RAIDING_WARNHIDE_DESC"] = "Hide boss warnings not targeting you. 0=show all (safer). 1=less noise for experienced raiders."  -- MT
L["GEMS_CVAR_RAIDING_AGGRO"] = "Aggro Highlight"  -- MT
L["GEMS_CVAR_RAIDING_AGGRO_DESC"] = "Highlight raid frames when that player has aggro."  -- MT
L["GEMS_CVAR_RAIDING_RDEBUFFS"] = "Raid Frame Debuffs"  -- MT
L["GEMS_CVAR_RAIDING_RDEBUFFS_DESC"] = "Show debuffs on raid frames. Essential for healers and dispellers."  -- MT
L["GEMS_CVAR_RAIDING_HEALPRED"] = "Incoming Heals"  -- MT
L["GEMS_CVAR_RAIDING_HEALPRED_DESC"] = "Show incoming heal predictions on raid frames."  -- MT
L["GEMS_CVAR_RAIDING_POWERBARS"] = "Raid Power Bars"  -- MT
L["GEMS_CVAR_RAIDING_POWERBARS_DESC"] = "Show mana/rage/energy bars on raid frames. Off by default to save space."  -- MT
L["GEMS_CVAR_RAIDING_RCLASSCOLOR"] = "Raid Class Colors"  -- MT
L["GEMS_CVAR_RAIDING_RCLASSCOLOR_DESC"] = "Color raid frame health bars by class. Makes it easier to identify players at a glance."  -- MT
L["GEMS_CVAR_RAIDING_DISPONLY"] = "Dispellable Only"  -- MT
L["GEMS_CVAR_RAIDING_DISPONLY_DESC"] = "Filter to only show debuffs you can dispel. 0=show all."  -- MT
L["GEMS_CVAR_RAIDING_ROLEDEBUFF"] = "Role Debuff Size"  -- MT
L["GEMS_CVAR_RAIDING_ROLEDEBUFF_DESC"] = "Show role-relevant debuffs at larger size. Tank debuffs bigger for tanks, healer debuffs for healers."  -- MT
L["GEMS_CVAR_RAIDING_BIGDEF"] = "Center Big Defensives"  -- MT
L["GEMS_CVAR_RAIDING_BIGDEF_DESC"] = "Show big defensive cooldowns (Ironbark, Pain Suppression) centered on the raid frame."  -- MT
L["GEMS_CVAR_RAIDING_DISPTYPE"] = "Dispel Indicator"  -- MT
L["GEMS_CVAR_RAIDING_DISPTYPE_DESC"] = "Dispel indicator style. 0=none, 1=icon, 2=icon+highlight."  -- MT
L["GEMS_CVAR_RAIDING_HEALTHTEXT"] = "Health Text Mode"  -- MT
L["GEMS_CVAR_RAIDING_HEALTHTEXT_DESC"] = "Health text display mode. none, health, losthealth, or perc. Preference-based."  -- MT
L["GEMS_CVAR_RAIDING_SORTMODE"] = "Raid Sort Mode"  -- MT
L["GEMS_CVAR_RAIDING_SORTMODE_DESC"] = "Raid frame sort mode. role (tanks/healers/DPS), group, or alphabetical."  -- MT
L["GEMS_CVAR_RAIDING_KEEPGRP"] = "Keep Groups Together"  -- MT
L["GEMS_CVAR_RAIDING_KEEPGRP_DESC"] = "Keep raid groups visually separated. 0=intermix, 1=group blocks."  -- MT
L["GEMS_CVAR_RAIDING_TANKASSIST"] = "Tank and Assist"  -- MT
L["GEMS_CVAR_RAIDING_TANKASSIST_DESC"] = "Show main tank and main assist units in raid frames."  -- MT
L["GEMS_CVAR_RAIDING_FINDSELF"] = "Find Yourself"  -- MT
L["GEMS_CVAR_RAIDING_FINDSELF_DESC"] = "Highlight your own character in raid frames."  -- MT
L["GEMS_CVAR_RAIDING_CASTBUFFS"] = "Castable Buffs"  -- MT
L["GEMS_CVAR_RAIDING_CASTBUFFS_DESC"] = "Show only buffs you can cast (raid only). 0=show all."  -- MT
L["GEMS_CVAR_RAIDING_DISPDEBUFFS"] = "Show Dispel Debuffs"  -- MT
L["GEMS_CVAR_RAIDING_DISPDEBUFFS_DESC"] = "Show only debuffs you can dispel (raid only)."  -- MT
L["GEMS_CVAR_RAIDING_RAIDSETTINGS"] = "Raid Graphics Settings"  -- MT
L["GEMS_CVAR_RAIDING_RAIDSETTINGS_DESC"] = "Enable separate graphics settings for raids. Biggest single raid FPS improvement. Many players miss this."  -- MT
L["GEMS_CVAR_RAIDING_NOFILTER"] = "No Buff/Debuff Filter"  -- MT
L["GEMS_CVAR_RAIDING_NOFILTER_DESC"] = "Disable ALL buff/debuff filtering on target frame. 0=normal filtering. 1=see everything."  -- MT
L["GEMS_CVAR_RAIDING_SPELLCLUTTER"] = "Spell Visual Clutter"  -- MT
L["GEMS_CVAR_RAIDING_SPELLCLUTTER_DESC"] = "Spell visual density. 1=essential only, 2=reduced, 3=some, 4=everything. Lower = cleaner raids."  -- MT
L["GEMS_CVAR_RAIDING_MYSPELLS"] = "Emphasize My Spells"  -- MT
L["GEMS_CVAR_RAIDING_MYSPELLS_DESC"] = "Tone down other players' spell effects while keeping yours at full. Essential in 20-man raids."  -- MT
L["GEMS_CVAR_RAIDING_COMBATWARN"] = "Combat Warnings"  -- MT
L["GEMS_CVAR_RAIDING_COMBATWARN_DESC"] = "Master toggle for combat warning UI (boss timeline + warnings)."  -- MT
L["GEMS_CVAR_DUNGEON_DPSRESET"] = "DPS Meter Reset"  -- MT
L["GEMS_CVAR_DUNGEON_DPSRESET_DESC"] = "Auto-reset damage meter on new instance entry. Clean data per dungeon without manual reset."  -- MT
L["GEMS_CVAR_DUNGEON_ENTRANCE"] = "Dungeon Entrances"  -- MT
L["GEMS_CVAR_DUNGEON_ENTRANCE_DESC"] = "Show dungeon entrance icons on the world map."  -- MT
L["GEMS_CVAR_DUNGEON_CLUTTER"] = "Unit Clutter Filter"  -- MT
L["GEMS_CVAR_DUNGEON_CLUTTER_DESC"] = "Limit unit clutter (NPC stacking reduction) to instances only."  -- MT
L["GEMS_CVAR_DUNGEON_ENEMYCAST"] = "Enemy Cast Bars"  -- MT
L["GEMS_CVAR_DUNGEON_ENEMYCAST_DESC"] = "Show enemy cast bars on arena frames. Also affects M+ party awareness."  -- MT
L["GEMS_CVAR_DUNGEON_LOGTIME"] = "Log Retention Time"  -- MT
L["GEMS_CVAR_DUNGEON_LOGTIME_DESC"] = "Seconds to keep combat log entries. 300s default. Increase to 600 for long M+ pulls."  -- MT
L["GEMS_CVAR_DUNGEON_LOGFILE"] = "Unique Log Filenames"  -- MT
L["GEMS_CVAR_DUNGEON_LOGFILE_DESC"] = "Use timestamped combat log filenames. Prevents overwriting previous logs."  -- MT
L["GEMS_CVAR_DUNGEON_DIMINISH"] = "CC Diminishing Returns"  -- MT
L["GEMS_CVAR_DUNGEON_DIMINISH_DESC"] = "Show crowd control diminishing returns on enemy frames."  -- MT
L["GEMS_CVAR_SOLO_AUTOLOOT"] = "Auto Loot"  -- MT
L["GEMS_CVAR_SOLO_AUTOLOOT_DESC"] = "Auto-loot items. Default OFF means clicking each item individually. Almost every player wants this ON."  -- MT
L["GEMS_CVAR_SOLO_LOOTRATE"] = "Loot Speed"  -- MT
L["GEMS_CVAR_SOLO_LOOTRATE_DESC"] = "Milliseconds between auto-loot ticks. Default 150ms feels sluggish. 50ms loots almost instantly."  -- MT
L["GEMS_CVAR_SOLO_LOOTMOUSE"] = "Loot at Cursor"  -- MT
L["GEMS_CVAR_SOLO_LOOTMOUSE_DESC"] = "Open loot window at mouse cursor. Saves mouse travel."  -- MT
L["GEMS_CVAR_SOLO_AELOOT"] = "AoE Looting"  -- MT
L["GEMS_CVAR_SOLO_AELOOT_DESC"] = "Disable area-of-effect looting. 0=AoE loot enabled (loot all nearby corpses at once)."  -- MT
L["GEMS_CVAR_SOLO_DISMOUNT"] = "Auto Dismount"  -- MT
L["GEMS_CVAR_SOLO_DISMOUNT_DESC"] = "Auto-dismount when casting."  -- MT
L["GEMS_CVAR_SOLO_DISMOUNTFLY"] = "Dismount While Flying"  -- MT
L["GEMS_CVAR_SOLO_DISMOUNTFLY_DESC"] = "Auto-dismount while flying (you will fall). Default OFF is sane."  -- MT
L["GEMS_CVAR_SOLO_TOT"] = "Target of Target"  -- MT
L["GEMS_CVAR_SOLO_TOT_DESC"] = "Show target-of-target frame. Essential for tanks (see what the boss targets) and DPS."  -- MT
L["GEMS_CVAR_SOLO_TCASTBAR"] = "Target Cast Bar"  -- MT
L["GEMS_CVAR_SOLO_TCASTBAR_DESC"] = "Show your target's cast bar. Essential for interrupting."  -- MT
L["GEMS_CVAR_SOLO_QUESTWATCH"] = "Auto Quest Watch"  -- MT
L["GEMS_CVAR_SOLO_QUESTWATCH_DESC"] = "Auto-track quests in the objective tracker when obtained."  -- MT
L["GEMS_CVAR_SOLO_QUESTPOI"] = "Quest POI on Map"  -- MT
L["GEMS_CVAR_SOLO_QUESTPOI_DESC"] = "Show quest points of interest on the world map."  -- MT
L["GEMS_CVAR_SOLO_PARTYPETS"] = "Show Party Pets"  -- MT
L["GEMS_CVAR_SOLO_PARTYPETS_DESC"] = "Show pet frames in party UI. Off by default to save screen space."  -- MT
L["GEMS_CVAR_SOLO_INTERACT"] = "Soft Interact"  -- MT
L["GEMS_CVAR_SOLO_INTERACT_DESC"] = "Soft targeting for interactive objects. 0=off, 1=gamepad, 3=always. Huge QoL for questing."  -- MT
L["GEMS_CVAR_SOLO_INTERARC"] = "Interact Arc"  -- MT
L["GEMS_CVAR_SOLO_INTERARC_DESC"] = "Directional constraint for interact soft target. 0=must face directly, 1=front arc, 2=anywhere."  -- MT
L["GEMS_CVAR_SOLO_INTERRANGE"] = "Interact Range"  -- MT
L["GEMS_CVAR_SOLO_INTERRANGE_DESC"] = "Max range for soft interact detection (yards). 10 is the default and cap."  -- MT
L["GEMS_CVAR_SOLO_INTERICON"] = "Interact Icon"  -- MT
L["GEMS_CVAR_SOLO_INTERICON_DESC"] = "Show icon indicator for soft interact targets. Keep on for visual feedback."  -- MT
L["GEMS_CVAR_SOLO_AUTOINTER"] = "Auto Move to Interact"  -- MT
L["GEMS_CVAR_SOLO_AUTOINTER_DESC"] = "Auto-move to interact target. Can be disorienting in combat areas. Informational."  -- MT
L["GEMS_CVAR_SOLO_QUESTITEMS"] = "Quest Item Interact"  -- MT
L["GEMS_CVAR_SOLO_QUESTITEMS_DESC"] = "Allow quest item use as an interaction. Enables using quest items directly from soft-interact."  -- MT
L["GEMS_CVAR_UI_TUTORIALS"] = "Tutorial Popups"  -- MT
L["GEMS_CVAR_UI_TUTORIALS_DESC"] = "Display tutorial popups. Experienced players should disable -- tutorials interrupt gameplay."  -- MT
L["GEMS_CVAR_UI_NPE"] = "New Player Tutorials"  -- MT
L["GEMS_CVAR_UI_NPE_DESC"] = "Display New Player Experience tutorials. Disable for experienced players."  -- MT
L["GEMS_CVAR_UI_LOADTIPS"] = "Loading Screen Tips"  -- MT
L["GEMS_CVAR_UI_LOADTIPS_DESC"] = "Show tips on loading screens. Low-cost, occasionally useful."  -- MT
L["GEMS_CVAR_UI_COMPARE"] = "Compare Items"  -- MT
L["GEMS_CVAR_UI_COMPARE_DESC"] = "Always show item comparison tooltips when hovering gear."  -- MT
L["GEMS_CVAR_UI_TOOLTIPS"] = "Detailed Tooltips"  -- MT
L["GEMS_CVAR_UI_TOOLTIPS_DESC"] = "Show verbose/detailed tooltips with stats."  -- MT
L["GEMS_CVAR_UI_TRANSMOG"] = "Missing Transmog Source"  -- MT
L["GEMS_CVAR_UI_TRANSMOG_DESC"] = "Show if you are missing a transmog appearance source. Hidden gem for collectors."  -- MT
L["GEMS_CVAR_UI_SSFORMAT"] = "Screenshot Format"  -- MT
L["GEMS_CVAR_UI_SSFORMAT_DESC"] = "Screenshot file format. TGA is lossless, JPEG saves disk space but looks worse."  -- MT
L["GEMS_CVAR_UI_SSQUALITY"] = "Screenshot Quality"  -- MT
L["GEMS_CVAR_UI_SSQUALITY_DESC"] = "JPEG quality (1-10). Default 3 is very low. If using JPEG, use 10."  -- MT
L["GEMS_CVAR_UI_ZOOM"] = "Camera Zoom Distance"  -- MT
L["GEMS_CVAR_UI_ZOOM_DESC"] = "Max camera zoom-out multiplier. Default 1.9 feels close. 2.6 gives more battlefield awareness."  -- MT
L["GEMS_CVAR_UI_EDGEFLASH"] = "Screen Edge Flash"  -- MT
L["GEMS_CVAR_UI_EDGEFLASH_DESC"] = "Red flash at screen edges while in combat with map open. Safety reminder."  -- MT
L["GEMS_CVAR_UI_BUBBLES"] = "Chat Bubbles"  -- MT
L["GEMS_CVAR_UI_BUBBLES_DESC"] = "Show in-game speech bubbles."  -- MT
L["GEMS_CVAR_UI_BIGNUMS"] = "Break Up Numbers"  -- MT
L["GEMS_CVAR_UI_BIGNUMS_DESC"] = "Use commas in large numbers (1,000,000 vs 1000000)."  -- MT
L["GEMS_CVAR_UI_BUFFDUR"] = "Buff Durations"  -- MT
L["GEMS_CVAR_UI_BUFFDUR_DESC"] = "Show remaining duration on buff icons."  -- MT
L["GEMS_CVAR_UI_COMBOPT"] = "Combo Point Location"  -- MT
L["GEMS_CVAR_UI_COMBOPT_DESC"] = "Combo point display. 1=on target frame, 2=on self (below personal resource display)."  -- MT
L["GEMS_CVAR_UI_FSTACK"] = "Frame Stack Debug"  -- MT
L["GEMS_CVAR_UI_FSTACK_DESC"] = "Enable frame stack tooltip (developer tool). Shows frame names on hover. Useful for debugging."  -- MT
L["GEMS_CVAR_UI_RAWMOUSE"] = "Raw Mouse Input"  -- MT
L["GEMS_CVAR_UI_RAWMOUSE_DESC"] = "Raw mouse input bypass. Deprecated/broken as of 2024 patches. Informational only."  -- MT
L["GEMS_CVAR_UI_TAINT"] = "Taint Log"  -- MT
L["GEMS_CVAR_UI_TAINT_DESC"] = "Taint debugging log. 0=off, 1=log to file, 2=log+chat. Addon developers set to 1 for debugging."  -- MT
L["GEMS_CVAR_UI_BAGS"] = "Combined Bags"  -- MT
L["GEMS_CVAR_UI_BAGS_DESC"] = "Display all bags as one combined inventory view. Added in Dragonflight. Much cleaner management."  -- MT
L["GEMS_CVAR_UI_ROTATEMM"] = "Rotate Minimap"  -- MT
L["GEMS_CVAR_UI_ROTATEMM_DESC"] = "Rotate minimap to match player facing direction instead of fixed north-up. Preference-based."  -- MT
L["GEMS_CVAR_FPS_MAXFPS"] = "Max FPS"  -- MT
L["GEMS_CVAR_FPS_MAXFPS_DESC"] = "FPS cap. Should match your monitor's refresh rate. Going higher wastes GPU."  -- MT
L["GEMS_CVAR_FPS_BGFPS"] = "Background FPS"  -- MT
L["GEMS_CVAR_FPS_BGFPS_DESC"] = "Background FPS cap (game not focused). 30 saves power/heat. Lower to 8 for maximum savings."  -- MT
L["GEMS_CVAR_FPS_LOADFPS"] = "Loading Screen FPS"  -- MT
L["GEMS_CVAR_FPS_LOADFPS_DESC"] = "Loading screen FPS cap. Low is fine -- no gameplay during loads."  -- MT
L["GEMS_CVAR_FPS_USEMAXFPS"] = "Enable FPS Cap"  -- MT
L["GEMS_CVAR_FPS_USEMAXFPS_DESC"] = "Enable the FPS cap. Default OFF means uncapped FPS (wastes GPU, causes heat)."  -- MT
L["GEMS_CVAR_FPS_VSYNC"] = "Vertical Sync"  -- MT
L["GEMS_CVAR_FPS_VSYNC_DESC"] = "Prevents screen tearing but adds input lag. For competitive play, disable and use FPS cap instead."  -- MT
L["GEMS_CVAR_FPS_TARGETFPS"] = "Target FPS"  -- MT
L["GEMS_CVAR_FPS_TARGETFPS_DESC"] = "Target FPS for dynamic quality scaling. Game auto-lowers settings to hit this."  -- MT
L["GEMS_CVAR_FPS_USETARGET"] = "Use Target FPS"  -- MT
L["GEMS_CVAR_FPS_USETARGET_DESC"] = "Enable target FPS system. Can cause jarring quality fluctuations. Prefer static settings."  -- MT
L["GEMS_CVAR_FPS_LATENCY"] = "GPU Frame Latency"  -- MT
L["GEMS_CVAR_FPS_LATENCY_DESC"] = "Max frames CPU can queue ahead of GPU. Default 3 = ~50ms lag at 60fps. 1 = ~16ms, worth it for macros."  -- MT
L["GEMS_CVAR_FPS_RSCALE"] = "Render Scale"  -- MT
L["GEMS_CVAR_FPS_RSCALE_DESC"] = "Render resolution multiplier. 1.0 = native. Below 1.0 = blurry but faster. Above 1.0 = supersampling."  -- MT
L["GEMS_CVAR_FPS_DYNSCALE"] = "Dynamic Render Scale"  -- MT
L["GEMS_CVAR_FPS_DYNSCALE_DESC"] = "Auto-lower render scale when GPU-bound. Beta feature -- can cause hitching. Leave off unless needed."  -- MT
L["GEMS_CVAR_FPS_LOWLAT"] = "Low Latency Mode"  -- MT
L["GEMS_CVAR_FPS_LOWLAT_DESC"] = "Low latency rendering. 0=none, 2=Reflex (NVIDIA), 4=XeLL (Intel). AMD users leave at 0."  -- MT
L["GEMS_CVAR_FPS_MULTITHREAD"] = "Multi-Thread Rendering"  -- MT
L["GEMS_CVAR_FPS_MULTITHREAD_DESC"] = "Multi-threaded rendering. Disabling significantly reduces framerate. Never set to 0."  -- MT
L["GEMS_CVAR_FPS_SPELLCLUTTER"] = "Spell Visual Density"  -- MT
L["GEMS_CVAR_FPS_SPELLCLUTTER_DESC"] = "Global spell visual density. 1=essential only, 4=everything. Lower = max FPS gain."  -- MT
L["GEMS_CVAR_FPS_PARTICLES"] = "Particle Density"  -- MT
L["GEMS_CVAR_FPS_PARTICLES_DESC"] = "Particle effect density (percentage). Reducing to 50 improves FPS in particle-heavy fights."  -- MT
L["GEMS_CVAR_FPS_WEATHER"] = "Weather Density"  -- MT
L["GEMS_CVAR_FPS_WEATHER_DESC"] = "Weather effect density. Reducing removes rain/snow particles."  -- MT
L["GEMS_CVAR_FPS_ANIMLOD"] = "Animation Frame Skip"  -- MT
L["GEMS_CVAR_FPS_ANIMLOD_DESC"] = "Skip animation frames for distant characters. Saves CPU with no visible impact."  -- MT
L["GEMS_CVAR_FPS_VFXDENSITY"] = "VFX Density Filter"  -- MT
L["GEMS_CVAR_FPS_VFXDENSITY_DESC"] = "Alternative spell visual density control. Works alongside spellClutter as a second-pass filter."  -- MT
L["GEMS_CVAR_VISUAL_QUALITY"] = "Graphics Quality"  -- MT
L["GEMS_CVAR_VISUAL_QUALITY_DESC"] = "Master graphics quality preset (1-10). Changes all sub-settings at once. Informational."  -- MT
L["GEMS_CVAR_VISUAL_SHADOWS"] = "Shadow Quality"  -- MT
L["GEMS_CVAR_VISUAL_SHADOWS_DESC"] = "Shadow quality (1-5). Shadows are GPU-expensive. Lowering to 1-2 gives significant FPS gains."  -- MT
L["GEMS_CVAR_VISUAL_SSAO"] = "Ambient Occlusion"  -- MT
L["GEMS_CVAR_VISUAL_SSAO_DESC"] = "Screen-space ambient occlusion quality. Adds depth to shadows. 0=off (fastest), 4=highest."  -- MT
L["GEMS_CVAR_VISUAL_VIEWDIST"] = "View Distance"  -- MT
L["GEMS_CVAR_VISUAL_VIEWDIST_DESC"] = "View distance (1-10). Lowering to 5 saves GPU with little visual impact in instanced content."  -- MT
L["GEMS_CVAR_VISUAL_GROUND"] = "Ground Clutter"  -- MT
L["GEMS_CVAR_VISUAL_GROUND_DESC"] = "Grass/ground detail density (1-10). Pure cosmetic -- lowering has zero gameplay impact and saves FPS."  -- MT
L["GEMS_CVAR_VISUAL_TEXRES"] = "Texture Resolution"  -- MT
L["GEMS_CVAR_VISUAL_TEXRES_DESC"] = "Texture resolution quality (1-3). Affects VRAM usage. Lower if VRAM-limited."  -- MT
L["GEMS_CVAR_VISUAL_LIQUID"] = "Water Quality"  -- MT
L["GEMS_CVAR_VISUAL_LIQUID_DESC"] = "Water rendering quality. Lower = less reflective water, better FPS near water."  -- MT
L["GEMS_CVAR_VISUAL_PROJTEX"] = "Projected Textures"  -- MT
L["GEMS_CVAR_VISUAL_PROJTEX_DESC"] = "Spell ground effects (Healing Rain, Consecration). MUST be on -- without it, boss mechanics are invisible."  -- MT
L["GEMS_CVAR_VISUAL_OUTLINE"] = "Outline Mode"  -- MT
L["GEMS_CVAR_VISUAL_OUTLINE_DESC"] = "Character/NPC outline mode. 0=none, 1=thin, 2=normal. Helps with visibility."  -- MT
L["GEMS_CVAR_VISUAL_AA"] = "Anti-Aliasing"  -- MT
L["GEMS_CVAR_VISUAL_AA_DESC"] = "Anti-aliasing mode. 0=none, 1=FXAA low, 2=FXAA high, 3=CMAA. CMAA is best quality-to-cost ratio."  -- MT
L["GEMS_CVAR_VISUAL_GLOW"] = "Glow Effect"  -- MT
L["GEMS_CVAR_VISUAL_GLOW_DESC"] = "Full-screen glow effect. Subtle but adds atmosphere."  -- MT
L["GEMS_CVAR_VISUAL_DEATH"] = "Death Effect"  -- MT
L["GEMS_CVAR_VISUAL_DEATH_DESC"] = "Death desaturation effect. Greyscale when dead."  -- MT
L["GEMS_CVAR_VISUAL_SHARPEN"] = "Sharpening Pass"  -- MT
L["GEMS_CVAR_VISUAL_SHARPEN_DESC"] = "Enable sharpening even without FSR upscaling. Makes image crisper at native resolution. Hidden CVar."  -- MT
L["GEMS_CVAR_VISUAL_SHARPNESS"] = "Sharpening Strength"  -- MT
L["GEMS_CVAR_VISUAL_SHARPNESS_DESC"] = "Sharpening strength [0.0-2.0]. Only active when ResampleAlwaysSharpen=1 or FSR is enabled."  -- MT
L["GEMS_CVAR_VISUAL_FARCLIP"] = "Far Clip Plane"  -- MT
L["GEMS_CVAR_VISUAL_FARCLIP_DESC"] = "Max render distance in world units. Lower = less distant geometry = better FPS. 800 is sufficient."  -- MT
L["GEMS_CVAR_SOUND_MASTER"] = "Master Sound Toggle"  -- MT
L["GEMS_CVAR_SOUND_MASTER_DESC"] = "Master sound toggle. Must be on for any audio."  -- MT
L["GEMS_CVAR_SOUND_MASTERVOL"] = "Master Volume"  -- MT
L["GEMS_CVAR_SOUND_MASTERVOL_DESC"] = "Master volume (0.0-1.0). 0.8 gives headroom for Discord/Spotify alongside WoW."  -- MT
L["GEMS_CVAR_SOUND_SFX"] = "SFX Volume"  -- MT
L["GEMS_CVAR_SOUND_SFX_DESC"] = "Sound effects volume. Keep at 1.0 for combat audio cues."  -- MT
L["GEMS_CVAR_SOUND_MUSIC"] = "Music Volume"  -- MT
L["GEMS_CVAR_SOUND_MUSIC_DESC"] = "Music volume. Lower during raids/dungeons to hear boss ability audio cues."  -- MT
L["GEMS_CVAR_SOUND_AMBIENCE"] = "Ambience Volume"  -- MT
L["GEMS_CVAR_SOUND_AMBIENCE_DESC"] = "Ambient sound volume. Lower in raids -- ambient noise can mask important combat audio."  -- MT
L["GEMS_CVAR_SOUND_DIALOG"] = "Dialog Volume"  -- MT
L["GEMS_CVAR_SOUND_DIALOG_DESC"] = "Voice/dialog volume (boss VO, quest narration)."  -- MT
L["GEMS_CVAR_SOUND_BGAUDIO"] = "Background Audio"  -- MT
L["GEMS_CVAR_SOUND_BGAUDIO_DESC"] = "Play sound when WoW is in background. Important for queue pops and ready checks while alt-tabbed."  -- MT
L["GEMS_CVAR_SOUND_ENCWARN"] = "Encounter Warning Sounds"  -- MT
L["GEMS_CVAR_SOUND_ENCWARN_DESC"] = "Play sounds for encounter/boss warnings."  -- MT
L["GEMS_CVAR_SOUND_ENCVOL"] = "Encounter Warning Volume"  -- MT
L["GEMS_CVAR_SOUND_ENCVOL_DESC"] = "Volume for encounter warning sounds (0.0-1.0)."  -- MT
L["GEMS_CVAR_SOUND_ERRSPEECH"] = "Error Speech"  -- MT
L["GEMS_CVAR_SOUND_ERRSPEECH_DESC"] = "Error voice (not enough mana, etc). Disable -- macro sequences hitting cooldowns trigger this rapidly."  -- MT
L["GEMS_CVAR_SOUND_GAMEPLAY"] = "Gameplay SFX"  -- MT
L["GEMS_CVAR_SOUND_GAMEPLAY_DESC"] = "Enable gameplay-specific sound effects."  -- MT
L["GEMS_CVAR_FCT_ENABLE"] = "Floating Combat Text"  -- MT
L["GEMS_CVAR_FCT_ENABLE_DESC"] = "Master toggle for floating combat text. Off by default! Enable to see damage/healing numbers."  -- MT
L["GEMS_CVAR_FCT_DAMAGE"] = "Damage Numbers"  -- MT
L["GEMS_CVAR_FCT_DAMAGE_DESC"] = "Show damage numbers on hostile targets."  -- MT
L["GEMS_CVAR_FCT_AUTOS"] = "Auto-Attack Numbers"  -- MT
L["GEMS_CVAR_FCT_AUTOS_DESC"] = "Show ALL auto-attack numbers (not just crits/procs)."  -- MT
L["GEMS_CVAR_FCT_HEALING"] = "Healing Numbers"  -- MT
L["GEMS_CVAR_FCT_HEALING_DESC"] = "Show healing numbers on targets."  -- MT
L["GEMS_CVAR_FCT_ABSSELF"] = "Self Absorbs"  -- MT
L["GEMS_CVAR_FCT_ABSSELF_DESC"] = "Show shield/absorb amounts applied to yourself."  -- MT
L["GEMS_CVAR_FCT_ABSTARGET"] = "Target Absorbs"  -- MT
L["GEMS_CVAR_FCT_ABSTARGET_DESC"] = "Show shield/absorb amounts applied to your target."  -- MT
L["GEMS_CVAR_FCT_PERIODIC"] = "Periodic Damage"  -- MT
L["GEMS_CVAR_FCT_PERIODIC_DESC"] = "Show DoT/HoT tick numbers."  -- MT
L["GEMS_CVAR_FCT_DODGEMISS"] = "Dodge/Parry/Miss"  -- MT
L["GEMS_CVAR_FCT_DODGEMISS_DESC"] = "Show dodge/parry/miss text. Useful for seeing when abilities are avoided."  -- MT
L["GEMS_CVAR_FCT_LOWRES"] = "Low Resource Warning"  -- MT
L["GEMS_CVAR_FCT_LOWRES_DESC"] = "Show low mana/health warnings."  -- MT
L["GEMS_CVAR_FCT_FLOATMODE"] = "Float Direction"  -- MT
L["GEMS_CVAR_FCT_FLOATMODE_DESC"] = "Float direction. 1=up, 2=down, 3=arc. 1 (up) is standard."  -- MT
L["GEMS_CVAR_FCT_DIRSCALE"] = "Directional Scale"  -- MT
L["GEMS_CVAR_FCT_DIRSCALE_DESC"] = "Directional damage number movement scale. 0=no directional movement. 1.0=default."  -- MT
L["GEMS_CVAR_FCT_PETMELEE"] = "Pet Melee Damage"  -- MT
L["GEMS_CVAR_FCT_PETMELEE_DESC"] = "Show pet melee damage numbers. Important for pet-class macros (BM Hunter, Demo Warlock)."  -- MT
L["GEMS_CVAR_FCT_PETSPELL"] = "Pet Spell Damage"  -- MT
L["GEMS_CVAR_FCT_PETSPELL_DESC"] = "Show pet spell damage numbers."  -- MT
L["GEMS_CVAR_FCT_REACTIVES"] = "Reactive Procs"  -- MT
L["GEMS_CVAR_FCT_REACTIVES_DESC"] = "Show reactive ability procs (Overpower, Revenge). Helps spot procs macro sequences should react to."  -- MT
L["GEMS_CVAR_FCT_ENERGY"] = "Energy Gains"  -- MT
L["GEMS_CVAR_FCT_ENERGY_DESC"] = "Show energy/rage/mana gain numbers. Off by default -- can be very spammy."  -- MT
L["GEMS_CVAR_FCT_AURAS"] = "Buff/Debuff Text"  -- MT
L["GEMS_CVAR_FCT_AURAS_DESC"] = "Show buff/debuff application text. Off by default -- very spammy in group content."  -- MT
L["GEMS_CVAR_FCT_HEALERS"] = "Healer Names"  -- MT
L["GEMS_CVAR_FCT_HEALERS_DESC"] = "Show name of healer who healed you."  -- MT
L["GEMS_CVAR_ACCESS_COLORBLIND"] = "Colorblind Mode"  -- MT
L["GEMS_CVAR_ACCESS_COLORBLIND_DESC"] = "Colorblind mode. 0=off, 1=Protanopia, 2=Deuteranopia, 3=Tritanopia. Informational."  -- MT
L["GEMS_CVAR_ACCESS_CENTERED"] = "Keep Centered"  -- MT
L["GEMS_CVAR_ACCESS_CENTERED_DESC"] = "Keep character head at screen center as a motion reference point. Reduces motion sickness."  -- MT
L["GEMS_CVAR_ACCESS_REDUCEMOVE"] = "Reduce Movement"  -- MT
L["GEMS_CVAR_ACCESS_REDUCEMOVE_DESC"] = "Reduce camera movement without player input. Helps with motion sickness but can feel unresponsive."  -- MT
L["GEMS_CVAR_ACCESS_FOCAL"] = "Focal Circle"  -- MT
L["GEMS_CVAR_ACCESS_FOCAL_DESC"] = "Show a focal circle when mounted. Reduces motion sickness during fast movement."  -- MT
L["GEMS_CVAR_ACCESS_TEXTCONTRAST"] = "Quest Text Contrast"  -- MT
L["GEMS_CVAR_ACCESS_TEXTCONTRAST_DESC"] = "Increase text contrast in quest UIs. Helps with readability."  -- MT
L["GEMS_CVAR_ACCESS_CAA"] = "Combat Audio Alerts"  -- MT
L["GEMS_CVAR_ACCESS_CAA_DESC"] = "Audio cues for combat events (health thresholds, ability readiness). Useful for visually impaired players."  -- MT
L["GEMS_CVAR_DRAGON_DYNFOV"] = "Dynamic FOV"  -- MT
L["GEMS_CVAR_DRAGON_DYNFOV_DESC"] = "Dynamic field-of-view based on gliding speed. Creates a sense of speed. Disable if motion sickness."  -- MT
L["GEMS_CVAR_DRAGON_MAXPITCH"] = "Max Pitch Rate"  -- MT
L["GEMS_CVAR_DRAGON_MAXPITCH_DESC"] = "Maximum pitch rate for keyboard dragonriding. Default 5 can feel sluggish. 6-7 is more responsive."  -- MT
L["GEMS_CVAR_DRAGON_MAXTURN"] = "Max Turn Rate"  -- MT
L["GEMS_CVAR_DRAGON_MAXTURN_DESC"] = "Maximum turn rate for keyboard dragonriding. Default 8 can feel slow. 10 improves maneuverability."  -- MT
L["GEMS_CVAR_DRAGON_MINPITCH"] = "Min Pitch Rate"  -- MT
L["GEMS_CVAR_DRAGON_MINPITCH_DESC"] = "Minimum pitch rate. Affects fine-grained pitch control. Slightly higher gives more precise control."  -- MT
L["GEMS_CVAR_DRAGON_PITCHCTRL"] = "Pitch Control Mode"  -- MT
L["GEMS_CVAR_DRAGON_PITCHCTRL_DESC"] = "How forward/back inputs affect pitch. 3=toggle. Most comfortable for keyboard players."  -- MT

-- Feature: CVar Profiles & Context-Aware Switching (Phase 2)
L["GEMS_CVAR_PROFILE_GENERAL"] = "General (Default)"  -- MT
L["GEMS_CVAR_PROFILE_RAID"] = "Raid"  -- MT
L["GEMS_CVAR_PROFILE_RAID_DESC"] = "Optimized for raid encounters: tighter plate range, stacking nameplate motion"  -- MT
L["GEMS_CVAR_PROFILE_MPLUS"] = "Mythic+"  -- MT
L["GEMS_CVAR_PROFILE_MPLUS_DESC"] = "Optimized for Mythic+ dungeons: enemy minion plates, tighter range"  -- MT
L["GEMS_CVAR_PROFILE_SOLO"] = "Solo / Open World"  -- MT
L["GEMS_CVAR_PROFILE_SOLO_DESC"] = "Optimized for solo content: full visuals, wider interact arc, plates off"  -- MT
L["GEMS_CVAR_PROFILE_PVP"] = "PvP"  -- MT
L["GEMS_CVAR_PROFILE_PVP_DESC"] = "Optimized for PvP: friendly plates on, enemy minions, stacking motion"  -- MT
L["GEMS_CVAR_PROFILE_ACTIVE"] = "Active Profile: %s"  -- MT
L["GEMS_CVAR_PROFILE_SELECT"] = "Select Profile"  -- MT
L["GEMS_CVAR_PROFILE_AUTO"] = "Auto (context-aware)"  -- MT
L["GEMS_CVAR_PROFILE_AUTOSWITCH"] = "Auto-switch by context"  -- MT
L["GEMS_CVAR_PROFILE_AUTOSWITCH_DESC"] = "Automatically switch CVar profile when entering raids, dungeons, PvP, or open world"  -- MT
L["GEMS_CVAR_PROFILE_MANAGE"] = "Manage Profiles..."  -- MT
L["GEMS_CVAR_PROFILE_CREATE"] = "Create Profile"  -- MT
L["GEMS_CVAR_PROFILE_CREATE_NAME"] = "Profile Name:"  -- MT
L["GEMS_CVAR_PROFILE_CLONE_FROM"] = "Clone From:"  -- MT
L["GEMS_CVAR_PROFILE_DELETE"] = "Delete Profile"  -- MT
L["GEMS_CVAR_PROFILE_DELETE_CONFIRM"] = "Delete custom profile \"%s\"? This cannot be undone."  -- MT
L["GEMS_CVAR_PROFILE_OVERRIDE"] = "Profile Override"  -- MT
L["GEMS_CVAR_PROFILE_OVERRIDE_NONE"] = "No override (use General)"  -- MT
L["GEMS_CVAR_PROFILE_ADD_OVERRIDE"] = "Add Override..."  -- MT
L["GEMS_CVAR_PROFILE_SWITCHED"] = "CVar profile switched to: %s"  -- MT
L["GEMS_CVAR_PROFILE_QUEUED"] = "%d secure CVars queued (applied out of combat)"  -- MT
L["GEMS_CVAR_CHANGES_DETECTED"] = "%d CVars changed since last session"  -- MT
L["GEMS_CVAR_CHANGES_DISMISS"] = "Dismiss"  -- MT
L["GEMS_CVAR_CHANGES_FIX_ALL"] = "Fix All Changed"  -- MT
L["GEMS_CVAR_CHANGES_CAUSE_PATCH"] = "Likely: game patch reset"  -- MT
L["GEMS_CVAR_CHANGES_CAUSE_ADDON"] = "Likely: changed by addon/UI"  -- MT
L["GEMS_CVAR_CHANGES_CAUSE_AUTOFIX"] = "Auto-fixed by EMS"  -- MT
L["GEMS_CVAR_CHANGES_CAUSE_UNKNOWN"] = "Changed since last session"  -- MT
L["GEMS_CVAR_PROFILE_NOT_FOUND"] = "Unknown profile: %s"  -- MT
L["GEMS_CVAR_AUTO_TOGGLED"] = "CVar auto-switch: %s"  -- MT
L["GEMS_CVAR_NO_CHANGES"] = "No CVar changes detected since last session"  -- MT
L["GEMS_CVAR_PROFILE_RENAME"] = "Rename"  -- MT
L["GEMS_CVAR_PROFILE_OVERRIDES"] = "Overrides (%d)"  -- MT
L["GEMS_CVAR_PROFILE_NO_OVERRIDES"] = "No overrides"  -- MT
L["GEMS_CVAR_MAP_HEADER"] = "Context Profile Map"  -- MT
L["GEMS_CVAR_MAP_DESC"] = "Choose which CVar profile applies for each context"  -- MT
L["GEMS_CVAR_MAP_DEFAULT"] = "Default (%s)"  -- MT
L["GEMS_CVAR_MAP_NONE"] = "General (no profile)"  -- MT

-- SQW Optimizer
L["GEMS_SQW_OPTIMIZER"] = "Dynamic SQW Optimizer"  -- MT
L["GEMS_SQW_OPTIMIZER_DESC"] = "Automatically adjusts SpellQueueWindow based on network latency"  -- MT
L["GEMS_SQW_BUFFER"] = "Safety Buffer (ms)"  -- MT
L["GEMS_SQW_BUFFER_DESC"] = "Higher = fewer gaps, lower = more responsive. 100ms recommended."  -- MT
L["GEMS_SQW_LIVE"] = "SQW: %dms (latency: %dms + buffer: %dms)"  -- MT
L["GEMS_SQW_ADVISORY"] = "Recommended click rate: %dms"  -- MT
L["GEMS_SQW_ADVISORY_DETAIL"] = "GCD: %dms, SQW: %dms, Latency: %dms"  -- MT
L["GEMS_SQW_ADVISORY_DELTA"] = "Your setting: %dms (%dms %s than optimal)"  -- MT
L["GEMS_SQW_MANAGED"] = "Managed by SQW Optimizer"  -- MT
L["GEMS_SQW_ENABLED"] = "SQW Optimizer enabled"  -- MT
L["GEMS_SQW_DISABLED"] = "SQW Optimizer disabled (SQW reverted to %d)"  -- MT
L["GEMS_SQW_STATUS"] = "SQW: %dms | Latency: %dms | Buffer: %dms | Advisory: %dms"  -- MT
L["GEMS_SQW_BUFFER_SET"] = "SQW buffer set to %dms"  -- MT
L["GEMS_SQW_BUFFER_RANGE"] = "Buffer must be between 50 and 200"  -- MT
L["GEMS_SQW_SLOWER"] = "slower"  -- MT
L["GEMS_SQW_FASTER"] = "faster"  -- MT
