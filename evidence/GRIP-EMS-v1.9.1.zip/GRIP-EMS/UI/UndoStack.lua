-- GRIP-EMS: UndoStack
-- Undo/redo action stack for sequence editor operations

local _, GRIPEMS = ...

local UndoStack = {}
GRIPEMS.UndoStack = UndoStack

UndoStack.undoStack = {}
UndoStack.redoStack = {}
UndoStack.maxDepth = 30

--- Create an independent undo/redo stack instance.
--- @return table New UndoStack instance with its own stacks
function UndoStack:New()
    local o = {
        undoStack = {},
        redoStack = {},
        maxDepth = (GRIPEMS.Defaults and GRIPEMS.Defaults.UNDO_MAX_DEPTH) or 30,
    }
    setmetatable(o, { __index = UndoStack })
    return o
end

--- Push an undoable action onto the stack.
--- @param undoFn function Reverts the action
--- @param redoFn function Re-applies the action
--- @param desc string Human-readable description
function UndoStack:Push(undoFn, redoFn, desc)
    if type(undoFn) ~= "function" then
        error("UndoStack:Push() undoFn must be a function, got " .. type(undoFn), 2)
    end
    if type(redoFn) ~= "function" then
        error("UndoStack:Push() redoFn must be a function, got " .. type(redoFn), 2)
    end
    local entry = { undoFn = undoFn, redoFn = redoFn, description = desc }
    self.undoStack[#self.undoStack + 1] = entry

    local D = GRIPEMS.Defaults
    local max = (D and D.UNDO_MAX_DEPTH) or self.maxDepth
    while #self.undoStack > max do
        table.remove(self.undoStack, 1)
    end

    -- New action invalidates the redo branch
    wipe(self.redoStack)

    if GRIPEMS.Fire then
        GRIPEMS:Fire("UNDO_STATE_CHANGED")
    end
end

--- Undo the most recent action.
--- @param suppressTarget table|nil Target for _suppressUndo flag (defaults to StepListView)
--- @return boolean True if an action was undone
function UndoStack:Undo(suppressTarget)
    if #self.undoStack == 0 then
        return false
    end

    local action = table.remove(self.undoStack)
    self.redoStack[#self.redoStack + 1] = action

    -- Suppress undo pushes during replay
    local target = suppressTarget or GRIPEMS.StepListView
    if target then
        target._suppressUndo = true
    end
    local ok, err = pcall(action.undoFn)
    if target then
        target._suppressUndo = false
    end
    if not ok then
        error(err)
    end

    if GRIPEMS.Fire then
        GRIPEMS:Fire("UNDO_STATE_CHANGED")
    end
    return true
end

--- Redo the most recently undone action.
--- @param suppressTarget table|nil Target for _suppressUndo flag (defaults to StepListView)
--- @return boolean True if an action was redone
function UndoStack:Redo(suppressTarget)
    if #self.redoStack == 0 then
        return false
    end

    local action = table.remove(self.redoStack)
    self.undoStack[#self.undoStack + 1] = action

    -- Suppress undo pushes during replay
    local target = suppressTarget or GRIPEMS.StepListView
    if target then
        target._suppressUndo = true
    end
    local ok, err = pcall(action.redoFn)
    if target then
        target._suppressUndo = false
    end
    if not ok then
        error(err)
    end

    if GRIPEMS.Fire then
        GRIPEMS:Fire("UNDO_STATE_CHANGED")
    end
    return true
end

--- Clear both stacks (e.g. on sequence switch).
function UndoStack:Clear()
    wipe(self.undoStack)
    wipe(self.redoStack)

    if GRIPEMS.Fire then
        GRIPEMS:Fire("UNDO_STATE_CHANGED")
    end
end

--- @return boolean True if there are actions to undo
function UndoStack:CanUndo()
    return #self.undoStack > 0
end

--- @return boolean True if there are actions to redo
function UndoStack:CanRedo()
    return #self.redoStack > 0
end

--- @return string|nil Description of the top undo action
function UndoStack:GetUndoDescription()
    local top = self.undoStack[#self.undoStack]
    return top and top.description or nil
end

--- @return string|nil Description of the top redo action
function UndoStack:GetRedoDescription()
    local top = self.redoStack[#self.redoStack]
    return top and top.description or nil
end
