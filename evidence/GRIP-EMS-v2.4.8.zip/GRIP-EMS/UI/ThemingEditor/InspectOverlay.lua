-- GRIP-EMS: Per-Element Theming editor -- Inspect Mode overlay (Phase D)
--
-- Created:    2026-04-23
-- Updated:    2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.
--
-- "Paradigm D" of the theming surface: a click-to-select overlay. Enter
-- via /gems theme inspect (wired in Core.lua). While active the cursor
-- picks up any frame tagged with _emsElementClass (set by
-- UI.Util:RegisterPanelFrame), a magenta outline traces the widget, and
-- a small tooltip follows the cursor naming the class. Clicking selects
-- the class and opens the theming editor scrolled to it; Escape exits.
--
-- Design reference: Research/Access/ThemingEditor_Design_2026-04-22.md
-- section 6.4 (Paradigm D) and section 16.4 (Phase D scope).

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

GRIPEMS.UI = GRIPEMS.UI or {}
GRIPEMS.UI.InspectOverlay = GRIPEMS.UI.InspectOverlay or {}
local IO = GRIPEMS.UI.InspectOverlay

local OUTLINE_COLOR = { r = 1.0, g = 0.25, b = 0.85, a = 1.0 }
local TOOLTIP_OFFSET_X = 14
local TOOLTIP_OFFSET_Y = -14

---------------------------------------------------------------------------
-- Two-frame architecture for Inspect Mode:
-- * cursorFrame: visible overlay (outline + tooltip), mouse DISABLED so
--   we can walk _classWidgets and ask each widget IsMouseOver(). Leaving
--   mouse disabled here also keeps GetMouseFocus() honest for any other
--   addon's UI inspection.
-- * clickTrap: invisible mouse-eating frame at FrameLevel 2000, absorbs
--   every mouse-down event while Inspect Mode is active so the underlying
--   widget never fires its own click handler. Hidden whenever Inspect
--   Mode is inactive -- a persistent click-blocker would be a UX disaster.
---------------------------------------------------------------------------
local function buildFrames()
    -- Frame A: cursor tracker (mouse disabled, visible)
    local cursorFrame = CreateFrame("Frame", "GRIPEMS_InspectOverlay", UIParent)
    cursorFrame:SetFrameStrata("FULLSCREEN_DIALOG")
    cursorFrame:SetAllPoints(UIParent)
    cursorFrame:EnableMouse(false)
    cursorFrame:Hide()

    -- Outline: four thin textures framing the hovered widget. Re-anchored
    -- every OnUpdate tick when the target changes.
    local outline = CreateFrame("Frame", nil, cursorFrame)
    outline:SetFrameStrata("FULLSCREEN_DIALOG")
    outline:EnableMouse(false)
    outline:Hide()
    local function edge(parent)
        local t = parent:CreateTexture(nil, "OVERLAY")
        t:SetColorTexture(OUTLINE_COLOR.r, OUTLINE_COLOR.g, OUTLINE_COLOR.b, OUTLINE_COLOR.a)
        return t
    end
    outline.top = edge(outline)
    outline.bottom = edge(outline)
    outline.left = edge(outline)
    outline.right = edge(outline)
    cursorFrame.outline = outline

    -- Class tooltip: small text label that follows the cursor.
    local tip = CreateFrame("Frame", nil, cursorFrame, "TooltipBackdropTemplate")
    tip:SetFrameStrata("TOOLTIP")
    tip:SetSize(220, 28)
    tip:EnableMouse(false)
    tip:Hide()
    local fs = tip:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    fs:SetPoint("LEFT", tip, "LEFT", 8, 0)
    fs:SetPoint("RIGHT", tip, "RIGHT", -8, 0)
    fs:SetJustifyH("LEFT")
    tip.text = fs
    cursorFrame.tip = tip

    -- Frame B: click trap (mouse enabled, invisible)
    local trap = CreateFrame("Frame", "GRIPEMS_InspectClickTrap", UIParent)
    trap:SetFrameStrata("FULLSCREEN_DIALOG")
    trap:SetFrameLevel(2000) -- above default UI
    trap:SetAllPoints(UIParent)
    trap:EnableMouse(true)
    trap:EnableKeyboard(false) -- keyboard stays on cursorFrame
    trap:Hide()

    return cursorFrame, trap
end

-- overlay = cursorFrame (name kept to minimise diff against existing code)
local overlay
local clickTrap

---------------------------------------------------------------------------
-- Move the outline to frame a target widget. Uses ClearAllPoints +
-- SetPoint on each edge texture so the rectangle tracks exactly.
---------------------------------------------------------------------------
local function frameTarget(target)
    if not overlay then
        return
    end
    local o = overlay.outline
    if not target then
        o:Hide()
        return
    end
    local thick = 2
    o:ClearAllPoints()
    o:SetPoint("TOPLEFT", target, "TOPLEFT", -thick, thick)
    o:SetPoint("BOTTOMRIGHT", target, "BOTTOMRIGHT", thick, -thick)
    o:Show()
    o.top:ClearAllPoints()
    o.top:SetPoint("TOPLEFT", o, "TOPLEFT", 0, 0)
    o.top:SetPoint("TOPRIGHT", o, "TOPRIGHT", 0, 0)
    o.top:SetHeight(thick)
    o.bottom:ClearAllPoints()
    o.bottom:SetPoint("BOTTOMLEFT", o, "BOTTOMLEFT", 0, 0)
    o.bottom:SetPoint("BOTTOMRIGHT", o, "BOTTOMRIGHT", 0, 0)
    o.bottom:SetHeight(thick)
    o.left:ClearAllPoints()
    o.left:SetPoint("TOPLEFT", o, "TOPLEFT", 0, 0)
    o.left:SetPoint("BOTTOMLEFT", o, "BOTTOMLEFT", 0, 0)
    o.left:SetWidth(thick)
    o.right:ClearAllPoints()
    o.right:SetPoint("TOPRIGHT", o, "TOPRIGHT", 0, 0)
    o.right:SetPoint("BOTTOMRIGHT", o, "BOTTOMRIGHT", 0, 0)
    o.right:SetWidth(thick)
end

---------------------------------------------------------------------------
-- Walk _classWidgets and return the topmost mouse-over-tagged frame.
-- Replaces GetMouseFocus + parent-walk because the click-trap absorbs
-- mouse focus while Inspect Mode is active, so GetMouseFocus would
-- always return the trap. We instead enumerate every widget that
-- RegisterPanelFrame has tagged and ask each one IsMouseOver(). The
-- widget with the highest FrameLevel wins ties (innermost stacked).
---------------------------------------------------------------------------
local function findHoveredEmsFrame()
    local widgets = GRIPEMS.UI and GRIPEMS.UI._classWidgets
    if type(widgets) ~= "table" then
        return nil, nil
    end
    local best, bestClass, bestLevel = nil, nil, -1
    for class, list in pairs(widgets) do
        if type(list) == "table" then
            for i = 1, #list do
                local w = list[i]
                if w and w.IsMouseOver and w.IsShown and w:IsShown() and w:IsMouseOver() then
                    local lvl = (w.GetFrameLevel and w:GetFrameLevel()) or 0
                    if lvl > bestLevel then
                        best, bestClass, bestLevel = w, class, lvl
                    end
                end
            end
        end
    end
    return best, bestClass
end

---------------------------------------------------------------------------
-- Cursor-follow OnUpdate. Only runs while the overlay is visible.
---------------------------------------------------------------------------
local function onUpdate(self)
    -- self is cursorFrame. Move the class tooltip to follow the cursor.
    local x, y = GetCursorPosition()
    local scale = self:GetEffectiveScale() or 1
    if scale == 0 then
        scale = 1
    end
    self.tip:ClearAllPoints()
    self.tip:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", x / scale + TOOLTIP_OFFSET_X, y / scale + TOOLTIP_OFFSET_Y)
    self.tip:Show()

    -- findHoveredEmsFrame replaces GetMouseFocus because the click-trap
    -- absorbs mouse focus while Inspect Mode is active.
    local target, class = findHoveredEmsFrame()
    self._hoverClass = class
    self._hoverTarget = target
    if target and class then
        frameTarget(target)
        self.tip.text:SetText("|cffff44ccEMS|r  " .. class)
    else
        frameTarget(nil)
        self.tip.text:SetText(L["ACCESS_THEMING_INSPECT_NO_CLASS"] or "No EMS class on this frame.")
    end
end

---------------------------------------------------------------------------
-- Event handler: PLAYER_REGEN_DISABLED only. GLOBAL_MOUSE_DOWN was
-- replaced by the click-trap's OnMouseDown handler so the click is
-- absorbed instead of merely observed -- the underlying widget never
-- sees the click while Inspect Mode is active.
---------------------------------------------------------------------------
local function onEvent(self, event, ...)
    if event == "PLAYER_REGEN_DISABLED" then
        if IO:IsActive() then
            IO:Exit()
        end
        return
    end
end

---------------------------------------------------------------------------
-- Click-trap OnMouseDown. The trap absorbs the click directly (no
-- propagation), so the underlying widget's normal action does not fire.
-- Hover state was set by cursorFrame's OnUpdate tick, so we read it
-- through the overlay upvalue rather than from self (self is the trap).
---------------------------------------------------------------------------
local function onClickTrap(self, button)
    if not IO:IsActive() then
        return
    end
    local cf = overlay -- cursor frame upvalue
    if button ~= "LeftButton" then
        -- Right-click or other: exit without selection.
        IO:Exit()
        return
    end
    local class = cf and cf._hoverClass or nil
    IO:Exit()
    if class and GRIPEMS.UI and GRIPEMS.UI.OpenThemeEditor then
        GRIPEMS.UI.OpenThemeEditor(class)
    end
end

---------------------------------------------------------------------------
-- Escape key handler. Taint-sweep rule: SetPropagateKeyboardInput is
-- pcall-wrapped so a throw never leaks into the default taint logs.
---------------------------------------------------------------------------
local function onKeyDown(self, key)
    if not IO:IsActive() then
        return
    end
    pcall(self.SetPropagateKeyboardInput, self, true)
    if key == "ESCAPE" then
        pcall(self.SetPropagateKeyboardInput, self, false)
        IO:Exit()
    end
end

---------------------------------------------------------------------------
-- Public API
---------------------------------------------------------------------------

--- Enter Inspect Mode. Refuses in combat. Auto-closes the standalone
--- theming modal if open so the overlay is not competing for strata.
function IO:Enter()
    if InCombatLockdown and InCombatLockdown() then
        if GRIPEMS.Print then
            GRIPEMS:Print(
                "|cFFFFAA33"
                    .. (L["ACCESS_THEMING_MODAL_COMBAT_BLOCKED"] or "Theme editor is hidden during combat.")
                    .. "|r"
            )
        end
        return
    end
    if not overlay then
        overlay, clickTrap = buildFrames()
        overlay:SetScript("OnUpdate", onUpdate)
        overlay:SetScript("OnEvent", onEvent)
        overlay:SetScript("OnKeyDown", onKeyDown)
        overlay:RegisterEvent("PLAYER_REGEN_DISABLED")
        -- GLOBAL_MOUSE_DOWN registration removed -- clickTrap absorbs.
        clickTrap:SetScript("OnMouseDown", onClickTrap)
    end
    if self._active then
        return
    end

    local TE = GRIPEMS.UI and GRIPEMS.UI.ThemingEditor
    if TE and TE.CloseModal then
        TE.CloseModal()
    end

    overlay:EnableKeyboard(true)
    pcall(overlay.SetPropagateKeyboardInput, overlay, true)
    if SetCursor then
        pcall(SetCursor, "CAST_CURSOR")
    end
    overlay:Show()
    clickTrap:Show()
    self._active = true

    if GRIPEMS.Print then
        GRIPEMS:Print(
            "|cff77ccff"
                .. (L["ACCESS_THEMING_INSPECT_ENTER_HINT"] or "Inspect mode on. Hover any EMS frame to see its theme class. Press Escape to exit.")
                .. "|r"
        )
    end
end

--- Exit Inspect Mode. Safe to call when inactive.
function IO:Exit()
    if not self._active then
        if overlay then
            overlay:Hide()
        end
        if clickTrap then
            clickTrap:Hide()
        end
        return
    end
    self._active = false
    if overlay then
        overlay:EnableKeyboard(false)
        pcall(overlay.SetPropagateKeyboardInput, overlay, true)
        overlay:Hide()
        if overlay.outline then
            overlay.outline:Hide()
        end
        if overlay.tip then
            overlay.tip:Hide()
        end
        overlay._hoverClass = nil
        overlay._hoverTarget = nil
    end
    if clickTrap then
        clickTrap:Hide()
    end
    if SetCursor then
        pcall(SetCursor, nil)
    end
end

--- Returns true while Inspect Mode is showing.
function IO:IsActive()
    return self._active == true
end

-- end of UI/ThemingEditor/InspectOverlay.lua
