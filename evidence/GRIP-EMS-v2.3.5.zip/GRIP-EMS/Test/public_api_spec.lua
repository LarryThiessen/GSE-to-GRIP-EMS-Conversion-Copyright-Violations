-- GRIP-EMS: Test spec for the frozen public plugin API (GRIPEMS.API, Phase 1a-1c)
--
-- Created:    2026-06-23
-- Updated:    2026-06-29
-- Patch: 12.0.7.68275 Midnight (Retail LIVE)
--
-- Registers tests in TestSuite under category "public_api" covering Core/PublicAPI.lua:
--   freeze        -- the GRIPEMS.API proxy rejects new and existing-key writes
--   handshake     -- API_VERSION / EMS_VERSION / RequireVersion
--   capabilities  -- GetCapabilities returns a fresh copy each call
--   events        -- On/Off over the CallbackHandler bus, pcall isolation, payload delivery
--   data          -- read-only accessors return fresh, isolated snapshots
--   sequences     -- RegisterSequences re-export reaches GetRegisteredPlugins
--   ui            -- layout-provider registry: freeze, validate, register, set-active, GetHost
--   preview       -- GRIPEMS.API.Preview facade: mode get/set, update, capability
--
-- Dual-mode: in-game it loads as a normal *_spec.lua via /gems test. Run directly
-- under plain Lua 5.1 (lua Test/public_api_spec.lua, from the EMS repo root) it
-- bootstraps the REAL CallbackHandler bus + PluginAPI + PublicAPI in a headless
-- sandbox and runs its own tests. Exit code 0 = all passed, 1 = at least one fail.

local ADDON_NAME, GRIPEMS = ...

local standalone = false

-- ---------------------------------------------------------------------------
-- Headless bootstrap (only when not loaded by the game client).
-- ---------------------------------------------------------------------------

if not GRIPEMS then
    standalone = true
    local addonName = "GRIP-EMS"

    -- Globals the WoW libs expect that plain Lua 5.1 does not provide.
    if not _G.strmatch then
        _G.strmatch = string.match
    end
    if not _G.securecallfunction then
        -- Deliberately a bare pass-through (no pcall): in headless mode the only
        -- crash isolation is PublicAPI's own wrapper pcall, so the throwing-handler
        -- test genuinely proves the wrapper -- not CallbackHandler -- swallows it.
        _G.securecallfunction = function(fn, ...)
            return fn(...)
        end
    end

    -- Locate a repo file from the EMS root, the Test dir, or the Hub root.
    local function loadModule(relPath)
        local prefixes = { "", "../", "GRIP/EMS/" }
        for _, prefix in ipairs(prefixes) do
            -- loadfile is dev-harness file I/O, intentionally outside the WoW std.
            -- selene: allow(undefined_variable)
            local chunk = loadfile(prefix .. relPath)
            if chunk then
                return chunk
            end
        end
        error("could not locate " .. relPath .. " (run from the EMS repo root)")
    end

    -- Real LibStub + CallbackHandler register themselves into _G.
    loadModule("Libs/LibStub/LibStub.lua")()
    loadModule("Libs/CallbackHandler-1.0/CallbackHandler-1.0.lua")()

    local stub = _G.LibStub

    -- Minimal AceLocale: every key resolves to itself (string.format ignores
    -- the trailing args when the format string carries no specifiers).
    local locale = setmetatable({}, {
        __index = function(_, key)
            return key
        end,
    })
    stub.libs["AceLocale-3.0"] = {
        GetLocale = function()
            return locale
        end,
    }
    stub.minors["AceLocale-3.0"] = 1

    GRIPEMS = {
        version = "headless",
        Print = function() end,
        Debug = function() end,
    }

    -- Event bus, created exactly as Core.lua does.
    local cbRegistry = stub("CallbackHandler-1.0"):New(GRIPEMS)
    function GRIPEMS:Fire(event, ...)
        cbRegistry:Fire(event, ...)
    end

    -- Fake Engine + Settings: only the read surface PublicAPI touches.
    GRIPEMS.Engine = {
        sequences = {},
        currentContext = "none",
        GetActiveVersion = function(_, seqData)
            if not seqData or not seqData.versions then
                return nil
            end
            local idx = seqData.defaultVersion or 1
            return seqData.versions[idx] or seqData.versions[1]
        end,
        GetSequenceList = function(self)
            local list = {}
            for name, entry in pairs(self.sequences) do
                local version = self:GetActiveVersion(entry.data)
                list[#list + 1] = {
                    name = name,
                    stepCount = (version and version.steps) and #version.steps or 0,
                    stepFunction = version and version.stepFunction or "sequential",
                }
            end
            table.sort(list, function(a, b)
                return a.name < b.name
            end)
            return list
        end,
        -- Phase A (API v3): the real Engine:GetActiveVersionStepList expands the
        -- active version into execution order (BuildExecutionOrder) and resolves
        -- each step's spell through SpellCache. The full suite loads the real
        -- Engine, so this fake only backs the focused direct run -- the same
        -- dual-mode split as the fake GetActiveVersion above. It walks the active
        -- version's steps in authored order (execution order == authored order for
        -- a Sequential seed) and resolves through the test-installed SpellCache
        -- stub, returning the same { index, spellID, spellName, icon } shape.
        GetActiveVersionStepList = function(self, seqData)
            local ver = self:GetActiveVersion(seqData)
            if not ver or type(ver.steps) ~= "table" then
                return {}
            end
            local SC = GRIPEMS.SpellCache
            local classID = seqData and seqData.classID or nil
            local out = {}
            for i = 1, #ver.steps do
                local macrotext = ver.steps[i]
                local spellName, spellID, icon
                if SC and SC.ParseSpellFromMacrotext then
                    spellName = SC:ParseSpellFromMacrotext(macrotext)
                end
                if spellName and SC then
                    if SC.GetSpellID then
                        spellID = SC:GetSpellID(spellName, classID)
                    end
                    if SC.GetIcon then
                        icon = SC:GetIcon(spellName)
                    end
                end
                out[i] = { index = i, spellID = spellID, spellName = spellName, icon = icon }
            end
            return out
        end,
    }
    GRIPEMS.Settings = {
        values = { debug = false },
        Get = function(self, key)
            return self.values[key]
        end,
        -- Phase 1b: SetActiveLayoutProvider persists uiLayout through Set, so the
        -- fake needs a writer for Set/Get("uiLayout") to round-trip headlessly.
        Set = function(self, key, value)
            self.values[key] = value
        end,
    }

    -- Phase 1c: the Preview facade reads GRIPEMS.Defaults.PREVIEW_MODE_* (always
    -- present in-game; Data/Defaults.lua is not loaded headless). Provide a
    -- minimal stand-in with just the preview-mode constants so GetMode/SetMode
    -- resolve without the data layer.
    GRIPEMS.Defaults = {
        PREVIEW_MODE_ICONS = "icons",
        PREVIEW_MODE_TEXT = "text",
        PREVIEW_MODE_COMPILED = "compiled",
        -- Phase 2c: StepFunctions.lua reads these at load (.name fields) and at
        -- run (ExpandPriority / ValidateSteps / RunExpander). Data/Defaults.lua
        -- is not loaded headless, so mirror the step-function constants here.
        STEP_SEQUENTIAL = "Sequential",
        STEP_RANDOM = "Random",
        STEP_PRIORITY = "Priority",
        STEP_REVERSE_PRIORITY = "ReversePriority",
        ATTR_TYPE_MACRO = "macro",
        MAX_MACROTEXT_LENGTH = 255,
    }

    -- Load the REAL registrar then the REAL public API into this sandbox.
    loadModule("Core/PluginAPI.lua")(addonName, GRIPEMS)
    -- Phase 2c: the REAL step-function module so RegisterStepFunction delegates
    -- to the live registry headlessly (needs only Defaults + AceLocale).
    loadModule("Engine/StepFunctions.lua")(addonName, GRIPEMS)
    loadModule("Core/PublicAPI.lua")(addonName, GRIPEMS)

    -- Mirror the in-game boot state: UI/MainFrame.lua registers the real
    -- "classic" layout provider at load. The headless sandbox has no UI layer,
    -- so register a minimal stand-in here. This lets the registry default and
    -- the SetActive test's restore-to-original path resolve "classic" without
    -- CreateFrame, matching the live addon.
    GRIPEMS.API.UI:RegisterLayoutProvider("classic", { id = "classic", name = "Classic" })

    -- TestSuite shim mirroring the in-game Pass/Fail/Skip contract.
    local current
    local TS = { tests = {} }
    function TS:Register(name, category, fn)
        self.tests[#self.tests + 1] = { name = name, category = category, fn = fn }
    end
    function TS:Pass()
        current.status = "pass"
    end
    function TS:Fail(msg)
        current.status = "fail"
        current.message = msg or "no reason"
    end
    function TS:Skip(msg)
        current.status = "skip"
        current.message = msg or ""
    end
    function TS:Assert(cond, msg)
        if not cond then
            self:Fail(msg or "assertion failed")
        end
    end
    function TS:RunStandalone()
        local passed, failed, skipped = 0, 0, 0
        for _, t in ipairs(self.tests) do
            current = { status = "pending" }
            local runOk, err = pcall(t.fn, self)
            if not runOk then
                current.status = "fail"
                current.message = "error: " .. tostring(err)
            end
            if current.status == "pass" then
                passed = passed + 1
                print("PASS  " .. t.name)
            elseif current.status == "skip" then
                skipped = skipped + 1
                print("SKIP  " .. t.name .. " -- " .. tostring(current.message))
            else
                failed = failed + 1
                print("FAIL  " .. t.name .. " -- " .. tostring(current.message))
            end
        end
        print(string.format("RESULT %d passed, %d failed, %d skipped", passed, failed, skipped))
        return failed
    end
    GRIPEMS.TestSuite = TS
end

-- ---------------------------------------------------------------------------
-- Shared spec body (runs both in-game and headless).
-- ---------------------------------------------------------------------------

local TS = GRIPEMS.TestSuite
if not TS then
    return
end

local CATEGORY = "public_api"

-- Assertion helper: returns false (and marks the test failed) on mismatch so the
-- caller can early-return. Avoids TestSuite's file-local currentResult, which is
-- not visible from a spec file.
local function eq(self, expected, actual, label)
    if expected ~= actual then
        self:Fail((label or "value") .. ": expected " .. tostring(expected) .. ", got " .. tostring(actual))
        return false
    end
    return true
end

-- ===========================================================================
-- Tier 0 -- freeze + handshake
-- ===========================================================================

TS:Register("Public API: frozen table rejects new and existing-key writes", CATEGORY, function(self)
    local API = GRIPEMS.API
    if not API then
        self:Skip("GRIPEMS.API not available")
        return
    end
    local newOk = pcall(function()
        API.brandNewField = 1
    end)
    if not eq(self, false, newOk, "writing a new key raises an error") then
        return
    end
    local overwriteOk = pcall(function()
        API.API_VERSION = 999
    end)
    if not eq(self, false, overwriteOk, "overwriting an existing key raises an error") then
        return
    end
    if not eq(self, 3, API.API_VERSION, "API_VERSION unchanged after the blocked write") then
        return
    end
    if not eq(self, API, _G.GRIPEMS_API, "global alias points at the same frozen table") then
        return
    end
    self:Pass()
end)

TS:Register("Public API: version handshake", CATEGORY, function(self)
    local API = GRIPEMS.API
    if not API then
        self:Skip("GRIPEMS.API not available")
        return
    end
    if not eq(self, true, (API:RequireVersion(1)), "RequireVersion(1) succeeds") then
        return
    end
    if not eq(self, true, (API:RequireVersion(2)), "RequireVersion(2) succeeds on the v2 surface") then
        return
    end
    if not eq(self, true, (API:RequireVersion(3)), "RequireVersion(3) succeeds on the v3 surface") then
        return
    end
    local high, reason = API:RequireVersion(API.API_VERSION + 1)
    if not eq(self, false, high, "RequireVersion(API_VERSION + 1) fails") then
        return
    end
    if not eq(self, "string", type(reason), "a failed handshake returns a reason string") then
        return
    end
    if not eq(self, GRIPEMS.version, API.EMS_VERSION, "EMS_VERSION mirrors GRIPEMS.version") then
        return
    end
    self:Pass()
end)

TS:Register("Public API: GetCapabilities returns a fresh copy each call", CATEGORY, function(self)
    local API = GRIPEMS.API
    if not API then
        self:Skip("GRIPEMS.API not available")
        return
    end
    local first = API:GetCapabilities()
    if not eq(self, "table", type(first), "GetCapabilities returns a table") then
        return
    end
    local originalCount = #first
    first[#first + 1] = "_TS_mutation"
    local second = API:GetCapabilities()
    if not eq(self, originalCount, #second, "a later call is unaffected by mutating an earlier result") then
        return
    end
    if not eq(self, false, (first == second), "each call returns a distinct table") then
        return
    end
    self:Pass()
end)

TS:Register("Public API: GetCapabilities advertises the v2 plugin surface", CATEGORY, function(self)
    local API = GRIPEMS.API
    if not API then
        self:Skip("GRIPEMS.API not available")
        return
    end
    local caps = API:GetCapabilities()
    local present = {}
    if type(caps) == "table" then
        for _, c in ipairs(caps) do
            present[c] = true
        end
    end
    for _, want in ipairs({ "plugins", "authoring", "panels", "views", "settings", "cvars" }) do
        if not eq(self, true, present[want] == true, "GetCapabilities includes '" .. want .. "'") then
            return
        end
    end
    self:Pass()
end)

-- ===========================================================================
-- Tier 1 -- events
-- ===========================================================================

TS:Register("Public API: On rejects unknown events and non-function handlers", CATEGORY, function(self)
    local API = GRIPEMS.API
    if not API then
        self:Skip("GRIPEMS.API not available")
        return
    end
    if not eq(self, false, (API:On("_TS_NOT_AN_EVENT", function() end)), "unknown event is rejected") then
        return
    end
    if not eq(self, false, (API:On("SEQUENCE_CREATED", "not a function")), "non-function handler is rejected") then
        return
    end
    self:Pass()
end)

TS:Register("Public API: On delivers payload, Off stops delivery, unknown Off is safe", CATEGORY, function(self)
    local API = GRIPEMS.API
    if not API or not GRIPEMS.Fire then
        self:Skip("GRIPEMS.API or event bus not available")
        return
    end
    -- PLUGIN_SEQUENCES_LOADED has no heavy core listener, so firing it during a
    -- test has no side effects beyond this spec's own handler.
    local event = "PLUGIN_SEQUENCES_LOADED"
    local received = {}
    local handle = API:On(event, function(a, b)
        received[#received + 1] = { a, b }
    end)
    -- Diagnose a broken On() directly, before any fire, so a failure names the
    -- real cause instead of a downstream count mismatch.
    if not eq(self, "string", type(handle), "On returns an opaque string handle") then
        return
    end

    GRIPEMS:Fire(event, "alpha", "beta")
    local afterFire = #received
    API:Off(handle)
    GRIPEMS:Fire(event, "gamma")
    local afterOff = #received
    local unknownOffOk = pcall(function()
        API:Off("_TS_unknown_handle")
    end)

    if not eq(self, 1, afterFire, "the handler ran exactly once on the first fire") then
        return
    end
    if not eq(self, "alpha", received[1][1], "first payload arg delivered (event name not leaked)") then
        return
    end
    if not eq(self, "beta", received[1][2], "second payload arg delivered") then
        return
    end
    if not eq(self, afterFire, afterOff, "Off stops further delivery") then
        return
    end
    if not eq(self, true, unknownOffOk, "Off on an unknown handle does not error") then
        return
    end
    self:Pass()
end)

TS:Register("Public API: a throwing handler does not break the firing site", CATEGORY, function(self)
    local API = GRIPEMS.API
    if not API or not GRIPEMS.Fire then
        self:Skip("GRIPEMS.API or event bus not available")
        return
    end
    local event = "PLUGIN_SEQUENCES_LOADED"
    local badRan = false
    local siblingRan = false
    local badHandle = API:On(event, function()
        badRan = true
        error("_TS_intentional handler failure")
    end)
    local goodHandle = API:On(event, function()
        siblingRan = true
    end)
    local handlesOk = type(badHandle) == "string" and type(goodHandle) == "string"
    local fireOk = pcall(function()
        GRIPEMS:Fire(event)
    end)
    API:Off(badHandle)
    API:Off(goodHandle)

    if not eq(self, true, handlesOk, "both handlers registered with string handles") then
        return
    end
    if not eq(self, true, badRan, "the throwing handler actually ran (not silently skipped)") then
        return
    end
    if not eq(self, true, fireOk, "firing survives a throwing handler") then
        return
    end
    if not eq(self, true, siblingRan, "a sibling handler still runs after one throws") then
        return
    end
    self:Pass()
end)

TS:Register("Public API: event payloads are read-only snapshots", CATEGORY, function(self)
    local API = GRIPEMS.API
    if not API or not GRIPEMS.Fire then
        self:Skip("GRIPEMS.API or event bus not available")
        return
    end
    -- A live table standing in for engine-owned sequence data, exactly
    -- as Engine fires SEQUENCE_CREATED(name, Engine.sequences[name].data).
    local live = {
        stepFunction = "sequential",
        versions = { { stepFunction = "sequential", steps = { "alpha" } } },
    }
    local sawTable = false
    local handle = API:On("SEQUENCE_CREATED", function(_, payload)
        if type(payload) == "table" then
            sawTable = true
            -- Hostile mutation of the received payload.
            payload.stepFunction = "_TS_hacked"
            payload.versions[1].steps[1] = "_TS_hacked"
            payload.__injected = true
        end
    end)
    GRIPEMS:Fire("SEQUENCE_CREATED", "_TS_PayloadSeq", live)
    API:Off(handle)

    if not eq(self, true, sawTable, "the handler received the table payload") then
        return
    end
    if not eq(self, "sequential", live.stepFunction, "top-level engine field is unchanged after handler mutation") then
        return
    end
    if not eq(self, "alpha", live.versions[1].steps[1], "nested engine step is unchanged after handler mutation") then
        return
    end
    if not eq(self, nil, live.__injected, "handler-injected key did not reach the engine table") then
        return
    end
    self:Pass()
end)

-- ===========================================================================
-- Tier 2 -- read-only data accessors
-- ===========================================================================

TS:Register("Public API: GetSequenceInfo nil for unknown, fresh snapshot for a seed", CATEGORY, function(self)
    local API = GRIPEMS.API
    local Engine = GRIPEMS.Engine
    if not API or not Engine then
        self:Skip("GRIPEMS.API or Engine not available")
        return
    end
    if not eq(self, nil, API:GetSequenceInfo("_TS_no_such_sequence"), "an unknown sequence returns nil") then
        return
    end

    local name = "_TS_PublicApiSeq"
    local savedSeq = Engine.sequences[name]
    Engine.sequences[name] = {
        data = {
            defaultVersion = 1,
            classID = 7,
            versions = {
                { stepFunction = "sequential", steps = { "a", "b", "c" } },
                { stepFunction = "priority", steps = { "x" } },
            },
        },
    }

    local info = API:GetSequenceInfo(name)
    local infoIsTable = type(info) == "table"
    -- Capture the derived values BEFORE mutating the snapshot.
    local cVersionCount = infoIsTable and info.versionCount
    local cDefaultVersion = infoIsTable and info.defaultVersion
    local cActiveIndex = infoIsTable and info.activeVersionIndex
    local cActiveSteps = infoIsTable and info.activeStepCount
    local cClassID = infoIsTable and info.classID
    local cStepFunction = infoIsTable and info.stepFunction
    -- Mutate the snapshot to prove it holds no reference into stored data.
    if infoIsTable then
        info.activeStepCount = -1
        info.classID = -1
    end
    local storedSteps = #Engine.sequences[name].data.versions[1].steps
    local storedClass = Engine.sequences[name].data.classID
    -- Restore the engine BEFORE asserting so a failure still leaves it clean.
    Engine.sequences[name] = savedSeq

    if not eq(self, "table", type(info), "a seeded sequence returns a table") then
        return
    end
    if not eq(self, 2, cVersionCount, "versionCount") then
        return
    end
    if not eq(self, 1, cDefaultVersion, "defaultVersion") then
        return
    end
    if not eq(self, 1, cActiveIndex, "activeVersionIndex resolves to the default version") then
        return
    end
    if not eq(self, 3, cActiveSteps, "activeStepCount counts the active version's steps") then
        return
    end
    if not eq(self, 7, cClassID, "classID copied from the sequence data") then
        return
    end
    if not eq(self, "sequential", cStepFunction, "stepFunction read from the active version") then
        return
    end
    if not eq(self, 3, storedSteps, "stored steps unchanged after mutating the snapshot") then
        return
    end
    if not eq(self, 7, storedClass, "stored classID unchanged after mutating the snapshot") then
        return
    end
    self:Pass()
end)

TS:Register("Public API: GetSequenceSteps nil for unknown, fresh indexed array for a seed", CATEGORY, function(self)
    local API = GRIPEMS.API
    local Engine = GRIPEMS.Engine
    if not API or not Engine then
        self:Skip("GRIPEMS.API or Engine not available")
        return
    end
    if not eq(self, nil, API:GetSequenceSteps("_TS_no_such_sequence"), "an unknown sequence returns nil") then
        return
    end

    -- Deterministic SpellCache stub: a /cast line resolves to its spell name; any
    -- other macrotext resolves to no spell. GetSpellID / GetIcon hand back fixed
    -- scalars so the per-entry fields are predictable. Save + restore the live
    -- module so the in-game full-suite run is left untouched.
    local savedSC = GRIPEMS.SpellCache
    GRIPEMS.SpellCache = {
        ParseSpellFromMacrotext = function(_, macrotext)
            return (type(macrotext) == "string" and macrotext:match("^/cast%s+(.+)$")) or nil
        end,
        GetSpellID = function()
            return 42
        end,
        GetIcon = function()
            return 99
        end,
    }

    local name = "_TS_PublicApiSteps"
    local savedSeq = Engine.sequences[name]
    Engine.sequences[name] = {
        data = {
            defaultVersion = 1,
            classID = 7,
            versions = {
                {
                    stepFunction = "Sequential",
                    steps = { "/cast Fireball", "/cast Frostbolt", "/cast Pyroblast" },
                },
            },
        },
    }

    local steps = API:GetSequenceSteps(name)
    local isTable = type(steps) == "table"
    local cLen = isTable and #steps or 0
    -- Capture the per-entry values BEFORE any mutation.
    local e1 = isTable and steps[1] or {}
    local e2 = isTable and steps[2] or {}
    local e3 = isTable and steps[3] or {}
    local c1Index, c1Name, c1ID, c1Icon = e1.index, e1.spellName, e1.spellID, e1.icon
    local c2Index, c2Name = e2.index, e2.spellName
    local c3Index, c3Name = e3.index, e3.spellName
    -- Mutate the returned array to prove a second call is unaffected and that the
    -- accessor holds no live reference into stored sequence data.
    if isTable and steps[1] then
        steps[1].spellName = "_TS_mutated"
        steps[1].spellID = -1
    end
    local steps2 = API:GetSequenceSteps(name)
    local c2ndName = (type(steps2) == "table" and steps2[1]) and steps2[1].spellName or nil
    local storedStep1 = Engine.sequences[name].data.versions[1].steps[1]
    -- Restore the engine + module BEFORE asserting so a failure leaves them clean.
    Engine.sequences[name] = savedSeq
    GRIPEMS.SpellCache = savedSC

    if not eq(self, "table", type(steps), "a seeded sequence returns a table") then
        return
    end
    if not eq(self, 3, cLen, "a 3-step Sequential version returns a 3-entry array") then
        return
    end
    if not eq(self, 1, c1Index, "entry 1 index") then
        return
    end
    if not eq(self, "Fireball", c1Name, "entry 1 spellName resolved from /cast") then
        return
    end
    if not eq(self, 42, c1ID, "entry 1 spellID from the stub") then
        return
    end
    if not eq(self, 99, c1Icon, "entry 1 icon from the stub") then
        return
    end
    if not eq(self, 2, c2Index, "entry 2 index") then
        return
    end
    if not eq(self, "Frostbolt", c2Name, "entry 2 spellName") then
        return
    end
    if not eq(self, 3, c3Index, "entry 3 index") then
        return
    end
    if not eq(self, "Pyroblast", c3Name, "entry 3 spellName") then
        return
    end
    if not eq(self, "Fireball", c2ndName, "a second call is unaffected by mutating the first result") then
        return
    end
    if not eq(self, "/cast Fireball", storedStep1, "stored steps unchanged after mutating the snapshot") then
        return
    end
    self:Pass()
end)

TS:Register("Public API: GetSequenceSteps keeps index alignment for an unresolvable step", CATEGORY, function(self)
    local API = GRIPEMS.API
    local Engine = GRIPEMS.Engine
    if not API or not Engine then
        self:Skip("GRIPEMS.API or Engine not available")
        return
    end

    -- Same stub: /cast resolves, /cancelaura (and anything else) does not.
    local savedSC = GRIPEMS.SpellCache
    GRIPEMS.SpellCache = {
        ParseSpellFromMacrotext = function(_, macrotext)
            return (type(macrotext) == "string" and macrotext:match("^/cast%s+(.+)$")) or nil
        end,
        GetSpellID = function()
            return 42
        end,
        GetIcon = function()
            return 99
        end,
    }

    local name = "_TS_PublicApiStepsGap"
    local savedSeq = Engine.sequences[name]
    -- Middle step casts no resolvable spell; the entry must still exist at index 2
    -- so a SEQUENCE_STEP_ADVANCED step index maps straight onto this array.
    Engine.sequences[name] = {
        data = {
            defaultVersion = 1,
            versions = {
                {
                    stepFunction = "Sequential",
                    steps = { "/cast Fireball", "/cancelaura Fireball", "/cast Pyroblast" },
                },
            },
        },
    }

    local steps = API:GetSequenceSteps(name)
    local isTable = type(steps) == "table"
    local cLen = isTable and #steps or 0
    local e1 = isTable and steps[1] or {}
    local e2 = isTable and steps[2] or {}
    local e3 = isTable and steps[3] or {}
    local c1Name, c1ID = e1.spellName, e1.spellID
    local c2Index, c2Name, c2ID, c2Icon = e2.index, e2.spellName, e2.spellID, e2.icon
    local c3Index, c3Name = e3.index, e3.spellName
    Engine.sequences[name] = savedSeq
    GRIPEMS.SpellCache = savedSC

    if not eq(self, 3, cLen, "every step gets an entry, including the unresolvable one") then
        return
    end
    if not eq(self, "Fireball", c1Name, "entry 1 resolves") then
        return
    end
    if not eq(self, 42, c1ID, "entry 1 spellID set") then
        return
    end
    if not eq(self, 2, c2Index, "the unresolvable step keeps its index") then
        return
    end
    if not eq(self, nil, c2Name, "the unresolvable step has a nil spellName") then
        return
    end
    if not eq(self, nil, c2ID, "the unresolvable step has a nil spellID") then
        return
    end
    if not eq(self, nil, c2Icon, "the unresolvable step has a nil icon") then
        return
    end
    if not eq(self, 3, c3Index, "the step after the gap keeps its index") then
        return
    end
    if not eq(self, "Pyroblast", c3Name, "the step after the gap still resolves") then
        return
    end
    self:Pass()
end)

TS:Register("Public API: GetSequenceMacroIndex reads the tracked stub slot, nil when none", CATEGORY, function(self)
    local API = GRIPEMS.API
    if not API then
        self:Skip("GRIPEMS.API not available")
        return
    end
    -- Seed the MacroManager stub map (seqName -> slot index) and restore the live
    -- module afterwards, the same seed-and-restore style as the GetSequenceSteps tests.
    local savedMM = GRIPEMS.MacroManager
    GRIPEMS.MacroManager = { stubs = { _TS_MacroSeq = 555 } }
    local hit = API:GetSequenceMacroIndex("_TS_MacroSeq")
    local miss = API:GetSequenceMacroIndex("_TS_nope")
    GRIPEMS.MacroManager = savedMM

    if not eq(self, 555, hit, "a tracked sequence returns its stub slot index") then
        return
    end
    if not eq(self, nil, miss, "a sequence with no stub returns nil") then
        return
    end
    self:Pass()
end)

TS:Register("Public API: GetSetting is allowlisted and never errors", CATEGORY, function(self)
    local API = GRIPEMS.API
    if not API then
        self:Skip("GRIPEMS.API not available")
        return
    end
    if not eq(self, nil, API:GetSetting("p2pEnabled"), "a non-allowlisted key returns nil") then
        return
    end
    local layoutOk = pcall(function()
        return API:GetSetting("uiLayout")
    end)
    if not eq(self, true, layoutOk, "an allowlisted key with no stored value does not error") then
        return
    end
    self:Pass()
end)

TS:Register("Public API: list and context accessors return read snapshots", CATEGORY, function(self)
    local API = GRIPEMS.API
    local Engine = GRIPEMS.Engine
    if not API or not Engine then
        self:Skip("GRIPEMS.API or Engine not available")
        return
    end
    if not eq(self, "table", type(API:GetSequenceList()), "GetSequenceList returns a table") then
        return
    end
    if not eq(self, "table", type(API:GetRegisteredPlugins()), "GetRegisteredPlugins returns a table") then
        return
    end
    -- Prove GetCurrentContext reads through the live field, not a constant.
    -- Restore BEFORE asserting so a failure still leaves the engine clean.
    local savedContext = Engine.currentContext
    Engine.currentContext = "_TS_ctx"
    local contextReadBack = API:GetCurrentContext()
    Engine.currentContext = savedContext
    if not eq(self, "_TS_ctx", contextReadBack, "GetCurrentContext reads through Engine.currentContext") then
        return
    end
    self:Pass()
end)

-- ===========================================================================
-- Tier 4 (partial) -- sequence registration re-export
-- ===========================================================================

TS:Register("Public API: RegisterSequences appears via GetRegisteredPlugins", CATEGORY, function(self)
    local API = GRIPEMS.API
    if not API then
        self:Skip("GRIPEMS.API not available")
        return
    end
    local PA = GRIPEMS.PluginAPI
    local pluginName = "_TS_PublicApiPlugin"
    local savedEntry = PA and PA.registeredAddons[pluginName]
    if PA then
        PA.registeredAddons[pluginName] = nil
    end

    local registered = API:RegisterSequences(pluginName, "1.0", { "_TS_PublicApiPluginSeq" }, {
        _TS_PublicApiPluginSeq = { versions = {} },
    })
    local plugins = API:GetRegisteredPlugins()
    local found = false
    if type(plugins) == "table" then
        for _, p in ipairs(plugins) do
            if p.name == pluginName then
                found = true
            end
        end
    end
    -- Drop the fixture registration BEFORE asserting.
    if PA then
        PA.registeredAddons[pluginName] = savedEntry
    end

    if not eq(self, true, registered, "RegisterSequences returns true") then
        return
    end
    if not eq(self, true, found, "the plugin appears via GetRegisteredPlugins") then
        return
    end
    self:Pass()
end)

TS:Register("Public API: RegisterSequences deep-copies plugin sequence data", CATEGORY, function(self)
    local API = GRIPEMS.API
    local PA = GRIPEMS.PluginAPI
    if not API or not PA then
        self:Skip("GRIPEMS.API or PluginAPI not available")
        return
    end
    local pluginName = "_TS_PublicApiIsolation"
    local seqName = "_TS_PublicApiIsoSeq"
    local savedEntry = PA.registeredAddons[pluginName]
    PA.registeredAddons[pluginName] = nil

    -- The table the plugin keeps a live reference to after registering.
    local original = {
        stepFunction = "sequential",
        versions = {
            { stepFunction = "sequential", steps = { "alpha", "beta" } },
        },
    }
    local registered = API:RegisterSequences(pluginName, "1.0", { seqName }, { [seqName] = original })

    local entry = PA.registeredAddons[pluginName]
    local stored = entry and entry.sequences[seqName]
    local storedIsTable = type(stored) == "table"
    local storedVer = storedIsTable and type(stored.versions) == "table" and stored.versions[1]
    local storedSteps = type(storedVer) == "table" and type(storedVer.steps) == "table" and storedVer.steps
    -- Hostile mutation: the plugin mutates the table it still holds.
    original.stepFunction = "_TS_hacked"
    original.versions[1].steps[1] = "_TS_hacked"
    original.versions[1].steps[3] = "_TS_injected"

    local distinct = storedIsTable and stored ~= original
    local topUnchanged = storedIsTable and stored.stepFunction == "sequential"
    local nestedUnchanged = type(storedSteps) == "table" and storedSteps[1] == "alpha" and storedSteps[3] == nil
    local sourceOnCopy = storedIsTable and stored.pluginSource == pluginName
    local sourceNotOnInput = original.pluginSource == nil

    -- Drop the fixture BEFORE asserting.
    PA.registeredAddons[pluginName] = savedEntry

    if not eq(self, true, registered, "RegisterSequences returns true") then
        return
    end
    if not eq(self, true, storedIsTable, "the registrar stored a sequence table") then
        return
    end
    if not eq(self, true, distinct, "stored copy is a distinct table from the plugin input") then
        return
    end
    if not eq(self, true, topUnchanged, "mutating the plugin table leaves the stored stepFunction intact") then
        return
    end
    if not eq(self, true, nestedUnchanged, "deep copy: nested steps are isolated from plugin mutation") then
        return
    end
    if not eq(self, true, sourceOnCopy, "pluginSource is stamped on the EMS-owned copy") then
        return
    end
    if not eq(self, true, sourceNotOnInput, "pluginSource is NOT stamped on the plugin input table") then
        return
    end
    self:Pass()
end)

-- ===========================================================================
-- Tier 4 -- variable-provider registry (Phase 2a)
--
-- Exercises the registry + the GRIPEMS:ResolvePluginVariable resolver directly
-- (same approach the Tier 3 tests use for GRIPEMS._layoutProviders): the
-- resolver is self-contained in PublicAPI.lua, so no Engine stub is needed. The
-- live registry array is saved by length and truncated back after each test.
-- ===========================================================================

TS:Register("Public API: RegisterVariableProvider validates the provider contract", CATEGORY, function(self)
    local API = GRIPEMS.API
    if not API then
        self:Skip("GRIPEMS.API not available")
        return
    end
    local arr = GRIPEMS._variableProviders
    local savedCount = arr and #arr or 0
    local id = "_TS_var_valid"

    local notTableOk = API:RegisterVariableProvider(id, "nope")
    local idMismatchOk = API:RegisterVariableProvider(id, { id = "other", name = "T", Resolve = function() end })
    local missingNameOk = API:RegisterVariableProvider(id, { id = id, Resolve = function() end })
    local badResolveOk = API:RegisterVariableProvider(id, { id = id, name = "T", Resolve = 5 })
    local badOnRegOk =
        API:RegisterVariableProvider(id, { id = id, name = "T", Resolve = function() end, OnRegister = 7 })
    local validOk = API:RegisterVariableProvider(id, { id = id, name = "T", Resolve = function() end })

    -- Restore the registry BEFORE asserting so a failure still leaves it clean.
    if arr then
        while #arr > savedCount do
            table.remove(arr)
        end
    end

    if not eq(self, false, notTableOk, "a non-table provider is rejected") then
        return
    end
    if not eq(self, false, idMismatchOk, "a provider whose id mismatches the key is rejected") then
        return
    end
    if not eq(self, false, missingNameOk, "a provider with no name is rejected") then
        return
    end
    if not eq(self, false, badResolveOk, "a non-function Resolve is rejected") then
        return
    end
    if not eq(self, false, badOnRegOk, "a non-function OnRegister is rejected") then
        return
    end
    if not eq(self, true, validOk, "a minimal valid provider is accepted") then
        return
    end
    self:Pass()
end)

TS:Register("Public API: RegisterVariableProvider rejects a duplicate id", CATEGORY, function(self)
    local API = GRIPEMS.API
    if not API then
        self:Skip("GRIPEMS.API not available")
        return
    end
    local arr = GRIPEMS._variableProviders
    local savedCount = arr and #arr or 0
    local id = "_TS_var_dupe"

    local firstOk = API:RegisterVariableProvider(id, {
        id = id,
        name = "T",
        Resolve = function()
            return "a"
        end,
    })
    local secondOk = API:RegisterVariableProvider(id, {
        id = id,
        name = "T2",
        Resolve = function()
            return "b"
        end,
    })

    if arr then
        while #arr > savedCount do
            table.remove(arr)
        end
    end

    if not eq(self, true, firstOk, "the first registration succeeds") then
        return
    end
    if not eq(self, false, secondOk, "a duplicate id is rejected, not overwritten") then
        return
    end
    self:Pass()
end)

TS:Register("Public API: ResolvePluginVariable resolves in registration order", CATEGORY, function(self)
    if not GRIPEMS.ResolvePluginVariable then
        self:Skip("ResolvePluginVariable not available")
        return
    end
    local API = GRIPEMS.API
    local arr = GRIPEMS._variableProviders
    local savedCount = arr and #arr or 0

    -- First provider answers "foo" only.
    API:RegisterVariableProvider("_TS_var_p1", {
        id = "_TS_var_p1",
        name = "P1",
        Resolve = function(_, n)
            if n == "foo" then
                return "from_p1"
            end
            return nil
        end,
    })
    -- Second provider answers both "foo" and "bar"; for "foo" it must lose to p1.
    API:RegisterVariableProvider("_TS_var_p2", {
        id = "_TS_var_p2",
        name = "P2",
        Resolve = function(_, n)
            if n == "foo" then
                return "from_p2"
            end
            if n == "bar" then
                return 42
            end
            return nil
        end,
    })

    local foo = GRIPEMS:ResolvePluginVariable("foo")
    local bar = GRIPEMS:ResolvePluginVariable("bar")
    local miss = GRIPEMS:ResolvePluginVariable("_TS_no_such")

    if arr then
        while #arr > savedCount do
            table.remove(arr)
        end
    end

    if not eq(self, "from_p1", foo, "the earlier-registered provider wins for a shared name") then
        return
    end
    if
        not eq(self, 42, bar, "a later provider resolves a name the earlier one passed on (number scalar preserved)")
    then
        return
    end
    if not eq(self, nil, miss, "an unresolved name returns nil") then
        return
    end
    self:Pass()
end)

TS:Register("Public API: ResolvePluginVariable rejects non-scalars and isolates a thrower", CATEGORY, function(self)
    if not GRIPEMS.ResolvePluginVariable then
        self:Skip("ResolvePluginVariable not available")
        return
    end
    local API = GRIPEMS.API
    local arr = GRIPEMS._variableProviders
    local savedCount = arr and #arr or 0

    -- Hostile provider: returns a table for "t", a function for "fn", throws for "boom".
    API:RegisterVariableProvider("_TS_var_hostile", {
        id = "_TS_var_hostile",
        name = "Hostile",
        Resolve = function(_, n)
            if n == "t" then
                return { 1, 2, 3 }
            end
            if n == "fn" then
                return function() end
            end
            if n == "boom" then
                error("_TS_intentional provider failure")
            end
            return nil
        end,
    })
    -- A later clean provider proves resolution continues past the hostile one.
    API:RegisterVariableProvider("_TS_var_clean", {
        id = "_TS_var_clean",
        name = "Clean",
        Resolve = function(_, n)
            if n == "t" then
                return "clean_t"
            end
            return nil
        end,
    })

    local tableReturn = GRIPEMS:ResolvePluginVariable("t")
    local fnMiss = GRIPEMS:ResolvePluginVariable("fn")
    local boomOk = pcall(function()
        return GRIPEMS:ResolvePluginVariable("boom")
    end)
    local boomReturn = GRIPEMS:ResolvePluginVariable("boom")

    if arr then
        while #arr > savedCount do
            table.remove(arr)
        end
    end

    if not eq(self, "clean_t", tableReturn, "a table return is rejected; a later scalar provider wins") then
        return
    end
    if not eq(self, nil, fnMiss, "a function return is rejected (no provider yields a scalar)") then
        return
    end
    if not eq(self, true, boomOk, "a throwing provider does not propagate the error") then
        return
    end
    if not eq(self, nil, boomReturn, "a throwing provider yields nil") then
        return
    end
    self:Pass()
end)

TS:Register(
    "Public API: ResolvePluginVariable rejects a secret-tagged scalar via issecretvalue",
    CATEGORY,
    function(self)
        if not GRIPEMS.ResolvePluginVariable then
            self:Skip("ResolvePluginVariable not available")
            return
        end
        local API = GRIPEMS.API
        local arr = GRIPEMS._variableProviders
        local savedCount = arr and #arr or 0
        -- A real secret value reports type()=="number" yet issecretvalue()==true, so
        -- the type allowlist alone cannot reject it. Model that by stubbing the WoW
        -- global issecretvalue to flag a sentinel string (a plain scalar by type) as
        -- secret, then confirm the resolver rejects it and falls through to a later
        -- clean provider.
        local savedIsSecret = _G.issecretvalue
        _G.issecretvalue = function(v)
            return v == "_TS_secret_sentinel"
        end

        API:RegisterVariableProvider("_TS_var_secret", {
            id = "_TS_var_secret",
            name = "Secret",
            Resolve = function(_, n)
                if n == "s" then
                    return "_TS_secret_sentinel"
                end
                return nil
            end,
        })
        API:RegisterVariableProvider("_TS_var_after_secret", {
            id = "_TS_var_after_secret",
            name = "AfterSecret",
            Resolve = function(_, n)
                if n == "s" then
                    return "clean_after_secret"
                end
                return nil
            end,
        })

        local got = GRIPEMS:ResolvePluginVariable("s")

        -- Restore the global + registry BEFORE asserting so a failure leaves them clean.
        _G.issecretvalue = savedIsSecret
        if arr then
            while #arr > savedCount do
                table.remove(arr)
            end
        end

        if
            not eq(self, "clean_after_secret", got, "a secret-flagged scalar is rejected; the next clean provider wins")
        then
            return
        end
        self:Pass()
    end
)

TS:Register("Public API: GetCapabilities advertises variables", CATEGORY, function(self)
    local API = GRIPEMS.API
    if not API then
        self:Skip("GRIPEMS.API not available")
        return
    end
    local caps = API:GetCapabilities()
    local hasVars = false
    if type(caps) == "table" then
        for _, c in ipairs(caps) do
            if c == "variables" then
                hasVars = true
            end
        end
    end
    if not eq(self, true, hasVars, "GetCapabilities includes 'variables'") then
        return
    end
    self:Pass()
end)

-- ===========================================================================
-- Tier 4 -- condition registry (Phase 2b)
--
-- Exercises the registry + the GRIPEMS.API:RegisterCondition / EvaluateCondition
-- surface directly; the dict is saved/restored via GRIPEMS._conditions per test
-- (same approach the variable-provider tests use). The baker-rejection test needs
-- the real MacroConditionalBaker, which is absent from the headless harness, so it
-- Skips headless and runs in-game.
-- ===========================================================================

TS:Register("Public API: RegisterCondition validates the condition contract", CATEGORY, function(self)
    local API = GRIPEMS.API
    if not API then
        self:Skip("GRIPEMS.API not available")
        return
    end
    local reg = GRIPEMS._conditions
    local id = "_TS_cond_valid"
    local saved = reg and reg[id]
    if reg then
        reg[id] = nil
    end

    local notTableOk = API:RegisterCondition(id, "nope")
    local idMismatchOk = API:RegisterCondition(id, { id = "other", name = "T", Evaluate = function() end })
    local missingNameOk = API:RegisterCondition(id, { id = id, Evaluate = function() end })
    local badEvalOk = API:RegisterCondition(id, { id = id, name = "T", Evaluate = 5 })
    local badOnRegOk = API:RegisterCondition(id, { id = id, name = "T", Evaluate = function() end, OnRegister = 7 })
    local validOk = API:RegisterCondition(id, { id = id, name = "T", Evaluate = function() end })

    -- Restore BEFORE asserting so a failure still leaves the registry clean.
    if reg then
        reg[id] = saved
    end

    if not eq(self, false, notTableOk, "a non-table condition is rejected") then
        return
    end
    if not eq(self, false, idMismatchOk, "a condition whose id mismatches the key is rejected") then
        return
    end
    if not eq(self, false, missingNameOk, "a condition with no name is rejected") then
        return
    end
    if not eq(self, false, badEvalOk, "a non-function Evaluate is rejected") then
        return
    end
    if not eq(self, false, badOnRegOk, "a non-function OnRegister is rejected") then
        return
    end
    if not eq(self, true, validOk, "a minimal valid condition is accepted") then
        return
    end
    self:Pass()
end)

TS:Register("Public API: RegisterCondition rejects a duplicate id", CATEGORY, function(self)
    local API = GRIPEMS.API
    if not API then
        self:Skip("GRIPEMS.API not available")
        return
    end
    local reg = GRIPEMS._conditions
    local id = "_TS_cond_dupe"
    local saved = reg and reg[id]
    if reg then
        reg[id] = nil
    end

    local firstOk = API:RegisterCondition(id, {
        id = id,
        name = "T",
        Evaluate = function()
            return true
        end,
    })
    local secondOk = API:RegisterCondition(id, {
        id = id,
        name = "T2",
        Evaluate = function()
            return false
        end,
    })

    if reg then
        reg[id] = saved
    end

    if not eq(self, true, firstOk, "the first registration succeeds") then
        return
    end
    if not eq(self, false, secondOk, "a duplicate id is rejected, not overwritten") then
        return
    end
    self:Pass()
end)

TS:Register(
    "Public API: EvaluateCondition returns a clean boolean (true/false/truthy/unknown)",
    CATEGORY,
    function(self)
        local API = GRIPEMS.API
        if not API then
            self:Skip("GRIPEMS.API not available")
            return
        end
        local reg = GRIPEMS._conditions
        local idT, idF, idTruthy = "_TS_cond_true", "_TS_cond_false", "_TS_cond_truthy"
        local savedT, savedF, savedTr = reg and reg[idT], reg and reg[idF], reg and reg[idTruthy]
        if reg then
            reg[idT], reg[idF], reg[idTruthy] = nil, nil, nil
        end

        API:RegisterCondition(idT, {
            id = idT,
            name = "T",
            Evaluate = function()
                return true
            end,
        })
        API:RegisterCondition(idF, {
            id = idF,
            name = "F",
            Evaluate = function()
                return false
            end,
        })
        API:RegisterCondition(idTruthy, {
            id = idTruthy,
            name = "Tr",
            Evaluate = function()
                return 42
            end,
        })

        local rT = API:EvaluateCondition(idT)
        local rF = API:EvaluateCondition(idF)
        local rTruthy = API:EvaluateCondition(idTruthy)
        local rUnknown = API:EvaluateCondition("_TS_cond_no_such")

        if reg then
            reg[idT], reg[idF], reg[idTruthy] = savedT, savedF, savedTr
        end

        if not eq(self, true, rT, "a true predicate yields true") then
            return
        end
        if not eq(self, false, rF, "a false predicate yields false") then
            return
        end
        if not eq(self, true, rTruthy, "a truthy non-boolean result coerces to true") then
            return
        end
        if not eq(self, false, rUnknown, "an unknown condition id yields false") then
            return
        end
        self:Pass()
    end
)

TS:Register("Public API: EvaluateCondition isolates a thrower and rejects a secret result", CATEGORY, function(self)
    local API = GRIPEMS.API
    if not API then
        self:Skip("GRIPEMS.API not available")
        return
    end
    local reg = GRIPEMS._conditions
    local idThrow, idSecret = "_TS_cond_throw", "_TS_cond_secret"
    local savedThrow, savedSecret = reg and reg[idThrow], reg and reg[idSecret]
    if reg then
        reg[idThrow], reg[idSecret] = nil, nil
    end
    -- A real 12.0 secret reports a normal type yet issecretvalue true; stub the
    -- global to flag a sentinel the predicate returns.
    local savedIsSecret = _G.issecretvalue
    _G.issecretvalue = function(v)
        return v == "_TS_cond_secret_marker"
    end

    API:RegisterCondition(idThrow, {
        id = idThrow,
        name = "Throw",
        Evaluate = function()
            error("_TS_intentional condition failure")
        end,
    })
    API:RegisterCondition(idSecret, {
        id = idSecret,
        name = "Secret",
        Evaluate = function()
            return "_TS_cond_secret_marker"
        end,
    })

    local rThrow = API:EvaluateCondition(idThrow)
    local throwOk = pcall(function()
        return API:EvaluateCondition(idThrow)
    end)
    local rSecret = API:EvaluateCondition(idSecret)

    -- Restore the global + registry BEFORE asserting.
    _G.issecretvalue = savedIsSecret
    if reg then
        reg[idThrow], reg[idSecret] = savedThrow, savedSecret
    end

    if not eq(self, false, rThrow, "a throwing predicate yields false, not an error") then
        return
    end
    if not eq(self, true, throwOk, "EvaluateCondition does not propagate the predicate's error") then
        return
    end
    if not eq(self, false, rSecret, "a secret-tagged result is rejected (yields false)") then
        return
    end
    self:Pass()
end)

TS:Register("Public API: MacroConditionalBaker rejects the EvaluateCondition shape", CATEGORY, function(self)
    local MCB = GRIPEMS.MacroConditionalBaker
    if not MCB or not MCB.Bake then
        self:Skip("MacroConditionalBaker not loaded (headless harness)")
        return
    end
    -- A condition is consumed at runtime, never baked to a native [cond]: the
    -- GRIPEMS.API:EvaluateCondition(...) call is not a recognised GRIPEMS.<Helper>()
    -- shape, so the baker must REJECT it (return nil) and leave the variable for
    -- runtime resolution. A crash here instead of a clean nil would break the bake
    -- pass for the whole step.
    local baked = MCB:Bake({ funct = 'GRIPEMS.API:EvaluateCondition("_TS_cond_x") and "A" or "B"' })
    if not eq(self, nil, baked, "the baker rejects the EvaluateCondition shape, leaving it for runtime") then
        return
    end
    self:Pass()
end)

TS:Register("Public API: GetCapabilities advertises conditions", CATEGORY, function(self)
    local API = GRIPEMS.API
    if not API then
        self:Skip("GRIPEMS.API not available")
        return
    end
    local caps = API:GetCapabilities()
    local hasCond = false
    if type(caps) == "table" then
        for _, c in ipairs(caps) do
            if c == "conditions" then
                hasCond = true
            end
        end
    end
    if not eq(self, true, hasCond, "GetCapabilities includes 'conditions'") then
        return
    end
    self:Pass()
end)

-- ===========================================================================
-- Tier 4 -- step-function registry (Phase 2c)
--
-- Exercises GRIPEMS.API:RegisterStepFunction (delegating to the real
-- StepFunctions module loaded into the headless sandbox) plus the engine-side
-- SF:IsExpander / SF:RunExpander surface. The registry dict is saved/restored
-- via GRIPEMS._stepFunctions per test, the same approach the condition tests use.
-- ===========================================================================

TS:Register("Public API: RegisterStepFunction validates the spec contract", CATEGORY, function(self)
    local API = GRIPEMS.API
    if not API then
        self:Skip("GRIPEMS.API not available")
        return
    end
    local reg = GRIPEMS._stepFunctions
    if not reg then
        self:Skip("step-function registry not available")
        return
    end
    local id = "_TS_sf_valid"
    local saved = reg[id]
    reg[id] = nil

    local emptyOk = API:RegisterStepFunction("", { id = "", name = "T", Expand = function() end })
    local builtinOk = API:RegisterStepFunction("Priority", { id = "Priority", name = "T", Expand = function() end })
    local notTableOk = API:RegisterStepFunction(id, "nope")
    local idMismatchOk = API:RegisterStepFunction(id, { id = "other", name = "T", Expand = function() end })
    local missingNameOk = API:RegisterStepFunction(id, { id = id, Expand = function() end })
    local badExpandOk = API:RegisterStepFunction(id, { id = id, name = "T", Expand = 5 })
    local badOnRegOk = API:RegisterStepFunction(id, { id = id, name = "T", Expand = function() end, OnRegister = 7 })
    local validOk = API:RegisterStepFunction(id, { id = id, name = "T", Expand = function() end })

    reg[id] = saved

    if not eq(self, false, emptyOk, "an empty id is rejected") then
        return
    end
    if not eq(self, false, builtinOk, "a built-in id collision is rejected") then
        return
    end
    if not eq(self, false, notTableOk, "a non-table spec is rejected") then
        return
    end
    if not eq(self, false, idMismatchOk, "a spec whose id mismatches the key is rejected") then
        return
    end
    if not eq(self, false, missingNameOk, "a spec with no name is rejected") then
        return
    end
    if not eq(self, false, badExpandOk, "a non-function Expand is rejected") then
        return
    end
    if not eq(self, false, badOnRegOk, "a non-function OnRegister is rejected") then
        return
    end
    if not eq(self, true, validOk, "a minimal valid step function is accepted") then
        return
    end
    self:Pass()
end)

TS:Register("Public API: RegisterStepFunction rejects a duplicate id", CATEGORY, function(self)
    local API = GRIPEMS.API
    if not API then
        self:Skip("GRIPEMS.API not available")
        return
    end
    local reg = GRIPEMS._stepFunctions
    if not reg then
        self:Skip("step-function registry not available")
        return
    end
    local id = "_TS_sf_dupe"
    local saved = reg[id]
    reg[id] = nil

    local firstOk = API:RegisterStepFunction(id, {
        id = id,
        name = "T",
        Expand = function(_, s)
            return s
        end,
    })
    local secondOk = API:RegisterStepFunction(id, {
        id = id,
        name = "T2",
        Expand = function(_, s)
            return s
        end,
    })

    reg[id] = saved

    if not eq(self, true, firstOk, "the first registration succeeds") then
        return
    end
    if not eq(self, false, secondOk, "a duplicate id is rejected, not overwritten") then
        return
    end
    self:Pass()
end)

TS:Register("Public API: a registered step function expands via SF:RunExpander", CATEGORY, function(self)
    local API = GRIPEMS.API
    local SF = GRIPEMS.StepFunctions
    local D = GRIPEMS.Defaults
    if not API or not SF or not D then
        self:Skip("GRIPEMS.API / StepFunctions / Defaults not available")
        return
    end
    local reg = GRIPEMS._stepFunctions
    local id = "_TS_sf_expand"
    local saved = reg[id]
    reg[id] = nil

    -- A weighting strategy: step 1 twice, then step 2 once.
    API:RegisterStepFunction(id, {
        id = id,
        name = "Weighted",
        Expand = function(_, s)
            return { s[1], s[1], s[2] }
        end,
    })
    local isExp = SF:IsExpander(id)
    local out = SF:RunExpander(id, { "/cast A", "/cast B" })

    reg[id] = saved

    if not eq(self, true, isExp, "the registered id is an expander") then
        return
    end
    if not eq(self, true, type(out) == "table", "RunExpander returns a table") then
        return
    end
    if not eq(self, 3, #out, "RunExpander returns one entry per produced string") then
        return
    end
    if not eq(self, D.ATTR_TYPE_MACRO, out[1].type, "entry type is macro") then
        return
    end
    if not eq(self, "/cast A", out[1].macrotext, "entry 1 macrotext") then
        return
    end
    if not eq(self, "/cast B", out[3].macrotext, "entry 3 macrotext") then
        return
    end
    self:Pass()
end)

TS:Register("Public API: SF:RunExpander falls back on a bad expander", CATEGORY, function(self)
    local API = GRIPEMS.API
    local SF = GRIPEMS.StepFunctions
    if not API or not SF then
        self:Skip("GRIPEMS.API / StepFunctions not available")
        return
    end
    local reg = GRIPEMS._stepFunctions
    local idThrow, idNon, idLong, idSecret = "_TS_sf_throw", "_TS_sf_nonstr", "_TS_sf_long", "_TS_sf_secret"
    local sThrow, sNon, sLong, sSecret = reg[idThrow], reg[idNon], reg[idLong], reg[idSecret]
    reg[idThrow], reg[idNon], reg[idLong], reg[idSecret] = nil, nil, nil, nil
    local savedIsSecret = _G.issecretvalue
    _G.issecretvalue = function(v)
        return v == "_TS_sf_secret_marker"
    end

    API:RegisterStepFunction(idThrow, {
        id = idThrow,
        name = "Throw",
        Expand = function()
            error("_TS_intentional expander failure")
        end,
    })
    API:RegisterStepFunction(idNon, {
        id = idNon,
        name = "NonStr",
        Expand = function()
            return { 42 }
        end,
    })
    API:RegisterStepFunction(idLong, {
        id = idLong,
        name = "Long",
        Expand = function()
            return { string.rep("x", 300) }
        end,
    })
    API:RegisterStepFunction(idSecret, {
        id = idSecret,
        name = "Secret",
        Expand = function()
            return { "_TS_sf_secret_marker" }
        end,
    })

    local input = { "/cast A", "/cast B" }
    local rThrow = SF:RunExpander(idThrow, input)
    local rNon = SF:RunExpander(idNon, input)
    local rLong = SF:RunExpander(idLong, input)
    local rSecret = SF:RunExpander(idSecret, input)

    _G.issecretvalue = savedIsSecret
    reg[idThrow], reg[idNon], reg[idLong], reg[idSecret] = sThrow, sNon, sLong, sSecret

    -- Every bad expander collapses to the sequential fallback: one entry per
    -- input string, original order, no error.
    if not eq(self, 2, #rThrow, "thrower falls back to sequential (one per input)") then
        return
    end
    if not eq(self, "/cast A", rThrow[1].macrotext, "thrower fallback keeps input order") then
        return
    end
    if not eq(self, 2, #rNon, "non-string output falls back") then
        return
    end
    if not eq(self, 2, #rLong, "overlong output falls back") then
        return
    end
    if not eq(self, 2, #rSecret, "secret-tagged output falls back") then
        return
    end
    self:Pass()
end)

TS:Register("Public API: GetCapabilities advertises stepfunctions", CATEGORY, function(self)
    local API = GRIPEMS.API
    if not API then
        self:Skip("GRIPEMS.API not available")
        return
    end
    local caps = API:GetCapabilities()
    local hasSF = false
    if type(caps) == "table" then
        for _, c in ipairs(caps) do
            if c == "stepfunctions" then
                hasSF = true
            end
        end
    end
    if not eq(self, true, hasSF, "GetCapabilities includes 'stepfunctions'") then
        return
    end
    self:Pass()
end)

TS:Register("Public API: GetCapabilities advertises stepdata", CATEGORY, function(self)
    local API = GRIPEMS.API
    if not API then
        self:Skip("GRIPEMS.API not available")
        return
    end
    local caps = API:GetCapabilities()
    local hasStepData = false
    if type(caps) == "table" then
        for _, c in ipairs(caps) do
            if c == "stepdata" then
                hasStepData = true
            end
        end
    end
    if not eq(self, true, hasStepData, "GetCapabilities includes 'stepdata'") then
        return
    end
    self:Pass()
end)

TS:Register("Public API: GetCapabilities advertises macro", CATEGORY, function(self)
    local API = GRIPEMS.API
    if not API then
        self:Skip("GRIPEMS.API not available")
        return
    end
    local caps = API:GetCapabilities()
    local hasMacro = false
    if type(caps) == "table" then
        for _, c in ipairs(caps) do
            if c == "macro" then
                hasMacro = true
            end
        end
    end
    if not eq(self, true, hasMacro, "GetCapabilities includes 'macro'") then
        return
    end
    self:Pass()
end)

TS:Register("Public API: GetCapabilities advertises slash", CATEGORY, function(self)
    local API = GRIPEMS.API
    if not API then
        self:Skip("GRIPEMS.API not available")
        return
    end
    local caps = API:GetCapabilities()
    local hasSlash = false
    if type(caps) == "table" then
        for _, c in ipairs(caps) do
            if c == "slash" then
                hasSlash = true
            end
        end
    end
    if not eq(self, true, hasSlash, "GetCapabilities includes 'slash'") then
        return
    end
    self:Pass()
end)

-- ===========================================================================
-- Tier 3 -- UI host frames + layout-provider registry (Phase 1b)
--
-- Frame-free registry logic only. The headless harness has no CreateFrame, so
-- the seven host frames are covered by the in-game smoke pass, not here.
-- ===========================================================================

TS:Register("Public API UI: registry exists and is frozen", CATEGORY, function(self)
    local API = GRIPEMS.API
    if not API or not API.UI then
        self:Skip("GRIPEMS.API.UI not available")
        return
    end
    local writeOk = pcall(function()
        API.UI.brandNewField = 1
    end)
    if not eq(self, false, writeOk, "writing a new key on API.UI raises an error") then
        return
    end
    if not eq(self, "function", type(API.UI.RegisterLayoutProvider), "RegisterLayoutProvider is exposed") then
        return
    end
    self:Pass()
end)

TS:Register("Public API UI: GetCapabilities advertises ui", CATEGORY, function(self)
    local API = GRIPEMS.API
    if not API then
        self:Skip("GRIPEMS.API not available")
        return
    end
    local caps = API:GetCapabilities()
    local hasUI = false
    if type(caps) == "table" then
        for _, c in ipairs(caps) do
            if c == "ui" then
                hasUI = true
            end
        end
    end
    if not eq(self, true, hasUI, "GetCapabilities includes 'ui'") then
        return
    end
    self:Pass()
end)

TS:Register("Public API UI: GetActiveLayoutProvider defaults to classic", CATEGORY, function(self)
    local API = GRIPEMS.API
    if not API or not API.UI then
        self:Skip("GRIPEMS.API.UI not available")
        return
    end
    local active = API.UI:GetActiveLayoutProvider()
    if not eq(self, "string", type(active), "GetActiveLayoutProvider returns a string id") then
        return
    end
    -- Headless: clean module state, nothing activated, no stored uiLayout -> classic.
    -- In-game the live value may legitimately be another provider, so only the
    -- type is asserted there.
    if standalone then
        if not eq(self, "classic", active, "defaults to classic when nothing was set") then
            return
        end
    end
    self:Pass()
end)

TS:Register("Public API UI: RegisterLayoutProvider validates the provider contract", CATEGORY, function(self)
    local API = GRIPEMS.API
    if not API or not API.UI then
        self:Skip("GRIPEMS.API.UI not available")
        return
    end
    local id = "_TS_layout_valid"
    local saved = GRIPEMS._layoutProviders and GRIPEMS._layoutProviders[id]
    if GRIPEMS._layoutProviders then
        GRIPEMS._layoutProviders[id] = nil
    end

    local missingNameOk = API.UI:RegisterLayoutProvider(id, { id = id })
    local badCbOk = API.UI:RegisterLayoutProvider(id, { id = id, name = "T", OnApplyLayout = 5 })
    local idMismatchOk = API.UI:RegisterLayoutProvider(id, { id = "other", name = "T" })
    local validOk = API.UI:RegisterLayoutProvider(id, { id = id, name = "T" })

    -- Drop the fixture BEFORE asserting so a failure still leaves the registry clean.
    if GRIPEMS._layoutProviders then
        GRIPEMS._layoutProviders[id] = saved
    end

    if not eq(self, false, missingNameOk, "a provider with no name is rejected") then
        return
    end
    if not eq(self, false, badCbOk, "a non-function OnApplyLayout is rejected") then
        return
    end
    if not eq(self, false, idMismatchOk, "a provider whose id mismatches the key is rejected") then
        return
    end
    if not eq(self, true, validOk, "a minimal valid provider is accepted") then
        return
    end
    self:Pass()
end)

TS:Register("Public API UI: RegisterLayoutProvider rejects a duplicate id", CATEGORY, function(self)
    local API = GRIPEMS.API
    if not API or not API.UI then
        self:Skip("GRIPEMS.API.UI not available")
        return
    end
    local id = "_TS_layout_dupe"
    local saved = GRIPEMS._layoutProviders and GRIPEMS._layoutProviders[id]
    if GRIPEMS._layoutProviders then
        GRIPEMS._layoutProviders[id] = nil
    end

    local firstOk = API.UI:RegisterLayoutProvider(id, { id = id, name = "T" })
    local secondOk = API.UI:RegisterLayoutProvider(id, { id = id, name = "T2" })

    if GRIPEMS._layoutProviders then
        GRIPEMS._layoutProviders[id] = saved
    end

    if not eq(self, true, firstOk, "the first registration succeeds") then
        return
    end
    if not eq(self, false, secondOk, "a duplicate id is rejected, not overwritten") then
        return
    end
    self:Pass()
end)

TS:Register("Public API UI: SetActiveLayoutProvider rejects unknown, accepts registered", CATEGORY, function(self)
    local API = GRIPEMS.API
    if not API or not API.UI then
        self:Skip("GRIPEMS.API.UI not available")
        return
    end
    local id = "_TS_layout_active"
    local saved = GRIPEMS._layoutProviders and GRIPEMS._layoutProviders[id]
    local originalActive = API.UI:GetActiveLayoutProvider()
    local originalLayout = GRIPEMS.Settings and GRIPEMS.Settings:Get("uiLayout")
    if GRIPEMS._layoutProviders then
        GRIPEMS._layoutProviders[id] = nil
    end

    local unknownOk = API.UI:SetActiveLayoutProvider("_TS_layout_not_registered")
    API.UI:RegisterLayoutProvider(id, { id = id, name = "T" })
    local acceptOk = API.UI:SetActiveLayoutProvider(id)
    local readBack = API.UI:GetActiveLayoutProvider()

    -- Fully restore live state so nothing leaks out of the test: an in-game
    -- /gems test must not switch the user's layout or dirty SavedVariables, and
    -- the in-memory active id must return to its pre-test value so a later test
    -- that reads the default ("defaults to classic") is not order-coupled to
    -- this one. "classic" is registered in both modes (in-game by MainFrame.lua,
    -- headless by the bootstrap above), so originalActive is always re-activatable.
    if GRIPEMS._layoutProviders and GRIPEMS._layoutProviders[originalActive] then
        API.UI:SetActiveLayoutProvider(originalActive)
    end
    if GRIPEMS.Settings and GRIPEMS.Settings.Set then
        GRIPEMS.Settings:Set("uiLayout", originalLayout)
    end
    if GRIPEMS._layoutProviders then
        GRIPEMS._layoutProviders[id] = saved
    end

    if not eq(self, false, unknownOk, "an unknown id is rejected") then
        return
    end
    if not eq(self, true, acceptOk, "a registered id is accepted") then
        return
    end
    if not eq(self, id, readBack, "GetActiveLayoutProvider returns the id just set") then
        return
    end
    self:Pass()
end)

TS:Register("Public API UI: On(GEMS_UI_READY) subscribes and the bus delivers", CATEGORY, function(self)
    local API = GRIPEMS.API
    if not API or not GRIPEMS.Fire then
        self:Skip("GRIPEMS.API or event bus not available")
        return
    end
    local fired = 0
    local handle = API:On("GEMS_UI_READY", function()
        fired = fired + 1
    end)
    local handleIsString = type(handle) == "string"
    GRIPEMS:Fire("GEMS_UI_READY")
    if handleIsString then
        API:Off(handle)
    end

    if not eq(self, true, handleIsString, "On(GEMS_UI_READY) returns a string handle") then
        return
    end
    if not eq(self, 1, fired, "firing GEMS_UI_READY delivers to the handler") then
        return
    end
    self:Pass()
end)

-- ===========================================================================
-- Tier 3 -- Preview facade (Phase 1c)
--
-- Frame-free facade logic only. GetMode/SetMode/Update fire + persist without
-- CreateFrame; the Mount* reparent methods need real frames, so they are
-- covered by the in-game smoke pass, not here.
-- ===========================================================================

TS:Register("Public API Preview: facade exists and is frozen", CATEGORY, function(self)
    local API = GRIPEMS.API
    if not API or not API.Preview then
        self:Skip("GRIPEMS.API.Preview not available")
        return
    end
    local writeOk = pcall(function()
        API.Preview.brandNewField = 1
    end)
    if not eq(self, false, writeOk, "writing a new key on API.Preview raises an error") then
        return
    end
    if not eq(self, "function", type(API.Preview.GetMode), "GetMode is exposed") then
        return
    end
    self:Pass()
end)

TS:Register("Public API Preview: GetMode default and Set round-trip", CATEGORY, function(self)
    local API = GRIPEMS.API
    if not API or not API.Preview then
        self:Skip("GRIPEMS.API.Preview not available")
        return
    end
    local S = GRIPEMS.Settings
    if not (S and S.Set) then
        self:Skip("settings writer not available")
        return
    end
    -- 'original' is the RESOLVED value (in-game S:Get falls back to the
    -- defaults.profile "icons"); restoring it writes that resolved value back.
    -- Behaviorally inert -- same accepted trade-off as the Phase 1b uiLayout test.
    local original = S:Get("previewMode")
    -- Force the unset state so the default is deterministic in both modes
    -- (headless falls through to the Defaults stand-in; in-game S:Get returns
    -- the defaults.profile "icons"). Restore BEFORE asserting.
    S:Set("previewMode", nil)
    local defaultMode = API.Preview:GetMode()
    S:Set("previewMode", "text")
    local afterSet = API.Preview:GetMode()
    S:Set("previewMode", original)

    if not eq(self, "icons", defaultMode, "GetMode falls back to icons when previewMode is unset") then
        return
    end
    if not eq(self, "text", afterSet, "GetMode reflects a Settings:Set('previewMode','text') round-trip") then
        return
    end
    self:Pass()
end)

TS:Register("Public API Preview: SetMode validates, persists, and fires", CATEGORY, function(self)
    local API = GRIPEMS.API
    if not API or not GRIPEMS.Fire then
        self:Skip("GRIPEMS.API or event bus not available")
        return
    end
    local S = GRIPEMS.Settings
    local original = S and S:Get("previewMode")
    local fired = {}
    local handle = API:On("GEMS_PREVIEW_MODE_CHANGED", function(mode)
        fired[#fired + 1] = mode
    end)

    local badOk = API.Preview:SetMode("_TS_not_a_mode")
    local goodOk = API.Preview:SetMode("text")
    local stored = S and S:Get("previewMode")

    -- Restore BEFORE asserting (drop the handler first so the restore Set does
    -- not feed the fired counter). 'original' is the resolved value -- restoring
    -- it is behaviorally inert (Phase 1b uiLayout precedent). In-game, re-render
    -- the live preview to the restored mode so a /gems test run does not leave
    -- the frame showing the test mode (no-op when the editor is not built).
    if type(handle) == "string" then
        API:Off(handle)
    end
    if S and S.Set then
        S:Set("previewMode", original)
    end
    if GRIPEMS.SequenceEditor and GRIPEMS.SequenceEditor.UpdatePreview then
        pcall(GRIPEMS.SequenceEditor.UpdatePreview, GRIPEMS.SequenceEditor)
    end

    if not eq(self, false, badOk, "an unknown mode is rejected") then
        return
    end
    if not eq(self, true, goodOk, "a valid mode is accepted") then
        return
    end
    if not eq(self, "text", stored, "the valid mode is persisted to previewMode") then
        return
    end
    if not eq(self, 1, #fired, "exactly one GEMS_PREVIEW_MODE_CHANGED fired (only the valid SetMode)") then
        return
    end
    if not eq(self, "text", fired[1], "the event payload carries the new mode") then
        return
    end
    self:Pass()
end)

TS:Register("Public API Preview: Update fires GEMS_PREVIEW_UPDATE", CATEGORY, function(self)
    local API = GRIPEMS.API
    if not API or not GRIPEMS.Fire then
        self:Skip("GRIPEMS.API or event bus not available")
        return
    end
    local fired = 0
    local handle = API:On("GEMS_PREVIEW_UPDATE", function()
        fired = fired + 1
    end)
    local handleIsString = type(handle) == "string"
    local updateOk = API.Preview:Update()
    if handleIsString then
        API:Off(handle)
    end

    if not eq(self, true, handleIsString, "On(GEMS_PREVIEW_UPDATE) returns a string handle") then
        return
    end
    if not eq(self, true, updateOk, "Update returns true") then
        return
    end
    if not eq(self, 1, fired, "Update fires GEMS_PREVIEW_UPDATE once") then
        return
    end
    self:Pass()
end)

TS:Register("Public API Preview: GetCapabilities advertises preview", CATEGORY, function(self)
    local API = GRIPEMS.API
    if not API then
        self:Skip("GRIPEMS.API not available")
        return
    end
    local caps = API:GetCapabilities()
    local hasPreview = false
    if type(caps) == "table" then
        for _, c in ipairs(caps) do
            if c == "preview" then
                hasPreview = true
            end
        end
    end
    if not eq(self, true, hasPreview, "GetCapabilities includes 'preview'") then
        return
    end
    self:Pass()
end)

-- ---------------------------------------------------------------------------
-- Headless runner entry point.
-- ---------------------------------------------------------------------------

if standalone then
    -- os.exit is dev-harness only; the game client never reaches this branch.
    -- selene: allow(undefined_variable)
    os.exit(GRIPEMS.TestSuite:RunStandalone() > 0 and 1 or 0)
end
