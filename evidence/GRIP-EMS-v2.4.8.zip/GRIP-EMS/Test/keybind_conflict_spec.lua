-- GRIP-EMS: Test spec for the keybind conflict detection core
--
-- Created:    2026-08-11
-- Updated:    2026-08-25 (Patch header swept to build 12.1.0.69273; 2026-08-11 GROUP 11: owner in the dedup key, third-party self-file)
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.
--
-- Registers tests in TestSuite under category "keybind_conflict" covering the
-- Lua surface of Engine/KeybindConflict.lua. Every function in that module takes
-- an optional deps table as its last parameter, so each test drives it with
-- stubbed globals rather than the live client:
--   1  canonicaliser -- modifier order normalises to ALT, CTRL, SHIFT regardless
--                       of input order or casing. Measured 2026-08-11: dispatch
--                       normalises to that order and only a canonically-ordered
--                       binding can fire, so the canonical form is the only form
--                       worth querying.
--   2  binding map   -- GetNumBindings / GetBinding sweep reads every key slot,
--                       skips empty keys, canonicalises, and retains BOTH owners
--                       of a collided key.
--   3  capabilities  -- every probed global absent degrades to false without
--                       raising, and the probe caches.
--   4  modified click-- value parsing (a value is NOT always a bare modifier),
--                       runtime enumeration preferred, and the measured 22-entry
--                       list as the labelled fallback.
--   5  CheckKey      -- per-layer statuses and the single verdict. The verdict is
--                       driven by the EFFECTIVE layer alone: it is the only layer
--                       that decides whether the keypress reaches EMS, and the
--                       other three are graded context. Covered here: the masked
--                       base layer measured live on 2026-08-11, the notes list,
--                       the per-layer severities, the is-this-key-free query, the
--                       rule that a missing capability can never read as clear,
--                       and the parsed intersection of a compound value. Also the
--                       two context-layer conflicts the effective layer cannot
--                       see -- a cast redirect and a click-binding owner -- each
--                       grading warning UNDER a verdict that stays clear.
--   6  addons        -- installed-but-not-loaded enumeration.
--   7  constants     -- MODIFIER_ORDER and SEVERITY.
--   8  expected action -- the CLICK GRIPEMS_<name>:LeftButton string EMS expects
--                       to own a sequence key, reusing Engine:SanitizeName.

local ADDON_NAME, GRIPEMS = ...

local TS = GRIPEMS.TestSuite
if not TS then
    return
end

local CATEGORY = "keybind_conflict"

-- Assertion helper: returns false (and marks the test failed) on mismatch so the
-- caller can early-return. Avoids TestSuite's file-local currentResult, which is
-- not visible from a spec file.
local function eq(self, expected, actual, label)
    if expected ~= actual then
        self:Fail((label or "value") .. ": expected " .. tostring(expected) .. ", got " .. tostring(actual))
        return false
    end
    return true
end

-- Pull one layer out of a CheckKey result by its id.
local function layerById(result, id)
    if not result or not result.layers then
        return nil
    end
    for _, layer in ipairs(result.layers) do
        if layer.id == id then
            return layer
        end
    end
    return nil
end

-- Pull one modifier-layer entry out by its action name.
local function entryByAction(layer, action)
    if not layer or not layer.entries then
        return nil
    end
    for _, entry in ipairs(layer.entries) do
        if entry.action == action then
            return entry
        end
    end
    return nil
end

-- Pull one note out of a CheckKey result by the layer id it reports.
local function noteById(result, id)
    if not result or not result.notes then
        return nil
    end
    for _, note in ipairs(result.notes) do
        if note.id == id then
            return note
        end
    end
    return nil
end

-- Count the notes on a result. #result.notes would report 0 just as loudly for a
-- missing field as for an empty list, and the difference matters here.
local function noteCount(result)
    if not result or type(result.notes) ~= "table" then
        return nil
    end
    return #result.notes
end

-- True when a value is one of the four strings KC.SEVERITY publishes. Every layer
-- must grade on that scale so a later phase can reuse RepairFrame's rendering
-- instead of inventing a second one, and a typo'd severity would otherwise sail
-- through as a plain string.
local function isSeverity(KC, value)
    if type(value) ~= "string" then
        return false
    end
    for _, known in pairs(KC.SEVERITY) do
        if value == known then
            return true
        end
    end
    return false
end

-- ===========================================================================
-- GROUP 1 -- the canonicaliser (KC.CanonicalizeKey / KC.SplitKey)
-- ===========================================================================

TS:Register("KB conflict: canonicaliser normalises all six three-modifier orderings", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.CanonicalizeKey then
        self:Skip("KeybindConflict.CanonicalizeKey not available")
        return
    end
    -- Asserted one at a time on purpose: a loop over a table of six would report
    -- a single failure and hide which ordering broke.
    if not eq(self, "ALT-CTRL-SHIFT-T", KC.CanonicalizeKey("ALT-CTRL-SHIFT-T"), "ALT-CTRL-SHIFT") then
        return
    end
    if not eq(self, "ALT-CTRL-SHIFT-T", KC.CanonicalizeKey("ALT-SHIFT-CTRL-T"), "ALT-SHIFT-CTRL") then
        return
    end
    if not eq(self, "ALT-CTRL-SHIFT-T", KC.CanonicalizeKey("CTRL-ALT-SHIFT-T"), "CTRL-ALT-SHIFT") then
        return
    end
    if not eq(self, "ALT-CTRL-SHIFT-T", KC.CanonicalizeKey("CTRL-SHIFT-ALT-T"), "CTRL-SHIFT-ALT") then
        return
    end
    if not eq(self, "ALT-CTRL-SHIFT-T", KC.CanonicalizeKey("SHIFT-ALT-CTRL-T"), "SHIFT-ALT-CTRL") then
        return
    end
    if not eq(self, "ALT-CTRL-SHIFT-T", KC.CanonicalizeKey("SHIFT-CTRL-ALT-T"), "SHIFT-CTRL-ALT") then
        return
    end
    self:Pass()
end)

TS:Register("KB conflict: canonicaliser normalises both orderings of each modifier pair", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.CanonicalizeKey then
        self:Skip("KeybindConflict.CanonicalizeKey not available")
        return
    end
    if not eq(self, "ALT-CTRL-T", KC.CanonicalizeKey("ALT-CTRL-T"), "ALT-CTRL") then
        return
    end
    if not eq(self, "ALT-CTRL-T", KC.CanonicalizeKey("CTRL-ALT-T"), "CTRL-ALT") then
        return
    end
    if not eq(self, "ALT-SHIFT-T", KC.CanonicalizeKey("ALT-SHIFT-T"), "ALT-SHIFT") then
        return
    end
    if not eq(self, "ALT-SHIFT-T", KC.CanonicalizeKey("SHIFT-ALT-T"), "SHIFT-ALT") then
        return
    end
    if not eq(self, "CTRL-SHIFT-T", KC.CanonicalizeKey("CTRL-SHIFT-T"), "CTRL-SHIFT") then
        return
    end
    if not eq(self, "CTRL-SHIFT-T", KC.CanonicalizeKey("SHIFT-CTRL-T"), "SHIFT-CTRL") then
        return
    end
    self:Pass()
end)

TS:Register("KB conflict: canonicaliser handles lowercase, bare, mouse, nil and empty input", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.CanonicalizeKey then
        self:Skip("KeybindConflict.CanonicalizeKey not available")
        return
    end
    if not eq(self, "ALT-CTRL-SHIFT-T", KC.CanonicalizeKey("ctrl-alt-shift-t"), "lowercase input") then
        return
    end
    if not eq(self, "T", KC.CanonicalizeKey("t"), "bare key, no modifier") then
        return
    end
    if not eq(self, "BUTTON4", KC.CanonicalizeKey("BUTTON4"), "mouse button") then
        return
    end
    if not eq(self, "SHIFT-BUTTON4", KC.CanonicalizeKey("shift-button4"), "lowercase mouse button") then
        return
    end
    if not eq(self, nil, KC.CanonicalizeKey(nil), "nil input") then
        return
    end
    if not eq(self, nil, KC.CanonicalizeKey(""), "empty string input") then
        return
    end
    self:Pass()
end)

TS:Register("KB conflict: SplitKey returns the modifier set and the bare key", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.SplitKey then
        self:Skip("KeybindConflict.SplitKey not available")
        return
    end
    local modifiers, bare = KC.SplitKey("shift-ctrl-f5")
    if not eq(self, "F5", bare, "bare key") then
        return
    end
    if not eq(self, true, modifiers.SHIFT, "SHIFT present") then
        return
    end
    if not eq(self, true, modifiers.CTRL, "CTRL present") then
        return
    end
    if not eq(self, nil, modifiers.ALT, "ALT absent") then
        return
    end
    -- A leading token that is not a modifier is part of the key, not a prefix.
    local plainMods, plainBare = KC.SplitKey("NUMPAD5")
    if not eq(self, "NUMPAD5", plainBare, "non-modifier token stays in the bare key") then
        return
    end
    if not eq(self, nil, plainMods.ALT, "no modifiers on a plain key") then
        return
    end
    if not eq(self, nil, KC.SplitKey(nil), "nil input") then
        return
    end
    if not eq(self, nil, KC.SplitKey(""), "empty string input") then
        return
    end
    self:Pass()
end)

-- ===========================================================================
-- GROUP 2 -- the binding-table sweep (KC.BuildBindingMap)
-- ===========================================================================

TS:Register("KB conflict: BuildBindingMap reads every key slot and skips empty keys", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.BuildBindingMap then
        self:Skip("KeybindConflict.BuildBindingMap not available")
        return
    end
    local deps = {
        strict = true,
        GetNumBindings = function()
            return 2
        end,
        GetBinding = function(index)
            if index == 1 then
                -- Three key slots, and slot 3 arrives in non-canonical order.
                return "CMDA", "CatA", "F1", "SHIFT-F1", "CTRL-ALT-SHIFT-T"
            end
            return "CMDB", "CatB", "", "F2"
        end,
    }
    local map = KC.BuildBindingMap(deps)
    if not map then
        self:Fail("BuildBindingMap returned nil with both stubs present")
        return
    end
    local total = 0
    for _ in pairs(map) do
        total = total + 1
    end
    if not eq(self, 4, total, "distinct canonical keys (the empty key is skipped)") then
        return
    end
    if not eq(self, "CMDA", map["F1"][1].command, "F1 command") then
        return
    end
    if not eq(self, "CatA", map["F1"][1].category, "F1 category") then
        return
    end
    if not eq(self, 1, map["F1"][1].slot, "F1 came from key slot 1") then
        return
    end
    if not eq(self, 2, map["SHIFT-F1"][1].slot, "SHIFT-F1 came from key slot 2") then
        return
    end
    if not eq(self, 3, map["ALT-CTRL-SHIFT-T"][1].slot, "third slot canonicalised to ALT-CTRL-SHIFT-T") then
        return
    end
    if not eq(self, "CMDB", map["F2"][1].command, "F2 command") then
        return
    end
    if not eq(self, 2, map["F2"][1].slot, "F2 came from key slot 2 (slot 1 was empty)") then
        return
    end
    self:Pass()
end)

TS:Register("KB conflict: BuildBindingMap keeps both commands on a collided key", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.BuildBindingMap then
        self:Skip("KeybindConflict.BuildBindingMap not available")
        return
    end
    local deps = {
        strict = true,
        GetNumBindings = function()
            return 2
        end,
        GetBinding = function(index)
            if index == 1 then
                return "CMDA", "CatA", "ALT-Q"
            end
            -- Same combo, different casing: it must collide, not miss.
            return "CMDB", "CatB", "alt-q"
        end,
    }
    local map = KC.BuildBindingMap(deps)
    if not map then
        self:Fail("BuildBindingMap returned nil with both stubs present")
        return
    end
    if not eq(self, 2, #map["ALT-Q"], "both owners retained on ALT-Q") then
        return
    end
    if not eq(self, "CMDA", map["ALT-Q"][1].command, "first owner") then
        return
    end
    if not eq(self, "CMDB", map["ALT-Q"][2].command, "second owner") then
        return
    end
    if not eq(self, nil, KC.BuildBindingMap({ strict = true }), "nil when the enumeration API is absent") then
        return
    end
    self:Pass()
end)

-- ===========================================================================
-- GROUP 3 -- the capability probe (KC.ProbeCapabilities / KC.ResetCapabilities)
-- ===========================================================================

TS:Register("KB conflict: ProbeCapabilities degrades to all-false with every global absent", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.ProbeCapabilities then
        self:Skip("KeybindConflict.ProbeCapabilities not available")
        return
    end
    -- strict suppresses the live globals; refresh keeps the production cache
    -- untouched. Reaching the next line at all proves nothing raised.
    local capabilities = KC.ProbeCapabilities({ strict = true, refresh = true })
    if not eq(self, false, capabilities.bindingAction, "bindingAction") then
        return
    end
    if not eq(self, false, capabilities.bindingEnum, "bindingEnum") then
        return
    end
    if not eq(self, false, capabilities.modifiedClickRead, "modifiedClickRead") then
        return
    end
    if not eq(self, false, capabilities.modifiedClickEnum, "modifiedClickEnum") then
        return
    end
    if not eq(self, false, capabilities.modifiedClickIndexed, "modifiedClickIndexed") then
        return
    end
    if not eq(self, false, capabilities.clickBindings, "clickBindings") then
        return
    end
    if not eq(self, false, capabilities.cvarBool, "cvarBool") then
        return
    end
    if not eq(self, nil, capabilities.probeError, "no error was raised by the probe") then
        return
    end
    self:Pass()
end)

TS:Register("KB conflict: ProbeCapabilities caches and ResetCapabilities clears it", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.ProbeCapabilities or not KC.ResetCapabilities then
        self:Skip("KeybindConflict.ProbeCapabilities/ResetCapabilities not available")
        return
    end
    KC.ResetCapabilities()
    local first = KC.ProbeCapabilities()
    local second = KC.ProbeCapabilities()
    if not eq(self, first, second, "second call returns the cached table") then
        return
    end
    KC.ResetCapabilities()
    local third = KC.ProbeCapabilities()
    if third == first then
        self:Fail("ResetCapabilities did not clear the cache")
        return
    end
    -- A refresh probe must never overwrite the production cache.
    KC.ProbeCapabilities({ strict = true, refresh = true })
    if not eq(self, third, KC.ProbeCapabilities(), "refresh probe left the cache intact") then
        return
    end
    self:Pass()
end)

-- ===========================================================================
-- GROUP 4 -- the modified-click registry (KC.GetModifiedClickMap)
-- ===========================================================================

TS:Register("KB conflict: ParseModifiedClickValue splits bare and compound values", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.ParseModifiedClickValue then
        self:Skip("KeybindConflict.ParseModifiedClickValue not available")
        return
    end
    -- The wiki states a modified-click value "Must be one of: ALT, CTRL, SHIFT,
    -- NONE". Measurement contradicts it: on a stock live client CHATLINK came
    -- back SHIFT-BUTTON1, DRESSUP CTRL-BUTTON1 and EXPANDITEM SHIFT-BUTTON2.
    -- Each case asserts the modifier set and the button component separately so
    -- a regression in one cannot be masked by the other.
    local noneMods, noneButton = KC.ParseModifiedClickValue("NONE")
    if not eq(self, nil, next(noneMods), "NONE yields an empty modifier set") then
        return
    end
    if not eq(self, nil, noneButton, "NONE yields no button") then
        return
    end
    local bareMods, bareButton = KC.ParseModifiedClickValue("SHIFT")
    if not eq(self, true, bareMods.SHIFT, "bare SHIFT sets SHIFT") then
        return
    end
    if not eq(self, nil, bareMods.CTRL, "bare SHIFT leaves CTRL unset") then
        return
    end
    if not eq(self, nil, bareButton, "bare SHIFT yields no button") then
        return
    end
    local chatMods, chatButton = KC.ParseModifiedClickValue("SHIFT-BUTTON1")
    if not eq(self, true, chatMods.SHIFT, "SHIFT-BUTTON1 sets SHIFT") then
        return
    end
    if not eq(self, "BUTTON1", chatButton, "SHIFT-BUTTON1 button component") then
        return
    end
    local dressMods, dressButton = KC.ParseModifiedClickValue("CTRL-BUTTON1")
    if not eq(self, true, dressMods.CTRL, "CTRL-BUTTON1 sets CTRL") then
        return
    end
    if not eq(self, nil, dressMods.SHIFT, "CTRL-BUTTON1 leaves SHIFT unset") then
        return
    end
    if not eq(self, "BUTTON1", dressButton, "CTRL-BUTTON1 button component") then
        return
    end
    local expandMods, expandButton = KC.ParseModifiedClickValue("SHIFT-BUTTON2")
    if not eq(self, true, expandMods.SHIFT, "SHIFT-BUTTON2 sets SHIFT") then
        return
    end
    if not eq(self, "BUTTON2", expandButton, "SHIFT-BUTTON2 button component") then
        return
    end
    self:Pass()
end)

TS:Register("KB conflict: the fallback action list is the measured 22, not the wiki list", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.KNOWN_MODIFIED_CLICK_ACTIONS then
        self:Skip("KeybindConflict.KNOWN_MODIFIED_CLICK_ACTIONS not available")
        return
    end
    -- This test exists to PIN the measurement against a future well-meaning edit
    -- that restores the wiki's published list. GetNumModifiedClickActions
    -- returned 22 on the live 12.0.7 client on 2026-08-11. The wiki's list has
    -- 14 entries, nine of the live 22 are absent from it, and it publishes
    -- SOCKETITEM, which does not exist at runtime. If this test fails, re-measure
    -- on a live client before touching the list.
    local present = {}
    for _, name in ipairs(KC.KNOWN_MODIFIED_CLICK_ACTIONS) do
        present[name] = true
    end
    if not eq(self, 22, #KC.KNOWN_MODIFIED_CLICK_ACTIONS, "measured action count") then
        return
    end
    if not eq(self, true, present.MOUSEOVERCAST, "MOUSEOVERCAST present (the wiki omits it)") then
        return
    end
    if not eq(self, true, present.HOUSINGEXTRAINCREMENT, "HOUSINGEXTRAINCREMENT present (the wiki omits it)") then
        return
    end
    if not eq(self, nil, present.SOCKETITEM, "SOCKETITEM absent (published by the wiki, absent at runtime)") then
        return
    end
    self:Pass()
end)

TS:Register("KB conflict: GetModifiedClickMap falls back to the known action list", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.GetModifiedClickMap or not KC.KNOWN_MODIFIED_CLICK_ACTIONS then
        self:Skip("KeybindConflict.GetModifiedClickMap not available")
        return
    end
    local deps = {
        strict = true,
        refresh = true,
        GetModifiedClick = function()
            return "SHIFT"
        end,
    }
    local map = KC.GetModifiedClickMap(deps)
    if not eq(self, "fallback", map.source, "source reports the degraded path") then
        return
    end
    if not eq(self, 22, #KC.KNOWN_MODIFIED_CLICK_ACTIONS, "known action list size") then
        return
    end
    if not eq(self, "SHIFT", map.SELFCAST, "SELFCAST modifier read through the fallback list") then
        return
    end
    if not eq(self, "SHIFT", map.MOUSEOVERCAST, "MOUSEOVERCAST is in the fallback list") then
        return
    end
    if not eq(self, "SHIFT", map.PICKUPACTION, "PICKUPACTION is in the fallback list") then
        return
    end
    -- With no way to read a modifier at all, the value is UNKNOWN, never "NONE".
    local blind = KC.GetModifiedClickMap({ strict = true, refresh = true })
    if not eq(self, "fallback", blind.source, "blind probe still reports fallback") then
        return
    end
    if not eq(self, "UNKNOWN", blind.SELFCAST, "unreadable modifier is UNKNOWN") then
        return
    end
    self:Pass()
end)

TS:Register("KB conflict: GetModifiedClickMap prefers the runtime enumeration", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.GetModifiedClickMap then
        self:Skip("KeybindConflict.GetModifiedClickMap not available")
        return
    end
    local names = { "SELFCAST", "FOCUSCAST" }
    local deps = {
        strict = true,
        refresh = true,
        GetNumModifiedClickActions = function()
            return #names
        end,
        GetModifiedClickAction = function(index)
            return names[index]
        end,
        GetModifiedClick = function(action)
            if action == "SELFCAST" then
                return "ALT"
            end
            return "NONE"
        end,
    }
    local map = KC.GetModifiedClickMap(deps)
    if not eq(self, "runtime", map.source, "source reports the runtime path") then
        return
    end
    if not eq(self, "ALT", map.SELFCAST, "SELFCAST modifier") then
        return
    end
    if not eq(self, "NONE", map.FOCUSCAST, "FOCUSCAST modifier") then
        return
    end
    if not eq(self, nil, map.PICKUPACTION, "the fallback list is not merged into a runtime result") then
        return
    end
    self:Pass()
end)

-- ===========================================================================
-- GROUP 5 -- the per-key probe (KC.CheckKey)
-- ===========================================================================

TS:Register("KB conflict: CheckKey reports conflict when effective is not the expected action", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.CheckKey then
        self:Skip("KeybindConflict.CheckKey not available")
        return
    end
    local deps = {
        strict = true,
        refresh = true,
        GetBindingAction = function(_, checkOverride)
            if checkOverride then
                return "CLICK BT4Button7:LeftButton"
            end
            return ""
        end,
        GetModifiedClick = function()
            return "NONE"
        end,
    }
    local result = KC.CheckKey("ctrl-alt-shift-t", "CLICK GRIPEMS_SeqA:LeftButton", deps)
    if not result then
        self:Fail("CheckKey returned nil for a valid key")
        return
    end
    if not eq(self, "ALT-CTRL-SHIFT-T", result.key, "canonical key on the result") then
        return
    end
    if not eq(self, "conflict", result.verdict, "verdict") then
        return
    end
    local effective = layerById(result, "effective")
    if not eq(self, "conflict", effective.status, "effective layer status") then
        return
    end
    if not eq(self, false, effective.ownedByExpected, "ownedByExpected") then
        return
    end
    if not eq(self, "CLICK BT4Button7:LeftButton", effective.action, "effective action") then
        return
    end
    if not eq(self, true, effective.maskedBase, "an override is masking the base binding") then
        return
    end
    -- The effective layer is the one that drove the verdict, so it grades hardest
    -- and it is NOT republished as a context note.
    if not eq(self, "error", effective.severity, "effective layer severity") then
        return
    end
    if not eq(self, nil, noteById(result, "effective"), "the verdict layer is never a context note") then
        return
    end
    if not eq(self, 0, noteCount(result), "no other layer found anything") then
        return
    end
    self:Pass()
end)

TS:Register("KB conflict: CheckKey reports clear when effective matches and no layer objects", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.CheckKey then
        self:Skip("KeybindConflict.CheckKey not available")
        return
    end
    local expected = "CLICK GRIPEMS_SeqA:LeftButton"
    local deps = {
        strict = true,
        refresh = true,
        GetBindingAction = function(_, checkOverride)
            if checkOverride then
                return expected
            end
            return ""
        end,
        GetModifiedClick = function()
            return "NONE"
        end,
    }
    local result = KC.CheckKey("SHIFT-ALT-CTRL-T", expected, deps)
    if not result then
        self:Fail("CheckKey returned nil for a valid key")
        return
    end
    if not eq(self, "clear", result.verdict, "verdict") then
        return
    end
    local effective = layerById(result, "effective")
    if not eq(self, "clear", effective.status, "effective layer status") then
        return
    end
    if not eq(self, true, effective.ownedByExpected, "ownedByExpected") then
        return
    end
    if not eq(self, "clear", layerById(result, "base").status, "base layer status") then
        return
    end
    if not eq(self, "clear", layerById(result, "modifier").status, "modifier layer status") then
        return
    end
    -- A keyboard key is simply not a click-binding question; that is "not asked",
    -- not "capability missing", so it must not drag the verdict to unknown.
    if not eq(self, false, layerById(result, "clickbind").applicable, "clickbind layer is not applicable") then
        return
    end
    -- Nothing found anything, so there is no context to report either.
    if not eq(self, 0, noteCount(result), "no context notes on a wholly clear key") then
        return
    end
    self:Pass()
end)

TS:Register("KB conflict: CheckKey reports unknown, never clear, on a missing capability", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.CheckKey then
        self:Skip("KeybindConflict.CheckKey not available")
        return
    end
    local result = KC.CheckKey("ALT-Q", "CLICK GRIPEMS_SeqA:LeftButton", { strict = true, refresh = true })
    if not result then
        self:Fail("CheckKey returned nil for a valid key")
        return
    end
    if not eq(self, "unknown", result.verdict, "verdict") then
        return
    end
    local base = layerById(result, "base")
    if not eq(self, "unknown", base.status, "base layer status") then
        return
    end
    if not eq(self, true, base.capabilityMissing, "base layer flags the missing capability") then
        return
    end
    local effective = layerById(result, "effective")
    if not eq(self, "unknown", effective.status, "effective layer status") then
        return
    end
    if not eq(self, false, effective.ownedByExpected, "ownedByExpected defaults to false") then
        return
    end
    if not eq(self, "unknown", layerById(result, "modifier").status, "modifier layer status") then
        return
    end
    if not eq(self, nil, KC.CheckKey("", "CMD", { strict = true, refresh = true }), "nil for an empty key") then
        return
    end
    self:Pass()
end)

TS:Register("KB conflict: CheckKey separates cast redirection from click modifiers", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.CheckKey then
        self:Skip("KeybindConflict.CheckKey not available")
        return
    end
    local expected = "CLICK GRIPEMS_SeqA:LeftButton"
    local names = { "SELFCAST", "PICKUPACTION", "CHATLINK" }
    local deps = {
        strict = true,
        refresh = true,
        GetBindingAction = function(_, checkOverride)
            if checkOverride then
                return expected
            end
            return ""
        end,
        GetNumModifiedClickActions = function()
            return #names
        end,
        GetModifiedClickAction = function(index)
            return names[index]
        end,
        GetModifiedClick = function(action)
            if action == "SELFCAST" then
                return "ALT"
            end
            if action == "PICKUPACTION" then
                return "SHIFT"
            end
            return "CTRL"
        end,
    }
    -- The key carries ALT and SHIFT, so SELFCAST and PICKUPACTION both match and
    -- CHATLINK (on CTRL) does not.
    local result = KC.CheckKey("shift-alt-q", expected, deps)
    if not result then
        self:Fail("CheckKey returned nil for a valid key")
        return
    end
    local modifier = layerById(result, "modifier")
    if not eq(self, "runtime", modifier.source, "modifier layer source") then
        return
    end
    if not eq(self, 2, #modifier.entries, "only the matching modifiers are reported") then
        return
    end
    local selfcast = entryByAction(modifier, "SELFCAST")
    if not selfcast then
        self:Fail("SELFCAST entry missing from the modifier layer")
        return
    end
    if not eq(self, true, selfcast.castRedirect, "SELFCAST redirects the cast") then
        return
    end
    if not eq(self, "ALT", selfcast.modifier, "SELFCAST modifier") then
        return
    end
    local pickup = entryByAction(modifier, "PICKUPACTION")
    if not pickup then
        self:Fail("PICKUPACTION entry missing from the modifier layer")
        return
    end
    if not eq(self, false, pickup.castRedirect, "PICKUPACTION does not redirect the cast") then
        return
    end
    if not eq(self, nil, entryByAction(modifier, "CHATLINK"), "CHATLINK is on an unheld modifier") then
        return
    end
    -- CHANGED 2026-08-11: this asserted verdict = conflict while the verdict was a
    -- flat OR across all four layers. The verdict now comes from the effective
    -- layer alone, and EMS owns this keypress, so the key reads clear and the cast
    -- redirect is republished as a context note. The modifier LAYER still reports
    -- conflict: the finding is real, it just no longer speaks for the whole key.
    if not eq(self, "conflict", modifier.status, "modifier layer status") then
        return
    end
    if not eq(self, "clear", result.verdict, "verdict") then
        return
    end
    if not eq(self, true, layerById(result, "effective").ownedByExpected, "EMS still owns the keypress") then
        return
    end
    local redirectNote = noteById(result, "modifier")
    if not redirectNote then
        self:Fail("the cast redirect was not republished as a context note")
        return
    end
    if not eq(self, "cast_redirect", redirectNote.reason, "note reason token") then
        return
    end
    -- CHANGED 2026-08-11: this asserted "info" while a modifier-layer conflict fell
    -- through to the info default. It grades warning now. The cast redirect is a
    -- real finding the effective layer structurally cannot see -- the keypress
    -- reaches EMS and the sequence fires, and every spell in it is redirected -- so
    -- info under a clear verdict buried it. The VERDICT is untouched: it still
    -- comes from the effective layer alone and still reads clear on this key.
    if not eq(self, "warning", redirectNote.severity, "note severity") then
        return
    end
    if not eq(self, 1, noteCount(result), "the cast redirect is the only context note") then
        return
    end
    self:Pass()
end)

TS:Register("KB conflict: CheckKey intersects a parsed compound modified-click value", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.CheckKey then
        self:Skip("KeybindConflict.CheckKey not available")
        return
    end
    local expected = "CLICK GRIPEMS_SeqA:LeftButton"
    local names = { "CHATLINK", "DRESSUP" }
    local deps = {
        strict = true,
        refresh = true,
        GetBindingAction = function(_, checkOverride)
            if checkOverride then
                return expected
            end
            return ""
        end,
        GetNumModifiedClickActions = function()
            return #names
        end,
        GetModifiedClickAction = function(index)
            return names[index]
        end,
        GetModifiedClick = function(action)
            -- Both values as measured off a stock live client.
            if action == "CHATLINK" then
                return "SHIFT-BUTTON1"
            end
            return "CTRL-BUTTON1"
        end,
    }
    -- The key carries SHIFT only, so the SHIFT component of SHIFT-BUTTON1 matches
    -- and CTRL-BUTTON1 does not. A raw string compare against the modifier set
    -- would have missed BOTH, because neither value is a bare modifier.
    local result = KC.CheckKey("shift-q", expected, deps)
    if not result then
        self:Fail("CheckKey returned nil for a valid key")
        return
    end
    local modifier = layerById(result, "modifier")
    if not eq(self, 1, #modifier.entries, "only the SHIFT-held action matches") then
        return
    end
    local chat = entryByAction(modifier, "CHATLINK")
    if not chat then
        self:Fail("CHATLINK entry missing from the modifier layer")
        return
    end
    if not eq(self, "SHIFT-BUTTON1", chat.modifier, "the compound value is carried verbatim") then
        return
    end
    if not eq(self, "BUTTON1", chat.button, "the parsed button component") then
        return
    end
    if not eq(self, false, chat.castRedirect, "CHATLINK modifies a click, it does not redirect a cast") then
        return
    end
    if not eq(self, nil, entryByAction(modifier, "DRESSUP"), "CTRL-BUTTON1 is on an unheld modifier") then
        return
    end
    -- A click modifier is not a keypress conflict, so the layer stays clear.
    if not eq(self, "clear", modifier.status, "modifier layer status") then
        return
    end
    if not eq(self, "clear", result.verdict, "verdict") then
        return
    end
    self:Pass()
end)

TS:Register("KB conflict: the measured live case reads clear with a masked base", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.CheckKey then
        self:Skip("KeybindConflict.CheckKey not available")
        return
    end
    -- REGRESSION PIN, and the reason the verdict rule changed at all. This is the
    -- exact state BOTH of Jesper's live EMS keys were measured in on 2026-08-11:
    -- key "5" sitting on top of ACTIONBUTTON5 and key "NUMPADPLUS" on top of
    -- MINIMAPZOOMIN. Both keys worked perfectly, and both reported
    -- verdict = conflict under the old flat-OR rule. The three strings below are
    -- the ones captured off the client for key "5", verbatim.
    local expected = "CLICK GRIPEMS_ORCBMPLMT16:LeftButton"
    local deps = {
        strict = true,
        refresh = true,
        GetBindingAction = function(_, checkOverride)
            if checkOverride then
                return expected
            end
            return "ACTIONBUTTON5"
        end,
        GetModifiedClick = function()
            return "NONE"
        end,
    }
    local result = KC.CheckKey("5", expected, deps)
    if not result then
        self:Fail("CheckKey returned nil for a valid key")
        return
    end
    if not eq(self, "clear", result.verdict, "verdict on a working live key") then
        return
    end
    local effective = layerById(result, "effective")
    if not eq(self, "clear", effective.status, "effective layer status") then
        return
    end
    if not eq(self, true, effective.ownedByExpected, "EMS owns the keypress") then
        return
    end
    if not eq(self, "info", effective.severity, "effective layer severity") then
        return
    end
    local base = layerById(result, "base")
    if not eq(self, "masked", base.status, "base layer downgraded to masked") then
        return
    end
    if not eq(self, "info", base.severity, "base layer severity") then
        return
    end
    -- The native command has to survive the downgrade: naming the command this key
    -- would fall through to is the entire point of keeping the row.
    if not eq(self, "ACTIONBUTTON5", base.action, "the native command is carried through unchanged") then
        return
    end
    if not eq(self, 1, noteCount(result), "exactly one context note") then
        return
    end
    local note = noteById(result, "base")
    if not note then
        self:Fail("the masked base layer was not republished as a context note")
        return
    end
    if not eq(self, "info", note.severity, "note severity") then
        return
    end
    if not eq(self, "masked_by_effective_override", note.reason, "note reason token") then
        return
    end
    self:Pass()
end)

TS:Register("KB conflict: the is-this-key-free query does not regress to clear", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.CheckKey then
        self:Skip("KeybindConflict.CheckKey not available")
        return
    end
    -- With expectedAction nil the question is not "does EMS hold this key" but
    -- "does anything", so a native owner is a conflict. Driving the verdict off
    -- the effective layer must not turn this query into an all-clear.
    local ownedDeps = {
        strict = true,
        refresh = true,
        GetBindingAction = function()
            return "ACTIONBUTTON5"
        end,
        GetModifiedClick = function()
            return "NONE"
        end,
    }
    local owned = KC.CheckKey("5", nil, ownedDeps)
    if not owned then
        self:Fail("CheckKey returned nil for a valid key")
        return
    end
    if not eq(self, "conflict", owned.verdict, "verdict with a native owner and no expected action") then
        return
    end
    local effective = layerById(owned, "effective")
    if not eq(self, "conflict", effective.status, "effective layer status") then
        return
    end
    if not eq(self, "ACTIONBUTTON5", effective.action, "the current owner is named") then
        return
    end
    if not eq(self, false, effective.ownedByExpected, "nothing was expected, so nothing is owned") then
        return
    end
    if not eq(self, "error", effective.severity, "effective layer severity") then
        return
    end
    -- The base layer is a genuine conflict here, not a masked one: no healthy EMS
    -- override sits above it, so it is not downgraded.
    local base = layerById(owned, "base")
    if not eq(self, "conflict", base.status, "base layer status") then
        return
    end
    if not eq(self, "error", base.severity, "base layer severity") then
        return
    end
    if not eq(self, "native_binding_owner", noteById(owned, "base").reason, "note reason token") then
        return
    end
    -- The other half of the query: an unowned key with no expected action is free.
    local freeDeps = {
        strict = true,
        refresh = true,
        GetBindingAction = function()
            return ""
        end,
        GetModifiedClick = function()
            return "NONE"
        end,
    }
    local free = KC.CheckKey("5", nil, freeDeps)
    if not free then
        self:Fail("CheckKey returned nil for a valid key")
        return
    end
    if not eq(self, "clear", free.verdict, "verdict on an unowned key") then
        return
    end
    if not eq(self, 0, noteCount(free), "no context notes on a free key") then
        return
    end
    self:Pass()
end)

TS:Register("KB conflict: a missing capability is unknown even when every layer is clear", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.CheckKey then
        self:Skip("KeybindConflict.CheckKey not available")
        return
    end
    -- Every layer the verdict looks at reads clear, and one capability is missing.
    -- Clear must still be unreachable: an absence is not an all-clear. C_ClickBindings
    -- is left out of the deps, and the key is a mouse button, so the click-binding
    -- layer is applicable AND unreadable rather than simply not asked.
    local expected = "CLICK GRIPEMS_SeqA:LeftButton"
    local deps = {
        strict = true,
        refresh = true,
        GetBindingAction = function(_, checkOverride)
            if checkOverride then
                return expected
            end
            return ""
        end,
        GetModifiedClick = function()
            return "NONE"
        end,
    }
    local result = KC.CheckKey("BUTTON4", expected, deps)
    if not result then
        self:Fail("CheckKey returned nil for a valid key")
        return
    end
    if not eq(self, "unknown", result.verdict, "verdict") then
        return
    end
    if not eq(self, "clear", layerById(result, "base").status, "base layer status") then
        return
    end
    local effective = layerById(result, "effective")
    if not eq(self, "clear", effective.status, "effective layer status") then
        return
    end
    if not eq(self, "info", effective.severity, "effective layer severity") then
        return
    end
    if not eq(self, "clear", layerById(result, "modifier").status, "modifier layer status") then
        return
    end
    local clickbind = layerById(result, "clickbind")
    if not eq(self, true, clickbind.applicable, "a mouse button IS a click-binding question") then
        return
    end
    if not eq(self, true, clickbind.capabilityMissing, "clickbind layer flags the missing capability") then
        return
    end
    if not eq(self, "unknown", clickbind.status, "clickbind layer status") then
        return
    end
    if not eq(self, "warning", clickbind.severity, "a missing capability grades warning") then
        return
    end
    -- Unknown is not a finding, so it is not context either.
    if not eq(self, 0, noteCount(result), "an unreadable layer is not a context note") then
        return
    end
    self:Pass()
end)

TS:Register("KB conflict: every layer carries a severity drawn from KC.SEVERITY", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.CheckKey or not KC.SEVERITY then
        self:Skip("KeybindConflict.CheckKey/SEVERITY not available")
        return
    end
    -- Phase 3 reuses RepairFrame's severity rendering, so an off-scale string on
    -- any layer would render as nothing at all. Both probes below are checked
    -- layer by layer rather than in aggregate.
    local expected = "CLICK GRIPEMS_SeqA:LeftButton"
    local healthyDeps = {
        strict = true,
        refresh = true,
        GetBindingAction = function(_, checkOverride)
            if checkOverride then
                return expected
            end
            return "ACTIONBUTTON5"
        end,
        GetModifiedClick = function(action)
            if action == "SELFCAST" then
                return "ALT"
            end
            return "NONE"
        end,
    }
    -- ALT-5 exercises three grading paths at once: a masked base, a modifier layer
    -- holding a cast redirect, and a click-binding layer that was never asked.
    local healthy = KC.CheckKey("alt-5", expected, healthyDeps)
    if not healthy then
        self:Fail("CheckKey returned nil for a valid key")
        return
    end
    for _, layer in ipairs(healthy.layers) do
        if not isSeverity(KC, layer.severity) then
            self:Fail("layer " .. tostring(layer.id) .. " has an off-scale severity: " .. tostring(layer.severity))
            return
        end
    end
    if not eq(self, "info", layerById(healthy, "base").severity, "masked base severity") then
        return
    end
    if not eq(self, "info", layerById(healthy, "effective").severity, "clear effective severity") then
        return
    end
    -- CHANGED 2026-08-11: a modifier layer holding a cast redirect is a conflict,
    -- and a conflict on either context layer now grades warning instead of taking
    -- the info default.
    if not eq(self, "warning", layerById(healthy, "modifier").severity, "cast-redirect modifier severity") then
        return
    end
    if not eq(self, "info", layerById(healthy, "clickbind").severity, "not-asked clickbind severity") then
        return
    end
    -- Second probe: every global suppressed, so three layers are unreadable and
    -- the fourth was never applicable.
    local blind = KC.CheckKey("ALT-Q", expected, { strict = true, refresh = true })
    if not blind then
        self:Fail("CheckKey returned nil for a valid key")
        return
    end
    for _, layer in ipairs(blind.layers) do
        if not isSeverity(KC, layer.severity) then
            self:Fail("layer " .. tostring(layer.id) .. " has an off-scale severity: " .. tostring(layer.severity))
            return
        end
    end
    if not eq(self, "warning", layerById(blind, "base").severity, "unreadable base severity") then
        return
    end
    if not eq(self, "warning", layerById(blind, "effective").severity, "unreadable effective severity") then
        return
    end
    if not eq(self, "warning", layerById(blind, "modifier").severity, "unreadable modifier severity") then
        return
    end
    if not eq(self, "info", layerById(blind, "clickbind").severity, "not-asked clickbind severity") then
        return
    end
    self:Pass()
end)

TS:Register("KB conflict: a cast redirect grades warning under a clear verdict", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.CheckKey or not KC.SEVERITY then
        self:Skip("KeybindConflict.CheckKey/SEVERITY not available")
        return
    end
    -- The grading half of the 2026-08-11 decision, pinned on its own rather than
    -- as a side assertion in a broader case. EMS owns this keypress, so the verdict
    -- is clear and MUST STAY clear -- the verdict rule is not what changed. What
    -- the modifier layer found is still real and still invisible from the effective
    -- layer: the sequence fires and every spell in it is redirected to self. A
    -- finding that survives a clear verdict has to grade above info or the clear
    -- verdict buries it.
    local expected = "CLICK GRIPEMS_SeqA:LeftButton"
    local names = { "SELFCAST" }
    local deps = {
        strict = true,
        refresh = true,
        GetBindingAction = function(_, checkOverride)
            if checkOverride then
                return expected
            end
            return ""
        end,
        GetNumModifiedClickActions = function()
            return #names
        end,
        GetModifiedClickAction = function(index)
            return names[index]
        end,
        GetModifiedClick = function()
            return "ALT"
        end,
    }
    -- The key holds ALT and SELFCAST is configured on ALT, so the redirect bites.
    local result = KC.CheckKey("alt-q", expected, deps)
    if not result then
        self:Fail("CheckKey returned nil for a valid key")
        return
    end
    if not eq(self, "clear", result.verdict, "the verdict rule is unchanged: EMS owns the keypress") then
        return
    end
    local effective = layerById(result, "effective")
    if not eq(self, true, effective.ownedByExpected, "the expected action owns the effective layer") then
        return
    end
    local modifier = layerById(result, "modifier")
    if not eq(self, "conflict", modifier.status, "modifier layer status") then
        return
    end
    if not isSeverity(KC, modifier.severity) then
        self:Fail("modifier severity is off the KC.SEVERITY scale: " .. tostring(modifier.severity))
        return
    end
    if not eq(self, KC.SEVERITY.warning, modifier.severity, "modifier layer severity") then
        return
    end
    if not eq(self, 1, noteCount(result), "the cast redirect is the only context note") then
        return
    end
    local note = noteById(result, "modifier")
    if not note then
        self:Fail("the cast redirect was not republished as a context note")
        return
    end
    if not eq(self, "cast_redirect", note.reason, "note reason token") then
        return
    end
    if not eq(self, KC.SEVERITY.warning, note.severity, "note severity") then
        return
    end
    self:Pass()
end)

TS:Register("KB conflict: a click-binding owner grades warning under a clear verdict", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.CheckKey or not KC.SEVERITY then
        self:Skip("KeybindConflict.CheckKey/SEVERITY not available")
        return
    end
    -- The other half of the same decision. A click binding already holds this mouse
    -- button. It does not cost the keypress either, so the verdict stays clear and
    -- the click layer never drives it -- and the effective layer has no way to
    -- report a click-binding owner, so info would hide it behind the all-clear.
    local expected = "CLICK GRIPEMS_SeqA:LeftButton"
    local deps = {
        strict = true,
        refresh = true,
        GetBindingAction = function(_, checkOverride)
            if checkOverride then
                return expected
            end
            return ""
        end,
        GetModifiedClick = function()
            return "NONE"
        end,
        C_ClickBindings = {
            GetBindingType = function()
                -- Any value that is not Enum.ClickBindingType.None means the
                -- click-binding profile already owns this button.
                return 1
            end,
        },
        Enum = {
            ClickBindingType = {
                None = 0,
                Spell = 1,
            },
        },
    }
    local result = KC.CheckKey("BUTTON4", expected, deps)
    if not result then
        self:Fail("CheckKey returned nil for a valid key")
        return
    end
    if not eq(self, "clear", result.verdict, "the verdict rule is unchanged: EMS owns the keypress") then
        return
    end
    local clickbind = layerById(result, "clickbind")
    if not eq(self, true, clickbind.applicable, "a mouse button IS a click-binding question") then
        return
    end
    if not eq(self, false, clickbind.capabilityMissing, "the click-binding probe was readable") then
        return
    end
    if not eq(self, "conflict", clickbind.status, "clickbind layer status") then
        return
    end
    if not isSeverity(KC, clickbind.severity) then
        self:Fail("clickbind severity is off the KC.SEVERITY scale: " .. tostring(clickbind.severity))
        return
    end
    if not eq(self, KC.SEVERITY.warning, clickbind.severity, "clickbind layer severity") then
        return
    end
    if not eq(self, 1, noteCount(result), "the click binding is the only context note") then
        return
    end
    local note = noteById(result, "clickbind")
    if not note then
        self:Fail("the click binding was not republished as a context note")
        return
    end
    if not eq(self, "click_binding_owner", note.reason, "note reason token") then
        return
    end
    if not eq(self, KC.SEVERITY.warning, note.severity, "note severity") then
        return
    end
    self:Pass()
end)

-- ===========================================================================
-- GROUP 6 -- installed-but-not-loaded addons (KC.ListUnloadedAddons)
-- ===========================================================================

TS:Register("KB conflict: ListUnloadedAddons names the installed addons that are not loaded", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.ListUnloadedAddons then
        self:Skip("KeybindConflict.ListUnloadedAddons not available")
        return
    end
    local rows = {
        { "AddonOne", "Addon One", "notes", true, nil },
        { "AddonTwo", "Addon Two", "notes", false, "DISABLED" },
        { "AddonThree", "Addon Three", "notes", true, "DEMAND_LOADED" },
    }
    local deps = {
        strict = true,
        C_AddOns = {
            GetNumAddOns = function()
                return #rows
            end,
            GetAddOnInfo = function(index)
                local row = rows[index]
                return row[1], row[2], row[3], row[4], row[5]
            end,
            IsAddOnLoaded = function(index)
                return index == 1
            end,
        },
    }
    local unloaded = KC.ListUnloadedAddons(deps)
    if not unloaded then
        self:Fail("ListUnloadedAddons returned nil with a full C_AddOns stub")
        return
    end
    if not eq(self, 2, #unloaded, "only the unloaded addons are listed") then
        return
    end
    if not eq(self, "AddonTwo", unloaded[1].name, "first unloaded name") then
        return
    end
    if not eq(self, "Addon Two", unloaded[1].title, "first unloaded title") then
        return
    end
    if not eq(self, "DISABLED", unloaded[1].reason, "first unloaded reason") then
        return
    end
    if not eq(self, "AddonThree", unloaded[2].name, "second unloaded name") then
        return
    end
    if not eq(self, "DEMAND_LOADED", unloaded[2].reason, "second unloaded reason") then
        return
    end
    if not eq(self, nil, KC.ListUnloadedAddons({ strict = true }), "nil when C_AddOns is absent") then
        return
    end
    self:Pass()
end)

-- ===========================================================================
-- GROUP 7 -- module constants
-- ===========================================================================

TS:Register("KB conflict: MODIFIER_ORDER and SEVERITY are the documented constants", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.MODIFIER_ORDER or not KC.SEVERITY then
        self:Skip("KeybindConflict constants not available")
        return
    end
    if not eq(self, 3, #KC.MODIFIER_ORDER, "modifier order length") then
        return
    end
    if not eq(self, "ALT", KC.MODIFIER_ORDER[1], "first modifier") then
        return
    end
    if not eq(self, "CTRL", KC.MODIFIER_ORDER[2], "second modifier") then
        return
    end
    if not eq(self, "SHIFT", KC.MODIFIER_ORDER[3], "third modifier") then
        return
    end
    -- Mapped to themselves so a later phase reuses RepairFrame's severity
    -- rendering instead of inventing a second scale.
    if not eq(self, "critical", KC.SEVERITY.critical, "critical severity") then
        return
    end
    if not eq(self, "error", KC.SEVERITY.error, "error severity") then
        return
    end
    if not eq(self, "warning", KC.SEVERITY.warning, "warning severity") then
        return
    end
    if not eq(self, "info", KC.SEVERITY.info, "info severity") then
        return
    end
    self:Pass()
end)

-- ===========================================================================
-- GROUP 8 -- the expected EMS action string (KC.ExpectedActionForSequence)
-- ===========================================================================

TS:Register("KB conflict: ExpectedActionForSequence reproduces both measured pairs", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.ExpectedActionForSequence then
        self:Skip("KeybindConflict.ExpectedActionForSequence not available")
        return
    end
    -- Both strings were read off GetBindingAction(key, true) on the live client
    -- on 2026-08-11. They are asserted one at a time because each pins a
    -- different half of the rule and a combined assert would hide which half
    -- broke: the first proves the dash is stripped, the second proves the dot is
    -- stripped while the UNDERSCORES SURVIVE. Together they rule out "strip every
    -- non-alphanumeric", which is why this function reuses Engine:SanitizeName
    -- rather than carrying a sanitiser of its own.
    local dashPair = KC.ExpectedActionForSequence("ORCBM-PLMT16")
    if not eq(self, "CLICK GRIPEMS_ORCBMPLMT16:LeftButton", dashPair, "ORCBM-PLMT16 pair") then
        return
    end
    local dotPair = KC.ExpectedActionForSequence("Slowdog_BMH_MT_V1.1")
    if not eq(self, "CLICK GRIPEMS_Slowdog_BMH_MT_V11:LeftButton", dotPair, "Slowdog_BMH_MT_V1.1 pair") then
        return
    end
    -- With the modules suppressed it returns nil rather than guessing a button
    -- name from a second, drifting sanitiser.
    local blind = KC.ExpectedActionForSequence("ORCBM-PLMT16", { strict = true })
    if not eq(self, nil, blind, "nil when the Engine module is not reachable") then
        return
    end
    if not eq(self, nil, KC.ExpectedActionForSequence(nil), "nil input") then
        return
    end
    if not eq(self, nil, KC.ExpectedActionForSequence(""), "empty string input") then
        return
    end
    self:Pass()
end)

-- ===========================================================================
-- GROUP 9 -- attribution (Phase 2): who CALLED a binding function
-- ===========================================================================
--
-- Detection answers "what owns this key" and is authoritative. Attribution
-- answers "who was seen calling a binding function" and is a HINT. These cases
-- pin the hint's machinery and, in 9o, pin the boundary between the two: adding
-- attribution to a CheckKey result must not move the verdict, a layer status, a
-- severity or a note by so much as one field.

-- The VERBATIM measured stack from the research record: hooking
-- SetOverrideBindingClick on the live 12.0.7 client on 2026-08-11 and triggering
-- it from real addon code. Copied unedited, leading [C] frame included.
--
-- THE LINE NUMBER IS 104 AND IT IS NOT A MISTAKE TO CORRECT. Engine/PetBattleButtons.lua
-- carries that call at line 143 today. The stack was captured at an earlier state
-- of the file, and this fixture pins the PARSER, not the file: 104 is the value
-- present in the string being parsed, so 104 is what the parser must return.
-- "Fixing" it to 143 would make the case assert something the input never said.
local MEASURED_STACK = [[
[C]: in function 'SetOverrideBindingClick'
[Interface/AddOns/GRIP-EMS/Engine/PetBattleButtons.lua]:104: in function 'Activate'
[<the calling chunk>]:1: in main chunk
[C]: in function 'RunScript'
[Interface/AddOns/Blizzard_ChatFrameBase/Shared/SlashCommands.lua]:1178: in function '?'
[Interface/AddOns/Blizzard_ChatFrameBase/Shared/ChatFrameEditBox.lua]:259: in function 'ParseText'
]]

-- The same frames rewritten in the other rendering: bare (unbracketed) paths,
-- backslash separators, and the backtick-quoted function form. Every value the
-- parser returns must be identical to the bracketed capture above, which is what
-- makes the tolerance real rather than merely claimed in a comment.
local BARE_STACK = [[
[C]: in function 'SetOverrideBindingClick'
Interface\AddOns\GRIP-EMS\Engine\PetBattleButtons.lua:104: in function `Activate'
[string "return 1"]:1: in main chunk
[C]: in function 'RunScript'
Interface\AddOns\Blizzard_ChatFrameBase\Shared\SlashCommands.lua:1178: in function `?'
]]

-- True when a list contains a value. Used for the limit tokens, where the ORDER is
-- not part of the contract but the presence is.
local function listHas(list, value)
    if type(list) ~= "table" then
        return false
    end
    for _, entry in ipairs(list) do
        if entry == value then
            return true
        end
    end
    return false
end

-- Sorted, comma-joined copy of a list, so two name lists can be compared for exact
-- equality in ONE assertion whose failure message shows both sides in full. A
-- per-entry loop would report only the first difference.
local function sortedJoin(list)
    local copy = {}
    for index = 1, #list do
        copy[index] = tostring(list[index])
    end
    table.sort(copy)
    return table.concat(copy, ",")
end

-- Every name InstallAttributionHooks touches: the descriptor rows plus the
-- separately-hooked invalidator. Derived from the module rather than restated, so
-- adding a descriptor cannot leave these cases quietly checking a stale set.
local function allHookNames(KC)
    local names = {}
    for _, row in ipairs(KC.ATTRIBUTION_HOOKS) do
        names[#names + 1] = row.name
    end
    names[#names + 1] = "ClearOverrideBindings"
    return names
end

-- Install into a PRIVATE buffer with a fake hooksecurefunc that captures every
-- (name, fn) pair, and fake globals for exactly the named subset. Returns the
-- fixture so a case can fire the captured hooks directly. Nothing here can reach
-- production state: deps.state is the documented escape and deps.strict suppresses
-- the live globals entirely.
local function fakeInstall(KC, presentNames)
    local fixture = { captured = {}, counter = { n = 0 } }
    fixture.deps = {
        strict = true,
        state = KC.NewAttributionState(),
        hooksecurefunc = function(name, fn)
            fixture.counter.n = fixture.counter.n + 1
            fixture.captured[name] = fn
        end,
    }
    for _, name in ipairs(presentNames) do
        fixture.deps[name] = function() end
    end
    fixture.state = KC.InstallAttributionHooks(fixture.deps)
    return fixture
end

TS:Register("KB attribution: ParseCallerFromStack reads the verbatim measured stack", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.ParseCallerFromStack then
        self:Skip("KeybindConflict.ParseCallerFromStack not available")
        return
    end
    -- The single most important case in this group: the only fixture with real
    -- provenance. Each of the four values is asserted separately so a regression
    -- names which part of the frame stopped parsing.
    local addon, file, line, funcName = KC.ParseCallerFromStack(MEASURED_STACK)
    if not eq(self, "GRIP-EMS", addon, "addon name") then
        return
    end
    if not eq(self, "Engine/PetBattleButtons.lua", file, "file path below the addon folder") then
        return
    end
    if not eq(self, 104, line, "line number as written in the captured stack") then
        return
    end
    if not eq(self, "Activate", funcName, "function name") then
        return
    end
    self:Pass()
end)

TS:Register("KB attribution: ParseCallerFromStack tolerates bare paths and backslashes", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.ParseCallerFromStack then
        self:Skip("KeybindConflict.ParseCallerFromStack not available")
        return
    end
    -- Same frame, other rendering. Identical values or the tolerance is a claim
    -- rather than a behaviour. This also exercises the backtick-quoted function
    -- form, which the bracketed fixture above does not.
    local addon, file, line, funcName = KC.ParseCallerFromStack(BARE_STACK)
    if not eq(self, "GRIP-EMS", addon, "addon name from a bare backslash path") then
        return
    end
    if not eq(self, "Engine/PetBattleButtons.lua", file, "separators normalised to forward slashes") then
        return
    end
    if not eq(self, 104, line, "line number") then
        return
    end
    if not eq(self, "Activate", funcName, "backtick-quoted function name") then
        return
    end
    self:Pass()
end)

TS:Register("KB attribution: ParseCallerFromStack returns nil with no addon frame", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.ParseCallerFromStack then
        self:Skip("KeybindConflict.ParseCallerFromStack not available")
        return
    end
    -- nil, not a guess. A caller that invents an addon name from a stack that
    -- names none is worse than one that says nothing.
    local noAddon = "[C]: in function 'SetBindingClick'\n[string \"return 1\"]:1: in main chunk\n[C]: in ?"
    if not eq(self, nil, KC.ParseCallerFromStack(noAddon), "stack with no Interface/AddOns frame") then
        return
    end
    if not eq(self, nil, KC.ParseCallerFromStack(nil), "nil input") then
        return
    end
    if not eq(self, nil, KC.ParseCallerFromStack(""), "empty string input") then
        return
    end
    self:Pass()
end)

TS:Register("KB attribution: a frame with no function name still yields addon, file and line", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.ParseCallerFromStack then
        self:Skip("KeybindConflict.ParseCallerFromStack not available")
        return
    end
    -- Losing the whole frame over a missing function name would discard exactly
    -- the part the panel needs: which addon, which file, which line.
    local mainChunk = "[C]: in function 'SetBindingClick'\n[Interface/AddOns/SomeAddon/Core.lua]:42: in main chunk"
    local addon, file, line, funcName = KC.ParseCallerFromStack(mainChunk)
    if not eq(self, "SomeAddon", addon, "addon name") then
        return
    end
    if not eq(self, "Core.lua", file, "file path") then
        return
    end
    if not eq(self, 42, line, "line number") then
        return
    end
    if not eq(self, nil, funcName, "function name is nil, and the frame survives anyway") then
        return
    end
    self:Pass()
end)

TS:Register("KB attribution: install degrades to not-installed without hooksecurefunc", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.InstallAttributionHooks or not KC.NewAttributionState then
        self:Skip("KeybindConflict attribution install not available")
        return
    end
    -- The headless and stripped-environment path. Reaching the next line at all
    -- proves nothing raised, which is the requirement: this runs at file load, and
    -- a raise here would take the whole module down.
    local state = KC.InstallAttributionHooks({ strict = true, state = KC.NewAttributionState() })
    if not eq(self, false, state.installed, "installed") then
        return
    end
    if not eq(self, 0, #state.hooked, "nothing was hooked") then
        return
    end
    if not eq(self, sortedJoin(allHookNames(KC)), sortedJoin(state.missing), "every hook name is reported missing") then
        return
    end
    if not eq(self, nil, state.installedAt, "no install timestamp") then
        return
    end
    self:Pass()
end)

TS:Register("KB attribution: install hooks exactly the globals that exist", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.InstallAttributionHooks or not KC.NewAttributionState then
        self:Skip("KeybindConflict attribution install not available")
        return
    end
    -- hooksecurefunc RAISES on a missing global, so every descriptor is checked
    -- before it is hooked. A present one lands on hooked, an absent one on missing,
    -- and neither list may be a guess.
    local productionBefore = KC._attribution
    local present = { "SetOverrideBindingClick", "SetBinding", "SetModifiedClick", "ClearOverrideBindings" }
    local fixture = fakeInstall(KC, present)
    if not eq(self, true, fixture.state.installed, "installed once at least one hook landed") then
        return
    end
    if not eq(self, sortedJoin(present), sortedJoin(fixture.state.hooked), "hooked list") then
        return
    end
    local expectedMissing = {}
    for _, name in ipairs(allHookNames(KC)) do
        if not listHas(present, name) then
            expectedMissing[#expectedMissing + 1] = name
        end
    end
    if not eq(self, sortedJoin(expectedMissing), sortedJoin(fixture.state.missing), "missing list") then
        return
    end
    -- Production state must be untouched by a spec-driven install. deps.state is
    -- the whole reason that escape exists.
    if not eq(self, productionBefore, KC._attribution, "KC._attribution is the same table it was") then
        return
    end
    if productionBefore and not eq(self, 0, #productionBefore.hooked, "production state hooked nothing") then
        return
    end
    self:Pass()
end)

TS:Register("KB attribution: a second install on an installed state hooks nothing", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.InstallAttributionHooks then
        self:Skip("KeybindConflict.InstallAttributionHooks not available")
        return
    end
    -- hooksecurefunc cannot be undone, so a double install would double every
    -- record for the rest of the session. Idempotence is a correctness property
    -- here, not a tidiness one.
    local fixture = fakeInstall(KC, { "SetOverrideBindingClick", "ClearOverrideBindings" })
    local callsAfterFirst = fixture.counter.n
    local hookedAfterFirst = sortedJoin(fixture.state.hooked)
    local second = KC.InstallAttributionHooks(fixture.deps)
    if not eq(self, fixture.state, second, "the same state is returned") then
        return
    end
    if not eq(self, callsAfterFirst, fixture.counter.n, "hooksecurefunc was not called again") then
        return
    end
    if not eq(self, hookedAfterFirst, sortedJoin(fixture.state.hooked), "hooked list unchanged") then
        return
    end
    self:Pass()
end)

TS:Register("KB attribution: a recorded key is stored and found in canonical form", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.InstallAttributionHooks or not KC.GetAttribution then
        self:Skip("KeybindConflict attribution recording not available")
        return
    end
    -- The coupling that makes attribution reachable from CheckKey at all: the
    -- recorder canonicalises on the way in, so a lookup canonicalises to the same
    -- string on the way out. Recorded under SHIFT-CTRL-ALT-F11, found under
    -- ALT-CTRL-SHIFT-F11.
    local fixture = fakeInstall(KC, { "SetOverrideBindingClick" })
    local hook = fixture.captured["SetOverrideBindingClick"]
    if type(hook) ~= "function" then
        self:Fail("the SetOverrideBindingClick hook was not captured")
        return
    end
    local owner = {}
    hook(owner, false, "SHIFT-CTRL-ALT-F11", "SomeButton")
    local records = KC.GetAttribution("ALT-CTRL-SHIFT-F11", fixture.deps)
    if not records then
        self:Fail("no records found under the canonical key")
        return
    end
    if not eq(self, 1, #records, "one record") then
        return
    end
    if not eq(self, "ALT-CTRL-SHIFT-F11", records[1].key, "stored under the canonical key") then
        return
    end
    if not eq(self, "SHIFT-CTRL-ALT-F11", records[1].rawKey, "the raw key is kept verbatim alongside it") then
        return
    end
    if not eq(self, "SetOverrideBindingClick", records[1].fn, "recorded function") then
        return
    end
    if not eq(self, "override", records[1].layer, "recorded layer") then
        return
    end
    if not eq(self, owner, records[1].owner, "the owner frame is held by identity") then
        return
    end
    if not eq(self, false, records[1].isPriority, "isPriority came from argument 2") then
        return
    end
    if not eq(self, "SomeButton", records[1].target, "target came from argument 4") then
        return
    end
    -- debugstack is absent under strict deps, so the capture degrades to nil rather
    -- than raising or inventing a caller.
    if not eq(self, nil, records[1].stack, "no stack captured when debugstack is unavailable") then
        return
    end
    if not eq(self, nil, records[1].addon, "no addon parsed without a stack") then
        return
    end
    -- The lookup canonicalises too, so the non-canonical spelling finds it as well.
    local viaRaw = KC.GetAttribution("shift-ctrl-alt-f11", fixture.deps)
    if not eq(self, 1, viaRaw and #viaRaw or 0, "the same bucket is reachable from a non-canonical query") then
        return
    end
    if not eq(self, nil, KC.GetAttribution("F12", fixture.deps), "nil for a key with no bucket") then
        return
    end
    self:Pass()
end)

TS:Register("KB attribution: an identical repeat bumps a count without advancing the ring", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.InstallAttributionHooks or not KC.GetAttribution then
        self:Skip("KeybindConflict attribution recording not available")
        return
    end
    -- Bar-paging addons call this in combat loops and debugstack walks the stack
    -- every time. The dedup is what makes the hook safe to leave installed.
    local fixture = fakeInstall(KC, { "SetOverrideBindingClick" })
    local hook = fixture.captured["SetOverrideBindingClick"]
    if type(hook) ~= "function" then
        self:Fail("the SetOverrideBindingClick hook was not captured")
        return
    end
    local owner = {}
    hook(owner, false, "F9", "SameButton")
    hook(owner, false, "F9", "SameButton")
    hook(owner, false, "F9", "SameButton")
    local records = KC.GetAttribution("F9", fixture.deps)
    if not records then
        self:Fail("no records found for F9")
        return
    end
    if not eq(self, 1, #records, "three identical calls collapse to one record") then
        return
    end
    if not eq(self, 3, records[1].count, "count") then
        return
    end
    if not eq(self, 1, fixture.state.byKey["F9"].cursor, "the ring cursor did not advance") then
        return
    end
    self:Pass()
end)

TS:Register("KB attribution: the ring keeps the newest records and drops the oldest", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.InstallAttributionHooks or not KC.GetAttribution then
        self:Skip("KeybindConflict attribution recording not available")
        return
    end
    local ringSize = KC.ATTRIBUTION_RING_SIZE
    if type(ringSize) ~= "number" or ringSize < 2 then
        self:Skip("KC.ATTRIBUTION_RING_SIZE is not a usable ring size")
        return
    end
    local fixture = fakeInstall(KC, { "SetOverrideBindingClick" })
    local hook = fixture.captured["SetOverrideBindingClick"]
    if type(hook) ~= "function" then
        self:Fail("the SetOverrideBindingClick hook was not captured")
        return
    end
    -- Distinct targets, so every call is a genuinely new triple and none dedups.
    local owner = {}
    local total = ringSize + 2
    for index = 1, total do
        hook(owner, false, "F8", "Target" .. index)
    end
    local records = KC.GetAttribution("F8", fixture.deps)
    if not records then
        self:Fail("no records found for F8")
        return
    end
    if not eq(self, ringSize, #records, "the bucket holds exactly the ring size") then
        return
    end
    -- Newest first, so entry i is call (total - i + 1); the two oldest are gone.
    for index = 1, ringSize do
        local expectedTarget = "Target" .. (total - index + 1)
        if not eq(self, expectedTarget, records[index].target, "record " .. index .. " newest-first") then
            return
        end
    end
    self:Pass()
end)

TS:Register("KB attribution: ClearOverrideBindings releases only that owner's records", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.InstallAttributionHooks or not KC.GetAttribution then
        self:Skip("KeybindConflict attribution recording not available")
        return
    end
    -- A cleared record is a key the addon LET GO of. Reporting its owner as the
    -- current holder sends the user chasing an addon that is no longer involved.
    local fixture = fakeInstall(KC, { "SetOverrideBindingClick", "ClearOverrideBindings" })
    local hook = fixture.captured["SetOverrideBindingClick"]
    local clear = fixture.captured["ClearOverrideBindings"]
    if type(hook) ~= "function" or type(clear) ~= "function" then
        self:Fail("the record and clear hooks were not both captured")
        return
    end
    local ownerA, ownerB = {}, {}
    hook(ownerA, false, "F6", "ButtonA")
    hook(ownerB, false, "F7", "ButtonB")
    clear(ownerA)
    local recordsA = KC.GetAttribution("F6", fixture.deps)
    local recordsB = KC.GetAttribution("F7", fixture.deps)
    if not recordsA or not recordsB then
        self:Fail("both keys should still have records after a clear")
        return
    end
    if not eq(self, true, recordsA[1].cleared, "the cleared owner's record is marked released") then
        return
    end
    if not eq(self, false, recordsB[1].cleared, "the other owner's record is untouched") then
        return
    end
    -- The record survives the clear rather than being deleted: knowing a key was
    -- released, and by whom, is the useful half of the fact.
    if not eq(self, "ButtonA", recordsA[1].target, "the cleared record keeps its detail") then
        return
    end
    self:Pass()
end)

TS:Register("KB attribution: SetModifiedClick never creates a key bucket", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.InstallAttributionHooks then
        self:Skip("KeybindConflict attribution recording not available")
        return
    end
    -- Its second argument is a MODIFIER VALUE such as SHIFT, not a binding key.
    -- Routing it into the key ring would put a bare modifier in the key space and
    -- corrupt every later lookup. This case exists to catch exactly that.
    local fixture = fakeInstall(KC, { "SetModifiedClick" })
    local hook = fixture.captured["SetModifiedClick"]
    if type(hook) ~= "function" then
        self:Fail("the SetModifiedClick hook was not captured")
        return
    end
    hook("SELFCAST", "SHIFT")
    local record = fixture.state.modifiedClick["SELFCAST"]
    if not record then
        self:Fail("no modified-click record was stored under SELFCAST")
        return
    end
    if not eq(self, "SHIFT", record.value, "the configured value") then
        return
    end
    if not eq(self, "SetModifiedClick", record.fn, "recorded function") then
        return
    end
    if not eq(self, 0, fixture.state.keyCount, "no key bucket was created") then
        return
    end
    if not eq(self, nil, next(fixture.state.byKey), "the key space is empty") then
        return
    end
    if not eq(self, nil, KC.GetAttribution("SHIFT", fixture.deps), "a bare modifier is not a key") then
        return
    end
    self:Pass()
end)

TS:Register("KB attribution: the key budget refuses new buckets and reports itself", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.InstallAttributionHooks or not KC.GetAttributionState then
        self:Skip("KeybindConflict attribution recording not available")
        return
    end
    -- The cap refuses NEW buckets rather than evicting old ones: evicting a bucket
    -- the user is already looking at, to make room for one they are not, is the
    -- worse failure.
    local fixture = fakeInstall(KC, { "SetOverrideBindingClick" })
    local hook = fixture.captured["SetOverrideBindingClick"]
    if type(hook) ~= "function" then
        self:Fail("the SetOverrideBindingClick hook was not captured")
        return
    end
    fixture.state.maxKeys = 2
    local owner = {}
    hook(owner, false, "F1", "ButtonOne")
    hook(owner, false, "F2", "ButtonTwo")
    hook(owner, false, "F3", "ButtonThree")
    if not eq(self, 2, fixture.state.keyCount, "the third key did not get a bucket") then
        return
    end
    if not eq(self, true, fixture.state.truncated, "truncated") then
        return
    end
    if not eq(self, nil, KC.GetAttribution("F3", fixture.deps), "the refused key has no records") then
        return
    end
    -- Existing buckets keep recording; the budget only refuses new ones.
    hook(owner, false, "F1", "ButtonOneAgain")
    local records = KC.GetAttribution("F1", fixture.deps)
    if not eq(self, 2, records and #records or 0, "an existing bucket still accepts records") then
        return
    end
    local summary = KC.GetAttributionState(fixture.deps)
    if not eq(self, true, listHas(summary.limits, KC.ATTRIBUTION_LIMITS.keyBudgetExhausted), "budget limit token") then
        return
    end
    self:Pass()
end)

TS:Register("KB attribution: the four structural limits are always published", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.GetAttributionState or not KC.ATTRIBUTION_LIMITS then
        self:Skip("KeybindConflict.GetAttributionState not available")
        return
    end
    -- These four describe the TECHNIQUE, not this session, so a clean fully-hooked
    -- state must still publish them. A UI that never sees them will never show
    -- them, and the user would read a silent attribution panel as completeness.
    local fixture = fakeInstall(KC, allHookNames(KC))
    local summary = KC.GetAttributionState(fixture.deps)
    if not eq(self, true, summary.installed, "the fixture installed cleanly") then
        return
    end
    if not eq(self, false, summary.truncated, "nothing was truncated") then
        return
    end
    local L = KC.ATTRIBUTION_LIMITS
    if not eq(self, true, listHas(summary.limits, L.hooksInstalledAtLoad), "hooks_installed_at_load") then
        return
    end
    if not eq(self, true, listHas(summary.limits, L.secureHandlerInvisible), "secure_handler_bindings_invisible") then
        return
    end
    if not eq(self, true, listHas(summary.limits, L.attemptsNotOwnership), "records_attempts_not_ownership") then
        return
    end
    if not eq(self, true, listHas(summary.limits, L.dedupFirstCaller), "deduplicated_stack_is_first_caller") then
        return
    end
    if not eq(self, false, listHas(summary.limits, L.keyBudgetExhausted), "the budget token is conditional") then
        return
    end
    if not eq(self, 4, #summary.limits, "exactly the four structural tokens") then
        return
    end
    -- The published lists are copies: a renderer must not be able to mutate live
    -- state through the summary it was handed.
    if summary.hooked == fixture.state.hooked then
        self:Fail("the hooked list was published by reference, not copied")
        return
    end
    self:Pass()
end)

TS:Register("KB attribution: attribution cannot move the verdict, a status or a note", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.CheckKey or not KC.NewAttributionState then
        self:Skip("KeybindConflict.CheckKey not available")
        return
    end
    -- THE CASE THAT PINS PHASE 2's BOUNDARY. Attribution is a best-effort parse of
    -- a stack string; the verdict was settled by measurement on a live client.
    -- Everything CheckKey decides must be byte-for-byte identical whether the
    -- attribution buffer is empty or full. If this case ever passes while the
    -- verdict reads attribution, it is not testing what it names.
    local expected = "CLICK GRIPEMS_SeqA:LeftButton"
    local function makeDeps(state)
        return {
            strict = true,
            refresh = true,
            state = state,
            GetBindingAction = function(_, checkOverride)
                if checkOverride then
                    return expected
                end
                return "ACTIONBUTTON5"
            end,
            GetModifiedClick = function(action)
                if action == "SELFCAST" then
                    return "ALT"
                end
                return "NONE"
            end,
        }
    end

    -- ALT-5 is chosen because it produces a non-trivial result to compare: a masked
    -- base layer, a modifier layer holding a cast redirect, a clear effective layer
    -- and two context notes. A key with nothing to say would compare equal for the
    -- wrong reason.
    local emptyState = KC.NewAttributionState()
    local quiet = KC.CheckKey("alt-5", expected, makeDeps(emptyState))

    local loud = fakeInstall(KC, { "SetOverrideBindingClick" })
    local hook = loud.captured["SetOverrideBindingClick"]
    if type(hook) ~= "function" then
        self:Fail("the SetOverrideBindingClick hook was not captured")
        return
    end
    local owner = {}
    hook(owner, true, "ALT-5", "SomeOtherAddonButton")
    hook(owner, true, "F4", "AnotherButton")
    hook(owner, false, "ALT-5", "YetAnotherButton")
    local noisy = KC.CheckKey("alt-5", expected, makeDeps(loud.state))

    if not quiet or not noisy then
        self:Fail("CheckKey returned nil for a valid key")
        return
    end
    -- The precondition: the two results really do differ in attribution, otherwise
    -- the comparisons below would be trivially satisfied.
    if not eq(self, nil, quiet.attribution, "the quiet run recorded nothing") then
        return
    end
    if not eq(self, 2, noisy.attribution and #noisy.attribution or 0, "the noisy run has ALT-5 records") then
        return
    end

    if not eq(self, quiet.verdict, noisy.verdict, "verdict") then
        return
    end
    if not eq(self, "clear", noisy.verdict, "and the verdict is the measured one, not an artefact") then
        return
    end
    for _, id in ipairs({ "base", "effective", "modifier", "clickbind" }) do
        local a, b = layerById(quiet, id), layerById(noisy, id)
        if not a or not b then
            self:Fail("layer " .. id .. " missing from one of the two results")
            return
        end
        if not eq(self, a.status, b.status, id .. " layer status") then
            return
        end
        if not eq(self, a.severity, b.severity, id .. " layer severity") then
            return
        end
    end
    if not eq(self, noteCount(quiet), noteCount(noisy), "note count") then
        return
    end
    for index = 1, noteCount(quiet) do
        if not eq(self, quiet.notes[index].id, noisy.notes[index].id, "note " .. index .. " id") then
            return
        end
        if not eq(self, quiet.notes[index].severity, noisy.notes[index].severity, "note " .. index .. " severity") then
            return
        end
        if not eq(self, quiet.notes[index].reason, noisy.notes[index].reason, "note " .. index .. " reason") then
            return
        end
    end
    -- And the additive half really is attached rather than merely harmless.
    if not eq(self, true, type(noisy.attributionState) == "table", "attributionState is attached") then
        return
    end
    self:Pass()
end)

-- ===========================================================================
-- GROUP 10 -- attribution against the REAL capture depth (Phase 2-polish)
-- ===========================================================================
--
-- WHY THIS GROUP EXISTS, AND IT IS NOT A COMPLIMENT TO GROUP 9. Phase 2 shipped
-- with all 41 cases green and the feature did not work at all on the client: every
-- record attributed to GRIP-EMS / Engine/KeybindConflict.lua, this module naming
-- itself as the caller of every binding call in the session.
--
-- The structural gap: GROUP 9 drives KC.ParseCallerFromStack with hand-written
-- fixtures and drives the recorder with a stubbed debugstack that returns a canned
-- string. Both halves were correct in isolation and nothing anywhere exercised the
-- REAL number of frames between the hooked function and the capture. The fixture
-- below closes that by BEING the real capture rather than a reconstruction of one.

-- VERBATIM live capture. Read off the account SavedVariables after driving the
-- 12.0.7 client on 2026-08-11 -- written into GRIP_EMS_DB, /reload, read from disk.
-- Copied unedited, self frames and all.
--
-- WHAT THE SHIPPED PARSER RETURNED FOR THIS EXACT INPUT: addon GRIP-EMS, file
-- Engine/KeybindConflict.lua, line 1223. Wrong on all three, and the call came from
-- a chat command.
--
-- AND WIDENING THE BUDGET DOES NOT FIX IT. Measured on the live client with
-- ATTRIBUTION_STACK_FRAMES raised to 20, the answer was STILL
-- GRIP-EMS / Engine/KeybindConflict.lua, because this parser returns the FIRST
-- Interface/AddOns frame and frame 1 is always this module's own code. The self-skip
-- is therefore mandatory and NOT redundant with the larger budget -- a future reader
-- who deletes one of the two fixes has restored the bug.
local LIVE_CAPTURE = [[
[Interface/AddOns/GRIP-EMS/Engine/KeybindConflict.lua]:1223: in function <Interface/AddOns/GRIP-EMS/Engine/KeybindConflict.lua:1218>
[Interface/AddOns/GRIP-EMS/Engine/KeybindConflict.lua]:1266: in function <Interface/AddOns/GRIP-EMS/Engine/KeybindConflict.lua:1250>
[tail call]: ?
[C]: in function 'pcall'
[Interface/AddOns/GRIP-EMS/Engine/KeybindConflict.lua]:1393: in function <Interface/AddOns/GRIP-EMS/Engine/KeybindConflict.lua:1392>
[C]: in function 'SetModifiedClick'
[local KC=GRIPEMS.KeybindConflict SetModifiedClick("MOUSEOVERCAST",x)]:1: in main chunk
[C]: in function 'RunScript'
[Interface/AddOns/Blizzard_ChatFrameBase/Shared/SlashCommands.lua]:1178: in function '?'
[Interface/AddOns/Blizzard_ChatFrameBase/Shared/ChatFrameEditBox.lua]:259: in function 'ParseText'
[Interface/AddOns/Blizzard_ChatFrameBase/Shared/ChatFrameEditBox.lua]:284: in function 'SendText'
]]

-- The same plumbing shape, but the caller is a GRIP-EMS file that genuinely binds.
-- Engine/VehicleKeybinds.lua and Engine/PetBattleButtons.lua really do call the
-- binding globals, and when they do the correct attribution IS GRIP-EMS. This is
-- what makes the self-skip a FILE skip and not an addon skip.
local SELF_ADDON_CALLER_CAPTURE = [[
[Interface/AddOns/GRIP-EMS/Engine/KeybindConflict.lua]:1223: in function <Interface/AddOns/GRIP-EMS/Engine/KeybindConflict.lua:1218>
[Interface/AddOns/GRIP-EMS/Engine/KeybindConflict.lua]:1266: in function <Interface/AddOns/GRIP-EMS/Engine/KeybindConflict.lua:1250>
[C]: in function 'pcall'
[C]: in function 'SetBindingClick'
[Interface/AddOns/GRIP-EMS/Engine/VehicleKeybinds.lua]:74: in function 'Apply'
[C]: in function 'RunScript'
]]

-- Plumbing only, no caller frame at all. The honest answer is nil.
local SELF_ONLY_CAPTURE = [[
[Interface/AddOns/GRIP-EMS/Engine/KeybindConflict.lua]:1223: in function <Interface/AddOns/GRIP-EMS/Engine/KeybindConflict.lua:1218>
[Interface/AddOns/GRIP-EMS/Engine/KeybindConflict.lua]:1266: in function <Interface/AddOns/GRIP-EMS/Engine/KeybindConflict.lua:1250>
[tail call]: ?
[C]: in function 'pcall'
[C]: in function 'SetModifiedClick'
]]

-- The position the first non-self addon frame occupied in the live capture above.
-- Counting from 1: three self frames, a tail call, a pcall, a second self frame, the
-- hooked [C] function, the calling chunk, THEN SlashCommands.lua at nine. The frame
-- budget has to be at least this or the real caller is outside the window and no
-- amount of parsing can recover it.
local FIRST_NON_SELF_FRAME_POSITION = 9

TS:Register("KB attribution: the live capture names the chat caller, not this module", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.ParseCallerFromStack then
        self:Skip("KeybindConflict.ParseCallerFromStack not available")
        return
    end
    -- THE REGRESSION CASE. This is the one that would have caught Phase 2 before it
    -- shipped, and the only fixture in either group taken off a running client.
    local addon, file, line, funcName = KC.ParseCallerFromStack(LIVE_CAPTURE)
    if not eq(self, "Blizzard_ChatFrameBase", addon, "addon (was GRIP-EMS before the self-skip)") then
        return
    end
    if not eq(self, "Shared/SlashCommands.lua", file, "file (was Engine/KeybindConflict.lua)") then
        return
    end
    if not eq(self, 1178, line, "line (was 1223, a line inside captureCaller)") then
        return
    end
    -- The frame renders its function name as '?', which is a readable name and is
    -- carried through rather than discarded.
    if not eq(self, "?", funcName, "function name as the client rendered it") then
        return
    end
    self:Pass()
end)

TS:Register("KB attribution: a GRIP-EMS bind site outside this module still reads GRIP-EMS", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.ParseCallerFromStack then
        self:Skip("KeybindConflict.ParseCallerFromStack not available")
        return
    end
    -- The case that proves the skip is on a FILE and not on the addon. Skipping all
    -- of GRIP-EMS would pass the case above and quietly break this one, replacing a
    -- wrong answer with a different wrong answer.
    local addon, file, line, funcName = KC.ParseCallerFromStack(SELF_ADDON_CALLER_CAPTURE)
    if not eq(self, "GRIP-EMS", addon, "a real GRIP-EMS bind site is still GRIP-EMS") then
        return
    end
    if not eq(self, "Engine/VehicleKeybinds.lua", file, "the binding file, not the conflict module") then
        return
    end
    if not eq(self, 74, line, "line") then
        return
    end
    if not eq(self, "Apply", funcName, "function name") then
        return
    end
    self:Pass()
end)

TS:Register("KB attribution: a stack of only self frames returns nil", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.ParseCallerFromStack then
        self:Skip("KeybindConflict.ParseCallerFromStack not available")
        return
    end
    -- nil, never a self attribution. "GRIP-EMS called it" is the exact wrong answer
    -- this whole polish pass exists to stop being given.
    if not eq(self, nil, KC.ParseCallerFromStack(SELF_ONLY_CAPTURE), "plumbing-only stack") then
        return
    end
    self:Pass()
end)

TS:Register("KB attribution: a rebind after a clear resurrects the record", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.InstallAttributionHooks or not KC.GetAttribution then
        self:Skip("KeybindConflict attribution recording not available")
        return
    end
    -- Clear-then-rebind is the cycle a bar-paging addon actually produces, and the
    -- first version of the dedup excluded cleared records, so every cycle captured a
    -- fresh stack and burned a ring slot. Four cycles filled the four-slot ring with
    -- four near-identical rows.
    local fixture = fakeInstall(KC, { "SetOverrideBindingClick", "ClearOverrideBindings" })
    local hook = fixture.captured["SetOverrideBindingClick"]
    local clear = fixture.captured["ClearOverrideBindings"]
    if type(hook) ~= "function" or type(clear) ~= "function" then
        self:Fail("the record and clear hooks were not both captured")
        return
    end
    local owner = {}
    hook(owner, false, "F5", "PagedButton")
    clear(owner)
    hook(owner, false, "F5", "PagedButton")
    local records = KC.GetAttribution("F5", fixture.deps)
    if not records then
        self:Fail("no records found for F5")
        return
    end
    if not eq(self, 1, #records, "the rebind folded into the existing record") then
        return
    end
    if not eq(self, 2, records[1].count, "count") then
        return
    end
    if not eq(self, 1, records[1].reacquired, "reacquired, so the release history is not lost") then
        return
    end
    if not eq(self, false, records[1].cleared, "the key is live again") then
        return
    end
    if not eq(self, nil, records[1].clearedAt, "the stale clear timestamp is dropped") then
        return
    end
    if not eq(self, 1, fixture.state.byKey["F5"].cursor, "the ring cursor did not advance") then
        return
    end
    -- The dedupFirstCaller token promises the FIRST caller's stack survives, and it
    -- has to survive a clear too or the token is a lie under the commonest pattern.
    if not eq(self, nil, records[1].stack, "no second capture was taken") then
        return
    end
    self:Pass()
end)

TS:Register("KB attribution: a different triple after a clear still opens a new record", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.InstallAttributionHooks or not KC.GetAttribution then
        self:Skip("KeybindConflict attribution recording not available")
        return
    end
    -- Resurrection is keyed on the TRIPLE matching, never on "the newest record was
    -- cleared". A different target after a clear is a different caller intent and
    -- must not be folded into the old row.
    local fixture = fakeInstall(KC, { "SetOverrideBindingClick", "ClearOverrideBindings" })
    local hook = fixture.captured["SetOverrideBindingClick"]
    local clear = fixture.captured["ClearOverrideBindings"]
    if type(hook) ~= "function" or type(clear) ~= "function" then
        self:Fail("the record and clear hooks were not both captured")
        return
    end
    local owner = {}
    hook(owner, false, "F5", "FirstButton")
    clear(owner)
    hook(owner, false, "F5", "SecondButton")
    local records = KC.GetAttribution("F5", fixture.deps)
    if not records then
        self:Fail("no records found for F5")
        return
    end
    if not eq(self, 2, #records, "a distinct triple opened its own record") then
        return
    end
    if not eq(self, "SecondButton", records[1].target, "newest record is the new target") then
        return
    end
    if not eq(self, false, records[1].cleared, "the new record is live") then
        return
    end
    if not eq(self, 0, records[1].reacquired, "a fresh record was never reacquired") then
        return
    end
    -- The old record stays cleared: that owner really did release that target.
    if not eq(self, "FirstButton", records[2].target, "the older record is preserved") then
        return
    end
    if not eq(self, true, records[2].cleared, "and it is still marked released") then
        return
    end
    self:Pass()
end)

TS:Register("KB attribution: a returned record is a copy, not the live buffer entry", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.InstallAttributionHooks or not KC.GetAttribution then
        self:Skip("KeybindConflict attribution recording not available")
        return
    end
    -- GetAttributionState has always copied its lists and says so in its comment;
    -- this function handed out live ring entries, so a renderer adjusting a field
    -- was editing the buffer. Phase 3 is the first consumer and does not exist yet.
    local fixture = fakeInstall(KC, { "SetOverrideBindingClick" })
    local hook = fixture.captured["SetOverrideBindingClick"]
    if type(hook) ~= "function" then
        self:Fail("the SetOverrideBindingClick hook was not captured")
        return
    end
    hook({}, false, "F3", "OriginalTarget")
    local first = KC.GetAttribution("F3", fixture.deps)
    if not first or not first[1] then
        self:Fail("no records found for F3")
        return
    end
    first[1].target = "MutatedByTheCaller"
    first[1].addon = "SomeOtherAddon"
    local second = KC.GetAttribution("F3", fixture.deps)
    if not second or not second[1] then
        self:Fail("no records found for F3 on the second read")
        return
    end
    if not eq(self, "OriginalTarget", second[1].target, "the buffer survived a caller mutation") then
        return
    end
    if not eq(self, nil, second[1].addon, "and so did every other field") then
        return
    end
    if first[1] == second[1] then
        self:Fail("the same record table was handed out twice, so it is not a copy")
        return
    end
    self:Pass()
end)

TS:Register("KB attribution: deps.strict suppresses the production buffer for both readers", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.GetAttribution or not KC.GetAttributionState then
        self:Skip("KeybindConflict attribution readers not available")
        return
    end
    -- Everywhere else in this module strict means the live source is suppressed,
    -- which is how the degradation paths are asserted. Both readers fell through to
    -- KC._attribution regardless, so a spec asserting degradation could pass by
    -- quietly reading real data.
    local saved = KC._attribution
    local seeded = KC.NewAttributionState()
    seeded.installed = true
    seeded.keyCount = 1
    seeded.byKey["F2"] = {
        cursor = 1,
        records = { { fn = "SetBinding", layer = "base", key = "F2", target = "Seeded", count = 1, cleared = false } },
    }
    KC._attribution = seeded

    -- Precondition: without strict the seeded buffer really is visible, otherwise
    -- the assertions below would pass for the wrong reason.
    local visible = KC.GetAttribution("F2")
    local strictRecords = KC.GetAttribution("F2", { strict = true })
    local strictSummary = KC.GetAttributionState({ strict = true })
    local looseSummary = KC.GetAttributionState()
    KC._attribution = saved

    if not eq(self, 1, visible and #visible or 0, "the seeded buffer is visible without strict") then
        return
    end
    if not eq(self, true, looseSummary.installed, "and the summary reads it too") then
        return
    end
    if not eq(self, nil, strictRecords, "strict returns no records") then
        return
    end
    if not eq(self, false, strictSummary.installed, "strict reports not installed") then
        return
    end
    if not eq(self, 0, strictSummary.keyCount, "strict reports no keys") then
        return
    end
    -- The structural limit tokens are still published: they describe the technique,
    -- not the buffer, so suppressing the buffer must not suppress them.
    if not eq(self, 4, #strictSummary.limits, "the structural tokens survive strict") then
        return
    end
    self:Pass()
end)

TS:Register("KB attribution: the frame budget clears the plumbing depth", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.ATTRIBUTION_STACK_FRAMES then
        self:Skip("KC.ATTRIBUTION_STACK_FRAMES not available")
        return
    end
    -- Expressed against the MEASURED position rather than a bare number, so the
    -- assertion carries its own justification. Phase 2 shipped a budget of 6 and the
    -- first non-self frame sat at 9, which is why the real caller was never in the
    -- window. An edit that lowers the budget back under the plumbing depth fails
    -- here rather than silently returning this module as every caller.
    if KC.ATTRIBUTION_STACK_FRAMES < FIRST_NON_SELF_FRAME_POSITION then
        self:Fail(
            "frame budget "
                .. tostring(KC.ATTRIBUTION_STACK_FRAMES)
                .. " is below the measured first non-self frame position "
                .. tostring(FIRST_NON_SELF_FRAME_POSITION)
        )
        return
    end
    -- The level is not the lever and is pinned so a blind tune of it is visible.
    if not eq(self, 2, KC.ATTRIBUTION_STACK_LEVEL, "stack level") then
        return
    end
    if not eq(self, "GRIP-EMS/Engine/KeybindConflict.lua", KC.ATTRIBUTION_SELF_FILE, "self-skip matches the FILE") then
        return
    end
    self:Pass()
end)

-- ===========================================================================
-- GROUP 11 -- owner is part of the dedup key
-- ===========================================================================
--
-- Phase 2-polish restored the dedup across a clear, and in doing so it revived
-- ANOTHER ADDON'S record. The dedup compared fn, target and isPriority and not
-- owner, so a cleared record belonging to one addon was resurrected by a different
-- addon's identical call and kept the first addon's attribution.
--
-- The owner-blindness is older than the resurrection: on the non-cleared path,
-- B's identical triple already bumped A's count. The resurrection only extended it
-- into the one path the cleared-record exclusion had accidentally kept correct.
-- That is why 3d exists alongside 3a: a fix applied inside the resurrection branch
-- passes 3a and leaves the older hole wide open.
--
-- The scenario is not exotic. Two addons overriding the same key onto the same
-- Blizzard button is the ORDINARY SHAPE of a keybind conflict, which is the exact
-- thing this module was built to report.

-- Fire one override bind through a captured hook. Named so the cases below read as
-- the scenario rather than as argument lists.
local function bindOverride(hook, owner, key, target, isPriority)
    hook(owner, isPriority, key, target)
end

TS:Register("KB attribution: a second addon's bind does not revive the first addon's record", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.InstallAttributionHooks or not KC.GetAttribution then
        self:Skip("KeybindConflict attribution recording not available")
        return
    end
    -- THE REGRESSION. Measured against the pre-fix code, this produced ONE record
    -- naming AddonA, carrying frameA, cleared false, reacquired 1 -- while AddonB
    -- was the addon actually holding the key.
    local fixture = fakeInstall(KC, { "SetOverrideBindingClick", "ClearOverrideBindings" })
    local hook = fixture.captured["SetOverrideBindingClick"]
    local clear = fixture.captured["ClearOverrideBindings"]
    if type(hook) ~= "function" or type(clear) ~= "function" then
        self:Fail("the record and clear hooks were not both captured")
        return
    end
    -- Distinct tables stand in for the two addons' owner frames; the recorder holds
    -- them by identity, which is exactly what the comparison now uses.
    local frameA, frameB = {}, {}
    bindOverride(hook, frameA, "1", "ActionButton1", true)
    clear(frameA)
    bindOverride(hook, frameB, "1", "ActionButton1", true)

    local records = KC.GetAttribution("1", fixture.deps)
    if not records then
        self:Fail("no records found for key 1")
        return
    end
    if not eq(self, 2, #records, "AddonB opened its own record instead of reviving AddonA's") then
        return
    end
    if not eq(self, frameB, records[1].owner, "the newest record is owned by the addon that holds the key") then
        return
    end
    if not eq(self, false, records[1].cleared, "and it is live") then
        return
    end
    if not eq(self, 0, records[1].reacquired, "a first bind by a new owner is not a reacquisition") then
        return
    end
    if not eq(self, frameA, records[2].owner, "the older record still belongs to the first addon") then
        return
    end
    if not eq(self, true, records[2].cleared, "and it is still marked released") then
        return
    end
    self:Pass()
end)

TS:Register("KB attribution: the releasing addon cannot clear a key another addon holds", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.InstallAttributionHooks or not KC.GetAttribution then
        self:Skip("KeybindConflict attribution recording not available")
        return
    end
    -- THE COMPOUNDING HALF. With the resurrected record still carrying frameA, a
    -- later ClearOverrideBindings(frameA) -- from the addon that no longer holds the
    -- key -- matched it and marked it released, so a live binding held by AddonB
    -- read as cleared. Both halves of the record were wrong at once.
    local fixture = fakeInstall(KC, { "SetOverrideBindingClick", "ClearOverrideBindings" })
    local hook = fixture.captured["SetOverrideBindingClick"]
    local clear = fixture.captured["ClearOverrideBindings"]
    if type(hook) ~= "function" or type(clear) ~= "function" then
        self:Fail("the record and clear hooks were not both captured")
        return
    end
    local frameA, frameB = {}, {}
    bindOverride(hook, frameA, "1", "ActionButton1", true)
    clear(frameA)
    bindOverride(hook, frameB, "1", "ActionButton1", true)
    -- AddonA tidies up again. It owns nothing on this key any more.
    clear(frameA)

    local records = KC.GetAttribution("1", fixture.deps)
    if not records or #records < 2 then
        self:Fail("expected both records to still be present")
        return
    end
    if not eq(self, frameB, records[1].owner, "the newest record is still AddonB's") then
        return
    end
    if not eq(self, false, records[1].cleared, "AddonB's live binding survives AddonA's clear") then
        return
    end
    if not eq(self, nil, records[1].clearedAt, "and carries no release timestamp") then
        return
    end
    if not eq(self, true, records[2].cleared, "AddonA's own record stays released") then
        return
    end
    self:Pass()
end)

TS:Register("KB attribution: fifty clear-rebind cycles by one owner cost one capture", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.InstallAttributionHooks or not KC.GetAttribution then
        self:Skip("KeybindConflict attribution recording not available")
        return
    end
    -- THE DEDUP MUST SURVIVE THE FIX. A paging addon reuses ONE owner frame across
    -- every cycle, so adding owner to the comparison must not reintroduce the cost
    -- Phase 2-polish removed. The debugstack calls are COUNTED rather than inferred:
    -- asserting the record shape alone would pass even if the capture ran fifty
    -- times, and the capture cost is the entire reason the dedup exists.
    local captures = { n = 0 }
    local fixture = fakeInstall(KC, { "SetOverrideBindingClick", "ClearOverrideBindings" })
    fixture.deps.debugstack = function()
        captures.n = captures.n + 1
        return "[C]: in function 'SetOverrideBindingClick'\n"
            .. "[Interface/AddOns/PagingAddon/Bars.lua]:12: in function 'Page'"
    end
    local hook = fixture.captured["SetOverrideBindingClick"]
    local clear = fixture.captured["ClearOverrideBindings"]
    if type(hook) ~= "function" or type(clear) ~= "function" then
        self:Fail("the record and clear hooks were not both captured")
        return
    end
    local owner = {}
    bindOverride(hook, owner, "2", "ActionButton2", true)
    for _ = 1, 49 do
        clear(owner)
        bindOverride(hook, owner, "2", "ActionButton2", true)
    end

    local records = KC.GetAttribution("2", fixture.deps)
    if not records then
        self:Fail("no records found for key 2")
        return
    end
    if not eq(self, 1, #records, "fifty cycles collapse to one record") then
        return
    end
    if not eq(self, 50, records[1].count, "count") then
        return
    end
    if not eq(self, 49, records[1].reacquired, "reacquired") then
        return
    end
    if not eq(self, false, records[1].cleared, "the key is live at the end") then
        return
    end
    if not eq(self, 1, captures.n, "debugstack was called exactly once across fifty cycles") then
        return
    end
    if not eq(self, "PagingAddon", records[1].addon, "and the one capture is the first caller's") then
        return
    end
    self:Pass()
end)

TS:Register("KB attribution: a different owner opens a record with no clear involved", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.InstallAttributionHooks or not KC.GetAttribution then
        self:Skip("KeybindConflict attribution recording not available")
        return
    end
    -- THE OLDER HALF OF THE BUG, and it needs its own case: the Phase 2 dedup was
    -- already owner-blind on the non-cleared path, so B's identical triple bumped
    -- A's count with no clear anywhere in the sequence. A fix that only guarded the
    -- resurrection branch passes the regression case above and fails this one.
    local fixture = fakeInstall(KC, { "SetOverrideBindingClick" })
    local hook = fixture.captured["SetOverrideBindingClick"]
    if type(hook) ~= "function" then
        self:Fail("the SetOverrideBindingClick hook was not captured")
        return
    end
    local frameA, frameB = {}, {}
    bindOverride(hook, frameA, "3", "ActionButton3", true)
    bindOverride(hook, frameB, "3", "ActionButton3", true)

    local records = KC.GetAttribution("3", fixture.deps)
    if not records then
        self:Fail("no records found for key 3")
        return
    end
    if not eq(self, 2, #records, "two owners, two records") then
        return
    end
    if not eq(self, frameB, records[1].owner, "newest is the second owner") then
        return
    end
    if not eq(self, 1, records[1].count, "and it is a first bind, not a bumped count") then
        return
    end
    if not eq(self, frameA, records[2].owner, "the first owner keeps its own record") then
        return
    end
    if not eq(self, 1, records[2].count, "which was never bumped by the second addon") then
        return
    end
    self:Pass()
end)

TS:Register("KB attribution: the base family still dedups with no owner at all", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.InstallAttributionHooks or not KC.GetAttribution then
        self:Skip("KeybindConflict attribution recording not available")
        return
    end
    -- SetBinding carries no owner, so owner is nil on BOTH sides and nil equals nil.
    -- This is the case that catches the obvious wrong fix: an owner comparison that
    -- treats a nil owner as a mismatch breaks every base-family dedup, and nothing
    -- else in the suite would notice.
    local fixture = fakeInstall(KC, { "SetBinding" })
    local hook = fixture.captured["SetBinding"]
    if type(hook) ~= "function" then
        self:Fail("the SetBinding hook was not captured")
        return
    end
    hook("4", "ACTIONBUTTON4")
    hook("4", "ACTIONBUTTON4")

    local records = KC.GetAttribution("4", fixture.deps)
    if not records then
        self:Fail("no records found for key 4")
        return
    end
    if not eq(self, 1, #records, "two identical base binds are one record") then
        return
    end
    if not eq(self, 2, records[1].count, "count") then
        return
    end
    if not eq(self, nil, records[1].owner, "the base family has no owner to compare") then
        return
    end
    if not eq(self, "base", records[1].layer, "layer") then
        return
    end
    self:Pass()
end)

TS:Register("KB attribution: a third-party file of the same name is not skipped as self", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.ParseCallerFromStack then
        self:Skip("KeybindConflict.ParseCallerFromStack not available")
        return
    end
    -- MEASURED against the bare-filename constant: this stack returned SomeOtherAddon
    -- / Main.lua / 7. The addon name survived while the file and line pointed at the
    -- wrong place INSIDE it, which is the worst shape of wrong because it looks
    -- specific enough to act on. The self-skip is now on the qualified path.
    local collision = table.concat({
        "[C]: in function 'SetOverrideBindingClick'",
        "[Interface/AddOns/GRIP-EMS/Engine/KeybindConflict.lua]:1223: in function <...>",
        "[C]: in function 'pcall'",
        "[Interface/AddOns/SomeOtherAddon/KeybindConflict.lua]:42: in function 'Bind'",
        "[Interface/AddOns/SomeOtherAddon/Main.lua]:7: in function 'OnLoad'",
    }, "\n")
    local addon, file, line, funcName = KC.ParseCallerFromStack(collision)
    if not eq(self, "SomeOtherAddon", addon, "addon") then
        return
    end
    if not eq(self, "KeybindConflict.lua", file, "its OWN KeybindConflict.lua is a legitimate caller") then
        return
    end
    if not eq(self, 42, line, "line (was 7, inside Main.lua, before the path qualification)") then
        return
    end
    if not eq(self, "Bind", funcName, "function name") then
        return
    end
    self:Pass()
end)

TS:Register("KB attribution: the self-skip survives backslash separators", CATEGORY, function(self)
    local KC = GRIPEMS.KeybindConflict
    if not KC or not KC.ParseCallerFromStack then
        self:Skip("KeybindConflict.ParseCallerFromStack not available")
        return
    end
    -- Qualifying the self-file path introduces a way to make the skip Windows-only
    -- by accident: a constant spelled with forward slashes stops matching a
    -- backslash-rendered frame, and the module would silently attribute to itself
    -- again on whichever rendering the client happens to use. The live capture from
    -- GROUP 10, respelled, must give the identical four values.
    local backslashed = string.gsub(LIVE_CAPTURE, "/", "\\")
    local addon, file, line, funcName = KC.ParseCallerFromStack(backslashed)
    if not eq(self, "Blizzard_ChatFrameBase", addon, "addon") then
        return
    end
    if not eq(self, "Shared/SlashCommands.lua", file, "file, separators normalised") then
        return
    end
    if not eq(self, 1178, line, "line") then
        return
    end
    if not eq(self, "?", funcName, "function name") then
        return
    end
    self:Pass()
end)
