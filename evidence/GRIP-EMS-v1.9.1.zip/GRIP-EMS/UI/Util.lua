-- GRIP-EMS: UI Utilities
-- Shared color constants, backdrop definitions, tooltip helpers, font helper, and button factory

local ADDON_NAME, GRIPEMS = ...

GRIPEMS.UI = GRIPEMS.UI or {}
local UI = GRIPEMS.UI

-- Upvalue accessor for Defaults
local function D()
    return GRIPEMS.Defaults
end

---------------------------------------------------------------------------
-- Color palette (dark theme -- see Phase3_UI_Design.md section 8)
---------------------------------------------------------------------------
UI.Colors = {
    bgDeep = CreateColor(0.051, 0.051, 0.102, 1), -- #0d0d1a
    bgMain = CreateColor(0.102, 0.102, 0.180, 1), -- #1a1a2e
    bgPanel = CreateColor(0.086, 0.129, 0.243, 1), -- #16213e
    bgInput = CreateColor(0.059, 0.090, 0.161, 1), -- #0f1729
    bgRowHover = CreateColor(0.059, 0.204, 0.376, 1), -- #0f3460
    bgRowSelected = CreateColor(0.325, 0.204, 0.514, 1), -- #533483
    bgButton = CreateColor(0.118, 0.176, 0.290, 1), -- #1e2d4a
    accent = CreateColor(0.914, 0.271, 0.376, 1), -- #e94560
    gripGreen = CreateColor(0.000, 0.800, 0.400, 1), -- #00cc66
    textPrimary = CreateColor(0.933, 0.933, 1.000, 1), -- #eeeeff
    textSecondary = CreateColor(0.533, 0.533, 0.667, 1), -- #8888aa
    textMuted = CreateColor(0.333, 0.333, 0.467, 1), -- #555577
    textWarning = CreateColor(1.000, 0.800, 0.000, 1), -- #ffcc00
    textError = CreateColor(1.000, 0.267, 0.267, 1), -- #ff4444
    textSuccess = CreateColor(0.000, 0.800, 0.400, 1), -- #00cc66
    keybindGold = CreateColor(1.000, 0.843, 0.000, 1), -- #ffd700
    bgSave = CreateColor(0.100, 0.280, 0.150, 1), -- #1a471a
    bgSaveHover = CreateColor(0.150, 0.380, 0.200, 1), -- #266133
    border = CreateColor(0.200, 0.200, 0.333, 1), -- #333355
    borderFocus = CreateColor(0.333, 0.333, 0.667, 1), -- #5555aa
}

---------------------------------------------------------------------------
-- Backdrop definitions (BackdropTemplate)
---------------------------------------------------------------------------
UI.Backdrops = {
    panel = {
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    },
    panelNoBorder = {
        bgFile = "Interface\\Buttons\\WHITE8x8",
    },
}

---------------------------------------------------------------------------
-- Tooltip helpers (GameTooltip wrappers)
---------------------------------------------------------------------------

--- Show a standard tooltip anchored to the given frame.
--- @param owner Frame The frame to anchor the tooltip to
--- @param title string Tooltip title (white text)
--- @param desc string|nil Optional description line (gray text)
--- @param hint string|nil Optional hint line (yellow text)
function UI:ShowTooltip(owner, title, desc, hint)
    if not owner or not title then
        return
    end
    GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")
    GameTooltip:SetText(title, 1, 1, 1)
    if desc then
        GameTooltip:AddLine(desc, 0.8, 0.8, 0.8, true)
    end
    if hint then
        GameTooltip:AddLine(hint, 1, 0.82, 0, true)
    end
    GameTooltip:Show()
    -- Screen-edge clamp: flip anchor if tooltip extends past right edge
    if GameTooltip:GetRight() and GameTooltip:GetRight() > UIParent:GetRight() then
        GameTooltip:ClearAllPoints()
        GameTooltip:SetPoint("TOPRIGHT", owner, "TOPLEFT", -2, 0)
    end
end

--- Hide the GameTooltip.
function UI:HideTooltip()
    GameTooltip:Hide()
end

---------------------------------------------------------------------------
-- Font helper
---------------------------------------------------------------------------

--- Set a FontString to the standard game font at the given size.
--- @param fontString FontString The FontString object to configure
--- @param size number Font size in points
--- @param flags string|nil Optional font flags ("OUTLINE", "THICKOUTLINE", etc.)
function UI:SetFont(fontString, size, flags)
    if not fontString then
        return
    end
    local fontPath = GameFontNormal:GetFont()
    fontString:SetFont(fontPath, size, flags or "")
end

---------------------------------------------------------------------------
-- Button factory
---------------------------------------------------------------------------

--- Create a themed button with dark-theme styling and tooltip support.
--- @param parent Frame Parent frame
--- @param text string Button label text
--- @param width number Button width
--- @param height number Button height
--- @return Button The created button frame
function UI:CreateButton(parent, text, width, height)
    local btn = CreateFrame("Button", nil, parent, "BackdropTemplate")
    btn:SetSize(width, height)
    local C = UI.Colors
    UI:ApplyBackdrop(btn, UI.Backdrops.panel, C.bgButton, C.border)

    -- Label
    local label = btn:CreateFontString(nil, "OVERLAY")
    UI:SetFont(label, 12)
    label:SetPoint("CENTER")
    label:SetText(text)
    label:SetTextColor(C.textPrimary:GetRGBA())
    btn.label = label

    -- Hover highlight
    btn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.bgRowHover:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
    end)
    btn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
    end)

    -- Click flash
    btn:SetScript("OnMouseDown", function(self)
        self:SetBackdropColor(C.accent:GetRGBA())
    end)
    btn:SetScript("OnMouseUp", function(self)
        self:SetBackdropColor(C.bgRowHover:GetRGBA())
    end)

    return btn
end

---------------------------------------------------------------------------
-- Backdrop application
---------------------------------------------------------------------------

--- Apply a backdrop definition with background and optional border color.
--- Colors must be ColorMixin objects (from UI.Colors).
--- @param frame Frame The frame to apply backdrop to
--- @param backdropDef table Backdrop definition (e.g. UI.Backdrops.panel)
--- @param bgColor table ColorMixin for SetBackdropColor
--- @param borderColor table|nil ColorMixin for SetBackdropBorderColor (omit for no-border backdrops)
function UI:ApplyBackdrop(frame, backdropDef, bgColor, borderColor)
    frame:SetBackdrop(backdropDef)
    frame:SetBackdropColor(bgColor:GetRGBA())
    if borderColor then
        frame:SetBackdropBorderColor(borderColor:GetRGBA())
    end
end

---------------------------------------------------------------------------
-- Icon resolution
---------------------------------------------------------------------------

--- Resolve an icon value to a WoW texture path.
--- Handles numeric IDs (pass through), string paths (prefix if needed), and nil.
--- @param icon any Icon value (number, string, or nil)
--- @return any Resolved texture path or ID
function UI:ResolveIcon(icon)
    if type(icon) == "number" then
        return icon
    end
    if type(icon) == "string" then
        if icon:find("^Interface\\") then
            return icon
        end
        if icon ~= "" then
            return "Interface\\Icons\\" .. icon
        end
    end
    return "Interface\\Icons\\" .. D().QUESTION_MARK_ICON
end

---------------------------------------------------------------------------
-- Scroll panel factory
---------------------------------------------------------------------------

--- Create a standard scroll panel with UIPanelScrollFrameTemplate.
--- Returns the ScrollFrame and its scrollChild. Caller must set anchoring
--- on the scrollFrame (too context-specific to generalize).
--- @param parent Frame Parent frame
--- @param childWidth number|nil Initial scrollChild width (default 300)
--- @return ScrollFrame scrollFrame
--- @return Frame scrollChild
function UI:CreateScrollPanel(parent, childWidth)
    local scrollFrame = CreateFrame("ScrollFrame", nil, parent, "UIPanelScrollFrameTemplate")
    local scrollChild = CreateFrame("Frame", nil, scrollFrame)
    scrollChild:SetWidth(childWidth or 300)
    scrollFrame:SetScrollChild(scrollChild)
    UI:SkinLegacyScrollBar(scrollFrame)
    return scrollFrame, scrollChild
end

---------------------------------------------------------------------------
-- Legacy scrollbar skinning
---------------------------------------------------------------------------

--- Skin a UIPanelScrollFrameTemplate scrollbar to match the dark theme.
--- Hides arrow buttons, narrows the bar, recolors thumb/track.
--- Defensive: silently no-ops if elements are missing.
--- @param scrollFrame ScrollFrame A UIPanelScrollFrameTemplate instance
function UI:SkinLegacyScrollBar(scrollFrame)
    if not scrollFrame then
        return
    end

    -- Locate scrollbar: named convention or anonymous child
    local sfName = scrollFrame.GetName and scrollFrame:GetName()
    local scrollBar = scrollFrame.ScrollBar or (sfName and _G[sfName .. "ScrollBar"])
    if not scrollBar then
        return
    end

    -- Narrow the bar
    pcall(scrollBar.SetWidth, scrollBar, 12)

    -- Hide arrow buttons (try all known patterns)
    local upBtn = scrollBar.ScrollUpButton or scrollBar.Back or (sfName and _G[sfName .. "ScrollBarScrollUpButton"])
    local downBtn = scrollBar.ScrollDownButton
        or scrollBar.Forward
        or (sfName and _G[sfName .. "ScrollBarScrollDownButton"])
    if upBtn then
        pcall(upBtn.SetAlpha, upBtn, 0)
        pcall(upBtn.SetSize, upBtn, 1, 1)
    end
    if downBtn then
        pcall(downBtn.SetAlpha, downBtn, 0)
        pcall(downBtn.SetSize, downBtn, 1, 1)
    end

    -- Reskin thumb
    local thumb = scrollBar.ThumbTexture or (sfName and _G[sfName .. "ScrollBarThumbTexture"])
    if thumb then
        pcall(thumb.SetColorTexture, thumb, 0.4, 0.4, 0.4, 0.6)
        pcall(thumb.SetSize, thumb, 8, 32)
    end

    -- Track background
    pcall(function()
        local track = scrollBar:CreateTexture(nil, "BACKGROUND")
        track:SetAllPoints()
        track:SetColorTexture(0.08, 0.08, 0.1, 0.8)
    end)
end

---------------------------------------------------------------------------
-- Frame reclamation (for /reload reuse)
---------------------------------------------------------------------------

--- Reclaim a named frame that survived /reload, or create a new one.
--- On /reload, named C++ frames persist and are re-mapped to _G.
--- This function reuses the surviving frame (clearing stale scripts
--- and orphaning old children) instead of creating a new one.
--- @param name string Global frame name
--- @param frameType string|nil Frame type (default "Frame")
--- @param parent Frame|nil Parent frame (default UIParent)
--- @param template string|nil Template name
--- @return Frame The reclaimed or newly created frame
function UI:ReclaimFrame(name, frameType, parent, template)
    local frame = _G[name]
    if frame then
        frame:SetParent(parent or UIParent)
        frame:ClearAllPoints()
        frame:UnregisterAllEvents()
        frame:SetScript("OnEvent", nil)
        frame:SetScript("OnUpdate", nil)
        frame:SetScript("OnShow", nil)
        frame:SetScript("OnHide", nil)
        if frame:HasScript("OnDragStart") then
            frame:SetScript("OnDragStart", nil)
        end
        if frame:HasScript("OnDragStop") then
            frame:SetScript("OnDragStop", nil)
        end
        if frame:HasScript("OnMouseDown") then
            frame:SetScript("OnMouseDown", nil)
        end
        if frame:HasScript("OnSizeChanged") then
            frame:SetScript("OnSizeChanged", nil)
        end
        if frame:HasScript("OnEnter") then
            frame:SetScript("OnEnter", nil)
        end
        if frame:HasScript("OnLeave") then
            frame:SetScript("OnLeave", nil)
        end
        if frame:HasScript("OnClick") then
            frame:SetScript("OnClick", nil)
        end
        if frame:HasScript("OnTextChanged") then
            frame:SetScript("OnTextChanged", nil)
        end
        for _, child in pairs({ frame:GetChildren() }) do
            child:Hide()
            child:ClearAllPoints()
            child:SetParent(nil)
        end
        for _, region in pairs({ frame:GetRegions() }) do
            region:Hide()
        end
        return frame
    end
    return CreateFrame(frameType or "Frame", name, parent or UIParent, template)
end
