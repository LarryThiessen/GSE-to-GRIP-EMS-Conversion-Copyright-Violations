-- GRIP-EMS: Headless test for opt-in macro-reference auto-refresh
--
-- Created:    2026-06-21
-- Updated:    2026-06-21
-- Patch: 12.0.7.68256 Midnight (Retail LIVE)
--
-- Standalone (Lua 5.1) test for Engine/MacroManager.lua's AutoRefreshAll /
-- _isAutoRefreshEligible / forEachMacroRef. EMS ships its in-game tests as
-- *_spec.lua files registered with GRIPEMS.TestSuite and run via /gems test;
-- there is no in-client-independent suite runner, so this drives the REAL
-- MacroManager module via loadfile + setfenv into a sandbox that stubs the
-- WoW macro API (GetMacroIndexByName, GetMacroInfo), CreateFrame, C_Timer,
-- LibStub, and a fake GRIPEMS.Engine. Keeping the stubs as fields on a local
-- env table (never global assignments) keeps the file luacheck-clean under the
-- read-only WoW std.
--
-- Run from the EMS root:  lua Test/test_macroref_autorefresh.lua
-- Exit code 0 = all passed, 1 = at least one failure.
--
-- Cases:
--   a  eligible node             -> body pulled, macroRefSynced updated, 1 recompile
--   b  imported node (synced=nil)-> left alone
--   c  in-editor-edited node     -> left alone (macro ~= macroRefSynced)
--   d  source macro missing      -> left alone
--   e  no drift (live == stored) -> left alone
--   f  macro-ref nested in a Loop AND in an If branch -> both reached
--   g  UPDATE_MACROS hook honors the macroRefAutoRefresh setting

local ADDON_NAME = "GRIP-EMS"

-- ---------------------------------------------------------------------------
-- Minimal assertion + runner harness (mirrors TestSuite Pass/Fail semantics).
-- ---------------------------------------------------------------------------

local tests = {}

local function test(name, fn)
    tests[#tests + 1] = { name = name, fn = fn }
end

local function assertEqual(expected, actual, label)
    if expected ~= actual then
        error((label or "value") .. ": expected " .. tostring(expected) .. ", got " .. tostring(actual), 2)
    end
end

local function assertTrue(cond, label)
    if not cond then
        error((label or "condition") .. " failed", 2)
    end
end

-- ---------------------------------------------------------------------------
-- Live /macro stub. name -> slot, slot -> { name, body }.
-- ---------------------------------------------------------------------------

local liveByName = {}
local liveBySlot = {}
local nextSlot = 0

local function clearLive()
    for k in pairs(liveByName) do
        liveByName[k] = nil
    end
    for k in pairs(liveBySlot) do
        liveBySlot[k] = nil
    end
    nextSlot = 0
end

local function setLiveMacro(name, body)
    nextSlot = nextSlot + 1
    liveByName[name] = nextSlot
    liveBySlot[nextSlot] = { name = name, body = body }
end

-- ---------------------------------------------------------------------------
-- Fake GRIPEMS namespace + sandbox environment.
-- ---------------------------------------------------------------------------

-- Stub constants. The exact ACTION_TYPE_IF string is irrelevant to the addon;
-- what matters is that the fixtures below use the SAME value the discriminator
-- compares against (node.type == D.ACTION_TYPE_IF).
local D = { ACTION_SUBTYPE_MACROREF = "macroref", ACTION_TYPE_IF = "If" }

local locale = setmetatable({
    GEMS_MACROREF_AUTOREFRESH_DEBUG = "Auto-refreshed macro-reference bodies in %d sequence(s)",
}, {
    __index = function(_, key)
        return key
    end,
})

local settingValue = false

local GRIPEMS = {
    Defaults = D,
    Debug = function() end,
    Settings = {
        Get = function(_, _)
            return settingValue
        end,
    },
}

local capturedOnEvent

local env = setmetatable({}, { __index = _G })
env._G = env
env.LibStub = function()
    return {
        GetLocale = function()
            return locale
        end,
    }
end
env.CreateFrame = function()
    local frame = {}
    frame.RegisterEvent = function() end
    frame.UnregisterAllEvents = function() end
    frame.SetScript = function(_, _, handler)
        capturedOnEvent = handler
    end
    return frame
end
env.C_Timer = {
    After = function(_, fn)
        fn()
    end,
}
env.GetMacroIndexByName = function(name)
    return liveByName[name] or 0
end
env.GetMacroInfo = function(slot)
    local entry = liveBySlot[slot]
    if not entry then
        return nil
    end
    return entry.name, 0, entry.body
end

-- ---------------------------------------------------------------------------
-- Load the REAL MacroManager module into the sandbox.
-- ---------------------------------------------------------------------------

local function loadMacroManager()
    local candidates = {
        "Engine/MacroManager.lua",
        "../Engine/MacroManager.lua",
        "GRIP/EMS/Engine/MacroManager.lua",
    }
    for _, path in ipairs(candidates) do
        -- loadfile is dev-harness file I/O, intentionally outside the addon WoW std.
        -- selene: allow(undefined_variable)
        local chunk = loadfile(path)
        if chunk then
            setfenv(chunk, env)
            return chunk
        end
    end
    error("could not locate Engine/MacroManager.lua (run from the EMS root)")
end

loadMacroManager()(ADDON_NAME, GRIPEMS)

local MM = GRIPEMS.MacroManager
assertTrue(MM ~= nil, "MacroManager loaded")
assertTrue(type(MM.AutoRefreshAll) == "function", "AutoRefreshAll defined")

-- ---------------------------------------------------------------------------
-- Fixtures.
-- ---------------------------------------------------------------------------

local function macroNode(macroName, macro, synced)
    return {
        type = "Action",
        subtype = D.ACTION_SUBTYPE_MACROREF,
        macroName = macroName,
        macro = macro,
        macroRefSynced = synced,
    }
end

-- Build a fake engine holding one sequence "Seq" with the given list of
-- per-version action arrays. Returns the engine plus a recompile-spy array.
local function engineWith(actionsByVersion)
    local recompiled = {}
    local versions = {}
    for i = 1, #actionsByVersion do
        versions[i] = { actions = actionsByVersion[i] }
    end
    local engine = {
        sequences = {
            Seq = { data = { versions = versions } },
        },
        RecompileSequence = function(_, name)
            recompiled[#recompiled + 1] = name
        end,
    }
    return engine, recompiled
end

-- ---------------------------------------------------------------------------
-- Cases.
-- ---------------------------------------------------------------------------

test("a: eligible node is refreshed and recompiled once", function()
    clearLive()
    setLiveMacro("MOONSPAM", "NEW BODY")
    local node = macroNode("MOONSPAM", "OLD BODY", "OLD BODY")
    local engine, recompiled = engineWith({ { node } })
    GRIPEMS.Engine = engine
    MM:AutoRefreshAll()
    assertEqual("NEW BODY", node.macro, "node.macro pulled to live body")
    assertEqual("NEW BODY", node.macroRefSynced, "macroRefSynced updated to new body")
    assertEqual(1, #recompiled, "exactly one recompile")
    assertEqual("Seq", recompiled[1], "recompiled the owning sequence")
end)

test("b: imported node (no macroRefSynced) is left alone", function()
    clearLive()
    setLiveMacro("MOONSPAM", "NEW BODY")
    local node = macroNode("MOONSPAM", "OLD BODY", nil)
    local engine, recompiled = engineWith({ { node } })
    GRIPEMS.Engine = engine
    MM:AutoRefreshAll()
    assertEqual("OLD BODY", node.macro, "imported macro body unchanged")
    assertTrue(node.macroRefSynced == nil, "macroRefSynced still nil")
    assertEqual(0, #recompiled, "no recompile")
end)

test("c: in-editor-edited node (macro ~= macroRefSynced) is left alone", function()
    clearLive()
    setLiveMacro("MOONSPAM", "NEW BODY")
    local node = macroNode("MOONSPAM", "EDITED BODY", "SYNCED BODY")
    local engine, recompiled = engineWith({ { node } })
    GRIPEMS.Engine = engine
    MM:AutoRefreshAll()
    assertEqual("EDITED BODY", node.macro, "edited macro body unchanged")
    assertEqual(0, #recompiled, "no recompile")
end)

test("d: missing source macro is left alone", function()
    clearLive()
    -- MOONSPAM intentionally not registered -> GetMacroIndexByName returns 0.
    local node = macroNode("MOONSPAM", "OLD BODY", "OLD BODY")
    local engine, recompiled = engineWith({ { node } })
    GRIPEMS.Engine = engine
    MM:AutoRefreshAll()
    assertEqual("OLD BODY", node.macro, "macro unchanged when source missing")
    assertEqual(0, #recompiled, "no recompile")
end)

test("e: no drift (live == stored) does nothing", function()
    clearLive()
    setLiveMacro("MOONSPAM", "SAME BODY")
    local node = macroNode("MOONSPAM", "SAME BODY", "SAME BODY")
    local engine, recompiled = engineWith({ { node } })
    GRIPEMS.Engine = engine
    MM:AutoRefreshAll()
    assertEqual("SAME BODY", node.macro, "macro unchanged with no drift")
    assertEqual(0, #recompiled, "no recompile")
end)

test("f: macro-ref nested in a Loop and in an If branch are both reached", function()
    clearLive()
    setLiveMacro("LOOPMAC", "LOOP NEW")
    setLiveMacro("IFMAC", "IF NEW")
    local loopNode = macroNode("LOOPMAC", "LOOP OLD", "LOOP OLD")
    local ifNode = macroNode("IFMAC", "IF OLD", "IF OLD")
    -- Loop children is a flat node array (children[1].type set); If children is
    -- { trueArray, falseArray } (children[1][1] truthy). forEachMacroRef must
    -- recurse into both shapes.
    local actions = {
        { type = "Loop", children = { loopNode } },
        { type = D.ACTION_TYPE_IF, children = { { ifNode }, {} } },
    }
    local engine, recompiled = engineWith({ actions })
    GRIPEMS.Engine = engine
    MM:AutoRefreshAll()
    assertEqual("LOOP NEW", loopNode.macro, "loop-nested macro-ref refreshed")
    assertEqual("IF NEW", ifNode.macro, "if-branch-nested macro-ref refreshed")
    assertEqual(1, #recompiled, "one recompile for the sequence")
end)

test("g: UPDATE_MACROS hook honors the macroRefAutoRefresh setting", function()
    assertTrue(type(capturedOnEvent) == "function", "OnEvent handler captured")

    -- Setting OFF: the hook returns before doing any work.
    clearLive()
    setLiveMacro("MOONSPAM", "NEW BODY")
    local nodeOff = macroNode("MOONSPAM", "OLD BODY", "OLD BODY")
    local engineOff, recompiledOff = engineWith({ { nodeOff } })
    GRIPEMS.Engine = engineOff
    settingValue = false
    MM._autoRefreshPending = false
    capturedOnEvent()
    assertEqual("OLD BODY", nodeOff.macro, "off: node untouched")
    assertEqual(0, #recompiledOff, "off: no recompile")

    -- Setting ON: the debounced refresh fires (the C_Timer stub runs inline).
    clearLive()
    setLiveMacro("MOONSPAM", "NEW BODY")
    local nodeOn = macroNode("MOONSPAM", "OLD BODY", "OLD BODY")
    local engineOn, recompiledOn = engineWith({ { nodeOn } })
    GRIPEMS.Engine = engineOn
    settingValue = true
    MM._autoRefreshPending = false
    capturedOnEvent()
    assertEqual("NEW BODY", nodeOn.macro, "on: node refreshed")
    assertEqual(1, #recompiledOn, "on: one recompile")
end)

test("h: else-only If (empty true, populated false branch) is reached", function()
    clearLive()
    setLiveMacro("ELSEMAC", "ELSE NEW")
    local elseNode = macroNode("ELSEMAC", "ELSE OLD", "ELSE OLD")
    -- Empty true branch, populated false branch. A structural children[1][1]
    -- heuristic misreads this as a flat Loop array and skips the false branch.
    local actions = {
        { type = D.ACTION_TYPE_IF, children = { {}, { elseNode } } },
    }
    local engine, recompiled = engineWith({ actions })
    GRIPEMS.Engine = engine
    MM:AutoRefreshAll()
    assertEqual("ELSE NEW", elseNode.macro, "false-branch macro-ref refreshed")
    assertEqual(1, #recompiled, "one recompile")
end)

test("i: macro-ref in an If false branch nested inside a Loop is reached", function()
    clearLive()
    setLiveMacro("DEEPMAC", "DEEP NEW")
    local deepNode = macroNode("DEEPMAC", "DEEP OLD", "DEEP OLD")
    local ifNode = { type = D.ACTION_TYPE_IF, children = { {}, { deepNode } } }
    local actions = {
        { type = "Loop", children = { ifNode } },
    }
    local engine, recompiled = engineWith({ actions })
    GRIPEMS.Engine = engine
    MM:AutoRefreshAll()
    assertEqual("DEEP NEW", deepNode.macro, "deeply-nested false-branch macro-ref refreshed")
    assertEqual(1, #recompiled, "one recompile")
end)

-- ---------------------------------------------------------------------------
-- Run.
-- ---------------------------------------------------------------------------

local passed = 0
local failed = 0
for _, t in ipairs(tests) do
    local ok, err = pcall(t.fn)
    if ok then
        passed = passed + 1
        print("PASS  " .. t.name)
    else
        failed = failed + 1
        print("FAIL  " .. t.name .. " -- " .. tostring(err))
    end
end
print(string.format("RESULT %d passed, %d failed", passed, failed))
os.exit(failed > 0 and 1 or 0)
