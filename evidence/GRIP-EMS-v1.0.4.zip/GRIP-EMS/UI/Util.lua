-- GRIP-EMS: UI Utilities
-- Shared color constants, backdrop definitions, tooltip helpers, font helper, and button factory

local ADDON_NAME, GRIPEMS = ...

GRIPEMS.UI = GRIPEMS.UI or {}
local UI = GRIPEMS.UI

---------------------------------------------------------------------------
-- Color palette (dark theme -- see Phase3_UI_Design.md section 8)
---------------------------------------------------------------------------
UI.Colors = {
    bgDeep        = CreateColor(0.051, 0.051, 0.102, 1),  -- #0d0d1a
    bgMain        = CreateColor(0.102, 0.102, 0.180, 1),  -- #1a1a2e
    bgPanel       = CreateColor(0.086, 0.129, 0.243, 1),  -- #16213e
    bgInput       = CreateColor(0.059, 0.090, 0.161, 1),  -- #0f1729
    bgRowHover    = CreateColor(0.059, 0.204, 0.376, 1),  -- #0f3460
    bgRowSelected = CreateColor(0.325, 0.204, 0.514, 1),  -- #533483
    bgButton      = CreateColor(0.118, 0.176, 0.290, 1),  -- #1e2d4a
    accent        = CreateColor(0.914, 0.271, 0.376, 1),  -- #e94560
    gripGreen     = CreateColor(0.000, 0.800, 0.400, 1),  -- #00cc66
    textPrimary   = CreateColor(0.933, 0.933, 1.000, 1),  -- #eeeeff
    textSecondary = CreateColor(0.533, 0.533, 0.667, 1),  -- #8888aa
    textMuted     = CreateColor(0.333, 0.333, 0.467, 1),  -- #555577
    textWarning   = CreateColor(1.000, 0.800, 0.000, 1),  -- #ffcc00
    textError     = CreateColor(1.000, 0.267, 0.267, 1),  -- #ff4444
    textSuccess   = CreateColor(0.000, 0.800, 0.400, 1),  -- #00cc66
    keybindGold   = CreateColor(1.000, 0.843, 0.000, 1),  -- #ffd700
    bgSave        = CreateColor(0.100, 0.280, 0.150, 1),  -- #1a471a
    bgSaveHover   = CreateColor(0.150, 0.380, 0.200, 1),  -- #266133
    border        = CreateColor(0.200, 0.200, 0.333, 1),  -- #333355
    borderFocus   = CreateColor(0.333, 0.333, 0.667, 1),  -- #5555aa
}

---------------------------------------------------------------------------
-- Backdrop definitions (BackdropTemplate)
---------------------------------------------------------------------------
UI.Backdrops = {
    panel = {
        bgFile   = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    },
    panelNoBorder = {
        bgFile = "Interface\\Buttons\\WHITE8x8",
    },
}

---------------------------------------------------------------------------
-- Tooltip helpers (GameTooltip wrappers)
---------------------------------------------------------------------------

--- Show a standard tooltip anchored to the given frame.
--- @param owner Frame The frame to anchor the tooltip to
--- @param title string Tooltip title (white text)
--- @param desc string|nil Optional description line (gray text)
--- @param hint string|nil Optional hint line (yellow text)
function UI:ShowTooltip(owner, title, desc, hint)
    if not owner or not title then return end
    GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")
    GameTooltip:SetText(title, 1, 1, 1)
    if desc then
        GameTooltip:AddLine(desc, 0.8, 0.8, 0.8, true)
    end
    if hint then
        GameTooltip:AddLine(hint, 1, 0.82, 0, true)
    end
    GameTooltip:Show()
end

--- Hide the GameTooltip.
function UI:HideTooltip()
    GameTooltip:Hide()
end

---------------------------------------------------------------------------
-- Font helper
---------------------------------------------------------------------------

--- Set a FontString to the standard game font at the given size.
--- @param fontString FontString The FontString object to configure
--- @param size number Font size in points
--- @param flags string|nil Optional font flags ("OUTLINE", "THICKOUTLINE", etc.)
function UI:SetFont(fontString, size, flags)
    if not fontString then return end
    local fontPath = GameFontNormal:GetFont()
    fontString:SetFont(fontPath, size, flags or "")
end

---------------------------------------------------------------------------
-- Button factory
---------------------------------------------------------------------------

--- Create a themed button with dark-theme styling and tooltip support.
--- @param parent Frame Parent frame
--- @param text string Button label text
--- @param width number Button width
--- @param height number Button height
--- @return Button The created button frame
function UI:CreateButton(parent, text, width, height)
    local btn = CreateFrame("Button", nil, parent, "BackdropTemplate")
    btn:SetSize(width, height)
    btn:SetBackdrop(UI.Backdrops.panel)

    local C = UI.Colors
    btn:SetBackdropColor(C.bgButton:GetRGBA())
    btn:SetBackdropBorderColor(C.border:GetRGBA())

    -- Label
    local label = btn:CreateFontString(nil, "OVERLAY")
    UI:SetFont(label, 12)
    label:SetPoint("CENTER")
    label:SetText(text)
    label:SetTextColor(C.textPrimary:GetRGBA())
    btn.label = label

    -- Hover highlight
    btn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.bgRowHover:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
    end)
    btn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
    end)

    -- Click flash
    btn:SetScript("OnMouseDown", function(self)
        self:SetBackdropColor(C.accent:GetRGBA())
    end)
    btn:SetScript("OnMouseUp", function(self)
        self:SetBackdropColor(C.bgRowHover:GetRGBA())
    end)

    return btn
end
