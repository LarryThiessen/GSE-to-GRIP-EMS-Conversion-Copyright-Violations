-- GRIP-EMS: SyntaxHighlight
-- Created: 2026-04-03
-- Updated: 2026-06-21
-- Patch: 12.0.7.68256 Midnight (Retail LIVE)

-- GRIP-EMS: Syntax Highlighting
-- Token-based colour coding for macro text and Lua source in editBoxes and FontStrings

local ADDON_NAME, GRIPEMS = ...
local S -- Settings reference, set on init

GRIPEMS.SyntaxHighlight = {}
local SH = GRIPEMS.SyntaxHighlight

---------------------------------------------------------------------------
-- Colour table (hex strings, populated from Settings on init)
---------------------------------------------------------------------------
SH.colors = {
    COMMAND = "4EC9B0",
    CONDITIONAL = "C586C0",
    VARIABLE = "DCDCAA",
    COMMENT = "6A9955",
    RESET = "CE9178",
    NUMBER = "B5CEA8",
}

-- Setting key -> token type mapping
local SETTING_MAP = {
    syntaxCommandColor = "COMMAND",
    syntaxConditionalColor = "CONDITIONAL",
    syntaxVariableColor = "VARIABLE",
    syntaxCommentColor = "COMMENT",
    syntaxResetColor = "RESET",
    syntaxNumberColor = "NUMBER",
}

--- Convert an {r, g, b} table (0-1 range) to a 6-char hex string.
--- @param key string Setting key name
--- @return string hex 6-character hex colour string
function SH:HexFromSetting(key)
    local c = S:Get(key)
    if not c or type(c) ~= "table" then
        return "FFFFFF"
    end
    local r = math.floor((c[1] or 1) * 255 + 0.5)
    local g = math.floor((c[2] or 1) * 255 + 0.5)
    local b = math.floor((c[3] or 1) * 255 + 0.5)
    return string.format("%02X%02X%02X", r, g, b)
end

--- Refresh all colour hex values from Settings.
local function RefreshColors()
    for settingKey, tokenType in pairs(SETTING_MAP) do
        SH.colors[tokenType] = SH:HexFromSetting(settingKey)
    end
end

---------------------------------------------------------------------------
-- Macro text tokenizer
---------------------------------------------------------------------------

--- Tokenize macro text into typed spans.
--- @param text string Macro text (may be multi-line)
--- @return table Array of {type, startPos, endPos}
function SH:TokenizeMacro(text)
    if not text or text == "" then
        return {}
    end

    local spans = {}
    -- Track which character positions are already claimed
    local claimed = {}

    local function claim(spanType, s, e)
        for i = s, e do
            if claimed[i] then
                return false
            end
        end
        for i = s, e do
            claimed[i] = true
        end
        spans[#spans + 1] = { type = spanType, startPos = s, endPos = e }
        return true
    end

    -- Process line by line
    local lineStart = 1
    for line in text:gmatch("([^\n]*)\n?") do
        if line == "" and lineStart > #text then
            break
        end
        local lineEnd = lineStart + #line - 1
        local commentFound = false

        -- Check for comment lines (optional leading whitespace then --)
        local wsEnd = line:find("%S")
        if wsEnd then
            local trimmed = line:sub(wsEnd)
            if trimmed:sub(1, 2) == "--" then
                claim("COMMENT", lineStart + wsEnd - 1, lineEnd)
                commentFound = true
            end
        end

        if not commentFound then
            -- Check for reset= at line start
            local rs, re = line:find("^reset=[%w/]+")
            if rs then
                claim("RESET", lineStart + rs - 1, lineStart + re - 1)
            end

            -- Scan remaining text left-to-right for tokens
            local pos = 1
            while pos <= #line do
                local globalPos = lineStart + pos - 1
                if claimed[globalPos] then
                    pos = pos + 1
                elseif line:sub(pos, pos) == "/" then
                    -- Slash command: /word
                    local ms, me = line:find("^/[%a]+", pos)
                    if ms then
                        claim("COMMAND", lineStart + ms - 1, lineStart + me - 1)
                        pos = me + 1
                    else
                        pos = pos + 1
                    end
                elseif line:sub(pos, pos) == "[" then
                    -- Conditional: [...]  (non-greedy, handle nested brackets)
                    local depth = 0
                    local cEnd = nil
                    for ci = pos, #line do
                        local ch = line:sub(ci, ci)
                        if ch == "[" then
                            depth = depth + 1
                        elseif ch == "]" then
                            depth = depth - 1
                            if depth == 0 then
                                cEnd = ci
                                break
                            end
                        end
                    end
                    if cEnd then
                        claim("CONDITIONAL", lineStart + pos - 1, lineStart + cEnd - 1)
                        pos = cEnd + 1
                    else
                        pos = pos + 1
                    end
                elseif line:sub(pos, pos) == "~" then
                    -- Variable: ~word~
                    local ms, me = line:find("^~[%w_]+~", pos)
                    if ms then
                        claim("VARIABLE", lineStart + ms - 1, lineStart + me - 1)
                        pos = me + 1
                    else
                        pos = pos + 1
                    end
                elseif line:sub(pos, pos):find("%d") then
                    -- Number: digit sequence (standalone)
                    local ms, me = line:find("^%d+", pos)
                    if ms then
                        -- Check char before is not alphanumeric/underscore
                        local before = pos > 1 and line:sub(pos - 1, pos - 1) or ""
                        if before == "" or not before:find("[%w_]") then
                            -- Check char after is not alphanumeric/underscore
                            local after = me < #line and line:sub(me + 1, me + 1) or ""
                            if after == "" or not after:find("[%w_]") then
                                claim("NUMBER", lineStart + ms - 1, lineStart + me - 1)
                            end
                        end
                        pos = me + 1
                    else
                        pos = pos + 1
                    end
                else
                    pos = pos + 1
                end
            end
        end

        lineStart = lineEnd + 2 -- skip past \n
    end

    -- Sort spans by startPos for consistent output
    table.sort(spans, function(a, b)
        return a.startPos < b.startPos
    end)

    return spans
end

---------------------------------------------------------------------------
-- Lua text tokenizer (simplified, for RawTab)
---------------------------------------------------------------------------

local LUA_KEYWORDS = {
    ["local"] = true,
    ["function"] = true,
    ["return"] = true,
    ["if"] = true,
    ["then"] = true,
    ["else"] = true,
    ["elseif"] = true,
    ["end"] = true,
    ["for"] = true,
    ["do"] = true,
    ["while"] = true,
    ["repeat"] = true,
    ["until"] = true,
    ["in"] = true,
    ["not"] = true,
    ["and"] = true,
    ["or"] = true,
    ["true"] = true,
    ["false"] = true,
    ["nil"] = true,
}

--- Tokenize Lua source text into typed spans.
--- @param text string Lua source (may be multi-line)
--- @return table Array of {type, startPos, endPos}
function SH:TokenizeLua(text)
    if not text or text == "" then
        return {}
    end

    local spans = {}
    local claimed = {}

    local function claim(spanType, s, e)
        for i = s, e do
            if claimed[i] then
                return false
            end
        end
        for i = s, e do
            claimed[i] = true
        end
        spans[#spans + 1] = { type = spanType, startPos = s, endPos = e }
        return true
    end

    local lineStart = 1
    for line in text:gmatch("([^\n]*)\n?") do
        if line == "" and lineStart > #text then
            break
        end
        local lineEnd = lineStart + #line - 1

        -- Check for -- comment
        local commentPos = nil
        local inStr = false
        local strChar = nil
        local skipNext = false
        for ci = 1, #line do
            if skipNext then
                skipNext = false
            elseif inStr then
                if line:sub(ci, ci) == "\\" then
                    skipNext = true
                elseif line:sub(ci, ci) == strChar then
                    inStr = false
                end
            else
                local ch = line:sub(ci, ci)
                if ch == '"' or ch == "'" then
                    inStr = true
                    strChar = ch
                elseif ch == "-" and ci < #line and line:sub(ci + 1, ci + 1) == "-" then
                    commentPos = ci
                    break
                end
            end
        end

        if commentPos then
            claim("COMMENT", lineStart + commentPos - 1, lineEnd)
        end

        -- Scan for strings, keywords, numbers
        local pos = 1
        local scanEnd = commentPos and (commentPos - 1) or #line
        while pos <= scanEnd do
            local globalPos = lineStart + pos - 1
            if claimed[globalPos] then
                pos = pos + 1
            else
                local ch = line:sub(pos, pos)
                -- String literals
                if ch == '"' or ch == "'" then
                    local strEnd = nil
                    local skipEsc = false
                    for si = pos + 1, scanEnd do
                        if skipEsc then
                            skipEsc = false
                        elseif line:sub(si, si) == "\\" then
                            skipEsc = true
                        elseif line:sub(si, si) == ch then
                            strEnd = si
                            break
                        end
                    end
                    if strEnd then
                        claim("VARIABLE", lineStart + pos - 1, lineStart + strEnd - 1)
                        pos = strEnd + 1
                    else
                        pos = pos + 1
                    end
                elseif ch:find("[%a_]") then
                    -- Identifier or keyword
                    local ms, me = line:find("^[%a_][%w_]*", pos)
                    if ms then
                        local word = line:sub(ms, me)
                        if LUA_KEYWORDS[word] then
                            claim("COMMAND", lineStart + ms - 1, lineStart + me - 1)
                        end
                        pos = me + 1
                    else
                        pos = pos + 1
                    end
                elseif ch:find("%d") then
                    -- Number (including decimals)
                    local ms, me = line:find("^%d+%.?%d*", pos)
                    if ms then
                        claim("NUMBER", lineStart + ms - 1, lineStart + me - 1)
                        pos = me + 1
                    else
                        pos = pos + 1
                    end
                else
                    pos = pos + 1
                end
            end
        end

        lineStart = lineEnd + 2
    end

    table.sort(spans, function(a, b)
        return a.startPos < b.startPos
    end)

    return spans
end

---------------------------------------------------------------------------
-- Colorize and Strip
---------------------------------------------------------------------------

--- Colorize text using the specified tokenizer.
--- @param text string Input text
--- @param tokenizer string "macro" (default) or "lua"
--- @return string Coloured text with WoW escape codes
function SH:Colorize(text, tokenizer)
    if not text or text == "" then
        return text or ""
    end

    local spans
    if tokenizer == "lua" then
        spans = self:TokenizeLua(text)
    else
        spans = self:TokenizeMacro(text)
    end

    if #spans == 0 then
        return text
    end

    local parts = {}
    local lastEnd = 0

    for _, span in ipairs(spans) do
        -- Add uncoloured text before this span
        if span.startPos > lastEnd + 1 then
            parts[#parts + 1] = text:sub(lastEnd + 1, span.startPos - 1)
        end

        -- Add coloured span
        local hex = self.colors[span.type] or "FFFFFF"
        local spanText = text:sub(span.startPos, span.endPos)
        parts[#parts + 1] = "|cff" .. hex .. spanText .. "|r"

        lastEnd = span.endPos
    end

    -- Add remaining text after last span
    if lastEnd < #text then
        parts[#parts + 1] = text:sub(lastEnd + 1)
    end

    return table.concat(parts)
end

--- Strip all WoW colour escape codes from text.
--- @param text string Text potentially containing colour codes
--- @return string Clean text without colour codes
function SH:Strip(text)
    if not text then
        return ""
    end
    local result = text:gsub("|cff%x%x%x%x%x%x", "")
    result = result:gsub("|r", "")
    return result
end

---------------------------------------------------------------------------
-- EditBox hook function
---------------------------------------------------------------------------

--- Hook an editBox for syntax highlighting on focus gain/loss.
--- Uses HookScript to chain with existing scripts.
--- @param editBox EditBox The editBox frame to hook
--- @param tokenizer string "macro" (default) or "lua"
function SH:HookEditBox(editBox, tokenizer)
    tokenizer = tokenizer or "macro"
    editBox._shBusy = false

    editBox:HookScript("OnEditFocusGained", function(self)
        if self._shBusy then
            return
        end
        -- Strip colour codes so user edits plain text
        local text = self:GetText()
        local clean = SH:Strip(text)
        if clean ~= text then
            self._shBusy = true
            self:SetText(clean)
            self._shBusy = false
        end
    end)

    editBox:HookScript("OnEditFocusLost", function(self)
        if self._shBusy then
            return
        end
        -- Colorize on focus loss
        local text = self:GetText()
        local coloured = SH:Colorize(text, tokenizer)
        if coloured ~= text then
            self._shBusy = true
            self:SetText(coloured)
            self._shBusy = false
        end
    end)

    editBox:HookScript("OnTextChanged", function(self, userInput)
        -- Only colorize programmatic SetText when editBox does not have focus
        if not userInput and not self:HasFocus() then
            if self._shBusy then
                return
            end
            self._shBusy = true
            local text = self:GetText()
            local coloured = SH:Colorize(text, tokenizer)
            if coloured ~= text then
                self:SetText(coloured)
            end
            self._shBusy = false
        end
    end)
end

---------------------------------------------------------------------------
-- FontString helper
---------------------------------------------------------------------------

--- Colorize text for display-only FontStrings (macro tokenizer).
--- @param text string Input text
--- @return string Coloured text
function SH:ColorizeString(text)
    return self:Colorize(text, "macro")
end

---------------------------------------------------------------------------
-- Initialization
---------------------------------------------------------------------------

--- Initialize the syntax highlighting module.
--- Reads colour settings and registers for SETTING_CHANGED updates.
function SH:Initialize()
    S = GRIPEMS.Settings
    RefreshColors()

    -- Listen for colour setting changes
    if GRIPEMS.RegisterCallback then
        GRIPEMS:RegisterCallback("SETTING_CHANGED", function(_, key)
            if SETTING_MAP[key] then
                SH.colors[SETTING_MAP[key]] = SH:HexFromSetting(key)
            end
        end, "SyntaxHighlight_SettingChanged")
    end
end
