-- GRIP-EMS: PetBattleButtons
-- Created: 2026-04-03
-- Updated: 2026-08-17
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)

-- GRIP-EMS: Pet Battle Buttons
-- 6 keybindable pet battle action buttons.
-- Slots 1-3 = abilities, 4 = swap pet, 5 = pass turn, 6 = forfeit.
-- Activated on PET_BATTLE_OPENING_DONE (not _START -- player cannot act
-- during transition). Deactivated on PET_BATTLE_CLOSE.
-- Data model: GRIP_EMS_CHAR.petBattleKeybinds = { [key] = slotIndex }

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)
local D = GRIPEMS.Defaults

GRIPEMS.PetBattleButtons = {}
local PB = GRIPEMS.PetBattleButtons

-- Runtime state
PB.active = false
PB.buttons = {}

-- Owner frame for pet battle override bindings
local petBattleOwner = _G["GRIPEMS_PetBattleOwner"] or CreateFrame("Frame", "GRIPEMS_PetBattleOwner", UIParent)
petBattleOwner:UnregisterAllEvents()
petBattleOwner:Hide()

--- Find the next alive pet that is not the active one.
--- Iterates ally pets 1-3 looking for the first alive non-active pet.
--- @return number|nil Pet index (1-3), or nil if no swap target found
function PB:FindNextAlivePet()
    local activePet = C_PetBattles.GetActivePet(Enum.BattlePetOwner.Ally)
    local numPets = C_PetBattles.GetNumPets(Enum.BattlePetOwner.Ally) or 3
    for i = 1, numPets do
        if i ~= activePet then
            local health = C_PetBattles.GetHealth(Enum.BattlePetOwner.Ally, i)
            if health and health > 0 then
                return i
            end
        end
    end
    return nil
end

--- Create 6 hidden SecureActionButtons for pet battle actions.
--- Each button exists only as a click target for SetOverrideBindingClick.
--- PostClick handlers call the appropriate C_PetBattles function.
function PB:CreateButtons()
    if PB.buttons[1] then
        return
    end

    for slot = 1, D.PET_BATTLE_SLOTS do
        local btnName = "GRIPEMS_PetBattle" .. slot
        local btn = CreateFrame("Button", btnName, UIParent, "SecureActionButtonTemplate")
        btn:SetSize(1, 1)
        btn:Hide()
        btn:SetAttribute("type", "click")

        btn:SetScript("PostClick", function()
            if slot <= 3 then
                C_PetBattles.UseAbility(slot)
            elseif slot == 4 then
                -- Swap to next alive pet (v1 simplified: cycle)
                local nextPet = PB:FindNextAlivePet()
                if nextPet then
                    C_PetBattles.ChangePet(nextPet)
                end
            elseif slot == 5 then
                C_PetBattles.SkipTurn()
            elseif slot == 6 then
                C_PetBattles.ForfeitGame()
            end
        end)

        PB.buttons[slot] = btn
    end
end

--- Activate pet battle keybinds. Called on PET_BATTLE_OPENING_DONE.
--- Creates buttons if needed, then applies override bindings.
function PB:Activate()
    if GRIPEMS.OOCQueue.IsRestricted() then
        GRIPEMS.OOCQueue:Add(function()
            PB:Activate()
        end, D.OOC_OP_GENERIC)
        return
    end

    PB:CreateButtons()

    if not _G.GRIP_EMS_CHAR or not GRIP_EMS_CHAR.petBattleKeybinds then
        return
    end

    -- Clear any existing pet battle bindings first
    ClearOverrideBindings(petBattleOwner)

    -- INVESTIGATION B, 2026-08-11: IS THE SEQUENCE-KEYBIND SUSPEND GUARANTEED TO
    -- LAND BEFORE THIS BINDS? NO. Reliable on the normal path, not guaranteed.
    --
    -- WHAT WORKS. Engine/KeybindManager.lua registers an attribute driver whose
    -- conditional carries "[petbattle] petbattle" (line 117), and its
    -- _onattributechanged snippet calls self:ClearBindings() unconditionally and
    -- only re-binds when the state is "none" (or skyride with autodismount on)
    -- -- lines 89 to 101. So entering a pet battle drops the sequence bindings.
    -- The ordering is comfortable too: that conditional flips at pet battle
    -- start, while PB:Activate runs on PET_BATTLE_OPENING_DONE, one transition
    -- later, and defers further still through OOCQueue when restricted (the
    -- guard at the top of this function). On the normal path the two never
    -- coexist.
    --
    -- WHERE THE GUARANTEE FAILS, and it is the same class of miss the skyride
    -- watchdog exists to paper over:
    --   1. A MISSED ENTER has no heal path for pet battles. KM:HealStuckSuspend
    --      only reaches its "enterheal" verdict when glidingActive is true
    --      (KM._SuspendWatchdogVerdict, the "not suspended and glidingActive"
    --      branch). A pet battle is not gliding, so if the driver ever misses the
    --      petbattle dispatch, emsstate stays "none" and NOTHING corrects it.
    --   2. The re-apply path keys off that same attribute. pushSecureMatrix runs
    --      a snippet that reads emsstate and re-binds the whole matrix when it
    --      reads "none". A LoadKeybinds triggered mid-battle (spec change,
    --      sequence edit, OOC queue flush) against a stale "none" therefore
    --      re-applies sequence bindings on top of these.
    --
    -- WHY THAT MATTERS FOR THE PRIORITY FLAG. Both binders are non-priority
    -- today, so the stale-state case above degenerates to last-writer-wins and
    -- self-corrects on the next clean transition. Flipping the six KeybindManager
    -- sites to priority = true would make the sequence bindings beat these
    -- REGARDLESS of write order, turning a recoverable race into a deterministic
    -- dead pet battle key for as long as the state stays stale. Under that flip
    -- this call would have to go to priority = true as well. It is deliberately
    -- LEFT AT false, because the flip did not happen: Investigation A found that
    -- TempoAdvisor hold mode binds the same key as a sequence keybind by
    -- construction and already relies on priority to win, so the sequence-path
    -- flip is parked for a decision. Raising this site alone would only invert
    -- the pet-battle-versus-sequence relationship for no benefit.
    local count = 0
    for key, slotIndex in pairs(GRIP_EMS_CHAR.petBattleKeybinds) do
        local btn = PB.buttons[slotIndex]
        if btn then
            SetOverrideBindingClick(petBattleOwner, false, key, btn:GetName(), "LeftButton")
            count = count + 1
        end
    end

    PB.active = true
    GRIPEMS:Debug(string.format(L["GEMS_PET_BATTLE_KEYBINDS_APPLIED"], count))
end

--- Deactivate pet battle keybinds. Called on PET_BATTLE_CLOSE.
function PB:Deactivate()
    if GRIPEMS.OOCQueue.IsRestricted() then
        GRIPEMS.OOCQueue:Add(function()
            PB:Deactivate()
        end, D.OOC_OP_GENERIC)
        return
    end

    ClearOverrideBindings(petBattleOwner)
    PB.active = false
    GRIPEMS:Debug(L["GEMS_PET_BATTLE_KEYBINDS_CLEARED"])
end

--- Set a keybind for a pet battle slot.
--- @param slotIndex number Slot index 1..6
--- @param key string WoW key string
function PB:SetKeybind(slotIndex, key)
    if type(slotIndex) ~= "number" or slotIndex < 1 or slotIndex > D.PET_BATTLE_SLOTS then
        return
    end
    if type(key) ~= "string" or key == "" then
        return
    end
    if not _G.GRIP_EMS_CHAR then
        return
    end

    GRIP_EMS_CHAR.petBattleKeybinds = GRIP_EMS_CHAR.petBattleKeybinds or {}
    local binds = GRIP_EMS_CHAR.petBattleKeybinds

    -- Clear any existing key for this slot
    for existingKey, existingSlot in pairs(binds) do
        if existingSlot == slotIndex then
            binds[existingKey] = nil
            break
        end
    end

    -- Clear any existing slot for this key
    if binds[key] then
        binds[key] = nil
    end

    -- Store the new binding
    binds[key] = slotIndex

    -- If currently in pet battle, reapply
    if PB.active and not GRIPEMS.OOCQueue.IsRestricted() then
        PB:Activate()
    end

    if GRIPEMS.Fire then
        GRIPEMS:Fire("PET_BATTLE_KEYBIND_CHANGED", slotIndex, key)
    end
end

--- Clear the keybind for a pet battle slot.
--- @param slotIndex number Slot index 1..6
function PB:ClearKeybind(slotIndex)
    if type(slotIndex) ~= "number" or slotIndex < 1 or slotIndex > D.PET_BATTLE_SLOTS then
        return
    end
    if not _G.GRIP_EMS_CHAR or not GRIP_EMS_CHAR.petBattleKeybinds then
        return
    end

    local binds = GRIP_EMS_CHAR.petBattleKeybinds
    local foundKey = nil
    for key, slot in pairs(binds) do
        if slot == slotIndex then
            foundKey = key
            break
        end
    end

    if not foundKey then
        return
    end

    binds[foundKey] = nil

    -- If in pet battle, clear that specific override binding
    if PB.active and not GRIPEMS.OOCQueue.IsRestricted() then
        SetOverrideBinding(petBattleOwner, false, foundKey)
    end

    if GRIPEMS.Fire then
        GRIPEMS:Fire("PET_BATTLE_KEYBIND_CHANGED", slotIndex, nil)
    end
end

--- Get the key string bound to a pet battle slot.
--- @param slotIndex number Slot index 1..6
--- @return string|nil The key string, or nil if no binding exists
function PB:GetKeybind(slotIndex)
    if not _G.GRIP_EMS_CHAR or not GRIP_EMS_CHAR.petBattleKeybinds then
        return nil
    end
    for key, slot in pairs(GRIP_EMS_CHAR.petBattleKeybinds) do
        if slot == slotIndex then
            return key
        end
    end
    return nil
end

--- Return a shallow copy of the pet battle keybinds table.
--- @return table copy { [key] = slotIndex }
function PB:GetAllKeybinds()
    if not _G.GRIP_EMS_CHAR or not GRIP_EMS_CHAR.petBattleKeybinds then
        return {}
    end
    local copy = {}
    for key, slot in pairs(GRIP_EMS_CHAR.petBattleKeybinds) do
        copy[key] = slot
    end
    return copy
end

--- Return true if pet battle keybinds are currently applied.
--- @return boolean
function PB:IsActive()
    return PB.active
end
