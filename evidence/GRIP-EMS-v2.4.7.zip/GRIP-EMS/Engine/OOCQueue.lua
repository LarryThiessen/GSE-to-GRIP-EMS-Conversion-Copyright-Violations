-- GRIP-EMS: OOCQueue
-- Created: 2026-03-18
-- Updated: 2026-08-17
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)

-- GRIP-EMS: Out-of-Combat Queue
-- Defers protected API calls (CreateMacro, SetAttribute, etc.) until combat ends.
-- Priority-ordered with deduplication: newer requests replace older ones for
-- the same (opType, seqName) pair. Lower priority number = processed first.

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)
local D = GRIPEMS.Defaults

GRIPEMS.OOCQueue = {
    queue = {},
    insertOrder = 0,
}
local OOCQueue = GRIPEMS.OOCQueue

-- Cache C_RestrictedActions API existence at file load (not per-call)
local hasRestrictedAPI = (C_RestrictedActions and C_RestrictedActions.IsAddOnRestrictionActive) and true or false

local RESTRICTION_NAMES = {
    [0] = "Combat",
    [1] = "Encounter",
    [2] = "ChallengeMode",
    [3] = "PvPMatch",
    [4] = "Map",
    [5] = "Chat",
}
local STATE_NAMES = { [0] = "Inactive", [1] = "Activating", [2] = "Active" }

--- Check if protected actions are currently restricted.
--- Returns true only during combat lockdown. WoW gates protected operations
--- (macro CRUD, secure-button attributes, WrapScript, override bindings) on
--- InCombatLockdown() alone. The Enum.AddOnRestrictionType states
--- (Encounter/ChallengeMode/PvPMatch) are secret-value privacy contexts:
--- they tag unit-data reads, they do not block protected setup out of
--- combat. Gating this predicate on those states starved the queue for the
--- entire match after a /reload inside arena or keyed Mythic+ (no
--- PLAYER_REGEN_ENABLED, restriction lift only at match end, ticker gated
--- on this same predicate), leaving every sequence dormant until the match
--- ended. Repro 2026-06-07 on 2.1.16; see Backlog ARENA-RELOAD-ISSUE.
--- @return boolean restricted
local function IsRestricted()
    return InCombatLockdown()
end
--- Check if protected actions are currently restricted (method form).
--- Wraps the local IsRestricted() so external callers can use OOCQueue:IsRestricted().
--- @return boolean restricted
function OOCQueue:IsRestricted()
    return IsRestricted()
end

GRIPEMS.restrictions = {
    [1] = 0, -- Encounter: Inactive
    [2] = 0, -- ChallengeMode: Inactive
    [3] = 0, -- PvPMatch: Inactive
}

-- IC-VAR-01 Win 1 (a): probe initial restriction state at module load
-- so GRIPEMS.restrictions is accurate BEFORE the first
-- ADDON_RESTRICTION_STATE_CHANGED event fires. Window matters when
-- the player logs in inside an instance with restrictions already
-- active -- without this probe the table reads all-Inactive until
-- Blizzard dispatches the catch-up event.
--
-- HasSecretRestrictions is a build-flag indicator (returns true on
-- every Patch 12.0+ client) per Research/Variable_Taint_Solution_
-- 2026-05-04.md L40-42. The per-type live state requires the
-- C_RestrictedActions.IsAddOnRestrictionActive loop. This probe feeds
-- GRIPEMS.restrictions for the Conditions helper, TrackerHUD, and the
-- debug window; it is NOT part of the OOCQueue gate, which is
-- combat-lockdown-only as of 2026-06-07.
if C_Secrets and C_Secrets.HasSecretRestrictions and C_Secrets.HasSecretRestrictions() then
    if hasRestrictedAPI then
        for _, rType in ipairs({ 1, 2, 3 }) do
            local ok, active = pcall(C_RestrictedActions.IsAddOnRestrictionActive, rType)
            if ok and active then
                GRIPEMS.restrictions[rType] = 2
            end
        end
    end
end

--- Add an operation to the queue, or execute immediately if out of combat.
---
--- THREE OUTCOMES, AND THE CALLER MUST BE ABLE TO TELL THEM APART. Out of
--- combat func() runs inline and its result is knowable right here; in combat
--- nothing has happened yet and no honest result exists. Collapsing "ran and
--- returned nil" into "did not run" is exactly the bug this return value was
--- added to fix one layer up, where a refused macro import was counted as
--- imported, so the two are reported on SEPARATE values rather than folded
--- into one falsy answer:
---
---   true, <result>   ran inline; <result> is whatever func() returned, and a
---                    nil there means the work ran and was REFUSED
---   false, nil       deferred; queued for combat end, outcome not yet knowable
---   nil              nothing happened; no func was supplied
---
--- func()'s result is captured into a local before being returned, so a func
--- that returns several values cannot widen this contract to a variable arity.
---
--- @param func function The function to call
--- @param opType string|nil Operation type from D.OOC_OP_* (default D.OOC_OP_GENERIC)
--- @param seqName string|nil Sequence name for dedup (nil for non-sequence ops)
--- @return boolean|nil ran True if func ran inline, false if queued, nil if no func
--- @return any result func()'s return value when it ran inline, nil otherwise
function OOCQueue:Add(func, opType, seqName)
    if not func then
        return nil
    end

    if not IsRestricted() then
        local result = func()
        return true, result
    end

    opType = opType or D.OOC_OP_GENERIC
    self.insertOrder = self.insertOrder + 1

    -- Dedup: replace existing entry with same opType+seqName (generic always appends).
    -- Nil seqName with non-generic opType skips dedup -- matching nil to nil would
    -- coalesce unrelated ops (e.g. any two SETTING writes) and spam "replaced ... for nil".
    -- IC-VAR-03 contract: 50 variable flips during combat collapse to 1 doRecompile
    -- entry (last value wins) because RecompileSequence always uses OOC_OP_RECOMPILE
    -- + seqName as the dedup key.
    if opType ~= D.OOC_OP_GENERIC and seqName ~= nil then
        for i, item in ipairs(self.queue) do
            if item.opType == opType and item.seqName == seqName then
                GRIPEMS:Debug(string.format(L["GEMS_OOC_REPLACED"], opType, tostring(seqName)))
                item.func = func
                -- Superseding a pending entry is still deferred work: the
                -- replacement has not run either.
                return false, nil
            end
        end
    end

    table.insert(self.queue, {
        func = func,
        opType = opType,
        seqName = seqName,
        order = self.insertOrder,
    })
    GRIPEMS:Debug(L["GEMS_OOC_QUEUED"])
    return false, nil
end

--- Process all queued operations in priority order. Skips if still in combat.
--- @param manual string|nil When "manual", bypasses the autoReloadAtCombatEnd gate
---   so user-initiated drains (/gems apply, settings flip-ON) still drain even when
---   automatic drains are disabled. Automatic triggers omit the arg.
function OOCQueue:Process(manual)
    if IsRestricted() then
        return
    end
    -- IC-VAR-03: gate automatic drains on the autoReloadAtCombatEnd setting.
    -- Manual callers bypass the gate; PLAYER_REGEN_ENABLED / restriction lift /
    -- ticker honor it. Default ON preserves current behavior.
    if manual ~= "manual" then
        local S = GRIPEMS.Settings
        if S and S:Get("autoReloadAtCombatEnd") == false then
            return
        end
    end
    local count = #self.queue
    if count == 0 then
        return
    end

    -- Stable sort by priority (equal priority preserves insertion order)
    local priorities = D.OOC_PRIORITY
    local defaultPri = priorities[D.OOC_OP_GENERIC] or 80
    table.sort(self.queue, function(a, b)
        local pa = priorities[a.opType] or defaultPri
        local pb = priorities[b.opType] or defaultPri
        if pa ~= pb then
            return pa < pb
        end
        return a.order < b.order
    end)

    -- Process all entries, pcall each to prevent one failure from aborting the rest
    for _, item in ipairs(self.queue) do
        local ok, err = pcall(item.func)
        if not ok then
            GRIPEMS:Debug("OOC Queue error (" .. tostring(item.opType) .. "): " .. tostring(err))
        end
    end

    wipe(self.queue)
    self.insertOrder = 0
    GRIPEMS:Debug(string.format(L["GEMS_OOC_PRIORITY_PROCESSED"], count))
end

--- Return the number of pending operations in the queue.
--- @return number
function OOCQueue:GetCount()
    return #self.queue
end

--- Action-descriptor enqueue. Wraps a dispatch table around the closure
--- primitive so producers (import / migrate paths) can pass a typed
--- payload instead of building closures themselves.
---
--- Recognized actions:
---   { action = "importmacro", node = <macro node> }
---       Dispatches to GRIPEMS.MacroManager:ImportMacro(node) under
---       opType D.OOC_OP_IMPORTMACRO with dedup key node.name. A newer
---       importmacro for the same name supersedes any pending entry for
---       that name (the standard Add() dedup behavior on opType+seqName).
---
--- Unknown action types fall through silently. The dispatch table is the
--- single source of truth for OOC action descriptors -- new producers add
--- a branch here rather than building bespoke closures at every call site.
---
--- Returns OOCQueue:Add's two-value outcome unchanged, so a producer can tell
--- an inline refusal from deferred work -- see the contract on Add. The
--- dispatch closure RETURNS the handler's result rather than discarding it,
--- which is what makes the inline arm readable at all; without that the
--- refusal reached Add as nil and was indistinguishable from a queued entry.
--- The validation guards return a bare nil, matching Add's "nothing happened".
---
--- @param descriptor table { action = string, ... }
--- @return boolean|nil ran True if dispatched inline, false if queued, nil if not dispatched
--- @return any result The handler's return value when it ran inline, nil otherwise
function OOCQueue:Enqueue(descriptor)
    if type(descriptor) ~= "table" or not descriptor.action then
        return nil
    end
    local action = descriptor.action
    if action == "importmacro" then
        local node = descriptor.node
        if type(node) ~= "table" or not node.name or node.name == "" then
            return nil
        end
        return self:Add(function()
            local MM = GRIPEMS.MacroManager
            if MM and MM.ImportMacro then
                return MM:ImportMacro(node)
            end
            return nil
        end, D.OOC_OP_IMPORTMACRO, node.name)
    end
    -- Unknown action: silent skip. Add a branch above when wiring a new
    -- producer through Enqueue.
    return nil
end

-- Event frame for PLAYER_REGEN_ENABLED (combat end) and PLAYER_REGEN_DISABLED
-- Named for /reload reuse -- prevents orphan C++ frame objects
local oocFrame = _G["GRIPEMS_OOCEvent"] or CreateFrame("Frame", "GRIPEMS_OOCEvent")
oocFrame:UnregisterAllEvents()
oocFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
oocFrame:RegisterEvent("PLAYER_REGEN_DISABLED")
if hasRestrictedAPI then
    oocFrame:RegisterEvent("ADDON_RESTRICTION_STATE_CHANGED")
end
oocFrame:SetScript("OnEvent", function(_, event, ...)
    if event == "PLAYER_REGEN_ENABLED" then
        OOCQueue:Process()
    elseif event == "ADDON_RESTRICTION_STATE_CHANGED" then
        -- State payload: Enum.AddOnRestrictionState (Inactive=0, Activating=1, Active=2)
        -- NOTE: C_RestrictedActions.IsAddOnRestrictionActive returns false DURING
        -- dispatch of this event, so use the payload directly.
        local restrictionType, state = ...
        if GRIPEMS.restrictions then
            GRIPEMS.restrictions[restrictionType] = state
        end
        if GRIPEMS.DebugWindow then
            GRIPEMS.DebugWindow:AddMessage(
                "Restriction: "
                    .. (RESTRICTION_NAMES[restrictionType] or tostring(restrictionType))
                    .. " -> "
                    .. (STATE_NAMES[state] or tostring(state))
            )
        end
        if state == 0 then
            -- Restrictions lifted (Inactive) -- process queue like combat ending
            OOCQueue:Process()
        end
    end
    -- PLAYER_REGEN_DISABLED: queue persists across combat sessions (no wipe)
end)

-- Periodic fallback ticker: catches edge cases where PLAYER_REGEN_ENABLED
-- might not fire (e.g., forced combat drop, death, disconnect recovery).
local oocInterval = D.OOC_TICKER_INTERVAL
local S = GRIPEMS.Settings
if S and S.db then
    oocInterval = S:Get("oocDelay") or oocInterval
end
if C_Timer and C_Timer.NewTicker then
    OOCQueue.ticker = C_Timer.NewTicker(oocInterval, function()
        if not IsRestricted() and #OOCQueue.queue > 0 then
            OOCQueue:Process()
        end
    end)
end

-- Dynamic ticker update: recreate ticker when oocDelay setting changes.
-- Deferred to next frame in case GRIPEMS.RegisterCallback is not yet
-- available at file-load time (load order).
if C_Timer and C_Timer.After then
    C_Timer.After(0, function()
        if GRIPEMS.RegisterCallback then
            -- SIGNATURE IS (event, key, value), NOT (self, event, key, value). A
            -- FUNCTION REF is dispatched with no self prepended -- see
            -- Libs/CallbackHandler-1.0:54 and the registration comment at :76-77.
            -- Producers fire (key, value) at Data/Settings.lua:229, :257 and :299.
            -- This carried function(_, _, key, value), so key bound the VALUE and
            -- value bound nil: "key == oocDelay" could never be true, the ticker
            -- interval never followed the setting, and the autoReloadAtCombatEnd
            -- drain arm never fired.
            GRIPEMS.RegisterCallback(OOCQueue, "SETTING_CHANGED", function(_, key, value)
                if key == "oocDelay" then
                    if OOCQueue.ticker then
                        OOCQueue.ticker:Cancel()
                    end
                    local newInterval = tonumber(value) or D.OOC_TICKER_INTERVAL
                    if C_Timer and C_Timer.NewTicker then
                        OOCQueue.ticker = C_Timer.NewTicker(newInterval, function()
                            if not IsRestricted() and #OOCQueue.queue > 0 then
                                OOCQueue:Process()
                            end
                        end)
                    end
                elseif key == "autoReloadAtCombatEnd" and value then
                    -- IC-VAR-03: toggle flipped ON; drain any ops queued while OFF.
                    if not IsRestricted() and #OOCQueue.queue > 0 then
                        OOCQueue:Process("manual")
                    end
                end
            end)
        end
    end)
end
