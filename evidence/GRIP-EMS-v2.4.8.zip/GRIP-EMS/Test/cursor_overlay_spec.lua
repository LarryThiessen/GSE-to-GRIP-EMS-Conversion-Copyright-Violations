-- GRIP-EMS: Test spec for Cursor Overlay (Phase 4 item 15)
--
-- Created:    2026-04-23
-- Updated:    2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.
--
-- Registers 7 tests in TestSuite under category "cursor" covering
-- module load, the lazy build contract (a disabled Refresh never
-- constructs the frame; enabling builds and shows it; disabling after
-- build hides but preserves it), ring vs crosshair mode switching, and
-- size-multiplier scaling. Run in-game with /gems test cursor.

local ADDON_NAME, GRIPEMS = ...

local TS = GRIPEMS.TestSuite
if not TS then
    return
end

local function snapshotAccess(a)
    return {
        enabled = a.cursorOverlayEnabled,
        mode = a.cursorOverlayMode,
        size = a.cursorOverlaySize,
    }
end

local function restoreAccess(a, snap)
    a.cursorOverlayEnabled = snap.enabled
    a.cursorOverlayMode = snap.mode
    a.cursorOverlaySize = snap.size
end

TS:Register("CursorOverlay: module loads with Init and Refresh", "cursor", function(self)
    local CO = GRIPEMS.UI and GRIPEMS.UI.CursorOverlay
    if CO and type(CO.Init) == "function" and type(CO.Refresh) == "function" then
        self:Pass()
    else
        self:Fail("GRIPEMS.UI.CursorOverlay missing Init or Refresh")
    end
end)

TS:Register("CursorOverlay: Refresh with enabled=false does not build the overlay", "cursor", function(self)
    local CO = GRIPEMS.UI and GRIPEMS.UI.CursorOverlay
    local S = GRIPEMS.Settings
    if not (CO and S and S.db and S.db.profile and S.db.profile.accessibility) then
        self:Fail("CursorOverlay or Settings missing")
        return
    end
    -- The overlay is built lazily, so a disabled Refresh must never
    -- construct the frame. The module-level `overlay` upvalue persists
    -- across re-runs of this suite, so only assert the "not built" path
    -- when the frame has not already been built earlier this session.
    local a = S.db.profile.accessibility
    local snap = snapshotAccess(a)
    local prebuilt = _G["GRIPEMS_CursorOverlay"] ~= nil
    a.cursorOverlayEnabled = false
    local ok = pcall(function()
        CO:Refresh()
    end)
    local frame = _G["GRIPEMS_CursorOverlay"]
    local builtWhileDisabled = (not prebuilt) and frame ~= nil
    local shownWhileDisabled = frame ~= nil and frame:IsShown()
    restoreAccess(a, snap)
    CO:Refresh()
    if not ok then
        self:Fail("Refresh errored when enabled=false")
        return
    end
    if builtWhileDisabled then
        self:Fail("disabled Refresh built the overlay frame")
        return
    end
    if shownWhileDisabled then
        self:Fail("frame shown when cursorOverlayEnabled=false")
        return
    end
    self:Pass()
end)

TS:Register("CursorOverlay: Refresh with enabled=true builds and shows the frame", "cursor", function(self)
    local CO = GRIPEMS.UI and GRIPEMS.UI.CursorOverlay
    local S = GRIPEMS.Settings
    if not (CO and S and S.db and S.db.profile and S.db.profile.accessibility) then
        self:Fail("CursorOverlay or Settings missing")
        return
    end
    local a = S.db.profile.accessibility
    local snap = snapshotAccess(a)
    a.cursorOverlayEnabled = true
    local ok = pcall(function()
        CO:Refresh()
    end)
    local frame = _G["GRIPEMS_CursorOverlay"]
    local shown = frame ~= nil and frame:IsShown()
    restoreAccess(a, snap)
    CO:Refresh()
    if not ok then
        self:Fail("Refresh errored when enabled=true")
        return
    end
    if not frame then
        self:Fail("enabled Refresh did not build the overlay")
        return
    end
    if not shown then
        self:Fail("overlay not shown after enabling")
        return
    end
    self:Pass()
end)

TS:Register("CursorOverlay: Refresh with enabled=false after build hides the frame", "cursor", function(self)
    local CO = GRIPEMS.UI and GRIPEMS.UI.CursorOverlay
    local S = GRIPEMS.Settings
    if not (CO and S and S.db and S.db.profile and S.db.profile.accessibility) then
        self:Fail("CursorOverlay or Settings missing")
        return
    end
    local a = S.db.profile.accessibility
    local snap = snapshotAccess(a)
    -- Build via the lazy enable path, then disable and confirm the
    -- frame is hidden but preserved (not destroyed).
    a.cursorOverlayEnabled = true
    CO:Refresh()
    a.cursorOverlayEnabled = false
    local ok = pcall(function()
        CO:Refresh()
    end)
    local frame = _G["GRIPEMS_CursorOverlay"]
    local shownWhileDisabled = frame ~= nil and frame:IsShown()
    restoreAccess(a, snap)
    CO:Refresh()
    if not ok then
        self:Fail("Refresh errored when enabled=false")
        return
    end
    if not frame then
        self:Fail("overlay frame missing from _G after build")
        return
    end
    if shownWhileDisabled then
        self:Fail("frame still shown when cursorOverlayEnabled=false")
        return
    end
    self:Pass()
end)

TS:Register("CursorOverlay: ring mode shows ring hides crosshair", "cursor", function(self)
    local CO = GRIPEMS.UI and GRIPEMS.UI.CursorOverlay
    local S = GRIPEMS.Settings
    if not (CO and S and S.db and S.db.profile and S.db.profile.accessibility) then
        self:Fail("CursorOverlay or Settings missing")
        return
    end
    CO:Init()
    local a = S.db.profile.accessibility
    local snap = snapshotAccess(a)
    a.cursorOverlayEnabled = true
    a.cursorOverlayMode = "ring"
    a.cursorOverlaySize = 1.5
    CO:Refresh()
    local frame = _G["GRIPEMS_CursorOverlay"]
    local ringShown = frame and frame.ring and frame.ring.top and frame.ring.top:IsShown()
    local crossShown = frame and frame.crosshair and frame.crosshair.h and frame.crosshair.h:IsShown()
    restoreAccess(a, snap)
    CO:Refresh()
    if not frame or not frame.ring or not frame.crosshair then
        self:Fail("overlay sub-tables missing")
        return
    end
    if not ringShown then
        self:Fail("ring.top not shown in ring mode")
        return
    end
    if crossShown then
        self:Fail("crosshair.h should be hidden in ring mode")
        return
    end
    self:Pass()
end)

TS:Register("CursorOverlay: crosshair mode shows crosshair hides ring", "cursor", function(self)
    local CO = GRIPEMS.UI and GRIPEMS.UI.CursorOverlay
    local S = GRIPEMS.Settings
    if not (CO and S and S.db and S.db.profile and S.db.profile.accessibility) then
        self:Fail("CursorOverlay or Settings missing")
        return
    end
    CO:Init()
    local a = S.db.profile.accessibility
    local snap = snapshotAccess(a)
    a.cursorOverlayEnabled = true
    a.cursorOverlayMode = "crosshair"
    a.cursorOverlaySize = 1.5
    CO:Refresh()
    local frame = _G["GRIPEMS_CursorOverlay"]
    local ringShown = frame and frame.ring and frame.ring.top and frame.ring.top:IsShown()
    local crossShown = frame and frame.crosshair and frame.crosshair.h and frame.crosshair.h:IsShown()
    restoreAccess(a, snap)
    CO:Refresh()
    if not frame or not frame.ring or not frame.crosshair then
        self:Fail("overlay sub-tables missing")
        return
    end
    if not crossShown then
        self:Fail("crosshair.h not shown in crosshair mode")
        return
    end
    if ringShown then
        self:Fail("ring.top should be hidden in crosshair mode")
        return
    end
    self:Pass()
end)

TS:Register("CursorOverlay: size 2.0 produces 64px ring bounding box", "cursor", function(self)
    local CO = GRIPEMS.UI and GRIPEMS.UI.CursorOverlay
    local S = GRIPEMS.Settings
    if not (CO and S and S.db and S.db.profile and S.db.profile.accessibility) then
        self:Fail("CursorOverlay or Settings missing")
        return
    end
    CO:Init()
    local a = S.db.profile.accessibility
    local snap = snapshotAccess(a)
    a.cursorOverlayEnabled = true
    a.cursorOverlayMode = "ring"
    a.cursorOverlaySize = 2.0
    CO:Refresh()
    local frame = _G["GRIPEMS_CursorOverlay"]
    local w = frame and frame:GetWidth() or 0
    local h = frame and frame:GetHeight() or 0
    restoreAccess(a, snap)
    CO:Refresh()
    if math.abs(w - 64) > 0.5 then
        self:Fail("expected width 64 at size=2.0, got " .. tostring(w))
        return
    end
    if math.abs(h - 64) > 0.5 then
        self:Fail("expected height 64 at size=2.0, got " .. tostring(h))
        return
    end
    self:Pass()
end)

-- end of Test/cursor_overlay_spec.lua
