-- GRIP-EMS: Spell Cache Viewer
-- UI frame for browsing and editing the runtime spell/item/toy cache
--
-- Created:    2025 (pre-stamping; exact date unknown)
-- Updated:    2026-07-16
-- Patch: 12.0.7.68256 Midnight (Retail LIVE)

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)
local UI = GRIPEMS.UI

GRIPEMS.SpellCacheViewer = {}
local SCV = GRIPEMS.SpellCacheViewer

-- State
SCV.filteredData = {}
SCV.activeTab = "Spells"
SCV.searchText = ""
SCV._editingEntryID = nil

local ROW_HEIGHT = 24
local ICON_SIZE = 20

---------------------------------------------------------------------------
-- Init: lazily create the viewer frame
---------------------------------------------------------------------------
function SCV:Init()
    if SCV.frame then
        return
    end

    local C = UI.Colors
    local SC = GRIPEMS.SpellCache

    -- Main frame
    local frame = CreateFrame("Frame", "GRIPEMS_SpellCacheViewer", UIParent, "BackdropTemplate")
    frame:SetSize(500, 450)
    frame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    frame:SetFrameStrata("HIGH")
    UI:ApplyBackdrop(frame, UI.Backdrops.panel, C.bgMain, C.border)
    if GRIPEMS.UI and GRIPEMS.UI.RegisterPanelFrame then
        GRIPEMS.UI:RegisterPanelFrame(frame, "panel", "panel.utility")
    end
    frame:SetMovable(true)
    frame:SetResizable(true)
    frame:SetResizeBounds(400, 300)
    frame:SetClampedToScreen(true)
    frame:Hide()

    ---------------------------------------------------------------------------
    -- Title bar (28px)
    ---------------------------------------------------------------------------
    local titleBar = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    titleBar:SetHeight(28)
    titleBar:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, 0)
    titleBar:SetPoint("TOPRIGHT", frame, "TOPRIGHT", 0, 0)
    UI:ApplyBackdrop(titleBar, UI.Backdrops.panelNoBorder, C.bgDeep)

    titleBar:EnableMouse(true)
    titleBar:RegisterForDrag("LeftButton")
    titleBar:SetScript("OnDragStart", function()
        frame:StartMoving()
    end)
    titleBar:SetScript("OnDragStop", function()
        frame:StopMovingOrSizing()
    end)

    local titleText = titleBar:CreateFontString(nil, "OVERLAY")
    UI:SetFont(titleText, 12, "OUTLINE")
    titleText:SetPoint("LEFT", titleBar, "LEFT", 8, 0)
    titleText:SetText(L["GEMS_SPELLCACHE_TITLE"])
    titleText:SetTextColor(C.gripGreen:GetRGBA())

    -- Close button
    local closeBtn = CreateFrame("Button", nil, titleBar, "BackdropTemplate")
    closeBtn:SetSize(20, 20)
    UI:RegisterLargeTarget(closeBtn)
    closeBtn:SetPoint("TOPRIGHT", titleBar, "TOPRIGHT", -4, -4)
    UI:ApplyBackdrop(closeBtn, UI.Backdrops.panel, C.bgButton, C.border)
    local closeLbl = closeBtn:CreateFontString(nil, "OVERLAY")
    UI:SetFont(closeLbl, 12)
    closeLbl:SetPoint("CENTER", 0, 1)
    closeLbl:SetText("X")
    closeLbl:SetTextColor(C.textSecondary:GetRGBA())
    closeBtn:SetScript("OnClick", function()
        frame:Hide()
    end)
    closeBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.accent:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
        closeLbl:SetTextColor(C.textPrimary:GetRGBA())
    end)
    closeBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
        closeLbl:SetTextColor(C.textSecondary:GetRGBA())
    end)

    ---------------------------------------------------------------------------
    -- Tab bar (28px, below title)
    ---------------------------------------------------------------------------
    local tabBar = CreateFrame("Frame", nil, frame)
    tabBar:SetHeight(28)
    tabBar:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, -28)
    tabBar:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -8, -28)

    local tabNames = {
        { key = "Spells", label = L["GEMS_SPELLCACHE_TAB_SPELLS"] },
        { key = "Items", label = L["GEMS_SPELLCACHE_TAB_ITEMS"] },
        { key = "Toys", label = L["GEMS_SPELLCACHE_TAB_TOYS"] },
    }
    SCV.tabButtons = {}

    for i, info in ipairs(tabNames) do
        local tab = CreateFrame("Button", nil, tabBar, "BackdropTemplate")
        tab:SetSize(80, 24)
        if i == 1 then
            tab:SetPoint("LEFT", tabBar, "LEFT", 0, 0)
        else
            tab:SetPoint("LEFT", SCV.tabButtons[i - 1], "RIGHT", 4, 0)
        end

        local tabLabel = tab:CreateFontString(nil, "OVERLAY")
        UI:SetFont(tabLabel, 11)
        tabLabel:SetPoint("CENTER")
        tabLabel:SetText(info.label)
        tab.label = tabLabel
        tab.tabKey = info.key

        -- Accent bottom border for active tab
        local accentLine = tab:CreateTexture(nil, "OVERLAY")
        accentLine:SetHeight(2)
        accentLine:SetPoint("BOTTOMLEFT", tab, "BOTTOMLEFT", 0, 0)
        accentLine:SetPoint("BOTTOMRIGHT", tab, "BOTTOMRIGHT", 0, 0)
        accentLine:SetColorTexture(C.accent:GetRGBA())
        tab.accentLine = accentLine

        tab:SetScript("OnClick", function()
            SCV:SwitchTab(info.key)
        end)

        SCV.tabButtons[i] = tab
    end

    ---------------------------------------------------------------------------
    -- Search bar (24px, below tabs)
    ---------------------------------------------------------------------------
    local searchBar = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    searchBar:SetHeight(24)
    searchBar:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, -58)
    searchBar:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -8, -58)
    UI:ApplyBackdrop(searchBar, UI.Backdrops.panel, C.bgInput, C.border)

    local searchBox = CreateFrame("EditBox", nil, searchBar)
    searchBox:SetPoint("TOPLEFT", 6, -2)
    searchBox:SetPoint("BOTTOMRIGHT", -6, 2)
    searchBox:SetAutoFocus(false)
    searchBox:SetMaxLetters(50)
    UI:SetFont(searchBox, 11)
    searchBox:SetTextColor(C.textPrimary:GetRGBA())

    -- Placeholder text
    local placeholder = searchBox:CreateFontString(nil, "ARTWORK")
    UI:SetFont(placeholder, 11)
    placeholder:SetPoint("LEFT", 0, 0)
    placeholder:SetText(L["GEMS_SPELLCACHE_SEARCH"])
    placeholder:SetTextColor(C.textMuted:GetRGBA())
    searchBox.placeholder = placeholder

    local searchTimer = nil
    searchBox:SetScript("OnTextChanged", function(self)
        local text = self:GetText()
        if text and text ~= "" then
            placeholder:Hide()
        else
            placeholder:Show()
        end
        -- Debounce 0.1s
        if searchTimer then
            searchTimer:Cancel()
        end
        if C_Timer and C_Timer.NewTimer then
            searchTimer = C_Timer.NewTimer(0.1, function()
                searchTimer = nil
                SCV:ApplyFilter(text or "")
            end)
        end
    end)
    searchBox:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
    end)
    SCV.searchBox = searchBox
    GRIPEMS.Focus:HookEditBox(searchBox)

    ---------------------------------------------------------------------------
    -- Content area (ScrollBox + MinimalScrollBar)
    ---------------------------------------------------------------------------
    local scrollBox = CreateFrame("Frame", nil, frame, "WowScrollBoxList")
    scrollBox:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, -86)
    scrollBox:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -26, 36)
    SCV.scrollBox = scrollBox

    local scrollBar = CreateFrame("EventFrame", nil, frame, "MinimalScrollBar")
    scrollBar:SetPoint("TOPLEFT", scrollBox, "TOPRIGHT", 2, 0)
    scrollBar:SetPoint("BOTTOMLEFT", scrollBox, "BOTTOMRIGHT", 2, 0)
    SCV.scrollBar = scrollBar

    local scrollView = CreateScrollBoxListLinearView()
    scrollView:SetElementExtent(ROW_HEIGHT)
    scrollView:SetElementInitializer("Button", function(button, data)
        SCV:InitRow(button, data)
    end)
    ScrollUtil.InitScrollBoxListWithScrollBar(scrollBox, scrollBar, scrollView)
    scrollBox:SetDataProvider(CreateDataProvider())

    -- Refresh on resize
    frame:SetScript("OnSizeChanged", function()
        SCV:RefreshList()
    end)

    ---------------------------------------------------------------------------
    -- Bottom bar: showing count + buttons
    ---------------------------------------------------------------------------
    local showingLabel = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(showingLabel, 10)
    showingLabel:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 10, 10)
    showingLabel:SetTextColor(C.textSecondary:GetRGBA())
    SCV.showingLabel = showingLabel

    -- Refresh button
    local refreshBtn = UI:CreateButton(frame, L["GEMS_SPELLCACHE_REFRESH"], 80, 24)
    refreshBtn:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -10, 8)
    refreshBtn:SetScript("OnClick", function()
        SCV.showingLabel:SetText(L["GEMS_SPELLCACHE_SCANNING"])
        if C_Timer and C_Timer.After then
            C_Timer.After(0, function()
                if SC then
                    SC:Scan()
                end
                SCV:RefreshList()
            end)
        end
    end)

    -- Clear Overrides button
    local clearBtn = UI:CreateButton(frame, L["GEMS_SPELLCACHE_CLEAR_OVERRIDES"], 120, 24)
    clearBtn:SetPoint("RIGHT", refreshBtn, "LEFT", -6, 0)
    if not GRIPEMS.Popup:GetDef("GRIPEMS_CLEAR_OVERRIDES") then
        GRIPEMS.Popup:Define("GRIPEMS_CLEAR_OVERRIDES", {
            text = L["GEMS_SPELLCACHE_CLEAR_CONFIRM"],
            button1 = ACCEPT,
            button2 = CANCEL,
            OnAccept = function()
                local db = GRIPEMS.Settings and GRIPEMS.Settings.db
                if db and db.profile then
                    wipe(db.profile.spellOverrides)
                end
                -- Revert the live cache too. Wiping the profile alone cleared
                -- the dot but left every custom name on screen until /reload.
                if SC and SC.ready then
                    SC:ApplySpellOverrides()
                end
                SCV:RefreshList()
                GRIPEMS:Print(L["GEMS_SPELLCACHE_OVERRIDE_CLEARED"])
            end,
            timeout = 0,
            hideOnEscape = true,
        })
    end
    clearBtn:SetScript("OnClick", function()
        GRIPEMS.Popup:Show("GRIPEMS_CLEAR_OVERRIDES")
    end)
    SCV.clearOverridesBtn = clearBtn

    ---------------------------------------------------------------------------
    -- Resize grip
    ---------------------------------------------------------------------------
    local resizeGrip = CreateFrame("Button", nil, frame)
    resizeGrip:SetSize(16, 16)
    resizeGrip:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -2, 2)
    resizeGrip:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    resizeGrip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    resizeGrip:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
    resizeGrip:SetScript("OnMouseDown", function()
        frame:StartSizing("BOTTOMRIGHT")
    end)
    resizeGrip:SetScript("OnMouseUp", function()
        frame:StopMovingOrSizing()
    end)

    SCV.frame = frame
    SCV:UpdateTabVisuals()
end

---------------------------------------------------------------------------
-- Tab management
---------------------------------------------------------------------------

function SCV:UpdateTabVisuals()
    local C = UI.Colors
    for _, tab in ipairs(SCV.tabButtons) do
        if tab.tabKey == SCV.activeTab then
            UI:ApplyBackdrop(tab, UI.Backdrops.panel, C.bgPanel, C.border)
            tab.label:SetTextColor(C.textPrimary:GetRGBA())
            tab.accentLine:Show()
        else
            UI:ApplyBackdrop(tab, UI.Backdrops.panel, C.bgDeep, C.border)
            tab.label:SetTextColor(C.textSecondary:GetRGBA())
            tab.accentLine:Hide()
        end
    end
    -- Clear Overrides only visible on Spells tab
    if SCV.clearOverridesBtn then
        if SCV.activeTab == "Spells" then
            SCV.clearOverridesBtn:Show()
        else
            SCV.clearOverridesBtn:Hide()
        end
    end
end

function SCV:SwitchTab(tabName)
    SCV.activeTab = tabName
    SCV:UpdateTabVisuals()
    SCV:RefreshList()
end

---------------------------------------------------------------------------
-- Data collection
---------------------------------------------------------------------------

local function CollectData()
    local SC = GRIPEMS.SpellCache
    if not SC or not SC.ready then
        return {}
    end

    if SCV.activeTab == "Spells" then
        return SC.spells -- already sorted
    elseif SCV.activeTab == "Items" then
        local items = {}
        for name, itemID in pairs(SC.itemByName) do
            items[#items + 1] = { name = name, id = itemID }
        end
        table.sort(items, function(a, b)
            return a.name < b.name
        end)
        return items
    elseif SCV.activeTab == "Toys" then
        -- OPP-01: ensure cache is built on first viewer open
        if SC.EnsureToyCache then
            SC:EnsureToyCache()
        end
        local toys = {}
        for name, itemID in pairs(SC.toyByName) do
            toys[#toys + 1] = { name = name, id = itemID }
        end
        table.sort(toys, function(a, b)
            return a.name < b.name
        end)
        return toys
    end

    return {}
end

---------------------------------------------------------------------------
-- Row initializer (ScrollBox element)
---------------------------------------------------------------------------

local function HasOverride(spellID)
    -- Settings.db, not GRIPEMS.db (never assigned anywhere): the old
    -- guard made this always-false, so the override dot never rendered.
    local db = GRIPEMS.Settings and GRIPEMS.Settings.db
    if not db or not db.profile then
        return false
    end
    local overrides = db.profile.spellOverrides
    return overrides and overrides[spellID] ~= nil
end

local function StartEdit(row, entry)
    if SCV.activeTab ~= "Spells" then
        return
    end
    SCV._editingEntryID = entry.spellID
    row.isEditing = true
    row.nameText:Hide()
    row.editBox:SetText(entry.name)
    row.editBox:Show()
    row.editBox:SetFocus()

    row.editBox:SetScript("OnEnterPressed", function(self)
        local newName = self:GetText()
        if newName and newName ~= "" and newName ~= entry.name then
            -- Settings.db, not GRIPEMS.db (never assigned anywhere): the
            -- old guard silently discarded every rename since v1.7.0-Beta.
            local db = GRIPEMS.Settings and GRIPEMS.Settings.db
            if db and db.profile and db.profile.spellOverrides then
                db.profile.spellOverrides[entry.spellID] = newName
                -- Push the override into the live cache. RefreshList reads
                -- the row name from SC.spells, which Scan only rewrites on a
                -- dirty rebuild, so without this the dot appeared next to the
                -- old name until /reload.
                local SC = GRIPEMS.SpellCache
                if SC and SC.ready then
                    SC:ApplySpellOverrides()
                end
            end
        end
        self:Hide()
        row.nameText:Show()
        row.isEditing = false
        SCV._editingEntryID = nil
        SCV:RefreshList(true)
    end)
    row.editBox:SetScript("OnEscapePressed", function(self)
        self:Hide()
        row.nameText:Show()
        row.isEditing = false
        SCV._editingEntryID = nil
    end)
end

function SCV:InitRow(button, data)
    local C = UI.Colors

    if not button._initialized then
        -- ScrollBox rows come from SetElementInitializer("Button", ...), a plain
        -- Button with no backdrop methods. Without the mixin the GetBackdrop
        -- call further down throws and secureexecuterange aborts the whole
        -- initializer before the row is ever populated, so every row rendered
        -- blank. Same guard as SequenceList and StepListView.
        if not button.SetBackdrop then
            Mixin(button, BackdropTemplateMixin)
        end

        button:SetHeight(ROW_HEIGHT)

        local icon = button:CreateTexture(nil, "ARTWORK")
        icon:SetSize(ICON_SIZE, ICON_SIZE)
        icon:SetPoint("LEFT", button, "LEFT", 12, 0)
        button.icon = icon

        -- The override dot owns a fixed 6px gutter at the row's left
        -- edge and the icon starts after it. Anchoring the dot to the
        -- icon's LEFT put 4 of its 6 pixels outside the row, where it
        -- was clipped or painted into the scroll frame's padding. The
        -- gutter is reserved whether or not the dot is shown, so rows
        -- stay aligned regardless of override state.
        local dot = button:CreateTexture(nil, "OVERLAY")
        dot:SetSize(6, 6)
        dot:SetPoint("LEFT", button, "LEFT", 3, 0)
        dot:SetColorTexture(C.accent:GetRGBA())
        dot:Hide()
        button.overrideDot = dot

        local nameText = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(nameText, 11)
        nameText:SetPoint("LEFT", icon, "RIGHT", 6, 0)
        nameText:SetPoint("RIGHT", button, "RIGHT", -80, 0)
        nameText:SetJustifyH("LEFT")
        nameText:SetWordWrap(false)
        button.nameText = nameText

        local idText = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(idText, 10)
        idText:SetPoint("RIGHT", button, "RIGHT", -4, 0)
        idText:SetJustifyH("RIGHT")
        idText:SetTextColor(C.textSecondary:GetRGBA())
        button.idText = idText

        local editBox = CreateFrame("EditBox", nil, button, "BackdropTemplate")
        editBox:SetPoint("LEFT", icon, "RIGHT", 4, 0)
        editBox:SetPoint("RIGHT", button, "RIGHT", -80, 0)
        editBox:SetHeight(ROW_HEIGHT - 4)
        editBox:SetAutoFocus(false)
        UI:SetFont(editBox, 11)
        editBox:SetTextColor(C.textPrimary:GetRGBA())
        UI:ApplyBackdrop(editBox, UI.Backdrops.panel, C.bgInput, C.borderFocus)
        editBox:Hide()
        button.editBox = editBox
        GRIPEMS.Focus:HookEditBox(editBox)

        button._initialized = true
    end

    -- Alternate row backdrop
    if not button:GetBackdrop() then
        button:SetBackdrop(UI.Backdrops.panelNoBorder)
    end
    if data.index % 2 == 0 then
        button:SetBackdropColor(C.bgInput:GetRGBA())
        button.bgColor = C.bgInput
    else
        button:SetBackdropColor(0, 0, 0, 0)
        button.bgColor = nil
    end

    -- Populate
    button.icon:SetTexture(data.iconID or 134400)
    button.nameText:SetText(data.name or "")
    button.nameText:SetTextColor(C.textPrimary:GetRGBA())
    button.idText:SetText(tostring(data.id or ""))

    if data.hasOverride then
        button.overrideDot:Show()
    else
        button.overrideDot:Hide()
    end

    -- Inline edit persistence
    if data.tabType == "Spells" and SCV._editingEntryID == data.id then
        button.isEditing = true
        button.nameText:Hide()
        button.editBox:Show()
        StartEdit(button, { name = data.name, spellID = data.id })
    else
        button.isEditing = false
        button.editBox:Hide()
        button.nameText:Show()
    end

    -- Double-click to edit (Spells only)
    if data.tabType == "Spells" then
        button:SetScript("OnDoubleClick", function()
            StartEdit(button, { name = data.name, spellID = data.id })
        end)
    else
        button:SetScript("OnDoubleClick", nil)
    end

    -- Hover
    button:SetScript("OnEnter", function(self)
        if not self.isEditing then
            self:SetBackdropColor(C.bgRowHover:GetRGBA())
        end
    end)
    button:SetScript("OnLeave", function(self)
        if not self.isEditing then
            local bg = self.bgColor
            if bg then
                self:SetBackdropColor(bg:GetRGBA())
            else
                self:SetBackdropColor(0, 0, 0, 0)
            end
        end
    end)
end

---------------------------------------------------------------------------
-- RefreshList / ApplyFilter
---------------------------------------------------------------------------

-- retainScroll: pass true to keep the current scroll offset (used after an
-- in-place row edit so the user is not snapped to the top). Search, tab, and
-- rescan refreshes omit it so a fresh result set jumps back to the top.
function SCV:RefreshList(retainScroll)
    if not SCV.frame or not SCV.scrollBox then
        return
    end

    local allData = CollectData()
    local search = strlower(SCV.searchText or "")
    local filtered = {}

    for _, entry in ipairs(allData) do
        if search == "" or strlower(entry.name):find(search, 1, true) then
            filtered[#filtered + 1] = entry
        end
    end

    SCV.filteredData = filtered
    local totalCount = #allData
    local tabType = SCV.activeTab

    local dp = CreateDataProvider()
    for i, entry in ipairs(filtered) do
        local iconID
        if tabType == "Items" then
            iconID = C_Item.GetItemIconByID(entry.id)
        elseif tabType == "Toys" then
            local _, _, toyIcon = C_ToyBox.GetToyInfo(entry.id)
            iconID = toyIcon
        else
            iconID = entry.iconID
        end

        dp:Insert({
            index = i,
            name = entry.name,
            id = (tabType == "Spells") and entry.spellID or entry.id,
            iconID = iconID or 134400,
            tabType = tabType,
            hasOverride = (tabType == "Spells") and HasOverride(entry.spellID) or false,
        })
    end

    if retainScroll then
        SCV.scrollBox:SetDataProvider(dp, ScrollBoxConstants.RetainScrollPosition)
    else
        SCV.scrollBox:SetDataProvider(dp)
    end
    SCV.showingLabel:SetText(string.format(L["GEMS_SPELLCACHE_SHOWING"], #filtered, totalCount))
end

function SCV:ApplyFilter(searchText)
    SCV.searchText = searchText or ""
    SCV:RefreshList()
end

---------------------------------------------------------------------------
-- Show / Hide
---------------------------------------------------------------------------

function SCV:Show()
    SCV:Init()
    SCV.frame:Show()
    SCV:RefreshList()
end

function SCV:Hide()
    if SCV.frame then
        SCV.frame:Hide()
    end
end
