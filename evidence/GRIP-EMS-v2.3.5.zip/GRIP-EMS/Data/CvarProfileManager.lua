-- GRIP-EMS: CvarProfileManager
-- Created: 2026-04-07
-- Updated: 2026-07-02
-- Patch: 12.0.7.68256 Midnight (Retail LIVE)

-- GRIP-EMS: CVar Profile Manager
-- Context-aware CVar profile switching with OOC-safe application.
-- Phase 2 of CVar Health Dashboard.

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)
local D = GRIPEMS.Defaults

GRIPEMS.CvarProfileManager = {}
local CPM = GRIPEMS.CvarProfileManager

-- Pending What Changed entries (cleared on dismiss)
CPM.pendingChanges = nil

--------------------------------------------------------------------------------
-- Utility
--------------------------------------------------------------------------------

--- Check if a CVar is flagged as secure by the client.
--- Uses C_CVar.GetCVarInfo (12.0+) with pcall for safety.
--- GetCVarInfo returns 7 positional values (not a table):
---   1=value, 2=defaultValue, 3=isStoredServerAccount,
---   4=isStoredServerCharacter, 5=isLockedFromUser, 6=isSecure, 7=isReadOnly.
--- @param cvarName string
--- @return boolean
function CPM.IsCVarSecure(cvarName)
    if not (C_CVar and C_CVar.GetCVarInfo) then
        return false
    end
    local ok, _, _, _, _, _, isSecure = pcall(C_CVar.GetCVarInfo, cvarName) -- isSecure is GetCVarInfo return 6
    if ok then
        return isSecure or false
    end
    return false
end

--- Look up the General (Phase 1) recommended value for a CVar.
--- @param cvarName string
--- @return string|nil recommended value
function CPM:GetGeneralRecommendation(cvarName)
    for _, section in ipairs(D.CVAR_SECTIONS) do
        for _, rec in ipairs(section.cvars) do
            if rec.cvar == cvarName then
                return rec.recommended
            end
        end
    end
    return nil
end

--- Get the effective recommendation for a CVar (profile override or General).
--- @param cvarName string
--- @return string|nil recommended value
function CPM:GetEffectiveRecommendation(cvarName)
    if cvarName == "SpellQueueWindow" then
        local SQWO = GRIPEMS.SQWOptimizer
        if SQWO and SQWO:IsActive() and SQWO.lastAppliedSQW then
            return tostring(SQWO.lastAppliedSQW)
        end
    end
    -- Hold Mode: when active, hold CVars are managed by HoldModeManager
    local TA = GRIPEMS.TempoAdvisor
    if TA and TA.HoldModeManager and TA.HoldModeManager.active then
        if cvarName == "ActionButtonUseKeyHeldSpell" then
            return "1"
        elseif cvarName == "UseKeyHeldSpellErrorPollTime" then
            return tostring(TA:GetHoldModePollRate())
        end
    end
    local S = GRIPEMS.Settings
    if S then
        local activeKey = S:Get("cvarActiveProfile")
        local profile = self:GetProfile(activeKey)
        if profile and profile.overrides and profile.overrides[cvarName] ~= nil then
            return profile.overrides[cvarName]
        end
    end
    return self:GetGeneralRecommendation(cvarName)
end

--------------------------------------------------------------------------------
-- G7: Previous-Value Cache (Undo backend)
--------------------------------------------------------------------------------

--- Capture the current CVar value into the previous-values cache.
--- Called BEFORE any SetCVar that the user might want to undo. Idempotent --
--- repeat captures overwrite, so the most recent change is the only undoable one.
--- The second arg `explicitValue` is optional. When provided, it overrides the
--- internal GetCVar read -- use it when the caller has already captured the
--- pre-change value AND has reordered SetCVar to run before CapturePrevious
--- (G5-POLISH-COMBAT-MID-THROTTLE pattern). When nil, behavior is unchanged.
--- @param cvarName string
--- @param explicitValue string|nil
function CPM:CapturePrevious(cvarName, explicitValue)
    local S = GRIPEMS.Settings
    if not S or not cvarName then
        return
    end
    local current = explicitValue ~= nil and explicitValue or GetCVar(cvarName)
    if current == nil then
        return
    end
    local prev = S:Get("cvarPreviousValues") or {}
    -- G.3a-OPTION-B: a fresh Fix forks the timeline. Any pending Redo
    -- target is for an earlier branch and no longer reachable -- clear
    -- redo[cvarName] so the Redo affordance does not show a stale entry.
    -- Matches text-editor Undo/Redo semantics (typing after Undo wipes
    -- the Redo stack). The pure-Redo path (RedoPrevious) writes to prev
    -- directly, NOT through CapturePrevious, so the Undo<->Redo cycle
    -- preserves both caches.
    local redo = S:Get("cvarRedoValues")
    if redo and redo[cvarName] ~= nil then
        redo[cvarName] = nil
        S:Set("cvarRedoValues", redo)
    end
    prev[cvarName] = current
    S:Set("cvarPreviousValues", prev)
end

--- Get the cached previous value for a CVar.
--- @param cvarName string
--- @return string|nil
function CPM:GetPrevious(cvarName)
    local S = GRIPEMS.Settings
    if not S or not cvarName then
        return nil
    end
    local prev = S:Get("cvarPreviousValues") or {}
    return prev[cvarName]
end

--- True if a previous value exists for this CVar (Undo affordance gate).
--- @param cvarName string
--- @return boolean
function CPM:HasPrevious(cvarName)
    return self:GetPrevious(cvarName) ~= nil
end

--- Restore the cached previous value for a CVar and clear the cache entry.
--- Returns false if no previous value exists, or if a secure CVar would
--- need to be set in combat lockdown.
--- @param cvarName string
--- @return boolean success
function CPM:UndoPrevious(cvarName)
    local S = GRIPEMS.Settings
    if not S or not cvarName then
        return false
    end
    -- G.3b: pin is ironclad. Undo respects pin (Jesper decision 2026-05-01).
    -- User must unpin first to undo a pinned CVar's previous value.
    if self:IsPinned(cvarName) then
        return false
    end
    local prev = S:Get("cvarPreviousValues") or {}
    local val = prev[cvarName]
    if val == nil then
        return false
    end
    if InCombatLockdown() and CPM.IsCVarSecure(cvarName) then
        return false
    end
    -- G.3a-OPTION-B: capture the current live value into cvarRedoValues
    -- BEFORE SetCVar restores the prior value. Inline (not via
    -- CapturePrevious) because CapturePrevious clears the redo cache.
    local liveBeforeUndo = GetCVar(cvarName)
    if liveBeforeUndo ~= nil then
        local redo = S:Get("cvarRedoValues") or {}
        redo[cvarName] = liveBeforeUndo
        S:Set("cvarRedoValues", redo)
    end
    SetCVar(cvarName, val)
    prev[cvarName] = nil
    S:Set("cvarPreviousValues", prev)
    if GRIPEMS.Fire then
        GRIPEMS:Fire("CVAR_UNDO_APPLIED", cvarName)
    end
    return true
end

--- Get the cached redo value for a CVar.
--- G.3a-OPTION-B mirror of GetPrevious.
--- @param cvarName string
--- @return string|nil
function CPM:GetRedo(cvarName)
    local S = GRIPEMS.Settings
    if not S or not cvarName then
        return nil
    end
    local redo = S:Get("cvarRedoValues") or {}
    return redo[cvarName]
end

--- True if a redo value exists for this CVar (Redo affordance gate).
--- G.3a-OPTION-B mirror of HasPrevious.
--- @param cvarName string
--- @return boolean
function CPM:HasRedo(cvarName)
    return self:GetRedo(cvarName) ~= nil
end

--- Restore the cached redo value for a CVar and clear the cache entry.
--- Captures the current live value into cvarPreviousValues BEFORE
--- the redo SetCVar so the user can Undo back to the post-Undo state
--- (full Fix/Undo/Redo/Undo cycle). Inline prev-write (not via
--- CapturePrevious) because CapturePrevious clears the redo cache;
--- here we want both caches preserved across the Redo step.
--- Returns false on pin or combat-lockdown on secure CVar, matching
--- UndoPrevious semantics. G.3a-OPTION-B.
--- @param cvarName string
--- @return boolean success
function CPM:RedoPrevious(cvarName)
    local S = GRIPEMS.Settings
    if not S or not cvarName then
        return false
    end
    if self:IsPinned(cvarName) then
        return false
    end
    local redo = S:Get("cvarRedoValues") or {}
    local val = redo[cvarName]
    if val == nil then
        return false
    end
    if InCombatLockdown() and CPM.IsCVarSecure(cvarName) then
        return false
    end
    local liveBeforeRedo = GetCVar(cvarName)
    if liveBeforeRedo ~= nil then
        local prev = S:Get("cvarPreviousValues") or {}
        prev[cvarName] = liveBeforeRedo
        S:Set("cvarPreviousValues", prev)
    end
    SetCVar(cvarName, val)
    redo[cvarName] = nil
    S:Set("cvarRedoValues", redo)
    if GRIPEMS.Fire then
        GRIPEMS:Fire("CVAR_REDO_APPLIED", cvarName)
    end
    return true
end

--- Drop cvarRedoValues entries whose cached value matches the current
--- live GetCVar value. Stale entries are no-ops on Redo and waste
--- SavedVariable space. G.3a-OPTION-B mirror of PruneStalePreviousValues.
--- @return number pruned
function CPM:PruneStaleRedoValues()
    local S = GRIPEMS.Settings
    if not S then
        return 0
    end
    local redo = S:Get("cvarRedoValues") or {}
    local pruned = 0
    for cvarName, cachedValue in pairs(redo) do
        local current = GetCVar(cvarName)
        if current and D.CvarMatch and D.CvarMatch(current, cachedValue) then
            redo[cvarName] = nil
            pruned = pruned + 1
        end
    end
    if pruned > 0 then
        S:Set("cvarRedoValues", redo)
    end
    return pruned
end

--- Drop cvarPreviousValues entries whose cached value matches the current
--- live GetCVar value (under D.CvarMatch normalization). Stale entries are
--- no-ops on Undo and waste SavedVariable space. Side-effect only on stale
--- entries; returns the number of pruned entries for diagnostic surfacing.
--- G.3a-POLISH-CACHE-CLEANUP (L370). Called from the 5-min in-session ticker.
--- @return number pruned
function CPM:PruneStalePreviousValues()
    local S = GRIPEMS.Settings
    if not S then
        return 0
    end
    local prev = S:Get("cvarPreviousValues") or {}
    local pruned = 0
    for cvarName, cachedValue in pairs(prev) do
        local current = GetCVar(cvarName)
        if current and D.CvarMatch and D.CvarMatch(current, cachedValue) then
            prev[cvarName] = nil
            pruned = pruned + 1
        end
    end
    if pruned > 0 then
        S:Set("cvarPreviousValues", prev)
    end
    return pruned
end

--------------------------------------------------------------------------------
-- G17: Pin My Choice (intentional-override flag backend)
--------------------------------------------------------------------------------

--- True if the user has pinned this CVar as an intentional override.
--- Pinned CVars are skipped by all Fix paths and ApplyProfile, and credited
--- as "matched" by the health score regardless of actual value.
--- @param cvarName string
--- @return boolean
function CPM:IsPinned(cvarName)
    local S = GRIPEMS.Settings
    if not S or not cvarName then
        return false
    end
    local pinned = S:Get("cvarPinned") or {}
    return pinned[cvarName] == true
end

--- Toggle the pinned flag for a CVar.
--- @param cvarName string
--- @param pinned boolean
function CPM:SetPinned(cvarName, pinned)
    local S = GRIPEMS.Settings
    if not S or not cvarName then
        return
    end
    local p = S:Get("cvarPinned") or {}
    if pinned then
        p[cvarName] = true
    else
        p[cvarName] = nil
    end
    S:Set("cvarPinned", p)
    if GRIPEMS.Fire then
        GRIPEMS:Fire("CVAR_PINNED_CHANGED", cvarName, pinned and true or false)
    end
end

--- Get the full pinned-CVar table (for iteration in score calc).
--- Returns the live SavedVariable table; callers must not mutate it directly.
--- @return table
function CPM:GetPinned()
    local S = GRIPEMS.Settings
    if not S then
        return {}
    end
    return S:Get("cvarPinned") or {}
end

--------------------------------------------------------------------------------
-- G12: Reset-to-Defaults (target collection + side-effect helpers)
--------------------------------------------------------------------------------

--- Build the target list for the Reset-to-Defaults action.
--- Walks D.CVAR_SECTIONS and returns every recommended CVar that:
---   - has a Blizzard-shipped default available via C_CVar.GetCVarDefault,
---   - currently differs from that default (CvarMatch normalisation),
---   - is not pinned (G17 intentional override survives reset),
---   - and is not the SQW Optimizer-managed SpellQueueWindow when SQW is active.
--- Each target is { cvar = <name>, default = <string> }. Caller is responsible
--- for combat checks and the throttled SetCVar burst.
--- @return table targets list of { cvar = string, default = string }
function CPM:GetResetToDefaultsTargets()
    local targets = {}
    for _, section in ipairs(D.CVAR_SECTIONS) do
        for _, rec in ipairs(section.cvars) do
            local default = GetCVarDefault and GetCVarDefault(rec.cvar)
            if default ~= nil then
                local current = GetCVar(rec.cvar)
                if not D.CvarMatch(current or "", default) then
                    if not self:IsPinned(rec.cvar) then
                        if
                            not (
                                rec.cvar == "SpellQueueWindow"
                                and GRIPEMS.SQWOptimizer
                                and GRIPEMS.SQWOptimizer:IsActive()
                            )
                        then
                            table.insert(targets, { cvar = rec.cvar, default = default })
                        end
                    end
                end
            end
        end
    end
    return targets
end

--- Wipe the per-CVar auto-fix opt-in table.
--- Called as a Reset-to-Defaults side effect so the next login does NOT
--- re-undo a deliberate reset by re-applying the recommendation under the
--- Auto-Fix-on-Login path. Pinned overrides survive: cvarPinned is a
--- separate SV and is intentionally not touched here.
function CPM:ClearAutoFixEntries()
    local S = GRIPEMS.Settings
    if not S then
        return
    end
    S:Set("cvarAutoFixEntries", {})
end

--- Re-snapshot the current CVar values into cvarSnapshot.
--- Called as a Reset-to-Defaults side effect so the next session's
--- What Changed banner does not flag the deliberate reset as user-driven
--- drift. Mirrors the snapshot tail of CPM:DetectChanges. self.pendingChanges
--- is intentionally preserved so any unread entries from PLAYER_LOGIN survive
--- until the user dismisses What Changed manually.
function CPM:RebuildSnapshot()
    local S = GRIPEMS.Settings
    if not S then
        return
    end
    local newSnapshot = {}
    for _, section in ipairs(D.CVAR_SECTIONS) do
        for _, rec in ipairs(section.cvars) do
            newSnapshot[rec.cvar] = GetCVar(rec.cvar)
        end
    end
    S:Set("cvarSnapshot", newSnapshot)
    S:Set("cvarSnapshotBuild", select(4, GetBuildInfo()))
    self._sessionSnapshot = newSnapshot
end

--------------------------------------------------------------------------------
-- G19/G20: Profile Diff + Export/Import
--------------------------------------------------------------------------------

--- Encode a CVar profile as a paste-string for sharing across characters.
--- Builds a payload table and runs it through the GRIPEMS.Serialization pipeline
--- (CBOR -> Compress -> Base64 -> !GEMSCP1! prefix). Works for both built-in
--- and custom profiles; the receiving end always lands the result as a new
--- custom_<name> profile via CPM:ImportProfile.
--- @param profileKey string Profile key to export
--- @return string|nil encoded Encoded string on success, nil on failure
--- @return string|nil err Error message when encoded is nil
function CPM:ExportProfile(profileKey)
    local profile = self:GetProfile(profileKey)
    if not profile then
        return nil, L["GEMS_CVAR_PROFILE_EXPORT_ERROR_NOT_FOUND"]
    end

    local payload = {
        format = "GEMSCP1",
        version = 1,
        label = profile.label,
        overrides = {},
    }
    local overrideCount = 0
    for cvar, val in pairs(profile.overrides or {}) do
        payload.overrides[cvar] = val
        overrideCount = overrideCount + 1
    end
    -- v2.3.3 Phase 1: parser metadata (ImportProfile ignores unknown keys;
    -- version stays 1). CVars are build-sensitive, so the full wowPatch /
    -- wowBuild / wowInterface triple ships here.
    payload.addonVersion = GRIPEMS.version
    payload.exportedAt = time()
    if GetBuildInfo then
        local wowPatch, wowBuild, _, wowInterface = GetBuildInfo()
        payload.wowPatch = wowPatch
        payload.wowBuild = wowBuild
        payload.wowInterface = wowInterface
    end
    local GE = GRIPEMS.GRIPExport
    local exportedBy = GE and GE.BuildExportedBy and GE.BuildExportedBy(nil) or nil
    if exportedBy then
        payload.author = exportedBy.name
    end
    payload.overrideCount = overrideCount

    local Serialization = GRIPEMS.Serialization
    if not Serialization or not Serialization.Encode then
        return nil, L["GEMS_CVAR_PROFILE_EXPORT_ERROR_NOT_FOUND"]
    end
    local ok, encoded = Serialization.Encode(payload, D.GEMSCP1_PREFIX)
    if not ok then
        return nil, encoded
    end
    return encoded
end

--- Decode a !GEMSCP1! paste-string and create a new custom profile from it.
--- The new profile is always created via CPM:CreateProfile so the "custom_"
--- prefix and dedup naming are enforced. Built-in profiles are never modified.
--- @param encodedString string The !GEMSCP1! paste-string
--- @param customLabel string|nil Optional override for the embedded label
--- @return string|nil newKey The new custom profile key, or nil on failure
--- @return number|string countOrErr Override count on success, error message on failure
function CPM:ImportProfile(encodedString, customLabel)
    if type(encodedString) ~= "string" or encodedString == "" then
        return nil, L["GEMS_CVAR_PROFILE_IMPORT_ERROR_FORMAT"]
    end

    local Serialization = GRIPEMS.Serialization
    if not Serialization or not Serialization.Decode then
        return nil, L["GEMS_CVAR_PROFILE_IMPORT_ERROR_DECODE"]
    end

    local ok, payload, format = Serialization.Decode(encodedString)
    if not ok or format ~= "GEMSCP1" then
        return nil, L["GEMS_CVAR_PROFILE_IMPORT_ERROR_DECODE"]
    end

    if
        type(payload) ~= "table"
        or payload.format ~= "GEMSCP1"
        or type(payload.version) ~= "number"
        or payload.version > 1
        or type(payload.label) ~= "string"
        or type(payload.overrides) ~= "table"
    then
        return nil, L["GEMS_CVAR_PROFILE_IMPORT_ERROR_PAYLOAD"]
    end

    local label
    if type(customLabel) == "string" and strtrim(customLabel) ~= "" then
        label = strtrim(customLabel)
    elseif strtrim(payload.label) ~= "" then
        label = strtrim(payload.label)
    else
        label = "Imported Profile"
    end

    local newKey = self:CreateProfile(label, nil)
    if not newKey then
        return nil, L["GEMS_CVAR_PROFILE_IMPORT_ERROR_PAYLOAD"]
    end

    local count = 0
    for cvar, val in pairs(payload.overrides) do
        if type(cvar) == "string" then
            self:SetProfileOverride(newKey, cvar, tostring(val))
            count = count + 1
        end
    end

    return newKey, count
end

--------------------------------------------------------------------------------
-- Profile Lookup
--------------------------------------------------------------------------------

--- Look up a profile definition by key.
--- Checks built-in profiles first, then custom profiles in SavedVariables.
--- @param profileKey string|nil
--- @return table|nil profile {key, label, desc, icon, overrides}
function CPM:GetProfile(profileKey)
    if not profileKey then
        return nil
    end

    for _, p in ipairs(D.CVAR_PROFILES) do
        if p.key == profileKey then
            return p
        end
    end

    local S = GRIPEMS.Settings
    local custom = S and S:Get("cvarProfiles") or {}
    if custom[profileKey] then
        return custom[profileKey]
    end

    return nil
end

--- Resolve which profile key applies for a given context key.
--- Checks user overrides first, then built-in map, then context fallback chain.
--- @param contextKey string
--- @return string|nil profileKey (nil = General)
function CPM:ResolveProfile(contextKey)
    local S = GRIPEMS.Settings
    if not S then
        return nil
    end

    -- User override map takes priority
    local userMap = S:Get("cvarProfileMap") or {}
    if userMap[contextKey] then
        return userMap[contextKey]
    end

    -- Built-in map
    if D.CVAR_PROFILE_MAP[contextKey] then
        return D.CVAR_PROFILE_MAP[contextKey]
    end

    -- Walk the fallback chain (reuses existing CONTEXT_FALLBACKS)
    local chain = D.CONTEXT_FALLBACKS and D.CONTEXT_FALLBACKS[contextKey]
    if chain then
        for _, fallback in ipairs(chain) do
            if userMap[fallback] then
                return userMap[fallback]
            end
            if D.CVAR_PROFILE_MAP[fallback] then
                return D.CVAR_PROFILE_MAP[fallback]
            end
        end
    end

    return nil -- General (no profile)
end

--------------------------------------------------------------------------------
-- Profile Application
--------------------------------------------------------------------------------

--- Apply a profile: set override CVars, revert previous profile's CVars to General.
--- Combat-safe: secure CVars queue via OOCQueue.
--- @param profileKey string|nil Profile key to apply, nil = revert to General
function CPM:ApplyProfile(profileKey)
    local S = GRIPEMS.Settings
    if not S then
        return
    end

    local oldKey = S:Get("cvarActiveProfile")
    local oldProfile = self:GetProfile(oldKey)
    local newProfile = self:GetProfile(profileKey)

    -- Collect CVars to change: union of old overrides (revert) and new overrides (apply)
    local changes = {}

    -- Step 1: Revert old profile overrides to General recommendations
    if oldProfile and oldProfile.overrides then
        for cvar, _ in pairs(oldProfile.overrides) do
            local generalRec = self:GetGeneralRecommendation(cvar)
            if generalRec then
                changes[cvar] = generalRec
            end
        end
    end

    -- Step 2: Apply new profile overrides (overwrites any revert from Step 1)
    if newProfile and newProfile.overrides then
        for cvar, val in pairs(newProfile.overrides) do
            changes[cvar] = val
        end
    end

    -- Step 3: Apply changes (combat-safe)
    local applied, queued = 0, 0
    local applyDetails = {}
    local queuedDetails = {}
    for cvar, val in pairs(changes) do
        -- SQW Optimizer takes priority over profiles for SpellQueueWindow
        if not (cvar == "SpellQueueWindow" and GRIPEMS.SQWOptimizer and GRIPEMS.SQWOptimizer:IsActive()) then
            -- G17: pinned CVars are user-intentional overrides; profile changes never touch them.
            if not self:IsPinned(cvar) then
                local current = GetCVar(cvar)
                if current and not D.CvarMatch(current, val) then
                    if CPM.IsCVarSecure(cvar) and InCombatLockdown() then
                        -- Queue secure CVars for OOC application
                        local prevForUndo = current
                        GRIPEMS.OOCQueue:Add(function()
                            -- G7: capture prev inside the closure so the cache reflects
                            -- the value at SetCVar time, not at Add time. If the CVar
                            -- changed between Add and OOC fire, prev still tracks the
                            -- value present immediately before our SetCVar.
                            local prevAtFire = GetCVar(cvar)
                            if prevAtFire ~= nil then
                                local S2 = GRIPEMS.Settings
                                if S2 then
                                    local prev = S2:Get("cvarPreviousValues") or {}
                                    prev[cvar] = prevAtFire
                                    S2:Set("cvarPreviousValues", prev)
                                end
                            else
                                -- fallback to value captured before queueing
                                if prevForUndo ~= nil then
                                    local S2 = GRIPEMS.Settings
                                    if S2 then
                                        local prev = S2:Get("cvarPreviousValues") or {}
                                        prev[cvar] = prevForUndo
                                        S2:Set("cvarPreviousValues", prev)
                                    end
                                end
                            end
                            -- G.2b-POLISH-PROFILE-CAUSE-CATEGORY: stamp BEFORE SetCVar
                            -- so the cause marker is recorded even if SetCVar errors.
                            CPM:MarkProfileApplied(cvar)
                            SetCVar(cvar, val)
                            if GRIPEMS.ReloadGate and GRIPEMS.ReloadGate.Notify then
                                GRIPEMS.ReloadGate:Notify(
                                    "OOC_APPLIED",
                                    1,
                                    { { cvar = cvar, from = prevForUndo, to = val } }
                                )
                            end
                        end, "cvar_profile", cvar)
                        queued = queued + 1
                        table.insert(queuedDetails, { cvar = cvar, from = current, to = val })
                    else
                        self:CapturePrevious(cvar)
                        -- G.2b-POLISH-PROFILE-CAUSE-CATEGORY: stamp BEFORE SetCVar so
                        -- the cause marker is recorded even if SetCVar errors.
                        self:MarkProfileApplied(cvar)
                        SetCVar(cvar, val)
                        applied = applied + 1
                        table.insert(applyDetails, { cvar = cvar, from = current, to = val })
                    end
                end
            end
        end -- SQW optimizer skip guard
    end

    -- Update state
    S:Set("cvarActiveProfile", profileKey)

    -- Fire callback for UI refresh
    if GRIPEMS.Fire then
        GRIPEMS:Fire("CVAR_PROFILE_CHANGED", profileKey, oldKey)
    end

    -- Logging
    local label = newProfile and newProfile.label or L["GEMS_CVAR_PROFILE_GENERAL"]
    if applied > 0 or queued > 0 then
        GRIPEMS:Debug(string.format("CVar profile: %s (%d applied, %d queued)", tostring(label), applied, queued))
    end
    if queued > 0 then
        GRIPEMS:Print(string.format(L["GEMS_CVAR_PROFILE_QUEUED"], queued))
    end
    if applied > 0 and GRIPEMS.ReloadGate and GRIPEMS.ReloadGate.Notify then
        GRIPEMS.ReloadGate:Notify("PROFILE_SWAP", applied, applyDetails)
    end
    if queued > 0 and GRIPEMS.ReloadGate and GRIPEMS.ReloadGate.Notify then
        GRIPEMS.ReloadGate:Notify("OOC_QUEUED", queued, queuedDetails)
    end
end

--- Manually select a profile. Sets manual override flag.
--- @param profileKey string|nil Profile key, nil = General
function CPM:SetManualProfile(profileKey)
    local S = GRIPEMS.Settings
    if not S then
        return
    end

    S:Set("cvarManualOverride", true)
    self:ApplyProfile(profileKey)

    local profile = self:GetProfile(profileKey)
    local label = profile and profile.label or L["GEMS_CVAR_PROFILE_GENERAL"]
    GRIPEMS:Print(string.format(L["GEMS_CVAR_PROFILE_SWITCHED"], tostring(label)))
end

--- Clear manual override and re-evaluate current context.
function CPM:ClearManualOverride()
    local S = GRIPEMS.Settings
    if not S then
        return
    end

    S:Set("cvarManualOverride", false)

    -- Re-evaluate context if auto-switch is on
    if S:Get("cvarAutoSwitchEnabled") and GRIPEMS.Engine then
        local ctx = GRIPEMS.Engine.currentContext
        if ctx then
            local profileKey = self:ResolveProfile(ctx)
            local currentKey = S:Get("cvarActiveProfile")
            if profileKey ~= currentKey then
                self:ApplyProfile(profileKey)
            end
        end
    end
end

--------------------------------------------------------------------------------
-- Custom Profile CRUD
--------------------------------------------------------------------------------

--- Create a custom profile.
--- @param label string Display name for the profile
--- @param cloneFrom string|nil Profile key to clone overrides from
--- @return string|nil key The generated profile key, or nil on failure
function CPM:CreateProfile(label, cloneFrom)
    local S = GRIPEMS.Settings
    if not S or not label or label == "" then
        return nil
    end

    -- Generate key: custom_ + sanitized lowercase alphanumeric (max 32 chars)
    local sanitized = label:lower():gsub("[^%a%d]", "")
    if sanitized == "" then
        sanitized = "profile"
    end
    sanitized = sanitized:sub(1, 32)
    local baseKey = "custom_" .. sanitized

    -- Dedup: append _N if key exists
    local custom = S:Get("cvarProfiles") or {}
    local key = baseKey
    local n = 1
    while custom[key] do
        key = baseKey .. "_" .. n
        n = n + 1
    end

    -- Clone overrides from source profile if provided
    local overrides = {}
    if cloneFrom then
        local source = self:GetProfile(cloneFrom)
        if source and source.overrides then
            for cvar, val in pairs(source.overrides) do
                overrides[cvar] = val
            end
        end
    end

    -- Store in cvarProfiles
    custom[key] = { key = key, label = label, overrides = overrides }
    S:Set("cvarProfiles", custom)

    if GRIPEMS.Fire then
        GRIPEMS:Fire("CVAR_PROFILE_CHANGED", key)
    end

    return key
end

--- Delete a custom profile.
--- @param profileKey string Must start with "custom_"
function CPM:DeleteProfile(profileKey)
    local S = GRIPEMS.Settings
    if not S or not profileKey then
        return
    end

    -- Guard: only custom profiles can be deleted
    if profileKey:sub(1, 7) ~= "custom_" then
        return
    end

    -- If this is the active profile, revert to General first
    if S:Get("cvarActiveProfile") == profileKey then
        self:ApplyProfile(nil)
    end

    -- Remove from cvarProfiles
    local custom = S:Get("cvarProfiles") or {}
    custom[profileKey] = nil
    S:Set("cvarProfiles", custom)

    -- Clean up cvarProfileMap (remove any context mappings referencing this key)
    local profileMap = S:Get("cvarProfileMap") or {}
    local changed = false
    for ctx, pk in pairs(profileMap) do
        if pk == profileKey then
            profileMap[ctx] = nil
            changed = true
        end
    end
    if changed then
        S:Set("cvarProfileMap", profileMap)
    end

    if GRIPEMS.Fire then
        GRIPEMS:Fire("CVAR_PROFILE_CHANGED", nil, profileKey)
    end
end

--- Rename a custom profile (label only, key is immutable).
--- @param profileKey string Must start with "custom_"
--- @param newLabel string New display name
function CPM:RenameProfile(profileKey, newLabel)
    local S = GRIPEMS.Settings
    if not S or not profileKey or not newLabel or newLabel == "" then
        return
    end

    if profileKey:sub(1, 7) ~= "custom_" then
        return
    end

    local custom = S:Get("cvarProfiles") or {}
    if not custom[profileKey] then
        return
    end

    custom[profileKey].label = newLabel
    S:Set("cvarProfiles", custom)

    if GRIPEMS.Fire then
        GRIPEMS:Fire("CVAR_PROFILE_CHANGED", profileKey)
    end
end

--- Set or remove an override value on a custom profile.
--- @param profileKey string Must start with "custom_"
--- @param cvarName string CVar name
--- @param value string|nil Value to set, nil removes the override
function CPM:SetProfileOverride(profileKey, cvarName, value)
    local S = GRIPEMS.Settings
    if not S or not profileKey or not cvarName then
        return
    end

    if profileKey:sub(1, 7) ~= "custom_" then
        return
    end

    local custom = S:Get("cvarProfiles") or {}
    if not custom[profileKey] then
        return
    end

    if not custom[profileKey].overrides then
        custom[profileKey].overrides = {}
    end

    if value == nil then
        custom[profileKey].overrides[cvarName] = nil
    else
        custom[profileKey].overrides[cvarName] = tostring(value)
    end
    S:Set("cvarProfiles", custom)

    -- If this profile is currently active, re-apply
    if S:Get("cvarActiveProfile") == profileKey then
        self:ApplyProfile(profileKey)
    end
end

--------------------------------------------------------------------------------
-- Context Profile Map
--------------------------------------------------------------------------------

--- Set or clear a user override in the context-to-profile map.
--- @param contextKey string Context key (e.g. "Raid", "MythicPlus")
--- @param profileKey string|nil Profile key, nil clears the override
function CPM:SetContextMapping(contextKey, profileKey)
    local S = GRIPEMS.Settings
    if not S or not contextKey then
        return
    end

    local profileMap = S:Get("cvarProfileMap") or {}
    profileMap[contextKey] = profileKey
    S:Set("cvarProfileMap", profileMap)

    -- If this context is currently active and auto-switch is on, re-evaluate
    if S:Get("cvarAutoSwitchEnabled") and not S:Get("cvarManualOverride") then
        local Engine = GRIPEMS.Engine
        if Engine and Engine.currentContext == contextKey then
            local resolved = self:ResolveProfile(contextKey)
            local currentKey = S:Get("cvarActiveProfile")
            if resolved ~= currentKey then
                self:ApplyProfile(resolved)
            end
        end
    end
end

--------------------------------------------------------------------------------
-- Slash Command Handler
--------------------------------------------------------------------------------

--- Handle /gems cvar subcommands.
--- @param args string Arguments after "cvar"
function CPM:HandleSlashCommand(args)
    local sub, rest = (args or ""):match("^(%S+)%s*(.*)")
    sub = sub and sub:lower() or ""

    if sub == "profile" then
        local key = rest and rest:match("^%S+") or nil
        if not key or key == "general" then
            self:SetManualProfile(nil)
        else
            local profile = self:GetProfile(key)
            if profile then
                self:SetManualProfile(key)
            else
                GRIPEMS:Print(string.format(L["GEMS_CVAR_PROFILE_NOT_FOUND"], tostring(key)))
            end
        end
    elseif sub == "auto" then
        local S = GRIPEMS.Settings
        if S then
            local enabled = not S:Get("cvarAutoSwitchEnabled")
            S:Set("cvarAutoSwitchEnabled", enabled)
            if enabled then
                self:ClearManualOverride()
            end
            local state = enabled and "ON" or "OFF"
            GRIPEMS:Print(string.format(L["GEMS_CVAR_AUTO_TOGGLED"], state))
        end
    elseif sub == "changes" then
        if self.pendingChanges and #self.pendingChanges > 0 then
            for _, c in ipairs(self.pendingChanges) do
                local arrow = c.was .. " -> " .. (c.now or "?")
                GRIPEMS:Print(tostring(c.label) .. ": " .. arrow)
            end
        else
            GRIPEMS:Print(L["GEMS_CVAR_NO_CHANGES"])
        end
    elseif sub == "notice" then
        local S = GRIPEMS.Settings
        if S then
            local toggleArg = rest and rest:match("^%S+")
            toggleArg = toggleArg and toggleArg:lower() or nil
            local enabled
            if toggleArg == "on" then
                enabled = true
            elseif toggleArg == "off" then
                enabled = false
            else
                enabled = not S:Get("cvarSessionChangeNotice")
            end
            S:Set("cvarSessionChangeNotice", enabled)
            local state = enabled and "ON" or "OFF"
            GRIPEMS:Print(string.format(L["GEMS_CVAR_NOTICE_TOGGLED"], state))
        end
    else
        GRIPEMS:Print("Usage: /gems cvar profile [key|general]")
        GRIPEMS:Print("       /gems cvar auto")
        GRIPEMS:Print("       /gems cvar changes")
        GRIPEMS:Print("       /gems cvar notice [on|off]")
    end
end

--------------------------------------------------------------------------------
-- Context-Aware Auto-Switching
--------------------------------------------------------------------------------

--- Initialize the CVar Profile Manager.
--- Registers CONTEXT_CHANGED callback for auto-switching.
function CPM:Initialize()
    if GRIPEMS.RegisterCallback then
        GRIPEMS.RegisterCallback(self, "CONTEXT_CHANGED", "OnContextChanged")
    end
    -- G.2a (G4): in-session re-snapshot every 5 minutes to detect CVar
    -- changes from other addons, /script, or in-game settings while
    -- the player is logged in. DetectChangesInSession is a no-op until
    -- self._sessionSnapshot is seeded by DetectChanges at PLAYER_LOGIN.
    if self._sessionTicker then
        self._sessionTicker:Cancel()
    end
    if C_Timer and C_Timer.NewTicker then
        self._sessionTicker = C_Timer.NewTicker(300, function()
            if self.DetectChangesInSession then
                self:DetectChangesInSession()
            end
            -- G.3a-POLISH-CACHE-CLEANUP (L370): drop stale cvarPreviousValues
            -- entries where cached == live (no-op on Undo, wasted SV space).
            if self.PruneStalePreviousValues then
                self:PruneStalePreviousValues()
            end
            -- G.3a-OPTION-B mirror: drop stale cvarRedoValues entries where
            -- cached == live (no-op on Redo, wasted SV space).
            if self.PruneStaleRedoValues then
                self:PruneStaleRedoValues()
            end
        end)
    end
end

--- Mark a CVar as auto-fixed by EMS this session.
--- Called by Core.lua's autoFix-on-login batch BEFORE each SetCVar.
--- Used by DetectChanges and DetectChangesInSession to attribute
--- cause = "AUTOFIX" for changes EMS itself made.
--- @param cvar string CVar name
function CPM:MarkAutoFixed(cvar)
    if not self.autoFixedThisSession then
        self.autoFixedThisSession = {}
    end
    self.autoFixedThisSession[cvar] = true
end

--- Mark a CVar as profile-applied this session.
--- Called by ApplyProfile BEFORE each SetCVar (immediate path) and inside the
--- OOCQueue closure (combat-deferred path). DetectChangesInSession reads this
--- marker to attribute cause = "PROFILE" for the change. The marker is cleared
--- at the end of each DetectChangesInSession tick so it does not stale-attribute
--- later manual changes to a profile-applied CVar.
--- @param cvar string CVar name
function CPM:MarkProfileApplied(cvar)
    if not self.profileAppliedThisSession then
        self.profileAppliedThisSession = {}
    end
    self.profileAppliedThisSession[cvar] = true
end

--- Build a human-readable trigger label for the active CVar profile.
--- Inspects cvarManualOverride + cvarAutoSwitchEnabled + GRIPEMS.Engine.currentContext.
--- Returns one of:
---   Manual selection
---   Auto-switch (<context label>)
---   Auto-switch (no active context)
---   Auto-switch off (last selection retained)
--- @return string localized trigger label
function CPM:GetActiveProfileCause()
    local S = GRIPEMS.Settings
    if not S then
        return ""
    end
    if S:Get("cvarManualOverride") then
        return L["GEMS_CVAR_PROFILE_TRIGGER_MANUAL"]
    end
    if S:Get("cvarAutoSwitchEnabled") then
        local Engine = GRIPEMS.Engine
        local context = Engine and Engine.currentContext
        if context and context ~= "none" and context ~= "" then
            local ctxLabel = (D.CONTEXT_LABELS and D.CONTEXT_LABELS[context]) or context
            return string.format(L["GEMS_CVAR_PROFILE_TRIGGER_AUTO"], ctxLabel)
        end
        return L["GEMS_CVAR_PROFILE_TRIGGER_AUTO_NO_CONTEXT"]
    end
    return L["GEMS_CVAR_PROFILE_TRIGGER_DISABLED"]
end

--- Handle context change: resolve and apply the appropriate profile.
--- Respects manual override and auto-switch toggle.
--- @param event string callback event name ("CONTEXT_CHANGED")
--- @param newContext string
--- @param oldContext string|nil
function CPM:OnContextChanged(event, newContext, oldContext)
    local S = GRIPEMS.Settings
    if not S then
        return
    end

    -- If auto-switching is disabled, do nothing
    if not S:Get("cvarAutoSwitchEnabled") then
        return
    end

    -- If user manually selected a profile, respect it
    if S:Get("cvarManualOverride") then
        return
    end

    local newProfileKey = self:ResolveProfile(newContext)
    local currentKey = S:Get("cvarActiveProfile")

    if newProfileKey == currentKey then
        return
    end

    self:ApplyProfile(newProfileKey)
end

--------------------------------------------------------------------------------
-- What Changed Detection
--------------------------------------------------------------------------------

--- Detect CVar changes since last session and take a new snapshot.
--- Called from Core.lua PLAYER_LOGIN handler (runs always, not gated behind
--- autoFixCVars, so What Changed detection works regardless of auto-fix setting).
function CPM:DetectChanges()
    local S = GRIPEMS.Settings
    if not S then
        return
    end

    local snapshot = S:Get("cvarSnapshot") or {}
    local snapshotBuild = S:Get("cvarSnapshotBuild")
    local currentBuild = select(4, GetBuildInfo())
    local buildDelta = snapshotBuild and currentBuild and snapshotBuild ~= currentBuild
    local changes = {}
    local newSnapshot = {}

    for _, section in ipairs(D.CVAR_SECTIONS) do
        for _, rec in ipairs(section.cvars) do
            local current = GetCVar(rec.cvar)
            newSnapshot[rec.cvar] = current

            if snapshot[rec.cvar] and snapshot[rec.cvar] ~= current then
                local cause
                if self.autoFixedThisSession and self.autoFixedThisSession[rec.cvar] then
                    cause = "AUTOFIX"
                elseif buildDelta then
                    cause = "PATCH"
                else
                    cause = "UNKNOWN"
                end
                table.insert(changes, {
                    cvar = rec.cvar,
                    label = rec.label,
                    section = section.label,
                    was = snapshot[rec.cvar],
                    now = current,
                    recommended = rec.recommended,
                    critical = rec.critical,
                    cause = cause,
                })
            end
        end
    end

    -- Always save a fresh snapshot
    S:Set("cvarSnapshot", newSnapshot)
    S:Set("cvarSnapshotBuild", currentBuild)
    self._sessionSnapshot = newSnapshot

    if #changes > 0 then
        self.pendingChanges = changes
        if GRIPEMS.Fire then
            GRIPEMS:Fire("CVAR_CHANGES_DETECTED", changes)
        end
        GRIPEMS:Print(string.format(L["GEMS_CVAR_CHANGES_DETECTED"], #changes))
    end
end

--- Detect CVar changes since the last in-session snapshot (5-minute interval).
--- Differs from DetectChanges (PLAYER_LOGIN) by comparing against an in-memory
--- snapshot rather than the persisted cvarSnapshot SV. Appends to pendingChanges
--- and fires CVAR_CHANGES_DETECTED so the What Changed button surfaces them.
--- No-op until self._sessionSnapshot is seeded by DetectChanges at PLAYER_LOGIN.
function CPM:DetectChangesInSession()
    local previous = self._sessionSnapshot
    if not previous then
        return
    end

    local newChanges = {}
    local newSnapshot = {}

    for _, section in ipairs(D.CVAR_SECTIONS) do
        for _, rec in ipairs(section.cvars) do
            local current = GetCVar(rec.cvar)
            newSnapshot[rec.cvar] = current

            if previous[rec.cvar] and previous[rec.cvar] ~= current then
                local cause
                -- G.2b-POLISH-PROFILE-CAUSE-CATEGORY: PROFILE wins over AUTOFIX wins
                -- over ADDON. A user-initiated profile swap stamps via MarkProfileApplied
                -- BEFORE SetCVar in ApplyProfile; an on-login auto-fix stamps via
                -- MarkAutoFixed; everything else is an external addon/UI write.
                if self.profileAppliedThisSession and self.profileAppliedThisSession[rec.cvar] then
                    cause = "PROFILE"
                elseif self.autoFixedThisSession and self.autoFixedThisSession[rec.cvar] then
                    cause = "AUTOFIX"
                else
                    cause = "ADDON"
                end
                table.insert(newChanges, {
                    cvar = rec.cvar,
                    label = rec.label,
                    section = section.label,
                    was = previous[rec.cvar],
                    now = current,
                    recommended = rec.recommended,
                    critical = rec.critical,
                    cause = cause,
                })
            end
        end
    end

    self._sessionSnapshot = newSnapshot

    if #newChanges > 0 then
        if not self.pendingChanges then
            self.pendingChanges = {}
        end
        -- G.2a-POLISH-PENDINGCHANGES-DEDUP: collapse repeat drift on the same CVar
        -- into one entry so the What Changed button prints one line per CVar.
        -- Update `now` to the latest value, preserve `was` (earliest baseline) so
        -- the user sees the full drift span (40 -> 60), not the most recent leg.
        for _, change in ipairs(newChanges) do
            local existing = nil
            for _, p in ipairs(self.pendingChanges) do
                if p.cvar == change.cvar then
                    existing = p
                    break
                end
            end
            if existing then
                existing.now = change.now
                existing.cause = change.cause or existing.cause
            else
                table.insert(self.pendingChanges, change)
            end
        end
        if GRIPEMS.Fire then
            GRIPEMS:Fire("CVAR_CHANGES_DETECTED", newChanges)
        end
        -- EMS-DISABLE-OR-QUIET-CVAR-CHANGED-SESSION-LOG: the 5-minute in-session
        -- notice is silent by default. Detection still fires CVAR_CHANGES_DETECTED
        -- (What Changed button) and populates pendingChanges (/gems cvar changes).
        -- Debug always logs the per-CVar detail (gated by the debug setting). The
        -- chat notice is opt-in via cvarSessionChangeNotice and names each changed
        -- CVar plus its cause (PROFILE / AUTOFIX / ADDON).
        local S = GRIPEMS.Settings
        local noticeOn = S and S:Get("cvarSessionChangeNotice")
        if noticeOn then
            GRIPEMS:Print(string.format(L["GEMS_CVAR_CHANGES_INSESSION"], #newChanges))
        end
        for _, c in ipairs(newChanges) do
            local arrow = tostring(c.was) .. " -> " .. tostring(c.now or "?")
            local causeKey = c.cause and ("GEMS_CVAR_CHANGES_CAUSE_" .. c.cause)
            local causeStr = (causeKey and L[causeKey]) or L["GEMS_CVAR_CHANGES_CAUSE_UNKNOWN"]
            GRIPEMS:Debug("CVar session change: %s: %s (%s)", tostring(c.label), arrow, causeStr)
            if noticeOn then
                GRIPEMS:Print(tostring(c.label) .. ": " .. arrow .. " (" .. causeStr .. ")")
            end
        end
    end

    -- G.2b-POLISH-PROFILE-CAUSE-CATEGORY: PROFILE marker is single-tick scoped;
    -- clear after this tick so a later manual change to a profile-applied CVar
    -- attributes as ADDON, not stale PROFILE.
    self.profileAppliedThisSession = nil
end
