-- GRIP-EMS: Spell Picker
-- Dropdown panel for browsing spells and inserting them (with optional
-- conditionals) into step EditBoxes. Integrates with StepListView and
-- PopupEditor via a small icon button next to each step's EditBox.
-- Created: 2026-03-31
-- Updated: 2026-06-29
-- Patch: 12.0.7.68275 Midnight (Retail LIVE)
--
-- Phase 2 #7: pushes a "SpellPicker" context on Show with the filter
-- buttons and close button as TAB targets; pops on Hide. OnKeyDown
-- routes TAB/ENTER/SPACE through GRIPEMS.Focus.

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

GRIPEMS.SpellPicker = {}
local SP = GRIPEMS.SpellPicker

---------------------------------------------------------------------------
-- Constants
---------------------------------------------------------------------------
local PICKER_WIDTH = 400
local PICKER_HEIGHT = 540
local SPELL_ROW_HEIGHT = 22
local ICON_SIZE = 20
-- MAX_VISIBLE_ROWS reserved for future scroll virtualization
local CONDITIONAL_BUTTONS = {
    "[mod:shift]",
    "[mod:ctrl]",
    "[mod:alt]",
    "[nomod]",
    "[harm]",
    "[help]",
    "[combat]",
    "[nocombat]",
    "[dead]",
    "[nodead]",
    "[channeling]",
    "[nochanneling]",
}

---------------------------------------------------------------------------
-- State
---------------------------------------------------------------------------
SP._frame = nil
SP._targetEditBox = nil
SP._filterMode = "Spec"
SP._searchText = ""
SP._scrollBox = nil
SP._spellData = {} -- filtered spell list for current display
-- Phase H1.9a: Spec filter sub-scope. "current" (default) shows only the
-- player's active-spec spells; "all" shows every spec-category entry; a
-- numeric string is a specID for a single off-spec view.
SP._specScope = "current"
-- Phase H1.9b: All Classes filter scope. "all" (default) browses every
-- class entry in the bundled CrossClassSpellCatalog; a class shortname
-- ("hunter", "mage", etc.) narrows the list to that class only. Resets
-- to "all" on every SP:Show so re-opening the picker is predictable.
SP._classScope = "all"

---------------------------------------------------------------------------
-- Accessibility helpers (reduce motion -- Phase 3 #12 Pass E)
---------------------------------------------------------------------------

local function reduceMotion()
    local S = GRIPEMS.Settings
    if not (S and S.Get) then
        return false
    end
    local a = S:Get("accessibility")
    return type(a) == "table" and a.reduceMotion and true or false
end

local function showWithMotion(frame)
    local target = (GRIPEMS.UI and GRIPEMS.UI.GetPanelAlpha and GRIPEMS.UI:GetPanelAlpha()) or 1.0
    frame:SetAlpha(0)
    frame:Show()
    if reduceMotion() or type(UIFrameFadeIn) ~= "function" then
        frame:SetAlpha(target)
        return
    end
    UIFrameFadeIn(frame, 0.12, 0, target)
end

---------------------------------------------------------------------------
-- Insert text at cursor position in the target EditBox
---------------------------------------------------------------------------

--- Insert text into the target EditBox. Focus is taken FIRST so WoW inserts at the
--- cursor instead of appending at the end of an unfocused box. If the box had a
--- text selection when it lost focus (captured by Focus:HookSelectionCapture),
--- re-create that selection so Insert replaces it; otherwise restore the captured
--- caret so a no-selection pick inserts at the cursor, not the end.
--- @param text string Text to insert
function SP:InsertText(text)
    local eb = self._targetEditBox
    if not eb then
        return
    end
    eb:SetFocus()
    local range = eb._gemsSelRange
    if range then
        eb._gemsSelRange = nil
        eb:HighlightText(range[1], range[2])
    elseif eb._gemsSelCursor then
        eb:SetCursorPosition(eb._gemsSelCursor)
    end
    eb._gemsSelCursor = nil
    eb:Insert(text)
end

---------------------------------------------------------------------------
-- Spell filtering
---------------------------------------------------------------------------

--- Collect gear entries (equipped on-use items).
--- @param search string Lowercase search filter
--- @return table Array of gear entries
local function CollectGear(search)
    local results = {}
    for slot = 1, 19 do
        local itemID = GetInventoryItemID("player", slot)
        if itemID then
            local useSpell = GetItemSpell(itemID)
            if useSpell then
                local classID = select(6, C_Item.GetItemInfoInstant(itemID))
                if classID == 2 or classID == 4 then
                    local name = C_Item.GetItemInfo(itemID)
                    if name and (search == "" or name:lower():find(search, 1, true)) then
                        results[#results + 1] = {
                            name = name,
                            spellID = itemID,
                            iconID = GetItemIcon(itemID),
                            _isItem = true,
                        }
                    end
                end
            end
        end
    end
    return results
end

--- Collect consumable entries (bag usable items with classID 0).
--- @param search string Lowercase search filter
--- @return table Array of consumable entries
local function CollectConsumables(search)
    local results = {}
    local seen = {}
    for bag = 0, 5 do
        local numSlots = C_Container.GetContainerNumSlots(bag)
        for slot = 1, numSlots do
            local info = C_Container.GetContainerItemInfo(bag, slot)
            if info and info.itemID and not seen[info.itemID] then
                seen[info.itemID] = true
                local useSpell = GetItemSpell(info.itemID)
                if useSpell then
                    local classID = select(6, C_Item.GetItemInfoInstant(info.itemID))
                    if classID == 0 then
                        local name = C_Item.GetItemInfo(info.itemID)
                        if name and (search == "" or name:lower():find(search, 1, true)) then
                            results[#results + 1] = {
                                name = name,
                                spellID = info.itemID,
                                iconID = GetItemIcon(info.itemID),
                                _isItem = true,
                            }
                        end
                    end
                end
            end
        end
    end
    return results
end

--- Collect generic "Items" entries (bag + warbank, classID not 0/2/4).
--- @param search string Lowercase search filter
--- @return table Array of item entries
local function CollectItems(search)
    local results = {}
    local seen = {}
    local bags = { 0, 1, 2, 3, 4, 5 }
    -- Add warbank tabs if available
    if Enum.BagIndex and Enum.BagIndex.AccountBankTab_1 then
        for tab = Enum.BagIndex.AccountBankTab_1, Enum.BagIndex.AccountBankTab_5 do
            bags[#bags + 1] = tab
        end
    end
    for _, bag in ipairs(bags) do
        local numSlots = C_Container.GetContainerNumSlots(bag)
        for slot = 1, numSlots do
            local info = C_Container.GetContainerItemInfo(bag, slot)
            if info and info.itemID and not seen[info.itemID] then
                seen[info.itemID] = true
                local useSpell = GetItemSpell(info.itemID)
                if useSpell then
                    local classID = select(6, C_Item.GetItemInfoInstant(info.itemID))
                    if classID ~= 0 and classID ~= 2 and classID ~= 4 then
                        local name = C_Item.GetItemInfo(info.itemID)
                        if name and (search == "" or name:lower():find(search, 1, true)) then
                            results[#results + 1] = {
                                name = name,
                                spellID = info.itemID,
                                iconID = GetItemIcon(info.itemID),
                                _isItem = true,
                            }
                        end
                    end
                end
            end
        end
    end
    return results
end

--- Collect toy entries from SpellCache.toyByName.
--- @param search string Lowercase search filter
--- @return table Array of toy entries
local function CollectToys(search)
    local SC = GRIPEMS.SpellCache
    local results = {}
    if not SC or not SC.toyByName then
        return results
    end
    -- OPP-01: ensure cache is built on first picker read
    if SC.EnsureToyCache then
        SC:EnsureToyCache()
    end
    for _, toyItemID in pairs(SC.toyByName) do
        local _, properName, toyIcon = C_ToyBox.GetToyInfo(toyItemID)
        if properName and (search == "" or properName:lower():find(search, 1, true)) then
            results[#results + 1] = {
                name = properName,
                spellID = toyItemID,
                iconID = toyIcon,
                _isToy = true,
            }
        end
    end
    return results
end

--- Collect mount entries from SpellCache.mounts.
--- @param search string Lowercase search filter
--- @return table Array of mount entries
local function CollectMounts(search)
    local SC = GRIPEMS.SpellCache
    local results = {}
    if not SC or not SC.mounts then
        return results
    end
    -- OPP-01: ensure cache is built on first picker read
    if SC.EnsureMountCache then
        SC:EnsureMountCache()
    end
    for _, m in ipairs(SC.mounts) do
        if search == "" or m.name:lower():find(search, 1, true) then
            results[#results + 1] = {
                name = m.name,
                spellID = m.spellID,
                iconID = m.iconID,
                _isMount = true,
            }
        end
    end
    return results
end

--- Collect companion entries from SpellCache.companions.
--- @param search string Lowercase search filter
--- @return table Array of companion entries
local function CollectCompanions(search)
    local SC = GRIPEMS.SpellCache
    local results = {}
    if not SC or not SC.companions then
        return results
    end
    -- OPP-01: ensure cache is built on first picker read
    if SC.EnsureCompanionCache then
        SC:EnsureCompanionCache()
    end
    for _, c in ipairs(SC.companions) do
        if search == "" or c.name:lower():find(search, 1, true) then
            results[#results + 1] = {
                name = c.name,
                spellID = c.spellID,
                iconID = c.iconID,
                petID = c.petID,
                _isCompanion = true,
            }
        end
    end
    return results
end

--- Category key mapping for spellbook-based filter modes
local CATEGORY_MAP = {
    Spec = "spec",
    Class = "class",
    Race = "racial",
    Pet = "pet",
    Prof = "profession",
}

---------------------------------------------------------------------------
-- Custom spell reference helper (Phase H1.7)
-- Pure lookup used by the Custom tab to cross-fill its two fields.
-- customResolveFromID: numeric spell ID -> spell name via C_Spell.GetSpellInfo.
-- Returns nil on failure; the caller paints the unresolved status row.
-- Phase H4-cleanup: customResolveFromName + runResolveFromName removed; the
-- customSearchByPrefix substring-search path (Phase H1.7.1) replaced the
-- exact-match name-to-ID lookup.
---------------------------------------------------------------------------
local function customResolveFromID(id)
    if type(id) ~= "number" or id <= 0 then
        return nil
    end
    if not C_Spell or not C_Spell.GetSpellInfo then
        return nil
    end
    local info = C_Spell.GetSpellInfo(id)
    return info and info.name or nil
end

---------------------------------------------------------------------------
-- Custom Name field substring search (Phase H1.7.1)
-- Walks the active-spec SpellCache UNION the CrossClassSpellCatalog and
-- returns every entry whose name contains the query as a case-insensitive
-- substring. plain=true on string.find keeps Lua pattern metachars in the
-- user query literal so input like "Death-" or "Death.X" does not break.
---------------------------------------------------------------------------
local function customSearchByPrefix(query)
    if type(query) ~= "string" or query == "" then
        return {}
    end
    local lowered = query:lower()
    local results = {}
    local seen = {}
    local SC = GRIPEMS.SpellCache
    if SC and SC.spells then
        for _, e in ipairs(SC.spells) do
            if e.name and e.name:lower():find(lowered, 1, true) then
                if not seen[e.spellID] then
                    seen[e.spellID] = true
                    results[#results + 1] = { id = e.spellID, name = e.name }
                end
            end
        end
    end
    local CC = GRIPEMS.CrossClassSpellCatalog
    if CC then
        for _, e in ipairs(CC) do
            if e.n and e.n:lower():find(lowered, 1, true) then
                if not seen[e.id] then
                    seen[e.id] = true
                    results[#results + 1] = { id = e.id, name = e.n }
                end
            end
        end
    end
    return results
end

---------------------------------------------------------------------------
-- Spec scope helper (Phase H1.9a)
-- Resolves the player's class specs once per addon load via
-- C_SpecializationInfo.GetSpecializationInfo. Cached on SP._specCache so
-- the dropdown menu builder is a cheap table read after the first call.
-- Returns a list of { specID, specIndex, name } in spec-index order.
---------------------------------------------------------------------------
local function getClassSpecList()
    if SP._specCache then
        return SP._specCache
    end
    local list = {}
    local numSpecs = (GetNumSpecializations and GetNumSpecializations()) or 0
    for i = 1, numSpecs do
        if C_SpecializationInfo and C_SpecializationInfo.GetSpecializationInfo then
            local specID, specName = C_SpecializationInfo.GetSpecializationInfo(i)
            if specID then
                list[#list + 1] = { specID = specID, specIndex = i, name = specName or "" }
            end
        elseif GetSpecializationInfo then
            local specID, specName = GetSpecializationInfo(i)
            if specID then
                list[#list + 1] = { specID = specID, specIndex = i, name = specName or "" }
            end
        end
    end
    SP._specCache = list
    return list
end

---------------------------------------------------------------------------
-- Class list (Phase H1.9b)
-- Hard-coded list of every class shortname that appears in the bundled
-- CrossClassSpellCatalog, in catalog walk order. The shortname is the
-- catalog's `c` field; the classFile is the WoW client constant used to
-- look up LOCALIZED_CLASS_NAMES_MALE. ASCII fallback names cover the
-- case where the global table is nil during very early load.
---------------------------------------------------------------------------
local CLASS_SHORTNAMES = {
    { shortname = "deathknight", classFile = "DEATHKNIGHT", fallback = "Death Knight" },
    { shortname = "demonhunter", classFile = "DEMONHUNTER", fallback = "Demon Hunter" },
    { shortname = "druid", classFile = "DRUID", fallback = "Druid" },
    { shortname = "evoker", classFile = "EVOKER", fallback = "Evoker" },
    { shortname = "hunter", classFile = "HUNTER", fallback = "Hunter" },
    { shortname = "mage", classFile = "MAGE", fallback = "Mage" },
    { shortname = "monk", classFile = "MONK", fallback = "Monk" },
    { shortname = "paladin", classFile = "PALADIN", fallback = "Paladin" },
    { shortname = "priest", classFile = "PRIEST", fallback = "Priest" },
    { shortname = "rogue", classFile = "ROGUE", fallback = "Rogue" },
    { shortname = "shaman", classFile = "SHAMAN", fallback = "Shaman" },
    { shortname = "warlock", classFile = "WARLOCK", fallback = "Warlock" },
    { shortname = "warrior", classFile = "WARRIOR", fallback = "Warrior" },
}

local function classDisplayName(shortname)
    if not shortname then
        return ""
    end
    for _, entry in ipairs(CLASS_SHORTNAMES) do
        if entry.shortname == shortname then
            local localized = LOCALIZED_CLASS_NAMES_MALE and LOCALIZED_CLASS_NAMES_MALE[entry.classFile]
            if localized and localized ~= "" then
                return localized
            end
            return entry.fallback
        end
    end
    return shortname
end

local function getClassList()
    if SP._classListCache then
        return SP._classListCache
    end
    local list = {}
    for _, entry in ipairs(CLASS_SHORTNAMES) do
        list[#list + 1] = {
            shortname = entry.shortname,
            classFile = entry.classFile,
            name = classDisplayName(entry.shortname),
        }
    end
    SP._classListCache = list
    return list
end

-- Expose the resolver so InitSpellRow can pull localized class names off
-- the SP namespace without a closure (the row initializer is declared
-- outside this closure scope).
SP._classDisplayName = classDisplayName

--- Get the filtered spell list based on current filter mode and search text.
--- @return table Array of spell entries matching current filters
local function GetFilteredSpells()
    local SC = GRIPEMS.SpellCache
    if not SC or not SC.spells then
        return {}
    end

    local results = {}
    local mode = SP._filterMode
    local search = SP._searchText:lower()

    -- Phase H1.9b: All Classes browse. Sources from the bundled
    -- GRIPEMS.CrossClassSpellCatalog instead of the active-spec spellbook
    -- cache, so the user can find cross-class spells by name regardless of
    -- the character's class. The class scope dropdown narrows the visible
    -- entries; "all" means every class. Cross-class entries also list pet
    -- shares via the catalog's `cs` array (e.g. Bite appears under DK and
    -- Hunter), so an entry passes the class filter if either its primary
    -- `c` matches or any `cs` entry matches. The branch short-circuits the
    -- spellbook walk below and runs its own alphabetical sort.
    if mode == "AllClasses" then
        local CC = GRIPEMS.CrossClassSpellCatalog
        if not CC then
            return results
        end
        local scope = SP._classScope or "all"
        for _, e in ipairs(CC) do
            local pass = true
            if scope ~= "all" then
                pass = (e.c == scope)
                if not pass and type(e.cs) == "table" then
                    for _, sh in ipairs(e.cs) do
                        if sh == scope then
                            pass = true
                            break
                        end
                    end
                end
            end
            if pass and search ~= "" then
                if not (e.n and e.n:lower():find(search, 1, true)) then
                    pass = false
                end
            end
            if pass then
                results[#results + 1] = {
                    spellID = e.id,
                    name = e.n,
                    iconID = (C_Spell and C_Spell.GetSpellTexture and C_Spell.GetSpellTexture(e.id)) or 134400,
                    _classKey = e.c,
                    _isCrossClass = true,
                }
            end
        end
        table.sort(results, function(a, b)
            return (a.name or ""):lower() < (b.name or ""):lower()
        end)
        return results
    end

    -- Spellbook-based modes (filter by category)
    local catKey = CATEGORY_MAP[mode]
    if catKey then
        for _, entry in ipairs(SC.spells) do
            local pass
            if catKey == "pet" then
                pass = entry.isPet or entry.category == "pet"
            else
                pass = entry.category == catKey
            end
            -- Phase H1.9a: Spec sub-scope filter. Applies only to the spec
            -- category (other catKeys are unaffected). Default scope is
            -- "current" so existing UX -- active-spec spells only -- is
            -- preserved. "all" surfaces every spec-tagged entry; a numeric
            -- string is a single off-spec view by specID.
            if pass and catKey == "spec" then
                local scope = SP._specScope or "current"
                if scope == "current" then
                    pass = entry.activeSpec == true
                elseif scope == "all" then
                    pass = entry.specID ~= nil
                else
                    local targetID = tonumber(scope)
                    pass = (targetID ~= nil) and (entry.specID == targetID)
                end
            end
            if pass and search ~= "" then
                if not entry.name:lower():find(search, 1, true) then
                    pass = false
                end
            end
            if pass then
                results[#results + 1] = entry
            end
        end
    elseif mode == "Gear" then
        results = CollectGear(search)
    elseif mode == "Consumables" then
        results = CollectConsumables(search)
    elseif mode == "Items" then
        results = CollectItems(search)
    elseif mode == "Toys" then
        results = CollectToys(search)
    elseif mode == "Mounts" then
        results = CollectMounts(search)
    elseif mode == "Companions" then
        results = CollectCompanions(search)
    elseif mode == "Macros" then
        local globalCount, perCharCount = GetNumMacros()
        local MAX_ACCOUNT = MAX_ACCOUNT_MACROS or 120
        for slot = 1, globalCount do
            local name, iconFileID, body = GetMacroInfo(slot)
            if name and (search == "" or name:lower():find(search, 1, true)) then
                results[#results + 1] = {
                    _isMacro = true,
                    macroSlot = slot,
                    macroScope = "account",
                    name = name,
                    iconID = iconFileID,
                    body = body,
                }
            end
        end
        for slot = MAX_ACCOUNT + 1, MAX_ACCOUNT + perCharCount do
            local name, iconFileID, body = GetMacroInfo(slot)
            if name and (search == "" or name:lower():find(search, 1, true)) then
                results[#results + 1] = {
                    _isMacro = true,
                    macroSlot = slot,
                    macroScope = "character",
                    name = name,
                    iconID = iconFileID,
                    body = body,
                }
            end
        end
    elseif mode == "Slash" then
        local seen = {}
        local function addSlash(slash)
            if type(slash) == "string" and slash:sub(1, 1) == "/" and not seen[slash] then
                seen[slash] = true
                if search == "" or slash:lower():find(search, 1, true) then
                    results[#results + 1] = {
                        _isSlash = true,
                        slash = slash,
                        name = slash,
                        iconID = 134400,
                    }
                end
            end
        end
        for key in pairs(SlashCmdList) do
            addSlash(_G["SLASH_" .. key .. "1"] or ("/" .. key:lower()))
        end
        if #results == 0 then
            for globalName, value in pairs(_G) do
                if type(globalName) == "string" and globalName:sub(1, 6) == "SLASH_" and globalName:sub(-1) == "1" then
                    addSlash(value)
                end
            end
        end
        table.sort(results, function(a, b)
            return (a.slash or "") < (b.slash or "")
        end)
    elseif mode == "Other" then
        for _, entry in ipairs(SC.spells) do
            local cat = entry.category
            if cat == "general" or cat == "other" then
                if search == "" or entry.name:lower():find(search, 1, true) then
                    results[#results + 1] = entry
                end
            end
        end
    end

    -- Sort all results alphabetically
    table.sort(results, function(a, b)
        return a.name:lower() < b.name:lower()
    end)

    return results
end

---------------------------------------------------------------------------
-- Row initializer (ScrollBox element)
---------------------------------------------------------------------------

local INT32_MAX = 2147483647
local function SafeSetSpellByID(spellID)
    if spellID and spellID > 0 and spellID <= INT32_MAX then
        GameTooltip:SetSpellByID(spellID)
        return true
    end
    return false
end

local function InitSpellRow(button, data)
    local UI2 = GRIPEMS.UI
    local C = UI2.Colors

    if not button._initialized then
        if not button.SetBackdrop then
            Mixin(button, BackdropTemplateMixin)
        end
        button:SetBackdrop(UI2.Backdrops.panelNoBorder)
        button:SetBackdropColor(0, 0, 0, 0)
        button:SetHeight(SPELL_ROW_HEIGHT)

        button.icon = button:CreateTexture(nil, "ARTWORK")
        button.icon:SetSize(ICON_SIZE, ICON_SIZE)
        button.icon:SetPoint("LEFT", button, "LEFT", 4, 0)

        button.nameLabel = button:CreateFontString(nil, "OVERLAY")
        UI2:SetFont(button.nameLabel, 11)
        button.nameLabel:SetPoint("LEFT", button.icon, "RIGHT", 4, 0)
        button.nameLabel:SetJustifyH("LEFT")
        button.nameLabel:SetWordWrap(false)

        button.idLabel = button:CreateFontString(nil, "OVERLAY")
        UI2:SetFont(button.idLabel, 9)
        button.idLabel:SetPoint("RIGHT", button, "RIGHT", -4, 0)
        button.idLabel:SetJustifyH("RIGHT")
        button.idLabel:SetTextColor(C.textMuted:GetRGBA())

        button._initialized = true
    end

    -- Icon
    button.icon:SetTexture(data.iconID or 134400)

    -- Name (truncate to prevent overflow into ID column)
    local displayName = data.name or ""
    if data.isPet then
        displayName = displayName .. " (Pet)"
    end
    -- Phase H1.9b: when a row comes from the cross-class catalog browse,
    -- append the source class in muted brackets so users can disambiguate
    -- shared spell names across classes (e.g. Bite [Hunter] vs Bite [DK]).
    -- Resolved through the SP namespace to keep this initializer free of
    -- closure dependencies on the CreatePickerFrame scope.
    if data._isCrossClass and data._classKey then
        local clsName = (
            GRIPEMS.SpellPicker
            and GRIPEMS.SpellPicker._classDisplayName
            and GRIPEMS.SpellPicker._classDisplayName(data._classKey)
        ) or ""
        if clsName ~= "" then
            displayName = displayName .. " [" .. clsName .. "]"
        end
    end
    if #displayName > 30 then
        displayName = displayName:sub(1, 28) .. ".."
    end
    button.nameLabel:SetText(displayName)
    button.nameLabel:SetTextColor(C.textPrimary:GetRGBA())
    button.nameLabel:SetPoint("RIGHT", button.idLabel, "LEFT", -4, 0)

    -- ID
    button.idLabel:SetText(data.spellID and tostring(data.spellID) or "")

    -- Tooltip
    button:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.bgRowHover:GetRGBA())
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        if data.isMacro then
            GameTooltip:SetText(data.name or "")
            if data.body and data.body ~= "" then
                GameTooltip:AddLine(data.body, 1, 1, 1, true)
            end
        elseif data.isSlash then
            GameTooltip:SetText(data.slash or data.name or "")
        elseif data.isCompanion then
            if data.petID then
                local ok = pcall(GameTooltip.SetCompanionPet, GameTooltip, data.petID)
                if not ok and data.spellID then
                    SafeSetSpellByID(data.spellID)
                end
            elseif data.spellID then
                SafeSetSpellByID(data.spellID)
            end
        elseif data.isItem then
            GameTooltip:SetItemByID(data.spellID)
        elseif data.isToy then
            GameTooltip:SetToyByItemID(data.spellID)
        elseif data.spellID then
            SafeSetSpellByID(data.spellID)
        end
        GameTooltip:Show()
    end)
    button:SetScript("OnLeave", function(self)
        self:SetBackdropColor(0, 0, 0, 0)
        GameTooltip:Hide()
    end)

    -- Click: insert slash command + name (or invoke callback in H1.6 callback mode)
    button:SetScript("OnClick", function()
        if SP._insertCallback then
            SP._insertCallback(data)
            return
        end
        if data.isMacro then
            SP:InsertText("/click " .. (data.name or ""))
            return
        elseif data.isSlash then
            SP:InsertText((data.slash or "") .. " ")
            return
        end
        local prefix
        if data.isMount then
            prefix = "/cast "
        elseif data.isCompanion then
            prefix = "/summonpet "
        elseif data.isToy then
            prefix = "/use "
        elseif data.isItem then
            prefix = "/use "
        else
            prefix = "/cast "
        end
        SP:InsertText(prefix .. (data.name or ""))
    end)
end

---------------------------------------------------------------------------
-- Refresh the spell list display
---------------------------------------------------------------------------
local function RefreshSpellList()
    if SP._filterMode == "Custom" then
        return
    end
    local frame = SP._frame
    if not frame or not SP._scrollBox then
        return
    end

    SP._spellData = GetFilteredSpells()
    local data = SP._spellData

    if #data == 0 then
        if frame.noResultsLabel then
            frame.noResultsLabel:Show()
        end
        SP._scrollBox:SetDataProvider(CreateDataProvider())
        return
    end
    if frame.noResultsLabel then
        frame.noResultsLabel:Hide()
    end

    local visibleCount = math.min(#data, 500)
    local dp = CreateDataProvider()
    for i = 1, visibleCount do
        local entry = data[i]
        dp:Insert({
            name = entry.name,
            spellID = entry.spellID,
            iconID = entry.iconID,
            isMount = entry._isMount or false,
            isCompanion = entry._isCompanion or false,
            isItem = entry._isItem or false,
            isToy = entry._isToy or false,
            isPet = entry.isPet or false,
            isMacro = entry._isMacro or false,
            isSlash = entry._isSlash or false,
            petID = entry.petID,
            body = entry.body,
            slash = entry.slash,
            macroSlot = entry.macroSlot,
            -- Phase H1.9b: pass cross-class hints through to InitSpellRow so
            -- the row initializer can append the source-class suffix to the
            -- display name. nil for non-AllClasses entries.
            _isCrossClass = entry._isCrossClass or nil,
            _classKey = entry._classKey or nil,
        })
    end
    SP._scrollBox:SetDataProvider(dp)
end

---------------------------------------------------------------------------
-- Palette awareness (Phase 3 #12 Pass A)
-- Widgets that SetTextColor / SetBackdropColor at create time cache the
-- RGBA values; mutating UI.Colors in place via SetRGBA does not repaint
-- them. Re-apply explicit colors after UI:SetPalette fires, then force a
-- spell-row repaint via RefreshSpellList so visible rows pick up changes.
---------------------------------------------------------------------------
local function applyPalette(frame)
    if not frame then
        return
    end
    local UI2 = GRIPEMS.UI
    local C = UI2.Colors

    if frame.SetBackdropColor then
        frame:SetBackdropColor(C.bgMain:GetRGBA())
    end
    if frame.SetBackdropBorderColor then
        frame:SetBackdropBorderColor(C.border:GetRGBA())
    end

    if frame._title then
        frame._title:SetTextColor(C.textPrimary:GetRGBA())
    end

    if frame.searchBox then
        frame.searchBox:SetBackdropColor(C.bgInput:GetRGBA())
        frame.searchBox:SetBackdropBorderColor(C.border:GetRGBA())
        frame.searchBox:SetTextColor(C.textPrimary:GetRGBA())
        if frame.searchBox._placeholder then
            frame.searchBox._placeholder:SetTextColor(C.textMuted:GetRGBA())
        end
    end

    if frame._filterBtns then
        for _, btn in ipairs(frame._filterBtns) do
            if btn._filterKey == SP._filterMode then
                btn:SetBackdropColor(C.bgRowSelected:GetRGBA())
                if btn._label then
                    btn._label:SetTextColor(C.textPrimary:GetRGBA())
                end
            else
                btn:SetBackdropColor(0, 0, 0, 0)
                if btn._label then
                    btn._label:SetTextColor(C.textSecondary:GetRGBA())
                end
            end
        end
    end

    if frame.noResultsLabel then
        frame.noResultsLabel:SetTextColor(C.textMuted:GetRGBA())
    end

    if frame._condHeader then
        frame._condHeader:SetTextColor(C.textSecondary:GetRGBA())
    end

    if frame._condButtons then
        for _, entry in ipairs(frame._condButtons) do
            if entry.btn then
                entry.btn:SetBackdropColor(C.bgButton:GetRGBA())
            end
            if entry.label then
                entry.label:SetTextColor(C.textPrimary:GetRGBA())
            end
        end
    end

    if frame._customLabel then
        frame._customLabel:SetTextColor(C.textSecondary:GetRGBA())
    end

    if frame._customBox then
        frame._customBox:SetBackdropColor(C.bgInput:GetRGBA())
        frame._customBox:SetBackdropBorderColor(C.textMuted:GetRGBA())
        frame._customBox:SetTextColor(C.textPrimary:GetRGBA())
    end

    RefreshSpellList()
end

---------------------------------------------------------------------------
-- Create the picker frame (lazy, single instance)
---------------------------------------------------------------------------
local function CreatePickerFrame()
    if SP._frame then
        return SP._frame
    end

    local UI = GRIPEMS.UI
    local C = UI.Colors

    local frame = CreateFrame("Frame", "GRIPEMS_SpellPicker", UIParent, "BackdropTemplate")
    frame:SetSize(PICKER_WIDTH, PICKER_HEIGHT)
    frame:SetFrameStrata("DIALOG")
    frame:SetClampedToScreen(true)
    UI:ApplyBackdrop(frame, UI.Backdrops.panel, C.bgMain, C.border)
    if GRIPEMS.UI and GRIPEMS.UI.RegisterPanelFrame then
        GRIPEMS.UI:RegisterPanelFrame(frame, "panel", "panel.spellPicker")
    end
    frame:EnableKeyboard(true)
    frame:SetScript("OnKeyDown", function(self, key)
        if InCombatLockdown() then
            return
        end
        -- Suspenders layer: independent of the Focus flag, query WoW
        -- directly for any focused EditBox. If found, propagate the key
        -- and let the EditBox handle it.
        if GetCurrentKeyBoardFocus and GetCurrentKeyBoardFocus() then
            pcall(self.SetPropagateKeyboardInput, self, true)
            return
        end
        local Focus = GRIPEMS.Focus
        if Focus and Focus:IsEditBoxFocused() then
            pcall(self.SetPropagateKeyboardInput, self, true)
            return
        end
        if key == "ESCAPE" then
            self:Hide()
            pcall(self.SetPropagateKeyboardInput, self, false)
        elseif key == "TAB" and Focus then
            Focus:Cycle(IsShiftKeyDown() and -1 or 1)
            pcall(self.SetPropagateKeyboardInput, self, false)
        elseif key == "ENTER" then
            -- Normal mode: ENTER inserts a newline into the target macro
            -- EditBox (never chat). Custom sub-form: keep Activate so ENTER on
            -- the focused Apply button still submits the custom entry.
            if self._customForm and self._customForm:IsShown() then
                if Focus then
                    Focus:Activate()
                end
            else
                -- Normal mode: newline only when the target macro box is
                -- multiline (the /gems Steps-tab box). A single-line target
                -- (PopupEditor step row) gets nothing -- still consumed below, so
                -- ENTER never opens chat while the picker is open.
                local eb = SP._targetEditBox
                if eb and eb.IsMultiLine and eb:IsMultiLine() then
                    SP:InsertText("\n")
                end
            end
            pcall(self.SetPropagateKeyboardInput, self, false)
        elseif key == "SPACE" and Focus then
            Focus:Activate()
            pcall(self.SetPropagateKeyboardInput, self, false)
        else
            pcall(self.SetPropagateKeyboardInput, self, true)
        end
    end)
    frame:Hide()

    -- Phase 3 #12 Pass C: global ESC closure via UISpecialFrames. The
    -- existing OnKeyDown ESCAPE branch stays untouched -- it covers the
    -- focused case; this covers mouse-only users whose picker is not
    -- the keyboard-focus owner. Both call :Hide() so double-fire is a
    -- no-op.
    if not tContains(UISpecialFrames, "GRIPEMS_SpellPicker") then
        tinsert(UISpecialFrames, "GRIPEMS_SpellPicker")
    end

    -- Movable via title bar drag
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", function(self)
        self:StartMoving()
    end)
    frame:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
    end)

    -- Title
    local title = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(title, 12)
    title:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, -6)
    title:SetText(L["GEMS_SPELLPICKER_TITLE"])
    title:SetTextColor(C.textPrimary:GetRGBA())
    frame._title = title

    -- Close button
    local closeBtn = CreateFrame("Button", nil, frame)
    closeBtn:SetSize(16, 16)
    closeBtn:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -4, -4)
    closeBtn:SetNormalTexture("Interface\\Buttons\\UI-Panel-MinimizeButton-Up")
    closeBtn:SetScript("OnClick", function()
        frame:Hide()
    end)
    frame.closeBtn = closeBtn

    -- Help (?) button (Phase 3 #12 Pass D): opens the shared Help popover
    -- with section key "Picker". Mirrors the SequenceEditor tabBar helpBtn
    -- pattern from Phase 3 #11. Anchored left of closeBtn at (-22, -4).
    local helpBtn = UI:CreateButton(frame, L["ACCESS_HELP_BUTTON_LABEL"] or "?", 16, 16)
    helpBtn:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -22, -4)
    helpBtn:SetScript("OnClick", function()
        if GRIPEMS.Help then
            GRIPEMS.Help:Toggle("Picker", helpBtn)
        end
    end)
    helpBtn:SetScript("OnEnter", function(self)
        UI:ShowTooltip(self, L["ACCESS_HELP_BUTTON_TOOLTIP"] or "Help")
    end)
    helpBtn:SetScript("OnLeave", function()
        UI:HideTooltip()
    end)
    frame.helpBtn = helpBtn

    -- Search EditBox
    local searchBox = CreateFrame("EditBox", nil, frame, "BackdropTemplate")
    searchBox:SetSize(PICKER_WIDTH - 16, 22)
    searchBox:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, -24)
    searchBox:SetAutoFocus(false)
    searchBox:SetMaxLetters(50)
    UI:ApplyBackdrop(searchBox, UI.Backdrops.panel, C.bgInput, C.border)
    searchBox:SetTextInsets(6, 6, 2, 2)
    local fontPath = GRIPEMS.UI:GetFontPath()
    searchBox:SetFont(fontPath, 11, "")
    searchBox:SetTextColor(C.textPrimary:GetRGBA())

    -- Placeholder text
    searchBox._placeholder = searchBox:CreateFontString(nil, "OVERLAY")
    UI:SetFont(searchBox._placeholder, 11)
    searchBox._placeholder:SetPoint("LEFT", searchBox, "LEFT", 8, 0)
    searchBox._placeholder:SetText(L["GEMS_SPELLPICKER_SEARCH"])
    searchBox._placeholder:SetTextColor(C.textMuted:GetRGBA())

    searchBox:SetScript("OnTextChanged", function(self, userInput)
        local text = self:GetText() or ""
        if text == "" then
            self._placeholder:Show()
        else
            self._placeholder:Hide()
        end
        SP._searchText = text
        RefreshSpellList()
    end)
    searchBox:SetScript("OnEditFocusGained", function(self)
        self._placeholder:Hide()
    end)
    searchBox:SetScript("OnEditFocusLost", function(self)
        if (self:GetText() or "") == "" then
            self._placeholder:Show()
        end
    end)
    searchBox:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
    end)
    searchBox:SetScript("OnEnterPressed", function()
        -- ENTER while the picker is open inserts a newline into the target
        -- macro EditBox (never chat), even with the search box focused.
        -- The Custom sub-form keeps its own ENTER (submit), so skip there.
        if frame._customForm and frame._customForm:IsShown() then
            return
        end
        -- Single-line target (PopupEditor step row): do nothing. The search
        -- box keeps focus, so ENTER does not open chat either.
        local eb = SP._targetEditBox
        if eb and eb.IsMultiLine and eb:IsMultiLine() then
            SP:InsertText("\n")
        end
    end)
    frame.searchBox = searchBox
    GRIPEMS.Focus:HookEditBox(searchBox)

    -- Filter tabs (vertical rail on the left edge, 14 modes + Custom callback-only).
    -- Phase H1.7: Custom is appended unconditionally; SP:Show toggles its
    -- visibility based on opts.insertCallback so the default open path
    -- never exposes a free-form spell ID / Name entry surface.
    local filterModes = {
        { key = "Spec", label = L["GEMS_SPELLPICKER_SPEC"] },
        { key = "Class", label = L["GEMS_SPELLPICKER_CLASS"] },
        { key = "Race", label = L["GEMS_SPELLPICKER_RACE"] },
        { key = "Pet", label = L["GEMS_SPELLPICKER_PET"] },
        { key = "Prof", label = L["GEMS_SPELLPICKER_PROF"] },
        { key = "Other", label = L["GEMS_SPELLPICKER_OTHER"] },
        { key = "Gear", label = L["GEMS_SPELLPICKER_GEAR"] },
        { key = "Consumables", label = L["GEMS_SPELLPICKER_CONSUMABLES"] },
        { key = "Items", label = L["GEMS_SPELLPICKER_ITEMS"] },
        { key = "Toys", label = L["GEMS_SPELLPICKER_TOYS"] },
        { key = "Mounts", label = L["GEMS_SPELLPICKER_MOUNTS"] },
        { key = "Companions", label = L["GEMS_SPELLPICKER_COMPANIONS"] },
        { key = "Macros", label = L["GEMS_SPELLPICKER_MACROS"] },
        { key = "Slash", label = L["GEMS_SPELLPICKER_SLASH"] },
        -- Phase H1.9b: All Classes tab is sourced from the bundled
        -- CrossClassSpellCatalog (not the active-spec spellbook). Placed
        -- second-to-last so Custom remains the final entry that SP:Show
        -- can hide based on opts.insertCallback.
        { key = "AllClasses", label = L["GEMS_SPELLPICKER_ALLCLASSES"] },
        { key = "Custom", label = L["GEMS_IF_PICKER_CUSTOM_TAB"] or "Custom" },
    }
    local filterBtns = {}
    local TAB_RAIL_X = 8
    local TAB_RAIL_Y = -52
    local TAB_RAIL_WIDTH = 110
    local TAB_ROW_HEIGHT = 22
    local TAB_ROW_GAP = 2
    for idx, fm in ipairs(filterModes) do
        local btn = CreateFrame("Button", nil, frame, "BackdropTemplate")
        btn:SetSize(TAB_RAIL_WIDTH, TAB_ROW_HEIGHT)
        btn:SetBackdrop(UI.Backdrops.panelNoBorder)

        local btnLabel = btn:CreateFontString(nil, "OVERLAY")
        UI:SetFont(btnLabel, 10)
        btnLabel:SetPoint("LEFT", btn, "LEFT", 6, 0)
        btnLabel:SetText(fm.label)
        btnLabel:SetWidth(TAB_RAIL_WIDTH - 8)
        btnLabel:SetWordWrap(false)
        btn._label = btnLabel
        btn._filterKey = fm.key

        local rowGap = TAB_ROW_GAP + UI:GetRowGap()
        local yOffset = TAB_RAIL_Y - (idx - 1) * (TAB_ROW_HEIGHT + rowGap)
        btn:SetPoint("TOPLEFT", frame, "TOPLEFT", TAB_RAIL_X, yOffset)

        btn:SetScript("OnClick", function(self)
            SP._filterMode = self._filterKey
            for _, fb in ipairs(filterBtns) do
                if fb._filterKey == SP._filterMode then
                    fb:SetBackdropColor(C.bgRowSelected:GetRGBA())
                    fb._label:SetTextColor(C.textPrimary:GetRGBA())
                else
                    fb:SetBackdropColor(0, 0, 0, 0)
                    fb._label:SetTextColor(C.textSecondary:GetRGBA())
                end
            end
            -- Phase H1.7: Custom tab swaps the spell list for the side-by-side
            -- ID + Name form. All other tabs return to the spell list view.
            if SP._filterMode == "Custom" then
                if frame._customForm then
                    if frame._customForm._idBox then
                        frame._customForm._idBox:SetText("")
                    end
                    if frame._customForm._nameBox then
                        frame._customForm._nameBox:SetText("")
                    end
                    if frame._customForm._statusLabel then
                        frame._customForm._statusLabel:SetText("")
                    end
                    frame._customForm:Show()
                end
                if frame._customForm and frame._customForm._matchRows then
                    for _, row in ipairs(frame._customForm._matchRows) do
                        row:Hide()
                    end
                    if frame._customForm._matchScroll then
                        frame._customForm._matchScroll:Hide()
                    end
                end
                if SP._scrollBox then
                    SP._scrollBox:Hide()
                end
                if frame._scrollBar then
                    frame._scrollBar:Hide()
                end
                if frame.noResultsLabel then
                    frame.noResultsLabel:Hide()
                end
            else
                if frame._customForm then
                    frame._customForm:Hide()
                end
                if SP._scrollBox then
                    SP._scrollBox:Show()
                end
                if frame._scrollBar then
                    frame._scrollBar:Show()
                end
                RefreshSpellList()
            end
            -- Phase H1.9a: route through the shared helper so the OnClick
            -- and SP:Show paths stay in lockstep.
            if frame._applySpecScopeVisibility then
                frame._applySpecScopeVisibility(SP._filterMode == "Spec")
            end
            -- Phase H1.9b: sibling class-scope visibility call. Spec call
            -- runs first by design; the class helper's inactive branch
            -- avoids clobbering spec's scrollBox anchor when both fire on
            -- a Spec-tab click. Custom-tab activation correctly hides
            -- both dropdowns via these two false-evaluating calls.
            if frame._applyClassScopeVisibility then
                frame._applyClassScopeVisibility(SP._filterMode == "AllClasses")
            end
        end)

        filterBtns[idx] = btn
    end
    frame._filterBtns = filterBtns

    -- Set initial filter state
    filterBtns[1]:SetBackdropColor(C.bgRowSelected:GetRGBA())
    filterBtns[1]._label:SetTextColor(C.textPrimary:GetRGBA())
    for i = 2, #filterBtns do
        filterBtns[i]:SetBackdropColor(0, 0, 0, 0)
        filterBtns[i]._label:SetTextColor(C.textSecondary:GetRGBA())
    end

    ---------------------------------------------------------------------------
    -- Phase H1.9a: Spec scope dropdown
    -- Visible only when the Spec filter tab is active. Lets the user opt
    -- into off-spec spells via "All specs" or a single-spec view; default
    -- is "Current spec" which mirrors the pre-H1.9a UX exactly. Uses the
    -- modern MenuUtil.CreateContextMenu API matching the EMS codebase
    -- (StepListView, VariablesTab, etc.) rather than the deprecated
    -- EasyMenu / UIDropDownMenuTemplate pair.
    ---------------------------------------------------------------------------
    local specScopeFrame = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    specScopeFrame:SetSize(180, 22)
    specScopeFrame:SetPoint("TOPLEFT", frame, "TOPLEFT", TAB_RAIL_X + TAB_RAIL_WIDTH + 8, -52)
    specScopeFrame:Hide()
    frame._specScopeFrame = specScopeFrame

    local specScopeLabel = specScopeFrame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(specScopeLabel, 10)
    specScopeLabel:SetPoint("LEFT", specScopeFrame, "LEFT", 0, 0)
    specScopeLabel:SetText(L["GEMS_SPELLPICKER_SPEC_SCOPE_LABEL"] or "Scope:")
    specScopeLabel:SetTextColor(C.textSecondary:GetRGBA())

    local specScopeButton = CreateFrame("Button", nil, specScopeFrame, "BackdropTemplate")
    specScopeButton:SetSize(140, 22)
    specScopeButton:SetPoint("LEFT", specScopeLabel, "RIGHT", 6, 0)
    UI:ApplyBackdrop(specScopeButton, UI.Backdrops.panel, C.bgInput, C.border)

    local specScopeText = specScopeButton:CreateFontString(nil, "OVERLAY")
    UI:SetFont(specScopeText, 10)
    specScopeText:SetPoint("LEFT", specScopeButton, "LEFT", 6, 0)
    specScopeText:SetTextColor(C.textPrimary:GetRGBA())
    specScopeButton._label = specScopeText

    local specScopeArrow = specScopeButton:CreateFontString(nil, "OVERLAY")
    UI:SetFont(specScopeArrow, 9)
    specScopeArrow:SetPoint("RIGHT", specScopeButton, "RIGHT", -6, 0)
    specScopeArrow:SetText("v")
    specScopeArrow:SetTextColor(C.textSecondary:GetRGBA())

    local function updateSpecScopeLabel()
        local scope = SP._specScope or "current"
        if scope == "current" then
            specScopeText:SetText(L["GEMS_SPELLPICKER_SPEC_SCOPE_CURRENT"] or "Current spec")
            return
        elseif scope == "all" then
            specScopeText:SetText(L["GEMS_SPELLPICKER_SPEC_SCOPE_ALL"] or "All specs")
            return
        end
        local id = tonumber(scope)
        if id then
            for _, spec in ipairs(getClassSpecList()) do
                if spec.specID == id then
                    specScopeText:SetText(spec.name)
                    return
                end
            end
        end
        specScopeText:SetText(tostring(scope))
    end
    frame._updateSpecScopeLabel = updateSpecScopeLabel

    specScopeButton:SetScript("OnClick", function(self)
        MenuUtil.CreateContextMenu(self, function(_, rootDescription)
            rootDescription:CreateButton(L["GEMS_SPELLPICKER_SPEC_SCOPE_CURRENT"] or "Current spec", function()
                SP._specScope = "current"
                updateSpecScopeLabel()
                RefreshSpellList()
            end)
            rootDescription:CreateButton(L["GEMS_SPELLPICKER_SPEC_SCOPE_ALL"] or "All specs", function()
                SP._specScope = "all"
                updateSpecScopeLabel()
                RefreshSpellList()
            end)
            for _, spec in ipairs(getClassSpecList()) do
                local specID = spec.specID
                local specName = spec.name
                rootDescription:CreateButton(specName, function()
                    SP._specScope = tostring(specID)
                    updateSpecScopeLabel()
                    RefreshSpellList()
                end)
            end
        end)
    end)
    frame._specScopeButton = specScopeButton

    -- Phase H1.9a: shared show/hide + scrollBox re-anchor helper. Captured
    -- in the CreatePickerFrame closure so it has access to TAB_RAIL_X /
    -- TAB_RAIL_WIDTH for the re-anchor math. Called from the filter button
    -- OnClick and from SP:Show so the picker's first-frame state matches
    -- the default "Spec" filter mode.
    frame._applySpecScopeVisibility = function(active)
        if not frame._specScopeFrame then
            return
        end
        if active then
            frame._specScopeFrame:Show()
            if frame._updateSpecScopeLabel then
                frame._updateSpecScopeLabel()
            end
            if SP._scrollBox then
                SP._scrollBox:ClearAllPoints()
                SP._scrollBox:SetPoint("TOPLEFT", frame, "TOPLEFT", TAB_RAIL_X + TAB_RAIL_WIDTH + 8, -82)
                SP._scrollBox:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -22, 130)
            end
        else
            frame._specScopeFrame:Hide()
            if SP._scrollBox then
                SP._scrollBox:ClearAllPoints()
                SP._scrollBox:SetPoint("TOPLEFT", frame, "TOPLEFT", TAB_RAIL_X + TAB_RAIL_WIDTH + 8, -52)
                SP._scrollBox:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -22, 130)
            end
        end
    end

    ---------------------------------------------------------------------------
    -- Phase H1.9b: Class scope dropdown
    -- Visible only when the All Classes filter tab is active. Lets the
    -- user narrow the bundled CrossClassSpellCatalog browse to a single
    -- class via a 13-class list pulled from CLASS_SHORTNAMES. Default
    -- scope is "all" so the first open shows every entry. Uses the same
    -- MenuUtil.CreateContextMenu pattern as the H1.9a spec scope dropdown
    -- and occupies the SAME screen position (only one dropdown is ever
    -- visible at a time, gated by the filter tab in OnClick).
    ---------------------------------------------------------------------------
    local classScopeFrame = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    classScopeFrame:SetSize(180, 22)
    classScopeFrame:SetPoint("TOPLEFT", frame, "TOPLEFT", TAB_RAIL_X + TAB_RAIL_WIDTH + 8, -52)
    classScopeFrame:Hide()
    frame._classScopeFrame = classScopeFrame

    local classScopeLabel = classScopeFrame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(classScopeLabel, 10)
    classScopeLabel:SetPoint("LEFT", classScopeFrame, "LEFT", 0, 0)
    classScopeLabel:SetText(L["GEMS_SPELLPICKER_SPEC_SCOPE_LABEL"] or "Scope:")
    classScopeLabel:SetTextColor(C.textSecondary:GetRGBA())

    local classScopeButton = CreateFrame("Button", nil, classScopeFrame, "BackdropTemplate")
    classScopeButton:SetSize(140, 22)
    classScopeButton:SetPoint("LEFT", classScopeLabel, "RIGHT", 6, 0)
    UI:ApplyBackdrop(classScopeButton, UI.Backdrops.panel, C.bgInput, C.border)

    local classScopeText = classScopeButton:CreateFontString(nil, "OVERLAY")
    UI:SetFont(classScopeText, 10)
    classScopeText:SetPoint("LEFT", classScopeButton, "LEFT", 6, 0)
    classScopeText:SetTextColor(C.textPrimary:GetRGBA())
    classScopeButton._label = classScopeText

    local classScopeArrow = classScopeButton:CreateFontString(nil, "OVERLAY")
    UI:SetFont(classScopeArrow, 9)
    classScopeArrow:SetPoint("RIGHT", classScopeButton, "RIGHT", -6, 0)
    classScopeArrow:SetText("v")
    classScopeArrow:SetTextColor(C.textSecondary:GetRGBA())

    local function updateClassScopeLabel()
        local scope = SP._classScope or "all"
        if scope == "all" then
            classScopeText:SetText(L["GEMS_SPELLPICKER_CLASS_SCOPE_ALL"] or "All classes")
            return
        end
        classScopeText:SetText(classDisplayName(scope))
    end
    frame._updateClassScopeLabel = updateClassScopeLabel

    classScopeButton:SetScript("OnClick", function(self)
        MenuUtil.CreateContextMenu(self, function(_, rootDescription)
            rootDescription:CreateButton(L["GEMS_SPELLPICKER_CLASS_SCOPE_ALL"] or "All classes", function()
                SP._classScope = "all"
                updateClassScopeLabel()
                RefreshSpellList()
            end)
            for _, cls in ipairs(getClassList()) do
                local shortname = cls.shortname
                local label = cls.name
                rootDescription:CreateButton(label, function()
                    SP._classScope = shortname
                    updateClassScopeLabel()
                    RefreshSpellList()
                end)
            end
        end)
    end)
    frame._classScopeButton = classScopeButton

    -- Phase H1.9b: parallel sibling of _applySpecScopeVisibility. Same
    -- show/hide + scrollBox re-anchor math, but the inactive branch only
    -- resets the scrollBox to -52 when the spec dropdown is ALSO hidden.
    -- Reason: OnClick fires both helpers in sequence (spec first, class
    -- second). When filter=Spec, spec sets scrollBox to -82 and class is
    -- called with active=false; an unconditional -52 reset here would
    -- clobber the spec anchor. The guard keeps the two helpers
    -- non-interfering without touching the H1.9a code paths.
    frame._applyClassScopeVisibility = function(active)
        if not frame._classScopeFrame then
            return
        end
        if active then
            frame._classScopeFrame:Show()
            if frame._updateClassScopeLabel then
                frame._updateClassScopeLabel()
            end
            if SP._scrollBox then
                SP._scrollBox:ClearAllPoints()
                SP._scrollBox:SetPoint("TOPLEFT", frame, "TOPLEFT", TAB_RAIL_X + TAB_RAIL_WIDTH + 8, -82)
                SP._scrollBox:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -22, 130)
            end
        else
            frame._classScopeFrame:Hide()
            local specShown = frame._specScopeFrame and frame._specScopeFrame:IsShown()
            if SP._scrollBox and not specShown then
                SP._scrollBox:ClearAllPoints()
                SP._scrollBox:SetPoint("TOPLEFT", frame, "TOPLEFT", TAB_RAIL_X + TAB_RAIL_WIDTH + 8, -52)
                SP._scrollBox:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -22, 130)
            end
        end
    end

    ---------------------------------------------------------------------------
    -- Spell scroll area (ScrollBox + MinimalScrollBar)
    ---------------------------------------------------------------------------
    local scrollBox = CreateFrame("Frame", nil, frame, "WowScrollBoxList")
    scrollBox:SetPoint("TOPLEFT", frame, "TOPLEFT", TAB_RAIL_X + TAB_RAIL_WIDTH + 8, -52)
    scrollBox:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -22, 130)
    SP._scrollBox = scrollBox

    local scrollBar = CreateFrame("EventFrame", nil, frame, "MinimalScrollBar")
    scrollBar:SetPoint("TOPLEFT", scrollBox, "TOPRIGHT", 2, 0)
    scrollBar:SetPoint("BOTTOMLEFT", scrollBox, "BOTTOMRIGHT", 2, 0)
    frame._scrollBar = scrollBar

    local scrollView = CreateScrollBoxListLinearView()
    scrollView:SetElementExtent(SPELL_ROW_HEIGHT)
    scrollView:SetElementInitializer("Button", function(button, data)
        InitSpellRow(button, data)
    end)
    ScrollUtil.InitScrollBoxListWithScrollBar(scrollBox, scrollBar, scrollView)
    scrollBox:SetDataProvider(CreateDataProvider())

    ---------------------------------------------------------------------------
    -- Custom spell reference form (Phase H1.7)
    -- Side-by-side SpellID + Name surface that replaces the spell list when
    -- the Custom filter tab is active. Only reachable from callback mode
    -- (the Custom tab itself is hidden when SP._insertCallback is nil), so
    -- unvalidated raw values never reach the default /cast open path.
    ---------------------------------------------------------------------------
    local customForm = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    customForm:SetPoint("TOPLEFT", frame, "TOPLEFT", TAB_RAIL_X + TAB_RAIL_WIDTH + 8, -52)
    customForm:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -22, 130)
    customForm:Hide()
    frame._customForm = customForm

    local customHeader = customForm:CreateFontString(nil, "OVERLAY")
    UI:SetFont(customHeader, 12)
    customHeader:SetPoint("TOPLEFT", customForm, "TOPLEFT", 4, -4)
    customHeader:SetText(L["GEMS_IF_PICKER_CUSTOM_HEADER"] or "Custom spell reference")
    customHeader:SetTextColor(C.textPrimary:GetRGBA())
    customForm._header = customHeader

    local customHint = customForm:CreateFontString(nil, "OVERLAY")
    UI:SetFont(customHint, 9)
    customHint:SetPoint("TOPLEFT", customHeader, "BOTTOMLEFT", 0, -6)
    customHint:SetWidth(240)
    customHint:SetText(
        L["GEMS_IF_PICKER_CUSTOM_HINT"] or "Enter a spell ID or name. Either field fills the other when validated."
    )
    customHint:SetTextColor(C.textSecondary:GetRGBA())
    customHint:SetJustifyH("LEFT")
    customHint:SetWordWrap(true)
    customForm._hint = customHint

    local customIDLabel = customForm:CreateFontString(nil, "OVERLAY")
    UI:SetFont(customIDLabel, 10)
    customIDLabel:SetPoint("TOPLEFT", customHint, "BOTTOMLEFT", 0, -20)
    customIDLabel:SetText(L["GEMS_IF_PICKER_CUSTOM_ID_LABEL"] or "Spell ID")
    customIDLabel:SetTextColor(C.textSecondary:GetRGBA())
    customForm._idLabel = customIDLabel

    local customIDBox = CreateFrame("EditBox", nil, customForm, "BackdropTemplate")
    customIDBox:SetSize(110, 20)
    customIDBox:SetPoint("LEFT", customIDLabel, "RIGHT", 8, 0)
    customIDBox:SetAutoFocus(false)
    customIDBox:SetMaxLetters(12)
    customIDBox:SetNumeric(true)
    UI:ApplyBackdrop(customIDBox, UI.Backdrops.panel, C.bgInput, C.border)
    customIDBox:SetTextInsets(4, 4, 2, 2)
    customIDBox:SetFont(fontPath, 10, "")
    customIDBox:SetTextColor(C.textPrimary:GetRGBA())
    customIDBox:SetJustifyH("RIGHT")
    customForm._idBox = customIDBox

    local customNameLabel = customForm:CreateFontString(nil, "OVERLAY")
    UI:SetFont(customNameLabel, 10)
    customNameLabel:SetPoint("TOPLEFT", customIDLabel, "BOTTOMLEFT", 0, -14)
    customNameLabel:SetText(L["GEMS_IF_PICKER_CUSTOM_NAME_LABEL"] or "Name")
    customNameLabel:SetTextColor(C.textSecondary:GetRGBA())
    customForm._nameLabel = customNameLabel

    local customNameBox = CreateFrame("EditBox", nil, customForm, "BackdropTemplate")
    customNameBox:SetSize(160, 20)
    customNameBox:SetPoint("LEFT", customNameLabel, "RIGHT", 8, 0)
    customNameBox:SetAutoFocus(false)
    customNameBox:SetMaxLetters(60)
    UI:ApplyBackdrop(customNameBox, UI.Backdrops.panel, C.bgInput, C.border)
    customNameBox:SetTextInsets(4, 4, 2, 2)
    customNameBox:SetFont(fontPath, 10, "")
    customNameBox:SetTextColor(C.textPrimary:GetRGBA())
    customForm._nameBox = customNameBox

    local customStatus = customForm:CreateFontString(nil, "OVERLAY")
    UI:SetFont(customStatus, 9)
    customStatus:SetPoint("TOPLEFT", customNameLabel, "BOTTOMLEFT", 0, -16)
    customStatus:SetWidth(240)
    customStatus:SetJustifyH("LEFT")
    customStatus:SetWordWrap(true)
    customStatus:SetText("")
    customForm._statusLabel = customStatus

    local function paintCustomStatusResolved(name, id)
        local success = C.textSuccess
        if success and success.GetRGBA then
            customStatus:SetTextColor(success:GetRGBA())
        else
            customStatus:SetTextColor(0.4, 0.85, 0.4, 1)
        end
        local fmt = L["GEMS_IF_PICKER_CUSTOM_RESOLVED"] or "Resolved: %s (ID %s)"
        customStatus:SetText(string.format(fmt, name or "", tostring(id or "")))
    end

    local function paintCustomStatusUnresolved()
        local warning = C.textWarning
        if warning and warning.GetRGBA then
            customStatus:SetTextColor(warning:GetRGBA())
        else
            customStatus:SetTextColor(1, 0.7, 0.2, 1)
        end
        customStatus:SetText(L["GEMS_IF_PICKER_CUSTOM_UNRESOLVED"] or "Spell not in cache (will use raw value)")
    end

    local function paintCustomStatusFound(n)
        local success = C.textSuccess
        if success and success.GetRGBA then
            customStatus:SetTextColor(success:GetRGBA())
        else
            customStatus:SetTextColor(0.4, 0.85, 0.4, 1)
        end
        local fmt = L["GEMS_IF_PICKER_CUSTOM_FOUND"] or "Found %d matches"
        customStatus:SetText(string.format(fmt, n))
    end

    local function runResolveFromID()
        local raw = customIDBox:GetText() or ""
        if raw == "" then
            return
        end
        local id = tonumber(raw)
        local resolvedName = customResolveFromID(id)
        if resolvedName then
            customNameBox:SetText(resolvedName)
            paintCustomStatusResolved(resolvedName, id)
        else
            paintCustomStatusUnresolved()
        end
    end

    customIDBox:SetScript("OnEditFocusLost", runResolveFromID)
    customIDBox:SetScript("OnEnterPressed", function(self)
        runResolveFromID()
        self:ClearFocus()
    end)
    customIDBox:SetScript("OnTabPressed", function(self)
        runResolveFromID()
        customNameBox:SetFocus()
    end)
    customIDBox:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
    end)
    GRIPEMS.Focus:HookEditBox(customIDBox)

    customNameBox:SetScript("OnEnterPressed", function(self)
        self:ClearFocus()
    end)
    customNameBox:SetScript("OnTabPressed", function(self)
        customIDBox:SetFocus()
    end)
    customNameBox:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
    end)
    GRIPEMS.Focus:HookEditBox(customNameBox)

    local customApply = UI:CreateButton(customForm, L["GEMS_IF_PICKER_APPLY"] or "Apply", 70, 22)
    customApply:SetPoint("BOTTOMRIGHT", customForm, "BOTTOMRIGHT", -4, 4)
    customApply:SetScript("OnClick", function()
        local nameText = customNameBox:GetText() or ""
        local idText = customIDBox:GetText() or ""
        local id = tonumber(idText)
        local chosenName = (nameText ~= "" and nameText) or (id and tostring(id)) or ""
        if chosenName == "" then
            return
        end
        local entry = { name = chosenName, spellID = id, _isCustom = true }
        if SP._insertCallback then
            SP._insertCallback(entry)
        end
        SP:Hide()
    end)
    customForm._applyBtn = customApply

    local customCancel = UI:CreateButton(customForm, L["GEMS_IF_PICKER_CANCEL"] or "Cancel", 70, 22)
    customCancel:SetPoint("RIGHT", customApply, "LEFT", -6, 0)
    customCancel:SetScript("OnClick", function()
        SP:Hide()
    end)
    customForm._cancelBtn = customCancel

    -- Scrollable match list (Phase H1.7.1)
    -- Anchored between status row and Apply/Cancel buttons. Rows are pooled
    -- and grow lazily via ensureMatchRowCount; the OnTextChanged hook fires
    -- the search and lays out / shows / hides rows based on match count.
    local matchScroll = CreateFrame("ScrollFrame", nil, customForm, "UIPanelScrollFrameTemplate")
    matchScroll:SetPoint("TOPLEFT", customStatus, "BOTTOMLEFT", 0, -8)
    matchScroll:SetPoint("BOTTOMRIGHT", customApply, "TOPRIGHT", -26, 8)
    matchScroll:Hide()
    customForm._matchScroll = matchScroll

    local matchContent = CreateFrame("Frame", nil, matchScroll)
    matchContent:SetSize(1, 1)
    matchScroll:SetScrollChild(matchContent)
    customForm._matchContent = matchContent

    local matchRows = {}
    customForm._matchRows = matchRows

    local function makeMatchRow()
        local row = CreateFrame("Button", nil, matchContent, "BackdropTemplate")
        row:SetSize(200, 18)
        row:SetPoint("RIGHT", matchContent, "RIGHT", 0, 0)
        UI:ApplyBackdrop(row, UI.Backdrops.panelNoBorder, C.bgPanel, C.border)
        row:SetBackdropColor(0, 0, 0, 0)
        local rowLabel = row:CreateFontString(nil, "OVERLAY")
        UI:SetFont(rowLabel, 11)
        rowLabel:SetPoint("LEFT", row, "LEFT", 6, 0)
        rowLabel:SetPoint("RIGHT", row, "RIGHT", -6, 0)
        rowLabel:SetJustifyH("LEFT")
        rowLabel:SetWordWrap(false)
        rowLabel:SetTextColor(C.textPrimary:GetRGBA())
        row._label = rowLabel
        row:SetScript("OnEnter", function(self)
            self:SetBackdropColor(C.bgRowHover:GetRGBA())
        end)
        row:SetScript("OnLeave", function(self)
            self:SetBackdropColor(0, 0, 0, 0)
        end)
        row:SetScript("OnClick", function(self)
            if not self._matchData then
                return
            end
            customIDBox:SetText(tostring(self._matchData.id))
            customNameBox:SetText(self._matchData.name)
            paintCustomStatusResolved(self._matchData.name, self._matchData.id)
            for _, r in ipairs(matchRows) do
                r:Hide()
            end
            matchScroll:Hide()
        end)
        return row
    end

    local function ensureMatchRowCount(n)
        while #matchRows < n do
            matchRows[#matchRows + 1] = makeMatchRow()
        end
    end

    local ROW_HEIGHT = 18
    local ROW_SPACING = 2

    customNameBox:SetScript("OnTextChanged", function(self, userInput)
        if not userInput then
            return
        end
        local query = self:GetText() or ""
        if query == "" then
            for _, row in ipairs(matchRows) do
                row:Hide()
            end
            matchScroll:Hide()
            customStatus:SetText("")
            return
        end
        local matches = customSearchByPrefix(query)
        if #matches > 0 then
            paintCustomStatusFound(#matches)
            matchScroll:Show()
        else
            paintCustomStatusUnresolved()
            matchScroll:Hide()
        end
        ensureMatchRowCount(#matches)
        local totalHeight = #matches * (ROW_HEIGHT + ROW_SPACING)
        matchContent:SetSize(matchScroll:GetWidth(), math.max(totalHeight, 1))
        local prev = nil
        for i, row in ipairs(matchRows) do
            if matches[i] then
                row._matchData = matches[i]
                row._label:SetText(string.format("%s (ID %s)", matches[i].name, tostring(matches[i].id)))
                row:ClearAllPoints()
                if prev then
                    row:SetPoint("TOPLEFT", prev, "BOTTOMLEFT", 0, -ROW_SPACING)
                else
                    row:SetPoint("TOPLEFT", matchContent, "TOPLEFT", 0, 0)
                end
                row:SetPoint("RIGHT", matchContent, "RIGHT", 0, 0)
                row:Show()
                prev = row
            else
                row:Hide()
            end
        end
        matchScroll:SetVerticalScroll(0)
    end)

    -- No results label
    local noResults = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(noResults, 11)
    noResults:SetPoint("CENTER", scrollBox, "CENTER")
    noResults:SetText(L["GEMS_SPELLPICKER_NO_RESULTS"])
    noResults:SetTextColor(C.textMuted:GetRGBA())
    noResults:Hide()
    frame.noResultsLabel = noResults

    ---------------------------------------------------------------------------
    -- Conditionals section (bottom)
    ---------------------------------------------------------------------------
    local condHeader = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(condHeader, 10)
    condHeader:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 8, 112)
    condHeader:SetText(L["GEMS_SPELLPICKER_CONDITIONALS"])
    condHeader:SetTextColor(C.textSecondary:GetRGBA())
    frame._condHeader = condHeader

    -- Conditional buttons grid (3 rows of buttons)
    local btnWidth = 80
    local btnHeight = 18
    local btnsPerRow = 3
    local startY = 90

    local condButtons = {}
    for i, cond in ipairs(CONDITIONAL_BUTTONS) do
        local cbtn = CreateFrame("Button", nil, frame, "BackdropTemplate")
        cbtn:SetSize(btnWidth, btnHeight)
        cbtn:SetBackdrop(UI.Backdrops.panelNoBorder)
        cbtn:SetBackdropColor(C.bgButton:GetRGBA())

        local row = math.floor((i - 1) / btnsPerRow)
        local col = (i - 1) % btnsPerRow
        cbtn:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 8 + col * (btnWidth + 4), startY - row * (btnHeight + 2))

        local cLabel = cbtn:CreateFontString(nil, "OVERLAY")
        UI:SetFont(cLabel, 9)
        cLabel:SetPoint("CENTER", cbtn, "CENTER")
        cLabel:SetText(cond)
        cLabel:SetTextColor(C.textPrimary:GetRGBA())

        cbtn:SetScript("OnClick", function()
            SP:InsertText(cond)
        end)
        cbtn:SetScript("OnEnter", function(self)
            self:SetBackdropColor(C.bgRowHover:GetRGBA())
        end)
        cbtn:SetScript("OnLeave", function(self)
            self:SetBackdropColor(C.bgButton:GetRGBA())
        end)

        condButtons[i] = { btn = cbtn, label = cLabel }
    end
    frame._condButtons = condButtons

    -- Custom conditional EditBox
    local customLabel = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(customLabel, 9)
    customLabel:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 8, 6)
    customLabel:SetText(L["GEMS_SPELLPICKER_CUSTOM"])
    customLabel:SetTextColor(C.textSecondary:GetRGBA())
    frame._customLabel = customLabel

    local customBox = CreateFrame("EditBox", nil, frame, "BackdropTemplate")
    customBox:SetSize(200, 20)
    customBox:SetPoint("LEFT", customLabel, "RIGHT", 4, 0)
    customBox:SetAutoFocus(false)
    customBox:SetMaxLetters(100)
    UI:ApplyBackdrop(customBox, UI.Backdrops.panel, C.bgInput, C.border)
    customBox:SetBackdropBorderColor(C.textMuted:GetRGBA())
    customBox:SetTextInsets(4, 4, 2, 2)
    customBox:SetFont(fontPath, 10, "")
    customBox:SetTextColor(C.textPrimary:GetRGBA())
    customBox:SetScript("OnEnterPressed", function(self)
        local text = self:GetText() or ""
        if text ~= "" then
            SP:InsertText(text)
            self:SetText("")
        end
        self:ClearFocus()
    end)
    customBox:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
    end)
    frame._customBox = customBox
    GRIPEMS.Focus:HookEditBox(customBox)

    -- Insert custom button
    local insertBtn = UI:CreateButton(frame, L["GEMS_SPELLPICKER_INSERT"], 50, 20)
    insertBtn:SetPoint("LEFT", customBox, "RIGHT", 4, 0)
    insertBtn:SetScript("OnClick", function()
        local text = customBox:GetText() or ""
        if text ~= "" then
            SP:InsertText(text)
            customBox:SetText("")
        end
    end)
    frame._insertBtn = insertBtn

    -- Phase 2 #7: Focus context lifecycle.
    -- Phase 3 #12 Pass B: extend targets to conditional buttons + insert
    -- button so keyboard-first users can TAB through every actionable
    -- control. Phase 3 follow-up: add helpBtn between insert and close.
    -- Order: filter rail (14), conditional grid (11, reading order),
    -- insert, help, close = 28 targets. Search box + custom box stay out
    -- of the rotation -- they are EditBoxes handled by OnKeyDown via
    -- Focus:IsEditBoxFocused().
    frame:HookScript("OnShow", function(self)
        local Focus = GRIPEMS.Focus
        if not Focus then
            return
        end
        local targets = {}
        if self._filterBtns then
            for _, btn in ipairs(self._filterBtns) do
                targets[#targets + 1] = btn
            end
        end
        if self._condButtons then
            for _, entry in ipairs(self._condButtons) do
                if entry.btn then
                    targets[#targets + 1] = entry.btn
                end
            end
        end
        if self._insertBtn then
            targets[#targets + 1] = self._insertBtn
        end
        if self.helpBtn then
            targets[#targets + 1] = self.helpBtn
        end
        targets[#targets + 1] = self.closeBtn
        Focus:PushContext("SpellPicker", targets)
    end)
    frame:HookScript("OnHide", function()
        local Focus = GRIPEMS.Focus
        if not Focus then
            return
        end
        Focus:PopContext("SpellPicker")
    end)

    -- Phase H1.7: fire and clear onCloseCallback on any close path
    -- (Apply, Cancel, X button, Esc keybind, UISpecialFrames Esc). SP:Hide
    -- also fires + clears as a backstop; both orderings are idempotent.
    frame:HookScript("OnHide", function()
        if SP._onCloseCallback then
            local cb = SP._onCloseCallback
            SP._onCloseCallback = nil
            cb()
        end
    end)

    SP._frame = frame

    -- Phase 3 #12 Pass A: repaint captured colors on palette change.
    if UI.OnPaletteChanged then
        UI:OnPaletteChanged(function()
            if SP._frame then
                applyPalette(SP._frame)
            end
        end)
    end

    return frame
end

---------------------------------------------------------------------------
-- Visibility helper for callback mode
---------------------------------------------------------------------------
-- H1.6: hide the conditional-buttons / custom-box / insert-button section
-- when the picker is opened in callback mode. The section is built
-- statically in CreatePickerFrame so we toggle visibility per-Show.
local function applyConditionalsVisibility(frame, hidden)
    if not frame then
        return
    end
    local widgets = {
        frame._condHeader,
        frame._customLabel,
        frame._customBox,
        frame._insertBtn,
    }
    for _, w in ipairs(widgets) do
        if w and w.SetShown then
            w:SetShown(not hidden)
        end
    end
    if frame._condButtons then
        for _, entry in ipairs(frame._condButtons) do
            if entry.btn and entry.btn.SetShown then
                entry.btn:SetShown(not hidden)
            end
        end
    end
end

---------------------------------------------------------------------------
-- Show / Hide
---------------------------------------------------------------------------

--- Show the spell picker anchored to a button, targeting the given EditBox.
--- @param editBox EditBox The EditBox to insert text into
--- @param anchorBtn Button|nil Optional button to anchor the picker to
--- @param opts table|nil Optional flags: { insertCallback, hideConditionals, onCloseCallback }
function SP:Show(editBox, anchorBtn, opts)
    opts = opts or {}
    if not editBox and not opts.insertCallback then
        return
    end

    local frame = CreatePickerFrame()
    self._targetEditBox = editBox
    self._insertCallback = opts.insertCallback
    self._hideConditionals = opts.hideConditionals and true or false
    self._onCloseCallback = opts.onCloseCallback
    self._searchText = ""
    self._filterMode = "Spec"
    -- Phase H1.9a: reset spec scope to "current" on every fresh Show so the
    -- default open path mirrors today's UX exactly (active-spec only).
    self._specScope = "current"
    -- Phase H1.9b: reset class scope to "all" on every fresh Show so opening
    -- the All Classes tab from a clean state shows every class entry. SP:Hide
    -- does not reset this field -- Show is the canonical reset point,
    -- mirroring the spec-scope handling above.
    self._classScope = "all"

    if frame.searchBox then
        frame.searchBox:SetText("")
    end

    if frame._filterBtns then
        local C = GRIPEMS.UI.Colors
        for _, btn in ipairs(frame._filterBtns) do
            -- Phase H1.7: Custom tab only visible in callback mode so the
            -- default open path never exposes a free-form ID / Name entry.
            if btn._filterKey == "Custom" then
                btn:SetShown(self._insertCallback ~= nil)
            end
            if btn._filterKey == "Spec" then
                btn:SetBackdropColor(C.bgRowSelected:GetRGBA())
                btn._label:SetTextColor(C.textPrimary:GetRGBA())
            else
                btn:SetBackdropColor(0, 0, 0, 0)
                btn._label:SetTextColor(C.textSecondary:GetRGBA())
            end
        end
    end

    -- Phase H1.7: ensure custom form is hidden and the spell list is the
    -- visible right pane on every fresh Show, regardless of the prior state.
    if frame._customForm then
        frame._customForm:Hide()
    end
    if SP._scrollBox then
        SP._scrollBox:Show()
    end
    if frame._scrollBar then
        frame._scrollBar:Show()
    end

    -- Phase H1.9a: paint the first-frame state for the spec scope dropdown.
    -- _filterMode = "Spec" by default so the dropdown is visible and the
    -- scrollBox sits at the -82 y-offset that leaves room above it.
    if frame._applySpecScopeVisibility then
        frame._applySpecScopeVisibility(self._filterMode == "Spec")
    end
    -- Phase H1.9b: paint the class scope dropdown's first-frame state. The
    -- default _filterMode is "Spec" so this call evaluates to false and the
    -- class scope dropdown stays hidden. The helper's inactive branch is
    -- guarded so it does not clobber the spec dropdown's -82 anchor that
    -- the call above just set.
    if frame._applyClassScopeVisibility then
        frame._applyClassScopeVisibility(self._filterMode == "AllClasses")
    end

    applyConditionalsVisibility(frame, self._hideConditionals)

    frame:ClearAllPoints()
    local anchor = anchorBtn or editBox
    if anchor then
        frame:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", 0, -2)
    else
        frame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    end

    RefreshSpellList()
    showWithMotion(frame)
end

--- Hide the spell picker.
function SP:Hide()
    if self._frame then
        self._frame:Hide()
    end
    self._targetEditBox = nil
    self._insertCallback = nil
    self._hideConditionals = false
    -- Phase H1.7: fire and clear onCloseCallback in case the OnHide path
    -- has not already fired it. Idempotent with the frame's OnHide hook.
    if self._onCloseCallback then
        local cb = self._onCloseCallback
        self._onCloseCallback = nil
        cb()
    end
end

--- Toggle the spell picker for the given EditBox.
--- @param editBox EditBox The EditBox to insert text into
--- @param anchorBtn Button|nil Optional anchor button
function SP:Toggle(editBox, anchorBtn)
    if self._frame and self._frame:IsShown() and self._targetEditBox == editBox then
        self:Hide()
    else
        self:Show(editBox, anchorBtn)
    end
end
