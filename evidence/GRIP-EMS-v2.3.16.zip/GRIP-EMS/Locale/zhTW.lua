-- GRIP-EMS: Locale-zhTW
-- Created: 2026-04-03
-- Updated: 2026-07-27
-- Patch: 12.0.7.68275 Midnight (Retail LIVE)

-- GRIP-EMS: Traditional Chinese Locale (Machine Translated, Needs Review)
-- All user-facing strings. L["key"] = translated value

local L = LibStub("AceLocale-3.0"):NewLocale("GRIP-EMS", "zhTW")
if not L then
    return
end

-- GEMS_KEYBINDS_ universal-parity backfill 2026-06-12 (MT bootstrap, native review pending)
L["GEMS_KEYBINDS_LOST_WARN"] = "這次沒能載入你的序列按鍵綁定，但已儲存的綁定仍然還在。" -- MT
L["GEMS_KEYBINDS_LOST_HINT"] = "輸入 /gems binds restore 即可復原。" -- MT
L["GEMS_KEYBINDS_RESTORE_DONE"] = "已復原 %d 個按鍵綁定。" -- MT
L["GEMS_KEYBINDS_RESTORE_NONE"] = "還沒有可用於復原的已儲存資料。" -- MT
L["GEMS_KEYBINDS_PRUNED_NOTICE"] =
    "已從被刪除的配置中移除 %d 個按鍵綁定。輸入 /gems binds restore 可以找回。" -- MT
L["GEMS_KEYBINDS_CLEARED_NOTICE"] = "已從該配置清除 %d 個按鍵綁定。" -- MT

-- GEMS_ universal-parity backfill 2026-06-04 (MT bootstrap, native review pending)
L["GEMS_HOLD_FREEZE_HEADER"] = "按住以凍結" -- MT
L["GEMS_HOLD_FREEZE_ENABLE"] = "啟用按住以凍結" -- MT
L["GEMS_HOLD_FREEZE_ENABLE_DESC"] =
    "按住一個輔助鍵可將目前啟用的序列暫停在目前的步驟。按住期間它不會前進或施放，放開後會從暫停處繼續。" -- MT
L["GEMS_HOLD_FREEZE_MODIFIER"] = "凍結輔助鍵" -- MT
L["GEMS_HOLD_FREEZE_MODIFIER_DESC"] =
    "按住哪個輔助鍵時凍結序列。如果某個序列將同一輔助鍵用於變體，則會改為執行該變體。如果你也在此輔助鍵上設定了重設，則按住期間凍結優先。" -- MT
L["GEMS_HOLD_FREEZE_MOD_ALT"] = "Alt" -- MT
L["GEMS_HOLD_FREEZE_MOD_CTRL"] = "Ctrl" -- MT
L["GEMS_HOLD_FREEZE_MOD_SHIFT"] = "Shift" -- MT
L["GEMS_HOLD_FREEZE_CONFLICT_RESET"] =
    "按住以凍結：你也在 %s 上設定了重設。按住該輔助鍵期間，凍結優先於重設。" -- MT
L["GEMS_HOLD_FREEZE_CONFLICT_VARIANT"] =
    "按住以凍結：序列 %s 將 %s 用於變體，因此會在那裡執行變體而不是凍結。" -- MT
L["GEMS_RESTRICTED_PAUSED"] =
    "在受保護動作受限期間（戰鬥、競技場、傳奇鑰石或團隊首領戰），已暫停 %d 個序列。限制解除後會自動重新啟用。" -- MT
L["GEMS_SETTING_UNRESOLVED_WARN_LABEL"] = "在聊天中警告無法辨識的法術" -- MT
L["GEMS_SETTING_UNRESOLVED_WARN_DESC"] =
    "當序列引用的法術名稱在你目前的法術書中找不到時，在聊天中顯示一則訊息。預設為關閉。受影響的序列一律會在清單中以圖示標記。" -- MT
L["GEMS_UI_CTX_ENABLE_STEP"] = "啟用步驟" -- MT
L["GEMS_UI_CTX_DISABLE_STEP"] = "停用步驟" -- MT
L["GEMS_UI_STEP_DISABLED_PREFIX"] = "(關) " -- MT
L["GEMS_UI_STEP_DISABLE_CONVERTED"] = "此序列現在是動作序列。復原即可還原。" -- MT

-- General
L["GRIP - Enhanced Macro Sequencer"] = "GRIP - 增強巨集序列器" -- MT

-- Slash command help
L["GEMS_HELP_HEADER"] = "可用指令:" -- MT
L["GEMS_HELP_NONE"] = "  /gems - 開啟主視窗 (若視窗未準備好則顯示說明)" -- MT
L["GEMS_HELP_HELP"] = "  /gems help - 此說明訊息" -- MT
L["GEMS_HELP_CREATE"] = "  /gems create [name] - 建立測試序列 (預設: TestSeq)" -- MT
L["GEMS_HELP_DELETE"] = "  /gems delete <name> - 刪除序列及其巨集樁" -- MT
L["GEMS_HELP_LIST"] = "  /gems list - 列出所有作用中序列" -- MT
L["GEMS_HELP_TEST"] = "  /gems test <name> - 手動推進步驟 (偵錯)" -- MT
L["GEMS_HELP_RESET"] = "  /gems reset <name> - 將序列重置為步驟 1" -- MT
L["GEMS_HELP_DEBUG"] = "  /gems debug - 切換偵錯模式" -- MT
L["GEMS_HELP_STATUS"] = "  /gems status - 顯示執行中狀態" -- MT
L["GEMS_HELP_TESTLOCALE"] = "  /gems testlocale - 測試地區語系翻譯" -- MT
L["GEMS_HELP_TESTSPELLID"] = "  /gems testspellid - 測試法術 ID 解析" -- MT

-- Slash command responses
L["GEMS_VERSION"] = "|cFF00CC66GRIP|r - 增強巨集序列器 |cFFAAAAAAv%s|r" -- MT
L["GEMS_DEBUG_ENABLED"] = "偵錯模式 |cFF00FF00已啟用|r。" -- MT
L["GEMS_DEBUG_DISABLED"] = "偵錯模式 |cFFFF4444已停用|r。" -- MT
L["GEMS_UNKNOWN_CMD"] = "未知指令 '%s'。輸入 /gems help 查看可用指令。" -- MT

-- Sequence creation/deletion
L["GEMS_CREATED"] = "序列 |cFF00FF00'%s'|r 已建立,共 %d 個步驟 (%s)。" -- MT
L["GEMS_DELETED"] = "序列 |cFF00FF00'%s'|r 已刪除。" -- MT
L["GEMS_ALREADY_EXISTS"] = "序列 '%s' 已存在。請先用 /gems delete %s 刪除它" -- MT
L["GEMS_NOT_FOUND"] = "找不到序列 '%s'。" -- MT
L["GEMS_DELETE_NEED_NAME"] = "用法: /gems delete <name>" -- MT

-- Sequence list
L["GEMS_LIST_HEADER"] = "作用中序列 (%d):" -- MT
L["GEMS_LIST_ENTRY"] = "  |cFF00FF00%s|r - %d 個步驟,步驟 %d/%d (%s)" -- MT
L["GEMS_LIST_EMPTY"] = "沒有作用中序列。使用 /gems create 建立一個。" -- MT

-- Sequence test/reset
L["GEMS_TEST_NEED_NAME"] = "用法: /gems test <name>" -- MT
L["GEMS_TEST_ADVANCED"] = "|cFF00FF00%s|r: 已推進至步驟 %d/%d。" -- MT
L["GEMS_RESET_NEED_NAME"] = "用法: /gems reset <name>" -- MT
L["GEMS_RESET_DONE"] = "|cFF00FF00%s|r: 已重置為步驟 1。" -- MT

-- Status
L["GEMS_STATUS_HEADER"] = "--- GRIP-EMS Status ---" -- MT
L["GEMS_STATUS_SEQUENCES"] = "作用中序列: %d" -- MT
L["GEMS_STATUS_MACROS"] = "巨集欄位: 每個角色已使用 %d/%d" -- MT
L["GEMS_STATUS_KEYDOWN"] = "ActionButtonUseKeyDown: %s (按鈕覆寫: true)" -- MT
L["GEMS_STATUS_SQW"] = "SpellQueueWindow: %s ms" -- MT
L["GEMS_STATUS_OOC"] = "戰鬥外佇列: %d 個待處理" -- MT
L["GEMS_STATUS_LOADOUT"] = "  Saved loadout: %d (%s)" -- MT
L["GEMS_STATUS_LOADOUT_NONE"] = "  Saved loadout: not selected yet" -- MT
L["GEMS_STATUS_PENDING_ACTIVE"] = "  Pending switch: target %d, elapsed %.1fs" -- MT
L["GEMS_STATUS_PENDING_NONE"] = "  Pending switch: no switch in progress" -- MT
L["GEMS_LM_FAIL_COMMIT_REJECTED"] = "Loadout switch failed: server rejected commit for build %d." -- MT
L["GEMS_LM_FAIL_TIMEOUT"] = "Loadout switch timed out after 15 seconds for build %d." -- MT
L["GEMS_LM_FAIL_PARTIAL"] = "Loadout switch ended with a different build active (target %d, got %d)." -- MT
L["GEMS_LM_FAIL_CANNOT_EDIT_TALENTS"] = "Cannot switch loadouts right now (in combat or restricted)." -- MT

-- Step function descriptions
L["GEMS_STEPFUNC_SEQUENTIAL_DESC"] = "依序循環步驟: 1, 2, 3, ..., N, 1, ..." -- MT
L["GEMS_STEPFUNC_RANDOM_DESC"] = "每次按下隨機選擇一個步驟" -- MT
L["GEMS_STEPFUNC_PRIORITY_DESC"] = "編號較高的步驟比編號較低的觸發更頻繁 (加權)" -- MT
L["GEMS_STEPFUNC_REVERSEPRIORITY_DESC"] =
    "反向優先順序: 較後面的步驟 (清單底部) 比較前面的觸發更頻繁" -- MT

-- Validation errors
L["GEMS_STEP_TOO_LONG"] = "步驟 %d 太長 (%d 字元,上限 %d)。" -- MT
L["GEMS_STEP_NIL"] = "步驟 %d 缺失。" -- MT
L["GEMS_ERR_NO_NAME"] = "需要序列名稱。" -- MT

-- Macro manager
L["GEMS_ERR_NO_MACRO_SLOTS"] = "沒有可用的巨集欄位 (此角色已使用 %d/%d 欄位)。" -- MT
L["GEMS_ERR_MACRO_CREATE_FAILED"] = "為序列 '%s' 建立巨集失敗。" -- MT
L["GEMS_MACRO_CREATED"] = "巨集樁 '%s' 已建立 (欄位 %d)。" -- MT
L["GEMS_MACROS_SCANNED"] = "回收了 %d 個現有的 GRIP-EMS 巨集樁。" -- MT
L["GEMS_WARN_KP_LINES_TRIMMED"] = "KeyPress: %d / %d 行符合步驟巨集 (255 字元上限)" -- MT
L["GEMS_WARN_KR_LINES_TRIMMED"] = "KeyRelease: %d / %d 行符合步驟巨集 (255 字元上限)" -- MT
L["GEMS_WARN_KP_STEP_OVERFLOW"] =
    "KeyPress: 符合 %d / %d 個步驟 (有 %d 個步驟因 255 字元上限而無 KeyPress 執行)" -- MT
L["GEMS_KP_STATUS_ALL_FIT"] = "符合所有 %d 個步驟" -- MT
L["GEMS_KP_STATUS_PARTIAL"] = "符合 %d/%d 個步驟 (255 字元上限)" -- MT
L["GEMS_KP_STATUS_NONE"] = "對任何步驟都太長 (0/%d)" -- MT

-- OOC Queue
L["GEMS_OOC_QUEUED"] = "操作已加入戰鬥外處理佇列。" -- MT
L["GEMS_OOC_PROCESSED"] = "已處理 %d 個佇列操作。" -- MT
L["GEMS_OOC_REPLACED"] = "戰鬥外佇列: 已為 %s 取代 %s" -- MT
L["GEMS_OOC_PRIORITY_PROCESSED"] = "戰鬥外佇列: 已處理 %d 個項目 (優先順序)" -- MT

-- Keybind manager
L["GEMS_HELP_BIND"] = "  /gems bind <name> <key> - 將按鍵綁定至序列觸發 (例如 CTRL-F12)" -- MT
L["GEMS_HELP_UNBIND"] = "  /gems unbind <name> - 移除序列的按鍵綁定" -- MT
L["GEMS_HELP_BINDS"] = "  /gems binds - 列出當前專精的所有按鍵綁定" -- MT
L["GEMS_BIND_SUCCESS"] = "已將 |cFF00FF00'%s'|r 綁定至 |cFFFFFF00%s|r。按下該鍵以觸發序列。" -- MT
L["GEMS_BIND_NEED_ARGS"] = "用法: /gems bind <name> <key> (例如 /gems bind TestSeq CTRL-F12)" -- MT
L["GEMS_UNBIND_SUCCESS"] = "已解除 |cFF00FF00'%s'|r 的綁定。" -- MT
L["GEMS_UNBIND_NO_BIND"] = "序列 '%s' 沒有按鍵綁定。" -- MT
L["GEMS_UNBIND_NEED_NAME"] = "用法: /gems unbind <name>" -- MT
L["GEMS_BINDS_HEADER"] = "按鍵綁定 (專精 %d):" -- MT
L["GEMS_BINDS_ENTRY"] = "  |cFFFFFF00%s|r -> |cFF00FF00%s|r" -- MT
L["GEMS_BINDS_EMPTY"] = "未設定按鍵綁定。使用 /gems bind <name> <key>。" -- MT
L["GEMS_KEYBINDS_LOADED"] = "已為專精 %d 載入 %d 個按鍵綁定。" -- MT
L["GEMS_STATUS_KEYBINDS"] = "按鍵綁定: 當前專精 %d 個" -- MT

-- IF action node UI surfaces (spec section 10)
L["GEMS_IF_COND_HINT"] = "e.g. mod:shift, combat, harm" -- MT
L["GEMS_IF_COND_TOOLTIP_TITLE"] = "Macro condition" -- MT
L["GEMS_IF_COND_TOOLTIP_BODY"] =
    "Type a WoW macro conditional. Comma-separated values are AND'd. Multiple bracket forms (e.g. [a][b]) are OR'd. Full reference: warcraft.wiki.gg/wiki/Macro_conditionals" -- MT
L["GEMS_IF_COND_INVALID"] = "Invalid condition" -- MT
L["GEMS_IF_PATH_SINGLE"] = "Single line" -- MT
L["GEMS_IF_PATH_TWO_LINE"] = "Two-line split" -- MT
L["GEMS_IF_PATH_PER_STEP"] = "Per-step" -- MT
L["GEMS_IF_PATH_FALL_THROUGH"] = "Fall-through" -- MT
L["GEMS_IF_PREVIEW_HEADER"] = "Compiled output" -- MT
L["GEMS_IF_PREVIEW_NEG_LABEL"] = "neg" -- MT
L["GEMS_IF_PREVIEW_EMPTY"] = "(no compiled output)" -- MT
L["GEMS_IF_LEN_WARN"] = "Approaching 255-char limit (%d)" -- MT
L["GEMS_IF_LEN_ERROR"] = "Exceeds 255-char limit (%d)" -- MT

-- IF action node combat-blocked command lint (spec section 10.8, 11.6, Phase H2)
L["GEMS_IF_LINT_COMBAT_BLOCKED_MARKER"] = "combat-blocked: %s" -- MT
L["GEMS_IF_LINT_COMBAT_BLOCKED_TOOLTIP_HEADER"] = "Combat-blocked commands:" -- MT
L["GEMS_IF_LINT_COMBAT_BLOCKED_HARD"] = "%s -- blocked in combat" -- MT
L["GEMS_IF_LINT_COMBAT_BLOCKED_PARTIAL"] = "%s -- partially blocked in combat" -- MT
L["GEMS_IF_LINT_COMBAT_BLOCKED_TOOLTIP_HINT"] = "Gate with [nocombat] in the Cond box, or move to an OOC sequence." -- MT
L["GEMS_IF_LINT_COMBAT_BLOCKED_VALIDATE_FMT"] = "Node %s: compiled step contains combat-blocked command %s" -- MT
L["GEMS_INTERLEAVE_OVERFLOW_LOOP_FMT"] =
    "Node %s: interval %s exceeds this loop's %s compiled steps. Clamped to %s so it still fires. Set the loop's Repeat to %s for an exact interval of %s." -- MT
L["GEMS_INTERLEAVE_OVERFLOW_ROOT_FMT"] =
    "Node %s: interval %s exceeds the sequence's %s base steps. Clamped to %s so it still fires; lower the interval to that or less for an exact interval." -- MT
L["GEMS_INTERLEAVE_BUDGET_FMT"] =
    "Node %s: the interleave copy budget (%s) is spent. This action emits %s of its %s copies. Lower an interval or remove an interleave." -- MT

-- IF action node conditional picker (spec section 10.7, Phase H1)
L["GEMS_IF_PICKER_TITLE"] = "Conditional picker" -- MT
L["GEMS_IF_PICKER_TAB_COMBAT"] = "Combat-relevant" -- MT
L["GEMS_IF_PICKER_TAB_GENERAL"] = "General-purpose" -- MT
L["GEMS_IF_PICKER_TAB_UI"] = "UI-state" -- MT
L["GEMS_IF_PICKER_APPLY"] = "Apply" -- MT
L["GEMS_IF_PICKER_CANCEL"] = "Cancel" -- MT
L["GEMS_IF_PICKER_NEGATE"] = "not" -- MT
L["GEMS_IF_PICKER_NEGATE_TOOLTIP"] =
    "Negate this conditional. mod:shift becomes nomod:shift, harm becomes noharm, etc. Spec section 5.2 (DeMorgan)." -- MT
L["GEMS_IF_PICKER_OR_GROUP_WARNING"] =
    "Multi-bracket OR groups not editable in picker (Phase H4). Use Cancel to keep the current value, or empty the Cond box and re-pick if you want a single-clause condition." -- MT

-- Combat-relevant rows
L["GEMS_IF_PICKER_COMBAT_LABEL"] = "combat" -- MT
L["GEMS_IF_PICKER_COMBAT_TOOLTIP"] =
    "True while you are in combat. Use to gate burst cooldowns or lockout-only abilities." -- MT
L["GEMS_IF_PICKER_NOCOMBAT_LABEL"] = "nocombat" -- MT
L["GEMS_IF_PICKER_NOCOMBAT_TOOLTIP"] =
    "True while you are out of combat. Use for pre-pull buffs, mount casts, or reset behaviours." -- MT
L["GEMS_IF_PICKER_HARM_LABEL"] = "harm" -- MT
L["GEMS_IF_PICKER_HARM_TOOLTIP"] = "True when your target is hostile. Pair with help in mixed friend/foe macros." -- MT
L["GEMS_IF_PICKER_HELP_LABEL"] = "help" -- MT
L["GEMS_IF_PICKER_HELP_TOOLTIP"] = "True when your target is friendly. Use for heals in mixed damage/heal macros." -- MT
L["GEMS_IF_PICKER_DEAD_LABEL"] = "dead" -- MT
L["GEMS_IF_PICKER_DEAD_TOOLTIP"] =
    "True when the target unit is dead. Use to swap to a resurrection spell or skip the cast." -- MT
L["GEMS_IF_PICKER_STEALTH_LABEL"] = "stealth" -- MT
L["GEMS_IF_PICKER_STEALTH_TOOLTIP"] =
    "True while in Stealth, Prowl, or Shadowmeld. Use for opener vs continuation branching." -- MT
L["GEMS_IF_PICKER_PVPCOMBAT_LABEL"] = "pvpcombat" -- MT
L["GEMS_IF_PICKER_PVPCOMBAT_TOOLTIP"] = "True while flagged for PvP combat. Use to swap PvP vs PvE talents or trinkets." -- MT
L["GEMS_IF_PICKER_CHANNELING_LABEL"] = "channelling" -- MT
L["GEMS_IF_PICKER_CHANNELING_TOOLTIP"] =
    "True while you are channelling a spell. Use to skip casts that would interrupt the channel." -- MT
L["GEMS_IF_PICKER_PET_LABEL"] = "pet" -- MT
L["GEMS_IF_PICKER_PET_TOOLTIP"] =
    "True when a pet (matching the optional name or family) is active. Leave the field empty to match any pet." -- MT
L["GEMS_IF_PICKER_NOPET_LABEL"] = "nopet" -- MT
L["GEMS_IF_PICKER_NOPET_TOOLTIP"] =
    "True when no pet is active. Used by the Hunter pattern to substitute a self-cast when soloing." -- MT
L["GEMS_IF_PICKER_PETBATTLE_LABEL"] = "petbattle" -- MT
L["GEMS_IF_PICKER_PETBATTLE_TOOLTIP"] = "True while in a pet battle. Use to swap to pet-battle abilities." -- MT
L["GEMS_IF_PICKER_MOD_LABEL"] = "mod:<key>" -- MT
L["GEMS_IF_PICKER_MOD_TOOLTIP"] =
    "True when the chosen modifier key is held. Pick shift, ctrl, alt, or an L/R variant for AoE vs single-target swaps." -- MT
L["GEMS_IF_PICKER_BUTTON_LABEL"] = "button:N" -- MT
L["GEMS_IF_PICKER_BUTTON_TOOLTIP"] =
    "True when the macro fired from the chosen mouse button or bind index. 1=left, 2=right, 3=middle, 4 and 5 are side buttons." -- MT
L["GEMS_IF_PICKER_PARTY_LABEL"] = "party" -- MT
L["GEMS_IF_PICKER_PARTY_TOOLTIP"] =
    "True while in a party. Use for group-only utility such as Battle Resurrection or party-target buffs." -- MT
L["GEMS_IF_PICKER_RAID_LABEL"] = "raid" -- MT
L["GEMS_IF_PICKER_RAID_TOOLTIP"] = "True while in a raid. Use for raid-only burst windows or cooldown alignment." -- MT
L["GEMS_IF_PICKER_EXISTS_LABEL"] = "exists" -- MT
L["GEMS_IF_PICKER_EXISTS_TOOLTIP"] =
    "True when the target unit exists. Pair with @focus or @mouseover so the macro has a fallback when the unit is gone." -- MT
L["GEMS_IF_PICKER_UNITVEHICLE_LABEL"] = "unithasvehicleui" -- MT
L["GEMS_IF_PICKER_UNITVEHICLE_TOOLTIP"] =
    "True when the unit is presenting a vehicle UI. Use to skip casts that would target the driver instead of the vehicle." -- MT

-- General-purpose rows
L["GEMS_IF_PICKER_MOUNTED_LABEL"] = "mounted" -- MT
L["GEMS_IF_PICKER_MOUNTED_TOOLTIP"] =
    "True while you are mounted. Common pattern: dismount in the true branch, cast a mount in the false branch." -- MT
L["GEMS_IF_PICKER_SWIMMING_LABEL"] = "swimming" -- MT
L["GEMS_IF_PICKER_SWIMMING_TOOLTIP"] = "True while you are swimming. Use to swap to a swim-form mount or aquatic spell." -- MT
L["GEMS_IF_PICKER_FLYING_LABEL"] = "flying" -- MT
L["GEMS_IF_PICKER_FLYING_TOOLTIP"] =
    "True while you are airborne on a flying mount. Use to skip ground-only casts mid-flight." -- MT
L["GEMS_IF_PICKER_FLYABLE_LABEL"] = "flyable" -- MT
L["GEMS_IF_PICKER_FLYABLE_TOOLTIP"] =
    "True in zones where standard flying is allowed. Pair with mount toggles for ground vs air swaps." -- MT
L["GEMS_IF_PICKER_ADVFLYABLE_LABEL"] = "advflyable" -- MT
L["GEMS_IF_PICKER_ADVFLYABLE_TOOLTIP"] =
    "True in zones where Skyriding is allowed. Use for sky vs ground mount swaps in modern zones." -- MT
L["GEMS_IF_PICKER_INDOORS_LABEL"] = "indoors" -- MT
L["GEMS_IF_PICKER_INDOORS_TOOLTIP"] =
    "True while indoors (mount-blocked area). Use to skip mount casts that would error or to fall back to a teleport." -- MT
L["GEMS_IF_PICKER_OUTDOORS_LABEL"] = "outdoors" -- MT
L["GEMS_IF_PICKER_OUTDOORS_TOOLTIP"] = "True while outdoors. Mirror of indoors; use for mount or ground-spell branches." -- MT
L["GEMS_IF_PICKER_RESTING_LABEL"] = "resting" -- MT
L["GEMS_IF_PICKER_RESTING_TOOLTIP"] =
    "True while resting in an inn or capital. Use for free-cast buffs or hearthstone shortcuts." -- MT
L["GEMS_IF_PICKER_GROUP_LABEL"] = "group" -- MT
L["GEMS_IF_PICKER_GROUP_TOOLTIP"] = "True while in any group (party or raid). Quick group-vs-solo branch." -- MT
L["GEMS_IF_PICKER_NOGROUP_LABEL"] = "nogroup" -- MT
L["GEMS_IF_PICKER_NOGROUP_TOOLTIP"] = "True when soloing. Use for solo burst that would be wasteful in a group context." -- MT
L["GEMS_IF_PICKER_SPEC_LABEL"] = "spec:N" -- MT
L["GEMS_IF_PICKER_SPEC_TOOLTIP"] =
    "True when the chosen specialisation slot (1-4) is active. Pair with utility branches per spec." -- MT
L["GEMS_IF_PICKER_FORM_LABEL"] = "form:N" -- MT
L["GEMS_IF_PICKER_FORM_TOOLTIP"] =
    "True when the chosen shapeshift or stance form is active. Druid, Warrior, and Rogue stance branches." -- MT
L["GEMS_IF_PICKER_STANCE_LABEL"] = "stance:N" -- MT
L["GEMS_IF_PICKER_STANCE_TOOLTIP"] = "Alias for form. Same semantics; kept for legacy macro compatibility." -- MT
L["GEMS_IF_PICKER_EQUIPPED_LABEL"] = "equipped:type" -- MT
L["GEMS_IF_PICKER_EQUIPPED_TOOLTIP"] =
    "True when the chosen item type is equipped (e.g. Sword, Shield, Polearm). Use for weapon-aware swaps." -- MT
L["GEMS_IF_PICKER_WORN_LABEL"] = "worn:type" -- MT
L["GEMS_IF_PICKER_WORN_TOOLTIP"] = "Alias for equipped. Same semantics." -- MT
L["GEMS_IF_PICKER_KNOWN_LABEL"] = "known:spell" -- MT
L["GEMS_IF_PICKER_KNOWN_TOOLTIP"] =
    "True when the chosen spell is known. Replaces the removed talent: conditional; type the spell name into the field." -- MT
L["GEMS_IF_PICKER_CANEXITVEHICLE_LABEL"] = "canexitvehicle" -- MT
L["GEMS_IF_PICKER_CANEXITVEHICLE_TOOLTIP"] =
    "True while in a vehicle that allows exiting. Pair with /run VehicleExit() guards." -- MT

-- UI-state rows
L["GEMS_IF_PICKER_BONUSBAR_LABEL"] = "bonusbar:N" -- MT
L["GEMS_IF_PICKER_BONUSBAR_TOOLTIP"] =
    "True when the chosen bonus action bar (1-10) is active. Pair with stance or form toggles." -- MT
L["GEMS_IF_PICKER_OVERRIDEBAR_LABEL"] = "overridebar" -- MT
L["GEMS_IF_PICKER_OVERRIDEBAR_TOOLTIP"] =
    "True when the override action bar is active (vehicle, possess, or quest override)." -- MT
L["GEMS_IF_PICKER_POSSESSBAR_LABEL"] = "possessbar" -- MT
L["GEMS_IF_PICKER_POSSESSBAR_TOOLTIP"] = "True when the possess bar is active (mind control or certain quests)." -- MT
L["GEMS_IF_PICKER_VEHICLEUI_LABEL"] = "vehicleui" -- MT
L["GEMS_IF_PICKER_VEHICLEUI_TOOLTIP"] =
    "True when the vehicle UI is active. Use when driving a mount-style vehicle with its own action bar." -- MT
L["GEMS_IF_PICKER_EXTRABAR_LABEL"] = "extrabar" -- MT
L["GEMS_IF_PICKER_EXTRABAR_TOOLTIP"] = "True when the extra action button is visible (boss fight or quest button)." -- MT
L["GEMS_IF_PICKER_CURSOR_LABEL"] = "cursor" -- MT
L["GEMS_IF_PICKER_CURSOR_TOOLTIP"] =
    "True when an item or spell is on the cursor. Use to skip casts that would consume the pickup." -- MT
L["GEMS_IF_PICKER_ACTIONBAR_LABEL"] = "actionbar:N" -- MT
L["GEMS_IF_PICKER_ACTIONBAR_TOOLTIP"] =
    "True when the chosen action bar page (1-12) is active. Pair with stance or form macros." -- MT
L["GEMS_IF_PICKER_BAR_LABEL"] = "bar:N" -- MT
L["GEMS_IF_PICKER_BAR_TOOLTIP"] = "Alias for actionbar. Same semantics; commonly used in older macros." -- MT
L["GEMS_IF_PICKER_SHAPESHIFT_LABEL"] = "shapeshift" -- MT
L["GEMS_IF_PICKER_SHAPESHIFT_TOOLTIP"] = "True when in any shapeshift form. Use for caster vs animal-form branching." -- MT
L["GEMS_IF_PICKER_HOUSE_LABEL"] = "house:where" -- MT
L["GEMS_IF_PICKER_HOUSE_TOOLTIP"] =
    "True when at the chosen housing location (inside, plot, editor, or neighbourhood). Use for housing toy macros." -- MT
L["GEMS_IF_PICKER_SEARCH_SPELL_HINT"] = "Search spell..." -- MT
L["GEMS_IF_PICKER_PETMODE_FAMILY"] = "F" -- MT
L["GEMS_IF_PICKER_PETMODE_NAME"] = "N" -- MT
L["GEMS_IF_PICKER_PETMODE_TOOLTIP"] = "Toggle: F = pick from family list, N = type a literal pet name" -- MT

-- IF action node conditional picker Custom tab (Phase H1.7)
L["GEMS_IF_PICKER_CUSTOM_TAB"] = "Custom" -- MT
L["GEMS_IF_PICKER_CUSTOM_HEADER"] = "Custom spell reference" -- MT
L["GEMS_IF_PICKER_CUSTOM_HINT"] = "Enter a spell ID or name. Either field fills the other when validated." -- MT
L["GEMS_IF_PICKER_CUSTOM_ID_LABEL"] = "Spell ID" -- MT
L["GEMS_IF_PICKER_CUSTOM_NAME_LABEL"] = "Name" -- MT
L["GEMS_IF_PICKER_CUSTOM_RESOLVED"] = "Resolved: %s (ID %s)" -- MT
L["GEMS_IF_PICKER_CUSTOM_UNRESOLVED"] = "Spell not in cache (will use raw value)" -- MT
L["GEMS_IF_PICKER_CUSTOM_FOUND"] = "Found %d matches" -- MT

-- Phase H1.9a: SpellPicker Spec filter sub-scope dropdown
L["GEMS_SPELLPICKER_SPEC_SCOPE_LABEL"] = "Scope:" -- MT
L["GEMS_SPELLPICKER_SPEC_SCOPE_CURRENT"] = "Current spec" -- MT
L["GEMS_SPELLPICKER_SPEC_SCOPE_ALL"] = "All specs" -- MT

-- Phase H1.9b: SpellPicker All Classes filter tab + class scope dropdown
L["GEMS_SPELLPICKER_ALLCLASSES"] = "All Classes" -- MT
L["GEMS_SPELLPICKER_CLASS_SCOPE_ALL"] = "All classes" -- MT
L["GEMS_SPELL_CACHE_UNRESOLVED"] =
    "GRIP-EMS: Unrecognised spell(s) after rescan: %s. If these are valid in your current talent loadout, run /reload." -- MT
L["GEMS_SPELL_CATALOG_DRIFT"] =
    "Spell catalogue last refreshed for build %s; you are on %s. Browsing may show outdated or missing entries." -- MT

-- Phase H4b: Conditional builder modal chrome
L["GEMS_IF_BUILDER_TITLE"] = "Conditional builder" -- MT
L["GEMS_IF_BUILDER_CLAUSE_HEADER"] = "OR clause %d" -- MT
L["GEMS_IF_BUILDER_ADD_OR_CLAUSE"] = "+ Add OR clause" -- MT
L["GEMS_IF_BUILDER_REMOVE_CLAUSE"] = "Remove" -- MT
L["GEMS_IF_BUILDER_APPLY"] = "Apply" -- MT
L["GEMS_IF_BUILDER_CANCEL"] = "Cancel" -- MT
L["GEMS_IF_BUILDER_PREVIEW"] = "Preview: %s" -- MT
-- Phase H4c: interactive multi-clause builder + picker escalation
L["GEMS_IF_BUILDER_CONVERT_TO_OR"] = "Convert to OR group" -- MT
L["GEMS_IF_BUILDER_EMPTY_CLAUSE_WARN"] = "Add a condition or remove this clause" -- MT
-- Phase H4d: targeting tab
L["GEMS_IF_BUILDER_TARGETING_TAB"] = "Targeting" -- MT
L["GEMS_IF_BUILDER_TARGETING_NONE"] = "(none)" -- MT
L["GEMS_IF_BUILDER_TARGETING_UNIT_HINT"] = "Custom unit (e.g. raid1, party2, arena1)" -- MT

-- Import/Export
L["GEMS_HELP_IMPORT"] = "  /gems import - 開啟匯入視窗 (貼上匯出字串)" -- MT
L["GEMS_HELP_EXPORT"] = "  /gems export <name> - 將序列匯出為 GRIP 字串" -- MT
L["GEMS_IMPORT_ENTRY"] = "  - '%s' (%d 個步驟)" -- MT
L["GEMS_IMPORT_FAILED"] = "匯入失敗: %s" -- MT
L["GEMS_IMPORT_WARNING"] = "警告: %s" -- MT
L["GEMS_IMPORT_USAGE"] = "用法: /gems import (開啟匯出字串貼上視窗)" -- MT
L["GEMS_EXPORT_USAGE"] = "用法: /gems export <name>" -- MT
L["GEMS_EXPORT_RESULT"] = "匯出: %s" -- MT
L["GEMS_EXPORT_FAILED"] = "匯出失敗: %s" -- MT
L["GEMS_IMPORT_PASTE_INSTRUCTIONS"] = "在下方貼上匯出字串,然後點擊匯入。" -- MT
L["GEMS_IMPORT_PASTE_LABEL"] = "匯出字串" -- MT
L["GEMS_IMPORT_CLEAR"] = "清除" -- MT

L["GEMS_IMPORT_SHORT_STRING"] = "提示: 使用 /gems import (無參數) 開啟長字串貼上視窗。" -- MT
L["GEMS_IMPORT_USE_FRAME"] = "提示: 字串可能已被截斷。使用 |cFFFFFF00/gems import|r 開啟貼上視窗。" -- MT
L["GEMS_IMPORT_UNKNOWN_FORMAT"] = "未知的匯入格式" -- MT
L["GEMS_IMPORT_ACTION_SKIPPED"] = "已略過動作: %s" -- MT
L["GEMS_IMPORT_EMBED_SKIPPED"] = "內嵌序列 '%s' 已略過 (無法使用)" -- MT
L["GEMS_IMPORT_PAUSE_CONVERTED"] = "暫停已轉換為 %d 個空步驟" -- MT
L["GEMS_IMPORT_INTERVAL_PRESERVED"] = "已保留 %d 個交錯動作" -- MT
L["GEMS_IMPORT_EMPTY_CASTSEQ_STRIPPED"] = "Removed %d empty cast sequence line(s) (they error on every press in-game)" -- MT
L["GEMS_ACTION_INTERLEAVE_EVERY"] = "每:" -- MT
L["GEMS_ACTION_INTERLEAVE_STEPS"] = "步驟" -- MT
L["GEMS_INTERLEAVE_TOOLTIP_TITLE"] = "交錯" -- MT
L["GEMS_INTERLEAVE_TOOLTIP_DESC"] =
    "啟用時,此動作每 N 次按鍵才觸發一次,而非每次按鍵。對於與主要循環一同使用的長冷卻增益相當實用。" -- MT
L["GEMS_ADD_ACTION_INTERLEAVE"] = "動作 (交錯)" -- MT

-- Layer 4: Macro action type (editor-side picker + drift UI)
L["GEMS_ADD_ACTION_MACRO"] = "Macro" -- MT
L["GEMS_MACRO_PICKER_TITLE"] = "Pick a Macro" -- MT
L["GEMS_MACRO_PICKER_SEARCH"] = "Search..." -- MT
L["GEMS_MACRO_PICKER_SOURCE_WOW"] = "WoW only" -- MT
L["GEMS_MACRO_PICKER_SOURCE_EMS"] = "EMS only" -- MT
L["GEMS_MACRO_PICKER_SOURCE_BOTH"] = "Both" -- MT
L["GEMS_MACRO_PICKER_EMPTY"] = "No macros found." -- MT
L["GEMS_MACROREF_NAME"] = "Macro:" -- MT
L["GEMS_MACROREF_DRIFT_INDICATOR"] = "stored body differs from /macro" -- MT
L["GEMS_MACROREF_SOURCE_MISSING"] = "source macro missing -- re-pick from picker" -- MT
L["GEMS_MACROREF_REFRESH"] = "Refresh from /macro" -- MT
L["GEMS_MACROREF_AUTOREFRESH"] = "自動重新整理巨集參考步驟" -- TODO: MT 2026-06-21
L["GEMS_MACROREF_AUTOREFRESH_DESC"] =
    "啟用後，由你的某個巨集建立的步驟會在你編輯該巨集後自動更新，這樣你就不必開啟該步驟並手動重新整理。預設為關閉。只有你在此角色上建立或重新整理過的步驟才會自動更新；匯入的步驟會保持不變，直到你手動重新整理一次。" -- TODO: MT 2026-06-21
L["GEMS_MACROREF_AUTOREFRESH_DEBUG"] = "已自動重新整理 %d 個序列中的巨集參考內容" -- TODO: MT 2026-06-21

-- Auxiliary-macro import (audit Layer 1: closes the bare-name macro gap)
L["GEMS_IMPORT_MACRO_LINE"] = "Macro %s was imported." -- MT
L["GEMS_IMPORT_MACROS_IMPORTED"] = "%d macro(s) imported." -- MT
L["GEMS_IMPORT_MACROS_SKIPPED"] = "%d macro(s) skipped." -- MT
L["GEMS_IMPORT_MACROS_OVERFLOW"] =
    "Macro '%s' could not be created -- macro slots full (%d/%d). Delete unused /macro entries and re-import." -- MT
L["GEMS_IMPORT_MACROS_SECTION_HEADING"] = "Macros" -- MT
L["GEMS_IMPORT_MACROS_BADGE_NEW"] = "(New)" -- MT
L["GEMS_IMPORT_MACROS_BADGE_UPDATE"] = "(Update)" -- MT
L["GEMS_IMPORT_MACRO_DEP_MISSING"] = "%s: references macro '%s' which is not in the import payload and not in your saved macros." -- MT
    .. " The step will type '%s' into chat at runtime." -- MT
L["GEMS_IMPORT_SEQUENCE_DEP_MISSING"] =
    "%s: embeds sequence '%s' which is not in the import payload and not in your saved sequences." -- MT

-- UI strings (Phase 3)
L["GEMS_HELP_OPEN"] = "  /gems open - 開啟/關閉主視窗" -- MT
L["GEMS_UI_TITLE"] = "GRIP-EMS" -- MT
L["GEMS_UI_SELECT_SEQUENCE"] = "選擇要編輯的序列" -- MT
L["GEMS_UI_SEQUENCE_LIST_PLACEHOLDER"] = "序列清單載入中..." -- MT
L["GEMS_UI_NO_SEQUENCES"] = "找不到序列。建立一個或匯入。" -- MT
L["GEMS_UI_RESIZE"] = "調整大小" -- MT
L["GEMS_UI_RESIZE_DESC"] = "拖曳以調整視窗大小" -- MT
L["GEMS_UI_MINIMAP_LEFT"] = "左鍵點擊: 開啟/關閉" -- MT
L["GEMS_UI_MINIMAP_RIGHT"] = "右鍵點擊: 快捷選單" -- MT
L["GEMS_UI_MINIMAP_RIGHTCLICK_SOON"] = "右鍵快捷選單即將推出。" -- MT
L["GEMS_UI_MINIMAP_OOC_QUEUE"] = "戰鬥外佇列" -- MT
L["GEMS_UI_MINIMAP_OOC_PENDING"] = "%d 個待處理" -- MT
L["GEMS_UI_MINIMAP_PARTY_USERS"] = "隊伍使用者" -- MT
L["GEMS_UI_MINIMAP_PARTY_NONE"] = "未偵測到" -- MT

-- UI strings (Phase 3A-2): Search
L["GEMS_UI_SEARCH"] = "搜尋..." -- MT
L["GEMS_UI_SEARCH_DESC"] = "依名稱篩選序列" -- MT

-- UI strings (Phase 3A-2): Buttons
L["GEMS_UI_NEW"] = "新建" -- MT
L["GEMS_UI_NEW_DESC"] = "建立新序列" -- MT
L["GEMS_UI_IMPORT_BTN"] = "匯入" -- MT
L["GEMS_UI_IMPORT_BTN_DESC"] = "從匯出字串匯入序列" -- MT

-- UI strings (Phase 3A-2): Context menu
L["GEMS_UI_DUPLICATE"] = "複製" -- MT
L["GEMS_UI_DELETE"] = "刪除" -- MT
L["GEMS_UI_EXPORT_CTX"] = "匯出" -- MT
L["GEMS_UI_RENAME"] = "重新命名" -- MT
L["GEMS_UI_REPAIR"] = "修復" -- MT
L["GEMS_UI_REPAIR_ALL"] = "全部修復" -- MT

-- Repair module strings
L["GEMS_REPAIR_USAGE"] = "用法: /gems repair <name> (或先選擇序列)" -- MT
L["GEMS_REPAIR_NOT_LOADED"] = "修復模組未載入" -- MT
L["GEMS_REPAIR_SEQ_NOT_FOUND"] = "找不到序列: %s" -- MT
L["GEMS_REPAIR_NONE"] = "找不到問題 (健康度: %d)" -- MT
L["GEMS_REPAIR_ALL_HEALTHY"] = "所有序列都很健康!" -- MT
L["GEMS_REPAIR_IMPORT_ISSUES"] = "已匯入 %s。發現 %d 個問題 -- 使用 /gems repair %s 來檢視。" -- MT
L["GEMS_REPAIR_EXPORT_WARN"] =
    "在所選序列中發現 %d 個問題。接收者可能會看到損壞的行為。仍要匯出嗎?" -- MT
L["GEMS_REPAIR_EXPORT_ACCEPT"] = "仍要匯出" -- MT
L["GEMS_REPAIR_SEND_WARN"] = "發現 %d 個問題。接收者可能會看到損壞的行為。仍要傳送嗎?" -- MT
L["GEMS_REPAIR_SEND_ACCEPT"] = "仍要傳送" -- MT

-- UI strings (Phase 3A-2): Editor header
L["GEMS_UI_SEQ_ICON"] = "圖示" -- MT
L["GEMS_UI_STEP_FUNCTION"] = "步驟函式" -- MT
L["GEMS_UI_RESET_COMBAT"] = "戰鬥結束時重置" -- MT
L["GEMS_UI_RESET_COMBAT_DESC"] = "戰鬥結束時重置步驟計數器" -- MT
L["GEMS_UI_RESET_TARGET"] = "目標變更時重置" -- MT
L["GEMS_UI_RESET_TARGET_DESC"] = "目標變更時重置步驟計數器 (僅戰鬥外)" -- MT
L["GEMS_UI_RESET_GEAR"] = "裝備變更" -- MT
L["GEMS_UI_RESET_GEAR_DESC"] = "裝備變更時重置步驟計數器 (僅戰鬥外)" -- MT
L["GEMS_UI_RESET_SPEC"] = "專精變更" -- MT
L["GEMS_UI_RESET_SPEC_DESC"] = "專精變更時重置步驟計數器" -- MT
L["GEMS_UI_RESET_TIMER"] = "計時器 (秒)" -- MT
L["GEMS_UI_RESET_TIMER_DESC"] = "經過此秒數無動作後重置步驟計數器 (0 為停用)" -- MT
L["GEMS_UI_REPEAT_COUNT"] = "Repeat" -- MT
L["GEMS_UI_REPEAT_COUNT_DESC"] =
    "Number of times to run the full sequence before cycling back to step 1. Use 1 (default) for infinite cycling. Best paired with the Sequential step function -- Priority/Reverse Priority combinations expand the weighted distribution across the repeats." -- MT
L["GEMS_UI_KEYPRESS"] = "按下" -- MT
L["GEMS_UI_KEYPRESS_DESC"] =
    "在每個步驟觸發前,於按鍵按下時執行的指令 (例如 /stopmacro [channeling])。當總長度在 255 字元內時,會合併到每個步驟的巨集中。超過上限的步驟將不執行 KeyPress -- 請查看預覽分頁了解哪些步驟符合。" -- MT
L["GEMS_UI_KEYRELEASE"] = "釋放" -- MT
L["GEMS_UI_KEYRELEASE_DESC"] =
    "在每個步驟觸發後,於按鍵釋放時執行的指令。當總長度在 255 字元內時,會合併到每個步驟的巨集中。超過上限的步驟將不執行 KeyRelease -- 請查看預覽分頁了解哪些步驟符合。" -- MT

-- UI strings: Metadata section
L["GEMS_EDITOR_METADATA"] = "元資料" -- MT
L["GEMS_EDITOR_METADATA_AUTHOR"] = "作者" -- MT
L["GEMS_EDITOR_METADATA_DESCRIPTION"] = "描述" -- MT
L["GEMS_EDITOR_METADATA_HELP"] = "說明文字" -- MT
L["GEMS_EDITOR_METADATA_HELPLINK"] = "說明連結" -- MT
L["GEMS_EDITOR_METADATA_CLASS"] = "職業" -- MT
L["GEMS_EDITOR_METADATA_SPEC"] = "專精" -- MT
L["GEMS_EDITOR_METADATA_CREATED"] = "建立" -- MT
L["GEMS_EDITOR_METADATA_UPDATED"] = "更新" -- MT

-- Per-sequence sound cue overrides (Phase 4 item 22 Phase 2)
L["GEMS_EDITOR_SEQ_SOUND_HEADER"] = "序列聲音提示 (選填)" -- MT
L["GEMS_EDITOR_SEQ_SOUND_DESC"] = "覆寫此序列的全域提示音。留空以使用全域設定。" -- MT
L["GEMS_EDITOR_SEQ_SOUND_ERROR"] = "錯誤提示" -- MT
L["GEMS_EDITOR_SEQ_SOUND_SUCCESS"] = "成功提示" -- MT
L["GEMS_EDITOR_SEQ_SOUND_INFO"] = "資訊提示" -- MT
L["GEMS_EDITOR_SEQ_SOUND_STEP"] = "步驟提示" -- MT
L["GEMS_EDITOR_SEQ_SOUND_NONE"] = "(全域預設)" -- MT

-- UI strings: Dependencies section
L["GEMS_DEPS_HEADER"] = "相依性" -- MT
L["GEMS_DEPS_VARIABLES"] = "變數" -- MT
L["GEMS_DEPS_SEQUENCES"] = "序列" -- MT
L["GEMS_DEPS_EMBEDDED_BY"] = "被內嵌於" -- MT
L["GEMS_DEPS_NONE"] = "(無)" -- MT
L["GEMS_DEPS_NOT_EMBEDDED"] = "未被任何序列內嵌" -- MT
L["GEMS_DEPS_MACROS"] = "Macros" -- MT
L["GEMS_UI_MACRO_DEPS_SECTION"] = "Macro Dependencies" -- MT
L["GEMS_UI_MACRO_DEPS_HINT"] = "Tag macros this sequence uses so they auto-include on export." -- MT
L["GEMS_UI_MACRO_DEPS_EMPTY"] = "No macros found. Use /macro to create one." -- MT

-- UI strings (Phase 3A-2): Tabs
L["GEMS_UI_TAB_STEPS"] = "步驟" -- MT
L["GEMS_UI_TAB_KEYBIND"] = "按鍵綁定" -- MT
L["GEMS_UI_TAB_VARIABLES"] = "變數" -- MT
L["GEMS_UI_TAB_RAW"] = "原始" -- MT
L["GEMS_UI_TAB_COMING_SOON"] = "即將推出" -- MT

-- UI strings (Phase 3A-2): Step list
L["GEMS_UI_STEP_NUM"] = "#%d" -- MT
L["GEMS_UI_NO_STEPS"] = "未定義步驟。" -- MT
L["GEMS_UI_ADD_STEP_HINT"] = "無步驟。點擊 '+ 新增' 建立一個。" -- MT

-- UI strings (Phase 3A-2): Dialogs
L["GEMS_UI_NEW_SEQ_DESC"] = "輸入新序列的名稱:" -- MT
L["GEMS_UI_DELETE_CONFIRM"] = "確定要刪除 '%s' 嗎?此操作無法復原。" -- MT
L["GEMS_UI_DUP_DESC"] = "輸入複製版本的名稱:" -- MT
L["GEMS_UI_RENAME_DESC"] = "輸入新名稱:" -- MT
L["GEMS_UI_NAME_EXISTS"] = "已存在名為 '%s' 的序列。" -- MT
L["GEMS_UI_RENAME_PLUGIN_OWNED"] = "Cannot rename '%s': it is managed by plugin '%s'." -- MT
L["GEMS_UI_NAME_EMPTY"] = "序列名稱不能為空。" -- MT

-- UI strings (Phase 3A-2): Status text in rows
L["GEMS_UI_ROW_SUBTITLE"] = "%s | %d 個步驟" -- MT

-- UI strings (Phase 3A-2): Sort
L["GEMS_UI_SORT_ALPHA"] = "A-Z" -- MT
L["GEMS_UI_SORT_CLASS"] = "職業" -- MT
L["GEMS_UI_SORT_UPDATED"] = "最近" -- MT
L["GEMS_UI_SORT_ALPHA_TIP"] = "按字母順序" -- MT
L["GEMS_UI_SORT_CLASS_TIP"] = "依職業" -- MT
L["GEMS_UI_SORT_UPDATED_TIP"] = "最近更新" -- MT
L["GEMS_UI_SORT_HINT"] = "排序" -- MT
L["GEMS_UI_SORT_CYCLE"] = "點擊以循環排序模式" -- MT

-- Spell validation (v1.1.0)
L["GEMS_SPELL_WARN_BANNER"] = "此序列中可能有 %d 個無效法術" -- MT
L["GEMS_SPELL_VALIDATE_SUMMARY"] = "已檢查 %d 個序列: %d 個無問題,%d 個有警告" -- MT
L["GEMS_SPELL_VALIDATE_CLEAN"] = "所有序列已驗證 -- 未發現問題" -- MT
L["GEMS_SPELL_VALIDATE_SEQ"] = "  %s: %d 個未知,%d 個天賦限定" -- MT
L["GEMS_SPELL_STATUS_LABEL"] = "可能有 %d 個無效法術" -- MT
L["GEMS_SPELL_INFO_LABEL"] = "%d 個已知但未學習" -- MT
L["GEMS_IMPORT_FREEFORM_WARN"] =
    "'%s': %d 個步驟包含原始巨集指令。它們不會自動翻譯為其他語系。" -- MT
L["GEMS_IMPORT_FREEFORM_LABEL"] = "%d 個自由格式" -- MT
L["GEMS_IMPORT_ICON_AUTO"] = "(自動偵測)" -- MT
L["GEMS_IMPORT_PICK_AUTO"] = "[自動]" -- MT
L["GEMS_IMPORT_PICK_VAR_DEPS"] = "使用 %d 個變數" -- MT
L["GEMS_SPELL_TOOLTIP_UNKNOWN"] = "找不到: %s" -- MT
L["GEMS_SPELL_TOOLTIP_KNOWN"] = "不在法術書中: %s" -- MT
L["GEMS_SPELL_TOOLTIP_COSMETIC"] = "|cff888888#showtooltip: %s|r" -- MT

-- Rotation Preview (v1.1.0)
L["GEMS_PLUGIN_LOADED"] = "已為 %s 載入外掛序列" -- MT
L["GEMS_PLUGIN_NOT_FOUND"] = "未知外掛: %s" -- MT
L["GEMS_PLUGIN_REGISTERED"] = "外掛已註冊: %s v%s (%d 個序列)" -- MT
L["GEMS_PLUGIN_SKIP_EXISTS"] = "外掛 %s: 略過 '%s' (使用者版本已存在)" -- MT

L["GEMS_PREVIEW_ICONS"] = "圖示" -- MT
L["GEMS_PREVIEW_TEXT"] = "文字" -- MT
L["GEMS_PREVIEW_TOGGLE_TIP"] = "切換預覽模式" -- MT
L["GEMS_PREVIEW_RANDOM_HINT"] = "隨機 -- 任何一個都可能觸發" -- MT
L["GEMS_PREVIEW_STEP_TOOLTIP"] = "步驟 %d: %s" -- MT
L["GEMS_PREVIEW_SPELL_TOOLTIP"] = "法術: %s" -- MT
L["GEMS_PREVIEW_COMPILED"] = "已編譯" -- MT
L["GEMS_PREVIEW_COMPILED_TIP"] = "顯示每個步驟的編譯後巨集 (WoW 實際執行的內容)" -- MT
L["GEMS_PREVIEW_KP_FIT"] = "%d/%d 個步驟符合 keyPress+keyRelease" -- MT
L["GEMS_PREVIEW_KP_DROPPED"] = "紅色步驟的 KeyPress/KeyRelease 已被捨棄 (對 255 字元上限太長)" -- MT
L["GEMS_PREVIEW_COPY"] = "複製" -- MT
L["GEMS_PREVIEW_COPY_TIP"] = "將循環預覽複製到剪貼簿" -- MT

-- UI strings (Phase 3A-2): Editor misc
L["GEMS_UI_ICON_HINT"] = "點擊以變更圖示" -- MT
L["GEMS_UI_DUPLICATE_FAILED"] = "複製失敗。" -- MT
L["GEMS_UI_COPY_SUFFIX"] = "_copy" -- MT

-- UI strings (Phase 3A-2): Step function labels
L["GEMS_UI_SF_SEQUENTIAL"] = "順序" -- MT
L["GEMS_UI_SF_RANDOM"] = "隨機" -- MT
L["GEMS_UI_SF_PRIORITY"] = "優先順序" -- MT
L["GEMS_UI_SF_REVERSEPRIORITY"] = "反向優先" -- MT

-- UI strings (Phase 3B-1): Step editor
L["GEMS_UI_ADD_STEP"] = "+ 新增" -- MT
L["GEMS_UI_ADD_STEP_DESC"] = "在所選步驟下方新增一個空步驟" -- MT
L["GEMS_UI_DUP_STEP"] = "複製" -- MT
L["GEMS_UI_DUP_STEP_DESC"] = "複製所選步驟" -- MT
L["GEMS_UI_MOVE_UP"] = "上移" -- MT
L["GEMS_UI_MOVE_UP_DESC"] = "將所選步驟上移" -- MT
L["GEMS_UI_MOVE_DOWN"] = "下移" -- MT
L["GEMS_UI_MOVE_DOWN_DESC"] = "將所選步驟下移" -- MT

L["GEMS_UI_DEL_STEP"] = "刪除" -- MT
L["GEMS_UI_DEL_STEP_DESC"] = "刪除所選步驟" -- MT
L["GEMS_UI_STEP_HEADER"] = "步驟 %d:" -- MT
L["GEMS_UI_SELECT_STEP"] = "選擇要編輯的步驟" -- MT
L["GEMS_UI_DELETE_STEP_CONFIRM"] = "刪除步驟 %d?此操作無法復原。" -- MT
L["GEMS_UI_CTX_DUP_STEP"] = "複製步驟" -- MT
L["GEMS_UI_CTX_MOVE_UP"] = "上移" -- MT
L["GEMS_UI_CTX_MOVE_DOWN"] = "下移" -- MT
L["GEMS_UI_CTX_DELETE_STEP"] = "刪除步驟" -- MT
L["GEMS_UI_DRAG_HANDLE_DESC"] = "拖曳以重新排序" -- MT
L["GEMS_UI_EXPORT_BTN_EDITOR"] = "匯出" -- MT
L["GEMS_UI_EXPORT_BTN_EDITOR_DESC"] = "將此序列匯出為 GRIP-EMS 字串" -- MT
L["GEMS_UI_NAME_TOOLTIP"] = "序列名稱" -- MT
L["GEMS_UI_NAME_EDIT_HINT"] = "點擊以重新命名。按 Enter 確認,Escape 取消。" -- MT
L["GEMS_UI_SAVE_PROMPT"] = "儲存對 '%s' 的變更?" -- MT
L["GEMS_UI_SAVE"] = "儲存" -- MT
L["GEMS_UI_SAVE_BTN_DESC"] = "儲存對此序列的變更" -- MT
L["GEMS_UI_DISCARD"] = "捨棄" -- MT
L["GEMS_UI_DISCARD_BTN_DESC"] = "捨棄變更並回到上次儲存的版本" -- MT
L["GEMS_UI_SAVE_COMBAT"] = "戰鬥中無法使用" -- MT
L["GEMS_UI_ENABLE"] = "啟用" -- MT
L["GEMS_UI_DISABLE"] = "停用" -- MT
L["GEMS_UI_ENABLE_BTN_DESC"] = "重新啟用此序列 (重新開啟按鈕和按鍵綁定)" -- MT
L["GEMS_UI_DISABLE_BTN_DESC"] = "停用此序列 (移除按鈕和按鍵綁定,保留資料)" -- MT
L["GEMS_UI_DISABLED_BADGE"] = "[已停用]" -- MT

-- Version bar (UX-4)
L["GEMS_VERSION_OF"] = "版本 %d / %d" -- MT
L["GEMS_VERSION_LABEL"] = "版本 %d" -- MT
L["GEMS_VERSION_DEFAULT_SUFFIX"] = " (預設)" -- MT
L["GEMS_VERSION_DEFAULT_MARKER"] = " (*)" -- MT

L["GEMS_VERSION_TOOLTIP_TITLE"] = "版本" -- MT
L["GEMS_VERSION_TOOLTIP_DESC"] = "選擇要編輯的版本" -- MT
L["GEMS_VERSION_ADD_TITLE"] = "新增版本" -- MT
L["GEMS_VERSION_ADD_DESC"] = "建立新的空版本" -- MT
L["GEMS_VERSION_DUP_TITLE"] = "複製版本" -- MT
L["GEMS_VERSION_DUP_DESC"] = "將目前版本複製到新版本" -- MT
L["GEMS_VERSION_DEL_TITLE"] = "刪除版本" -- MT
L["GEMS_VERSION_DEL_DESC"] = "移除目前版本" -- MT
L["GEMS_VERSION_DEFAULT_TITLE"] = "設為預設" -- MT
L["GEMS_VERSION_DEFAULT_DESC"] = "將此版本標記為執行的預設" -- MT

-- Phase 3B-2: Keybind tab
L["GEMS_UI_CURRENT_KEYBIND"] = "目前按鍵綁定" -- MT
L["GEMS_UI_KEYBIND_DISPLAY_NONE"] = "無" -- MT
L["GEMS_UI_SET_KEYBIND"] = "設定按鍵綁定" -- MT
L["GEMS_UI_CHANGE_KEYBIND"] = "變更" -- MT
L["GEMS_UI_CLEAR_KEYBIND"] = "清除" -- MT
L["GEMS_UI_PRESS_KEY"] = "按下按鍵..." -- MT
L["GEMS_UI_KEYBIND_HINT"] =
    "按鍵綁定依專精儲存於您的 GRIP-EMS 設定檔中。它們不會變更您的正常 WoW 按鍵綁定。" -- MT
L["GEMS_UI_CAPTURE_COMBAT"] = "戰鬥中無法擷取按鍵綁定。" -- MT
L["GEMS_UI_SPEC_KEYBINDS"] = "依專精的按鍵綁定" -- MT
L["GEMS_UI_CURRENT_SPEC"] = "(目前)" -- MT
L["GEMS_UI_LOADOUT_COMING_SOON"] = "依天賦配置的按鍵綁定: 即將推出" -- MT
L["GEMS_UI_CAPTURE_ESC_HINT"] = "(按 ESC 取消)" -- MT
L["GEMS_UI_KEYBIND_CONFLICT"] = "%s 原本綁定至 '%s'。現已綁定至此序列。" -- MT
L["GEMS_UI_KEYBIND_CP_CONFLICT"] = "%s 在 ConsolePort 中綁定至 '%s'。EMS 將在序列作用時覆寫該綁定。" -- MT
L["GEMS_KEYBIND_MOUSE_NEEDS_MODIFIER"] = "Mouse1 和 Mouse2 需要修飾鍵 (Alt、Ctrl 或 Shift) 才能綁定。" -- MT
L["GEMS_UI_GAMEPAD_HINT"] = "偵測到控制器 -- 您可以綁定遊戲手把按鍵。" -- MT
L["GEMS_UI_SIMPLIFIED_LOCKED_HINT"] =
    "簡化模式已開啟。點擊解鎖編輯器以編輯此序列，或在設定中關閉簡化模式。" -- MT

-- Phase 3B-2: Macros tab
L["GEMS_UI_TAB_MACROS"] = "巨集" -- MT
L["GEMS_UI_MACRO_STUB_SECTION"] = "巨集樁" -- MT
L["GEMS_UI_STUB_INFO"] = "%s (欄位 %d)" -- MT
L["GEMS_UI_STUB_NONE"] = "無巨集樁" -- MT
L["GEMS_UI_SLOTS_USED"] = "已使用 %d / %d 個角色巨集欄位" -- MT
L["GEMS_UI_REFRESH_STUBS"] = "重新整理" -- MT
L["GEMS_UI_REFRESH_STUBS_DESC"] = "重新掃描現有的 GRIP-EMS 巨集樁" -- MT
L["GEMS_UI_CLEAN_ORPHANS"] = "清除孤立項" -- MT
L["GEMS_UI_CLEAN_ORPHANS_DESC"] = "刪除已不存在序列的巨集樁" -- MT
L["GEMS_UI_CLEAN_CONFIRM"] = "刪除 %d 個孤立的巨集樁?此操作無法復原。" -- MT
L["GEMS_UI_ORPHANS_CLEANED"] = "已清除 %d 個孤立的巨集樁。" -- MT
L["GEMS_UI_NO_ORPHANS"] = "找不到孤立的巨集樁。" -- MT
L["GEMS_UI_STUB_LIST_HEADER"] = "所有巨集樁 (%d)" -- MT
L["GEMS_UI_NO_STUBS"] = "找不到巨集樁。" -- MT
L["GEMS_UI_STUBS_MORE"] = "還有 %d 個巨集樁未顯示" -- MT

-- Phase 3B-2: Priority preview

-- Phase 3C-1: Spell autocomplete

-- Phase 3C-2: Icon picker
L["GEMS_UI_ICON_PICKER_TITLE"] = "選擇圖示" -- MT
L["GEMS_UI_AUTO_DETECT"] = "自動偵測" -- MT
L["GEMS_UI_AUTO_DETECT_DESC"] = "從第一個 /cast 法術自動偵測圖示" -- MT

-- Context version selection (T2-1)
L["GEMS_CONTEXT_CHANGED"] = "情境已變更: %s" -- MT
L["GEMS_CONTEXT_NONE_LABEL"] = "無" -- MT
L["GEMS_CONTEXT_RELOAD"] = "已切換情境: 重新載入了 %d 個序列" -- MT

-- Context tab (T2-1b)
L["GEMS_UI_TAB_CONTEXT"] = "情境" -- MT
L["GEMS_CONTEXT_DEFAULT_LABEL"] = "預設版本: %d" -- MT

L["GEMS_CONTEXT_CURRENT_INFO"] = "目前情境: %s" -- MT
L["GEMS_CONTEXT_VIEWING"] = "版本 %d 的指派" -- MT
L["GEMS_CONTEXT_NO_VERSIONS"] = "新增第二個版本以設定情境覆寫。" -- MT
L["GEMS_CONTEXT_HINT"] =
    "勾選此版本應作用的內容類型。未勾選的情境會回退至更廣泛的類別 (例如:傳奇鑰石回退至地下城,然後預設)。" -- MT
L["GEMS_CONTEXT_CONFLICT_MSG"] = "%s 已指派至版本 %d。\n要重新指派至版本 %d 嗎?" -- MT
L["GEMS_CONTEXT_CONFLICT_MULTI_MSG"] =
    "此群組中有 %d 個情境已指派至其他版本。\n要將它們全部重新指派至版本 %d 嗎?" -- MT
L["GEMS_CONTEXT_SELECT_ALL_TIP"] =
    "將此群組中的所有情境指派至目前檢視的版本。已指派至其他版本的情境會要求一次確認。" -- MT
L["GEMS_CONTEXT_CLEAR_ALL_TIP"] =
    "清除此群組在目前檢視版本下的指派。屬於其他版本的指派保持不變。" -- MT
L["GEMS_CONTEXT_DEFAULT_TIP_TITLE"] = "預設版本" -- MT
L["GEMS_CONTEXT_DEFAULT_TIP_TEXT"] = "當沒有符合的情境覆寫時所使用的版本。" -- MT
L["GEMS_CONTEXT_ASSIGNED_OTHER"] = "(版本 %d)" -- MT
L["GEMS_CONTEXT_GROUP_RAIDS"] = "團隊副本" -- MT
L["GEMS_CONTEXT_GROUP_DUNGEONS"] = "地下城" -- MT
L["GEMS_CONTEXT_GROUP_PVP"] = "PvP" -- MT
L["GEMS_CONTEXT_GROUP_ARENA_MAPS"] = "競技場地圖" -- MT
L["GEMS_CONTEXT_GROUP_BG_MAPS"] = "戰場地圖" -- MT
L["GEMS_CONTEXT_GROUP_OTHER"] = "其他" -- MT
L["GEMS_CONTEXT_WRONG_VERSION"] = "%s 已指派至版本 %d。切換至該版本來修改它。" -- MT

-- Context group buttons and fallback chain (v1.2.0 S19)
L["GEMS_CONTEXT_SELECT_ALL"] = "全部" -- MT
L["GEMS_CONTEXT_CLEAR_ALL"] = "無" -- MT
L["GEMS_CONTEXT_FALLBACK_NONE"] = "無作用情境 -- 預設版本 %d" -- MT
L["GEMS_CONTEXT_FALLBACK_MATCH"] = " (v%d)" -- MT
L["GEMS_CONTEXT_FALLBACK_DEFAULT"] = "預設" -- MT
L["GEMS_CONTEXT_FALLBACK_SEP"] = " > " -- MT
L["GEMS_SETTINGS_CONTEXT_HEADER"] = "情境偵測" -- MT
L["GEMS_SETTINGS_CONTEXT_DESC"] = "選擇外掛如何根據您正在進行的內容自動選擇正確的版本。" -- MT
L["GEMS_SETTINGS_MPLUS_MID"] = "傳奇鑰石中階" -- MT
L["GEMS_SETTINGS_MPLUS_MID_DESC"] = "傳奇鑰石內容類型從低階變為中階的鑰石等級。" -- MT
L["GEMS_SETTINGS_MPLUS_HIGH"] = "傳奇鑰石高階" -- MT
L["GEMS_SETTINGS_MPLUS_HIGH_DESC"] = "傳奇鑰石內容類型從中階變為高階的鑰石等級。" -- MT
L["GEMS_SETTINGS_DELVES_HIGH"] = "深淵高階" -- MT
L["GEMS_SETTINGS_DELVES_HIGH_DESC"] = "深淵內容類型從低階變為高階的層級。" -- MT

-- Context migration (T2-3)

-- Phase 2B: Migration
L["GEMS_HELP_MIGRATE"] = "  /gems migrate - 從另一個序列器遷移序列" -- MT
L["GEMS_UI_MIGRATE_BTN"] = "遷移" -- MT
L["GEMS_UI_MIGRATE_BTN_DESC"] = "從另一個序列器匯入所有序列" -- MT
L["GEMS_MIGRATE_NO_SOURCE"] = "找不到相容的序列器。" -- MT
L["GEMS_MIGRATE_SOURCE_DISABLED"] =
    "已安裝相容的序列器但已停用。在 AddOns 清單中啟用它,然後 /reload 以遷移。" -- MT
L["GEMS_MIGRATE_FAILED"] = "遷移失敗: %s" -- MT
L["GEMS_MIGRATE_CONFIRM"] =
    "從您先前的序列器遷移所有序列?\n\n找到 %d 個序列。同名的現有序列將被略過。" -- MT
L["GEMS_DELETE_COMBAT"] = "戰鬥中無法刪除序列。" -- MT
L["GEMS_MIGRATE_COMBAT"] = "戰鬥中無法遷移。請於戰鬥後再試。" -- MT
L["GEMS_MIGRATE_EMPTY"] = "在來源資料庫中找不到序列。" -- MT
L["GEMS_MIGRATE_SKIPPED"] = "%s (已存在,已略過)" -- MT
L["GEMS_MIGRATE_KEYBINDS"] = "按鍵綁定: %d 個已遷移,%d 個已略過,%d 個衝突" -- MT
L["GEMS_MIGRATE_AO_WARNING"] =
    "%d 個動作條綁定未遷移。EMS 綁定的是按鍵,而非動作條欄位。請使用 /gems bind 來設定。" -- MT

-- Phase 2C: Export frame
L["GEMS_EXPORT_FRAME_LABEL"] = "已匯出: %s" -- MT
L["GEMS_EXPORT_FRAME_HINT"] = "按 Ctrl+C 複製,然後貼到另一位玩家的匯入視窗。" -- MT

-- Phase 3C-3: Variable system
L["GEMS_VAR_EVAL_ERROR"] = "變數 '%s' 求值失敗: %s" -- MT
L["GEMS_VAR_INVALID_NAME"] = "變數名稱必須只使用字母、數字或底線 (a-z、0-9、_)。" -- MT
L["GEMS_VAR_NAME_TOO_LONG"] = "變數名稱超過 %d 字元" -- MT
L["GEMS_VAR_FUNC_TOO_LONG"] = "變數函式超過 %d 字元" -- MT
L["GEMS_VAR_NAME_EMPTY"] = "變數名稱不能為空" -- MT
L["GEMS_VAR_NAME_EXISTS"] = "變數 '%s' 已存在" -- MT
L["GEMS_VAR_DELETED"] = "變數 '%s' 已刪除" -- MT
L["GEMS_VAR_SAVED"] = "變數 '%s' 已儲存" -- MT

L["GEMS_VAR_IMPORT_PAUSE"] = "含變數的暫停已轉換為註解" -- MT
L["GEMS_VAR_IMPORT_SKIPPED"] = "已略過 %d 個變數 (已存在)。" -- MT
L["GEMS_VAR_RECOMPILE"] = "重新編譯 '%s' (變數已變更)" -- MT

-- Phase 3C-3b: Variables Tab UI
L["GEMS_VAR_TAB_EMPTY"] = "未定義變數。點擊新建以建立一個。" -- MT
L["GEMS_VAR_NEW"] = "新變數" -- MT
L["GEMS_VAR_NAME_LABEL"] = "名稱" -- MT
L["GEMS_VAR_FUNC_LABEL"] = "函式內容" -- MT
L["GEMS_VAR_FUNC_PLACEHOLDER"] = "return GetHaste() > 20" -- MT
L["GEMS_VAR_EVENTS_LABEL"] = "事件 (以逗號分隔)" -- MT
L["GEMS_VAR_EVENTS_PLACEHOLDER"] = "SPELL_CAST_SUCCESS, UNIT_AURA" -- MT
L["GEMS_VAR_COMMENTS_LABEL"] = "註解" -- MT
L["GEMS_VAR_DISABLED_LABEL"] = "已停用" -- MT
L["GEMS_VAR_SAVE"] = "儲存" -- MT
L["GEMS_VAR_TEST"] = "測試" -- MT
L["GEMS_VAR_TEST_RESULT"] = "變數 '%s' = %s" -- MT
L["GEMS_VAR_TEST_ERROR"] = "變數 '%s' 錯誤: %s" -- MT
L["GEMS_VAR_VALID"] = "有效" -- MT
L["GEMS_VAR_INVALID"] = "錯誤: %s" -- MT
L["GEMS_VAR_USED_BY"] = "被使用於: %s" -- MT
L["GEMS_VAR_NOT_USED"] = "未被任何序列使用" -- MT
L["GEMS_VAR_DELETE_CONFIRM"] = "刪除變數 '%s'?" -- MT
L["GEMS_VAR_DELETE_REFS_WARN"] = "此變數被 %d 個序列使用。仍要刪除嗎?" -- MT
L["GEMS_VAR_RENAME"] = "重新命名變數" -- MT
L["GEMS_VAR_EVENTS_BROWSE"] = "瀏覽事件" -- MT
L["GEMS_VAR_NEW_DESC"] = "建立新變數" -- MT
L["GEMS_VAR_SAVE_DESC"] = "儲存對此變數的變更" -- MT
L["GEMS_VAR_TEST_DESC"] = "執行函式並顯示結果" -- MT
L["GEMS_VAR_DELETE_DESC"] = "永久刪除此變數" -- MT
L["GEMS_VAR_EVENTS_BROWSE_TIP"] = "點擊以瀏覽可用事件" -- MT

L["GEMS_VAR_EVENTS_ENABLED_DESC"] =
    "未勾選時,此變數會停止監聽事件。事件清單會保留以供稍後重新開啟。" -- MT
L["GEMS_VAR_LOCALE_WARN"] = "變數傳回法術名稱 '%s'。為了語系安全,請使用: %s" -- MT
L["GEMS_VAR_PRIVATE_AURA_WARN"] =
    "Variable returns spell '%s' (ID %d) whose aura is marked private; addon detection (UnitAura) will return nil." -- MT
L["GEMS_VAR_FUNC_HELP"] =
    "可用的輔助函式 (12.0+ 戰鬥中安全):\n  GRIPEMS.HasBuff(spellID, unit) - 單位是否擁有此增益\n  GRIPEMS.HasDebuff(spellID, unit) - 單位是否擁有此減益\n  GRIPEMS.SpellReady(spellID) - 法術目前是否可使用\n  GRIPEMS.SpellOnCooldown(spellID) - 法術是否在冷卻中\n  GRIPEMS.SpellEnabled(spellID) - 法術是否啟用\n  GRIPEMS.IsRestricted() - 是否任何外掛動作限制作用中\nunit 預設為 'player'。所有輔助函式在缺失法術時傳回 false。\n\n隱私光環注意事項: 部分 12.0+ 光環標記為私人並從外掛迭代中隱藏。HasBuff 和 HasDebuff 無法偵測這些。如果您在遊戲中看到增益但輔助函式傳回 false,可能是隱私光環。\n\n為了語系安全的法術名稱,請使用 C_Spell.GetSpellName(spellID)。範例: C_Spell.GetSpellName(133) 而非 'Fireball'。" -- MT
L["GEMS_VAR_INSERT_HELPER"] = "插入輔助函式" -- MT
L["GEMS_VAR_INSERT_HELPER_TIP"] = "在游標位置插入條件輔助函式" -- MT
L["GEMS_VAR_INSERT_HASBUFF_PLAYER_DESC"] = "玩家是否擁有此增益" -- MT
L["GEMS_VAR_INSERT_HASBUFF_TARGET_DESC"] = "目標是否擁有此增益" -- MT
L["GEMS_VAR_INSERT_HASDEBUFF_PLAYER_DESC"] = "玩家是否擁有此減益" -- MT
L["GEMS_VAR_INSERT_HASDEBUFF_TARGET_DESC"] = "目標是否擁有此減益" -- MT
L["GEMS_VAR_INSERT_SPELLREADY_DESC"] = "法術目前是否可使用" -- MT
L["GEMS_VAR_INSERT_SPELLONCD_DESC"] = "法術是否在冷卻中" -- MT
L["GEMS_VAR_INSERT_SPELLENABLED_DESC"] = "法術是否啟用" -- MT
L["GEMS_VAR_INSERT_ISRESTRICTED_DESC"] = "是否任何外掛動作限制作用中" -- MT

-- Raw tab
L["GEMS_RAW_TITLE"] = "原始資料" -- MT
L["GEMS_RAW_EDIT"] = "編輯" -- MT
L["GEMS_RAW_APPLY"] = "套用" -- MT
L["GEMS_RAW_CANCEL"] = "取消" -- MT
L["GEMS_RAW_INVALID"] = "無效: %s" -- MT
L["GEMS_RAW_MISSING_FIELD"] = "缺少必要欄位: %s" -- MT
L["GEMS_RAW_APPLIED"] = "變更已套用" -- MT
L["GEMS_RAW_NAME_IGNORED"] = "已忽略名稱變更。請從右鍵選單使用重新命名。" -- MT
L["GEMS_RAW_NO_SEQUENCE"] = "未選擇序列" -- MT
L["GEMS_RAW_READONLY_HINT"] = "點擊編輯以修改。變更會在套用前進行檢查。" -- MT
L["GEMS_RAW_CANCEL_DESC"] = "關閉而不套用變更" -- MT
L["GEMS_RAW_EDIT_DESC"] = "解析並套用 Lua 表作為序列資料" -- MT

-- Step action bar (Save + hint)
L["GEMS_STEP_SAVE"] = "儲存" -- MT
L["GEMS_STEP_SAVE_DESC"] = "儲存所有步驟變更至序列" -- MT
L["GEMS_STEP_UNSAVED_HINT"] = "未儲存的變更" -- MT

-- Engine debug
L["GEMS_SEQ_ACTIVATED"] = "序列 '%s' 已啟動 (%d 個步驟)。" -- MT
L["GEMS_SEQ_DEACTIVATED"] = "序列 '%s' 已停用。" -- MT
L["GEMS_SEQUENCE_REFRESH_FAILED"] = "GRIP-EMS: Sequence '%s' edit did not apply. Run /reload to retry." -- MT

L["GEMS_STEP_RESET"] = "序列 '%s' 步驟已重置為 1。" -- MT
L["GEMS_STEP_ADVANCED"] = "序列 '%s' 步驟已推進至 %d/%d。" -- MT
L["GEMS_COMBAT_RESET"] = "序列 '%s' 已重置 (戰鬥結束)。" -- MT
L["GEMS_TARGET_RESET"] = "序列 '%s' 已重置 (目標變更)。" -- MT
L["GEMS_GEAR_RESET"] = "%s: 因裝備變更而重置 (原步驟 %d,欄位 %d)。" -- MT
L["GEMS_SPEC_RESET"] = "%s: 因專精變更而重置 (原步驟 %d)。" -- MT
L["GEMS_RESTORED"] = "已還原 %d 個已儲存序列。" -- MT

-- Compiler messages
L["GEMS_COMPILE_DEPTH_EXCEEDED"] =
    "已超過序列最大巢狀深度 (%d) -- 已從編譯步驟中捨棄一個 Loop 或其他巢狀節點。請在步驟分頁中減少巢狀。" -- MT

-- Settings panel (T1-1 + T1-7)
L["GEMS_HELP_SETTINGS"] = "  /gems settings|config|options - 開啟設定面板" -- MT
L["GEMS_SETTINGS_HEADER_DESC"] = "GRIP - 增強巨集序列器的行為與外觀設定。" -- MT
L["GEMS_OVERVIEW_NAME"] = "概覽" -- MT
L["GEMS_OVERVIEW_VERSION_LABEL"] = "版本: %s" -- MT
L["GEMS_OVERVIEW_NAVIGATE_HINT"] = "使用左側樹狀目錄導覽至設定類別。" -- MT
L["GEMS_OVERVIEW_DISCORD_BUTTON"] = "加入 Discord" -- MT
L["GEMS_OVERVIEW_AUTHOR_LINE"] = "由 Sataana 製作" -- MT
L["GEMS_SETTINGS_GENERAL"] = "一般" -- MT
L["GEMS_SETTINGS_OOC_DELAY"] = "戰鬥外佇列延遲 (秒)" -- MT
L["GEMS_SETTINGS_OOC_DELAY_DESC"] =
    "戰鬥結束後等待多久才執行佇列任務。較小的數字會更快執行。預設為 7 秒。重新載入 UI 以套用新值。" -- MT
L["GEMS_SETTINGS_RESET_OOC"] = "戰鬥結束時重置 (預設)" -- MT
L["GEMS_SETTINGS_RESET_OOC_DESC"] =
    "為您建立的任何新序列設定 '戰鬥結束時重置' 的起始值。已建立的序列保持原樣。" -- MT
L["GEMS_SETTINGS_AUTO_RELOAD"] = "Auto-reload sequences at combat end" -- MT
L["GEMS_SETTINGS_AUTO_RELOAD_DESC"] =
    "When ON, EMS auto-applies queued sequence operations (recompile, activate, deactivate, imports) when combat ends. When OFF, queued operations wait until you run /gems apply. Default is ON." -- MT
L["GEMS_APPLY_DRAINED"] = "Applied %d queued operation(s)." -- MT
L["GEMS_APPLY_NOTHING_QUEUED"] = "Nothing queued." -- MT
L["GEMS_APPLY_IN_COMBAT"] =
    "Cannot apply queued operations during combat. Wait for combat to end or run /gems apply afterwards." -- MT
L["GEMS_HELP_APPLY"] = "  /gems apply - Apply queued sequence operations (when Auto-reload is OFF)" -- MT
L["GEMS_SETTINGS_UI"] = "顯示" -- MT
L["GEMS_SETTINGS_HIDE_LOGIN"] = "隱藏登入訊息" -- MT
L["GEMS_SETTINGS_HIDE_LOGIN_DESC"] = "隱藏登入時於聊天框顯示的 'GRIP-EMS vX.X' 訊息。" -- MT

L["GEMS_SETTINGS_DEBUG"] = "偵錯模式" -- MT
L["GEMS_SETTINGS_DEBUG_DESC"] =
    "於聊天框顯示額外的技術訊息。也可以使用 /gems debug 來開啟或關閉。" -- MT
L["GEMS_SETTINGS_INFO"] = "資訊" -- MT
L["GEMS_SETTINGS_VERSION_INFO"] = "GRIP-EMS v%s | %d 個作用中序列" -- MT

-- Accessibility panel (v2.0.0 Phase 1A)
L["ACCESS_PANEL_NAME"] = "輔助使用" -- MT
L["ACCESS_GENERAL_TAB"] = "一般" -- MT
L["ACCESS_THEMING_OVERVIEW_TAB"] = "概覽" -- MT
L["ACCESS_THEMING_CUSTOMIZE_TAB"] = "自訂" -- MT
L["ACCESS_SECTION_DISPLAY"] = "顯示" -- MT
L["ACCESS_SECTION_DISPLAY_DESC"] = "大小與版面選項" -- MT
L["ACCESS_SECTION_MOTION"] = "動態" -- MT
L["ACCESS_SECTION_MOTION_DESC"] = "動畫選項" -- MT
L["ACCESS_SECTION_AUDIO"] = "音訊" -- MT
L["ACCESS_SECTION_AUDIO_DESC"] = "語音與聲音選項" -- MT
L["ACCESS_REDUCE_MOTION_LABEL"] = "減少動態" -- MT
L["ACCESS_REDUCE_MOTION_DESC"] = "關閉脈動、淡入淡出和閃爍動畫。最終顏色和圖示仍會顯示。" -- MT
L["ACCESS_FLICKER_SAFE_LABEL"] = "防閃爍模式" -- MT
L["ACCESS_FLICKER_SAFE_DESC"] =
    "為光敏感使用者靜音節奏與追蹤器動畫的 alpha 脈動。首次執行時從您的暴雪輔助使用設定自動偵測。" -- MT
L["ACCESS_SPEECH_ENABLED_LABEL"] = "語音播報步驟變化" -- MT
L["ACCESS_SPEECH_ENABLED_DESC"] =
    "使用暴雪文字轉語音播報步驟推進與警告。需要在暴雪設定中啟用語音聊天。" -- MT
L["ACCESS_SPEECH_RATE_LABEL"] = "語音速率" -- MT
L["ACCESS_SPEECH_RATE_DESC"] = "更快或更慢的語音。0 為暴雪預設。" -- MT
L["ACCESS_SPEECH_VOLUME_LABEL"] = "語音音量" -- MT
L["ACCESS_SPEECH_VOLUME_DESC"] = "語音播放的音量。" -- MT
L["ACCESS_SPEECH_NO_VOICE_TOAST"] = "在社交選單中啟用暴雪語音聊天以聽見步驟播報。" -- MT
L["ACCESS_SPEECH_STEP_FORMAT"] = "第 %d 步,共 %d 步" -- MT

L["ACCESS_CHAT_EMITTER_ENABLED_LABEL"] = "向聊天視窗發出狀態" -- MT
L["ACCESS_CHAT_EMITTER_ENABLED_DESC"] =
    "將每次序列狀態變更傳送至聊天視窗。僅本機 -- 永不透過網路傳送。螢幕閱讀器橋接器 (BlindSlash、NVDA) 可停駐選定視窗並大聲讀出訊息。與上方語音設定搭配使用。" -- MT
L["ACCESS_CHAT_EMITTER_FRAME_LABEL"] = "聊天視窗插槽" -- MT
L["ACCESS_CHAT_EMITTER_FRAME_DESC"] =
    "10 個聊天視窗中哪一個接收狀態訊息。預設為視窗 9,通常為隱藏 -- 適合螢幕閱讀器橋接器。避免視窗 2 (戰鬥日誌)。" -- MT
L["ACCESS_CHAT_EMITTER_PREFIX"] = "[EMS] " -- MT
L["ACCESS_CHAT_EMITTER_INVALID_TOAST"] = "聊天視窗 %d 無法使用。改用預設聊天視窗。" -- MT
L["ACCESS_STEP_LABEL_LABEL"] = "步驟標籤" -- MT
L["ACCESS_STEP_LABEL_DESC"] = "選用的短名,語音啟用時會大聲讀出,並顯示在步驟編號旁。" -- MT
L["ACCESS_STEP_LABEL_PLACEHOLDER"] = "標籤 (選填)" -- MT
L["ACCESS_MODE_SECTION_NAME"] = "輔助使用模式" -- MT
L["ACCESS_MODE_SECTION_DESC"] =
    "一鍵預設,啟用語音、高對比、減少動態及更大的編輯器。之後您可以微調任何這些設定。" -- MT
L["ACCESS_MODE_TOGGLE_LABEL"] = "啟用輔助使用模式" -- MT
L["ACCESS_MODE_TOGGLE_DESC"] =
    "一步啟用語音、高對比顏色、減少動態及 1.25 倍編輯器縮放。關閉以還原預設值。" -- MT
L["ACCESS_MODE_TOAST_APPLIED"] = "輔助使用模式已開啟。重新載入 UI 以完整生效。" -- MT
L["ACCESS_MODE_TOAST_REVERTED"] =
    "輔助使用模式已關閉。已還原預設值。重新載入 UI 以完整生效。" -- MT
L["ACCESS_MODE_SMALL_DISPLAY_WARNING"] =
    "EMS: 輔助使用模式已開啟,但您的螢幕在此 UI 縮放下太小。MainFrame 可能無法完全顯示。請考慮停用輔助使用模式或使用較大的螢幕。" -- MT
L["ACCESS_CVAR_MIRROR_SECTION_NAME"] = "CVar 自動鏡像" -- MT
L["ACCESS_CVAR_MIRROR_SECTION_DESC"] =
    "首次登入時,將您的暴雪輔助使用設定複製到 EMS。已在 EMS 中變更的設定將保留。" -- MT
L["ACCESS_CVAR_MIRROR_REDETECT_LABEL"] = "重新偵測輔助使用設定" -- MT
L["ACCESS_CVAR_MIRROR_REDETECT_DESC"] =
    "重新檢查您的暴雪色盲、相機動態和遊戲手把設定,並重新套用對應的 EMS 預設。已在 EMS 中變更的設定將保留。" -- MT
L["ACCESS_CVAR_MIRROR_TOAST_APPLIED"] = "GRIP-EMS: 已將 %d 個暴雪輔助使用設定複製到 EMS。" -- MT
L["ACCESS_CVAR_MIRROR_TOAST_NOOP"] = "GRIP-EMS: 沒有需要複製的輔助使用設定。" -- MT

L["ACCESS_FONT_LABEL"] = "UI 字型" -- MT
L["ACCESS_FONT_DESC"] =
    "選擇 EMS 面板和編輯器使用的字型。Atkinson Hyperlegible 已內附,提供有閱讀障礙友善的可讀性 (僅限拉丁文字;其他文字會回退至預設遊戲字型)。" -- MT
L["ACCESS_FONT_RELOAD_NOTICE"] = "重新載入 UI 以使新字型在所有地方生效。" -- MT
L["ACCESS_THEME_SECTION_NAME"] = "主題" -- MT
L["ACCESS_THEME_SECTION_DESC"] =
    "微調背景與邊框透明度、每個面板 alpha,以及影響每個 EMS 面板的全域 UI 縮放。節奏與追蹤器疊層使用固定品牌顏色 -- 透明度滑桿不會變更那些顏色,但疊層 alpha 滑桿仍會淡化它們。" -- MT
L["ACCESS_THEME_UI_SCALE_LABEL"] = "UI 縮放 (所有 EMS 面板)" -- MT
L["ACCESS_THEME_UI_SCALE_DESC"] = "縮放每個 EMS 面板和疊層。1.0 為原生大小。" -- MT
L["ACCESS_THEME_BG_OPACITY_LABEL"] = "背景透明度" -- MT
L["ACCESS_THEME_BG_OPACITY_DESC"] = "面板背景透明度的乘數。1.0 保持主題預設。" -- MT
L["ACCESS_THEME_BORDER_OPACITY_LABEL"] = "邊框透明度" -- MT
L["ACCESS_THEME_BORDER_OPACITY_DESC"] = "面板邊框透明度的乘數。1.0 保持主題預設。" -- MT
L["ACCESS_THEME_PANEL_ALPHA_LABEL"] = "面板 alpha" -- MT
L["ACCESS_THEME_PANEL_ALPHA_DESC"] = "主要 EMS 面板的整體透明度 -- 主視窗、編輯器和對話方塊。" -- MT
L["ACCESS_THEME_OVERLAY_ALPHA_LABEL"] = "疊層 alpha" -- MT
L["ACCESS_THEME_OVERLAY_ALPHA_DESC"] =
    "疊層的整體透明度 (節奏、追蹤器 HUD、浮動選單、最新消息)。" -- MT
L["ACCESS_THEME_RESET_LABEL"] = "重置主題為預設" -- MT
L["ACCESS_THEME_RESET_DESC"] = "將所有主題滑桿還原為 1.0。" -- MT
L["ACCESS_COLORBLIND_SECTION_NAME"] = "色覺" -- MT
L["ACCESS_COLORBLIND_SECTION_DESC"] =
    "若您有色覺缺陷,請於下方挑選最接近的選項並調整修正強度。EMS 將調整自身顏色,使錯誤、警告和重點維持可區分。" -- MT
L["ACCESS_COLORBLIND_TYPE_LABEL"] = "色覺缺陷" -- MT
L["ACCESS_COLORBLIND_TYPE_DESC"] = "套用於對比預設之上。選擇無會停用修正。" -- MT
L["ACCESS_COLORBLIND_TYPE_NONE"] = "無" -- MT
L["ACCESS_COLORBLIND_TYPE_PROTANOMALY"] = "紅色弱視 (紅色反應減少)" -- MT
L["ACCESS_COLORBLIND_TYPE_PROTANOPIA"] = "紅色盲 (無紅色反應)" -- MT
L["ACCESS_COLORBLIND_TYPE_DEUTERANOMALY"] = "綠色弱視 (綠色反應減少)" -- MT
L["ACCESS_COLORBLIND_TYPE_DEUTERANOPIA"] = "綠色盲 (無綠色反應)" -- MT

L["ACCESS_COLORBLIND_TYPE_TRITANOMALY"] = "藍色弱視 (藍色反應減少)" -- MT
L["ACCESS_COLORBLIND_TYPE_TRITANOPIA"] = "藍色盲 (無藍色反應)" -- MT
L["ACCESS_COLORBLIND_TYPE_ACHROMATOMALY"] = "色覺異常 (部分色彩喪失)" -- MT
L["ACCESS_COLORBLIND_TYPE_ACHROMATOPSIA"] = "全色盲 (完全色彩喪失)" -- MT
L["ACCESS_COLORBLIND_STRENGTH_LABEL"] = "修正強度" -- MT
L["ACCESS_COLORBLIND_STRENGTH_DESC"] = "零會保持 EMS 顏色不變。一百會套用所選缺陷的完整修正。" -- MT
L["ACCESS_COLORBLIND_ACHROMAT_HINT"] =
    "在最大強度下,全色盲會將 EMS 顏色摺疊為灰階。如果您偏好基於標籤的提示而非顏色,請將高對比預設與此處的無搭配使用。" -- MT
L["ACCESS_COLORBLIND_PREVIEW_LABEL"] = "預覽:" -- MT
L["ACCESS_COLORBLIND_STACK_WARN"] =
    "所選預設已為此缺陷調校。堆疊可能過度修正 -- 請嘗試預設或降低強度。" -- MT

-- Accessibility Tour (v2.0.0 Phase 3 item 10)
L["ACCESS_TOUR_WELCOME_TITLE"] = "歡迎使用 GRIP-EMS" -- MT
L["ACCESS_TOUR_WELCOME_BODY"] = "此簡短導覽將帶您熟悉序列編輯器。您可以隨時略過。" -- MT
L["ACCESS_TOUR_LIST_TITLE"] = "您的序列" -- MT
L["ACCESS_TOUR_LIST_BODY"] = "此面板列出您的每個序列。點擊一個進行編輯。" -- MT
L["ACCESS_TOUR_STEPS_TITLE"] = "步驟分頁" -- MT
L["ACCESS_TOUR_STEPS_BODY"] = "在這裡為您的序列編寫巨集步驟。每個巨集行對應一個步驟。" -- MT
L["ACCESS_TOUR_MACROS_TITLE"] = "巨集分頁" -- MT
L["ACCESS_TOUR_MACROS_BODY"] = "此分頁顯示產生的巨集欄位。您可以將它們釘選至動作條。" -- MT
L["ACCESS_TOUR_KEYBIND_TITLE"] = "按鍵綁定分頁" -- MT
L["ACCESS_TOUR_KEYBIND_BODY"] = "在這裡將按鍵綁定至序列。擷取新綁定或從清單中選擇。" -- MT
L["ACCESS_TOUR_TEST_TITLE"] = "測試與停用" -- MT
L["ACCESS_TOUR_TEST_BODY"] = "使用此按鈕停用序列而不刪除它。戰鬥中安全。" -- MT
L["ACCESS_TOUR_IMPORT_TITLE"] = "匯入與匯出" -- MT
L["ACCESS_TOUR_IMPORT_BODY"] = "在這裡貼上序列字串以匯入。匯出您的以與其他玩家分享。" -- MT
L["ACCESS_TOUR_DONE_TITLE"] = "您已準備好" -- MT
L["ACCESS_TOUR_DONE_BODY"] =
    "開啟輔助使用設定以調整縮放、對比和語音選項。隨時可使用 /gems tour 重新執行導覽。" -- MT
L["ACCESS_TOUR_BACK"] = "返回" -- MT
L["ACCESS_TOUR_SKIP"] = "略過" -- MT
L["ACCESS_TOUR_NEXT"] = "下一步" -- MT
L["ACCESS_TOUR_DONE"] = "完成" -- MT

L["ACCESS_TOUR_RESET_TOAST"] = "教學已重置。將於下次登入時顯示。" -- MT

-- Accessibility: Help popovers (Phase 3 #11)
L["ACCESS_HELP_BUTTON_LABEL"] = "?" -- MT
L["ACCESS_HELP_BUTTON_TOOLTIP"] = "說明" -- MT
L["ACCESS_HELP_CLOSE"] = "關閉" -- MT
L["ACCESS_HELP_TITLE_STEPS"] = "步驟分頁" -- MT
L["ACCESS_HELP_BODY_STEPS"] =
    "每個列為序列中的一個步驟。新增按鈕可讓您插入法術、物品、巨集或巢狀動作。拖曳列以重新排序。當清單獲得鍵盤焦點時,使用方向鍵在列之間移動。" -- MT
L["ACCESS_HELP_TITLE_KEYBIND"] = "按鍵綁定分頁" -- MT
L["ACCESS_HELP_BODY_KEYBIND"] =
    "設定觸發此序列的按鍵。支援修飾鍵 (Shift、Ctrl、Alt) 和滑鼠按鍵。每個序列只能有一個按鍵綁定。與現有綁定的衝突會內嵌標示。" -- MT
L["ACCESS_HELP_TITLE_MACROS"] = "巨集分頁" -- MT
L["ACCESS_HELP_BODY_MACROS"] =
    "編寫與序列一同執行的輔助巨集行。用於目標、停止施法或任何不需要自己步驟的事情。它們在序列觸發的每個步驟中執行。" -- MT
L["ACCESS_HELP_TITLE_CONTEXT"] = "情境分頁" -- MT
L["ACCESS_HELP_BODY_CONTEXT"] =
    "尚未提供。此分頁將讓您依區域、難度、專精或其他遊戲內情境限制序列。" -- MT
L["ACCESS_HELP_TITLE_VARIABLES"] = "變數分頁" -- MT
L["ACCESS_HELP_BODY_VARIABLES"] =
    "尚未提供。此分頁將讓您定義可重複使用的值,讓步驟以名稱參考。" -- MT
L["ACCESS_HELP_TITLE_RAW"] = "原始分頁" -- MT
L["ACCESS_HELP_BODY_RAW"] = "尚未提供。此分頁將顯示序列完全產生的巨集文字,適用於偵錯。" -- MT
L["ACCESS_HELP_TITLE_DEFAULT"] = "序列編輯器" -- MT
L["ACCESS_HELP_BODY_DEFAULT"] =
    "選擇上方分頁以切換區段。右上角按鈕列處理儲存、捨棄、匯出、停用、錄製和傳送。? 按鈕開啟作用中分頁的說明。" -- MT
L["ACCESS_HELP_TITLE_PICKER"] = "法術 / 物品 / 巨集選擇器" -- MT
L["ACCESS_HELP_BODY_PICKER"] = "搜尋法術、物品、巨集和斜線指令。" -- MT
    .. "使用左側欄依類別篩選。"
    .. "點擊列以將其插入步驟。底部的條件按鈕"
    .. "新增修飾前綴。ESC 關閉。" -- MT

-- About info (T1-5)
L["GEMS_ABOUT_AUTHOR"] = "作者: Sataana (MrSataana)" -- MT
L["GEMS_ABOUT_LINKS"] =
    "指南: jesperlive.github.io/grip-ems-guide/\nCurseForge: curseforge.com/wow/addons/grip-enhanced-macro-sequencer\nWago: addons.wago.io/addons/qGZODqNd\nWoWInterface: wowinterface.com/downloads/info27081" -- MT
L["GEMS_ABOUT_KEYBINDS"] = "作用中按鍵綁定: %d" -- MT
L["GEMS_ABOUT_OOC_QUEUE"] = "戰鬥外佇列: %d 個待處理" -- MT
L["GEMS_ABOUT_SOURCE_STATUS"] = "遷移來源: %s" -- MT
L["GEMS_ABOUT_MACRO_SLOTS"] = "巨集欄位: %d / %d (每個角色)" -- MT
L["GEMS_UI_ACTIVE_SEQUENCES_LABEL"] = "作用中序列" -- MT
L["GEMS_UI_CONTEXT_LABEL"] = "情境" -- MT
L["GEMS_LOGIN_ACTIVE"] = "|cFF888888  %d 個作用中序列|r" -- MT
L["GEMS_UI_SETTINGS_BTN"] = "設定" -- MT
L["GEMS_UI_SETTINGS_BTN_DESC"] = "開啟 GRIP-EMS 設定面板" -- MT

-- Migration report (T1-9)
L["GEMS_REPORT_HEADER_MIGRATE"] = "--- GRIP-EMS Migration Report ---" -- MT
L["GEMS_REPORT_HEADER_IMPORT"] = "--- GRIP-EMS Import Report ---" -- MT
L["GEMS_REPORT_IMPORTED"] = "已匯入: %d 個序列、%d 個變數" -- MT
L["GEMS_REPORT_DORMANT"] = "  (%d 個為其他職業儲存,登入時啟動)" -- MT
L["GEMS_REPORT_SKIPPED"] = "已略過: %d (已存在)" -- MT
L["GEMS_REPORT_SEQ_ENTRY"] = "  + %s (%d 個步驟,%s)" -- MT
L["GEMS_REPORT_LIMITATIONS"] = "已知限制:" -- MT
L["GEMS_REPORT_VERSIONS_DROPPED"] = "  - 未匯入 %d 個額外版本 (僅支援預設版本)" -- MT
L["GEMS_REPORT_PAUSES_CONVERTED"] = "  - %d 個暫停動作已轉換為 %d 個空步驟" -- MT
L["GEMS_REPORT_EMBEDS_SKIPPED"] = "  - %d 個內嵌序列參考已略過 (尚未支援)" -- MT
L["GEMS_REPORT_TRUNCATED"] = "  - %d 個步驟太長已被截斷 (WoW 限制巨集為 255 字元)" -- MT
L["GEMS_REPORT_ENCRYPTED_SKIPPED"] = "  - 已略過 %d 個加密項目（受保護內容，無法匯入）" -- TODO: MT 2026-06-21
L["GEMS_REPORT_TIP_VERIFY"] = "提示: 開啟每個遷移的序列並驗證步驟看起來正確。" -- MT
L["GEMS_REPORT_TIP_VERSIONS"] = "使用 /gems 開啟編輯器並設定情境版本覆寫。" -- MT

-- Guide (T1-10)
L["GEMS_GUIDE_TITLE"] = "GRIP-EMS 互動式指南" -- MT
L["GEMS_GUIDE_PATH"] = "複製此 URL 並在您的瀏覽器中開啟:" -- MT
L["GEMS_GUIDE_TIP"] = "本機檔案: Interface/AddOns/GRIP-EMS/Guide/GRIP-EMS_Guide.html" -- MT
L["GEMS_GUIDE_URL"] = "https://jesperlive.github.io/grip-ems-guide/" -- MT
L["GEMS_GUIDE_CLICK"] = "|cff4ecca3|HGRIPEMSguide|h[點擊此處開啟 GRIP-EMS 指南]|h|r" -- MT
L["GEMS_HELP_GUIDE"] = "  /gems guide - GRIP-EMS 互動式指南" -- MT

-- Import preview (T2-4)
L["GEMS_IMPORT_PREVIEW_TITLE"] = "匯入預覽" -- MT
L["GEMS_IMPORT_PREVIEW_SEQ_HEADER"] = "序列 (%d)" -- MT
L["GEMS_IMPORT_PREVIEW_VAR_HEADER"] = "變數 (%d)" -- MT
L["GEMS_IMPORT_PREVIEW_NEW"] = "新" -- MT
L["GEMS_IMPORT_PREVIEW_EXISTS"] = "已存在" -- MT
L["GEMS_IMPORT_PREVIEW_IDENTICAL"] = "相同" -- MT
L["GEMS_IMPORT_PREVIEW_DIFFERENT"] = "不同" -- MT
L["GEMS_IMPORT_PREVIEW_IMPORT_SELECTED"] = "匯入所選 (%d)" -- MT
L["GEMS_IMPORT_PREVIEW_CANCEL"] = "取消" -- MT
L["GEMS_IMPORT_PREVIEW_SELECT_ALL"] = "全選" -- MT
L["GEMS_IMPORT_PREVIEW_DESELECT_ALL"] = "全部取消選擇" -- MT
L["GEMS_IMPORT_PREVIEW_EMPTY"] = "在此字串中找不到序列或變數。" -- MT
L["GEMS_IMPORT_PREVIEW_DESC"] = "讀取貼上的文字並顯示可匯入的序列" -- MT
L["GEMS_IMPORT_CLEAR_DESC"] = "清除貼上方塊" -- MT
L["GEMS_IMPORT_SELECT_ALL_DESC"] = "選擇所有序列以進行匯入" -- MT
L["GEMS_IMPORT_DESELECT_ALL_DESC"] = "取消選擇所有序列" -- MT
L["GEMS_IMPORT_CANCEL_DESC"] = "返回貼上步驟" -- MT
L["GEMS_IMPORT_COMMIT_DESC"] = "匯入所選序列" -- MT
L["GEMS_IMPORT_PREVIEW_SUMMARY"] = "已匯入 %d 個序列、%d 個變數" -- MT
L["GEMS_IMPORT_PREVIEW_BTN"] = "預覽" -- MT
L["GEMS_IMPORT_PREVIEW_HEADER"] = "%d 個序列、%d 個變數" -- MT
L["GEMS_IMPORT_PREVIEW_NEW_COUNT"] = "%d 個新的" -- MT
L["GEMS_IMPORT_PREVIEW_EXISTING_COUNT"] = "%d 個現有的" -- MT
L["GEMS_IMPORT_PREVIEW_INFO"] = "%d 個版本、%d 個步驟" -- MT

L["GEMS_IMPORT_PREVIEW_ACTION_SKIP"] = "略過" -- MT
L["GEMS_IMPORT_PREVIEW_ACTION_REPLACE"] = "取代" -- MT
L["GEMS_IMPORT_PREVIEW_ACTION_RENAME"] = "重新命名" -- MT

-- Advanced Export (T2-12)
L["GEMS_EXPORT_PICK_TITLE"] = "匯出序列" -- MT
L["GEMS_EXPORT_PICK_HEADER"] = "%d sequences, %d variables, %d macros available" -- MT
L["GEMS_EXPORT_PICK_SEQ_HEADER"] = "序列 (%d)" -- MT
L["GEMS_EXPORT_PICK_VAR_HEADER"] = "變數 (%d)" -- MT
L["GEMS_EXPORT_PICK_MACRO_HEADER"] = "Macros (%d)" -- MT
L["GEMS_EXPORT_PICK_MACRO_DEPS"] = "(+%d macros)" -- MT
L["GEMS_EXPORT_PICK_MACRO_SCOPE_ACCOUNT"] = "account" -- MT
L["GEMS_EXPORT_PICK_MACRO_SCOPE_CHARACTER"] = "char" -- MT
L["GEMS_EXPORT_PICK_INFO"] = "%d 個版本、%d 個步驟" -- MT
L["GEMS_EXPORT_PICK_VAR_DEPS"] = "(+%d 個變數)" -- MT
L["GEMS_EXPORT_PICK_USED_BY"] = "被使用於: %s" -- MT
L["GEMS_EXPORT_PICK_AUTO"] = "自動" -- MT
L["GEMS_EXPORT_PICK_SELECT_ALL"] = "全選" -- MT
L["GEMS_EXPORT_PICK_DESELECT_ALL"] = "全部取消選擇" -- MT
L["GEMS_EXPORT_PICK_EXPORT_SELECTED"] = "匯出所選 (%d)" -- MT
L["GEMS_EXPORT_PICK_BACK"] = "返回" -- MT
L["GEMS_EXPORT_PICK_DISPLAY_HEADER"] = "Exported %d sequences, %d variables, %d macros" -- MT
L["GEMS_EXPORT_PICK_EMBEDDED_WARN"] = "%s 使用 %s (未選擇)" -- MT
L["GEMS_EXPORT_PICK_LOCALE_WARN"] =
    "依賴特定語系法術名稱的變數可能無法為使用其他遊戲語言的玩家正常運作" -- MT
L["GEMS_EXPORT_COPY_TEXT"] = "以文字複製" -- MT
L["GEMS_EXPORT_COPY_TEXT_DESC"] = "將可讀摘要複製至剪貼簿" -- MT
L["GEMS_EXPORT_META_TITLE"] = "匯出元資料" -- MT
L["GEMS_EXPORT_META_SUBTITLE"] = "在匯出 %d 個序列前審閱並自訂" -- MT
L["GEMS_EXPORT_META_NAME"] = "集合名稱" -- MT
L["GEMS_EXPORT_META_AUTHOR"] = "作者" -- MT
L["GEMS_EXPORT_META_DESC"] = "描述" -- MT
L["GEMS_EXPORT_META_URL"] = "URL / 連結" -- MT
L["GEMS_EXPORT_META_TALENT"] = "天賦配置" -- MT
L["GEMS_EXPORT_META_INCLUDE_AUTHOR"] = "包含作者" -- MT
L["GEMS_EXPORT_META_INCLUDE_DESC"] = "包含描述" -- MT
L["GEMS_EXPORT_META_INCLUDE_TALENT"] = "包含天賦字串" -- MT
L["GEMS_EXPORT_META_INCLUDE_URL"] = "包含 URL" -- MT

L["GEMS_EXPORT_META_GENERATE"] = "產生匯出字串" -- MT
L["GEMS_EXPORT_META_BACK"] = "返回選擇" -- MT
L["GEMS_IMPORT_COLLECTION_HEADER"] = "集合: %s 由 %s" -- MT
L["GEMS_UI_EXPORT_MULTI"] = "匯出多個..." -- MT
L["GEMS_HELP_EXPORTALL"] = "  /gems exportall - 開啟多選匯出視窗" -- MT
L["GEMS_EXPORT_GENERATE_DESC"] = "從所選序列產生匯出字串" -- MT
L["GEMS_EXPORT_COPY_DESC"] = "將匯出字串複製至剪貼簿" -- MT
L["GEMS_EXPORT_SELECT_ALL_DESC"] = "選擇所有序列以進行匯出" -- MT
L["GEMS_EXPORT_DESELECT_ALL_DESC"] = "取消選擇所有序列" -- MT
L["GEMS_EXPORT_BACK_DESC"] = "返回選擇" -- MT
L["GEMS_EXPORT_CLOSE_DESC"] = "關閉匯出視窗" -- MT

-- Transmission (T2-9)
L["GEMS_HELP_SEND"] = "  /gems send <name> <player> - 將序列傳送給其他玩家" -- MT
L["GEMS_HELP_ACCEPT"] = "  /gems accept - 接受最新的傳入序列" -- MT
L["GEMS_HELP_VALIDATE"] = "  /gems validate - 驗證所有序列以檢查過時/無效法術" -- MT
L["GEMS_SEND_USAGE"] = "用法: /gems send <name> <player>" -- MT
L["GEMS_SEND_SUCCESS"] = "已將 '%s' 傳送至 %s" -- MT
L["GEMS_SEND_FAILED"] = "傳送失敗: %s" -- MT
L["GEMS_SEND_DISABLED"] = "P2P 分享已在設定中停用。" -- MT
L["GEMS_SEND_NO_SEQ"] = "找不到名為 '%s' 的序列。" -- MT
L["GEMS_RECEIVE_ANNOUNCE"] = "已從 %s 收到序列。開啟匯入..." -- MT
L["GEMS_RECEIVE_AUTO"] = "已自動匯入來自 %s 的 '%s' (好友)。" -- MT
L["GEMS_REQUEST_SENT"] = "正在從 %s 請求 '%s'..." -- MT
L["GEMS_REQUEST_FULFILLED"] = "已將 '%s' 傳送至 %s (已請求)。" -- MT
L["GEMS_VERSION_ANNOUNCE"] = "偵測到 GRIP-EMS 使用者: %s (v%s)" -- MT
L["GEMS_ACCEPT_USAGE"] = "沒有待接受的序列。" -- MT
L["GEMS_UI_SEND_PLAYER"] = "傳送至玩家" -- MT
L["GEMS_UI_SEND_BTN"] = "傳送" -- MT
L["GEMS_UI_SEND_BTN_DESC"] = "將此序列傳送給其他玩家" -- MT
L["GEMS_SEND_DIALOG_TEXT"] = "將 '%s' 傳送至:" -- MT

L["GEMS_SEND_DIALOG_ACCEPT"] = "傳送" -- MT
L["GEMS_SEND_DIALOG_KNOWN"] = "已知使用者:" -- MT
L["GEMS_META_SENT"] = "'%s' 的元資料同步請求已傳送。" -- MT
L["GEMS_META_NEWER"] = "'%s' 的較新版本可從 %s 取得,正在請求..." -- MT
L["GEMS_META_CURRENT"] = "本機 '%s' 為最新 (遠端來自 %s)。" -- MT
L["GEMS_SPELLCACHE_SENT"] = "法術快取廣播已傳送至群組。" -- MT
L["GEMS_SPELLCACHE_MERGED"] = "已從 %s 合併 %d 個法術快取項目。" -- MT
L["GEMS_P2P_ENABLED"] = "啟用 P2P 分享" -- MT
L["GEMS_P2P_ENABLED_DESC"] = "與其他使用此外掛的玩家傳送和接收序列。" -- MT
L["GEMS_P2P_AUTO_FRIENDS"] = "自動接受來自好友" -- MT
L["GEMS_P2P_AUTO_FRIENDS_DESC"] = "儲存好友傳送的序列,無需先詢問您。" -- MT
L["GEMS_P2P_ANNOUNCE"] = "播報已接收" -- MT
L["GEMS_P2P_ANNOUNCE_DESC"] = "從其他玩家接收序列時,於聊天框顯示一行訊息。" -- MT
L["GEMS_IMPORT_FROM"] = "從 %s 匯入" -- MT

-- Block list (T2-9)
L["GEMS_BLOCK_ADDED"] = "已封鎖 %s 進行 P2P 傳輸。" -- MT
L["GEMS_BLOCK_REMOVED"] = "已解除封鎖 %s。" -- MT
L["GEMS_BLOCK_NOT_FOUND"] = "%s 未被封鎖。" -- MT
L["GEMS_BLOCK_LIST_EMPTY"] = "沒有玩家被封鎖。" -- MT
L["GEMS_BLOCK_LIST_HEADER"] = "已封鎖玩家:" -- MT
L["GEMS_SETTINGS_BLOCKED_PLAYERS"] = "已封鎖玩家" -- MT
L["GEMS_SETTINGS_BLOCKED_PLAYERS_DESC"] = "此清單中的玩家無法傳送序列給您。" -- MT
L["GEMS_HELP_BLOCK"] = "  /gems block <player> - 封鎖玩家傳送序列給您" -- MT
L["GEMS_HELP_UNBLOCK"] = "  /gems unblock <player> - 解除封鎖玩家" -- MT
L["GEMS_HELP_BLOCKLIST"] = "  /gems blocklist - 列出所有已封鎖玩家" -- MT

-- Tracker HUD (T2-7)
L["GEMS_TRACKER_TOGGLE"] = "追蹤器 HUD %s。" -- MT
L["GEMS_TRACKER_LOCKED"] = "追蹤器已鎖定。" -- MT
L["GEMS_TRACKER_UNLOCKED"] = "追蹤器已解鎖。" -- MT
L["GEMS_TRACKER_HEADER"] = "追蹤器 HUD" -- MT
L["GEMS_TRACKER_ICONSIZE_DESC"] = "設定每個序列圖示的大小 (像素)。" -- MT

L["GEMS_TRACKER_ORIENTATION_DESC"] = "將圖示堆疊為列或行。" -- MT
L["GEMS_TRACKER_SHOWNAME_DESC"] = "在每個圖示下方顯示序列名稱。" -- MT
L["GEMS_TRACKER_SHOWMODS_DESC"] = "顯示目前按住的修飾鍵 (Alt、Shift 或 Ctrl)。" -- MT
L["GEMS_TRACKER_LOCK_DESC"] = "將追蹤器 HUD 鎖定在原位,使您無法拖曳。" -- MT
L["GEMS_TRACKER_SHOWMODE_DESC"] = "選擇追蹤器 HUD 何時在螢幕上顯示。" -- MT
L["GEMS_TRACKER_MODE_ALWAYS"] = "永遠" -- MT
L["GEMS_TRACKER_MODE_COMBAT"] = "戰鬥中" -- MT
L["GEMS_TRACKER_MODE_TARGET"] = "有目標時" -- MT
L["GEMS_TRACKER_MODE_NEVER"] = "永不" -- MT
L["GEMS_TRACKER_SCALE_DESC"] = "變更追蹤器 HUD 的整體大小。" -- MT
L["GEMS_TRACKER_PREVIEW_HINT"] = "預覽顯示 HUD 目前的樣子。戰鬥中的值可能不同。" -- MT
L["GEMS_HELP_TRACKER"] = "  /gems tracker [lock] - 切換追蹤器 HUD" -- MT

-- Debug window (T1-6)
L["GEMS_HELP_DEBUGWINDOW"] = "  /gems debugwindow - 切換偵錯訊息視窗" -- MT
L["GEMS_DEBUG_WINDOW_TITLE"] = "GRIP-EMS 偵錯" -- MT
L["GEMS_DEBUG_CLEAR"] = "清除" -- MT
L["GEMS_DEBUG_COPY"] = "複製" -- MT
L["GEMS_DEBUG_COPY_HINT"] = "使用 /gems export 或從匯出框中按 Ctrl+C 來複製偵錯輸出。" -- MT
L["GEMS_UI_WHATSNEW_DISMISS"] = "不再顯示" -- MT
L["GEMS_WHATSNEW_DISMISS_DESC"] = "對於此版本不再顯示" -- MT
L["GEMS_DEBUG_CLOSE_DESC"] = "關閉偵錯視窗" -- MT
L["GEMS_DEBUG_CLEAR_DESC"] = "清除所有偵錯訊息" -- MT
L["GEMS_DEBUG_COPY_DESC"] = "將所有訊息複製至剪貼簿" -- MT

-- Locale Phase 2e
L["GEMS_HELP_REVALIDATE"] = "  /gems revalidate - 用目前法術 ID 更新所有序列" -- MT

-- Click rate (v1.2.0 S01)
L["GEMS_SETTINGS_CLICK_RATE"] = "點擊速率 (ms)" -- MT
-- TODO: MT 2026-06-13, needs native review (match British enUS)
L["GEMS_SETTINGS_CLICK_RATE_DESC"] =
    "序列的按鍵速度（毫秒）。EMS 每次按鍵前進一步，不會限制你的按鍵速度；此數值用於指導 Faster, Slower 建議與匯入暫停的計時。預設值為 250 毫秒。" -- MT

L["GEMS_SETTINGS_CHAR_OVERRIDES"] = "角色覆寫" -- MT
L["GEMS_SETTINGS_CHAR_CLICK_RATE"] = "每角色點擊速率 (ms)" -- MT
L["GEMS_SETTINGS_CHAR_CLICK_RATE_DESC"] =
    "僅在此角色上使用不同的點擊速率。設為 0 以使用共用值。" -- MT
L["GEMS_STATUS_CLICK_RATE"] = "點擊速率: %dms (有效)" -- MT
L["GEMS_STATUS_CVAR_PENDING_LINE"] = "%d pending CVar changes:" -- MT
L["GEMS_STATUS_CVAR_CAUSE_LINE"] = "  %d %s" -- MT

-- Macro reset modifiers (v1.2.0 S01)
L["GEMS_SETTINGS_MACRO_RESET"] = "巨集重置" -- MT
L["GEMS_RESET_MOD_DESC"] = "按下按鍵時若按住此修飾鍵,則將步驟計數器重置為 1。" -- MT
L["GEMS_UI_RESET_MODS_HEADER"] = "重置修飾鍵覆寫" -- MT
L["GEMS_UI_RESET_MODS_ENABLE"] = "使用每序列覆寫" -- MT
L["GEMS_UI_RESET_MODS_GLOBAL"] = "(使用全域設定)" -- MT
L["GEMS_RESET_MOD_LEFTBUTTON"] = "左鍵點擊" -- MT
L["GEMS_RESET_MOD_RIGHTBUTTON"] = "右鍵點擊" -- MT
L["GEMS_RESET_MOD_MIDDLEBUTTON"] = "中鍵點擊" -- MT
L["GEMS_RESET_MOD_BUTTON4"] = "滑鼠按鍵 4" -- MT
L["GEMS_RESET_MOD_BUTTON5"] = "滑鼠按鍵 5" -- MT
L["GEMS_RESET_MOD_LEFTALT"] = "左 Alt" -- MT
L["GEMS_RESET_MOD_RIGHTALT"] = "右 Alt" -- MT
L["GEMS_RESET_MOD_ALT"] = "任意 Alt" -- MT
L["GEMS_RESET_MOD_LEFTCONTROL"] = "左 Control" -- MT
L["GEMS_RESET_MOD_RIGHTCONTROL"] = "右 Control" -- MT
L["GEMS_RESET_MOD_CONTROL"] = "任意 Control" -- MT
L["GEMS_RESET_MOD_LEFTSHIFT"] = "左 Shift" -- MT
L["GEMS_RESET_MOD_RIGHTSHIFT"] = "右 Shift" -- MT
L["GEMS_RESET_MOD_SHIFT"] = "任意 Shift" -- MT
L["GEMS_RESET_MOD_ANYMOD"] = "任意修飾鍵" -- MT
L["GEMS_RESET_MOD_MOUSE_HEADER"] = "滑鼠按鍵" -- MT
L["GEMS_RESET_MOD_ALT_HEADER"] = "Alt 鍵" -- MT
L["GEMS_RESET_MOD_CONTROL_HEADER"] = "Control 鍵" -- MT
L["GEMS_RESET_MOD_SHIFT_HEADER"] = "Shift 鍵" -- MT
L["GEMS_RESET_MOD_ANY_HEADER"] = "組合" -- MT

-- Corrupt sequence recovery
L["GEMS_CORRUPT_TITLE"] = "偵測到損毀的序列" -- MT
L["GEMS_CORRUPT_TEXT"] = "無法載入序列 '%s'。\n\n錯誤: %s\n\n選擇動作:" -- MT
L["GEMS_CORRUPT_DELETE"] = "刪除" -- MT
L["GEMS_CORRUPT_SKIP"] = "略過" -- MT
L["GEMS_CORRUPT_EXPORT"] = "匯出原始" -- MT
L["GEMS_CORRUPT_SUMMARY"] = "損毀序列: %d 個已刪除,%d 個已略過,%d 個已匯出" -- MT
L["GEMS_CORRUPT_NONE"] = "找不到損毀的序列。" -- MT

-- Execution Tracer (v1.2.0 S03-B)
L["GEMS_TRACE_CAST"] = "[追蹤] %s (ID: %d)%s" -- MT
L["GEMS_TRACE_STARTED"] = "執行追蹤已開始" -- MT
L["GEMS_TRACE_STOPPED"] = "執行追蹤已停止" -- MT
L["GEMS_TRACE_STATUS"] = "執行追蹤器: %s (%.2f CPS)。" -- MT
L["GEMS_TRACE_STATE_ON"] = "開啟" -- MT
L["GEMS_TRACE_STATE_OFF"] = "關閉" -- MT
L["GEMS_TRACE_UNAVAILABLE"] = "執行追蹤器無法使用。" -- MT

-- CVar health (v1.2.0 S01)
L["GEMS_SETTINGS_CVAR_HEALTH"] = "CVar 健康度" -- MT
L["GEMS_SETTINGS_CVAR_DESC"] =
    "%d 個類別的遊戲變數 (%d 個 CVars)。綠色 = 最佳,黃色 = 次佳,紅色 = 關鍵,灰色 = 資訊性。" -- MT
L["GEMS_SETTINGS_CVAR_AUTOFIX"] = "登入時自動修復 CVars" -- MT
L["GEMS_SETTINGS_CVAR_AUTOFIX_DESC"] = "每次登入時為您設定建議的 CVar 值。" -- MT
L["GEMS_SETTINGS_CVAR_FIX"] = "修復" -- MT

-- CVar Dashboard UI strings
L["GEMS_CVAR_FIX_ALL"] = "全部修復" -- MT
L["GEMS_CVAR_FIX_ALL_CRITICAL"] = "修復所有關鍵" -- MT
L["GEMS_CVAR_FIX_ALL_SECTION"] = "修復區段中所有" -- MT
L["GEMS_CVAR_AUTOFIX_ENTRY"] = "登入時自動修復" -- MT

L["GEMS_CVAR_AUTOFIX_ENTRY_GATED"] =
    "必須先啟用主要自動修復。請先開啟上方的自動修復建議值,才能使用每 CVar 加入。" -- MT
L["GEMS_CVAR_AUTOFIX_SECTION_GATED"] =
    "Master Auto-fix is off. Turn on Auto-fix recommended values above to choose per-CVar opt-ins." -- MT
L["GEMS_CVAR_AUTOFIX_PIN_OVERRIDE"] = "Pinned -- auto-fix is overridden until you unpin." -- MT
L["GEMS_CVAR_AUTOFIX_COUNT"] = "GEMS: 登入時自動修復了 %d 個 CVars。" -- MT
L["GEMS_CVAR_HEALTH_SCORE"] = "CVar 健康度: %d/100" -- MT
L["GEMS_CVAR_SCORE_HISTORY_HEADER"] = "評分歷史" -- MT
L["GEMS_CVAR_SCORE_HISTORY_EMPTY"] = "尚無歷史記錄：將在登入時記錄。" -- MT
L["GEMS_CVAR_SCORE_HISTORY_RANGE"] = "最低 %d / 最高 %d" -- MT
L["GEMS_CVAR_SECTION_HEALTH"] = "%s %s"
L["GEMS_CVAR_HEALTH_EXPLAIN_HEADER"] = "此分數的原因:" -- MT
L["GEMS_CVAR_HEALTH_EXPLAIN_PERFECT"] = "所有建議值已套用。沒有要修復的。" -- MT
L["GEMS_CVAR_HEALTH_EXPLAIN_OFFENDER"] = "  - %s: %s -> %s (權重 %d)" -- MT
L["GEMS_CVAR_HEALTH_EXPLAIN_SQW_CREDIT"] = "  - SpellQueueWindow: 由 SQW 最佳化器管理 (自動歸功)" -- MT
L["GEMS_CVAR_HEALTH_EXPLAIN_MORE"] = "  ... 還有 %d 個 (開啟相關區段以查看全部)。" -- MT
L["GEMS_CVAR_SECURE_TAG"] = " (安全)" -- MT
L["GEMS_CVAR_COMBAT_DISABLED"] = "戰鬥中無法變更安全 CVars。" -- MT
L["GEMS_CVAR_INFORMATIONAL"] = " (資訊性)" -- MT
L["GEMS_CVAR_YOUR_CHOICE"] = "(您的選擇)" -- MT
L["GEMS_CVAR_WILL_CHANGE"] = "將從 %s 變更為 %s。" -- MT
L["GEMS_CVAR_SET_VALUE"] = "設定值" -- MT
L["GEMS_CVAR_UNDO"] = "復原" -- MT
L["GEMS_CVAR_UNDO_DESC"] =
    "還原此 CVar 的先前值 (上次 EMS 驅動變更前的值)。CVar 釘選時停用 -- 請先取消釘選。" -- MT
L["GEMS_CVAR_UNDO_TO"] = "復原至 %s" -- MT
L["GEMS_CVAR_REDO"] = "Redo" -- MT
L["GEMS_CVAR_REDO_DESC"] =
    "Reapply the value that was undone by the last Undo. Disabled while the CVar is pinned -- unpin first." -- MT
L["GEMS_CVAR_REDO_TO"] = "Redo to %s" -- MT
L["GEMS_CVAR_PIN"] = "釘選我的選擇" -- MT
L["GEMS_CVAR_PIN_DESC"] =
    "將此值標記為您有意的選擇。EMS 將不會透過修復動作、設定檔交換或登入時自動修復來修改它。CVar 健康度分數會將其視為最佳。" -- MT
L["GEMS_CVAR_PIN_PINNED"] = "已釘選 -- EMS 不會變更此 CVar。" -- MT
L["GEMS_CVAR_OPTION_RECOMMENDED"] = "%s (建議)" -- MT

-- L372 G.3b first wave -- options + descLong for 6 cvars (MT placeholders, awaiting native review)
L["GEMS_CVAR_MACRO_KEYDOWN_OPT_0"] = "Key Up (release)" -- MT
L["GEMS_CVAR_MACRO_KEYDOWN_OPT_1"] = "Key Down (press)" -- MT
L["GEMS_CVAR_MACRO_KEYDOWN_DESCLONG"] =
    "Controls whether action bar buttons fire when you press the key (1) or when you release it (0). EMS macro sequences need this set to 1 -- the click-on-press path is what advances the step counter. Set to 0 and your sequences either don't advance or fire on the wrong key event." -- MT

L["GEMS_CVAR_MACRO_LOCKBARS_OPT_0"] = "Unlocked" -- MT
L["GEMS_CVAR_MACRO_LOCKBARS_OPT_1"] = "Locked" -- MT
L["GEMS_CVAR_MACRO_LOCKBARS_DESCLONG"] =
    "Locks action bar buttons in place so you cannot drag them off the bar by accident. Recommended on (1) once you have your bars set up the way you want -- accidentally dragging a spell off mid-fight is a frustrating way to die. Turn it off (0) when you actively want to rearrange spells." -- MT

L["GEMS_CVAR_NAMEPLATES_SHOWENEMY_OPT_0"] = "Hide" -- MT
L["GEMS_CVAR_NAMEPLATES_SHOWENEMY_OPT_1"] = "Show" -- MT
L["GEMS_CVAR_NAMEPLATES_SHOWENEMY_DESCLONG"] =
    "Master toggle for showing nameplates above enemy units. Recommended on (1) for anyone who plays in groups or PvP -- you need them to read incoming damage and target priority. Off (0) only makes sense for solo overworld questing where the screen is already cluttered." -- MT

L["GEMS_CVAR_FCT_ENABLE_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_FCT_ENABLE_OPT_1"] = "On" -- MT
L["GEMS_CVAR_FCT_ENABLE_DESCLONG"] =
    "Master toggle for the floating numbers that pop up when you deal or take damage. Recommended on (1) -- the numbers are how most players read combat tempo and gauge how hard a hit landed. Off (0) cleans the screen but you lose the per-hit feedback that healers and DPS both lean on." -- MT

L["GEMS_CVAR_MACRO_SELFCAST_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_MACRO_SELFCAST_OPT_1"] = "On" -- MT
L["GEMS_CVAR_MACRO_SELFCAST_DESCLONG"] =
    "Lets the game cast certain friendly spells on you when you have no target. Recommended on (1) -- without it, healing spells with no target either silently fail or pop a no-target error. With it on, you save a modifier-key tap for self-heals. Off (0) is for players who use macros that already encode their self-cast intent." -- MT

L["GEMS_CVAR_MACRO_AUTOPUSH_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_MACRO_AUTOPUSH_OPT_1"] = "On" -- MT
L["GEMS_CVAR_MACRO_AUTOPUSH_DESCLONG"] =
    "When you learn a new spell, the game automatically places it on your first empty action bar slot. Recommended off (0) -- for players running organised bars, which is most EMS users, the auto-place behaviour scatters newly learned spells into random slots you then have to find and remove. Off lets you place spells where you want them." -- MT

L["GEMS_CVAR_MACRO_MULTIBARS_OPT_0"] = "0 (None)" -- MT
L["GEMS_CVAR_MACRO_MULTIBARS_OPT_1"] = "1 (Action Bar 2)" -- MT
L["GEMS_CVAR_MACRO_MULTIBARS_OPT_3"] = "3 (Action Bars 2 + 3)" -- MT
L["GEMS_CVAR_MACRO_MULTIBARS_OPT_12"] = "12 (Right Action Bars 1 + 2)" -- MT
L["GEMS_CVAR_MACRO_MULTIBARS_OPT_15"] = "15 (All four extra bars)" -- MT
L["GEMS_CVAR_MACRO_MULTIBARS_DESCLONG"] =
    "Picks which extra action bars are visible on top of your main action bar. WoW exposes four extra bars and stores your selection as a 4-bit mask: bit 1 (value 1) shows Action Bar 2 (Bottom Left), bit 2 (value 2) shows Action Bar 3 (Bottom Right), bit 4 (value 4) shows Right Action Bar 1, bit 8 (value 8) shows Right Action Bar 2. The dropdown exposes five common combinations: 0=None, 1=Action Bar 2 only, 3=Action Bars 2+3 (both bottom), 12=Right Action Bars 1+2 (both right), 15=all four. For mixed combinations not in the list (e.g. bottom-left + right only = 5), use the in-game ActionBars settings panel (Settings > ActionBars) which exposes per-bar checkboxes, or run /console set enableMultiActionBars N where N is your chosen bitmask sum. EMS does not auto-set this value because bar-layout is a personal UX choice -- pick what matches your playstyle. This setting is per-character (each alt has its own bar visibility)." -- MT

L["GEMS_CVAR_MACRO_HELDPOLL_OPT_100"] = "100 ms (minimum, clamped)" -- MT
L["GEMS_CVAR_MACRO_HELDPOLL_OPT_250"] = "250 ms (snappy)" -- MT
L["GEMS_CVAR_MACRO_HELDPOLL_OPT_500"] = "500 ms (Blizzard default, recommended)" -- MT
L["GEMS_CVAR_MACRO_HELDPOLL_OPT_1000"] = "1000 ms (relaxed)" -- MT
L["GEMS_CVAR_MACRO_HELDPOLL_OPT_2000"] = "2000 ms (very relaxed)" -- MT
L["GEMS_CVAR_MACRO_HELDPOLL_DESCLONG"] =
    "Controls how often the WoW engine retries casting a held-key spell after a failed cast attempt -- the spell-error poll interval in milliseconds. Default 500 ms means the engine polls roughly twice per second; lower values poll faster (more responsive when the cast becomes available) but consume slightly more client CPU. Higher values reduce polling overhead at the cost of a brief delay before the spell actually fires once it becomes castable. The Blizzard engine clamps any chosen value to the 100-10000 ms range. NOTE: Blizzard documents this as Internal-only -- advanced users only. Changing it rarely helps in practice and may cause unexpected interactions with other addons that rely on the default polling cadence. EMS recommends staying at 500 (Blizzard default) unless you have a specific reason to tune it." -- MT

-- L372 G.3b second wave -- options + descLong for 3 numeric-range cvars (MT placeholders, awaiting native review)
L["GEMS_CVAR_NAMEPLATES_MAXDIST_OPT_20"] = "20 yards (close)" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXDIST_OPT_41"] = "41 yards (Classic)" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXDIST_OPT_60"] = "60 yards (raid/M+)" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXDIST_OPT_80"] = "80 yards (long range)" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXDIST_OPT_100"] = "100 yards (max)" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXDIST_DESCLONG"] =
    "Sets how far away enemy nameplates stay visible, in yards. 20 keeps the screen uncluttered in solo overworld content but loses visibility on ranged threats in groups. 60 is the modern raid and M+ sweet spot -- you see every relevant enemy without the screen drowning in plates. 80-100 maxes out the range for ranged DPS who want to spot casters at extreme distance, at the cost of more screen noise. 41 is the legacy Classic cap, harmless on Retail but rarely the right choice." -- MT

L["GEMS_CVAR_FPS_MAXFPS_OPT_0"] = "0 (uncapped)" -- MT
L["GEMS_CVAR_FPS_MAXFPS_OPT_60"] = "60 (60Hz monitor)" -- MT
L["GEMS_CVAR_FPS_MAXFPS_OPT_120"] = "120 (120Hz monitor)" -- MT
L["GEMS_CVAR_FPS_MAXFPS_OPT_144"] = "144 (144Hz monitor)" -- MT
L["GEMS_CVAR_FPS_MAXFPS_OPT_240"] = "240 (240Hz monitor)" -- MT
L["GEMS_CVAR_FPS_MAXFPS_DESCLONG"] =
    "Caps your in-game frame rate when the window is focused. 0 (uncapped) is fine on high-end hardware but causes coil whine and runs the GPU hot. Matching your monitor's refresh rate (60, 120, 144, or 240) gives smooth scrolling and saves power without any visible loss. Set lower than your refresh rate only if you're hitting thermal limits or want quieter fans." -- MT

L["GEMS_CVAR_MACRO_SPELLQUEUE_OPT_0"] = "0 ms (no queue)" -- MT
L["GEMS_CVAR_MACRO_SPELLQUEUE_OPT_100"] = "100 ms (Retail default)" -- MT
L["GEMS_CVAR_MACRO_SPELLQUEUE_OPT_200"] = "200 ms (relaxed)" -- MT
L["GEMS_CVAR_MACRO_SPELLQUEUE_OPT_400"] = "400 ms (max)" -- MT
L["GEMS_CVAR_MACRO_SPELLQUEUE_DESCLONG"] =
    "The time window in milliseconds after a global cooldown finishes during which a queued spell fires on its own. EMS needs 400 (the engine maximum) so macro sequence steps don't drop when GCDs finish a tick later than expected. Lower values (0, 100, 200) work for hand-cast play where you time inputs precisely, but they cause EMS sequences to skip clicks on variable latency. Set this to 400 for any EMS work." -- MT

-- L372 G.3b third wave -- options + descLong for 3 tiered-quality cvars (MT placeholders, awaiting native review)
L["GEMS_CVAR_VISUAL_SHADOWS_OPT_0"] = "Low" -- MT
L["GEMS_CVAR_VISUAL_SHADOWS_OPT_1"] = "Fair" -- MT
L["GEMS_CVAR_VISUAL_SHADOWS_OPT_2"] = "Good" -- MT
L["GEMS_CVAR_VISUAL_SHADOWS_OPT_3"] = "High" -- MT
L["GEMS_CVAR_VISUAL_SHADOWS_OPT_4"] = "Ultra" -- MT
L["GEMS_CVAR_VISUAL_SHADOWS_DESCLONG"] =
    "Sets the resolution and depth of shadow maps under units, trees, and structures. Low and Fair save GPU memory and frame time, which helps on integrated graphics or a laptop on battery. Medium and High sit in the middle -- soft shadow edges and reasonable draw distance without dropping frames on mid-range cards. Ultra and Ultra High raise the shadow-map resolution and cascade depth for pristine screenshots, at a cost of 5-15 FPS on most cards for marginal in-motion gain. The default is High." -- MT

L["GEMS_CVAR_FPS_PARTICLES_OPT_0"] = "0 (Off)" -- MT
L["GEMS_CVAR_FPS_PARTICLES_OPT_25"] = "25 (Low)" -- MT
L["GEMS_CVAR_FPS_PARTICLES_OPT_50"] = "50 (Medium)" -- MT
L["GEMS_CVAR_FPS_PARTICLES_OPT_75"] = "75 (High)" -- MT
L["GEMS_CVAR_FPS_PARTICLES_OPT_100"] = "100 (Full)" -- MT
L["GEMS_CVAR_FPS_PARTICLES_DESCLONG"] =
    "Controls how many spell and environmental particle effects the game draws. Disabled removes them completely -- the biggest GPU saving, but it also strips some combat visual cues, so you can miss effects firing around you. Low through High trade detail for frame rate; Ultra keeps every spark and flame, which looks best solo but can bury the ground effects you need to dodge in 20-player raids and busy M+ pulls. The Blizzard default is High." -- MT

L["GEMS_CVAR_VISUAL_TEXRES_OPT_0"] = "Low" -- MT
L["GEMS_CVAR_VISUAL_TEXRES_OPT_1"] = "Fair" -- MT
L["GEMS_CVAR_VISUAL_TEXRES_OPT_2"] = "High" -- MT
L["GEMS_CVAR_VISUAL_TEXRES_OPT_3"] = "Ultra" -- MT
L["GEMS_CVAR_VISUAL_TEXRES_DESCLONG"] =
    "Sets the resolution of in-game texture maps for terrain, buildings, armour, and weapons. Low and Fair compress textures heavily to save VRAM, which gives older or low-VRAM cards a usable game but leaves armour and walls looking soft. High strikes the modern balance: textures sharpen at typical viewing distances without filling VRAM on a 4-6 GB card. Ultra loads full-resolution mip levels, which pushes total texture memory past 8 GB during raid bosses and pulls in stutter for anything below that VRAM line." -- MT

-- L372 G.3b fourth wave -- options + descLong for 14 floatingCombatText 0/1 toggle cvars (MT placeholders, awaiting native review)
L["GEMS_CVAR_FCT_DAMAGE_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_FCT_DAMAGE_OPT_1"] = "On" -- MT
L["GEMS_CVAR_FCT_DAMAGE_DESCLONG"] =
    "Shows the damage numbers that float up from enemies you hit with spells and abilities. Recommended on (1) -- this is the headline DPS feedback most players rely on to read combat tempo. Off (0) hides every damage number and leaves only debuff/buff feedback." -- MT

L["GEMS_CVAR_FCT_AUTOS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_FCT_AUTOS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_FCT_AUTOS_DESCLONG"] =
    "Shows damage numbers for every auto-attack swing, not just abilities. Recommended on (1) for melee specs where auto damage is a noticeable share of total damage -- you can read auto cadence visually. Off (0) hides the auto trickle and only shows ability hits, which cleans the screen for caster specs that don't auto-attack much." -- MT

L["GEMS_CVAR_FCT_HEALING_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_FCT_HEALING_OPT_1"] = "On" -- MT
L["GEMS_CVAR_FCT_HEALING_DESCLONG"] =
    "Shows healing numbers that float up when you or allies receive healing in combat. Recommended on (1) -- healers read team health recovery from these numbers, and DPS see when they're being topped off. Off (0) hides all healing feedback in combat." -- MT

L["GEMS_CVAR_FCT_ABSSELF_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_FCT_ABSSELF_OPT_1"] = "On" -- MT
L["GEMS_CVAR_FCT_ABSSELF_DESCLONG"] =
    "Shows absorb numbers when your own shields (Power Word: Shield, Ice Barrier, similar) soak incoming damage. Recommended on (1) -- you can see how much your defensive cooldowns are mitigating versus the boss's hit size. Off (0) hides the absorb feedback even though the shield still works." -- MT

L["GEMS_CVAR_FCT_ABSTARGET_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_FCT_ABSTARGET_OPT_1"] = "On" -- MT
L["GEMS_CVAR_FCT_ABSTARGET_DESCLONG"] =
    "Shows absorb numbers when your shields soak damage on a friendly target you're shielding. Recommended on (1) for healers and tank-shielding specs (Disc Priest, Brewmaster) who need to see if their bubbles are landing. Off (0) is fine for DPS who do not cast absorbs." -- MT

L["GEMS_CVAR_FCT_PERIODIC_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_FCT_PERIODIC_OPT_1"] = "On" -- MT
L["GEMS_CVAR_FCT_PERIODIC_DESCLONG"] =
    "Shows damage/healing tick numbers for periodic effects (DoTs, HoTs) from the combat log. Recommended on (1) -- visible DoT ticks help you confirm bleeds and DoTs are still ticking on the target. Off (0) hides every tick but the spell is still working in the background." -- MT

L["GEMS_CVAR_FCT_DODGEMISS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_FCT_DODGEMISS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_FCT_DODGEMISS_DESCLONG"] =
    "Shows MISS / DODGE / PARRY markers when your attacks fail to land. Recommended on (1) -- you can see at a glance whether you're hitting from the wrong angle or whether the boss is parrying everything. Off (0) hides the miss feedback even though the attack still misses." -- MT

L["GEMS_CVAR_FCT_LOWRES_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_FCT_LOWRES_OPT_1"] = "On" -- MT
L["GEMS_CVAR_FCT_LOWRES_DESCLONG"] =
    "Shows the floating warning when your health or resource pool drops below the danger threshold. Recommended on (1) -- this is your last-second visual cue to pop a defensive or healing potion before you die. Off (0) hides the warning and you rely on bar UI alone." -- MT

L["GEMS_CVAR_FCT_PETMELEE_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_FCT_PETMELEE_OPT_1"] = "On" -- MT
L["GEMS_CVAR_FCT_PETMELEE_DESCLONG"] =
    "Shows damage numbers for your pet's auto-attacks. Recommended on (1) for Hunters, Warlocks, and Unholy DKs where pet damage is a noticeable share of the meter. Off (0) is fine for specs without a permanent pet, where the toggle does nothing anyway." -- MT

L["GEMS_CVAR_FCT_PETSPELL_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_FCT_PETSPELL_OPT_1"] = "On" -- MT
L["GEMS_CVAR_FCT_PETSPELL_DESCLONG"] =
    "Shows damage numbers for your pet's ability casts (Kill Command, Felhunter Spell Lock, etc.). Recommended on (1) for any pet-spec where the pet's ability output is part of the rotation. Off (0) keeps the pet's contribution invisible in the visual stream." -- MT

L["GEMS_CVAR_FCT_REACTIVES_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_FCT_REACTIVES_OPT_1"] = "On" -- MT
L["GEMS_CVAR_FCT_REACTIVES_DESCLONG"] =
    "Shows the floating notification when a reactive ability becomes usable (Overpower after dodge, Riposte after parry, Counterstrike). Recommended on (1) -- the popup is how you know a procced ability is available before it falls off. Off (0) hides the proc indicator and you watch the bar instead." -- MT

-- L372 G.3b fifth wave -- options + descLong for 15 raid-cluster 0/1 toggle cvars (MT placeholders, awaiting native review)
L["GEMS_CVAR_RAIDING_AGGRO_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_AGGRO_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_AGGRO_DESCLONG"] =
    "Highlights raid frame portraits red when a unit pulls aggro from the boss. Recommended on (1) -- healers and off-tanks read aggro at a glance from this colour cue. Off (0) hides the red flash even when a squishy is about to die from boss attention." -- MT

L["GEMS_CVAR_RAIDING_RDEBUFFS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_RDEBUFFS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_RDEBUFFS_DESCLONG"] =
    "Shows debuff icons on raid frame portraits so you can see who needs cleansing. Recommended on (1) -- healers and dispellers track who has bleeds, magic debuffs, or curses without needing a separate addon. Off (0) hides all debuff icons and you watch the chat log instead." -- MT

L["GEMS_CVAR_RAIDING_HEALPRED_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_HEALPRED_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_HEALPRED_DESCLONG"] =
    "Shows an incoming-heal overlay on raid frame health bars when an ally has cast a heal but it has not landed yet. Recommended on (1) for healers running multiple casters together -- you can see if another healer's heal is already inbound and avoid overhealing. Off (0) hides the prediction and you rely on call-outs." -- MT

L["GEMS_CVAR_RAIDING_POWERBARS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_POWERBARS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_POWERBARS_DESCLONG"] =
    "Shows mana, energy, rage, or focus bars under raid frame portraits. Recommended off (0) by default -- reclaims vertical space on every raid frame which matters in 20-40 player groups. On (1) is useful for healers (mana visibility on other healers) and for tanks (rage visibility on co-tank)." -- MT

L["GEMS_CVAR_RAIDING_RCLASSCOLOR_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_RCLASSCOLOR_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_RCLASSCOLOR_DESCLONG"] =
    "Colours raid frame health bars by class colour (Mage blue, Warrior brown, etc.) instead of green-to-red health gradient. Recommended on (1) -- you can identify who is who at a glance, especially in mixed groups. Off (0) uses the threat-level gradient instead, which some players prefer for at-a-glance health reading." -- MT

L["GEMS_CVAR_RAIDING_DISPONLY_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_DISPONLY_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_DISPONLY_DESCLONG"] =
    "Filters raid frame debuff icons so only debuffs your class can dispel are shown. Recommended off (0) by default -- shows every debuff regardless of dispel kit, useful for understanding what's happening across the raid. On (1) for dispelling classes (Priest/Druid/Shaman/Paladin/Monk healers, Mage Spellsteal) cuts visual noise to only actionable debuffs." -- MT

L["GEMS_CVAR_RAIDING_ROLEDEBUFF_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_ROLEDEBUFF_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_ROLEDEBUFF_DESCLONG"] =
    "Renders certain role-specific debuff icons (boss mechanics, tank busters, healer-action-required debuffs) larger than normal so they stand out. Recommended on (1) -- the size difference makes major mechanics impossible to miss versus background noise. Off (0) renders every debuff at uniform size." -- MT

L["GEMS_CVAR_RAIDING_BIGDEF_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_BIGDEF_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_BIGDEF_DESCLONG"] =
    "Centres large defensive-cooldown icons on raid frame portraits when a tank or DPS is using a major defensive (Shield Wall, Icebound Fortitude, etc.). Recommended on (1) for healers -- you can see when the tank already mitigated incoming damage and adjust healing priority. Off (0) hides the defensive indicator entirely." -- MT

L["GEMS_CVAR_RAIDING_TIMELINE_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_TIMELINE_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_TIMELINE_DESCLONG"] =
    "Shows the in-game encounter timeline UI that lists upcoming boss abilities. Recommended on (1) -- the timeline helps new raiders learn fight sequences without external addons. Off (0) hides the timeline; you rely on DBM, BigWigs, or voice calls instead." -- MT

L["GEMS_CVAR_RAIDING_TIMEROLE_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_TIMEROLE_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_TIMEROLE_DESCLONG"] =
    "Filters the encounter timeline to show only abilities that affect your role. Recommended on (1) -- DPS players don't need to see healer-specific timeline notes and vice versa. Off (0) shows the full timeline including notes targeted at other roles." -- MT

L["GEMS_CVAR_RAIDING_WARNINGS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_WARNINGS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_WARNINGS_DESCLONG"] =
    "Shows large screen warnings for major boss mechanics (Targeted-by-Beam, Move-Away, etc.). Recommended on (1) for raiders without DBM or BigWigs -- the in-engine warning is the only call-out you'll get. Off (0) hides the warnings; useful if you use addons that fire competing warnings." -- MT

L["GEMS_CVAR_RAIDING_WARNHIDE_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_WARNHIDE_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_WARNHIDE_DESCLONG"] =
    "Filters encounter warnings to show only mechanics specifically targeting you. Recommended off (0) by default -- shows every encounter warning regardless of target, important for healers tracking group-wide mechanics. On (1) cuts visual noise on mechanics that don't require your action." -- MT

L["GEMS_CVAR_RAIDING_THREATNUM_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_THREATNUM_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_THREATNUM_DESCLONG"] =
    "Shows numeric threat percentage on target frame instead of just the threat colour band. Recommended on (1) for tanks -- you can read exact threat lead over the second-highest player and plan taunts. Off (0) shows the colour band only (green / yellow / orange / red)." -- MT

L["GEMS_CVAR_RAIDING_THREATSOUND_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_THREATSOUND_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_THREATSOUND_DESCLONG"] =
    "Plays an audio cue when you pull or lose threat. Recommended on (1) for tanks who pay attention to ears more than eyes -- the sound is faster than reading the bar colour. Off (0) makes threat purely visual, which matters if you raid with VoIP on speakers." -- MT

L["GEMS_CVAR_RAIDING_THREATTEXT_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_THREATTEXT_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_THREATTEXT_DESCLONG"] =
    "Shows a floating PULLED THREAT text in the screen middle when you pull aggro you shouldn't have. Recommended on (1) for DPS -- the warning is your last-second cue to drop threat or stop casting. Off (0) keeps the in-engine threat warnings purely on the unit frame." -- MT

-- L372 G.3b sixth wave -- options + descLong for 14 combat_targeting 0/1 toggle cvars (MT placeholders, awaiting native review)
L["GEMS_CVAR_COMBAT_SOFTFORCE_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBAT_SOFTFORCE_OPT_1"] = "On" -- MT
L["GEMS_CVAR_COMBAT_SOFTFORCE_DESCLONG"] =
    "Forces soft-targeting on units even when a hard target is already locked. Recommended on (1) -- this is how the modern WoW soft-target system smoothly hands off between manually picked targets and contextual soft-targets. Off (0) hides the soft-target indicator whenever a hard target is set, which is the legacy pre-Dragonflight behaviour." -- MT

L["GEMS_CVAR_COMBAT_SOFTFRIEND_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBAT_SOFTFRIEND_OPT_1"] = "Gamepad only" -- MT
L["GEMS_CVAR_COMBAT_SOFTFRIEND_DESCLONG"] =
    "Sets the soft-target highlight for friendly units -- the ghosted unit frame that appears when you face a player or NPC ally. Off (the default, and the EMS recommendation) suppresses it, which most healers prefer because they pick frames directly. Gamepad only enables it for controller binds. Mouse and keyboard only restricts it to KBM. Always shows it for both input modes. Healers and tanks who use click-targeting tend to leave this off so the soft-target overlay does not interfere with mouse picks." -- MT

L["GEMS_CVAR_COMBAT_TABNEW_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBAT_TABNEW_OPT_1"] = "On" -- MT
L["GEMS_CVAR_COMBAT_TABNEW_DESCLONG"] =
    "Uses the modern target-nearest algorithm (introduced in Dragonflight) instead of the legacy alphabetical-by-name tab-target order. Recommended on (1) -- the modern algorithm picks based on screen position, which is what 99% of players actually want when they hit TAB. Off (0) reverts to the legacy algorithm which can feel random." -- MT

L["GEMS_CVAR_COMBAT_COMBATLOCK_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBAT_COMBATLOCK_OPT_1"] = "On" -- MT
L["GEMS_CVAR_COMBAT_COMBATLOCK_DESCLONG"] =
    "Locks tab-target priority to your current target's combat-engagement set while you are in combat. Recommended on (1) -- prevents accidentally tabbing onto a non-combat NPC or summon when you're mid-pull. Off (0) lets TAB cycle through any unit in range regardless of combat state." -- MT

L["GEMS_CVAR_COMBAT_LOCKRELAX_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBAT_LOCKRELAX_OPT_1"] = "On" -- MT
L["GEMS_CVAR_COMBAT_LOCKRELAX_DESCLONG"] =
    "Allows tab-target priority lock to relax when no valid combat target remains nearby (e.g. last enemy died, you stepped out of combat). Recommended on (1) -- the relaxation prevents getting stuck with no tab-targetable unit after a pull ends. Off (0) keeps the lock active until combat explicitly ends, which can leave you without a tab target if combat is still technically active." -- MT

L["GEMS_CVAR_COMBAT_PVPPRIO_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBAT_PVPPRIO_OPT_1"] = "On" -- MT
L["GEMS_CVAR_COMBAT_PVPPRIO_DESCLONG"] =
    "Treats hostile players as higher priority than NPCs when picking tab-targets in PvP zones. Recommended on (1) for any open-world PvP play -- you want to tab onto the human threatening you, not the wolf next to them. Off (0) treats players and NPCs at equal priority, which is fine for purely PvE play." -- MT

L["GEMS_CVAR_COMBAT_ATTACKER_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBAT_ATTACKER_OPT_1"] = "On" -- MT
L["GEMS_CVAR_COMBAT_ATTACKER_DESCLONG"] =
    "Auto-targets the enemy that just attacked you if you have no current target. Recommended on (1) for casters and ranged classes -- the auto-target gives you something to retaliate against without losing a global cooldown to manual targeting. Off (0) is for players who want full manual control even in unexpected combat." -- MT

L["GEMS_CVAR_COMBAT_AUTOENEMY_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBAT_AUTOENEMY_OPT_1"] = "On" -- MT
L["GEMS_CVAR_COMBAT_AUTOENEMY_DESCLONG"] =
    "Auto-targets the nearest enemy when you start attacking with no target selected. Recommended on (1) -- the auto-pick is the fastest way to begin a melee engagement when you're walking into a pull. Off (0) means autoattack does nothing without a manual target first." -- MT

L["GEMS_CVAR_COMBAT_DESELECT_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBAT_DESELECT_OPT_1"] = "On" -- MT
L["GEMS_CVAR_COMBAT_DESELECT_DESCLONG"] =
    "Drops your current target when you click in empty space. Recommended off (0) by default -- accidental click-drops in the middle of a fight are a common cause of losing a kick-target or boss tab-target. On (1) for players who specifically want click-deselect as a quick way to clear targeting." -- MT

L["GEMS_CVAR_COMBAT_LEFTCLICK_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBAT_LEFTCLICK_OPT_1"] = "On" -- MT
L["GEMS_CVAR_COMBAT_LEFTCLICK_DESCLONG"] =
    "Allows left-click to interact with NPCs (talk, loot, vendor) instead of needing right-click. Recommended on (1) -- the modern Retail default since left-click is faster and matches every other game's interaction model. Off (0) reverts to the legacy right-click-to-interact behaviour." -- MT

L["GEMS_CVAR_COMBAT_HIGHLIGHT_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBAT_HIGHLIGHT_OPT_1"] = "On" -- MT
L["GEMS_CVAR_COMBAT_HIGHLIGHT_DESCLONG"] =
    "Highlights the unit that the AI assist system suggests you target next. Recommended off (0) by default -- the assist suggestions are noisy in busy fights and most experienced players ignore them. On (1) for new players learning a class who want the suggestion overlay as a training aid." -- MT

L["GEMS_CVAR_COMBAT_PROCS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBAT_PROCS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_COMBAT_PROCS_DESCLONG"] =
    "Shows the screen-edge flash overlay when a procced spell becomes castable (Hot Streak, Snipe, Sudden Death, etc.). Recommended on (1) -- the proc flash is how most rotations communicate cast this now to the player. Off (0) leaves you reading the bar manually, which is fine if you use WeakAura-style addons for procs." -- MT

L["GEMS_CVAR_COMBAT_LOC_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBAT_LOC_OPT_1"] = "On" -- MT
L["GEMS_CVAR_COMBAT_LOC_DESCLONG"] =
    "Shows the large screen overlay when you are stunned, silenced, feared, or otherwise loss-of-control'd. Recommended on (1) -- the overlay tells you what specifically is preventing you from acting and how long it lasts. Off (0) hides the overlay; you read your debuff bar instead." -- MT

L["GEMS_CVAR_COMBAT_MOUSEOVER_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBAT_MOUSEOVER_OPT_1"] = "On" -- MT
L["GEMS_CVAR_COMBAT_MOUSEOVER_DESCLONG"] =
    "Lets you cast targeted spells on whatever unit you're hovering over with the cursor, without changing your hard target. No recommended value -- mouseover casting is a healer-style technique that requires custom macros and isn't a universal default. On (1) enables the feature engine-wide; off (0) keeps cursor hover purely cosmetic." -- MT

L["GEMS_CVAR_FCT_ENERGY_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_FCT_ENERGY_OPT_1"] = "On" -- MT
L["GEMS_CVAR_FCT_ENERGY_DESCLONG"] =
    "Shows the floating numbers when you gain energy, rage, focus, or runic power outside of regen ticks (e.g. procced resource refunds). Recommended off (0) -- the gains are already visible on the resource bar, and the floating numbers add screen clutter. Turn on (1) only if you specifically want to track refund procs visually." -- MT

L["GEMS_CVAR_FCT_AURAS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_FCT_AURAS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_FCT_AURAS_DESCLONG"] =
    "Shows the floating notification when buffs or debuffs appear or fall off. Recommended off (0) -- BuffFrame and aura addons already display this with better positioning and grouping. Turn on (1) only if you don't use a buff addon and want the in-engine feedback." -- MT

L["GEMS_CVAR_FCT_HEALERS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_FCT_HEALERS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_FCT_HEALERS_DESCLONG"] =
    "Shows a marker over friendly healers in PvP combat so allies can see who is healing them. Recommended off (0) -- the engine implementation is unreliable on modern Retail and most arena UIs already track healers better through party frames. Turn on (1) if you specifically want the in-engine cue and don't use a focused PvP UI." -- MT

-- L372 G.3b seventh wave -- options + descLong for 12 solo_play 0/1 toggle cvars (MT placeholders, awaiting native review)
L["GEMS_CVAR_SOLO_AUTOLOOT_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_SOLO_AUTOLOOT_OPT_1"] = "On" -- MT
L["GEMS_CVAR_SOLO_AUTOLOOT_DESCLONG"] =
    "When you loot a corpse, every item lands in your bags automatically without the per-slot click prompt. Recommended on (1) -- the manual click prompt was the default 15 years ago and exists today only for nostalgia. Off (0) is for players who specifically want to see each item before accepting it, useful when sharing loot in old-world group play." -- MT

L["GEMS_CVAR_SOLO_LOOTMOUSE_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_SOLO_LOOTMOUSE_OPT_1"] = "On" -- MT
L["GEMS_CVAR_SOLO_LOOTMOUSE_DESCLONG"] =
    "Spawns the loot window directly under your cursor instead of in a fixed screen position. Recommended on (1) -- you don't have to drag the cursor across the screen to right-click items. Off (0) puts the window in a fixed location, easier to predict but slower to click through." -- MT

L["GEMS_CVAR_SOLO_AELOOT_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_SOLO_AELOOT_OPT_1"] = "On" -- MT
L["GEMS_CVAR_SOLO_AELOOT_DESCLONG"] =
    "Disables area-of-effect looting (one Shift-click loots every corpse in range). Recommended off (0) by default -- AE looting is the modern default and saves hundreds of clicks per session in mob-grinding content. Turn on (1) only if you want forced one-corpse-at-a-time looting for nostalgia or for picking through specific item drops." -- MT

L["GEMS_CVAR_SOLO_DISMOUNT_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_SOLO_DISMOUNT_OPT_1"] = "On" -- MT
L["GEMS_CVAR_SOLO_DISMOUNT_DESCLONG"] =
    "Automatically dismounts you when you try to cast a spell or attack while mounted. Recommended on (1) -- the alternative is the cast silently failing because mounted players cannot cast. Off (0) forces you to dismount manually before casting, which is fine for players who treat casting-while-mounted as a mistake worth blocking." -- MT

L["GEMS_CVAR_SOLO_DISMOUNTFLY_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_SOLO_DISMOUNTFLY_OPT_1"] = "On" -- MT
L["GEMS_CVAR_SOLO_DISMOUNTFLY_DESCLONG"] =
    "Automatically dismounts you from flying mounts even when in flight. Recommended off (0) by default -- dismounting at flight altitude drops you several hundred yards and almost always kills you. On (1) for players who fly low and want consistency with the ground-mount auto-dismount behaviour." -- MT

L["GEMS_CVAR_SOLO_TOT_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_SOLO_TOT_OPT_1"] = "On" -- MT
L["GEMS_CVAR_SOLO_TOT_DESCLONG"] =
    "Shows a small target-of-target frame near the main target frame so you can see who your target is targeting. Recommended on (1) for tanks (am I being attacked?) and healers (who is my tank healing?). Off (0) reclaims a small chunk of screen space, fine if you rely on raid frames or addons for the same info." -- MT

L["GEMS_CVAR_SOLO_TCASTBAR_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_SOLO_TCASTBAR_OPT_1"] = "On" -- MT
L["GEMS_CVAR_SOLO_TCASTBAR_DESCLONG"] =
    "Shows a castbar on the target frame for enemies and friendlies that are casting spells. Recommended on (1) -- the castbar tells you what the enemy is about to do and when to interrupt. Off (0) only makes sense for players who rely on dedicated nameplate or boss-mod castbar addons." -- MT

L["GEMS_CVAR_SOLO_QUESTWATCH_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_SOLO_QUESTWATCH_OPT_1"] = "On" -- MT
L["GEMS_CVAR_SOLO_QUESTWATCH_DESCLONG"] =
    "Automatically adds newly accepted quests to the visible quest tracker on the right side of the screen. Recommended on (1) -- accepting a quest implies you want to see how to do it. Off (0) is for players who manage the tracker manually and prefer a clean default state." -- MT

L["GEMS_CVAR_SOLO_QUESTPOI_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_SOLO_QUESTPOI_OPT_1"] = "On" -- MT
L["GEMS_CVAR_SOLO_QUESTPOI_DESCLONG"] =
    "Shows quest objectives as numbered icons on the world map and minimap. Recommended on (1) -- the POI icons are how modern WoW shows you where to go for any active quest. Off (0) reverts to text-only objective lists, useful only for players who specifically want a no-map exploration experience." -- MT

L["GEMS_CVAR_SOLO_PARTYPETS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_SOLO_PARTYPETS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_SOLO_PARTYPETS_DESCLONG"] =
    "Shows party-member pets in your party frame list (separate small bars under each party member). Recommended off (0) by default -- party pet bars clutter the party UI and most players read pet health through nameplates instead. On (1) for healers who explicitly want pet visibility, especially in Hunter-heavy or Warlock-heavy groups where pet damage tanking is part of the strategy." -- MT

L["GEMS_CVAR_SOLO_INTERICON_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_SOLO_INTERICON_OPT_1"] = "On" -- MT
L["GEMS_CVAR_SOLO_INTERICON_DESCLONG"] =
    "Shows the soft-target interact icon (the floating cursor-like glyph) on units you can interact with while in range. Recommended on (1) -- the icon tells you at a glance whether the NPC in front of you is talkable or just decoration. Off (0) hides the icon and you rely on cursor hover to discover interactable units." -- MT

L["GEMS_CVAR_SOLO_AUTOINTER_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_SOLO_AUTOINTER_OPT_1"] = "On" -- MT
L["GEMS_CVAR_SOLO_AUTOINTER_DESCLONG"] =
    "Auto-triggers the interact action on the soft-targeted unit when you walk into interact range. Recommended off (0) by default -- auto-interact is aggressive and triggers any time you walk past an NPC you didn't mean to talk to. On (1) is a controller or streamlined-UI preference for players who use the interact key as a primary input." -- MT

-- L372 G.3b eighth wave -- options + descLong for 17 dungeons + raid-leftover 0/1 toggle cvars (MT placeholders, awaiting native review)
L["GEMS_CVAR_RAIDING_COMBATWARN_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_COMBATWARN_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_COMBATWARN_DESCLONG"] =
    "Master toggle for all engine-level in-combat screen warnings (pull timers, role calls, encounter start). Recommended on (1) -- the master toggle gates every per-feature warning below it. Off (0) suppresses combat warnings engine-wide, useful only if you fully rely on an addon stack for raid feedback." -- MT

L["GEMS_CVAR_DUNGEON_DPSRESET_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_DUNGEON_DPSRESET_OPT_1"] = "On" -- MT
L["GEMS_CVAR_DUNGEON_DPSRESET_DESCLONG"] =
    "Resets the in-engine damage meter when you zone into a new dungeon or raid instance. Recommended on (1) -- the meter should show numbers for this pull, not lifetime totals from previous content. Off (0) keeps a running tally across instances, mostly useful only if you don't use Details or Skada for proper metering." -- MT

L["GEMS_CVAR_DUNGEON_ENTRANCE_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_DUNGEON_ENTRANCE_OPT_1"] = "On" -- MT
L["GEMS_CVAR_DUNGEON_ENTRANCE_DESCLONG"] =
    "Shows dungeon and raid entrance markers on the world map and minimap. Recommended on (1) -- the markers help locate dungeon entrances when running into-instance from outside (M+ pulls, weekly chest visits). Off (0) hides the markers; you navigate by memory or by group leader's coordinates." -- MT

L["GEMS_CVAR_DUNGEON_CLUTTER_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_DUNGEON_CLUTTER_OPT_1"] = "On" -- MT
L["GEMS_CVAR_DUNGEON_CLUTTER_DESCLONG"] =
    "Restricts the unit-clutter visual cleanup (transparent friendly players in dense areas) to inside instances only. Recommended on (1) -- the cleanup helps see boss mechanics in raids without affecting overworld visibility. Off (0) extends the clutter cleanup to overworld content too, which can hide players in capital cities." -- MT

L["GEMS_CVAR_DUNGEON_ENEMYCAST_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_DUNGEON_ENEMYCAST_OPT_1"] = "On" -- MT
L["GEMS_CVAR_DUNGEON_ENEMYCAST_DESCLONG"] =
    "Shows enemy castbars on Arena UI enemy frames. Recommended on (1) for arena PvP -- you need to see enemy casts to interrupt or counter them, and the Arena UI is often the cleanest source of that info. Off (0) hides the castbars; only fine if you use a dedicated PvP enemy-cast addon." -- MT

L["GEMS_CVAR_DUNGEON_LOGFILE_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_DUNGEON_LOGFILE_OPT_1"] = "On" -- MT
L["GEMS_CVAR_DUNGEON_LOGFILE_DESCLONG"] =
    "Appends a timestamp to each combat log file so new logs don't overwrite old ones. Recommended on (1) -- separate files per session are how Warcraft Logs uploaders find each raid night's data. Off (0) reuses one filename and overwrites, useful only if you don't archive combat logs." -- MT

L["GEMS_CVAR_DUNGEON_DIMINISH_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_DUNGEON_DIMINISH_OPT_1"] = "On" -- MT
L["GEMS_CVAR_DUNGEON_DIMINISH_DESCLONG"] =
    "Shows diminishing-returns indicators on enemy nameplates in PvP combat (stun, fear, root, etc.). Recommended on (1) for any PvP play -- you can see whether your next CC will be reduced-duration or completely immune. Off (0) hides the DR icons; you track DRs in your head." -- MT

L["GEMS_CVAR_RAIDING_COMBATLOG_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_COMBATLOG_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_COMBATLOG_DESCLONG"] =
    "Enables high-detail combat logging (per-event metadata, more granular timestamps). Recommended on (1) for any raider running parses through Warcraft Logs -- the advanced log fields are required for accurate parse uploading. Off (0) writes a slimmer log that uploads fail to parse correctly." -- MT

L["GEMS_CVAR_RAIDING_KEEPGRP_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_KEEPGRP_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_KEEPGRP_DESCLONG"] =
    "When sorting raid frames, keeps the original sub-group (Group 1, Group 2) ordering instead of merging across groups. Recommended off (0) by default -- modern role-sort is more useful than group-sort for healing. On (1) for raid leaders who use group composition as a tactical assignment (e.g. group 1 = ranged, group 2 = melee)." -- MT

L["GEMS_CVAR_RAIDING_TANKASSIST_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_TANKASSIST_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_TANKASSIST_DESCLONG"] =
    "Shows the Main Tank and Main Assist callouts visually on raid frames. Recommended on (1) -- the visual marker helps the raid identify who to follow for kill order and who to look at for taunt swaps. Off (0) hides the markers; fine only if your raid doesn't use the MA/MT system." -- MT

L["GEMS_CVAR_RAIDING_FINDSELF_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_FINDSELF_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_FINDSELF_DESCLONG"] =
    "Highlights your own raid frame more strongly than others. Recommended on (1) -- in a 30-person raid with similar-looking frames, you need to know which one is YOU at a glance. Off (0) treats your frame identically to everyone else's, which can cause confusion when self-healing or self-buffing." -- MT

L["GEMS_CVAR_RAIDING_CASTBUFFS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_CASTBUFFS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_CASTBUFFS_DESCLONG"] =
    "Shows buffs you can cast on raid frame portraits (your own Power Word: Shield, Innervate, etc.). Recommended off (0) by default -- the buff icons clutter raid frames and most players track their own cooldowns via the action bar. On (1) for buff-class healers who want visual confirmation of who has their HoT or shield active." -- MT

L["GEMS_CVAR_RAIDING_DISPDEBUFFS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_DISPDEBUFFS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_DISPDEBUFFS_DESCLONG"] =
    "Shows debuffs you can dispel on raid frame portraits (your Mass Dispel, Cure Disease, Decurse, etc.). Recommended on (1) for dispelling specs -- the highlight is how you spot which raid member needs the dispel without scanning the whole frame. Off (0) hides the highlight; you read raw debuff icons instead." -- MT

L["GEMS_CVAR_RAIDING_RAIDSETTINGS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_RAIDSETTINGS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_RAIDSETTINGS_DESCLONG"] =
    "Enables the raid-specific UI profile (alternate raid frame layout, larger nameplates, etc.) when you enter a raid instance. Recommended on (1) -- the raid profile is designed for 20-40 player groups and looks better than the party profile at that scale. Off (0) uses your party profile in raids, fine for players who explicitly want one consistent UI." -- MT

L["GEMS_CVAR_RAIDING_RAIDCLUTTER_OPT_0"] = "0 (none, dev-only)" -- MT
L["GEMS_CVAR_RAIDING_RAIDCLUTTER_OPT_1"] = "1 (minimum, recommended)" -- MT
L["GEMS_CVAR_RAIDING_RAIDCLUTTER_OPT_2"] = "2 (reduced, default)" -- MT
L["GEMS_CVAR_RAIDING_RAIDCLUTTER_OPT_3"] = "3 (performance)" -- MT
L["GEMS_CVAR_RAIDING_RAIDCLUTTER_OPT_4"] = "4 (full)" -- MT
L["GEMS_CVAR_RAIDING_RAIDCLUTTER_DESCLONG"] =
    "啟用團隊專用圖形設定後（EMS 在上方建議啟用），團隊副本會使用這一團隊專用鏡像值，而非一般的法術視覺密度。EMS 建議 1，理由與主設定相同：最低密度能在人多的戰鬥中保持首領機制與地面效果清晰可讀。該團隊鏡像值的暴雪預設值為 2。" -- MT

L["GEMS_CVAR_RAIDING_NOFILTER_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_NOFILTER_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_NOFILTER_DESCLONG"] =
    "Disables the default filtering of buffs and debuffs on the target frame (shows every buff/debuff regardless of source). Recommended off (0) by default -- the filter hides irrelevant buffs from the target frame which keeps it readable. Turn on (1) for tanks and theorycrafters who need full debuff visibility regardless of source." -- MT

L["GEMS_CVAR_RAIDING_MYSPELLS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_MYSPELLS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_RAIDING_MYSPELLS_DESCLONG"] =
    "Makes your own spell effects render more prominently than other players' effects on screen. Recommended on (1) -- you need to see whether your ground effect (Healing Rain, Death and Decay, Consecration) landed where you placed it, distinct from teammates' similar effects. Off (0) renders every player's spell effects at uniform intensity." -- MT

-- L372 G.3b ninth wave -- options + descLong for 2 string-enum cvars (MT placeholders, awaiting native review)
L["GEMS_CVAR_RAIDING_HEALTHTEXT_OPT_NONE"] = "None" -- MT
L["GEMS_CVAR_RAIDING_HEALTHTEXT_OPT_PERC"] = "Percentage" -- MT
L["GEMS_CVAR_RAIDING_HEALTHTEXT_OPT_HEALTH"] = "Health value" -- MT
L["GEMS_CVAR_RAIDING_HEALTHTEXT_OPT_LOSTHEALTH"] = "Lost health" -- MT
L["GEMS_CVAR_RAIDING_HEALTHTEXT_DESCLONG"] =
    "Sets what text appears on raid frame health bars. None (the default) keeps bars clean and lets you focus on the bar fill alone. Percentage shows XX% which is the most readable at-a-glance health gauge. Health shows the raw health value (e.g. 347000 / 480000), useful for tanks tracking specific HP thresholds for defensive cooldowns. Lost health shows the missing-HP number (e.g. -133000), useful for healers matching incoming heal sizes to actual deficits." -- MT

L["GEMS_CVAR_RAIDING_SORTMODE_OPT_ROLE"] = "By role (tank / heal / DPS)" -- MT
L["GEMS_CVAR_RAIDING_SORTMODE_OPT_GROUP"] = "By group number" -- MT
L["GEMS_CVAR_RAIDING_SORTMODE_DESCLONG"] =
    "Sets the sort order for raid frames. Role (the default) groups tanks at the top, then healers, then DPS -- matches the priority-of-attention order most players want. Group keeps Group 1 / Group 2 / Group N groupings intact, useful for raid leaders who use group composition as tactical assignment." -- MT

L["GEMS_CVAR_FIX_ALL_BUSY"] = "GEMS: 正在修復 %d 個 CVars..." -- MT
L["GEMS_CVAR_FIX_ALL_DONE"] = "GEMS: 已修復 %d 個 CVars。" -- MT
L["GEMS_CVAR_FIX_ALL_DONE_PARTIAL"] = "GEMS: Fixed %d of %d CVars (%d pinned or combat-locked)." -- MT
L["GEMS_CVAR_RESET_DEFAULTS"] = "全部重置為暴雪預設" -- MT
-- TODO: gloss SQW (MT review)
L["GEMS_CVAR_RESET_DEFAULTS_DESC"] =
    "將每個建議的 CVar 重置為其暴雪出貨的預設值。已釘選的 CVars 和 SQW 管理項目將略過。每行有復原按鈕可還原它。登入時自動修復加入也會被清除 -- 重置後若您希望 EMS 重新管理它們,請重新切換。" -- MT
-- TODO: gloss SQW (MT review)
L["GEMS_CVAR_RESET_DEFAULTS_CONFIRM"] =
    "將 %d 個 CVars 重置為暴雪預設?已釘選的 CVars 和 SQW 管理項目將略過。您可以個別復原每個還原的 CVar。" -- MT
L["GEMS_CVAR_RESET_DEFAULTS_BUSY"] = "GEMS: 正在將 %d 個 CVars 重置為暴雪預設..." -- MT

L["GEMS_CVAR_RESET_DEFAULTS_DONE"] =
    "GEMS: 已重置 %d 個 CVars。每行有復原。登入時自動修復加入已清除。" -- MT
L["GEMS_CVAR_RESET_DEFAULTS_DONE_PARTIAL"] =
    "GEMS: Reset %d of %d CVars (%d pinned or combat-locked). Each row has Undo. Auto-fix-on-login opt-ins were cleared." -- MT
L["GEMS_CVAR_ONBOARDING_BODY"] =
    "EMS 掃描 %d 個遊戲設定 (CVars) 並向您顯示哪些符合建議值。綠點表示符合。紅色表示關鍵不符。黃色表示次佳。\n\n點擊任一行的修復以套用建議,或使用上方按鈕一次修復多個。釘選我的選擇告訴 EMS 保留 CVar 不動,適用於您想保留自己的值時。" -- MT

-- CVar Section Headers
L["GEMS_CVAR_SECTION_MACRO"] = "巨集序列" -- MT
L["GEMS_CVAR_SECTION_COMBAT"] = "戰鬥與目標" -- MT
L["GEMS_CVAR_SECTION_NAMEPLATES"] = "姓名板" -- MT
L["GEMS_CVAR_SECTION_RAIDING"] = "團隊副本" -- MT
L["GEMS_CVAR_SECTION_DUNGEON"] = "地下城與傳奇鑰石" -- MT
L["GEMS_CVAR_SECTION_SOLO"] = "單人遊玩與開放世界" -- MT
L["GEMS_CVAR_SECTION_UI"] = "UI 與生活品質" -- MT
L["GEMS_CVAR_SECTION_FPS"] = "FPS 與效能" -- MT
L["GEMS_CVAR_SECTION_VISUAL"] = "視覺品質" -- MT
L["GEMS_CVAR_SECTION_SOUND"] = "聲音" -- MT
L["GEMS_CVAR_SECTION_FCT"] = "浮動戰鬥文字" -- MT
L["GEMS_CVAR_SECTION_ACCESS"] = "輔助使用" -- MT
L["GEMS_CVAR_SECTION_DRAGON"] = "馭龍術與進階飛行" -- MT

-- CVar Section: Macro Sequencing
L["GEMS_CVAR_MACRO_KEYDOWN"] = "按鍵按下施法" -- MT
L["GEMS_CVAR_MACRO_KEYDOWN_DESC"] =
    "於按鍵按下時觸發能力,而非釋放時。若為 0,每次巨集按鍵都有 50-100ms 的額外延遲。對於序列化是必要的。" -- MT
L["GEMS_CVAR_MACRO_KEYHELD"] = "按住施法" -- MT
L["GEMS_CVAR_MACRO_KEYHELD_DESC"] =
    "按住會自動重複能力。僅適用於原生暴雪動作按鈕,不適用於外掛建立的按鈕。Hold Mode 作用時會為您管理此設定。基於偏好 -- 兩者皆無建議。" -- MT
L["GEMS_CVAR_MACRO_SPELLQUEUE"] = "法術佇列視窗" -- MT
L["GEMS_CVAR_MACRO_SPELLQUEUE_DESC"] =
    "GCD 結束前可佇列下一個法術的毫秒數。對大多數玩家而言 400ms 為最佳。" -- MT
L["GEMS_CVAR_MACRO_LOCKBARS"] = "鎖定動作條" -- MT
L["GEMS_CVAR_MACRO_LOCKBARS_DESC"] = "防止戰鬥中意外將巨集樁從動作條拖出。" -- MT

L["GEMS_CVAR_MACRO_MULTIBARS"] = "多動作條" -- MT
L["GEMS_CVAR_MACRO_MULTIBARS_DESC"] =
    "選擇要啟用哪些額外動作條 (0=無,15=全部)。更多動作條 = 更多空間放置巨集樁。" -- MT
L["GEMS_CVAR_MACRO_AUTOPUSH"] = "自動推送法術" -- MT
L["GEMS_CVAR_MACRO_AUTOPUSH_DESC"] =
    "自動將新法術放在動作條上。建議關閉 -- 升級時的新法術會將巨集樁推離動作條。" -- MT
L["GEMS_CVAR_MACRO_SELFCAST"] = "自動自我施法" -- MT
L["GEMS_CVAR_MACRO_SELFCAST_DESC"] =
    "無有效目標時自動對自己施放有益法術。對含有自我治療的巨集步驟很重要。" -- MT
L["GEMS_CVAR_MACRO_AUTOSTAND"] = "自動站立" -- MT
L["GEMS_CVAR_MACRO_AUTOSTAND_DESC"] = "施法時自動站立。沒有此項,巨集序列會在坐著時靜默失敗。" -- MT
L["GEMS_CVAR_MACRO_AUTOUNSHIFT"] = "自動取消變身" -- MT
L["GEMS_CVAR_MACRO_AUTOUNSHIFT_DESC"] =
    "施放不相容法術時自動離開變形/潛行。沒有此項,德魯伊/盜賊巨集步驟會靜默失敗。" -- MT
L["GEMS_CVAR_MACRO_STOPATTACK"] = "切換時停止攻擊" -- MT
L["GEMS_CVAR_MACRO_STOPATTACK_DESC"] =
    "切換目標時繼續自動攻擊。若為 1,序列中切換目標會停止近戰自動攻擊。" -- MT
L["GEMS_CVAR_MACRO_ICONRATE"] = "圖示更新速率" -- MT
L["GEMS_CVAR_MACRO_ICONRATE_DESC"] =
    "動作條圖示重新整理的頻率 (秒)。0.05 = 每秒 20 次更新,比預設 0.1 更流暢。" -- MT
L["GEMS_CVAR_MACRO_CDCOUNT"] = "冷卻倒數" -- MT
L["GEMS_CVAR_MACRO_CDCOUNT_DESC"] =
    "在動作按鈕上顯示數字冷卻計時器。對於查看序列按鈕的精確剩餘冷卻至關重要。" -- MT
L["GEMS_CVAR_MACRO_SECTOGGLE"] = "安全能力切換" -- MT
L["GEMS_CVAR_MACRO_SECTOGGLE_DESC"] = "防止雙擊將能力切換關閉。防止快速按鍵停用切換能力。" -- MT
L["GEMS_CVAR_MACRO_EMPTAP"] = "強化點按控制" -- MT
L["GEMS_CVAR_MACRO_EMPTAP_DESC"] =
    "強化法術 (喚能師) 的點點 vs 按住釋放。按住釋放與序列搭配更好。" -- MT
L["GEMS_CVAR_MACRO_EMPHOLD"] = "強化按住階段" -- MT
L["GEMS_CVAR_MACRO_EMPHOLD_DESC"] =
    "自動釋放前所需的第一個強化階段百分比 [0.0-1.0]。喚能師專用。" -- MT

L["GEMS_CVAR_MACRO_HELDPOLL"] = "按住法術輪詢時間" -- MT
L["GEMS_CVAR_MACRO_HELDPOLL_DESC"] =
    "按住法術施法失敗時的重試嘗試間隔毫秒。較低 = 更快重試,更具回應性。" -- MT
L["GEMS_CVAR_MACRO_PRECAST"] = "預先施法" -- MT
L["GEMS_CVAR_MACRO_PRECAST_DESC"] = "在法術實際觸發前略早顯示施法動畫。未文件化的暴雪功能。" -- MT

-- CVar Section: Combat & Targeting
L["GEMS_CVAR_COMBAT_SOFTENEMY"] = "軟目標敵人" -- MT
L["GEMS_CVAR_COMBAT_SOFTENEMY_DESC"] =
    "軟目標何時為敵人啟動。0=關閉,1=遊戲手把,2=鍵鼠,3=永遠。建議 3 以自動取得。" -- MT
L["GEMS_CVAR_COMBAT_SOFTARC"] = "軟目標弧形" -- MT
L["GEMS_CVAR_COMBAT_SOFTARC_DESC"] =
    "敵人軟目標的方向限制。0=必須直接面對,1=前方弧形,2=任何位置。" -- MT
L["GEMS_CVAR_COMBAT_SOFTRANGE"] = "軟目標範圍" -- MT
L["GEMS_CVAR_COMBAT_SOFTRANGE_DESC"] =
    "軟目標敵人偵測的最大範圍 (碼)。45 碼涵蓋大多數遠程能力。" -- MT
L["GEMS_CVAR_COMBAT_SOFTFORCE"] = "軟目標強制" -- MT
L["GEMS_CVAR_COMBAT_SOFTFORCE_DESC"] =
    "自動鎖定軟目標。沒有此項,軟目標會顯示目標但法術會對空中施放。" -- MT
L["GEMS_CVAR_COMBAT_SOFTFRIEND"] = "軟目標友方" -- MT
L["GEMS_CVAR_COMBAT_SOFTFRIEND_DESC"] =
    "友方的軟目標。0=關閉。治療者可能想要 3 (永遠)。DPS 應保持為 0。" -- MT
L["GEMS_CVAR_COMBAT_SOFTLOCKED"] = "鎖定時軟目標" -- MT
L["GEMS_CVAR_COMBAT_SOFTLOCKED_DESC"] = "在硬鎖定目標時允許軟目標。2=永遠允許軟目標預覽。" -- MT
L["GEMS_CVAR_COMBAT_SOFTMATCH"] = "軟匹配鎖定" -- MT
L["GEMS_CVAR_COMBAT_SOFTMATCH_DESC"] =
    "將軟目標與鎖定目標匹配。讓軟目標指示器與您實際目標保持同步。" -- MT
L["GEMS_CVAR_COMBAT_TABNEW"] = "新 Tab 目標" -- MT
L["GEMS_CVAR_COMBAT_TABNEW_DESC"] =
    "使用現代 (7.2+) Tab 目標演算法。優先選擇您前方且戰鬥中的敵人。" -- MT

L["GEMS_CVAR_COMBAT_COMBATLOCK"] = "戰鬥目標鎖定" -- MT
L["GEMS_CVAR_COMBAT_COMBATLOCK_DESC"] =
    "將 Tab 目標鎖定為戰鬥中敵人。防止跳到尚未拉的遠處怪物。" -- MT
L["GEMS_CVAR_COMBAT_LOCKRELAX"] = "鎖定放鬆" -- MT
L["GEMS_CVAR_COMBAT_LOCKRELAX_DESC"] = "當沒有戰鬥中目標時,智慧地放鬆戰鬥鎖定。" -- MT
L["GEMS_CVAR_COMBAT_PVPPRIO"] = "PvP 目標優先" -- MT
L["GEMS_CVAR_COMBAT_PVPPRIO_DESC"] = "在 PvP 中,優先選擇玩家和重要 PvP 目標。1=玩家優先。" -- MT
L["GEMS_CVAR_COMBAT_ATTACKER"] = "目標攻擊者" -- MT
L["GEMS_CVAR_COMBAT_ATTACKER_DESC"] =
    "自動鎖定攻擊您的敵人。對於怪物仇恨的單人遊玩至關重要。" -- MT
L["GEMS_CVAR_COMBAT_AUTOENEMY"] = "自動鎖定敵人" -- MT
L["GEMS_CVAR_COMBAT_AUTOENEMY_DESC"] =
    "在無目標施放攻擊性法術時自動鎖定最近敵人。確保巨集觸發。" -- MT
L["GEMS_CVAR_COMBAT_DESELECT"] = "點擊取消選擇" -- MT
L["GEMS_CVAR_COMBAT_DESELECT_DESC"] =
    "點擊地形時清除目標。若為 1,戰鬥中點擊地面會取消您的目標。" -- MT
L["GEMS_CVAR_COMBAT_LEFTCLICK"] = "互動左鍵點擊" -- MT
L["GEMS_CVAR_COMBAT_LEFTCLICK_DESC"] = "左鍵點擊與 NPC 互動。大多數玩家預期的標準行為。" -- MT
L["GEMS_CVAR_COMBAT_HIGHLIGHT"] = "戰鬥高亮" -- MT
L["GEMS_CVAR_COMBAT_HIGHLIGHT_DESC"] =
    "下個施法的法術高亮。在視覺上與序列追蹤競爭。建議關閉。" -- MT
L["GEMS_CVAR_COMBAT_PROCS"] = "觸發疊層" -- MT
L["GEMS_CVAR_COMBAT_PROCS_DESC"] =
    "顯示觸發/法術警示疊層 (發光邊框)。對於看到影響巨集優先順序的觸發很重要。" -- MT
L["GEMS_CVAR_COMBAT_PROCOPACITY"] = "觸發疊層透明度" -- MT
L["GEMS_CVAR_COMBAT_PROCOPACITY_DESC"] =
    "法術警示疊層的透明度。預設 0.65 不錯。如果難以看見,提升至 0.8-1.0。" -- MT
L["GEMS_CVAR_COMBAT_LOC"] = "失去控制" -- MT
L["GEMS_CVAR_COMBAT_LOC_DESC"] =
    "暈眩/沉默時顯示失去控制橫幅。幫助理解為何巨集序列看起來卡住。" -- MT
L["GEMS_CVAR_COMBAT_MOUSEOVER"] = "滑鼠移過施法" -- MT
L["GEMS_CVAR_COMBAT_MOUSEOVER_DESC"] = "對游標下的單位施法而不變更目標。對治療者來說很重要。" -- MT

L["GEMS_CVAR_COMBAT_FRIENDARC"] = "友方軟弧形" -- MT
L["GEMS_CVAR_COMBAT_FRIENDARC_DESC"] =
    "友方軟目標的方向限制。與敵人弧形設定相同概念。僅在啟用軟目標友方時才重要。" -- MT
L["GEMS_CVAR_COMBAT_FRIENDRANGE"] = "友方軟範圍" -- MT
L["GEMS_CVAR_COMBAT_FRIENDRANGE_DESC"] = "軟目標友方偵測的最大範圍。45 碼涵蓋所有治療法術。" -- MT

-- CVar Section: Nameplates
L["GEMS_CVAR_NAMEPLATES_SHOWALL"] = "顯示所有姓名板" -- MT
L["GEMS_CVAR_NAMEPLATES_SHOWALL_DESC"] =
    "顯示所有姓名板 (敵人、友方 NPC、寵物)。主開關。大多數戰鬥玩家想要此項開啟。" -- MT
L["GEMS_CVAR_NAMEPLATES_SHOWENEMY"] = "顯示敵人姓名板" -- MT
L["GEMS_CVAR_NAMEPLATES_SHOWENEMY_DESC"] = "顯示敵人姓名板。任何戰鬥意識都必須開啟。" -- MT
L["GEMS_CVAR_NAMEPLATES_SHOWSELF"] = "顯示自身姓名板" -- MT
L["GEMS_CVAR_NAMEPLATES_SHOWSELF_DESC"] =
    "顯示個人資源顯示 (角色下方的生命/法力條)。許多玩家不知道有此項。" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXDIST"] = "最大距離" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXDIST_DESC"] =
    "最大姓名板渲染距離。60 碼為上限與預設。較低值節省 GPU 但失去意識。" -- MT
L["GEMS_CVAR_NAMEPLATES_PLAYERDIST"] = "玩家最大距離" -- MT
L["GEMS_CVAR_NAMEPLATES_PLAYERDIST_DESC"] = "玩家姓名板的最大距離。保持與 nameplateMaxDistance 相等。" -- MT
L["GEMS_CVAR_NAMEPLATES_MINALPHA"] = "最小不透明度" -- MT
L["GEMS_CVAR_NAMEPLATES_MINALPHA_DESC"] =
    "遠處姓名板的最小不透明度。預設 0.6 讓遠處姓名板難以看見。0.8 更好。" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXALPHA"] = "最大不透明度" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXALPHA_DESC"] =
    "附近姓名板的最大不透明度。1.0 = 完全不透明。沒有理由降低。" -- MT
L["GEMS_CVAR_NAMEPLATES_MINSCALE"] = "最小縮放" -- MT
L["GEMS_CVAR_NAMEPLATES_MINSCALE_DESC"] =
    "遠處姓名板的最小縮放。較低值會使遠處姓名板太小無法閱讀。" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXSCALE"] = "最大縮放" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXSCALE_DESC"] = "附近姓名板的最大縮放。" -- MT

L["GEMS_CVAR_NAMEPLATES_SELSCALE"] = "選擇縮放" -- MT
L["GEMS_CVAR_NAMEPLATES_SELSCALE_DESC"] =
    "您目前目標姓名板的縮放乘數。預設 1.2 讓目標在視覺上突出。" -- MT
L["GEMS_CVAR_NAMEPLATES_OCCLUDED"] = "遮蔽不透明度" -- MT
L["GEMS_CVAR_NAMEPLATES_OCCLUDED_DESC"] =
    "牆壁/物體後方姓名板的不透明度。預設 0.4 幾乎不可見。0.6 保持可讀。" -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPH"] = "水平重疊" -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPH_DESC"] = "水平堆疊重疊。較低 = 更分散。0.8 為預設堆疊行為。" -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPV"] = "垂直重疊" -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPV_DESC"] = "垂直堆疊重疊。控制姓名板在 AoE 包中如何垂直堆疊。" -- MT
L["GEMS_CVAR_NAMEPLATES_CASTBARS"] = "姓名板施法條" -- MT
L["GEMS_CVAR_NAMEPLATES_CASTBARS_DESC"] = "在姓名板上顯示施法條。對打斷至關重要。" -- MT
L["GEMS_CVAR_NAMEPLATES_CLASSCOLOR"] = "職業顏色條" -- MT
L["GEMS_CVAR_NAMEPLATES_CLASSCOLOR_DESC"] =
    "依職業為敵方姓名板生命條上色。對 PvP 目標識別很重要。" -- MT
L["GEMS_CVAR_NAMEPLATES_DEBUFFS"] = "友方減益" -- MT
L["GEMS_CVAR_NAMEPLATES_DEBUFFS_DESC"] = "在友方姓名板上顯示減益。對治療者和驅散者有用。" -- MT
L["GEMS_CVAR_NAMEPLATES_MINIONS"] = "敵方僕從" -- MT
L["GEMS_CVAR_NAMEPLATES_MINIONS_DESC"] =
    "顯示僕從姓名板。預設關閉以減少混亂。在重要僕從生命的傳奇鑰石中啟用。" -- MT
L["GEMS_CVAR_NAMEPLATES_MINUS"] = "微不足道的敵人" -- MT
L["GEMS_CVAR_NAMEPLATES_MINUS_DESC"] =
    "顯示微不足道 (減號) 敵人的姓名板。在開放世界中查看所有怪物時有用。" -- MT
L["GEMS_CVAR_NAMEPLATES_TOTEMS"] = "敵方圖騰" -- MT
L["GEMS_CVAR_NAMEPLATES_TOTEMS_DESC"] = "顯示敵方圖騰姓名板。在 PvP 中很重要 -- 圖騰是擊殺目標。" -- MT
L["GEMS_CVAR_NAMEPLATES_FRIENDLY"] = "友方玩家" -- MT
L["GEMS_CVAR_NAMEPLATES_FRIENDLY_DESC"] =
    "顯示友方玩家姓名板。PvE 中關閉以減少混亂。PvP 中開啟以保持意識。" -- MT

L["GEMS_CVAR_NAMEPLATES_AURASCALE"] = "光環圖示縮放" -- MT
L["GEMS_CVAR_NAMEPLATES_AURASCALE_DESC"] =
    "姓名板上增益/減益圖示的縮放乘數。1.2 讓 DoT 追蹤一目瞭然。" -- MT
L["GEMS_CVAR_NAMEPLATES_NAMEONLY"] = "僅顯示友方姓名" -- MT
L["GEMS_CVAR_NAMEPLATES_NAMEONLY_DESC"] =
    "將友方姓名板簡化為僅顯示姓名 (無生命條)。減少團隊副本中的視覺雜訊。" -- MT
L["GEMS_CVAR_NAMEPLATES_ATBASE"] = "於底部位置" -- MT
L["GEMS_CVAR_NAMEPLATES_ATBASE_DESC"] = "將非目標姓名板放置於角色底部而非頭頂。0=頭頂 (標準)。" -- MT
L["GEMS_CVAR_NAMEPLATES_OFFSCREEN"] = "顯示螢幕外" -- MT
L["GEMS_CVAR_NAMEPLATES_OFFSCREEN_DESC"] = "顯示螢幕外目標的姓名板。可能有用但也雜亂。" -- MT
L["GEMS_CVAR_NAMEPLATES_RADIAL"] = "放射狀位置" -- MT
L["GEMS_CVAR_NAMEPLATES_RADIAL_DESC"] = "螢幕外時於螢幕邊緣放射狀顯示目標姓名板。0=關閉。" -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTNP"] = "軟目標姓名板" -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTNP_DESC"] = "永遠顯示軟目標敵人的姓名板。" -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTSIZE"] = "軟目標大小" -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTSIZE_DESC"] =
    "姓名板上軟目標指示器的大小。預設 19 可能難以看見。25 較好。" -- MT
L["GEMS_CVAR_NAMEPLATES_DEBUFFPAD"] = "減益填充" -- MT
L["GEMS_CVAR_NAMEPLATES_DEBUFFPAD_DESC"] = "減益清單與生命條之間的填充。0 = 緊湊。" -- MT

-- CVar Section: Raiding
L["GEMS_CVAR_RAIDING_COMBATLOG"] = "進階戰鬥日誌" -- MT
L["GEMS_CVAR_RAIDING_COMBATLOG_DESC"] =
    "啟用進階戰鬥日誌 (額外事件資料)。對於精確的 Warcraft Logs 上傳是必需的。" -- MT

L["GEMS_CVAR_RAIDING_THREATWARN"] = "仇恨警告" -- MT
L["GEMS_CVAR_RAIDING_THREATWARN_DESC"] = "仇恨警告顯示。0=關閉,1=地下城,2=隊伍,3=永遠。" -- MT
L["GEMS_CVAR_RAIDING_THREATNUM"] = "數字仇恨" -- MT
L["GEMS_CVAR_RAIDING_THREATNUM_DESC"] =
    "在目標/焦點框架上顯示數字仇恨值。對坦克和注重仇恨的 DPS 有用。" -- MT
L["GEMS_CVAR_RAIDING_THREATSOUND"] = "仇恨聲音" -- MT
L["GEMS_CVAR_RAIDING_THREATSOUND_DESC"] = "仇恨轉移時播放聲音 (取得/失去仇恨)。" -- MT
L["GEMS_CVAR_RAIDING_THREATTEXT"] = "仇恨世界文字" -- MT
L["GEMS_CVAR_RAIDING_THREATTEXT_DESC"] = "戰鬥中顯示仇恨浮動文字 (仇恨文字)。" -- MT
L["GEMS_CVAR_RAIDING_TIMELINE"] = "遭遇時間軸" -- MT
L["GEMS_CVAR_RAIDING_TIMELINE_DESC"] = "啟用首領遭遇時間軸。顯示即將到來的首領能力。" -- MT
L["GEMS_CVAR_RAIDING_TIMEROLE"] = "時間軸角色篩選" -- MT
L["GEMS_CVAR_RAIDING_TIMEROLE_DESC"] =
    "隱藏與您角色無關的遭遇時間軸事件。減少 DPS/治療的雜訊。" -- MT
L["GEMS_CVAR_RAIDING_WARNINGS"] = "遭遇警告" -- MT
L["GEMS_CVAR_RAIDING_WARNINGS_DESC"] = "顯示遭遇警告訊息 (首領能力警示)。" -- MT
L["GEMS_CVAR_RAIDING_WARNHIDE"] = "隱藏非目標警告" -- MT
L["GEMS_CVAR_RAIDING_WARNHIDE_DESC"] =
    "隱藏未針對您的首領警告。0=顯示全部 (較安全)。1=經驗豐富的團隊副本玩家較少雜訊。" -- MT
L["GEMS_CVAR_RAIDING_AGGRO"] = "仇恨高亮" -- MT
L["GEMS_CVAR_RAIDING_AGGRO_DESC"] = "當該玩家擁有仇恨時高亮團隊副本框架。" -- MT
L["GEMS_CVAR_RAIDING_RDEBUFFS"] = "團隊副本框架減益" -- MT
L["GEMS_CVAR_RAIDING_RDEBUFFS_DESC"] = "在團隊副本框架上顯示減益。對治療者和驅散者至關重要。" -- MT
L["GEMS_CVAR_RAIDING_HEALPRED"] = "傳入治療" -- MT
L["GEMS_CVAR_RAIDING_HEALPRED_DESC"] = "在團隊副本框架上顯示傳入治療預測。" -- MT
L["GEMS_CVAR_RAIDING_POWERBARS"] = "團隊副本能量條" -- MT
L["GEMS_CVAR_RAIDING_POWERBARS_DESC"] =
    "在團隊副本框架上顯示法力/怒氣/能量條。預設關閉以節省空間。" -- MT
L["GEMS_CVAR_RAIDING_RCLASSCOLOR"] = "團隊副本職業顏色" -- MT
L["GEMS_CVAR_RAIDING_RCLASSCOLOR_DESC"] = "依職業為團隊副本框架生命條上色。讓識別玩家更容易。" -- MT

L["GEMS_CVAR_RAIDING_DISPONLY"] = "僅可驅散" -- MT
L["GEMS_CVAR_RAIDING_DISPONLY_DESC"] = "篩選為僅顯示您可驅散的減益。0=顯示全部。" -- MT
L["GEMS_CVAR_RAIDING_ROLEDEBUFF"] = "角色減益大小" -- MT
L["GEMS_CVAR_RAIDING_ROLEDEBUFF_DESC"] =
    "以較大尺寸顯示角色相關減益。坦克看到坦克減益較大,治療看到治療減益較大。" -- MT
L["GEMS_CVAR_RAIDING_BIGDEF"] = "中央大型防禦" -- MT
L["GEMS_CVAR_RAIDING_BIGDEF_DESC"] =
    "在團隊副本框架中央顯示大型防禦冷卻 (Ironbark、Pain Suppression)。" -- MT
L["GEMS_CVAR_RAIDING_DISPTYPE"] = "驅散指示器" -- MT
L["GEMS_CVAR_RAIDING_DISPTYPE_DESC"] = "驅散指示器樣式。0=無,1=圖示,2=圖示+高亮。" -- MT
L["GEMS_CVAR_RAIDING_HEALTHTEXT"] = "生命文字模式" -- MT
L["GEMS_CVAR_RAIDING_HEALTHTEXT_DESC"] =
    "生命文字顯示模式。none、health、losthealth 或 perc。基於偏好。" -- MT
L["GEMS_CVAR_RAIDING_SORTMODE"] = "團隊副本排序模式" -- MT
L["GEMS_CVAR_RAIDING_SORTMODE_DESC"] = "團隊副本框架排序模式。role (坦克/治療/DPS) 或 group。" -- MT
L["GEMS_CVAR_RAIDING_KEEPGRP"] = "保持群組一起" -- MT
L["GEMS_CVAR_RAIDING_KEEPGRP_DESC"] = "保持團隊副本群組視覺上分隔。0=混合,1=群組區塊。" -- MT
L["GEMS_CVAR_RAIDING_TANKASSIST"] = "坦克與輔助" -- MT
L["GEMS_CVAR_RAIDING_TANKASSIST_DESC"] = "在團隊副本框架中顯示主坦克和主輔助單位。" -- MT
L["GEMS_CVAR_RAIDING_FINDSELF"] = "找到自己" -- MT
L["GEMS_CVAR_RAIDING_FINDSELF_DESC"] = "在團隊副本框架中高亮您自己的角色。" -- MT
L["GEMS_CVAR_RAIDING_CASTBUFFS"] = "可施放增益" -- MT
L["GEMS_CVAR_RAIDING_CASTBUFFS_DESC"] = "僅顯示您可以施放的增益 (僅團隊副本)。0=顯示全部。" -- MT
L["GEMS_CVAR_RAIDING_DISPDEBUFFS"] = "顯示驅散減益" -- MT
L["GEMS_CVAR_RAIDING_DISPDEBUFFS_DESC"] = "僅顯示您可驅散的減益 (僅團隊副本)。" -- MT
L["GEMS_CVAR_RAIDING_RAIDSETTINGS"] = "團隊副本圖形設定" -- MT
L["GEMS_CVAR_RAIDING_RAIDSETTINGS_DESC"] =
    "為團隊副本啟用獨立的圖形設定。最大的單一團隊副本 FPS 改善。許多玩家錯過此項。" -- MT
L["GEMS_CVAR_RAIDING_RAIDCLUTTER"] = "團隊法術視覺密度" -- MT
L["GEMS_CVAR_RAIDING_RAIDCLUTTER_DESC"] = "啟用團隊專用設定時，團隊副本內使用的法術視覺密度。" -- MT
L["GEMS_CVAR_RAIDING_NOFILTER"] = "無增益/減益篩選" -- MT
L["GEMS_CVAR_RAIDING_NOFILTER_DESC"] =
    "停用目標框架上所有增益/減益篩選。0=正常篩選。1=查看所有。" -- MT

L["GEMS_CVAR_RAIDING_MYSPELLS"] = "強調我的法術" -- MT
L["GEMS_CVAR_RAIDING_MYSPELLS_DESC"] =
    "降低其他玩家的法術效果同時保持您的全強度。20 人團隊副本中至關重要。" -- MT
L["GEMS_CVAR_RAIDING_COMBATWARN"] = "戰鬥警告" -- MT
L["GEMS_CVAR_RAIDING_COMBATWARN_DESC"] = "戰鬥警告 UI (首領時間軸 + 警告) 的主開關。" -- MT

-- CVar Section: Dungeons & M+
L["GEMS_CVAR_DUNGEON_DPSRESET"] = "DPS 計量重置" -- MT
L["GEMS_CVAR_DUNGEON_DPSRESET_DESC"] =
    "進入新副本時自動重置傷害計量。每個地下城乾淨資料而無需手動重置。" -- MT
L["GEMS_CVAR_DUNGEON_ENTRANCE"] = "地下城入口" -- MT
L["GEMS_CVAR_DUNGEON_ENTRANCE_DESC"] = "在世界地圖上顯示地下城入口圖示。" -- MT
L["GEMS_CVAR_DUNGEON_CLUTTER"] = "單位雜亂篩選" -- MT
L["GEMS_CVAR_DUNGEON_CLUTTER_DESC"] = "限制單位雜亂 (NPC 堆疊減少) 僅在副本中。" -- MT
L["GEMS_CVAR_DUNGEON_ENEMYCAST"] = "敵人施法條" -- MT
L["GEMS_CVAR_DUNGEON_ENEMYCAST_DESC"] =
    "在競技場框架上顯示敵人施法條。也影響傳奇鑰石隊伍意識。" -- MT
L["GEMS_CVAR_DUNGEON_LOGTIME"] = "日誌保留時間" -- MT
L["GEMS_CVAR_DUNGEON_LOGTIME_DESC"] =
    "保留戰鬥日誌項目的秒數。預設 300 秒。對於長傳奇鑰石拉怪增加至 600。" -- MT
L["GEMS_CVAR_DUNGEON_LOGFILE"] = "唯一日誌檔名" -- MT
L["GEMS_CVAR_DUNGEON_LOGFILE_DESC"] = "使用時間戳記戰鬥日誌檔名。防止覆寫先前日誌。" -- MT
L["GEMS_CVAR_DUNGEON_DIMINISH"] = "CC 遞減效應" -- MT
L["GEMS_CVAR_DUNGEON_DIMINISH_DESC"] = "在敵人框架上顯示控場遞減效應。" -- MT

-- CVar Section: Solo Play & Open World
L["GEMS_CVAR_SOLO_AUTOLOOT"] = "自動拾取" -- MT
L["GEMS_CVAR_SOLO_AUTOLOOT_DESC"] =
    "自動拾取物品。預設關閉表示需要分別點擊每個物品。幾乎每個玩家都想要此項開啟。" -- MT

L["GEMS_CVAR_SOLO_LOOTRATE"] = "拾取速度" -- MT
L["GEMS_CVAR_SOLO_LOOTRATE_DESC"] =
    "自動拾取勾選間的毫秒數。預設 150ms 感覺遲緩。50ms 幾乎瞬間拾取。" -- MT
L["GEMS_CVAR_SOLO_LOOTMOUSE"] = "在游標處拾取" -- MT
L["GEMS_CVAR_SOLO_LOOTMOUSE_DESC"] = "在滑鼠游標處開啟拾取視窗。節省滑鼠移動。" -- MT
L["GEMS_CVAR_SOLO_AELOOT"] = "AoE 拾取" -- MT
L["GEMS_CVAR_SOLO_AELOOT_DESC"] = "停用區域效應拾取。0=啟用 AoE 拾取 (一次拾取所有附近屍體)。" -- MT
L["GEMS_CVAR_SOLO_DISMOUNT"] = "自動下坐騎" -- MT
L["GEMS_CVAR_SOLO_DISMOUNT_DESC"] = "施法時自動下坐騎。" -- MT
L["GEMS_CVAR_SOLO_DISMOUNTFLY"] = "飛行中下坐騎" -- MT
L["GEMS_CVAR_SOLO_DISMOUNTFLY_DESC"] = "飛行時自動下坐騎 (您會墜落)。預設關閉合理。" -- MT
L["GEMS_CVAR_SOLO_TOT"] = "目標的目標" -- MT
L["GEMS_CVAR_SOLO_TOT_DESC"] = "顯示目標的目標框架。對坦克 (查看首領目標) 和 DPS 至關重要。" -- MT
L["GEMS_CVAR_SOLO_TCASTBAR"] = "目標施法條" -- MT
L["GEMS_CVAR_SOLO_TCASTBAR_DESC"] = "顯示您目標的施法條。對打斷至關重要。" -- MT
L["GEMS_CVAR_SOLO_QUESTWATCH"] = "自動任務追蹤" -- MT
L["GEMS_CVAR_SOLO_QUESTWATCH_DESC"] = "獲得任務時於目標追蹤器中自動追蹤。" -- MT
L["GEMS_CVAR_SOLO_QUESTPOI"] = "地圖任務興趣點" -- MT
L["GEMS_CVAR_SOLO_QUESTPOI_DESC"] = "在世界地圖上顯示任務興趣點。" -- MT
L["GEMS_CVAR_SOLO_PARTYPETS"] = "顯示隊伍寵物" -- MT
L["GEMS_CVAR_SOLO_PARTYPETS_DESC"] = "在隊伍 UI 中顯示寵物框架。預設關閉以節省螢幕空間。" -- MT
L["GEMS_CVAR_SOLO_INTERACT"] = "軟互動" -- MT
L["GEMS_CVAR_SOLO_INTERACT_DESC"] =
    "互動物件的軟目標。0=關閉,1=遊戲手把,3=永遠。對任務有重大生活品質提升。" -- MT
L["GEMS_CVAR_SOLO_INTERARC"] = "互動弧形" -- MT
L["GEMS_CVAR_SOLO_INTERARC_DESC"] =
    "互動軟目標的方向限制。0=必須直接面對,1=前方弧形,2=任何位置。" -- MT
L["GEMS_CVAR_SOLO_INTERRANGE"] = "互動範圍" -- MT
L["GEMS_CVAR_SOLO_INTERRANGE_DESC"] = "軟互動偵測的最大範圍 (碼)。10 為預設與上限。" -- MT

L["GEMS_CVAR_SOLO_INTERICON"] = "互動圖示" -- MT
L["GEMS_CVAR_SOLO_INTERICON_DESC"] = "顯示軟互動目標的圖示指示器。保持開啟以獲得視覺回饋。" -- MT
L["GEMS_CVAR_SOLO_AUTOINTER"] = "自動移動至互動" -- MT
L["GEMS_CVAR_SOLO_AUTOINTER_DESC"] = "自動移動至互動目標。在戰鬥區域可能令人迷失方向。" -- MT
L["GEMS_CVAR_SOLO_QUESTITEMS"] = "任務物品互動" -- MT
L["GEMS_CVAR_SOLO_QUESTITEMS_DESC"] =
    "允許將任務物品作為互動使用。讓您直接從軟互動鍵使用任務物品。" -- MT
L["GEMS_CVAR_SOLO_QUESTITEMS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_SOLO_QUESTITEMS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_SOLO_QUESTITEMS_DESCLONG"] =
    "Enables quest items to participate in soft-target interaction. Recommended on (1) -- quest items become eligible for soft-target highlighting and interaction alongside NPCs and objects, which matches how the rest of the modern open-world interaction system works. Off (0) excludes quest items from the soft-target system; you click them manually like in older expansions." -- MT

-- CVar Section: UI & Quality of Life
L["GEMS_CVAR_UI_TUTORIALS"] = "教學彈出" -- MT
L["GEMS_CVAR_UI_TUTORIALS_DESC"] = "顯示教學彈出。經驗豐富的玩家應停用 -- 教學會中斷遊戲。" -- MT
L["GEMS_CVAR_UI_NPE"] = "新玩家教學" -- MT
L["GEMS_CVAR_UI_NPE_DESC"] = "顯示新玩家體驗教學。經驗豐富的玩家停用。" -- MT
L["GEMS_CVAR_UI_LOADTIPS"] = "載入畫面提示" -- MT
L["GEMS_CVAR_UI_LOADTIPS_DESC"] = "在載入畫面顯示提示。低成本,偶爾有用。" -- MT
L["GEMS_CVAR_UI_COMPARE"] = "比較物品" -- MT
L["GEMS_CVAR_UI_COMPARE_DESC"] = "懸停裝備時永遠顯示物品比較提示。" -- MT
L["GEMS_CVAR_UI_TOOLTIPS"] = "詳細提示" -- MT
L["GEMS_CVAR_UI_TOOLTIPS_DESC"] = "顯示有屬性的詳細/詳盡提示。" -- MT
L["GEMS_CVAR_UI_TRANSMOG"] = "缺失幻化來源" -- MT
L["GEMS_CVAR_UI_TRANSMOG_DESC"] = "顯示您是否缺少幻化外觀來源。收藏者的隱藏寶藏。" -- MT
L["GEMS_CVAR_UI_SSFORMAT"] = "螢幕擷取格式" -- MT
L["GEMS_CVAR_UI_SSFORMAT_DESC"] = "螢幕擷取檔案格式。TGA 為無損,JPEG 節省磁碟空間但較差。" -- MT
L["GEMS_CVAR_UI_SSQUALITY"] = "螢幕擷取品質" -- MT
L["GEMS_CVAR_UI_SSQUALITY_DESC"] = "JPEG 品質 (1-10)。預設 3 非常低。如使用 JPEG,請用 10。" -- MT
L["GEMS_CVAR_UI_ZOOM"] = "相機縮放距離" -- MT
L["GEMS_CVAR_UI_ZOOM_DESC"] = "最大相機拉遠乘數。預設 1.9 感覺很近。2.6 提供更多戰場意識。" -- MT
L["GEMS_CVAR_UI_EDGEFLASH"] = "螢幕邊緣閃爍" -- MT
L["GEMS_CVAR_UI_EDGEFLASH_DESC"] = "戰鬥中地圖開啟時螢幕邊緣的紅色閃爍。安全提醒。" -- MT
L["GEMS_CVAR_UI_BUBBLES"] = "聊天氣泡" -- MT

L["GEMS_CVAR_UI_BUBBLES_DESC"] = "顯示遊戲內語音氣泡。" -- MT
L["GEMS_CVAR_UI_BIGNUMS"] = "拆解數字" -- MT
L["GEMS_CVAR_UI_BIGNUMS_DESC"] = "在大數字中使用逗號 (1,000,000 vs 1000000)。" -- MT
L["GEMS_CVAR_UI_BUFFDUR"] = "增益持續時間" -- MT
L["GEMS_CVAR_UI_BUFFDUR_DESC"] = "在增益圖示上顯示剩餘持續時間。" -- MT
L["GEMS_CVAR_UI_COMBOPT"] = "連擊點位置" -- MT
L["GEMS_CVAR_UI_COMBOPT_DESC"] = "連擊點顯示。1=於目標框架,2=於自身 (個人資源顯示下方)。" -- MT
L["GEMS_CVAR_UI_FSTACK"] = "框架堆疊偵錯" -- MT
L["GEMS_CVAR_UI_FSTACK_DESC"] =
    "啟用框架堆疊提示 (開發者工具)。懸停時顯示框架名稱。對偵錯有用。" -- MT
L["GEMS_CVAR_UI_RAWMOUSE"] = "原始滑鼠輸入" -- MT
L["GEMS_CVAR_UI_RAWMOUSE_DESC"] = "原始滑鼠輸入模式。自 2024 修補檔損壞 -- 開啟此項無效。" -- MT
L["GEMS_CVAR_UI_TAINT"] = "汙染日誌" -- MT
L["GEMS_CVAR_UI_TAINT_DESC"] =
    "汙染偵錯日誌。0=關閉,1=記錄至檔案,2=記錄+聊天。外掛開發者設為 1 以偵錯。" -- MT
L["GEMS_CVAR_UI_BAGS"] = "合併背包" -- MT
L["GEMS_CVAR_UI_BAGS_DESC"] =
    "將所有背包顯示為一個合併庫存檢視。在 Dragonflight 新增。管理更乾淨。" -- MT
L["GEMS_CVAR_UI_ROTATEMM"] = "旋轉小地圖" -- MT
L["GEMS_CVAR_UI_ROTATEMM_DESC"] = "旋轉小地圖以匹配玩家面對方向,而非固定北上。基於偏好。" -- MT

-- CVar Section: FPS & Performance
L["GEMS_CVAR_FPS_MAXFPS"] = "最大 FPS" -- MT
L["GEMS_CVAR_FPS_MAXFPS_DESC"] = "FPS 上限。應符合您螢幕的更新率。提高浪費 GPU。" -- MT
L["GEMS_CVAR_FPS_BGFPS"] = "背景 FPS" -- MT
L["GEMS_CVAR_FPS_BGFPS_DESC"] =
    "背景 FPS 上限 (遊戲未聚焦)。30 節省電力/熱量。降至 8 以最大節省。" -- MT
L["GEMS_CVAR_FPS_LOADFPS"] = "載入畫面 FPS" -- MT
L["GEMS_CVAR_FPS_LOADFPS_DESC"] = "載入畫面 FPS 上限。低為佳 -- 載入時無遊戲。" -- MT
L["GEMS_CVAR_FPS_USEMAXFPS"] = "啟用 FPS 上限" -- MT
L["GEMS_CVAR_FPS_USEMAXFPS_DESC"] = "啟用 FPS 上限。預設關閉表示無限 FPS (浪費 GPU,造成熱量)。" -- MT

L["GEMS_CVAR_FPS_VSYNC"] = "垂直同步" -- MT
L["GEMS_CVAR_FPS_VSYNC_DESC"] =
    "防止畫面撕裂但增加輸入延遲。對競技遊玩,停用並改用 FPS 上限。" -- MT
L["GEMS_CVAR_FPS_TARGETFPS"] = "目標 FPS" -- MT
L["GEMS_CVAR_FPS_TARGETFPS_DESC"] = "動態品質縮放的目標 FPS。遊戲會自動降低設定以達成此目標。" -- MT
L["GEMS_CVAR_FPS_USETARGET"] = "使用目標 FPS" -- MT
L["GEMS_CVAR_FPS_USETARGET_DESC"] =
    "啟用目標 FPS 系統。可能造成不穩定的品質波動。偏好靜態設定。" -- MT
L["GEMS_CVAR_FPS_LATENCY"] = "GPU 框架延遲" -- MT
L["GEMS_CVAR_FPS_LATENCY_DESC"] =
    "CPU 可在 GPU 之前佇列的最大框架。預設 3 = 60fps 時 ~50ms 延遲。1 = ~16ms,值得用於巨集。" -- MT
L["GEMS_CVAR_FPS_RSCALE"] = "渲染縮放" -- MT
L["GEMS_CVAR_FPS_RSCALE_DESC"] =
    "渲染解析度乘數。1.0 = 原生。低於 1.0 = 模糊但較快。高於 1.0 = 超取樣。" -- MT
L["GEMS_CVAR_FPS_DYNSCALE"] = "動態渲染縮放" -- MT
L["GEMS_CVAR_FPS_DYNSCALE_DESC"] =
    "GPU 受限時自動降低渲染縮放。Beta 功能 -- 可能造成卡頓。除非需要否則保持關閉。" -- MT
L["GEMS_CVAR_FPS_LOWLAT"] = "低延遲模式" -- MT
L["GEMS_CVAR_FPS_LOWLAT_DESC"] =
    "低延遲渲染。0=無,2=Reflex (NVIDIA),4=XeLL (Intel)。AMD 使用者保持為 0。" -- MT
L["GEMS_CVAR_FPS_MULTITHREAD"] = "多執行緒渲染" -- MT
L["GEMS_CVAR_FPS_MULTITHREAD_DESC"] = "多執行緒渲染。停用會顯著降低幀率。永遠不要設為 0。" -- MT
L["GEMS_CVAR_FPS_SPELLCLUTTER"] = "法術視覺密度" -- MT
L["GEMS_CVAR_FPS_SPELLCLUTTER_DESC"] = "全域法術視覺密度。1=僅必要,4=全部。較低 = 最大 FPS 增益。" -- MT
L["GEMS_CVAR_FPS_PARTICLES"] = "粒子密度" -- MT
L["GEMS_CVAR_FPS_PARTICLES_DESC"] =
    "Particle effect detail. Lower tiers cut GPU load in particle-heavy fights; Disabled turns particles off entirely (and hides some combat cues)." -- MT
L["GEMS_CVAR_FPS_WEATHER"] = "天氣密度" -- MT
L["GEMS_CVAR_FPS_WEATHER_DESC"] = "天氣效果密度。降低會移除雨/雪粒子。" -- MT

L["GEMS_CVAR_FPS_ANIMLOD"] = "動畫畫格略過" -- MT
L["GEMS_CVAR_FPS_ANIMLOD_DESC"] = "略過遠距離角色的動畫畫格。節省 CPU 而無可見影響。" -- MT
L["GEMS_CVAR_FPS_VFXDENSITY"] = "VFX 密度篩選" -- MT
L["GEMS_CVAR_FPS_VFXDENSITY_DESC"] =
    "替代法術視覺密度控制。與 spellClutter 一起作為第二階段篩選。" -- MT
L["GEMS_CVAR_FPS_USEMAXFPS_OPT_0"] = "Off (default)" -- MT
L["GEMS_CVAR_FPS_USEMAXFPS_OPT_1"] = "On (recommended)" -- MT
L["GEMS_CVAR_FPS_USEMAXFPS_DESCLONG"] =
    "Master switch for the FPS limit. EMS recommends 1 because uncapped frames can spike to 300+ in light scenes (e.g. open-world solo play), spinning your GPU up to high power draw for no visible benefit on a 60-144Hz monitor. Setting a cap reduces fan noise, lowers GPU temperature, and prevents the framerate-cliff sensation when you enter dense content. Pair this with maxFPS at your monitor refresh rate. Set to 0 if you specifically want uncapped frames for input-latency reasons (high-refresh competitive PvP). This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_FPS_VSYNC_OPT_0"] = "Off (recommended)" -- MT
L["GEMS_CVAR_FPS_VSYNC_OPT_1"] = "On (default)" -- MT
L["GEMS_CVAR_FPS_VSYNC_DESCLONG"] =
    "Vertical sync, synchronising frame output to your monitor refresh rate. EMS recommends 0 because vsync adds input latency (typically one full frame, 8-16ms on a 60-120Hz monitor) which is noticeable during reactive play -- interrupt windows feel mushier and dragonriding inputs feel delayed. Modern high-refresh-rate monitors generally handle tearing well without vsync. Set to 1 only if you see visible tearing artefacts that bother you and your monitor lacks G-Sync or FreeSync support. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_FPS_USETARGET_OPT_0"] = "Off (recommended)" -- MT
L["GEMS_CVAR_FPS_USETARGET_OPT_1"] = "On (default)" -- MT
L["GEMS_CVAR_FPS_USETARGET_DESCLONG"] =
    "Enables the dynamic-FPS-adjustment system: WoW lowers render scale, particle density, and other quality settings on the fly when actual FPS drops below targetFPS. EMS recommends 0 because the dynamic adjustments cause visible quality shifts mid-fight (textures pop, shadows fade in and out) which is more distracting than a stable lower framerate. Set quality manually to a level your hardware sustains and accept the framerate that produces. Set to 1 if you specifically prefer the dynamic-quality tradeoff. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_FPS_DYNSCALE_OPT_0"] = "Off (default, recommended)" -- MT
L["GEMS_CVAR_FPS_DYNSCALE_OPT_1"] = "On" -- MT
L["GEMS_CVAR_FPS_DYNSCALE_DESCLONG"] =
    "Lowers render scale dynamically if GPU-bound to hit targetFPS. EMS recommends 0 (match-default) because Blizzard marks this as BETA with known issues (May cause hitching. May behave poorly with vsync on). The trade-off is visible: text and UI go subtly blurry when DynamicRenderScale kicks in, which is more distracting than a stable lower framerate. Set to 1 only if you specifically want dynamic GPU-bound adjustment. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_FPS_MULTITHREAD_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_FPS_MULTITHREAD_OPT_1"] = "On (default, recommended)" -- MT
L["GEMS_CVAR_FPS_MULTITHREAD_DESCLONG"] =
    "Multi-threaded command list compatibility mode. Default 1 is correct -- disabling this significantly reduces framerate per Blizzard's own description, particularly on multi-core CPUs (which is every modern system). Only set to 0 if you experience specific multi-threaded rendering bugs that disabling solves; this is rare. Critical setting -- changes take effect on the next graphics reset (logout + login, or /console gxRestart). This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_FPS_ANIMLOD_OPT_0"] = "Off (default)" -- MT
L["GEMS_CVAR_FPS_ANIMLOD_OPT_1"] = "On (recommended)" -- MT
L["GEMS_CVAR_FPS_ANIMLOD_DESCLONG"] =
    "Skips animation frames for distant units to save CPU. EMS recommends 1 because crowded scenes (raid, capital city, mass PvP) can have dozens of off-screen or far-away animated units whose animation updates burn CPU cycles you do not see. Frame-skipping at distance is visually imperceptible at 30+ yards (the units are too small to notice their reduced anim cadence) and frees CPU for the units that matter (the boss, your party, the unit you target). Set to 0 if you want full animation fidelity at all distances. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_FPS_LATENCY_OPT_1"] = "1 (recommended, lowest input lag)" -- MT
L["GEMS_CVAR_FPS_LATENCY_OPT_2"] = "2 (balanced)" -- MT
L["GEMS_CVAR_FPS_LATENCY_OPT_3"] = "3 (default, smoothest frame pacing)" -- MT
L["GEMS_CVAR_FPS_LATENCY_DESCLONG"] =
    "Maximum number of frames the CPU can render ahead of the GPU (input-to-display pipeline depth). EMS recommends 1 because the Blizzard default 3 adds substantial input latency (each queued frame is one frame of delay between keypress and on-screen action). Setting to 1 cuts the pipeline to the minimum, reducing input lag noticeably for reactive play (interrupt windows, dodge mechanics, dragonriding). Trade-off: on a CPU-bottlenecked system, lower values can cause minor frame pacing inconsistency. Increase to 2 or 3 if you see hitching. Critical setting -- changes take effect on the next graphics reset (logout + login, or /console gxRestart). This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_FPS_WEATHER_OPT_0"] = "0 (off)" -- MT
L["GEMS_CVAR_FPS_WEATHER_OPT_1"] = "1 (light, recommended)" -- MT
L["GEMS_CVAR_FPS_WEATHER_OPT_2"] = "2 (full, default)" -- MT
L["GEMS_CVAR_FPS_WEATHER_DESCLONG"] =
    "Density of weather particle effects (rain, snow, sandstorm). EMS recommends 1 because the Blizzard default 2 (full) renders thousands of weather particles in outdoor zones -- the FPS cost runs 10-20% in dense storms with little gameplay benefit. Setting to 1 (light) keeps the atmospheric feel but cuts the particle count to a level that does not tank framerate during outdoor combat. Set to 0 if you want zero weather rendering (max FPS in storms). This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_FPS_VFXDENSITY_OPT_1"] = "1 (minimum, recommended)" -- MT
L["GEMS_CVAR_FPS_VFXDENSITY_OPT_2"] = "2 (reduced)" -- MT
L["GEMS_CVAR_FPS_VFXDENSITY_OPT_3"] = "3 (performance)" -- MT
L["GEMS_CVAR_FPS_VFXDENSITY_OPT_4"] = "4 (full, default)" -- MT
L["GEMS_CVAR_FPS_VFXDENSITY_DESCLONG"] =
    "Filters out overlapping spell visuals (SVKs) in dense scenes. EMS recommends 1 (minimum) because the Blizzard default 4 (full) renders every spell visual in raid scenes which causes catastrophic FPS drops in 20+ player encounters with multiple AoE effects (think Mythic raid bosses with overlapping ground effects). Minimum mode drops less-important visuals first while keeping your own spell cues clear. Increase to 2 (reduced) or 3 (performance) only if you have headroom; the FPS difference between settings is dramatic in dense raid content. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_FPS_BGFPS_OPT_8"] = "8 (minimum)" -- MT
L["GEMS_CVAR_FPS_BGFPS_OPT_30"] = "30 (default, recommended)" -- MT
L["GEMS_CVAR_FPS_BGFPS_OPT_60"] = "60 (smooth)" -- MT
L["GEMS_CVAR_FPS_BGFPS_OPT_120"] = "120 (high)" -- MT
L["GEMS_CVAR_FPS_BGFPS_OPT_240"] = "240 (very high)" -- MT
L["GEMS_CVAR_FPS_BGFPS_DESCLONG"] =
    "Background FPS limit -- the cap applied when WoW is not the focused window (Alt-Tab to browser, Discord). Default 30 is correct because backgrounded WoW still consumes some CPU/GPU and capping it at 30 lets the focused application (your browser, Discord) have full performance headroom. Lower to 8 (minimum) if you want WoW to use almost no resources when backgrounded. Raise to 60+ if you stream WoW from a backgrounded source. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_FPS_LOADFPS_OPT_5"] = "5 (very low)" -- MT
L["GEMS_CVAR_FPS_LOADFPS_OPT_10"] = "10 (default, recommended)" -- MT
L["GEMS_CVAR_FPS_LOADFPS_OPT_30"] = "30 (low)" -- MT
L["GEMS_CVAR_FPS_LOADFPS_OPT_60"] = "60 (mid)" -- MT
L["GEMS_CVAR_FPS_LOADFPS_OPT_120"] = "120 (high)" -- MT
L["GEMS_CVAR_FPS_LOADFPS_DESCLONG"] =
    "FPS cap during loading screens. Default 10 is correct because loading screens are static visuals; rendering them at 200 FPS only loads the GPU for no benefit. Lower to 5 if you want the absolute minimum power draw during loads. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_FPS_TARGETFPS_OPT_30"] = "30 (low)" -- MT
L["GEMS_CVAR_FPS_TARGETFPS_OPT_45"] = "45 (mid-low)" -- MT
L["GEMS_CVAR_FPS_TARGETFPS_OPT_60"] = "60 (default, recommended)" -- MT
L["GEMS_CVAR_FPS_TARGETFPS_OPT_90"] = "90 (high)" -- MT
L["GEMS_CVAR_FPS_TARGETFPS_OPT_120"] = "120 (very high)" -- MT
L["GEMS_CVAR_FPS_TARGETFPS_DESCLONG"] =
    "Target FPS for the dynamic adjustment system (only used when useTargetFPS is On). Default 60 is the standard target for stable play on a 60Hz monitor. Set to your monitor refresh rate if higher (120 for 120Hz, 144 for 144Hz). Lower targets accept worse quality to maintain framerate; higher targets reduce quality more aggressively. This setting only matters when useTargetFPS is enabled. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_FPS_LOWLAT_OPT_0"] = "0 None (default, safe)" -- MT
L["GEMS_CVAR_FPS_LOWLAT_OPT_1"] = "1 BuiltIn (works on any GPU)" -- MT
L["GEMS_CVAR_FPS_LOWLAT_OPT_2"] = "2 Reflex (NVIDIA RTX only)" -- MT
L["GEMS_CVAR_FPS_LOWLAT_OPT_3"] = "3 Reflex+Boost (NVIDIA RTX only)" -- MT
L["GEMS_CVAR_FPS_LOWLAT_OPT_4"] = "4 XeLL (Intel Arc only)" -- MT
L["GEMS_CVAR_FPS_LOWLAT_DESCLONG"] =
    "Hardware-specific frame latency reduction. Default 0 (None) is universally safe. Options: 0=None (no vendor-specific path); 1=BuiltIn (Blizzard's generic latency reduction, works on any GPU); 2=Reflex (NVIDIA Reflex, requires RTX GPU and updated NVIDIA driver); 3=Reflex+Boost (NVIDIA Reflex with Boost, RTX GPU only); 4=XeLL (Intel Xe Low Latency, requires Intel Arc GPU and updated Intel driver). Pick the option matching your hardware: NVIDIA RTX owners use 2 or 3, Intel Arc owners use 4, all others use 1 (BuiltIn) for moderate gains or 0 (safe default). Note: setting an unsupported mode (e.g. Reflex on an AMD GPU) is harmless -- the driver simply ignores the request. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_FPS_SPELLCLUTTER_OPT_0"] = "0 (none, dev-only)" -- MT
L["GEMS_CVAR_FPS_SPELLCLUTTER_OPT_1"] = "1 (minimum, recommended)" -- MT
L["GEMS_CVAR_FPS_SPELLCLUTTER_OPT_2"] = "2 (reduced)" -- MT
L["GEMS_CVAR_FPS_SPELLCLUTTER_OPT_3"] = "3 (performance)" -- MT
L["GEMS_CVAR_FPS_SPELLCLUTTER_OPT_4"] = "4 (full, default)" -- MT
L["GEMS_CVAR_FPS_SPELLCLUTTER_DESCLONG"] =
    "Legacy Spell Density CVar paired with spellVisualDensityFilterSetting (same 0-4 enum where 0=none dev-only, 1=minimum, 2=reduced, 3=performance, 4=full). EMS recommends 1 for the same reason as spellVisualDensityFilterSetting: at 4 (full) raid scenes can drop FPS by 50%+ during overlapping AoE effects. Keep both cvars at 1 for consistent spell-density behaviour. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_FPS_RSCALE_OPT_75"] = "0.75 (undersample, blurry, FPS gain)" -- MT
L["GEMS_CVAR_FPS_RSCALE_OPT_90"] = "0.9 (light undersample)" -- MT
L["GEMS_CVAR_FPS_RSCALE_OPT_100"] = "1.0 (native, default, recommended)" -- MT
L["GEMS_CVAR_FPS_RSCALE_OPT_125"] = "1.25 (light supersample)" -- MT
L["GEMS_CVAR_FPS_RSCALE_OPT_150"] = "1.5 (supersample, sharper, GPU cost)" -- MT
L["GEMS_CVAR_FPS_RSCALE_DESCLONG"] =
    "Render scale: 1.0 is native resolution, values above 1.0 supersample (render at higher resolution then downscale, sharper image, more GPU cost), values below 1.0 undersample (render at lower resolution, blurrier, less GPU cost). Default 1.0 is correct for almost every player. Set to 1.25 or 1.5 only if you have substantial GPU headroom and want sharper visuals at 1080p/1440p. Set to 0.9 or 0.75 if you need FPS gains and can accept a softer image. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT

-- CVar Section: Visual Quality
L["GEMS_CVAR_VISUAL_QUALITY"] = "圖形品質" -- MT
L["GEMS_CVAR_VISUAL_QUALITY_DESC"] = "主要圖形品質預設 (1-10)。一次變更所有子設定。" -- MT
L["GEMS_CVAR_VISUAL_SHADOWS"] = "陰影品質" -- MT
L["GEMS_CVAR_VISUAL_SHADOWS_DESC"] =
    "Shadow quality (0-5). Shadows are GPU-expensive; lowering to Low or Fair gives significant FPS gains." -- MT
L["GEMS_CVAR_VISUAL_SSAO"] = "環境光遮蔽" -- MT
L["GEMS_CVAR_VISUAL_SSAO_DESC"] =
    "螢幕空間環境光遮蔽品質。為陰影增添深度。0=關閉 (最快),4=最高。" -- MT
L["GEMS_CVAR_VISUAL_VIEWDIST"] = "視野距離" -- MT
L["GEMS_CVAR_VISUAL_VIEWDIST_DESC"] =
    "視野距離 (1-10)。降至 5 在副本內容中節省 GPU 而無視覺影響。" -- MT
L["GEMS_CVAR_VISUAL_GROUND"] = "地面雜亂" -- MT
L["GEMS_CVAR_VISUAL_GROUND_DESC"] =
    "草地/地面細節密度 (1-10)。純粹外觀 -- 降低無遊戲影響並節省 FPS。" -- MT
L["GEMS_CVAR_VISUAL_TEXRES"] = "材質解析度" -- MT
L["GEMS_CVAR_VISUAL_TEXRES_DESC"] = "材質解析度品質 (1-3)。影響 VRAM 使用。VRAM 受限時降低。" -- MT
L["GEMS_CVAR_VISUAL_LIQUID"] = "水質量" -- MT
L["GEMS_CVAR_VISUAL_LIQUID_DESC"] = "水渲染品質。較低 = 較少反射水,水附近 FPS 較佳。" -- MT
L["GEMS_CVAR_VISUAL_PROJTEX"] = "投影材質" -- MT
L["GEMS_CVAR_VISUAL_PROJTEX_DESC"] =
    "法術地面效果 (Healing Rain、Consecration)。必須開啟 -- 沒有此項首領機制不可見。" -- MT
L["GEMS_CVAR_VISUAL_OUTLINE"] = "輪廓模式" -- MT
L["GEMS_CVAR_VISUAL_OUTLINE_DESC"] = "角色/NPC 輪廓模式。0=無,1=細,2=正常。幫助可見性。" -- MT

L["GEMS_CVAR_VISUAL_AA"] = "反鋸齒" -- MT
L["GEMS_CVAR_VISUAL_AA_DESC"] =
    "反鋸齒模式。0=無,1=FXAA 低,2=FXAA 高,3=CMAA。CMAA 為最佳品質成本比。" -- MT
L["GEMS_CVAR_VISUAL_GLOW"] = "發光效果" -- MT
L["GEMS_CVAR_VISUAL_GLOW_DESC"] = "全螢幕發光效果。微妙但增添氣氛。" -- MT
L["GEMS_CVAR_VISUAL_DEATH"] = "死亡效果" -- MT
L["GEMS_CVAR_VISUAL_DEATH_DESC"] = "死亡去飽和效果。死亡時為灰階。" -- MT
L["GEMS_CVAR_VISUAL_SHARPEN"] = "銳利化通道" -- MT
L["GEMS_CVAR_VISUAL_SHARPEN_DESC"] =
    "即使無 FSR 升頻也啟用銳利化。讓原生解析度的圖像更銳利。標準圖形選單未公開。" -- MT
L["GEMS_CVAR_VISUAL_SHARPNESS"] = "銳利化強度" -- MT
L["GEMS_CVAR_VISUAL_SHARPNESS_DESC"] =
    "銳利化強度 (0.0-2.0)。僅在啟用銳利化或 FSR 開啟時才有作用。" -- MT
L["GEMS_CVAR_VISUAL_FARCLIP"] = "遠裁切平面" -- MT
L["GEMS_CVAR_VISUAL_FARCLIP_DESC"] =
    "世界單位中的最大渲染距離。較低 = 較少遠處幾何 = 較佳 FPS。800 已足夠。" -- MT
L["GEMS_CVAR_VISUAL_PROJTEX_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_VISUAL_PROJTEX_OPT_1"] = "On (default, recommended)" -- MT
L["GEMS_CVAR_VISUAL_PROJTEX_DESCLONG"] =
    "Projected textures for ground-effect indicators (AoE markers, void zones, fire patches, healing circles). Default 1 is correct because turning this off removes the visible ground indicators for raid mechanics -- you cannot see where the swirly is. Critical setting -- changes take effect on the next graphics reset (logout + login, or /console gxRestart). Set to 0 only if you have a specific GPU-bottleneck issue and use a third-party addon that draws its own AoE markers. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_VISUAL_GLOW_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_VISUAL_GLOW_OPT_1"] = "On (default, recommended)" -- MT
L["GEMS_CVAR_VISUAL_GLOW_DESCLONG"] =
    "Full-screen glow effect -- the soft bloom on bright surfaces (light sources, magic spells, sun glare). Default 1 is correct because bloom is a small visual flourish with negligible FPS cost on modern hardware. Set to 0 if you find bloom distracting in dark zones or if you specifically prefer a flatter visual style. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_VISUAL_DEATH_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_VISUAL_DEATH_OPT_1"] = "On (default, recommended)" -- MT
L["GEMS_CVAR_VISUAL_DEATH_DESCLONG"] =
    "Full-screen death desaturation effect -- the grey-out filter applied when your character dies. Default 1 is correct because the desat is a useful visual cue confirming your death state (vs a screen freeze or disconnect). Set to 0 if you find the grey-out disorienting during PvP corpse runs. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_VISUAL_SHARPEN_OPT_0"] = "Off (default)" -- MT
L["GEMS_CVAR_VISUAL_SHARPEN_OPT_1"] = "On (recommended)" -- MT
L["GEMS_CVAR_VISUAL_SHARPEN_DESCLONG"] =
    "Forces the sharpness pass to run even when AMD FSR upscaling is disabled. EMS recommends 1 because the default 0 means sharpening only applies during FSR upscaling, which most players are not using -- the result is a soft, slightly washed-out image at native resolution. Setting to 1 enables the sharpness pass regardless, giving you crisper text and UI at all resolutions. ResampleSharpness controls the strength (see below). Set to 0 if you prefer the softer default look. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_VISUAL_OUTLINE_OPT_0"] = "0 (None)" -- MT
L["GEMS_CVAR_VISUAL_OUTLINE_OPT_1"] = "1 (Some)" -- MT
L["GEMS_CVAR_VISUAL_OUTLINE_OPT_2"] = "2 (All, default, recommended)" -- MT
L["GEMS_CVAR_VISUAL_OUTLINE_DESCLONG"] =
    "Character outline rendering: 0=None, 1=Some (allies and selected enemies), 2=All (every character has an outline). Default 2 is correct because outlines help you visually parse character positions in dense scenes (raid stacking, crowded PvP). Set to 0 if you prefer a flatter look or use a third-party UI that handles unit visibility differently. Set to 1 for a middle ground. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_VISUAL_SSAO_OPT_0"] = "0 (Low)" -- MT
L["GEMS_CVAR_VISUAL_SSAO_OPT_1"] = "1 (Fair)" -- MT
L["GEMS_CVAR_VISUAL_SSAO_OPT_2"] = "2 (High)" -- MT
L["GEMS_CVAR_VISUAL_SSAO_OPT_3"] = "3 (Ultra, default, recommended)" -- MT
L["GEMS_CVAR_VISUAL_SSAO_DESCLONG"] =
    "Screen-space ambient occlusion -- the soft contact shadow where objects meet surfaces. Blizzard's tiers run Disabled, Low, Medium, High, Ultra. High (the default) is a sensible stop: SSAO is a cheap way to keep characters looking grounded instead of floating above the terrain, and the frame cost from Disabled up to High is small on modern GPUs. Go to Ultra for the cleanest contact shadows, or drop it only if you need every frame for competitive play. This setting resets each session and does not persist across logouts; EMS re-applies your choice on every login." -- MT
L["GEMS_CVAR_VISUAL_LIQUID_OPT_0"] = "0 (Low)" -- MT
L["GEMS_CVAR_VISUAL_LIQUID_OPT_1"] = "1 (Fair, recommended)" -- MT
L["GEMS_CVAR_VISUAL_LIQUID_OPT_2"] = "2 (High, default)" -- MT
L["GEMS_CVAR_VISUAL_LIQUID_OPT_3"] = "3 (Ultra)" -- MT
L["GEMS_CVAR_VISUAL_LIQUID_DESCLONG"] =
    "Water and lava surface rendering: 0=Low (flat coloured surface), 1=Fair (basic ripples), 2=High (reflections, refraction), 3=Ultra (caustics, volumetric depth). EMS recommends 1 because the Blizzard default 2 renders full reflections on every water surface which costs noticeable FPS in zones with large water areas (Suramar, Nazjatar, Azshara, the Plunderstorm coastline). Setting to 1 keeps the surface looking like water without the expensive reflection pass. Set to 2 or 3 if you specifically enjoy water visuals and have GPU headroom. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_VISUAL_VIEWDIST_OPT_1"] = "1 (very low)" -- MT
L["GEMS_CVAR_VISUAL_VIEWDIST_OPT_3"] = "3 (low)" -- MT
L["GEMS_CVAR_VISUAL_VIEWDIST_OPT_5"] = "5 (recommended)" -- MT
L["GEMS_CVAR_VISUAL_VIEWDIST_OPT_7"] = "7 (high)" -- MT
L["GEMS_CVAR_VISUAL_VIEWDIST_OPT_10"] = "10 (ultra)" -- MT
L["GEMS_CVAR_VISUAL_VIEWDIST_DESCLONG"] =
    "How far the engine renders distant terrain, buildings, and props on Blizzard's 1-10 scale. EMS recommends 5 because the Blizzard default 6 renders enough distance that outdoor zones with many distant objects (Boralus, Valdrakken, Dornogal skyline) cost FPS for environment your camera barely catches. Setting to 5 keeps the playable horizon visible but trims the far-distance prop count. Set to 7 or higher if you specifically want maximum draw distance for screenshots or extended Skyriding flight planning. Set to 1-3 only if you need aggressive FPS gains. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_VISUAL_GROUND_OPT_1"] = "1 (very low)" -- MT
L["GEMS_CVAR_VISUAL_GROUND_OPT_3"] = "3 (recommended)" -- MT
L["GEMS_CVAR_VISUAL_GROUND_OPT_5"] = "5 (mid)" -- MT
L["GEMS_CVAR_VISUAL_GROUND_OPT_7"] = "7 (high)" -- MT
L["GEMS_CVAR_VISUAL_GROUND_OPT_10"] = "10 (ultra)" -- MT
L["GEMS_CVAR_VISUAL_GROUND_DESCLONG"] =
    "Density of small ground objects: grass, pebbles, leaves, flowers, debris. EMS recommends 3 because the Blizzard default 6 fills outdoor zones with thousands of grass and flower tiles that cost FPS without contributing to gameplay -- you cannot interact with them, they do not hide units, and at typical camera angles you mostly see the top surface. Setting to 3 keeps the ground looking varied without the high-density particle cost. Set to 5+ if you specifically enjoy the dense vegetation look in outdoor zones. Set to 1 for maximum FPS in dense outdoor content. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_VISUAL_AA_OPT_0"] = "0 (Disabled, default)" -- MT
L["GEMS_CVAR_VISUAL_AA_OPT_1"] = "1 (FXAA Low)" -- MT
L["GEMS_CVAR_VISUAL_AA_OPT_2"] = "2 (FXAA High)" -- MT
L["GEMS_CVAR_VISUAL_AA_OPT_3"] = "3 (CMAA, recommended)" -- MT
L["GEMS_CVAR_VISUAL_AA_OPT_4"] = "4 (CMAA2, sharpest)" -- MT
L["GEMS_CVAR_VISUAL_AA_DESCLONG"] =
    "Post-process anti-aliasing technique. EMS recommends 3 (CMAA) because the Blizzard default 0 leaves pixel edges jagged at every resolution, while CMAA gives clean edges with no temporal smearing and very low FPS cost on modern hardware. Options: 0=Disabled, 1=FXAA Low (blurry, cheap), 2=FXAA High (less blurry, slightly more expensive), 3=CMAA (sharp, well-balanced), 4=CMAA2 (sharpest, slightly more expensive than CMAA). Pick CMAA2 if you have GPU headroom and want the cleanest edges, FXAA Low if you need maximum FPS, or Disabled if you specifically prefer pixel-perfect rendering. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_VISUAL_FARCLIP_OPT_500"] = "500 yds (low)" -- MT
L["GEMS_CVAR_VISUAL_FARCLIP_OPT_800"] = "800 yds (recommended)" -- MT
L["GEMS_CVAR_VISUAL_FARCLIP_OPT_1000"] = "1000 yds (default)" -- MT
L["GEMS_CVAR_VISUAL_FARCLIP_OPT_1500"] = "1500 yds (high)" -- MT
L["GEMS_CVAR_VISUAL_FARCLIP_OPT_2500"] = "2500 yds (max)" -- MT
L["GEMS_CVAR_VISUAL_FARCLIP_DESCLONG"] =
    "Maximum render distance in yards for the world far-clipping plane. EMS recommends 800 because the Blizzard default 1000 renders an extra 200 yards of distant terrain and props you rarely visually engage with -- the FPS cost is real in outdoor zones with long sightlines (Suramar overlooks, Plunderstorm coast, Skyriding mid-altitude). Setting to 800 trims the horizon to the practical play distance. Set to 1500 or 2500 if you take landscape screenshots or want maximum visibility for long-range Skyriding flight planning. Set to 500 only if you need aggressive FPS gains in outdoor content. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_VISUAL_QUALITY_OPT_1"] = "1 (Low)" -- MT
L["GEMS_CVAR_VISUAL_QUALITY_OPT_3"] = "3 (Fair)" -- MT
L["GEMS_CVAR_VISUAL_QUALITY_OPT_6"] = "6 (Good, default, recommended)" -- MT
L["GEMS_CVAR_VISUAL_QUALITY_OPT_8"] = "8 (High)" -- MT
L["GEMS_CVAR_VISUAL_QUALITY_OPT_10"] = "10 (Ultra)" -- MT
L["GEMS_CVAR_VISUAL_QUALITY_DESCLONG"] =
    "Master video-quality slider on Blizzard's 1-10 preset scale (1=Low, 3=Fair, 6=Good (default), 8=High, 10=Ultra). Default 6 (Good) is correct for balanced play on modern hardware. WARNING: changing this value cascades to all other graphics CVars (shadowQuality, viewDistance, groundClutter, liquidDetail, textureResolution, SSAO, projectedTextures, outlineMode, AA, glow, death, sharpen, sharpness, farclip) -- the preset rewrites every per-cvar tuning you made in the panel above. If you have tuned individual graphics cvars in EMS to specific values, picking a different preset here will OVERWRITE those tunings to the preset's defaults. Recommended workflow: leave this at 6 (Good) and tune individual cvars above for fine-grained control. Pick a different preset only if you want to reset all graphics cvars to Blizzard's preset values. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_VISUAL_SHARPNESS_OPT_NEG_100"] = "-1.0 (disabled)" -- MT
L["GEMS_CVAR_VISUAL_SHARPNESS_OPT_0"] = "0.0 (full strength)" -- MT
L["GEMS_CVAR_VISUAL_SHARPNESS_OPT_20"] = "0.2 (default, recommended)" -- MT
L["GEMS_CVAR_VISUAL_SHARPNESS_OPT_50"] = "0.5 (mild)" -- MT
L["GEMS_CVAR_VISUAL_SHARPNESS_OPT_100"] = "1.0 (soft)" -- MT
L["GEMS_CVAR_VISUAL_SHARPNESS_DESCLONG"] =
    "FSR upscaling sharpness strength on a 0.0-2.0 scale where 0.0 is full strength, 2.0 is minimum, and -1 disables. Default 0.2 is correct -- slightly off full strength to avoid over-sharpening text artefacts. Pairs with ResampleAlwaysSharpen above (which controls whether sharpening runs at all). Set to 0.0 for maximum sharpening (slightly more aliasing artefacts on text). Set to 0.5 or 1.0 for a softer look. Set to -1 to fully disable the sharpness pass regardless of ResampleAlwaysSharpen. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT

-- CVar Section: Sound
L["GEMS_CVAR_SOUND_MASTER"] = "主聲音切換" -- MT
L["GEMS_CVAR_SOUND_MASTER_DESC"] = "主聲音切換。任何音訊都必須開啟。" -- MT
L["GEMS_CVAR_SOUND_MASTERVOL"] = "主音量" -- MT
L["GEMS_CVAR_SOUND_MASTERVOL_DESC"] =
    "主音量 (0.0-1.0)。0.8 為與 WoW 一同使用 Discord/Spotify 提供餘裕。" -- MT
L["GEMS_CVAR_SOUND_SFX"] = "音效音量" -- MT
L["GEMS_CVAR_SOUND_SFX_DESC"] = "音效音量。保持 1.0 以獲得戰鬥音訊提示。" -- MT
L["GEMS_CVAR_SOUND_MUSIC"] = "音樂音量" -- MT
L["GEMS_CVAR_SOUND_MUSIC_DESC"] = "音樂音量。團隊副本/地下城時降低以聽到首領能力音訊提示。" -- MT
L["GEMS_CVAR_SOUND_AMBIENCE"] = "環境音音量" -- MT
L["GEMS_CVAR_SOUND_AMBIENCE_DESC"] =
    "環境音量。團隊副本中降低 -- 環境噪音可能掩蓋重要戰鬥音訊。" -- MT
L["GEMS_CVAR_SOUND_DIALOG"] = "對話音量" -- MT
L["GEMS_CVAR_SOUND_DIALOG_DESC"] = "語音/對話音量 (首領 VO、任務旁白)。" -- MT

L["GEMS_CVAR_SOUND_BGAUDIO"] = "背景音訊" -- MT
L["GEMS_CVAR_SOUND_BGAUDIO_DESC"] =
    "WoW 在背景時播放聲音。對 Alt-Tab 時的隊伍彈出和準備檢查很重要。" -- MT
L["GEMS_CVAR_SOUND_ENCWARN"] = "遭遇警告聲音" -- MT
L["GEMS_CVAR_SOUND_ENCWARN_DESC"] = "為遭遇/首領警告播放聲音。" -- MT
L["GEMS_CVAR_SOUND_ENCVOL"] = "遭遇警告音量" -- MT
L["GEMS_CVAR_SOUND_ENCVOL_DESC"] = "遭遇警告聲音的音量 (0.0-1.0)。" -- MT
L["GEMS_CVAR_SOUND_ERRSPEECH"] = "錯誤語音" -- MT
L["GEMS_CVAR_SOUND_ERRSPEECH_DESC"] =
    "錯誤語音 (法力不足等)。停用 -- 巨集序列遇到冷卻會快速觸發。" -- MT
L["GEMS_CVAR_SOUND_GAMEPLAY"] = "遊戲音效" -- MT
L["GEMS_CVAR_SOUND_GAMEPLAY_DESC"] = "啟用遊戲音效 (戰鬥、能力、NPC)。" -- MT
L["GEMS_CVAR_SOUND_MASTER_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_SOUND_MASTER_OPT_1"] = "On (default, recommended)" -- MT
L["GEMS_CVAR_SOUND_MASTER_DESCLONG"] =
    "Master switch for all WoW audio output. On is the default and the right answer for almost every player. Turn Off if you want to play silent (during a stream where you have separate music, or to switch to Discord-only voice). Note: when Off, in-game UI ping sounds disappear too, including ready check and trade requests. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_SOUND_MASTERVOL_OPT_50"] = "0.5 (quiet)" -- MT
L["GEMS_CVAR_SOUND_MASTERVOL_OPT_70"] = "0.7 (lower)" -- MT
L["GEMS_CVAR_SOUND_MASTERVOL_OPT_80"] = "0.8 (recommended)" -- MT
L["GEMS_CVAR_SOUND_MASTERVOL_OPT_90"] = "0.9 (loud)" -- MT
L["GEMS_CVAR_SOUND_MASTERVOL_OPT_100"] = "1.0 (default, max)" -- MT
L["GEMS_CVAR_SOUND_MASTERVOL_DESCLONG"] =
    "Overall game volume across every audio channel. EMS recommends 0.8 because at 1.0 the game audio sits at the same level as Discord, music apps, and OS notifications, which forces you to constantly rebalance them in Windows Volume Mixer. 0.8 gives voice chat and music headroom to sit above ambience without manual ducking on every raid pull. Lower it further if you stream and want game audio to clearly sit below your mic. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_SOUND_SFX_OPT_50"] = "0.5 (quiet)" -- MT
L["GEMS_CVAR_SOUND_SFX_OPT_70"] = "0.7 (lower)" -- MT
L["GEMS_CVAR_SOUND_SFX_OPT_85"] = "0.85 (mid)" -- MT
L["GEMS_CVAR_SOUND_SFX_OPT_95"] = "0.95 (slightly soft)" -- MT
L["GEMS_CVAR_SOUND_SFX_OPT_100"] = "1.0 (default, recommended)" -- MT
L["GEMS_CVAR_SOUND_SFX_DESCLONG"] =
    "Combat sound effects channel: spell impacts, weapon swings, ability cast clicks, environmental SFX. Default 1.0 is correct for almost every player because SFX carries the audio cues you need for reactive play (interrupt windows, AoE markers, channelled-cast endings). Lower only if you find combat noise fatiguing during very long sessions. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_SOUND_MUSIC_OPT_0"] = "0.0 (off)" -- MT
L["GEMS_CVAR_SOUND_MUSIC_OPT_10"] = "0.1 (very quiet)" -- MT
L["GEMS_CVAR_SOUND_MUSIC_OPT_20"] = "0.2 (recommended)" -- MT
L["GEMS_CVAR_SOUND_MUSIC_OPT_40"] = "0.4 (default)" -- MT
L["GEMS_CVAR_SOUND_MUSIC_OPT_70"] = "0.7 (loud)" -- MT
L["GEMS_CVAR_SOUND_MUSIC_DESCLONG"] =
    "Background music channel. EMS recommends 0.2 because at the Blizzard default 0.4 the soundtrack competes with combat SFX during raid mechanics -- you can miss a Sated cast bar because the zone music swell drowned the cue. 0.2 keeps the soundtrack as ambient mood without burying spell audio. Set to 0.0 if you prefer Spotify for background music. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_SOUND_AMBIENCE_OPT_0"] = "0.0 (off)" -- MT
L["GEMS_CVAR_SOUND_AMBIENCE_OPT_15"] = "0.15 (quiet)" -- MT
L["GEMS_CVAR_SOUND_AMBIENCE_OPT_30"] = "0.3 (recommended)" -- MT
L["GEMS_CVAR_SOUND_AMBIENCE_OPT_60"] = "0.6 (default)" -- MT
L["GEMS_CVAR_SOUND_AMBIENCE_OPT_100"] = "1.0 (max)" -- MT
L["GEMS_CVAR_SOUND_AMBIENCE_DESCLONG"] =
    "Zone ambience channel: waterfalls, wind, crowd noise, weather. EMS recommends 0.3 because at the Blizzard default 0.6 zone ambience often sits louder than combat audio during raid mechanics, especially in outdoor encounters with weather sound layers. 0.3 keeps the zone atmosphere readable without competing with mechanic cues. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_SOUND_DIALOG_OPT_50"] = "0.5 (quiet)" -- MT
L["GEMS_CVAR_SOUND_DIALOG_OPT_70"] = "0.7 (lower)" -- MT
L["GEMS_CVAR_SOUND_DIALOG_OPT_85"] = "0.85 (mid)" -- MT
L["GEMS_CVAR_SOUND_DIALOG_OPT_95"] = "0.95 (slightly soft)" -- MT
L["GEMS_CVAR_SOUND_DIALOG_OPT_100"] = "1.0 (default, recommended)" -- MT
L["GEMS_CVAR_SOUND_DIALOG_DESCLONG"] =
    "NPC dialogue and voice-over channel: questgiver speech, boss in-fight callouts, lore voice cues. Default 1.0 is correct because boss callouts often carry mechanic timing information you want clearly audible above music and ambience. Lower if you find quest-NPC chatter fatiguing during long levelling sessions. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_SOUND_BGAUDIO_OPT_0"] = "Off (default)" -- MT
L["GEMS_CVAR_SOUND_BGAUDIO_OPT_1"] = "On (recommended)" -- MT
L["GEMS_CVAR_SOUND_BGAUDIO_DESCLONG"] =
    "Keeps WoW audio running when the game window is in the background (Alt-Tab to browser, Discord, Spotify). EMS recommends 1 because the Blizzard default 0 silences the game the moment you tab out, which means you can miss queue pops, raid pulls, AH bid wars, and group invites while reading a guide in another window. Set to 0 if you specifically want WoW quiet when not focused (streaming with shared audio devices, sharing the room with someone working). This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_SOUND_ENCWARN_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_SOUND_ENCWARN_OPT_1"] = "On (default, recommended)" -- MT
L["GEMS_CVAR_SOUND_ENCWARN_DESCLONG"] =
    "In-game warning sounds for boss encounter callouts (the alarm tone that plays alongside a boss yell). Default 1 is correct because these sounds carry mechanic timing for fights where the visual on-screen text is easy to miss in raid chaos. Turn Off only if you use a third-party boss mod that plays its own warning audio and you want to avoid the doubled audio cue. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_SOUND_ENCVOL_OPT_50"] = "0.5 (quiet)" -- MT
L["GEMS_CVAR_SOUND_ENCVOL_OPT_70"] = "0.7 (lower)" -- MT
L["GEMS_CVAR_SOUND_ENCVOL_OPT_85"] = "0.85 (mid)" -- MT
L["GEMS_CVAR_SOUND_ENCVOL_OPT_95"] = "0.95 (slightly soft)" -- MT
L["GEMS_CVAR_SOUND_ENCVOL_OPT_100"] = "1.0 (default, recommended)" -- MT
L["GEMS_CVAR_SOUND_ENCVOL_DESCLONG"] =
    "Volume for the encounter warning sound channel above. Default 1.0 is the safe answer because boss warnings need to cut through music and combat SFX clearly. Lower only if you find the warning tone uncomfortably loud relative to the rest of the audio mix. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_SOUND_ERRSPEECH_OPT_0"] = "Off (recommended)" -- MT
L["GEMS_CVAR_SOUND_ERRSPEECH_OPT_1"] = "On (default)" -- MT
L["GEMS_CVAR_SOUND_ERRSPEECH_DESCLONG"] =
    "Spoken error voice lines from your character (the cannot-do-that-yet and not-enough-rage style audio). EMS recommends 0 because the on-screen red text already tells you the same information, the voice lines get repetitive in a long session (you hear the same six clips dozens of times), and many players find them immersion-breaking. Set to 1 if you specifically like the auditory cue distinct from reading the red text. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_SOUND_GAMEPLAY_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_SOUND_GAMEPLAY_OPT_1"] = "On (default, recommended)" -- MT
L["GEMS_CVAR_SOUND_GAMEPLAY_DESCLONG"] =
    "Gameplay-specific sound effects (separate from the SFXVolume channel) -- includes click feedback for action bar buttons and secondary UI sounds. Default 1 is correct because action bar clicks help confirm an input registered, especially during high-APM rotations. Turn Off only if you prefer fully silent action bar feedback. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT

-- CVar Section: Floating Combat Text
L["GEMS_CVAR_FCT_ENABLE"] = "浮動戰鬥文字" -- MT
L["GEMS_CVAR_FCT_ENABLE_DESC"] = "浮動戰鬥文字主開關。預設關閉!啟用以查看傷害/治療數字。" -- MT
L["GEMS_CVAR_FCT_DAMAGE"] = "傷害數字" -- MT
L["GEMS_CVAR_FCT_DAMAGE_DESC"] = "在敵對目標上顯示傷害數字。" -- MT
L["GEMS_CVAR_FCT_AUTOS"] = "自動攻擊數字" -- MT
L["GEMS_CVAR_FCT_AUTOS_DESC"] = "顯示所有自動攻擊數字 (不僅暴擊/觸發)。" -- MT
L["GEMS_CVAR_FCT_HEALING"] = "治療數字" -- MT
L["GEMS_CVAR_FCT_HEALING_DESC"] = "在目標上顯示治療數字。" -- MT
L["GEMS_CVAR_FCT_ABSSELF"] = "自身吸收" -- MT
L["GEMS_CVAR_FCT_ABSSELF_DESC"] = "顯示套用至自身的護盾/吸收量。" -- MT
L["GEMS_CVAR_FCT_ABSTARGET"] = "目標吸收" -- MT
L["GEMS_CVAR_FCT_ABSTARGET_DESC"] = "顯示套用至您目標的護盾/吸收量。" -- MT
L["GEMS_CVAR_FCT_PERIODIC"] = "週期傷害" -- MT
L["GEMS_CVAR_FCT_PERIODIC_DESC"] = "顯示 DoT/HoT 跳動數字。" -- MT
L["GEMS_CVAR_FCT_DODGEMISS"] = "閃避/招架/失誤" -- MT
L["GEMS_CVAR_FCT_DODGEMISS_DESC"] = "顯示閃避/招架/失誤文字。對於了解能力何時被避免有用。" -- MT

L["GEMS_CVAR_FCT_LOWRES"] = "低資源警告" -- MT
L["GEMS_CVAR_FCT_LOWRES_DESC"] = "顯示低法力/生命警告。" -- MT
L["GEMS_CVAR_FCT_FLOATMODE"] = "浮動方向" -- MT
L["GEMS_CVAR_FCT_FLOATMODE_DESC"] = "浮動方向。1=向上,2=向下,3=弧形。1 (向上) 為標準。" -- MT
L["GEMS_CVAR_FCT_FLOATMODE_OPT_1"] = "Scroll Up" -- MT
L["GEMS_CVAR_FCT_FLOATMODE_OPT_2"] = "Scroll Down" -- MT
L["GEMS_CVAR_FCT_FLOATMODE_OPT_3"] = "Fountain" -- MT
L["GEMS_CVAR_FCT_FLOATMODE_DESCLONG"] =
    "Direction floating combat text travels from the engagement point. Scroll Up (1, recommended) rises from the target -- the long-standing default that players expect. Scroll Down (2) falls from the target -- some players prefer this for reduced overlap with target buffs above the unit. Fountain (3) arcs outward in a fountain pattern, a more visual style. All three values are documented Blizzard CVar settings; the in-engine fallback for any non-1/non-2 input is fountain." -- MT
L["GEMS_CVAR_FCT_DIRSCALE"] = "方向縮放" -- MT
L["GEMS_CVAR_FCT_DIRSCALE_DESC"] = "方向傷害數字移動縮放。0=無方向移動。1.0=預設。" -- MT
L["GEMS_CVAR_FCT_PETMELEE"] = "寵物近戰傷害" -- MT
L["GEMS_CVAR_FCT_PETMELEE_DESC"] =
    "顯示寵物近戰傷害數字。對寵物職業巨集 (BM 獵人、惡魔術士) 很重要。" -- MT
L["GEMS_CVAR_FCT_PETSPELL"] = "寵物法術傷害" -- MT
L["GEMS_CVAR_FCT_PETSPELL_DESC"] = "顯示寵物法術傷害數字。" -- MT
L["GEMS_CVAR_FCT_REACTIVES"] = "反應性觸發" -- MT
L["GEMS_CVAR_FCT_REACTIVES_DESC"] =
    "顯示反應性能力觸發 (Overpower、Revenge)。幫助識別巨集序列應反應的觸發。" -- MT
L["GEMS_CVAR_FCT_ENERGY"] = "能量獲得" -- MT
L["GEMS_CVAR_FCT_ENERGY_DESC"] = "顯示能量/怒氣/法力獲得數字。預設關閉 -- 可能很吵。" -- MT
L["GEMS_CVAR_FCT_AURAS"] = "增益/減益文字" -- MT
L["GEMS_CVAR_FCT_AURAS_DESC"] = "顯示增益/減益套用文字。預設關閉 -- 群組內容中很吵。" -- MT
L["GEMS_CVAR_FCT_HEALERS"] = "治療者姓名" -- MT
L["GEMS_CVAR_FCT_HEALERS_DESC"] = "顯示治療您的治療者姓名。" -- MT

-- CVar Section: Accessibility
L["GEMS_CVAR_ACCESS_COLORBLIND"] = "色盲模式" -- MT
L["GEMS_CVAR_ACCESS_COLORBLIND_DESC"] =
    "Colourblind mode. Adds colourblind-friendly text labels to tooltips and other interfaces." -- MT
L["GEMS_CVAR_ACCESS_CENTERED"] = "保持置中" -- MT
L["GEMS_CVAR_ACCESS_CENTERED_DESC"] =
    "將角色頭部保持在螢幕中央作為動態參考點。減少動態暈眩。" -- MT
L["GEMS_CVAR_ACCESS_REDUCEMOVE"] = "減少移動" -- MT
L["GEMS_CVAR_ACCESS_REDUCEMOVE_DESC"] = "減少自動相機移動。幫助動態暈眩但可能感覺反應遲鈍。" -- MT

L["GEMS_CVAR_ACCESS_FOCAL"] = "焦點圈" -- MT
L["GEMS_CVAR_ACCESS_FOCAL_DESC"] = "騎乘時顯示焦點圈。減少快速移動時的動態暈眩。" -- MT
L["GEMS_CVAR_ACCESS_TEXTCONTRAST"] = "任務文字對比" -- MT
L["GEMS_CVAR_ACCESS_TEXTCONTRAST_DESC"] = "增加任務 UI 中的文字對比。幫助可讀性。" -- MT
L["GEMS_CVAR_ACCESS_COLORBLIND_OPT_0"] = "Off (default, recommended)" -- MT
L["GEMS_CVAR_ACCESS_COLORBLIND_OPT_1"] = "On (colourblind accessibility)" -- MT
L["GEMS_CVAR_ACCESS_COLORBLIND_DESCLONG"] =
    "Enables colourblind accessibility features across the WoW UI. Default 0 (Off) is the safe baseline for non-colourblind players. Set to 1 if you have any form of colour vision deficiency -- this adds gold/silver/copper text labels next to coin icons, debuff type prefixes on aura tooltips, talent button icons that do not rely solely on colour, gem colour text in the socketing UI, mail error text without coin-colour indicators, and many other accessibility helpers. EMS does not auto-detect your accessibility needs; pick the value that matches your vision. (The Protanopia/Deuteranopia/Tritanopia screen filter is the separate Colourblind Filter row below.)" -- MT
L["GEMS_CVAR_ACCESS_CENTERED_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_ACCESS_CENTERED_OPT_1"] = "On (default, recommended)" -- MT
L["GEMS_CVAR_ACCESS_CENTERED_DESCLONG"] =
    "Motion-sickness control: keeps your character's head fixed at the centre of the screen as a stable reference point, reducing the visual drift sensation during fast camera movement. Default 1 (On) is the right answer for almost every player because the stable head anchor helps with motion sickness during dragonriding, fast camera turns, and mounted travel. Set to 0 if you specifically prefer the unanchored cinematic camera and have no motion-sickness sensitivity." -- MT
L["GEMS_CVAR_ACCESS_REDUCEMOVE_OPT_0"] = "Off (default, recommended)" -- MT
L["GEMS_CVAR_ACCESS_REDUCEMOVE_OPT_1"] = "On (motion-sickness mode)" -- MT
L["GEMS_CVAR_ACCESS_REDUCEMOVE_DESCLONG"] =
    "Motion-sickness control: reduces camera movement that happens without your direct input (autocamera adjustments during combat, terrain bumps, ledge edges). Default 0 (Off) is the baseline because the autocamera adjustments are usually helpful for tracking action. Set to 1 if you experience motion sickness from camera-without-input movements -- this is often paired with CameraKeepCharacterCentered=1 for full motion-sickness accommodation." -- MT
L["GEMS_CVAR_ACCESS_FOCAL_OPT_0"] = "Off (default, recommended)" -- MT
L["GEMS_CVAR_ACCESS_FOCAL_OPT_1"] = "On (focal point while mounted)" -- MT
L["GEMS_CVAR_ACCESS_FOCAL_DESCLONG"] =
    "Motion-sickness control: shows a small visual focal circle in the centre of your screen while mounted to give your eyes a fixed point to focus on. Default 0 (Off) is the baseline. Set to 1 if you experience motion sickness during mount travel or Skyriding flights -- a static focal point reduces the brain's confusion when the world rushes past." -- MT
L["GEMS_CVAR_ACCESS_TEXTCONTRAST_OPT_0"] = "Off (default, recommended)" -- MT
L["GEMS_CVAR_ACCESS_TEXTCONTRAST_OPT_1"] = "On (high contrast quest UI)" -- MT
L["GEMS_CVAR_ACCESS_TEXTCONTRAST_DESCLONG"] =
    "Increases the contrast of text in quest UI windows (questgiver dialogues, quest log details, objective tracker). Default 0 (Off) preserves the standard parchment-style appearance. Set to 1 if you find quest text difficult to read against the textured backgrounds -- the high-contrast mode darkens the parchment and brightens the text. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_DRAGON_DYNFOV"] = "動態 FOV" -- MT
L["GEMS_CVAR_DRAGON_DYNFOV_DESC"] = "基於滑行速度的動態視野。創造速度感。動態暈眩時停用。" -- MT
L["GEMS_CVAR_DRAGON_MAXPITCH"] = "最大俯仰速率" -- MT
L["GEMS_CVAR_DRAGON_MAXPITCH_DESC"] =
    "鍵盤馭龍術的最大俯仰速率。預設 5 可能感覺遲緩。6-7 反應更靈敏。" -- MT
L["GEMS_CVAR_DRAGON_MAXTURN"] = "最大轉彎速率" -- MT
L["GEMS_CVAR_DRAGON_MAXTURN_DESC"] =
    "鍵盤馭龍術的最大轉彎速率。預設 8 可能感覺慢。10 改善機動性。" -- MT
L["GEMS_CVAR_DRAGON_MINPITCH"] = "最小俯仰速率" -- MT
L["GEMS_CVAR_DRAGON_MINPITCH_DESC"] =
    "最小俯仰速率。影響細微的俯仰控制。略高提供更精確的控制。" -- MT
L["GEMS_CVAR_DRAGON_PITCHCTRL"] = "俯仰控制模式" -- MT
L["GEMS_CVAR_DRAGON_PITCHCTRL_DESC"] = "前進/後退輸入如何影響俯仰。3=切換。對鍵盤玩家最舒適。" -- MT

-- Comparison Frame (v1.2.0 S04-B)
L["GEMS_IMPORT_COMPARE"] = "比較" -- MT
L["GEMS_UI_COMPARE_WITH"] = "比較與..." -- MT
L["GEMS_COMPARE_TITLE"] = "序列比較" -- MT
L["GEMS_COMPARE_LEFT_LABEL"] = "現有" -- MT
L["GEMS_COMPARE_RIGHT_LABEL"] = "傳入" -- MT
L["GEMS_COMPARE_STEPS"] = "%d 個步驟" -- MT
L["GEMS_COMPARE_NO_STEPS"] = "無步驟" -- MT
L["GEMS_COMPARE_CLOSE_DESC"] = "關閉比較檢視" -- MT

-- Sequence autocomplete (v1.2.0 S07b)
L["GEMS_AUTOCOMPLETE_SEQUENCES"] = "序列" -- MT
L["GEMS_AUTOCOMPLETE_CLICK_INSERT"] = "/click GRIPEMS_%s" -- MT

-- Popup Editor (v1.2.0 S07a)
L["GEMS_UI_OPEN_NEW_WINDOW"] = "在新視窗開啟" -- MT
L["GEMS_UI_POPUP_TITLE"] = "GRIP-EMS 編輯器" -- MT
L["GEMS_UI_POPUP_CLOSE_DIRTY"] = "此編輯器有未儲存變更。\n關閉前儲存?" -- MT
L["GEMS_UI_POPUP_MAX_REACHED"] = "您已達到編輯器視窗上限 (%d)。" -- MT

-- Editor Colours (v1.2.0 S08a)
L["GEMS_SETTINGS_EDITOR_COLOURS"] = "編輯器顏色" -- MT
L["GEMS_SETTINGS_SYNTAX_COMMAND"] = "斜線指令" -- MT
L["GEMS_SETTINGS_SYNTAX_COMMAND_DESC"] = "用於 /cast、/use、/click 等斜線指令的顏色。" -- MT
L["GEMS_SETTINGS_SYNTAX_CONDITIONAL"] = "條件式" -- MT
L["GEMS_SETTINGS_SYNTAX_CONDITIONAL_DESC"] = "用於 [mod:shift] 或 [talent:X] 等巨集條件的顏色。" -- MT
L["GEMS_SETTINGS_SYNTAX_VARIABLE"] = "變數" -- MT
L["GEMS_SETTINGS_SYNTAX_VARIABLE_DESC"] = "用於寫成 ~name~ 的巨集序列變數的顏色。" -- MT
L["GEMS_SETTINGS_SYNTAX_COMMENT"] = "註解" -- MT
L["GEMS_SETTINGS_SYNTAX_COMMENT_DESC"] = "用於以兩個破折號開頭的註解行的顏色。" -- MT
L["GEMS_SETTINGS_SYNTAX_RESET"] = "重置條件" -- MT
L["GEMS_SETTINGS_SYNTAX_RESET_DESC"] = "用於 reset=target、reset=combat 或 reset=5 等重置規則的顏色。" -- MT
L["GEMS_SETTINGS_SYNTAX_NUMBER"] = "數字" -- MT
L["GEMS_SETTINGS_SYNTAX_NUMBER_DESC"] = "用於巨集文字內數字的顏色。" -- MT

-- Floating Menu (v1.2.0 S09a)
L["GEMS_FLOATING_HEADER"] = "浮動選單" -- MT
L["GEMS_FLOATING_SHOW_DESC"] = "在螢幕上顯示浮動快速存取選單。" -- MT
L["GEMS_FLOATING_DIRECTION_DESC"] = "選單按鈕從主按鈕往哪個方向開啟。" -- MT
L["GEMS_FLOATING_LOCK_DESC"] = "將浮動選單鎖定在原位,使您無法拖曳。" -- MT
L["GEMS_FLOATING_SCALE_DESC"] = "變更浮動選單的整體大小。" -- MT
L["GEMS_FLOATING_LOCKED"] = "浮動選單已鎖定。" -- MT
L["GEMS_FLOATING_UNLOCKED"] = "浮動選單已解鎖。" -- MT

L["GEMS_FLOATING_BTN_SEQUENCES"] = "序列" -- MT
L["GEMS_FLOATING_BTN_IMPORT"] = "匯入" -- MT
L["GEMS_FLOATING_BTN_EXPORT"] = "匯出" -- MT
L["GEMS_FLOATING_BTN_VARIABLES"] = "變數" -- MT
L["GEMS_FLOATING_BTN_TRACKER"] = "追蹤器" -- MT
L["GEMS_FLOATING_BTN_OPTIONS"] = "選項" -- MT
L["GEMS_FLOATING_BTN_COLLAPSE"] = "收合" -- MT
L["GEMS_FLOATING_BTN_EXPAND"] = "展開" -- MT
L["GEMS_FLOATING_BTN_CLOSE"] = "關閉" -- MT
L["GEMS_FLOATING_DIR_UP"] = "向上" -- MT
L["GEMS_FLOATING_DIR_DOWN"] = "向下" -- MT
L["GEMS_FLOATING_DIR_LEFT"] = "向左" -- MT
L["GEMS_FLOATING_DIR_RIGHT"] = "向右" -- MT
L["GEMS_HELP_MENU"] = "  /gems menu - 切換浮動選單列" -- MT

-- Support tab (v1.2.0 S10-B)
L["GEMS_SETTINGS_SUPPORT"] = "支援" -- MT
L["GEMS_SUPPORT_CREDITS"] = "由 Sataana 製作 (MrSataana / JesperLive)" -- MT
L["GEMS_SUPPORT_DISCORD"] = "Discord: discord.gg/temptingus" -- MT
L["GEMS_SUPPORT_SYSTEM_HEADER"] = "系統資訊" -- MT
L["GEMS_SUPPORT_CREDITS_HEADER"] = "致謝" -- MT
L["GEMS_SUPPORT_DISCORD_HEADER"] = "社群" -- MT
L["GEMS_HELP_COMPRESS"] = "  /gems compress <name> - 編碼序列 (開發者)" -- MT
L["GEMS_HELP_DECOMPRESS"] = "  /gems decompress <string> - 解碼字串 (開發者)" -- MT

-- Remote Browser (v1.2.0 S13b)
L["GEMS_UI_REMOTE_BROWSER_TITLE"] = "遠端巨集瀏覽器" -- MT
L["GEMS_UI_REMOTE_PLAYERS_HEADER"] = "擁有 EMS 的玩家" -- MT
L["GEMS_UI_REMOTE_REFRESH"] = "重新整理" -- MT
L["GEMS_UI_REMOTE_SEQUENCES_FROM"] = "來自 %s 的序列" -- MT
L["GEMS_UI_REMOTE_WAITING"] = "等待回應..." -- MT
L["GEMS_UI_REMOTE_NO_PLAYERS"] = "找不到 EMS 使用者。加入隊伍以發現玩家。" -- MT
L["GEMS_UI_REMOTE_NO_SEQUENCES"] = "此玩家無可用序列。" -- MT
L["GEMS_UI_REMOTE_IMPORT"] = "匯入" -- MT

L["GEMS_UI_REMOTE_REQUEST_SENT"] = "已從 %s 請求 %s" -- MT
L["GEMS_UI_REMOTE_LIST_RECEIVED"] = "已從 %s 收到序列清單 (%d 個序列)" -- MT
L["GEMS_HELP_BROWSE"] = "  /gems browse - 開啟遠端序列瀏覽器" -- MT
L["GEMS_BROWSE_REFRESH_DESC"] = "重新整理隊員清單及其序列" -- MT
L["GEMS_BROWSE_IMPORT_DESC"] = "將此序列匯入您的程式庫" -- MT
L["GEMS_BROWSE_CLOSE_DESC"] = "關閉瀏覽器" -- MT

-- Recorder
L["GEMS_UI_RECORD"] = "錄製" -- MT
L["GEMS_UI_RECORDING"] = "錄製中..." -- MT
L["GEMS_UI_RECORDING_COUNT"] = "錄製中 (%d)" -- MT
L["GEMS_RECORDER_MAX_REACHED"] = "錄製已停止: 已達步驟限制。" -- MT
L["GEMS_RECORDER_STARTED"] = "巨集錄製器: 已開始。" -- MT
L["GEMS_RECORDER_STOPPED"] = "錄製已停止: 已捕獲 %d 個法術。" -- MT
L["GEMS_RECORDER_UNAVAILABLE"] = "巨集錄製器無法使用。" -- MT
L["GEMS_RECORDER_CREATE_CONFIRM"] = "錄製已捕獲 %d 個法術。從此錄製建立新序列?" -- MT
L["GEMS_RECORDER_CREATE_YES"] = "建立序列" -- MT
L["GEMS_RECORDER_CREATE_NO"] = "捨棄" -- MT
L["GEMS_RECORDER_EMPTY"] = "未錄製任何法術。" -- MT
L["GEMS_SETTINGS_RECORDER_HEADER"] = "錄製器" -- MT
L["GEMS_SETTINGS_RECORDER_DEDUP"] = "將重複的施法合併為一個步驟" -- MT
L["GEMS_SETTINGS_RECORDER_DEDUP_DESC"] = "啟用時,錄製器會將同法術連續施法合併為一個步驟。" -- MT

-- Spell Cache Viewer (v1.2.0 S16)
L["GEMS_SPELLCACHE_TITLE"] = "法術快取" -- MT
L["GEMS_SPELLCACHE_TAB_SPELLS"] = "法術" -- MT
L["GEMS_SPELLCACHE_TAB_ITEMS"] = "物品" -- MT
L["GEMS_SPELLCACHE_TAB_TOYS"] = "玩具" -- MT
L["GEMS_SPELLCACHE_SEARCH"] = "搜尋..." -- MT
L["GEMS_SPELLCACHE_REFRESH"] = "重新整理" -- MT
L["GEMS_SPELLCACHE_CLEAR_OVERRIDES"] = "清除覆寫" -- MT
L["GEMS_SPELLCACHE_CLEAR_CONFIRM"] = "移除所有法術名稱覆寫?此操作無法復原。" -- MT

L["GEMS_SPELLCACHE_SHOWING"] = "顯示 %d / %d" -- MT
L["GEMS_SPELLCACHE_SCANNING"] = "掃描中..." -- MT
L["GEMS_SPELLCACHE_NOT_AVAILABLE"] = "法術快取檢視器無法使用。" -- MT
L["GEMS_SPELLCACHE_OVERRIDE_CLEARED"] = "法術名稱覆寫已清除。" -- MT
L["GEMS_HELP_SPELLCACHE"] = "|cFF00CC66/gems spellcache|r -- 開啟法術快取檢視器" -- MT
L["GEMS_HELP_MAPINFO"] = "|cFF00CC66/gems mapinfo|r -- 顯示目前地圖/副本 ID" -- MT

-- Inline string localization (v1.2.0 S22-D)
L["GEMS_UI_STUB_PREVIEW"] = "巨集樁預覽" -- MT
L["GEMS_UI_EMPTY_HINT"] = "匯入或建立序列以開始" -- MT
L["GEMS_UI_KEYBIND_TOOLTIP"] = "按鍵綁定: %s" -- MT

-- Vehicle / Pet Battle Keybinds (v1.2.0 S23)
L["GEMS_VEHICLE_KEYBINDS_HEADER"] = "載具 / 覆寫條按鍵綁定" -- MT
L["GEMS_PET_BATTLE_KEYBINDS_HEADER"] = "寵物對戰按鍵綁定" -- MT
L["GEMS_VEHICLE_SLOT"] = "欄位 %d" -- MT
L["GEMS_VEHICLE_KEYBINDS_APPLIED"] = "載具按鍵綁定已套用: %d 個綁定" -- MT
L["GEMS_VEHICLE_KEYBINDS_CLEARED"] = "載具按鍵綁定已清除" -- MT
L["GEMS_PET_BATTLE_KEYBINDS_APPLIED"] = "寵物對戰按鍵綁定已套用: %d 個綁定" -- MT
L["GEMS_PET_BATTLE_KEYBINDS_CLEARED"] = "寵物對戰按鍵綁定已清除" -- MT
L["GEMS_PET_BATTLE_ABILITY"] = "能力 %d" -- MT
L["GEMS_PET_BATTLE_SWAP"] = "交換寵物" -- MT
L["GEMS_PET_BATTLE_PASS"] = "略過回合" -- MT
L["GEMS_PET_BATTLE_FORFEIT"] = "認輸" -- MT
L["GEMS_BAR_INTEGRATION_HEADER"] = "動作條整合" -- MT
L["GEMS_BAR_INTEGRATION_DESC"] = "在持有序列的動作條按鈕上方顯示序列圖示。" -- MT
L["GEMS_BAR_INTEGRATION_TRACKED"] = "動作條整合: 追蹤 %d 個按鈕 (%s)" -- MT
L["GEMS_UI_NOT_BOUND"] = "未綁定" -- MT

-- Feature: Click Rate Diagnostics (/gems diag)
L["GEMS_DIAG_HEADER"] = "--- Execution Diagnostics ---" -- MT
L["GEMS_DIAG_CPS"] = "即時 CPS: %.1f" -- MT
L["GEMS_DIAG_CONFIGURED"] = "設定的點擊速率: %dms (有效)" -- MT
L["GEMS_DIAG_TOTAL"] = "追蹤的總施法數: %d" -- MT

L["GEMS_DIAG_TRACER"] = "追蹤器: %s" -- MT
L["GEMS_DIAG_TRACER_ON"] = "作用中" -- MT
L["GEMS_DIAG_TRACER_OFF"] = "未作用" -- MT
L["GEMS_DIAG_TOP_SPELLS"] = "最常用法術:" -- MT
L["GEMS_DIAG_SPELL_ROW"] = "  %d. %s (ID: %d) -- %d 次施法" -- MT
L["GEMS_DIAG_NO_DATA"] = "尚無施法資料。請先使用序列。" -- MT
L["GEMS_HELP_DIAG"] = "顯示執行診斷 (CPS、最常用法術)" -- MT
L["GEMS_HELP_MEMCHECK"] = "記憶體診斷 (GC、表格大小、堆積)" -- MT
L["GEMS_HELP_PERF"] = "效能分析 (OnUpdate、畫格、計時)" -- MT
L["GEMS_HELP_MONITOR"] = "300 畫格連續分析器 (掛勾關鍵函式)" -- MT

-- Feature: Optimal MS Advisor (/gems msadvisor)
L["GEMS_MSADVISOR_HEADER"] = "--- MS Advisor%s ---" -- MT
L["GEMS_MSADVISOR_GCD"] = "基礎 GCD: %dms (%.1f%% 加速)" -- MT
L["GEMS_MSADVISOR_LAG"] = "世界延遲: %dms" -- MT
L["GEMS_MSADVISOR_SQW"] = "法術佇列視窗: %dms" -- MT
L["GEMS_MSADVISOR_RECOMMEND"] = "建議點擊速率: %dms" -- MT
L["GEMS_MSADVISOR_CURRENT"] = "目前設定: %dms" -- MT
L["GEMS_MSADVISOR_DELTA"] = "差距: %+dms (%s)" -- MT
L["GEMS_MSADVISOR_FASTER"] = "您可以更快點擊" -- MT
L["GEMS_MSADVISOR_SLOWER"] = "您點擊速度比 GCD 允許的快" -- MT
L["GEMS_MSADVISOR_GOOD"] = "搭配良好" -- MT
L["GEMS_MSADVISOR_ROTATION"] = "序列 '%s': %d 個步驟,完整循環約 %dms" -- MT
L["GEMS_MSADVISOR_NOT_FOUND"] = "找不到序列 '%s'。" -- MT
L["GEMS_HELP_MSADVISOR"] = "依加速建議最佳點擊速率" -- MT

-- Feature: Dormant Sequence Lazy Loading
L["GEMS_DORMANT_LOADED"] = "  %d 個序列載入為休眠 (不同職業)" -- MT
L["GEMS_DORMANT_LABEL"] = "(休眠)" -- MT
L["GEMS_HELP_LOADCLASS"] = "為職業 ID 啟動休眠序列" -- MT
L["GEMS_HELP_REPAIR"] = "/gems repair <name> -- 分析並修復序列" -- MT
L["GEMS_HELP_REPAIRALL"] = "/gems repairall -- 分析並修復所有序列" -- MT
L["GEMS_HELP_RECORD"] = "/gems record -- 切換巨集錄製器 (將法術擷取至序列)。" -- MT

L["GEMS_HELP_TRACE"] = "/gems trace [on|off|status] -- 切換執行追蹤器。" -- MT
L["GEMS_HELP_RESETUI"] = "/gems resetui -- 重置視窗為預設大小和位置" -- MT
L["GEMS_RESETUI_DONE"] = "UI 已重置為預設大小和位置。" -- MT
L["GEMS_LOADCLASS_ALREADY"] = "職業 %d 序列已載入。" -- MT
L["GEMS_LOADCLASS_DONE"] = "已為職業 %d 啟動 %d 個休眠序列。" -- MT
L["GEMS_LOADCLASS_USAGE"] = "用法: /gems loadclass <classID> (1=戰士、2=聖騎士、...)" -- MT
L["GEMS_UI_ACTIVATE"] = "啟動" -- MT

-- Feature: Raw Macrotext Import
L["GEMS_RAWIMPORT_DETECTED"] = "找到原始巨集文字。解析 %d 行..." -- MT
L["GEMS_RAWIMPORT_RESULT"] = "已從原始巨集文字解析 %d 個步驟。" -- MT
L["GEMS_RAWIMPORT_NAME"] = "已匯入巨集" -- MT
L["GEMS_RAWIMPORT_NO_SPELLS"] = "貼上的文字中找不到可施放的行。" -- MT

-- Feature: Step Spell Picker
L["GEMS_SPELLPICKER_TITLE"] = "法術選擇器" -- MT
L["GEMS_SPELLPICKER_SEARCH"] = "搜尋法術..." -- MT
L["GEMS_SPELLPICKER_ALL"] = "全部" -- MT
L["GEMS_SPELLPICKER_CLASS"] = "職業" -- MT
L["GEMS_SPELLPICKER_PET"] = "寵物能力" -- MT
L["GEMS_SPELLPICKER_ITEMS"] = "物品" -- MT
L["GEMS_SPELLPICKER_GEAR"] = "裝備" -- MT
L["GEMS_SPELLPICKER_CONSUMABLES"] = "消耗品" -- MT
L["GEMS_SPELLPICKER_TOYS"] = "玩具" -- MT
L["GEMS_SPELLPICKER_SPEC"] = "專精" -- MT
L["GEMS_SPELLPICKER_RACE"] = "種族" -- MT
L["GEMS_SPELLPICKER_GENERAL"] = "一般" -- MT
L["GEMS_SPELLPICKER_PROF"] = "專業" -- MT
L["GEMS_SPELLPICKER_OTHER"] = "其他" -- MT
L["GEMS_SPELLPICKER_MOUNTS"] = "坐騎" -- MT
L["GEMS_SPELLPICKER_COMPANIONS"] = "夥伴" -- MT
L["GEMS_SPELLPICKER_CONDITIONALS"] = "條件式" -- MT

L["GEMS_SPELLPICKER_CUSTOM"] = "自訂:" -- MT
L["GEMS_SPELLPICKER_INSERT"] = "插入" -- MT
L["GEMS_SPELLPICKER_NO_RESULTS"] = "無相符法術" -- MT
L["GEMS_SPELLPICKER_FAVORITES"] = "我的最愛" -- MT
L["GEMS_SPELLPICKER_WARBANK_NOTE"] = "戰隊銀行物品僅在銀行家處可見" -- MT
L["GEMS_SPELLPICKER_MACROS"] = "巨集" -- MT
L["GEMS_SPELLPICKER_SLASH"] = "斜線" -- MT
L["GEMS_HELP_SPELLPICKER"] = "點擊任一步驟上的圖示按鈕以開啟法術選擇器。" -- MT

-- Feature: Gear-Aware Variables
L["GEMS_GEAR_VAR_HEADER"] = "裝備變數 (自動偵測使用效果):" -- MT
L["GEMS_GEAR_VAR_ROW"] = "  ~%s~ = %s" -- MT
L["GEMS_GEAR_VAR_NONE"] = "未偵測到裝備使用效果。" -- MT
L["GEMS_GEAR_VAR_UPDATED"] = "裝備變數已更新 (偵測到 %d 個使用效果)。" -- MT

-- Feature: CVar Profiles & Context-Aware Switching (Phase 2)
L["GEMS_CVAR_PROFILE_GENERAL"] = "一般 (預設)" -- MT
L["GEMS_CVAR_PROFILE_RAID"] = "團隊副本" -- MT
L["GEMS_CVAR_PROFILE_RAID_DESC"] = "為團隊副本遭遇調校: 較短的姓名板範圍、堆疊姓名板版面。" -- MT
L["GEMS_CVAR_PROFILE_MPLUS"] = "傳奇鑰石" -- MT
L["GEMS_CVAR_PROFILE_MPLUS_DESC"] = "為傳奇鑰石地下城調校: 開啟敵人僕從姓名板,較短範圍。" -- MT
L["GEMS_CVAR_PROFILE_SOLO"] = "單人 / 開放世界" -- MT
L["GEMS_CVAR_PROFILE_SOLO_DESC"] = "為單人內容調校: 完整視覺、更寬的互動弧形、姓名板關閉。" -- MT
L["GEMS_CVAR_PROFILE_DELVES"] = "深淵" -- MT
L["GEMS_CVAR_PROFILE_DELVES_DESC"] =
    "Tuned for Delves: enemy minion nameplates on, shorter nameplate range, wider interact arc." -- MT
L["GEMS_CVAR_PROFILE_PVP"] = "PvP" -- MT
L["GEMS_CVAR_PROFILE_PVP_DESC"] =
    "為 PvP 調校: 開啟友方姓名板、開啟敵人僕從姓名板、堆疊姓名板版面。" -- MT
L["GEMS_CVAR_PROFILE_ACTIVE"] = "作用中設定檔: %s" -- MT
L["GEMS_CVAR_PROFILE_SELECT"] = "選擇設定檔" -- MT
L["GEMS_CVAR_PROFILE_AUTO"] = "自動 (情境感知)" -- MT
L["GEMS_CVAR_PROFILE_AUTOSWITCH"] = "依情境自動切換" -- MT

L["GEMS_CVAR_PROFILE_AUTOSWITCH_DESC"] =
    "當您進入團隊副本、地下城、PvP 對戰或開放世界時為您切換 CVar 設定檔。" -- MT
L["GEMS_CVAR_PROFILE_MANAGE"] = "管理設定檔..." -- MT
L["GEMS_CVAR_PROFILE_MANAGE_DESC"] = "建立和管理含有每 CVar 覆寫的自訂 CVar 設定檔。" -- MT
L["GEMS_CVAR_PROFILE_CREATE"] = "建立設定檔" -- MT
L["GEMS_CVAR_PROFILE_CREATE_NAME"] = "設定檔名稱:" -- MT
L["GEMS_CVAR_PROFILE_CLONE_FROM"] = "從以下複製:" -- MT
L["GEMS_CVAR_PROFILE_DELETE"] = "刪除設定檔" -- MT
L["GEMS_CVAR_PROFILE_DELETE_CONFIRM"] = '刪除自訂設定檔 "%s"?此操作無法復原。' -- MT
L["GEMS_CVAR_PROFILE_OVERRIDE"] = "設定檔覆寫" -- MT
L["GEMS_CVAR_PROFILE_OVERRIDE_NONE"] = "無覆寫 (使用一般)" -- MT
L["GEMS_CVAR_PROFILE_ADD_OVERRIDE"] = "新增覆寫..." -- MT
L["GEMS_CVAR_PROFILE_SWITCHED"] = "CVar 設定檔已切換至: %s" -- MT
L["GEMS_CVAR_PROFILE_QUEUED"] = "%d 個安全 CVars 已加入佇列 (戰鬥外套用)" -- MT
L["GEMS_CVAR_CHANGES_DETECTED"] = "自上次工作階段以來 %d 個 CVars 已變更" -- MT
L["GEMS_CVAR_CHANGES_INSESSION"] = "本工作階段中 %d 個 CVars 已變更" -- MT
L["GEMS_CVAR_SESSION_NOTICE"] = "通知本工作階段中的 CVar 變更" -- TODO: MT 2026-06-20
L["GEMS_CVAR_SESSION_NOTICE_DESC"] =
    "開啟後，EMS 會為本工作階段中每個變更的 CVar 輸出一行聊天訊息，並標明變更來源。預設關閉；可隨時使用 /gems cvar changes 查看。" -- TODO: MT 2026-06-20
L["GEMS_CVAR_NOTICE_TOGGLED"] = "CVar 工作階段通知：%s" -- TODO: MT 2026-06-20
L["GEMS_CVAR_CHANGES_DISMISS"] = "關閉" -- MT
L["GEMS_CVAR_CHANGES_FIX_ALL"] = "修復所有變更" -- MT
L["GEMS_CVAR_CHANGES_CAUSE_PATCH"] = "可能原因: 遊戲修補檔重置" -- MT
L["GEMS_CVAR_CHANGES_CAUSE_ADDON"] = "可能原因: 由外掛/UI 變更" -- MT
L["GEMS_CVAR_CHANGES_CAUSE_AUTOFIX"] = "由 EMS 自動修復" -- MT
L["GEMS_CVAR_CHANGES_CAUSE_PROFILE"] = "Profile swap" -- MT
L["GEMS_CVAR_CHANGES_CAUSE_UNKNOWN"] = "自上次工作階段以來變更" -- MT
L["GEMS_CVAR_CHANGES_BULK_SUMMARY"] = "%d CVars %s -- open /gems options -> CVar Health to review" -- MT
L["GEMS_CVAR_PROFILE_NOT_FOUND"] = "未知設定檔: %s" -- MT
L["GEMS_CVAR_AUTO_TOGGLED"] = "CVar 自動切換: %s" -- MT
L["GEMS_CVAR_NO_CHANGES"] = "自上次工作階段以來未偵測到 CVar 變更" -- MT
L["GEMS_CVAR_PROFILE_RENAME"] = "重新命名" -- MT
L["GEMS_CVAR_PROFILE_OVERRIDES"] = "覆寫 (%d)" -- MT
L["GEMS_CVAR_PROFILE_NO_OVERRIDES"] = "無覆寫" -- MT
L["GEMS_CVAR_PROFILE_TRIGGERED_BY"] = "由以下觸發: %s" -- MT
L["GEMS_CVAR_PROFILE_TRIGGER_MANUAL"] = "手動選擇" -- MT

L["GEMS_CVAR_PROFILE_TRIGGER_AUTO"] = "自動切換 (%s)" -- MT
L["GEMS_CVAR_PROFILE_TRIGGER_AUTO_NO_CONTEXT"] = "自動切換 (無作用情境)" -- MT
L["GEMS_CVAR_PROFILE_TRIGGER_DISABLED"] = "自動切換已關閉 (保留上次選擇)" -- MT

-- Profile Diff (G19)
L["GEMS_CVAR_DIFF_TAB"] = "比較設定檔" -- MT
L["GEMS_CVAR_DIFF_DESC"] =
    "選擇兩個設定檔以查看哪些 CVars 它們覆寫以及差異點。顏色代碼: 紅色表示兩個設定檔都用不同值覆寫該 CVar,黃色表示僅一個設定檔覆寫,綠色表示兩個都用相同值覆寫。" -- MT
L["GEMS_CVAR_DIFF_LEFT"] = "左側設定檔" -- MT
L["GEMS_CVAR_DIFF_RIGHT"] = "右側設定檔" -- MT
L["GEMS_CVAR_DIFF_SHOW_DIFFS_ONLY"] = "僅顯示差異" -- MT
L["GEMS_CVAR_DIFF_HEADER"] = "比較 %s 與 %s:" -- MT
L["GEMS_CVAR_DIFF_NO_DIFFERENCES"] = "無覆寫可比較。請選擇兩個有自訂 CVar 值的設定檔。" -- MT
L["GEMS_CVAR_DIFF_LEFT_ONLY"] = "%s: %s | (無)" -- MT
L["GEMS_CVAR_DIFF_RIGHT_ONLY"] = "%s: (無) | %s" -- MT
L["GEMS_CVAR_DIFF_BOTH_DIFFER"] = "%s: %s | %s" -- MT
L["GEMS_CVAR_DIFF_BOTH_SAME"] = "%s: %s" -- MT

-- Profile Export/Import (G20)
L["GEMS_CVAR_PROFILE_EXPORT"] = "匯出" -- MT
L["GEMS_CVAR_PROFILE_EXPORT_DESC"] =
    "為此設定檔產生貼上字串。與其他角色或玩家分享以複製覆寫集。" -- MT
L["GEMS_CVAR_PROFILE_EXPORT_RESULT"] = "%s 的匯出字串。按 Ctrl+C 複製,然後貼到另一角色的匯入框。" -- MT
L["GEMS_CVAR_PROFILE_EXPORT_ERROR_NOT_FOUND"] = "找不到設定檔。" -- MT
L["GEMS_CVAR_PROFILE_IMPORT"] = "匯入設定檔" -- MT
L["GEMS_CVAR_PROFILE_IMPORT_DESC"] = "貼上來自另一角色的匯出字串以新增為新自訂設定檔。" -- MT
L["GEMS_CVAR_PROFILE_IMPORT_INPUT"] = "貼上匯出字串" -- MT
L["GEMS_CVAR_PROFILE_IMPORT_LABEL"] = "新設定檔名稱 (選填)" -- MT
L["GEMS_CVAR_PROFILE_IMPORT_LABEL_DESC"] =
    "覆寫匯入的設定檔名稱。留空以使用匯出字串內嵌的名稱。" -- MT

L["GEMS_CVAR_PROFILE_IMPORT_BUTTON"] = "匯入" -- MT
L["GEMS_CVAR_PROFILE_IMPORT_SUCCESS"] = "GEMS: 已匯入設定檔 %s,有 %d 個覆寫。" -- MT
L["GEMS_CVAR_PROFILE_IMPORT_ERROR"] = "GEMS: 匯入失敗: %s" -- MT
L["GEMS_CVAR_PROFILE_IMPORT_ERROR_FORMAT"] = "輸入為空或無效。" -- MT
L["GEMS_CVAR_PROFILE_IMPORT_ERROR_DECODE"] = "解碼失敗 -- 不是 GEMSCP1 匯出字串。" -- MT
L["GEMS_CVAR_PROFILE_IMPORT_ERROR_PAYLOAD"] = "匯出酬載格式錯誤或版本不支援。" -- MT

L["GEMS_CVAR_MAP_HEADER"] = "情境設定檔對應" -- MT
L["GEMS_CVAR_MAP_DESC"] = "選擇每個情境套用哪個 CVar 設定檔" -- MT
L["GEMS_CVAR_MAP_DEFAULT"] = "預設 (%s)" -- MT
L["GEMS_CVAR_MAP_NONE"] = "一般 (無設定檔)" -- MT

-- SQW Optimizer
L["GEMS_SQW_OPTIMIZER"] = "動態 SQW 最佳化器" -- MT
L["GEMS_SQW_OPTIMIZER_LINK"] = "啟用時,自動管理巨集序列區段中的 SpellQueueWindow CVar。" -- MT
L["GEMS_SQW_OPTIMIZER_DESC"] = "依您的網路延遲自動設定法術佇列視窗 (SQW)。" -- MT
L["GEMS_SQW_BUFFER"] = "安全緩衝 (ms)" -- MT
L["GEMS_SQW_BUFFER_DESC"] =
    "新增至法術佇列視窗 (SQW) 的額外時間填充。較高值損失較少按鍵;較低值感覺更靈敏。建議值為 100 毫秒。" -- MT
L["GEMS_SQW_LIVE"] = "SQW: %dms (延遲: %dms + 緩衝: %dms)" -- MT
L["GEMS_SQW_ADVISORY"] = "建議點擊速率: %dms" -- MT
L["GEMS_SQW_ADVISORY_DETAIL"] = "GCD: %dms,SQW: %dms,延遲: %dms" -- MT
L["GEMS_SQW_ADVISORY_DELTA"] = "您的設定: %dms (比建議 %s %dms)" -- MT
L["GEMS_SQW_MANAGED"] = "由 SQW 最佳化器管理" -- MT
L["GEMS_SQW_ENABLED"] = "SQW 最佳化器已啟用" -- MT
L["GEMS_SQW_DISABLED"] = "SQW 最佳化器已停用 (SQW 重置為 %d)" -- MT
L["GEMS_SQW_STATUS"] = "SQW: %dms | 延遲: %dms | 緩衝: %dms | 建議: %dms" -- MT
L["GEMS_SQW_HISTORY_HEADER"] = "Latency trend" -- MT
L["GEMS_SQW_HISTORY_EMPTY"] = "No latency samples yet -- samples record while the optimiser runs." -- MT
L["GEMS_SQW_HISTORY_RANGE"] = "low %d / high %d ms" -- MT
L["GEMS_SQW_BUFFER_SET"] = "SQW 緩衝設為 %dms" -- MT
L["GEMS_SQW_BUFFER_RANGE"] = "緩衝必須在 50 與 200 之間" -- MT

L["GEMS_SQW_SLOWER"] = "慢" -- MT
L["GEMS_SQW_FASTER"] = "快" -- MT

-- Faster, Slower (TempoAdvisor)
L["FS_CMD_HELP"] = "用法: /gems fs [name] - 分析序列點擊速率" -- MT
L["FS_STATUS_HEADER"] = "Faster, Slower" -- MT
L["FS_COMPLEXITY_RELAXED"] = "輕鬆" -- MT
L["FS_COMPLEXITY_STANDARD"] = "標準" -- MT
L["FS_COMPLEXITY_DEMANDING"] = "嚴苛" -- MT
L["FS_COMPLEXITY_INTENSE"] = "激烈" -- MT
L["FS_CONFIDENCE_ESTIMATED"] = "估計" -- MT
L["FS_CONFIDENCE_PRECISE"] = "精確" -- MT
L["FS_CONFIDENCE_CALIBRATED"] = "已校準" -- MT
L["FS_UNKNOWN_SPELLS"] = "%d 個未知法術 - 使用通用估計" -- MT
L["FS_RECOMMENDED"] = "建議: %d ms (%d/秒)" -- MT
L["FS_COMPLEXITY"] = "複雜度: %s" -- MT
L["FS_NO_SEQUENCE"] = "無作用中序列" -- MT
L["FS_NO_STEPS"] = "無步驟可分析" -- MT
L["FS_ANALYZING"] = "分析 %s 中..." -- MT
L["FS_DEBUG_ON"] = "Faster, Slower 偵錯已啟用" -- MT
L["FS_DEBUG_OFF"] = "Faster, Slower 偵錯已停用" -- MT
L["FS_HOLD_DEV"] = "Hold Mode 開發中。請參閱 /gems fs 了解可用指令。" -- MT
L["FS_HOLD_RESET_DONE"] = "Hold mode 非 GCD 覆寫已重置。正在重新檢查..." -- MT
L["FS_HOLD_DIAG_HEADER"] = "--- Hold Mode Diagnostics ---" -- MT
L["FS_HOLD_DIAG_STATE"] = "  active=%s  seq=%s  key=%s" -- MT
L["FS_HOLD_DIAG_BUTTON"] = "  button=%s  step=%s" -- MT
L["FS_HOLD_DIAG_CVAR"] = "  CVar held=%s  poll=%s" -- MT
L["FS_HOLD_DIAG_STEPS"] = "  compiled steps=%d" -- MT

-- Faster, Slower Phase 2: Settings + Auto-Set
L["FS_AUTO_SET"] = "依序列自動調整點擊速率" -- MT
L["FS_AUTO_SET_DESC"] = "啟動每個序列時調整其點擊速率。" -- MT
L["FS_SPARKLINE"] = "顯示 CPS 火花圖" -- MT

L["FS_ALERT_ENABLED"] = "啟用不符警示" -- MT
L["FS_ALERT_VISUAL"] = "視覺警示" -- MT
L["FS_ALERT_AUDIO"] = "音訊警示" -- MT
L["FS_ALERT_SOUND_SLOW"] = "慢速警示音" -- MT
L["FS_ALERT_SOUND_FAST"] = "快速警示音" -- MT
L["FS_ALERT_CHANNEL"] = "音訊頻道" -- MT
L["FS_ALERT_TEST"] = "測試" -- MT
L["FS_ALERT_SLOW"] = "慢速門檻" -- MT
L["FS_ALERT_FAST"] = "快速門檻" -- MT
L["FS_AUTO_LABEL"] = "自動: %dms (%s)" -- MT
L["FS_MANUAL_OVERRIDE"] = "手動覆寫" -- MT
L["FS_CLEAR_OVERRIDE"] = "清除覆寫" -- MT
L["FS_OVERRIDE_SET"] = "%s 的手動覆寫設為 %dms" -- MT
L["FS_OVERRIDE_CLEARED"] = "%s 的覆寫已清除" -- MT
L["FS_RATE_WILL_UPDATE"] = "離開戰鬥時點擊速率將更新" -- MT
L["FS_OVERLAY_TITLE"] = "Faster, Slower" -- MT
L["FS_OVERLAY_LOCKED"] = "疊層已鎖定" -- MT
L["FS_OVERLAY_UNLOCKED"] = "疊層已解鎖" -- MT
L["FS_OVERLAY_SHOWN"] = "顯示點擊速率疊層" -- MT
L["FS_LDB_NO_SEQ"] = "-- /秒" -- MT
L["FS_LDB_SPAM"] = "%.1f/秒 . %dms" -- MT
L["FS_LDB_HOLD"] = "Hold . %dms" -- MT
L["FS_ALERT_TOO_SLOW"] = "點擊太慢!" -- MT
L["FS_ALERT_TOO_FAST"] = "點擊太快" -- MT
L["FS_HOLD_AUTOTUNED"] = "自動調校 . 輪詢 %dms" -- MT
L["FS_HOLD_CONFLICT"] = "Hold Mode 與 %s 衝突。兩個外掛都管理 hold-to-cast。" -- MT
L["FS_HOLD_ACTIVATED"] = "%s 的 Hold Mode 已啟動" -- MT
L["FS_HOLD_DEACTIVATED"] = "Hold Mode 已停用" -- MT
L["FS_HOLD_NO_BUTTON"] = "Hold Mode: 找不到原生按鈕" -- MT
L["FS_HOLD_NO_KEYBIND"] = "Hold Mode: '%s' 沒有指派的按鍵綁定 -- 請先在按鍵綁定分頁指派一個。" -- MT
L["FS_HOLD_ENABLED"] = "啟用 Hold Mode" -- MT

L["FS_HOLD_ENABLED_DESC"] = "按住按鍵而非連點。EMS 使用原生動作按鈕並為您調校重複速率。" -- MT
L["FS_HOLD_SLOT"] = "原生按鈕欄位" -- MT
L["FS_HOLD_SLOT_DESC"] =
    "EMS 將使用哪個原生動作條按鈕 (預設: MultiBar7Button12 -- 第 7 列、第 12 欄)。請保持您的動作條此欄位空白。" -- MT
L["FS_HOLD_POLL_MIN"] = "最小輪詢速率 (ms)" -- MT
L["FS_HOLD_POLL_MIN_DESC"] = "按住輪詢速率的下限。較小值反應更靈敏但可能漏掉輸入。" -- MT
L["FS_HOLD_NOTE"] =
    "Hold Mode 使用未使用的原生按鈕,讓您按住按鍵以重複。在序列編輯器中針對每個序列開啟。" -- MT
L["FS_HOLD_TOGGLED_ON"] = "%s 的 Hold Mode 已啟用" -- MT
L["FS_HOLD_TOGGLED_OFF"] = "%s 的 Hold Mode 已停用" -- MT
L["FS_HOLD_SEQ_TOGGLE"] = "Hold Mode" -- MT
L["FS_HOLD_SEQ_TOGGLE_DESC"] =
    "對此序列使用 hold-to-cast 而非連點。需要在 Faster, Slower 設定中啟用 Hold Mode。" -- MT
L["FS_TEMPO_JUST_RIGHT"] = "剛剛好" -- MT
L["FS_TEMPO_FASTER"] = "更快" -- MT
L["FS_TEMPO_FASTER_URGENT"] = "更快!" -- MT
L["FS_ALERT_DISABLED"] = "不符警示已停用" -- MT
L["FS_ADJUSTED"] = "依您的遊玩資料調整建議" -- MT
L["FS_WASTED_CLICKS"] = "%d / %d 次點擊/秒被浪費" -- MT

-- Phase 4 item 21 Phase B per-element theming editor
L["ACCESS_THEMING_EDITOR_NAME"] = "每元素主題" -- MT
L["ACCESS_THEMING_EDITOR_DESC"] = "微調每個 UI 元素類別的顏色、alpha、字型和大小。" -- MT
L["ACCESS_THEMING_SWATCH_ADVANCED"] = "色票" -- MT
L["ACCESS_THEMING_FIELD_BG"] = "背景顏色" -- MT
L["ACCESS_THEMING_FIELD_BORDER"] = "邊框顏色" -- MT
L["ACCESS_THEMING_FIELD_TEXT"] = "文字顏色" -- MT
L["ACCESS_THEMING_FIELD_ALPHA"] = "Alpha" -- MT
L["ACCESS_THEMING_FIELD_FONT"] = "字型" -- MT

L["ACCESS_THEMING_FIELD_FONT_DESC"] =
    "在這裡選擇字型會將此文字元素固定為所選字型和大小,繞過暴雪的 UIFontSize CVar 和 EMS 的 UI 縮放。其他 EMS 文字會持續以兩者縮放。" -- MT
L["ACCESS_THEMING_FIELD_SIZE"] = "大小" -- MT
L["ACCESS_THEMING_FIELD_BG_TEXTURE"] = "背景材質" -- MT
L["ACCESS_THEMING_FIELD_BG_TEXTURE_DESC"] = "選擇平鋪背景圖像。留空以保持實心顏色填充。" -- MT
L["ACCESS_THEMING_FIELD_BORDER_TEXTURE"] = "邊框材質" -- MT
L["ACCESS_THEMING_FIELD_BORDER_TEXTURE_DESC"] = "選擇邊框樣式。留空以保持細的預設邊框。" -- MT
L["ACCESS_THEMING_RESET_CLASS"] = "重置" -- MT
L["ACCESS_THEMING_RESET_CLASS_DESC"] = "移除此元素的覆寫並回退至預設。" -- MT
L["ACCESS_THEMING_GROUP_PANELS"] = "面板" -- MT
L["ACCESS_THEMING_GROUP_OVERLAYS"] = "疊層" -- MT
L["ACCESS_THEMING_GROUP_ROWS"] = "列" -- MT
L["ACCESS_THEMING_GROUP_BUTTONS"] = "按鈕" -- MT
L["ACCESS_THEMING_GROUP_TEXT"] = "文字" -- MT
L["ACCESS_THEMING_GROUP_EMPHASIS"] = "強調" -- MT
L["ACCESS_THEMING_GROUP_GLOBAL"] = "全域" -- MT
L["ACCESS_THEMING_SLOTS_HEADER"] = "已儲存主題" -- MT
L["ACCESS_THEMING_SLOTS_DESC"] = "儲存最多五個主題並切換。" -- MT
L["ACCESS_THEMING_SLOT_NAME"] = "名稱" -- MT
L["ACCESS_THEMING_SLOT_SAVE"] = "儲存" -- MT
L["ACCESS_THEMING_SLOT_LOAD"] = "載入" -- MT
L["ACCESS_THEMING_SLOT_RENAME"] = "重新命名" -- MT
L["ACCESS_THEMING_SLOT_CLEAR"] = "清除" -- MT
L["ACCESS_THEMING_SLOT_CLEAR_CONFIRM"] = "清除此欄位?" -- MT
L["ACCESS_THEMING_SLOT_EMPTY"] = "(空)" -- MT
L["ACCESS_THEMING_SLOT_DEFAULT_NAME"] = "主題 %d" -- MT
L["ACCESS_THEMING_SLOT_OVERWRITE_CONFIRM"] = "覆寫欄位 %d (%s)?" -- MT
L["ACCESS_THEMING_IMPORTEXPORT_HEADER"] = "匯入 / 匯出" -- MT
L["ACCESS_THEMING_EXPORT_LABEL"] = "匯出" -- MT
L["ACCESS_THEMING_IMPORT_LABEL"] = "匯入" -- MT

L["ACCESS_THEMING_IMPORT_APPLY"] = "套用匯入" -- MT
L["ACCESS_THEMING_IMPORT_OK"] = "主題已匯入。" -- MT
L["ACCESS_THEMING_IMPORT_FAIL"] = "匯入失敗" -- MT
L["ACCESS_THEMING_PRESET_HEADER"] = "預設" -- MT
L["ACCESS_THEMING_PRESET_LABEL"] = "預設" -- MT
L["ACCESS_THEMING_PRESET_DEFAULT"] = "預設" -- MT
L["ACCESS_THEMING_PRESET_HIGH_CONTRAST"] = "高對比" -- MT
L["ACCESS_THEMING_PRESET_CUSTOM"] = "自訂" -- MT
L["ACCESS_THEMING_RESET_ALL"] = "全部重置" -- MT
L["ACCESS_THEMING_RESET_ALL_DESC"] = "清除每個元素覆寫並還原所選預設。" -- MT
L["ACCESS_THEMING_RESET_ALL_CONFIRM"] = "將每個主題覆寫重置為預設?" -- MT
L["ACCESS_THEMING_COPY_ALL_PROFILES"] = "複製到所有設定檔" -- MT
L["ACCESS_THEMING_COPY_ALL_PROFILES_DESC"] = "將目前主題套用至每個 EMS 設定檔。" -- MT
L["ACCESS_THEMING_COPY_ALL_CONFIRM"] = "將目前主題複製到每個設定檔?" -- MT
L["ACCESS_THEMING_FOOTER_HEADER"] = "" -- MT
L["ACCESS_THEMING_MODAL_TITLE"] = "GRIP-EMS 每元素主題" -- MT
L["ACCESS_THEMING_MODAL_DESC"] =
    "自訂每個 EMS 面板、按鈕、列、文字和疊層類別。變更即時套用並依設定檔儲存。" -- MT
L["ACCESS_THEMING_MODAL_COMBAT_BLOCKED"] = "戰鬥中主題編輯器隱藏。" -- MT
L["ACCESS_THEMING_SLASH_HINT"] = "開啟每元素主題編輯器。" -- MT
L["ACCESS_THEMING_CONTRAST_WARN_TITLE"] = "對比警告" -- MT
L["ACCESS_THEMING_CONTRAST_WARN_TEXT"] =
    "%s 上的文字 %s 為 %.1f:1 (AA 要求 %.1f:1)。低視力使用者可能無法閱讀。" -- MT
L["ACCESS_THEMING_CONTRAST_WARN_UI"] = "UI %s 對 %s 為 %.1f:1 (要求 3:1)。" -- MT
L["ACCESS_THEMING_CONTRAST_LOW_ALPHA"] = "低 alpha: %s 為 %.2f (低於 0.3,可能不可見)。" -- MT
L["ACCESS_THEMING_CONTRAST_TEXTURE_UNKNOWN"] = "%s 的對比檢查已停用 -- %s 使用自訂背景材質。" -- MT
L["ACCESS_THEMING_TEXTURE_MISSING"] = "EMS: 主題材質 '%s' 無法使用。回退至預設材質。" -- MT
L["ACCESS_THEMING_CONTRAST_DISMISS"] = "關閉 (30 分鐘)" -- MT
L["ACCESS_THEMING_CONTRAST_AUTOFIX"] = "自動修復背景" -- MT

L["ACCESS_THEMING_CONTRAST_BADGE_PASS"] = "|TInterface\\RAIDFRAME\\ReadyCheck-Ready:12:12|t" -- MT
L["ACCESS_THEMING_CONTRAST_BADGE_FAIL"] = "|TInterface\\RAIDFRAME\\ReadyCheck-NotReady:12:12|t" -- MT
L["ACCESS_THEMING_CONTRAST_QUEUE_MORE"] = "+%d 更多" -- MT
L["ACCESS_THEMING_CONTRAST_SILENCE_HEADER"] = "已靜音對比" -- MT
L["ACCESS_THEMING_CONTRAST_SILENCE_HEADER_BADGE"] = "已靜音對比 (%d)" -- MT
L["ACCESS_THEMING_CONTRAST_SILENCE_EMPTY"] = "目前沒有對比警告被靜音。" -- MT
L["ACCESS_THEMING_CONTRAST_SILENCE_REMAINING"] = "%s -- 剩餘 %d 分鐘" -- MT
L["ACCESS_THEMING_CONTRAST_SILENCE_UNSILENCE"] = "取消靜音" -- MT
L["ACCESS_THEMING_CONTRAST_SILENCE_UNSILENCE_ALL"] = "全部取消靜音" -- MT
L["ACCESS_THEMING_CONTRAST_SILENCE_UNSILENCE_ALL_CONFIRM"] =
    "為所有 %d 個已靜音類別清除靜音?它們將在下次主題套用或 /reload 時再次警告。" -- MT
L["ACCESS_THEMING_CHATLINK_INSERT"] = "插入聊天連結" -- MT
L["ACCESS_THEMING_CHATLINK_INSERT_DESC"] =
    "將可點擊主題連結插入作用中聊天編輯框。接收者點擊以預覽和套用。" -- MT
L["ACCESS_THEMING_CHATLINK_NO_EDITBOX"] = "請先開啟聊天編輯框,然後點擊插入聊天連結。" -- MT
L["ACCESS_THEMING_CHATLINK_NO_RECEIVER"] = "%s 未安裝 EMS。" -- MT
L["ACCESS_THEMING_CHATLINK_OWN_LINK"] = "那是您自己的主題連結。與其他玩家分享以傳送。" -- MT
L["ACCESS_THEMING_CHATLINK_RECEIVE_PROMPT"] = "接受來自 %s 的主題?" -- MT
L["ACCESS_THEMING_CHATLINK_TIMEOUT"] = "主題傳輸逾時。" -- MT
L["ACCESS_THEMING_CHATLINK_VERSION_MISMATCH"] = "此主題來自較新的 EMS 版本。請更新 EMS 並再試。" -- MT
L["ACCESS_THEMING_CHATLINK_DOS_BLOCK"] = "EMS: 主題傳輸被拒絕。發送者宣稱過多區塊。" -- MT
L["ACCESS_THEMING_CHATLINK_REALM_BLOCK"] = "EMS: 主題連結發送者位於未連接的伺服器。已忽略點擊。" -- MT
L["ACCESS_THEMING_CHATLINK_RATE_LIMIT"] = "EMS: 對該玩家近期主題請求過多。請稍後再試。" -- MT
L["ACCESS_THEMING_INSPECT_ENTER_HINT"] =
    "檢查模式已開啟。將滑鼠移過任何 EMS 框架以查看其主題類別。按 Escape 退出。" -- MT
L["ACCESS_THEMING_INSPECT_NO_CLASS"] = "此框架上無 EMS 類別。" -- MT
L["ACCESS_THEMING_INSPECT_MODE_BUTTON"] = "檢查模式" -- MT
L["ACCESS_THEMING_INSPECT_TOOLTIP_HINT"] = "點擊主題化的 EMS 框架以開啟編輯器並捲動到該類別。" -- MT

-- Sound cues (item 14)
L["ACCESS_SOUND_SECTION_NAME"] = "聲音提示" -- MT
L["ACCESS_SOUND_SECTION_DESC"] =
    "驗證結果和序列觸發的短音訊提示。其他外掛用 SharedMedia 註冊的任何聲音都會出現在下方下拉選單。預設停用。" -- MT
L["ACCESS_SOUND_ENABLED_LABEL"] = "啟用聲音提示" -- MT
L["ACCESS_SOUND_ENABLED_DESC"] =
    "開啟以播放驗證錯誤、成功、資訊提示和序列步驟的短音訊提示。" -- MT
L["ACCESS_SOUND_CHANNEL_LABEL"] = "聲音頻道" -- MT
L["ACCESS_SOUND_CHANNEL_DESC"] = "哪個暴雪音訊頻道播放提示。音量遵循您遊戲內頻道滑桿。" -- MT
L["ACCESS_SOUND_CUE_ERROR_LABEL"] = "錯誤提示" -- MT
L["ACCESS_SOUND_CUE_ERROR_DESC"] = "失敗時播放 -- 不良匯入、損壞序列或無效專精。" -- MT
L["ACCESS_SOUND_CUE_SUCCESS_LABEL"] = "成功提示" -- MT
L["ACCESS_SOUND_CUE_SUCCESS_DESC"] = "成功儲存、匯入和驗證通過時播放。" -- MT
L["ACCESS_SOUND_CUE_INFO_LABEL"] = "資訊提示" -- MT
L["ACCESS_SOUND_CUE_INFO_DESC"] = "資訊提示時播放 -- 首次執行通知、檢查點訊息。" -- MT
L["ACCESS_SOUND_CUE_STEP_LABEL"] = "步驟提示" -- MT
L["ACCESS_SOUND_CUE_STEP_DESC"] =
    "序列推進至下一步時播放。每半秒最多播放一次,讓快速序列不會洗音訊。" -- MT
L["ACCESS_SOUND_PREVIEW_LABEL"] = "播放" -- MT
L["ACCESS_SOUND_VISUAL_LABEL"] = "聲音提示的視覺閃爍" -- MT
L["ACCESS_SOUND_VISUAL_DESC"] =
    "聲音提示觸發時顯示短暫的中央閃爍。獨立於音訊切換,因此聾人和重聽使用者可以使用視覺而無需聲音。閃爍顏色告訴您是哪個提示: 紅色為錯誤,綠色為成功,青色為資訊,金色為步驟完成。" -- MT
-- Per-cue Blizzard channel routing (Phase 4 item 22 Phase 2)
L["ACCESS_SOUND_CHANNEL_PER_CUE_DESC"] =
    "為此特定提示選擇暴雪音訊頻道。音量遵循 WoW 聲音選項中的頻道滑桿。" -- MT
L["ACCESS_SOUND_CHANNEL_ERROR_LABEL"] = "錯誤頻道" -- MT
L["ACCESS_SOUND_CHANNEL_SUCCESS_LABEL"] = "成功頻道" -- MT
L["ACCESS_SOUND_CHANNEL_INFO_LABEL"] = "資訊頻道" -- MT
L["ACCESS_SOUND_CHANNEL_STEP_LABEL"] = "步驟頻道" -- MT

-- Cursor overlay (item 15)
L["ACCESS_CURSOR_SECTION_NAME"] = "游標疊層" -- MT
L["ACCESS_CURSOR_SECTION_DESC"] =
    "在滑鼠游標周圍繪製彩色環或十字準星,使其更容易找到。顏色遵循作用中的對比預設。" -- MT
L["ACCESS_CURSOR_ENABLED_LABEL"] = "啟用游標疊層" -- MT
L["ACCESS_CURSOR_ENABLED_DESC"] = "開啟或關閉游標疊層。" -- MT
L["ACCESS_CURSOR_MODE_LABEL"] = "疊層形狀" -- MT
L["ACCESS_CURSOR_MODE_DESC"] = "選擇環或十字準星。" -- MT
L["ACCESS_CURSOR_MODE_RING"] = "環" -- MT
L["ACCESS_CURSOR_MODE_CROSSHAIR"] = "十字準星" -- MT
L["ACCESS_CURSOR_SIZE_LABEL"] = "疊層大小" -- MT
L["ACCESS_CURSOR_SIZE_DESC"] = "選擇 1x、1.5x 或 2x 預設大小。" -- MT
L["ACCESS_CURSOR_SIZE_1X"] = "1x" -- MT
L["ACCESS_CURSOR_SIZE_15X"] = "1.5x" -- MT
L["ACCESS_CURSOR_SIZE_2X"] = "2x" -- MT
L["ACCESS_CURSOR_COLOR_INFO"] = "疊層顏色遵循作用中對比預設的焦點環顏色。" -- MT

-- Feedback and accessibility resources (item 17 / A11Y-DEFER-16)
L["ACCESS_FEEDBACK_SECTION_NAME"] = "輔助使用資源與意見回饋" -- MT
L["ACCESS_FEEDBACK_SECTION_DESC"] =
    "輔助使用標準連結、WoW 社群紀念碑,以及回報問題或分享意見的地方。" -- MT
L["ACCESS_FEEDBACK_APX_LABEL"] = "AbleGamers APX" -- MT
L["ACCESS_FEEDBACK_APX_DESC"] = "AbleGamers Accessible Player Experiences 框架。開啟可複製連結。" -- MT
L["ACCESS_FEEDBACK_GAG_LABEL"] = "Game Accessibility Guidelines" -- MT
L["ACCESS_FEEDBACK_GAG_DESC"] = "讓遊戲輔助使用的社群框架。開啟可複製連結。" -- MT
L["ACCESS_FEEDBACK_IBELIN_LABEL"] = "紀念 Ibelin" -- MT
L["ACCESS_FEEDBACK_IBELIN_DESC"] =
    "Mats Steen 1989-2014。WoW 玩家的紀念網站,他的故事重新定義了這個遊戲的意義。開啟可複製連結。" -- MT
L["ACCESS_FEEDBACK_DISCORD_LABEL"] = "回報輔助使用問題" -- MT
L["ACCESS_FEEDBACK_DISCORD_DESC"] =
    "開啟 GRIP Discord 的可複製連結,您可在此回報輔助使用問題或分享意見。" -- MT
L["ACCESS_FEEDBACK_POPUP_TEXT"] = "複製此連結以在瀏覽器中開啟:" -- MT

L["ACCESS_GUIDE_SECTION_NAME"] = "輔助使用指南" -- MT
L["ACCESS_GUIDE_SECTION_DESC"] =
    "完整輔助使用文件位於外掛根目錄的 ACCESSIBILITY.md。互動式指南於線上輔助使用區段有摘要。" -- MT
L["ACCESS_GUIDE_BUTTON_LABEL"] = "開啟互動式指南" -- MT
L["ACCESS_GUIDE_BUTTON_DESC"] = "開啟彈出視窗,顯示互動式指南連結,讓您可以用 Ctrl+C 複製。" -- MT

-- Large-target density (item 16 / A11Y-DEFER-14)
L["ACCESS_DENSITY_SECTION_NAME"] = "大型互動目標" -- MT
L["ACCESS_DENSITY_SECTION_DESC"] =
    "讓按鈕、核取方塊和分頁等可點擊目標更容易點擊。將點擊區域增長至 WCAG 2.5.5 的最低 44 x 44 像素而不變更視覺大小。" -- MT
L["ACCESS_DENSITY_TOGGLE_LABEL"] = "增大點擊區域" -- MT
L["ACCESS_DENSITY_TOGGLE_DESC"] =
    "增長分頁、核取方塊和對話方塊按鈕的點擊區域。視覺大小保持不變。立即套用至開啟的視窗。" -- MT
L["ACCESS_DENSITY_RELOAD_HINT"] =
    "點擊區域增加會立即套用。某些序列編輯器列僅在您關閉並重新開啟編輯器後才會接收變更。" -- MT

-- Simplified Mode (item 18 / A11Y-DEFER-17)
L["ACCESS_SIMPLIFIED_SECTION_NAME"] = "簡化模式" -- MT
L["ACCESS_SIMPLIFIED_SECTION_DESC"] =
    "將編輯器收合為最小介面,適用於切換器、眼動追蹤器和單按鈕使用者。" -- MT
L["ACCESS_SIMPLIFIED_TOGGLE_LABEL"] = "啟用簡化模式" -- MT
L["ACCESS_SIMPLIFIED_TOGGLE_DESC"] =
    "將編輯器減少為四個 Tab 可達控制項 -- 步驟分頁、動作條、標題列和執行按鈕。最佳搭配大型密度和 UI 縮放 1.25 或更高。" -- MT
L["ACCESS_SIMPLIFIED_DELAY_LABEL"] = "接受後延遲 (ms)" -- MT
L["ACCESS_SIMPLIFIED_DELAY_DESC"] =
    "啟動之間的冷卻。500 ms 符合 Game Accessibility Guidelines 動作進階。為較強顫動或切換彈跳提高。" -- MT
L["ACCESS_SIMPLIFIED_FIRST_ENABLE_HINT"] =
    "簡化模式作用中。使用 Tab、Shift+Tab、Enter、Space 和 Escape 來導覽。" -- MT

L["ACCESS_SIMPLIFIED_RELOAD_HINT"] = "簡化模式已套用。為獲得最佳結果,切換後請輸入 /reload。" -- MT
L["ACCESS_SIMPLIFIED_DENSITY_REJECT"] = "簡化模式需要大型目標。請先關閉簡化模式。" -- MT
L["ACCESS_SIMPLIFIED_SCALE_REJECT"] = "簡化模式需要 UI 縮放 1.25 或更高。關閉簡化模式以降低。" -- MT
L["ACCESS_SIMPLIFIED_UNLOCK_BUTTON"] = "解鎖編輯器" -- MT
L["ACCESS_SIMPLIFIED_RUN_BUTTON"] = "執行序列" -- MT

-- Phase G.7 (G23): ReloadGate
L["RELOAD_GATE_POPUP_TITLE"] = "EMS - 重新載入以完整套用" -- MT
L["RELOAD_GATE_POPUP_BODY"] =
    "在 %d 個動作中套用了 %d 個設定變更。立即重新載入以使變更完全生效,或繼續而不重新載入。\n\n%s" -- MT
L["RELOAD_GATE_RELOAD_NOW"] = "立即重新載入" -- MT
L["RELOAD_GATE_LATER"] = "稍後" -- MT
L["RELOAD_GATE_TOOLTIP_TITLE"] = "EMS - 待處理變更" -- MT
L["RELOAD_GATE_TOOLTIP_NONE"] = "無待處理變更。" -- MT
L["RELOAD_GATE_TOOLTIP_HINT"] = "點擊查看詳情" -- MT
L["RELOAD_GATE_CAUSE_AUTOFIX"] = "登入時自動修復" -- MT
L["RELOAD_GATE_CAUSE_FIX_ALL_CRIT"] = "修復所有關鍵" -- MT
L["RELOAD_GATE_CAUSE_FIX_ALL_SEC"] = "修復區段中所有" -- MT
L["RELOAD_GATE_CAUSE_PER_ROW_FIX"] = "修復個別設定" -- MT
L["RELOAD_GATE_CAUSE_PER_ROW_SET"] = "設定自訂值" -- MT
L["RELOAD_GATE_CAUSE_RESET_DEFS"] = "重置為預設" -- MT
L["RELOAD_GATE_CAUSE_PROFILE_SWP"] = "設定檔交換" -- MT
L["RELOAD_GATE_CAUSE_PROFILE_IMP"] = "設定檔匯入" -- MT
L["RELOAD_GATE_CAUSE_OOC_QUEUED"] = "已加入佇列 (戰鬥)" -- MT
L["RELOAD_GATE_CAUSE_OOC_APPLIED"] = "已套用 (戰鬥後)" -- MT

-- G8-AUDIT-04 / -10 / -14 / -19 / -27 / -36 / -50 (G.8c.2 TTS coverage)
-- These strings are spoken aloud by TTS and emitted to chat. Plain
-- language only. No marketing tone. No em dashes. Short sentences.
L["ACCESS_ANNOUNCE_RELOAD_PENDING"] = "重新載入待處理" -- MT
L["ACCESS_ANNOUNCE_S18_EXPORT_READY"] = "%s 的匯出已就緒。按 Control C 複製。" -- MT
L["ACCESS_ANNOUNCE_S18_IMPORT_OK"] = "設定檔已匯入為 %s。%d 個設定。" -- MT

L["ACCESS_ANNOUNCE_S18_IMPORT_ERROR"] = "匯入失敗。%s" -- MT
L["ACCESS_ANNOUNCE_S18_DELETE_CONFIRM"] = "刪除 %s?確認或取消。" -- MT
L["ACCESS_ANNOUNCE_CVAR_FIX"] = "已修復 %s 為 %s" -- MT
L["ACCESS_ANNOUNCE_CVAR_SET"] = "%s 設為 %s" -- MT
L["ACCESS_ANNOUNCE_CVAR_UNDO"] = "%s 已還原為 %s" -- MT
L["ACCESS_ANNOUNCE_CVAR_REDO"] = "%s reapplied to %s" -- MT
L["ACCESS_ANNOUNCE_CVAR_PIN_ON"] = "%s 已釘選" -- MT
L["ACCESS_ANNOUNCE_CVAR_PIN_OFF"] = "%s 已取消釘選" -- MT
L["ACCESS_ANNOUNCE_CVAR_AUTOFIX_ON"] = "%s 自動修復開啟" -- MT
L["ACCESS_ANNOUNCE_CVAR_AUTOFIX_OFF"] = "%s 自動修復關閉" -- MT
L["ACCESS_ANNOUNCE_CVAR_FIXALL_BUSY"] = "正在修復 %d 個設定" -- MT
L["ACCESS_ANNOUNCE_CVAR_FIXALL_DONE"] = "已修復 %d 個設定" -- MT
L["ACCESS_ANNOUNCE_TOGGLE_REDUCE_MOTION_ON"] = "減少動態開啟" -- MT
L["ACCESS_ANNOUNCE_TOGGLE_REDUCE_MOTION_OFF"] = "減少動態關閉" -- MT
L["ACCESS_ANNOUNCE_TOGGLE_FLICKER_SAFE_ON"] = "防閃爍模式開啟" -- MT
L["ACCESS_ANNOUNCE_TOGGLE_FLICKER_SAFE_OFF"] = "防閃爍模式關閉" -- MT
L["ACCESS_ANNOUNCE_TOGGLE_SPEECH_ENABLED_ON"] = "語音開啟" -- MT
L["ACCESS_ANNOUNCE_TOGGLE_SPEECH_ENABLED_OFF"] = "語音關閉" -- MT
L["ACCESS_ANNOUNCE_TOGGLE_CHAT_EMITTER_ON"] = "聊天發送開啟" -- MT
L["ACCESS_ANNOUNCE_TOGGLE_CHAT_EMITTER_OFF"] = "聊天發送關閉" -- MT
-- G.9: cvarHealth numbered-key + skip-to-issues nav announcements.
L["ACCESS_ANNOUNCE_SECTION_JUMP"] = "區段 %d / %d: %s" -- MT
L["ACCESS_ANNOUNCE_ISSUE_JUMP"] = "問題 %d / %d: %s" -- MT

-- v2.1.0 Authorship Integrity (Phase A): English values stubbed, awaiting MT pass.
L["GEMS_AUTHOR_LOCKED_TOOLTIP"] =
    "Original Author is set on creation and cannot be changed. Use Fork to create your own version." -- MT
L["GEMS_AUTHOR_ORIGINAL_LABEL"] = "Original Author" -- MT
L["GEMS_AUTHOR_LAST_MODIFIED_LABEL"] = "Last modified by" -- MT
L["GEMS_AUTHOR_CREATED_AT"] = "Created" -- MT
L["GEMS_AUTHOR_LAST_MODIFIED_VALUE"] = "%s on %s" -- MT
L["GEMS_PROVENANCE_UNKNOWN"] = "Provenance unknown" -- MT
L["GEMS_PROVENANCE_UNKNOWN_TOOLTIP"] =
    "No signature on file. Sequence predates v2.1.0 or was imported from a source without provenance." -- MT
L["GEMS_PROVENANCE_LEGACY_IMPORT"] = "Legacy import" -- MT
L["GEMS_PROVENANCE_LEGACY_IMPORT_TOOLTIP"] = "Imported from a legacy format. Original author: %s (unverified)." -- MT
L["GEMS_PROVENANCE_FORGE_IMPORT"] = "Forge import" -- MT
L["GEMS_PROVENANCE_FORGE_IMPORT_TOOLTIP"] = "Built with GRIP Forge. Attribution: %s (unverified)." -- MT

-- v2.1.0 Authorship Integrity (Phase B): English values stubbed, awaiting MT pass.
L["GEMS_PROVENANCE_VERIFIED"] = "Verified" -- MT
L["GEMS_PROVENANCE_VERIFIED_TOOLTIP"] = "Signature matches. This is the unmodified original." -- MT
L["GEMS_PROVENANCE_MODIFIED"] = "Modified" -- MT
L["GEMS_PROVENANCE_MODIFIED_TOOLTIP"] = "Original signature intact. Modifier chain has %d entries." -- MT
L["GEMS_PROVENANCE_TAMPERED"] = "Tampered" -- MT
L["GEMS_PROVENANCE_TAMPERED_TOOLTIP"] = "Signature mismatch. Provenance fields may have been edited outside the addon." -- MT
L["GEMS_PROVENANCE_DAMAGED"] = "Damaged" -- MT
L["GEMS_PROVENANCE_DAMAGED_TOOLTIP"] =
    "Provenance fields present but signature missing. SavedVariables file may be partially corrupted." -- MT
L["GEMS_PROVENANCE_FORKED_BADGE"] = "Forked" -- MT
L["GEMS_PROVENANCE_FORKED_TOOLTIP"] = "This sequence was forked from another author. See chain for details." -- MT
L["GEMS_AUTHOR_MODIFIER_CHAIN_HEADER"] = "Modification chain" -- MT

-- v2.1.0 Authorship Integrity (Phase C): English values stubbed, awaiting MT pass.
L["GEMS_FORK_BUTTON"] = "Fork" -- MT
L["GEMS_FORK_TOOLTIP"] =
    "Create a new sequence based on this one, with you as the Original Author. The original sequence is unchanged." -- MT
L["GEMS_FORK_DIALOG_TITLE"] = "Fork sequence" -- MT
L["GEMS_FORK_DIALOG_BODY"] =
    "Forking '%s' creates a new sequence with you as the Original Author. Enter a name for the fork:" -- MT
L["GEMS_FORK_CONFIRM"] = "Fork '%s' as a new sequence?" -- MT
L["GEMS_PROVENANCE_SHOW_ALL_CHAIN"] = "Show all (%d)" -- MT

-- v2.1.0 Authorship Integrity (Phase C polish): English values stubbed, awaiting MT pass.
L["GEMS_AUTHOR_FORKED_FROM_LABEL"] = "Forked from" -- MT
L["GEMS_AUTHOR_FORKED_FROM_VALUE"] = "%s on %s" -- MT
L["GEMS_AUTHOR_FORKED_FROM_CHAIN_TRUNCATE"] = "(+%d more)" -- MT
L["GEMS_AUTHOR_FORK_LINEAGE_HEADER"] = "Fork lineage" -- MT

-- v2.1.0 Authorship Integrity (Phase D): English values stubbed, awaiting MT pass.
L["GEMS_PRIVACY_GROUP_NAME"] = "Authorship Privacy" -- MT
L["GEMS_PRIVACY_MODE_LABEL"] = "Privacy mode" -- MT
L["GEMS_PRIVACY_MODE_PUBLIC"] = "Public" -- MT
L["GEMS_PRIVACY_MODE_PSEUDONYMOUS"] = "Pseudonymous" -- MT
L["GEMS_PRIVACY_MODE_PRIVATE"] = "Private" -- MT
L["GEMS_PRIVACY_DEFAULT_LABEL"] = "Default privacy mode for new sequences" -- MT
L["GEMS_PRIVACY_DEFAULT_DESC"] = "New sequences inherit this privacy mode unless overridden per-sequence." -- MT
L["GEMS_PRIVACY_PSEUDONYM_LABEL"] = "Pseudonym" -- MT
L["GEMS_PRIVACY_PSEUDONYM_DESC"] =
    "Display name used in pseudonymous-mode exports. Identity hash is preserved so receivers can link sequences from the same author." -- MT
L["GEMS_PRIVACY_SHOW_BADGES_LABEL"] = "Show provenance badges in sequence list" -- MT
L["GEMS_PRIVACY_SHOW_BADGES_DESC"] = "Render the small verification badge next to each sequence row." -- MT

-- ===========================================================================
-- L372 Wave 10a+10b: 14 CVar option labels + descLong (2026-05-19, MT)
-- ===========================================================================

L["GEMS_CVAR_COMBAT_SOFTENEMY_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBAT_SOFTENEMY_OPT_1"] = "Gamepad only" -- MT
L["GEMS_CVAR_COMBAT_SOFTENEMY_OPT_2"] = "Mouse and keyboard only" -- MT
L["GEMS_CVAR_COMBAT_SOFTENEMY_OPT_3"] = "Always (gamepad and KBM)" -- MT
L["GEMS_CVAR_COMBAT_SOFTENEMY_DESCLONG"] =
    "Sets the soft-target highlight for enemies -- the ghosted unit frame that appears when you face an enemy without clicking it. Off disables it. Gamepad only lights it up when a controller is bound. Mouse and keyboard only restricts it to KBM input, an unusual pick. Always (the EMS recommendation) shows it for both input modes, which gives KBM players the same on-the-fly target hint controller players already get." -- MT

L["GEMS_CVAR_COMBAT_SOFTFRIEND_OPT_2"] = "Mouse and keyboard only" -- MT
L["GEMS_CVAR_COMBAT_SOFTFRIEND_OPT_3"] = "Always (gamepad and KBM)" -- MT

L["GEMS_CVAR_SOLO_INTERACT_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_SOLO_INTERACT_OPT_1"] = "Gamepad only" -- MT
L["GEMS_CVAR_SOLO_INTERACT_OPT_2"] = "Mouse and keyboard only" -- MT
L["GEMS_CVAR_SOLO_INTERACT_OPT_3"] = "Always (gamepad and KBM)" -- MT
L["GEMS_CVAR_SOLO_INTERACT_DESCLONG"] =
    "Sets the soft-target highlight for interactable objects -- NPCs, mailboxes, ore nodes, herbs, quest items. Off disables it. Gamepad only lights up the nearest interactable when a controller is bound. Mouse and keyboard only restricts it to KBM input. Always (the EMS recommendation) shows it for both input modes, which keeps controller and KBM behaviour the same and helps you spot quest objects you might otherwise click past." -- MT

L["GEMS_CVAR_RAIDING_THREATWARN_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_RAIDING_THREATWARN_OPT_1"] = "Progressive (warning text)" -- MT
L["GEMS_CVAR_RAIDING_THREATWARN_OPT_2"] = "Flashing health bar" -- MT
L["GEMS_CVAR_RAIDING_THREATWARN_OPT_3"] = "Tinted health bar" -- MT
L["GEMS_CVAR_RAIDING_THREATWARN_DESCLONG"] =
    "Sets how nameplates warn you about threat. Off hides the warning entirely. Progressive shows a warning text overlay when your threat ramps. Flashing health bar pulses the nameplate red as a strong visual cue. Tinted health bar (the default, and the EMS recommendation) tints the nameplate fill from yellow through orange to red as your threat percentage climbs -- the same data as flashing but at a glance, without the eye strain." -- MT

L["GEMS_CVAR_RAIDING_DISPTYPE_OPT_0"] = "Hidden" -- MT
L["GEMS_CVAR_RAIDING_DISPTYPE_OPT_1"] = "Only ones I can dispel" -- MT
L["GEMS_CVAR_RAIDING_DISPTYPE_OPT_2"] = "All dispellable debuffs" -- MT
L["GEMS_CVAR_RAIDING_DISPTYPE_DESCLONG"] =
    "Sets which dispellable debuffs show on raid frames. Hidden suppresses the indicator entirely. Only ones I can dispel filters to the debuff types your spec can actually remove, which is the cleanest look for non-healer roles. All dispellable debuffs (the default, and the EMS recommendation) shows everything someone in the group could remove, which is what healers want so they can see which categories their off-healers should be covering." -- MT

L["GEMS_CVAR_COMBAT_SOFTLOCKED_OPT_0"] = "Off (suppress when target is locked)" -- MT
L["GEMS_CVAR_COMBAT_SOFTLOCKED_OPT_1"] = "On (keep showing soft target)" -- MT
L["GEMS_CVAR_COMBAT_SOFTLOCKED_DESCLONG"] =
    "Controls whether the soft-target overlay stays visible while you have a hard target locked. Off suppresses the soft overlay when something is locked, reducing visual noise. On (the default, and the EMS recommendation) keeps the soft-target ghost visible alongside your locked target, which is what you usually want for fast target swaps without re-acquiring." -- MT

L["GEMS_CVAR_COMBAT_SOFTMATCH_OPT_0"] = "Off (always use soft target if unlocked)" -- MT
L["GEMS_CVAR_COMBAT_SOFTMATCH_OPT_1"] = "On (prefer soft target that matches your locked target)" -- MT
L["GEMS_CVAR_COMBAT_SOFTMATCH_DESCLONG"] =
    "Controls how the soft-target picks a candidate when you already have a hard target locked. Off lets the soft target choose freely based on your aim cone. On (the default, and the EMS recommendation) biases the soft target towards whatever you have locked, which keeps your soft and hard targets aligned for actions that prefer the hard target while leaving room to glance at others nearby." -- MT

L["GEMS_CVAR_COMBAT_SOFTRANGE_OPT_20"] = "20 yards (melee plus a small buffer)" -- MT
L["GEMS_CVAR_COMBAT_SOFTRANGE_OPT_30"] = "30 yards (close ranged)" -- MT
L["GEMS_CVAR_COMBAT_SOFTRANGE_OPT_45"] = "45 yards (standard ranged)" -- MT
L["GEMS_CVAR_COMBAT_SOFTRANGE_OPT_60"] = "60 yards (long ranged)" -- MT
L["GEMS_CVAR_COMBAT_SOFTRANGE_OPT_100"] = "100 yards (extreme range)" -- MT
L["GEMS_CVAR_COMBAT_SOFTRANGE_DESCLONG"] =
    "Sets the maximum distance for the enemy soft-target pick. Lower values keep the soft target focused on the closest enemies and ignore distant mobs you cannot reach. 45 yards (the default, and the EMS recommendation) matches the standard spell range for most ranged DPS specs, so soft target picks the same mobs your finishers can actually hit. Raise it for hunters or balance druids who want to acquire targets at long range; lower it for melee specs who do not want to lock onto far-away mobs." -- MT

L["GEMS_CVAR_COMBAT_FRIENDRANGE_OPT_20"] = "20 yards (melee plus a small buffer)" -- MT
L["GEMS_CVAR_COMBAT_FRIENDRANGE_OPT_30"] = "30 yards (close ranged)" -- MT
L["GEMS_CVAR_COMBAT_FRIENDRANGE_OPT_45"] = "45 yards (standard ranged)" -- MT
L["GEMS_CVAR_COMBAT_FRIENDRANGE_OPT_60"] = "60 yards (long ranged)" -- MT
L["GEMS_CVAR_COMBAT_FRIENDRANGE_OPT_100"] = "100 yards (extreme range)" -- MT
L["GEMS_CVAR_COMBAT_FRIENDRANGE_DESCLONG"] =
    "Sets the maximum distance for the friendly soft-target pick. Lower values keep the soft target on nearby allies; higher values let the soft target reach distant party members. 45 yards (the default, and the EMS recommendation) matches the standard heal range, which is the most useful value for healers who lean on soft targeting. Raise it for druids or priests with longer-range heals; drop it for melee healers who only care about the immediate group cluster." -- MT

L["GEMS_CVAR_SOLO_INTERRANGE_OPT_5"] = "5 yards (right next to you)" -- MT
L["GEMS_CVAR_SOLO_INTERRANGE_OPT_10"] = "10 yards (one step away)" -- MT
L["GEMS_CVAR_SOLO_INTERRANGE_OPT_15"] = "15 yards (a short walk)" -- MT
L["GEMS_CVAR_SOLO_INTERRANGE_OPT_20"] = "20 yards (visible nearby)" -- MT
L["GEMS_CVAR_SOLO_INTERRANGE_OPT_30"] = "30 yards (full screen visible)" -- MT
L["GEMS_CVAR_SOLO_INTERRANGE_DESCLONG"] =
    "Sets the maximum distance the soft-target picker uses for interactable objects -- ore nodes, herbs, mailboxes, NPCs, quest items. 10 yards (the default, and the EMS recommendation) matches the actual interact range the game enforces, so the soft target only lights up when you can actually reach the object. Raising it gives you an earlier visual hint that something is nearby but you still need to walk into actual interact range to use it; useful for quest hubs or gathering zones where you want a heads-up. Lower it if soft targeting is grabbing too many objects in dense areas." -- MT

L["GEMS_CVAR_COMBAT_PROCOPACITY_OPT_025"] = "25% (barely visible)" -- MT
L["GEMS_CVAR_COMBAT_PROCOPACITY_OPT_050"] = "50% (subdued)" -- MT
L["GEMS_CVAR_COMBAT_PROCOPACITY_OPT_065"] = "65% (default)" -- MT
L["GEMS_CVAR_COMBAT_PROCOPACITY_OPT_085"] = "85% (strong)" -- MT
L["GEMS_CVAR_COMBAT_PROCOPACITY_OPT_100"] = "100% (full)" -- MT
L["GEMS_CVAR_COMBAT_PROCOPACITY_DESCLONG"] =
    "Sets the opacity of the spell-activation glow -- the coloured aura that lights up around your action bars when a proc is ready (Tidal Waves, Hot Streak, Spotlight, and so on). 65% (the default, and the EMS recommendation) is bright enough to catch your eye without overpowering the action-bar icons. Lower it if the glow is distracting; raise it if you keep missing procs on a busy UI." -- MT

L["GEMS_CVAR_FCT_DIRSCALE_OPT_070"] = "70% (subtle)" -- MT
L["GEMS_CVAR_FCT_DIRSCALE_OPT_085"] = "85% (small)" -- MT
L["GEMS_CVAR_FCT_DIRSCALE_OPT_100"] = "100% (default)" -- MT
L["GEMS_CVAR_FCT_DIRSCALE_OPT_125"] = "125% (large)" -- MT
L["GEMS_CVAR_FCT_DIRSCALE_OPT_150"] = "150% (exaggerated)" -- MT
L["GEMS_CVAR_FCT_DIRSCALE_DESCLONG"] =
    "Sets how much the floating-combat-text numbers grow when damage comes from a specific direction. 100% (the default, and the EMS recommendation) shows numbers at their normal size. Lower values tamp down the directional emphasis if combat text is cluttering your view. Higher values exaggerate hits from your front and sides, useful for tanks who use damage direction as a positional cue." -- MT

L["GEMS_CVAR_SOLO_LOOTRATE_OPT_50"] = "50 ms (snappy)" -- MT
L["GEMS_CVAR_SOLO_LOOTRATE_OPT_100"] = "100 ms (fast)" -- MT
L["GEMS_CVAR_SOLO_LOOTRATE_OPT_150"] = "150 ms (Blizzard default)" -- MT
L["GEMS_CVAR_SOLO_LOOTRATE_OPT_250"] = "250 ms (relaxed)" -- MT
L["GEMS_CVAR_SOLO_LOOTRATE_OPT_500"] = "500 ms (slow)" -- MT
L["GEMS_CVAR_SOLO_LOOTRATE_DESCLONG"] =
    "Sets the polling interval for auto-loot in milliseconds. Lower values process loot pickups faster but check the loot system more often. 50 ms (the EMS recommendation) makes auto-loot feel near-instant on a single corpse and matters most during mass mob clears where you skim past dozens of bodies. 150 ms is the Blizzard default and is fine for normal play. Higher values are mainly useful if you are hunting CPU savings on a weak machine." -- MT

L["GEMS_CVAR_DUNGEON_LOGTIME_OPT_60"] = "1 minute (very short)" -- MT
L["GEMS_CVAR_DUNGEON_LOGTIME_OPT_180"] = "3 minutes (short)" -- MT
L["GEMS_CVAR_DUNGEON_LOGTIME_OPT_300"] = "5 minutes (default)" -- MT
L["GEMS_CVAR_DUNGEON_LOGTIME_OPT_600"] = "10 minutes (long)" -- MT
L["GEMS_CVAR_DUNGEON_LOGTIME_OPT_1800"] = "30 minutes (very long)" -- MT
L["GEMS_CVAR_DUNGEON_LOGTIME_DESCLONG"] =
    "Sets how long the in-memory combat log keeps events before discarding them. 5 minutes (the default, and the EMS recommendation) covers most boss fights with margin for trash before. Raise it for long fights where you want to scrub back through several pulls worth of events; drop it on weaker hardware where the in-memory log is causing FPS dips during heavy AoE." -- MT

L["GEMS_CVAR_UI_TUTORIALS_OPT_0"] = "Off (hide tutorial pop-ups)" -- MT
L["GEMS_CVAR_UI_TUTORIALS_OPT_1"] = "On (show tutorial pop-ups)" -- MT
L["GEMS_CVAR_UI_TUTORIALS_DESCLONG"] =
    "Controls whether Blizzard's tutorial pop-ups appear as you play. Off (the EMS recommendation) hides them entirely, which is what most players past their first character want. On (the default) shows the standard tutorial prompts Blizzard added to teach UI features." -- MT

L["GEMS_CVAR_UI_NPE_OPT_0"] = "Off (skip new-player overlays)" -- MT
L["GEMS_CVAR_UI_NPE_OPT_1"] = "On (show new-player overlays)" -- MT
L["GEMS_CVAR_UI_NPE_DESCLONG"] =
    "Controls whether the New Player Experience overlays appear during early-level questing. Off (the EMS recommendation) hides the NPE prompts, which are aimed at brand-new accounts and feel intrusive on alts. On (the default) shows the full NPE walkthrough Blizzard ships for first-time players." -- MT

L["GEMS_CVAR_UI_LOADTIPS_OPT_0"] = "Off (blank loading screen)" -- MT
L["GEMS_CVAR_UI_LOADTIPS_OPT_1"] = "On (show tips during loading)" -- MT
L["GEMS_CVAR_UI_LOADTIPS_DESCLONG"] =
    "Shows helpful tips on the loading screen while you wait for a zone to finish loading. Off leaves the loading bar blank. On (the default, and the EMS recommendation) shows rotating tips and lore snippets, which makes loading screens less dead time. This setting resets each time you log in and does not persist across sessions." -- MT

L["GEMS_CVAR_UI_COMPARE_OPT_0"] = "Off (require Shift to compare)" -- MT
L["GEMS_CVAR_UI_COMPARE_OPT_1"] = "On (always show comparison)" -- MT
L["GEMS_CVAR_UI_COMPARE_DESCLONG"] =
    "Controls whether item tooltips automatically show a side-by-side comparison with whatever you currently have equipped. Off requires Shift while hovering to bring up the compare panel. On (the default, and the EMS recommendation) always shows comparisons, which saves a keypress every time you loot or browse the auction house." -- MT

L["GEMS_CVAR_UI_TOOLTIPS_OPT_0"] = "Off (basic tooltip text)" -- MT
L["GEMS_CVAR_UI_TOOLTIPS_OPT_1"] = "On (full stats and details)" -- MT
L["GEMS_CVAR_UI_TOOLTIPS_DESCLONG"] =
    "Controls how much detail item and ability tooltips show. Off uses a stripped-down tooltip with only the basics. On (the default, and the EMS recommendation) shows full stats, item level, slot type, and set-bonus information, which is what every modern UI relies on." -- MT

L["GEMS_CVAR_UI_TRANSMOG_OPT_0"] = "Off (no appearance highlight)" -- MT
L["GEMS_CVAR_UI_TRANSMOG_OPT_1"] = "On (tag unknown appearances)" -- MT
L["GEMS_CVAR_UI_TRANSMOG_DESCLONG"] =
    "Highlights items whose appearance you have not yet collected for transmog. Off (the default) gives no indication. On (the EMS recommendation) tags missing-appearance gear directly in item tooltips, which is what transmog collectors want when running old content. This is a per-character setting, since alts can be at different points in the collection." -- MT

L["GEMS_CVAR_UI_EDGEFLASH_OPT_0"] = "Off (no edge flash)" -- MT
L["GEMS_CVAR_UI_EDGEFLASH_OPT_1"] = "On (flash at low health)" -- MT
L["GEMS_CVAR_UI_EDGEFLASH_DESCLONG"] =
    "Controls the red flash around the screen edges when you take heavy damage or your health drops low. Off removes the flash entirely. On (the default, and the EMS recommendation) keeps the visual cue, which is a useful low-attention warning when you are focused on your rotation instead of your health bar." -- MT

L["GEMS_CVAR_UI_BUBBLES_OPT_0"] = "Off (no floating speech)" -- MT
L["GEMS_CVAR_UI_BUBBLES_OPT_1"] = "On (show floating speech bubbles)" -- MT
L["GEMS_CVAR_UI_BUBBLES_DESCLONG"] =
    "Controls whether NPC and player chat appears as floating speech bubbles over their heads in addition to the chat frame. Off only shows messages in the chat window. On (the default, and the EMS recommendation) adds the floating bubbles, which makes it easier to follow conversations in busy areas without watching the chat log." -- MT

L["GEMS_CVAR_UI_BIGNUMS_OPT_0"] = "Off (raw digits like 1234567)" -- MT
L["GEMS_CVAR_UI_BIGNUMS_OPT_1"] = "On (grouped digits like 1,234,567)" -- MT
L["GEMS_CVAR_UI_BIGNUMS_DESCLONG"] =
    "Adds thousand separators (commas or periods, depending on locale) to large numbers in tooltips and the UI. Off shows raw digit strings like 1234567. On (the default, and the EMS recommendation) shows 1,234,567, which is much easier to read at a glance for damage numbers, gold totals, and item stats." -- MT

L["GEMS_CVAR_UI_BUFFDUR_OPT_0"] = "Off (no countdown on icons)" -- MT
L["GEMS_CVAR_UI_BUFFDUR_OPT_1"] = "On (show seconds remaining)" -- MT
L["GEMS_CVAR_UI_BUFFDUR_DESCLONG"] =
    "Shows the seconds remaining on buff and debuff icons in the default UI. Off shows only the icon and stack count. On (the default, and the EMS recommendation) overlays a countdown timer, which is what you want for tracking cooldown durations, stack timers, and time-sensitive buffs." -- MT

L["GEMS_CVAR_UI_FSTACK_OPT_0"] = "Off (no debug overlay)" -- MT
L["GEMS_CVAR_UI_FSTACK_OPT_1"] = "On (show frame stack debug)" -- MT
L["GEMS_CVAR_UI_FSTACK_DESCLONG"] =
    "Toggles the frame stack debug overlay, a tool that shows which UI frame is under your mouse cursor. Off (the default, and the EMS recommendation) is what every player wants. On is a developer aid for troubleshooting an addon UI bug. This resets each session and does not persist." -- MT

L["GEMS_CVAR_UI_RAWMOUSE_OPT_0"] = "Off (standard mouse path)" -- MT
L["GEMS_CVAR_UI_RAWMOUSE_OPT_1"] = "On (bypass OS acceleration)" -- MT
L["GEMS_CVAR_UI_RAWMOUSE_DESCLONG"] =
    "Toggles raw mouse input mode, which bypasses Windows pointer acceleration and reads input directly from the device. Off (the default, and the EMS recommendation) uses the standard mouse path, which is what nearly every player wants. On is a niche option for players who prefer a 1:1 input feel and have already disabled OS acceleration. This resets each session." -- MT

L["GEMS_CVAR_UI_TAINT_OPT_0"] = "Off (no taint logging)" -- MT
L["GEMS_CVAR_UI_TAINT_OPT_1"] = "On (write taint events to disk)" -- MT
L["GEMS_CVAR_UI_TAINT_DESCLONG"] =
    "Toggles taint logging, which writes UI taint events to a file for addon debugging. Off (the default, and the EMS recommendation) keeps taint logging silent. On is for addon authors investigating taint chains and adds disk I/O. This resets each session." -- MT

L["GEMS_CVAR_UI_BAGS_OPT_0"] = "Off (separate bag windows)" -- MT
L["GEMS_CVAR_UI_BAGS_OPT_1"] = "On (single combined bag)" -- MT
L["GEMS_CVAR_UI_BAGS_DESCLONG"] =
    "Controls whether the bag UI shows as a single combined window or as separate panels per bag. Off (the default) gives you four separate bag frames. On (the EMS recommendation) merges everything into one combined window, which is the modern bag UI Blizzard added in Dragonflight." -- MT

L["GEMS_CVAR_UI_ROTATEMM_OPT_0"] = "Off (north stays at top)" -- MT
L["GEMS_CVAR_UI_ROTATEMM_OPT_1"] = "On (rotates with facing)" -- MT
L["GEMS_CVAR_UI_ROTATEMM_DESCLONG"] =
    "Controls whether the minimap rotates as you turn your character or stays fixed with north at the top. Off (the default, and the EMS recommendation) keeps north pinned, which makes the minimap behave like a map you would read on a table. On rotates it so the top always points the direction you face, which some players find more intuitive but most experienced players find disorienting." -- MT

-- L372 Wave 12: Section 7 non-toggle CVars + WAVE10c SoftTargetArc trio (2026-05-19)
L["GEMS_CVAR_UI_SSFORMAT_OPT_JPEG"] = "JPEG (small files, lossy)" -- MT
L["GEMS_CVAR_UI_SSFORMAT_OPT_PNG"] = "PNG (lossless, mid size)" -- MT
L["GEMS_CVAR_UI_SSFORMAT_OPT_TGA"] = "TGA (lossless, large files)" -- MT
L["GEMS_CVAR_UI_SSFORMAT_DESCLONG"] =
    "File format the game writes to your Screenshots folder. JPEG keeps file size down at the cost of compression artefacts. TGA and PNG are lossless. EMS picks TGA because guides and transmog comparisons need pixel-accurate screenshots." -- MT
L["GEMS_CVAR_UI_SSQUALITY_OPT_01"] = "1 (lowest)" -- MT
L["GEMS_CVAR_UI_SSQUALITY_OPT_03"] = "3 (default)" -- MT
L["GEMS_CVAR_UI_SSQUALITY_OPT_05"] = "5 (medium)" -- MT
L["GEMS_CVAR_UI_SSQUALITY_OPT_08"] = "8 (high)" -- MT
L["GEMS_CVAR_UI_SSQUALITY_OPT_10"] = "10 (max)" -- MT
L["GEMS_CVAR_UI_SSQUALITY_DESCLONG"] =
    "JPEG compression quality, 1 to 10. Lower values produce smaller files with more visible artefacts. Has no effect when screenshotFormat is set to TGA or PNG, since those formats are already lossless. If you stay on JPEG, 10 is the right pick." -- MT
L["GEMS_CVAR_UI_ZOOM_OPT_100"] = "1.0 (15 yards)" -- MT
L["GEMS_CVAR_UI_ZOOM_OPT_150"] = "1.5 (22.5 yards)" -- MT
L["GEMS_CVAR_UI_ZOOM_OPT_190"] = "1.9 (28.5 yards, default)" -- MT
L["GEMS_CVAR_UI_ZOOM_OPT_220"] = "2.2 (33 yards)" -- MT
L["GEMS_CVAR_UI_ZOOM_OPT_260"] = "2.6 (39 yards, max)" -- MT
L["GEMS_CVAR_UI_ZOOM_DESCLONG"] =
    "Multiplier on the camera's max zoom-out distance. The engine caps at 2.6, which gives roughly 39 yards out from the player. The default 1.9 (28.5 yards) feels cramped on melee classes trying to see swirly mechanics at the edge of the screen. EMS picks the max." -- MT
L["GEMS_CVAR_UI_COMBOPT_OPT_1"] = "On target" -- MT
L["GEMS_CVAR_UI_COMBOPT_OPT_2"] = "On player (below resource bar)" -- MT
L["GEMS_CVAR_UI_COMBOPT_DESCLONG"] =
    "Where the combo-point UI element draws. Set to 1 to show points above the targeted unit's nameplate; 2 (the default) shows them on the player below the personal resource display. EMS keeps the default." -- MT
L["GEMS_CVAR_COMBAT_SOFTARC_OPT_0"] = "Straight ahead only" -- MT
L["GEMS_CVAR_COMBAT_SOFTARC_OPT_1"] = "Front arc" -- MT
L["GEMS_CVAR_COMBAT_SOFTARC_OPT_2"] = "Anywhere in tab area" -- MT
L["GEMS_CVAR_COMBAT_SOFTARC_DESCLONG"] =
    "How wide the yaw arc is for picking a soft-target enemy. 0 only selects mobs directly in front of you. 1 selects within a narrow front arc. 2 selects anywhere in the tab-target search area. Default and recommended is 2 for the widest catch." -- MT
L["GEMS_CVAR_COMBAT_FRIENDARC_OPT_0"] = "Straight ahead only" -- MT
L["GEMS_CVAR_COMBAT_FRIENDARC_OPT_1"] = "Front arc" -- MT
L["GEMS_CVAR_COMBAT_FRIENDARC_OPT_2"] = "Anywhere in targeting area" -- MT
L["GEMS_CVAR_COMBAT_FRIENDARC_DESCLONG"] =
    "How wide the yaw arc is for picking a soft-target friendly. Mirrors the enemy version: 0 directly ahead, 1 narrow front arc, 2 anywhere in the targeting area. Default and recommended is 2." -- MT
L["GEMS_CVAR_SOLO_INTERARC_OPT_0"] = "Straight ahead only" -- MT
L["GEMS_CVAR_SOLO_INTERARC_OPT_1"] = "Front arc" -- MT
L["GEMS_CVAR_SOLO_INTERARC_OPT_2"] = "Anywhere in targeting area" -- MT
L["GEMS_CVAR_SOLO_INTERARC_DESCLONG"] =
    "How wide the yaw arc is for the interact (Tab-to-loot, NPC click) softtarget. The default 0 only catches things directly in front, which often misses corpses or NPCs at a slight angle. EMS picks 1 (the narrow front arc), wider than the default but narrow enough to avoid accidental selection." -- MT
L["GEMS_CVAR_MACRO_KEYHELD_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_MACRO_KEYHELD_OPT_1"] = "On" -- MT
L["GEMS_CVAR_MACRO_KEYHELD_DESCLONG"] =
    "Activates the press-and-hold cast option on key-down. When On, holding the key past the cast triggers an error-retry path some macros use for repeat-cast behaviour. Default Off works for almost everyone." -- MT
L["GEMS_CVAR_MACRO_AUTOSTAND_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_MACRO_AUTOSTAND_OPT_1"] = "On" -- MT
L["GEMS_CVAR_MACRO_AUTOSTAND_DESCLONG"] =
    "Automatically stands your character when you cast a spell that requires standing. With this Off you have to /stand by hand before any seated cast works. Leave On unless you want strict seated control." -- MT
L["GEMS_CVAR_MACRO_AUTOUNSHIFT_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_MACRO_AUTOUNSHIFT_OPT_1"] = "On" -- MT
L["GEMS_CVAR_MACRO_AUTOUNSHIFT_DESCLONG"] =
    "Automatically leaves your shapeshift form (Druid form, Warrior stance, Evoker hover) when you cast a spell that cannot be cast in the current form. With this Off the cast fails and you have to shift out by hand. Leave On for normal play." -- MT
L["GEMS_CVAR_MACRO_STOPATTACK_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_MACRO_STOPATTACK_OPT_1"] = "On" -- MT
L["GEMS_CVAR_MACRO_STOPATTACK_DESCLONG"] =
    "Stops your auto-attack when you switch targets. With this On a target swap makes you stop swinging; you have to re-engage with /startattack. The default Off keeps you swinging through target swaps. This is a per-character setting." -- MT
L["GEMS_CVAR_MACRO_ICONRATE_OPT_000"] = "0 sec (every frame)" -- MT
L["GEMS_CVAR_MACRO_ICONRATE_OPT_005"] = "0.05 sec (responsive)" -- MT
L["GEMS_CVAR_MACRO_ICONRATE_OPT_010"] = "0.10 sec (default)" -- MT
L["GEMS_CVAR_MACRO_ICONRATE_OPT_025"] = "0.25 sec (low overhead)" -- MT
L["GEMS_CVAR_MACRO_ICONRATE_OPT_050"] = "0.50 sec (very low overhead)" -- MT
L["GEMS_CVAR_MACRO_ICONRATE_DESCLONG"] =
    "How often the assisted-combat action-bar icon refreshes, in seconds. Lower values are more responsive but cost a small amount of CPU each frame; higher values save CPU at the cost of a slightly slower icon swap. EMS recommends 0.05 which keeps the icon snappy without measurable overhead." -- MT
L["GEMS_CVAR_MACRO_CDCOUNT_OPT_0"] = "Off (radial swipe)" -- MT
L["GEMS_CVAR_MACRO_CDCOUNT_OPT_1"] = "On (number countdown)" -- MT
L["GEMS_CVAR_MACRO_CDCOUNT_DESCLONG"] =
    "Replaces the spinning radial cooldown overlay on action buttons with a numeric countdown. The Blizzard default is the radial swipe; EMS recommends the number countdown because it is easier to read at a glance while watching a sequence run." -- MT
L["GEMS_CVAR_MACRO_SECTOGGLE_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_MACRO_SECTOGGLE_OPT_1"] = "On" -- MT
L["GEMS_CVAR_MACRO_SECTOGGLE_DESCLONG"] =
    "Protects you from accidentally double-clicking a toggle ability (Shadow Form, Skirmisher, etc.) and turning it back off. With this Off a fast double-click can deactivate the toggle; the default On treats the second click as a no-op. Leave On for normal play." -- MT
L["GEMS_CVAR_MACRO_EMPTAP_OPT_0"] = "Off (press-hold-release)" -- MT
L["GEMS_CVAR_MACRO_EMPTAP_OPT_1"] = "On (tap-tap)" -- MT
L["GEMS_CVAR_MACRO_EMPTAP_DESCLONG"] =
    "Evoker only. Changes how Empower spells trigger. Default Off uses press-hold-release: hold the key to charge stages, release to fire. On switches to a tap-tap scheme where each tap advances the stage. Pick the scheme that matches your macros. This is a per-character setting." -- MT
L["GEMS_CVAR_MACRO_EMPHOLD_OPT_000"] = "0.00 (release any time)" -- MT
L["GEMS_CVAR_MACRO_EMPHOLD_OPT_025"] = "0.25 (release after 25%)" -- MT
L["GEMS_CVAR_MACRO_EMPHOLD_OPT_050"] = "0.50 (release after 50%)" -- MT
L["GEMS_CVAR_MACRO_EMPHOLD_OPT_075"] = "0.75 (release after 75%)" -- MT
L["GEMS_CVAR_MACRO_EMPHOLD_OPT_100"] = "1.00 (full first stage required)" -- MT
L["GEMS_CVAR_MACRO_EMPHOLD_DESCLONG"] =
    "Evoker only. Sets the minimum portion of an Empower spell's first stage you must hold before a release is accepted. The default 1.00 requires the full first stage to elapse before any release fires; lower values let you release earlier at the cost of accidental misfires. Tune this if Empower macros feel like they release too early or too late." -- MT
L["GEMS_CVAR_MACRO_PRECAST_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_MACRO_PRECAST_OPT_1"] = "On" -- MT
L["GEMS_CVAR_MACRO_PRECAST_DESCLONG"] =
    "Enables preemptive cast visuals: the cast animation can begin before the spell release timing fully confirms. This resets each session and does not persist across logouts. Leave Off unless you are testing visual latency." -- MT
L["GEMS_CVAR_NAMEPLATES_SHOWALL_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_SHOWALL_OPT_1"] = "On" -- MT
L["GEMS_CVAR_NAMEPLATES_SHOWALL_DESCLONG"] =
    "Turns on every nameplate category at once: enemies, friendly NPCs, pets, guardians, and totems. The individual category toggles below still apply -- this is the master switch. EMS recommends On because nameplates are the primary mechanic-tracking surface in modern WoW; the Blizzard default Off was set when nameplates were a niche feature." -- MT
L["GEMS_CVAR_NAMEPLATES_SHOWSELF_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_SHOWSELF_OPT_1"] = "On" -- MT
L["GEMS_CVAR_NAMEPLATES_SHOWSELF_DESCLONG"] =
    "Shows the personal resource display: a nameplate floating below your character with your own health and resource. EMS recommends On because resource-gated rotations are easier to read off the personal plate than the unit frame. This is a per-character setting." -- MT
L["GEMS_CVAR_NAMEPLATES_CASTBARS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_CASTBARS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_NAMEPLATES_CASTBARS_DESCLONG"] =
    "Shows cast bars under each unit nameplate so you can see what mob is casting and when. On is the default and the right answer for almost every player; Off only makes sense if you have a dedicated cast tracker that draws over the nameplates. This is a per-character setting." -- MT
L["GEMS_CVAR_NAMEPLATES_CLASSCOLOR_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_CLASSCOLOR_OPT_1"] = "On" -- MT
L["GEMS_CVAR_NAMEPLATES_CLASSCOLOR_DESCLONG"] =
    "Colours enemy player nameplate health bars by class so you can spot a Mage vs a Warrior at a glance. On is the default. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_NAMEPLATES_DEBUFFS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_DEBUFFS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_NAMEPLATES_DEBUFFS_DESCLONG"] =
    "Shows debuff icons on friendly nameplates so you can see who needs a dispel or a cleanse. On is the default. Turn Off only if you run a dedicated raid frame that already surfaces these debuffs. This is a per-character setting." -- MT
L["GEMS_CVAR_NAMEPLATES_MINIONS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_MINIONS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_NAMEPLATES_MINIONS_DESCLONG"] =
    "Shows nameplates for enemy minions (Warlock pets, Hunter pets, Death Knight pets, mage water-elemental, etc.). Off is the default and keeps PvE clutter down. Turn On for PvP where you may want to focus a pet to cleave its owner." -- MT
L["GEMS_CVAR_NAMEPLATES_MINUS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_MINUS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_NAMEPLATES_MINUS_DESCLONG"] =
    "Shows nameplates for trash mobs marked as weaker than you (the minus-sign mobs in the world). On is the default and you want it on for any AoE-tagging or open-world farming." -- MT
L["GEMS_CVAR_NAMEPLATES_TOTEMS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_TOTEMS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_NAMEPLATES_TOTEMS_DESCLONG"] =
    "Shows nameplates for enemy totems. EMS recommends On because hostile totems carry mechanic-critical information (Storm Totem damage, Healing Stream Totem healing, Capacitor Totem stun timer); the Blizzard default Off hides them behind the totem 3D model." -- MT
L["GEMS_CVAR_NAMEPLATES_FRIENDLY_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_FRIENDLY_OPT_1"] = "On" -- MT
L["GEMS_CVAR_NAMEPLATES_FRIENDLY_DESCLONG"] =
    "Shows nameplates for friendly players (your raid, your party, your guild). Off is the default and the right answer in raids -- friendly nameplates carry an FPS cost because each plate processes aura updates whether the plate is visible or not. Turn On only in BG/Arena where you want to track friendly positions." -- MT
L["GEMS_CVAR_NAMEPLATES_NAMEONLY_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_NAMEONLY_OPT_1"] = "On" -- MT
L["GEMS_CVAR_NAMEPLATES_NAMEONLY_DESCLONG"] =
    "When On, friendly player nameplates collapse to just the name (no health bar, no resource bar). Pairs naturally with friendly-nameplates being On. Off is the default. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_NAMEPLATES_ATBASE_OPT_0"] = "Off (overhead)" -- MT
L["GEMS_CVAR_NAMEPLATES_ATBASE_OPT_1"] = "On (at base)" -- MT
L["GEMS_CVAR_NAMEPLATES_ATBASE_DESCLONG"] =
    "Positions nameplates at the unit's feet (On) rather than over its head (Off, default). Some players prefer base-positioned plates because they line up with ground swirls and AoE markers, but the default overhead position keeps the plate clear of ground effects." -- MT
L["GEMS_CVAR_NAMEPLATES_OFFSCREEN_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_OFFSCREEN_OPT_1"] = "On" -- MT
L["GEMS_CVAR_NAMEPLATES_OFFSCREEN_DESCLONG"] =
    "Keeps a nameplate visible at the edge of your screen when its owner is in combat with you or with someone in your group, even if the unit itself is off-screen. Off is the default. On is useful in fights where you must track a mob you cannot see (back-camera bosses, ranged adds)." -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTNP_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTNP_OPT_1"] = "On" -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTNP_DESCLONG"] =
    "Forces a nameplate to always be visible on your soft enemy target (the auto-acquired target you have not hard-clicked yet). On is the default and pairs with the soft-targeting system from the Combat section." -- MT
L["GEMS_CVAR_NAMEPLATES_RADIAL_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_RADIAL_OPT_1"] = "Target Only" -- MT
L["GEMS_CVAR_NAMEPLATES_RADIAL_OPT_2"] = "All In Combat" -- MT
L["GEMS_CVAR_NAMEPLATES_RADIAL_DESCLONG"] =
    "When a unit is off-screen, this setting decides whether to draw its nameplate radially around the edges of your screen instead of hiding it. Off (default) hides off-screen plates. Target Only draws a plate at the edge for your current target. All In Combat draws plates at the edges for every unit you are fighting -- useful when you must track several mobs at once but can be visually busy." -- MT
L["GEMS_CVAR_NAMEPLATES_MINALPHA_OPT_020"] = "0.2 (very faded)" -- MT
L["GEMS_CVAR_NAMEPLATES_MINALPHA_OPT_040"] = "0.4 (faded)" -- MT
L["GEMS_CVAR_NAMEPLATES_MINALPHA_OPT_060"] = "0.6 (default)" -- MT
L["GEMS_CVAR_NAMEPLATES_MINALPHA_OPT_080"] = "0.8 (readable)" -- MT
L["GEMS_CVAR_NAMEPLATES_MINALPHA_OPT_100"] = "1.0 (fully opaque)" -- MT
L["GEMS_CVAR_NAMEPLATES_MINALPHA_DESCLONG"] =
    "Sets the minimum opacity (alpha) of nameplates as they fade with distance. A nameplate fades from MaxAlpha at the close range down to MinAlpha at the far edge. EMS recommends 0.8 because the Blizzard default 0.6 lets distant plates drop to a hard-to-read 60% opacity; 0.8 keeps the text legible at every range while preserving the visual distance cue. This is a per-character setting." -- MT
L["GEMS_CVAR_NAMEPLATES_MAXALPHA_OPT_060"] = "0.6 (subtle)" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXALPHA_OPT_075"] = "0.75" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXALPHA_OPT_085"] = "0.85" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXALPHA_OPT_095"] = "0.95" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXALPHA_OPT_100"] = "1.0 (fully opaque)" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXALPHA_DESCLONG"] =
    "Sets the maximum opacity (alpha) of nameplates at close range. The default 1.0 is fully opaque and the right choice for almost everyone. Lower values bake in a permanent see-through look that pairs with very low MinAlpha for an art-style preference; there is no gameplay reason to drop it. This is a per-character setting." -- MT
L["GEMS_CVAR_NAMEPLATES_MINSCALE_OPT_050"] = "0.5 (very small)" -- MT
L["GEMS_CVAR_NAMEPLATES_MINSCALE_OPT_065"] = "0.65" -- MT
L["GEMS_CVAR_NAMEPLATES_MINSCALE_OPT_080"] = "0.8 (default)" -- MT
L["GEMS_CVAR_NAMEPLATES_MINSCALE_OPT_100"] = "1.0 (no shrink)" -- MT
L["GEMS_CVAR_NAMEPLATES_MINSCALE_OPT_120"] = "1.2 (larger far)" -- MT
L["GEMS_CVAR_NAMEPLATES_MINSCALE_DESCLONG"] =
    "Sets the minimum size of distant nameplates. The default 0.8 shrinks far plates to 80% of MaxScale so they read as smaller in the depth cue. Setting MinScale equal to MaxScale (e.g. both 1.0) disables the depth-scaling entirely so every plate is the same size at every range. This is a per-character setting." -- MT
L["GEMS_CVAR_NAMEPLATES_MAXSCALE_OPT_080"] = "0.8 (small)" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXSCALE_OPT_090"] = "0.9" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXSCALE_OPT_100"] = "1.0 (default)" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXSCALE_OPT_110"] = "1.1" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXSCALE_OPT_120"] = "1.2 (large)" -- MT
L["GEMS_CVAR_NAMEPLATES_MAXSCALE_DESCLONG"] =
    "Sets the maximum size of nameplates at close range. The default 1.0 is the baseline. Larger values make close plates more readable at the cost of more screen real estate; smaller values keep the screen cleaner but cost some legibility. This is a per-character setting." -- MT
L["GEMS_CVAR_NAMEPLATES_SELSCALE_OPT_100"] = "1.0 (no bump)" -- MT
L["GEMS_CVAR_NAMEPLATES_SELSCALE_OPT_110"] = "1.1" -- MT
L["GEMS_CVAR_NAMEPLATES_SELSCALE_OPT_120"] = "1.2 (default)" -- MT
L["GEMS_CVAR_NAMEPLATES_SELSCALE_OPT_130"] = "1.3" -- MT
L["GEMS_CVAR_NAMEPLATES_SELSCALE_OPT_150"] = "1.5 (big bump)" -- MT
L["GEMS_CVAR_NAMEPLATES_SELSCALE_DESCLONG"] =
    "Sets the scale multiplier applied to the currently selected unit's nameplate. The default 1.2 enlarges your target's plate to 120% so it stands out in a crowd. Setting this to 1.0 disables the bump entirely; higher values make the target plate even more prominent. This is a per-character setting." -- MT
L["GEMS_CVAR_NAMEPLATES_OCCLUDED_OPT_020"] = "0.2 (mostly hidden)" -- MT
L["GEMS_CVAR_NAMEPLATES_OCCLUDED_OPT_040"] = "0.4 (default)" -- MT
L["GEMS_CVAR_NAMEPLATES_OCCLUDED_OPT_060"] = "0.6 (visible)" -- MT
L["GEMS_CVAR_NAMEPLATES_OCCLUDED_OPT_080"] = "0.8 (clear)" -- MT
L["GEMS_CVAR_NAMEPLATES_OCCLUDED_OPT_100"] = "1.0 (no fade)" -- MT
L["GEMS_CVAR_NAMEPLATES_OCCLUDED_DESCLONG"] =
    "Alpha multiplier applied to nameplates of targets behind walls or terrain (occluded line-of-sight). The Blizzard default 0.4 fades occluded plates down to 40% which is hard to track. EMS recommends 0.6 because tracking a mob you cannot directly see is exactly when you need its plate readable -- think peeling adds around a pillar, or a healer hiding behind a doorway in PvP. Setting this to 1.0 disables the fade entirely if you want full visibility. This is a per-character setting." -- MT
L["GEMS_CVAR_NAMEPLATES_AURASCALE_OPT_080"] = "0.8 (compact)" -- MT
L["GEMS_CVAR_NAMEPLATES_AURASCALE_OPT_100"] = "1.0 (default)" -- MT
L["GEMS_CVAR_NAMEPLATES_AURASCALE_OPT_120"] = "1.2 (larger)" -- MT
L["GEMS_CVAR_NAMEPLATES_AURASCALE_OPT_140"] = "1.4 (big)" -- MT
L["GEMS_CVAR_NAMEPLATES_AURASCALE_OPT_160"] = "1.6 (very big)" -- MT
L["GEMS_CVAR_NAMEPLATES_AURASCALE_DESCLONG"] =
    "Sets the size multiplier for the buff and debuff icons that show on each nameplate. EMS recommends 1.2 because the default 1.0 icons can vanish behind the unit name when several auras stack, and 1.2 keeps each icon legible without dominating the plate. Push higher (1.4 or 1.6) if you raid on a 4K display where the default reads small." -- MT
L["GEMS_CVAR_NAMEPLATES_PLAYERDIST_OPT_20"] = "20 yds (close only)" -- MT
L["GEMS_CVAR_NAMEPLATES_PLAYERDIST_OPT_41"] = "41 yds (raid-tuned)" -- MT
L["GEMS_CVAR_NAMEPLATES_PLAYERDIST_OPT_60"] = "60 yds (default)" -- MT
L["GEMS_CVAR_NAMEPLATES_PLAYERDIST_OPT_80"] = "80 yds (long)" -- MT
L["GEMS_CVAR_NAMEPLATES_PLAYERDIST_OPT_100"] = "100 yds (max)" -- MT
L["GEMS_CVAR_NAMEPLATES_PLAYERDIST_DESCLONG"] =
    "Maximum distance at which friendly-player nameplates are drawn. The default 60 yards is the right answer for almost every situation. Raid scenes use 41 yards to match the in-combat range cap, and short-range setups (5-man, PvP) can drop to 20 yards to declutter the screen. The 80 / 100 yard values are useful for outdoor world play or large pulls where you want to spot a friend at extreme range. This is a per-character setting." -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPH_OPT_050"] = "0.5 (tight)" -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPH_OPT_070"] = "0.7" -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPH_OPT_080"] = "0.8 (default)" -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPH_OPT_100"] = "1.0 (loose)" -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPH_OPT_120"] = "1.2 (very loose)" -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPH_DESCLONG"] =
    "Horizontal-overlap factor that controls how aggressively the nameplate engine spreads adjacent plates apart along the X axis. Lower values let plates sit closer together (tighter packing, more overlap); higher values force more horizontal separation. The default 0.8 is a balanced middle ground. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPV_OPT_080"] = "0.8 (tight)" -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPV_OPT_100"] = "1.0" -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPV_OPT_110"] = "1.1 (default)" -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPV_OPT_130"] = "1.3 (loose)" -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPV_OPT_150"] = "1.5 (very loose)" -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPV_DESCLONG"] =
    "Vertical-overlap factor that controls how aggressively the nameplate engine spreads adjacent plates apart along the Y axis. Lower values let plates sit closer together; higher values force more vertical separation. The default 1.1 leaves a small visual gap between stacked plates. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTSIZE_OPT_0"] = "0 (off)" -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTSIZE_OPT_19"] = "19 (default)" -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTSIZE_OPT_25"] = "25 (recommended)" -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTSIZE_OPT_35"] = "35 (large)" -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTSIZE_OPT_50"] = "50 (huge)" -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTSIZE_DESCLONG"] =
    "Size in pixels of the soft-target marker icon that overlays the current soft-target's nameplate. EMS recommends 25 because the Blizzard default 19 reads small on modern displays, especially in dense raid scenes; 25 makes the marker visible at a glance without dominating the plate. Set to 0 to disable the icon entirely if your nameplate addon draws its own target indicator." -- MT
L["GEMS_CVAR_NAMEPLATES_DEBUFFPAD_OPT_0"] = "0 (compact, default)" -- MT
L["GEMS_CVAR_NAMEPLATES_DEBUFFPAD_OPT_2"] = "2 px" -- MT
L["GEMS_CVAR_NAMEPLATES_DEBUFFPAD_OPT_4"] = "4 px" -- MT
L["GEMS_CVAR_NAMEPLATES_DEBUFFPAD_OPT_6"] = "6 px" -- MT
L["GEMS_CVAR_NAMEPLATES_DEBUFFPAD_OPT_8"] = "8 px (loose)" -- MT
L["GEMS_CVAR_NAMEPLATES_DEBUFFPAD_DESCLONG"] =
    "Padding in pixels between the debuff icon row and the health bar on each nameplate. The default 0 packs the row directly against the bar (compact). Higher values insert a gap so the debuffs read as a separate strip; useful on large nameplate scales or 4K displays where the debuff icons sit visually too close to the bar text." -- MT
L["GEMS_CVAR_DRAGON_DYNFOV_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_DRAGON_DYNFOV_OPT_1"] = "On" -- MT
L["GEMS_CVAR_DRAGON_DYNFOV_DESCLONG"] =
    "Widens the camera field of view as your gliding speed increases. On is the default and the right answer for almost every player -- the FOV stretch sells the sensation of speed during a dive. Turn Off if you find the dynamic FOV motion-sickening or if you prefer a fixed-frame look during long flights. This setting resets each session and does not persist across logouts; EMS will re-apply your choice on every login." -- MT
L["GEMS_CVAR_DRAGON_MAXPITCH_OPT_30"] = "3.0 (slow)" -- MT
L["GEMS_CVAR_DRAGON_MAXPITCH_OPT_50"] = "5.0 (default)" -- MT
L["GEMS_CVAR_DRAGON_MAXPITCH_OPT_60"] = "6.0 (recommended)" -- MT
L["GEMS_CVAR_DRAGON_MAXPITCH_OPT_80"] = "8.0 (fast)" -- MT
L["GEMS_CVAR_DRAGON_MAXPITCH_OPT_100"] = "10.0 (very fast)" -- MT
L["GEMS_CVAR_DRAGON_MAXPITCH_DESCLONG"] =
    "Maximum pitch rate when steering Skyriding / Dragonriding with the keyboard. EMS recommends 6.0 because the Blizzard default 5.0 feels sluggish during reactive manoeuvres (avoiding map geometry, chasing a friend's slipstream); 6.0 gives the keyboard pitch parity with a mid-sensitivity mouse without overshooting on small inputs. Lower values give finer precision at the cost of slower turns." -- MT
L["GEMS_CVAR_DRAGON_MAXTURN_OPT_50"] = "5.0 (slow)" -- MT
L["GEMS_CVAR_DRAGON_MAXTURN_OPT_80"] = "8.0 (default)" -- MT
L["GEMS_CVAR_DRAGON_MAXTURN_OPT_100"] = "10.0 (recommended)" -- MT
L["GEMS_CVAR_DRAGON_MAXTURN_OPT_120"] = "12.0 (fast)" -- MT
L["GEMS_CVAR_DRAGON_MAXTURN_OPT_150"] = "15.0 (very fast)" -- MT
L["GEMS_CVAR_DRAGON_MAXTURN_DESCLONG"] =
    "Maximum turn rate when steering Skyriding / Dragonriding with the keyboard. EMS recommends 10.0 because the Blizzard default 8.0 caps your yaw rate below what the dragon can actually execute; 10.0 lets you carve tighter holding patterns around treasure spawns and pull off the half-cobra reversal during PvP duels. Lower values feel safer but cost time on every turn." -- MT
L["GEMS_CVAR_DRAGON_MINPITCH_OPT_15"] = "1.5 (very gentle)" -- MT
L["GEMS_CVAR_DRAGON_MINPITCH_OPT_25"] = "2.5 (default)" -- MT
L["GEMS_CVAR_DRAGON_MINPITCH_OPT_30"] = "3.0 (recommended)" -- MT
L["GEMS_CVAR_DRAGON_MINPITCH_OPT_40"] = "4.0 (sharper)" -- MT
L["GEMS_CVAR_DRAGON_MINPITCH_OPT_50"] = "5.0 (sharpest)" -- MT
L["GEMS_CVAR_DRAGON_MINPITCH_DESCLONG"] =
    "Minimum pitch rate -- the floor that small keyboard taps produce. EMS recommends 3.0 because the Blizzard default 2.5 makes light corrective taps feel mushy; 3.0 gives every tap a noticeable nose change so you can fine-tune your dive angle without overcommitting. Lower values feel more cinematic; higher values feel snappier." -- MT
L["GEMS_CVAR_DRAGON_PITCHCTRL_OPT_1"] = "1 (Forward/Up)" -- MT
L["GEMS_CVAR_DRAGON_PITCHCTRL_OPT_2"] = "2 (Backward/Up)" -- MT
L["GEMS_CVAR_DRAGON_PITCHCTRL_OPT_3"] = "3 (Default, recommended)" -- MT
L["GEMS_CVAR_DRAGON_PITCHCTRL_DESCLONG"] =
    "Helps with hand motor function during Skyriding by remapping which keyboard input pitches your dragon up. Default 3 (Default) uses Blizzard's standard pitch behaviour -- pitch follows mouse and spacebar, forward and backward inputs are used purely for thrust. Set to 1 (Forward/Up) if you want the Move Forward key to also pitch the dragon up (and Move Backward to pitch down) -- useful for players who find combined mouse+forward inputs physically demanding. Set to 2 (Backward/Up) for the inverse mapping (Move Backward pitches up, Move Forward pitches down). Blizzard's official description: \"Helps to address hand motor function while skyriding.\" EMS does not auto-detect your accessibility needs; pick the option that matches your physical comfort." -- MT

-- ExportAsText labels (POLISH-EXPORTASTEXT-LOCALE, Backlog L97)
L["GEMS_EXPORTTEXT_SEQUENCE_LABEL"] = "Sequence: " -- MT
L["GEMS_EXPORTTEXT_AUTHOR_LABEL"] = "Author: " -- MT
L["GEMS_EXPORTTEXT_AUTHOR_UNKNOWN"] = "(unknown)" -- MT
L["GEMS_EXPORTTEXT_SPEC_LABEL"] = "Spec: " -- MT
L["GEMS_EXPORTTEXT_STEPFUNCTION_LABEL"] = "Step Function: " -- MT
L["GEMS_EXPORTTEXT_ICON_LABEL"] = "Icon: " -- MT
L["GEMS_EXPORTTEXT_VERSIONS_LABEL"] = "Versions: " -- MT
L["GEMS_EXPORTTEXT_VARIABLES_HEADING"] = "Variables:" -- MT
L["GEMS_EXPORTTEXT_MACROS_HEADING"] = "Macros:" -- MT
L["GEMS_EXPORTTEXT_VARIABLE_EVENT_SUFFIX"] = " (Event: %s)" -- MT
L["GEMS_EXPORTTEXT_VERSION_HEADING"] = "Version %d:" -- MT
L["GEMS_EXPORTTEXT_VERSION_HEADING_DEFAULT"] = "Version %d (Default):" -- MT
L["GEMS_EXPORTTEXT_RESET_LABEL"] = "  Reset: " -- MT
L["GEMS_EXPORTTEXT_STEPS_HEADING"] = "  Steps:" -- MT
L["GEMS_EXPORTTEXT_STEPS_NONE"] = "    (none)" -- MT
L["GEMS_EXPORTTEXT_ACTIONS_HEADING"] = "  Actions:" -- MT
L["GEMS_EXPORTTEXT_KEYPRESS_LABEL"] = "  Key Press: " -- MT
L["GEMS_EXPORTTEXT_KEYRELEASE_LABEL"] = "  Key Release: " -- MT

-- v2.1.6 Author Picker
L["GEMS_AUTHOR_PICKER_PSEUDONYM"] = "%s (pseudonym)" -- MT
L["GEMS_AUTHOR_PICKER_CURRENT"] = "%s (this character)" -- MT
L["GEMS_AUTHOR_PICKER_ALT"] = "%s (%s)" -- MT

-- v2.2.0 Per-loadout keybinds (L127)
L["GEMS_KEYBINDS_PER_LOADOUT_TOGGLE"] = "Per-loadout keybinds" -- MT
L["GEMS_KEYBINDS_PER_LOADOUT_TOGGLE_TOOLTIP"] =
    "When on, new keybinds bind to the currently active talent loadout. Per-spec keybinds set previously stay as a fallback for loadouts with no override." -- MT
L["GEMS_KEYBINDS_SUPPRESS_IN_LOADOUT"] = "Suppress in this loadout" -- MT
L["GEMS_KEYBINDS_SUPPRESS_IN_LOADOUT_TOOLTIP"] =
    "Hide this per-spec binding while this loadout is active. The binding stays active in other loadouts of this spec." -- MT
L["GEMS_KEYBINDS_ACTIVE_LOADOUT_LABEL"] = "Active loadout: %s" -- MT
L["GEMS_KEYBINDS_NO_ACTIVE_LOADOUT"] = "No active loadout (per-spec bindings only)." -- MT
L["GEMS_KEYBINDS_FALLBACK_NOTICE"] = "Showing per-spec fallback bindings." -- MT
L["GEMS_KEYBINDS_COPY_BUTTON"] = "Copy bindings from another loadout" -- MT
L["GEMS_KEYBINDS_MANAGE_ALL"] = "Manage all loadouts" -- MT
L["GEMS_KEYBINDS_LOADOUT_BINDING_COUNT"] = "%s: %d binding(s)" -- MT
L["GEMS_HELP_BIND_LOADOUT_FLAG"] =
    "  /gems bind <name> <key> [--loadout <id-or-name>] - bind to a specific loadout (default: active loadout if per-loadout mode is on)" -- MT
L["GEMS_BIND_LOADOUT_NOT_FOUND"] = "Loadout '%s' not found for current spec." -- MT
L["GEMS_KEYBINDS_LOADOUT_OVERRIDES_HINT"] = "  + %d loadout(s) with overrides" -- MT
L["GEMS_RESERVED_NAME"] = "Sequence name '%s' is reserved and cannot be used." -- MT

L["GEMS_REPARENT_DEPTH_REJECT"] =
    "無法放置在此處 -- 這會超過最大巢狀深度 (%d)。請將其移動到較淺的迴圈中。" -- TODO: MT 2026-06-21
-- Auto-mirrored from enUS for prefix GEMS_ADD_MENU_DEPTH_CAP_HINT (cowork_util fix-locale-parity 2026-05-25)
L["GEMS_ADD_MENU_DEPTH_CAP_HINT"] =
    "Max nesting depth (%d) reached -- add disabled here. Reduce nesting in a parent container to enable additions." -- MT

-- Auto-mirrored from enUS for prefix GEMS_SETTINGS_CHAR (cowork_util fix-locale-parity 2026-05-25)
L["GEMS_SETTINGS_CHAR_CLICK_RATE_WARN"] = "Your setting: %dms (%dms faster than the %dms human/hardware floor)" -- MT

-- Auto-mirrored from enUS for prefix GEMS_VARIANT_ (cowork_util fix-locale-parity 2026-05-26)
L["GEMS_VARIANT_ADDED"] = "Added variant '%s' to %s (modifier: %s)." -- MT
L["GEMS_VARIANT_BAD_MODIFIER"] = "Invalid modifier '%s'. Must be one of: shift, ctrl, alt." -- MT
L["GEMS_VARIANT_DUP_MODIFIER"] = "Cannot add variant: modifier '%s' already exists on %s." -- MT
L["GEMS_VARIANT_LIST_HEADER"] = "Variants for %s:" -- MT
L["GEMS_VARIANT_LIST_NONE"] = "%s has no variant overrides (single variant only)." -- MT
L["GEMS_VARIANT_LIST_ROW"] = "  v%d %s (modifier: %s, %d steps)" -- MT
L["GEMS_VARIANT_MAX_REACHED"] = "Cannot add variant: %s already has the maximum of %d overrides." -- MT
L["GEMS_VARIANT_NOT_FOUND"] = "Sequence %s has no variant with modifier '%s'." -- MT
L["GEMS_VARIANT_REMOVED"] = "Removed variant on %s (modifier: %s)." -- MT

-- Variant indicator strip (IC-VAR-08 Phase 3) -- MT mirror from enUS
L["GEMS_VARIANT_INDICATOR_LABEL_PLAIN"] = "1" -- MT
L["GEMS_VARIANT_INDICATOR_LABEL_SHIFT"] = "S" -- MT
L["GEMS_VARIANT_INDICATOR_LABEL_CTRL"] = "C" -- MT
L["GEMS_VARIANT_INDICATOR_LABEL_ALT"] = "A" -- MT
L["GEMS_VARIANT_INDICATOR_TOOLTIP"] = "Variant: %s  Modifier: %s  Bind: %s" -- MT
L["GEMS_SETTINGS_VARIANT_INDICATORS_TRACKER"] = "TrackerHUD variant indicators" -- MT
L["GEMS_SETTINGS_VARIANT_INDICATORS_TRACKER_DESC"] =
    "Show coloured status icons, cooldown rings, and a pulsing border for each variant of a Smart Keybind Group sequence inside the Tracker HUD." -- MT
L["GEMS_SETTINGS_VARIANT_INDICATORS_BAR"] = "Action bar variant indicators" -- MT
L["GEMS_SETTINGS_VARIANT_INDICATORS_BAR_DESC"] =
    "Overlay the same variant indicators on action bar buttons that run /click GRIPEMS_<seq>_v<N>." -- MT

-- Auto-mirrored from enUS for prefix GEMS_HELP_VARIANTS (cowork_util fix-locale-parity 2026-05-26)
L["GEMS_HELP_VARIANTS"] = "  /gems variants - List and manage Smart Keybind Group variants" -- MT

-- Auto-mirrored from enUS for prefix GEMS_UI_TAB_VARIANTS (cowork_util fix-locale-parity 2026-05-26)
L["GEMS_UI_TAB_VARIANTS"] = "Variants" -- MT

-- Auto-mirrored from enUS for prefix GEMS_VARIANTS_ (cowork_util fix-locale-parity 2026-05-26)
L["GEMS_VARIANTS_ADD"] = "Add" -- MT
L["GEMS_VARIANTS_COMPILE_ERROR"] = "Recommend function did not compile: %s" -- MT
L["GEMS_VARIANTS_MOD_ALT_ROW"] = "Alt" -- MT
L["GEMS_VARIANTS_MOD_CTRL_ROW"] = "Ctrl" -- MT
L["GEMS_VARIANTS_MOD_PLAIN_ROW"] = "Plain (base)" -- MT
L["GEMS_VARIANTS_MOD_SHIFT_ROW"] = "Shift" -- MT
L["GEMS_VARIANTS_REMOVE"] = "Remove" -- MT
L["GEMS_VARIANTS_SEQ_RECOMMEND"] = "Sequence-level recommend function" -- MT
L["GEMS_VARIANTS_SEQ_RECOMMEND_TT"] =
    "Lua function returning one of: plain, shift, ctrl, alt. Falls back per-version if version-level is set." -- MT
L["GEMS_VARIANTS_UNSAFE_API_WARN"] = "Recommend function references restricted API. Run OOC only." -- MT
L["GEMS_VARIANTS_VER_RECOMMEND"] = "Per-version recommend function" -- MT
L["GEMS_VARIANTS_VER_RECOMMEND_EMPTY"] = "Using sequence default" -- MT
L["GEMS_VARIANTS_VER_TARGET_LIVE"] = "Rows edit version %d (live)" -- MT
L["GEMS_VARIANTS_VER_TARGET_NOT_LIVE"] = "Rows edit version %d (NOT live)" -- MT

-- Auto-mirrored from enUS for prefix GEMS_SETTINGS_SHOW_VARIANTS_TAB (cowork_util fix-locale-parity 2026-05-26)
L["GEMS_SETTINGS_SHOW_VARIANTS_TAB"] = "Show Variants tab in Sequence Editor" -- MT
L["GEMS_SETTINGS_SHOW_VARIANTS_TAB_DESC"] =
    "Adds a Variants subtab to the Sequence Editor for managing per-modifier variant overrides and the recommend function." -- MT

-- Auto-mirrored from enUS for prefix GEMS_UI_FILTER_ (cowork_util fix-locale-parity 2026-06-02)
L["GEMS_UI_FILTER_CLASS"] = "Current class only" -- MT
L["GEMS_UI_FILTER_CLASS_TIP"] = "Hide sequences that belong to other classes" -- MT

-- Auto-mirrored from enUS for prefix GEMS_MIGRATE_ (cowork_util fix-locale-parity 2026-06-02)
L["GEMS_MIGRATE_ALL_CLASSES"] = "All Classes" -- MT
L["GEMS_MIGRATE_CURRENT_CLASS"] = "Current Class Only" -- MT

-- Auto-mirrored from enUS for prefix GEMS_SPELL_TOOLTIP_ (cowork_util fix-locale-parity 2026-06-03)
L["GEMS_SPELL_TOOLTIP_CONTEXTUAL"] = "Castable in the right form or state: %s" -- MT

-- Auto-mirrored from enUS for prefix GEMS_VEHICLE_EXT (cowork_util fix-locale-parity 2026-06-11)
L["GEMS_VEHICLE_EXT_COLLISION"] = "Sky riding binds from %s also use: %s" -- MT

-- Auto-mirrored from enUS for prefix ACCESS_ANNOUNCE_SIMPLIFIED_ (cowork_util fix-locale-parity 2026-06-11)
L["ACCESS_ANNOUNCE_SIMPLIFIED_RUN"] = "Running %s" -- MT
L["ACCESS_ANNOUNCE_SIMPLIFIED_UNLOCKED"] = "Editing unlocked" -- MT
L["ACCESS_ANNOUNCE_SIMPLIFIED_LOCKED"] = "Editing locked" -- MT
L["ACCESS_ANNOUNCE_SIMPLIFIED_CLOSED"] = "Window closed" -- MT

-- Auto-mirrored from enUS for prefix GEMS_VERSION (cowork_util fix-locale-parity 2026-06-29)
L["GEMS_VERSION_LIVE_BADGE"] = "Live: V%d" -- MT
L["GEMS_VERSION_LIVE_MARKER"] = " (Live)" -- MT
L["GEMS_VERSION_TOOLTIP_LIVE_HINT"] =
    "This selects which version you edit. The live version your keybind runs is shown by the Live badge and can differ by content type." -- MT
L["GEMS_VERSION_PINNED_BADGE"] = "Live: V%d (pinned)" -- MT
L["GEMS_VERSION_PIN_ACTION"] = "Make live (pin)" -- MT
L["GEMS_VERSION_UNPIN_ACTION"] = "Unpin (use context)" -- MT
L["GEMS_VERSION_PIN_COMBAT_NOTE"] = " -- applies after combat" -- MT

-- Auto-mirrored from enUS for prefix GEMS_SWAP (cowork_util fix-locale-parity 2026-06-29)
L["GEMS_SWAP_USAGE"] = "Usage: /gems swap <sequence> <version#>" -- MT
L["GEMS_SWAP_DONE"] = "%s is now running version %d." -- MT
L["GEMS_SWAP_DONE_COMBAT"] = "%s will switch to version %d when combat ends." -- MT

-- Auto-mirrored from enUS for prefix GEMS_UNPIN (cowork_util fix-locale-parity 2026-06-29)
L["GEMS_UNPIN_USAGE"] = "Usage: /gems unpin <sequence>" -- MT
L["GEMS_UNPIN_DONE"] = "%s is back to its context or default version." -- MT
L["GEMS_HELP_SWAP"] = "  /gems swap <name> <n> - Pin the running version to version n (until unpinned)" -- MT
L["GEMS_HELP_UNPIN"] = "  /gems unpin <name> - Clear the pin; use the context or default version" -- MT

-- Auto-mirrored from enUS for prefix GEMS_EDITOR_METADATA_CHANGELOG (cowork_util fix-locale-parity 2026-06-30)
L["GEMS_EDITOR_METADATA_CHANGELOG"] = "Changelog" -- MT

-- Auto-mirrored from enUS for prefix GEMS_EXPORTTEXT_ (cowork_util fix-locale-parity 2026-07-02)
L["GEMS_EXPORTTEXT_CLASS_LABEL"] = "Class: " -- MT
L["GEMS_EXPORTTEXT_DESC_LABEL"] = "Description: " -- MT
L["GEMS_EXPORTTEXT_TALENT_LABEL"] = "Talents: " -- MT
L["GEMS_EXPORTTEXT_URL_LABEL"] = "Link: " -- MT
L["GEMS_EXPORTTEXT_CREATEDBY"] = "Created by: %s" -- MT
L["GEMS_EXPORTTEXT_FOOTER"] = "Exported from GRIP-EMS v%s (WoW %s)" -- MT

-- Auto-mirrored from enUS for prefix GEMS_CVAR_NAMEPLATES_STACKING (cowork_util fix-locale-parity 2026-07-09)
L["GEMS_CVAR_NAMEPLATES_STACKING"] = "Nameplate Stacking" -- MT
L["GEMS_CVAR_NAMEPLATES_STACKING_DESC"] = "Which nameplates stack apart instead of overlapping." -- MT
L["GEMS_CVAR_NAMEPLATES_STACKING_OPT_NONE"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_STACKING_OPT_ENEMY"] = "Enemy" -- MT
L["GEMS_CVAR_NAMEPLATES_STACKING_OPT_FRIENDLY"] = "Friendly" -- MT
L["GEMS_CVAR_NAMEPLATES_STACKING_OPT_BOTH"] = "Enemy + Friendly" -- MT
L["GEMS_CVAR_NAMEPLATES_STACKING_DESCLONG"] =
    "Controls which nameplates stack apart when they would overlap, so you can read them in a pack. Enemy keeps enemy plates separated for target selection in dungeons and raids. Friendly does the same for friendly plates. EMS 建議僅敵對：暴雪預設完全不堆疊名條，怪群中敵對名條會彼此重疊；啟用敵對堆疊可讓每個名條都能點選。PvP 設定檔會自動套用敵對 + 友方，因為它同時開啟友方玩家名條。" -- MT
L["GEMS_INTERLEAVE_NOBASE_WARN"] =
    "All actions are set to Interleave, so there is no base step to interleave into. Compiled them as a normal rotation instead. Turn off Interleave on at least one action to set your base rotation." -- MT
L["GEMS_UI_CTX_DUP_SELECTED"] = "Duplicate Selected (%d)" -- MT
L["GEMS_UI_CTX_DELETE_SELECTED"] = "Delete Selected (%d)" -- MT
L["GEMS_UI_STEPS_SELECTED"] = "%d steps selected" -- MT
L["GEMS_UI_DELETE_STEPS_CONFIRM"] = "Delete %d steps? This cannot be undone." -- MT
L["GEMS_SETTINGS_PLUGINS"] = "Plugins" -- MT
L["GEMS_EXPORT_META_FORMAT_LABEL"] = "Format:" -- MT
L["GEMS_EXPORT_FORMAT_BUILTIN"] = "GRIP-EMS" -- MT
L["GEMS_CVAR_FPS_USEMAXFPSBK"] = "Use Background Cap" -- MT
L["GEMS_CVAR_FPS_USEMAXFPSBK_DESC"] = "Turns the background FPS limit on or off when the game window loses focus." -- MT
L["GEMS_CVAR_FPS_USEMAXFPSBK_OPT_0"] = "Off (full FPS in background)" -- MT
L["GEMS_CVAR_FPS_USEMAXFPSBK_OPT_1"] = "On (default, recommended)" -- MT
L["GEMS_CVAR_FPS_USEMAXFPSBK_DESCLONG"] =
    "Works together with Background FPS. When enabled, the client drops to the Background FPS value while you are tabbed out, cutting GPU load and heat. Disable only if you record or stream the game window in the background." -- MT
L["GEMS_CVAR_FPS_DYNSCALEMIN"] = "Dynamic Scale Floor" -- MT
L["GEMS_CVAR_FPS_DYNSCALEMIN_DESC"] = "Lowest render scale the dynamic scaler is allowed to reach." -- MT
L["GEMS_CVAR_FPS_DYNSCALEMIN_OPT_33"] = "33% (default, recommended)" -- MT
L["GEMS_CVAR_FPS_DYNSCALEMIN_OPT_50"] = "50% (balanced)" -- MT
L["GEMS_CVAR_FPS_DYNSCALEMIN_OPT_67"] = "67% (sharper)" -- MT
L["GEMS_CVAR_FPS_DYNSCALEMIN_OPT_75"] = "75% (minimal savings)" -- MT
L["GEMS_CVAR_FPS_DYNSCALEMIN_DESCLONG"] =
    "Only matters while Dynamic Render Scale is enabled. The default 33% floor keeps FPS stable at a heavy image-quality cost; raise the floor to keep the image sharper in exchange for smaller FPS savings." -- MT
L["GEMS_CVAR_VISUAL_RESAMPLEQ"] = "Resample Quality" -- MT
L["GEMS_CVAR_VISUAL_RESAMPLEQ_DESC"] = "Upscaling filter used when Render Scale is not 100%." -- MT
L["GEMS_CVAR_VISUAL_RESAMPLEQ_OPT_0"] = "Point (fastest)" -- MT
L["GEMS_CVAR_VISUAL_RESAMPLEQ_OPT_1"] = "Bilinear" -- MT
L["GEMS_CVAR_VISUAL_RESAMPLEQ_OPT_2"] = "Bicubic" -- MT
L["GEMS_CVAR_VISUAL_RESAMPLEQ_OPT_3"] = "FidelityFX Super Resolution (default, recommended)" -- MT
L["GEMS_CVAR_VISUAL_RESAMPLEQ_DESCLONG"] =
    "Only applies while Render Scale differs from 100%. FidelityFX Super Resolution gives the cleanest upscale on modern GPUs; Point and Bilinear are cheaper fallbacks for very old hardware." -- MT
L["GEMS_CVAR_DUNGEON_UNITCLUTTER"] = "Unit Clutter Reduction" -- MT
L["GEMS_CVAR_DUNGEON_UNITCLUTTER_DESC"] = "Master toggle for the system that thins out stacked NPCs and pets." -- MT
L["GEMS_CVAR_DUNGEON_UNITCLUTTER_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_DUNGEON_UNITCLUTTER_OPT_1"] = "On (default, recommended)" -- MT
L["GEMS_CVAR_DUNGEON_UNITCLUTTER_DESCLONG"] =
    "Master switch for unit clutter reduction. Keep it on so crowded scenes stay readable; the instances-only setting scopes where it applies and the player threshold controls how many nearby players it takes to kick in." -- MT
L["GEMS_CVAR_DUNGEON_CLUTTERTHRESH"] = "Clutter Player Threshold" -- MT
L["GEMS_CVAR_DUNGEON_CLUTTERTHRESH_DESC"] = "Nearby players required before clutter reduction kicks in." -- MT
L["GEMS_CVAR_DUNGEON_CLUTTERTHRESH_OPT_5"] = "5 (aggressive)" -- MT
L["GEMS_CVAR_DUNGEON_CLUTTERTHRESH_OPT_9"] = "9 (default, recommended)" -- MT
L["GEMS_CVAR_DUNGEON_CLUTTERTHRESH_OPT_15"] = "15 (relaxed)" -- MT
L["GEMS_CVAR_DUNGEON_CLUTTERTHRESH_OPT_20"] = "20 (rarely triggers)" -- MT
L["GEMS_CVAR_DUNGEON_CLUTTERTHRESH_DESCLONG"] =
    "Lower values start hiding cosmetic units earlier, which helps framerate in busy hubs and raids. The default of 9 is a solid middle ground; raise it if you only want clutter reduction in very large groups." -- MT
L["GEMS_CVAR_COMBAT_SOFTICONENEMY"] = "Enemy Soft Target Icon" -- MT
L["GEMS_CVAR_COMBAT_SOFTICONENEMY_DESC"] = "Show an icon above the enemy action targeting has picked." -- MT
L["GEMS_CVAR_COMBAT_SOFTICONENEMY_OPT_0"] = "Hidden (default)" -- MT
L["GEMS_CVAR_COMBAT_SOFTICONENEMY_OPT_1"] = "Shown (recommended)" -- MT
L["GEMS_CVAR_COMBAT_SOFTICONENEMY_DESCLONG"] =
    "With enemy soft targeting active, this icon marks exactly which enemy your next cast will hit. Recommended for sequence users: you see what the engine sees before the button press." -- MT
L["GEMS_CVAR_COMBAT_SOFTICONFRIEND"] = "Friendly Soft Target Icon" -- MT
L["GEMS_CVAR_COMBAT_SOFTICONFRIEND_DESC"] = "Show an icon above your current friendly soft target." -- MT
L["GEMS_CVAR_COMBAT_SOFTICONFRIEND_OPT_0"] = "Hidden (default, recommended)" -- MT
L["GEMS_CVAR_COMBAT_SOFTICONFRIEND_OPT_1"] = "Shown" -- MT
L["GEMS_CVAR_COMBAT_SOFTICONFRIEND_DESCLONG"] =
    "Only relevant when friendly soft targeting is enabled, which the registry recommends leaving off. Keep the icon off unless you have turned friendly soft targeting on for support play." -- MT
L["GEMS_CVAR_SOLO_INTERHARDRANGE"] = "Hard Interact Range Cutoff" -- MT
L["GEMS_CVAR_SOLO_INTERHARDRANGE_DESC"] = "Treat the interact range as a hard cutoff in every case." -- MT
L["GEMS_CVAR_SOLO_INTERHARDRANGE_OPT_0"] = "Off (default, recommended)" -- MT
L["GEMS_CVAR_SOLO_INTERHARDRANGE_OPT_1"] = "On (strict)" -- MT
L["GEMS_CVAR_SOLO_INTERHARDRANGE_DESCLONG"] =
    "Off keeps the forgiving behaviour: an object already in interact range stays targetable at the edge. On drops the soft target the moment it leaves the configured range. Leave off unless you want strict range discipline." -- MT
L["GEMS_CVAR_SOLO_INTERICONGO"] = "Object Interact Icon" -- MT
L["GEMS_CVAR_SOLO_INTERICONGO_DESC"] = "Show an icon on usable objects that cannot normally be targeted." -- MT
L["GEMS_CVAR_SOLO_INTERICONGO_OPT_0"] = "Hidden (default)" -- MT
L["GEMS_CVAR_SOLO_INTERICONGO_OPT_1"] = "Shown (recommended)" -- MT
L["GEMS_CVAR_SOLO_INTERICONGO_DESCLONG"] =
    "Extends the interact icon to chests, levers, and other world objects without a real target frame. Pairs with the interact icon and range settings above so every usable object is flagged before you press interact." -- MT
L["GEMS_CVAR_SOLO_LOWPRIOICONS"] = "Low-Priority Interact Icons" -- MT
L["GEMS_CVAR_SOLO_LOWPRIOICONS_DESC"] = "Show interact icons on objects quest or loot effects already mark." -- MT
L["GEMS_CVAR_SOLO_LOWPRIOICONS_OPT_0"] = "Hidden (default, recommended)" -- MT
L["GEMS_CVAR_SOLO_LOWPRIOICONS_OPT_1"] = "Always shown" -- MT
L["GEMS_CVAR_SOLO_LOWPRIOICONS_DESCLONG"] =
    "Off keeps the screen quieter by letting quest sparkles and loot glows stand alone. Turn it on if you want the interact icon visible on every usable object regardless of other markers." -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTNPFRIEND"] = "Friendly Soft Target Nameplate" -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTNPFRIEND_DESC"] = "Always show a nameplate for your current friendly soft target." -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTNPFRIEND_OPT_0"] = "Off (default, recommended)" -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTNPFRIEND_OPT_1"] = "On" -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTNPFRIEND_DESCLONG"] =
    "Only relevant when friendly soft targeting is enabled, which the registry recommends leaving off. Leave disabled to keep friendly nameplates uncluttered." -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTNPINTERACT"] = "Interact Target Nameplate" -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTNPINTERACT_DESC"] = "Always show a nameplate for your current soft interact target." -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTNPINTERACT_OPT_0"] = "Off (default)" -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTNPINTERACT_OPT_1"] = "On (recommended)" -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTNPINTERACT_DESCLONG"] =
    "Puts a nameplate on the NPC or object your interact key is pointed at, which makes the pick unambiguous in crowded quest hubs. Pairs with the interact icons for full interact visibility." -- MT
L["GEMS_CVAR_FILTER_ISSUES"] = "Show only issues" -- MT
L["GEMS_CVAR_FILTER_ISSUES_DESC"] =
    "Hide rows that already match the recommendation and hide sections with nothing to fix. Rows you marked as your choice count as fine and are hidden too. Session-only; the filter resets on reload." -- MT
L["GEMS_CVAR_SEARCH"] = "Find a CVar" -- MT
L["GEMS_CVAR_SEARCH_DESC"] =
    "Type part of a CVar name or its label. Up to eight matches appear below; click one to jump to its section page." -- MT
L["GEMS_CVAR_SEARCH_NOMATCH"] = "No matching CVar." -- MT
L["GEMS_CVAR_NAMEPLATES_THREATDISP"] = "Threat Display" -- MT
L["GEMS_CVAR_NAMEPLATES_THREATDISP_DESC"] = "How threat is shown on enemy nameplates." -- MT
L["GEMS_CVAR_NAMEPLATES_INFODISP"] = "Nameplate Info" -- MT
L["GEMS_CVAR_NAMEPLATES_INFODISP_DESC"] = "Extra info shown on nameplates." -- MT
L["GEMS_CVAR_NAMEPLATES_CASTBARDISP"] = "Cast Bar Info" -- MT
L["GEMS_CVAR_NAMEPLATES_CASTBARDISP_DESC"] = "What nameplate cast bars show." -- MT
L["GEMS_CVAR_NAMEPLATES_AURAENEMYPLAYER"] = "Enemy Player Auras" -- MT
L["GEMS_CVAR_NAMEPLATES_AURAENEMYPLAYER_DESC"] = "Buffs, debuffs, and loss of control on enemy player nameplates." -- MT
L["GEMS_CVAR_NAMEPLATES_AURAENEMYNPC"] = "Enemy NPC Auras" -- MT
L["GEMS_CVAR_NAMEPLATES_AURAENEMYNPC_DESC"] = "Buffs, debuffs, and crowd control on enemy NPC nameplates." -- MT
L["GEMS_CVAR_NAMEPLATES_AURAFRIENDPLAYER"] = "Friendly Player Auras" -- MT
L["GEMS_CVAR_NAMEPLATES_AURAFRIENDPLAYER_DESC"] = "Buffs, debuffs, and loss of control on friendly player nameplates." -- MT
L["GEMS_CVAR_NAMEPLATES_THREATDISP_OPT_OFF"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_THREATDISP_OPT_PROGRESSIVE"] = "Progressive" -- MT
L["GEMS_CVAR_NAMEPLATES_THREATDISP_OPT_FLASH"] = "Aggro Flash" -- MT
L["GEMS_CVAR_NAMEPLATES_THREATDISP_OPT_HBCOLOR"] = "Health Bar Colour" -- MT
L["GEMS_CVAR_NAMEPLATES_THREATDISP_OPT_ALL"] = "All" -- MT
L["GEMS_CVAR_NAMEPLATES_THREATDISP_DESCLONG"] =
    "Off matches the default. Progressive fills a threat meter on the plate, Aggro Flash warns when you gain or lose aggro, and Health Bar Colour tints the health bar by threat state. Tanks get the most from Health Bar Colour." -- MT
L["GEMS_CVAR_NAMEPLATES_INFODISP_OPT_OFF"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_INFODISP_OPT_RARITY"] = "Rarity Icon" -- MT
L["GEMS_CVAR_NAMEPLATES_INFODISP_OPT_PCT"] = "Health Percent" -- MT
L["GEMS_CVAR_NAMEPLATES_INFODISP_OPT_PCTRARITY"] = "Health Percent + Rarity" -- MT
L["GEMS_CVAR_NAMEPLATES_INFODISP_OPT_ALL"] = "Everything" -- MT
L["GEMS_CVAR_NAMEPLATES_INFODISP_DESCLONG"] =
    "Rarity Icon matches the default: rare and elite mobs get a marker on their plate. The percent options add a health number readout. Everything shows percent, exact value, and the rarity marker at once." -- MT
L["GEMS_CVAR_NAMEPLATES_CASTBARDISP_OPT_OFF"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_CASTBARDISP_OPT_NAMEICON"] = "Name + Icon" -- MT
L["GEMS_CVAR_NAMEPLATES_CASTBARDISP_OPT_HIGHLIGHTS"] = "Name, Icon + Highlights" -- MT
L["GEMS_CVAR_NAMEPLATES_CASTBARDISP_OPT_ALL"] = "Everything" -- MT
L["GEMS_CVAR_NAMEPLATES_CASTBARDISP_DESCLONG"] =
    "Name, Icon + Highlights matches the default: spell name and icon, plus a highlight for important casts and for casts aimed at you. Everything adds the cast target name so you can see who the mob is casting at. Off hides cast bar extras." -- MT
L["GEMS_CVAR_NAMEPLATES_AURAENEMYPLAYER_OPT_OFF"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_AURAENEMYPLAYER_OPT_DEBUFFS"] = "Debuffs Only" -- MT
L["GEMS_CVAR_NAMEPLATES_AURAENEMYPLAYER_OPT_BUFFSDEBUFFS"] = "Buffs + Debuffs" -- MT
L["GEMS_CVAR_NAMEPLATES_AURAENEMYPLAYER_OPT_ALL"] = "Buffs, Debuffs + Loss of Control" -- MT
L["GEMS_CVAR_NAMEPLATES_AURAENEMYPLAYER_DESCLONG"] =
    "The recommended setting adds loss of control markers, so you can tell when an enemy player is stunned, feared, or silenced straight from their plate. The game default leaves those markers off." -- MT
L["GEMS_CVAR_NAMEPLATES_AURAENEMYNPC_OPT_OFF"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_AURAENEMYNPC_OPT_DEBUFFS"] = "Debuffs Only" -- MT
L["GEMS_CVAR_NAMEPLATES_AURAENEMYNPC_OPT_BUFFSDEBUFFS"] = "Buffs + Debuffs" -- MT
L["GEMS_CVAR_NAMEPLATES_AURAENEMYNPC_OPT_ALL"] = "Buffs, Debuffs + Crowd Control" -- MT
L["GEMS_CVAR_NAMEPLATES_AURAENEMYNPC_DESCLONG"] =
    "The default shows all three. Crowd control markers on NPC plates show which mobs are already locked down, so the group does not stack CC on the same target in dungeons." -- MT
L["GEMS_CVAR_NAMEPLATES_AURAFRIENDPLAYER_OPT_OFF"] = "Off" -- MT
L["GEMS_CVAR_NAMEPLATES_AURAFRIENDPLAYER_OPT_DEBUFFS"] = "Debuffs Only" -- MT
L["GEMS_CVAR_NAMEPLATES_AURAFRIENDPLAYER_OPT_BUFFSDEBUFFS"] = "Buffs + Debuffs" -- MT
L["GEMS_CVAR_NAMEPLATES_AURAFRIENDPLAYER_OPT_ALL"] = "Buffs, Debuffs + Loss of Control" -- MT
L["GEMS_CVAR_NAMEPLATES_AURAFRIENDPLAYER_DESCLONG"] =
    "Buffs + Debuffs matches the default. Add loss of control if you play healer and want to see which teammates are stunned or silenced without staring at raid frames." -- MT

-- Auto-mirrored from enUS for prefix GEMS_CVAR_COMBATAUDIO_ (cowork_util fix-locale-parity 2026-07-20)
L["GEMS_CVAR_COMBATAUDIO_ENABLE"] = "Combat Audio Alerts" -- MT
L["GEMS_CVAR_COMBATAUDIO_ENABLE_DESC"] = "Master switch for the game's spoken combat alerts." -- MT
L["GEMS_CVAR_COMBATAUDIO_ENABLE_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBATAUDIO_ENABLE_OPT_1"] = "On" -- MT
L["GEMS_CVAR_COMBATAUDIO_ENABLE_DESCLONG"] =
    "Turns on the game's built-in spoken combat alerts. Every other row in this section only does something while this is on. It is off by default; turn it on if you want callouts for casts, interrupts, and target changes without watching the screen." -- MT
L["GEMS_CVAR_COMBATAUDIO_TARGETNAME"] = "Speak Target Name" -- MT
L["GEMS_CVAR_COMBATAUDIO_TARGETNAME_DESC"] = "Say the target's name when you switch targets." -- MT
L["GEMS_CVAR_COMBATAUDIO_TARGETNAME_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBATAUDIO_TARGETNAME_OPT_1"] = "On" -- MT
L["GEMS_CVAR_COMBATAUDIO_TARGETNAME_DESCLONG"] =
    "Reads out each new target's name as you tab or click onto it. On by default once combat audio is enabled. Useful for confirming your target without looking at the target frame." -- MT
L["GEMS_CVAR_COMBATAUDIO_COMBATSTART"] = "Announce Combat Start" -- MT
L["GEMS_CVAR_COMBATAUDIO_COMBATSTART_DESC"] = "Say a line when you enter combat." -- MT
L["GEMS_CVAR_COMBATAUDIO_COMBATSTART_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBATAUDIO_COMBATSTART_OPT_1"] = "On" -- MT
L["GEMS_CVAR_COMBATAUDIO_COMBATSTART_DESCLONG"] =
    "Speaks a short line the moment you enter combat. On by default. A cue that a pull has started when you are looking away from the screen." -- MT
L["GEMS_CVAR_COMBATAUDIO_COMBATEND"] = "Announce Combat End" -- MT
L["GEMS_CVAR_COMBATAUDIO_COMBATEND_DESC"] = "Say a line when you leave combat." -- MT
L["GEMS_CVAR_COMBATAUDIO_COMBATEND_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBATAUDIO_COMBATEND_OPT_1"] = "On" -- MT
L["GEMS_CVAR_COMBATAUDIO_COMBATEND_DESCLONG"] =
    "Speaks a short line when combat ends. On by default. Pairs with the combat-start callout to bracket each fight." -- MT
L["GEMS_CVAR_COMBATAUDIO_TARGETCAST"] = "Target Cast Alerts" -- MT
L["GEMS_CVAR_COMBATAUDIO_TARGETCAST_DESC"] = "Speak when your target starts or finishes a cast." -- MT
L["GEMS_CVAR_COMBATAUDIO_TARGETCAST_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBATAUDIO_TARGETCAST_OPT_1"] = "Cast Start" -- MT
L["GEMS_CVAR_COMBATAUDIO_TARGETCAST_OPT_2"] = "Cast End" -- MT
L["GEMS_CVAR_COMBATAUDIO_TARGETCAST_DESCLONG"] =
    "Reads out your target's casts. Off by default. Cast Start speaks as the cast begins, which gives you the most warning for an interrupt. Cast End speaks as it finishes. Off keeps the audio quiet." -- MT
L["GEMS_CVAR_COMBATAUDIO_TARGETCASTMIN"] = "Target Cast Minimum Length" -- MT
L["GEMS_CVAR_COMBATAUDIO_TARGETCASTMIN_DESC"] = "Only speak target casts at least this long." -- MT
L["GEMS_CVAR_COMBATAUDIO_TARGETCASTMIN_OPT_ALL"] = "All Casts" -- MT
L["GEMS_CVAR_COMBATAUDIO_TARGETCASTMIN_OPT_10"] = "1 second" -- MT
L["GEMS_CVAR_COMBATAUDIO_TARGETCASTMIN_OPT_15"] = "1.5 seconds" -- MT
L["GEMS_CVAR_COMBATAUDIO_TARGETCASTMIN_OPT_20"] = "2 seconds" -- MT
L["GEMS_CVAR_COMBATAUDIO_TARGETCASTMIN_OPT_30"] = "3 seconds" -- MT
L["GEMS_CVAR_COMBATAUDIO_TARGETCASTMIN_DESCLONG"] =
    "Filters which target casts get read out by length. The default is 1.5 seconds, so very short casts stay quiet and only slower ones are announced. All Casts reads every cast, which gets noisy in dungeons. Raise it if you only care about long, dangerous casts." -- MT
L["GEMS_CVAR_COMBATAUDIO_PLAYERCAST"] = "Your Cast Alerts" -- MT
L["GEMS_CVAR_COMBATAUDIO_PLAYERCAST_DESC"] = "Speak when you start or finish a cast." -- MT
L["GEMS_CVAR_COMBATAUDIO_PLAYERCAST_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBATAUDIO_PLAYERCAST_OPT_1"] = "Cast Start" -- MT
L["GEMS_CVAR_COMBATAUDIO_PLAYERCAST_OPT_2"] = "Cast End" -- MT
L["GEMS_CVAR_COMBATAUDIO_PLAYERCAST_DESCLONG"] =
    "Reads out your own casts. Off by default. Cast Start speaks as you begin casting, Cast End as it lands. Mostly for accessibility, or for confirming a cast fired without watching the cast bar." -- MT
L["GEMS_CVAR_COMBATAUDIO_INTERRUPT"] = "Announce Interruptible Casts" -- MT
L["GEMS_CVAR_COMBATAUDIO_INTERRUPT_DESC"] = "Speak when the target begins something you can interrupt." -- MT
L["GEMS_CVAR_COMBATAUDIO_INTERRUPT_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBATAUDIO_INTERRUPT_OPT_1"] = "On" -- MT
L["GEMS_CVAR_COMBATAUDIO_INTERRUPT_DESCLONG"] =
    "Speaks a cue when your target starts a cast that can be interrupted. Off by default. A hands-free prompt to use your kick, which pairs well with a sequencer keybind." -- MT
L["GEMS_CVAR_COMBATAUDIO_INTERRUPTOK"] = "Announce Interrupt Success" -- MT
L["GEMS_CVAR_COMBATAUDIO_INTERRUPTOK_DESC"] = "Speak when the target's cast is interrupted." -- MT
L["GEMS_CVAR_COMBATAUDIO_INTERRUPTOK_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_COMBATAUDIO_INTERRUPTOK_OPT_1"] = "On" -- MT
L["GEMS_CVAR_COMBATAUDIO_INTERRUPTOK_DESCLONG"] =
    "Speaks a cue when your target's cast gets interrupted. Off by default. Confirms the kick landed so you are not lining up a second one for a cast that already stopped." -- MT
L["GEMS_CVAR_COMBATAUDIO_VOLUME"] = "Alert Volume" -- MT
L["GEMS_CVAR_COMBATAUDIO_VOLUME_DESC"] = "How loud the combat audio alerts are." -- MT
L["GEMS_CVAR_COMBATAUDIO_VOLUME_OPT_0"] = "Muted" -- MT
L["GEMS_CVAR_COMBATAUDIO_VOLUME_OPT_25"] = "25%" -- MT
L["GEMS_CVAR_COMBATAUDIO_VOLUME_OPT_50"] = "50%" -- MT
L["GEMS_CVAR_COMBATAUDIO_VOLUME_OPT_75"] = "75%" -- MT
L["GEMS_CVAR_COMBATAUDIO_VOLUME_OPT_100"] = "100% (default)" -- MT
L["GEMS_CVAR_COMBATAUDIO_VOLUME_DESCLONG"] =
    "Sets the volume of the spoken combat alerts, separate from your other sound sliders. Full volume by default. Lower it if the callouts drown out game sound, or mute it to keep the feature configured but silent." -- MT

-- Auto-mirrored from enUS for prefix GEMS_CVAR_SECTION_COMBATAUDIO (cowork_util fix-locale-parity 2026-07-20)
L["GEMS_CVAR_SECTION_COMBATAUDIO"] = "Combat Audio" -- MT

-- Auto-mirrored from enUS for prefix GEMS_CVAR_ACCESS_ (cowork_util fix-locale-parity 2026-07-20)
L["GEMS_CVAR_ACCESS_SHAKECAM"] = "Camera Shake Strength" -- MT
L["GEMS_CVAR_ACCESS_SHAKECAM_DESC"] = "How much combat and spell effects shake the camera." -- MT
L["GEMS_CVAR_ACCESS_SHAKECAM_OPT_0"] = "None" -- MT
L["GEMS_CVAR_ACCESS_SHAKECAM_OPT_25"] = "Light" -- MT
L["GEMS_CVAR_ACCESS_SHAKECAM_OPT_50"] = "Half" -- MT
L["GEMS_CVAR_ACCESS_SHAKECAM_OPT_75"] = "Strong" -- MT
L["GEMS_CVAR_ACCESS_SHAKECAM_OPT_100"] = "Full (default)" -- MT
L["GEMS_CVAR_ACCESS_SHAKECAM_DESCLONG"] =
    "Scales how much screen effects shake the 3D camera. Full is the default. Lower it, or set it to None, if camera shake causes motion discomfort. This is a common motion-sickness aid." -- MT
L["GEMS_CVAR_ACCESS_SHAKEUI"] = "UI Shake Strength" -- MT
L["GEMS_CVAR_ACCESS_SHAKEUI_DESC"] = "How much effects shake the 2D interface." -- MT
L["GEMS_CVAR_ACCESS_SHAKEUI_OPT_0"] = "None" -- MT
L["GEMS_CVAR_ACCESS_SHAKEUI_OPT_25"] = "Light" -- MT
L["GEMS_CVAR_ACCESS_SHAKEUI_OPT_50"] = "Half" -- MT
L["GEMS_CVAR_ACCESS_SHAKEUI_OPT_75"] = "Strong" -- MT
L["GEMS_CVAR_ACCESS_SHAKEUI_OPT_100"] = "Full (default)" -- MT
L["GEMS_CVAR_ACCESS_SHAKEUI_DESCLONG"] =
    "Scales how much screen effects shake the flat UI layer, separate from the camera. Full is the default. Lower it if on-screen shake bothers you but you still want the camera effect, or set both shake rows down together." -- MT
L["GEMS_CVAR_ACCESS_CBSIM"] = "Colourblind Filter" -- MT
L["GEMS_CVAR_ACCESS_CBSIM_DESC"] = "Which type of colourblindness the colour filter is tuned for." -- MT
L["GEMS_CVAR_ACCESS_CBSIM_OPT_0"] = "None (default)" -- MT
L["GEMS_CVAR_ACCESS_CBSIM_OPT_1"] = "Protanopia (red)" -- MT
L["GEMS_CVAR_ACCESS_CBSIM_OPT_2"] = "Deuteranopia (green)" -- MT
L["GEMS_CVAR_ACCESS_CBSIM_OPT_3"] = "Tritanopia (blue)" -- MT
L["GEMS_CVAR_ACCESS_CBSIM_DESCLONG"] =
    "Selects the type of colourblindness the game's colour filter is tuned for. None is the default, which leaves the screen unchanged. Pick a type here to turn the filter on; the strength row below sets how far it shifts. This is separate from the Colourblind Mode toggle above, which adds colourblind-friendly text labels rather than filtering the screen." -- MT
L["GEMS_CVAR_ACCESS_CBWEAK"] = "Colourblind Strength" -- MT
L["GEMS_CVAR_ACCESS_CBWEAK_DESC"] = "How strongly the colourblind filter shifts colours." -- MT
L["GEMS_CVAR_ACCESS_CBWEAK_OPT_0"] = "0 (none)" -- MT
L["GEMS_CVAR_ACCESS_CBWEAK_OPT_25"] = "0.25" -- MT
L["GEMS_CVAR_ACCESS_CBWEAK_OPT_50"] = "0.5 (default)" -- MT
L["GEMS_CVAR_ACCESS_CBWEAK_OPT_75"] = "0.75" -- MT
L["GEMS_CVAR_ACCESS_CBWEAK_OPT_100"] = "1.0 (full)" -- MT
L["GEMS_CVAR_ACCESS_CBWEAK_DESCLONG"] =
    "Sets how strongly the colourblind filter shifts colours, from none at 0 to full at 1. The default is 0.5. Only does anything when a colourblind filter type is selected above." -- MT
L["GEMS_CVAR_ACCESS_CURSORSIZE"] = "Cursor Size" -- MT
L["GEMS_CVAR_ACCESS_CURSORSIZE_DESC"] = "Size of the mouse cursor." -- MT
L["GEMS_CVAR_ACCESS_CURSORSIZE_OPT_AUTO"] = "Auto (by monitor)" -- MT
L["GEMS_CVAR_ACCESS_CURSORSIZE_OPT_0"] = "Small (32px)" -- MT
L["GEMS_CVAR_ACCESS_CURSORSIZE_OPT_1"] = "Medium (48px)" -- MT
L["GEMS_CVAR_ACCESS_CURSORSIZE_OPT_2"] = "Large (64px)" -- MT
L["GEMS_CVAR_ACCESS_CURSORSIZE_OPT_3"] = "Extra Large (96px)" -- MT
L["GEMS_CVAR_ACCESS_CURSORSIZE_OPT_4"] = "Huge (128px)" -- MT
L["GEMS_CVAR_ACCESS_CURSORSIZE_DESCLONG"] =
    "Sets the mouse cursor size. Auto picks a size from your monitor resolution and is the default. The fixed sizes make the cursor easier to track on a busy screen or a large display." -- MT
L["GEMS_CVAR_ACCESS_CLIPCURSOR"] = "Lock Cursor to Window" -- MT
L["GEMS_CVAR_ACCESS_CLIPCURSOR_DESC"] = "Keep the mouse cursor inside the game window." -- MT
L["GEMS_CVAR_ACCESS_CLIPCURSOR_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_ACCESS_CLIPCURSOR_OPT_1"] = "On" -- MT
L["GEMS_CVAR_ACCESS_CLIPCURSOR_DESCLONG"] =
    "Stops the mouse from leaving the game window. Off is the default. Turn it on for windowed play across multiple monitors so the cursor does not slip onto another screen mid-fight." -- MT
L["GEMS_CVAR_ACCESS_TTS"] = "Chat Text to Speech" -- MT
L["GEMS_CVAR_ACCESS_TTS_DESC"] = "Read chat messages out loud." -- MT
L["GEMS_CVAR_ACCESS_TTS_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_ACCESS_TTS_OPT_1"] = "On" -- MT
L["GEMS_CVAR_ACCESS_TTS_DESCLONG"] =
    "Reads incoming chat out loud using the system voice. Off is the default. This is separate from the combat audio alerts in their own section; this row is for chat channels." -- MT
L["GEMS_CVAR_ACCESS_STT"] = "Voice Transcription" -- MT
L["GEMS_CVAR_ACCESS_STT_DESC"] = "Show on-screen text for spoken words in voice chat." -- MT
L["GEMS_CVAR_ACCESS_STT_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_ACCESS_STT_OPT_1"] = "On" -- MT
L["GEMS_CVAR_ACCESS_STT_DESCLONG"] =
    "Transcribes other players' voice chat into on-screen text. Off is the default. Useful if you are in a voice channel but cannot hear it clearly or at all." -- MT
L["GEMS_CVAR_ACCESS_TTSCHAR"] = "Per-Character Voice Settings" -- MT
L["GEMS_CVAR_ACCESS_TTSCHAR_DESC"] = "Use separate text-to-speech settings for this character." -- MT
L["GEMS_CVAR_ACCESS_TTSCHAR_OPT_0"] = "Off" -- MT
L["GEMS_CVAR_ACCESS_TTSCHAR_OPT_1"] = "On" -- MT
L["GEMS_CVAR_ACCESS_TTSCHAR_DESCLONG"] =
    "When on, this character keeps its own text-to-speech voice and options instead of sharing the account-wide set. On is the default. Turn it off to use one shared voice setup across every character." -- MT
L["GEMS_CVAR_VISUAL_RAIDSHADOWS"] = "Raid Shadow Quality" -- MT
L["GEMS_CVAR_VISUAL_RAIDSHADOWS_DESC"] =
    "Shadow tier for the raid and battleground graphics profile (0-5). Lower it for FPS in big group content; your open-world shadows stay untouched." -- MT
L["GEMS_CVAR_VISUAL_RAIDSHADOWS_DESCLONG"] =
    "WoW keeps a separate graphics profile for raids and battlegrounds so you can run lighter settings where framerate matters most. This is the shadow tier for that profile, on Blizzard's scale from Low up to Ultra High. Shadows are one of the heaviest GPU settings, so dropping raid shadows to Low or Fair frees the most frames in a 20-player pull or a packed battleground, and everywhere else keeps full shadows. The live raid default is High. Drop it if raids stutter, keep it up if your GPU has room. This setting resets each session and does not persist across logouts; EMS re-applies your choice on every login." -- MT
L["GEMS_CVAR_VISUAL_RAIDSSAO"] = "Raid Ambient Occlusion" -- MT
L["GEMS_CVAR_VISUAL_RAIDSSAO_DESC"] =
    "Ambient occlusion tier for the raid and battleground profile (0 off, 4 highest). Cheaper than shadows; leave at default unless you need every frame." -- MT
L["GEMS_CVAR_VISUAL_RAIDSSAO_DESCLONG"] =
    "Screen-space ambient occlusion is the soft contact shadow where objects meet the ground. This is the raid and battleground copy of that setting, separate from your open-world value, with tiers running Disabled, Low, Medium, High, Ultra. It costs less GPU than shadow quality, so most people leave it at the default High and only drop to Low or Disabled when a dense pull needs the frames. The live raid default is High. This setting resets each session and does not persist across logouts; EMS re-applies your choice on every login." -- MT
L["GEMS_CVAR_VISUAL_RAIDGROUND"] = "Raid Ground Clutter" -- MT
L["GEMS_CVAR_VISUAL_RAIDGROUND_DESC"] =
    "Grass and ground-detail density in raids and battlegrounds (1-10). Cosmetic, so lowering it costs nothing in gameplay." -- MT
L["GEMS_CVAR_VISUAL_RAIDGROUND_DESCLONG"] =
    "Density of small ground objects like grass, pebbles, and leaves while you are in a raid or battleground, kept separate from your open-world value. It is purely cosmetic: clutter never hides a unit or a ground effect, so trimming it is free FPS. The recommended value matches the live raid default of 6, which is fairly dense; most raid bosses sit indoors where you barely see grass, so dropping to 1 through 3 is a safe cut if you want a few more frames. This setting resets each session and does not persist across logouts; EMS re-applies your choice on every login." -- MT
L["GEMS_CVAR_VISUAL_RAIDPROJTEX"] = "Raid Projected Textures" -- MT
L["GEMS_CVAR_VISUAL_RAIDPROJTEX_DESC"] =
    "Spell ground effects (swirls, void zones) inside raids and battlegrounds. Keep it on; off hides boss telegraphs." -- MT
L["GEMS_CVAR_VISUAL_RAIDPROJTEX_DESCLONG"] =
    "Projected textures are the ground-effect decals for raid mechanics: AoE swirls, void zones, fire patches, healing circles. This is the raid and battleground copy of the setting, separate from your open-world value. Keep it on (1), because with it off those indicators do not draw and you cannot see where a mechanic is about to land, in exactly the content where that gets you killed. Turn it off only if you have a real GPU bottleneck and run a third-party addon that draws its own markers. This setting resets each session and does not persist across logouts; EMS re-applies your choice on every login." -- MT
L["GEMS_CVAR_DRAGON_NOFSFX"] = "Disable Full-Screen Flight Effects" -- MT
L["GEMS_CVAR_DRAGON_NOFSFX_DESC"] =
    "Turns off the full-screen speed blur and vignette during Skyriding. Unchecked by default; tick it if they bother you." -- MT
L["GEMS_CVAR_DRAGON_NOFSFX_DESCLONG"] =
    "The advanced-flying full-screen effects are the speed blur and edge vignette that wash across the screen while you Skyride at pace. This setting disables them: unchecked (the default) keeps the effects on, ticked turns them off. EMS recommends leaving it unchecked because the blur and vignette are part of the intended sense-of-speed feedback, but tick it if they trigger motion sickness or you want a cleaner view on long flights. This setting is saved account-wide, so it persists across sessions once you set it." -- MT
L["GEMS_CVAR_DRAGON_NOVELVFX"] = "Disable Flight Velocity Effects" -- MT
L["GEMS_CVAR_DRAGON_NOVELVFX_DESC"] =
    "Turns off the streaking speed-line particles during Skyriding. Unchecked by default; tick it for a calmer view." -- MT
L["GEMS_CVAR_DRAGON_NOVELVFX_DESCLONG"] =
    "The velocity VFX are the streaking speed-line particles that trail past the camera as your Skyriding speed climbs. This setting disables them: unchecked (the default) keeps them on, ticked turns them off. EMS recommends leaving it unchecked since the speed lines reinforce the feel of fast flight, but tick it if the particles distract you or add to motion discomfort. This setting is saved account-wide, so it persists across sessions once you set it." -- MT
L["GEMS_CVAR_DRAGON_LOOKAHEAD"] = "Dynamic Flight Look-Ahead" -- MT
L["GEMS_CVAR_DRAGON_LOOKAHEAD_DESC"] =
    "Leans the camera into your direction of travel for a more dynamic flight feel. Off by default." -- MT
L["GEMS_CVAR_DRAGON_LOOKAHEAD_DESCLONG"] =
    "When enabled, the game makes more dynamic attitude adjustments while you fly, leaning the view into your direction of travel so the horizon tilts with your manoeuvres. It is off by default. Turn it on for a livelier flight camera that leans with you; leave it off if you prefer a steady horizon or find the extra motion uncomfortable. This setting resets each session and does not persist across logouts; EMS re-applies your choice on every login." -- MT

-- Auto-mirrored from enUS for prefix GEMS_IMPORT_PREVIEW_STEPS_MALFORMED (cowork_util fix-locale-parity 2026-07-27)
L["GEMS_IMPORT_PREVIEW_STEPS_MALFORMED"] = "'%s': steps field is malformed, no steps could be read." -- MT
