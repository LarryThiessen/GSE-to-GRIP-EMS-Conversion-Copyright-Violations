-- GRIP-EMS: SQWOptimizer
-- Created: 2026-04-07
-- Updated: 2026-08-17
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)

--------------------------------------------------------------------------------
-- SQWOptimizer.lua -- Dynamic SpellQueueWindow Optimizer
-- Adjusts SpellQueueWindow in real-time based on EWMA-smoothed latency.
-- Off by default. When enabled, takes priority over CVar profiles for SQW.
--------------------------------------------------------------------------------

GRIPEMS.SQWOptimizer = {}
local SQW = GRIPEMS.SQWOptimizer
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

--------------------------------------------------------------------------------
-- Constants
--------------------------------------------------------------------------------

local MIN_SQW = 50
local MAX_SQW = 400
local DEFAULT_BUFFER = 100
local HYSTERESIS_THRESHOLD = 15
local EWMA_ALPHA = 0.3
local OUTLIER_MULTIPLIER = 3
local SAMPLE_INTERVAL = 10
local MIN_CLICK_RATE = 100
local GCD_SPELL_ID = 61304
local HISTORY_SIZE = 30

--------------------------------------------------------------------------------
-- State
--------------------------------------------------------------------------------

SQW.ewmaLatency = nil
SQW.lastAppliedSQW = nil
SQW.ticker = nil
SQW.advisoryMs = nil
SQW.lastGCD = nil
SQW.originalSQW = nil
-- debugMode now persisted via Settings ("sqwDebug")
SQW.history = {}

--------------------------------------------------------------------------------
-- History
--------------------------------------------------------------------------------

function SQW:RecordHistory(rawLatency)
    local entry = { GetTime(), rawLatency, self.ewmaLatency }
    table.insert(self.history, entry)
    if #self.history > HISTORY_SIZE then
        table.remove(self.history, 1)
    end
end

--------------------------------------------------------------------------------
-- Latency Sampling
--------------------------------------------------------------------------------

function SQW:UpdateLatencySample()
    local _, _, _, latencyWorld = GetNetStats()
    if latencyWorld == 0 then
        return
    end

    if not self.ewmaLatency then
        self.ewmaLatency = latencyWorld
        self:RecordHistory(latencyWorld)
        if GRIPEMS.Settings and GRIPEMS.Settings:Get("sqwDebug") then
            GRIPEMS:Debug("SQW Debug: seed=%dms", latencyWorld)
        end
        return
    end

    if latencyWorld > self.ewmaLatency * OUTLIER_MULTIPLIER then
        if GRIPEMS.Settings and GRIPEMS.Settings:Get("sqwDebug") then
            GRIPEMS:Debug(
                "SQW Debug: REJECTED outlier %dms (>%dx avg %.0fms)",
                latencyWorld,
                OUTLIER_MULTIPLIER,
                self.ewmaLatency
            )
        end
        return
    end

    self.ewmaLatency = EWMA_ALPHA * latencyWorld + (1 - EWMA_ALPHA) * self.ewmaLatency
    self:RecordHistory(latencyWorld)
    if GRIPEMS.Settings and GRIPEMS.Settings:Get("sqwDebug") then
        GRIPEMS:Debug("SQW Debug: sample=%dms ewma=%.1fms", latencyWorld, self.ewmaLatency)
    end
end

--------------------------------------------------------------------------------
-- GCD + Advisory
--------------------------------------------------------------------------------

-- WoW 12.0+ secret-value defense: GetHaste() returns a secret-
-- tagged number; arithmetic on it from addon-tainted code raises
-- a Lua error. pcall the formula and fall back to the no-haste
-- baseline (1500ms) when the secret tag blocks the math.
-- Sister site of TempoAdvisor.lua:GetLiveGCD (4f93676).
-- See reference_wow_12_0_secret_values memory.
function SQW:GetCurrentGCD()
    local spellCD = C_Spell and C_Spell.GetSpellCooldown and C_Spell.GetSpellCooldown(GCD_SPELL_ID)
    if spellCD and spellCD.duration and spellCD.duration > 0 then
        return spellCD.duration * 1000
    end
    local haste = GetHaste() or 0
    local ok, gcd = pcall(function()
        return math.max(750, math.floor(1500 / (1 + haste / 100)))
    end)
    if ok and gcd then
        return gcd
    end
    return math.max(750, 1500)
end

function SQW:CalculateRecommendedClickRate()
    local gcd = self:GetCurrentGCD()
    local sqw = self.lastAppliedSQW or (tonumber(GetCVar("SpellQueueWindow")) or 400)
    local lat = self.ewmaLatency or 0
    self.lastGCD = gcd
    return math.max(MIN_CLICK_RATE, math.floor(gcd - sqw + lat))
end

function SQW:UpdateAdvisory()
    self.advisoryMs = self:CalculateRecommendedClickRate()
end

--------------------------------------------------------------------------------
-- SQW Calculation + Application
--------------------------------------------------------------------------------

function SQW:CalculateOptimalSQW()
    if not self.ewmaLatency then
        return nil
    end
    local S = GRIPEMS.Settings
    local buffer = (S and S:Get("sqwBuffer")) or DEFAULT_BUFFER
    local value = self.ewmaLatency + buffer
    return math.max(MIN_SQW, math.min(MAX_SQW, math.floor(value)))
end

function SQW:MaybeApply(force)
    local optimal = self:CalculateOptimalSQW()
    if not optimal then
        return
    end
    local current = tonumber(GetCVar("SpellQueueWindow")) or 400
    if force or math.abs(optimal - current) >= HYSTERESIS_THRESHOLD then
        SetCVar("SpellQueueWindow", tostring(optimal))
        self.lastAppliedSQW = optimal
        self:UpdateAdvisory()
        if GRIPEMS.Fire then
            GRIPEMS:Fire("SQW_UPDATED", optimal)
        end
        if GRIPEMS.Settings and GRIPEMS.Settings:Get("sqwDebug") then
            GRIPEMS:Debug("SQW Debug: APPLIED %dms (was %dms, delta=%d)", optimal, current, math.abs(optimal - current))
        end
    end
end

--------------------------------------------------------------------------------
-- Start / Stop
--------------------------------------------------------------------------------

function SQW:Start()
    self.originalSQW = tonumber(GetCVar("SpellQueueWindow")) or 400
    self:UpdateLatencySample()
    self:MaybeApply(true)
    if C_Timer and C_Timer.NewTicker then
        self.ticker = C_Timer.NewTicker(SAMPLE_INTERVAL, function()
            self:OnLatencyTick()
        end)
    end
    if GRIPEMS.Fire then
        GRIPEMS:Fire("SQW_OPTIMIZER_STATE")
    end
end

function SQW:Stop()
    if self.ticker then
        self.ticker:Cancel()
    end

    local revertValue = self.originalSQW or 400
    local CPM = GRIPEMS.CvarProfileManager
    if CPM and CPM.GetEffectiveRecommendation then
        local rec = CPM:GetEffectiveRecommendation("SpellQueueWindow")
        if rec then
            revertValue = tonumber(rec) or revertValue
        end
    end
    SetCVar("SpellQueueWindow", tostring(revertValue))

    self.ewmaLatency = nil
    self.lastAppliedSQW = nil
    self.ticker = nil
    self.advisoryMs = nil
    self.originalSQW = nil
    self.history = {}

    if GRIPEMS.Fire then
        GRIPEMS:Fire("SQW_OPTIMIZER_STATE")
    end
end

function SQW:OnLatencyTick()
    self:UpdateLatencySample()
    self:MaybeApply()
end

--------------------------------------------------------------------------------
-- Query
--------------------------------------------------------------------------------

function SQW:IsActive()
    local S = GRIPEMS.Settings
    return S and S:Get("sqwOptimizerEnabled") and self.ticker ~= nil
end

--- Read-only view of the latency sample ring (oldest first).
--- Each entry is { GetTime(), rawLatency, ewmaLatency }.
--- @return table history
function SQW:GetHistory()
    return self.history
end

function SQW:GetState()
    return {
        enabled = self:IsActive(),
        sqw = self.lastAppliedSQW,
        latency = self.ewmaLatency,
        buffer = (GRIPEMS.Settings and GRIPEMS.Settings:Get("sqwBuffer")) or DEFAULT_BUFFER,
        advisoryMs = self.advisoryMs,
        gcd = self.lastGCD or self:GetCurrentGCD(),
        haste = GetHaste(),
        historyCount = #self.history,
    }
end

--------------------------------------------------------------------------------
-- Slash Commands
--------------------------------------------------------------------------------

function SQW:HandleSlashCommand(args)
    local sub = args:match("^(%S+)") or ""
    sub = sub:lower()

    if sub == "on" then
        GRIPEMS.Settings:Set("sqwOptimizerEnabled", true)
        GRIPEMS:Print(L["GEMS_SQW_ENABLED"])
    elseif sub == "off" then
        GRIPEMS.Settings:Set("sqwOptimizerEnabled", false)
        local revert = tonumber(GetCVar("SpellQueueWindow")) or 400
        GRIPEMS:Print(string.format(L["GEMS_SQW_DISABLED"], revert))
    elseif sub == "buffer" then
        local val = tonumber(args:match("buffer%s+(%d+)"))
        if val and val >= 50 and val <= 200 then
            GRIPEMS.Settings:Set("sqwBuffer", val)
            GRIPEMS:Print(string.format(L["GEMS_SQW_BUFFER_SET"], val))
            if self:IsActive() then
                self:MaybeApply(true)
            end
        else
            GRIPEMS:Print(L["GEMS_SQW_BUFFER_RANGE"])
        end
    elseif sub == "debug" then
        local S = GRIPEMS.Settings
        if S then
            local current = S:Get("sqwDebug")
            S:Set("sqwDebug", not current)
            GRIPEMS:Print("SQW debug mode: " .. (not current and "ON" or "OFF"))
        end
    else
        -- Status display (default, including bare /gems sqw)
        local state = self:GetState()
        if state.enabled and state.sqw then
            GRIPEMS:Print(
                string.format(
                    L["GEMS_SQW_STATUS"],
                    state.sqw,
                    math.floor(state.latency or 0),
                    state.buffer,
                    state.advisoryMs or 0
                )
            )
        else
            GRIPEMS:Print(L["GEMS_SQW_OPTIMIZER"] .. ": " .. (state.enabled and "enabled (no data yet)" or "disabled"))
        end
    end
end

--------------------------------------------------------------------------------
-- Initialize
--------------------------------------------------------------------------------

function SQW:Initialize()
    local frame = CreateFrame("Frame")
    self.eventFrame = frame
    frame:RegisterEvent("PLAYER_ENTERING_WORLD")
    frame:RegisterEvent("UNIT_SPELL_HASTE")
    frame:RegisterEvent("ZONE_CHANGED_NEW_AREA")
    frame:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")
    frame:RegisterEvent("PLAYER_LOGOUT")

    frame:SetScript("OnEvent", function(_, event, unit)
        if event == "UNIT_SPELL_HASTE" and unit ~= "player" then
            return
        end
        if event == "PLAYER_ENTERING_WORLD" then
            if self:IsActive() then
                self:UpdateLatencySample()
                self:MaybeApply()
            end
        elseif event == "ZONE_CHANGED_NEW_AREA" then
            if self:IsActive() then
                self:UpdateLatencySample()
                self:MaybeApply()
            end
        elseif event == "UNIT_SPELL_HASTE" then
            if self:IsActive() then
                self:UpdateAdvisory()
            end
        elseif event == "PLAYER_SPECIALIZATION_CHANGED" then
            if self:IsActive() then
                self:UpdateAdvisory()
            end
        elseif event == "PLAYER_LOGOUT" then
            if self:IsActive() and self.originalSQW then
                SetCVar("SpellQueueWindow", tostring(self.originalSQW))
            end
        end
    end)

    -- Start if already enabled
    local S = GRIPEMS.Settings
    if S and S:Get("sqwOptimizerEnabled") then
        self:Start()
    end

    -- Watch setting changes
    if GRIPEMS.RegisterCallback then
        GRIPEMS.RegisterCallback(SQW, "SETTING_CHANGED", function(_, key, value)
            if key == "sqwOptimizerEnabled" then
                if value then
                    SQW:Start()
                else
                    SQW:Stop()
                end
            elseif key == "sqwBuffer" then
                if SQW:IsActive() then
                    SQW:MaybeApply(true)
                end
            end
        end)
    end
end
