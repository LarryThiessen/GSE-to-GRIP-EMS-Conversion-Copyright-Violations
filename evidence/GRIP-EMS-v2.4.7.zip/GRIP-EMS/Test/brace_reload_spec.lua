-- GRIP-EMS: Test spec for the brace-deferral reload state machine (ARENA-RELOAD-ISSUE)
--
-- Created:    2026-06-05
-- Updated:    2026-08-17
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
--
-- Pins the per-slot keying fix for Engine:DeferIfBraced. Before the fix the
-- _braceReload state was keyed only by sequence name, so a brace-free base
-- button eagerly wiped a braced variant's attempts counter every cycle: the
-- cap was unreachable in the mixed braced/clean case and the reload looped
-- every ~3s forever for a permanently-unresolvable {spell:N} in a SUBSET of
-- buttons. The fix keys attempts per physical button slot ("base" / "v"..N)
-- while keeping scheduling per-sequence. These tests drive the state machine
-- directly (no secure buttons, no live timers) and assert that the mixed case
-- caps at BRACE_RELOAD_MAX_ATTEMPTS and writes a "brace-permanent" trace. The
-- manual loop is bounded, so a regression cannot hang the suite.

local ADDON_NAME, GRIPEMS = ...

local TS = GRIPEMS.TestSuite
if not TS then
    return
end

local Engine = GRIPEMS.Engine
local D = GRIPEMS.Defaults

-- A sequence name no real sequence uses, so the test never touches live state
-- and Engine.sequences[NAME] stays nil (the scheduled reload timer is a no-op).
local NAME = "__grip_brace_reload_test__"
local CLEAN = "/cast Fireball"
local BRACED = "/cast {spell:99999999}"

-- Reset just this test's _braceReload entry; leave any real entries untouched.
local function resetState()
    Engine._braceReload = Engine._braceReload or {}
    Engine._braceReload[NAME] = nil
end

-- Drop every trace failure this test produced (all carry seq == NAME) so the
-- suite does not pollute the player's persisted failure ring.
local function cleanupTrace()
    local failures = GRIP_EMS_TRACE and GRIP_EMS_TRACE.failures
    if type(failures) ~= "table" then
        return
    end
    for i = #failures, 1, -1 do
        local rec = failures[i]
        if type(rec) == "table" and rec.seq == NAME then
            table.remove(failures, i)
        end
    end
end

local function countPermanent()
    local failures = GRIP_EMS_TRACE and GRIP_EMS_TRACE.failures
    if type(failures) ~= "table" then
        return 0
    end
    local n = 0
    for _, rec in ipairs(failures) do
        if type(rec) == "table" and rec.seq == NAME and rec.kind == "brace-permanent" then
            n = n + 1
        end
    end
    return n
end

-- ---------------------------------------------------------------------------
-- Tests
-- ---------------------------------------------------------------------------

TS:Register("BraceReload: clean base does not wipe a braced sibling counter", "braceReload", function(self)
    resetState()
    -- Seed a braced variant mid-countdown, then load a brace-free base.
    Engine._braceReload[NAME] = { scheduled = false, slots = { v2 = { attempts = 2, permanent = false } } }
    Engine:DeferIfBraced(NAME, nil, CLEAN, nil, "base", "base")
    local st = Engine._braceReload[NAME]
    local ok = st and st.slots and st.slots.v2 and st.slots.v2.attempts == 2 and st.slots.base == nil
    resetState()
    cleanupTrace()
    if ok then
        self:Pass()
    else
        self:Fail("clean base wiped the braced variant counter (expected v2.attempts == 2, no base slot)")
    end
end)

TS:Register("BraceReload: braced variant caps at max with one permanent trace", "braceReload", function(self)
    resetState()
    cleanupTrace()
    local maxAttempts = D.BRACE_RELOAD_MAX_ATTEMPTS or 3
    -- Simulate the mixed pass: clean base, braced variant, then the reload
    -- timer firing (scheduled reset), repeated past the cap. Bounded loop.
    for _ = 1, maxAttempts + 2 do
        Engine:DeferIfBraced(NAME, nil, CLEAN, nil, "base", "base")
        Engine:DeferIfBraced(NAME, nil, BRACED, nil, "variant 2", "v2")
        local st = Engine._braceReload[NAME]
        if st then
            st.scheduled = false
        end
    end
    local st = Engine._braceReload[NAME]
    local v2 = st and st.slots and st.slots.v2
    local cappedExact = v2 and v2.attempts == maxAttempts
    local baseAbsent = st and st.slots and st.slots.base == nil
    local permanents = countPermanent()
    resetState()
    cleanupTrace()
    if not cappedExact then
        self:Fail("variant attempts did not cap at max (got " .. tostring(v2 and v2.attempts) .. ")")
    elseif not baseAbsent then
        self:Fail("clean base left a stray slot entry")
    elseif permanents ~= 1 then
        self:Fail("expected exactly 1 brace-permanent trace, got " .. tostring(permanents))
    else
        self:Pass()
    end
end)

TS:Register("BraceReload: both braced buttons cap independently", "braceReload", function(self)
    resetState()
    cleanupTrace()
    local maxAttempts = D.BRACE_RELOAD_MAX_ATTEMPTS or 3
    for _ = 1, maxAttempts + 2 do
        Engine:DeferIfBraced(NAME, nil, BRACED, nil, "base", "base")
        Engine:DeferIfBraced(NAME, nil, BRACED, nil, "variant 2", "v2")
        local st = Engine._braceReload[NAME]
        if st then
            st.scheduled = false
        end
    end
    local st = Engine._braceReload[NAME]
    local base = st and st.slots and st.slots.base
    local v2 = st and st.slots and st.slots.v2
    local ok = base and v2 and base.attempts == maxAttempts and v2.attempts == maxAttempts
    local permanents = countPermanent()
    resetState()
    cleanupTrace()
    if not ok then
        self:Fail("expected both slots to cap at max")
    elseif permanents ~= 2 then
        self:Fail("expected 2 brace-permanent traces (one per slot), got " .. tostring(permanents))
    else
        self:Pass()
    end
end)

-- Self-heal: RetryCappedBraceReloads clears a capped entry so a settled cache
-- can grant fresh attempts. Engine.sequences[NAME] is nil here, so no recompile
-- is queued; we only assert the capped entry is dropped.
TS:Register("BraceReload: RetryCappedBraceReloads clears a capped entry", "braceReload", function(self)
    resetState()
    local maxAttempts = D.BRACE_RELOAD_MAX_ATTEMPTS or 3
    Engine._braceReload[NAME] = {
        scheduled = false,
        slots = { base = { attempts = maxAttempts, permanent = true } },
    }
    Engine:RetryCappedBraceReloads()
    local cleared = Engine._braceReload[NAME] == nil
    resetState()
    cleanupTrace()
    if cleared then
        self:Pass()
    else
        self:Fail("RetryCappedBraceReloads did not clear the capped entry")
    end
end)
