-- GRIP-EMS: Keybind Tab
-- Keybind editor panel with display, key capture, and per-spec overview

local ADDON_NAME, GRIPEMS = ...
local UI = GRIPEMS.UI
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS")

-- Upvalue accessor for Defaults
local function D()
    return GRIPEMS.Defaults
end

GRIPEMS.KeybindTab = {}
local KT = GRIPEMS.KeybindTab

--- Check if a key combo conflicts with a ConsolePort binding.
--- @param key string The WoW key combo string (e.g. "ALT-F1")
--- @return string|nil action The bound action name, or nil if no conflict
function KT.CheckConsolePortConflict(key)
    if not ConsolePort or not ConsolePort.GetCurrentBindings then
        return nil
    end
    local bindings = ConsolePort:GetCurrentBindings()
    if bindings and bindings[key] then
        return bindings[key]
    end
    return nil
end

-- Runtime state
KT.currentSeqName = nil
KT.isCapturing = false
-- captureTarget routes key capture to the correct manager:
--   { type = "sequence" }  -> KeybindManager (default)
--   { type = "vehicle", slot = N }  -> VehicleKeybinds
--   { type = "petbattle", slot = N }  -> PetBattleButtons
KT.captureTarget = { type = "sequence" }

-- Human-readable display names for gamepad buttons
local GAMEPAD_DISPLAY_NAMES = {
    PAD1 = "A / Cross",
    PAD2 = "B / Circle",
    PAD3 = "X / Square",
    PAD4 = "Y / Triangle",
    PAD5 = "LB Extra",
    PAD6 = "RB Extra",
    PADDUP = "D-Pad Up",
    PADDDOWN = "D-Pad Down",
    PADDLEFT = "D-Pad Left",
    PADDRIGHT = "D-Pad Right",
    PADLSHOULDER = "Left Bumper",
    PADRSHOULDER = "Right Bumper",
    PADLTRIGGER = "Left Trigger",
    PADRTRIGGER = "Right Trigger",
    PADLSTICK = "Left Stick Click",
    PADRSTICK = "Right Stick Click",
    PADLSTICKUP = "Left Stick Up",
    PADLSTICKDOWN = "Left Stick Down",
    PADLSTICKLEFT = "Left Stick Left",
    PADLSTICKRIGHT = "Left Stick Right",
    PADRSTICKUP = "Right Stick Up",
    PADRSTICKDOWN = "Right Stick Down",
    PADRSTICKLEFT = "Right Stick Left",
    PADRSTICKRIGHT = "Right Stick Right",
    PADPADDLE1 = "Paddle 1",
    PADPADDLE2 = "Paddle 2",
    PADPADDLE3 = "Paddle 3",
    PADPADDLE4 = "Paddle 4",
    PADFORWARD = "Start / Options",
    PADBACK = "Back / Share",
    PADSYSTEM = "System",
    PADSOCIAL = "Social / Share",
}

--- Format a key string with friendly gamepad name if applicable.
--- @param keyStr string|nil The key combo string (e.g. "SHIFT-PAD1")
--- @return string|nil Formatted display string
local function FormatKeyDisplay(keyStr)
    if not keyStr then
        return nil
    end
    local parts = { strsplit("-", keyStr) }
    local baseKey = parts[#parts]
    local friendly = GAMEPAD_DISPLAY_NAMES[baseKey]
    if friendly then
        return keyStr .. " (" .. friendly .. ")"
    end
    return keyStr
end

-- Modifier-only keys to ignore during capture
local MODIFIER_KEYS = {
    LSHIFT = true,
    RSHIFT = true,
    LCTRL = true,
    RCTRL = true,
    LALT = true,
    RALT = true,
}

---------------------------------------------------------------------------
-- Initialization
---------------------------------------------------------------------------

--- Build the keybind tab UI inside the given parent frame (content area).
--- @param parentFrame Frame The content area that hosts tab content
function KT:Init(parentFrame)
    if not parentFrame then
        return
    end
    local C = UI.Colors

    KT.container = parentFrame

    -- Main scroll frame for the keybind tab content
    local frame = CreateFrame("Frame", nil, parentFrame)
    frame:SetAllPoints(parentFrame)
    frame:Hide()
    KT.frame = frame

    local yOff = -8

    -----------------------------------------------------------------------
    -- A) Current Keybind Display
    -----------------------------------------------------------------------
    local kbLabel = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(kbLabel, 10)
    kbLabel:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, yOff)
    kbLabel:SetText(L["GEMS_UI_CURRENT_KEYBIND"])
    kbLabel:SetTextColor(C.textSecondary:GetRGBA())
    KT.kbLabel = kbLabel

    local kbDisplay = frame:CreateFontString(nil, "OVERLAY")
    local fontPath = GameFontNormal:GetFont()
    kbDisplay:SetFont(fontPath, D().KEYBIND_DISPLAY_FONT_SIZE, "OUTLINE")
    kbDisplay:SetPoint("TOPLEFT", kbLabel, "BOTTOMLEFT", 0, -4)
    kbDisplay:SetText(L["GEMS_UI_KEYBIND_DISPLAY_NONE"])
    kbDisplay:SetTextColor(C.textMuted:GetRGBA())
    KT.kbDisplay = kbDisplay

    yOff = -8 - 14 - 4 - D().KEYBIND_DISPLAY_FONT_SIZE - 8

    -----------------------------------------------------------------------
    -- B) Key Capture Row
    -----------------------------------------------------------------------
    local captureRow = CreateFrame("Frame", nil, frame)
    captureRow:SetHeight(D().KEY_CAPTURE_BUTTON_HEIGHT + 4)
    captureRow:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, yOff)
    captureRow:SetPoint("RIGHT", frame, "RIGHT", -8, 0)
    KT.captureRow = captureRow

    -- Set/Change button
    local setBtn = UI:CreateButton(
        captureRow,
        L["GEMS_UI_SET_KEYBIND"],
        D().KEY_CAPTURE_BUTTON_WIDTH,
        D().KEY_CAPTURE_BUTTON_HEIGHT
    )
    setBtn:SetPoint("LEFT", captureRow, "LEFT", 0, 0)
    setBtn:SetScript("OnClick", function()
        KT:StartCapture()
    end)
    setBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.bgRowHover:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
        UI:ShowTooltip(self, L["GEMS_UI_SET_KEYBIND"], L["GEMS_UI_KEYBIND_HINT"])
    end)
    setBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
        UI:HideTooltip()
    end)
    KT.setBtn = setBtn

    -- Clear button
    local clearBtn = UI:CreateButton(captureRow, L["GEMS_UI_CLEAR_KEYBIND"], 70, D().KEY_CAPTURE_BUTTON_HEIGHT)
    clearBtn:SetPoint("LEFT", setBtn, "RIGHT", 4, 0)
    clearBtn:SetScript("OnClick", function()
        if not KT.currentSeqName then
            return
        end
        local KM = GRIPEMS.KeybindManager
        if KM then
            KM:ClearKeybind(KT.currentSeqName)
            KT:RefreshDisplay()
        end
    end)
    clearBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.bgRowHover:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
        UI:ShowTooltip(self, L["GEMS_UI_CLEAR_KEYBIND"])
    end)
    clearBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
        UI:HideTooltip()
    end)
    KT.clearBtn = clearBtn

    -- Capture hint label (ESC to cancel)
    local captureHint = captureRow:CreateFontString(nil, "OVERLAY")
    UI:SetFont(captureHint, 9)
    captureHint:SetPoint("LEFT", clearBtn, "RIGHT", 8, 0)
    captureHint:SetText(L["GEMS_UI_CAPTURE_ESC_HINT"])
    captureHint:SetTextColor(C.textMuted:GetRGBA())
    captureHint:Hide()
    KT.captureHint = captureHint

    yOff = yOff - D().KEY_CAPTURE_BUTTON_HEIGHT - 16

    -----------------------------------------------------------------------
    -- C) Spec Overview
    -----------------------------------------------------------------------
    local specLabel = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(specLabel, 10)
    specLabel:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, yOff)
    specLabel:SetText(L["GEMS_UI_SPEC_KEYBINDS"])
    specLabel:SetTextColor(C.textSecondary:GetRGBA())
    KT.specLabel = specLabel

    -- Spec rows scroll panel (future-proofs for >4 specs)
    local specScroll, specChild = UI:CreateScrollPanel(frame)
    specScroll:SetPoint("TOPLEFT", specLabel, "BOTTOMLEFT", 0, -4)
    specScroll:SetPoint("RIGHT", frame, "RIGHT", -8, 0)
    specScroll:SetHeight(4 * D().SPEC_ROW_HEIGHT)
    local initSpecs = GetNumSpecializations and GetNumSpecializations() or 4
    specChild:SetHeight(math.max(initSpecs, 1) * D().SPEC_ROW_HEIGHT)
    KT.specScroll = specScroll
    KT.specContainer = specChild

    -- Loadout hint text
    local loadoutHint = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(loadoutHint, 9)
    loadoutHint:SetPoint("TOPLEFT", specScroll, "BOTTOMLEFT", 0, -6)
    loadoutHint:SetText(L["GEMS_UI_LOADOUT_COMING_SOON"])
    loadoutHint:SetTextColor(C.textMuted:GetRGBA())
    KT.loadoutHint = loadoutHint

    -----------------------------------------------------------------------
    -- D) Vehicle Keybinds Section (collapsible)
    -----------------------------------------------------------------------
    KT:CreateVehicleSection(frame, specScroll)

    -----------------------------------------------------------------------
    -- E) Pet Battle Keybinds Section (collapsible)
    -----------------------------------------------------------------------
    KT:CreatePetBattleSection(frame)

    -----------------------------------------------------------------------
    -- F) Hint text (bottom)
    -----------------------------------------------------------------------
    local hintText = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(hintText, 9)
    hintText:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 8, 8)
    hintText:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -8, 8)
    hintText:SetText(L["GEMS_UI_KEYBIND_HINT"])
    hintText:SetTextColor(C.textMuted:GetRGBA())
    hintText:SetJustifyH("LEFT")
    hintText:SetWordWrap(true)
    KT.hintText = hintText

    -- Gamepad hint (shown when controller detected)
    local gpHint = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(gpHint, 9)
    gpHint:SetPoint("BOTTOMLEFT", hintText, "TOPLEFT", 0, 4)
    gpHint:SetText(L["GEMS_UI_GAMEPAD_HINT"])
    gpHint:SetTextColor(C.accent:GetRGBA())
    gpHint:Hide()
    KT.gpHint = gpHint

    -----------------------------------------------------------------------
    -- Key capture frame (invisible, fullscreen, eats all keypresses)
    -----------------------------------------------------------------------
    local captureFrame = CreateFrame("Frame", "GRIPEMS_KeyCapture", UIParent)
    captureFrame:SetFrameStrata("FULLSCREEN_DIALOG")
    captureFrame:SetAllPoints(UIParent)
    captureFrame:EnableKeyboard(true)
    captureFrame:EnableGamePadButton(true)
    captureFrame:Hide()

    captureFrame:SetScript("OnKeyDown", function(self, key)
        KT:OnCaptureKeyDown(key)
    end)
    captureFrame:SetScript("OnGamePadButtonDown", function(self, button)
        KT:OnCaptureKeyDown(button)
    end)
    captureFrame:SetScript("OnShow", function(self)
        self:SetPropagateKeyboardInput(false)
    end)
    captureFrame:SetScript("OnHide", function(self)
        self:SetPropagateKeyboardInput(true)
    end)
    KT.captureFrame = captureFrame

    -- Register KEYBIND_CHANGED callback
    if GRIPEMS.RegisterCallback then
        GRIPEMS.RegisterCallback(KT, "KEYBIND_CHANGED", "OnKeybindChanged")
    end
end

---------------------------------------------------------------------------
-- Key capture logic
---------------------------------------------------------------------------

--- Start key capture mode. Checks combat lockdown first.
--- @param target table|nil Optional capture target { type, slot }
function KT:StartCapture(target)
    KT.captureTarget = target or { type = "sequence" }

    -- Sequence capture requires a selected sequence
    if KT.captureTarget.type == "sequence" and not KT.currentSeqName then
        return
    end

    if GRIPEMS.OOCQueue.IsRestricted() then
        GRIPEMS:Print(L["GEMS_UI_CAPTURE_COMBAT"])
        return
    end

    KT.isCapturing = true
    local C = UI.Colors

    -- Update button text
    if KT.setBtn and KT.setBtn.label then
        KT.setBtn.label:SetText(L["GEMS_UI_PRESS_KEY"])
        KT.setBtn:SetBackdropBorderColor(C.accent:GetRGBA())
    end

    -- Show capture hint
    if KT.captureHint then
        KT.captureHint:Show()
    end

    -- Show capture frame (with pcall safety)
    local ok, err = pcall(function()
        if KT.captureFrame then
            KT.captureFrame:Show()
        end
    end)
    if not ok then
        KT:StopCapture()
        GRIPEMS:Print("Capture error: " .. tostring(err))
    end
end

--- Stop key capture mode. Always hides the capture frame safely.
function KT:StopCapture()
    KT.isCapturing = false

    -- CRITICAL: Always hide the capture frame
    if KT.captureFrame then
        KT.captureFrame:Hide()
    end

    -- Hide capture hint
    if KT.captureHint then
        KT.captureHint:Hide()
    end

    -- Restore button text
    KT:UpdateSetButtonLabel()
end

--- Handle a key press during capture mode.
--- @param key string The WoW key name
function KT:OnCaptureKeyDown(key)
    -- Ignore lone modifier keys
    if MODIFIER_KEYS[key] then
        return
    end

    -- Escape cancels capture (deferred so ESCAPE isn't propagated to MainFrame)
    if key == "ESCAPE" then
        C_Timer.After(0, function()
            KT:StopCapture()
        end)
        return
    end

    -- Build combo string: ALT-CTRL-SHIFT-KEY (alphabetical order)
    local parts = {}
    if IsAltKeyDown() then
        parts[#parts + 1] = "ALT"
    end
    if IsControlKeyDown() then
        parts[#parts + 1] = "CTRL"
    end
    if IsShiftKeyDown() then
        parts[#parts + 1] = "SHIFT"
    end
    parts[#parts + 1] = key
    local combo = table.concat(parts, "-")

    local target = KT.captureTarget or { type = "sequence" }

    -- Apply keybind based on capture target type (pcall for safety)
    local ok, err = pcall(function()
        if target.type == "vehicle" then
            local VK = GRIPEMS.VehicleKeybinds
            if VK and target.slot then
                VK:SetKeybind(target.slot, combo)
            end
        elseif target.type == "petbattle" then
            local PBM = GRIPEMS.PetBattleButtons
            if PBM and target.slot then
                PBM:SetKeybind(target.slot, combo)
            end
        else
            -- Default: sequence keybind
            local KM = GRIPEMS.KeybindManager
            -- Detect keybind conflict
            if KM and KM.GetCurrentSpec then
                local specIdx = KM:GetCurrentSpec()
                local specBinds = _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.keybinds and GRIP_EMS_CHAR.keybinds[specIdx]
                if specBinds and specBinds[combo] and specBinds[combo] ~= KT.currentSeqName then
                    UIErrorsFrame:AddMessage(
                        string.format(L["GEMS_UI_KEYBIND_CONFLICT"], combo, specBinds[combo]),
                        1.0,
                        0.5,
                        0.0
                    )
                end
            end
            -- ConsolePort conflict warning
            local cpAction = KT.CheckConsolePortConflict(combo)
            if cpAction then
                UIErrorsFrame:AddMessage(
                    string.format(L["GEMS_UI_KEYBIND_CP_CONFLICT"], combo, tostring(cpAction)),
                    1.0,
                    0.7,
                    0.0
                )
            end
            if KM and KT.currentSeqName then
                KM:SetKeybind(KT.currentSeqName, combo)
            end
        end
    end)

    -- Always stop capture (hides frame)
    KT:StopCapture()
    KT:RefreshDisplay()
    KT:RefreshVehicleSection()
    KT:RefreshPetBattleSection()

    if not ok then
        GRIPEMS:Print("Keybind error: " .. tostring(err))
    end
end

---------------------------------------------------------------------------
-- Display refresh
---------------------------------------------------------------------------

--- Update the Set/Change button label based on current keybind state.
function KT:UpdateSetButtonLabel()
    if not KT.setBtn or not KT.setBtn.label then
        return
    end
    local KM = GRIPEMS.KeybindManager
    local currentKey = KM and KT.currentSeqName and KM:GetKeybind(KT.currentSeqName)

    if currentKey then
        KT.setBtn.label:SetText(L["GEMS_UI_CHANGE_KEYBIND"])
    else
        KT.setBtn.label:SetText(L["GEMS_UI_SET_KEYBIND"])
    end

    local C = UI.Colors
    KT.setBtn:SetBackdropBorderColor(C.border:GetRGBA())
end

--- Refresh the entire keybind tab display.
function KT:RefreshDisplay()
    if not KT.frame then
        return
    end
    local C = UI.Colors
    local KM = GRIPEMS.KeybindManager

    -- Current keybind display
    local currentKey = KM and KT.currentSeqName and KM:GetKeybind(KT.currentSeqName)
    if KT.kbDisplay then
        if currentKey then
            KT.kbDisplay:SetText(FormatKeyDisplay(currentKey))
            KT.kbDisplay:SetTextColor(C.keybindGold:GetRGBA())
        else
            KT.kbDisplay:SetText(L["GEMS_UI_KEYBIND_DISPLAY_NONE"])
            KT.kbDisplay:SetTextColor(C.textMuted:GetRGBA())
        end
    end

    -- Button states
    KT:UpdateSetButtonLabel()

    -- Clear button: disabled if no keybind
    if KT.clearBtn then
        if currentKey then
            KT.clearBtn:Enable()
            KT.clearBtn.label:SetTextColor(C.textPrimary:GetRGBA())
            KT.clearBtn:SetBackdropColor(C.bgButton:GetRGBA())
        else
            KT.clearBtn:Disable()
            KT.clearBtn.label:SetTextColor(C.textMuted:GetRGBA())
            KT.clearBtn:SetBackdropColor(C.bgDeep:GetRGBA())
        end
    end

    -- Combat/restriction lockdown check for buttons
    if GRIPEMS.OOCQueue.IsRestricted() then
        if KT.setBtn then
            KT.setBtn:Disable()
            KT.setBtn.label:SetTextColor(C.textMuted:GetRGBA())
            KT.setBtn:SetBackdropColor(C.bgDeep:GetRGBA())
        end
        if KT.clearBtn then
            KT.clearBtn:Disable()
            KT.clearBtn.label:SetTextColor(C.textMuted:GetRGBA())
            KT.clearBtn:SetBackdropColor(C.bgDeep:GetRGBA())
        end
    else
        if KT.setBtn and KT.currentSeqName then
            KT.setBtn:Enable()
            KT.setBtn.label:SetTextColor(C.textPrimary:GetRGBA())
            KT.setBtn:SetBackdropColor(C.bgButton:GetRGBA())
        end
    end

    -- Spec overview
    KT:RefreshSpecOverview()
end

--- Refresh the spec overview section.
function KT:RefreshSpecOverview()
    if not KT.specContainer then
        return
    end
    local C = UI.Colors
    local KM = GRIPEMS.KeybindManager

    -- Clear existing spec rows
    if KT.specRows then
        for _, row in ipairs(KT.specRows) do
            row:Hide()
        end
    end
    KT.specRows = KT.specRows or {}

    local numSpecs = GetNumSpecializations() or 0
    local currentSpec = KM and KM:GetCurrentSpec() or 0

    for i = 1, numSpecs do
        local _, specName, _, specIcon = C_SpecializationInfo.GetSpecializationInfo(i)
        if not specName then
            specName = "Spec " .. i
        end

        -- Create row frame if needed
        local row = KT.specRows[i]
        if not row then
            row = CreateFrame("Frame", nil, KT.specContainer, "BackdropTemplate")
            row:SetHeight(D().SPEC_ROW_HEIGHT)

            if not row.SetBackdrop then
                Mixin(row, BackdropTemplateMixin)
            end
            row:SetBackdrop(UI.Backdrops.panelNoBorder)

            -- Spec icon
            row.icon = row:CreateTexture(nil, "ARTWORK")
            row.icon:SetSize(20, 20)
            row.icon:SetPoint("LEFT", row, "LEFT", 4, 0)

            -- Spec name
            row.nameText = row:CreateFontString(nil, "OVERLAY")
            UI:SetFont(row.nameText, 11)
            row.nameText:SetPoint("LEFT", row.icon, "RIGHT", 6, 0)

            -- Key display
            row.keyText = row:CreateFontString(nil, "OVERLAY")
            UI:SetFont(row.keyText, 11)
            row.keyText:SetPoint("RIGHT", row, "RIGHT", -4, 0)

            KT.specRows[i] = row
        end

        -- Position
        row:SetPoint("TOPLEFT", KT.specContainer, "TOPLEFT", 0, -(i - 1) * D().SPEC_ROW_HEIGHT)
        row:SetPoint("RIGHT", KT.specContainer, "RIGHT", 0, 0)

        -- Icon
        if specIcon then
            row.icon:SetTexture(specIcon)
        end

        -- Name with (current) suffix
        local isCurrent = (i == currentSpec)
        if isCurrent then
            row.nameText:SetText(specName .. " " .. L["GEMS_UI_CURRENT_SPEC"])
            row.nameText:SetTextColor(C.textPrimary:GetRGBA())
            row:SetBackdropColor(C.bgRowSelected:GetRGBA())
        else
            row.nameText:SetText(specName)
            row.nameText:SetTextColor(C.textSecondary:GetRGBA())
            row:SetBackdropColor(0, 0, 0, 0)
        end

        -- Find keybind for this spec and current sequence
        local specKey = nil
        if KT.currentSeqName and _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.keybinds and GRIP_EMS_CHAR.keybinds[i] then
            for key, seqName in pairs(GRIP_EMS_CHAR.keybinds[i]) do
                if seqName == KT.currentSeqName then
                    specKey = key
                    break
                end
            end
        end

        if specKey then
            row.keyText:SetText(FormatKeyDisplay(specKey))
            row.keyText:SetTextColor(C.keybindGold:GetRGBA())
        else
            row.keyText:SetText(L["GEMS_UI_KEYBIND_DISPLAY_NONE"])
            row.keyText:SetTextColor(C.textMuted:GetRGBA())
        end

        row:Show()
    end

    -- Adjust scroll child height for content
    KT.specContainer:SetHeight(math.max(numSpecs, 1) * D().SPEC_ROW_HEIGHT)
end

---------------------------------------------------------------------------
-- Data flow methods (called by SequenceEditor)
---------------------------------------------------------------------------

--- Load keybind data for a sequence.
--- @param name string Sequence name
function KT:LoadSequence(name)
    KT.currentSeqName = name
    KT:RefreshDisplay()
end

--- Clear the keybind tab.
function KT:Clear()
    KT.currentSeqName = nil
    KT:StopCapture()

    local C = UI.Colors
    if KT.kbDisplay then
        KT.kbDisplay:SetText(L["GEMS_UI_KEYBIND_DISPLAY_NONE"])
        KT.kbDisplay:SetTextColor(C.textMuted:GetRGBA())
    end

    if KT.specRows then
        for _, row in ipairs(KT.specRows) do
            row:Hide()
        end
    end
end

--- Show the keybind tab.
function KT:Show()
    if KT.frame then
        KT.frame:Show()
    end
    if GRIPEMS.gamepadDetected and KT.gpHint then
        KT.gpHint:Show()
    elseif KT.gpHint then
        KT.gpHint:Hide()
    end
    KT:RefreshDisplay()
    KT:RefreshVehicleSection()
    KT:RefreshPetBattleSection()
end

--- Hide the keybind tab.
function KT:Hide()
    if KT.frame then
        KT.frame:Hide()
    end
    KT:StopCapture()
end

---------------------------------------------------------------------------
-- Callback handler
---------------------------------------------------------------------------

--- Respond to KEYBIND_CHANGED events.
function KT:OnKeybindChanged(event, seqName, key)
    if KT.frame and KT.frame:IsShown() then
        KT:RefreshDisplay()
    end
end

--- Respond to VEHICLE_KEYBIND_CHANGED events.
function KT:OnVehicleKeybindChanged()
    if KT.frame and KT.frame:IsShown() then
        KT:RefreshVehicleSection()
    end
end

--- Respond to PET_BATTLE_KEYBIND_CHANGED events.
function KT:OnPetBattleKeybindChanged()
    if KT.frame and KT.frame:IsShown() then
        KT:RefreshPetBattleSection()
    end
end

---------------------------------------------------------------------------
-- Vehicle Keybinds Section
---------------------------------------------------------------------------

--- Create the collapsible vehicle keybinds section (12 slots).
--- @param parent Frame Parent frame
--- @param anchor Frame Frame to anchor below
function KT:CreateVehicleSection(parent, anchor)
    local C = UI.Colors

    -- Container for entire vehicle section
    local section = CreateFrame("Frame", nil, parent)
    section:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", 0, -12)
    section:SetPoint("RIGHT", parent, "RIGHT", -8, 0)
    KT.vehicleSection = section

    -- Collapse header
    local header = CreateFrame("Button", nil, section)
    header:SetHeight(20)
    header:SetPoint("TOPLEFT", section, "TOPLEFT", 0, 0)
    header:SetPoint("RIGHT", section, "RIGHT", 0, 0)

    local headerText = header:CreateFontString(nil, "OVERLAY")
    UI:SetFont(headerText, 10)
    headerText:SetPoint("LEFT", header, "LEFT", 0, 0)
    headerText:SetText(L["GEMS_VEHICLE_KEYBINDS_HEADER"])
    headerText:SetTextColor(C.textSecondary:GetRGBA())
    KT.vehicleHeaderText = headerText

    local collapseIndicator = header:CreateFontString(nil, "OVERLAY")
    UI:SetFont(collapseIndicator, 10)
    collapseIndicator:SetPoint("RIGHT", header, "RIGHT", 0, 0)
    collapseIndicator:SetTextColor(C.textMuted:GetRGBA())
    KT.vehicleCollapseIndicator = collapseIndicator

    -- Content frame (hidden when collapsed)
    local content = CreateFrame("Frame", nil, section)
    content:SetPoint("TOPLEFT", header, "BOTTOMLEFT", 0, -4)
    content:SetPoint("RIGHT", section, "RIGHT", 0, 0)
    KT.vehicleContent = content

    -- Vehicle slot rows
    KT.vehicleRows = {}
    for slot = 1, D().VEHICLE_KEYBIND_SLOTS do
        local row = CreateFrame("Frame", nil, content)
        row:SetHeight(D().SPEC_ROW_HEIGHT)
        row:SetPoint("TOPLEFT", content, "TOPLEFT", 0, -(slot - 1) * D().SPEC_ROW_HEIGHT)
        row:SetPoint("RIGHT", content, "RIGHT", 0, 0)

        -- Slot label
        row.slotLabel = row:CreateFontString(nil, "OVERLAY")
        UI:SetFont(row.slotLabel, 10)
        row.slotLabel:SetPoint("LEFT", row, "LEFT", 4, 0)
        row.slotLabel:SetText(string.format(L["GEMS_VEHICLE_SLOT"], slot))
        row.slotLabel:SetTextColor(C.textSecondary:GetRGBA())

        -- Key display
        row.keyText = row:CreateFontString(nil, "OVERLAY")
        UI:SetFont(row.keyText, 10)
        row.keyText:SetPoint("CENTER", row, "CENTER", 0, 0)
        row.keyText:SetText(L["GEMS_UI_NOT_BOUND"])
        row.keyText:SetTextColor(C.textMuted:GetRGBA())

        -- Clear button
        local clearBtn = UI:CreateButton(row, L["GEMS_UI_CLEAR_KEYBIND"], 50, 20)
        clearBtn:SetPoint("RIGHT", row, "RIGHT", 0, 0)
        clearBtn.slot = slot
        clearBtn:SetScript("OnClick", function()
            local VK = GRIPEMS.VehicleKeybinds
            if VK then
                VK:ClearKeybind(slot)
                KT:RefreshVehicleSection()
            end
        end)

        -- Set button
        local setBtn = UI:CreateButton(row, L["GEMS_UI_SET_KEYBIND"], 60, 20)
        setBtn:SetPoint("RIGHT", clearBtn, "LEFT", -4, 0)
        setBtn.slot = slot
        setBtn:SetScript("OnClick", function()
            KT:StartCapture({ type = "vehicle", slot = slot })
        end)

        row.setBtn = setBtn
        row.clearBtn = clearBtn
        KT.vehicleRows[slot] = row
    end

    content:SetHeight(D().VEHICLE_KEYBIND_SLOTS * D().SPEC_ROW_HEIGHT)

    -- Default collapsed state from saved data
    local expanded = _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.vehicleKeybindsExpanded
    if expanded then
        content:Show()
        collapseIndicator:SetText("[-]")
    else
        content:Hide()
        collapseIndicator:SetText("[+]")
    end

    -- Update section height
    KT:UpdateVehicleSectionHeight()

    header:SetScript("OnClick", function()
        if not _G.GRIP_EMS_CHAR then
            return
        end
        GRIP_EMS_CHAR.vehicleKeybindsExpanded = not GRIP_EMS_CHAR.vehicleKeybindsExpanded
        if GRIP_EMS_CHAR.vehicleKeybindsExpanded then
            content:Show()
            collapseIndicator:SetText("[-]")
        else
            content:Hide()
            collapseIndicator:SetText("[+]")
        end
        KT:UpdateVehicleSectionHeight()
        KT:UpdatePetBattleSectionAnchor()
    end)

    -- Register callback
    if GRIPEMS.RegisterCallback then
        GRIPEMS.RegisterCallback(KT, "VEHICLE_KEYBIND_CHANGED", "OnVehicleKeybindChanged")
    end
end

--- Update the height of the vehicle section based on collapse state.
function KT:UpdateVehicleSectionHeight()
    if not KT.vehicleSection then
        return
    end
    local headerHeight = 20
    if KT.vehicleContent and KT.vehicleContent:IsShown() then
        KT.vehicleSection:SetHeight(headerHeight + 4 + D().VEHICLE_KEYBIND_SLOTS * D().SPEC_ROW_HEIGHT)
    else
        KT.vehicleSection:SetHeight(headerHeight)
    end
end

--- Refresh the vehicle keybinds section display.
function KT:RefreshVehicleSection()
    if not KT.vehicleRows then
        return
    end
    local C = UI.Colors
    local VK = GRIPEMS.VehicleKeybinds

    for slot = 1, D().VEHICLE_KEYBIND_SLOTS do
        local row = KT.vehicleRows[slot]
        if row then
            local key = VK and VK:GetKeybind(slot)
            if key then
                row.keyText:SetText(FormatKeyDisplay(key))
                row.keyText:SetTextColor(C.keybindGold:GetRGBA())
            else
                row.keyText:SetText(L["GEMS_UI_NOT_BOUND"])
                row.keyText:SetTextColor(C.textMuted:GetRGBA())
            end
        end
    end
end

---------------------------------------------------------------------------
-- Pet Battle Keybinds Section
---------------------------------------------------------------------------

--- Create the collapsible pet battle keybinds section (6 slots).
--- @param parent Frame Parent frame
function KT:CreatePetBattleSection(parent)
    local C = UI.Colors

    -- Container for entire pet battle section
    local section = CreateFrame("Frame", nil, parent)
    section:SetPoint("TOPLEFT", KT.vehicleSection, "BOTTOMLEFT", 0, -8)
    section:SetPoint("RIGHT", parent, "RIGHT", -8, 0)
    KT.petBattleSection = section

    -- Collapse header
    local header = CreateFrame("Button", nil, section)
    header:SetHeight(20)
    header:SetPoint("TOPLEFT", section, "TOPLEFT", 0, 0)
    header:SetPoint("RIGHT", section, "RIGHT", 0, 0)

    local headerText = header:CreateFontString(nil, "OVERLAY")
    UI:SetFont(headerText, 10)
    headerText:SetPoint("LEFT", header, "LEFT", 0, 0)
    headerText:SetText(L["GEMS_PET_BATTLE_KEYBINDS_HEADER"])
    headerText:SetTextColor(C.textSecondary:GetRGBA())
    KT.petBattleHeaderText = headerText

    local collapseIndicator = header:CreateFontString(nil, "OVERLAY")
    UI:SetFont(collapseIndicator, 10)
    collapseIndicator:SetPoint("RIGHT", header, "RIGHT", 0, 0)
    collapseIndicator:SetTextColor(C.textMuted:GetRGBA())
    KT.petBattleCollapseIndicator = collapseIndicator

    -- Content frame (hidden when collapsed)
    local content = CreateFrame("Frame", nil, section)
    content:SetPoint("TOPLEFT", header, "BOTTOMLEFT", 0, -4)
    content:SetPoint("RIGHT", section, "RIGHT", 0, 0)
    KT.petBattleContent = content

    -- Slot labels for pet battle
    local slotLabels = D().PET_BATTLE_SLOT_NAMES

    -- Pet battle slot rows
    KT.petBattleRows = {}
    for slot = 1, D().PET_BATTLE_SLOTS do
        local row = CreateFrame("Frame", nil, content)
        row:SetHeight(D().SPEC_ROW_HEIGHT)
        row:SetPoint("TOPLEFT", content, "TOPLEFT", 0, -(slot - 1) * D().SPEC_ROW_HEIGHT)
        row:SetPoint("RIGHT", content, "RIGHT", 0, 0)

        -- Slot label
        row.slotLabel = row:CreateFontString(nil, "OVERLAY")
        UI:SetFont(row.slotLabel, 10)
        row.slotLabel:SetPoint("LEFT", row, "LEFT", 4, 0)
        row.slotLabel:SetText(slotLabels[slot] or ("Slot " .. slot))
        row.slotLabel:SetTextColor(C.textSecondary:GetRGBA())

        -- Key display
        row.keyText = row:CreateFontString(nil, "OVERLAY")
        UI:SetFont(row.keyText, 10)
        row.keyText:SetPoint("CENTER", row, "CENTER", 0, 0)
        row.keyText:SetText(L["GEMS_UI_NOT_BOUND"])
        row.keyText:SetTextColor(C.textMuted:GetRGBA())

        -- Clear button
        local clearBtn = UI:CreateButton(row, L["GEMS_UI_CLEAR_KEYBIND"], 50, 20)
        clearBtn:SetPoint("RIGHT", row, "RIGHT", 0, 0)
        clearBtn.slot = slot
        clearBtn:SetScript("OnClick", function()
            local PBM = GRIPEMS.PetBattleButtons
            if PBM then
                PBM:ClearKeybind(slot)
                KT:RefreshPetBattleSection()
            end
        end)

        -- Set button
        local setBtn = UI:CreateButton(row, L["GEMS_UI_SET_KEYBIND"], 60, 20)
        setBtn:SetPoint("RIGHT", clearBtn, "LEFT", -4, 0)
        setBtn.slot = slot
        setBtn:SetScript("OnClick", function()
            KT:StartCapture({ type = "petbattle", slot = slot })
        end)

        row.setBtn = setBtn
        row.clearBtn = clearBtn
        KT.petBattleRows[slot] = row
    end

    content:SetHeight(D().PET_BATTLE_SLOTS * D().SPEC_ROW_HEIGHT)

    -- Default collapsed state from saved data
    local expanded = _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.petBattleKeybindsExpanded
    if expanded then
        content:Show()
        collapseIndicator:SetText("[-]")
    else
        content:Hide()
        collapseIndicator:SetText("[+]")
    end

    -- Update section height
    KT:UpdatePetBattleSectionHeight()

    header:SetScript("OnClick", function()
        if not _G.GRIP_EMS_CHAR then
            return
        end
        GRIP_EMS_CHAR.petBattleKeybindsExpanded = not GRIP_EMS_CHAR.petBattleKeybindsExpanded
        if GRIP_EMS_CHAR.petBattleKeybindsExpanded then
            content:Show()
            collapseIndicator:SetText("[-]")
        else
            content:Hide()
            collapseIndicator:SetText("[+]")
        end
        KT:UpdatePetBattleSectionHeight()
    end)

    -- Register callback
    if GRIPEMS.RegisterCallback then
        GRIPEMS.RegisterCallback(KT, "PET_BATTLE_KEYBIND_CHANGED", "OnPetBattleKeybindChanged")
    end
end

--- Update the height of the pet battle section based on collapse state.
function KT:UpdatePetBattleSectionHeight()
    if not KT.petBattleSection then
        return
    end
    local headerHeight = 20
    if KT.petBattleContent and KT.petBattleContent:IsShown() then
        KT.petBattleSection:SetHeight(headerHeight + 4 + D().PET_BATTLE_SLOTS * D().SPEC_ROW_HEIGHT)
    else
        KT.petBattleSection:SetHeight(headerHeight)
    end
end

--- Update the pet battle section anchor after vehicle section collapse toggle.
function KT:UpdatePetBattleSectionAnchor()
    if not KT.petBattleSection or not KT.vehicleSection then
        return
    end
    KT.petBattleSection:SetPoint("TOPLEFT", KT.vehicleSection, "BOTTOMLEFT", 0, -8)
end

--- Refresh the pet battle keybinds section display.
function KT:RefreshPetBattleSection()
    if not KT.petBattleRows then
        return
    end
    local C = UI.Colors
    local PBM = GRIPEMS.PetBattleButtons

    for slot = 1, D().PET_BATTLE_SLOTS do
        local row = KT.petBattleRows[slot]
        if row then
            local key = PBM and PBM:GetKeybind(slot)
            if key then
                row.keyText:SetText(FormatKeyDisplay(key))
                row.keyText:SetTextColor(C.keybindGold:GetRGBA())
            else
                row.keyText:SetText(L["GEMS_UI_NOT_BOUND"])
                row.keyText:SetTextColor(C.textMuted:GetRGBA())
            end
        end
    end
end
