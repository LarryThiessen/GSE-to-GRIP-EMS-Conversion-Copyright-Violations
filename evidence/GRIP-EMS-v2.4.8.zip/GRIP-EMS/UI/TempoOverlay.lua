--------------------------------------------------------------------------------
-- TempoOverlay.lua -- Faster, Slower: Popout Overlay + Mismatch Alerts
-- Compact floating frame showing live click rate recommendation, complexity,
-- delta bar, optional CPS sparkline, and mismatch alert visuals.
--------------------------------------------------------------------------------
-- Created: 2026-04-07 (estimated, pre-stamping)
-- Updated: 2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.
-- WCAG 2.3.1 audit (2026-04-19): 1 animation site in this file
-- (alertAnimGroup in FlashAlert). 3 chained Alpha sub-anims totalling
-- ALERT_FLASH_DURATION (1.0s). Fires below 3 flashes per second,
-- covers a small overlay region well under 25 percent of viewport.
-- Compliant without rate cap. reduceMotion guard at the Play site.
--------------------------------------------------------------------------------
local _, GRIPEMS = ...

GRIPEMS.TempoOverlay = {}
local TO = GRIPEMS.TempoOverlay
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

-- Lazy module accessors (avoid load-order dependency)
local function S()
    return GRIPEMS.Settings
end
local function TA()
    return GRIPEMS.TempoAdvisor
end
local function Engine()
    return GRIPEMS.Engine
end
local function ET()
    return GRIPEMS.ExecutionTracer
end

---------------------------------------------------------------------------
-- Constants
---------------------------------------------------------------------------
local OVERLAY_WIDTH = 200
local OVERLAY_HEIGHT_NORMAL = 90
local OVERLAY_HEIGHT_SPARKLINE = 130
local SPARKLINE_BAR_COUNT = 10
local SPARKLINE_BAR_WIDTH = 14
local SPARKLINE_BAR_GAP = 2
local SPARKLINE_MAX_HEIGHT = 30
local REDRAW_THROTTLE = 0.5
local ALERT_FLASH_DURATION = 1.0
local DEFAULT_POS = { "TOPRIGHT", "UIParent", "TOPRIGHT", -200, -200 }

-- Reusable table for UpdateSparkline (avoid per-call garbage)
local sparklineBuckets = {}

-- Delta thresholds (ms)
local DELTA_GREEN = 50
local DELTA_YELLOW = 150

-- Alert sound IDs (numeric only -- no string names)
-- Sound constants moved to Settings (tempoAlertSoundSlow, tempoAlertSoundFast)

-- Pin icon textures
local PIN_LOCKED = "Interface\\Buttons\\UI-CheckBox-Check"
local PIN_UNLOCKED = "Interface\\Buttons\\UI-CheckBox-Up"

---------------------------------------------------------------------------
-- State
---------------------------------------------------------------------------
TO.frame = nil
TO.locked = false
TO.lastRedraw = 0
TO.alertFlashing = false
TO._updatingFromSetting = false

---------------------------------------------------------------------------
-- Frame creation (called once from Init)
---------------------------------------------------------------------------
local function CreateOverlayFrame()
    local UI = GRIPEMS.UI
    local C = UI.Colors

    local overlay = UI:ReclaimFrame("GRIPEMSTempoOverlay", "Frame", UIParent, "BackdropTemplate")
    overlay:SetSize(OVERLAY_WIDTH, OVERLAY_HEIGHT_NORMAL)
    overlay:SetFrameStrata("MEDIUM")
    overlay:SetFrameLevel(110)
    overlay:SetBackdrop(UI.Backdrops.panel)
    overlay:SetBackdropColor(0.10, 0.10, 0.14, 0.92)
    overlay:SetBackdropBorderColor(0.30, 0.30, 0.35, 1)
    if GRIPEMS.UI and GRIPEMS.UI.RegisterPanelFrame then
        GRIPEMS.UI:RegisterPanelFrame(overlay, "overlay", "overlay.hud")
    end
    overlay:SetClampedToScreen(true)
    overlay:SetMovable(true)
    overlay:EnableMouse(true)
    overlay:RegisterForDrag("LeftButton")
    overlay:SetScript("OnDragStart", function(self)
        if not TO.locked then
            self:StartMoving()
        end
    end)
    overlay:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        TO:SavePosition()
    end)
    overlay:Hide()

    ---------------------------------------------------------------------------
    -- Title bar
    ---------------------------------------------------------------------------
    local titleBar = CreateFrame("Frame", nil, overlay, "BackdropTemplate")
    titleBar:SetHeight(18)
    titleBar:SetPoint("TOPLEFT", overlay, "TOPLEFT", 0, 0)
    titleBar:SetPoint("TOPRIGHT", overlay, "TOPRIGHT", 0, 0)
    titleBar:SetBackdrop(UI.Backdrops.panelNoBorder)
    titleBar:SetBackdropColor(C.bgPanel:GetRGBA())

    local titleText = titleBar:CreateFontString(nil, "OVERLAY")
    UI:SetFont(titleText, 10, "OUTLINE")
    titleText:SetPoint("LEFT", titleBar, "LEFT", 6, 0)
    titleText:SetText(L["FS_OVERLAY_TITLE"])
    titleText:SetTextColor(C.accent:GetRGBA())
    overlay.titleText = titleText

    -- Close button (X)
    local closeBtn = CreateFrame("Button", nil, titleBar)
    closeBtn:SetSize(14, 14)
    closeBtn:SetPoint("RIGHT", titleBar, "RIGHT", -4, 0)
    closeBtn:SetNormalTexture("Interface\\Buttons\\UI-Panel-MinimizeButton-Up")
    closeBtn:SetHighlightTexture("Interface\\Buttons\\UI-Panel-MinimizeButton-Highlight")
    closeBtn:SetScript("OnClick", function()
        TO:Hide()
    end)
    overlay.closeBtn = closeBtn

    -- Pin button (lock/unlock toggle)
    local pinBtn = CreateFrame("Button", nil, titleBar)
    pinBtn:SetSize(14, 14)
    local pinGap = UI:IsLargeTargets() and -20 or -2
    pinBtn:SetPoint("RIGHT", closeBtn, "LEFT", pinGap, 0)
    pinBtn:SetNormalTexture(PIN_UNLOCKED)
    pinBtn:SetScript("OnClick", function()
        TO:ToggleLock()
    end)
    pinBtn:SetScript("OnEnter", function(self)
        UI:ShowTooltip(self, TO.locked and L["FS_OVERLAY_LOCKED"] or L["FS_OVERLAY_UNLOCKED"], nil, nil)
    end)
    pinBtn:SetScript("OnLeave", function()
        UI:HideTooltip()
    end)
    overlay.pinBtn = pinBtn

    ---------------------------------------------------------------------------
    -- Content area
    ---------------------------------------------------------------------------
    local contentTop = -20 -- below title bar

    -- Line 1: Recommended rate (large font)
    local line1 = overlay:CreateFontString(nil, "OVERLAY")
    UI:SetFont(line1, 14, "OUTLINE")
    line1:SetPoint("TOPLEFT", overlay, "TOPLEFT", 8, contentTop)
    line1:SetPoint("TOPRIGHT", overlay, "TOPRIGHT", -8, contentTop)
    line1:SetJustifyH("LEFT")
    line1:SetTextColor(C.textPrimary:GetRGBA())
    line1:SetText("-- /sec")
    overlay.line1 = line1

    -- Line 2: Complexity + key stat (normal font)
    local line2 = overlay:CreateFontString(nil, "OVERLAY")
    UI:SetFont(line2, 10)
    line2:SetPoint("TOPLEFT", line1, "BOTTOMLEFT", 0, -4)
    line2:SetPoint("TOPRIGHT", line1, "BOTTOMRIGHT", 0, -4)
    line2:SetJustifyH("LEFT")
    line2:SetTextColor(C.textSecondary:GetRGBA())
    line2:SetText("")
    overlay.line2 = line2

    -- Line 3: Status bar + delta text
    local barBg = CreateFrame("Frame", nil, overlay, "BackdropTemplate")
    barBg:SetHeight(12)
    barBg:SetPoint("TOPLEFT", line2, "BOTTOMLEFT", 0, -4)
    barBg:SetPoint("TOPRIGHT", line2, "BOTTOMRIGHT", 0, -4)
    barBg:SetBackdrop(UI.Backdrops.panelNoBorder)
    barBg:SetBackdropColor(0.08, 0.08, 0.10, 0.9)
    overlay.barBg = barBg

    local barFill = barBg:CreateTexture(nil, "ARTWORK")
    barFill:SetPoint("TOPLEFT", barBg, "TOPLEFT", 1, -1)
    barFill:SetPoint("BOTTOMLEFT", barBg, "BOTTOMLEFT", 1, 1)
    barFill:SetWidth(1)
    barFill:SetColorTexture(0, 0.8, 0.4, 1)
    overlay.barFill = barFill

    local barText = barBg:CreateFontString(nil, "OVERLAY")
    UI:SetFont(barText, 9)
    barText:SetPoint("CENTER", barBg, "CENTER", 0, 0)
    barText:SetTextColor(C.textPrimary:GetRGBA())
    barText:SetText("")
    overlay.barText = barText

    -- Hold mode text (replaces bar when in hold mode)
    local holdText = overlay:CreateFontString(nil, "OVERLAY")
    UI:SetFont(holdText, 10)
    holdText:SetPoint("TOPLEFT", line2, "BOTTOMLEFT", 0, -4)
    holdText:SetPoint("TOPRIGHT", line2, "BOTTOMRIGHT", 0, -4)
    holdText:SetJustifyH("LEFT")
    holdText:SetTextColor(C.gripGreen:GetRGBA())
    holdText:SetText("")
    holdText:Hide()
    overlay.holdText = holdText

    ---------------------------------------------------------------------------
    -- Line 4: Optional sparkline (mini bar chart of rolling 10s CPS)
    ---------------------------------------------------------------------------
    local sparkContainer = CreateFrame("Frame", nil, overlay)
    sparkContainer:SetHeight(SPARKLINE_MAX_HEIGHT + 4)
    sparkContainer:SetPoint("TOPLEFT", barBg, "BOTTOMLEFT", 0, -4)
    sparkContainer:SetPoint("TOPRIGHT", barBg, "BOTTOMRIGHT", 0, -4)
    sparkContainer:Hide()
    overlay.sparkContainer = sparkContainer

    local sparkBars = {}
    for i = 1, SPARKLINE_BAR_COUNT do
        local bar = sparkContainer:CreateTexture(nil, "ARTWORK")
        bar:SetWidth(SPARKLINE_BAR_WIDTH)
        bar:SetHeight(1)
        bar:SetPoint(
            "BOTTOMLEFT",
            sparkContainer,
            "BOTTOMLEFT",
            (i - 1) * (SPARKLINE_BAR_WIDTH + SPARKLINE_BAR_GAP) + 2,
            2
        )
        bar:SetColorTexture(C.gripGreen:GetRGB())
        sparkBars[i] = bar
    end
    overlay.sparkBars = sparkBars

    local sparkLabel = sparkContainer:CreateFontString(nil, "OVERLAY")
    UI:SetFont(sparkLabel, 8)
    sparkLabel:SetPoint("BOTTOMRIGHT", sparkContainer, "BOTTOMRIGHT", -2, 2)
    sparkLabel:SetTextColor(C.textMuted:GetRGBA())
    sparkLabel:SetText("CPS")
    overlay.sparkLabel = sparkLabel

    ---------------------------------------------------------------------------
    -- Alert flash border texture
    ---------------------------------------------------------------------------
    local alertBorder = overlay:CreateTexture(nil, "OVERLAY")
    alertBorder:SetPoint("TOPLEFT", overlay, "TOPLEFT", -2, 2)
    alertBorder:SetPoint("BOTTOMRIGHT", overlay, "BOTTOMRIGHT", 2, -2)
    alertBorder:SetColorTexture(1, 0, 0, 0)
    alertBorder:SetAlpha(0)
    overlay.alertBorder = alertBorder

    local alertAnimGroup = alertBorder:CreateAnimationGroup()
    local flashIn = alertAnimGroup:CreateAnimation("Alpha")
    flashIn:SetFromAlpha(0)
    flashIn:SetToAlpha(0.6)
    flashIn:SetDuration(0.15)
    flashIn:SetOrder(1)
    local flashHold = alertAnimGroup:CreateAnimation("Alpha")
    flashHold:SetFromAlpha(0.6)
    flashHold:SetToAlpha(0.6)
    flashHold:SetDuration(ALERT_FLASH_DURATION - 0.30)
    flashHold:SetOrder(2)
    local flashOut = alertAnimGroup:CreateAnimation("Alpha")
    flashOut:SetFromAlpha(0.6)
    flashOut:SetToAlpha(0)
    flashOut:SetDuration(0.15)
    flashOut:SetOrder(3)
    alertAnimGroup:SetScript("OnFinished", function()
        alertBorder:SetAlpha(0)
        TO.alertFlashing = false
    end)
    overlay.alertAnimGroup = alertAnimGroup

    return overlay
end

---------------------------------------------------------------------------
-- Position save / restore (5-element format matching TrackerHUD)
---------------------------------------------------------------------------
function TO:SavePosition()
    if not TO.frame then
        return
    end
    local point, _, relPoint, x, y = TO.frame:GetPoint(1)
    local db = GRIPEMS.Settings and GRIPEMS.Settings.db
    if not (db and db.profile and db.profile.tempoOverlay and db.profile.tempoOverlay.position) then
        return
    end
    local pos = db.profile.tempoOverlay.position
    pos.point = point
    pos.relPoint = relPoint
    pos.x = x
    pos.y = y
end

function TO:RestorePosition()
    if not TO.frame then
        return
    end
    local db = GRIPEMS.Settings and GRIPEMS.Settings.db
    local pos = db and db.profile and db.profile.tempoOverlay and db.profile.tempoOverlay.position
    TO.frame:ClearAllPoints()
    if pos and pos.point then
        TO.frame:SetPoint(pos.point, UIParent, pos.relPoint or pos.point, pos.x or 0, pos.y or 0)
    else
        TO.frame:SetPoint(DEFAULT_POS[1], UIParent, DEFAULT_POS[3], DEFAULT_POS[4], DEFAULT_POS[5])
    end
end

---------------------------------------------------------------------------
-- Lock / unlock
---------------------------------------------------------------------------
function TO:ToggleLock()
    TO.locked = not TO.locked
    if _G.GRIP_EMS_CHAR then
        GRIP_EMS_CHAR.tempoOverlayLocked = TO.locked
    end
    if TO.frame and TO.frame.pinBtn then
        TO.frame.pinBtn:SetNormalTexture(TO.locked and PIN_LOCKED or PIN_UNLOCKED)
    end
    if TO.locked then
        GRIPEMS:Print(L["FS_OVERLAY_LOCKED"])
    else
        GRIPEMS:Print(L["FS_OVERLAY_UNLOCKED"])
    end
end

---------------------------------------------------------------------------
-- Visibility
---------------------------------------------------------------------------
function TO:Show()
    if not TO.frame then
        TO.frame = CreateOverlayFrame()
        TO:RestorePosition()
    end
    TO.frame:Show()
    if not TO._updatingFromSetting then
        S():Set("tempoOverlayShown", true)
    end
    TO:Refresh()
end

function TO:Hide()
    if TO.frame then
        TO.frame:Hide()
    end
    if not TO._updatingFromSetting then
        S():Set("tempoOverlayShown", false)
    end
end

function TO:Toggle()
    if TO.frame and TO.frame:IsShown() then
        TO:Hide()
    else
        TO:Show()
    end
end

function TO:IsShown()
    return TO.frame and TO.frame:IsShown()
end

---------------------------------------------------------------------------
-- Delta bar update
---------------------------------------------------------------------------
local function UpdateDeltaBar(overlay, recommendedMs, actualMs, isHoldMode)
    if not overlay then
        return
    end

    -- Hold mode: show status text instead of bar
    if isHoldMode then
        overlay.barBg:Hide()
        overlay.holdText:Show()
        overlay.holdText:SetText(string.format(L["FS_HOLD_AUTOTUNED"], recommendedMs))
        return
    end

    overlay.holdText:Hide()
    overlay.barBg:Show()

    if not actualMs or actualMs <= 0 then
        overlay.barFill:SetWidth(1)
        overlay.barText:SetText("")
        return
    end

    local delta = actualMs - recommendedMs
    local absDelta = math.abs(delta)
    local barWidth = math.max(
        1,
        math.min(overlay.barBg:GetWidth() - 2, (overlay.barBg:GetWidth() - 2) * math.min(1, 1 - absDelta / 500))
    )

    overlay.barFill:SetWidth(barWidth)

    -- Color coding
    local r, g, b
    if absDelta <= DELTA_GREEN then
        r, g, b = 0, 0.8, 0.4 -- green
    elseif absDelta <= DELTA_YELLOW then
        r, g, b = 1, 0.8, 0 -- yellow
    else
        r, g, b = 1, 0.27, 0.27 -- red
    end
    overlay.barFill:SetColorTexture(r, g, b, 1)

    -- Tempo labels: pressing faster than rec is fine for spam macros
    if delta <= DELTA_GREEN then
        -- At or faster than recommended -- all good
        overlay.barText:SetText(L["FS_TEMPO_JUST_RIGHT"])
    elseif delta <= DELTA_YELLOW then
        -- Slightly slower than recommended
        overlay.barText:SetText(L["FS_TEMPO_FASTER"])
    else
        -- Much slower than recommended
        overlay.barText:SetText(L["FS_TEMPO_FASTER_URGENT"])
    end
end

---------------------------------------------------------------------------
-- Sparkline update
---------------------------------------------------------------------------
local function UpdateSparkline(overlay)
    if not overlay or not overlay.sparkContainer then
        return
    end

    local showSparkline = S():Get("tempoSparkline")
    if not showSparkline then
        overlay.sparkContainer:Hide()
        overlay:SetHeight(OVERLAY_HEIGHT_NORMAL)
        return
    end

    overlay.sparkContainer:Show()
    overlay:SetHeight(OVERLAY_HEIGHT_SPARKLINE)

    -- Get click times from ExecutionTracer
    local et = ET()
    local clickTimes = et and et._clickTimes
    if not clickTimes or #clickTimes < 2 then
        -- No data -- flatten all bars
        for i = 1, SPARKLINE_BAR_COUNT do
            overlay.sparkBars[i]:SetHeight(1)
        end
        return
    end

    -- Build CPS buckets for last 10 seconds
    local now = GetTime()
    local bucketDuration = 10 / SPARKLINE_BAR_COUNT -- 1s per bucket
    wipe(sparklineBuckets)
    local buckets = sparklineBuckets
    for i = 1, SPARKLINE_BAR_COUNT do
        buckets[i] = 0
    end

    for _, t in ipairs(clickTimes) do
        local age = now - t
        if age >= 0 and age < 10 then
            local bucket = math.floor(age / bucketDuration) + 1
            if bucket >= 1 and bucket <= SPARKLINE_BAR_COUNT then
                -- Reverse so newest is on the right
                local idx = SPARKLINE_BAR_COUNT - bucket + 1
                buckets[idx] = buckets[idx] + 1
            end
        end
    end

    -- Scale to bucket duration to get CPS
    local maxCPS = 1
    for i = 1, SPARKLINE_BAR_COUNT do
        buckets[i] = buckets[i] / bucketDuration
        if buckets[i] > maxCPS then
            maxCPS = buckets[i]
        end
    end

    -- Update bar heights
    for i = 1, SPARKLINE_BAR_COUNT do
        local height = math.max(1, math.floor((buckets[i] / maxCPS) * SPARKLINE_MAX_HEIGHT))
        overlay.sparkBars[i]:SetHeight(height)
    end
end

---------------------------------------------------------------------------
-- Mismatch alert
---------------------------------------------------------------------------
function TO:FlashAlert(alertType)
    if not TO.frame or not TO.frame.alertBorder then
        return
    end
    if TO.alertFlashing then
        return
    end

    -- Check settings
    if not S():Get("tempoAlertEnabled") then
        return
    end
    if not S():Get("tempoAlertVisual") then
        return
    end

    -- Set color: yellow for too fast, red for too slow
    if alertType == "fast" then
        TO.frame.alertBorder:SetColorTexture(1, 0.8, 0, 1)
    else
        TO.frame.alertBorder:SetColorTexture(1, 0.27, 0.27, 1)
    end

    TO.alertFlashing = true
    TO.frame.alertAnimGroup:Stop()
    TO.frame.alertBorder:SetAlpha(0)
    local a = GRIPEMS.Settings.db.profile.accessibility
    -- flickerSafe overrides reduceMotion -- both intentionally lose the
    -- pulse animation; flickerSafe additionally mutes the sustained
    -- alpha (0.3 vs 0.6) for photosensitivity-safe display.
    if a.flickerSafe then
        TO.frame.alertBorder:SetAlpha(0.3)
        if C_Timer and C_Timer.After then
            C_Timer.After(ALERT_FLASH_DURATION, function()
                if TO.frame and TO.frame.alertBorder then
                    TO.frame.alertBorder:SetAlpha(0)
                end
                TO.alertFlashing = false
            end)
        end
    elseif a.reduceMotion then
        -- Existing reduceMotion path: sustained 0.6 alpha for ALERT_FLASH_DURATION
        TO.frame.alertBorder:SetAlpha(0.6)
        if C_Timer and C_Timer.After then
            C_Timer.After(ALERT_FLASH_DURATION, function()
                TO.frame.alertBorder:SetAlpha(0)
                TO.alertFlashing = false
            end)
        end
    else
        TO.frame.alertAnimGroup:Play()
    end

    -- Audio alert (sound + channel from settings)
    if S():Get("tempoAlertAudio") then
        local channel = S():Get("tempoAlertChannel") or "Master"
        if alertType == "fast" then
            PlaySound(S():Get("tempoAlertSoundFast") or 37666, channel)
        else
            PlaySound(S():Get("tempoAlertSoundSlow") or 43505, channel)
        end
    end
end

---------------------------------------------------------------------------
-- Main refresh (throttled)
---------------------------------------------------------------------------
function TO:Refresh()
    if not TO.frame or not TO.frame:IsShown() then
        return
    end

    local now = GetTime()
    TO.lastRedraw = now

    local overlay = TO.frame
    local ta = TA()
    local eng = Engine()
    local liveCPS = eng and eng.GetButtonPressRate and eng:GetButtonPressRate() or 0
    local liveMs = liveCPS > 0 and math.floor(1000 / liveCPS) or 0

    -- Determine active sequence
    local seqName = eng and eng._lastClickedSequence
    if not seqName or not ta then
        overlay.line1:SetText(L["FS_LDB_NO_SEQ"])
        overlay.line2:SetText("")
        UpdateDeltaBar(overlay, 0, nil, false)
        UpdateSparkline(overlay)
        return
    end

    -- Get recommendation
    local rec = ta:GetRecommendation(seqName)
    -- Force fresh analysis once per session (stored recs may be stale)
    if not ta._analyzedThisSession[seqName] and ta._spellCacheReady then
        local entry = eng.sequences and eng.sequences[seqName]
        if entry and entry.data then
            local result = ta:AnalyzeSequence(seqName, entry.data)
            if result then
                rec = ta:GetRecommendation(seqName)
            end
        end
        ta._analyzedThisSession[seqName] = true
    end
    if not rec then
        -- Try analyzing now (fallback for sequences with no stored rec)
        local entry = eng.sequences and eng.sequences[seqName]
        if entry and entry.data then
            local result = ta:AnalyzeSequence(seqName, entry.data)
            if result then
                rec = ta:GetRecommendation(seqName)
            end
        end
    end

    if not rec or not rec.recommendedMs then
        overlay.line1:SetText(L["FS_LDB_NO_SEQ"])
        overlay.line2:SetText("")
        UpdateDeltaBar(overlay, 0, nil, false)
        UpdateSparkline(overlay)
        return
    end

    -- Check hold mode
    local isHoldMode = ta:IsHoldMode(seqName)

    -- Line 1: live CPS when active, else recommended rate
    local recCPS = rec.recommendedMs > 0 and math.floor(1000 / rec.recommendedMs) or 0
    if isHoldMode then
        overlay.line1:SetText(string.format(L["FS_LDB_HOLD"], rec.recommendedMs))
    elseif liveCPS > 0 then
        overlay.line1:SetText(string.format("%.1f/sec . rec %dms", liveCPS, rec.recommendedMs))
    else
        overlay.line1:SetText(string.format(L["FS_LDB_SPAM"], recCPS, rec.recommendedMs))
    end

    -- Line 2: complexity + key stat
    local complexityLabel = rec.complexity or "Standard"
    local complexityKey = "FS_COMPLEXITY_" .. string.upper(complexityLabel)
    local localizedComplexity = L[complexityKey] or complexityLabel

    -- Count off-GCD steps from stored data
    local offGCDCount = 0
    if rec.offGCDCount then
        offGCDCount = rec.offGCDCount
    end

    local line2Text
    if offGCDCount > 0 then
        line2Text = string.format("%s . %d off-GCD steps", localizedComplexity, offGCDCount)
    else
        line2Text = localizedComplexity
    end
    local eff = GRIPEMS.TempoAdvisor and GRIPEMS.TempoAdvisor:GetEffectiveConfidence(rec)
    if eff == "Calibrated" then
        line2Text = line2Text .. " (cal.)"
    elseif eff == "Estimated" then
        line2Text = line2Text .. " (est.)"
    end
    overlay.line2:SetText(line2Text)

    -- Line 3: delta bar (live measurement vs recommendation)
    UpdateDeltaBar(overlay, rec.recommendedMs, liveMs, isHoldMode)

    -- Line 4: sparkline
    UpdateSparkline(overlay)
end

---------------------------------------------------------------------------
-- Callback handlers
---------------------------------------------------------------------------
function TO:OnSettingChanged(_, key)
    if not key then
        return
    end
    if key == "tempoOverlayShown" then
        TO._updatingFromSetting = true
        if S():Get("tempoOverlayShown") then
            TO:Show()
        else
            TO:Hide()
        end
        TO._updatingFromSetting = false
    elseif key == "tempoSparkline" then
        TO:Refresh()
    elseif key == "msClickRate" then
        TO:Refresh()
    end
end

function TO:OnSpellCacheReady()
    local ta = TA()
    if ta then
        ta._spellCacheReady = true
        -- Invalidate all session analysis to re-analyze with real spell data
        if ta._analyzedThisSession then
            wipe(ta._analyzedThisSession)
        end
    end
    TO:Refresh()
end

function TO:OnTempoUpdated()
    -- SQW or recommendation changed -- force re-analysis next refresh
    local ta = TA()
    local eng = Engine()
    local seqName = eng and eng._lastClickedSequence
    if ta and ta._analyzedThisSession and seqName then
        ta._analyzedThisSession[seqName] = nil
    end
    TO:Refresh()
end

function TO:OnSequenceChanged()
    TO:Refresh()
end

function TO:OnEvent()
    TO:Refresh()
end

---------------------------------------------------------------------------
-- Initialization
---------------------------------------------------------------------------
function TO:Init()
    -- Create frame
    TO.frame = CreateOverlayFrame()
    TO:RestorePosition()

    -- One-shot legacy migration: pre-FS-AUDIT-06 builds wrote position to
    -- GRIP_EMS_CHAR.overlayPos (per-character). Copy any remaining legacy
    -- value into the active profile's tempoOverlay.position and nil out
    -- the old field so migration self-disarms. Each character that had a
    -- custom position seeds whichever profile is active at that login.
    if _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.overlayPos then
        local legacy = GRIP_EMS_CHAR.overlayPos
        local db = GRIPEMS.Settings and GRIPEMS.Settings.db
        if db and db.profile and db.profile.tempoOverlay and db.profile.tempoOverlay.position then
            local pos = db.profile.tempoOverlay.position
            pos.point = legacy[1] or pos.point
            pos.relPoint = legacy[3] or pos.relPoint
            pos.x = legacy[4] or pos.x
            pos.y = legacy[5] or pos.y
            TO:RestorePosition()
        end
        GRIP_EMS_CHAR.overlayPos = nil
    end

    -- Re-anchor on profile change so the overlay follows profile-scoped
    -- preferences (FS-AUDIT-06). Mirrors the profile-change watch in UI/CursorOverlay.lua.
    local db = GRIPEMS.Settings and GRIPEMS.Settings.db
    if db and db.RegisterCallback then
        db.RegisterCallback(TO, "OnProfileChanged", "RestorePosition")
        db.RegisterCallback(TO, "OnProfileCopied", "RestorePosition")
        db.RegisterCallback(TO, "OnProfileReset", "RestorePosition")
    end

    GRIPEMS:Debug("TempoOverlay: Init complete")

    -- Restore lock state from SavedVariables
    if _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.tempoOverlayLocked then
        TO.locked = true
        if TO.frame and TO.frame.pinBtn then
            TO.frame.pinBtn:SetNormalTexture(PIN_LOCKED)
        end
    end

    -- Periodic refresh via ticker (replaces OnUpdate to avoid per-frame overhead)
    if C_Timer and C_Timer.NewTicker then
        C_Timer.NewTicker(REDRAW_THROTTLE, function()
            if TO.frame and TO.frame:IsShown() then
                TO:Refresh()
            end
        end)
    end

    -- Register callbacks
    if GRIPEMS.RegisterCallback then
        GRIPEMS.RegisterCallback(TO, "SETTING_CHANGED", "OnSettingChanged")
        GRIPEMS.RegisterCallback(TO, "SQW_UPDATED", "OnTempoUpdated")
        GRIPEMS.RegisterCallback(TO, "TEMPO_RECOMMENDATION_UPDATED", "OnTempoUpdated")
        GRIPEMS.RegisterCallback(TO, "SEQUENCE_CREATED", "OnSequenceChanged")
        GRIPEMS.RegisterCallback(TO, "SEQUENCE_DELETED", "OnSequenceChanged")
        GRIPEMS.RegisterCallback(TO, "SEQUENCE_UPDATED", "OnSequenceChanged")
        GRIPEMS.RegisterCallback(TO, "SPELL_CACHE_REFRESHED", "OnSpellCacheReady")
        GRIPEMS.RegisterCallback(TO, "TEMPO_MISMATCH_SLOW", function()
            TO:FlashAlert("slow")
        end)
        GRIPEMS.RegisterCallback(TO, "TEMPO_MISMATCH_FAST", function()
            TO:FlashAlert("fast")
        end)
    end

    -- Event frame for haste/spec changes
    local eventFrame = CreateFrame("Frame")
    eventFrame:RegisterEvent("UNIT_SPELL_HASTE")
    eventFrame:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED")
    eventFrame:SetScript("OnEvent", function(self, event, unit)
        -- Re-analyze active sequence on haste change so recommendation stays fresh
        if event == "UNIT_SPELL_HASTE" then
            if unit ~= "player" then
                return
            end
            local eng = Engine()
            local ta = TA()
            local seqName = eng and eng._lastClickedSequence
            if seqName and ta and ta._analyzedThisSession then
                ta._analyzedThisSession[seqName] = nil
            end
        end
        TO:Refresh()
    end)
    TO.eventFrame = eventFrame

    -- Restore visibility from settings
    if S():Get("tempoOverlayShown") then
        TO:Show()
    end
end
