-- GRIP-EMS: Headless test for SEQUENCE_STEP_ADVANCED numSteps domain agreement
--
-- Created:    2026-07-11
-- Updated:    2026-08-17
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
--
-- Guards STEPADV-NUMSTEPS-EXPANDED-MISMATCH. The secure click body cycles the
-- button "step" attribute over the EXPANDED step array (BuildExecuteString emits
-- numSteps = #compiledSteps), but Engine:UpdateButtonIcon used to fire the event
-- with #ver.steps -- the AUTHORED count. For every expanding step function
-- (Priority, ReversePriority, plugin expanders) the two disagree: a 4-step
-- Priority sequence expands to 10, so the button cycles step 1..10 while the
-- event reported numSteps = 4 (the TrackerHUD "7/4" display).
--
-- The fix caches the compiled length on the button at compile time
-- (btn._numExecSteps = #compiledSteps) and fires that, falling back to
-- #ver.steps only when the field is absent (a button compiled before the field
-- existed). This test drives the REAL Engine:UpdateButtonIcon fire path and the
-- REAL Engine:BuildExecutionOrder / GetActiveVersionStepList expansion path and
-- asserts the two domains agree.
--
-- Scope note: this exercises the CONSUMER of the cache (Engine:UpdateButtonIcon,
-- edit 6) and the read accessor the docs pair it with. The five producer sites
-- that set btn._numExecSteps = #compiledSteps (ActivateSequence base + variant,
-- RecompileSequence base + variant, TempoAdvisor hold mode) are trivial one-line
-- assignments verified against the compiled-length invariant proven here: for a
-- non-overflowing sequence #compiledSteps == #BuildExecutionOrder(steps, sf), so
-- the value they cache is exactly the value asserted below.
--
-- Loads the REAL modules (Engine/StepFunctions.lua + Engine/Engine.lua) via
-- loadfile + setfenv into a no-op stub sandbox, the same technique as
-- test_legacy_import_parity.lua. No secure frames are created; the fire path is
-- pure Lua and safe headless.
--
-- Run from the EMS root:  lua Test/test_stepadv_numsteps_domain.lua
-- Exit code 0 = all passed, 1 = at least one failure.
--
-- Cases:
--   P1  Priority 4-step expands to 10 (BuildExecutionOrder == the accessor array)
--   P2  Priority fire reports the EXPANDED 10 when the button carries the cache
--   P3  Priority fire with NO cache expands rather than reporting the compiled 4
--   P4  #GetSequenceSteps(name) == fired numSteps == 10 (docs/api/data.md pairing)
--   P5  a DORMANT sequence (button = nil) reports the execution count via GetSequenceList
--   S1  Sequential 4-step stays 4 across expand, fire, and accessor (no regression)
--   R1  ReversePriority 4-step expands to 10 and fires 10 (second expander covered)
--   X3  no-cache text AND count both sit in the execution domain (cached == uncached)
--   X4  ReversePriority no-cache text returns the EXPANDED order[1], not authored steps[1]
--   X5  cached and no-cache GetExecStepText agree for every step (regression net)
--   G1  GetActiveVersion resolves a SCALAR versions to nil and never indexes it
--       (the only case in SET A driving that head check against the REAL Engine)
--   E1  UpdateSequenceData (the SAVE path) survives every versions shape and
--       hands only a real version to the locale normaliser  -- Engine.lua:2724
--   E2  HealLocaleSteps walks a store holding a malformed entry and still heals
--       its well-formed neighbour                            -- Engine.lua:2983
--   E3  HealOverrideSteps does the same on the talent-change path
--                                                            -- Engine.lua:3068
--   E4  DuplicateSequence copies every versions shape and really deep-copies a
--       real one                                             -- Engine.lua:3201
--       (Engine.lua:1407 is the fifth guard and stays SOURCE-ONLY: it is a
--       look-alike protected by GetActiveVersion's own head check. See the
--       measured note at the head of the E-cases.)
--   T1  the four step-entry shape gates absorb a number, a boolean and a
--       string on CompileSteps, BuildExecutionOrder, SimulateSteps and
--       BuildExecuteString -- Engine.lua:155, :254, :307, :459 pre-15t
--
-- NOTE ON THE Engine.lua NUMBERS IN THIS FILE. Every citation below has been
-- SWEPT to the CURRENT tree at 15u and checked against the line's own text.
-- The pre-15t value is kept in parentheses only where the surrounding prose
-- quotes a pre-15t run.
--
-- 15t recorded the shift as "everything below the first guard moved down by
-- exactly 56 lines". THAT IS WRONG, and it is worth the space because the
-- wrong version was written into this file and into a commit body. The four
-- guards created FOUR bands, and the diff's own hunk headers say so:
--     old 159..250  ->  +23      @@ -152,7 +152,30 @@
--     old 258..303  ->  +37      @@ -251,7 +274,21 @@
--     old 311..455  ->  +41      @@ -304,7 +341,11 @@
--     old 463..end  ->  +56      @@ -456,7 +497,22 @@
-- Checked against line text: old :162 is now :185, old :217 is now :240, old
-- :263 is now :300, old :463 is now :519. (Those four "now" values are in the
-- 15t tree; 15u shifted them again -- see the next block.)
--
-- HOW THE ONE-BAND CLAIM SURVIVED ITS OWN EVIDENCE. Six spot-checks were
-- offered for it -- :641, :2735, :2738, :1538, :2153, :2811 -- and every one
-- of them is above old :462, so every one lands in the +56 band. The sample
-- was drawn entirely from the bucket it confirmed. A spot-check has to span
-- the boundaries of the thing it is testing or it tests nothing.
--
-- And the file used to contradict itself: the guard heads are listed above at
-- the T1 case as pre-15t :155, :254, :307, :459, and applying a flat +56 to
-- those gives 211, 310, 363, 515 while the correct values are 178, 291, 348,
-- 515. Three of the four disagree.
--
-- AND 15u SHIFTED IT AGAIN, so this note states its OWN bands rather than
-- leaving the next pass to guess. 15u added four comment blocks to
-- Engine.lua (+68 / -22, net +46). From git diff's own hunk headers:
--     15t-tree 1..49       ->  +0     @@ -49,0 +50,14 @@
--     15t-tree 50..286     ->  +14    @@ -280,7 +294,10 @@
--     15t-tree 287..290    ->  +17    @@ -288,3 +305,8 @@   (interior to the
--                                     rewritten comment; no citation lands here)
--     15t-tree 291..514    ->  +22    @@ -503,12 +525,28 @@
--     15t-tree 515..1277   ->  +38    @@ -1277,0 +1316,8 @@
--     15t-tree 1278..end   ->  +46
-- So the four 15t guard heads are now Engine.lua:192, :313, :370 and :553.
-- FIVE bands this time, not four and not one: git split the BuildExecutionOrder
-- rewrite into two hunks because one "--" line inside it happened to survive.
-- Every Engine.lua number in this file is post-15u and was READ at the line it
-- names. None of them was produced by adding an offset to an older number.

local ADDON_NAME = "GRIP-EMS"

-- ---------------------------------------------------------------------------
-- Minimal assertion + runner harness.
-- ---------------------------------------------------------------------------

local tests = {}

local function test(name, fn)
    tests[#tests + 1] = { name = name, fn = fn }
end

local function assertEqual(expected, actual, label)
    if expected ~= actual then
        error((label or "value") .. ": expected " .. tostring(expected) .. ", got " .. tostring(actual), 2)
    end
end

local function assertTrue(cond, label)
    if not cond then
        error((label or "condition") .. " failed", 2)
    end
end

-- ---------------------------------------------------------------------------
-- Sandbox: a self-referential no-op stub backs every unknown global so the real
-- modules load without a WoW client. Real stdlib falls through to _G.
-- ---------------------------------------------------------------------------

local stub = {}
setmetatable(stub, {
    __index = function()
        return stub
    end,
    __call = function()
        return stub
    end,
})

local env = setmetatable({}, {
    __index = function(_, k)
        local v = rawget(_G, k)
        if v ~= nil then
            return v
        end
        return stub
    end,
})
env._G = env

-- AceLocale stand-in: every key echoes back so any L["KEY"] format is inert.
local LOCALE = setmetatable({}, {
    __index = function(_, k)
        return k
    end,
})
env.LibStub = function()
    return {
        GetLocale = function()
            return LOCALE
        end,
    }
end

-- ---------------------------------------------------------------------------
-- GRIPEMS control table. Fire captures the SEQUENCE_STEP_ADVANCED payload;
-- OOCQueue.IsRestricted() returns true so UpdateButtonIcon skips the icon branch
-- (which needs MacroManager / SpellCache) and reaches the unconditional fire.
-- ---------------------------------------------------------------------------

local lastFire = {}

local GRIPEMS = {
    version = "headless",
    Print = function() end,
    Debug = function() end,
    Defaults = {
        STEP_SEQUENTIAL = "Sequential",
        STEP_RANDOM = "Random",
        STEP_PRIORITY = "Priority",
        STEP_REVERSE_PRIORITY = "ReversePriority",
        ATTR_TYPE_MACRO = "macro",
        MAX_MACROTEXT_LENGTH = 255,
        MAX_SAB_MACROTEXT_LENGTH = 255,
        CONTEXT_NONE = "none",
        -- Real values from Data/Defaults.lua. They must be the REAL strings: the
        -- C-cases assert a queued op's opType equals D.OOC_OP_SETTING, and two
        -- nils would satisfy that comparison vacuously.
        OOC_OP_RECOMPILE = "recompile",
        OOC_OP_SETTING = "setting",
        -- Real value from Data/Defaults.lua. O4 asserts the delay handed to
        -- C_Timer.NewTimer IS this constant, so a nil here would be a silent
        -- pass on a build that lost the constant.
        OVERRIDE_HEAL_DEBOUNCE = 0.5,
    },
    -- UpdateSequenceData's publish re-reads the global reset modifiers at drain
    -- time. Empty is correct here: these cases assert on resetTimer and the
    -- channel-hold pair, not on modifier fan-out.
    Settings = {
        GetResetModifiers = function()
            return {}
        end,
    },
    OOCQueue = {
        IsRestricted = function()
            return true
        end,
        -- RecompileSequence queues doRecompile here; run it synchronously so the
        -- test observes the cache-set outcome in-line.
        Add = function(_, fn)
            fn()
        end,
    },
    MacroManager = {
        UpdateIcon = function() end,
        UpdateStubBody = function() end,
    },
    KeybindManager = {},
    -- Engine.lua registers a corrupt-sequence popup at module scope (Popup:Define);
    -- the fire path never shows it, so a no-op definer is enough to load the file.
    Popup = {
        Define = function() end,
        Show = function() end,
    },
}

function GRIPEMS:Fire(event, seqName, step, numSteps)
    if event == "SEQUENCE_STEP_ADVANCED" then
        lastFire.seqName = seqName
        lastFire.step = step
        lastFire.numSteps = numSteps
        lastFire.count = (lastFire.count or 0) + 1
    end
end

-- ---------------------------------------------------------------------------
-- Sandbox pieces the O-block (STALE-OVERRIDE-STEP-TEXT) needs. Both must exist
-- BEFORE Engine.lua is loaded below, so they live here rather than beside the
-- cases that read them.
-- ---------------------------------------------------------------------------

-- InCombatLockdown backs the combat gate at the head of Engine:HealOverrideSteps.
-- Without a real stub the sandbox catch-all answers, and the catch-all is a
-- TRUTHY table -- the gate would then short-circuit every heal and E3 would go
-- green while nothing ran. Default false, the out-of-combat world every case
-- written before the gate assumed; the O-cases flip it through
-- rawset(env, "_headlessInCombat", true).
env.InCombatLockdown = function()
    return rawget(env, "_headlessInCombat") == true
end

-- The engine event frame. Engine.lua reads _G["GRIPEMS_EngineEvent"] first and
-- only calls CreateFrame when that is absent -- and the sandbox catch-all
-- SATISFIES that read with an inert stub which swallows RegisterEvent and
-- SetScript alike. O5 drives the real OnEvent handler and O6 reads the real
-- registration set, so both are recorded here instead of discarded.
local engineEvents = {}
local engineScripts = {}
rawset(env, "GRIPEMS_EngineEvent", {
    UnregisterAllEvents = function()
        for k in pairs(engineEvents) do
            engineEvents[k] = nil
        end
    end,
    RegisterEvent = function(_, event)
        engineEvents[event] = true
    end,
    SetScript = function(_, script, fn)
        engineScripts[script] = fn
    end,
})

-- ---------------------------------------------------------------------------
-- Load the REAL modules into the sandbox. StepFunctions first: Engine captures
-- GRIPEMS.StepFunctions as a file-scope upvalue at load, so it must exist first.
-- ---------------------------------------------------------------------------

local function loadModule(candidates)
    for _, path in ipairs(candidates) do
        -- loadfile is dev-harness file I/O, intentionally outside the addon WoW std.
        -- selene: allow(undefined_variable)
        local chunk = loadfile(path)
        if chunk then
            setfenv(chunk, env)
            chunk(ADDON_NAME, GRIPEMS)
            return true
        end
    end
    return false
end

assert(
    loadModule({
        "Engine/StepFunctions.lua",
        "../Engine/StepFunctions.lua",
        "GRIP/EMS/Engine/StepFunctions.lua",
    }),
    "could not locate Engine/StepFunctions.lua (run from the EMS root)"
)
assert(
    loadModule({
        "Engine/Engine.lua",
        "../Engine/Engine.lua",
        "GRIP/EMS/Engine/Engine.lua",
    }),
    "could not locate Engine/Engine.lua (run from the EMS root)"
)

local Engine = GRIPEMS.Engine
local SF = GRIPEMS.StepFunctions
assert(Engine ~= nil, "Engine loaded")
assert(SF ~= nil, "StepFunctions loaded")
assert(type(Engine.BuildExecutionOrder) == "function", "BuildExecutionOrder defined")
assert(type(Engine.UpdateButtonIcon) == "function", "UpdateButtonIcon defined")
assert(type(Engine.GetActiveVersionStepList) == "function", "GetActiveVersionStepList defined")
Engine.sequences = {}

-- ---------------------------------------------------------------------------
-- Fixtures + helpers.
-- ---------------------------------------------------------------------------

-- A four-step authored sequence in the versioned format GetActiveVersion reads.
-- `steps` is optional and defaults to the four plain steps every case above the
-- S-block expects, values and all. Pass an array to author a different list (the
-- S-block needs one carrying an empowered spell); labels are then generated to
-- the same length so BuildExecLabels never sees more labels than steps. Both
-- arrays are rebuilt per call, so no two fixtures share a mutable table.
local function makeSequence(stepFunction, steps)
    local useSteps, labels
    if steps then
        useSteps, labels = {}, {}
        for i = 1, #steps do
            useSteps[i] = steps[i]
            labels[i] = "Step" .. i
        end
    else
        useSteps = { "/cast Alpha", "/cast Bravo", "/cast Charlie", "/cast Delta" }
        labels = { "Alpha", "Bravo", "Charlie", "Delta" }
    end
    return {
        versions = {
            {
                steps = useSteps,
                stepFunction = stepFunction,
                compiledLabels = labels,
                keyPress = "",
                keyRelease = "",
            },
        },
        defaultVersion = 1,
    }
end

-- Mirrors Core/PublicAPI.lua impl.GetSequenceSteps(name): resolve the registered
-- entry, then delegate to Engine:GetActiveVersionStepList (the expanded array).
local function apiGetSequenceSteps(name)
    local entry = Engine.sequences[name]
    if not entry then
        return nil
    end
    return Engine:GetActiveVersionStepList(entry.data)
end

-- Register a sequence, build a fake button (no secure frame -- the fire path is
-- pure Lua), and drive the REAL Engine:UpdateButtonIcon. numExecSteps stands in
-- for the compile-time cache the producer sites set; pass nil to test the
-- fallback. Returns the captured numSteps.
local function driveFire(name, seqData, numExecSteps)
    Engine.sequences[name] = { data = seqData }
    local btn = {
        seqName = name,
        seqData = seqData,
        _numExecSteps = numExecSteps,
        _attrs = { step = 1 },
    }
    function btn:GetAttribute(key)
        return self._attrs[key]
    end
    lastFire.count = 0
    lastFire.numSteps = nil
    Engine:UpdateButtonIcon(btn)
    assertEqual(1, lastFire.count, "exactly one SEQUENCE_STEP_ADVANCED fired for " .. name)
    return lastFire.numSteps
end

-- ---------------------------------------------------------------------------
-- Cases.
-- ---------------------------------------------------------------------------

test("P1: a 4-step Priority sequence expands to 10 (BuildExecutionOrder)", function()
    local seq = makeSequence("Priority")
    local ver = seq.versions[1]
    local execOrder = Engine:BuildExecutionOrder(ver.steps, ver.stepFunction)
    assertEqual(10, #execOrder, "Priority 4-step expands to a 10-entry execution order")
    assertEqual(4, #ver.steps, "the authored count is still 4 (the old, wrong denominator)")
end)

test("P2: Priority fire reports the EXPANDED 10 when the button carries the cache", function()
    local seq = makeSequence("Priority")
    local expanded = #Engine:BuildExecutionOrder(seq.versions[1].steps, "Priority")
    -- The producer sites cache exactly this: btn._numExecSteps = #compiledSteps.
    local fired = driveFire("P2_Priority", seq, expanded)
    assertEqual(10, fired, "fired numSteps is the expanded 10, NOT the authored 4")
end)

test("P3: Priority with NO cache expands rather than reporting the compiled 4", function()
    local seq = makeSequence("Priority")
    -- No _numExecSteps cache (a dormant sequence, or a button whose Execute has not yet
    -- succeeded): the no-cache path expands ver.steps through BuildExecutionOrder instead
    -- of degrading to the compiled #ver.steps, so it stays in the execution domain. Still
    -- never nil and never a Lua error. Passing nil for numExecSteps exercises the fallback.
    local fired = driveFire("P3_PriorityNoCache", seq, nil)
    assertEqual(10, fired, "no-cache path expands through BuildExecutionOrder to the execution 10, not the compiled 4")
end)

test("P4: #GetSequenceSteps(name) == fired numSteps == 10 for Priority", function()
    local seq = makeSequence("Priority")
    local expanded = #Engine:BuildExecutionOrder(seq.versions[1].steps, "Priority")
    local fired = driveFire("P4_Priority", seq, expanded)
    local steps = apiGetSequenceSteps("P4_Priority")
    assertEqual(10, #steps, "GetSequenceSteps returns the 10-entry expanded array")
    assertEqual(#steps, fired, "the accessor length and the fired denominator agree")
end)

test("P5: a DORMANT sequence (button = nil) reports the execution count", function()
    local seq = makeSequence("Priority")
    Engine.sequences["P5_Dormant"] = { button = nil, data = seq }
    local list = Engine:GetSequenceList()
    local entry
    for i = 1, #list do
        if list[i].name == "P5_Dormant" then
            entry = list[i]
        end
    end
    assert(entry ~= nil, "the dormant sequence appears in GetSequenceList")
    local steps = apiGetSequenceSteps("P5_Dormant")
    assertEqual(10, #steps, "GetSequenceSteps expands to 10 for a dormant Priority")
    assertEqual(10, entry.stepCount, "stepCount is the execution 10, not the compiled 4")
    assertEqual(#steps, entry.stepCount, "stepCount == #GetSequenceSteps (docs/api/data.md contract)")
end)

test("S1: Sequential 4-step stays 4 across expand, fire, and accessor (no regression)", function()
    local seq = makeSequence("Sequential")
    local expanded = #Engine:BuildExecutionOrder(seq.versions[1].steps, "Sequential")
    assertEqual(4, expanded, "Sequential does not expand: authored == expanded == 4")
    local fired = driveFire("S1_Sequential", seq, expanded)
    assertEqual(4, fired, "Sequential fires 4 (expanded == authored, the fix is a no-op here)")
    local steps = apiGetSequenceSteps("S1_Sequential")
    assertEqual(4, #steps, "GetSequenceSteps returns 4 for the non-expanding path")
    assertEqual(#steps, fired, "accessor length and fired denominator agree at 4")
end)

test("R1: ReversePriority 4-step expands to 10 and fires 10 (second expander)", function()
    local seq = makeSequence("ReversePriority")
    local expanded = #Engine:BuildExecutionOrder(seq.versions[1].steps, "ReversePriority")
    assertEqual(10, expanded, "ReversePriority 4-step also expands to 10")
    local fired = driveFire("R1_ReversePriority", seq, expanded)
    assertEqual(10, fired, "ReversePriority fires the expanded 10")
    assertEqual(#apiGetSequenceSteps("R1_ReversePriority"), fired, "accessor length and fired denominator agree")
end)

-- ---------------------------------------------------------------------------
-- Phase 2: _numExecSteps is written ONLY after a successful Execute, so the
-- cache always describes what is actually live in the button's restricted env.
-- These cases drive the REAL Engine:RecompileSequence -- its queued doRecompile
-- runs synchronously through the OOCQueue.Add stub -- and force the three
-- Execute outcomes via test-injected Engine.DeferIfBraced and btn.Execute:
--   D0  success -> the cache is UPDATED to the new compiled count
--   D1  defer   -> Execute is skipped, the cache RETAINS its prior value
--   D2  failure -> Execute fails, the cache RETAINS its prior value
-- D0 is the non-vacuity control: it proves the harness actually reaches the
-- cache-set, so the D1/D2 "unchanged" assertions describe a path that ran.
-- ---------------------------------------------------------------------------

-- A failed base Execute in RecompileSequence auto-recovers via Deactivate +
-- Activate; stub both to counters so D2 does not re-enter the heavy activation
-- path headless, and so the test can confirm the failure branch was taken.
local recovery = { deactivate = 0, activate = 0 }
function Engine:DeactivateSequence()
    recovery.deactivate = recovery.deactivate + 1
end
function Engine:ActivateSequence()
    recovery.activate = recovery.activate + 1
end

-- Register a Priority 4-step sequence (doRecompile expands it to 10) with a
-- button whose prior cache is a distinct sentinel (7), so "updated to 10" and
-- "retained at 7" are both distinguishable from the authored count (4).
local function makeRecompileEntry(priorCache, failExecute, stepFunction, steps)
    local seqData = makeSequence(stepFunction or "Priority", steps)
    local btn = {
        seqName = "RC_Seq",
        seqData = seqData,
        _numExecSteps = priorCache,
        _failExecute = failExecute,
        _attrs = { step = 1 },
    }
    function btn:GetAttribute(key)
        return self._attrs[key]
    end
    function btn:SetAttribute(key, value)
        self._attrs[key] = value
    end
    function btn:Execute()
        if self._failExecute then
            error("simulated restricted-env Execute failure")
        end
    end
    Engine.sequences["RC_Seq"] = { data = seqData, button = btn }
    return btn
end

-- Fire the event from an EXISTING button (reads its current _numExecSteps).
local function fireExistingButton(btn)
    lastFire.count = 0
    lastFire.numSteps = nil
    Engine:UpdateButtonIcon(btn)
    assertEqual(1, lastFire.count, "exactly one SEQUENCE_STEP_ADVANCED fired for " .. tostring(btn.seqName))
    return lastFire.numSteps
end

test("D0 (control): a successful recompile UPDATES the cache to the new compiled count", function()
    local btn = makeRecompileEntry(7, false)
    recovery.activate = 0
    Engine.DeferIfBraced = function()
        return false
    end
    Engine:RecompileSequence("RC_Seq")
    assertEqual(10, btn._numExecSteps, "success writes #compiledSteps (Priority 4 -> 10), replacing the prior 7")
    assertEqual(0, recovery.activate, "a successful Execute does not trigger auto-recovery")
    assertEqual(10, fireExistingButton(btn), "the fired numSteps is the freshly loaded 10")
end)

test("D1 (defer): a deferred recompile RETAINS the prior cache (Execute never ran)", function()
    local btn = makeRecompileEntry(7, false)
    Engine.DeferIfBraced = function()
        return true
    end
    Engine:RecompileSequence("RC_Seq")
    assertEqual(7, btn._numExecSteps, "defer leaves the prior 7: the new 10 was never loaded into the restricted env")
    assertEqual(7, fireExistingButton(btn), "fired numSteps still describes the live (old) steps, not the deferred 10")
end)

test("D2 (failure): a failed Execute RETAINS the prior cache", function()
    local btn = makeRecompileEntry(7, true)
    recovery.activate = 0
    Engine.DeferIfBraced = function()
        return false
    end
    Engine:RecompileSequence("RC_Seq")
    assertEqual(7, btn._numExecSteps, "a failed Execute leaves the prior 7, never the count we failed to load")
    assertTrue(recovery.activate >= 1, "the failed Execute reached the auto-recovery path (confirms Execute failed)")
    assertEqual(7, fireExistingButton(btn), "fired numSteps still describes the live (old) steps")
end)

-- ---------------------------------------------------------------------------
-- Phase 3: the button "step" attribute indexes the EXPANDED execution array, so
-- the icon/counter consumers must read it through Engine:GetExecStepText /
-- GetExecStepCount rather than ver.steps[step] / #ver.steps. These cases drive
-- the real RecompileSequence to populate btn._execSteps, then assert the helpers.
-- X1 step-3 (-> B, not C) and step-4 (-> A, not D) are the non-vacuity controls:
-- they fail against authored indexing, and X3 shows authored indexing gives C/D.
-- ---------------------------------------------------------------------------

test("X1 (Priority): the button 'step' indexes the EXPANDED array [A,A,B,A,B,C,A,B,C,D]", function()
    local btn = makeRecompileEntry(7, false, "Priority")
    Engine.DeferIfBraced = function()
        return false
    end
    Engine:RecompileSequence("RC_Seq")
    assertEqual(10, #btn._execSteps, "Priority 4-step caches a 10-entry expanded array")
    local ver = Engine:GetActiveVersion(btn.seqData)
    -- Authored [A,B,C,D] -> [A, A,B, A,B,C, A,B,C,D]; A=/cast Alpha .. D=/cast Delta.
    assertEqual("/cast Alpha", Engine:GetExecStepText(btn, 1, ver), "step 1 -> A")
    assertEqual("/cast Bravo", Engine:GetExecStepText(btn, 3, ver), "step 3 -> B, not the old C")
    assertEqual("/cast Alpha", Engine:GetExecStepText(btn, 4, ver), "step 4 -> A, not the old D")
    assertEqual("/cast Alpha", Engine:GetExecStepText(btn, 7, ver), "step 7 -> A (old: out-of-range)")
    assertEqual("/cast Delta", Engine:GetExecStepText(btn, 10, ver), "step 10 -> D (old: out-of-range)")
    assertEqual(10, Engine:GetExecStepCount(btn, ver), "denominator is the expanded 10")
end)

test("X2 (Sequential control): expanded == authored, GetExecStepText(k) == authored[k]", function()
    local btn = makeRecompileEntry(99, false, "Sequential")
    Engine.DeferIfBraced = function()
        return false
    end
    Engine:RecompileSequence("RC_Seq")
    assertEqual(4, #btn._execSteps, "Sequential does not expand: 4 authored -> 4 compiled")
    local ver = Engine:GetActiveVersion(btn.seqData)
    assertEqual("/cast Alpha", Engine:GetExecStepText(btn, 1, ver), "k=1")
    assertEqual("/cast Bravo", Engine:GetExecStepText(btn, 2, ver), "k=2")
    assertEqual("/cast Charlie", Engine:GetExecStepText(btn, 3, ver), "k=3")
    assertEqual("/cast Delta", Engine:GetExecStepText(btn, 4, ver), "k=4")
    assertEqual(4, Engine:GetExecStepCount(btn, ver), "count == 4 (no expansion regression)")
end)

test("X3 (fallback control): no-cache text AND count both sit in the execution domain", function()
    local seqData = makeSequence("Priority")
    local ver = Engine:GetActiveVersion(seqData)
    local bareBtn = {}
    -- No _execSteps -> the no-cache branch expands ver.steps through BuildExecutionOrder,
    -- so it returns the SAME text the cached branch returns (see X5). Priority [A,B,C,D]
    -- expands to [A,A,B,A,B,C,A,B,C,D], so order[3]=B (not authored C) and order[7]=A.
    assertEqual("/cast Alpha", Engine:GetExecStepText(bareBtn, 1, ver), "step 1 -> order[1]=A (== steps[1] here)")
    assertEqual("/cast Bravo", Engine:GetExecStepText(bareBtn, 3, ver), "step 3 -> order[3]=B (same as cached X1)")
    assertEqual("/cast Alpha", Engine:GetExecStepText(bareBtn, 7, ver), "step 7 -> order[7]=A (now in-range)")
    -- Both accessors now live in the execution domain: the count expands too, matching
    -- #GetSequenceSteps for a dormant sequence.
    assertEqual(
        10,
        Engine:GetExecStepCount(bareBtn, ver),
        "no-cache count expands via BuildExecutionOrder to the execution 10, not the compiled 4"
    )
    assertEqual(nil, Engine:GetExecStepText(bareBtn, 3, nil), "no ver, no cache -> nil")
    assertEqual(0, Engine:GetExecStepCount(nil, nil), "no btn, no ver -> 0")
end)

test("X4 (ReversePriority no-cache): text fallback returns the EXPANDED order[1], not authored steps[1]", function()
    local seqData = makeSequence("ReversePriority")
    local ver = Engine:GetActiveVersion(seqData)
    local order = Engine:BuildExecutionOrder(ver.steps, ver.stepFunction)
    local bareBtn = {}
    assertEqual("/cast Delta", order[1], "ReversePriority expands to [D,C,D,B,C,D,A,B,C,D]")
    assertEqual(
        "/cast Delta",
        Engine:GetExecStepText(bareBtn, 1, ver),
        "no-cache step 1 returns the execution order[1] (Delta), NOT authored steps[1] (Alpha)"
    )
    assertEqual(10, Engine:GetExecStepCount(bareBtn, ver), "no-cache count is the expanded 10")
end)

test("X5 (domain agreement): cached and no-cache GetExecStepText return the same text for every step", function()
    Engine.DeferIfBraced = function()
        return false
    end
    -- Priority: a cached button (real compiled _execSteps, built like X1) vs a bare button.
    local btn = makeRecompileEntry(7, false, "Priority")
    Engine:RecompileSequence("RC_Seq")
    local ver = Engine:GetActiveVersion(btn.seqData)
    local order = Engine:BuildExecutionOrder(ver.steps, ver.stepFunction)
    local bareBtn = {}
    for k = 1, #order do
        assertEqual(
            Engine:GetExecStepText(btn, k, ver),
            Engine:GetExecStepText(bareBtn, k, ver),
            "Priority step " .. k .. ": cached and no-cache agree"
        )
    end
    -- ReversePriority: the expander whose order[1] is the LAST authored step.
    local rpBtn = makeRecompileEntry(7, false, "ReversePriority")
    Engine:RecompileSequence("RC_Seq")
    local rpVer = Engine:GetActiveVersion(rpBtn.seqData)
    local rpOrder = Engine:BuildExecutionOrder(rpVer.steps, rpVer.stepFunction)
    local rpBare = {}
    for k = 1, #rpOrder do
        assertEqual(
            Engine:GetExecStepText(rpBtn, k, rpVer),
            Engine:GetExecStepText(rpBare, k, rpVer),
            "ReversePriority step " .. k .. ": cached and no-cache agree"
        )
    end
end)

-- ---------------------------------------------------------------------------
-- Phase 4: the accessibility "speak step on advance" label + "of Y" denominator
-- must live in the EXPANDED domain. RecompileSequence now caches an expanded
-- labels array (btn._execLabels) that Engine:GetExecStepLabel reads. These cases
-- drive the real compile and assert the label at each expanded position; L1's
-- step-3 (-> Bravo) and step-4 (-> Alpha) fail against authored indexing, which
-- L2 shows yields Charlie/Delta.
-- ---------------------------------------------------------------------------

test("L1 (Priority): the spoken label follows the EXPANDED array, and 'of Y' is expanded", function()
    local btn = makeRecompileEntry(7, false, "Priority")
    Engine.DeferIfBraced = function()
        return false
    end
    Engine:RecompileSequence("RC_Seq")
    assertEqual(10, #btn._execLabels, "Priority 4 labels expand to 10 aligned entries")
    assertEqual("Alpha", Engine:GetExecStepLabel(btn, 1), "step 1 label -> Alpha")
    assertEqual("Bravo", Engine:GetExecStepLabel(btn, 3), "step 3 label -> Bravo, not the old Charlie")
    assertEqual("Alpha", Engine:GetExecStepLabel(btn, 4), "step 4 label -> Alpha, not the old Delta")
    assertEqual("Delta", Engine:GetExecStepLabel(btn, 10), "step 10 label -> Delta")
    local ver = Engine:GetActiveVersion(btn.seqData)
    assertEqual(10, Engine:GetExecStepCount(btn, ver), "'of Y' is the expanded 10 (was 4 -> 'Step 7 of 4')")
end)

test("L2 (Sequential control): labels are 1:1 with the authored steps (no regression)", function()
    local btn = makeRecompileEntry(99, false, "Sequential")
    Engine.DeferIfBraced = function()
        return false
    end
    Engine:RecompileSequence("RC_Seq")
    assertEqual(4, #btn._execLabels, "Sequential does not expand labels")
    assertEqual("Alpha", Engine:GetExecStepLabel(btn, 1), "k=1")
    assertEqual("Charlie", Engine:GetExecStepLabel(btn, 3), "k=3 identity (authored indexing IS correct here)")
    assertEqual("Delta", Engine:GetExecStepLabel(btn, 4), "k=4")
end)

test("L3 (fallback): no _execLabels -> nil (generic 'Step X of Y'), never a wrong label", function()
    local bareBtn = {}
    assertEqual(nil, Engine:GetExecStepLabel(bareBtn, 3), "no cache -> nil, never an authored-domain label")
    assertEqual(nil, Engine:BuildExecLabels(nil, "Priority", 4), "nil labels -> nil")
    assertEqual(nil, Engine:BuildExecLabels({ "", "", "", "" }, "Priority", 4), "all-empty labels -> nil")
    -- A registered plugin expander reorders by macrotext CONTENT, so its label mapping
    -- cannot be recovered -> nil (the handler then speaks the generic "Step X of Y").
    SF:RegisterStepFunction("l3plugin", {
        id = "l3plugin",
        name = "L3 Plugin",
        Expand = function(_, texts)
            return texts
        end,
    })
    assertEqual(nil, Engine:BuildExecLabels({ "A", "B" }, "l3plugin", 2), "plugin expander -> nil (unrecoverable)")
end)

-- ---------------------------------------------------------------------------
-- Pass 15b: the versions-shape head check on Engine:GetActiveVersion. This file
-- loads the REAL Engine/Engine.lua, which is why the case lives here: the
-- malformed-entry suite (Test/test_malformed_entry_guards.lua) drives
-- GE.BuildExportList through an Engine STUB, so its W24 rows cannot pin the
-- real function no matter how many shapes they run.
-- ---------------------------------------------------------------------------

test("G1 (versions shape): GetActiveVersion resolves a scalar versions to nil and never indexes it", function()
    -- Corrupt data (bad import, hand-edited SavedVariables) can leave a scalar
    -- in seqData.versions. This function is the single indirection point for
    -- version access and INDEXES that field at four sites; the head check at
    -- what was Engine.lua:621 in the PRE-FIX tree -- that number is a frozen
    -- quote from the pre-fix run and is deliberately NOT swept; the check now
    -- lives at Engine.lua:735 -- was bare truthiness, so all four ran against a
    -- non-table.
    -- Measured before the fix: "attempt to index field 'versions' (a number
    -- value)" / "(a boolean value)" at the default resolution. A string is the
    -- tolerant shape -- it indexes to nil through the string metatable -- so a
    -- length check would not model this field either.
    --
    -- Blast radius, and why a nil answer matters rather than merely not
    -- raising: GE.BuildExportList (Import/ExportPreview.lua:43) resolves the
    -- active version for EVERY stored sequence, so one corrupt entry failed the
    -- whole export dialog before its own row was reached.
    for _, shape in ipairs({ 42, true, "text" }) do
        local seqData = { name = "G1Seq", defaultVersion = 1, versions = shape }
        local ok, ver = pcall(Engine.GetActiveVersion, Engine, seqData)
        assertTrue(ok, "GetActiveVersion raised on versions=" .. type(shape) .. ": " .. tostring(ver))
        assertEqual(nil, ver, "a scalar versions resolves to no active version for " .. type(shape))
    end

    -- The PIN read at Engine.lua:744 indexes the same field two guards earlier
    -- than the default resolution, so a pinned sequence took the raise first.
    -- The head check covers it by construction; this row proves that.
    local okPin, verPin = pcall(Engine.GetActiveVersion, Engine, { versions = 42, pinnedVersion = 1 })
    assertTrue(okPin, "GetActiveVersion raised on a PINNED scalar versions: " .. tostring(verPin))
    assertEqual(nil, verPin, "a pinned scalar versions still resolves to nil")

    -- ABSENT must keep working unchanged: nil is the answer this function
    -- already gave for a missing versions field, so no caller sees a new shape.
    assertEqual(nil, Engine:GetActiveVersion({ name = "G1Seq" }), "an absent versions still resolves to nil")
    assertEqual(nil, Engine:GetActiveVersion(nil), "a nil seqData still resolves to nil")

    -- CONTROL on a non-zero observable: a real versions table must still
    -- resolve, and resolve to the RIGHT version, so the nils above are not what
    -- this function returns for everything.
    local seqData = makeSequence("Sequential")
    local verC = Engine:GetActiveVersion(seqData)
    assertTrue(verC ~= nil, "the control resolves an active version")
    assertEqual(4, #verC.steps, "the control resolved the version carrying all four steps")

    -- CONTROL-FALSIFY: defaultVersion drives the choice, so a two-version
    -- sequence pointing at version 2 must return version 2 and not version 1.
    local twoVer = {
        name = "G1Two",
        defaultVersion = 2,
        versions = {
            { steps = { "/cast Alpha" }, stepFunction = "Sequential" },
            { steps = { "/cast Bravo", "/cast Charlie" }, stepFunction = "Sequential" },
        },
    }
    local verF = Engine:GetActiveVersion(twoVer)
    assertEqual(2, #verF.steps, "control-falsify: defaultVersion 2 resolves the SECOND version")
    assertEqual("/cast Bravo", verF.steps[1], "control-falsify: and it is really version 2's step list")
end)

-- ---------------------------------------------------------------------------
-- Pass 15j: the FIVE .versions guards in Engine/Engine.lua.
--
-- WHY THEY LIVE HERE, and it is exactly the reason G1's note above gives: THIS
-- file loads the REAL Engine/Engine.lua. Test/test_malformed_entry_guards.lua
-- never does -- every .versions read it resolves goes through an Engine STUB,
-- so no fixture there can pin a real Engine function no matter how many shapes
-- it runs. W26's note in that file recorded these five as a "probable next
-- candidate" with an explicit instruction to MEASURE first rather than assume
-- that "the module is loaded" means "the guard is reachable". Measured:
--
--   :2724  Engine:UpdateSequenceData   REACHABLE  -> E1
--   :2983  Engine:HealLocaleSteps      REACHABLE  -> E2
--   :3068  Engine:HealOverrideSteps    REACHABLE  -> E3
--   :3201  Engine:DuplicateSequence    REACHABLE  -> E4
--   :1407  Engine:ActivateSequence     NOT FALSIFIABLE -- stays SOURCE-ONLY
--
-- :1407 IS A LOOK-ALIKE, the same class W26 records for GRIPExport :1120 and
-- ImportPreview :515, and it is left source-only rather than given a fixture
-- that would be green for the wrong reason. The line reads
--     if resolvedVer and type(sequenceData.versions) == "table" then
-- and resolvedVer is Engine:GetActiveVersion(sequenceData), assigned two lines
-- above at :1405. That function's own head check (Engine.lua:735, pinned by G1)
-- already returns nil for EVERY non-table versions, so the FIRST operand is
-- false in precisely the cases where the second one would matter. Reverting the
-- type() test alone therefore changes no observable -- measured green on
-- 2026-07-28, the whole file still 20 passed / 0 failed. A second and
-- independent reason: this file replaces Engine.ActivateSequence with the
-- counter stub at line 363 (D2's auto-recovery path needs it), so no case here
-- reaches :1407 at all. Both would have to be undone, and undoing them would
-- still leave the guard unfalsifiable.
--
-- E1 to E4 each drive the PUBLIC entry point with versions = nil, 5, true,
-- 'abc', {} and a real one-version table, and each asserts the observable the
-- function is FOR. A case that only asserted "did not raise" would pass while
-- the function silently did nothing, so every row also pins what the walk
-- actually did: which version table reached the locale normaliser (E1), the
-- healed step text and advanced stepsLocale on the well-formed NEIGHBOUR in the
-- same store (E2, E3), and the copied version array handed to activation (E4).
--
-- STUB AUDIT, in the form the guards harness keeps at
-- Test/test_malformed_entry_guards.lua:96. It lives here because these stubs
-- live here: they are installed and REMOVED inside the cases that need them, so
-- no case above this point ever observes one.
--
--   GRIPEMS.SpellCache  ready = true. NormalizeVersionLocale COUNTS its calls
--                       and records the version table it was handed;
--                       TranslateMacrotext returns "HEALED:" or "OVERRIDE:"
--                       (chosen by opts.useOverrides) prefixed to its input and
--                       mode; TagSteps returns "TAG:" prefixed to each step.
--                       LIVE: the real spell-tag translator and locale
--                       normaliser, resolving names against the spell cache.
--                       DIFFERS in BEHAVIOUR -- no real spell name is ever
--                       resolved -- so no case below asserts on a translation
--                       being CORRECT, only on WHICH versions the walk visited
--                       and that it wrote back. It does not mask the guards
--                       E1/E2/E3 pin: all three walks dereference
--                       seqData.versions BEFORE any SpellCache method is
--                       called, so reverting the guard still raises first.
--   env.GRIP_EMS_CHAR   a real { sequences = {...} } table for E2 and E3,
--                       rawset into the sandbox env and rawset back to nil
--                       after. LIVE: the per-character SavedVariables table.
--                       MATCHES in SHAPE. Required, not cosmetic: without it
--                       env.__index hands back the catch-all stub, which is
--                       TRUTHY, so Engine.lua:2973 / :3058 pass their own
--                       "not GRIP_EMS_CHAR.sequences" guard and then walk
--                       pairs(stub) -- which is EMPTY. That is the inert-stub
--                       failure mode this block exists to prevent: green, and
--                       nothing ran.
--   env.GetLocale       "enUS", for E2 only. LIVE: the client locale string.
--                       MATCHES in type. Also required rather than cosmetic:
--                       HealLocaleSteps ends in
--                       string.format("... from %s.", currentLocale) and Lua
--                       5.1's %s raises on the catch-all stub table.
--   D.CopyVersion       for E4: a shallow copy with a fresh steps array,
--                       mirroring the container-copy contract of the real
--                       Data/Defaults.lua:3989. LIVE: the real function, which
--                       also deep-copies actions, resetModifiers, taggedSteps,
--                       stepLabels, compiledLabels and variantOverrides.
--                       DIFFERS -- E4 asserts only that the copy is a DIFFERENT
--                       table carrying the same steps, which both satisfy.
--
-- RUNNING TOTAL for the forty-five .versions guards the 15c-15e arc shipped,
-- restated here so it is not only in the guards file:
--   TWENTY of forty-five behaviourally proven -- sixteen from
--   Test/test_malformed_entry_guards.lua (W27 to W31) plus the four E-cases
--   below. TWENTY-FIVE source-only, split seven / eighteen: seven whose module
--   a harness loads but which are unfalsifiable or out of reach for a measured
--   reason (RepairAnalyzer :397, :404, :439; GRIPExport :1120;
--   ImportPreview :515 and :1331; Engine :1407), and eighteen in files no
--   harness loads (Core/Core.lua x3, Core/PublicAPI.lua x1,
--   Data/SpellCache.lua x3, and eleven across the five UI files).
-- The full per-guard tally stays in the note at the head of W26 in the guards
-- file; do not keep a second copy of it here.
-- ---------------------------------------------------------------------------

-- nil cannot be an ipairs element, so the shapes are carried as ROWS and read
-- off .value -- an absent key yields nil, which IS the first shape. An empty
-- TABLE is the sixth row for the same reason W27 carries it: it is not a shape
-- confusion, it is the other half of what these walks must tolerate.
local ENGINE_SHAPES = {
    { label = "nil" },
    { label = "number", value = 5 },
    { label = "boolean", value = true },
    { label = "string", value = "abc" },
    { label = "empty table", value = {} },
}

--- Install the counting SpellCache stub described in the STUB AUDIT above and
--- return the record it writes into. Paired with removeSpellCache().
local function installSpellCache()
    local seen = { normalize = 0, versions = {} }
    GRIPEMS.SpellCache = {
        ready = true,
        NormalizeVersionLocale = function(_, version)
            seen.normalize = seen.normalize + 1
            seen.versions[seen.normalize] = version
        end,
        TranslateMacrotext = function(_, text, mode, opts)
            local prefix = (opts and opts.useOverrides) and "OVERRIDE:" or "HEALED:"
            return prefix .. tostring(text) .. ":" .. tostring(mode)
        end,
        TagSteps = function(_, steps)
            local out = {}
            for i, s in ipairs(steps or {}) do
                out[i] = "TAG:" .. tostring(s)
            end
            return out
        end,
    }
    return seen
end

local function removeSpellCache()
    GRIPEMS.SpellCache = nil
end

-- A button of the shape RecompileSequence and the in-place attribute refresh
-- expect. Same construction as makeRecompileEntry above, without registering.
local function makeBareButton(name)
    local btn = { seqName = name, _attrs = { step = 1 } }
    function btn:GetAttribute(key)
        return self._attrs[key]
    end
    function btn:SetAttribute(key, value)
        self._attrs[key] = value
    end
    function btn:Execute() end
    return btn
end

test("E1 (Engine.lua:2724): UpdateSequenceData saves every versions shape and normalizes only real ones", function()
    -- THE HIGHEST-VALUE OF THE FIVE. This is the SAVE path: the editor, the
    -- quick persists, the version bar and set-default all land here, so a raise
    -- on the locale re-tag walk loses the user's edit rather than merely
    -- degrading a display. The walk sits at :2724, ahead of every branch that
    -- decides between an in-place update and a full rebuild.
    for _, row in ipairs(ENGINE_SHAPES) do
        local seen = installSpellCache()
        local name = "E1_" .. row.label
        local btn = makeBareButton(name)
        Engine.sequences[name] = { data = { name = name, defaultVersion = 1, versions = {} }, button = btn }
        local seqData = { name = name, defaultVersion = 1, versions = row.value }
        local ok, err = pcall(Engine.UpdateSequenceData, Engine, name, seqData)
        -- Restore BEFORE asserting: the runner pcalls each case, so a failing
        -- assertion aborts this one and a leaked SpellCache would then be
        -- observed by every case after it.
        removeSpellCache()
        local tag = " for versions=" .. row.label
        assertTrue(ok, "UpdateSequenceData raised" .. tag .. ": " .. tostring(err))
        -- NOT merely "it returned". The save LANDED.
        assertTrue(Engine.sequences[name].data == seqData, "the new seqData was stored in place" .. tag)
        assertTrue(seqData.updatedAt ~= nil, "the save stamped updatedAt" .. tag)
        assertEqual(0, seen.normalize, "no version reached the locale normaliser" .. tag)
    end

    -- CONTROL: a REAL one-version table must reach the normaliser exactly once,
    -- and be the SAME table -- so the zeroes above are not what this walk
    -- reports for everything.
    local name = "E1_control"
    local btn = makeBareButton(name)
    Engine.sequences[name] = { data = { name = name, defaultVersion = 1, versions = {} }, button = btn }
    local seqData = makeSequence("Sequential")
    seqData.name = name
    local seen = installSpellCache()
    local before = recovery.activate
    local ok, err = pcall(Engine.UpdateSequenceData, Engine, name, seqData)
    local count, first = seen.normalize, seen.versions[1]
    removeSpellCache()
    assertTrue(ok, "UpdateSequenceData raised on the well-formed control: " .. tostring(err))
    assertEqual(1, count, "the one real version reached the locale normaliser exactly once")
    assertTrue(first == seqData.versions[1], "and it was THAT version table, not a copy")
    -- CONTROL-FALSIFY on a second, independent observable: 0 authored steps ->
    -- 4 is a step-count change, so the save must take the full-rebuild branch.
    assertTrue(recovery.activate > before, "the step-count change drove the full rebuild")
end)

test("E2 (Engine.lua:2983): HealLocaleSteps walks a store holding every versions shape", function()
    -- Fired on SPELL_CACHE_REFRESHED after a client locale change, over EVERY
    -- stored sequence with no pcall between them -- so before the guard a single
    -- corrupt entry took the whole heal down and every well-formed sequence in
    -- the store silently kept its stale-locale steps.
    for _, row in ipairs(ENGINE_SHAPES) do
        local seen = installSpellCache()
        rawset(env, "GetLocale", function()
            return "enUS"
        end)
        local good = {
            name = "E2Good",
            defaultVersion = 1,
            versions = {
                {
                    stepFunction = "Sequential",
                    steps = { "/cast Alpha" },
                    taggedSteps = { "T1" },
                    stepsLocale = "deDE",
                },
            },
        }
        rawset(env, "GRIP_EMS_CHAR", {
            sequences = {
                E2Bad = { name = "E2Bad", defaultVersion = 1, versions = row.value },
                E2Good = good,
            },
        })
        local ok, err = pcall(Engine.HealLocaleSteps, Engine)
        rawset(env, "GRIP_EMS_CHAR", nil)
        rawset(env, "GetLocale", nil)
        removeSpellCache()
        local tag = " for versions=" .. row.label
        assertTrue(ok, "HealLocaleSteps raised" .. tag .. ": " .. tostring(err))
        assertEqual(0, seen.normalize, "this path does not use the normaliser" .. tag)
        local ver = good.versions[1]
        -- THE OBSERVABLE: the NEIGHBOUR in the same store was really healed.
        assertEqual("HEALED:T1:toNames", ver.steps[1], "the neighbour's step was healed from its tag" .. tag)
        assertEqual("enUS", ver.stepsLocale, "the neighbour's stepsLocale advanced to the client locale" .. tag)
        assertEqual("/cast Alpha", (ver.stepsOriginal or {})[1], "the pre-heal author text was preserved" .. tag)
        assertEqual("TAG:HEALED:T1:toNames", (ver.taggedSteps or {})[1], "the neighbour was re-tagged" .. tag)
    end

    -- CONTROL-FALSIFY: a version ALREADY in the client locale must not be
    -- touched, so the rows above cannot be passing through a walk that heals
    -- unconditionally.
    installSpellCache()
    rawset(env, "GetLocale", function()
        return "enUS"
    end)
    local fresh = {
        name = "E2Fresh",
        defaultVersion = 1,
        versions = {
            { stepFunction = "Sequential", steps = { "/cast Alpha" }, taggedSteps = { "T1" }, stepsLocale = "enUS" },
        },
    }
    rawset(env, "GRIP_EMS_CHAR", { sequences = { E2Fresh = fresh } })
    local okF, errF = pcall(Engine.HealLocaleSteps, Engine)
    rawset(env, "GRIP_EMS_CHAR", nil)
    rawset(env, "GetLocale", nil)
    removeSpellCache()
    assertTrue(okF, "the falsify control raised: " .. tostring(errF))
    assertEqual("/cast Alpha", fresh.versions[1].steps[1], "control-falsify: an in-locale version is left alone")
    assertEqual(nil, fresh.versions[1].stepsOriginal, "control-falsify: and no original was snapshotted")
end)

test("E3 (Engine.lua:3068): HealOverrideSteps walks a store holding every versions shape", function()
    -- Fired on PLAYER_SPECIALIZATION_CHANGED / TRAIT_CONFIG_UPDATED, same
    -- whole-store shape as E2: one corrupt entry used to cost every other
    -- sequence its talent-override re-translation.
    for _, row in ipairs(ENGINE_SHAPES) do
        local seen = installSpellCache()
        local good = {
            name = "E3Good",
            defaultVersion = 1,
            versions = {
                { stepFunction = "Sequential", steps = { "/cast Alpha" }, taggedSteps = { "T1" } },
            },
        }
        rawset(env, "GRIP_EMS_CHAR", {
            sequences = {
                E3Bad = { name = "E3Bad", defaultVersion = 1, versions = row.value },
                E3Good = good,
            },
        })
        local ok, err = pcall(Engine.HealOverrideSteps, Engine)
        local okD, entry = pcall(Engine.GetOverrideDisplay, Engine, "E3Good", 1)
        rawset(env, "GRIP_EMS_CHAR", nil)
        Engine._overrideDisplay = nil
        removeSpellCache()
        local tag = " for versions=" .. row.label
        assertTrue(ok, "HealOverrideSteps raised" .. tag .. ": " .. tostring(err))
        assertEqual(0, seen.normalize, "this path does not use the normaliser" .. tag)
        -- THE OBSERVABLE, INVERTED AT v2.4.4. It used to be that the
        -- neighbour's PERSISTED step had been re-translated in place. The walk
        -- no longer writes SavedVariables, so the observable is now that the
        -- neighbour was still REACHED past the corrupt entry -- proven by the
        -- display entry it produced, through the OVERRIDE arm
        -- (opts.useOverrides) rather than the plain one -- while its stored
        -- text came back byte-identical.
        assertEqual("/cast Alpha", good.versions[1].steps[1], "the neighbour's stored step is untouched" .. tag)
        assertTrue(okD and entry ~= nil, "the neighbour was reached past the corrupt entry" .. tag)
        assertEqual(
            "OVERRIDE:T1:toNames",
            entry.steps[1],
            "and its display entry was resolved with overrides applied" .. tag
        )
    end

    -- CONTROL-FALSIFY: a version with NO taggedSteps carries nothing to
    -- re-translate and must come back untouched.
    installSpellCache()
    local plain = {
        name = "E3Plain",
        defaultVersion = 1,
        versions = { { stepFunction = "Sequential", steps = { "/cast Alpha" } } },
    }
    rawset(env, "GRIP_EMS_CHAR", { sequences = { E3Plain = plain } })
    local okF, errF = pcall(Engine.HealOverrideSteps, Engine)
    local okFD, plainEntry = pcall(Engine.GetOverrideDisplay, Engine, "E3Plain", 1)
    rawset(env, "GRIP_EMS_CHAR", nil)
    Engine._overrideDisplay = nil
    removeSpellCache()
    assertTrue(okF, "the falsify control raised: " .. tostring(errF))
    assertEqual("/cast Alpha", plain.versions[1].steps[1], "control-falsify: an untagged version is left alone")
    assertTrue(okFD and plainEntry == nil, "control-falsify: and it produces no display entry either")
end)

test("E4 (Engine.lua:3201): DuplicateSequence copies every versions shape without raising", function()
    -- The deep-copy loop that builds the duplicate's version array. Everything
    -- is restored in one place at the bottom, including on failure, because
    -- both overrides installed here are read by cases OTHER than this one.
    local D = GRIPEMS.Defaults
    local savedActivate = Engine.ActivateSequence
    local savedCopy = D.CopyVersion
    local captured = {}

    D.CopyVersion = function(ver)
        if type(ver) ~= "table" then
            return {}
        end
        local copy = {}
        for k, v in pairs(ver) do
            copy[k] = v
        end
        if type(ver.steps) == "table" then
            copy.steps = {}
            for i, s in ipairs(ver.steps) do
                copy.steps[i] = s
            end
        end
        return copy
    end
    -- ActivateSequence is the counter stub from line 363 by this point, and it
    -- discards its arguments -- so the duplicate would be unobservable. Swap in
    -- a capturing stub of the same class for the length of this case.
    Engine.ActivateSequence = function(_, activateName, activateData)
        captured.name = activateName
        captured.data = activateData
    end

    local function run()
        for _, row in ipairs(ENGINE_SHAPES) do
            local src, dst = "E4Src_" .. row.label, "E4Dst_" .. row.label
            Engine.sequences[src] = { data = { name = src, defaultVersion = 1, versions = row.value } }
            captured.name, captured.data = nil, nil
            local ok, res = pcall(Engine.DuplicateSequence, Engine, src, dst)
            local tag = " for versions=" .. row.label
            assertTrue(ok, "DuplicateSequence raised" .. tag .. ": " .. tostring(res))
            assertEqual(true, res, "the duplicate reported success" .. tag)
            -- NOT merely "it returned". The copy reached activation, under the
            -- new name, carrying a versions TABLE whatever the source held.
            assertEqual(dst, captured.name, "the duplicate was activated under the new name" .. tag)
            assertEqual("table", type(captured.data.versions), "the duplicate carries a versions table" .. tag)
            assertEqual(0, #captured.data.versions, "no version was copyable from a malformed source" .. tag)
        end

        -- CONTROL: a REAL one-version source must be copied, so the empty
        -- arrays above are not what this function produces for everything.
        local src, dst = "E4Src_control", "E4Dst_control"
        Engine.sequences[src] = makeSequence("Sequential")
        Engine.sequences[src] = { data = Engine.sequences[src] }
        captured.name, captured.data = nil, nil
        local ok, res = pcall(Engine.DuplicateSequence, Engine, src, dst)
        assertTrue(ok, "DuplicateSequence raised on the well-formed control: " .. tostring(res))
        assertEqual(1, #captured.data.versions, "the control copied exactly one version")
        assertEqual(4, #captured.data.versions[1].steps, "and that version carries all four steps")
        assertEqual("/cast Alpha", captured.data.versions[1].steps[1], "with the source's step text")
        -- CONTROL-FALSIFY: a duplicate that ALIASED the source would satisfy
        -- every assertion above, and would be the forgery-adjacent bug this
        -- loop exists to avoid.
        local srcVer = Engine.sequences[src].data.versions[1]
        assertTrue(captured.data.versions[1] ~= srcVer, "control-falsify: the copy is a NEW table, not the source's")
        assertTrue(captured.data.versions[1].steps ~= srcVer.steps, "control-falsify: and so is its steps array")
    end

    local okAll, errAll = pcall(run)
    Engine.ActivateSequence = savedActivate
    D.CopyVersion = savedCopy
    if not okAll then
        error(errAll, 0)
    end
end)

-- ---------------------------------------------------------------------------
-- Pass 15t: the FOUR step-entry truthiness gates in Engine/Engine.lua.
--
-- WHY THE CASE LIVES HERE. Same reason G1 and E1-E4 give: this file loads the
-- REAL Engine/Engine.lua. Test/test_malformed_entry_guards.lua explicitly never
-- does -- see its own note at :216 -- so a fixture there could not drive these
-- four no matter how many shapes it ran.
--
-- WHY ONE OF THE FOUR WAS NEVER ON ANY LIST. Engine:CompileSteps opened with
-- "if not steps then". That line carries no "#", no field name and no length
-- operator, so every one of the census's nine shapes -- BARE_NOTLEN, BARE_LEN,
-- BARE_PAREN and the field-keyed family -- is structurally blind to it. The
-- other three were in the eight-item .steps residue and were left as NOT FIXED.
--
-- MEASURED at 914109d, one pcall per shape against the real Engine.lua, before
-- any guard landed:
--   CompileSteps(5) / (true)          :162  length of local 'steps'
--   CompileSteps("abc")               :163  bad argument #1 to 'ipairs'
--   BuildExecutionOrder(5) / (true)   :254  length of local 'steps'
--   BuildExecutionOrder("abc")        :263  bad argument #1 to 'ipairs'
--   SimulateSteps(5) / (true)         :307  length of local 'steps'
--   SimulateSteps("abc")              :263  via BuildExecutionOrder
--   BuildExecuteString(5) / (true)    :459  length of local 'compiledSteps'
--   BuildExecuteString("abc")         :463  bad argument #1 to 'ipairs'
-- THREE shapes raise per entry point, not two. The string is why the fix is a
-- type test and not a tightened truthiness test: "#" on a string is legal and
-- returns its byte length, so a string sails past any length test and dies at
-- the ipairs one line later.
--
-- ONE MEASURED ASYMMETRY, recorded because it changes what a single-guard
-- revert proves. The string row for SimulateSteps raised at 914109d only
-- because BuildExecutionOrder was unguarded too. With EDIT 5 alone reverted the
-- upstream guard absorbs the string and SimulateSteps("abc") returns cleanly --
-- so that revert reddens on the number and boolean rows and NOT on the string.
-- The other three entry points own all three of their shapes outright.
--
-- The rows assert the RETURN SHAPE, not merely the absence of a raise: a guard
-- that returned nil would satisfy a pcall-only case. The TABLE CONTROL at the
-- bottom is what stops all of it passing against a head that returned early
-- unconditionally, and the nil row pins the one shape the old truthiness gates
-- already absorbed as unchanged.
-- ---------------------------------------------------------------------------

local ENTRY_SHAPES = {
    { label = "number", value = 5 },
    { label = "boolean", value = true },
    { label = "string", value = "abc" },
}

local EMPTY_EXEC_STRING = "steps = newtable()\nnumSteps = 0\n"

test("T1 (step-entry shapes): the four Engine step entry points absorb every scalar", function()
    for _, row in ipairs(ENTRY_SHAPES) do
        local tag = " for steps=" .. row.label

        -- CompileSteps -- the site no census pattern could see.
        local csOk, csRes = pcall(Engine.CompileSteps, Engine, row.value, "", "")
        assertTrue(csOk, "CompileSteps raised" .. tag .. ": " .. tostring(csRes))
        assertEqual("table", type(csRes), "CompileSteps returns a table" .. tag)
        assertEqual(0, #csRes, "CompileSteps compiles zero steps" .. tag)

        -- BuildExecutionOrder -- both returns are pinned, not just the first.
        local beoOk, beoOrder, beoRandom = pcall(Engine.BuildExecutionOrder, Engine, row.value, "Sequential")
        assertTrue(beoOk, "BuildExecutionOrder raised" .. tag .. ": " .. tostring(beoOrder))
        assertEqual("table", type(beoOrder), "BuildExecutionOrder returns a table" .. tag)
        assertEqual(0, #beoOrder, "BuildExecutionOrder returns an empty order" .. tag)
        assertEqual(false, beoRandom, "BuildExecutionOrder still reports isRandom = false" .. tag)

        -- SimulateSteps -- the icon-strip preview path.
        local simOk, simRes = pcall(Engine.SimulateSteps, Engine, row.value, "Sequential", 5)
        assertTrue(simOk, "SimulateSteps raised" .. tag .. ": " .. tostring(simRes))
        assertEqual("table", type(simRes), "SimulateSteps returns a table" .. tag)
        assertEqual(0, #simRes, "SimulateSteps simulates zero steps" .. tag)

        -- BuildExecuteString -- the restricted-env payload builder.
        local besOk, besRes = pcall(Engine.BuildExecuteString, Engine, row.value)
        assertTrue(besOk, "BuildExecuteString raised" .. tag .. ": " .. tostring(besRes))
        assertEqual("string", type(besRes), "BuildExecuteString returns a string" .. tag)
        assertEqual(EMPTY_EXEC_STRING, besRes, "BuildExecuteString returns the empty-steps payload" .. tag)
    end

    -- NIL, pinned as UNCHANGED. The old truthiness gates already absorbed it,
    -- so no caller may see a new shape because the test tightened.
    local nilOk, nilRes = pcall(Engine.CompileSteps, Engine, nil, "", "")
    assertTrue(nilOk, "CompileSteps raised for steps=nil: " .. tostring(nilRes))
    assertEqual("table", type(nilRes), "CompileSteps still returns a table for steps=nil")
    assertEqual(0, #nilRes, "CompileSteps still compiles zero steps for steps=nil")

    -- TABLE CONTROL, LAST and able to fail. Without it every row above is
    -- satisfied by a head that returned early unconditionally.
    local ctlSteps = { "/cast Alpha" }
    local ctlCompiled = Engine:CompileSteps(ctlSteps, "", "")
    assertEqual(1, #ctlCompiled, "control: CompileSteps compiles the one authored step")
    assertEqual("/cast Alpha", ctlCompiled[1].macrotext, "control: and carries its macrotext")

    local ctlOrder, ctlRandom = Engine:BuildExecutionOrder(ctlSteps, "Sequential")
    assertEqual(1, #ctlOrder, "control: BuildExecutionOrder returns a non-empty order")
    assertEqual("/cast Alpha", ctlOrder[1], "control: and it is the resolved step text")
    assertEqual(false, ctlRandom, "control: Sequential is not random")

    local ctlSim = Engine:SimulateSteps(ctlSteps, "Sequential", 5)
    assertEqual(5, #ctlSim, "control: SimulateSteps returns one entry per simulated keypress")

    local ctlExec = Engine:BuildExecuteString(ctlCompiled)
    assertTrue(ctlExec ~= EMPTY_EXEC_STRING, "control: BuildExecuteString does not return the empty payload")
    assertTrue(ctlExec:find("numSteps = 1", 1, true) ~= nil, "control: and it reports the one compiled step")
end)

-- ---------------------------------------------------------------------------
-- Channel-hold cases (holdOnChannel).
--
-- No test in the suite EXECUTED a click body before this: battery_spec only
-- string-compares BuildClickBody() output. So there was no existing environment
-- fake to follow, and this one is added here beside the cases that use it rather
-- than as a second harness file. It loads the REAL body string returned by the
-- REAL SF.Sequential/SF.Random.BuildClickBody and runs it under a fake self, so
-- the thing under test is the shipped snippet and not a paraphrase of it.
--
-- Every modifier predicate reads false and GetFrameRef returns nil (no driver),
-- so the skyriding branch is inert and the only variables are the two the hold
-- actually reads: the holdOnChannel attribute and PlayerIsChanneling.
-- ---------------------------------------------------------------------------

local function RunClickBody(body, opts)
    opts = opts or {}
    local attrs = opts.attrs or {}
    local calls = {}
    local fakeSelf = {
        GetAttribute = function(_, k)
            return attrs[k]
        end,
        SetAttribute = function(_, k, v)
            attrs[k] = v
        end,
        CallMethod = function(_, m)
            calls[#calls + 1] = m
        end,
        GetFrameRef = function()
            return nil
        end,
    }
    local cenv = {
        self = fakeSelf,
        button = opts.button or "LeftButton",
        steps = opts.steps or {},
        numSteps = opts.numSteps or #(opts.steps or {}),
        PlayerIsChanneling = function()
            return opts.channeling and true or false
        end,
        SecureCmdOptionParse = function()
            return "seq"
        end,
        math = math,
        pairs = pairs,
        tonumber = tonumber,
        random = function(a)
            return a or 1
        end,
    }
    local mods = {
        "IsShiftKeyDown",
        "IsControlKeyDown",
        "IsAltKeyDown",
        "IsLeftShiftKeyDown",
        "IsRightShiftKeyDown",
        "IsLeftControlKeyDown",
        "IsRightControlKeyDown",
        "IsLeftAltKeyDown",
        "IsRightAltKeyDown",
    }
    for _, modName in ipairs(mods) do
        cenv[modName] = function()
            return false
        end
    end
    local chunk = assert(loadstring(body, "clickbody"))
    setfenv(chunk, cenv)
    chunk()
    return attrs, calls
end

local HOLD_STEPS = {
    { type = "macro", macrotext = "/cast Alpha" },
    { type = "macro", macrotext = "/cast Beta" },
}

local function ContainsCall(calls, want)
    for _, c in ipairs(calls) do
        if c == want then
            return true
        end
    end
    return false
end

-- H1 is the INTEGRATION SHAPE and it is the one that matters most. Every
-- sequence saved before this feature existed carries NO holdOnChannel field at
-- all, so the engine writes no attribute and GetAttribute returns nil. A case
-- that only ever sets the attribute explicitly does not cover that path.
test("H1 no holdOnChannel attribute at all: channeling does NOT hold the step", function()
    local attrs, calls = RunClickBody(SF.Sequential.BuildClickBody(), {
        steps = HOLD_STEPS,
        channeling = true,
        attrs = { step = 1 },
    })
    assertEqual(2, attrs.step, "H1: step advanced 1 -> 2 with no hold attribute present")
    assertEqual("/cast Alpha", attrs.macrotext, "H1: and the step macrotext was applied")
    assertTrue(ContainsCall(calls, "UpdateIcon"), "H1: the normal path ran to completion")
end)

test("H2 holdOnChannel on but NOT channeling: step advances normally", function()
    local attrs = RunClickBody(SF.Sequential.BuildClickBody(), {
        steps = HOLD_STEPS,
        channeling = false,
        attrs = { step = 1, holdOnChannel = "1" },
    })
    assertEqual(2, attrs.step, "H2: step advanced 1 -> 2")
    assertEqual("/cast Alpha", attrs.macrotext, "H2: and the step macrotext was applied")
end)

test("H3 holdOnChannel on AND channeling: step holds and the press casts nothing", function()
    local attrs, calls = RunClickBody(SF.Sequential.BuildClickBody(), {
        steps = HOLD_STEPS,
        channeling = true,
        attrs = { step = 1, holdOnChannel = "1", macrotext = "/cast Stale" },
    })
    assertEqual(1, attrs.step, "H3: step did NOT advance")
    -- The cleared shape is load-bearing: a second cast of the same empowered
    -- spell is discarded silently inside the tap threshold and releases it early
    -- beyond that, so the press must carry no macro at all rather than the old one.
    assertEqual("", attrs.macrotext, "H3: macrotext cleared, not left at the previous step")
    assertEqual(nil, attrs.macro, "H3: macro attribute cleared")
    assertEqual(nil, attrs.unit, "H3: unit attribute cleared")
    assertTrue(ContainsCall(calls, "PostClick"), "H3: PostClick still fired")
    assertTrue(not ContainsCall(calls, "UpdateIcon"), "H3: returned before the normal tail")
end)

test("H4 Random body holds on the same condition", function()
    local attrs, calls = RunClickBody(SF.Random.BuildClickBody(), {
        steps = HOLD_STEPS,
        channeling = true,
        attrs = { holdOnChannel = "1", macrotext = "/cast Stale" },
    })
    assertEqual(nil, attrs.step, "H4: Random never reached its step write")
    assertEqual("", attrs.macrotext, "H4: macrotext cleared")
    assertTrue(ContainsCall(calls, "PostClick"), "H4: PostClick still fired")
end)

-- Placement proof. The hold sits ABOVE the modReset run, so a reset modifier
-- that would otherwise latch _shouldReset must not have been written. If the
-- block were moved below that run this case fails while H3 still passes.
test("H5 hold returns ABOVE the modReset run, leaving no half-applied state", function()
    local attrs = RunClickBody(SF.Sequential.BuildClickBody(), {
        steps = HOLD_STEPS,
        channeling = true,
        button = "LeftButton",
        attrs = { step = 1, holdOnChannel = "1", resetMod_LeftButton = "1" },
    })
    assertEqual(nil, attrs._shouldReset, "H5: _shouldReset was never written")
    assertEqual(1, attrs.step, "H5: and the step is untouched")
end)

-- ---------------------------------------------------------------------------
-- Empower release cases (releaseAtMax + empowerRelease), H6 through H10.
--
-- MEASURED in the client 2026-08-13: a second /cast gated on [nochanneling]
-- fired while the empower sits in its hold-at-max window releases the spell at
-- MAX rank and reports EMPOWER_STOP complete=true. During the ramp the same
-- macrotext no-ops because the conditional reads false, so ONE text covers both
-- zones and nothing here counts stages or measures time.
--
-- The release rides the branch that was ALREADY consuming the press: the hold
-- still returns without advancing the step cursor, it just no longer sets the
-- macrotext to the empty string. H6 is the upgrade path and H10 is the
-- unreachable-by-UI pair; both must stay inert.
-- ---------------------------------------------------------------------------

local RELEASE_TEXT = "/cast [nochanneling] Fire Breath"

test("H6 holdOnChannel on, releaseAtMax ABSENT: release text is published but not used", function()
    local attrs, calls = RunClickBody(SF.Sequential.BuildClickBody(), {
        steps = HOLD_STEPS,
        channeling = true,
        attrs = { step = 1, holdOnChannel = "1", empowerRelease = RELEASE_TEXT },
    })
    assertEqual("", attrs.macrotext, "H6: a pre-feature sequence still casts nothing on a held press")
    assertEqual(1, attrs.step, "H6: and the step did NOT advance")
    assertTrue(ContainsCall(calls, "PostClick"), "H6: PostClick still fired")
end)

test("H7 holdOnChannel + releaseAtMax on: the held press carries the release", function()
    local attrs, calls = RunClickBody(SF.Sequential.BuildClickBody(), {
        steps = HOLD_STEPS,
        channeling = true,
        attrs = { step = 1, holdOnChannel = "1", releaseAtMax = "1", empowerRelease = RELEASE_TEXT },
    })
    assertEqual(RELEASE_TEXT, attrs.macrotext, "H7: macrotext is the release text verbatim")
    assertEqual(1, attrs.step, "H7: step did NOT advance -- the release is not a step cast")
    assertEqual(nil, attrs.macro, "H7: macro attribute cleared")
    assertEqual(nil, attrs.unit, "H7: unit attribute cleared")
    assertTrue(ContainsCall(calls, "PostClick"), "H7: PostClick still fired")
    assertTrue(not ContainsCall(calls, "UpdateIcon"), "H7: returned before the normal tail")
end)

test("H8 releaseAtMax on but NO empowerRelease: the press still casts nothing", function()
    local attrs = RunClickBody(SF.Sequential.BuildClickBody(), {
        steps = HOLD_STEPS,
        channeling = true,
        attrs = { step = 1, holdOnChannel = "1", releaseAtMax = "1", macrotext = "/cast Stale" },
    })
    assertEqual("", attrs.macrotext, "H8: a non-empower step cannot fire a release during an unrelated channel")
    assertEqual(1, attrs.step, "H8: and the step did NOT advance")
end)

test("H9 Random body carries the release on the same condition", function()
    local attrs, calls = RunClickBody(SF.Random.BuildClickBody(), {
        steps = HOLD_STEPS,
        channeling = true,
        attrs = { holdOnChannel = "1", releaseAtMax = "1", empowerRelease = RELEASE_TEXT },
    })
    assertEqual(RELEASE_TEXT, attrs.macrotext, "H9: macrotext is the release text verbatim")
    assertEqual(nil, attrs.macro, "H9: macro attribute cleared")
    assertEqual(nil, attrs.unit, "H9: unit attribute cleared")
    assertTrue(ContainsCall(calls, "PostClick"), "H9: PostClick still fired")
    assertTrue(not ContainsCall(calls, "UpdateIcon"), "H9: returned before the normal tail")
end)

-- The UI cannot produce releaseAtMax without holdOnChannel, but a hand-edited
-- SavedVariables can. The click body tests holdOnChannel FIRST, so the pair is
-- inert rather than a second, ungated release path.
test("H10 releaseAtMax on with NO holdOnChannel: the normal path runs", function()
    local attrs, calls = RunClickBody(SF.Sequential.BuildClickBody(), {
        steps = HOLD_STEPS,
        channeling = true,
        attrs = { step = 1, releaseAtMax = "1", empowerRelease = RELEASE_TEXT },
    })
    assertEqual(2, attrs.step, "H10: step advanced 1 -> 2")
    assertEqual("/cast Alpha", attrs.macrotext, "H10: and the step's own text was applied, not the release")
    assertTrue(ContainsCall(calls, "UpdateIcon"), "H10: the normal path ran to completion")
end)

-- ---------------------------------------------------------------------------
-- Release-lookup and stale-release cases, R1 through R7.
--
-- H8 AND R7 ARE DIFFERENT STATES, and conflating them is what let a defect
-- through review. H8 covers empowerRelease ABSENT: the attribute was never
-- written to the button, the hold falls back to "" and the press casts nothing.
-- R7 covers empowerRelease STALE: the attribute IS on the button, left there by
-- an earlier step commit on a different step function, and nothing on the switch
-- path overwrote or cleared it. Absent is safe by construction; stale casts the
-- WRONG SPELL during the next empower's hold-at-max window.
--
-- These cases drive the two public Engine methods in isolation, which is the
-- right shape for input-domain coverage: nil, empty, non-string, the tooltip
-- filter and the not-in-map fallback are all far cheaper to state here than
-- through a full recompile.
--
-- CORRECTION. This block used to end by saying ResolveFitAndExpand is "reachable
-- from no suite" and that its wiring is source-only. That was FALSE, and
-- Engine.lua's own comment inside the helper said so at the time: the one caller
-- a suite reaches is RecompileSequence's base path, which the D-block above
-- already drives with a Priority sequence. The S-block below now asserts the
-- stamping end to end through that path.
-- ---------------------------------------------------------------------------

local R_EMPOWER_NAME = "Fire Breath"
local R_EMPOWER_ID = 357208
local R_PLAIN_NAME = "Living Flame"
local R_PLAIN_ID = 361469
local R_RELEASE = "/cast [nochanneling] " .. R_EMPOWER_NAME

-- Same SpellCache stub shape Test/empower_repair_spec.lua uses, so detection
-- stays on IsEmpowerSpell and never on a class, a spec or a name compare. The
-- stubs are installed for one case and removed afterwards: every case above ran
-- with SpellCache absent and must keep doing so.
local function WithSpellStubs(fn)
    local empowerSet = { [R_EMPOWER_ID] = true }
    GRIPEMS.SpellCache = {
        ready = true,
        empowerIDs = empowerSet,
        hasEmpower = true,
        GetSpellID = function(_, name)
            if name == R_EMPOWER_NAME then
                return R_EMPOWER_ID
            elseif name == R_PLAIN_NAME then
                return R_PLAIN_ID
            end
            return nil
        end,
        IsEmpowerSpell = function(_, id)
            return id ~= nil and empowerSet[id] == true
        end,
        HasEmpowerSpells = function()
            return true
        end,
    }
    GRIPEMS.SpellValidator = {
        -- Minimal stand-in that keeps the ONE distinction the lookup reads: a
        -- #showtooltip argument carries command "showtooltip", a cast does not.
        ExtractAllSpells = function(_, text)
            local out = {}
            if type(text) ~= "string" then
                return out
            end
            for line in text:gmatch("[^\r\n]+") do
                local tt = line:match("^%s*#showtooltip%s+(.+)$")
                local rest = line:match("^%s*/cast%s+(.+)$") or line:match("^%s*/use%s+(.+)$")
                local name = tt or rest
                if name then
                    name = name:gsub("%[.-%]", ""):gsub("^%s+", ""):gsub("%s+$", "")
                    if name ~= "" then
                        out[#out + 1] = { name = name, command = tt and "showtooltip" or "cast" }
                    end
                end
            end
            return out
        end,
    }
    local ok, err = pcall(fn)
    GRIPEMS.SpellCache = nil
    GRIPEMS.SpellValidator = nil
    if not ok then
        error(err, 0)
    end
end

test("R1 EmpowerReleaseFor on a step casting the empowered spell returns the release", function()
    WithSpellStubs(function()
        local got = Engine:EmpowerReleaseFor("/cast " .. R_EMPOWER_NAME)
        assertEqual(R_RELEASE, got, "R1: release built from the step's own cast")
    end)
end)

test("R2 EmpowerReleaseFor on a plain non-empower step returns the empty string", function()
    WithSpellStubs(function()
        local got = Engine:EmpowerReleaseFor("/cast " .. R_PLAIN_NAME)
        assertEqual("", got, "R2: a known non-empower spell arms nothing")
    end)
end)

test("R3 EmpowerReleaseFor absorbs nil, empty and non-string input", function()
    WithSpellStubs(function()
        assertEqual("", Engine:EmpowerReleaseFor(nil), "R3: nil returns the empty string")
        assertEqual("", Engine:EmpowerReleaseFor(""), "R3: empty string returns the empty string")
        assertEqual("", Engine:EmpowerReleaseFor(5), "R3: a number returns the empty string")
        assertEqual("", Engine:EmpowerReleaseFor(true), "R3: a boolean returns the empty string")
        assertEqual("", Engine:EmpowerReleaseFor({}), "R3: a table returns the empty string")
    end)
end)

-- Pins the command filter. #showtooltip names the spell for the icon; it casts
-- nothing, so it must never decide which spell a release names.
test("R4 EmpowerReleaseFor ignores a #showtooltip naming the empowered spell", function()
    WithSpellStubs(function()
        local text = "#showtooltip " .. R_EMPOWER_NAME .. "\n/cast " .. R_PLAIN_NAME
        local got = Engine:EmpowerReleaseFor(text)
        assertEqual("", got, "R4: a tooltip line does not arm a release")
    end)
end)

test("R5 StampEmpowerReleases stamps mapped entries and empty-strings an unmapped one", function()
    local map = {
        ["/cast " .. R_EMPOWER_NAME] = R_RELEASE,
        ["/cast " .. R_PLAIN_NAME] = "",
    }
    local out = {
        { type = "macro", macrotext = "/cast " .. R_EMPOWER_NAME },
        { type = "macro", macrotext = "/cast " .. R_PLAIN_NAME },
        { type = "macro", macrotext = "/cast Something A Plugin Invented" },
    }
    local same = Engine:StampEmpowerReleases(out, map)
    assertTrue(same == out, "R5: the same array comes back, stamped in place")
    assertEqual(R_RELEASE, out[1].empowerRelease, "R5: the mapped empower entry carries its release")
    assertEqual("", out[2].empowerRelease, "R5: the mapped plain entry carries the empty string")
    -- Exactly "" is load-bearing, not merely tidy. A nil field would read the
    -- same through the click body's "or", but BuildExecuteString walks the step
    -- table with pairs() and a nil field is simply not there, so no attribute
    -- would be published and a stale one already on the button would survive.
    assertEqual("", out[3].empowerRelease, "R5: an invented text stamps exactly the empty string")
    assertEqual("string", type(out[3].empowerRelease), "R5: and it is a string, not nil")
end)

test("R6 StampEmpowerReleases absorbs a nil array, a scalar and a non-table element", function()
    assertEqual(nil, Engine:StampEmpowerReleases(nil, {}), "R6: nil array returns nil without raising")
    assertEqual(5, Engine:StampEmpowerReleases(5, {}), "R6: a scalar comes back unchanged")
    local out = { { type = "macro", macrotext = "/cast Alpha" }, 7 }
    local ok = pcall(Engine.StampEmpowerReleases, Engine, out, nil)
    assertTrue(ok, "R6: a non-table element does not raise")
    assertEqual("", out[1].empowerRelease, "R6: and the real entry still stamped with a nil map")
end)

-- THE REGRESSION. Two presses against ONE attrs table, because a real button
-- keeps its attributes across presses and nothing between them recreates it.
test("R7 a step-function switch cannot leave a STALE release armed on the button", function()
    local attrs = { step = 1 }
    local staleSteps = {
        { type = "macro", macrotext = "/cast Alpha", empowerRelease = R_RELEASE },
        { type = "macro", macrotext = "/cast Beta", empowerRelease = "" },
    }
    RunClickBody(SF.Sequential.BuildClickBody(), {
        steps = staleSteps,
        channeling = false,
        attrs = attrs,
    })
    assertEqual(R_RELEASE, attrs.empowerRelease, "R7: press 1 committed the step and armed the release")

    -- The switch. Engine:UpdateSequenceData republishes releaseAtMax and now
    -- clears empowerRelease on the SAME button object, which is the line under
    -- test here; RecompileSequence then swaps in expander output.
    attrs.empowerRelease = nil
    attrs.holdOnChannel = "1"
    attrs.releaseAtMax = "1"

    local after = RunClickBody(SF.Sequential.BuildClickBody(), {
        steps = staleSteps,
        channeling = true,
        attrs = attrs,
    })
    assertEqual("", after.macrotext, "R7: the held press casts nothing")
    assertTrue(after.macrotext ~= R_RELEASE, "R7: and specifically NOT the outgoing version's release text")
end)

-- ---------------------------------------------------------------------------
-- Recompile-invariant and end-to-end stamping cases, S1 through S5.
--
-- These are named S1..S5 and the P-block above already has a case printed as
-- "S1: Sequential 4-step stays 4". The two are unrelated; every case here prints
-- "S<n> (recompile):" so the two blocks stay distinguishable in the output.
--
-- WHAT THIS BLOCK EXISTS TO PROVE, both of which were previously declared
-- untestable and were not:
--
--   1. THE INVARIANT IS ON THE RECOMPILE. A recompile is the event that
--      re-evaluates the four-arm step-function branch and swaps the steps table,
--      so it is the moment the PRODUCER of empowerRelease can change. Clearing
--      only where releaseAtMax is published misses it, because
--      Engine:UpdateSequenceData gates its whole publish block on
--      "not OOCQueue.IsRestricted()" with NO queue fallback, while
--      RecompileSequence DOES queue -- so an in-combat step-function change lands
--      the recompile and never lands the publish. S1 fails without the clear.
--
--   2. THE EXPANDER ARM REALLY STAMPS. RecompileSequence's base path is a
--      ResolveFitAndExpand caller for the Priority, ReversePriority and plugin
--      arms, and the D-block above already drives it. So the stamping is
--      assertable end to end here, through the REAL ExpandPriority and
--      ExpandReversePriority, rather than only through StampEmpowerReleases in
--      isolation. S4 pins that the CompileSteps arm produces the SAME field for
--      the same step text, which is the property the two public methods exist to
--      guarantee, and S5 is the non-vacuity control in the D0 spirit.
-- ---------------------------------------------------------------------------

local S_EMPOWER_STEP = "/cast " .. R_EMPOWER_NAME
local S_PLAIN_STEP = "/cast " .. R_PLAIN_NAME
-- Two authored steps, so every expander produces BOTH kinds in its output:
-- Priority gives [empower, empower, plain] and ReversePriority [plain, empower,
-- plain]. A single-step fixture could pass the "every entry matches" assertion
-- while covering only one branch.
local S_STEPS = { S_EMPOWER_STEP, S_PLAIN_STEP }

-- Assert the stamped field on every entry of a recompiled button's _execSteps,
-- and refuse to pass on an empty or single-kind array.
local function assertStampedExecSteps(btn, label)
    local exec = btn._execSteps
    assertTrue(type(exec) == "table" and #exec > 0, label .. ": _execSteps is a non-empty array")
    local sawEmpower, sawPlain = 0, 0
    for i = 1, #exec do
        local e = exec[i]
        if e.macrotext == S_EMPOWER_STEP then
            sawEmpower = sawEmpower + 1
            assertEqual(R_RELEASE, e.empowerRelease, label .. ": empower entry " .. i .. " carries its release")
        elseif e.macrotext == S_PLAIN_STEP then
            sawPlain = sawPlain + 1
            assertEqual("", e.empowerRelease, label .. ": plain entry " .. i .. " carries exactly the empty string")
        else
            error(label .. ": unexpected macrotext at " .. i .. ": " .. tostring(e.macrotext), 2)
        end
    end
    assertTrue(sawEmpower >= 1, label .. ": at least one empower entry was seen")
    assertTrue(sawPlain >= 1, label .. ": at least one plain entry was seen")
end

-- Drive a real recompile with Execute allowed through, the way D0 does.
local function recompileWith(stepFunction, steps)
    local btn = makeRecompileEntry(7, false, stepFunction, steps)
    Engine.DeferIfBraced = function()
        return false
    end
    Engine:RecompileSequence("RC_Seq")
    return btn
end

-- S1 is the case that FAILS on c99e392 and passes with the recompile clear.
test("S1 (recompile): a recompile clears a stale empowerRelease off the base button", function()
    local btn = makeRecompileEntry(7, false, "Priority")
    btn._attrs.empowerRelease = R_RELEASE
    Engine.DeferIfBraced = function()
        return false
    end
    Engine:RecompileSequence("RC_Seq")
    assertEqual(nil, btn._attrs.empowerRelease, "S1: the recompile cleared the outgoing arm's armed release")
end)

test("S2 (recompile): Priority stamps the release end to end through ExpandPriority", function()
    WithSpellStubs(function()
        local btn = recompileWith("Priority", S_STEPS)
        assertStampedExecSteps(btn, "S2")
    end)
end)

test("S3 (recompile): ReversePriority stamps the release end to end", function()
    WithSpellStubs(function()
        local btn = recompileWith("ReversePriority", S_STEPS)
        assertStampedExecSteps(btn, "S3")
    end)
end)

-- Both compile paths, same step text, same field. This is the agreement the two
-- public methods exist to guarantee; without it the release would work on one
-- step function and silently not on another.
test("S4 (recompile): the CompileSteps arm produces the same field for the same text", function()
    WithSpellStubs(function()
        local btn = recompileWith("Sequential", S_STEPS)
        assertStampedExecSteps(btn, "S4")
    end)
end)

-- NON-VACUITY CONTROL, in the D0 spirit. With no SpellCache, EmpowerReleaseFor
-- short-circuits before it can ask anything, so nothing may carry a release.
-- S2 and S4 cannot both be satisfied by a permissive stub that matches every
-- name, because this case runs the SAME fixture with the stub gone and demands
-- the opposite answer.
test("S5 (recompile): with no SpellCache nothing is stamped, on the same fixture", function()
    assertEqual(nil, GRIPEMS.SpellCache, "S5: the stub really was torn down before this case")
    local btn = recompileWith("Priority", S_STEPS)
    local exec = btn._execSteps
    assertTrue(type(exec) == "table" and #exec > 0, "S5: _execSteps is a non-empty array")
    for i = 1, #exec do
        assertEqual("", exec[i].empowerRelease, "S5: entry " .. i .. " carries exactly the empty string")
    end
end)

-- ---------------------------------------------------------------------------
-- S6, THE COLD-START REGRESSION (EMPOWER-RELEASE-INERT-UNTIL-RECOMPILE).
--
-- WHY NOTHING ABOVE COULD SEE THIS. Every H, R and S case hands the empower
-- data to the compile -- H and R construct the release text directly, S2..S4
-- install the stubs BEFORE calling recompileWith. So all of them describe a
-- compile that already had the answer. The shipped defect is the opposite
-- order: at login and at every reload the sequence compiles BEFORE the
-- spellbook walk has populated the empower set, so every step stamps "" and
-- nothing re-stamps it afterwards. The hold still works and the empower still
-- completes on its own, so the user is never told; the release they enabled is
-- simply inert for the whole session unless they happen to edit the sequence.
--
-- THE ORDER IS THE CASE, and it is the in-game measurement replayed:
--   1. compile with SpellCache absent          -> every entry stamps ""
--      (reading 1: _execSteps[1].empowerRelease is the EMPTY STRING)
--   2. the cache settles, the lookup now answers
--      (reading 2: EmpowerReleaseFor returns the release AT THAT SAME MOMENT,
--       while the compiled array still carries "" -- so the data is there and
--       the bake is what is stale)
--   3. run the heal the SPELL_CACHE_REFRESHED handler runs
--      (reading 3 without the by-hand RecompileSequence the measurement needed)
--
-- THE CALL AT STEP 3 IS GUARDED ON PURPOSE. Pre-fix the method does not exist,
-- and a direct call would redden this case with "attempt to call a nil value",
-- which proves nothing about stamping. Guarded, the pre-fix run falls through
-- to assertStampedExecSteps and reddens on the DEFECT -- entry 1 still carrying
-- the empty string after the data arrived. That is the RED this case is for.
-- ---------------------------------------------------------------------------

test("S6 (cold start): a compile that ran before the empower data existed heals itself", function()
    -- Precondition, stated rather than assumed: this compile really is cold.
    assertEqual(nil, GRIPEMS.SpellCache, "S6: the cold-start compile runs with no empower data, as at login")
    local btn = recompileWith("Priority", S_STEPS)
    local cold = btn._execSteps
    assertTrue(type(cold) == "table" and #cold > 0, "S6: the cold compile produced a non-empty array")
    for i = 1, #cold do
        assertEqual("", cold[i].empowerRelease, "S6 (cold): entry " .. i .. " stamped the empty string")
    end

    WithSpellStubs(function()
        -- Reading 2. Both halves matter: the lookup was never broken, and the
        -- compiled entry is still empty at the same moment. Without the second
        -- assertion the case could pass on a fixture that was never stale.
        assertEqual(R_RELEASE, Engine:EmpowerReleaseFor(S_EMPOWER_STEP), "S6: the lookup itself answers correctly now")
        assertEqual("", btn._execSteps[1].empowerRelease, "S6: and the baked entry is STILL empty at that moment")

        if Engine.HealEmpowerReleases then
            local healed = Engine:HealEmpowerReleases()
            assertTrue(healed >= 1, "S6: the heal re-queued at least the stale sequence")
            assertStampedExecSteps(btn, "S6")
            -- The latch. A heal that ran on every refresh would recompile every
            -- active sequence forever; it fires once per empower-availability
            -- transition and reports nothing to do on the next refresh.
            assertEqual(0, Engine:HealEmpowerReleases(), "S6: the heal is one-shot per availability transition")
        else
            assertStampedExecSteps(btn, "S6")
        end
    end)
end)

-- S7 IS THE ARM THE MEASUREMENT DID NOT COVER. The in-game readings were taken
-- on a Priority sequence, so they exercised ResolveFitAndExpand /
-- StampEmpowerReleases only. Engine:CompileSteps bakes the SAME field from the
-- SAME Engine:EmpowerReleaseFor for Sequential and Random, so it is affected
-- identically -- but that was inferred from source, never driven. S7 drives it:
-- same cold-then-warm order as S6, on the other arm.
--
-- It also exercises the latch-release branch rather than reaching into the
-- field. Calling the heal while SpellCache is absent is the real behaviour of a
-- character that knows no empowered spell: it reports nothing to do AND drops
-- the latch, which is what lets a later transition into an empower spec heal.
-- That is precisely the state a fresh login presents, so S7 gets it honestly.
test("S7 (cold start): the CompileSteps arm heals on the same cold-then-warm order", function()
    assertEqual(nil, GRIPEMS.SpellCache, "S7: the cold-start compile runs with no empower data")
    if Engine.HealEmpowerReleases then
        local idle = Engine:HealEmpowerReleases()
        assertEqual(0, idle, "S7: with no empower data the heal reports nothing to do")
    end

    local btn = recompileWith("Sequential", S_STEPS)
    local cold = btn._execSteps
    assertEqual(#S_STEPS, #cold, "S7: Sequential does not expand, so the array matches the authored count")
    for i = 1, #cold do
        assertEqual("", cold[i].empowerRelease, "S7 (cold): entry " .. i .. " stamped the empty string")
    end

    WithSpellStubs(function()
        assertEqual("", btn._execSteps[1].empowerRelease, "S7: the baked entry is still empty once data exists")
        if Engine.HealEmpowerReleases then
            assertTrue(Engine:HealEmpowerReleases() >= 1, "S7: the heal re-queued the stale Sequential sequence")
        end
        assertStampedExecSteps(btn, "S7")
    end)
end)

-- ---------------------------------------------------------------------------
-- In-combat publish cases, C1 and C2.
--
-- Engine:UpdateSequenceData's in-place branch used to be gated on
-- "btn and not OOCQueue.IsRestricted()" with NO fallback, so in combat the whole
-- publish was skipped and never retried, while the RecompileSequence call in the
-- SAME branch does queue and lands afterwards. A setting changed in combat
-- therefore swapped the compiled steps while the button kept the old attributes
-- until something else happened to republish.
--
-- The publish now runs through the same OOCQueue gate the SETTING_CHANGED site at
-- the bottom of Engine.lua already uses, and re-resolves entry, button and active
-- version at DRAIN time instead of capturing them. C2 is exactly that property:
-- it mutates the version between queue and drain and asserts the LATER value wins,
-- which is the self-correcting behaviour the decision to ship rested on.
--
-- The file-scope OOCQueue stub drains synchronously, which is what every case
-- above wants. These two swap in a stub that really DEFERS, so "queued but not
-- applied" and "applied" are separately observable, and restore it afterwards.
-- ---------------------------------------------------------------------------

local OP_SETTING = GRIPEMS.Defaults.OOC_OP_SETTING
assert(type(OP_SETTING) == "string", "OOC_OP_SETTING must be the real string, not nil")

local function WithDeferredQueue(fn)
    local prev = GRIPEMS.OOCQueue
    local queued = {}
    GRIPEMS.OOCQueue = {
        IsRestricted = function()
            return true
        end,
        Add = function(_, opFn, opType, opName)
            queued[#queued + 1] = { fn = opFn, opType = opType, name = opName }
        end,
    }
    local ok, err = pcall(fn, queued)
    GRIPEMS.OOCQueue = prev
    if not ok then
        error(err, 0)
    end
end

local function CountOps(queued, opType)
    local n = 0
    for i = 1, #queued do
        if queued[i].opType == opType then
            n = n + 1
        end
    end
    return n
end

local function DrainOps(queued, opType)
    for i = 1, #queued do
        if queued[i].opType == opType then
            queued[i].fn()
        end
    end
end

test("C1 (combat): the in-place publish is QUEUED rather than dropped, and lands on drain", function()
    local btn = makeRecompileEntry(7, false, "Sequential")
    local entry = Engine.sequences["RC_Seq"]
    local ver = entry.data.versions[1]
    ver.holdOnChannel = true
    ver.releaseAtMax = true
    ver.resetTimer = 12
    WithDeferredQueue(function(queued)
        Engine:UpdateSequenceData("RC_Seq", entry.data)
        assertEqual(nil, btn._attrs.holdOnChannel, "C1: holdOnChannel is NOT published during combat")
        assertEqual(nil, btn._attrs.releaseAtMax, "C1: releaseAtMax is NOT published during combat")
        assertEqual(nil, btn._attrs.resetTimer, "C1: resetTimer is NOT published during combat")
        assertEqual(1, CountOps(queued, OP_SETTING), "C1: exactly one SETTING op was queued")
        DrainOps(queued, OP_SETTING)
        assertEqual("1", btn._attrs.holdOnChannel, "C1: holdOnChannel landed on drain")
        assertEqual("1", btn._attrs.releaseAtMax, "C1: releaseAtMax landed on drain")
        assertEqual(12, btn._attrs.resetTimer, "C1: resetTimer landed on drain")
    end)
end)

test("C2 (combat): the queued publish re-resolves at DRAIN time, so the LATER edit wins", function()
    local btn = makeRecompileEntry(7, false, "Sequential")
    local entry = Engine.sequences["RC_Seq"]
    local ver = entry.data.versions[1]
    ver.holdOnChannel = true
    ver.releaseAtMax = true
    ver.resetTimer = 3
    WithDeferredQueue(function(queued)
        Engine:UpdateSequenceData("RC_Seq", entry.data)
        assertEqual(1, CountOps(queued, OP_SETTING), "C2: exactly one SETTING op was queued")
        -- A second save inside the same combat, and it SWAPS THE TABLE rather than
        -- mutating the one already queued. That distinction is the whole case: a real
        -- editor save hands UpdateSequenceData a whole new seqData with new version
        -- tables, so a doPublish that captured the version would publish the orphaned
        -- queue-time table. Mutating the original in place would pass either way,
        -- because the captured reference and the re-resolved one would be the same
        -- object -- measured, not assumed: a capturing build stays green on that shape.
        local laterData = makeSequence("Sequential")
        laterData.versions[1].holdOnChannel = false
        laterData.versions[1].releaseAtMax = false
        laterData.versions[1].resetTimer = 25
        Engine.sequences["RC_Seq"].data = laterData
        DrainOps(queued, OP_SETTING)
        assertEqual(nil, btn._attrs.holdOnChannel, "C2: the LATER holdOnChannel (off) won")
        assertEqual(nil, btn._attrs.releaseAtMax, "C2: the LATER releaseAtMax (off) won")
        assertEqual(25, btn._attrs.resetTimer, "C2: the LATER resetTimer won, not the queue-time 3")
    end)
end)

-- ---------------------------------------------------------------------------
-- N1 and N2, THE REGISTRATION ITSELF (ENGINE-TOPLEVEL-CALLBACKS-NEVER-REGISTERED).
--
-- WHY EVERY CASE ABOVE MISSED IT. All fifty call the handler bodies directly.
-- That is the right way to test a body and it is structurally blind to whether
-- anything ever calls it. At fa38627 the two registration blocks at the bottom
-- of Engine.lua sat at COLUMN 0, tested a nil GRIPEMS.RegisterCallback and
-- registered NOTHING -- and this file printed 50 passed, 0 failed while five
-- heals and the whole macroResetModifiers republish were dead on every client,
-- the HealEmpowerReleases fix from the row above among them: correct code,
-- never once invoked. A green suite was not evidence and is still not evidence;
-- these two cases are the part that would have caught it.
--
-- THIS HARNESS ALREADY REPRODUCES THE REAL BOOT ORDER, which is what makes the
-- cases cheap. GRIPEMS.RegisterCallback is defined NOWHERE in the sandbox
-- above, so Engine/Engine.lua was loaded at L270 with the name absent -- exactly
-- the client, where Core builds the registry later, inside ADDON_LOADED. N1
-- asserts that precondition rather than assuming it: without it the case could
-- pass against a harness that handed Engine a registry at load time, and would
-- then prove nothing at all about the client.
--
-- The registry below is a CallbackHandler stand-in carrying the one property
-- under test: a handler registered with a FUNCTION REF is dispatched as
-- fn(eventname, ...) with NO self prepended. That is Dispatch(events[eventname],
-- eventname, ...) at Libs/CallbackHandler-1.0:54, and the registration comment
-- at :75, "self with function ref, leads to functionref(...)".
-- ---------------------------------------------------------------------------

local function WithRegistry(fn)
    local slots = {}
    local prevFire = GRIPEMS.Fire
    GRIPEMS.RegisterCallback = function(owner, event, method)
        slots[event] = slots[event] or {}
        slots[event][owner] = method
    end
    function GRIPEMS:Fire(event, ...) -- luacheck: no redefined
        for _, method in pairs(slots[event] or {}) do
            method(event, ...)
        end
    end
    local ok, err = pcall(fn)
    GRIPEMS.Fire = prevFire
    GRIPEMS.RegisterCallback = nil
    Engine._callbacksRegistered = nil
    if not ok then
        error(err, 0)
    end
end

test("N1 (registration): SPELL_CACHE_REFRESHED reaches Engine's handler after the ADDON_LOADED hookup", function()
    assertEqual(nil, GRIPEMS.RegisterCallback, "N1: Engine.lua was loaded with the registrar absent, as in the client")
    assertEqual("function", type(Engine.RegisterCallbacks), "N1: Engine exposes a RegisterCallbacks for Core to call")

    WithRegistry(function()
        -- All five arms the Backlog row names as dead, hooked to counters so the
        -- case is hermetic and so "reached" is asserted per arm, not in aggregate.
        local seen = { locale = 0, override = 0, vars = 0, brace = 0, empower = 0 }
        local prevLocale = Engine.HealLocaleSteps
        local prevOverride = Engine.HealOverrideSteps
        local prevBrace = Engine.RetryCappedBraceReloads
        local prevEmpower = Engine.HealEmpowerReleases
        local prevVS = GRIPEMS.VariableStore
        Engine.HealLocaleSteps = function()
            seen.locale = seen.locale + 1
        end
        Engine.HealOverrideSteps = function()
            seen.override = seen.override + 1
        end
        Engine.RetryCappedBraceReloads = function()
            seen.brace = seen.brace + 1
            return 0
        end
        Engine.HealEmpowerReleases = function()
            seen.empower = seen.empower + 1
            return 0
        end
        GRIPEMS.VariableStore = {
            HealLocaleVariables = function()
                seen.vars = seen.vars + 1
            end,
        }

        -- THE CONTROL, and it is the shipped client's whole history: fire before
        -- any hookup and nothing runs. Without this half, N1 could pass on a
        -- harness where the handler was somehow always live.
        GRIPEMS:Fire("SPELL_CACHE_REFRESHED")
        local beforeHookup = seen.locale + seen.override + seen.vars + seen.brace + seen.empower

        -- The ADDON_LOADED-equivalent hookup: the line Core.lua now carries.
        local registered = Engine:RegisterCallbacks()
        GRIPEMS:Fire("SPELL_CACHE_REFRESHED")
        -- Second call must be a no-op, or ADDON_LOADED firing twice would
        -- double-register and every heal would run twice per refresh.
        local reRegistered = Engine:RegisterCallbacks()

        Engine.HealLocaleSteps = prevLocale
        Engine.HealOverrideSteps = prevOverride
        Engine.RetryCappedBraceReloads = prevBrace
        Engine.HealEmpowerReleases = prevEmpower
        GRIPEMS.VariableStore = prevVS

        assertEqual(0, beforeHookup, "N1 (control): with nothing registered no arm runs -- the shipped behaviour")
        assertTrue(registered, "N1: the first RegisterCallbacks performed the registration")
        assertTrue(not reRegistered, "N1: a second RegisterCallbacks is a no-op, so ADDON_LOADED twice is safe")
        assertEqual(1, seen.locale, "N1: HealLocaleSteps reached exactly once")
        assertEqual(1, seen.override, "N1: HealOverrideSteps reached exactly once")
        assertEqual(1, seen.vars, "N1: VariableStore:HealLocaleVariables reached exactly once")
        assertEqual(1, seen.brace, "N1: RetryCappedBraceReloads reached exactly once")
        assertEqual(1, seen.empower, "N1: HealEmpowerReleases reached exactly once")
    end)
end)

-- N2 IS THE OTHER HALF OF THE SAME BUG, and it is why fixing the registration
-- alone would have shipped a block that registers and still does nothing. Every
-- producer fires Fire("SETTING_CHANGED", key, value) (Data/Settings.lua:229,
-- :257, :299), so a function-ref handler receives (event, key, value). This arm
-- carried function(_, _, key) and therefore compared the setting's VALUE against
-- "macroResetModifiers". The decoy below is the discriminating half: on the old
-- signature the two assertions come out exactly inverted, 0 and 1.
test("N2 (registration): SETTING_CHANGED reaches the republish on the KEY, not on the value", function()
    WithRegistry(function()
        local hits = 0
        local prevGet = GRIPEMS.Settings.GetResetModifiers
        local prevSeqs = Engine.sequences
        -- Isolated from whatever earlier cases left registered: this case is
        -- about which argument the handler reads, not about button fan-out.
        Engine.sequences = {}
        GRIPEMS.Settings.GetResetModifiers = function()
            hits = hits + 1
            return {}
        end

        Engine:RegisterCallbacks()
        GRIPEMS:Fire("SETTING_CHANGED", "macroResetModifiers", true)
        local onKey = hits
        GRIPEMS:Fire("SETTING_CHANGED", "someOtherSetting", "macroResetModifiers")
        local onValue = hits - onKey

        GRIPEMS.Settings.GetResetModifiers = prevGet
        Engine.sequences = prevSeqs

        assertEqual(1, onKey, "N2: the matching KEY reaches the republish")
        assertEqual(0, onValue, "N2: a decoy carrying the name in the VALUE slot does not")
    end)
end)

-- ---------------------------------------------------------------------------
-- O1 to O6 and S1-persist to S6-persist, STALE-OVERRIDE-STEP-TEXT.
--
-- Engine:HealOverrideSteps re-translates version.taggedSteps with
-- { useOverrides = true }, which reaches C_SpellBook.FindSpellOverrideByID.
-- That API answers for whatever override is LIVE at call time and does not
-- separate a durable talent override from a transient one driven by a
-- shapeshift form, a channel or a proc.
--
-- Through v2.4.3 the results were WRITTEN into version.steps / keyPress /
-- keyRelease, which are PERSISTED SavedVariables fields, so a heal landing
-- while a transient override was up stored a name the player could not cast
-- once it dropped. v2.4.2 answered that with a combat gate. The gate is not
-- enough and S3-persist below is why: a San'layn proc can still be up at
-- PLAYER_REGEN_ENABLED, which is exactly when the gate lets the heal through,
-- so the transient name was written on the combat-drop path anyway.
--
-- v2.4.4 removes the write instead of guarding it. The resolved name goes into
-- Engine._overrideDisplay, read back through Engine:GetOverrideDisplay, and
-- the persisted text keeps the DURABLE base name. WoW resolves /cast <base
-- name> through whatever override is live, so the base name is what casts;
-- measured on a live Guardian Druid 2026-08-17, Maul 6807 is castable while
-- Ravage 441583 resolves to an ID but not to a castable name
-- (Research/Override_Name_Castability_Probe_2026-08-17.md).
--
-- NOTE THE GUARD THAT IS DELIBERATELY ABSENT. The fix proposed on the thread
-- keyed on C_Spell.DoesSpellExist(name) == false. The same probe falsified it:
-- Lunar Beam and Incarnation both measured false on a character that casts
-- them, because the NAME form of that call answers a question about the
-- current build rather than about the spell. Keying a write on it would rewrite
-- working steps. No case below asserts anything about that predicate because
-- no code below consults it.
--
-- What each case pins:
--   O1  the combat gate still short-circuits (kept, now for cost not safety)
--   O2  the SAME fixture still RESOLVES out of combat, so O1 cannot pass by the
--       feature being dead -- but resolves into the display, not the store
--   O3  a live override appears in the display and really leaves it on revert
--   O4  the debounce collapses a burst of form events into one walk
--   O5  the real OnEvent handler reaches ScheduleOverrideHeal on all three
--   O6  UPDATE_SHAPESHIFT_FORM is really registered
--   S1-persist  a proc-up heal leaves version.steps byte-identical
--   S2-persist  ... and puts the override name in the display table instead
--   S3-persist  the combat-drop path with a STILL-LIVE proc writes nothing
--               (the San'layn case the v2.4.2 combat gate missed)
--   S4-persist  RepairPersistedOverrideNames restores a base name from a base tag
--   S5-persist  ... and leaves a poisoned TAG alone rather than guessing
--   S6-persist  ... and runs exactly once across two invocations
--
-- The S-persist names carry the suffix because this file already has an
-- unrelated S1 to S7 block (empower-release recompile). Same runner, distinct
-- names, no collision in the PASS/FAIL output.
--
-- STUB AUDIT, in the form the E-block above keeps.
--
--   installOverrideCache  the E-block's installSpellCache with ONE method
--                         swapped: a TranslateMacrotext that really resolves
--                         "TAG:<id>" through an override table rather than
--                         returning a fixed prefix, so these cases assert a
--                         NAME. LIVE: SC:TranslateSpellRef ->
--                         C_SpellBook.FindSpellOverrideByID. DIFFERS -- no real
--                         spell is resolved -- so no case here asserts a
--                         translation is CORRECT, only which name the walk
--                         produced and WHERE it put it, which is exactly what
--                         the defect was about.
--   env._headlessInCombat the flag env.InCombatLockdown reads, set at the top of
--                         the sandbox. LIVE: the client's combat lockdown.
--                         MATCHES in type (boolean).
--   env.C_Timer           O4 and S3-persist: a NewTimer that hands back a
--                         cancellable handle and holds the callback instead of
--                         running it, so the burst is observable without real
--                         time passing. Removed after, so every other case sees
--                         the catch-all again.
--   Engine.RecompileSequence  counted in O1 to O3 and the S-persist cases. The
--                         real one is exercised by the empower S-block above;
--                         here the OBSERVABLE is whether the walk decided
--                         anything changed, and a counter says so without
--                         dragging button fan-out into a persistence case.
-- ---------------------------------------------------------------------------

local OVERRIDE_NAMES = { [100] = "BaseSpell", [200] = "VariantSpell" }

--- installSpellCache with an override-aware translator. The override table is
--- read through a GETTER, not captured: O3 swaps the whole table between passes
--- and a harness that held the first one would answer from it forever.
local function installOverrideCache(getOverrides)
    local seen = installSpellCache()
    GRIPEMS.SpellCache.TranslateMacrotext = function(_, text, _, opts)
        local id = tonumber(tostring(text):match("^TAG:(%d+)$"))
        if not id then
            return tostring(text)
        end
        if opts and opts.useOverrides then
            id = (getOverrides() or {})[id] or id
        end
        return "/cast " .. (OVERRIDE_NAMES[id] or ("spell:" .. tostring(id)))
    end
    return seen
end

--- A one-sequence store in the shape HealOverrideSteps walks, rawset into the
--- sandbox as GRIP_EMS_CHAR. Returns the version table so the case can read
--- version.steps back after the call. Paired with clearOverrideStore().
--- Pass `fields` to override any of the version's keys -- the S-persist repair
--- cases need a POISONED steps array (an override name already stored) and, for
--- S5-persist, a poisoned TAG as well.
local function installOverrideStore(name, fields)
    local ver = {
        stepFunction = "Sequential",
        steps = { "/cast BaseSpell" },
        taggedSteps = { "TAG:100" },
        keyPress = "",
        keyRelease = "",
    }
    for k, v in pairs(fields or {}) do
        ver[k] = v
    end
    rawset(env, "GRIP_EMS_CHAR", {
        sequences = { [name] = { name = name, defaultVersion = 1, versions = { ver } } },
    })
    return ver
end

--- Snapshot the three PERSISTED fields as one comparable string. Lua compares
--- strings by value, so an equality on this IS the byte-identity check the
--- S-persist cases are named for -- and it covers all three fields at once, so
--- a build that stopped writing steps but kept writing keyPress cannot pass.
local function persistedSnapshot(ver)
    return table.concat(ver.steps or {}, "\1") .. "\2" .. tostring(ver.keyPress) .. "\2" .. tostring(ver.keyRelease)
end

local function clearOverrideStore()
    rawset(env, "GRIP_EMS_CHAR", nil)
    rawset(env, "_headlessInCombat", nil)
    -- The display table survives a call by design (the revert case reads the
    -- previous walk to decide dirty), so every case starts from a clean one.
    Engine._overrideDisplay = nil
    removeSpellCache()
end

test("O1 (combat): HealOverrideSteps resolves NOTHING while in combat", function()
    installOverrideCache(function()
        return { [100] = 200 }
    end)
    local ver = installOverrideStore("O1_Seq")
    local before = ver.steps[1]
    local recompiled = 0
    local prevRecompile = Engine.RecompileSequence
    Engine.RecompileSequence = function()
        recompiled = recompiled + 1
    end
    rawset(env, "_headlessInCombat", true)

    local ok, err = pcall(Engine.HealOverrideSteps, Engine)
    local display = Engine:GetOverrideDisplay("O1_Seq", 1)

    Engine.RecompileSequence = prevRecompile
    clearOverrideStore()

    assertTrue(ok, "O1: HealOverrideSteps raised in combat: " .. tostring(err))
    -- Strings are compared by value in Lua, so this IS the byte-identical check.
    assertEqual(before, ver.steps[1], "O1: the persisted step text is byte-identical after an in-combat heal")
    assertEqual("/cast BaseSpell", ver.steps[1], "O1: and it is still the BASE name, not the transient variant")
    assertEqual(nil, display, "O1: the walk returned before recording any display entry")
    assertEqual(0, recompiled, "O1: nothing was recompiled either")
end)

test("O2 (out of combat): the SAME fixture still resolves, so O1 cannot pass by the feature being dead", function()
    installOverrideCache(function()
        return { [100] = 200 }
    end)
    local ver = installOverrideStore("O2_Seq")
    local recompiled = 0
    local prevRecompile = Engine.RecompileSequence
    Engine.RecompileSequence = function()
        recompiled = recompiled + 1
    end
    rawset(env, "_headlessInCombat", false)

    local ok, err = pcall(Engine.HealOverrideSteps, Engine)
    local display = Engine:GetOverrideDisplay("O2_Seq", 1)

    Engine.RecompileSequence = prevRecompile
    clearOverrideStore()

    assertTrue(ok, "O2: HealOverrideSteps raised out of combat: " .. tostring(err))
    -- INVERTED at v2.4.4. This used to assert version.steps[1] had BECOME the
    -- variant name. The variant name is now a display string and the persisted
    -- text is the durable base name, which is the whole point of the fix.
    assertEqual("/cast BaseSpell", ver.steps[1], "O2: the persisted step is UNTOUCHED and still the base name")
    assertTrue(display ~= nil, "O2: a display entry was recorded for the version")
    assertEqual("/cast VariantSpell", display.steps[1], "O2: and it carries the resolved override name")
    assertEqual(
        "/cast BaseSpell",
        display.sourceSteps[1],
        "O2: alongside the persisted text it stands in for, so the draw path can tell an edited row apart"
    )
    assertEqual(1, recompiled, "O2: the changed display recompiled the sequence exactly once")
end)

test("O3 (the revert): a live override reaches the display, then really leaves it again", function()
    local overrides = { [100] = 200 }
    installOverrideCache(function()
        return overrides
    end)
    local ver = installOverrideStore("O3_Seq")
    local snapshot = persistedSnapshot(ver)
    local prevRecompile = Engine.RecompileSequence
    Engine.RecompileSequence = function() end
    rawset(env, "_headlessInCombat", false)

    local ok1, err1 = pcall(Engine.HealOverrideSteps, Engine)
    -- pcall the READ, so a build without the accessor fails on the persistence
    -- claim below rather than aborting here. The assertions still require a
    -- real entry, so this cannot pass on a build that lost the accessor.
    local okD1, afterOverride = pcall(Engine.GetOverrideDisplay, Engine, "O3_Seq", 1)
    local displayedOverride = (okD1 and afterOverride) and afterOverride.steps[1] or nil

    -- SWAP the whole table rather than mutating it in place. A build that read
    -- the override state once and cached it would still answer 200 out of the
    -- first table and would stay green under in-place mutation; it cannot
    -- survive the swap.
    overrides = { [100] = 100 }
    local ok2, err2 = pcall(Engine.HealOverrideSteps, Engine)
    local okD2, afterRevert = pcall(Engine.GetOverrideDisplay, Engine, "O3_Seq", 1)
    if not okD2 then
        afterRevert = nil
    end
    local snapshotAfter = persistedSnapshot(ver)

    Engine.RecompileSequence = prevRecompile
    clearOverrideStore()

    assertTrue(ok1, "O3 pass 1 raised: " .. tostring(err1))
    assertTrue(ok2, "O3 pass 2 raised: " .. tostring(err2))
    assertEqual("/cast VariantSpell", displayedOverride, "O3 pass 1: the live override is recorded in the display")
    assertEqual(
        nil,
        afterRevert,
        "O3 pass 2: the entry is GONE once the override reverts, so the draw path falls back to the base name"
    )
    assertEqual(snapshot, snapshotAfter, "O3: the persisted fields are byte-identical across BOTH passes")
end)

test("O4 (debounce): five ScheduleOverrideHeal calls collapse into ONE heal", function()
    local pending, cancelled, healed, lastDelay = nil, 0, 0, nil
    rawset(env, "C_Timer", {
        NewTimer = function(delay, fn)
            lastDelay = delay
            local timer = { _fn = fn }
            function timer:Cancel()
                cancelled = cancelled + 1
                self._cancelled = true
            end
            pending = timer
            return timer
        end,
    })
    local prevHeal = Engine.HealOverrideSteps
    Engine.HealOverrideSteps = function()
        healed = healed + 1
    end
    Engine._overrideHealTimer = nil

    for _ = 1, 5 do
        Engine:ScheduleOverrideHeal()
    end
    local beforeFire = healed
    local hasPending = pending ~= nil
    if hasPending then
        pending._fn()
    end
    local clearedAfterFire = Engine._overrideHealTimer

    Engine.HealOverrideSteps = prevHeal
    Engine._overrideHealTimer = nil
    rawset(env, "C_Timer", nil)

    assertTrue(hasPending, "O4: a timer is pending after the burst")
    assertEqual(0, beforeFire, "O4: nothing ran while the timer was still pending")
    assertEqual(4, cancelled, "O4: the four superseded timers were cancelled")
    assertEqual(1, healed, "O4: the burst of five produced exactly one heal")
    assertEqual(GRIPEMS.Defaults.OVERRIDE_HEAL_DEBOUNCE, lastDelay, "O4: the debounce constant is what was scheduled")
    assertEqual(nil, clearedAfterFire, "O4: the handle is cleared when the timer fires, so the next burst starts clean")
end)

test("O5 (wiring): the REAL OnEvent handler reaches ScheduleOverrideHeal on all three events", function()
    -- A green suite that only drives function BODIES cannot tell a wired
    -- feature from a dead one -- the lesson N1 and N2 above are named for.
    local handler = engineScripts.OnEvent
    assertEqual("function", type(handler), "O5: the real OnEvent handler was captured off the engine frame")

    local events = { "PLAYER_REGEN_ENABLED", "UPDATE_OVERRIDE_ACTIONBAR", "UPDATE_SHAPESHIFT_FORM" }
    local reached = 0
    local prevSchedule = Engine.ScheduleOverrideHeal
    local prevSeqs = Engine.sequences
    local prevLoad = Engine._initialLoadComplete
    Engine.ScheduleOverrideHeal = function()
        reached = reached + 1
    end
    -- The bar-swap arm returns early without this, so two of the three would
    -- pass vacuously and the case would prove only the regen arm.
    Engine._initialLoadComplete = true
    Engine.sequences = {}

    local results = {}
    for i = 1, #events do
        local n = reached
        local ok, err = pcall(handler, nil, events[i])
        results[i] = { ok = ok, err = err, delta = reached - n }
    end

    Engine.ScheduleOverrideHeal = prevSchedule
    Engine.sequences = prevSeqs
    Engine._initialLoadComplete = prevLoad

    for i = 1, #events do
        assertTrue(results[i].ok, "O5: the handler raised on " .. events[i] .. ": " .. tostring(results[i].err))
        assertEqual(1, results[i].delta, "O5: " .. events[i] .. " reached ScheduleOverrideHeal exactly once")
    end
end)

test("O6 (registration): UPDATE_SHAPESHIFT_FORM is in the engine frame's registered set", function()
    assertTrue(engineEvents["UPDATE_SHAPESHIFT_FORM"], "O6: UPDATE_SHAPESHIFT_FORM was registered at file load")
    -- CONTROLS: a neighbour that was always registered, and a name that never
    -- was, so the assertion above cannot be passing against a recorder that
    -- answers true for every key.
    assertTrue(
        engineEvents["UPDATE_OVERRIDE_ACTIONBAR"],
        "O6 (control): the pre-existing bar-swap event is still there"
    )
    assertTrue(not engineEvents["UPDATE_SHAPESHIFT_FORM_NOT_AN_EVENT"], "O6 (control): an unregistered name is absent")
end)

test("O7 (no timer): ScheduleOverrideHeal falls back to a DIRECT heal when C_Timer is unavailable", function()
    -- The second call shape inside ScheduleOverrideHeal. O4 covers the timer
    -- arm; this is the one taken when C_Timer or C_Timer.NewTimer is missing,
    -- which the sandbox catch-all otherwise hides by answering truthy for both.
    local healed = 0
    local prevHeal = Engine.HealOverrideSteps
    Engine.HealOverrideSteps = function()
        healed = healed + 1
    end
    Engine._overrideHealTimer = nil
    -- A table with no NewTimer: the guard reads `not C_Timer.NewTimer`.
    rawset(env, "C_Timer", {})

    local ok, err = pcall(Engine.ScheduleOverrideHeal, Engine)
    local direct = healed
    local leftPending = Engine._overrideHealTimer

    rawset(env, "C_Timer", nil)
    Engine.HealOverrideSteps = prevHeal
    Engine._overrideHealTimer = nil

    assertTrue(ok, "O7: ScheduleOverrideHeal raised without a timer: " .. tostring(err))
    assertEqual(1, direct, "O7: the heal ran inline exactly once instead of being dropped")
    assertEqual(nil, leftPending, "O7: and no timer handle was left behind")
end)

test("O8 (durable arms): the REAL OnEvent handler reaches HealOverrideSteps on the two talent events", function()
    -- The two DIRECT call sites, distinct from the three debounced ones O5
    -- covers. These are the durable talent events, and they were the only
    -- triggers before v2.4.0 -- they must keep reaching the walk.
    local handler = engineScripts.OnEvent
    assertEqual("function", type(handler), "O8: the real OnEvent handler was captured off the engine frame")

    local reached = 0
    local prevHeal = Engine.HealOverrideSteps
    local prevSeqs = Engine.sequences
    local prevLoadout = Engine.currentLoadoutID
    local prevUpdate = Engine.UpdateLoadout
    -- The spec arm reloads keybinds above the heal. GRIPEMS.KeybindManager is
    -- an empty table in this sandbox, so the call is reached and raises; a
    -- scoped no-op keeps the arm running to the line under test without
    -- changing what any other case sees.
    local prevSchedLoad = GRIPEMS.KeybindManager.ScheduleLoadKeybinds
    GRIPEMS.KeybindManager.ScheduleLoadKeybinds = function() end
    Engine.HealOverrideSteps = function()
        reached = reached + 1
    end
    Engine.sequences = {}
    Engine.UpdateLoadout = function() end
    -- The trait arm only proceeds when the payload names the active or the
    -- last-observed loadout; C_ClassTalents is the sandbox catch-all here, so
    -- the currentLoadoutID half is the reachable one.
    Engine.currentLoadoutID = 4242

    local specBefore = reached
    local okSpec, errSpec = pcall(handler, nil, "PLAYER_SPECIALIZATION_CHANGED", "player")
    local specDelta = reached - specBefore

    -- CONTROL: another unit's spec change must NOT reach the walk.
    local otherBefore = reached
    local okOther, errOther = pcall(handler, nil, "PLAYER_SPECIALIZATION_CHANGED", "party1")
    local otherDelta = reached - otherBefore

    local traitBefore = reached
    local okTrait, errTrait = pcall(handler, nil, "TRAIT_CONFIG_UPDATED", 4242)
    local traitDelta = reached - traitBefore

    Engine.HealOverrideSteps = prevHeal
    Engine.sequences = prevSeqs
    Engine.currentLoadoutID = prevLoadout
    Engine.UpdateLoadout = prevUpdate
    GRIPEMS.KeybindManager.ScheduleLoadKeybinds = prevSchedLoad

    assertTrue(okSpec, "O8: the handler raised on PLAYER_SPECIALIZATION_CHANGED: " .. tostring(errSpec))
    assertEqual(1, specDelta, "O8: PLAYER_SPECIALIZATION_CHANGED reached HealOverrideSteps exactly once")
    assertTrue(okOther, "O8: the handler raised on a party spec change: " .. tostring(errOther))
    assertEqual(0, otherDelta, "O8 (control): another unit's spec change reaches nothing")
    assertTrue(okTrait, "O8: the handler raised on TRAIT_CONFIG_UPDATED: " .. tostring(errTrait))
    assertEqual(1, traitDelta, "O8: TRAIT_CONFIG_UPDATED reached HealOverrideSteps exactly once")
end)

test("S1-persist (proc up): a heal with a live override leaves version.steps byte-identical", function()
    installOverrideCache(function()
        return { [100] = 200 }
    end)
    local ver = installOverrideStore("S1p_Seq", {
        keyPress = "/cast BaseSpell",
        taggedKeyPress = "TAG:100",
        keyRelease = "/cast BaseSpell",
        taggedKeyRelease = "TAG:100",
    })
    local snapshot = persistedSnapshot(ver)
    local prevRecompile = Engine.RecompileSequence
    Engine.RecompileSequence = function() end
    rawset(env, "_headlessInCombat", false)

    local ok, err = pcall(Engine.HealOverrideSteps, Engine)
    local snapshotAfter = persistedSnapshot(ver)

    Engine.RecompileSequence = prevRecompile
    clearOverrideStore()

    assertTrue(ok, "S1-persist: HealOverrideSteps raised: " .. tostring(err))
    -- All three persisted fields at once. A build that stopped writing steps
    -- but kept writing keyPress or keyRelease fails here, not silently.
    assertEqual(snapshot, snapshotAfter, "S1-persist: steps, keyPress and keyRelease are ALL byte-identical")
    assertEqual("/cast BaseSpell", ver.steps[1], "S1-persist: the stored step is still the durable base name")
    assertEqual("/cast BaseSpell", ver.keyPress, "S1-persist: so is keyPress")
    assertEqual("/cast BaseSpell", ver.keyRelease, "S1-persist: so is keyRelease")
end)

test("S2-persist (proc up): the same heal puts the override name in the DISPLAY table", function()
    installOverrideCache(function()
        return { [100] = 200 }
    end)
    installOverrideStore("S2p_Seq", {
        keyPress = "/cast BaseSpell",
        taggedKeyPress = "TAG:100",
        keyRelease = "/cast BaseSpell",
        taggedKeyRelease = "TAG:100",
    })
    local prevRecompile = Engine.RecompileSequence
    Engine.RecompileSequence = function() end
    rawset(env, "_headlessInCombat", false)

    local ok, err = pcall(Engine.HealOverrideSteps, Engine)
    local entry = Engine:GetOverrideDisplay("S2p_Seq", 1)
    -- The accessor must absorb every miss rather than raising: it runs once per
    -- drawn row, ahead of any check the caller could make.
    local missSeq = Engine:GetOverrideDisplay("S2p_NoSuchSequence", 1)
    local missVer = Engine:GetOverrideDisplay("S2p_Seq", 9)
    local missName = Engine:GetOverrideDisplay(nil, 1)
    local missIndex = Engine:GetOverrideDisplay("S2p_Seq", nil)

    Engine.RecompileSequence = prevRecompile
    clearOverrideStore()

    assertTrue(ok, "S2-persist: HealOverrideSteps raised: " .. tostring(err))
    assertTrue(entry ~= nil, "S2-persist: an entry exists for the healed version")
    assertEqual("/cast VariantSpell", entry.steps[1], "S2-persist: the step slot carries the resolved override name")
    assertEqual("/cast VariantSpell", entry.keyPress, "S2-persist: keyPress carries it too")
    assertEqual("/cast VariantSpell", entry.keyRelease, "S2-persist: and keyRelease")
    assertEqual("/cast BaseSpell", entry.sourceSteps[1], "S2-persist: the persisted text it stands in for is recorded")
    assertEqual(nil, missSeq, "S2-persist: an unknown sequence name returns nil")
    assertEqual(nil, missVer, "S2-persist: an out-of-range version returns nil")
    assertEqual(nil, missName, "S2-persist: a nil sequence name returns nil")
    assertEqual(nil, missIndex, "S2-persist: a nil version index returns nil")
end)

test("S3-persist (combat drop, proc STILL up): the real regen path writes nothing -- the San'layn case", function()
    -- THE CASE THE v2.4.2 GUARD MISSED. That fix gated the heal on
    -- InCombatLockdown and re-scheduled it from PLAYER_REGEN_ENABLED. A
    -- San'layn proc does not necessarily end when combat does, so the
    -- rescheduled heal ran with the transient override STILL live and wrote it
    -- -- the gate moved the write, it did not remove it. Driven through the
    -- REAL OnEvent handler and the REAL debounce timer, not by calling the heal
    -- directly, because the reschedule is the path that carried the defect.
    installOverrideCache(function()
        return { [100] = 200 }
    end)
    local ver = installOverrideStore("S3p_Seq")
    local snapshot = persistedSnapshot(ver)
    local prevRecompile = Engine.RecompileSequence
    Engine.RecompileSequence = function() end
    local prevSeqs = Engine.sequences
    Engine.sequences = {}
    Engine._overrideHealTimer = nil

    local pending
    rawset(env, "C_Timer", {
        NewTimer = function(_, fn)
            pending = { _fn = fn }
            function pending:Cancel() end
            return pending
        end,
    })
    -- Combat has just dropped. The proc has NOT.
    rawset(env, "_headlessInCombat", false)

    local handler = engineScripts.OnEvent
    local okEvent, errEvent = pcall(handler, nil, "PLAYER_REGEN_ENABLED")
    local scheduled = pending ~= nil
    local okFire, errFire = true, nil
    if scheduled then
        okFire, errFire = pcall(pending._fn)
    end
    local snapshotAfter = persistedSnapshot(ver)
    -- pcall the READ so a build without the accessor fails on the PERSISTENCE
    -- claim -- the regression this case exists for -- rather than aborting on a
    -- nil method. The assertions below still require a real entry.
    local okDisplay, entry = pcall(Engine.GetOverrideDisplay, Engine, "S3p_Seq", 1)
    if not okDisplay then
        entry = nil
    end

    rawset(env, "C_Timer", nil)
    Engine._overrideHealTimer = nil
    Engine.sequences = prevSeqs
    Engine.RecompileSequence = prevRecompile
    clearOverrideStore()

    assertTrue(okEvent, "S3-persist: the regen handler raised: " .. tostring(errEvent))
    assertTrue(scheduled, "S3-persist: leaving combat really scheduled a heal (the path under test is live)")
    assertTrue(okFire, "S3-persist: the debounced heal raised: " .. tostring(errFire))
    assertEqual(snapshot, snapshotAfter, "S3-persist: the persisted fields survived the combat-drop heal unchanged")
    assertEqual("/cast BaseSpell", ver.steps[1], "S3-persist: still the castable base name, not the proc name")
    -- And the resolution DID happen -- otherwise this case would pass on a
    -- build where the whole reschedule chain is dead.
    assertTrue(entry ~= nil, "S3-persist: the heal really ran and recorded a display entry")
    assertEqual("/cast VariantSpell", entry.steps[1], "S3-persist: the proc name went to the display, not the store")
end)

test("S4-persist (repair): RepairPersistedOverrideNames restores a base name from a base tag", function()
    installOverrideCache(function()
        return { [100] = 200 }
    end)
    -- Already poisoned, exactly as the pre-v2.4.4 writer left it: the NAME is
    -- the override, the TAG is still the base id.
    local ver = installOverrideStore("S4p_Seq", {
        steps = { "/cast VariantSpell" },
        taggedSteps = { "TAG:100" },
        keyPress = "/cast VariantSpell",
        taggedKeyPress = "TAG:100",
        keyRelease = "/cast VariantSpell",
        taggedKeyRelease = "TAG:100",
    })
    local recompiled = 0
    local prevRecompile = Engine.RecompileSequence
    Engine.RecompileSequence = function()
        recompiled = recompiled + 1
    end
    local prevSeqs = Engine.sequences
    Engine.sequences = { S4p_Seq = { data = {} } }

    local ok, repaired = pcall(Engine.RepairPersistedOverrideNames, Engine)
    local flag = rawget(env, "GRIP_EMS_CHAR") and rawget(env, "GRIP_EMS_CHAR").overrideNameRepairV1

    Engine.sequences = prevSeqs
    Engine.RecompileSequence = prevRecompile
    clearOverrideStore()

    assertTrue(ok, "S4-persist: RepairPersistedOverrideNames raised: " .. tostring(repaired))
    assertEqual(1, repaired, "S4-persist: exactly one version was repaired")
    assertEqual("/cast BaseSpell", ver.steps[1], "S4-persist: the poisoned step name is back to the base name")
    assertEqual("/cast BaseSpell", ver.keyPress, "S4-persist: keyPress too")
    assertEqual("/cast BaseSpell", ver.keyRelease, "S4-persist: and keyRelease")
    assertEqual("TAG:100", ver.taggedSteps[1], "S4-persist: the tag itself is NOT rewritten")
    assertEqual(true, flag, "S4-persist: the per-character gate was stamped")
    -- The button was compiled from the poisoned text, so a repair that never
    -- reaches it leaves the dead macro live until something else recompiles.
    assertEqual(1, recompiled, "S4-persist: the registered sequence was recompiled so the repair reaches the button")
end)

test("S5-persist (repair): a poisoned TAG is left alone rather than guessing, and does not raise", function()
    installOverrideCache(function()
        return { [100] = 200 }
    end)
    -- The unrepairable shape: the TAG itself is the override id. Re-deriving
    -- from it lands on the override name again, so the honest answer is to
    -- change nothing. See EMS-OVERRIDE-BASE-MAP-OFFLINE.
    local poisoned = installOverrideStore("S5p_PoisonedTag", {
        steps = { "/cast VariantSpell" },
        taggedSteps = { "TAG:200" },
    })
    -- CONTROL, in the SAME store: a neighbour whose tag is still the base id.
    -- Without it this case would stay green on a build where the repair walk
    -- does nothing at all for anyone.
    local repairable = {
        stepFunction = "Sequential",
        steps = { "/cast VariantSpell" },
        taggedSteps = { "TAG:100" },
        keyPress = "",
        keyRelease = "",
    }
    rawget(env, "GRIP_EMS_CHAR").sequences["S5p_Repairable"] =
        { name = "S5p_Repairable", defaultVersion = 1, versions = { repairable } }
    local prevRecompile = Engine.RecompileSequence
    Engine.RecompileSequence = function() end

    local ok, repaired = pcall(Engine.RepairPersistedOverrideNames, Engine)

    Engine.RecompileSequence = prevRecompile
    clearOverrideStore()

    assertTrue(ok, "S5-persist: RepairPersistedOverrideNames raised on a poisoned tag: " .. tostring(repaired))
    assertEqual(
        "/cast VariantSpell",
        poisoned.steps[1],
        "S5-persist: the poisoned-tag row is untouched -- no wrong name was emitted"
    )
    assertEqual("TAG:200", poisoned.taggedSteps[1], "S5-persist: and its tag is untouched too")
    assertEqual("/cast BaseSpell", repairable.steps[1], "S5-persist (control): the base-tag neighbour WAS repaired")
    assertEqual(1, repaired, "S5-persist: the count reflects the one repairable version, not both")
end)

test("S6-persist (repair): the migration runs exactly once across two invocations", function()
    installOverrideCache(function()
        return { [100] = 200 }
    end)
    local ver = installOverrideStore("S6p_Seq", {
        steps = { "/cast VariantSpell" },
        taggedSteps = { "TAG:100" },
    })
    local prevRecompile = Engine.RecompileSequence
    Engine.RecompileSequence = function() end

    local ok1, first = pcall(Engine.RepairPersistedOverrideNames, Engine)
    local afterFirst = ver.steps[1]
    -- RE-POISON between the calls. A build whose gate does not hold would
    -- repair this a second time; a build that merely happens to be idempotent
    -- would not be distinguished by calling it twice on clean data.
    ver.steps[1] = "/cast VariantSpell"
    local ok2, second = pcall(Engine.RepairPersistedOverrideNames, Engine)
    local afterSecond = ver.steps[1]

    Engine.RecompileSequence = prevRecompile
    clearOverrideStore()

    assertTrue(ok1, "S6-persist: pass 1 raised: " .. tostring(first))
    assertTrue(ok2, "S6-persist: pass 2 raised: " .. tostring(second))
    assertEqual(1, first, "S6-persist: pass 1 repaired the version")
    assertEqual("/cast BaseSpell", afterFirst, "S6-persist: pass 1 really wrote the base name")
    assertEqual(0, second, "S6-persist: pass 2 repaired nothing -- the gate held")
    assertEqual("/cast VariantSpell", afterSecond, "S6-persist: and the re-poisoned text was left exactly as found")
end)

-- ---------------------------------------------------------------------------
-- S7-persist to S9-persist, the POISONED TAG half.
--
-- S4/S5 above cover a poisoned NAME whose TAG is still the base id, which the
-- plain re-derive always recovers. These three cover the other shape: the TAG
-- itself is the override's own id.
--
-- The earlier build left EVERY poisoned tag alone, on the stated reason that
-- "the replacement chain does not exist for a proc override". That reason is
-- FALSIFIED. Measured on a live Guardian Druid (Sataanoir, 12.1.0.69299) with
-- C_SpellBook.FindBaseSpellByID:
--
--     441583  Ravage  ->  441583   no recovery
--     400254  Raze    ->    6807   RECOVERS to Maul
--       6807  Maul    ->    6807   identity, the unpoisoned control
--
-- Ravage and Raze are BOTH talent overrides of Maul and NEITHER was talented at
-- measurement time, so the discriminator is not proc versus talent and not
-- whether the override is live. It is whether the spell's own data carries a
-- base link. The fixtures below are those three ids and those three answers.
--
-- STUB AUDIT, additions only; the O-block audit above still describes the rest.
--   installTagCache      a translator that resolves the REAL "{spell:N}" tag
--                        form, because that is the pattern
--                        Engine:_RecoverPoisonedTagName matches. The TAG:<id>
--                        shape the O-block uses would never match it, so these
--                        cases would pass vacuously on that stub. LIVE:
--                        SC:TranslateMacrotext -> TranslateSpellRef. DIFFERS --
--                        no real spell is resolved -- so nothing here asserts a
--                        translation is CORRECT, only which id was looked up.
--                        Also supplies IsValidSpellID, which the recovery
--                        bounds-checks through.
--   env.C_SpellBook      rawset per case with the measured BASE_LINKS table.
--                        REQUIRED, not cosmetic: the sandbox catch-all answers
--                        C_SpellBook.FindBaseSpellByID with a TABLE, so the
--                        function's own type check rejects it and no recovery
--                        runs. The default sandbox state is therefore
--                        "no recovery", and S9-persist relies on exactly that.
-- ---------------------------------------------------------------------------

-- The measured rows. BASE_LINKS is what FindBaseSpellByID answered.
--
-- 999001 is SYNTHETIC and is labelled as such wherever it is used. It stands for
-- the class "no base link from the API and no row in D.BASE_SPELL_TABLE", which
-- is a real class that must stay unrepaired; it is not a claim about any real
-- spell. Ravage 441583 used to play that part and no longer can, because Phase 4
-- added a measured table row for it and moved it into the repairable set.
local TAG_SPELL_NAMES = {
    [6807] = "Maul",
    [400254] = "Raze",
    [441583] = "Ravage",
    [999001] = "SyntheticOrphan",
}
local TAG_BASE_LINKS = { [6807] = 6807, [400254] = 6807, [441583] = 441583, [999001] = 999001 }

-- The SHIPPED D.BASE_SPELL_TABLE, pulled out of the real Data/Defaults.lua into
-- a throwaway namespace so only that one field crosses over. S10 then asserts
-- against the table the addon actually ships rather than against a fixture copy
-- of it, which is the difference between testing the data and restating it. The
-- rest of the harness Defaults table is left exactly as it was, so no other case
-- is disturbed. A load failure leaves this empty and S10 fails loudly.
local SHIPPED_BASE_SPELL_TABLE = {}
do
    local probe = {}
    -- loadfile is dev-harness file I/O, intentionally outside the addon WoW std.
    -- selene: allow(undefined_variable)
    local chunk = loadfile("Data/Defaults.lua")
        -- selene: allow(undefined_variable)
        or loadfile("../Data/Defaults.lua")
        -- selene: allow(undefined_variable)
        or loadfile("GRIP/EMS/Data/Defaults.lua")
    if chunk then
        setfenv(chunk, env)
        pcall(chunk, ADDON_NAME, probe)
        if type(probe.Defaults) == "table" and type(probe.Defaults.BASE_SPELL_TABLE) == "table" then
            SHIPPED_BASE_SPELL_TABLE = probe.Defaults.BASE_SPELL_TABLE
        end
    end
end

--- installSpellCache with a translator that resolves "{spell:N}" tokens, the
--- form the recovery actually pattern-matches, plus the GetBaseSpellID the
--- recovery now delegates to.
local function installTagCache()
    local seen = installSpellCache()
    GRIPEMS.SpellCache.IsValidSpellID = function(_, id)
        return type(id) == "number" and id > 0 and id <= 2147483647
    end
    -- The contract SC:GetBaseSpellID owns: API first, an IDENTITY answer counts
    -- as a miss, then the table. Fed by the SHIPPED table, so what it returns
    -- for 441583 is decided by Data/Defaults.lua and not by this file.
    --
    -- This is not a tautological mirror of the code under test. The Engine used
    -- to call C_SpellBook.FindBaseSpellByID inline, and that API still answers
    -- 441583 -> 441583 in these fixtures. So a build that did NOT delegate gets
    -- identity and recovers nothing, while a build that delegates gets 6807 from
    -- the table. The two answers differ, which is exactly what S10 reads.
    -- The REAL SC:GetBaseSpellID is driven separately, against the real module,
    -- in Test/test_spellcache_overrides.lua.
    GRIPEMS.SpellCache.GetBaseSpellID = function(_, id)
        if type(id) ~= "number" then
            return id
        end
        local api = rawget(env, "C_SpellBook")
        local baseID = nil
        if type(api) == "table" and type(api.FindBaseSpellByID) == "function" then
            baseID = api.FindBaseSpellByID(id)
        end
        if baseID and baseID ~= id then
            return baseID
        end
        return SHIPPED_BASE_SPELL_TABLE[id] or baseID or id
    end
    GRIPEMS.SpellCache.TranslateMacrotext = function(_, text, _, _)
        local out = tostring(text):gsub("{spell:(%d+)}", function(digits)
            local id = tonumber(digits)
            return TAG_SPELL_NAMES[id] or ("spell:" .. tostring(digits))
        end)
        return out
    end
    return seen
end

--- Install the measured FindBaseSpellByID. Pass false to install a C_SpellBook
--- that does NOT carry the function, which is the S9-persist world.
local function installBaseSpellAPI(present)
    if present then
        rawset(env, "C_SpellBook", {
            FindBaseSpellByID = function(id)
                return TAG_BASE_LINKS[id] or id
            end,
        })
    else
        rawset(env, "C_SpellBook", {})
    end
end

local function clearBaseSpellAPI()
    rawset(env, "C_SpellBook", nil)
end

--- A store holding one poisoned-tag version. `id` is the override id written
--- into BOTH the tag and the stored name, which is what the old writer left.
local function installPoisonedTagStore(name, id)
    return installOverrideStore(name, {
        steps = { "/cast " .. TAG_SPELL_NAMES[id] },
        taggedSteps = { "/cast {spell:" .. id .. "}" },
    })
end

test("S7-persist (recover): a poisoned tag WITH a base link is repaired to the base name", function()
    installTagCache()
    installBaseSpellAPI(true)
    -- Raze 400254, which measured a real base link back to Maul 6807.
    local ver = installPoisonedTagStore("S7p_Raze", 400254)
    local prevRecompile = Engine.RecompileSequence
    Engine.RecompileSequence = function() end

    local ok, repaired = pcall(Engine.RepairPersistedOverrideNames, Engine)

    Engine.RecompileSequence = prevRecompile
    clearBaseSpellAPI()
    clearOverrideStore()

    assertTrue(ok, "S7-persist: RepairPersistedOverrideNames raised: " .. tostring(repaired))
    assertEqual(1, repaired, "S7-persist: the version was counted as repaired")
    assertEqual("/cast Maul", ver.steps[1], "S7-persist: the poisoned Raze name is back to the base name Maul")
    -- The TAG is deliberately NOT rewritten. Only stored TEXT is repaired; the
    -- display walk normalises through FindBaseSpellByID on its own.
    assertEqual("/cast {spell:400254}", ver.taggedSteps[1], "S7-persist: the stored tag itself is left as it was")
end)

test("S8-persist (no guessing): a poisoned tag with NO base link is left byte-identical", function()
    -- THE ONE THAT MATTERS MOST. Emitting a name here would make the repair a
    -- guess-emitter, which is the defect this whole release exists to remove.
    --
    -- RE-POINTED IN PHASE 4. This case used to use Ravage 441583, which had no
    -- base link from the API and no table row, so it was unrepairable. Phase 4
    -- added a MEASURED table row for Ravage and moved it into the repairable set,
    -- where S10 now covers it. The unrepairable class did not go away, so this
    -- case moves to the synthetic id that still occupies it: no base link AND no
    -- table row. Keeping Ravage here would have quietly turned the strongest
    -- case in the file into an assertion about nothing.
    installTagCache()
    installBaseSpellAPI(true)
    local unrecoverable = installPoisonedTagStore("S8p_Orphan", 999001)
    local before = persistedSnapshot(unrecoverable)
    -- CONTROL in the SAME store: a Raze row that DOES recover. Without it this
    -- case stays green on a build where the recovery does nothing for anyone.
    local recoverable = {
        stepFunction = "Sequential",
        steps = { "/cast Raze" },
        taggedSteps = { "/cast {spell:400254}" },
        keyPress = "",
        keyRelease = "",
    }
    rawget(env, "GRIP_EMS_CHAR").sequences["S8p_Raze"] =
        { name = "S8p_Raze", defaultVersion = 1, versions = { recoverable } }
    local prevRecompile = Engine.RecompileSequence
    Engine.RecompileSequence = function() end

    local ok, repaired = pcall(Engine.RepairPersistedOverrideNames, Engine)
    local after = persistedSnapshot(unrecoverable)

    Engine.RecompileSequence = prevRecompile
    clearBaseSpellAPI()
    clearOverrideStore()

    assertTrue(ok, "S8-persist: RepairPersistedOverrideNames raised: " .. tostring(repaired))
    assertEqual(before, after, "S8-persist: every persisted field of the orphan row is byte-identical")
    assertEqual("/cast SyntheticOrphan", unrecoverable.steps[1], "S8-persist: and no name was guessed into it")
    assertEqual(
        "/cast Maul",
        recoverable.steps[1],
        "S8-persist (control): the Raze neighbour in the same walk WAS repaired"
    )
    assertEqual(1, repaired, "S8-persist: the count is the one recoverable version, not both")
end)

test("S9-persist (absent API): no FindBaseSpellByID means no raise and no change", function()
    -- A build or a load order without the function must degrade to the old
    -- behaviour rather than erroring: this runs inside a login-time migration.
    installTagCache()
    installBaseSpellAPI(false)
    local ver = installPoisonedTagStore("S9p_Raze", 400254)
    local before = persistedSnapshot(ver)
    local prevRecompile = Engine.RecompileSequence
    Engine.RecompileSequence = function() end

    local okAbsent, absentCount = pcall(Engine.RepairPersistedOverrideNames, Engine)
    local afterAbsent = persistedSnapshot(ver)
    clearBaseSpellAPI()
    clearOverrideStore()

    -- DISCRIMINATOR: the SAME fixture, with the API present, must recover.
    -- Without this half the case would pass on a build that has no recovery at
    -- all, which is precisely what it is meant to distinguish.
    installTagCache()
    installBaseSpellAPI(true)
    local verPresent = installPoisonedTagStore("S9p_RazeControl", 400254)
    local okPresent, presentCount = pcall(Engine.RepairPersistedOverrideNames, Engine)
    local afterPresent = verPresent.steps[1]

    Engine.RecompileSequence = prevRecompile
    clearBaseSpellAPI()
    clearOverrideStore()

    assertTrue(okAbsent, "S9-persist: the repair raised with no FindBaseSpellByID: " .. tostring(absentCount))
    assertEqual(0, absentCount, "S9-persist: nothing was repaired without the API")
    assertEqual(before, afterAbsent, "S9-persist: every persisted field is byte-identical without the API")
    assertTrue(okPresent, "S9-persist (control): the repair raised with the API present: " .. tostring(presentCount))
    assertEqual(1, presentCount, "S9-persist (control): the same fixture DOES repair once the API is there")
    assertEqual("/cast Maul", afterPresent, "S9-persist (control): and it lands on the base name")
end)

-- ---------------------------------------------------------------------------
-- S10-persist and S11-persist, the TABLE half.
--
-- Phase 3b closed the Raze class: a poisoned tag whose spell carries a real base
-- link recovers through the API. Ravage was left open because the API answers
-- 441583 with 441583, its own id.
--
-- D.BASE_SPELL_TABLE already existed for exactly that gap and was EMPTY, and it
-- was also UNREACHABLE for the class it was built for, because SC:GetBaseSpellID
-- read a truthy identity answer as a real answer and returned early. Phase 4
-- fixes the reachability, adds the one measured pair, and points the recovery at
-- SC:GetBaseSpellID instead of at its own inline copy of the API call.
--
-- These two cases read the SHIPPED table, not a fixture copy, so removing the
-- row from Data/Defaults.lua fails S10.
--
-- WHY S10 IS NOT A TAUTOLOGY. In these fixtures the raw API still answers
-- 441583 -> 441583. A build that kept the inline API call therefore gets
-- identity and recovers nothing, while a build that delegates to
-- SC:GetBaseSpellID gets 6807 out of the table. The two disagree, and S10 reads
-- which one arrived.
-- ---------------------------------------------------------------------------

test("S10-persist (table): a poisoned Ravage tag now repairs to Maul through the shipped table", function()
    installTagCache()
    installBaseSpellAPI(true)
    -- 441583 with the API answering identity, which is the measured truth.
    local ver = installPoisonedTagStore("S10p_Ravage", 441583)
    local prevRecompile = Engine.RecompileSequence
    Engine.RecompileSequence = function() end

    local ok, repaired = pcall(Engine.RepairPersistedOverrideNames, Engine)

    Engine.RecompileSequence = prevRecompile
    clearBaseSpellAPI()
    clearOverrideStore()

    -- Read the SHIPPED table directly too, so a passing case cannot be hiding an
    -- empty table plus a coincidence.
    assertEqual(6807, SHIPPED_BASE_SPELL_TABLE[441583], "S10-persist: Data/Defaults.lua ships the measured pair")
    assertEqual(441583, TAG_BASE_LINKS[441583], "S10-persist: and the API in this fixture still answers identity")
    assertTrue(ok, "S10-persist: RepairPersistedOverrideNames raised: " .. tostring(repaired))
    assertEqual(1, repaired, "S10-persist: the version was counted as repaired")
    assertEqual("/cast Maul", ver.steps[1], "S10-persist: the poisoned Ravage name is back to the base name Maul")
    assertEqual(
        "/cast {spell:441583}",
        ver.taggedSteps[1],
        "S10-persist: the stored tag itself is still left as it was"
    )
end)

test("S11-persist (no table row): an id absent from the table is still left byte-identical", function()
    -- The other half of S8. S8's control proves the API path still works; this
    -- one's control proves the TABLE path works, so neither case can pass on a
    -- build where the corresponding route is dead.
    installTagCache()
    installBaseSpellAPI(true)
    local orphan = installPoisonedTagStore("S11p_Orphan", 999001)
    local before = persistedSnapshot(orphan)
    -- CONTROL in the SAME store: Ravage, which recovers only through the table.
    local viaTable = {
        stepFunction = "Sequential",
        steps = { "/cast Ravage" },
        taggedSteps = { "/cast {spell:441583}" },
        keyPress = "",
        keyRelease = "",
    }
    rawget(env, "GRIP_EMS_CHAR").sequences["S11p_Ravage"] =
        { name = "S11p_Ravage", defaultVersion = 1, versions = { viaTable } }
    local prevRecompile = Engine.RecompileSequence
    Engine.RecompileSequence = function() end

    local ok, repaired = pcall(Engine.RepairPersistedOverrideNames, Engine)
    local after = persistedSnapshot(orphan)

    Engine.RecompileSequence = prevRecompile
    clearBaseSpellAPI()
    clearOverrideStore()

    assertTrue(ok, "S11-persist: RepairPersistedOverrideNames raised: " .. tostring(repaired))
    assertEqual(nil, SHIPPED_BASE_SPELL_TABLE[999001], "S11-persist: the orphan id really is absent from the table")
    assertEqual(before, after, "S11-persist: every persisted field of the orphan row is byte-identical")
    assertEqual("/cast SyntheticOrphan", orphan.steps[1], "S11-persist: no name was guessed into it")
    assertEqual(
        "/cast Maul",
        viaTable.steps[1],
        "S11-persist (control): the in-table neighbour in the same walk WAS repaired"
    )
    assertEqual(1, repaired, "S11-persist: the count is the one repairable version, not both")
end)

-- ---------------------------------------------------------------------------
-- Run.
-- ---------------------------------------------------------------------------

local passed = 0
local failed = 0
for _, t in ipairs(tests) do
    local ok, err = pcall(t.fn)
    if ok then
        passed = passed + 1
        print("PASS  " .. t.name)
    else
        failed = failed + 1
        print("FAIL  " .. t.name .. " -- " .. tostring(err))
    end
end
print(string.format("RESULT %d passed, %d failed", passed, failed))
os.exit(failed > 0 and 1 or 0)
