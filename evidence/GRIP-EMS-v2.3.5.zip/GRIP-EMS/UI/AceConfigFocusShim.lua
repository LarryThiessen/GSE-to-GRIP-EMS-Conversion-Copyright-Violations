-- GRIP-EMS: AceConfig Focus Shim
-- Created: 2026-05-02
-- Updated: 2026-06-21
-- Patch: 12.0.7.68256 Midnight (Retail LIVE)
--
-- Bridges AceConfigDialog subpanels into GRIPEMS.Focus so Blizzard
-- SettingsCanvas pages get TAB cycle + ENTER activation. Opt-in per
-- group via Shim:Enable. All settings subpanels are shim-enabled by the
-- SettingsPanel.lua subpanel-build loop (else-branch); accessibility and
-- cvarHealth additionally register section / issue anchors for numbered-key
-- and skip-to-issue nav. The standalone "GRIP-EMS-Theme" theming modal is
-- shim-enabled by ModalFrame.lua. Externals (e.g. reload-gate sidebar pip)
-- join every active shim context via Shim:RegisterExternal.

local ADDON_NAME, GRIPEMS = ...
GRIPEMS.UI = GRIPEMS.UI or {}
GRIPEMS.UI.AceConfigFocusShim = GRIPEMS.UI.AceConfigFocusShim or {}
local Shim = GRIPEMS.UI.AceConfigFocusShim

local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

Shim._enabledGroups = Shim._enabledGroups or {}
Shim._externals = Shim._externals or {}
Shim._coalescing = false

-- G.9: per-group anchor registries for numbered-key + skip-to-issues nav.
-- Registered by panel-build code via RegisterSectionAnchors /
-- RegisterIssueAnchors. Replace-whole-array semantics on every register.
Shim._sectionAnchors = Shim._sectionAnchors or {}
Shim._issueAnchors = Shim._issueAnchors or {}

local LEAF_TYPES = {
    CheckBox = true,
    Dropdown = true,
    Slider = true,
    EditBox = true,
    Button = true,
    Keybinding = true,
    MultiLineEditBox = true,
    ColorPicker = true,
}

local CONTAINER_TYPES = {
    SimpleGroup = true,
    InlineGroup = true,
    TabGroup = true,
    TreeGroup = true,
    DropdownGroup = true,
    Frame = true,
}

local function isLeafType(t)
    if not t then
        return false
    end
    if LEAF_TYPES[t] then
        return true
    end
    if string.sub(t, 1, 6) == "LSM30_" then
        return true
    end
    return false
end

local function isContainerType(t)
    return t ~= nil and CONTAINER_TYPES[t] == true
end

-- The `seen` set de-duplicates by frame. A standalone AceGUI Frame exposes
-- THREE children whose .obj is the Frame widget itself (content, closebutton,
-- statusbg -- AceGUIContainer-Frame sets the latter two, RegisterAsContainer
-- sets content), and "Frame" is a container type, so without dedup the same
-- leaf set would be collected once per obj-bearing child (3x). Bliz canvas
-- subpanels expose a single obj-bearing child, so the set is a no-op there.
local function walkAceGUIChildren(children, targets, seen)
    if type(children) ~= "table" then
        return
    end
    for _, widget in ipairs(children) do
        local t = widget and widget.type
        if t then
            if isLeafType(t) then
                if widget.frame and not seen[widget.frame] then
                    seen[widget.frame] = true
                    targets[#targets + 1] = widget.frame
                end
            elseif isContainerType(t) then
                walkAceGUIChildren(widget.children, targets, seen)
            end
        end
    end
end

local function walkBlizzardChildren(parent, targets, seen)
    if not parent or not parent.GetChildren then
        return
    end
    local kids = { parent:GetChildren() }
    for _, child in ipairs(kids) do
        if child.obj and child.obj.type then
            local t = child.obj.type
            if isLeafType(t) then
                if not seen[child] then
                    seen[child] = true
                    targets[#targets + 1] = child
                end
            elseif isContainerType(t) then
                walkAceGUIChildren(child.obj.children, targets, seen)
            end
        else
            walkBlizzardChildren(child, targets, seen)
        end
    end
end

local function walkPanel(panelFrame)
    local targets = {}
    local seen = {}
    walkBlizzardChildren(panelFrame, targets, seen)
    return targets
end

local function appendExternals(targets)
    for _, ext in ipairs(Shim._externals) do
        targets[#targets + 1] = ext.widget
    end
end

local function buildActivator()
    return function(widget)
        for _, ext in ipairs(Shim._externals) do
            if ext.widget == widget then
                if type(ext.activator) == "function" then
                    ext.activator(widget)
                end
                return
            end
        end
        if widget.Click then
            widget:Click("LeftButton", true)
        end
    end
end

-- G.9 path-resolution helpers ------------------------------------------------
-- Resolve an option-table-relative dotted path (e.g. "cvarSection_general.fixAll")
-- to a rendered AceGUI widget frame under panelFrame. Returns nil when the
-- widget is not present, hidden, or its frame is missing.

local function getOption(widget)
    if not widget then
        return nil
    end
    if type(widget.GetUserData) == "function" then
        local ok, opt = pcall(widget.GetUserData, widget, "option")
        if ok then
            return opt
        end
    end
    if type(widget.userdata) == "table" then
        return widget.userdata.option
    end
    return nil
end

local function findOptionWidget(node, optionName)
    if not node then
        return nil
    end
    if getOption(node) == optionName then
        return node
    end
    if type(node.children) == "table" then
        for _, child in ipairs(node.children) do
            local hit = findOptionWidget(child, optionName)
            if hit then
                return hit
            end
        end
    end
    if type(node.GetChildren) == "function" then
        local ok, kids = pcall(function()
            return { node:GetChildren() }
        end)
        if ok and type(kids) == "table" then
            for _, child in ipairs(kids) do
                if child.obj then
                    local hit = findOptionWidget(child.obj, optionName)
                    if hit then
                        return hit
                    end
                end
                local hit = findOptionWidget(child, optionName)
                if hit then
                    return hit
                end
            end
        end
    end
    return nil
end

local function resolveOptionPath(panelFrame, path)
    if not panelFrame or type(path) ~= "string" or path == "" then
        return nil
    end
    local segments = {}
    for seg in string.gmatch(path, "([^.]+)") do
        segments[#segments + 1] = seg
    end
    if #segments == 0 then
        return nil
    end
    local current = panelFrame
    for _, seg in ipairs(segments) do
        local hit = findOptionWidget(current, seg)
        if not hit then
            return nil
        end
        current = hit
    end
    if current and current.frame then
        if current.frame.IsShown and not current.frame:IsShown() then
            return nil
        end
        return current.frame
    end
    return nil
end

local function indexOfFrameInTargets(frame, targets)
    if not frame or type(targets) ~= "table" then
        return nil
    end
    for i, t in ipairs(targets) do
        if t == frame then
            return i
        end
    end
    return nil
end

-- TTS announce helpers. Speech:Announce is a no-op when speech is disabled
-- upstream via accessibility.speechEnabled, so no extra gate needed here.

local function announceSection(anchorIdx, total, name)
    local Speech = GRIPEMS.Speech
    if not (Speech and Speech.Announce) then
        return
    end
    local fmt = L["ACCESS_ANNOUNCE_SECTION_JUMP"]
    if not fmt then
        return
    end
    Speech:Announce(string.format(fmt, anchorIdx, total, tostring(name or "")))
end

-- V2OX-G9-PINNED-MISMATCH-DIVERGENCE follow-up: pinned mismatch
-- rows now anchor on cvar_pin_<cvar> (see SettingsPanel.lua
-- _RegisterCvarHealthAnchors). Without the second match, those
-- paths fall through to tostring(path) and TTS speaks the raw
-- AceConfig path string instead of the cvar name. All three
-- shipped prefixes map to the same display name (cvar name).
--
-- ORDERING RULE: longest prefix FIRST in the chain. CVar names
-- can contain underscores (Sound_MasterVolume, fstack_enabled,
-- *_v2 family in Data/Defaults.lua), so [^_]+ capture would
-- mis-truncate; chain ordering is the only correct discriminator.
-- cvar_fix_select_ is shipped pre-emptively here -- the producer
-- side at SettingsPanel.lua _RegisterCvarHealthAnchors does not
-- yet emit cvar_fix_select_ paths (gated by V2OX-G9-FIX-SELECT-
-- ANCHOR Backlog L1530), but the chain handles them correctly the
-- moment that producer ships. Future additions (e.g. cvar_set_)
-- follow the same rule: prepend if the new prefix has an existing
-- prefix as a substring; append otherwise.
local function issueDisplayName(path)
    if path == "healthScoreExplain" then
        return L["GEMS_CVAR_HEALTH_EXPLAIN_HEADER"] or "details"
    end
    local cvarName = string.match(tostring(path), "%.cvar_fix_select_(.+)$")
        or string.match(tostring(path), "%.cvar_fix_(.+)$")
        or string.match(tostring(path), "%.cvar_pin_(.+)$")
    if cvarName then
        return cvarName
    end
    return tostring(path)
end

local function announceIssue(anchorIdx, total, path)
    local Speech = GRIPEMS.Speech
    if not (Speech and Speech.Announce) then
        return
    end
    local fmt = L["ACCESS_ANNOUNCE_ISSUE_JUMP"]
    if not fmt then
        return
    end
    Speech:Announce(string.format(fmt, anchorIdx, total, tostring(issueDisplayName(path))))
end

-- Move the active context cursor to `frame` (must be in top.targets) and
-- fire focus listeners exactly the way Focus:Cycle does for TAB. Returns
-- the new cursor index, or nil if the frame is not currently a target.
local function jumpCursorToFrame(entry, frame)
    if not entry or not frame then
        return nil
    end
    local Focus = GRIPEMS.Focus
    if not Focus then
        return nil
    end
    local top = Focus:TopContext()
    if not top or top.name ~= entry.ctxName then
        return nil
    end
    local cursorIdx = indexOfFrameInTargets(frame, top.targets)
    if not cursorIdx then
        return nil
    end
    local prev = top.cursor and top.targets[top.cursor] or nil
    top.cursor = cursorIdx
    if Focus._listeners then
        for i = 1, #Focus._listeners do
            local fn = Focus._listeners[i]
            if fn then
                pcall(fn, frame, prev)
            end
        end
    end
    return cursorIdx
end

-- REGRESSION-G9-KEYBOARD-LAYER-INERT (2026-05-24) -----------------------
-- Blizzard Patch 12.0 SettingsPanel embedded subFrames never deliver
-- OnKeyDown to canvas children -- SettingsPanel owns keyboard focus
-- and the action-bar binding system intercepts 1-9 / TAB / ENTER /
-- SPACE / Alt+N before any addon-side handler runs. The
-- panelFrame:HookScript("OnKeyDown", ...) ladder inside Shim:Enable
-- below remains as belt-and-braces for any future surface that does
-- deliver keys directly to a panelFrame, but it is 100 percent inert
-- today for cvarHealth + accessibility subpanels.
--
-- Workaround: register override bindings scoped to each panelFrame
-- on OnShow, with hidden dispatcher Button frames carrying
-- gripems_action closures + EditBox-aware dispatch (eb:Insert when an
-- EditBox owns keyboard focus). ClearOverrideBindings on OnHide.
-- Combat-lockdown defers install to PLAYER_REGEN_ENABLED.
-- Wiki: https://warcraft.wiki.gg/wiki/API_SetOverrideBindingClick

local _pendingInstall = {}

-- Dispatcher button registry. Each entry:
--   name    = global frame name (passed to SetOverrideBindingClick)
--   keybind = WoW normalized keybinding string
local _dispatcherButtons = {}

local function dispatcherOnClick(self)
    local eb = GetCurrentKeyBoardFocus and GetCurrentKeyBoardFocus() or nil
    if eb and eb.Insert and self.gripems_keyChar then
        local ok = pcall(eb.Insert, eb, self.gripems_keyChar)
        if ok then
            return
        end
    end
    if self.gripems_action then
        local ok, err = pcall(self.gripems_action)
        if not ok and GRIPEMS.Debug then
            GRIPEMS:Debug("FocusShim dispatcher action error:", err)
        end
    end
end

do
    local function makeButton(name, keybind, keyChar, action)
        local btn = CreateFrame("Button", name, nil)
        if btn.Hide then
            btn:Hide()
        end
        btn.gripems_keyChar = keyChar
        btn.gripems_action = action
        btn:SetScript("OnClick", dispatcherOnClick)
        _dispatcherButtons[#_dispatcherButtons + 1] = {
            name = name,
            keybind = keybind,
        }
    end

    -- Section jumps 1-9: type the digit into an EditBox if one is
    -- focused, otherwise jump the active group's cursor to section N.
    makeButton("GRIPEMS_FocusShim_Key1", "1", "1", function()
        if not Shim._activeKey then
            return
        end
        Shim:JumpToSection(Shim._activeKey, 1)
    end)
    makeButton("GRIPEMS_FocusShim_Key2", "2", "2", function()
        if not Shim._activeKey then
            return
        end
        Shim:JumpToSection(Shim._activeKey, 2)
    end)
    makeButton("GRIPEMS_FocusShim_Key3", "3", "3", function()
        if not Shim._activeKey then
            return
        end
        Shim:JumpToSection(Shim._activeKey, 3)
    end)
    makeButton("GRIPEMS_FocusShim_Key4", "4", "4", function()
        if not Shim._activeKey then
            return
        end
        Shim:JumpToSection(Shim._activeKey, 4)
    end)
    makeButton("GRIPEMS_FocusShim_Key5", "5", "5", function()
        if not Shim._activeKey then
            return
        end
        Shim:JumpToSection(Shim._activeKey, 5)
    end)
    makeButton("GRIPEMS_FocusShim_Key6", "6", "6", function()
        if not Shim._activeKey then
            return
        end
        Shim:JumpToSection(Shim._activeKey, 6)
    end)
    makeButton("GRIPEMS_FocusShim_Key7", "7", "7", function()
        if not Shim._activeKey then
            return
        end
        Shim:JumpToSection(Shim._activeKey, 7)
    end)
    makeButton("GRIPEMS_FocusShim_Key8", "8", "8", function()
        if not Shim._activeKey then
            return
        end
        Shim:JumpToSection(Shim._activeKey, 8)
    end)
    makeButton("GRIPEMS_FocusShim_Key9", "9", "9", function()
        if not Shim._activeKey then
            return
        end
        Shim:JumpToSection(Shim._activeKey, 9)
    end)

    -- Section cycle: PageUp = backward, PageDown = forward. Wrap at ends.
    makeButton("GRIPEMS_FocusShim_KeyPageUp", "PAGEUP", nil, function()
        if not Shim._activeKey then
            return
        end
        Shim:CycleSection(Shim._activeKey, -1)
    end)
    makeButton("GRIPEMS_FocusShim_KeyPageDown", "PAGEDOWN", nil, function()
        if not Shim._activeKey then
            return
        end
        Shim:CycleSection(Shim._activeKey, 1)
    end)

    -- Issue cycle: Alt+N = forward, Alt+Shift+N = backward.
    makeButton("GRIPEMS_FocusShim_AltN", "ALT-N", nil, function()
        if not Shim._activeKey then
            return
        end
        Shim:CycleIssue(Shim._activeKey, 1)
    end)
    makeButton("GRIPEMS_FocusShim_AltShiftN", "ALT-SHIFT-N", nil, function()
        if not Shim._activeKey then
            return
        end
        Shim:CycleIssue(Shim._activeKey, -1)
    end)

    -- Focus cycle: TAB forward, Shift+TAB backward.
    makeButton("GRIPEMS_FocusShim_KeyTab", "TAB", nil, function()
        local Focus = GRIPEMS.Focus
        if Focus and Focus.Cycle then
            Focus:Cycle(1)
        end
    end)
    makeButton("GRIPEMS_FocusShim_KeyShiftTab", "SHIFT-TAB", nil, function()
        local Focus = GRIPEMS.Focus
        if Focus and Focus.Cycle then
            Focus:Cycle(-1)
        end
    end)

    -- Activate (Space) -- fires Focus:Activate on cursor target.
    -- ENTER intentionally NOT overridden -- it blocks chat OPENCHAT
    -- and the chat-send commit path when the chat EditBox is focused.
    -- Users activate via SPACE or by clicking the widget directly.
    makeButton("GRIPEMS_FocusShim_KeySpace", "SPACE", nil, function()
        local Focus = GRIPEMS.Focus
        if Focus and Focus.Activate then
            Focus:Activate()
        end
    end)

    -- Clear (three-stage) -- ESC dismisses, in priority order:
    -- Stage 0: any visible GRIPEMS popup (modal confirmation, URL
    --          display, export string copy) dismisses first via its
    --          registered OnCancel callback + POP:Hide. Respects
    --          def.hideOnEscape so non-escapable popups stay modal.
    -- Stage 1: Focus cursor (set by 1-9 / PageUp / PageDown / Alt+N
    --          nav) clears next.
    -- Stage 2: Otherwise close the Settings panel via the canonical
    --          Blizzard call.
    -- Mirrors text-editor ESC semantics; this is the same root-cause
    -- class as REGRESSION-G9-KEYBOARD-LAYER-INERT (override binding
    -- intercepts before any frame OnKeyDown), applied recursively to
    -- the popups parented to UIParent that overlay the SettingsPanel.
    makeButton("GRIPEMS_FocusShim_KeyEscape", "ESCAPE", nil, function()
        -- Stage 0: dismiss any visible GRIPEMS popup first.
        local POP = GRIPEMS.Popup
        local popFrame = _G.GRIPEMS_PopupFrame
        if POP and popFrame and popFrame:IsShown() and popFrame.def then
            if popFrame.def.hideOnEscape ~= false then
                if popFrame.def.OnCancel then
                    pcall(popFrame.def.OnCancel, popFrame, popFrame.data)
                end
                if POP.Hide then
                    local ok, err = pcall(POP.Hide, POP, popFrame.currentName)
                    if not ok and GRIPEMS.Debug then
                        GRIPEMS:Debug("FocusShim ESC POP:Hide error:", popFrame.currentName, err)
                    end
                end
            end
            return
        end

        local Focus = GRIPEMS.Focus
        if Focus and Focus.GetCurrent and Focus:GetCurrent() then
            Focus:Clear()
            return
        end
        if SettingsPanel and SettingsPanel.Close then
            SettingsPanel:Close()
        elseif HideUIPanel and SettingsPanel then
            HideUIPanel(SettingsPanel)
        end
    end)
end

local function _InstallOverrideBindings(panelFrame, groupKey)
    if not panelFrame then
        return
    end
    if InCombatLockdown and InCombatLockdown() then
        _pendingInstall[panelFrame] = groupKey
        return
    end
    for _, entry in ipairs(_dispatcherButtons) do
        if SetOverrideBindingClick then
            SetOverrideBindingClick(panelFrame, true, entry.keybind, entry.name)
        end
    end
    _pendingInstall[panelFrame] = nil
end

local function _UninstallOverrideBindings(panelFrame)
    if not panelFrame then
        return
    end
    if ClearOverrideBindings then
        ClearOverrideBindings(panelFrame)
    end
    _pendingInstall[panelFrame] = nil
end

local _combatExitFrame = CreateFrame("Frame")
_combatExitFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
_combatExitFrame:SetScript("OnEvent", function()
    -- Drain deferred installs on combat exit. Snapshot keys first
    -- because _InstallOverrideBindings mutates _pendingInstall.
    local drain = {}
    for pf, gk in pairs(_pendingInstall) do
        drain[#drain + 1] = { panelFrame = pf, groupKey = gk }
    end
    for _, item in ipairs(drain) do
        if item.panelFrame.IsShown and item.panelFrame:IsShown() then
            _InstallOverrideBindings(item.panelFrame, item.groupKey)
        else
            _pendingInstall[item.panelFrame] = nil
        end
    end
end)

-- Resolve the registered group, drop the active context, walk the panel for
-- current targets (plus externals), push the Focus context, and mark the group
-- active. Extracted from the OnShow hook so callers that show the panel before
-- Enable runs (e.g. the standalone theming modal, which opens the AceConfig
-- frame first) can trigger the initial activation manually.
--
-- One safe generalization vs the original inline body: it pops ANY active
-- context, including a prior context for this same group, not only a different
-- group's. The OnShow path always clears _activeKey via OnHide before
-- re-showing, so the same-group case never arises there and existing
-- accessibility / cvarHealth behavior is unchanged. It DOES arise for manual
-- re-activation of the pooled AceConfigDialog frame (re-opening /gems theme,
-- or an Inspect-Mode re-open, without closing first): AceConfigDialog:Open
-- releases and rebuilds the child widgets, so the old targets are stale --
-- popping first replaces the context instead of stacking a leaked duplicate.
function Shim:_ActivateGroup(groupKey)
    local entry = self._enabledGroups[groupKey]
    if not entry then
        return
    end
    local panelFrame = entry.panelFrame
    local ctxName = entry.ctxName
    local Focus = GRIPEMS.Focus
    if not Focus then
        return
    end

    if self._activeKey ~= nil then
        local prev = self._enabledGroups[self._activeKey]
        if prev then
            Focus:PopContext(prev.ctxName)
        end
        self._activeKey = nil
    end

    local targets = walkPanel(panelFrame)
    appendExternals(targets)

    Focus:PushContext(ctxName, targets, { onActivate = buildActivator() })
    self._activeKey = groupKey
end

function Shim:Enable(groupKey, panelFrame, opts)
    if not groupKey or not panelFrame then
        return
    end
    if self._enabledGroups[groupKey] then
        return
    end

    local ctxName = "AceConfigShim:" .. groupKey
    self._enabledGroups[groupKey] = {
        panelFrame = panelFrame,
        ctxName = ctxName,
        onRewalk = (opts and opts.onRewalk) or nil,
    }

    panelFrame:EnableKeyboard(true)

    panelFrame:HookScript("OnShow", function()
        Shim:_ActivateGroup(groupKey)
    end)

    panelFrame:HookScript("OnHide", function()
        if Shim._activeKey ~= groupKey then
            return
        end
        local Focus = GRIPEMS.Focus
        if not Focus then
            return
        end
        Focus:PopContext(ctxName)
        Shim._activeKey = nil
    end)

    -- REGRESSION-G9-KEYBOARD-LAYER-INERT: install override bindings on
    -- show, uninstall on hide. These hooks stack additively on the
    -- HookScripts above. Combat-lockdown is handled inside
    -- _InstallOverrideBindings (defers to PLAYER_REGEN_ENABLED).
    panelFrame:HookScript("OnShow", function()
        _InstallOverrideBindings(panelFrame, groupKey)
    end)

    panelFrame:HookScript("OnHide", function()
        _UninstallOverrideBindings(panelFrame)
    end)

    panelFrame:HookScript("OnKeyDown", function(self, key)
        if InCombatLockdown() then
            return
        end
        -- Suspenders layer: independent of the Focus flag, query WoW
        -- directly for any focused EditBox. If found, propagate the key
        -- and let the EditBox handle it.
        if GetCurrentKeyBoardFocus and GetCurrentKeyBoardFocus() then
            pcall(self.SetPropagateKeyboardInput, self, true)
            return
        end
        local Focus = GRIPEMS.Focus
        if not Focus then
            return
        end
        if Shim._activeKey ~= groupKey then
            return
        end
        local top = Focus:TopContext()
        if not top or top.name ~= ctxName then
            return
        end
        if Focus:IsEditBoxFocused() then
            pcall(self.SetPropagateKeyboardInput, self, true)
            return
        end
        if key == "TAB" then
            Focus:Cycle(IsShiftKeyDown() and -1 or 1)
            pcall(self.SetPropagateKeyboardInput, self, false)
            return
        elseif key == "ENTER" or key == "SPACE" then
            Focus:Activate()
            pcall(self.SetPropagateKeyboardInput, self, false)
            return
        elseif key == "ESCAPE" then
            Focus:Clear()
            pcall(self.SetPropagateKeyboardInput, self, true)
            return
        elseif
            (
                key == "1"
                or key == "2"
                or key == "3"
                or key == "4"
                or key == "5"
                or key == "6"
                or key == "7"
                or key == "8"
                or key == "9"
            )
            and not IsShiftKeyDown()
            and not IsControlKeyDown()
            and not IsAltKeyDown()
        then
            Shim:JumpToSection(groupKey, tonumber(key))
            pcall(self.SetPropagateKeyboardInput, self, false)
            return
        elseif key == "PAGEUP" or key == "PAGEDOWN" then
            Shim:CycleSection(groupKey, (key == "PAGEDOWN") and 1 or -1)
            pcall(self.SetPropagateKeyboardInput, self, false)
            return
        elseif key == "N" and IsAltKeyDown() then
            Shim:CycleIssue(groupKey, IsShiftKeyDown() and -1 or 1)
            pcall(self.SetPropagateKeyboardInput, self, false)
            return
        end
        pcall(self.SetPropagateKeyboardInput, self, true)
    end)
end

-- Enable the shim for a group whose panel frame is POOLED / recreated on each
-- open -- e.g. an AceConfigDialog:Open standalone Frame. AceConfigDialog
-- releases that Frame to the shared AceGUI "Frame" pool on close
-- (FrameOnClose -> gui:Release), and gui:Create may hand back a DIFFERENT widget
-- on the next open (the main settings window is also a pooled Frame, so opening
-- it between theme sessions churns the pool). Shim:Enable binds the frame and
-- its hooks once and early-returns forever, so it cannot follow a pooled frame.
--
-- EnablePooled (re)binds entry.panelFrame to the CURRENT frame on every call,
-- hooks that frame once (HookScript stacks, so a per-frame flag stops a frame
-- returning from the pool being double-hooked), and activates manually (the
-- frame is already shown before this runs, so an OnShow activation would be
-- missed on first open anyway). It installs NO OnShow hook: activation is
-- manual, and an OnShow hook on a pooled frame would spuriously re-activate the
-- group when that frame is later reused for a different window. The OnHide /
-- OnKeyDown hooks are frame-aware (no-op unless they fire on the group's current
-- frame), so hooks stranded on previously-used pooled frames stay inert. No
-- override bindings: a standalone frame routes keys through its own OnKeyDown,
-- and a pooled modal registers no section anchors.
function Shim:EnablePooled(groupKey, panelFrame)
    if not groupKey or not panelFrame then
        return
    end
    local entry = self._enabledGroups[groupKey]
    if not entry then
        entry = { ctxName = "AceConfigShim:" .. groupKey }
        self._enabledGroups[groupKey] = entry
    end
    entry.panelFrame = panelFrame
    self:_HookPooledFrame(panelFrame, groupKey)
    self:_ActivateGroup(groupKey)
end

-- Install the keyboard hooks for a pooled panel frame, once per physical frame.
-- See EnablePooled for why these are frame-aware and why there is no OnShow
-- hook. The OnKeyDown mirrors Shim:Enable's handler minus the section / issue
-- numbered-key nav (pooled modals register no anchors); ESC propagates so the
-- frame's UISpecialFrames entry closes it.
function Shim:_HookPooledFrame(panelFrame, groupKey)
    if panelFrame._gemsPooledShimHook then
        return
    end
    panelFrame._gemsPooledShimHook = groupKey
    panelFrame:EnableKeyboard(true)

    panelFrame:HookScript("OnHide", function(self)
        local entry = Shim._enabledGroups[groupKey]
        if not entry or entry.panelFrame ~= self or Shim._activeKey ~= groupKey then
            return
        end
        local Focus = GRIPEMS.Focus
        if Focus then
            Focus:PopContext(entry.ctxName)
        end
        Shim._activeKey = nil
    end)

    panelFrame:HookScript("OnKeyDown", function(self, key)
        if InCombatLockdown() then
            return
        end
        -- Every non-combat early-return restores propagation. This frame is
        -- pooled: once released it can be reused as another window (e.g. the
        -- main settings frame), and SetPropagateKeyboardInput is sticky -- if a
        -- prior theme TAB/SPACE left it false, a stranded hook returning without
        -- re-propagating would silently swallow that window's keys.
        local entry = Shim._enabledGroups[groupKey]
        if not entry or entry.panelFrame ~= self or Shim._activeKey ~= groupKey then
            pcall(self.SetPropagateKeyboardInput, self, true)
            return
        end
        if GetCurrentKeyBoardFocus and GetCurrentKeyBoardFocus() then
            pcall(self.SetPropagateKeyboardInput, self, true)
            return
        end
        local Focus = GRIPEMS.Focus
        if not Focus then
            pcall(self.SetPropagateKeyboardInput, self, true)
            return
        end
        local top = Focus:TopContext()
        if not top or top.name ~= entry.ctxName then
            pcall(self.SetPropagateKeyboardInput, self, true)
            return
        end
        if Focus:IsEditBoxFocused() then
            pcall(self.SetPropagateKeyboardInput, self, true)
            return
        end
        if key == "TAB" then
            Focus:Cycle(IsShiftKeyDown() and -1 or 1)
            pcall(self.SetPropagateKeyboardInput, self, false)
            return
        elseif key == "ENTER" or key == "SPACE" then
            Focus:Activate()
            pcall(self.SetPropagateKeyboardInput, self, false)
            return
        elseif key == "ESCAPE" then
            Focus:Clear()
            pcall(self.SetPropagateKeyboardInput, self, true)
            return
        end
        pcall(self.SetPropagateKeyboardInput, self, true)
    end)
end

function Shim:RegisterExternal(widget, activatorFn)
    if not widget then
        return
    end

    for _, ext in ipairs(self._externals) do
        if ext.widget == widget then
            ext.activator = activatorFn
            return
        end
    end

    self._externals[#self._externals + 1] = {
        widget = widget,
        activator = activatorFn,
    }

    if self._activeKey then
        local Focus = GRIPEMS.Focus
        if Focus then
            local entry = self._enabledGroups[self._activeKey]
            if entry then
                local top = Focus:TopContext()
                if top and top.name == entry.ctxName then
                    top.targets[#top.targets + 1] = widget
                end
            end
        end
    end
end

function Shim:UnregisterExternal(widget)
    if not widget then
        return
    end

    for i, ext in ipairs(self._externals) do
        if ext.widget == widget then
            table.remove(self._externals, i)
            break
        end
    end

    if self._activeKey then
        local Focus = GRIPEMS.Focus
        if Focus then
            local entry = self._enabledGroups[self._activeKey]
            if entry then
                local top = Focus:TopContext()
                if top and top.name == entry.ctxName then
                    for i = #top.targets, 1, -1 do
                        if top.targets[i] == widget then
                            table.remove(top.targets, i)
                            if top.cursor == i then
                                top.cursor = nil
                            elseif top.cursor and top.cursor > i then
                                top.cursor = top.cursor - 1
                            end
                            break
                        end
                    end
                end
            end
        end
    end
end

-- G.9 anchor-registration + jump APIs ---------------------------------------

--- Replace the section-anchor array for groupKey. anchors is an array of
--- { key, name, path } tables. Pass nil or an empty table to clear.
function Shim:RegisterSectionAnchors(groupKey, anchors)
    if not groupKey then
        return
    end
    if anchors == nil or (type(anchors) == "table" and #anchors == 0) then
        self._sectionAnchors[groupKey] = nil
        return
    end
    if type(anchors) ~= "table" then
        return
    end
    local copy = {}
    for i, a in ipairs(anchors) do
        if type(a) == "table" and type(a.path) == "string" then
            copy[i] = { key = a.key, name = a.name, path = a.path }
        end
    end
    self._sectionAnchors[groupKey] = copy
end

--- Replace the issue-anchor array for groupKey. paths is an array of
--- option-table-relative path strings. Pass nil or an empty table to clear.
function Shim:RegisterIssueAnchors(groupKey, paths)
    if not groupKey then
        return
    end
    if paths == nil or (type(paths) == "table" and #paths == 0) then
        self._issueAnchors[groupKey] = nil
        return
    end
    if type(paths) ~= "table" then
        return
    end
    local copy = {}
    for _, p in ipairs(paths) do
        if type(p) == "string" and p ~= "" then
            copy[#copy + 1] = p
        end
    end
    self._issueAnchors[groupKey] = copy
end

--- Jump the active context cursor to section idx (1-based). No-op if no
--- anchors are registered, idx is out of range, the resolved frame is not
--- in the current targets array, or the panel is not shown. Fires Focus
--- listeners and announces via Speech when the jump succeeds.
function Shim:JumpToSection(groupKey, idx)
    local anchors = self._sectionAnchors[groupKey]
    if not anchors or type(idx) ~= "number" then
        return
    end
    local anchor = anchors[idx]
    if not anchor then
        return
    end
    local entry = self._enabledGroups[groupKey]
    if not entry or not entry.panelFrame then
        return
    end
    if entry.panelFrame.IsShown and not entry.panelFrame:IsShown() then
        return
    end
    local frame = resolveOptionPath(entry.panelFrame, anchor.path)
    if not frame then
        return
    end
    if not jumpCursorToFrame(entry, frame) then
        return
    end
    announceSection(idx, #anchors, anchor.name or anchor.key or "")
end

local function findCurrentSectionIndex(entry, anchors, cursor)
    if not cursor or cursor == 0 then
        return nil
    end
    local Focus = GRIPEMS.Focus
    if not Focus then
        return nil
    end
    local top = Focus:TopContext()
    if not top or not top.targets then
        return nil
    end
    local result
    for i = 1, #anchors do
        local frame = resolveOptionPath(entry.panelFrame, anchors[i].path)
        if frame then
            local fi = indexOfFrameInTargets(frame, top.targets)
            if fi and fi <= cursor then
                result = i
            end
        end
    end
    return result
end

--- Cycle to the next/previous section anchor, wrapping at the array ends.
--- dir is 1 (forward) or -1 (backward). No-op if no anchors registered.
function Shim:CycleSection(groupKey, dir)
    local anchors = self._sectionAnchors[groupKey]
    if not anchors or #anchors == 0 then
        return
    end
    dir = (dir == -1) and -1 or 1
    local entry = self._enabledGroups[groupKey]
    if not entry or not entry.panelFrame then
        return
    end
    if entry.panelFrame.IsShown and not entry.panelFrame:IsShown() then
        return
    end
    local Focus = GRIPEMS.Focus
    if not Focus then
        return
    end
    local top = Focus:TopContext()
    if not top or top.name ~= entry.ctxName then
        return
    end

    local cursor = top.cursor or 0
    local total = #anchors
    local currentIdx = findCurrentSectionIndex(entry, anchors, cursor)
    local nextIdx
    if currentIdx then
        nextIdx = ((currentIdx - 1 + dir) % total) + 1
    else
        nextIdx = (dir == 1) and 1 or total
    end
    self:JumpToSection(groupKey, nextIdx)
end

local function findCurrentIssueIndex(entry, paths, cursor)
    if not cursor or cursor == 0 then
        return nil
    end
    local Focus = GRIPEMS.Focus
    if not Focus then
        return nil
    end
    local top = Focus:TopContext()
    if not top or not top.targets then
        return nil
    end
    for i = 1, #paths do
        local frame = resolveOptionPath(entry.panelFrame, paths[i])
        if frame and top.targets[cursor] == frame then
            return i
        end
    end
    return nil
end

--- Cycle to the next/previous issue anchor, wrapping at the array ends.
--- dir is 1 (forward) or -1 (backward). No-op if no anchors registered.
function Shim:CycleIssue(groupKey, dir)
    local paths = self._issueAnchors[groupKey]
    if not paths or #paths == 0 then
        return
    end
    dir = (dir == -1) and -1 or 1
    local entry = self._enabledGroups[groupKey]
    if not entry or not entry.panelFrame then
        return
    end
    if entry.panelFrame.IsShown and not entry.panelFrame:IsShown() then
        return
    end
    local Focus = GRIPEMS.Focus
    if not Focus then
        return
    end
    local top = Focus:TopContext()
    if not top or top.name ~= entry.ctxName then
        return
    end

    local cursor = top.cursor or 0
    local total = #paths
    local currentIdx = findCurrentIssueIndex(entry, paths, cursor)
    local nextIdx
    if currentIdx then
        nextIdx = ((currentIdx - 1 + dir) % total) + 1
    else
        nextIdx = (dir == 1) and 1 or total
    end
    local path = paths[nextIdx]
    if not path then
        return
    end
    local frame = resolveOptionPath(entry.panelFrame, path)
    if not frame then
        return
    end
    if not jumpCursorToFrame(entry, frame) then
        return
    end
    announceIssue(nextIdx, total, path)
end

function Shim:_RewalkActive()
    if not self._activeKey then
        return
    end
    local entry = self._enabledGroups[self._activeKey]
    if not entry or not entry.panelFrame then
        return
    end
    if not entry.panelFrame:IsShown() then
        return
    end
    local Focus = GRIPEMS.Focus
    if not Focus then
        return
    end
    local top = Focus:TopContext()
    if not top or top.name ~= entry.ctxName then
        return
    end

    local newTargets = walkPanel(entry.panelFrame)
    for _, ext in ipairs(self._externals) do
        newTargets[#newTargets + 1] = ext.widget
    end

    local prevWidget = top.cursor and top.targets[top.cursor] or nil

    for i = #top.targets, 1, -1 do
        top.targets[i] = nil
    end
    for i, t in ipairs(newTargets) do
        top.targets[i] = t
    end

    local newCursor = nil
    if prevWidget then
        for i, t in ipairs(newTargets) do
            if t == prevWidget then
                newCursor = i
                break
            end
        end
    end
    top.cursor = newCursor

    -- G.9: notify owner so anchor registries can be re-resolved against the
    -- freshly-walked tree. Errors in onRewalk must not fail the rewalk.
    if entry.onRewalk then
        pcall(entry.onRewalk)
    end
end

function Shim:_OnConfigChange(event, appName)
    if appName ~= "GRIP-EMS" and not Shim._enabledGroups[appName] then
        return
    end
    if Shim._activeKey == nil then
        return
    end
    if Shim._coalescing then
        return
    end
    Shim._coalescing = true
    if C_Timer and C_Timer.After then
        C_Timer.After(0, function()
            Shim._coalescing = false
            Shim:_RewalkActive()
        end)
    end
end

do
    local reg = LibStub and LibStub("AceConfigRegistry-3.0", true)
    if reg and reg.RegisterCallback then
        reg.RegisterCallback(Shim, "ConfigTableChange", "_OnConfigChange")
    end
end
