-- GRIP-EMS: Context Tab
-- Context version assignment panel with collapsible groups and per-version checkboxes

local ADDON_NAME, GRIPEMS = ...
local UI = GRIPEMS.UI
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS")

-- Upvalue accessor for Defaults
local function D()
    return GRIPEMS.Defaults
end

GRIPEMS.ContextTab = {}
local CT = GRIPEMS.ContextTab

-- Runtime state
CT.viewingVersionIdx = 1

-- Group name to locale key mapping
local GROUP_LOCALE = {
    Raids = "GEMS_CONTEXT_GROUP_RAIDS",
    Dungeons = "GEMS_CONTEXT_GROUP_DUNGEONS",
    PvP = "GEMS_CONTEXT_GROUP_PVP",
    ["Arena Maps"] = "GEMS_CONTEXT_GROUP_ARENA_MAPS",
    ["Battleground Maps"] = "GEMS_CONTEXT_GROUP_BG_MAPS",
    Other = "GEMS_CONTEXT_GROUP_OTHER",
}

-- Collapsed state per group (all start expanded)
-- Group button references
CT.groupSelectAll = {}
CT.groupClearAll = {}

local function GetCollapsed()
    local S = GRIPEMS.Settings
    if not S then
        return {}
    end
    local saved = S:Get("contextGroupCollapsed")
    if type(saved) ~= "table" then
        return {}
    end
    return saved
end

local function SetCollapsed(groupName, collapsed)
    local S = GRIPEMS.Settings
    if not S then
        return
    end
    local tbl = S:Get("contextGroupCollapsed")
    if type(tbl) ~= "table" then
        tbl = {}
    end
    tbl[groupName] = collapsed
    S:Set("contextGroupCollapsed", tbl)
end

---------------------------------------------------------------------------
-- StaticPopup (registered once)
---------------------------------------------------------------------------
if not StaticPopupDialogs["GRIPEMS_CONTEXT_CONFLICT"] then
    StaticPopupDialogs["GRIPEMS_CONTEXT_CONFLICT"] = {
        text = "",
        button1 = ACCEPT,
        button2 = CANCEL,
        OnAccept = nil,
        OnCancel = nil,
        timeout = 0,
        whileDead = true,
        hideOnEscape = true,
    }
end

---------------------------------------------------------------------------
-- Initialization
---------------------------------------------------------------------------

--- Build the context tab UI inside the given parent frame (content area).
--- @param parentFrame Frame The content area that hosts tab content
function CT:Init(parentFrame)
    if not parentFrame then
        return
    end
    local C = UI.Colors

    CT.container = parentFrame

    -- Main frame for the context tab
    local frame = CreateFrame("Frame", nil, parentFrame)
    frame:SetAllPoints(parentFrame)
    frame:Hide()
    CT.frame = frame

    local yOff = -8

    -------------------------------------------------------------------
    -- A) Info bar (top ~40px)
    -------------------------------------------------------------------
    -- Left side: "Current Context: [label]"
    local currentLabel = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(currentLabel, 10)
    currentLabel:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, yOff)
    currentLabel:SetTextColor(C.textSecondary:GetRGBA())
    currentLabel:SetText(string.format(L["GEMS_CONTEXT_CURRENT_INFO"], L["GEMS_CONTEXT_NONE_LABEL"]))
    CT.currentLabel = currentLabel

    -- Right side: "Default Version: N" button
    local defaultBtn = UI:CreateButton(frame, string.format(L["GEMS_CONTEXT_DEFAULT_LABEL"], 1), 150, 22)
    defaultBtn:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -8, yOff + 2)
    defaultBtn:SetScript("OnClick", function(self)
        if not GRIPEMS.SequenceEditor then
            return
        end
        local SE = GRIPEMS.SequenceEditor
        if not SE.currentSequence then
            return
        end
        local entry = GRIPEMS.Engine and GRIPEMS.Engine.sequences and GRIPEMS.Engine.sequences[SE.currentSequence]
        if not entry or not entry.data then
            return
        end
        local seqData = entry.data
        local numVersions = seqData.versions and #seqData.versions or 0

        MenuUtil.CreateContextMenu(self, function(_, rootDescription)
            for vi = 1, numVersions do
                local lbl = "Version " .. vi
                if vi == (seqData.defaultVersion or 1) then
                    lbl = lbl .. " (*)"
                end
                rootDescription:CreateButton(lbl, function()
                    seqData.defaultVersion = vi
                    SE.isDirty = true
                    SE:UpdateSaveButtons()
                    CT:Refresh()
                end)
            end
        end)
    end)
    defaultBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.bgRowHover:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
        UI:ShowTooltip(self, "Default Version", "The version used when no context override matches.")
    end)
    defaultBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
        UI:HideTooltip()
    end)
    CT.defaultBtn = defaultBtn

    yOff = yOff - 28

    -------------------------------------------------------------------
    -- B) Version selector (~30px)
    -------------------------------------------------------------------
    local viewLabel = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(viewLabel, 10)
    viewLabel:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, yOff)
    viewLabel:SetTextColor(C.textPrimary:GetRGBA())
    viewLabel:SetText(string.format(L["GEMS_CONTEXT_VIEWING"], 1))
    CT.viewLabel = viewLabel

    local viewBtn = UI:CreateButton(frame, "Version 1", 100, 22)
    viewBtn:SetPoint("LEFT", viewLabel, "RIGHT", 8, 0)
    viewBtn:SetScript("OnClick", function(self)
        if not GRIPEMS.SequenceEditor then
            return
        end
        local SE = GRIPEMS.SequenceEditor
        if not SE.currentSequence then
            return
        end
        local entry = GRIPEMS.Engine and GRIPEMS.Engine.sequences and GRIPEMS.Engine.sequences[SE.currentSequence]
        if not entry or not entry.data or not entry.data.versions then
            return
        end

        local seqImported = entry.data.importMeta ~= nil
        MenuUtil.CreateContextMenu(self, function(_, rootDescription)
            for i = 1, #entry.data.versions do
                local lbl = "Version " .. i
                if seqImported then
                    lbl = lbl .. " (imported)"
                end
                rootDescription:CreateButton(lbl, function()
                    CT.viewingVersionIdx = i
                    CT:Refresh()
                end)
            end
        end)
    end)
    viewBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.bgRowHover:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
    end)
    viewBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
    end)
    CT.viewBtn = viewBtn

    yOff = yOff - 28

    -------------------------------------------------------------------
    -- C) Hint text (~20px)
    -------------------------------------------------------------------
    local hintText = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(hintText, 9)
    hintText:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, yOff)
    hintText:SetPoint("RIGHT", frame, "RIGHT", -8, 0)
    hintText:SetText(L["GEMS_CONTEXT_HINT"])
    hintText:SetTextColor(C.textMuted:GetRGBA())
    hintText:SetJustifyH("LEFT")
    hintText:SetWordWrap(true)
    CT.hintText = hintText

    yOff = yOff - 30

    -------------------------------------------------------------------
    -- C2) Fallback chain indicator (~24px)
    -------------------------------------------------------------------
    local fallbackFrame = CreateFrame("Frame", nil, frame)
    fallbackFrame:SetHeight(24)
    fallbackFrame:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, yOff)
    fallbackFrame:SetPoint("RIGHT", frame, "RIGHT", -8, 0)
    CT.fallbackFrame = fallbackFrame
    CT.fallbackLabels = {}

    yOff = yOff - 28

    -------------------------------------------------------------------
    -- "No versions" hint (shown when < 2 versions)
    -------------------------------------------------------------------
    local noVersionsHint = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(noVersionsHint, 11)
    noVersionsHint:SetPoint("CENTER", frame, "CENTER", 0, 0)
    noVersionsHint:SetText(L["GEMS_CONTEXT_NO_VERSIONS"])
    noVersionsHint:SetTextColor(C.textMuted:GetRGBA())
    noVersionsHint:Hide()
    CT.noVersionsHint = noVersionsHint

    -------------------------------------------------------------------
    -- D) Scrollable group area
    -------------------------------------------------------------------
    local scrollFrame, scrollChild = UI:CreateScrollPanel(frame, 300)
    scrollFrame:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, yOff)
    scrollFrame:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -26, 4)
    CT.scrollFrame = scrollFrame
    CT.scrollChild = scrollChild

    scrollFrame:SetScript("OnSizeChanged", function(self)
        if CT.scrollChild then
            local w = self:GetWidth()
            if w and w > 0 then
                CT.scrollChild:SetWidth(w)
            end
        end
    end)

    -- Build group headers and checkbox rows
    CT.groupHeaders = {}
    CT.checkboxRows = {}

    local childY = 0
    local defaults = D()

    for _, group in ipairs(defaults.CONTEXT_GROUPS) do
        local groupName = group.name
        local localeKey = GROUP_LOCALE[groupName]
        local groupLabel = localeKey and L[localeKey] or groupName
        -- Group header button
        local headerBtn = CreateFrame("Button", nil, scrollChild, "BackdropTemplate")
        headerBtn:SetHeight(22)
        headerBtn:SetPoint("TOPLEFT", scrollChild, "TOPLEFT", 4, -childY)
        headerBtn:SetPoint("RIGHT", scrollChild, "RIGHT", -4, 0)
        if not headerBtn.SetBackdrop then
            Mixin(headerBtn, BackdropTemplateMixin)
        end
        UI:ApplyBackdrop(headerBtn, UI.Backdrops.panelNoBorder, C.bgDeep)

        local headerText = headerBtn:CreateFontString(nil, "OVERLAY")
        UI:SetFont(headerText, 11)
        headerText:SetPoint("LEFT", headerBtn, "LEFT", 8, 0)
        headerText:SetText("v " .. groupLabel)
        headerText:SetTextColor(C.textPrimary:GetRGBA())
        headerBtn.label = headerText
        headerBtn._groupName = groupName
        headerBtn._groupLabel = groupLabel

        headerBtn:SetScript("OnClick", function(self)
            local current = GetCollapsed()[self._groupName]
            SetCollapsed(self._groupName, not current)
            CT:LayoutGroups()
        end)
        headerBtn:SetScript("OnEnter", function(self)
            self:SetBackdropColor(C.bgRowHover:GetRGBA())
        end)
        headerBtn:SetScript("OnLeave", function(self)
            self:SetBackdropColor(C.bgDeep:GetRGBA())
        end)

        -- "None" button (right side of header)
        local clearBtn = UI:CreateButton(headerBtn, L["GEMS_CONTEXT_CLEAR_ALL"], 36, 18)
        UI:SetFont(clearBtn.label, 9)
        clearBtn:SetPoint("RIGHT", headerBtn, "RIGHT", -4, 0)
        clearBtn._groupKeys = group.keys
        clearBtn:SetScript("OnClick", function()
            local SE = GRIPEMS.SequenceEditor
            if not SE or not SE.currentSequence then
                return
            end
            local entry = GRIPEMS.Engine and GRIPEMS.Engine.sequences and GRIPEMS.Engine.sequences[SE.currentSequence]
            if not entry or not entry.data then
                return
            end
            local seqData = entry.data
            seqData.contextOverrides = seqData.contextOverrides or {}
            for _, ctxKey in ipairs(group.keys) do
                if seqData.contextOverrides[ctxKey] == CT.viewingVersionIdx then
                    seqData.contextOverrides[ctxKey] = nil
                end
            end
            SE.isDirty = true
            SE:UpdateSaveButtons()
            CT:Refresh()
        end)
        clearBtn:SetScript("OnEnter", function(self)
            self:SetBackdropColor(C.bgRowHover:GetRGBA())
            self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
        end)
        clearBtn:SetScript("OnLeave", function(self)
            self:SetBackdropColor(C.bgButton:GetRGBA())
            self:SetBackdropBorderColor(C.border:GetRGBA())
        end)
        CT.groupClearAll[groupName] = clearBtn

        -- "All" button (left of None)
        local selectBtn = UI:CreateButton(headerBtn, L["GEMS_CONTEXT_SELECT_ALL"], 30, 18)
        UI:SetFont(selectBtn.label, 9)
        selectBtn:SetPoint("RIGHT", headerBtn, "RIGHT", -40, 0)
        selectBtn._groupKeys = group.keys
        selectBtn:SetScript("OnClick", function()
            local SE = GRIPEMS.SequenceEditor
            if not SE or not SE.currentSequence then
                return
            end
            local entry = GRIPEMS.Engine and GRIPEMS.Engine.sequences and GRIPEMS.Engine.sequences[SE.currentSequence]
            if not entry or not entry.data then
                return
            end
            local seqData = entry.data
            seqData.contextOverrides = seqData.contextOverrides or {}
            local firstConflict = nil
            for _, ctxKey in ipairs(group.keys) do
                local ovIdx = seqData.contextOverrides[ctxKey]
                if not ovIdx or ovIdx == CT.viewingVersionIdx then
                    seqData.contextOverrides[ctxKey] = CT.viewingVersionIdx
                elseif ovIdx ~= CT.viewingVersionIdx and not firstConflict then
                    firstConflict = ctxKey
                end
            end
            SE.isDirty = true
            SE:UpdateSaveButtons()
            CT:Refresh()
            if firstConflict then
                local defaults = D() -- luacheck: no redefined
                local dialog = StaticPopupDialogs["GRIPEMS_CONTEXT_CONFLICT"]
                local conflictIdx = seqData.contextOverrides[firstConflict]
                dialog.text = string.format(
                    L["GEMS_CONTEXT_CONFLICT_MSG"],
                    defaults.CONTEXT_LABELS[firstConflict] or firstConflict,
                    conflictIdx,
                    CT.viewingVersionIdx
                )
                dialog.OnAccept = function()
                    seqData.contextOverrides[firstConflict] = CT.viewingVersionIdx
                    SE.isDirty = true
                    SE:UpdateSaveButtons()
                    CT:Refresh()
                end
                dialog.OnCancel = function()
                    CT:Refresh()
                end
                StaticPopup_Show("GRIPEMS_CONTEXT_CONFLICT")
            end
        end)
        selectBtn:SetScript("OnEnter", function(self)
            self:SetBackdropColor(C.bgRowHover:GetRGBA())
            self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
        end)
        selectBtn:SetScript("OnLeave", function(self)
            self:SetBackdropColor(C.bgButton:GetRGBA())
            self:SetBackdropBorderColor(C.border:GetRGBA())
        end)
        CT.groupSelectAll[groupName] = selectBtn

        CT.groupHeaders[groupName] = headerBtn
        childY = childY + 22

        -- Checkbox rows for each context key in this group
        for _, ctxKey in ipairs(group.keys) do
            local row = CreateFrame("Frame", nil, scrollChild)
            row:SetHeight(22)
            row:SetPoint("TOPLEFT", scrollChild, "TOPLEFT", 8, -childY)
            row:SetPoint("RIGHT", scrollChild, "RIGHT", -4, 0)

            -- CheckButton
            local cb = CreateFrame("CheckButton", nil, row, "UICheckButtonTemplate")
            cb:SetSize(22, 22)
            cb:SetPoint("LEFT", row, "LEFT", 0, 0)
            cb._ctxKey = ctxKey
            cb:SetScript("OnClick", function(self)
                CT:OnCheckboxClicked(self._ctxKey, self:GetChecked())
            end)
            row.checkbox = cb

            -- Context label
            local ctxLabel = row:CreateFontString(nil, "OVERLAY")
            UI:SetFont(ctxLabel, 10)
            ctxLabel:SetPoint("LEFT", cb, "RIGHT", 4, 0)
            ctxLabel:SetText(defaults.CONTEXT_LABELS[ctxKey] or ctxKey)
            ctxLabel:SetTextColor(C.textSecondary:GetRGBA())
            row.ctxLabel = ctxLabel

            -- "(Version N)" muted label on the right
            local otherLabel = row:CreateFontString(nil, "OVERLAY")
            UI:SetFont(otherLabel, 9)
            otherLabel:SetPoint("RIGHT", row, "RIGHT", -4, 0)
            otherLabel:SetText("")
            otherLabel:SetTextColor(C.textMuted:GetRGBA())
            row.otherLabel = otherLabel

            row._ctxKey = ctxKey
            row._groupName = groupName

            CT.checkboxRows[ctxKey] = row
            childY = childY + 22
        end

        -- Small gap between groups
        childY = childY + 4
    end

    scrollChild:SetHeight(childY)

    -- Register CONTEXT_CHANGED callback
    if GRIPEMS.RegisterCallback then
        GRIPEMS.RegisterCallback(CT, "CONTEXT_CHANGED", "OnContextChanged")
    end
end

---------------------------------------------------------------------------
-- Checkbox click handler
---------------------------------------------------------------------------

--- Handle a context checkbox being clicked.
--- @param ctxKey string The context key
--- @param checked boolean Whether the checkbox is now checked
function CT:OnCheckboxClicked(ctxKey, checked)
    local SE = GRIPEMS.SequenceEditor
    if not SE or not SE.currentSequence then
        return
    end
    local entry = GRIPEMS.Engine and GRIPEMS.Engine.sequences and GRIPEMS.Engine.sequences[SE.currentSequence]
    if not entry or not entry.data then
        return
    end
    local seqData = entry.data
    seqData.contextOverrides = seqData.contextOverrides or {}

    if checked then
        local existingIdx = seqData.contextOverrides[ctxKey]
        if existingIdx and existingIdx ~= CT.viewingVersionIdx then
            -- Conflict: show StaticPopup
            local defaults = D()
            local dialog = StaticPopupDialogs["GRIPEMS_CONTEXT_CONFLICT"]
            dialog.text = string.format(
                L["GEMS_CONTEXT_CONFLICT_MSG"],
                defaults.CONTEXT_LABELS[ctxKey] or ctxKey,
                existingIdx,
                CT.viewingVersionIdx
            )
            dialog.OnAccept = function()
                seqData.contextOverrides[ctxKey] = CT.viewingVersionIdx
                SE.isDirty = true
                SE:UpdateSaveButtons()
                CT:Refresh()
            end
            dialog.OnCancel = function()
                CT:Refresh() -- revert checkbox visual
            end
            StaticPopup_Show("GRIPEMS_CONTEXT_CONFLICT")
        else
            seqData.contextOverrides[ctxKey] = CT.viewingVersionIdx
            SE.isDirty = true
            SE:UpdateSaveButtons()
            CT:Refresh()
        end
    else
        -- Only uncheck if this context is assigned to the viewed version
        if seqData.contextOverrides[ctxKey] == CT.viewingVersionIdx then
            seqData.contextOverrides[ctxKey] = nil
            SE.isDirty = true
            SE:UpdateSaveButtons()
            CT:Refresh()
        else
            -- Revert: context belongs to a different version
            local defaults = D()
            local ctxLabel = defaults.CONTEXT_LABELS[ctxKey] or ctxKey
            local ovIdx = seqData.contextOverrides[ctxKey]
            UIErrorsFrame:AddMessage(string.format(L["GEMS_CONTEXT_WRONG_VERSION"], ctxLabel, ovIdx), 1.0, 0.5, 0.0)
            CT:Refresh()
        end
    end
end

---------------------------------------------------------------------------
-- Layout and Refresh
---------------------------------------------------------------------------

--- Reposition all group headers and checkbox rows based on collapsed state.
function CT:LayoutGroups()
    if not CT.scrollChild then
        return
    end
    local defaults = D()
    local childY = 0

    for _, group in ipairs(defaults.CONTEXT_GROUPS) do
        local groupName = group.name
        local header = CT.groupHeaders[groupName]
        if not header then
            break
        end

        local collapsed = GetCollapsed()[groupName]

        -- Update header triangle
        if header.label then
            local indicator = collapsed and "> " or "v "
            header.label:SetText(indicator .. header._groupLabel)
        end

        -- Position header
        header:ClearAllPoints()
        header:SetPoint("TOPLEFT", CT.scrollChild, "TOPLEFT", 4, -childY)
        header:SetPoint("RIGHT", CT.scrollChild, "RIGHT", -4, 0)
        header:Show()
        childY = childY + 22

        -- Position or hide checkbox rows
        for _, ctxKey in ipairs(group.keys) do
            local row = CT.checkboxRows[ctxKey]
            if row then
                if collapsed then
                    row:Hide()
                else
                    row:ClearAllPoints()
                    row:SetPoint("TOPLEFT", CT.scrollChild, "TOPLEFT", 8, -childY)
                    row:SetPoint("RIGHT", CT.scrollChild, "RIGHT", -4, 0)
                    row:Show()
                    childY = childY + 22
                end
            end
        end

        childY = childY + 4
    end

    CT.scrollChild:SetHeight(math.max(childY, 1))
end

--- Refresh all context tab content.
function CT:Refresh()
    if not CT.frame then
        return
    end
    local defaults = D()
    local C = UI.Colors
    local Engine = GRIPEMS.Engine
    local SE = GRIPEMS.SequenceEditor

    local entry = SE and SE.currentSequence and Engine and Engine.sequences and Engine.sequences[SE.currentSequence]
    if not entry or not entry.data then
        return
    end

    local seqData = entry.data
    local numVersions = seqData.versions and #seqData.versions or 0

    -- Clamp defaultVersion to valid range
    if seqData.defaultVersion and (seqData.defaultVersion < 1 or seqData.defaultVersion > math.max(numVersions, 1)) then
        seqData.defaultVersion = 1
    end

    -- If fewer than 2 versions, show "no versions" hint
    if numVersions < 2 then
        if CT.noVersionsHint then
            CT.noVersionsHint:Show()
        end
        if CT.scrollFrame then
            CT.scrollFrame:Hide()
        end
        if CT.viewLabel then
            CT.viewLabel:Hide()
        end
        if CT.viewBtn then
            CT.viewBtn:Hide()
        end
        if CT.hintText then
            CT.hintText:Hide()
        end
        if CT.defaultBtn then
            CT.defaultBtn:Hide()
        end
        if CT.fallbackFrame then
            CT.fallbackFrame:Hide()
        end
        -- Still show current context
        if CT.currentLabel then
            local ctx = Engine and Engine.currentContext or "none"
            local displayLabel
            if ctx == "none" then
                displayLabel = L["GEMS_CONTEXT_NONE_LABEL"]
            else
                displayLabel = defaults.CONTEXT_LABELS[ctx] or ctx
            end
            CT.currentLabel:SetText(string.format(L["GEMS_CONTEXT_CURRENT_INFO"], displayLabel))
        end
        return
    end

    -- Show all controls
    if CT.noVersionsHint then
        CT.noVersionsHint:Hide()
    end
    if CT.scrollFrame then
        CT.scrollFrame:Show()
    end
    if CT.viewLabel then
        CT.viewLabel:Show()
    end
    if CT.viewBtn then
        CT.viewBtn:Show()
    end
    if CT.hintText then
        CT.hintText:Show()
    end
    if CT.defaultBtn then
        CT.defaultBtn:Show()
    end
    if CT.fallbackFrame then
        CT.fallbackFrame:Show()
    end

    -- Clamp viewingVersionIdx
    if CT.viewingVersionIdx > numVersions then
        CT.viewingVersionIdx = numVersions
    end
    if CT.viewingVersionIdx < 1 then
        CT.viewingVersionIdx = 1
    end

    -- Update "Current Context" label
    if CT.currentLabel then
        local ctx = Engine and Engine.currentContext or "none"
        local displayLabel
        if ctx == "none" then
            displayLabel = L["GEMS_CONTEXT_NONE_LABEL"]
        else
            displayLabel = defaults.CONTEXT_LABELS[ctx] or ctx
        end
        CT.currentLabel:SetText(string.format(L["GEMS_CONTEXT_CURRENT_INFO"], displayLabel))
    end

    -- Update "Default Version" button
    if CT.defaultBtn and CT.defaultBtn.label then
        CT.defaultBtn.label:SetText(string.format(L["GEMS_CONTEXT_DEFAULT_LABEL"], seqData.defaultVersion or 1))
    end

    -- Update "Assignments for Version N" label
    if CT.viewLabel then
        CT.viewLabel:SetText(string.format(L["GEMS_CONTEXT_VIEWING"], CT.viewingVersionIdx))
    end

    -- Update version selector button (with import origin indicator)
    local isImported = seqData.importMeta ~= nil
    if CT.viewBtn and CT.viewBtn.label then
        local vLabel = "Version " .. CT.viewingVersionIdx
        if isImported then
            vLabel = vLabel .. " |cFF8888AA(imported)|r"
        end
        CT.viewBtn.label:SetText(vLabel)
    end

    -- Update checkboxes
    local overrides = seqData.contextOverrides or {}
    for _, group in ipairs(defaults.CONTEXT_GROUPS) do
        for _, ctxKey in ipairs(group.keys) do
            local row = CT.checkboxRows[ctxKey]
            if row then
                local ovIdx = overrides[ctxKey]
                -- Check if assigned to the viewed version
                if row.checkbox then
                    row.checkbox:SetChecked(ovIdx == CT.viewingVersionIdx)
                end
                -- "(Version N)" label for other-version assignments
                if row.otherLabel then
                    if ovIdx and ovIdx ~= CT.viewingVersionIdx and seqData.versions[ovIdx] then
                        row.otherLabel:SetText(string.format(L["GEMS_CONTEXT_ASSIGNED_OTHER"], ovIdx))
                        if isImported then
                            row.otherLabel:SetTextColor(C.textSecondary:GetRGBA())
                        else
                            row.otherLabel:SetTextColor(C.textMuted:GetRGBA())
                        end
                    else
                        row.otherLabel:SetText("")
                    end
                end
            end
        end
    end

    -- Re-layout groups (handles collapse state)
    CT:LayoutGroups()

    -- Update scroll child width
    if CT.scrollFrame and CT.scrollChild then
        local w = CT.scrollFrame:GetWidth()
        if w and w > 0 then
            CT.scrollChild:SetWidth(w)
        end
    end

    -- Refresh fallback chain indicator
    CT:RefreshFallbackChain()
end

---------------------------------------------------------------------------
-- Fallback chain visualization
---------------------------------------------------------------------------

--- Refresh the visual fallback chain indicator.
function CT:RefreshFallbackChain()
    if not CT.fallbackFrame then
        return
    end
    local C = UI.Colors
    local defaults = D()
    local Engine = GRIPEMS.Engine
    local SE = GRIPEMS.SequenceEditor

    -- Clear previous labels
    for _, lbl in ipairs(CT.fallbackLabels) do
        lbl:Hide()
        lbl:SetText("")
    end

    local entry = SE and SE.currentSequence and Engine and Engine.sequences and Engine.sequences[SE.currentSequence]
    if not entry or not entry.data then
        return
    end
    local seqData = entry.data
    local overrides = seqData.contextOverrides or {}
    local ctx = Engine and Engine.currentContext or "none"

    -- No active context
    if ctx == "none" then
        local lbl = CT.fallbackLabels[1]
        if not lbl then
            lbl = CT.fallbackFrame:CreateFontString(nil, "OVERLAY")
            UI:SetFont(lbl, 9)
            CT.fallbackLabels[1] = lbl
        end
        lbl:SetPoint("LEFT", CT.fallbackFrame, "LEFT", 0, 0)
        lbl:SetTextColor(C.textMuted:GetRGBA())
        lbl:SetText(string.format(L["GEMS_CONTEXT_FALLBACK_NONE"], seqData.defaultVersion or 1))
        lbl:Show()
        return
    end

    -- Build chain: current context + fallbacks + Default
    local chain = { ctx }
    local fallbacks = defaults.CONTEXT_FALLBACKS[ctx]
    if fallbacks then
        for _, fb in ipairs(fallbacks) do
            chain[#chain + 1] = fb
        end
    end
    chain[#chain + 1] = "Default"

    -- Find the first match in the chain
    local matchIdx = nil
    local matchVersion = nil
    for i, key in ipairs(chain) do
        if key == "Default" then
            matchIdx = i
            matchVersion = seqData.defaultVersion or 1
            break
        elseif overrides[key] then
            matchIdx = i
            matchVersion = overrides[key]
            break
        end
    end
    if not matchIdx then
        matchIdx = #chain
        matchVersion = seqData.defaultVersion or 1
    end

    -- Render chain labels with separators
    local sep = L["GEMS_CONTEXT_FALLBACK_SEP"]
    local frameWidth = CT.fallbackFrame:GetWidth()
    if frameWidth <= 0 then
        frameWidth = 400
    end
    local labelIdx = 0
    local totalWidth = 0
    local truncated = false

    for i, key in ipairs(chain) do
        -- Check if we need truncation (skip middle entries if too wide)
        if not truncated or i == matchIdx or i == #chain then
            -- Separator before non-first entries
            if labelIdx > 0 then
                labelIdx = labelIdx + 1
                local sepLbl = CT.fallbackLabels[labelIdx]
                if not sepLbl then
                    sepLbl = CT.fallbackFrame:CreateFontString(nil, "OVERLAY")
                    UI:SetFont(sepLbl, 9)
                    CT.fallbackLabels[labelIdx] = sepLbl
                end
                sepLbl:SetTextColor(C.textMuted:GetRGBA())
                sepLbl:SetText(sep)
                if labelIdx == 1 then
                    sepLbl:SetPoint("LEFT", CT.fallbackFrame, "LEFT", 0, 0)
                else
                    sepLbl:SetPoint("LEFT", CT.fallbackLabels[labelIdx - 1], "RIGHT", 0, 0)
                end
                sepLbl:Show()
                totalWidth = totalWidth + sepLbl:GetStringWidth()
            end

            labelIdx = labelIdx + 1
            local lbl = CT.fallbackLabels[labelIdx]
            if not lbl then
                lbl = CT.fallbackFrame:CreateFontString(nil, "OVERLAY")
                UI:SetFont(lbl, 9)
                CT.fallbackLabels[labelIdx] = lbl
            end

            -- Build display text
            local displayName
            if key == "Default" then
                displayName = L["GEMS_CONTEXT_FALLBACK_DEFAULT"]
            else
                displayName = defaults.CONTEXT_LABELS[key] or key
            end

            -- Append version suffix for matched entry and Default
            if i == matchIdx then
                displayName = displayName .. string.format(L["GEMS_CONTEXT_FALLBACK_MATCH"], matchVersion)
            elseif key == "Default" then
                displayName = displayName
                    .. string.format(L["GEMS_CONTEXT_FALLBACK_MATCH"], seqData.defaultVersion or 1)
            end

            lbl:SetText(displayName)

            -- Color based on position relative to match
            if i == matchIdx then
                local gr, gg, gb = C.statusGreen and C.statusGreen:GetRGB() or 0.2, 0.8, 0.2
                if C.statusGreen then
                    gr, gg, gb = C.statusGreen:GetRGB()
                end
                lbl:SetTextColor(gr, gg, gb, 1)
            elseif i < matchIdx then
                lbl:SetTextColor(C.textSecondary:GetRGBA())
            else
                lbl:SetTextColor(C.textMuted:GetRGBA())
            end

            if labelIdx == 1 then
                lbl:SetPoint("LEFT", CT.fallbackFrame, "LEFT", 0, 0)
            else
                lbl:SetPoint("LEFT", CT.fallbackLabels[labelIdx - 1], "RIGHT", 0, 0)
            end
            lbl:Show()
            totalWidth = totalWidth + lbl:GetStringWidth()

            -- Check if we need to start truncating
            if not truncated and totalWidth > frameWidth * 0.7 and i < matchIdx - 1 then
                truncated = true
                -- Insert ellipsis
                labelIdx = labelIdx + 1
                local ellipsis = CT.fallbackLabels[labelIdx]
                if not ellipsis then
                    ellipsis = CT.fallbackFrame:CreateFontString(nil, "OVERLAY")
                    UI:SetFont(ellipsis, 9)
                    CT.fallbackLabels[labelIdx] = ellipsis
                end
                ellipsis:SetText(sep .. "..." .. sep)
                ellipsis:SetTextColor(C.textMuted:GetRGBA())
                ellipsis:SetPoint("LEFT", CT.fallbackLabels[labelIdx - 1], "RIGHT", 0, 0)
                ellipsis:Show()
                totalWidth = totalWidth + ellipsis:GetStringWidth()
            end
        end
    end
end

---------------------------------------------------------------------------
-- Show / Hide / Data flow
---------------------------------------------------------------------------

--- Show the context tab.
function CT:Show()
    if CT.frame then
        CT.frame:Show()
    end
    -- Default to SE.activeVersionIndex when tab is opened
    local SE = GRIPEMS.SequenceEditor
    if SE then
        CT.viewingVersionIdx = SE.activeVersionIndex or 1
    end
    CT:Refresh()
end

--- Hide the context tab.
function CT:Hide()
    if CT.frame then
        CT.frame:Hide()
    end
end

--- Clear the context tab state.
function CT:Clear()
    CT.viewingVersionIdx = 1
end

---------------------------------------------------------------------------
-- Callback handler
---------------------------------------------------------------------------

--- Respond to CONTEXT_CHANGED events.
function CT:OnContextChanged()
    if CT.frame and CT.frame:IsShown() then
        CT:Refresh()
    end
end
