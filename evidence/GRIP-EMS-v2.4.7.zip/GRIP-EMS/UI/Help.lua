-- GRIP-EMS: Help (Accessibility Popovers)
-- Created: 2026-04-21
-- Updated: 2026-08-17
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
--
-- In-frame contextual help popover for the Sequence Editor. A single
-- ? button in the SE tabBar opens this popover with a short title
-- and body describing the currently active tab. Palette-aware
-- (UI:OnPaletteChanged) and reduce-motion-aware
-- (accessibility.reduceMotion). Keyboard accessible: ESC closes the
-- popover. Standalone module -- does not share the Tutorial.lua
-- popover primitive in this pass.

local ADDON_NAME, GRIPEMS = ...

GRIPEMS.Help = {}
local H = GRIPEMS.Help

GRIPEMS.UI = GRIPEMS.UI or {}
local UI = GRIPEMS.UI
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)
local C = UI.Colors

H._popover = nil
H._activeSection = nil

-- Map internal tab names (matches SequenceEditor tabDefs) to locale
-- key pairs. Unknown sections fall back to DEFAULT.
local SECTION_MAP = {
    Steps = { title = "ACCESS_HELP_TITLE_STEPS", body = "ACCESS_HELP_BODY_STEPS" },
    Keybind = { title = "ACCESS_HELP_TITLE_KEYBIND", body = "ACCESS_HELP_BODY_KEYBIND" },
    Macros = { title = "ACCESS_HELP_TITLE_MACROS", body = "ACCESS_HELP_BODY_MACROS" },
    Context = { title = "ACCESS_HELP_TITLE_CONTEXT", body = "ACCESS_HELP_BODY_CONTEXT" },
    Variables = { title = "ACCESS_HELP_TITLE_VARIABLES", body = "ACCESS_HELP_BODY_VARIABLES" },
    Raw = { title = "ACCESS_HELP_TITLE_RAW", body = "ACCESS_HELP_BODY_RAW" },
    Picker = { title = "ACCESS_HELP_TITLE_PICKER", body = "ACCESS_HELP_BODY_PICKER" },
}
local DEFAULT_KEYS = { title = "ACCESS_HELP_TITLE_DEFAULT", body = "ACCESS_HELP_BODY_DEFAULT" }

-- Palette: mutate in place via SetRGBA so HighContrast and
-- DeuteranopiaSafe recolour without a reload.
local function applyPalette(p)
    if not p then
        return
    end
    local bg = C.bgDeep or C.bgRowSelected or C.bgMain
    if p.SetBackdropColor and bg then
        p:SetBackdropColor(bg:GetRGBA())
    end
    if p.SetBackdropBorderColor and C.border then
        p:SetBackdropBorderColor(C.border:GetRGBA())
    end
    if p.title and C.textPrimary then
        p.title:SetTextColor(C.textPrimary:GetRGBA())
    end
    if p.body and C.textPrimary then
        p.body:SetTextColor(C.textPrimary:GetRGBA())
    end
end

local function reduceMotion()
    local S = GRIPEMS.Settings
    if not (S and S.Get) then
        return false
    end
    local a = S:Get("accessibility")
    return type(a) == "table" and a.reduceMotion and true or false
end

local function buildPopover()
    if H._popover then
        return H._popover
    end
    local p = CreateFrame("Frame", "GRIPEMS_HelpPopover", UIParent, "BackdropTemplate")
    p:SetFrameStrata("TOOLTIP")
    p:SetFrameLevel(101)
    p:SetSize(340, 160)
    p:SetClampedToScreen(true)
    p:EnableMouse(true)
    p:Hide()
    if GRIPEMS.UI and GRIPEMS.UI.RegisterPanelFrame then
        GRIPEMS.UI:RegisterPanelFrame(p, "panel", "panel.help")
    end
    if not tContains(UISpecialFrames, "GRIPEMS_HelpPopover") then
        tinsert(UISpecialFrames, "GRIPEMS_HelpPopover")
    end
    UI:ApplyBackdrop(p, UI.Backdrops.panel, C.bgDeep or C.bgRowSelected, C.border)

    local title = p:CreateFontString(nil, "OVERLAY")
    UI:SetFont(title, 14, "OUTLINE")
    title:SetPoint("TOPLEFT", p, "TOPLEFT", 12, -12)
    title:SetPoint("TOPRIGHT", p, "TOPRIGHT", -32, -12)
    title:SetJustifyH("LEFT")
    title:SetTextColor(C.textPrimary:GetRGBA())
    p.title = title

    local body = p:CreateFontString(nil, "OVERLAY")
    UI:SetFont(body, 12)
    body:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -8)
    body:SetWidth(300)
    body:SetJustifyH("LEFT")
    body:SetJustifyV("TOP")
    body:SetWordWrap(true)
    body:SetNonSpaceWrap(true)
    body:SetTextColor(C.textPrimary:GetRGBA())
    p.body = body

    local closeX = CreateFrame("Button", nil, p, "UIPanelCloseButton")
    closeX:SetPoint("TOPRIGHT", p, "TOPRIGHT", -2, -2)
    closeX:SetScript("OnClick", function()
        H:Hide()
    end)
    p.closeX = closeX

    p:EnableKeyboard(true)
    p:SetScript("OnKeyDown", function(self, key)
        if key == "ESCAPE" then
            H:Hide()
            pcall(self.SetPropagateKeyboardInput, self, false)
            return
        end
        pcall(self.SetPropagateKeyboardInput, self, true)
    end)

    p:SetScript("OnHide", function()
        H._activeSection = nil
    end)

    if UI.OnPaletteChanged then
        UI:OnPaletteChanged(function()
            if H._popover then
                applyPalette(H._popover)
            end
        end)
    end

    H._popover = p
    return p
end

local function showWithMotion(p)
    local target = (GRIPEMS.UI and GRIPEMS.UI.GetPanelAlpha and GRIPEMS.UI:GetPanelAlpha()) or 1.0
    p:SetAlpha(0)
    p:Show()
    if reduceMotion() then
        p:SetAlpha(target)
        return
    end
    if type(UIFrameFadeIn) == "function" then
        UIFrameFadeIn(p, 0.12, 0, target)
    else
        p:SetAlpha(target)
    end
end

--- Show the help popover for a given tab section, anchored below
--- the provided anchorFrame. Unknown sectionKey falls back to the
--- DEFAULT locale pair.
--- @param sectionKey string|nil Internal tab name
--- @param anchorFrame Frame|nil Frame to anchor TOPRIGHT below
function H:Show(sectionKey, anchorFrame)
    local p = buildPopover()
    local keys = (sectionKey and SECTION_MAP[sectionKey]) or DEFAULT_KEYS
    p.title:SetText(L[keys.title] or "")
    p.body:SetText(L[keys.body] or "")

    p:ClearAllPoints()
    if anchorFrame then
        p:SetPoint("TOPRIGHT", anchorFrame, "BOTTOMRIGHT", 0, -6)
    else
        p:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    end

    applyPalette(p)
    H._activeSection = sectionKey
    showWithMotion(p)
end

--- Hide the help popover.
function H:Hide()
    if H._popover then
        H._popover:Hide()
    end
    H._activeSection = nil
end

--- Toggle: hide if already showing the same section, otherwise show.
--- @param sectionKey string|nil
--- @param anchorFrame Frame|nil
function H:Toggle(sectionKey, anchorFrame)
    if H._popover and H._popover:IsShown() and H._activeSection == sectionKey then
        H:Hide()
    else
        H:Show(sectionKey, anchorFrame)
    end
end
