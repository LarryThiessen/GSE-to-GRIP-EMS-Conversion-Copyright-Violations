-- GRIP-EMS: Per-Element Theming editor -- class tree builder (Phase B)
--
-- Created:    2026-04-22
-- Updated:    2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.
--
-- Declares the shared UI.ThemingEditor namespace (first loader wins) and
-- builds the 7-group AceConfig args table for the Paradigm B settings-tree
-- editor. Groups mirror the class-prefix axis of UI.ELEMENT_CLASSES; each
-- leaf is produced by UI.ThemingEditor.BuildClassArgs defined in
-- UI/ThemingEditor/ClassEditor.lua (loaded after this file).
--
-- Loads first in the UI/ThemingEditor/ block so subsequent editor files can
-- add fields to the namespace table without re-declaring it.

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

GRIPEMS.UI = GRIPEMS.UI or {}
local UI = GRIPEMS.UI
UI.ThemingEditor = UI.ThemingEditor or {}
local TE = UI.ThemingEditor

---------------------------------------------------------------------------
-- FormatClassLabel splits a class key on "." and Title-Cases each segment.
-- "panel.sequenceEditor" -> "Panel: Sequence Editor"
-- "emphasis.focusRing"   -> "Emphasis: Focus Ring"
-- "global.addonFont"     -> "Global: Addon Font"
---------------------------------------------------------------------------
local function titlize(segment)
    if type(segment) ~= "string" or segment == "" then
        return tostring(segment)
    end
    local spaced = segment:gsub("(%l)(%u)", "%1 %2")
    local out = spaced:gsub("(%a)(%w*)", function(first, rest)
        return first:upper() .. rest
    end)
    return out
end

function TE.FormatClassLabel(class)
    if type(class) ~= "string" or class == "" then
        return tostring(class)
    end
    local parts = {}
    for seg in class:gmatch("[^%.]+") do
        parts[#parts + 1] = titlize(seg)
    end
    if #parts == 0 then
        return class
    end
    if #parts == 1 then
        return parts[1]
    end
    local tail = {}
    for i = 2, #parts do
        tail[#tail + 1] = parts[i]
    end
    return parts[1] .. ": " .. table.concat(tail, " ")
end

---------------------------------------------------------------------------
-- GROUP_META is the display order of the 7 group nodes. The prefix matches
-- the substring before the first "." in a class key.
---------------------------------------------------------------------------
local GROUP_META = {
    { prefix = "panel", key = "ACCESS_THEMING_GROUP_PANELS", order = 10 },
    { prefix = "overlay", key = "ACCESS_THEMING_GROUP_OVERLAYS", order = 11 },
    { prefix = "row", key = "ACCESS_THEMING_GROUP_ROWS", order = 12 },
    { prefix = "button", key = "ACCESS_THEMING_GROUP_BUTTONS", order = 13 },
    { prefix = "text", key = "ACCESS_THEMING_GROUP_TEXT", order = 14 },
    { prefix = "emphasis", key = "ACCESS_THEMING_GROUP_EMPHASIS", order = 15 },
    { prefix = "global", key = "ACCESS_THEMING_GROUP_GLOBAL", order = 16 },
}

local function classGroup(class)
    if type(class) ~= "string" then
        return nil
    end
    local dot = class:find("%.")
    if not dot then
        return class
    end
    return class:sub(1, dot - 1)
end

local function leafKey(class)
    return (class:gsub("%.", "_"))
end

---------------------------------------------------------------------------
-- BuildOptionsTree returns 7 group nodes keyed by class-prefix. Each group
-- contains leaf nodes -- one per class in UI.ELEMENT_CLASSES matching that
-- prefix -- produced by UI.ThemingEditor.BuildClassArgs.
--
-- Returned shape merges directly into the Accessibility subpanel args via
-- BuildSettingsPanelArgs. No wrapping container; the 7 group entries live
-- alongside preset / slots / importExport / footer in the final args table.
---------------------------------------------------------------------------
function TE.BuildOptionsTree()
    local classes = UI.ELEMENT_CLASSES or {}
    local args = {}
    for _, meta in ipairs(GROUP_META) do
        local leafArgs = {}
        local leafOrder = 1
        for i = 1, #classes do
            local class = classes[i]
            if classGroup(class) == meta.prefix then
                -- Closes A11Y-THEME-GHOST-CLASSES: forward-declared classes
                -- with no bound widget (overlay.toast.info / .error,
                -- overlay.tooltip, panel.profileMgr in v1.9.9) stay in
                -- UI.ELEMENT_CLASSES as design-doc / future-binding intent
                -- but do not appear in the editor picker. When a widget
                -- later calls UI:RegisterElement under that class,
                -- _classWidgets[class] becomes non-empty and the entry
                -- auto-appears in the picker on next BuildOptionsTree
                -- pass -- no taxonomy change required.
                local widgets = UI._classWidgets and UI._classWidgets[class]
                if widgets and next(widgets) ~= nil then
                    local leaf = TE.BuildClassArgs and TE.BuildClassArgs(class) or nil
                    if leaf then
                        leaf.order = leafOrder
                        leafArgs[leafKey(class)] = leaf
                        leafOrder = leafOrder + 1
                    end
                end
            end
        end
        args[meta.prefix] = {
            type = "group",
            name = L[meta.key] or meta.key,
            order = meta.order,
            args = leafArgs,
        }
    end
    return args
end

TE._classGroup = classGroup
TE._leafKey = leafKey

-- end of UI/ThemingEditor/Tree.lua
