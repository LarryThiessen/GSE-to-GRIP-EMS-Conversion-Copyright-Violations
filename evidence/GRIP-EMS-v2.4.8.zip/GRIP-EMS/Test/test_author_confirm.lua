-- GRIP-EMS: Headless test for the author confirmation
--
-- Created:    2026-08-25
-- Updated:    2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.
--
-- Standalone (Lua 5.1) test for the rule that a sequence the local player did
-- not write does not leave this client until the player says so.
--
-- Three outcomes, in this order, for any sequence about to leave:
--   1) the author marked it do-not-share  -> REFUSE, no prompt
--   2) the local player did not author it -> ASK, send only on confirm
--   3) the local player authored it       -> send, no prompt
--
-- Run from the EMS root:  lua Test/test_author_confirm.lua
-- Exit code 0 = all passed, 1 = at least one failure.
--
-- WHY THE POPUP STUB DOES NOT AUTO-ACCEPT. The sibling harness
-- (test_variable_sandbox_and_noredistribute.lua) stubs GRIPEMS.Popup so that
-- Show fires OnAccept inline, which is right for the case IT covers -- a user
-- who clicks through a repair warning still sends. It also means that harness
-- cannot tell "asked, and the player said yes" apart from "not asked at all".
-- This one records the show instead and fires the callbacks by hand, so the
-- gap between the request arriving and the player answering is observable.
-- That gap is the entire feature.
--
-- Cases:
--   A1  GE.IsLocallyAuthored is true for a sequence stamped with the current
--       identity hash, false for another account's hash, false for an empty
--       string, and false when the identity is unavailable. The last is the
--       FAIL-CLOSED case, and closed here means ASK, not refuse
--   A2  GE.NeedsAuthorConfirm is TRUE for a foreign-authored sequence and
--       FALSE for a locally authored one
--   A3  GE.NeedsAuthorConfirm is FALSE for a do-not-share sequence, because it
--       is refused outright and never reaches a prompt. The ORDERING case
--   A4  legacy-sourced content, originalAuthorIdentity "", needs confirm, and
--       the author string the prompt will show is the stored one -- except the
--       converter's unknown-author placeholder, which names the source addon
--       and so resolves to the label instead
--   A5  THE LOAD-BEARING ONE. The REAL CMD_REQUEST handler, driven through
--       T:HandleReceive the way a remote player drives it, with a
--       foreign-authored sequence: NO comm message before confirmation, and
--       the sequence IS sent once the popup's confirm handler runs. A case
--       that only checked the predicate would prove nothing about the handler
--   A6  the same request, CANCELLED: no comm message is ever emitted
--   A7  a locally authored sequence is still answered automatically, with no
--       prompt at all. The control that stops this change breaking ordinary
--       sharing
--   A8  a second inbound request while a prompt is open does NOT open a second
--       popup, and sends nothing
--   A9  T:SendListResponse omits a foreign-authored sequence, mirroring N6 in
--       the sibling harness
--
-- Added beyond the brief, because EDIT 5 shipped both behaviours and neither
-- would otherwise be covered anywhere:
--  A10  the per-sender prompt cooldown: a second request from the SAME sender
--       inside the window raises no prompt, one from a DIFFERENT sender does,
--       and the same sender is heard again once the window passes
--  A11  IN COMBAT a request for a foreign-authored sequence raises no prompt
--       and sends nothing, and prints one line to the owner
--
-- A fork of someone else's work is still someone else's work. Identity:
-- StampForked re-stamps a copy with THIS account, which is correct -- identity
-- and signature follow whoever re-signed -- and was being read as "the local
-- player wrote it". These four drive the REAL StampForked:
--  A12  a fork of FOREIGN work needs confirming even though the stamp is local
--  A13  CONTROL: a fork of the player's OWN sequence does NOT, asserted through
--       the request handler as well as the predicate. Without it the fix could
--       pass by prompting on every fork, which is worse than the hole
--  A14  multi-hop: fork someone else's work, then fork your own fork. The
--       IMMEDIATE parent is local and only forkedFromChain still names the
--       foreign root, so a forkedFrom-only fix would wave it through
--  A15  an ancestor with an EMPTY identity needs confirming, as does one whose
--       ancestry field is present but unreadable; an EMPTY chain does not
--
-- Naming the real author, and the two writes that could forge one:
--  A16  a duplicate of foreign work reports the SOURCE author from
--       GE.CollectForeignAuthors, not the local re-stamp
--  A17  multi-hop reports the ROOT author, not the local immediate parent
--  A18  CONTROL: a sequence foreign by its OWN stamp still reports its own
--       byline, unchanged from before this phase, including the author fallback
--  A19  an unusable ancestor name falls back to the unknown label and NEVER to
--       the local player -- empty byline, unreadable lineage, and a CRAFTED
--       ancestor carrying the victim's own name against a foreign identity
--  A20  GE.ImportNative blanks an inbound originalAuthorIdentity that equals
--       the receiver's hash, so the stored copy still needs confirming
--  A21  CONTROL: ImportNative preserves an identity that is NOT the receiver's,
--       so ordinary sharing still records and names the true author
--
-- The last route in, and the two controls that keep the gate honest:
--  A22  a BYLINELESS inbound payload, through the real GE.ImportNative, lands
--       marked "no-provenance" and STILL needs confirming after a first save.
--       The editors cannot be stood up here, so the save branch is REPLICATED
--       and anchored against the shipped source in both editor files
--  A23  CONTROL: a genuinely new local sequence still gets its first-save
--       stamp. Without it the fix could pass by never stamping anything
--  A24  CONTROL: the fork path still works -- StampForked calls StampOriginal
--       itself, so a duplicate carries the local stamp and is held foreign by
--       ancestry alone. The case EDIT 2 was most likely to break
--  A25  the OTHER import rail, BuildSeqDataFromGRIP1 in ImportPreview.lua,
--       marks a bylineless payload too. Found by measurement after A22 was
--       green: that rail is what LI.CommitSelected uses, so it is how a pasted
--       string and a received transmission are actually committed, and it had
--       the identical fall-through. SPLICED from the shipped source, with both
--       existing provenance arms asserted as controls
--
-- NON-VACUITY. Run with GEMS_TEST_STUB_NEEDSCONFIRM=1 in the environment and
-- GE.NeedsAuthorConfirm is forced to false immediately after the modules load,
-- which is the shape of "the confirmation was never wired in". A5, A6, A8, A10
-- and A11 must FAIL in that run and A7 must stay green. A run in which A5 or A6
-- passes with the predicate stubbed out is measuring nothing.
--
-- That switch does NOT prove A12 to A15, because it stubs the wrong predicate:
-- it forces the ANSWER false rather than removing the ancestry test that
-- produces it, so A13 -- which expects false -- would pass either way. The
-- proof for those four is to delete the ancestry block from
-- GE.IsLocallyAuthored in a COPY of the tree and re-run: A12, A14 and A15 must
-- fail and A13 must stay green. Measured 2026-08-25, exactly that.

-- ---------------------------------------------------------------------------
-- Minimal assertion + runner harness.
-- ---------------------------------------------------------------------------

local passed, failed = 0, 0

local function test(name, fn)
    local ok, err = pcall(fn)
    if ok then
        passed = passed + 1
        print("PASS  " .. name)
    else
        failed = failed + 1
        print("FAIL  " .. name)
        print("      " .. tostring(err))
    end
end

local function assertEqual(expected, actual, label)
    if expected ~= actual then
        error((label or "assertEqual") .. ": expected " .. tostring(expected) .. ", got " .. tostring(actual), 2)
    end
end

local function assertTrue(cond, label)
    if not cond then
        error((label or "assertTrue") .. " failed", 2)
    end
end

local function assertNil(actual, label)
    if actual ~= nil then
        error((label or "assertNil") .. ": expected nil, got " .. tostring(actual), 2)
    end
end

-- ---------------------------------------------------------------------------
-- Mutable client state the cases drive.
-- ---------------------------------------------------------------------------

-- A frozen clock the cases advance by hand. The prompt cooldown compares
-- time() against a stored stamp, so A10 needs to move the clock rather than
-- wait; every other case leaves it alone and gets deterministic behaviour.
local clock = 1000
local inCombat = false

local frameStub = {}
frameStub.RegisterEvent = function() end
frameStub.UnregisterEvent = function() end
frameStub.UnregisterAllEvents = function() end
frameStub.SetScript = function() end
frameStub.Hide = function() end
frameStub.Show = function() end

local WOW_GLOBALS = {
    CreateFrame = function()
        return frameStub
    end,
    GetLocale = function()
        return "enUS"
    end,
    UnitName = function()
        return "Sataana"
    end,
    UnitClass = function()
        return "Mage", "MAGE", 8
    end,
    GetBuildInfo = function()
        return "12.0.7", "68453", nil, 120007
    end,
    GetMacroIndexByName = function()
        return 0
    end,
    GetMacroInfo = function()
        return nil
    end,
    GetNumMacros = function()
        return 0, 0
    end,
    InCombatLockdown = function()
        return inCombat
    end,
    Ambiguate = function(name)
        return (tostring(name):gsub("%-.*$", ""))
    end,
    GetNormalizedRealmName = function()
        return "TestRealm"
    end,
    IsInGroup = function()
        return false
    end,
    IsInRaid = function()
        return false
    end,
    -- The surface Engine/Identity.lua reaches for, added when A12 to A15 began
    -- driving the REAL I:StampForked. Nothing else in this file reads any of
    -- them. BNGetInfo returning a tag is load-bearing for I:GetCurrent's
    -- source == "battletag" branch, though every case here compares hashes
    -- through the override installed after the module load rather than through
    -- whichever branch produced them.
    GetRealmName = function()
        return "TestRealm"
    end,
    UnitFactionGroup = function()
        return "Alliance", "Alliance"
    end,
    GetCurrentRegion = function()
        return 3
    end,
    BNGetInfo = function()
        return 1, "Tester#1234"
    end,
    C_AddOns = {
        IsAddOnLoaded = function()
            return false
        end,
        GetAddOnMetadata = function()
            return nil
        end,
    },
    C_Timer = {
        After = function() end,
    },
    -- T:PrintChatLink writes into this UNGUARDED on a successful send.
    DEFAULT_CHAT_FRAME = {
        AddMessage = function() end,
    },
}

local env = setmetatable({}, {
    __index = function(_, k)
        local v = rawget(_G, k)
        if v ~= nil then
            return v
        end
        return WOW_GLOBALS[k]
    end,
})
env._G = env
env.strlower = string.lower
env.strtrim = function(s)
    return (tostring(s):gsub("^%s+", ""):gsub("%s+$", ""))
end
env.GetTime = function()
    return clock
end
env.wipe = function(t)
    for k in pairs(t) do
        t[k] = nil
    end
    return t
end
env.time = function()
    return clock
end
-- Identity's roster stamps a human-readable date. Echoes the format string,
-- which is all any case here needs it to do.
env.date = function(fmt)
    return tostring(fmt)
end

-- Real enUS values, loaded the way the addon loads them, with an echo fallback
-- so a key absent from enUS.lua returns the key rather than nil.
local LOADED_LOCALE = {}
local LOCALE = setmetatable({}, {
    __index = function(_, k)
        return LOADED_LOCALE[k] or k
    end,
})

env.LibStub = function()
    return {
        GetLocale = function()
            return LOCALE
        end,
        NewLocale = function()
            return LOADED_LOCALE
        end,
    }
end

-- ---------------------------------------------------------------------------
-- The addon namespace stub.
-- ---------------------------------------------------------------------------

local printLog = {}
local sentMessages = {}

local LOCAL_IDENTITY_HASH = "HASH-THIS-ACCOUNT"
local OTHER_IDENTITY_HASH = "HASH-SOME-OTHER-ACCOUNT"

-- Recording popup stub. Show parks the name; the callbacks are fired by hand.
-- Button order mirrors Core/Popup.lua: the handler runs FIRST and the frame is
-- hidden AFTER it, so a callback that re-enters the send sees the popup still
-- shown, exactly as it would in the client.
local Popup = {
    defs = {},
    shownName = nil,
    showCount = 0,
}
function Popup:Define(name, def)
    self.defs[name] = def
end
function Popup:GetDef(name)
    self.defs[name] = self.defs[name] or {}
    return self.defs[name]
end
function Popup:Show(name)
    self.shownName = name
    self.showCount = self.showCount + 1
    return true
end
function Popup:Hide(name)
    if name == nil or self.shownName == name then
        self.shownName = nil
    end
end
function Popup:IsShown(name)
    if not self.shownName then
        return false
    end
    if name == nil then
        return true
    end
    return self.shownName == name
end

--- Press the confirm button on whatever popup is currently shown.
local function pressConfirm()
    local name = Popup.shownName
    assertTrue(name ~= nil, "pressConfirm called with no popup shown")
    local def = Popup.defs[name]
    assertTrue(def ~= nil and type(def.OnAccept) == "function", "the shown popup must carry an OnAccept")
    def.OnAccept()
    Popup:Hide(name)
end

--- Press the cancel button on whatever popup is currently shown.
local function pressCancel()
    local name = Popup.shownName
    assertTrue(name ~= nil, "pressCancel called with no popup shown")
    local def = Popup.defs[name]
    assertTrue(def ~= nil and type(def.OnCancel) == "function", "the shown popup must carry an OnCancel")
    def.OnCancel()
    Popup:Hide(name)
end

local GRIPEMS = {
    version = "test",
    Debug = function() end,
    Print = function(_, msg)
        printLog[#printLog + 1] = tostring(msg)
    end,
    Fire = function() end,
    SendCommMessage = function(_, _, encoded, channel, target)
        sentMessages[#sentMessages + 1] = { encoded = encoded, channel = channel, target = target }
    end,
    NormalizeUpdatedAt = function(v)
        return tonumber(v) or 0
    end,
    Engine = {
        sequences = {},
        GetActiveVersion = function(_, seqData)
            if not seqData or type(seqData.versions) ~= "table" then
                return nil
            end
            return seqData.versions[seqData.defaultVersion or 1] or seqData.versions[1]
        end,
    },
    SpellCache = {
        ready = true,
        GetSpellID = function()
            return nil
        end,
        RecoverHandleTokensInText = function(_, text)
            return text
        end,
        TranslateMacrotext = function(_, text)
            return text
        end,
        NormalizeVersionLocale = function() end,
    },
    Settings = {
        Get = function()
            return true
        end,
    },
    SpellValidator = {
        ValidateStep = function()
            return { spells = {}, tooltipSpells = {}, hasVariable = false }
        end,
        ExtractAllSpells = function()
            return {}
        end,
    },
    MacroManager = {
        stubs = {},
        TruncateName = function(_, name)
            return name
        end,
    },
    Popup = Popup,
    Serialization = {},
}

-- The identity every case reads through GE.IsLocallyAuthored.
--
-- GetCurrent and AppendModifierEntry only. No BuildExportPayload: GE.Export
-- would then run its privacy scrub, which is a different module's behaviour and
-- has its own coverage.
--
-- STILL A STUB even though the REAL Engine/Identity.lua is now loaded for
-- A12 to A15. The module is loaded, captured, and then this stub is put BACK on
-- GRIPEMS.Identity -- see the RealIdentity block after the module loop. Keeping
-- the published namespace on the stub is what makes A12 to A15 additive: A1 to
-- A11 read exactly the surface they were written against, and GE.Export keeps
-- the exact path it was measured on.
local function currentIdentity()
    return {
        displayName = "Sataana",
        identityHash = LOCAL_IDENTITY_HASH,
        realm = "TestRealm",
        source = "battletag",
    }
end

local IDENTITY_STUB = {
    GetCurrent = currentIdentity,
    AppendModifierEntry = function() end,
}
GRIPEMS.Identity = IDENTITY_STUB

env.GRIPEMS = GRIPEMS
env.GRIP_EMS_DB = { variables = {}, config = {} }
_G.GRIPEMS = GRIPEMS

-- Registry-backed Serialization stub: Encode parks the table and returns
-- "<prefix>#<index>"; Decode resolves the index back.
local REGISTRY = {}
local PREFIX_ORDER = { "GEMSCP1_PREFIX", "GRIP1_PREFIX", "GSE3_ENCRYPTED_PREFIX", "FRG1_PREFIX", "EMS1_PREFIX" }
local FORMAT_OF = {
    GEMSCP1_PREFIX = "GEMSCP1",
    GRIP1_PREFIX = "GRIP1",
    GSE3_ENCRYPTED_PREFIX = "GSE3ENC",
    FRG1_PREFIX = "FRG1",
    EMS1_PREFIX = "EMS1",
}

local function matchPrefix(str)
    local DD = GRIPEMS.Defaults
    for _, key in ipairs(PREFIX_ORDER) do
        local prefix = DD and DD[key]
        if prefix and str:sub(1, #prefix) == prefix then
            return key, prefix
        end
    end
    return nil
end

GRIPEMS.Serialization = {
    Encode = function(tbl, prefix)
        REGISTRY[#REGISTRY + 1] = tbl
        return true, prefix .. "#" .. tostring(#REGISTRY)
    end,
    Decode = function(str)
        local key, prefix = matchPrefix(str)
        if not key then
            return false, "Unknown format"
        end
        local idx = tonumber(str:sub(#prefix + 2))
        local tbl = idx and REGISTRY[idx]
        if not tbl then
            return false, "Decode failed"
        end
        return true, tbl, FORMAT_OF[key]
    end,
    DetectFormat = function(str)
        local key = matchPrefix(str)
        return key and FORMAT_OF[key] or nil
    end,
}

-- ---------------------------------------------------------------------------
-- Load the REAL modules into the sandbox.
-- ---------------------------------------------------------------------------

local function loadModule(candidates)
    for _, path in ipairs(candidates) do
        -- loadfile is dev-harness file I/O, intentionally outside the addon WoW std.
        -- selene: allow(undefined_variable)
        local chunk = loadfile(path)
        if chunk then
            setfenv(chunk, env)
            chunk("GRIP-EMS", GRIPEMS)
            return true
        end
    end
    return false
end

local MODULES = {
    { "Locale/enUS.lua", "../Locale/enUS.lua" },
    { "Data/Defaults.lua", "../Data/Defaults.lua" },
    -- Loaded so A12 to A15 drive the REAL I:StampForked rather than a lookalike
    -- fork table. It publishes itself onto GRIPEMS.Identity, which the block
    -- after this loop captures and then undoes.
    { "Engine/Identity.lua", "../Engine/Identity.lua" },
    { "Engine/MacroSyntax.lua", "../Engine/MacroSyntax.lua" },
    { "Engine/ActionCompiler.lua", "../Engine/ActionCompiler.lua" },
    { "Import/GRIPExport.lua", "../Import/GRIPExport.lua" },
    { "Import/ExportPreview.lua", "../Import/ExportPreview.lua" },
    -- Loaded for ONE published constant: LI.LEGACY_UNKNOWN_AUTHOR, the author
    -- placeholder a conversion leaves behind. A4 asserts the substitution
    -- against the REAL value rather than a retyped copy of it.
    { "Import/LegacyImport.lua", "../Import/LegacyImport.lua" },
    { "Engine/Transmission.lua", "../Engine/Transmission.lua" },
}
for _, candidates in ipairs(MODULES) do
    assertTrue(loadModule(candidates), "could not locate " .. candidates[1] .. " (run from the EMS root)")
end

local GE = GRIPEMS.GRIPExport
local T = GRIPEMS.Transmission
local D = GRIPEMS.Defaults

-- ---------------------------------------------------------------------------
-- The REAL Identity module, captured and then taken back off the namespace.
--
-- Engine/Identity.lua assigns itself to GRIPEMS.Identity on load, which would
-- replace the stub every one of A1 to A11 was written against and would drag
-- BuildExportPayload's privacy scrub into GE.Export on the send path. So it is
-- captured here and the stub is restored. A12 to A15 call RealIdentity
-- DIRECTLY; nothing else in this file sees it.
--
-- I:StampForked calls I:StampOriginal through the module's own local `I`, so the
-- fork path stays entirely inside the real module no matter what the namespace
-- holds. That is what makes the split safe rather than clever.
--
-- GetCurrent is overridden to the SAME identity the stub reports. Without it the
-- real GetCurrent would hash the harness BattleTag and StampOriginal would write
-- that hash, while GE.IsLocallyAuthored compared against LOCAL_IDENTITY_HASH --
-- so A13's control would fail as "needs confirming" for a reason that has
-- nothing to do with ancestry, and would look like the fix over-firing.
--
-- The two signers are stubbed for the reason the sibling fork suite gives: they
-- canonicalise and hash the whole sequence, they only ever WRITE signature
-- fields, and no case here asserts on a signature.
local RealIdentity = GRIPEMS.Identity
assertTrue(
    type(RealIdentity) == "table" and type(RealIdentity.StampForked) == "function",
    "Engine/Identity.lua must have loaded and published StampForked"
)
assertTrue(RealIdentity ~= IDENTITY_STUB, "the real module must have replaced the stub before it is captured back")
GRIPEMS.Identity = IDENTITY_STUB
RealIdentity.GetCurrent = currentIdentity
RealIdentity.SignSequence = function()
    return "sig-v1-restamped"
end
RealIdentity.SignSequenceV2 = function()
    return "sig-v2-restamped"
end

-- NON-VACUITY SWITCH. See the header. Forcing the predicate false is the shape
-- of "the confirmation was never wired in": the handler stops asking, so A5,
-- A6, A8, A10 and A11 must go red while A7 -- which is about the path that
-- never asked -- stays green.
-- os is dev-harness environment access, intentionally outside the addon WoW std.
-- selene: allow(undefined_variable)
if os and os.getenv and os.getenv("GEMS_TEST_STUB_NEEDSCONFIRM") == "1" then
    GE.NeedsAuthorConfirm = function()
        return false
    end
    print("-- NON-VACUITY RUN: GE.NeedsAuthorConfirm stubbed to false --")
end

-- ---------------------------------------------------------------------------
-- Fixtures.
-- ---------------------------------------------------------------------------

--- Build a stored sequence. opts.identity is the ORIGINAL AUTHOR's identity
--- hash: pass LOCAL_IDENTITY_HASH for a sequence this player wrote, anything
--- else (or "") for one they did not. help is populated on every fixture
--- because it is authored prose and A9 reads it.
local function makeSequence(name, opts)
    opts = opts or {}
    return {
        data = {
            name = name,
            icon = D.QUESTION_MARK_ICON,
            defaultVersion = 1,
            versions = {
                {
                    stepFunction = D.STEP_SEQUENTIAL,
                    steps = { "/cast Fireball" },
                    keyPress = "",
                    keyRelease = "",
                },
            },
            author = opts.author or "Sataana",
            originalAuthor = opts.originalAuthor,
            originalAuthorIdentity = opts.identity,
            provenanceSource = opts.provenanceSource,
            help = "AUTHORED-HELP-" .. name,
            classID = 8,
            createdAt = 1000,
            updatedAt = 1000,
            noRedistribute = opts.noRedistribute or nil,
        },
    }
end

local function storeSequence(name, opts)
    local entry = makeSequence(name, opts)
    GRIPEMS.Engine.sequences[name] = entry
    return entry.data
end

--- Drive a CMD_REQUEST through the REAL T:HandleReceive dispatch, the way a
--- remote player drives it. Calling the handler's body directly is not an
--- option: it has no name, and the dispatch is the only live entry point.
local function requestFrom(seqName, sender)
    local okEnc, encoded = GRIPEMS.Serialization.Encode({
        Command = D.CMD_REQUEST,
        SeqName = seqName,
    }, D.GRIP1_PREFIX)
    assertTrue(okEnc, "test payload must encode")
    T:HandleReceive(D.COMM_PREFIX, encoded, "WHISPER", sender or "Requester")
end

--- Decode the payload of the most recent comm message the stub captured.
local function lastSentPayload()
    local last = sentMessages[#sentMessages]
    if not last then
        return nil
    end
    local ok, payload = GRIPEMS.Serialization.Decode(last.encoded)
    return ok and payload or nil
end

-- ---------------------------------------------------------------------------
-- A1 to A4 -- the predicates.
-- ---------------------------------------------------------------------------

test("A1 IsLocallyAuthored answers for the stamp, and fails closed to ASK", function()
    local mine = makeSequence("a1Mine", { identity = LOCAL_IDENTITY_HASH }).data
    local theirs = makeSequence("a1Theirs", { identity = OTHER_IDENTITY_HASH }).data
    local blank = makeSequence("a1Blank", { identity = "" }).data
    local absent = makeSequence("a1Absent", {}).data

    assertEqual(true, GE.IsLocallyAuthored(mine), "the current identity's stamp must read as locally authored")
    assertEqual(false, GE.IsLocallyAuthored(theirs), "another account's stamp must not")
    assertEqual(false, GE.IsLocallyAuthored(blank), "an empty stamp is not a stamp")
    assertEqual(false, GE.IsLocallyAuthored(absent), "a missing stamp is not a stamp")

    -- A non-string stamp. Stored data can be anything a bad import left behind,
    -- and a number equal to nothing must not compare equal to a hash either.
    local numeric = makeSequence("a1Numeric", {}).data
    numeric.originalAuthorIdentity = 42
    assertEqual(false, GE.IsLocallyAuthored(numeric), "a non-string stamp must not read as authorship")

    -- FAIL-CLOSED, and closed here means ASK. With no identity module at all,
    -- and with one whose GetCurrent yields no usable hash, the answer is false
    -- -- which routes the sequence into the confirmation rather than letting it
    -- leave unasked. Returning true here would send silently.
    local savedIdentity = GRIPEMS.Identity
    local okRun, err = pcall(function()
        GRIPEMS.Identity = nil
        assertEqual(false, GE.IsLocallyAuthored(mine), "no identity module must answer false, not true")
        assertEqual(true, GE.NeedsAuthorConfirm(mine), "and the sequence must then need confirming")

        GRIPEMS.Identity = {
            GetCurrent = function()
                return { displayName = "Sataana", identityHash = "" }
            end,
        }
        assertEqual(false, GE.IsLocallyAuthored(mine), "an empty current hash must answer false")

        GRIPEMS.Identity = {
            GetCurrent = function()
                return nil
            end,
        }
        assertEqual(false, GE.IsLocallyAuthored(mine), "a GetCurrent returning nothing must answer false")

        GRIPEMS.Identity = {
            GetCurrent = function()
                error("BNGetInfo is not available outside the client")
            end,
        }
        assertEqual(false, GE.IsLocallyAuthored(mine), "a raising GetCurrent must answer false, not propagate")
    end)
    GRIPEMS.Identity = savedIdentity
    assertTrue(okRun, tostring(err))

    -- The restore really restored, or every case after this one is measuring a
    -- broken harness rather than the product.
    assertEqual(true, GE.IsLocallyAuthored(mine), "the identity must be restored for the cases that follow")
end)

test("A2 NeedsAuthorConfirm is true for foreign work and false for your own", function()
    local mine = makeSequence("a2Mine", { identity = LOCAL_IDENTITY_HASH }).data
    local theirs = makeSequence("a2Theirs", { identity = OTHER_IDENTITY_HASH, originalAuthor = "Someone Else" }).data

    assertEqual(true, GE.NeedsAuthorConfirm(theirs), "a sequence someone else wrote must need confirming")
    assertEqual(false, GE.NeedsAuthorConfirm(mine), "a sequence this player wrote must not")

    -- Non-vacuity for the pair: neither is refused, so the difference between
    -- them is authorship and nothing else.
    assertEqual(false, GE.IsNoRedistribute(theirs), "the foreign fixture must not be refused")
    assertEqual(false, GE.IsNoRedistribute(mine), "the local fixture must not be refused")
end)

test("A3 a do-not-share sequence never needs confirming -- it is refused first", function()
    -- THE ORDERING CASE. Both fixtures are foreign-authored, so the ONLY thing
    -- separating them is the author's flag. A prompt for the marked one would
    -- offer the player a choice the author already made and they do not have.
    local marked = makeSequence("a3Marked", { identity = OTHER_IDENTITY_HASH, noRedistribute = true }).data
    local unmarked = makeSequence("a3Unmarked", { identity = OTHER_IDENTITY_HASH }).data

    assertEqual(true, GE.IsNoRedistribute(marked), "the marked fixture must be refused")
    assertEqual(false, GE.NeedsAuthorConfirm(marked), "a refused sequence must never reach a prompt")
    assertEqual("marked", GE.RefusalReason(marked), "and the refusal must be the author's own flag")

    assertEqual(true, GE.NeedsAuthorConfirm(unmarked), "the unmarked control must still need confirming")

    -- A sequence that is BOTH marked AND locally authored is still refused: the
    -- flag outranks authorship as well as confirmation.
    local mineMarked = makeSequence("a3MineMarked", { identity = LOCAL_IDENTITY_HASH, noRedistribute = true }).data
    assertEqual(true, GE.IsNoRedistribute(mineMarked), "the flag still refuses a sequence you hold the stamp on")
    assertEqual(false, GE.NeedsAuthorConfirm(mineMarked), "and it still raises no prompt")
end)

test("A4 legacy-sourced content with a blank stamp needs confirming", function()
    local legacy = makeSequence("a4Legacy", {
        identity = "",
        originalAuthor = "Someone Else Entirely",
        provenanceSource = "gse-legacy",
    }).data

    assertEqual(true, GE.IsProvenanceGated(legacy), "converted content must still read as unproven")
    assertEqual(false, GE.IsNoRedistribute(legacy), "and must NOT be refused any more")
    assertEqual(true, GE.NeedsAuthorConfirm(legacy), "it must need the player's confirmation instead")

    -- The author string the prompt will show is whatever was imported, shown
    -- as-is. An unknown author is exactly the case the player needs to see.
    local authors, names = GE.CollectForeignAuthors({ "a4LegacyStored" })
    assertEqual(0, #authors, "an unstored name must contribute nothing")
    assertEqual(0, #names, "and must not be listed")

    GRIPEMS.Engine.sequences["a4LegacyStored"] = { data = legacy }
    authors, names = GE.CollectForeignAuthors({ "a4LegacyStored" })
    assertEqual(1, #names, "the stored legacy sequence must be listed as needing confirmation")
    assertEqual("Someone Else Entirely", authors[1], "the imported author string must be shown as-is")

    -- THE ONE SUBSTITUTION. The converter writes a fixed placeholder when the
    -- payload names nobody, and that placeholder spells out the source addon.
    -- No shipped string may name another addon, so it is replaced with the
    -- unknown-author label -- which tells the player the same thing.
    --
    -- The placeholder is read off the REAL converter module rather than retyped,
    -- so the two cannot drift apart without this case failing. The two guards
    -- below are the non-vacuity: a nil placeholder would compare equal to
    -- nothing and the substitution would silently never fire, and a placeholder
    -- that no longer names the source addon would make the case pointless.
    local LI = GRIPEMS.LegacyImport
    local placeholder = LI and LI.LEGACY_UNKNOWN_AUTHOR
    assertTrue(
        type(placeholder) == "string" and placeholder ~= "",
        "the converter must publish its unknown-author placeholder"
    )
    assertTrue(placeholder:find("GSE", 1, true) ~= nil, "and it must be the value that names the source addon")

    legacy.originalAuthor = placeholder
    authors = GE.CollectForeignAuthors({ "a4LegacyStored" })
    assertEqual(1, #authors, "the placeholder sequence must still need confirming")
    assertEqual(LOCALE["GEMS_CONFIRM_AUTHOR_UNKNOWN"], authors[1], "the placeholder must resolve to the label")
    assertTrue(LOCALE["GEMS_CONFIRM_AUTHOR_UNKNOWN"] ~= "GEMS_CONFIRM_AUTHOR_UNKNOWN", "the label key must exist")
    assertNil(authors[1]:find("GSE", 1, true), "no shipped prompt string may name another addon")

    -- A sequence with NO author at all resolves to the same label.
    legacy.originalAuthor = nil
    legacy.author = ""
    authors = GE.CollectForeignAuthors({ "a4LegacyStored" })
    assertEqual(LOCALE["GEMS_CONFIRM_AUTHOR_UNKNOWN"], authors[1], "an absent author must resolve to the label too")
end)

-- ---------------------------------------------------------------------------
-- A5 to A8 -- the REAL CMD_REQUEST handler.
-- ---------------------------------------------------------------------------

test("A5 a request for foreign work sends NOTHING until the player confirms", function()
    storeSequence("a5Theirs", { identity = OTHER_IDENTITY_HASH, originalAuthor = "Someone Else" })

    local before = #sentMessages
    local showsBefore = Popup.showCount
    requestFrom("a5Theirs", "RequesterA5")

    -- The gap. This is the whole feature: the request has been handled, the
    -- player has been asked, and nothing has left the client.
    assertEqual(before, #sentMessages, "no comm message may be emitted before confirmation")
    assertEqual(showsBefore + 1, Popup.showCount, "exactly one popup must have been raised")
    assertEqual("GEMS_CONFIRM_AUTHOR_SEND", Popup.shownName, "and it must be the author-confirmation popup")

    -- The prompt has to name the author and the sequence, or the player is
    -- being asked to approve something they cannot identify.
    local def = Popup.defs["GEMS_CONFIRM_AUTHOR_SEND"]
    assertTrue(type(def.text) == "string" and def.text ~= "", "the popup must carry text")
    assertTrue(def.text:find("a5Theirs", 1, true) ~= nil, "the prompt must name the sequence")
    assertTrue(def.text:find("Someone Else", 1, true) ~= nil, "the prompt must name the author")
    assertTrue(def.text:find("RequesterA5", 1, true) ~= nil, "the prompt must name who asked")
    assertEqual(0, def.timeout, "the prompt must not time out -- an unanswered question is not a yes")

    -- Now the player confirms.
    pressConfirm()
    assertEqual(before + 1, #sentMessages, "the sequence must be sent once the player confirms")
    local payload = lastSentPayload()
    assertTrue(payload ~= nil, "the sent payload must decode")
    assertEqual(D.CMD_TRANSMIT, payload.Command, "and it must be a transmit")
    -- Name-Realm: T:HandleReceive normalizes an unqualified sender before any
    -- branch reads it, so the reply is addressed to the normalized form.
    assertEqual("RequesterA5-TestRealm", sentMessages[#sentMessages].target, "addressed to the player who asked")

    -- The fulfilled line still fires after an ACCEPTED send.
    assertEqual(
        string.format(LOCALE["GEMS_REQUEST_FULFILLED"], "a5Theirs", "RequesterA5-TestRealm"),
        printLog[#printLog],
        "an accepted send must still print the fulfilled line"
    )
end)

test("A6 a cancelled request never emits a comm message", function()
    storeSequence("a6Theirs", { identity = OTHER_IDENTITY_HASH, originalAuthor = "Someone Else" })

    local before = #sentMessages
    requestFrom("a6Theirs", "RequesterA6")
    assertEqual(before, #sentMessages, "nothing may leave before the player answers")
    assertEqual("GEMS_CONFIRM_AUTHOR_SEND", Popup.shownName, "the prompt must be up")

    pressCancel()
    assertEqual(before, #sentMessages, "nothing may leave after a cancel either")

    -- A declined request gets its OWN line, distinct from the fulfilled one.
    assertEqual(
        string.format(LOCALE["GEMS_CONFIRM_AUTHOR_DECLINED"], "a6Theirs", "RequesterA6"),
        printLog[#printLog],
        "a declined request must print the declined line"
    )
    assertTrue(
        printLog[#printLog] ~= string.format(LOCALE["GEMS_REQUEST_FULFILLED"], "a6Theirs", "RequesterA6-TestRealm"),
        "and must not print the fulfilled line"
    )

    -- Non-vacuity: the cancel really did clear the latch, so the next request
    -- is not dropped by the one-at-a-time rule instead of being answered.
    assertEqual(false, Popup:IsShown("GEMS_CONFIRM_AUTHOR_SEND"), "the popup must be closed after a cancel")
end)

test("A7 a request for the player's OWN sequence is still answered automatically", function()
    -- THE CONTROL. Without it this change could break ordinary sharing entirely
    -- and every other case here would still pass.
    storeSequence("a7Mine", { identity = LOCAL_IDENTITY_HASH })

    local before = #sentMessages
    local showsBefore = Popup.showCount
    requestFrom("a7Mine", "RequesterA7")

    assertEqual(before + 1, #sentMessages, "a sequence the player wrote must still be sent on request")
    assertEqual(showsBefore, Popup.showCount, "and no prompt may be raised for it")
    assertEqual(
        string.format(LOCALE["GEMS_REQUEST_FULFILLED"], "a7Mine", "RequesterA7-TestRealm"),
        printLog[#printLog],
        "the fulfilled line must still fire"
    )
end)

test("A8 a second request while a prompt is open does not open a second popup", function()
    storeSequence("a8First", { identity = OTHER_IDENTITY_HASH, originalAuthor = "Author One" })
    storeSequence("a8Second", { identity = OTHER_IDENTITY_HASH, originalAuthor = "Author Two" })

    local before = #sentMessages
    local showsBefore = Popup.showCount
    requestFrom("a8First", "RequesterA8a")
    assertEqual(showsBefore + 1, Popup.showCount, "the first request must raise one popup")

    -- A DIFFERENT sender, deliberately. The same name would be dropped by the
    -- per-sender cooldown and the case would pass without ever exercising the
    -- one-at-a-time latch it exists to measure.
    requestFrom("a8Second", "RequesterA8b")
    assertEqual(showsBefore + 1, Popup.showCount, "a second request must NOT raise a second popup")
    assertEqual(before, #sentMessages, "and must send nothing")

    -- The popup still on screen is the FIRST one, unreplaced.
    local def = Popup.defs["GEMS_CONFIRM_AUTHOR_SEND"]
    assertTrue(def.text:find("a8First", 1, true) ~= nil, "the open prompt must still be the first one")
    assertNil(def.text:find("a8Second", 1, true), "the second request must not have overwritten it")

    -- Confirming answers the FIRST request only. The dropped one is gone, not
    -- queued: the requester can ask again.
    pressConfirm()
    assertEqual(before + 1, #sentMessages, "exactly one sequence may be sent")
    local payload = lastSentPayload()
    assertTrue(payload ~= nil, "the sent payload must decode")
    assertEqual("RequesterA8a-TestRealm", sentMessages[#sentMessages].target, "it must answer the first requester")
end)

-- ---------------------------------------------------------------------------
-- A9 -- the disclosure half.
-- ---------------------------------------------------------------------------

test("A9 SendListResponse omits a sequence the player did not author", function()
    -- Mirrors N6 in the sibling harness, on the authorship axis instead of the
    -- author's flag. A clean store, so the fixtures below are the whole list.
    local saved = GRIPEMS.Engine.sequences
    GRIPEMS.Engine.sequences = {}
    local okRun, err = pcall(function()
        storeSequence("a9Mine", { identity = LOCAL_IDENTITY_HASH })
        storeSequence("a9Theirs", { identity = OTHER_IDENTITY_HASH, originalAuthor = "Someone Else" })
        storeSequence("a9Marked", { identity = LOCAL_IDENTITY_HASH, noRedistribute = true })

        T:SendListResponse("Someone")
        local payload = lastSentPayload()
        assertTrue(payload ~= nil, "the list payload must decode")
        assertEqual(D.CMD_LIST_RESPONSE, payload.Command, "the payload must be a list response")

        local sawMine, sawTheirs, sawMarked = false, false, false
        for _, row in ipairs(payload.Sequences) do
            if row.name == "a9Mine" then
                sawMine = true
            end
            if row.name == "a9Theirs" then
                sawTheirs = true
            end
            if row.name == "a9Marked" then
                sawMarked = true
            end
            -- Whatever else is listed, no row may carry the foreign sequence's
            -- authored prose under any key.
            assertTrue(row.help ~= "AUTHORED-HELP-a9Theirs", "no row may carry the foreign sequence's help")
        end
        assertEqual(true, sawMine, "a sequence the player wrote must still be listed")
        assertEqual(false, sawTheirs, "a sequence someone else wrote must be omitted")
        assertEqual(false, sawMarked, "and a do-not-share sequence must still be omitted")
        assertEqual(1, #payload.Sequences, "exactly one of the three may be listed")
    end)
    GRIPEMS.Engine.sequences = saved
    assertTrue(okRun, tostring(err))
end)

-- ---------------------------------------------------------------------------
-- A10 / A11 -- the two guards EDIT 5 shipped alongside the prompt.
-- ---------------------------------------------------------------------------

test("A10 the prompt cooldown is per sender and expires", function()
    storeSequence("a10Theirs", { identity = OTHER_IDENTITY_HASH, originalAuthor = "Someone Else" })

    local showsBefore = Popup.showCount
    requestFrom("a10Theirs", "RequesterA10")
    assertEqual(showsBefore + 1, Popup.showCount, "the first request must prompt")
    pressCancel()

    -- Same sender, inside the window: dropped, with no prompt and nothing sent.
    local sentBefore = #sentMessages
    requestFrom("a10Theirs", "RequesterA10")
    assertEqual(showsBefore + 1, Popup.showCount, "a repeat from the same sender must not prompt again")
    assertEqual(sentBefore, #sentMessages, "and must send nothing")

    -- A different sender is not throttled by the first one's stamp.
    requestFrom("a10Theirs", "RequesterA10Other")
    assertEqual(showsBefore + 2, Popup.showCount, "a different sender must still be heard")
    pressCancel()

    -- Past the window, the first sender is heard again.
    clock = clock + 61
    requestFrom("a10Theirs", "RequesterA10")
    assertEqual(showsBefore + 3, Popup.showCount, "the cooldown must expire, not latch permanently")
    pressCancel()
    clock = clock - 61
end)

test("A11 in combat a request for foreign work neither prompts nor sends", function()
    storeSequence("a11Theirs", { identity = OTHER_IDENTITY_HASH, originalAuthor = "Someone Else" })

    local sentBefore = #sentMessages
    local showsBefore = Popup.showCount
    inCombat = true
    local okRun, err = pcall(function()
        requestFrom("a11Theirs", "RequesterA11")
        assertEqual(showsBefore, Popup.showCount, "no popup may be raised in combat")
        assertEqual(sentBefore, #sentMessages, "and nothing may be sent to the requester")
        assertEqual(
            string.format(LOCALE["GEMS_CONFIRM_AUTHOR_COMBAT"], "RequesterA11", "a11Theirs"),
            printLog[#printLog],
            "the owner must get one line saying the request was not answered"
        )

        -- The player's OWN sequence is still answered in combat: this guard is
        -- about the prompt, not about combat stopping sharing.
        storeSequence("a11Mine", { identity = LOCAL_IDENTITY_HASH })
        requestFrom("a11Mine", "RequesterA11b")
        assertEqual(sentBefore + 1, #sentMessages, "your own sequence must still be sent in combat")
    end)
    inCombat = false
    assertTrue(okRun, tostring(err))
end)

-- ---------------------------------------------------------------------------
-- A12 to A15 -- a fork of someone else's work is still someone else's work.
--
-- Every case here drives the REAL I:StampForked read off disk. That matters
-- more than usual: the whole defect was that StampForked's re-stamp is CORRECT
-- and the conclusion drawn from it was not, so a lookalike fork table written
-- in this file would be testing my understanding of the re-stamp rather than
-- the re-stamp. StampForked is not modified by this phase and these cases
-- assert that -- each one checks the local stamp landed before checking that
-- the copy still reads as someone else's work.
-- ---------------------------------------------------------------------------

--- Fork src through the REAL module. The new table is a fully-formed sequence
--- because A13 drives its fork through the send path, which exports it.
local function forkOf(forkName, src)
    local newSeq = makeSequence(forkName, {}).data
    local stamped = RealIdentity:StampForked(newSeq, src)
    assertTrue(stamped, "StampForked must report a first stamp")
    return newSeq
end

test("A12 a fork of FOREIGN work needs confirming even though the stamp is local", function()
    local src = makeSequence("a12Theirs", { identity = OTHER_IDENTITY_HASH, originalAuthor = "Someone Else" }).data
    assertEqual(true, GE.NeedsAuthorConfirm(src), "the source must need confirming")

    local newSeq = forkOf("a12Fork", src)

    -- THE RE-STAMP REALLY HAPPENED, and it has to be asserted before anything
    -- else. Without these two lines the case could pass on a fork that simply
    -- kept the foreign stamp -- which is not what StampForked does, and would
    -- mean the ancestry test was never exercised at all.
    assertEqual(LOCAL_IDENTITY_HASH, newSeq.originalAuthorIdentity, "StampForked must re-stamp with the local hash")
    assertEqual(
        OTHER_IDENTITY_HASH,
        newSeq.forkedFrom.originalAuthorIdentity,
        "and must record the source author in forkedFrom"
    )

    assertEqual(false, GE.IsLocallyAuthored(newSeq), "a fork of foreign work is not locally authored")
    assertEqual(true, GE.NeedsAuthorConfirm(newSeq), "so the copy must still need confirming")
end)

test("A13 CONTROL a fork of the player's OWN sequence needs no confirmation", function()
    -- WITHOUT THIS CASE the ancestry test could pass by answering "not locally
    -- authored" for every fork, which would prompt the player about their own
    -- duplicates. That is a worse bug than the one being fixed: it turns a
    -- silent hole into constant nagging on work nobody else has a claim to.
    local src = makeSequence("a13Mine", { identity = LOCAL_IDENTITY_HASH }).data
    assertEqual(false, GE.NeedsAuthorConfirm(src), "the source must not need confirming")

    local newSeq = forkOf("a13MineFork", src)
    assertEqual(LOCAL_IDENTITY_HASH, newSeq.forkedFrom.originalAuthorIdentity, "the ancestor must be the local player")
    assertEqual(true, GE.IsLocallyAuthored(newSeq), "a fork of your own work is still your own work")
    assertEqual(false, GE.NeedsAuthorConfirm(newSeq), "and must not prompt")

    -- Through the REAL request handler as well. A predicate-only assertion
    -- would not catch a regression that reached the prompt by another route.
    GRIPEMS.Engine.sequences["a13MineFork"] = { data = newSeq }
    local before = #sentMessages
    local showsBefore = Popup.showCount
    requestFrom("a13MineFork", "RequesterA13")
    assertEqual(before + 1, #sentMessages, "the fork must still be answered automatically")
    assertEqual(showsBefore, Popup.showCount, "and must raise no prompt")
end)

test("A14 multi-hop: a local parent does not launder a foreign root", function()
    -- THE CASE forkedFromChain EXISTS FOR, and the one a forkedFrom-only fix
    -- would miss. Fork someone else's sequence, then fork your own fork: the
    -- IMMEDIATE parent of the second copy is you.
    local root = makeSequence("a14Root", { identity = OTHER_IDENTITY_HASH, originalAuthor = "Someone Else" }).data
    local hop1 = forkOf("a14Hop1", root)
    local hop2 = forkOf("a14Hop2", hop1)

    -- The shape is asserted rather than assumed, because the whole case rests
    -- on it: forkedFrom says "local", and only the chain still says otherwise.
    assertEqual(LOCAL_IDENTITY_HASH, hop2.forkedFrom.originalAuthorIdentity, "the immediate parent must be local")
    assertTrue(type(hop2.forkedFromChain) == "table", "the chain must exist")
    assertTrue(#hop2.forkedFromChain >= 2, "and must reach past the immediate parent")
    assertEqual(
        OTHER_IDENTITY_HASH,
        hop2.forkedFromChain[#hop2.forkedFromChain].originalAuthorIdentity,
        "with the foreign author at the root of it"
    )

    assertEqual(false, GE.IsLocallyAuthored(hop2), "a foreign root is still foreign two hops out")
    assertEqual(true, GE.NeedsAuthorConfirm(hop2), "so the fork of the fork must still need confirming")

    -- The first hop is covered by A12; asserting it here too pins that the
    -- chain grew rather than being rebuilt from the immediate parent alone.
    assertEqual(true, GE.NeedsAuthorConfirm(hop1), "the first hop must need confirming as well")
end)

test("A15 an ancestor with an EMPTY or unreadable identity needs confirming", function()
    -- Converted content is the real shape: that format offers no identity hash,
    -- so the ancestor's is "". An ancestor this client cannot identify is
    -- exactly the case to ask about, not to wave through.
    local src = makeSequence("a15Unknown", { identity = "", provenanceSource = "gse-legacy" }).data
    local newSeq = forkOf("a15Fork", src)

    assertEqual("", newSeq.forkedFrom.originalAuthorIdentity, "the ancestor must carry an empty identity")
    assertEqual(LOCAL_IDENTITY_HASH, newSeq.originalAuthorIdentity, "while the copy carries the local re-stamp")
    assertEqual(false, GE.IsLocallyAuthored(newSeq), "an unidentifiable ancestor is not the local player")
    assertEqual(true, GE.NeedsAuthorConfirm(newSeq), "so the fork must need confirming")

    -- The same rule for ancestry that is PRESENT but not readable. Both fields
    -- arrive from the wire on an imported sequence and can be any shape a
    -- sender chose, and ipairs RAISES on a string where the length operator
    -- would not. Lineage this client cannot read is not the same as none.
    local wire = makeSequence("a15Wire", { identity = LOCAL_IDENTITY_HASH }).data
    assertEqual(true, GE.IsLocallyAuthored(wire), "the fixture must start out locally authored")

    wire.forkedFromChain = "not a table"
    assertEqual(false, GE.IsLocallyAuthored(wire), "an unreadable chain must not be skipped over")

    wire.forkedFromChain = { "not a table either" }
    assertEqual(false, GE.IsLocallyAuthored(wire), "nor an unreadable entry inside it")

    wire.forkedFromChain = nil
    wire.forkedFrom = 42
    assertEqual(false, GE.IsLocallyAuthored(wire), "nor an unreadable forkedFrom")

    -- An EMPTY chain is not lineage and must not be treated as any: a sequence
    -- rebuilt through D.CarrySequenceIdentity arrives with forkedFromChain = {}.
    wire.forkedFrom = nil
    wire.forkedFromChain = {}
    assertEqual(true, GE.IsLocallyAuthored(wire), "an empty chain records no ancestor and must not block")
end)

-- ---------------------------------------------------------------------------
-- A16 to A19 -- the prompt names the person who actually wrote it.
--
-- Knowing a sequence needs confirming and knowing WHOSE work it is are two
-- questions, and the second one was answered wrong for every duplicate:
-- StampForked clears the byline and StampOriginal re-writes it, so the collector
-- read the LOCAL player's name off a copy of someone else's work. Measured
-- 2026-08-25 -- a source by "Gaupanda" reported as "Sataana".
-- ---------------------------------------------------------------------------

local SOURCE_AUTHOR = "Gaupanda"
local LOCAL_DISPLAY_NAME = "Sataana"

--- Store a sequence and return its data, so a case can hand the NAME to
--- GE.CollectForeignAuthors -- which reads the store, not a loose table.
local function storeData(name, seqData)
    GRIPEMS.Engine.sequences[name] = { data = seqData }
    return seqData
end

test("A16 a duplicate of foreign work reports the SOURCE author, not the local player", function()
    local src = makeSequence("a16Src", {
        identity = OTHER_IDENTITY_HASH,
        originalAuthor = SOURCE_AUTHOR,
    }).data
    storeData("a16Src", src)

    local copy = storeData("a16Copy", forkOf("a16Copy", src))

    -- The re-stamp really happened, asserted first: without it the case could
    -- pass on a copy that never had the local byline written over it, and would
    -- prove nothing about the resolution order.
    assertEqual(LOCAL_DISPLAY_NAME, copy.originalAuthor, "StampForked must overwrite the byline with the local name")
    assertEqual(LOCAL_IDENTITY_HASH, copy.originalAuthorIdentity, "and stamp the local identity")
    assertEqual(SOURCE_AUTHOR, copy.forkedFrom.originalAuthor, "with the source author recorded in forkedFrom")

    local authors, names = GE.CollectForeignAuthors({ "a16Copy" })
    assertEqual(1, #names, "the copy must still need confirming")
    assertEqual(SOURCE_AUTHOR, authors[1], "and the prompt must name the person who wrote it")
    assertTrue(authors[1] ~= LOCAL_DISPLAY_NAME, "never the local player")
end)

test("A17 multi-hop reports the ROOT author, not the local immediate parent", function()
    -- The case forkedFromChain exists for, on the NAMING side this time. The
    -- immediate parent of hop2 is the local player, so a forkedFrom-only walk
    -- would report "Sataana" and be exactly as wrong as reading the top-level
    -- byline. Measured before the fix: it did.
    local root = makeSequence("a17Root", {
        identity = OTHER_IDENTITY_HASH,
        originalAuthor = SOURCE_AUTHOR,
    }).data
    storeData("a17Root", root)
    local hop1 = storeData("a17Hop1", forkOf("a17Hop1", root))
    local hop2 = storeData("a17Hop2", forkOf("a17Hop2", hop1))

    assertEqual(LOCAL_DISPLAY_NAME, hop2.forkedFrom.originalAuthor, "the immediate parent must be the local player")
    assertEqual(
        SOURCE_AUTHOR,
        hop2.forkedFromChain[#hop2.forkedFromChain].originalAuthor,
        "with the real author at the root of the chain"
    )

    local authors = GE.CollectForeignAuthors({ "a17Hop2" })
    assertEqual(SOURCE_AUTHOR, authors[1], "the prompt must name the root author two hops out")
end)

test("A18 CONTROL a sequence foreign by its OWN stamp still reports its own byline", function()
    -- UNCHANGED FROM BEFORE THIS PHASE, and the control that stops the fix
    -- rewriting the ordinary case. Most confirmed sequences are foreign by
    -- their own stamp -- received, not duplicated -- and their byline was
    -- always right.
    local theirs = makeSequence("a18Theirs", {
        identity = OTHER_IDENTITY_HASH,
        originalAuthor = SOURCE_AUTHOR,
    }).data
    storeData("a18Theirs", theirs)
    assertNil(theirs.forkedFrom, "the fixture must carry no ancestry, so only branch 1 can answer")

    local authors = GE.CollectForeignAuthors({ "a18Theirs" })
    assertEqual(SOURCE_AUTHOR, authors[1], "its own originalAuthor must still be reported")

    -- The author fallback under it is unchanged too: no originalAuthor, use
    -- author.
    local bare = makeSequence("a18Bare", { identity = OTHER_IDENTITY_HASH, author = "PlainAuthor" }).data
    bare.originalAuthor = nil
    storeData("a18Bare", bare)
    assertEqual("PlainAuthor", GE.CollectForeignAuthors({ "a18Bare" })[1], "the author fallback must still work")
end)

test("A19 an unusable ancestor name falls back to the label, never to the local player", function()
    -- BOTH HALVES ASSERTED. "It fell back" and "it did not fall back to me" are
    -- different claims and only the second one is the invariant.
    local label = LOCALE["GEMS_CONFIRM_AUTHOR_UNKNOWN"]
    assertTrue(label ~= "GEMS_CONFIRM_AUTHOR_UNKNOWN", "the label key must exist in Locale/enUS.lua")

    -- An ancestor with an empty byline.
    local src = makeSequence("a19Src", { identity = OTHER_IDENTITY_HASH, originalAuthor = "" }).data
    src.originalAuthor = ""
    storeData("a19Src", src)
    local copy = storeData("a19Copy", forkOf("a19Copy", src))
    assertEqual("", copy.forkedFrom.originalAuthor, "the ancestor must carry no usable name")
    local authors = GE.CollectForeignAuthors({ "a19Copy" })
    assertEqual(label, authors[1], "an unnamed ancestor must resolve to the label")
    assertTrue(authors[1] ~= LOCAL_DISPLAY_NAME, "and must NOT resolve to the local player")

    -- Unreadable lineage: the walk finds nothing and falls through rather than
    -- reaching past to the top-level byline, which is the local name.
    local unreadable = makeSequence("a19Unreadable", { identity = LOCAL_IDENTITY_HASH }).data
    unreadable.originalAuthor = LOCAL_DISPLAY_NAME
    unreadable.forkedFrom = 42
    storeData("a19Unreadable", unreadable)
    assertEqual(true, GE.NeedsAuthorConfirm(unreadable), "unreadable lineage must still be confirmed")
    local unreadableAuthors = GE.CollectForeignAuthors({ "a19Unreadable" })
    assertEqual(label, unreadableAuthors[1], "and must resolve to the label")
    assertTrue(unreadableAuthors[1] ~= LOCAL_DISPLAY_NAME, "never the local player")

    -- A CRAFTED ancestor carrying the victim's own name against a foreign
    -- identity. The walk would happily report it; the final guard is what
    -- stops the prompt reading "you wrote this" about content they did not.
    local crafted = makeSequence("a19Crafted", { identity = LOCAL_IDENTITY_HASH }).data
    crafted.forkedFrom = {
        originalAuthor = LOCAL_DISPLAY_NAME,
        originalAuthorIdentity = OTHER_IDENTITY_HASH,
    }
    storeData("a19Crafted", crafted)
    assertEqual(true, GE.NeedsAuthorConfirm(crafted), "a foreign ancestor must still be confirmed")
    local craftedAuthors = GE.CollectForeignAuthors({ "a19Crafted" })
    assertEqual(label, craftedAuthors[1], "a crafted local-looking byline must resolve to the label")
    assertTrue(craftedAuthors[1] ~= LOCAL_DISPLAY_NAME, "the prompt may never claim the player wrote it")
end)

-- ---------------------------------------------------------------------------
-- A20 / A21 -- an inbound payload may not name the RECEIVER as author.
-- ---------------------------------------------------------------------------

--- Encode a native payload and put it through the REAL GE.ImportNative.
local function importPayload(name, sequenceBlock)
    local payload = {
        format = "GRIP-EMS",
        version = D.GRIP_FORMAT_VERSION,
        name = name,
        sequence = sequenceBlock,
    }
    local okEnc, encoded = GRIPEMS.Serialization.Encode(payload, D.GRIP1_PREFIX)
    assertTrue(okEnc, "the test payload must encode")
    local okImp, impName, impData = GE.ImportNative(encoded)
    assertTrue(okImp, "the payload must import: " .. tostring(impName))
    return impData
end

--- The wire shape of a sequence, with the authorship block a case supplies.
local function wireSequence(fields)
    local seq = {
        icon = D.QUESTION_MARK_ICON,
        defaultVersion = 1,
        versions = {
            { stepFunction = D.STEP_SEQUENTIAL, steps = { "/cast Fireball" }, keyPress = "", keyRelease = "" },
        },
        author = "WireAuthor",
        help = "authored prose",
        createdAt = 500,
        updatedAt = 500,
    }
    for k, v in pairs(fields or {}) do
        seq[k] = v
    end
    return seq
end

test("A20 ImportNative blanks an inbound identity claiming to be the receiver", function()
    -- THE CRAFT: a payload that names the RECEIVER as original author, with the
    -- receiver's own hash. Nothing arriving from the wire was authored locally,
    -- so the claim is either crafted or wrong and is not believed either way.
    local impData = importPayload(
        "a20Crafted",
        wireSequence({
            originalAuthor = LOCAL_DISPLAY_NAME,
            originalAuthorIdentity = LOCAL_IDENTITY_HASH,
            originalAuthorRealm = "TestRealm",
            originalCreatedAt = 500,
        })
    )

    assertEqual("", impData.originalAuthorIdentity, "the inbound claim must be blanked, not stored")
    assertEqual(false, GE.IsLocallyAuthored(impData), "so the received copy is not locally authored")
    assertEqual(true, GE.NeedsAuthorConfirm(impData), "and the player is asked before it moves on")
end)

test("A21 CONTROL ImportNative preserves an inbound identity that is not the receiver's", function()
    -- WITHOUT THIS the fix could pass by blanking every inbound identity, which
    -- would erase the true author from every shared sequence and break the
    -- provenance the confirmation reads.
    local impData = importPayload(
        "a21Honest",
        wireSequence({
            originalAuthor = SOURCE_AUTHOR,
            originalAuthorIdentity = OTHER_IDENTITY_HASH,
            originalAuthorRealm = "OtherRealm",
            originalCreatedAt = 500,
        })
    )

    assertEqual(OTHER_IDENTITY_HASH, impData.originalAuthorIdentity, "a foreign identity must survive the import")
    assertEqual(SOURCE_AUTHOR, impData.originalAuthor, "along with the byline that goes with it")
    assertEqual(true, GE.NeedsAuthorConfirm(impData), "the received copy still needs confirming")

    storeData("a21Honest", impData)
    assertEqual(SOURCE_AUTHOR, GE.CollectForeignAuthors({ "a21Honest" })[1], "and the prompt names the true author")
end)

-- ---------------------------------------------------------------------------
-- A22 to A24 -- a wire payload may not reach the first-save branch.
--
-- GE.ImportNative's provenance carry is gated on a non-empty originalAuthor, so
-- a payload that carried none skipped it and landed with the byline nil, no
-- ancestry and no provenance. Both editors rebuild with
-- `oldData.originalAuthor or ""`, which turns that nil into the exact condition
-- on their FIRST-SAVE branch -- the one that calls StampOriginal. Import, open,
-- save, and content from another player was stamped as written here.
--
-- THE EDITORS CANNOT BE STOOD UP IN THIS HARNESS, so the save branch is
-- REPLICATED below rather than driven. That is a real evidence limit and it is
-- mitigated the only way it can be: each case first asserts that the shipped
-- source still contains the guard it replicates, so a rename or a deletion
-- reddens the case instead of leaving it measuring a copy of itself.
-- ---------------------------------------------------------------------------

--- Read a shipped source file so a case can anchor on the real text.
local function readSource(candidates)
    for _, path in ipairs(candidates) do
        -- io is dev-harness file I/O, intentionally outside the addon WoW std.
        -- selene: allow(undefined_variable)
        local fh = io.open(path, "r")
        if fh then
            local text = fh:read("*a")
            fh:close()
            return text
        end
    end
    return nil
end

--- The two shipped lines the editors run on save, replicated verbatim in shape:
--- the rebuild's `or ""` coercion, then the gated first-save branch.
local function simulateFirstSave(stored)
    local newData = stored
    newData.originalAuthor = newData.originalAuthor or ""
    local cameFromElsewhere = type(newData.provenanceSource) == "string" and newData.provenanceSource ~= ""
    if newData.originalAuthor == "" and not cameFromElsewhere then
        RealIdentity:StampOriginal(newData)
        return true
    end
    return false
end

--- Both editors carry the same gate. Anchored on the shipped text so the
--- replication above cannot silently drift away from what ships.
local function assertGateAnchoredInBothEditors()
    for _, f in ipairs({
        { "UI/SequenceEditor.lua", "../UI/SequenceEditor.lua" },
        { "UI/PopupEditor.lua", "../UI/PopupEditor.lua" },
    }) do
        local src = readSource(f)
        assertTrue(src ~= nil, "could not read " .. f[1])
        assertTrue(
            src:find('newData.originalAuthor = oldData.originalAuthor or ""', 1, true) ~= nil,
            f[1] .. " must still coerce a nil byline to the empty string"
        )
        assertTrue(
            src:find("local cameFromElsewhere", 1, true) ~= nil,
            f[1] .. " must still compute the came-from-elsewhere gate"
        )
        assertTrue(
            src:find('if newData.originalAuthor == "" and not cameFromElsewhere then', 1, true) ~= nil,
            f[1] .. " must still gate the first-save branch on it"
        )
    end
end

test("A22 a bylineless inbound payload stays unproven through a first save", function()
    assertGateAnchoredInBothEditors()

    -- The whole payload shape: no originalAuthor at all.
    local impData = importPayload("a22Bylineless", wireSequence({}))

    assertNil(impData.originalAuthor, "the payload carries no byline, so none is stored")
    assertNil(impData.forkedFrom, "and no ancestry")
    assertEqual("no-provenance", impData.provenanceSource, "but the import MARKS it as not originating here")
    assertEqual(false, GE.IsLocallyAuthored(impData), "so it is not locally authored")
    assertEqual(true, GE.NeedsAuthorConfirm(impData), "and needs confirming as stored")

    -- Now the save that used to claim it.
    local stamped = simulateFirstSave(impData)
    assertEqual(false, stamped, "the first-save branch must NOT fire for a record that arrived from the wire")
    assertEqual(true, GE.NeedsAuthorConfirm(impData), "and it must STILL need confirming afterwards")
    assertTrue(
        impData.originalAuthorIdentity ~= LOCAL_IDENTITY_HASH,
        "the local identity must not have been stamped onto it"
    )
end)

test("A23 CONTROL a genuinely new local sequence still gets its first-save stamp", function()
    -- WITHOUT THIS the fix could pass by never stamping anything, which would
    -- leave every sequence the player writes unsigned and unshareable without a
    -- prompt -- a worse outcome than the hole.
    local fresh = makeSequence("a23Fresh", {}).data
    fresh.originalAuthor = nil
    fresh.originalAuthorIdentity = nil
    fresh.provenanceSource = nil
    assertNil(fresh.provenanceSource, "a new sequence carries no provenance before its first save")

    local stamped = simulateFirstSave(fresh)
    assertEqual(true, stamped, "the first-save branch MUST still fire for a new local sequence")
    assertEqual(LOCAL_IDENTITY_HASH, fresh.originalAuthorIdentity, "and stamp the local identity")
    assertEqual(true, GE.IsLocallyAuthored(fresh), "so the player's own new work is locally authored")
    assertEqual(false, GE.NeedsAuthorConfirm(fresh), "and never prompts")
end)

test("A24 CONTROL the fork path still stamps, and still needs confirming", function()
    -- THE CASE EDIT 2 WAS MOST LIKELY TO BREAK. I:StampForked blanks the byline
    -- and calls I:StampOriginal ITSELF, inside Identity, before the copy is ever
    -- stored -- so the blanked byline never travels through the editor branch
    -- that was just gated. Asserted rather than reasoned, because "the fork
    -- reaches StampOriginal another way" is exactly the kind of claim that is
    -- true right up until it is not.
    local src = makeSequence("a24Src", {
        identity = OTHER_IDENTITY_HASH,
        originalAuthor = SOURCE_AUTHOR,
    }).data
    storeData("a24Src", src)

    local copy = storeData("a24Copy", forkOf("a24Copy", src))

    -- StampOriginal really ran inside StampForked: the copy carries the local
    -- byline and the local stamp.
    assertEqual(LOCAL_DISPLAY_NAME, copy.originalAuthor, "the fork must carry the local byline")
    assertEqual(LOCAL_IDENTITY_HASH, copy.originalAuthorIdentity, "and the local identity stamp")
    assertTrue(
        type(copy.provenanceSource) == "string" and copy.provenanceSource ~= "",
        "and a provenanceSource, written by StampOriginal"
    )

    -- Ancestry still holds it foreign, unchanged by this phase.
    assertEqual(false, GE.IsLocallyAuthored(copy), "a fork of someone else's work is still someone else's work")
    assertEqual(true, GE.NeedsAuthorConfirm(copy), "so it still needs confirming")
    assertEqual(SOURCE_AUTHOR, GE.CollectForeignAuthors({ "a24Copy" })[1], "and still names the real author")

    -- Saving it takes the ELSE arm and changes none of that. The copy has a
    -- byline, so the first-save branch was never its route -- but the new gate
    -- would ALSO exclude it on provenanceSource, and either way the answer must
    -- not move.
    local stamped = simulateFirstSave(copy)
    assertEqual(false, stamped, "a fork does not re-enter the first-save branch")
    assertEqual(true, GE.NeedsAuthorConfirm(copy), "and still needs confirming after a save")
end)

test("A25 the OTHER import rail marks a bylineless payload too", function()
    -- FOUND BY MEASUREMENT, NOT BY READING. GE.ImportNative is one of two rails
    -- that build a stored record from a native payload. The other is
    -- BuildSeqDataFromGRIP1 in Import/ImportPreview.lua, reached through
    -- LI.CommitSelected -- which is how a pasted string and a received
    -- transmission are ACTUALLY committed, so if anything it is the busier of
    -- the two. Its provenance block was
    --     if <non-empty byline> then ... elseif seq.gseVersion then ... end
    -- with no else, so a payload carrying neither fell through both arms and
    -- landed with provenanceSource nil -- the same shape A22 covers on the
    -- native rail, on the rail A22 does not touch.
    --
    -- The function is file-local, so it is SPLICED out of the shipped source and
    -- run for real. A rename or a reordered body fails the anchor loudly rather
    -- than silently covering nothing.
    local src = readSource({ "Import/ImportPreview.lua", "../Import/ImportPreview.lua" })
    assertTrue(src ~= nil, "could not read Import/ImportPreview.lua")
    local startPos = src:find("local function BuildSeqDataFromGRIP1", 1, true)
    assertTrue(startPos ~= nil, "anchor gone: BuildSeqDataFromGRIP1 not found in ImportPreview.lua")
    local endPos = src:find("\nend\n", startPos, true)
    assertTrue(endPos ~= nil, "anchor gone: no column-0 terminator after BuildSeqDataFromGRIP1")

    local body = src:sub(startPos, endPos + 4) .. "\nreturn BuildSeqDataFromGRIP1\n"
    local spliceEnv = setmetatable({}, { __index = env })
    spliceEnv.GRIPEMS = GRIPEMS
    spliceEnv.D = D
    spliceEnv.L = LOCALE
    spliceEnv.SC = GRIPEMS.SpellCache
    spliceEnv.LI = GRIPEMS.LegacyImport
    local chunk, err = loadstring(body, "BuildSeqDataFromGRIP1-splice")
    assertTrue(chunk ~= nil, "the splice failed to compile: " .. tostring(err))
    setfenv(chunk, spliceEnv)
    local build = chunk()
    assertTrue(type(build) == "function", "the splice defined no function")

    -- The shape under test: no byline, no source stamp.
    local bare = build(wireSequence({}), "a25Bare")
    assertNil(bare.originalAuthor, "no byline is stored, as before")
    assertEqual("no-provenance", bare.provenanceSource, "but this rail must mark it as not originating here too")
    assertEqual(true, GE.NeedsAuthorConfirm(bare), "so it needs confirming")
    assertEqual(false, simulateFirstSave(bare), "and the first-save branch must not fire for it")
    assertEqual(true, GE.NeedsAuthorConfirm(bare), "leaving it still needing confirmation")

    -- CONTROLS: the two arms that already set a provenance must be untouched by
    -- the new fall-through, or this case would pass with the whole block
    -- collapsed into one value.
    local withByline = build(
        wireSequence({ originalAuthor = SOURCE_AUTHOR, originalAuthorIdentity = OTHER_IDENTITY_HASH }),
        "a25Byline"
    )
    assertEqual(SOURCE_AUTHOR, withByline.originalAuthor, "a real byline still lands")
    assertEqual(OTHER_IDENTITY_HASH, withByline.originalAuthorIdentity, "with its identity")
    assertEqual(true, GE.NeedsAuthorConfirm(withByline), "and still needs confirming")

    local converted = build(wireSequence({ gseVersion = 3 }), "a25Converted")
    assertEqual("gse-legacy", converted.provenanceSource, "a converted payload still lands in its own family")
    assertEqual(true, GE.NeedsAuthorConfirm(converted), "and still needs confirming")
end)

-- ---------------------------------------------------------------------------
-- Summary.
-- ---------------------------------------------------------------------------

print(string.format("\n%d/%d passed", passed, passed + failed))
if failed > 0 then
    -- os is dev-harness process control, intentionally outside the addon WoW std.
    -- selene: allow(undefined_variable)
    os.exit(1)
end
