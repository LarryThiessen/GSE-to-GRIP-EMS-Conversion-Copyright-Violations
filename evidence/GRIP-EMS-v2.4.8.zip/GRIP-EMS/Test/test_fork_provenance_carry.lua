-- GRIP-EMS: Headless test for the sharing flags carried across a fork
--
-- Created:    2026-08-24
-- Updated:    2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.
--
-- Standalone (Lua 5.1) test for the two sharing fields that must survive a
-- fork, and the one that must NOT.
--
-- Identity:StampForked resets the original-author trio and re-signs the copy,
-- which is correct: identity and signature follow whoever re-signed. It also
-- dropped noRedistribute and provenanceSource on the floor, which is not: those
-- follow the CONTENT. A duplicate of a do-not-share sequence became shareable,
-- and a duplicate of content converted from another sequencer came out looking
-- natively authored. Both fields are now carried in StampForked, AFTER the
-- StampOriginal call, because StampOriginal writes provenanceSource itself.
--
-- provenanceAttestedBy is the opposite case and is explicitly cleared: the
-- attestation is per-account and per-copy, so a fresh copy starts unattested.
--
-- Every case drives the REAL I:StampForked read off disk. Nothing about the
-- carry is re-implemented here.
--
-- Run from the EMS root:  lua Test/test_fork_provenance_carry.lua
-- Exit code 0 = all passed, 1 = at least one failure.
--
-- Cases:
--   F1  a source with noRedistribute true produces a fork with noRedistribute
--       true, and GE.IsNoRedistribute answers true for BOTH
--   F2  a NATIVELY sourced sequence with noRedistribute true also produces a
--       marked fork. The case that proves the fix is not scoped to converted
--       content -- native + flagged is the shape that shipped broken
--   F3  a source with provenanceSource "gse-legacy" produces a fork whose
--       provenanceSource is still "gse-legacy", and the fork is still gated.
--       Also pins that the gate is no longer a REFUSAL reason, and that the
--       fork STILL NEEDS CONFIRMATION despite carrying the local re-stamp --
--       a fork of someone else's work is still someone else's work
--   F4  a source carrying provenanceAttestedBy produces a fork whose
--       provenanceAttestedBy is nil, and the fork is gated again even in
--       attested mode, where the SOURCE is released. The mode is set through
--       GRIP_EMS_DB.config.provenanceGate, the way a user would set it
--   F5  CONTROL: an unmarked native source produces an unmarked fork that is
--       NOT refused, and whose provenanceSource is what StampOriginal stamps
--       rather than nil
--   F6  CONTROL: a source carrying NO provenanceSource field does not blank the
--       value StampOriginal just stamped. This pins the `or` tail in the carry
--   F7  the identity re-stamp still happens: the fork's originalAuthor is NOT
--       the source's, the source's signature is NOT carried, forkedFrom records
--       the source, and StampForked still refuses a second stamp. This is what
--       proves the carry did not quietly reopen the forgery vector StampForked
--       exists to close
--   D1  the refusal itself: Engine:DuplicateSequence refuses converted content,
--       emits the real enUS string, and registers NOTHING. The F series drives
--       StampForked directly and cannot see this gate, so without D1 the
--       refusal would ship untested
--   D2  CONTROL: DuplicateSequence still ALLOWS an author-marked native
--       sequence. Gating on the combined GE.IsNoRedistribute instead of the
--       provenance predicate would break exactly this case
--   D3  end to end: the copy DuplicateSequence stores is itself refused for
--       sharing. The only case that proves the carry survives the real caller
--       rather than the harness's own fork table

-- ---------------------------------------------------------------------------
-- Minimal assertion + runner harness.
-- ---------------------------------------------------------------------------

local tests = {}

local function test(name, fn)
    tests[#tests + 1] = { name = name, fn = fn }
end

local function assertEqual(expected, actual, label)
    if expected ~= actual then
        error((label or "value") .. ": expected " .. tostring(expected) .. ", got " .. tostring(actual), 2)
    end
end

local function assertNotEqual(unexpected, actual, label)
    if unexpected == actual then
        error((label or "value") .. ": expected anything but " .. tostring(unexpected), 2)
    end
end

local function assertTrue(cond, label)
    if not cond then
        error((label or "condition") .. " failed", 2)
    end
end

local function assertFalse(cond, label)
    if cond then
        error((label or "condition") .. " expected false, got " .. tostring(cond), 2)
    end
end

local function assertNil(actual, label)
    if actual ~= nil then
        error((label or "value") .. ": expected nil, got " .. tostring(actual), 2)
    end
end

-- ---------------------------------------------------------------------------
-- Sandbox for the LOADED MODULES.
--
-- Identity.lua loads standalone: the only WoW surface it touches at file scope
-- is one CreateFrame("Frame") that registers PLAYER_LOGIN. Everything else in
-- this table is reached from inside the functions under test (GetCurrent,
-- GetAuthorOptions, GetAccountRoster) or from Defaults.lua on load.
-- ---------------------------------------------------------------------------

local frameStub = setmetatable({}, {
    __index = function()
        return function() end
    end,
})

local WOW_GLOBALS = {
    CreateFrame = function()
        return frameStub
    end,
    GetLocale = function()
        return "enUS"
    end,
    UnitName = function()
        return "Sataana"
    end,
    UnitClass = function()
        return "Mage", "MAGE", 8
    end,
    UnitFactionGroup = function()
        return "Alliance", "Alliance"
    end,
    GetRealmName = function()
        return "TestRealm"
    end,
    GetNormalizedRealmName = function()
        return "TestRealm"
    end,
    GetCurrentRegion = function()
        return 3
    end,
    -- The presence of a BattleTag is load-bearing: I:GetCurrent reports
    -- source == "battletag", so StampOriginal stamps provenanceSource "native"
    -- rather than "offline-fallback". F5 and F6 assert that exact value.
    BNGetInfo = function()
        return 1, "Tester#1234"
    end,
    C_AddOns = {
        IsAddOnLoaded = function()
            return false
        end,
        GetAddOnMetadata = function()
            return nil
        end,
    },
    C_Timer = {
        After = function() end,
    },
}

local env = setmetatable({}, {
    __index = function(_, k)
        local v = rawget(_G, k)
        if v ~= nil then
            return v
        end
        return WOW_GLOBALS[k]
    end,
})
env._G = env
env.strlower = string.lower
env.strtrim = function(s)
    return (tostring(s):gsub("^%s+", ""):gsub("%s+$", ""))
end
env.time = function()
    return 1000
end
env.date = function(fmt)
    return tostring(fmt)
end

-- Real enUS values, loaded the way the addon loads them, with an echo fallback
-- so a key absent from enUS.lua returns the key rather than nil.
local LOADED_LOCALE = {}
local LOCALE = setmetatable({}, {
    __index = function(_, k)
        return LOADED_LOCALE[k] or k
    end,
})

-- One LibStub for every library name. AceLocale-shaped, which is all enUS.lua
-- asks for; LibHash-1.0 resolves to the same table, has no .sha256, and
-- Identity's _hash falls back to its own djb2 placeholder. That fallback is
-- shipped code and is enough for every hash comparison below, which only ever
-- compares one identity hash against another produced the same way.
env.LibStub = function()
    return {
        GetLocale = function()
            return LOCALE
        end,
        NewLocale = function()
            return LOADED_LOCALE
        end,
    }
end

local GRIPEMS = {
    version = "test",
    Debug = function() end,
    Print = function() end,
    Fire = function() end,
}

env.GRIPEMS = GRIPEMS
env.GRIP_EMS_DB = { config = {} }
env.GRIP_EMS_CHAR = {}

-- Mirrors Core.lua:10 (_G.GRIPEMS = GRIPEMS).
_G.GRIPEMS = GRIPEMS

-- ---------------------------------------------------------------------------
-- Load the REAL modules into the sandbox.
-- ---------------------------------------------------------------------------

local function loadModule(candidates)
    for _, path in ipairs(candidates) do
        -- loadfile is dev-harness file I/O, intentionally outside the addon WoW std.
        -- selene: allow(undefined_variable)
        local chunk = loadfile(path)
        if chunk then
            setfenv(chunk, env)
            chunk("GRIP-EMS", GRIPEMS)
            return true
        end
    end
    return false
end

local MODULES = {
    { "Locale/enUS.lua", "../Locale/enUS.lua" },
    { "Data/Defaults.lua", "../Data/Defaults.lua" },
    { "Engine/Identity.lua", "../Engine/Identity.lua" },
    { "Import/GRIPExport.lua", "../Import/GRIPExport.lua" },
}
for _, candidates in ipairs(MODULES) do
    assertTrue(loadModule(candidates), "could not locate " .. candidates[1] .. " (run from the EMS root)")
end

local I = GRIPEMS.Identity
local GE = GRIPEMS.GRIPExport

assertTrue(type(I) == "table" and type(I.StampForked) == "function", "Identity:StampForked must be loaded")
assertTrue(type(GE) == "table" and type(GE.IsProvenanceGated) == "function", "GRIPExport must be loaded")

-- THE ONLY TWO FUNCTIONS STUBBED, and the reason they are in scope to stub:
-- I:SignSequence and I:SignSequenceV2 canonicalise the whole sequence and hash
-- it, which pulls in LibHash-1.0 and the full canon serialiser. Both are pure
-- WRITERS of signature fields -- originalSignature / originalSignatureV2 /
-- currentSignature / currentSignatureV2 -- and neither reads nor writes any of
-- noRedistribute, provenanceSource or provenanceAttestedBy, the three fields
-- every case below asserts on. Replacing them therefore cannot move a single
-- assertion. StampForked and StampOriginal are NOT stubbed: they are the real
-- shipped source loaded from disk above, and they are what is under test.
-- F7 still pins that the signature fields are REWRITTEN rather than inherited,
-- which these stubs make observable by returning a value no source carries.
I.SignSequence = function()
    return "sig-v1-restamped"
end
I.SignSequenceV2 = function()
    return "sig-v2-restamped"
end

local FORK_NAME = "Fork"
local SOURCE_SIG = "sig-from-the-source"

-- A stored sequence as it sits in Engine.sequences[name].data. Only the fields
-- these cases read are populated; `fields` overlays the sharing / provenance
-- shape each case needs.
local function makeSource(fields)
    local seq = {
        name = "Source",
        originalAuthor = "SomeoneElse",
        originalAuthorIdentity = "0badc0de",
        originalAuthorRealm = "OtherRealm",
        originalAuthorBattleTag = "Someone#0001",
        originalCreatedAt = 500,
        originalSignature = SOURCE_SIG,
        originalSignatureV2 = SOURCE_SIG .. "-v2",
        currentSignature = SOURCE_SIG,
        currentSignatureV2 = SOURCE_SIG .. "-v2",
        signatureAlgorithm = "ALG_V2_SHA256",
        versions = {},
    }
    for k, v in pairs(fields or {}) do
        seq[k] = v
    end
    return seq
end

-- The new table StampForked is handed. Default shape mirrors what
-- Engine:DuplicateSequence builds: CONTENT fields only, none of the sharing or
-- provenance fields, which is exactly why the carry has to exist at all.
--
-- carryEverything mirrors the other realistic caller shape -- copy the source
-- wholesale, then stamp. F4 needs it: with the default shape
-- provenanceAttestedBy is already nil before StampForked runs and the
-- assertion that StampForked clears it could not fail.
local function makeFork(src, carryEverything)
    local newSeq = { name = FORK_NAME, versions = {} }
    if carryEverything then
        for k, v in pairs(src) do
            if newSeq[k] == nil then
                newSeq[k] = v
            end
        end
    end
    return newSeq
end

local function fork(src, carryEverything)
    local newSeq = makeFork(src, carryEverything)
    local stamped = I:StampForked(newSeq, src)
    assertTrue(stamped, "StampForked must report a first stamp")
    return newSeq
end

local function setGateMode(mode)
    env.GRIP_EMS_DB.config.provenanceGate = mode
end

-- ---------------------------------------------------------------------------
-- F1 / F2 -- the author's do-not-share flag survives the copy.
-- ---------------------------------------------------------------------------

test("F1 a fork of a do-not-share source is itself do-not-share", function()
    setGateMode(nil)
    -- No provenanceSource on the source on purpose: the ONLY thing that can
    -- make GE.IsNoRedistribute answer true for the fork here is the carried
    -- flag. A legacy-sourced source would answer true through the provenance
    -- axis and the case would prove nothing about noRedistribute.
    local src = makeSource({ noRedistribute = true })
    local newSeq = fork(src)

    assertEqual(true, newSeq.noRedistribute, "fork.noRedistribute")
    assertTrue(GE.IsNoRedistribute(src), "source must be refused")
    assertTrue(GE.IsNoRedistribute(newSeq), "fork must be refused")
    assertEqual("marked", GE.RefusalReason(newSeq), "fork refusal reason")
end)

test("F2 a NATIVELY sourced do-not-share sequence still forks marked", function()
    setGateMode(nil)
    -- The shape that shipped broken. Nothing about this sequence is converted
    -- content, so the provenance gate never touches it; the flag is the whole
    -- refusal, and before the carry the fork lost it outright.
    local src = makeSource({ noRedistribute = true, provenanceSource = "native" })
    local newSeq = fork(src)

    assertEqual(true, newSeq.noRedistribute, "fork.noRedistribute")
    assertEqual("native", newSeq.provenanceSource, "fork.provenanceSource stays native")
    assertFalse(GE.IsProvenanceGated(newSeq), "a native fork must NOT be provenance gated")
    assertTrue(GE.IsNoRedistribute(newSeq), "fork must be refused on the flag axis alone")
end)

-- ---------------------------------------------------------------------------
-- F3 / F4 -- provenance follows the content across the copy.
-- ---------------------------------------------------------------------------

test("F3 a fork of converted content keeps its provenance and stays gated", function()
    setGateMode(nil)
    local src = makeSource({ provenanceSource = "gse-legacy" })
    local newSeq = fork(src)

    assertEqual("gse-legacy", newSeq.provenanceSource, "fork.provenanceSource")
    assertTrue(GE.IsProvenanceGated(src), "source must be gated")
    assertTrue(GE.IsProvenanceGated(newSeq), "fork must be gated")

    -- RESTATED. This line used to be
    --   assertEqual("provenance", GE.RefusalReason(newSeq), "fork refusal reason")
    -- The gate stopped refusing and started asking (2026-08-24), so it is not a
    -- refusal reason any more and GE.RefusalReason answers only the author's own
    -- flag. The carry itself is unchanged and is still asserted above: the fork
    -- is still gse-legacy and still unproven.
    assertNil(GE.RefusalReason(newSeq), "a gated fork is no longer REFUSED, so it has no refusal reason")
    assertTrue(GE.NeedsAuthorConfirm(src), "the SOURCE still needs the player's confirmation before it leaves")

    -- RESTATED, and this is the SAME CASE DOING THE SAME JOB. This line used to
    -- be
    --   assertFalse(GE.NeedsAuthorConfirm(newSeq), "a re-stamped fork reads as locally authored")
    -- written on 2026-08-25 to PIN A HOLE: StampForked clears the
    -- original-author trio and StampOriginal re-stamps it with THIS account, so
    -- by GE.IsLocallyAuthored the copy read as written here and
    -- duplicate-then-share was a route around the confirmation. The comment
    -- above it said in as many words that a future change to either predicate
    -- should fail a case rather than quietly widen the route.
    --
    -- That change has now happened, and this is the case failing. The hole is
    -- closed: GE.IsLocallyAuthored reads forkedFrom and forkedFromChain, so an
    -- ancestor that is not the local player makes the copy answer "someone
    -- else's work" no matter whose stamp is on it. The assertion inverts and the
    -- case keeps its job -- it pinned the hole, it now pins the closure, and
    -- either way it is the line that moves if the fork rule moves.
    --
    -- The fixture's ancestor is CONVERTED content, whose identity is "" because
    -- that format offers no hash. An unidentifiable ancestor counts as not the
    -- local player, which is why this particular fork needs confirming twice
    -- over: unproven provenance AND unproven ancestry.
    assertTrue(GE.NeedsAuthorConfirm(newSeq), "a fork of someone else's work is still someone else's work")

    -- StampForked itself is UNCHANGED and this proves it: the copy still carries
    -- the local re-stamp. The verdict moved because of what IsLocallyAuthored
    -- CONCLUDES from that stamp plus the lineage, not because the stamp moved.
    local me = I:GetCurrent()
    assertEqual(me.identityHash, newSeq.originalAuthorIdentity, "the fork must still carry the local re-stamp")
    assertFalse(GE.IsLocallyAuthored(newSeq), "and must still not read as locally authored")
end)

test("F4 the attestation does not ride along and the fork is gated again", function()
    setGateMode("attested")
    local me = I:GetCurrent()
    assertTrue(
        type(me.identityHash) == "string" and me.identityHash ~= "",
        "the harness identity must produce a hash or F4 is vacuous"
    )

    -- The source is released: converted content this very account attested.
    local src = makeSource({
        provenanceSource = "gse-legacy",
        provenanceAttestedBy = me.identityHash,
    })
    assertFalse(GE.IsProvenanceGated(src), "an attested source must be released in attested mode")

    -- carryEverything: the fork ARRIVES carrying the attestation, so clearing
    -- it is an observable act rather than an accident of the fork's shape.
    local newSeq = fork(src, true)

    assertNil(newSeq.provenanceAttestedBy, "fork.provenanceAttestedBy")
    assertEqual("gse-legacy", newSeq.provenanceSource, "fork.provenanceSource")
    assertTrue(GE.IsProvenanceGated(newSeq), "fork must be gated again even in attested mode")

    setGateMode(nil)
end)

-- ---------------------------------------------------------------------------
-- F5 / F6 -- the controls. Without these, the carry could be a blanket copy or
-- a blanket nil and every case above would still pass.
-- ---------------------------------------------------------------------------

test("F5 CONTROL an unmarked native source forks unmarked and unrefused", function()
    setGateMode(nil)
    local src = makeSource({ provenanceSource = "native" })
    local newSeq = fork(src)

    assertNil(newSeq.noRedistribute, "fork.noRedistribute must stay unset")
    assertEqual("native", newSeq.provenanceSource, "fork.provenanceSource")
    assertFalse(GE.IsNoRedistribute(newSeq), "an unmarked fork must NOT be refused")
    assertNil(GE.RefusalReason(newSeq), "an unmarked fork has no refusal reason")
end)

test("F6 CONTROL a source with no provenance field does not blank the stamp", function()
    setGateMode(nil)
    -- Pins the `or newSeq.provenanceSource` tail. A bare assignment would write
    -- nil here and erase what StampOriginal stamped one line earlier, turning
    -- every pre-provenance stored sequence into an unattributed fork.
    local src = makeSource({})
    assertNil(src.provenanceSource, "the source must genuinely carry no provenance field")

    local newSeq = fork(src)
    assertEqual("native", newSeq.provenanceSource, "fork keeps what StampOriginal stamped")
end)

-- ---------------------------------------------------------------------------
-- F7 -- the forgery vector StampForked exists to close is still closed.
-- ---------------------------------------------------------------------------

test("F7 the identity re-stamp is untouched by the carry", function()
    setGateMode(nil)
    local src = makeSource({ noRedistribute = true, provenanceSource = "gse-legacy" })
    local newSeq = fork(src)

    -- Identity follows whoever re-signed, so NONE of the source's author trio
    -- may appear on the fork.
    assertEqual("Sataana", newSeq.originalAuthor, "fork.originalAuthor is the local user")
    assertNotEqual(src.originalAuthor, newSeq.originalAuthor, "fork must not inherit the source author")
    assertNotEqual(
        src.originalAuthorIdentity,
        newSeq.originalAuthorIdentity,
        "fork must not inherit the source identity hash"
    )
    assertNotEqual(src.originalAuthorBattleTag, newSeq.originalAuthorBattleTag, "fork must not inherit the source tag")

    -- And the signature is re-issued, not inherited.
    assertNotEqual(SOURCE_SIG, newSeq.originalSignature, "fork must not inherit the source signature")
    assertEqual("sig-v1-restamped", newSeq.originalSignature, "fork carries a freshly issued signature")
    assertEqual(newSeq.originalSignature, newSeq.currentSignature, "fork current signature matches original")

    -- Lineage is recorded rather than erased.
    assertTrue(type(newSeq.forkedFrom) == "table", "fork.forkedFrom must exist")
    assertEqual(src.originalAuthor, newSeq.forkedFrom.originalAuthor, "forkedFrom records the source author")
    assertEqual(SOURCE_SIG, newSeq.forkedFrom.originalSignature, "forkedFrom records the source signature")
    assertEqual("forked-from", newSeq.modifierChain[1].kind, "the chain begins at the fork point")

    -- The idempotent guard still refuses a second stamp: re-stamping would
    -- overwrite forkedFrom and lose the lineage the first stamp recorded.
    local restamped = I:StampForked(newSeq, src)
    assertFalse(restamped, "StampForked must refuse an already-forked sequence")
    assertEqual(src.originalAuthor, newSeq.forkedFrom.originalAuthor, "lineage survives the refused re-stamp")
end)

-- ---------------------------------------------------------------------------
-- D1 / D2 / D3 -- the Engine:DuplicateSequence refusal itself.
--
-- The F series drives StampForked directly and therefore cannot see the gate
-- that sits in DuplicateSequence, so the refusal would otherwise ship
-- untested. Engine.lua as a whole needs the Popup / OOCQueue / secure-frame
-- surface this harness deliberately does not stand up, so the ONE function is
-- spliced out of the real shipped source at run time, the same way the sibling
-- harness lifts Engine:SubstituteVariables. If the function is renamed or its
-- body reordered past the column-0 terminator, the splice fails loudly rather
-- than silently covering nothing.
-- ---------------------------------------------------------------------------

local function readFile(candidates)
    for _, path in ipairs(candidates) do
        -- io is dev-harness file I/O, intentionally outside the addon WoW std.
        -- selene: allow(undefined_variable)
        local fh = io.open(path, "r")
        if fh then
            local text = fh:read("*a")
            fh:close()
            return text
        end
    end
    return nil
end

local D = GRIPEMS.Defaults

local spliceEnv = setmetatable({}, { __index = env })
spliceEnv.D = D
spliceEnv.L = LOCALE
spliceEnv.GRIPEMS = GRIPEMS
spliceEnv.Engine = {
    sequences = {},
    ActivateSequence = function(self, name, seqData)
        self.sequences[name] = { data = seqData }
    end,
}

local function spliceDuplicateSequence()
    local src = readFile({ "Engine/Engine.lua", "../Engine/Engine.lua" })
    assertTrue(src ~= nil, "could not read Engine/Engine.lua for the D splice")
    local startPos = src:find("function Engine:DuplicateSequence", 1, true)
    assertTrue(startPos ~= nil, "D anchor gone: Engine:DuplicateSequence not found in Engine.lua")
    local endPos = src:find("\nend\n", startPos, true)
    assertTrue(endPos ~= nil, "D anchor gone: no column-0 terminator after Engine:DuplicateSequence")
    local chunk, err = loadstring(src:sub(startPos, endPos + 4), "DuplicateSequence-splice")
    assertTrue(chunk ~= nil, "D splice failed to compile: " .. tostring(err))
    setfenv(chunk, spliceEnv)
    chunk()
    assertTrue(type(spliceEnv.Engine.DuplicateSequence) == "function", "D splice defined no function")
    return spliceEnv.Engine
end

local SplicedEngine = spliceDuplicateSequence()

--- Register a stored sequence the way Engine.sequences holds one.
local function store(name, seq)
    seq.name = name
    SplicedEngine.sequences[name] = { data = seq }
    return seq
end

test("D1 DuplicateSequence refuses converted content and builds nothing", function()
    setGateMode(nil)
    store("Converted", makeSource({ provenanceSource = "gse-legacy" }))

    local ok, msg = SplicedEngine:DuplicateSequence("Converted", "Converted Copy")
    assertFalse(ok, "DuplicateSequence must refuse a provenance-gated source")

    -- The refusal has to be a real shipped string, not the echoed key: an
    -- absent locale entry would surface the raw key to the user.
    local template = LOCALE["GEMS_DUPLICATE_PROVENANCE_GATED"]
    assertNotEqual("GEMS_DUPLICATE_PROVENANCE_GATED", template, "the locale key must resolve to a real enUS string")
    assertEqual(string.format(template, "Converted"), msg, "refusal message")

    -- Nothing half-built: the gate sits above the newData literal, so a refusal
    -- cannot leave a partial sequence in the store.
    assertNil(SplicedEngine.sequences["Converted Copy"], "a refused duplicate must not be registered")
end)

test("D2 DuplicateSequence still ALLOWS an author-marked native sequence", function()
    setGateMode(nil)
    store("Marked", makeSource({ noRedistribute = true, provenanceSource = "native" }))

    -- The reason the gate is the PROVENANCE predicate and not the combined
    -- GE.IsNoRedistribute. Copying content you imported so you can edit it for
    -- your own use is legitimate; sharing it is what stays refused. Gating on
    -- the combined predicate would break this case, which is exactly why it is
    -- pinned here.
    assertTrue(GE.IsNoRedistribute(SplicedEngine.sequences["Marked"].data), "the fixture must be refused for SHARING")

    local ok, msg = SplicedEngine:DuplicateSequence("Marked", "Marked Copy")
    assertTrue(ok, "duplicating a do-not-share sequence must stay allowed (" .. tostring(msg) .. ")")
    assertTrue(SplicedEngine.sequences["Marked Copy"] ~= nil, "the copy must be registered")
end)

test("D3 the copy DuplicateSequence produces is itself refused for sharing", function()
    setGateMode(nil)
    store("Marked2", makeSource({ noRedistribute = true, provenanceSource = "native" }))

    local ok = SplicedEngine:DuplicateSequence("Marked2", "Marked2 Copy")
    assertTrue(ok, "duplicate must succeed")

    -- End to end through the REAL DuplicateSequence: the flag reaches the
    -- STORED copy, not merely the table StampForked was handed.
    local copy = SplicedEngine.sequences["Marked2 Copy"].data
    assertEqual(true, copy.noRedistribute, "stored copy keeps the do-not-share flag")
    assertTrue(GE.IsNoRedistribute(copy), "the stored copy must be refused for sharing")
    assertEqual("Marked2 Copy", copy.name, "the copy carries its own name")
end)

-- ---------------------------------------------------------------------------
-- Runner.
-- ---------------------------------------------------------------------------

local failures = 0
for _, t in ipairs(tests) do
    local ok, err = pcall(t.fn)
    if ok then
        print("PASS  " .. t.name)
    else
        failures = failures + 1
        print("FAIL  " .. t.name)
        print("      " .. tostring(err))
    end
end

print("")
print(string.format("%d/%d passed", #tests - failures, #tests))
if failures > 0 then
    -- os is dev-harness process control, intentionally outside the addon WoW std.
    -- selene: allow(undefined_variable)
    os.exit(1)
end
