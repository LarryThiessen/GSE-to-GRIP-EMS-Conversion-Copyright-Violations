-- GRIP-EMS: Focus Ring (Phase 2 #8)
-- Created: 2026-04-19
-- Updated: 2026-06-21
-- Patch: 12.0.7.68256 Midnight (Retail LIVE)
--
-- High-contrast outlined keyboard-focus ring. Attached to the central
-- Focus manager via Focus:RegisterListener. Reads its color live from
-- UI.Colors.focusRing so palette switches take effect immediately.
-- 2px outset on all sides, 4 edge textures (no backdrop template).

local ADDON_NAME, GRIPEMS = ...

GRIPEMS.UI = GRIPEMS.UI or {}
local UI = GRIPEMS.UI

local FocusRing = {}
GRIPEMS.UI.FocusRing = FocusRing

local ring
local RING_THICKNESS = 2
local RING_THICKNESS_SIMPLIFIED = 4
local RING_OUTSET = 2

-- Simplified Mode (Phase S2): a thicker ring reads better at a distance
-- and for CVD users. The picker reads the accessibility flag on every
-- anchorTo pass so toggling the setting takes effect on the next focus
-- change with no reload.
local function currentThickness()
    local acc = GRIPEMS.Settings
        and GRIPEMS.Settings.db
        and GRIPEMS.Settings.db.profile
        and GRIPEMS.Settings.db.profile.accessibility
    if acc and acc.simplifiedMode then
        return RING_THICKNESS_SIMPLIFIED
    end
    return RING_THICKNESS
end

local function createRing()
    local f = GRIPEMS.UI:ReclaimFrame("GRIPEMS_FocusRing", "Frame", UIParent)
    f:SetFrameStrata("TOOLTIP")
    f:SetFrameLevel(100)
    f:Hide()

    -- Inventory surviving texture regions once. ReclaimFrame hides
    -- regions on /reload but cannot unparent textures (WoW textures
    -- are bound to the creating frame for that frame's lifetime).
    -- Reuse anything we find before creating more.
    local pool = {}
    for _, r in ipairs({ f:GetRegions() }) do
        if r.GetObjectType and r:GetObjectType() == "Texture" then
            pool[#pool + 1] = r
        end
    end

    -- Prefer a name-match (stable across /reload in the post-
    -- POLISH-02 era). Absorb any unclaimed texture next -- covers
    -- the one-time upgrade path from pre-POLISH-02 builds that
    -- created anonymous textures, so no orphans survive the first
    -- post-upgrade /reload. Create fresh only if the pool is out.
    local claimed = {}
    local function ensureEdge(texName)
        for _, r in ipairs(pool) do
            if not claimed[r] and r.GetName and r:GetName() == texName then
                claimed[r] = true
                return r
            end
        end
        for _, r in ipairs(pool) do
            if not claimed[r] then
                claimed[r] = true
                return r
            end
        end
        return f:CreateTexture(texName, "OVERLAY")
    end
    f.top = ensureEdge("GRIPEMS_FocusRing_Top")
    f.bottom = ensureEdge("GRIPEMS_FocusRing_Bottom")
    f.left = ensureEdge("GRIPEMS_FocusRing_Left")
    f.right = ensureEdge("GRIPEMS_FocusRing_Right")

    return f
end

local function applyColor(f)
    local c = UI.Colors and UI.Colors.focusRing
    local r, g, b, a
    if c and c.GetRGBA then
        r, g, b, a = c:GetRGBA()
    else
        r, g, b, a = 1.0, 0.85, 0.10, 1
    end
    f.top:SetColorTexture(r, g, b, a)
    f.bottom:SetColorTexture(r, g, b, a)
    f.left:SetColorTexture(r, g, b, a)
    f.right:SetColorTexture(r, g, b, a)
end

local function findAncestorRegion(widget)
    local Focus = GRIPEMS.Focus
    if not Focus or not Focus._regions then
        return nil
    end
    -- Sort region names once so the ancestry walk is deterministic
    -- regardless of pairs() hash order. Region count stays small so
    -- O(n log n) per focus change is negligible.
    local names = {}
    for name in pairs(Focus._regions) do
        names[#names + 1] = name
    end
    table.sort(names)
    local node = widget
    while node do
        for i = 1, #names do
            local region = Focus._regions[names[i]]
            if node == region then
                return region
            end
        end
        if node.GetParent then
            node = node:GetParent()
        else
            return nil
        end
    end
    return nil
end

local function findScrollAncestor(widget)
    local node = widget and widget.GetParent and widget:GetParent() or nil
    while node do
        if node.GetObjectType and node:GetObjectType() == "ScrollFrame" then
            return node
        end
        if node.GetParent then
            node = node:GetParent()
        else
            return nil
        end
    end
    return nil
end

local function isWithinScroll(widget, scroll)
    if not widget or not scroll or not widget.GetTop then
        return true
    end
    local top, bottom = widget:GetTop(), widget:GetBottom()
    local sTop, sBottom = scroll:GetTop(), scroll:GetBottom()
    if not (top and bottom and sTop and sBottom) then
        return true
    end
    return bottom >= sBottom and top <= sTop
end

local function anchorTo(widget)
    if not widget or not widget.GetObjectType then
        ring:Hide()
        return
    end
    local region = findAncestorRegion(widget)
    if region and ring:GetParent() ~= region then
        ring:SetParent(region)
        ring:SetFrameStrata("TOOLTIP")
        ring:SetFrameLevel(100)
    elseif (not region) and ring:GetParent() ~= UIParent then
        ring:SetParent(UIParent)
        ring:SetFrameStrata("TOOLTIP")
        ring:SetFrameLevel(100)
    end
    local scroll = findScrollAncestor(widget)
    if scroll and not isWithinScroll(widget, scroll) then
        ring:Hide()
        return
    end
    local thickness = currentThickness()
    local ok = pcall(function()
        ring:ClearAllPoints()
        ring:SetPoint("TOPLEFT", widget, "TOPLEFT", -RING_OUTSET, RING_OUTSET)
        ring:SetPoint("BOTTOMRIGHT", widget, "BOTTOMRIGHT", RING_OUTSET, -RING_OUTSET)

        ring.top:ClearAllPoints()
        ring.top:SetPoint("TOPLEFT", ring, "TOPLEFT", 0, 0)
        ring.top:SetPoint("TOPRIGHT", ring, "TOPRIGHT", 0, 0)
        ring.top:SetHeight(thickness)

        ring.bottom:ClearAllPoints()
        ring.bottom:SetPoint("BOTTOMLEFT", ring, "BOTTOMLEFT", 0, 0)
        ring.bottom:SetPoint("BOTTOMRIGHT", ring, "BOTTOMRIGHT", 0, 0)
        ring.bottom:SetHeight(thickness)

        ring.left:ClearAllPoints()
        ring.left:SetPoint("TOPLEFT", ring, "TOPLEFT", 0, 0)
        ring.left:SetPoint("BOTTOMLEFT", ring, "BOTTOMLEFT", 0, 0)
        ring.left:SetWidth(thickness)

        ring.right:ClearAllPoints()
        ring.right:SetPoint("TOPRIGHT", ring, "TOPRIGHT", 0, 0)
        ring.right:SetPoint("BOTTOMRIGHT", ring, "BOTTOMRIGHT", 0, 0)
        ring.right:SetWidth(thickness)

        applyColor(ring)
        ring:Show()
    end)
    if not ok then
        ring:Hide()
    end
end

local function onFocusChange(current, prev)
    if not ring then
        return
    end
    if not current then
        ring:Hide()
        return
    end
    if current.IsVisible and not current:IsVisible() then
        ring:Hide()
        return
    end
    anchorTo(current)
end

function FocusRing:Init()
    if ring then
        return
    end
    ring = createRing()
    applyColor(ring)

    if GRIPEMS.UI and GRIPEMS.UI.RegisterElement then
        GRIPEMS.UI:RegisterElement(ring, "emphasis.focusRing")
    end

    if GRIPEMS.Focus and GRIPEMS.Focus.RegisterListener then
        GRIPEMS.Focus:RegisterListener(onFocusChange)
    end

    if UI.OnPaletteChanged then
        UI:OnPaletteChanged(function()
            if ring and ring:IsShown() then
                applyColor(ring)
            end
        end)
    end

    ring:SetScript("OnUpdate", function(self, elapsed)
        self._t = (self._t or 0) + elapsed
        if self._t < 0.25 then
            return
        end
        self._t = 0
        local current = GRIPEMS.Focus and GRIPEMS.Focus:GetCurrent()
        if not current then
            self:Hide()
            return
        end
        if current.IsVisible and not current:IsVisible() then
            self:Hide()
            return
        end
        local scroll = findScrollAncestor(current)
        if scroll and not isWithinScroll(current, scroll) then
            self:Hide()
        end
    end)
end

function FocusRing:Hide()
    if ring then
        ring:Hide()
    end
end

--- Fade the ring to 50% alpha for the Simplified Mode lockout duration,
--- then snap back to full opacity. Tells the user the activation was
--- accepted and that further presses on this widget will be ignored
--- until the lockout clears. Duration reads from
--- accessibility.simplifiedDelay (default 500 ms). Early-outs when
--- simplifiedMode is off, or when the ring is not built / not shown.
--- Called by Focus:Activate after the per-widget lockout accepts.
function FocusRing:FlashActivate()
    if not ring then
        return
    end
    local acc = GRIPEMS.Settings
        and GRIPEMS.Settings.db
        and GRIPEMS.Settings.db.profile
        and GRIPEMS.Settings.db.profile.accessibility
    if not (acc and acc.simplifiedMode) then
        return
    end
    local current = GRIPEMS.Focus and GRIPEMS.Focus:GetCurrent()
    if current then
        -- re-anchor (local forward-declared) to ensure ring tracks
        -- the currently focused widget before we fade.
        anchorTo(current)
    end
    if not ring:IsShown() then
        return
    end
    local delaySec = (acc.simplifiedDelay or 500) / 1000
    ring:SetAlpha(0.5)
    if C_Timer and C_Timer.After then
        C_Timer.After(delaySec, function()
            if ring and ring.SetAlpha then
                ring:SetAlpha(1.0)
            end
        end)
    end
end
