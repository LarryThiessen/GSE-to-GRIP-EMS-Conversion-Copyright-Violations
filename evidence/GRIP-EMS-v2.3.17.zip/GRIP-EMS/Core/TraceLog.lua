-- GRIP-EMS: TraceLog
-- Created: 2026-06-05
-- Updated: 2026-06-21
-- Patch: 12.0.7.68256 Midnight (Retail LIVE)

-- GRIP-EMS: Persistent trace log
-- Mirrors restricted-env Execute failures (and, when debug is on, general
-- debug events) into the GRIP_EMS_TRACE account SavedVariable so they survive
-- /reload. Capped rings keep the saved global small enough to read in one pass.

local ADDON_NAME, GRIPEMS = ...

GRIPEMS.Trace = {}
local Trace = GRIPEMS.Trace

local function D()
    return GRIPEMS.Defaults
end

local function InitDB()
    if type(GRIP_EMS_TRACE) ~= "table" then
        GRIP_EMS_TRACE = {}
    end
    GRIP_EMS_TRACE.failures = GRIP_EMS_TRACE.failures or {}
    GRIP_EMS_TRACE.events = GRIP_EMS_TRACE.events or {}
    GRIP_EMS_TRACE.schema = 1
    Trace.db = GRIP_EMS_TRACE
end

local loader = CreateFrame("Frame")
loader:RegisterEvent("ADDON_LOADED")
loader:SetScript("OnEvent", function(_, _, name)
    if name == ADDON_NAME then
        InitDB()
        loader:UnregisterEvent("ADDON_LOADED")
    end
end)

local function PushCapped(ring, rec, maxLen)
    ring[#ring + 1] = rec
    while #ring > maxLen do
        table.remove(ring, 1)
    end
end

local function CurrentSpecID()
    local idx = GetSpecialization and GetSpecialization()
    if not idx then
        return 0
    end
    local id = GetSpecializationInfo and GetSpecializationInfo(idx)
    return id or 0
end

local function UnresolvedCount()
    local SC = GRIPEMS.SpellCache
    if not SC or type(SC._unresolvedAfterScan) ~= "table" then
        return 0
    end
    local n = 0
    for _ in pairs(SC._unresolvedAfterScan) do
        n = n + 1
    end
    return n
end

--- Record a restricted-env Execute failure or brace deferral to the SV.
--- @param name string Sequence name
--- @param execStr string The execStr that was about to be loaded
--- @param bracePos number|nil 1-based index of the first brace, if any
--- @param compiledSteps table|nil Compiled steps array
--- @param label string Call-site label ("base", "variant 2", "recompile", ...)
--- @param kind string "brace" | "brace-permanent" | "execute"
--- @param err any Error captured from pcall (execute kind only)
function Trace:RecordExecuteFailure(name, execStr, bracePos, compiledSteps, label, kind, err)
    if not Trace.db then
        InitDB()
    end
    if type(execStr) ~= "string" then
        execStr = tostring(execStr)
    end
    local defaults = D()
    local win = (defaults and defaults.TRACE_BRACE_WINDOW) or 80
    local braceCtx
    if bracePos then
        local lo = math.max(1, bracePos - win)
        local hi = math.min(#execStr, bracePos + win)
        braceCtx = execStr:sub(lo, hi)
    end
    local rec = {
        t = date("%Y-%m-%d %H:%M:%S"),
        gt = math.floor(GetTime()),
        v = (C_AddOns and C_AddOns.GetAddOnMetadata and C_AddOns.GetAddOnMetadata(ADDON_NAME, "Version")) or "?",
        realm = (GetRealmName and GetRealmName()) or "?",
        char = (UnitName and UnitName("player")) or "?",
        class = select(2, UnitClass("player")) or "?",
        spec = CurrentSpecID(),
        seq = tostring(name),
        label = tostring(label or "?"),
        kind = tostring(kind or "?"),
        err = err and tostring(err) or nil,
        execLen = #execStr,
        bracePos = bracePos,
        brace = braceCtx,
        head = execStr:sub(1, 200),
        steps = compiledSteps and #compiledSteps or 0,
        combat = InCombatLockdown() and 1 or 0,
        inst = select(2, IsInInstance()),
        diff = select(3, GetInstanceInfo()),
        scReady = (GRIPEMS.SpellCache and GRIPEMS.SpellCache.ready) and 1 or 0,
        scUnresolved = UnresolvedCount(),
    }
    local maxF = (defaults and defaults.TRACE_MAX_FAILURES) or 60
    PushCapped(Trace.db.failures, rec, maxF)
end

--- Record a general debug event (only when the debug setting is enabled).
--- Called from DebugWindow:AddMessage.
--- @param msg string Formatted message
function Trace:RecordEvent(msg)
    if Trace._suspend then
        return
    end
    local S = GRIPEMS.Settings
    if not (S and S.Get and S:Get("debug")) then
        return
    end
    if not Trace.db then
        InitDB()
    end
    local defaults = D()
    local maxE = (defaults and defaults.TRACE_MAX_EVENTS) or 400
    PushCapped(Trace.db.events, { t = date("%H:%M:%S"), m = tostring(msg) }, maxE)
end

--- Wipe the persisted trace rings.
function Trace:Wipe()
    if not Trace.db then
        InitDB()
    end
    wipe(Trace.db.failures)
    wipe(Trace.db.events)
end
