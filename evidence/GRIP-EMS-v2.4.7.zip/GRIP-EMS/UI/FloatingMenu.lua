-- GRIP-EMS: Floating Menu
-- Movable quick-access button bar for common actions
--
-- Created:    2025 (pre-stamping; exact date unknown)
-- Updated:    2026-08-17
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)

local ADDON_NAME, GRIPEMS = ...

GRIPEMS.FloatingMenu = {}
local FM = GRIPEMS.FloatingMenu
local UI = GRIPEMS.UI
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

-- Upvalue accessors (modules load before UI/)
local function S()
    return GRIPEMS.Settings
end

---------------------------------------------------------------------------
-- Constants
---------------------------------------------------------------------------
local collapsed = false

local BUTTON_SIZE = 32
local BUTTON_PADDING = 4
local FRAME_PADDING = 6
local DEFAULT_POS = { "CENTER", nil, "CENTER", 0, 0 }

---------------------------------------------------------------------------
-- Button definitions
---------------------------------------------------------------------------
local BUTTON_DEFS = {
    {
        key = "sequences",
        icon = "Ability_Rogue_MasterOfSubtlety",
        localeKey = "GEMS_FLOATING_BTN_SEQUENCES",
        onClick = function()
            if GRIPEMS.UI and GRIPEMS.UI.ToggleMainFrame then
                GRIPEMS.UI:ToggleMainFrame()
            end
        end,
    },
    {
        key = "import",
        icon = "INV_Letter_01",
        localeKey = "GEMS_FLOATING_BTN_IMPORT",
        onClick = function()
            if GRIPEMS.ImportFrame then
                GRIPEMS.ImportFrame:Show()
            end
        end,
    },
    {
        key = "export",
        icon = "INV_Letter_02",
        localeKey = "GEMS_FLOATING_BTN_EXPORT",
        onClick = function()
            if GRIPEMS.ExportFrame then
                GRIPEMS.ExportFrame:Show()
            end
        end,
    },
    {
        key = "variables",
        icon = "INV_Misc_Gear_01",
        localeKey = "GEMS_FLOATING_BTN_VARIABLES",
        onClick = function()
            if GRIPEMS_MainFrame then
                GRIPEMS_MainFrame:Show()
            end
            if GRIPEMS.MainFrame and GRIPEMS.MainFrame.SelectTab then
                GRIPEMS.MainFrame:SelectTab("variables")
            end
        end,
    },
    {
        key = "tracker",
        icon = "Ability_Hunter_SteadyShot",
        localeKey = "GEMS_FLOATING_BTN_TRACKER",
        onClick = function()
            if GRIPEMS.TrackerHUD then
                GRIPEMS.TrackerHUD:Toggle()
            end
        end,
    },
    {
        key = "options",
        icon = "Trade_Engineering",
        localeKey = "GEMS_FLOATING_BTN_OPTIONS",
        onClick = function()
            local ok = pcall(Settings.OpenToCategory, "GRIP-EMS")
            if not ok and GRIPEMS.SettingsPanel then
                GRIPEMS.SettingsPanel:Open()
            end
        end,
    },
    {
        key = "collapse",
        icon = "Spell_ChargeNegative",
        localeKey = "GEMS_FLOATING_BTN_COLLAPSE",
        onClick = function()
            collapsed = true
            FM:UpdateCollapsedState()
        end,
    },
}

---------------------------------------------------------------------------
-- Button creation
---------------------------------------------------------------------------
local function CreateMenuButton(parent, def)
    local btn = CreateFrame("Button", nil, parent)
    btn:SetSize(BUTTON_SIZE, BUTTON_SIZE)
    UI:RegisterLargeTarget(btn)
    btn:SetNormalTexture("Interface\\Icons\\" .. def.icon)
    local hl = btn:CreateTexture(nil, "HIGHLIGHT")
    hl:SetAllPoints()
    hl:SetColorTexture(1, 1, 1, 0.3)
    btn:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText(L[def.localeKey] or def.key, 1, 1, 1)
        GameTooltip:Show()
    end)
    btn:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)
    btn:SetScript("OnClick", def.onClick)
    return btn
end

---------------------------------------------------------------------------
-- Layout
---------------------------------------------------------------------------
local function LayoutButtons()
    if not FM.frame or not FM.buttons then
        return
    end
    local dir = S():Get("floatingMenuDirection") or "DOWN"
    local count = #FM.buttons

    for i, btn in ipairs(FM.buttons) do
        btn:ClearAllPoints()
        local idx = i - 1
        if dir == "DOWN" then
            btn:SetPoint(
                "TOPLEFT",
                FM.frame,
                "TOPLEFT",
                FRAME_PADDING,
                -(FRAME_PADDING + idx * (BUTTON_SIZE + BUTTON_PADDING))
            )
        elseif dir == "UP" then
            btn:SetPoint(
                "BOTTOMLEFT",
                FM.frame,
                "BOTTOMLEFT",
                FRAME_PADDING,
                FRAME_PADDING + idx * (BUTTON_SIZE + BUTTON_PADDING)
            )
        elseif dir == "RIGHT" then
            btn:SetPoint(
                "TOPLEFT",
                FM.frame,
                "TOPLEFT",
                FRAME_PADDING + idx * (BUTTON_SIZE + BUTTON_PADDING),
                -FRAME_PADDING
            )
        elseif dir == "LEFT" then
            btn:SetPoint(
                "TOPRIGHT",
                FM.frame,
                "TOPRIGHT",
                -(FRAME_PADDING + idx * (BUTTON_SIZE + BUTTON_PADDING)),
                -FRAME_PADDING
            )
        end
    end

    -- Resize frame to fit
    local totalBtn = count * BUTTON_SIZE + (count - 1) * BUTTON_PADDING
    local w, h
    if dir == "DOWN" or dir == "UP" then
        w = BUTTON_SIZE + FRAME_PADDING * 2
        h = totalBtn + FRAME_PADDING * 2
    else
        w = totalBtn + FRAME_PADDING * 2
        h = BUTTON_SIZE + FRAME_PADDING * 2
    end
    FM.frame:SetSize(w, h)
end

---------------------------------------------------------------------------
-- Frame creation
---------------------------------------------------------------------------
local function CreateMenuFrame()
    local C = UI.Colors

    local frame = UI:ReclaimFrame("GRIPEMS_FloatingMenu", "Frame", UIParent, "BackdropTemplate")
    frame:SetSize(60, 60)
    frame:SetFrameStrata("MEDIUM")
    frame:SetFrameLevel(90)
    UI:ApplyBackdrop(frame, UI.Backdrops.panel, CreateColor(0.12, 0.12, 0.14, 0.9), C.border)
    if GRIPEMS.UI and GRIPEMS.UI.RegisterPanelFrame then
        GRIPEMS.UI:RegisterPanelFrame(frame, "overlay", "overlay.menu")
    end
    frame:SetClampedToScreen(true)
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", function(self)
        if not S():Get("floatingMenuLocked") then
            self:StartMoving()
        end
    end)
    frame:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        FM:SavePosition()
    end)
    frame:Hide()

    -- Right-click context menu
    frame:SetScript("OnMouseDown", function(self, button)
        if button == "RightButton" then
            MenuUtil.CreateContextMenu(self, function(_, rootDesc)
                -- Direction submenu
                local dirSub = rootDesc:CreateButton(L["GEMS_FLOATING_DIRECTION_DESC"])
                local dirs = {
                    { "UP", L["GEMS_FLOATING_DIR_UP"] },
                    { "DOWN", L["GEMS_FLOATING_DIR_DOWN"] },
                    { "LEFT", L["GEMS_FLOATING_DIR_LEFT"] },
                    { "RIGHT", L["GEMS_FLOATING_DIR_RIGHT"] },
                }
                for _, pair in ipairs(dirs) do
                    local dirVal, dirLabel = pair[1], pair[2]
                    local item = dirSub:CreateRadio(dirLabel, function()
                        return S():Get("floatingMenuDirection") == dirVal
                    end, function()
                        S():Set("floatingMenuDirection", dirVal)
                    end)
                    item:SetResponse(MenuResponse.Refresh)
                end

                -- Lock/Unlock toggle
                local locked = S():Get("floatingMenuLocked")
                local lockLabel = locked and L["GEMS_FLOATING_UNLOCKED"] or L["GEMS_FLOATING_LOCKED"]
                rootDesc:CreateButton(lockLabel, function()
                    local isLocked = S():Get("floatingMenuLocked")
                    S():Set("floatingMenuLocked", not isLocked)
                    if isLocked then
                        GRIPEMS:Print(L["GEMS_FLOATING_UNLOCKED"])
                    else
                        GRIPEMS:Print(L["GEMS_FLOATING_LOCKED"])
                    end
                end)

                rootDesc:CreateDivider()
                rootDesc:CreateButton(L["GEMS_FLOATING_BTN_CLOSE"], function()
                    S():Set("floatingMenuShow", false)
                end)
            end)
        end
    end)

    -- Create buttons
    FM.buttons = {}
    for _, def in ipairs(BUTTON_DEFS) do
        local btn = CreateMenuButton(frame, def)
        FM.buttons[#FM.buttons + 1] = btn
    end

    -- Expand button (not in BUTTON_DEFS or FM.buttons)
    local expandBtn = CreateFrame("Button", nil, frame)
    expandBtn:SetSize(BUTTON_SIZE, BUTTON_SIZE)
    UI:RegisterLargeTarget(expandBtn)
    expandBtn:SetNormalTexture("Interface\\Icons\\Ability_Rogue_MasterOfSubtlety")
    local exHL = expandBtn:CreateTexture(nil, "HIGHLIGHT")
    exHL:SetAllPoints()
    exHL:SetColorTexture(1, 1, 1, 0.3)
    expandBtn:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText(L["GEMS_FLOATING_BTN_EXPAND"] or "Expand", 1, 1, 1)
        GameTooltip:Show()
    end)
    expandBtn:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)
    expandBtn:SetScript("OnClick", function()
        collapsed = false
        FM:UpdateCollapsedState()
    end)
    expandBtn:Hide()
    FM.expandBtn = expandBtn

    return frame
end

---------------------------------------------------------------------------
-- Collapse / Expand
---------------------------------------------------------------------------
function FM:UpdateCollapsedState()
    if collapsed then
        for _, btn in ipairs(FM.buttons) do
            btn:Hide()
        end
        FM.expandBtn:ClearAllPoints()
        FM.expandBtn:SetPoint("TOPLEFT", FM.frame, "TOPLEFT", FRAME_PADDING, -FRAME_PADDING)
        FM.expandBtn:Show()
        FM.frame:SetSize(BUTTON_SIZE + FRAME_PADDING * 2, BUTTON_SIZE + FRAME_PADDING * 2)
    else
        FM.expandBtn:Hide()
        for _, btn in ipairs(FM.buttons) do
            btn:Show()
        end
        LayoutButtons()
    end
end

---------------------------------------------------------------------------
-- Position save / restore
---------------------------------------------------------------------------
function FM:SavePosition()
    if not FM.frame then
        return
    end
    local point, _, relPoint, x, y = FM.frame:GetPoint(1)
    if not _G.GRIP_EMS_DB then
        return
    end
    GRIP_EMS_DB.floatingMenuPos = { point, "UIParent", relPoint, x, y }
end

function FM:RestorePosition()
    if not FM.frame then
        return
    end
    local pos = _G.GRIP_EMS_DB and GRIP_EMS_DB.floatingMenuPos
    if pos and pos[1] then
        FM.frame:ClearAllPoints()
        FM.frame:SetPoint(pos[1], UIParent, pos[3], pos[4], pos[5])
    else
        FM.frame:ClearAllPoints()
        FM.frame:SetPoint(DEFAULT_POS[1], UIParent, DEFAULT_POS[3], DEFAULT_POS[4], DEFAULT_POS[5])
    end
end

---------------------------------------------------------------------------
-- SETTING_CHANGED callback
---------------------------------------------------------------------------
function FM:OnSettingChanged(_, key, value)
    if not key or not tostring(key):match("^floatingMenu") then
        return
    end
    if key == "floatingMenuShow" then
        if FM.frame then
            if value then
                FM.frame:Show()
            else
                FM.frame:Hide()
            end
        end
    elseif key == "floatingMenuDirection" then
        LayoutButtons()
    elseif key == "floatingMenuScale" then
        if FM.frame then
            FM.frame:SetScale(value or 1.0)
        end
    end
    -- floatingMenuLocked: checked dynamically in OnDragStart
end

---------------------------------------------------------------------------
-- Public API
---------------------------------------------------------------------------
function FM:Toggle()
    local current = S():Get("floatingMenuShow")
    S():Set("floatingMenuShow", not current)
end

---------------------------------------------------------------------------
-- Initialization
---------------------------------------------------------------------------
function FM:Init()
    FM.frame = CreateMenuFrame()
    FM:RestorePosition()
    LayoutButtons()

    -- Apply saved scale
    local scale = S():Get("floatingMenuScale") or 1.0
    FM.frame:SetScale(scale)

    -- Show if setting is on
    if S():Get("floatingMenuShow") then
        FM.frame:Show()
    end

    -- Register callbacks
    if GRIPEMS.RegisterCallback then
        GRIPEMS.RegisterCallback(FM, "SETTING_CHANGED", "OnSettingChanged")
    end

    GRIPEMS:Debug("FloatingMenu: Init complete")
end
