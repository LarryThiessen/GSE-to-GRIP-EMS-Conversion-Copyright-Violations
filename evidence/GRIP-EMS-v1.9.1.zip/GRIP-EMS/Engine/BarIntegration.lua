-- GRIP-EMS: Bar Integration
-- Cosmetic overlay: shows current-step spell icons on action bar buttons
-- containing EMS macro stubs. Supports Blizzard native, ElvUI, Bartender4.

local ADDON_NAME, GRIPEMS = ...
local D = GRIPEMS.Defaults

GRIPEMS.BarIntegration = {}
local BI = GRIPEMS.BarIntegration

BI.trackedButtons = {} -- globalButtonName -> { button, seqName, originalTexture }
BI.enabled = false
BI.adapters = {} -- array of active adapter tables
BI.pendingRescan = false -- combat-deferred rescan flag

-- ---------------------------------------------------------------------------
-- Adapter: Blizzard native action bars
-- ---------------------------------------------------------------------------
local BlizzardAdapter = {}
BlizzardAdapter.name = "Blizzard"

function BlizzardAdapter:IsAvailable()
    return true
end

function BlizzardAdapter:GetButtons()
    local results = {}
    local patterns = {
        "ActionButton",
        "MultiBarBottomLeftButton",
        "MultiBarBottomRightButton",
        "MultiBarRightButton",
        "MultiBar2Button",
        "MultiBar5Button",
        "MultiBar6Button",
        "MultiBar7Button",
    }
    for _, prefix in ipairs(patterns) do
        for i = 1, 12 do
            local name = prefix .. i
            local btn = _G[name]
            if btn then
                local slot = btn.action or (btn.GetAttribute and btn:GetAttribute("action"))
                slot = tonumber(slot)
                if slot then
                    results[#results + 1] = { frame = btn, slot = slot }
                end
            end
        end
    end
    return results
end

-- ---------------------------------------------------------------------------
-- Adapter: ElvUI (LibActionButton-1.0 based)
-- ---------------------------------------------------------------------------
local ElvUIAdapter = {}
ElvUIAdapter.name = "ElvUI"

function ElvUIAdapter:IsAvailable()
    return C_AddOns.IsAddOnLoaded("ElvUI")
end

function ElvUIAdapter:GetButtons()
    local results = {}
    for bar = 1, 10 do
        for slot = 1, 12 do
            local name = "ElvUI_Bar" .. bar .. "Button" .. slot
            local btn = _G[name]
            if btn then
                local action = btn._state_action or (btn.GetAttribute and btn:GetAttribute("action"))
                action = tonumber(action)
                if action then
                    results[#results + 1] = { frame = btn, slot = action }
                end
            end
        end
    end
    return results
end

-- ---------------------------------------------------------------------------
-- Adapter: Bartender4 (LibActionButton-1.0 based)
-- ---------------------------------------------------------------------------
local BT4Adapter = {}
BT4Adapter.name = "Bartender4"

function BT4Adapter:IsAvailable()
    return C_AddOns.IsAddOnLoaded("Bartender4")
end

function BT4Adapter:GetButtons()
    local results = {}
    for i = 1, 120 do
        local name = "BT4Button" .. i
        local btn = _G[name]
        if btn then
            local action = btn._state_action or (btn.GetAttribute and btn:GetAttribute("action"))
            action = tonumber(action)
            if action then
                results[#results + 1] = { frame = btn, slot = action }
            end
        end
    end
    return results
end

-- ---------------------------------------------------------------------------
-- Sequence-from-slot resolver
-- ---------------------------------------------------------------------------
local function GetSequenceFromSlot(slot)
    if not slot then
        return nil
    end
    local actionType, macroID = GetActionInfo(slot)
    if actionType ~= "macro" then
        return nil
    end
    local _, _, body = GetMacroInfo(macroID)
    if not body then
        return nil
    end
    -- Match /click GRIPEMS_SomeName (handles both /click and /click! variants)
    local btnName = body:match("/click[!]? (" .. D.BUTTON_PREFIX .. "%S+)")
    if not btnName then
        return nil
    end
    local sanitized = btnName:gsub("^" .. D.BUTTON_PREFIX, "")
    -- Reverse-lookup: find sequence whose sanitized name matches
    local Engine = GRIPEMS.Engine
    if not Engine or not Engine.sequences then
        return nil
    end
    for name, _ in pairs(Engine.sequences) do
        if Engine:SanitizeName(name) == sanitized then
            return name
        end
    end
    return nil
end

-- ---------------------------------------------------------------------------
-- Icon resolver (shared helper)
-- ---------------------------------------------------------------------------
local function ResolveSequenceIcon(seqName)
    local Engine = GRIPEMS.Engine
    if not Engine then
        return nil
    end
    local entry = Engine.sequences[seqName]
    if not entry or not entry.button then
        return nil
    end
    local btn = entry.button
    local seqData = btn.seqData
    if not seqData then
        return nil
    end

    -- Fixed icon takes priority
    if seqData.autoIcon == false and type(seqData.icon) == "number" then
        return seqData.icon
    end

    -- Resolve from current step spell
    local ver = Engine:GetActiveVersion(seqData)
    local steps = ver and ver.steps
    if not steps or #steps == 0 then
        return nil
    end
    local step = tonumber(btn:GetAttribute("step")) or 1
    local stepText = steps[step] or steps[1]
    if not stepText then
        return nil
    end

    local SC = GRIPEMS.SpellCache
    if not SC then
        return nil
    end
    local spellName = SC:ParseSpellFromMacrotext(stepText)
    if not spellName then
        return nil
    end
    return SC:GetIcon(spellName)
end

-- ---------------------------------------------------------------------------
-- Core methods
-- ---------------------------------------------------------------------------

function BI:Init()
    if BI.enabled then
        return
    end
    -- Respect setting (default true)
    if GRIPEMS.Settings and GRIPEMS.Settings.Get then
        local val = GRIPEMS.Settings:Get("barIntegration")
        if val == false then
            return
        end
    end

    -- Detect available addons
    local allAdapters = { BlizzardAdapter, ElvUIAdapter, BT4Adapter }
    for _, adapter in ipairs(allAdapters) do
        if adapter:IsAvailable() then
            BI.adapters[#BI.adapters + 1] = adapter
        end
    end

    if #BI.adapters == 0 then
        return
    end

    -- Initial scan
    BI:ScanAllButtons()

    -- Hook Blizzard button updates (covers all ActionButton/MultiBar frames)
    -- ActionBarActionButtonMixin:Update() sets icon:SetTexture.
    -- DerivedMixin inherits from it (FrameXML ActionButton.lua).
    -- This single hook covers ALL Blizzard bar buttons.
    if ActionBarActionButtonMixin and ActionBarActionButtonMixin.Update then
        hooksecurefunc(ActionBarActionButtonMixin, "Update", function(self)
            if not BI.enabled then
                return
            end
            if InCombatLockdown() then
                return
            end
            local name = self:GetName()
            if name and BI.trackedButtons[name] then
                local iconID = ResolveSequenceIcon(BI.trackedButtons[name].seqName)
                if iconID and self.icon then
                    self.icon:SetTexture(iconID)
                end
            end
        end)
    end

    -- Hook LAB button updates (covers ElvUI and BT4)
    -- LAB fires "OnButtonUpdate" callback after every button Update()
    local LAB = LibStub and LibStub("LibActionButton-1.0", true)
    if LAB and LAB.RegisterCallback then
        LAB.RegisterCallback(BI, "OnButtonUpdate", function(_, btn)
            if not BI.enabled then
                return
            end
            if InCombatLockdown() then
                return
            end
            local name = btn:GetName()
            if name and BI.trackedButtons[name] then
                local iconID = ResolveSequenceIcon(BI.trackedButtons[name].seqName)
                if iconID and btn.icon then
                    btn.icon:SetTexture(iconID)
                end
            end
        end)
    end

    -- Register GRIPEMS callbacks for lifecycle events
    if GRIPEMS.RegisterCallback then
        GRIPEMS.RegisterCallback(BI, "SEQUENCE_STEP_ADVANCED", "OnStepAdvanced")
        GRIPEMS.RegisterCallback(BI, "SEQUENCE_CREATED", "OnSequenceCreated")
        GRIPEMS.RegisterCallback(BI, "SEQUENCE_DELETED", "OnSequenceDeleted")
    end

    -- Private event frame for ACTIONBAR_SLOT_CHANGED + PLAYER_REGEN_ENABLED
    local eventFrame = CreateFrame("Frame")
    eventFrame:RegisterEvent("ACTIONBAR_SLOT_CHANGED")
    eventFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
    eventFrame:SetScript("OnEvent", function(_, event)
        if event == "ACTIONBAR_SLOT_CHANGED" then
            BI:DeferredRescan()
        elseif event == "PLAYER_REGEN_ENABLED" then
            if BI.pendingRescan then
                BI.pendingRescan = false
                BI:ScanAllButtons()
            end
        end
    end)

    BI.enabled = true
    local names = {}
    for _, a in ipairs(BI.adapters) do
        names[#names + 1] = a.name
    end
    local count = 0
    for _ in pairs(BI.trackedButtons) do
        count = count + 1
    end
    local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS")
    GRIPEMS:Debug(string.format(L["GEMS_BAR_INTEGRATION_TRACKED"], count, table.concat(names, ", ")))
end

function BI:ScanAllButtons()
    -- Restore originals before wiping
    BI:RestoreAll()

    for _, adapter in ipairs(BI.adapters) do
        local buttons = adapter:GetButtons()
        for _, info in ipairs(buttons) do
            local seqName = GetSequenceFromSlot(info.slot)
            if seqName then
                local origTexture = info.frame.icon and info.frame.icon:GetTexture()
                BI.trackedButtons[info.frame:GetName()] = {
                    button = info.frame,
                    seqName = seqName,
                    originalTexture = origTexture,
                }
                -- Apply icon immediately (OOC check)
                if not InCombatLockdown() then
                    local iconID = ResolveSequenceIcon(seqName)
                    if iconID and info.frame.icon then
                        info.frame.icon:SetTexture(iconID)
                    end
                end
            end
        end
    end
end

function BI:RestoreAll()
    for _, entry in pairs(BI.trackedButtons) do
        if entry.button and entry.button.icon and entry.originalTexture then
            if not InCombatLockdown() then
                entry.button.icon:SetTexture(entry.originalTexture)
            end
        end
    end
    wipe(BI.trackedButtons)
end

function BI:OnStepAdvanced(_, seqName)
    if InCombatLockdown() then
        return
    end
    local iconID = ResolveSequenceIcon(seqName)
    if not iconID then
        return
    end
    for _, entry in pairs(BI.trackedButtons) do
        if entry.seqName == seqName and entry.button and entry.button.icon then
            entry.button.icon:SetTexture(iconID)
        end
    end
end

function BI:OnSequenceCreated()
    BI:DeferredRescan()
end

function BI:OnSequenceDeleted(_, seqName)
    for globalName, entry in pairs(BI.trackedButtons) do
        if entry.seqName == seqName then
            if entry.button and entry.button.icon and entry.originalTexture then
                if not InCombatLockdown() then
                    entry.button.icon:SetTexture(entry.originalTexture)
                end
            end
            BI.trackedButtons[globalName] = nil
        end
    end
end

function BI:DeferredRescan()
    if InCombatLockdown() then
        BI.pendingRescan = true
        return
    end
    C_Timer.After(0.5, function()
        if not InCombatLockdown() then
            BI:ScanAllButtons()
        else
            BI.pendingRescan = true
        end
    end)
end
