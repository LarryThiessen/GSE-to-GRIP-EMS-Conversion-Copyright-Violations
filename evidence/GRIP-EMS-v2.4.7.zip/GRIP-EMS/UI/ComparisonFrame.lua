-- GRIP-EMS: Side-by-Side Sequence Comparison Frame
-- Created: 2026-03-31
-- Updated: 2026-08-17
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
--
-- Displays two sequences in parallel with per-step diff highlighting.
-- Phase 2 #7: keyboard-focus lifecycle hooked into GRIPEMS.Focus; pushes
-- a "ComparisonFrame" context on Show with the title-close and bottom
-- Close buttons as TAB targets, pops it on Hide.

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

GRIPEMS.ComparisonFrame = {}
local CF = GRIPEMS.ComparisonFrame

local frame = nil -- lazy-created, reused

-- Diff type constants
local DIFF_SAME = "same"
local DIFF_CHANGED = "changed"
local DIFF_REMOVED = "removed"
local DIFF_ADDED = "added"

-- Row height constant
local ROW_HEIGHT = 24
local META_ROW_HEIGHT = 20

---------------------------------------------------------------------------
-- BuildMetaRows: compare sequence metadata fields
---------------------------------------------------------------------------

--- Build an array of metadata comparison rows from two meta tables.
--- @param leftMeta table|nil { stepFunction, resetConditions, icon, contextVersions }
--- @param rightMeta table|nil { stepFunction, resetConditions, icon, contextVersions }
--- @return table Array of { label, leftVal, rightVal, changed }
local function BuildMetaRows(leftMeta, rightMeta)
    leftMeta = leftMeta or {}
    rightMeta = rightMeta or {}

    local fields = {
        { key = "stepFunction", label = "Step Function" },
        { key = "resetConditions", label = "Reset Conditions" },
        { key = "icon", label = "Icon" },
        { key = "contextVersions", label = "Context Versions" },
    }

    local rows = {}
    for _, f in ipairs(fields) do
        local lv = leftMeta[f.key]
        local rv = rightMeta[f.key]
        if lv ~= nil or rv ~= nil then
            rows[#rows + 1] = {
                label = f.label,
                leftVal = tostring(lv or ""),
                rightVal = tostring(rv or ""),
                changed = (lv ~= rv),
            }
        end
    end

    return rows
end

---------------------------------------------------------------------------
-- BuildDiffData: walk both step arrays and produce unified diff rows
---------------------------------------------------------------------------

--- Build a flat array of diff rows from two step arrays.
--- @param leftSteps table Array of step strings (or nil)
--- @param rightSteps table Array of step strings (or nil)
--- @return table Array of { index, leftText, rightText, diffType }
local function BuildDiffData(leftSteps, rightSteps)
    leftSteps = leftSteps or {}
    rightSteps = rightSteps or {}

    local maxLen = math.max(#leftSteps, #rightSteps)
    local rows = {}

    for i = 1, maxLen do
        local lt = leftSteps[i]
        local rt = rightSteps[i]
        local diffType

        if lt and rt then
            if lt == rt then
                diffType = DIFF_SAME
            else
                diffType = DIFF_CHANGED
            end
        elseif lt and not rt then
            diffType = DIFF_REMOVED
        else
            diffType = DIFF_ADDED
        end

        rows[#rows + 1] = {
            index = i,
            leftText = lt or "",
            rightText = rt or "",
            diffType = diffType,
        }
    end

    return rows
end

---------------------------------------------------------------------------
-- CreateFrame: builds the comparison dialog (once)
---------------------------------------------------------------------------

local function CreateComparisonFrame()
    local UI = GRIPEMS.UI
    local C = UI.Colors

    frame = CreateFrame("Frame", "GRIPEMS_ComparisonFrame", UIParent, "BackdropTemplate")
    frame:SetSize(900, 500)
    frame:SetPoint("CENTER")
    frame:SetFrameStrata("DIALOG")
    frame:SetClampedToScreen(true)
    UI:ApplyBackdrop(frame, UI.Backdrops.panel, C.bgMain, C.border)
    if GRIPEMS.UI and GRIPEMS.UI.RegisterPanelFrame then
        GRIPEMS.UI:RegisterPanelFrame(frame, "panel", "panel.utility")
    end
    frame:SetMovable(true)
    frame:Hide()

    -- Keyboard nav: ESC closes; TAB / ENTER / SPACE route through
    -- GRIPEMS.Focus so title-bar and footer buttons are keyboard-reachable.
    frame:EnableKeyboard(true)
    pcall(frame.SetPropagateKeyboardInput, frame, true)
    frame:SetScript("OnKeyDown", function(self, key)
        if InCombatLockdown() then
            return
        end
        -- Suspenders layer: independent of the Focus flag, query WoW
        -- directly for any focused EditBox. If found, propagate the key
        -- and let the EditBox handle it.
        if GetCurrentKeyBoardFocus and GetCurrentKeyBoardFocus() then
            pcall(self.SetPropagateKeyboardInput, self, true)
            return
        end
        local Focus = GRIPEMS.Focus
        if Focus and Focus:IsEditBoxFocused() then
            pcall(self.SetPropagateKeyboardInput, self, true)
            return
        end
        if key == "ESCAPE" then
            pcall(self.SetPropagateKeyboardInput, self, false)
            self:Hide()
        elseif key == "TAB" and Focus then
            Focus:Cycle(IsShiftKeyDown() and -1 or 1)
            pcall(self.SetPropagateKeyboardInput, self, false)
        elseif (key == "ENTER" or key == "SPACE") and Focus then
            Focus:Activate()
            pcall(self.SetPropagateKeyboardInput, self, false)
        else
            pcall(self.SetPropagateKeyboardInput, self, true)
        end
    end)

    -------------------------------------------------------------------
    -- Title bar (30px)
    -------------------------------------------------------------------
    local titleBar = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    titleBar:SetHeight(30)
    titleBar:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, 0)
    titleBar:SetPoint("TOPRIGHT", frame, "TOPRIGHT", 0, 0)
    UI:ApplyBackdrop(titleBar, UI.Backdrops.panelNoBorder, C.bgDeep)

    titleBar:EnableMouse(true)
    titleBar:RegisterForDrag("LeftButton")
    titleBar:SetScript("OnDragStart", function()
        frame:StartMoving()
    end)
    titleBar:SetScript("OnDragStop", function()
        frame:StopMovingOrSizing()
    end)

    -- Title text
    local titleText = titleBar:CreateFontString(nil, "OVERLAY")
    UI:SetFont(titleText, 13, "OUTLINE")
    titleText:SetPoint("LEFT", titleBar, "LEFT", 12, 0)
    titleText:SetText("GRIP-EMS: " .. L["GEMS_COMPARE_TITLE"])
    titleText:SetTextColor(C.gripGreen:GetRGBA())
    frame.titleText = titleText

    -- Close button (themed dark-UI X)
    local titleCloseBtn = CreateFrame("Button", nil, titleBar, "BackdropTemplate")
    titleCloseBtn:SetSize(24, 24)
    UI:RegisterLargeTarget(titleCloseBtn)
    titleCloseBtn:SetPoint("TOPRIGHT", titleBar, "TOPRIGHT", -6, -3)
    UI:ApplyBackdrop(titleCloseBtn, UI.Backdrops.panel, C.bgButton, C.border)
    local closeLbl = titleCloseBtn:CreateFontString(nil, "OVERLAY")
    UI:SetFont(closeLbl, 14)
    closeLbl:SetPoint("CENTER", 0, 1)
    closeLbl:SetText("X")
    closeLbl:SetTextColor(C.textSecondary:GetRGBA())
    titleCloseBtn:SetScript("OnClick", function()
        frame:Hide()
    end)
    titleCloseBtn:SetScript("OnEnter", function(self)
        UI:ShowTooltip(self, CLOSE or "Close", L["GEMS_COMPARE_CLOSE_DESC"])
        self:SetBackdropColor(C.accent:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
        closeLbl:SetTextColor(C.textPrimary:GetRGBA())
    end)
    titleCloseBtn:SetScript("OnLeave", function(self)
        GameTooltip:Hide()
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
        closeLbl:SetTextColor(C.textSecondary:GetRGBA())
    end)
    frame.titleCloseBtn = titleCloseBtn

    -------------------------------------------------------------------
    -- Content area (between title bar and bottom bar)
    -------------------------------------------------------------------
    local content = CreateFrame("Frame", nil, frame)
    content:SetPoint("TOPLEFT", frame, "TOPLEFT", 10, -32)
    content:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -10, 40)
    frame._content = content

    -- Left panel header
    local leftHeader = content:CreateFontString(nil, "OVERLAY")
    UI:SetFont(leftHeader, 13)
    leftHeader:SetPoint("TOPLEFT", content, "TOPLEFT", 4, -2)
    leftHeader:SetTextColor(C.textPrimary:GetRGBA())
    leftHeader:SetJustifyH("LEFT")
    leftHeader:SetWordWrap(false)
    leftHeader:SetWidth(360)
    frame._leftHeader = leftHeader

    -- Left sub-header (step function + count)
    local leftSubHeader = content:CreateFontString(nil, "OVERLAY")
    UI:SetFont(leftSubHeader, 10)
    leftSubHeader:SetPoint("TOPLEFT", leftHeader, "BOTTOMLEFT", 0, -2)
    leftSubHeader:SetTextColor(C.textSecondary:GetRGBA())
    leftSubHeader:SetJustifyH("LEFT")
    frame._leftSubHeader = leftSubHeader

    -- Right panel header
    local rightHeader = content:CreateFontString(nil, "OVERLAY")
    UI:SetFont(rightHeader, 13)
    rightHeader:SetPoint("TOPLEFT", content, "TOP", 4, -2)
    rightHeader:SetTextColor(C.textPrimary:GetRGBA())
    rightHeader:SetJustifyH("LEFT")
    rightHeader:SetWordWrap(false)
    rightHeader:SetWidth(360)
    frame._rightHeader = rightHeader

    -- Right sub-header
    local rightSubHeader = content:CreateFontString(nil, "OVERLAY")
    UI:SetFont(rightSubHeader, 10)
    rightSubHeader:SetPoint("TOPLEFT", rightHeader, "BOTTOMLEFT", 0, -2)
    rightSubHeader:SetTextColor(C.textSecondary:GetRGBA())
    rightSubHeader:SetJustifyH("LEFT")
    frame._rightSubHeader = rightSubHeader

    -------------------------------------------------------------------
    -- Metadata comparison strip (between sub-headers and scroll boxes)
    -------------------------------------------------------------------
    local metaStrip = CreateFrame("Frame", nil, content)
    metaStrip:SetPoint("TOPLEFT", leftSubHeader, "BOTTOMLEFT", -4, -4)
    metaStrip:SetPoint("RIGHT", content, "RIGHT", 0, 0)
    metaStrip:SetHeight(0)
    frame._metaStrip = metaStrip

    local metaRows = {}
    for i = 1, 4 do
        local row = CreateFrame("Frame", nil, metaStrip, "BackdropTemplate")
        row:SetHeight(META_ROW_HEIGHT)
        if i == 1 then
            row:SetPoint("TOPLEFT", metaStrip, "TOPLEFT", 0, 0)
        else
            row:SetPoint("TOPLEFT", metaRows[i - 1], "BOTTOMLEFT", 0, 0)
        end
        row:SetPoint("RIGHT", metaStrip, "RIGHT", 0, 0)

        local bg = row:CreateTexture(nil, "BACKGROUND")
        bg:SetAllPoints()
        bg:SetColorTexture(0, 0, 0, 0)
        row._bg = bg

        local label = row:CreateFontString(nil, "OVERLAY")
        UI:SetFont(label, 10)
        label:SetPoint("LEFT", row, "LEFT", 8, 0)
        label:SetWidth(140)
        label:SetJustifyH("LEFT")
        label:SetTextColor(C.textSecondary:GetRGBA())
        row._label = label

        local leftVal = row:CreateFontString(nil, "OVERLAY")
        UI:SetFont(leftVal, 10)
        leftVal:SetPoint("LEFT", row, "LEFT", 160, 0)
        leftVal:SetPoint("RIGHT", row, "CENTER", -10, 0)
        leftVal:SetJustifyH("LEFT")
        leftVal:SetWordWrap(false)
        row._leftVal = leftVal

        local rightVal = row:CreateFontString(nil, "OVERLAY")
        UI:SetFont(rightVal, 10)
        rightVal:SetPoint("LEFT", row, "CENTER", 10, 0)
        rightVal:SetPoint("RIGHT", row, "RIGHT", -8, 0)
        rightVal:SetJustifyH("LEFT")
        rightVal:SetWordWrap(false)
        row._rightVal = rightVal

        row:Hide()
        metaRows[i] = row
    end
    frame._metaRows = metaRows

    -------------------------------------------------------------------
    -- Left ScrollBox
    -------------------------------------------------------------------
    local leftScrollBox = CreateFrame("Frame", nil, content, "WowScrollBoxList")
    leftScrollBox:SetPoint("TOPLEFT", metaStrip, "BOTTOMLEFT", 4, -2)
    leftScrollBox:SetPoint("BOTTOMRIGHT", content, "BOTTOM", -2, 0)
    frame._leftScrollBox = leftScrollBox

    local leftScrollBar = CreateFrame("EventFrame", nil, content, "MinimalScrollBar")
    leftScrollBar:SetPoint("TOPLEFT", leftScrollBox, "TOPRIGHT", 0, 0)
    leftScrollBar:SetPoint("BOTTOMLEFT", leftScrollBox, "BOTTOMRIGHT", 0, 0)
    leftScrollBar:Hide() -- hidden; sync is driven by right scrollbar only

    -- Dark backdrop behind left scroll
    local leftScrollBg = CreateFrame("Frame", nil, content, "BackdropTemplate")
    leftScrollBg:SetPoint("TOPLEFT", leftScrollBox, "TOPLEFT", 0, 0)
    leftScrollBg:SetPoint("BOTTOMRIGHT", leftScrollBox, "BOTTOMRIGHT", 0, 0)
    leftScrollBg:SetFrameLevel(content:GetFrameLevel())
    UI:ApplyBackdrop(leftScrollBg, UI.Backdrops.panel, C.bgInput, C.border)

    -------------------------------------------------------------------
    -- Right ScrollBox
    -------------------------------------------------------------------
    local rightScrollBox = CreateFrame("Frame", nil, content, "WowScrollBoxList")
    rightScrollBox:SetPoint("TOPLEFT", metaStrip, "BOTTOM", 4, -2)
    rightScrollBox:SetPoint("BOTTOMRIGHT", content, "BOTTOMRIGHT", -16, 0)
    frame._rightScrollBox = rightScrollBox

    local rightScrollBar = CreateFrame("EventFrame", nil, content, "MinimalScrollBar")
    rightScrollBar:SetPoint("TOPLEFT", rightScrollBox, "TOPRIGHT", 2, 0)
    rightScrollBar:SetPoint("BOTTOMLEFT", rightScrollBox, "BOTTOMRIGHT", 2, 0)
    frame._rightScrollBar = rightScrollBar

    -- Dark backdrop behind right scroll
    local rightScrollBg = CreateFrame("Frame", nil, content, "BackdropTemplate")
    rightScrollBg:SetPoint("TOPLEFT", rightScrollBox, "TOPLEFT", 0, 0)
    rightScrollBg:SetPoint("BOTTOMRIGHT", rightScrollBar, "BOTTOMRIGHT", 0, 0)
    rightScrollBg:SetFrameLevel(content:GetFrameLevel())
    UI:ApplyBackdrop(rightScrollBg, UI.Backdrops.panel, C.bgInput, C.border)

    -------------------------------------------------------------------
    -- Row initializers
    -------------------------------------------------------------------

    --- Create a row initializer for one side of the comparison.
    --- @param side string "left" or "right"
    --- @return function
    local function MakeRowInitializer(side)
        return function(button, data)
            button:SetHeight(ROW_HEIGHT)

            if not button._cmpInit then
                button._cmpInit = true

                local bg = button:CreateTexture(nil, "BACKGROUND")
                bg:SetAllPoints()
                bg:SetColorTexture(0, 0, 0, 0)
                button._bg = bg

                local stepNum = button:CreateFontString(nil, "OVERLAY")
                UI:SetFont(stepNum, 10)
                stepNum:SetPoint("LEFT", button, "LEFT", 4, 0)
                stepNum:SetWidth(30)
                stepNum:SetJustifyH("RIGHT")
                stepNum:SetTextColor(C.textSecondary:GetRGBA())
                button._stepNum = stepNum

                local stepText = button:CreateFontString(nil, "OVERLAY")
                UI:SetFont(stepText, 11)
                stepText:SetPoint("LEFT", stepNum, "RIGHT", 6, 0)
                stepText:SetPoint("RIGHT", button, "RIGHT", -4, 0)
                stepText:SetJustifyH("LEFT")
                stepText:SetWordWrap(false)
                stepText:SetMaxLines(1)
                button._stepText = stepText
            end

            -- Reset
            button._bg:SetColorTexture(0, 0, 0, 0)

            local text = (side == "left") and data.leftText or data.rightText
            local hasText = text and text ~= ""

            button._stepNum:SetText(hasText and tostring(data.index) or "")

            if hasText then
                -- Truncate for display, full text in tooltip
                local SH = GRIPEMS.SyntaxHighlight
                if SH then
                    text = SH:ColorizeString(text)
                end
                button._stepText:SetText(text)
            else
                button._stepText:SetText("")
            end

            -- Background tint based on diffType
            local dt = data.diffType
            if dt == DIFF_CHANGED then
                button._bg:SetColorTexture(C.textWarning:GetRGB())
                button._bg:SetAlpha(0.15)
            elseif dt == DIFF_REMOVED then
                if side == "left" then
                    button._bg:SetColorTexture(C.textError:GetRGB())
                    button._bg:SetAlpha(0.15)
                else
                    button._bg:SetColorTexture(0, 0, 0, 0)
                end
            elseif dt == DIFF_ADDED then
                if side == "right" then
                    button._bg:SetColorTexture(C.textSuccess:GetRGB())
                    button._bg:SetAlpha(0.15)
                else
                    button._bg:SetColorTexture(0, 0, 0, 0)
                end
            else
                button._bg:SetColorTexture(0, 0, 0, 0)
            end

            -- Tooltip on hover for full step text
            button:SetScript("OnEnter", function(self)
                if hasText and text:len() > 60 then
                    UI:ShowTooltip(self, string.format(L["GEMS_COMPARE_STEPS"], data.index), text)
                end
            end)
            button:SetScript("OnLeave", function()
                UI:HideTooltip()
            end)
        end
    end

    -------------------------------------------------------------------
    -- ScrollBox setup (left)
    -------------------------------------------------------------------
    local leftView = CreateScrollBoxListLinearView()
    leftView:SetElementExtent(ROW_HEIGHT)
    leftView:SetElementInitializer("Button", MakeRowInitializer("left"))
    ScrollUtil.InitScrollBoxListWithScrollBar(leftScrollBox, leftScrollBar, leftView)

    -------------------------------------------------------------------
    -- ScrollBox setup (right)
    -------------------------------------------------------------------
    local rightView = CreateScrollBoxListLinearView()
    rightView:SetElementExtent(ROW_HEIGHT)
    rightView:SetElementInitializer("Button", MakeRowInitializer("right"))
    ScrollUtil.InitScrollBoxListWithScrollBar(rightScrollBox, rightScrollBar, rightView)

    -------------------------------------------------------------------
    -- Scroll sync: keep both ScrollBoxes at the same position
    -------------------------------------------------------------------
    local syncing = false

    local function SyncScroll(source, target)
        if syncing then
            return
        end
        syncing = true
        local pct = source:GetScrollPercentage()
        target:SetScrollPercentage(pct)
        syncing = false
    end

    leftScrollBox:RegisterCallback("OnScrollRangeChanged", function()
        SyncScroll(leftScrollBox, rightScrollBox)
    end)
    rightScrollBox:RegisterCallback("OnScrollRangeChanged", function()
        SyncScroll(rightScrollBox, leftScrollBox)
    end)

    -- Event-driven sync: ScrollBox fires OnScroll when the user scrolls
    -- (mouse wheel, drag, keyboard). Replaces per-frame OnUpdate polling.
    leftScrollBox:RegisterCallback("OnScroll", function()
        SyncScroll(leftScrollBox, rightScrollBox)
    end)
    rightScrollBox:RegisterCallback("OnScroll", function()
        SyncScroll(rightScrollBox, leftScrollBox)
    end)

    -------------------------------------------------------------------
    -- Bottom bar with Close button
    -------------------------------------------------------------------
    local bottomBar = CreateFrame("Frame", nil, frame)
    bottomBar:SetHeight(36)
    bottomBar:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 10, 4)
    bottomBar:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -10, 4)

    local closeBtn = UI:CreateButton(bottomBar, L["GEMS_IMPORT_PREVIEW_CANCEL"], 80, 26)
    closeBtn:SetPoint("RIGHT", bottomBar, "RIGHT", 0, 0)
    closeBtn:SetScript("OnClick", function()
        frame:Hide()
    end)
    frame.closeBtn = closeBtn

    -- Phase 2 #7: Focus context lifecycle.
    frame:HookScript("OnShow", function(self)
        local Focus = GRIPEMS.Focus
        if not Focus then
            return
        end
        Focus:PushContext("ComparisonFrame", {
            self.titleCloseBtn,
            self.closeBtn,
        })
    end)
    frame:HookScript("OnHide", function()
        local Focus = GRIPEMS.Focus
        if not Focus then
            return
        end
        Focus:PopContext("ComparisonFrame")
    end)

    return frame
end

---------------------------------------------------------------------------
-- CF:Show(leftLabel, leftSteps, rightLabel, rightSteps)
---------------------------------------------------------------------------

--- Show the comparison frame with two step arrays side by side.
--- @param leftLabel string Left panel header (e.g. sequence name)
--- @param leftSteps table Array of step strings
--- @param rightLabel string Right panel header
--- @param rightSteps table Array of step strings
--- @param leftSubLabel string|nil Optional sub-header for left panel
--- @param rightSubLabel string|nil Optional sub-header for right panel
--- @param leftMeta table|nil { stepFunction, resetConditions, icon, contextVersions }
--- @param rightMeta table|nil { stepFunction, resetConditions, icon, contextVersions }
function CF:Show(leftLabel, leftSteps, rightLabel, rightSteps, leftSubLabel, rightSubLabel, leftMeta, rightMeta)
    if not frame then
        CreateComparisonFrame()
    end

    local C = GRIPEMS.UI.Colors

    leftSteps = leftSteps or {}
    rightSteps = rightSteps or {}

    -- Populate metadata strip
    local mRows = BuildMetaRows(leftMeta, rightMeta)
    local visibleCount = #mRows
    for i, mr in ipairs(frame._metaRows) do
        if i <= visibleCount then
            local data = mRows[i]
            mr._label:SetText(data.label)
            mr._leftVal:SetText(data.leftVal)
            mr._rightVal:SetText(data.rightVal)
            if data.changed then
                mr._bg:SetColorTexture(C.textWarning:GetRGB())
                mr._bg:SetAlpha(0.18)
                mr._leftVal:SetTextColor(C.textWarning:GetRGBA())
                mr._rightVal:SetTextColor(C.textWarning:GetRGBA())
            else
                mr._bg:SetColorTexture(0, 0, 0, 0)
                mr._leftVal:SetTextColor(C.textPrimary:GetRGBA())
                mr._rightVal:SetTextColor(C.textPrimary:GetRGBA())
            end
            mr:Show()
        else
            mr:Hide()
        end
    end
    frame._metaStrip:SetHeight(visibleCount * META_ROW_HEIGHT)

    -- Set headers
    frame._leftHeader:SetText(leftLabel or L["GEMS_COMPARE_LEFT_LABEL"])
    frame._rightHeader:SetText(rightLabel or L["GEMS_COMPARE_RIGHT_LABEL"])

    -- Sub-headers (step count)
    local leftCountText = #leftSteps > 0 and string.format(L["GEMS_COMPARE_STEPS"], #leftSteps)
        or L["GEMS_COMPARE_NO_STEPS"]
    local rightCountText = #rightSteps > 0 and string.format(L["GEMS_COMPARE_STEPS"], #rightSteps)
        or L["GEMS_COMPARE_NO_STEPS"]

    frame._leftSubHeader:SetText(leftSubLabel and (leftSubLabel .. " - " .. leftCountText) or leftCountText)
    frame._rightSubHeader:SetText(rightSubLabel and (rightSubLabel .. " - " .. rightCountText) or rightCountText)

    -- Build diff data
    local diffData = BuildDiffData(leftSteps, rightSteps)

    -- Create data providers (same data drives both, rows extract their side)
    local leftDP = CreateDataProvider()
    local rightDP = CreateDataProvider()
    for _, row in ipairs(diffData) do
        leftDP:Insert(row)
        rightDP:Insert(row)
    end

    frame._leftScrollBox:SetDataProvider(leftDP)
    frame._rightScrollBox:SetDataProvider(rightDP)

    -- Reset scroll position
    frame._leftScrollBox:SetScrollPercentage(0)
    frame._rightScrollBox:SetScrollPercentage(0)

    frame:Show()
end

--- Hide the comparison frame.
function CF:Hide()
    if frame then
        frame:Hide()
    end
end

--- Check if the comparison frame is currently shown.
--- @return boolean
function CF:IsShown()
    return frame and frame:IsShown()
end
