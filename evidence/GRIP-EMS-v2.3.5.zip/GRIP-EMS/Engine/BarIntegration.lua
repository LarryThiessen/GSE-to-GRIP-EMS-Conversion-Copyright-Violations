-- GRIP-EMS: BarIntegration
-- Created: 2026-04-03
-- Updated: 2026-06-21
-- Patch: 12.0.7.68256 Midnight (Retail LIVE)

-- GRIP-EMS: Bar Integration
-- Cosmetic overlay: shows current-step spell icons on action bar buttons
-- containing EMS macro stubs. Supports Blizzard native, ElvUI, Bartender4.

local ADDON_NAME, GRIPEMS = ...
local D = GRIPEMS.Defaults
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

GRIPEMS.BarIntegration = {}
local BI = GRIPEMS.BarIntegration

BI.trackedButtons = {} -- globalButtonName -> { button, seqName, variantIdx }
BI.enabled = false
BI.adapters = {} -- array of active adapter tables
BI.pendingRescan = false -- combat-deferred rescan flag

-- ---------------------------------------------------------------------------
-- Adapter: Blizzard native action bars
-- ---------------------------------------------------------------------------
local BlizzardAdapter = {}
BlizzardAdapter.name = "Blizzard"

function BlizzardAdapter:IsAvailable()
    return true
end

function BlizzardAdapter:GetButtons()
    local results = {}
    local patterns = {
        "ActionButton",
        "MultiBarBottomLeftButton",
        "MultiBarBottomRightButton",
        "MultiBarRightButton",
        "MultiBar2Button",
        "MultiBar5Button",
        "MultiBar6Button",
        "MultiBar7Button",
    }
    for _, prefix in ipairs(patterns) do
        for i = 1, 12 do
            local name = prefix .. i
            local btn = _G[name]
            if btn then
                local slot = btn.action or (btn.GetAttribute and btn:GetAttribute("action"))
                slot = tonumber(slot)
                if slot then
                    results[#results + 1] = { frame = btn, slot = slot }
                end
            end
        end
    end
    return results
end

-- ---------------------------------------------------------------------------
-- Adapter: ElvUI (LibActionButton-1.0 based)
-- ---------------------------------------------------------------------------
local ElvUIAdapter = {}
ElvUIAdapter.name = "ElvUI"

function ElvUIAdapter:IsAvailable()
    return C_AddOns.IsAddOnLoaded("ElvUI")
end

function ElvUIAdapter:GetButtons()
    local results = {}
    for bar = 1, 10 do
        for slot = 1, 12 do
            local name = "ElvUI_Bar" .. bar .. "Button" .. slot
            local btn = _G[name]
            if btn then
                local action = btn._state_action or (btn.GetAttribute and btn:GetAttribute("action"))
                action = tonumber(action)
                if action then
                    results[#results + 1] = { frame = btn, slot = action }
                end
            end
        end
    end
    return results
end

-- ---------------------------------------------------------------------------
-- Adapter: Bartender4 (LibActionButton-1.0 based)
-- ---------------------------------------------------------------------------
local BT4Adapter = {}
BT4Adapter.name = "Bartender4"

function BT4Adapter:IsAvailable()
    return C_AddOns.IsAddOnLoaded("Bartender4")
end

function BT4Adapter:GetButtons()
    local results = {}
    for i = 1, 120 do
        local name = "BT4Button" .. i
        local btn = _G[name]
        if btn then
            local action = btn._state_action or (btn.GetAttribute and btn:GetAttribute("action"))
            action = tonumber(action)
            if action then
                results[#results + 1] = { frame = btn, slot = action }
            end
        end
    end
    return results
end

-- ---------------------------------------------------------------------------
-- Sequence-from-slot resolver
-- ---------------------------------------------------------------------------
-- Returns { seqName = name, variantIdx = N } where variantIdx is nil for the
-- base button and 2..4 for an override slot. Returns nil when the slot does
-- not host a recognized EMS /click stub. IC-VAR-08: variantIdx is used by
-- ApplyOverlayIcon + OnRecommendationUpdated to drive per-variant indicators.
local function GetSequenceFromSlot(slot)
    if not slot then
        return nil
    end
    local actionType, macroID = GetActionInfo(slot)
    if actionType ~= "macro" then
        return nil
    end
    local _, _, body = GetMacroInfo(macroID)
    if not body then
        return nil
    end
    -- Match /click GRIPEMS_SomeName (handles both /click and /click! variants)
    local btnName = body:match("/click[!]? (" .. D.BUTTON_PREFIX .. "%S+)")
    if not btnName then
        return nil
    end
    local originalSanitized = btnName:gsub("^" .. D.BUTTON_PREFIX, "")
    local sanitized = originalSanitized
    -- IC-VAR-08: detect variant suffix (_v2, _v3, _v4) before reverse-lookup.
    -- The base sanitized name comes from Engine:SanitizeName which strips
    -- punctuation; the variant suffix is appended in compile time as
    -- D.VARIANT_BUTTON_SUFFIX .. (ovIdx + 1), so the suffix arrives as "_vN"
    -- on the macrotext side.
    local variantIdx
    local baseName, vTail = originalSanitized:match("^(.-)" .. D.VARIANT_BUTTON_SUFFIX .. "(%d+)$")
    if baseName and vTail then
        local n = tonumber(vTail)
        if n and n >= 2 and n <= (D.MAX_VARIANT_OVERRIDES + 1) then
            -- Tentative classification; verify in the reverse-lookup loop.
            sanitized = baseName
            variantIdx = n
        end
    end
    -- IC-VAR-08-polish: confirm the variant slot actually exists on the
    -- candidate sequence's active version. If not, fall back to treating
    -- the macrotext as a plain (non-variant) stub. Prevents misclassifying
    -- a user-named sequence ending in "_v2..v4" (e.g. "Foo_v3") as a
    -- variant of an unrelated sequence.
    -- Reverse-lookup: find sequence whose sanitized name matches
    local Engine = GRIPEMS.Engine
    if not Engine or not Engine.sequences then
        return nil
    end
    -- Pass 1: tentative variant classification. Only confirm a match when the
    -- candidate's active version actually has the override slot present.
    if variantIdx then
        for name, _ in pairs(Engine.sequences) do
            if Engine:SanitizeName(name) == sanitized then
                local seqEntry = Engine.sequences[name]
                local disabled = seqEntry and seqEntry.data and seqEntry.data.disabled
                local ver = seqEntry
                        and seqEntry.data
                        and Engine.GetActiveVersion
                        and Engine:GetActiveVersion(seqEntry.data)
                    or nil
                local override = ver and ver.variantOverrides and ver.variantOverrides[variantIdx - 1]
                if override and not disabled then
                    return { seqName = name, variantIdx = variantIdx }
                end
            end
        end
        -- Variant suffix was a false-positive (no candidate with the slot);
        -- fall back to the original sanitized name and retry as plain. The
        -- pass-2 return literal already uses variantIdx = nil, so we only
        -- need to restore the sanitized name here.
        sanitized = originalSanitized
    end
    -- Pass 2: plain reverse-lookup with the original sanitized name. Skip
    -- disabled sequences so a leftover /click stub for a disabled sequence
    -- does not resolve to a tracked overlay; the loop falls through and the
    -- function returns nil when nothing live matches.
    for name, _ in pairs(Engine.sequences) do
        if Engine:SanitizeName(name) == sanitized then
            local seqEntry = Engine.sequences[name]
            local disabled = seqEntry and seqEntry.data and seqEntry.data.disabled
            if not disabled then
                return { seqName = name, variantIdx = nil }
            end
        end
    end
    return nil
end

-- ---------------------------------------------------------------------------
-- Icon resolver (shared helper)
-- ---------------------------------------------------------------------------
local function ResolveSequenceIcon(seqName)
    local Engine = GRIPEMS.Engine
    if not Engine then
        return nil
    end
    local entry = Engine.sequences[seqName]
    if not entry or not entry.button then
        return nil
    end
    local btn = entry.button
    local seqData = btn.seqData
    if not seqData then
        return nil
    end

    -- Fixed icon takes priority
    if seqData.autoIcon == false and type(seqData.icon) == "number" then
        return seqData.icon
    end

    -- Resolve from current step spell
    local ver = Engine:GetActiveVersion(seqData)
    local steps = ver and ver.steps
    if not steps or #steps == 0 then
        return nil
    end
    local step = tonumber(btn:GetAttribute("step")) or 1
    local stepText = steps[step] or steps[1]
    if not stepText then
        return nil
    end

    local SC = GRIPEMS.SpellCache
    if not SC then
        return nil
    end
    local spellName = SC:ParseSpellFromMacrotext(stepText)
    if not spellName then
        return nil
    end
    return SC:GetIcon(spellName)
end

-- ---------------------------------------------------------------------------
-- Overlay-texture pattern (BUG-BARINTEGRATION-ACTIONBAR-TAINT defense)
-- ---------------------------------------------------------------------------
-- Private overlay storage: globalButtonName -> { frame, texture, button }.
-- Mirrors the StaticPopupDialogs taint fix in Core/Popup.lua: keep all
-- addon-side state in addon-private storage, never write into a
-- Blizzard-owned global table.
--
-- Why this exists. Writing iconID into a Blizzard action button's icon
-- child (e.g. MultiBarBottomLeftButton1.icon:SetTexture(iconID)) taints
-- the action bar tree. ActionBarController_UpdateAll later iterates the
-- bars in a secure context (e.g. Guardian Druid form shift), inherits
-- the taint, and ADDON_ACTION_BLOCKED fires on MultiBarBottomLeft:ShowBase().
--
-- The fix. Each tracked button gets an addon-owned overlay frame parented
-- to UIParent and anchored to the button via SetPoint. Texture writes go
-- to overlays[name].texture (addon-owned) only. The Blizzard button's
-- icon child is never written to. SetParent stays off the Blizzard button
-- so we do not mutate its child list either.
local overlays = {}

-- IC-VAR-08 render-path helpers (Path D5). ColorCurve tint + Cooldown ring
-- evaluation are render-only: tagged secret values from C_CurveUtil never
-- leak back into insecure code because the only thing we do with the result
-- is feed it straight into texture:SetVertexColor / Cooldown:SetCooldown.
--
-- ApplyColorCurveTint(textureRef):
--   Reads UnitHealthPercent("player", true, curve) per the canonical Patch
--   12.0+ curve-launder pattern -- the engine evaluates the curve in C++
--   against the secret-tagged UnitHealth result, returning a
--   LuaCurveEvaluatedResult whose :GetRGBA() components are SECRET when
--   the resource is restricted -- clean plain-number curve stops do NOT
--   clean the output. Safe ONLY because every component is forwarded
--   straight to SetVertexColor (render path). Returns nothing.
--   Bug history: pre-fix the function took hpFrac/powerFrac args computed
--   in Lua as UnitHealth/UnitHealthMax -- that division throws on Patch
--   12.0+ because UnitHealth is always secret-tagged. See
--   Research/Variable_Taint_Solution_2026-05-04.md.
local function ApplyColorCurveTint(textureRef)
    if not textureRef then
        return
    end
    if not (C_CurveUtil and C_CurveUtil.CreateColorCurve and UnitHealthPercent) then
        return
    end
    local low = D.VARIANT_COLOR_CURVE_RGBA_LOW
    local high = D.VARIANT_COLOR_CURVE_RGBA_HIGH
    local okCurve, curve = pcall(C_CurveUtil.CreateColorCurve)
    if not okCurve or not curve or not curve.AddPoint then
        return
    end
    -- Table-form stops REQUIRED: positional components silently build an EMPTY curve (alpha-0 tint; proven in-game 2026-06-10).
    pcall(curve.AddPoint, curve, 0, { r = low[1], g = low[2], b = low[3], a = low[4] })
    pcall(curve.AddPoint, curve, 1, { r = high[1], g = high[2], b = high[3], a = high[4] })
    local okEval, result = pcall(UnitHealthPercent, "player", true, curve)
    if not okEval or not result or not result.GetRGBA then
        return
    end
    local okRGBA, r, g, b, a = pcall(result.GetRGBA, result)
    if not okRGBA or not r then
        return
    end
    textureRef:SetVertexColor(r, g, b, a or 1)
end

-- ApplyCooldownRing(cooldownRef, spellID):
--   Reads C_Spell.GetSpellCooldown(spellID) and stamps startTime + duration
--   onto cooldownRef. Both pcalls are render-path; no value is ever read back
--   into insecure arithmetic. Defensive: nil spellID + nil info short-circuit
--   so a variant whose first step does not resolve to a spell renders a
--   neutral ring instead of erroring.
local function ApplyCooldownRing(cooldownRef, spellID)
    if not cooldownRef or not spellID then
        return
    end
    if not (C_Spell and C_Spell.GetSpellCooldown) then
        return
    end
    local ok, info = pcall(C_Spell.GetSpellCooldown, spellID)
    if not ok or type(info) ~= "table" then
        return
    end
    local startTime = info.startTime
    local duration = info.duration
    if not startTime or not duration then
        return
    end
    pcall(cooldownRef.SetCooldown, cooldownRef, startTime, duration)
end

-- PulseBorder(textureRef, periodSec, minA, maxA):
--   Drives a sin-wave alpha pulse on textureRef via OnUpdate, stamped on
--   textureRef's parent frame. Caller sets parent._pulseEnabled to true to
--   start and false to stop; the OnUpdate respects the flag and idles when
--   off (alpha clamped to maxA so the border stays visible without pulsing).
local function PulseBorder(textureRef, periodSec, minA, maxA)
    if not textureRef then
        return
    end
    local parent = textureRef:GetParent()
    if not parent then
        return
    end
    parent._pulsePhase = parent._pulsePhase or 0
    parent._pulseEnabled = true
    parent:SetScript("OnUpdate", function(self, elapsed)
        if not self._pulseEnabled then
            textureRef:SetAlpha(maxA)
            -- IC-VAR-08-polish: detach the OnUpdate once we have both stopped
            -- pulsing and gone offscreen, so the no-op handler does not keep
            -- firing every frame for the entire session lifetime.
            if not self:IsShown() then
                self:SetScript("OnUpdate", nil)
            end
            return
        end
        self._pulsePhase = (self._pulsePhase or 0) + (elapsed or 0)
        local p = periodSec > 0 and periodSec or 1
        local theta = (self._pulsePhase / p) * math.pi * 2
        local sinNorm = (math.sin(theta) + 1) * 0.5
        local alpha = minA + (maxA - minA) * sinNorm
        textureRef:SetAlpha(alpha)
    end)
end

local function CreateOverlay(button)
    local frame = CreateFrame("Frame", nil, UIParent)
    frame:SetSize(button:GetWidth() or 36, button:GetHeight() or 36)
    frame:SetPoint("CENTER", button, "CENTER", 0, 0)
    frame:SetFrameStrata(button:GetFrameStrata() or "MEDIUM")
    frame:SetFrameLevel((button:GetFrameLevel() or 0) + 5)
    frame:Hide()

    local tex = frame:CreateTexture(nil, "OVERLAY")
    tex:SetAllPoints(frame)
    tex:SetTexCoord(0.07, 0.93, 0.07, 0.93)

    -- IC-VAR-08 layered indicators (only used when entry.variantIdx is set
    -- and the barVariantIndicators setting is enabled). Frame-level ordering
    -- keeps cooldownRing UNDER statusIcon + borderPulse so the sweep arc
    -- does not eat the threshold tint or the armed border. statusIcon
    -- anchors TOPRIGHT outside the cooldown arc; borderPulse anchors to the
    -- 4 edges with a 1px inset so the pulse rims the overlay, not the icon.
    local statusIcon = frame:CreateTexture(nil, "ARTWORK")
    statusIcon:SetSize(16, 16)
    statusIcon:SetPoint("TOPRIGHT", frame, "TOPRIGHT", 0, 0)
    statusIcon:SetTexture(D.QUESTION_MARK_ICON)
    statusIcon:Hide()

    local cooldownRing = CreateFrame("Cooldown", nil, frame, "CooldownFrameTemplate")
    cooldownRing:SetAllPoints(frame)
    if cooldownRing.SetHideCountdownNumbers then
        cooldownRing:SetHideCountdownNumbers(true)
    end
    if cooldownRing.SetReverse then
        cooldownRing:SetReverse(true)
    end
    if cooldownRing.SetDrawEdge then
        cooldownRing:SetDrawEdge(false)
    end
    cooldownRing:SetFrameLevel(frame:GetFrameLevel() + 1)
    cooldownRing:Hide()

    local borderPulse = frame:CreateTexture(nil, "OVERLAY")
    borderPulse:SetColorTexture(1, 0.85, 0.25, 1)
    borderPulse:SetPoint("TOPLEFT", frame, "TOPLEFT", 1, -1)
    borderPulse:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -1, 1)
    borderPulse:Hide()

    return {
        frame = frame,
        texture = tex,
        button = button,
        statusIcon = statusIcon,
        cooldownRing = cooldownRing,
        borderPulse = borderPulse,
    }
end

local function GetOrCreateOverlay(button)
    if not button then
        return nil
    end
    local name = button.GetName and button:GetName()
    if not name then
        return nil
    end
    local entry = overlays[name]
    if not entry then
        entry = CreateOverlay(button)
        overlays[name] = entry
    end
    return entry
end

-- Returns the resolved first-step spellID for the given seqName + variantIdx,
-- or nil. variantIdx nil/1 = base button steps; 2..4 = variantOverrides[N-1].
local function ResolveVariantFirstSpellID(seqName, variantIdx)
    local Engine = GRIPEMS.Engine
    if not Engine or not Engine.sequences then
        return nil
    end
    local entry = Engine.sequences[seqName]
    if not entry or not entry.data then
        return nil
    end
    local ver = Engine.GetActiveVersion and Engine:GetActiveVersion(entry.data) or nil
    if not ver then
        return nil
    end
    local steps
    if variantIdx and variantIdx >= 2 then
        local override = ver.variantOverrides and ver.variantOverrides[variantIdx - 1]
        steps = override and override.steps
    else
        steps = ver.steps
    end
    if not steps or #steps == 0 then
        return nil
    end
    local SC = GRIPEMS.SpellCache
    if not SC or not SC.ParseSpellFromMacrotext then
        return nil
    end
    local spellName = SC:ParseSpellFromMacrotext(steps[1])
    if not spellName then
        return nil
    end
    if SC.GetSpellID then
        return SC:GetSpellID(spellName, entry.data.classID)
    end
    return nil
end

local function ApplyOverlayIcon(button, iconID, entry)
    if not button or not iconID then
        return
    end
    local overlay = GetOrCreateOverlay(button)
    if not overlay then
        return
    end
    overlay.texture:SetTexture(iconID)
    overlay.frame:Show()

    -- IC-VAR-08: per-variant indicator layers. Gated on entry.variantIdx and
    -- the barVariantIndicators setting; the single-variant path (entry nil
    -- or entry.variantIdx nil) leaves the new layers hidden so the previous
    -- behavior is byte-identical for unbound bars.
    local showVariants = entry
        and entry.variantIdx
        and GRIPEMS.Settings
        and GRIPEMS.Settings:Get("barVariantIndicators")
    if not showVariants then
        if overlay.statusIcon then
            overlay.statusIcon:Hide()
        end
        if overlay.cooldownRing then
            overlay.cooldownRing:Hide()
        end
        if overlay.borderPulse then
            overlay.borderPulse:Hide()
            overlay.frame._pulseEnabled = false
        end
        return
    end

    if not InCombatLockdown() then
        -- See ApplyColorCurveTint docstring for the curve-launder rationale.
        -- The prior Lua-division pattern crashed with secret-value taint on
        -- Patch 12.0+. Research/Variable_Taint_Solution_2026-05-04.md.
        ApplyColorCurveTint(overlay.statusIcon)
    end
    overlay.statusIcon:SetTexture(iconID)
    overlay.statusIcon:Show()

    local spellID = ResolveVariantFirstSpellID(entry.seqName, entry.variantIdx)
    if spellID then
        ApplyCooldownRing(overlay.cooldownRing, spellID)
        overlay.cooldownRing:Show()
    else
        overlay.cooldownRing:Hide()
    end

    overlay.borderPulse:Show()
end

local function HideOverlayByName(name)
    local entry = name and overlays[name]
    if entry then
        entry.frame:Hide()
    end
end

local function HideAllOverlays()
    for _, entry in pairs(overlays) do
        entry.frame:Hide()
    end
end

-- ---------------------------------------------------------------------------
-- Core methods
-- ---------------------------------------------------------------------------

function BI:Init()
    if BI.enabled then
        return
    end
    -- Respect setting (default true)
    if GRIPEMS.Settings and GRIPEMS.Settings.Get then
        local val = GRIPEMS.Settings:Get("barIntegration")
        if val == false then
            return
        end
    end

    -- Detect available addons
    local allAdapters = { BlizzardAdapter, ElvUIAdapter, BT4Adapter }
    for _, adapter in ipairs(allAdapters) do
        if adapter:IsAvailable() then
            BI.adapters[#BI.adapters + 1] = adapter
        end
    end

    if #BI.adapters == 0 then
        return
    end

    -- Initial scan
    BI:ScanAllButtons()

    -- BLIZZARD HOOK INTENTIONALLY DISABLED (BUG-BARINTEGRATION-ACTIONBAR-TAINT, 2026-05-03).
    -- We previously installed hooksecurefunc(ActionBarActionButtonMixin, "Update", ...) to
    -- refresh the bar icon overlay whenever Blizzard updated an action button. The closure
    -- did self.icon:SetTexture(iconID) -- an addon write to a Blizzard action button's
    -- texture child. Cumulative writes during OOC autoclick left the action bar tree
    -- addon-tainted, and ActionBarController_UpdateAll (fired on Guardian Druid form
    -- shifts, etc.) then blocked the protected MultiBarBottomLeft:ShowBase() call.
    --
    -- Trade-off accepted: Blizzard-bar users lose icon refresh on cooldown ticks, slot
    -- changes, vehicle entry, etc. The icon now only updates on EMS step advance
    -- (via OnStepAdvanced below). ElvUI/Bartender users are unaffected because the
    -- LAB OnButtonUpdate callback below still covers their bars.
    --
    -- Defensive guard now in place (2026-05-05): all bar-integration writes route
    -- through addon-owned overlay textures (see overlays table + ApplyOverlayIcon
    -- helper above). The Blizzard button's icon child is never written to. Re-enabling
    -- the hook to call ApplyOverlayIcon(self, ...) is now safe and is tracked as a
    -- follow-up in Backlog BUG-BARINTEGRATION-ACTIONBAR-TAINT (cosmetic refresh).

    -- Hook LAB button updates (covers ElvUI and BT4)
    -- LAB fires "OnButtonUpdate" callback after every button Update().
    -- The closure routes through ApplyOverlayIcon, so writes land on the
    -- addon-owned overlay texture only. LAB buttons are addon-owned, but
    -- we use the same overlay surface for uniformity with Blizzard bars.
    local LAB = LibStub and LibStub("LibActionButton-1.0", true)
    if LAB and LAB.RegisterCallback then
        LAB.RegisterCallback(BI, "OnButtonUpdate", function(_, btn)
            if not BI.enabled then
                return
            end
            if InCombatLockdown() then
                return
            end
            local name = btn:GetName()
            local entry = name and BI.trackedButtons[name]
            if entry then
                local iconID = ResolveSequenceIcon(entry.seqName)
                if iconID then
                    ApplyOverlayIcon(btn, iconID, entry)
                end
            end
        end)
    end

    -- Register GRIPEMS callbacks for lifecycle events
    if GRIPEMS.RegisterCallback then
        GRIPEMS.RegisterCallback(BI, "SEQUENCE_STEP_ADVANCED", "OnStepAdvanced")
        GRIPEMS.RegisterCallback(BI, "SEQUENCE_CREATED", "OnSequenceCreated")
        GRIPEMS.RegisterCallback(BI, "SEQUENCE_DELETED", "OnSequenceDeleted")
        -- IC-VAR-08: VARIANT_RECOMMENDATION_UPDATED -> per-variant pulse + alpha
        GRIPEMS.RegisterCallback(BI, "VARIANT_RECOMMENDATION_UPDATED", "OnRecommendationUpdated")
        -- IC-VAR-08: SETTING_CHANGED -> rescan on barVariantIndicators flip
        GRIPEMS.RegisterCallback(BI, "SETTING_CHANGED", "OnSettingChanged")
    end

    -- Private event frame for ACTIONBAR_SLOT_CHANGED + PLAYER_REGEN_ENABLED.
    -- IC-VAR-08 also routes UNIT_HEALTH + UNIT_POWER_UPDATE here so the
    -- ColorCurve tint refreshes on resource change. The OOC gate inside
    -- the handler matches Path D5 discipline -- HP/power are read only when
    -- InCombatLockdown() is false; cached tints persist during combat.
    local eventFrame = CreateFrame("Frame")
    eventFrame:RegisterEvent("ACTIONBAR_SLOT_CHANGED")
    eventFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
    eventFrame:RegisterEvent("UNIT_HEALTH")
    eventFrame:RegisterEvent("UNIT_POWER_UPDATE")
    eventFrame:SetScript("OnEvent", function(_, event, unit)
        if event == "ACTIONBAR_SLOT_CHANGED" then
            BI:DeferredRescan()
        elseif event == "PLAYER_REGEN_ENABLED" then
            if BI.pendingRescan then
                BI.pendingRescan = false
                BI:ScanAllButtons()
            end
        elseif event == "UNIT_HEALTH" or event == "UNIT_POWER_UPDATE" then
            if unit ~= "player" then
                return
            end
            if InCombatLockdown() then
                return
            end
            BI:RefreshVariantTints()
        end
    end)
    BI.eventFrame = eventFrame

    BI.enabled = true
    local names = {}
    for _, a in ipairs(BI.adapters) do
        names[#names + 1] = a.name
    end
    local count = 0
    for _ in pairs(BI.trackedButtons) do
        count = count + 1
    end
    GRIPEMS:Debug(string.format(L["GEMS_BAR_INTEGRATION_TRACKED"], count, table.concat(names, ", ")))
end

function BI:ScanAllButtons()
    -- Hide overlays and drop tracked entries before re-scanning.
    BI:RestoreAll()

    for _, adapter in ipairs(BI.adapters) do
        local buttons = adapter:GetButtons()
        for _, info in ipairs(buttons) do
            local resolved = GetSequenceFromSlot(info.slot)
            if resolved then
                local seqName = resolved.seqName
                local variantIdx = resolved.variantIdx
                BI.trackedButtons[info.frame:GetName()] = {
                    button = info.frame,
                    seqName = seqName,
                    variantIdx = variantIdx,
                }
                -- Apply overlay icon immediately (OOC check). The combat
                -- guard is paranoia carryover; overlay textures are
                -- addon-owned and safe to write at any time.
                if not InCombatLockdown() then
                    local iconID = ResolveSequenceIcon(seqName)
                    if iconID then
                        ApplyOverlayIcon(info.frame, iconID, BI.trackedButtons[info.frame:GetName()])
                    end
                end
            end
        end
    end
end

function BI:RestoreAll()
    -- Hide all addon-owned overlays. The Blizzard button icons were
    -- never modified, so there is nothing to restore on the Blizzard
    -- side -- this is the whole point of the overlay-texture pattern.
    HideAllOverlays()
    wipe(BI.trackedButtons)
end

function BI:OnStepAdvanced(_, seqName)
    if InCombatLockdown() then
        return
    end
    local iconID = ResolveSequenceIcon(seqName)
    if not iconID then
        return
    end
    for _, entry in pairs(BI.trackedButtons) do
        if entry.seqName == seqName then
            ApplyOverlayIcon(entry.button, iconID, entry)
        end
    end
end

function BI:OnSequenceCreated()
    BI:DeferredRescan()
end

function BI:OnSequenceDeleted(_, seqName)
    for globalName, entry in pairs(BI.trackedButtons) do
        if entry.seqName == seqName then
            HideOverlayByName(globalName)
            BI.trackedButtons[globalName] = nil
        end
    end
end

function BI:OnSettingChanged(_, key, _value)
    if key ~= "barVariantIndicators" then
        return
    end
    if InCombatLockdown() then
        BI.pendingRescan = true
        return
    end
    BI:ScanAllButtons()
end

-- IC-VAR-08: per-variant pulse + alpha when RecommendationEvaluator flips
-- the recommended modifier. Each tracked button's variantIdx (nil/1 = plain,
-- 2..4 = first/second/third override modifier read from the sequence's
-- variantOverrides ordered list) is compared against newMod. When the slot
-- matches: enable borderPulse + set frame alpha to ARMED_ALPHA. Otherwise:
-- stop pulse + dim to DIM_ALPHA. Single-variant tracked entries (variantIdx
-- nil) keep ARMED_ALPHA so the previous behavior stays byte-identical.
function BI:OnRecommendationUpdated(_, seqName, _oldMod, newMod)
    if not (GRIPEMS.Settings and GRIPEMS.Settings:Get("barVariantIndicators")) then
        return
    end
    local Engine = GRIPEMS.Engine
    if not Engine then
        return
    end
    local seqEntry = Engine.sequences and Engine.sequences[seqName]
    if not seqEntry or not seqEntry.data then
        return
    end
    local ver = Engine.GetActiveVersion and Engine:GetActiveVersion(seqEntry.data) or nil
    local overrides = ver and ver.variantOverrides or {}
    for trackedName, entry in pairs(BI.trackedButtons) do
        if entry.seqName == seqName then
            local slotMod
            if not entry.variantIdx or entry.variantIdx == 1 then
                slotMod = D.VARIANT_MOD_PLAIN
            else
                local override = overrides[entry.variantIdx - 1]
                slotMod = override and override.modifier or nil
            end
            local overlay = overlays[trackedName]
            if overlay then
                if slotMod and slotMod == newMod then
                    if overlay.borderPulse then
                        PulseBorder(
                            overlay.borderPulse,
                            D.VARIANT_PULSE_PERIOD,
                            D.VARIANT_PULSE_MIN_ALPHA,
                            D.VARIANT_PULSE_MAX_ALPHA
                        )
                        overlay.borderPulse:Show()
                    end
                    overlay.frame:SetAlpha(D.VARIANT_INDICATOR_ARMED_ALPHA)
                else
                    overlay.frame._pulseEnabled = false
                    if overlay.borderPulse then
                        overlay.borderPulse:SetAlpha(D.VARIANT_PULSE_MAX_ALPHA)
                        overlay.borderPulse:Hide()
                    end
                    overlay.frame:SetAlpha(D.VARIANT_INDICATOR_DIM_ALPHA)
                end
            end
        end
    end
end

-- IC-VAR-08: refresh ColorCurve tints on the per-variant statusIcon layer
-- after UNIT_HEALTH / UNIT_POWER_UPDATE. OOC-only; in combat we keep the
-- cached tint from the last sample (Path D5 discipline).
function BI:RefreshVariantTints()
    if not (GRIPEMS.Settings and GRIPEMS.Settings:Get("barVariantIndicators")) then
        return
    end
    -- Pre-12.0 IC-VAR-08-polish (2026-05-26 BugSack fix): the previous body
    -- read UnitHealth + UnitPower directly and divided by their Max
    -- counterparts to produce hpFrac/powerFrac, which crashed with
    -- "attempt to perform arithmetic on local 'hCur' (a secret number
    -- value...)" because UnitHealth is always secret-tagged on Patch 12.0+
    -- even OOC. The fix delegates the secret-value read entirely to
    -- ApplyColorCurveTint, which uses the canonical UnitHealthPercent +
    -- C_CurveUtil curve-launder pattern (Plater + NSRT precedent). See
    -- Research/Variable_Taint_Solution_2026-05-04.md.
    --
    -- The power-factor consideration from the prior implementation
    -- (use the LOWER of hp/power as the visual signal) is PERMANENTLY
    -- dropped. Curve-evaluated outputs are SECRET when the resource is
    -- restricted (GetRGBA components are individually secret-tagged), so
    -- ANY Lua comparison or blend of two evaluations throws. Proven
    -- in-game 2026-06-09 (IC-VAR-08-polish-3/-3b crash, both reverted).
    -- See the v2.4 addendum in Research/Variable_Taint_Solution_2026-05-04.md.
    -- Backlog row IC-VAR-08-POLISH-3-POWER-FACTOR-TINT is BLOCKED-CONCRETE.
    for trackedName, entry in pairs(BI.trackedButtons) do
        if entry.variantIdx then
            local overlay = overlays[trackedName]
            if overlay and overlay.statusIcon and overlay.statusIcon:IsShown() then
                ApplyColorCurveTint(overlay.statusIcon)
            end
        end
    end
end

function BI:DeferredRescan()
    if InCombatLockdown() then
        BI.pendingRescan = true
        return
    end
    if C_Timer and C_Timer.After then
        C_Timer.After(0.5, function()
            if not InCombatLockdown() then
                BI:ScanAllButtons()
            else
                BI.pendingRescan = true
            end
        end)
    end
end
