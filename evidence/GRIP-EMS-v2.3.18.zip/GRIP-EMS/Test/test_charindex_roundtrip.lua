-- GRIP-EMS: Headless test for the cross-character index + push outbox
--
-- Created:    2026-08-03
-- Updated:    2026-08-03
-- Patch: 12.0.7 Midnight (Retail LIVE)
--
-- Sequences are SavedVariablesPerCharacter, so an alt's sequences are never in
-- memory. Engine/CharIndex.lua bridges that with two account-scoped tables: a
-- METADATA index each character republishes at its own login, and a push outbox
-- the target character claims at its next login. This file pins the five
-- properties that make that safe:
--
--   C1  Publish stores summary fields ONLY -- the seven summary fields, among
--       them stepFunction, arrive; no steps, versions or actions reach
--       GRIP_EMS_DB -- and a wholesale overwrite drops deleted sequences.
--   C2  GetForeignRows excludes the current character, stamps foreign /
--       ownerChar / ownerRealm on every row it returns, passes stepFunction
--       through to the subtitle, and tolerates a meta published by an older
--       build that carries no stepFunction at all.
--   C3  StageCopy deep-copies and strips _recommendFunc (a compiled closure
--       cached on a version table; SavedVariables cannot serialize functions).
--   C4  A name collision on claim RENAMES the incoming sequence instead of
--       overwriting the local one, and escalates to a numeric suffix.
--   C5  Claim clears the outbox slot so a payload is never claimed twice.
--
-- Drives the REAL shipped Engine/CharIndex.lua through the WoW addon vararg
-- contract (loadfile + setfenv into a stub-backed sandbox).
--
-- Run from the EMS root:  lua Test/test_charindex_roundtrip.lua
-- Exit code 0 = all passed, 1 = at least one failure.

local ADDON_NAME = "GRIP-EMS"

-- ---------------------------------------------------------------------------
-- Minimal assertion + runner harness (mirrors test_v0_upgrade_guard.lua).
-- ---------------------------------------------------------------------------

local tests = {}

local function test(name, fn)
    tests[#tests + 1] = { name = name, fn = fn }
end

local function assertEqual(expected, actual, label)
    if expected ~= actual then
        error((label or "value") .. ": expected " .. tostring(expected) .. ", got " .. tostring(actual), 2)
    end
end

local function assertNil(actual, label)
    if actual ~= nil then
        error((label or "value") .. ": expected nil, got " .. tostring(actual), 2)
    end
end

local function assertTrue(cond, label)
    if not cond then
        error((label or "condition") .. " failed", 2)
    end
end

-- ---------------------------------------------------------------------------
-- Sandbox: a self-referential no-op stub backs every unknown global, so the
-- shipped module loads without a real WoW client. Real stdlib falls through.
-- ---------------------------------------------------------------------------

local stub = {}
setmetatable(stub, {
    __index = function()
        return stub
    end,
    __call = function()
        return stub
    end,
})

local env = setmetatable({}, {
    __index = function(_, k)
        local v = rawget(_G, k)
        if v ~= nil then
            return v
        end
        return stub
    end,
})
env._G = env

-- Locale keys echo back so every format string resolves.
local LOCALE = setmetatable({}, {
    __index = function(_, k)
        return k
    end,
})

env.LibStub = function()
    return {
        GetLocale = function()
            return LOCALE
        end,
    }
end
env.time = os.time
-- select(3, UnitClass("player")) is the classID Publish stamps on the entry.
env.UnitClass = function()
    return "Warrior", "WARRIOR", 1
end

-- Identity is swapped between characters by reassigning this upvalue.
local currentChar = { displayName = "Hero", realm = "RealmA" }

local printed = {}

local GRIPEMS = {
    Debug = function() end,
    Print = function(_, msg)
        printed[#printed + 1] = msg
    end,
    Identity = {
        GetCurrent = function()
            return { displayName = currentChar.displayName, realm = currentChar.realm }
        end,
    },
    Engine = {
        GetActiveVersion = function(_, seqData)
            if not seqData or type(seqData.versions) ~= "table" then
                return nil
            end
            return seqData.versions[seqData.defaultVersion or 1]
        end,
    },
    NormalizeUpdatedAt = function(v)
        return tonumber(v) or 0
    end,
}

-- ---------------------------------------------------------------------------
-- Load the REAL Engine/CharIndex.lua into the sandbox.
-- ---------------------------------------------------------------------------

local function loadModule(candidates)
    for _, path in ipairs(candidates) do
        -- loadfile is dev-harness file I/O, intentionally outside the addon WoW std.
        -- selene: allow(undefined_variable)
        local chunk = loadfile(path)
        if chunk then
            setfenv(chunk, env)
            chunk(ADDON_NAME, GRIPEMS)
            return true
        end
    end
    return false
end

assertTrue(
    loadModule({
        "Engine/CharIndex.lua",
        "../Engine/CharIndex.lua",
        "GRIP/EMS/Engine/CharIndex.lua",
    }),
    "could not locate Engine/CharIndex.lua (run from the EMS root)"
)

local CI = GRIPEMS.CharIndex
assertTrue(CI ~= nil, "GRIPEMS.CharIndex attached")

-- ---------------------------------------------------------------------------
-- Fixtures.
-- ---------------------------------------------------------------------------

local function MakeSequence(name)
    return {
        name = name,
        classID = 2,
        icon = 12345,
        description = "desc of " .. name,
        updatedAt = 500,
        versions = {
            { stepFunction = "Sequential", steps = { "/cast A", "/cast B" }, actions = { { type = "spell" } } },
            { stepFunction = "Priority", steps = { "/cast C" } },
        },
    }
end

--- Reset both SavedVariables scopes and the captured print log.
local function ResetWorld(charName, charRealm)
    currentChar = { displayName = charName, realm = charRealm }
    env.GRIP_EMS_CHAR = { sequences = {} }
    env.GRIP_EMS_DB = {}
    printed = {}
end

-- ---------------------------------------------------------------------------
-- C1: Publish writes metadata and no payload.
-- ---------------------------------------------------------------------------

test("C1a: Publish stores the seven summary fields and NO step/version payload", function()
    ResetWorld("Hero", "RealmA")
    env.GRIP_EMS_CHAR.sequences.Alpha = MakeSequence("Alpha")
    CI:Publish()

    local entry = env.GRIP_EMS_DB.charIndex["Hero-RealmA"]
    assertTrue(entry ~= nil, "charIndex entry created under the Name-Realm key")
    assertEqual("Hero", entry.name, "entry.name")
    assertEqual("RealmA", entry.realm, "entry.realm")
    assertEqual(1, entry.classID, "entry.classID from UnitClass")
    assertTrue(type(entry.publishedAt) == "number", "entry.publishedAt stamped")

    local meta = entry.seqs.Alpha
    assertTrue(meta ~= nil, "sequence indexed")
    assertEqual(2, meta.classID, "meta.classID")
    assertEqual(12345, meta.icon, "meta.icon")
    assertEqual("Sequential", meta.stepFunction, "meta.stepFunction from the active version")
    assertEqual(2, meta.stepCount, "meta.stepCount from the active version")
    assertEqual(2, meta.versionCount, "meta.versionCount")
    assertEqual(500, meta.updatedAt, "meta.updatedAt")
    assertEqual("desc of Alpha", meta.description, "meta.description")

    -- The point of the whole design: no payload crosses into account scope.
    assertNil(meta.steps, "meta.steps must not exist")
    assertNil(meta.versions, "meta.versions must not exist")
    assertNil(meta.actions, "meta.actions must not exist")
end)

test("C1b: scalar .versions does not raise and counts as one version", function()
    ResetWorld("Hero", "RealmA")
    -- Corrupt shape: a bare # on this field raises. Publish must survive it.
    env.GRIP_EMS_CHAR.sequences.Broken = { classID = 0, versions = 7 }
    CI:Publish()
    local meta = env.GRIP_EMS_DB.charIndex["Hero-RealmA"].seqs.Broken
    assertEqual(1, meta.versionCount, "scalar versions falls back to 1")
    assertEqual(0, meta.stepCount, "no active version means no steps")
end)

test("C1c: republishing drops a deleted sequence from the index", function()
    ResetWorld("Hero", "RealmA")
    env.GRIP_EMS_CHAR.sequences.Alpha = MakeSequence("Alpha")
    env.GRIP_EMS_CHAR.sequences.Beta = MakeSequence("Beta")
    CI:Publish()
    assertTrue(env.GRIP_EMS_DB.charIndex["Hero-RealmA"].seqs.Alpha ~= nil, "Alpha indexed on first publish")

    env.GRIP_EMS_CHAR.sequences.Alpha = nil
    CI:Publish()
    local seqs = env.GRIP_EMS_DB.charIndex["Hero-RealmA"].seqs
    assertNil(seqs.Alpha, "deleted sequence gone after republish")
    assertTrue(seqs.Beta ~= nil, "surviving sequence still indexed")
end)

-- ---------------------------------------------------------------------------
-- C2: GetForeignRows excludes the current character.
-- ---------------------------------------------------------------------------

test("C2: GetForeignRows returns other characters only, stamped foreign", function()
    ResetWorld("Hero", "RealmA")
    env.GRIP_EMS_CHAR.sequences.Mine = MakeSequence("Mine")
    CI:Publish()
    env.GRIP_EMS_DB.charIndex["Alt-RealmB"] = {
        name = "Alt",
        realm = "RealmB",
        classID = 5,
        seqs = {
            Theirs = {
                classID = 5,
                icon = 999,
                stepFunction = "Priority",
                stepCount = 3,
                versionCount = 1,
                updatedAt = 77,
                description = "x",
            },
        },
    }

    local rows = CI:GetForeignRows()
    assertEqual(1, #rows, "exactly one foreign row (own character excluded)")
    local row = rows[1]
    assertEqual("Theirs", row.name, "row.name")
    assertEqual(true, row.foreign, "row.foreign")
    assertEqual("Alt", row.ownerChar, "row.ownerChar")
    assertEqual("RealmB", row.ownerRealm, "row.ownerRealm")
    assertEqual(3, row.stepCount, "row.stepCount")
    assertEqual("Priority", row.stepFunction, "row.stepFunction reaches the subtitle")
    assertEqual(5, row.classID, "row.classID feeds the class filter")
    assertEqual(77, row.updatedAt, "row.updatedAt feeds the updated sort")

    -- Own-row-only fields are absent by design; every consumer nil-guards them.
    assertNil(row.keybind, "keybind is an own-row field")
    assertNil(row.liveVersion, "liveVersion is an own-row field")
end)

test("C2b: an absent charIndex yields an empty table, not nil", function()
    ResetWorld("Hero", "RealmA")
    local rows = CI:GetForeignRows()
    assertTrue(type(rows) == "table", "returns a table")
    assertEqual(0, #rows, "and it is empty")
end)

test("C2c: a meta from a build that never published stepFunction still yields a row", function()
    ResetWorld("Hero", "RealmA")
    -- Exactly the shape an alt running the previous build left behind: every
    -- other summary field present, stepFunction absent. The row must survive
    -- and carry nil so the subtitle falls back to its own default.
    env.GRIP_EMS_DB.charIndex = {
        ["Alt-RealmB"] = {
            name = "Alt",
            realm = "RealmB",
            classID = 5,
            seqs = {
                Legacy = { classID = 5, icon = 999, stepCount = 3, versionCount = 1, updatedAt = 77, description = "x" },
            },
        },
    }

    local rows = CI:GetForeignRows()
    assertEqual(1, #rows, "the row is still produced")
    assertEqual("Legacy", rows[1].name, "row.name")
    assertEqual(3, rows[1].stepCount, "the fields that ARE published still arrive")
    assertNil(rows[1].stepFunction, "row.stepFunction stays nil, never a fabricated default")
end)

-- ---------------------------------------------------------------------------
-- C3: StageCopy deep-copies and strips _recommendFunc.
-- ---------------------------------------------------------------------------

test("C3: StageCopy strips _recommendFunc and takes a real deep copy", function()
    ResetWorld("Hero", "RealmA")
    local seq = MakeSequence("Alpha")
    seq.versions[1]._recommendFunc = function()
        return true
    end
    seq._recommendFunc = function()
        return true
    end
    env.GRIP_EMS_CHAR.sequences.Alpha = seq

    local ok, reason = CI:StageCopy("Alpha", "Alt-RealmB")
    assertEqual(true, ok, "StageCopy succeeded (" .. tostring(reason) .. ")")

    local parcel = env.GRIP_EMS_DB.charOutbox["Alt-RealmB"].Alpha
    assertEqual("Hero-RealmA", parcel.from, "parcel.from is the sender charKey")
    assertNil(parcel.data._recommendFunc, "top-level _recommendFunc stripped")
    assertNil(parcel.data.versions[1]._recommendFunc, "per-version _recommendFunc stripped")
    assertEqual("/cast A", parcel.data.versions[1].steps[1], "payload steps survive the copy")

    -- Deep, not shallow: mutating the source must not reach the staged parcel.
    seq.versions[1].steps[1] = "/cast MUTATED"
    assertEqual("/cast A", parcel.data.versions[1].steps[1], "staged parcel is independent of the source")
end)

test("C3b: StageCopy refuses an unknown sequence and an empty target", function()
    ResetWorld("Hero", "RealmA")
    env.GRIP_EMS_CHAR.sequences.Alpha = MakeSequence("Alpha")
    assertEqual(false, (CI:StageCopy("Nope", "Alt-RealmB")), "unknown sequence rejected")
    assertEqual(false, (CI:StageCopy("Alpha", "")), "empty target rejected")
    assertEqual(false, (CI:StageCopy("Alpha", "Hero-RealmA")), "self-targeting rejected")
    assertNil(env.GRIP_EMS_DB.charOutbox, "nothing staged on a rejected call")
end)

-- ---------------------------------------------------------------------------
-- C4 / C5: claim renames on collision, never overwrites, and clears the outbox.
-- ---------------------------------------------------------------------------

test("C4a: a colliding claim renames the incoming sequence, local one untouched", function()
    ResetWorld("Alt", "RealmB")
    env.GRIP_EMS_CHAR.sequences.Alpha = { marker = "mine" }
    env.GRIP_EMS_DB.charOutbox = {
        ["Alt-RealmB"] = {
            Alpha = { from = "Hero-RealmA", data = { marker = "theirs" } },
        },
    }

    local claimed, renames = CI:ClaimInbox()
    assertEqual(1, claimed, "one sequence claimed")
    assertEqual(1, #renames, "one rename reported")
    assertEqual("Alpha", renames[1].from, "rename.from")
    assertEqual("Alpha (Hero)", renames[1].to, "rename.to uses the sender character name")

    assertEqual("mine", env.GRIP_EMS_CHAR.sequences.Alpha.marker, "local sequence NOT overwritten")
    assertEqual("theirs", env.GRIP_EMS_CHAR.sequences["Alpha (Hero)"].marker, "incoming stored under the new name")
    assertEqual("Alpha (Hero)", env.GRIP_EMS_CHAR.sequences["Alpha (Hero)"].name, "data.name follows the table key")
end)

test("C4b: a second collision escalates to a numeric suffix", function()
    ResetWorld("Alt", "RealmB")
    env.GRIP_EMS_CHAR.sequences.Alpha = { marker = "mine" }
    env.GRIP_EMS_CHAR.sequences["Alpha (Hero)"] = { marker = "earlier copy" }
    env.GRIP_EMS_DB.charOutbox = {
        ["Alt-RealmB"] = {
            Alpha = { from = "Hero-RealmA", data = { marker = "theirs" } },
        },
    }

    local claimed, renames = CI:ClaimInbox()
    assertEqual(1, claimed, "one sequence claimed")
    assertEqual("Alpha (Hero) 2", renames[1].to, "suffix escalates past the taken name")
    assertEqual("earlier copy", env.GRIP_EMS_CHAR.sequences["Alpha (Hero)"].marker, "earlier copy untouched")
    assertEqual("theirs", env.GRIP_EMS_CHAR.sequences["Alpha (Hero) 2"].marker, "new copy stored beside it")
end)

test("C4c: a non-colliding claim keeps its name and reports no renames", function()
    ResetWorld("Alt", "RealmB")
    env.GRIP_EMS_DB.charOutbox = {
        ["Alt-RealmB"] = {
            Fresh = { from = "Hero-RealmA", data = { marker = "theirs" } },
        },
    }
    local claimed, renames = CI:ClaimInbox()
    assertEqual(1, claimed, "one sequence claimed")
    assertEqual(0, #renames, "no renames")
    assertEqual("theirs", env.GRIP_EMS_CHAR.sequences.Fresh.marker, "stored under its own name")
end)

test("C5: claim clears the outbox slot and is not claimable twice", function()
    ResetWorld("Alt", "RealmB")
    env.GRIP_EMS_DB.charOutbox = {
        ["Alt-RealmB"] = {
            Fresh = { from = "Hero-RealmA", data = { marker = "theirs" } },
        },
        ["Third-RealmC"] = {
            Untouched = { from = "Hero-RealmA", data = { marker = "not mine" } },
        },
    }

    assertEqual(1, (CI:ClaimInbox()), "first claim takes the payload")
    assertNil(env.GRIP_EMS_DB.charOutbox["Alt-RealmB"], "our outbox slot cleared")
    assertTrue(env.GRIP_EMS_DB.charOutbox["Third-RealmC"] ~= nil, "another character's slot left alone")

    env.GRIP_EMS_CHAR.sequences.Fresh = nil
    assertEqual(0, (CI:ClaimInbox()), "second claim finds nothing")
    assertNil(env.GRIP_EMS_CHAR.sequences.Fresh, "and re-inserts nothing")
end)

test("C5b: claim prints one summary line plus one line per rename", function()
    ResetWorld("Alt", "RealmB")
    env.GRIP_EMS_CHAR.sequences.Alpha = { marker = "mine" }
    env.GRIP_EMS_DB.charOutbox = {
        ["Alt-RealmB"] = {
            Alpha = { from = "Hero-RealmA", data = { marker = "theirs" } },
        },
    }
    CI:ClaimInbox()
    assertEqual(2, #printed, "one summary line + one rename line")
end)

-- ---------------------------------------------------------------------------
-- Run.
-- ---------------------------------------------------------------------------

local passed = 0
local failed = 0
for _, t in ipairs(tests) do
    local ok, err = pcall(t.fn)
    if ok then
        passed = passed + 1
        print("PASS  " .. t.name)
    else
        failed = failed + 1
        print("FAIL  " .. t.name .. " " .. tostring(err))
    end
end
print(string.format("RESULT %d passed, %d failed", passed, failed))
os.exit(failed > 0 and 1 or 0)
