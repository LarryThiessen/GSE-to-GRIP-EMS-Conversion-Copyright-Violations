-- GRIP-EMS: PluginAPI
-- Created: 2026-04-03
-- Updated: 2026-08-17
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)

-- GRIP-EMS: Plugin/Addon Registration API
-- Public API for third-party addons to register sequences with EMS

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

GRIPEMS.PluginAPI = {}
local PA = GRIPEMS.PluginAPI

-- Internal storage for registered addons
-- Structure per entry:
-- { name=string, version=string, sequences={}, checksum=string,
--   loaded=false, loadedAt=nil }
PA.registeredAddons = {}

-- Recursive deep copy. Registered sequence data must be fully EMS-owned: the
-- Engine compiles it into execute strings and secure-button attributes, so the
-- plugin must not keep a live alias it could mutate after registration to change
-- what the Engine runs. Scalars pass through; nested tables are cloned.
local function DeepCopy(value)
    if type(value) ~= "table" then
        return value
    end
    local copy = {}
    for k, v in pairs(value) do
        copy[k] = DeepCopy(v)
    end
    return copy
end

--- Register a third-party addon and its sequences with EMS.
--- Call this from your addon's initialization (after GRIPEMS is available).
--- @param name string Addon/plugin name (must be non-empty)
--- @param version string Version string
--- @param seqNames table Array of sequence name strings to register
--- @param seqTable table Table keyed by sequence names containing sequence data
--- @return boolean success True if registration succeeded
function GRIPEMS.RegisterAddon(name, version, seqNames, seqTable)
    -- Validate inputs
    if type(name) ~= "string" or name == "" then
        GRIPEMS:Print("RegisterAddon: name must be a non-empty string")
        return false
    end
    if type(version) ~= "string" then
        GRIPEMS:Print("RegisterAddon: version must be a string")
        return false
    end
    if type(seqNames) ~= "table" then
        GRIPEMS:Print("RegisterAddon: seqNames must be a table")
        return false
    end
    if type(seqTable) ~= "table" then
        GRIPEMS:Print("RegisterAddon: seqTable must be a table")
        return false
    end

    -- Reject duplicate registration
    if PA.registeredAddons[name] then
        GRIPEMS:Print("RegisterAddon: '" .. name .. "' is already registered")
        return false
    end

    -- Compute simple checksum: sorted seqNames concatenated, length as marker
    local sorted = {}
    for i = 1, #seqNames do
        sorted[i] = seqNames[i]
    end
    table.sort(sorted)
    local concat = table.concat(sorted, "")
    local checksum = tostring(string.len(concat))

    -- Store registration entry
    local entry = {
        name = name,
        version = version,
        sequences = {},
        checksum = checksum,
        loaded = false,
        loadedAt = nil,
    }

    -- Deep-copy each sequence into EMS-owned storage and stamp pluginSource on
    -- the copy, never the caller's table. The plugin keeps no alias into the data
    -- the Engine compiles and runs, so it cannot mutate execution post-registration.
    for _, seqName in ipairs(seqNames) do
        if seqTable[seqName] then
            local seqData = DeepCopy(seqTable[seqName])
            seqData.pluginSource = name
            entry.sequences[seqName] = seqData
        end
    end

    PA.registeredAddons[name] = entry

    -- Notify listeners
    if GRIPEMS.Fire then
        GRIPEMS:Fire("PLUGIN_REGISTERED", name, version)
    end

    GRIPEMS:Print(string.format(L["GEMS_PLUGIN_REGISTERED"], name, version, #seqNames))
    return true
end

--- Load all pending plugin sequences into the Engine.
--- User-created sequences take priority (skipped if name already exists).
--- Called automatically during PLAYER_LOGIN after user sequences are restored.
function GRIPEMS.LoadPluginSequences()
    local Engine = GRIPEMS.Engine
    if not Engine then
        return
    end

    for addonName, addon in pairs(PA.registeredAddons) do
        if not addon.loaded then
            for seqName, seqData in pairs(addon.sequences) do
                if Engine.sequences[seqName] then
                    -- User version takes priority
                    GRIPEMS:Print(string.format(L["GEMS_PLUGIN_SKIP_EXISTS"], addonName, seqName))
                else
                    local ok, err = pcall(Engine.ActivateSequence, Engine, seqName, seqData)
                    if not ok then
                        GRIPEMS:Debug("Plugin ActivateSequence failed for '" .. seqName .. "': " .. tostring(err))
                    end
                end
            end
            addon.loaded = true
            addon.loadedAt = time()
            GRIPEMS:Print(string.format(L["GEMS_PLUGIN_LOADED"], addonName))
        end
    end

    -- Notify listeners
    if GRIPEMS.Fire then
        GRIPEMS:Fire("PLUGIN_SEQUENCES_LOADED")
    end
end

--- Get status information for a registered plugin addon.
--- @param addonName string The addon name to query
--- @return table|nil status Status table or nil if not registered
function GRIPEMS.GetPluginSequenceStatus(addonName)
    local addon = PA.registeredAddons[addonName]
    if not addon then
        return nil
    end

    local Engine = GRIPEMS.Engine
    local sequenceCount = 0
    local activeCount = 0

    for seqName in pairs(addon.sequences) do
        sequenceCount = sequenceCount + 1
        if Engine and Engine.sequences[seqName] then
            activeCount = activeCount + 1
        end
    end

    return {
        name = addon.name,
        version = addon.version,
        checksum = addon.checksum,
        loaded = addon.loaded,
        loadedAt = addon.loadedAt,
        sequenceCount = sequenceCount,
        activeCount = activeCount,
    }
end

--- Get a list of all registered addons for UI display.
--- @return table list Array of { name, version, loaded, sequenceCount }
function GRIPEMS.GetRegisteredAddons()
    local list = {}
    for _, addon in pairs(PA.registeredAddons) do
        local count = 0
        for _ in pairs(addon.sequences) do
            count = count + 1
        end
        list[#list + 1] = {
            name = addon.name,
            version = addon.version,
            loaded = addon.loaded,
            sequenceCount = count,
        }
    end
    return list
end

-- ===========================================================================
-- Plugin API v2 -- plugin handle + ownership + teardown journal + lifecycle
-- (Phase A backbone)
--
-- RegisterPlugin(id, meta) -> frozen handle. The id is the namespace for every
-- contribution the plugin makes. The handle carries the id in a CLOSURE (never a
-- public field a caller could rewrite); each contribution made through the handle
-- is recorded in the plugin's teardown journal, owned by the id. DisablePlugin
-- replays the journal so EMS returns to its default-installed state, then runs
-- OnDisable. EnablePlugin re-runs OnEnable so the plugin re-establishes its
-- in-memory registry contributions.
--
-- Engine / Settings / StepFunctions are resolved by call-time lookup (nil-safe)
-- so load order and the headless harness both work. The four runtime registries
-- and the owned-sequence Engine path are the SAME shared tables the public
-- registrars write to (GRIPEMS._variableProviders / _conditions /
-- _layoutProviders and GRIPEMS.Engine.sequences) -- teardown removes from those,
-- never from a private copy.
-- ===========================================================================

-- id -> { id, meta, handle, enabled }
PA.plugins = {}

-- id -> teardown journal. Phase A categories only: the four in-memory registry
-- contributions and the owned-sequence names. Later phases add setting / CVar
-- snapshots and view / panel ids.
PA.journal = {}

-- key -> { owner = id, def = def }. The settings panel reads this to build the Plugins group.
PA.settingsDefs = {}

-- plugin /gems subcommands keyed by lowercased sub-name, each value { owner = id, handler = fn, helpText = string|nil }.
PA.slashCommands = {}

-- key -> { base = <pre-plugin value>, stack = { { plugin = id, value = v }, ... } }.
-- base is the user value if one was set, else the default, captured the first time ANY
-- plugin overrides the key, so a user value is never lost. The last stack entry is the live
-- override (most-recently-enabled wins). base is restored when the stack empties.
PA.settingOverrides = {}

-- Sentinel placed in a journal settingSnapshots slot when the captured base is nil (a
-- plugin-defined key with no default and no stored value). A literal nil cannot live in the
-- table -- it would drop the key and disable would skip reverting it -- so the sentinel keeps
-- the key present for the teardown loop; the real nil base is restored from
-- PA.settingOverrides[key].base.
local NIL_SNAPSHOT = {}

-- A fresh, empty journal of the Phase A shape. Used at registration and to reset
-- the journal after a disable replay.
local function NewJournal()
    return {
        registries = {
            variableProviders = {},
            conditions = {},
            stepFunctions = {},
            layoutProviders = {},
            views = {},
            panels = {},
            settingsDefs = {},
            importProviders = {},
            exportProviders = {},
            -- Array of /gems sub-names THIS plugin registered (Phase C); removed on disable.
            slashCommands = {},
        },
        ownedSequences = {},
        -- Plugin-created macros (Phase B). Array of sequence names whose action-bar macro
        -- stub THIS plugin caused EMS to create via EnsureSequenceMacro. A pre-existing
        -- EMS/user stub is returned WITHOUT journaling, so disable (MM:DeleteStub per name)
        -- only removes macros the plugin itself brought into existence.
        createdMacros = {},
        settingSnapshots = {},
        -- CVar requests (Phase G). cvarTouched is the set of CVar names this
        -- plugin's RequestCVarProfile changed (each restored through the manager's
        -- UndoPrevious on disable; a CVar with no captured previous value no-ops, so
        -- over-recording a skipped CVar is harmless). cvarProfileCaptured gates
        -- whether the prior active-profile id was snapshotted (nil = General is a
        -- valid prior id); cvarProfileRestore holds it so disable restores the
        -- pre-plugin active profile -- the same prior-id restore pattern Phase D uses
        -- for the active view.
        cvarTouched = {},
        cvarProfileCaptured = false,
        cvarProfileRestore = nil,
        -- View / nav + chrome teardown (Phase D). viewActiveRestore holds the
        -- active view id captured before this plugin's FIRST SetActiveView; nil is
        -- a valid captured value (no active view), so viewActiveCaptured gates
        -- whether a restore runs on disable. chromeHidden records that the plugin
        -- hid the classic chrome so disable shows it again.
        viewActiveCaptured = false,
        viewActiveRestore = nil,
        chromeHidden = false,
    }
end

-- Plugin setting-override base snapshot persistence. The pre-plugin base value for an
-- overridden key is stored in a plugin-namespaced SV bucket so it survives a reload while
-- the plugin stays enabled; without this, a reload re-derives the base from the already-
-- overridden live value and disable cannot reach the genuine pre-plugin value. The {value=v}
-- wrapper keeps a nil base distinguishable from an absent key (an empty table is still present).
local function PluginSettingBaseBucket()
    local db = _G.GRIP_EMS_DB
    if type(db) ~= "table" then
        return nil
    end
    db.pluginSettingBase = db.pluginSettingBase or {}
    return db.pluginSettingBase
end

local function ReadPersistedSettingBase(key)
    local bucket = PluginSettingBaseBucket()
    if not bucket then
        return false, nil
    end
    local entry = bucket[key]
    if type(entry) ~= "table" then
        return false, nil
    end
    return true, entry.value
end

local function WritePersistedSettingBase(key, value)
    local bucket = PluginSettingBaseBucket()
    if bucket then
        bucket[key] = { value = value }
    end
end

local function ClearPersistedSettingBase(key)
    local bucket = PluginSettingBaseBucket()
    if bucket then
        bucket[key] = nil
    end
end

-- Drop every persisted setting-override base whose key has no active override. Called
-- once after all enabled plugins have re-applied their overrides (right after
-- GEMS_UI_READY). A base with no active override is orphaned: the plugin that captured
-- it was removed (or disabled by removal) while enabled, so no RevertSettingLayer ran to
-- clear it. Pruning the stale base means a later first-capture of that key reads the
-- current live value, not the orphaned snapshot. Idempotent; never changes a live value
-- (the orphaned override, like an orphaned owned sequence, is left in place).
function GRIPEMS.ReconcileOrphanSettingBases()
    local bucket = PluginSettingBaseBucket()
    if not bucket then
        return
    end
    for key in pairs(bucket) do
        if PA.settingOverrides[key] == nil then
            bucket[key] = nil
        end
    end
end

-- Revert one plugin's override layer for a single setting key and re-apply the value that
-- should now be live. Removes every stack entry owned by pluginId. If the stack empties,
-- restores rec.base (the user value if one was set when the key was first overridden, else
-- the default) and drops the record; otherwise the most-recently-enabled remaining layer
-- (top of stack) wins. Routes the re-applied value through Settings:Set so SETTING_CHANGED
-- fires exactly once. Returns false when the key has no record or this plugin owns no layer
-- in it (the caller treats false as "not ours"). Shared by RevertSetting (explicit) and
-- DisablePlugin (teardown) so both paths behave identically.
local function RevertSettingLayer(key, pluginId)
    local rec = PA.settingOverrides[key]
    if not rec then
        return false
    end
    local removed = false
    for i = #rec.stack, 1, -1 do
        if rec.stack[i].plugin == pluginId then
            table.remove(rec.stack, i)
            removed = true
        end
    end
    if not removed then
        return false
    end
    local newValue
    if #rec.stack == 0 then
        newValue = rec.base
        PA.settingOverrides[key] = nil
        ClearPersistedSettingBase(key)
    else
        newValue = rec.stack[#rec.stack].value
    end
    local Settings = GRIPEMS.Settings
    if Settings and Settings.Set then
        Settings:Set(key, newValue)
    end
    return true
end

-- Revert every CVar this plugin changed through RequestCVarProfile and restore the
-- pre-plugin active profile, returning the CVar surface to its default-installed
-- state. UndoPrevious routes through the existing manager (pin-aware, combat /
-- secure-aware, fires CVAR_UNDO_APPLIED); a CVar with no captured previous value
-- no-ops, so over-recording a skipped CVar is harmless. Restores cvarActiveProfile
-- to the id captured before this plugin's FIRST RequestCVarProfile (nil = General).
-- Clears the journal CVar state. Shared by RevertCVarProfile (explicit) and
-- DisablePlugin (teardown). Returns true if the plugin had requested a profile,
-- false otherwise.
local function RevertPluginCVars(pluginId)
    local j = PA.journal[pluginId]
    if not j or not j.cvarProfileCaptured then
        return false
    end
    local CPM = GRIPEMS.CvarProfileManager
    if CPM and CPM.UndoPrevious then
        for cvar in pairs(j.cvarTouched) do
            CPM:UndoPrevious(cvar)
        end
    end
    local Settings = GRIPEMS.Settings
    if Settings and Settings.Set then
        Settings:Set("cvarActiveProfile", j.cvarProfileRestore)
    end
    j.cvarTouched = {}
    j.cvarProfileCaptured = false
    j.cvarProfileRestore = nil
    return true
end

-- Build a frozen plugin handle for id. The handle is a read-only proxy (same
-- pattern as GRIPEMS.API): __index reads through to a per-plugin methods table,
-- __newindex errors, __metatable is false. id lives only as an upvalue of the
-- methods closure, so a caller can never read it as a field or rewrite it. Every
-- method takes a leading ignored self because callers use handle:Method(...).
local function BuildHandle(id)
    local methods = {}

    --- The plugin id this handle owns.
    --- @return string id
    function methods.GetId(_)
        return id
    end

    --- Register a read-only variable provider owned by this plugin. Delegates to
    --- the validated public registrar; on success the provider id is recorded in
    --- the teardown journal so disable removes it.
    --- @param spec table Provider table (id, name, Resolve, optional OnRegister)
    --- @return boolean ok
    --- @return string|nil reason
    function methods.RegisterVariableProvider(_, spec)
        if type(spec) ~= "table" then
            return false, "RegisterVariableProvider: spec must be a table"
        end
        local ok, reason = GRIPEMS.API:RegisterVariableProvider(spec.id, spec)
        if ok then
            local owned = PA.journal[id].registries.variableProviders
            owned[#owned + 1] = spec.id
        end
        return ok, reason
    end

    --- Register a condition predicate owned by this plugin. Journaled on success.
    --- @param spec table Condition table (id, name, Evaluate, optional OnRegister)
    --- @return boolean ok
    --- @return string|nil reason
    function methods.RegisterCondition(_, spec)
        if type(spec) ~= "table" then
            return false, "RegisterCondition: spec must be a table"
        end
        local ok, reason = GRIPEMS.API:RegisterCondition(spec.id, spec)
        if ok then
            local owned = PA.journal[id].registries.conditions
            owned[#owned + 1] = spec.id
        end
        return ok, reason
    end

    --- Register a step-ordering strategy owned by this plugin. Journaled on success.
    --- @param spec table Step-function table (id, name, Expand, optional OnRegister)
    --- @return boolean ok
    --- @return string|nil reason
    function methods.RegisterStepFunction(_, spec)
        if type(spec) ~= "table" then
            return false, "RegisterStepFunction: spec must be a table"
        end
        local ok, reason = GRIPEMS.API:RegisterStepFunction(spec.id, spec)
        if ok then
            local owned = PA.journal[id].registries.stepFunctions
            owned[#owned + 1] = spec.id
        end
        return ok, reason
    end

    --- Register a UI layout provider owned by this plugin. Journaled on success.
    --- @param provider table Provider table (id, name, optional lifecycle callbacks)
    --- @return boolean ok
    --- @return string|nil reason
    function methods.RegisterLayoutProvider(_, provider)
        if type(provider) ~= "table" then
            return false, "RegisterLayoutProvider: provider must be a table"
        end
        local ok, reason = GRIPEMS.API.UI:RegisterLayoutProvider(provider.id, provider)
        if ok then
            local owned = PA.journal[id].registries.layoutProviders
            owned[#owned + 1] = provider.id
        end
        return ok, reason
    end

    --- Create and activate a sequence OWNED by this plugin (Tier 5 authoring).
    --- Rejects a non-string / empty name or non-table data. Refuses to clobber a
    --- sequence that exists and is NOT owned by this plugin (a user sequence has no
    --- ownerPlugin; another plugin's sequence carries a different id). On success it
    --- deep-copies data into EMS-owned storage, stamps ownerPlugin, persists it in
    --- the plugin-namespaced bucket, and activates it through Engine:ActivateSequence
    --- -- which is the site that fires the public SEQUENCE_CREATED event, so this
    --- method never fires it directly (a second fire here would double-fire). The
    --- name is journaled once for disable removal; re-creating an already-owned name
    --- re-applies the data without a duplicate journal entry.
    --- @param name string Sequence name
    --- @param data table Sequence definition
    --- @return boolean ok
    --- @return string|nil reason
    function methods.CreateSequence(_, name, data)
        if type(name) ~= "string" or name == "" then
            return false, "CreateSequence: name must be a non-empty string"
        end
        if type(data) ~= "table" then
            return false, "CreateSequence: data must be a table"
        end
        local Engine = GRIPEMS.Engine
        if Engine and Engine.sequences then
            local existing = Engine.sequences[name]
            if existing and not (existing.data and existing.data.ownerPlugin == id) then
                return false, "CreateSequence: '" .. name .. "' is not owned by this plugin"
            end
        end
        local copy = DeepCopy(data)
        copy.ownerPlugin = id
        local db = _G.GRIP_EMS_DB
        if type(db) == "table" then
            db.pluginOwned = db.pluginOwned or {}
            db.pluginOwned[id] = db.pluginOwned[id] or {}
            db.pluginOwned[id][name] = copy
        end
        if Engine and Engine.ActivateSequence then
            Engine:ActivateSequence(name, copy)
        end
        local owned = PA.journal[id].ownedSequences
        for i = 1, #owned do
            if owned[i] == name then
                return true
            end
        end
        owned[#owned + 1] = name
        return true
    end

    --- Update a sequence OWNED by this plugin (Tier 5 authoring). Owner-required:
    --- the sequence must already exist AND carry this plugin's ownerPlugin stamp; a
    --- user sequence (no ownerPlugin), another plugin's sequence, or an unknown name
    --- is rejected. On success it deep-copies the new data, re-stamps ownerPlugin,
    --- replaces the plugin-namespaced bucket entry, and routes through
    --- Engine:UpdateSequenceData -- which is the site that fires SEQUENCE_UPDATED, so
    --- this method never fires it directly. The name is already journaled by
    --- CreateSequence, so the journal is left unchanged (no double-tracking).
    --- @param name string Sequence name
    --- @param data table Updated sequence definition
    --- @return boolean ok
    --- @return string|nil reason
    function methods.UpdateSequence(_, name, data)
        if type(name) ~= "string" or name == "" then
            return false, "UpdateSequence: name must be a non-empty string"
        end
        if type(data) ~= "table" then
            return false, "UpdateSequence: data must be a table"
        end
        local Engine = GRIPEMS.Engine
        local existing = Engine and Engine.sequences and Engine.sequences[name]
        if not (existing and existing.data and existing.data.ownerPlugin == id) then
            return false, "UpdateSequence: '" .. tostring(name) .. "' is not owned by this plugin"
        end
        local copy = DeepCopy(data)
        copy.ownerPlugin = id
        local db = _G.GRIP_EMS_DB
        if type(db) == "table" and db.pluginOwned and db.pluginOwned[id] then
            db.pluginOwned[id][name] = copy
        end
        if Engine.UpdateSequenceData then
            Engine:UpdateSequenceData(name, copy)
        end
        return true
    end

    --- Delete a sequence OWNED by this plugin (Tier 5 authoring). Owner-required,
    --- same check as UpdateSequence. Routes through Engine:DeactivateSequence(name,
    --- false) -- which is the site that fires SEQUENCE_DELETED, so this method never
    --- fires it directly -- then drops the sequence from the Engine (only if still
    --- owned by this id), the plugin-namespaced bucket, and the journal so a later
    --- disable does not try to remove it again.
    --- @param name string Sequence name
    --- @return boolean ok
    --- @return string|nil reason
    function methods.DeleteSequence(_, name)
        if type(name) ~= "string" or name == "" then
            return false, "DeleteSequence: name must be a non-empty string"
        end
        local Engine = GRIPEMS.Engine
        local existing = Engine and Engine.sequences and Engine.sequences[name]
        if not (existing and existing.data and existing.data.ownerPlugin == id) then
            return false, "DeleteSequence: '" .. tostring(name) .. "' is not owned by this plugin"
        end
        if Engine.DeactivateSequence then
            Engine:DeactivateSequence(name, false)
        end
        if Engine.sequences then
            local entry = Engine.sequences[name]
            if entry and entry.data and entry.data.ownerPlugin == id then
                Engine.sequences[name] = nil
            end
        end
        local db = _G.GRIP_EMS_DB
        if type(db) == "table" and db.pluginOwned and db.pluginOwned[id] then
            db.pluginOwned[id][name] = nil
        end
        local owned = PA.journal[id].ownedSequences
        for i = #owned, 1, -1 do
            if owned[i] == name then
                table.remove(owned, i)
            end
        end
        return true
    end

    --- Ensure the sequence's draggable action-bar macro stub exists, returning its slot
    --- index so the plugin can PickupMacro(index) onto a bar. Owner-scoped + reversible: a
    --- macro this call creates is journaled and deleted on disable; a macro that already
    --- exists (EMS auto-stub or a prior call) is returned WITHOUT journaling so disable never
    --- deletes a user/EMS-owned macro. Macro CRUD is out-of-combat only -- in combat returns
    --- false + reason. Honors the MacroManager slot-pool overflow guard. The sequence must
    --- exist. A WoW macro is taint-neutral; no secure path opens.
    --- @param name string Sequence name (must be a live sequence)
    --- @return number|boolean macroIndex slot index on success, or false on failure
    --- @return string|nil reason failure reason when the first return is false
    function methods.EnsureSequenceMacro(_, name)
        if type(name) ~= "string" or name == "" then
            return false, "EnsureSequenceMacro: name must be a non-empty string"
        end
        local Engine = GRIPEMS.Engine
        local entry = Engine and Engine.sequences and Engine.sequences[name]
        if not entry then
            return false, "EnsureSequenceMacro: unknown sequence '" .. name .. "'"
        end
        local MM = GRIPEMS.MacroManager
        if not MM or not MM.CreateStub then
            return false, "EnsureSequenceMacro: macro manager unavailable"
        end
        -- Already has a stub (EMS auto-stub or a prior call): return it, journal nothing.
        if MM.stubs and MM.stubs[name] then
            return MM.stubs[name]
        end
        -- Macro CRUD is protected; only safe out of combat. OOCQueue is nil-safe here
        -- (absent in the headless harness -> treated as not restricted).
        local OOC = GRIPEMS.OOCQueue
        if OOC and OOC.IsRestricted and OOC:IsRestricted() then
            return false, "EnsureSequenceMacro: in combat; try again out of combat"
        end
        -- Slot-pool overflow guard BEFORE creating.
        if MM.GetAvailableSlots and MM:GetAvailableSlots() <= 0 then
            return false, "EnsureSequenceMacro: macro slot pool is full"
        end
        -- Create the stub from the active version's keyPress/keyRelease/steps so it matches
        -- an EMS-created stub. Out of combat MM:CreateStub runs synchronously, so
        -- MM.stubs[name] is populated on return.
        local ver = (Engine.GetActiveVersion and Engine:GetActiveVersion(entry.data)) or nil
        local kp = ver and ver.keyPress or nil
        local kr = ver and ver.keyRelease or nil
        local steps = ver and ver.steps or nil
        MM:CreateStub(name, kp, kr, steps)
        local slot = MM.stubs and MM.stubs[name]
        if not slot then
            return false, "EnsureSequenceMacro: macro creation failed"
        end
        -- Journal as plugin-created so disable deletes it (dedup like ownedSequences).
        local owned = PA.journal[id].createdMacros
        for i = 1, #owned do
            if owned[i] == name then
                return slot
            end
        end
        owned[#owned + 1] = name
        return slot
    end

    --- Drive the UI to select a sequence in the list (Tier 5 UI action). Delegates
    --- to the in-core sequence-list selection path, which loads the sequence into
    --- the editor and fires GEMS_SEQUENCE_SELECTED. A read / UI action only: not
    --- owner-scoped (selecting does not mutate the sequence), not persisted, not
    --- journaled. Nil-safe when the list module is absent (headless / pre-UI).
    --- @param name string Sequence name
    --- @return boolean ok
    --- @return string|nil reason
    function methods.SelectSequence(_, name)
        if type(name) ~= "string" or name == "" then
            return false, "SelectSequence: name must be a non-empty string"
        end
        local SL = GRIPEMS.SequenceList
        if not (SL and SL.DoSelectSequence) then
            return false, "SelectSequence: the sequence list is not available"
        end
        SL:DoSelectSequence(name)
        return true
    end

    --- Drive the UI to open a sequence in the editor (Tier 5 UI action). Delegates
    --- to the editor's load path. A read / UI action only: not owner-scoped, not
    --- persisted, not journaled. Nil-safe when the editor module is absent.
    --- @param name string Sequence name
    --- @return boolean ok
    --- @return string|nil reason
    function methods.OpenEditor(_, name)
        if type(name) ~= "string" or name == "" then
            return false, "OpenEditor: name must be a non-empty string"
        end
        local SE = GRIPEMS.SequenceEditor
        if not (SE and SE.LoadSequence) then
            return false, "OpenEditor: the sequence editor is not available"
        end
        SE:LoadSequence(name)
        return true
    end

    --- Register a plugin-owned setting definition (Tier: settings). The def names a key
    --- plus AceConfig presentation hints (type, name, desc, and for range types min / max /
    --- step) that the settings panel reads to build the Plugins group. Rejects a non-table
    --- def or a non-string / empty key, and refuses to clobber a key already registered (by
    --- this or any plugin). The key is journaled so disable unregisters it. Registration
    --- does NOT change any live value -- it only makes the key visible to the panel and to
    --- OverrideSetting's known-key check.
    --- @param def table { key, type, name, desc, min, max, step }
    --- @return boolean ok
    --- @return string|nil reason
    function methods.RegisterSetting(_, def)
        if type(def) ~= "table" then
            return false, "RegisterSetting: def must be a table"
        end
        local key = def.key
        if type(key) ~= "string" or key == "" then
            return false, "RegisterSetting: def.key must be a non-empty string"
        end
        if PA.settingsDefs[key] then
            return false, "RegisterSetting: '" .. key .. "' is already registered"
        end
        PA.settingsDefs[key] = { owner = id, def = def }
        local owned = PA.journal[id].registries.settingsDefs
        owned[#owned + 1] = key
        return true
    end

    --- Override a setting value, owned by this plugin (Tier: settings). The key must be
    --- known -- either a built-in default (Settings.defaults.profile[key]) or a key some
    --- plugin registered via RegisterSetting -- else it is rejected. The first time ANY
    --- plugin overrides the key, the pre-plugin value (user value if set, else the default)
    --- is snapshotted as base. This plugin's prior layer (if any) is replaced, then a fresh
    --- layer is pushed on top so it becomes live (most-recently-enabled wins). The value is
    --- applied through Settings:Set, which is the ONLY site that fires SETTING_CHANGED --
    --- this method never fires it directly. The base is recorded in the journal (a nil base
    --- via an internal sentinel) so disable reverts this key even when the pre-plugin value
    --- was nil.
    --- @param key string A known setting key
    --- @param value any New value
    --- @return boolean ok
    --- @return string|nil reason
    function methods.OverrideSetting(_, key, value)
        if type(key) ~= "string" or key == "" then
            return false, "OverrideSetting: key must be a non-empty string"
        end
        local Settings = GRIPEMS.Settings
        if not (Settings and Settings.Get and Settings.Set) then
            return false, "OverrideSetting: settings are not available"
        end
        local known = (Settings.defaults and Settings.defaults.profile and Settings.defaults.profile[key] ~= nil)
            or PA.settingsDefs[key] ~= nil
        if not known then
            return false, "OverrideSetting: '" .. key .. "' is not a known setting"
        end
        local rec = PA.settingOverrides[key]
        if not rec then
            local captured, persistedBase = ReadPersistedSettingBase(key)
            local base
            if captured then
                base = persistedBase
            else
                base = Settings:Get(key)
                WritePersistedSettingBase(key, base)
            end
            rec = { base = base, stack = {} }
            PA.settingOverrides[key] = rec
        end
        for i = #rec.stack, 1, -1 do
            if rec.stack[i].plugin == id then
                table.remove(rec.stack, i)
            end
        end
        rec.stack[#rec.stack + 1] = { plugin = id, value = value }
        if rec.base == nil then
            PA.journal[id].settingSnapshots[key] = NIL_SNAPSHOT
        else
            PA.journal[id].settingSnapshots[key] = rec.base
        end
        Settings:Set(key, value)
        return true
    end

    --- Revert this plugin's override of a setting key (Tier: settings). Rejects a key with
    --- no override record, or one this plugin holds no layer in. On success the live value
    --- falls back to the next remaining layer, or to the base value when this was the last
    --- layer (the user value is preserved -- never the bare default unless the user never
    --- set one). Shares RevertSettingLayer with disable, so the re-applied value routes
    --- through Settings:Set and SETTING_CHANGED fires exactly once. Clears the journal
    --- snapshot for the key.
    --- @param key string The overridden key
    --- @return boolean ok
    --- @return string|nil reason
    function methods.RevertSetting(_, key)
        if type(key) ~= "string" or key == "" then
            return false, "RevertSetting: key must be a non-empty string"
        end
        if not PA.settingOverrides[key] then
            return false, "RevertSetting: '" .. key .. "' is not overridden"
        end
        if not RevertSettingLayer(key, id) then
            return false, "RevertSetting: '" .. key .. "' is not overridden by this plugin"
        end
        PA.journal[id].settingSnapshots[key] = nil
        return true
    end

    --- Register a named view (UI screen) owned by this plugin. Delegates to the
    --- public UI registrar; on success the view id is journaled so disable
    --- unregisters it. viewId is a separate parameter from the plugin id this
    --- handle owns (which lives only in the closure -- never name a param "id" here).
    --- @param viewId string View id (must equal def.id)
    --- @param def table View def ({ id, name })
    --- @return boolean ok
    --- @return string|nil reason
    function methods.RegisterView(_, viewId, def)
        local ok, reason = GRIPEMS.API.UI:RegisterView(viewId, def)
        if ok then
            local owned = PA.journal[id].registries.views
            owned[#owned + 1] = viewId
        end
        return ok, reason
    end

    --- Set the active view, owned by this plugin. On the FIRST call it snapshots
    --- the active view id that was live BEFORE this plugin touched it (nil is a
    --- valid snapshot), so disable restores it. Delegates to the public UI
    --- primitive (which fires GEMS_UI_NAV_CHANGED).
    --- @param viewId string A registered view id
    --- @return boolean ok
    --- @return string|nil reason
    function methods.SetActiveView(_, viewId)
        local j = PA.journal[id]
        if not j.viewActiveCaptured then
            j.viewActiveCaptured = true
            j.viewActiveRestore = GRIPEMS.API.UI:GetActiveView()
        end
        return GRIPEMS.API.UI:SetActiveView(viewId)
    end

    --- Mount a built-in panel into a host frame, owned by this plugin. Delegates
    --- to the public UI primitive; on success the panel id is journaled so disable
    --- un-mounts it back to its original parent (content panels) or no-ops
    --- (dialog / preview ids).
    --- @param panelId string A known panel id
    --- @param host table|nil Host frame (ignored by dialog-class ids)
    --- @return boolean ok
    --- @return string|nil reason
    function methods.MountPanel(_, panelId, host)
        local ok, reason = GRIPEMS.API.UI:MountPanel(panelId, host)
        if ok then
            local owned = PA.journal[id].registries.panels
            owned[#owned + 1] = panelId
        end
        return ok, reason
    end

    --- Show / hide the classic two-panel chrome, owned by this plugin. Delegates
    --- to the public UI primitive; records that the plugin hid the chrome so
    --- disable shows it again.
    --- @param enabled boolean|nil false hides the classic chrome; true / nil shows it
    --- @return boolean ok
    --- @return string|nil reason
    function methods.SetClassicChrome(_, enabled)
        local ok, reason = GRIPEMS.API.UI:SetClassicChrome(enabled)
        if ok and enabled == false then
            PA.journal[id].chromeHidden = true
        end
        return ok, reason
    end

    --- Apply a CVar profile, owned by this plugin (Tier 5 authoring). The profile id
    --- must resolve through the CVar profile manager (a built-in or a stored custom
    --- profile), else it is rejected. On this plugin's FIRST request the active
    --- profile id live BEFORE the plugin touched it is snapshotted (nil = General is
    --- valid) so disable restores it. The CVars the apply changes -- the union of the
    --- outgoing and incoming profile overrides -- are recorded in the journal; disable
    --- restores each through the manager's UndoPrevious. The apply itself routes
    --- through CvarProfileManager:ApplyProfile, which snapshots each live value
    --- (CapturePrevious) before SetCVar and is combat / secure-aware -- no new
    --- CVar-write path is created here. Nil-safe when the manager is absent.
    --- @param profileKey string A known CVar profile id
    --- @return boolean ok
    --- @return string|nil reason
    function methods.RequestCVarProfile(_, profileKey)
        if type(profileKey) ~= "string" or profileKey == "" then
            return false, "RequestCVarProfile: profileKey must be a non-empty string"
        end
        local CPM = GRIPEMS.CvarProfileManager
        if not (CPM and CPM.GetProfile and CPM.ApplyProfile) then
            return false, "RequestCVarProfile: the CVar profile manager is not available"
        end
        local newProfile = CPM:GetProfile(profileKey)
        if not newProfile then
            return false, "RequestCVarProfile: '" .. profileKey .. "' is not a known profile"
        end
        local j = PA.journal[id]
        local Settings = GRIPEMS.Settings
        local oldKey = Settings and Settings.Get and Settings:Get("cvarActiveProfile")
        if not j.cvarProfileCaptured then
            j.cvarProfileCaptured = true
            j.cvarProfileRestore = oldKey
        end
        local oldProfile = CPM:GetProfile(oldKey)
        if oldProfile and oldProfile.overrides then
            for cvar in pairs(oldProfile.overrides) do
                j.cvarTouched[cvar] = true
            end
        end
        if newProfile.overrides then
            for cvar in pairs(newProfile.overrides) do
                j.cvarTouched[cvar] = true
            end
        end
        CPM:ApplyProfile(profileKey)
        return true
    end

    --- Revert this plugin's CVar profile request (Tier 5 authoring). Restores every
    --- CVar the plugin changed through the manager's UndoPrevious and puts the active
    --- profile back to the id live before the plugin's first request. Rejects when the
    --- plugin never requested a profile. Shares RevertPluginCVars with disable.
    --- @return boolean ok
    --- @return string|nil reason
    function methods.RevertCVarProfile(_)
        if not RevertPluginCVars(id) then
            return false, "RevertCVarProfile: this plugin has not requested a CVar profile"
        end
        return true
    end

    --- Register an import format provider owned by this plugin (Tier 5 authoring).
    --- The plugin supplies a parser; EMS owns the import pipeline. Delegates to the
    --- validated public registrar; on success the provider id is journaled so disable
    --- removes it.
    --- @param spec table Provider table (id, name, Parse, optional Detect, OnRegister)
    --- @return boolean ok
    --- @return string|nil reason
    function methods.RegisterImportProvider(_, spec)
        if type(spec) ~= "table" then
            return false, "RegisterImportProvider: spec must be a table"
        end
        local ok, reason = GRIPEMS.API:RegisterImportProvider(spec.id, spec)
        if ok then
            local owned = PA.journal[id].registries.importProviders
            owned[#owned + 1] = spec.id
        end
        return ok, reason
    end

    --- Register an export format provider owned by this plugin (Tier 5 authoring).
    --- The plugin supplies a serializer; EMS owns the export pipeline. Journaled.
    --- @param spec table Provider table (id, name, Serialize, optional OnRegister)
    --- @return boolean ok
    --- @return string|nil reason
    function methods.RegisterExportProvider(_, spec)
        if type(spec) ~= "table" then
            return false, "RegisterExportProvider: spec must be a table"
        end
        local ok, reason = GRIPEMS.API:RegisterExportProvider(spec.id, spec)
        if ok then
            local owned = PA.journal[id].registries.exportProviders
            owned[#owned + 1] = spec.id
        end
        return ok, reason
    end

    --- Register a /gems subcommand owned by this plugin (Plugin API v3 Phase C). The
    --- plugin supplies a handler the dispatcher calls as handler(argString) when a user
    --- types "/gems <sub> <args>" and <sub> is not a built-in. Owner-scoped + journaled:
    --- the subcommand is removed on disable. Slash dispatch is taint-neutral -- no secure
    --- path opens and no event fires. Rejects a name that is not a clean single token, a
    --- built-in collision, or a duplicate.
    --- @param sub string Subcommand name (letters/digits/underscore only; lowercased)
    --- @param handler function Called with the argument string on dispatch
    --- @param helpText string|nil Optional one-line help shown by /gems help
    --- @return boolean ok
    --- @return string|nil reason
    function methods.RegisterSlashCommand(_, sub, handler, helpText)
        if type(sub) ~= "string" or sub == "" then
            return false, "RegisterSlashCommand: sub must be a non-empty string"
        end
        sub = sub:lower()
        if not sub:match("^[%l%d_]+$") then
            return false, "RegisterSlashCommand: sub must be letters, digits, or underscore only"
        end
        if type(handler) ~= "function" then
            return false, "RegisterSlashCommand: handler must be a function"
        end
        if helpText ~= nil and type(helpText) ~= "string" then
            return false, "RegisterSlashCommand: helpText must be a string or nil"
        end
        -- Built-in collision: never let a plugin shadow a core /gems subcommand. nil-safe so
        -- a harness without Core loaded skips this check.
        if GRIPEMS.IsBuiltinSlashCommand and GRIPEMS.IsBuiltinSlashCommand(sub) then
            return false, "RegisterSlashCommand: '" .. sub .. "' is a built-in /gems command"
        end
        if PA.slashCommands[sub] then
            return false, "RegisterSlashCommand: '" .. sub .. "' is already registered"
        end
        PA.slashCommands[sub] = { owner = id, handler = handler, helpText = helpText }
        local owned = PA.journal[id].registries.slashCommands
        for i = 1, #owned do
            if owned[i] == sub then
                return true
            end
        end
        owned[#owned + 1] = sub
        return true
    end

    return setmetatable({}, {
        __index = methods,
        __newindex = function()
            error("GRIP-EMS plugin handle is read-only", 2)
        end,
        __metatable = false,
    })
end

--- Register a plugin and return its frozen handle (impl behind
--- GRIPEMS.API:RegisterPlugin). Validates the id, rejects a duplicate (never
--- overwrites), creates the empty teardown journal, builds the handle, persists
--- the per-plugin enable state in GRIP_EMS_DB (nil-safe so the headless harness
--- can supply its own DB), runs meta.OnEnable in pcall, and fires PLUGIN_ENABLED.
--- @param id string Plugin id (non-empty string)
--- @param meta table|nil Optional { name, version, OnEnable, OnDisable }
--- @return table|nil handle Frozen handle, or nil on rejection
--- @return string|nil reason Failure reason when handle is nil
function GRIPEMS.RegisterPluginImpl(id, meta)
    if type(id) ~= "string" or id == "" then
        return nil, "RegisterPlugin: id must be a non-empty string"
    end
    if PA.plugins[id] then
        return nil, "RegisterPlugin: id '" .. id .. "' is already registered"
    end
    if meta ~= nil and type(meta) ~= "table" then
        return nil, "RegisterPlugin: meta must be a table when present"
    end

    PA.journal[id] = NewJournal()
    local handle = BuildHandle(id)

    -- Load-time enable-state: a plugin the user disabled in a prior session stays disabled
    -- across reloads. The persisted record in GRIP_EMS_DB.plugins[id] is authoritative; a
    -- missing record (first-ever registration) defaults to enabled.
    local db = _G.GRIP_EMS_DB
    local persistedEnabled = true
    if type(db) == "table" and db.plugins and db.plugins[id] and db.plugins[id].enabled == false then
        persistedEnabled = false
    end
    PA.plugins[id] = { id = id, meta = meta, handle = handle, enabled = persistedEnabled }

    if type(db) == "table" then
        db.plugins = db.plugins or {}
        db.pluginOwned = db.pluginOwned or {}
        db.pluginOwned[id] = db.pluginOwned[id] or {}
        db.plugins[id] = { enabled = persistedEnabled }
    end

    -- Only run the enable lifecycle when the plugin is actually enabled. A persisted-disabled
    -- plugin still returns its handle (so it can EnablePlugin later) but does not run OnEnable
    -- or fire PLUGIN_ENABLED.
    if persistedEnabled then
        if meta and type(meta.OnEnable) == "function" then
            pcall(meta.OnEnable, handle)
        end
        if GRIPEMS.Fire then
            GRIPEMS:Fire("PLUGIN_ENABLED", id)
        end
    end
    return handle
end

--- Dispatch a /gems subcommand to a plugin handler (Plugin API v3 Phase C). The core
--- dispatcher calls this for any cmd it does not match as a built-in; cmd arrives already
--- lowercased from ParseSlashInput. Returns false when no plugin claims the cmd (the
--- dispatcher then prints the unknown-command message). When a plugin owns the cmd its
--- handler runs in pcall as handler(arg or "") -- a handler error is soft-logged and
--- swallowed so a broken plugin can never break the dispatcher -- and this returns true
--- (the cmd was claimed). Taint-neutral: no secure path opens, no event fires.
--- @param _ any Ignored self (callable as GRIPEMS.PluginAPI:DispatchSlashCommand)
--- @param cmd string The lowercased subcommand name
--- @param arg string|nil The argument string after the subcommand
--- @return boolean handled True when a plugin claimed the cmd
function PA.DispatchSlashCommand(_, cmd, arg)
    local entry = PA.slashCommands[cmd]
    if not entry then
        return false
    end
    local ok, err = pcall(entry.handler, arg or "")
    if not ok and GRIPEMS.Debug then
        GRIPEMS:Debug("plugin slash handler '%s' error: %s", tostring(cmd), tostring(err))
    end
    return true
end

--- Disable a plugin: replay its teardown journal so EMS returns to the
--- default-installed state, then run OnDisable. Reverts in order -- variable
--- providers (remove the matching entry from the shared ordered array),
--- conditions (clear by id), step functions (unregister by id), layout providers
--- (clear by id; restore uiLayout to classic if it pointed at a removed id), and
--- owned sequences (deactivate, drop from the Engine only if still owned by this
--- id, drop from the namespaced bucket), views (unregister by id; restore the
--- active view to the pre-plugin id, or the classic default), panels (un-mount to
--- the original parent), and classic chrome (show it again if the plugin hid it).
--- Then it clears the journal, flips the
--- enable flags, runs meta.OnDisable in pcall, and fires PLUGIN_DISABLED.
--- @param id string Plugin id
--- @return boolean ok False when the id is unknown, true otherwise
function GRIPEMS.DisablePlugin(id)
    local plugin = PA.plugins[id]
    if not plugin then
        return false
    end
    local journal = PA.journal[id] or NewJournal()
    local registries = journal.registries

    -- Variable providers: shared ordered array; find by .id and remove that index.
    local providers = GRIPEMS._variableProviders
    if providers then
        for _, provId in ipairs(registries.variableProviders) do
            for i = 1, #providers do
                if providers[i].id == provId then
                    table.remove(providers, i)
                    break
                end
            end
        end
    end

    -- Conditions: dict keyed by id.
    local conds = GRIPEMS._conditions
    if conds then
        for _, condId in ipairs(registries.conditions) do
            conds[condId] = nil
        end
    end

    -- Step functions: clear through the engine module's unregister primitive.
    local SF = GRIPEMS.StepFunctions
    if SF and SF.UnregisterStepFunction then
        for _, sfId in ipairs(registries.stepFunctions) do
            SF:UnregisterStepFunction(sfId)
        end
    end

    -- Layout providers: dict keyed by id; restore the active layout to classic
    -- when the stored uiLayout setting pointed at a provider we just removed.
    local layouts = GRIPEMS._layoutProviders
    local Settings = GRIPEMS.Settings
    if layouts then
        for _, layId in ipairs(registries.layoutProviders) do
            layouts[layId] = nil
            if Settings and Settings.Get and Settings.Set and Settings:Get("uiLayout") == layId then
                Settings:Set("uiLayout", "classic")
            end
        end
    end

    -- Owned sequences: deactivate, drop from the Engine only if still ours, drop
    -- from the plugin-namespaced bucket.
    local Engine = GRIPEMS.Engine
    local db = _G.GRIP_EMS_DB
    for _, seqName in ipairs(journal.ownedSequences) do
        if Engine and Engine.DeactivateSequence then
            Engine:DeactivateSequence(seqName, false)
        end
        if Engine and Engine.sequences then
            local entry = Engine.sequences[seqName]
            if entry and entry.data and entry.data.ownerPlugin == id then
                Engine.sequences[seqName] = nil
            end
        end
        if type(db) == "table" and db.pluginOwned and db.pluginOwned[id] then
            db.pluginOwned[id][seqName] = nil
        end
    end

    -- Plugin-created macros (Phase B): delete each macro stub this plugin caused EMS to
    -- create. EnsureSequenceMacro journaled a name only when its call brought the stub into
    -- existence (a pre-existing EMS/user stub was returned un-journaled), so this never
    -- deletes a macro the user or EMS owns. MM:DeleteStub is OOC-queued and idempotent.
    local MM = GRIPEMS.MacroManager
    if MM and MM.DeleteStub then
        for _, seqName in ipairs(journal.createdMacros) do
            MM:DeleteStub(seqName)
        end
    end

    -- Plugin /gems subcommands (Phase C): drop each subcommand this plugin registered,
    -- owner-checked so a re-registration by another plugin is never clobbered (mirrors the
    -- settingsDefs owner-checked teardown).
    for _, sub in ipairs(registries.slashCommands) do
        if PA.slashCommands[sub] and PA.slashCommands[sub].owner == id then
            PA.slashCommands[sub] = nil
        end
    end

    -- Views (Phase D): dict keyed by id, same shape as conditions / layouts.
    -- Unregister each view this plugin added, then restore the active view to the
    -- id captured before the plugin's first SetActiveView (nil = classic default).
    local viewsReg = GRIPEMS._views
    if viewsReg then
        for _, viewId in ipairs(registries.views) do
            viewsReg[viewId] = nil
        end
    end
    if journal.viewActiveCaptured and GRIPEMS.RestoreActiveView then
        GRIPEMS:RestoreActiveView(journal.viewActiveRestore)
    end

    -- Panels (Phase D): un-mount each panel this plugin mounted back to the parent
    -- recorded on first mount (content panels); dialog / preview ids no-op.
    if GRIPEMS.UnmountPanel then
        for _, panelId in ipairs(registries.panels) do
            GRIPEMS:UnmountPanel(panelId)
        end
    end

    -- Classic chrome (Phase D): if the plugin hid it, show it again.
    if journal.chromeHidden and GRIPEMS.API and GRIPEMS.API.UI then
        GRIPEMS.API.UI:SetClassicChrome(true)
    end

    -- Settings (Phase F): revert every key this plugin overrode (RevertSettingLayer
    -- re-applies the fallback value and fires SETTING_CHANGED once per key), then drop every
    -- setting definition this plugin registered so the panel stops showing them.
    for key in pairs(journal.settingSnapshots) do
        RevertSettingLayer(key, id)
    end
    for _, key in ipairs(registries.settingsDefs) do
        if PA.settingsDefs[key] and PA.settingsDefs[key].owner == id then
            PA.settingsDefs[key] = nil
        end
    end

    -- Import / export providers (Phase G): shared ordered arrays; find each by .id
    -- and remove that index, the same shape as the variable-provider teardown above.
    local impProviders = GRIPEMS._importProviders
    if impProviders then
        for _, provId in ipairs(registries.importProviders) do
            for i = 1, #impProviders do
                if impProviders[i].id == provId then
                    table.remove(impProviders, i)
                    break
                end
            end
        end
    end
    local expProviders = GRIPEMS._exportProviders
    if expProviders then
        for _, provId in ipairs(registries.exportProviders) do
            for i = 1, #expProviders do
                if expProviders[i].id == provId then
                    table.remove(expProviders, i)
                    break
                end
            end
        end
    end

    -- CVar requests (Phase G): restore every CVar the plugin changed through the
    -- manager's UndoPrevious and put the active profile back to the pre-plugin id.
    RevertPluginCVars(id)

    PA.journal[id] = NewJournal()
    plugin.enabled = false
    if type(db) == "table" then
        db.plugins = db.plugins or {}
        db.plugins[id] = db.plugins[id] or {}
        db.plugins[id].enabled = false
    end

    local meta = plugin.meta
    if meta and type(meta.OnDisable) == "function" then
        pcall(meta.OnDisable, plugin.handle)
    end
    if GRIPEMS.Fire then
        GRIPEMS:Fire("PLUGIN_DISABLED", id)
    end
    return true
end

--- Re-enable a previously disabled plugin. Flips the enable flags and re-runs
--- meta.OnEnable in pcall -- the plugin re-establishes its in-memory registry
--- contributions there (the journal was cleared on disable). Fires PLUGIN_ENABLED.
--- @param id string Plugin id
--- @return boolean ok False when the id is unknown, true otherwise
function GRIPEMS.EnablePlugin(id)
    local plugin = PA.plugins[id]
    if not plugin then
        return false
    end
    plugin.enabled = true
    local db = _G.GRIP_EMS_DB
    if type(db) == "table" then
        db.plugins = db.plugins or {}
        db.plugins[id] = db.plugins[id] or {}
        db.plugins[id].enabled = true
    end
    local meta = plugin.meta
    if meta and type(meta.OnEnable) == "function" then
        pcall(meta.OnEnable, plugin.handle)
    end
    if GRIPEMS.Fire then
        GRIPEMS:Fire("PLUGIN_ENABLED", id)
    end
    return true
end
