-- GRIP-EMS: Defaults
-- Constants, limits, and template data for the sequencer engine

local ADDON_NAME, GRIPEMS = ...

-- Defaults module: provides named constants for all numeric limits, icon IDs,
-- and template sequence data used throughout the engine. No magic numbers in
-- any other file -- they all reference GRIPEMS.Defaults instead.
GRIPEMS.Defaults = {}
local D = GRIPEMS.Defaults

-- Macro system limits (verified against 12.0.1 API, Research/07 Section 2)
D.MAX_MACROTEXT_LENGTH = 255       -- macro slot cap (CreateMacro/EditMacro) since Patch 11.0.2
D.MAX_SAB_MACROTEXT_LENGTH = 1023  -- Practical warning threshold for SAB macrotext (no hard WoW limit)
D.MAX_MACRO_BODY = 255             -- CreateMacro body cap
D.MAX_MACRO_NAME = 16              -- WoW UI enforced name length
D.MAX_PER_CHAR_MACROS = MAX_CHARACTER_MACROS or 30  -- per-character macro slots
D.MAX_ACCOUNT_MACROS = MAX_ACCOUNT_MACROS or 120    -- account-wide macro slots

-- Icons
D.QUESTION_MARK_ICON = "INV_Misc_QuestionMark"  -- string texture name (guaranteed format)

-- Attribute type constants (SecureActionButton type values)
D.ATTR_TYPE_SPELL = "spell"        -- CastSpellByID/Name
D.ATTR_TYPE_MACRO = "macro"        -- RunMacro/RunMacroText (255-char macrotext limit)
D.ATTR_TYPE_ITEM  = "item"         -- UseItem
D.ATTR_TYPE_CLICK = "click"        -- clickbutton:Click() (also used as pause/no-op)

-- Macro stub naming
D.MACRO_PREFIX = "GEMS:"           -- prefix for GRIP-EMS managed macros
D.BUTTON_PREFIX = "GRIPEMS_"       -- prefix for SecureActionButton global names
-- Two %s args: both the button global name. The [button:1] conditional targets
-- left-click /click events with LeftButton+t flags; the trailing bare name is
-- a fallback for virtual button and keyboard-only usage.
D.MACRO_BODY_TEMPLATE = "#showtooltip\n/click [button:1] %s LeftButton t; %s"

-- OOC queue
D.OOC_TICKER_INTERVAL = 7          -- seconds between fallback queue processing

-- Step function names (registry keys)
D.STEP_SEQUENTIAL = "Sequential"
D.STEP_RANDOM = "Random"
D.STEP_PRIORITY = "Priority"
D.STEP_REVERSE_PRIORITY = "ReversePriority"

-- Context version selection (T2-1)
D.CONTEXT_NONE = "none"

-- Ordered array of all 15 context key strings
D.CONTEXT_KEYS = {
    "Raid", "RaidLFR", "RaidHeroic", "RaidMythic",
    "Arena", "PVP",
    "MythicPlus", "Mythic", "Heroic", "Dungeon",
    "Timewalking", "Delves", "Party", "Solo", "Scenario",
}

-- Display labels for each context key
D.CONTEXT_LABELS = {
    Raid        = "Raid",
    RaidLFR     = "Raid: LFR",
    RaidHeroic  = "Raid: Heroic",
    RaidMythic  = "Raid: Mythic",
    Arena       = "Arena",
    PVP         = "Battleground",
    MythicPlus  = "Mythic+",
    Mythic      = "Mythic Dungeon",
    Heroic      = "Heroic Dungeon",
    Dungeon     = "Normal Dungeon",
    Timewalking = "Timewalking",
    Delves      = "Delves",
    Party       = "Party (World)",
    Solo        = "Solo (World)",
    Scenario    = "Scenario",
}

-- Fallback chains: each context key maps to an ordered array of fallback
-- keys to check before defaultVersion. Table-driven cascade logic.
D.CONTEXT_FALLBACKS = {
    RaidMythic = { "RaidHeroic", "RaidLFR", "Raid" },
    RaidHeroic = { "RaidLFR", "Raid" },
    RaidLFR    = { "Raid" },
    Arena      = { "PVP" },
    MythicPlus = { "Mythic", "Heroic", "Dungeon" },
    Mythic     = { "Heroic", "Dungeon" },
    Heroic     = { "Dungeon" },
    Delves     = { "Scenario" },
}

-- Context groups for the Context tab UI (T2-1b)
D.CONTEXT_GROUPS = {
    { name = "Raids",    keys = { "Raid", "RaidLFR", "RaidHeroic", "RaidMythic" } },
    { name = "Dungeons", keys = { "Dungeon", "Heroic", "Mythic", "MythicPlus" } },
    { name = "PvP",      keys = { "Arena", "PVP" } },
    { name = "Other",    keys = { "Timewalking", "Delves", "Party", "Solo", "Scenario" } },
}

-- Map difficultyID to context key (used for instanceType "party" and "raid")
D.DIFFICULTY_CONTEXT = {
    -- Party difficulties
    [1]   = "Dungeon",
    [2]   = "Heroic",
    [8]   = "MythicPlus",
    [23]  = "Mythic",
    [24]  = "Timewalking",
    [150] = "Dungeon",
    [205] = "Dungeon",
    -- Raid difficulties
    [14]  = "Raid",
    [15]  = "RaidHeroic",
    [16]  = "RaidMythic",
    [17]  = "RaidLFR",
    [33]  = "Timewalking",
    [151] = "RaidLFR",
    -- Legacy raid difficulties
    [3]  = "Raid",
    [4]  = "Raid",
    [5]  = "RaidHeroic",
    [6]  = "RaidHeroic",
    [7]  = "RaidLFR",
    [9]  = "Raid",
}

-- Map instanceType string to context key (types that do NOT need difficultyID)
D.INSTANCE_TYPE_CONTEXT = {
    arena = "Arena",
    pvp   = "PVP",
}

-- Version template (per-version fields: steps, stepFunction, reset conditions)
D.NewVersion = {
    stepFunction = "Sequential",
    steps = {},
    resetOnCombat = false,
    resetOnTarget = false,
    resetOnGear = false,
    resetOnSpec = false,
    resetTimer = 0,
}

-- Test sequence for /gems create (verifies engine with harmless /say commands)
D.TestSequence = {
    name = "TestSeq",
    icon = D.QUESTION_MARK_ICON,
    defaultVersion = 1,
    versions = {
        [1] = {
            stepFunction = "Sequential",
            resetOnCombat = true,
            resetOnTarget = false,
            resetOnGear = false,
            resetOnSpec = false,
            resetTimer = 0,
            steps = {
                "/say GRIP-EMS Step 1",
                "/say GRIP-EMS Step 2",
                "/say GRIP-EMS Step 3",
            },
        },
    },
}

-- Import/Export format constants
D.GSE3_PREFIX = "!GSE3!"         -- 6-char prefix for legacy encoded strings
D.GRIP1_PREFIX = "!GRIP1!"       -- 7-char prefix for GRIP-EMS native encoded strings
D.GRIP_FORMAT_VERSION = 3        -- v3: locale-safe export (spell ID tags)

-- UI frame defaults (Phase 3A)
D.MAIN_FRAME_WIDTH = 800
D.MAIN_FRAME_HEIGHT = 500
D.MAIN_FRAME_MIN_WIDTH = 600
D.MAIN_FRAME_MIN_HEIGHT = 400
D.LEFT_PANEL_WIDTH = 280
D.LEFT_PANEL_MIN_WIDTH = 180
D.LEFT_PANEL_MAX_WIDTH = 400
D.TITLE_BAR_HEIGHT = 40
D.ROW_HEIGHT = 32

-- UI list/editor constants (Phase 3A-2)
D.SEARCH_BOX_HEIGHT = 28
D.BUTTON_BAR_HEIGHT = 36
D.TAB_HEIGHT = 28
D.STEP_ROW_HEIGHT = 24
D.EDITOR_HEADER_HEIGHT = 100
D.CHAR_COUNT_WARNING = 800        -- yellow threshold for step char count
D.CHAR_COUNT_DANGER = D.MAX_SAB_MACROTEXT_LENGTH  -- red threshold (SAB macrotext limit: 1023)

-- Phase 3B-1 constants
D.STEP_ACTION_BAR_HEIGHT = 30
D.STEP_EDIT_HEIGHT_MIN = 40
D.STEP_EDIT_HEIGHT_MAX = 80
D.STEP_BUTTON_WIDTH = 50
D.STEP_BUTTON_HEIGHT = 24
D.NAME_EDITBOX_HEIGHT = 22

-- Phase 3B-2 constants
D.KEYBIND_DISPLAY_FONT_SIZE = 16
D.KEY_CAPTURE_BUTTON_WIDTH = 120
D.KEY_CAPTURE_BUTTON_HEIGHT = 28
D.SPEC_ROW_HEIGHT = 26
D.PRIORITY_PREVIEW_HEIGHT = 80
D.STUB_ROW_HEIGHT = 20
D.MACROS_TAB_MAX_STUBS = 30

-- Phase 3C-1 constants
D.AUTOCOMPLETE_MIN_CHARS = 2      -- minimum prefix length for macro commands (/ or #)
D.AUTOCOMPLETE_MIN_SPELL_CHARS = 1 -- minimum prefix length for spell names
D.AUTOCOMPLETE_MAX_RESULTS = 10   -- max suggestions to show in popup
D.SPELL_CACHE_DEBOUNCE = 0.5      -- seconds to debounce spell cache refresh

-- Phase 3C-3 constants (Variable System)
D.VAR_PATTERN = "~(%w+)~"        -- pattern to match variable references in macrotext
D.VAR_MAX_NAME = 32              -- max variable name length
D.VAR_MAX_FUNC = 1024            -- max function body length
D.VAR_EVAL_TIMEOUT = 0.05        -- max eval time before warning (logged, not enforced)
D.VAR_CONSOLIDATION = 0.1        -- event consolidation timer seconds

-- Phase 3C-3b constants (Variables Tab UI)
D.VAR_LIST_WIDTH = 200             -- variable list panel width
D.VAR_EDITOR_ROW_HEIGHT = 24      -- row height in variable list
D.VAR_FUNC_EDIT_HEIGHT = 120      -- function editor height

-- Phase 3C-2 constants (Icon Picker)
D.ICON_PICKER_WIDTH = 320
D.ICON_PICKER_HEIGHT = 380
D.ICON_GRID_COLS = 8
D.ICON_GRID_SIZE = 32
D.ICON_GRID_GAP = 4

-- Raw tab constants
D.RAW_HEADER_HEIGHT = 28
D.RAW_STATUS_HEIGHT = 18

-- Import preview picker constants (T2-4)
D.IMPORT_PICKER_WIDTH = 550
D.IMPORT_PICKER_HEIGHT = 500
D.IMPORT_PICKER_ROW_HEIGHT = 28

-- Export preview picker constants (T2-12)
D.EXPORT_PICKER_WIDTH = 550
D.EXPORT_PICKER_HEIGHT = 500
D.EXPORT_PICKER_ROW_HEIGHT = 28

-- Transmission constants (T2-9)
D.COMM_PREFIX = "GRIPEMS"                    -- max 16 chars
D.CMD_TRANSMIT = "GEMS_TRANSMIT"             -- send sequence(s)
D.CMD_REQUEST = "GEMS_REQUEST"               -- request a sequence
D.CMD_VERSION = "GEMS_VERSION"               -- version check
D.COMM_LINK_PREFIX = "GRIPEMS"               -- for chat hyperlinks
D.COMM_MAX_PENDING = 10                      -- max pending incoming

-- Debug window constants
D.DEBUG_WINDOW_WIDTH = 500
D.DEBUG_WINDOW_HEIGHT = 300

-- Empty sequence template (used when creating new sequences via UI in Phase 3)
D.NewSequence = {
    name = "",
    icon = D.QUESTION_MARK_ICON,
    defaultVersion = 1,
    contextOverrides = {},
    versions = {
        [1] = {
            stepFunction = "Sequential",
            steps = {},
            resetOnCombat = false,
            resetOnTarget = false,
            resetOnGear = false,
            resetOnSpec = false,
            resetTimer = 0,
        },
    },
}
