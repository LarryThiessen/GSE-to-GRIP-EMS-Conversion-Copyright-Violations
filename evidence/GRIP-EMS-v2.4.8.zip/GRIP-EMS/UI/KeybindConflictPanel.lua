-- GRIP-EMS: Keybind Conflict Panel
-- Created: 2026-08-11
-- Updated: 2026-08-25 (Patch header swept to build 12.1.0.69273; 2026-08-12 Phase 4: resolution actions, revalidating undo)
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.
--
-- The first consumer of Engine/KeybindConflict.lua. It renders what that module
-- found across the five layers a key can be taken on, plus the best-effort addon
-- attribution, plus an honest block naming what the check cannot see.
--
-- STRUCTURE MIRRORS UI/RepairFrame.lua deliberately: lazy construction, the same
-- ReclaimFrame and RegisterPanelFrame calls, the same title bar, the same
-- severity filter chips, the same WowScrollBoxList, the same Focus context
-- lifecycle. Same severity scale too -- UI.SEVERITY_COLORS and friends now live
-- in UI/Util.lua so both panels grade on one scale rather than two.
--
-- THREE DELIBERATE DIFFERENCES:
--   * A row's Fix button is enabled exactly when KCH.BuildFixPlan can build a
--     plan for that row, and shown-but-disabled otherwise with the manual
--     instruction on its tooltip. Phase 3 shipped every one of them disabled and
--     promised that Phase 4 would enable them and move nothing; that held, and
--     the layout is unchanged. A row with no supported fix -- every override-layer
--     row, because there is no way to clear another addon's override binding --
--     keeps the disabled button and the honest tooltip.
--   * THIS PANEL MUTATES GLOBAL CLIENT STATE, and it carries a REVALIDATING
--     revert list rather than GRIPEMS.UndoStack. UndoStack:Push executes its
--     undoFn blind, which is exactly right for RepairFrame because RF._seqData is
--     a table only EMS writes, and exactly wrong here: the binding registry is
--     written by the user, by the client's own Key Bindings panel and by every
--     other addon in the gap between the fix and the undo. So every revert is
--     re-checked against the live world through KCH.RevertMatchesObservedState
--     immediately before it runs, and refuses rather than overwriting whatever
--     claimed the key in the meantime. There is deliberately no Redo: redoing a
--     fix is pressing Fix again, and a redo stack would be a second surface
--     holding state the world can invalidate underneath it.
--   * A probe row: type any key, see what owns it. It shows the CANONICAL form
--     next to what was typed, because CanonicalizeKey reorders modifiers and the
--     user has to be able to see the string that was actually queried.
--
-- All presentation logic that can run without a client lives in
-- Engine/KeybindConflictHelper.lua and is covered by
-- Test/test_keybind_conflict_panel.lua. This file is the part that cannot be
-- tested headless, so it is kept as thin as the rendering allows.

local _, GRIPEMS = ...
GRIPEMS.KeybindConflictPanel = {}
local KCP = GRIPEMS.KeybindConflictPanel
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

local UI, KC, KCH
local function ResolveDeps()
    if UI then
        return
    end
    UI = GRIPEMS.UI
    KC = GRIPEMS.KeybindConflict
    KCH = GRIPEMS.KeybindConflictHelper
end

local ROW_HEIGHT = 28

-- The shared scale, read off GRIPEMS.UI rather than the file-local UI for the
-- same reason RepairFrame does: the local is nil until ResolveDeps runs.
local SEV_COLORS = GRIPEMS.UI.SEVERITY_COLORS
local SEV_LABELS = GRIPEMS.UI.SEVERITY_LABELS
local SEV_ORDER = GRIPEMS.UI.SEVERITY_ORDER

local scrollBox, dataProvider
local summaryLabel, probeBox, probeResultLabel, contextLabel, undoBtn

-- Per-row fix status, keyed by KCH.RowIdentity and NEVER reset by Rebuild.
-- A fix is followed immediately by a rebuild, so a status keyed by table
-- reference -- or cleared on rebuild -- would vanish in the same frame it was
-- set, and the button would report nothing at all. Keying by identity is the
-- whole reason KCH.RowIdentity exists.
local fixStatus = {}

-- The revert list, used as a LIFO stack. Each entry is
-- { revert = <from KCH.BuildRevertPlan>, identity = <row identity>, key = <key> }.
-- See the header for why this is not GRIPEMS.UndoStack.
local revertStack = {}

local function SevColor(sev)
    local c = SEV_COLORS[sev] or SEV_COLORS.info
    return c[1], c[2], c[3]
end

-- Fix All confirmation.
--
-- GRIPEMS.Popup AND NEVER _G.StaticPopupDialogs. Writing to that global taints
-- the table for every Blizzard read of it, which is the entire reason
-- Core/Popup.lua exists.
--
-- OnAccept reads the pending list off KCP rather than being redefined per show,
-- so the definition stays static and there is exactly one place that decides what
-- Fix All actually does. The button itself NEVER writes -- only this OnAccept
-- does, which is what makes the confirmation a real gate rather than decoration.
GRIPEMS.Popup:Define("GRIPEMS_KC_FIX_ALL", {
    text = "%s",
    button1 = ACCEPT,
    button2 = CANCEL,
    OnAccept = function()
        local pending = GRIPEMS.KeybindConflictPanel._pendingFixAll
        GRIPEMS.KeybindConflictPanel._pendingFixAll = nil
        if type(pending) ~= "table" then
            return
        end
        for _, row in ipairs(pending) do
            GRIPEMS.KeybindConflictPanel:ApplyFix(row)
        end
    end,
    timeout = 0,
    hideOnEscape = true,
})

--- Locale lookup that never renders blank. A missing key shows the key itself,
--- which is ugly and diagnosable; a blank row reads as "nothing found", which is
--- the one thing this panel must never say by accident.
local function Copy(key, ...)
    if type(key) ~= "string" or key == "" then
        return ""
    end
    local text = L[key]
    if type(text) ~= "string" or text == "" then
        return key
    end
    if select("#", ...) > 0 then
        local ok, formatted = pcall(string.format, text, ...)
        if ok then
            return formatted
        end
    end
    return text
end

-- ===========================================================================
-- Gathering the keys to check
-- ===========================================================================

--- Every bound sequence key for the current spec, from the same per-spec table
--- UI/KeybindTab.lua reads. Guarded at every step: a missing table is a section
--- with no entries, never an error.
local function CollectSequenceEntries(entries)
    local char = _G.GRIP_EMS_CHAR
    if type(char) ~= "table" or type(char.keybinds) ~= "table" then
        return
    end
    local specIndex = GetSpecialization and GetSpecialization() or nil
    local binds = specIndex and char.keybinds[specIndex] or nil
    if type(binds) ~= "table" then
        return
    end
    local KM = GRIPEMS.KeybindManager
    local resolved = binds
    if KM and KM._ResolveFinalKeybinds then
        local loadoutID = KM.GetActiveLoadoutID and KM:GetActiveLoadoutID() or nil
        local ok, final = pcall(KM._ResolveFinalKeybinds, KM, binds, loadoutID)
        if ok and type(final) == "table" then
            resolved = final
        end
    end
    for key, seqName in pairs(resolved) do
        if type(key) == "string" and type(seqName) == "string" and key ~= "_byLoadout" then
            entries[#entries + 1] = {
                family = "sequence",
                label = seqName,
                key = key,
                seqName = seqName,
            }
        end
    end
end

--- Vehicle and pet-battle keys, read through the same accessors KeybindTab uses.
--- A module that is not loaded is a skipped section.
local function CollectSlotEntries(entries, moduleName, family)
    local module = GRIPEMS[moduleName]
    if type(module) ~= "table" or type(module.GetKeybind) ~= "function" then
        return
    end
    for slot = 1, 12 do
        local ok, key = pcall(module.GetKeybind, module, slot)
        if ok and type(key) == "string" and key ~= "" then
            entries[#entries + 1] = {
                family = family,
                label = tostring(slot),
                key = key,
            }
        end
    end
end

local function BuildEntries()
    local entries = {}
    CollectSequenceEntries(entries)
    CollectSlotEntries(entries, "VehicleKeybinds", "vehicle")
    CollectSlotEntries(entries, "PetBattleButtons", "petbattle")
    if KCP._probeKey and KCP._probeKey ~= "" then
        entries[#entries + 1] = {
            family = "probe",
            label = KCP._probeKey,
            key = KCP._probeKey,
        }
    end
    return entries
end

-- ===========================================================================
-- Rows
-- ===========================================================================

--- The text one row shows. Row kinds differ enough that a single format string
--- would be worse than a short branch.
local function RowText(row)
    if row.kind == "verdict" then
        return (row.label or "") .. "  " .. (row.key or "") .. "  -  " .. Copy(row.copyKey)
    elseif row.kind == "layer" then
        local text = "    " .. Copy(row.copyKey) .. ": " .. Copy(row.statusCopyKey)
        if row.action and row.action ~= "" then
            text = text .. "  " .. Copy("GEMS_KC_ROW_LAYER_ACTION", row.action)
        end
        return text
    elseif row.kind == "note" then
        return "    " .. Copy(row.copyKey)
    elseif row.kind == "attribution" then
        if row.cleared then
            return "    " .. Copy("GEMS_KC_ROW_ATTRIBUTION_RELEASED", row.addon or "?")
        end
        if row.addon and row.file and row.line then
            return "    " .. Copy("GEMS_KC_ROW_ATTRIBUTION", row.addon, row.file, row.line)
        end
        return "    " .. Copy("GEMS_KC_ROW_ATTRIBUTION_UNNAMED")
    elseif row.kind == "invalid" then
        return (row.rawKey or "") .. "  -  " .. Copy(row.copyKey)
    elseif row.kind == "section" then
        return Copy(row.copyKey)
    end
    return Copy(row.copyKey)
end

local function InitRow(btn, row)
    local C = UI.Colors
    if not btn._built then
        btn._built = true
        btn:SetHeight(ROW_HEIGHT)
        -- A BACKGROUND texture, exactly as RepairFrame's InitRow does it, and NOT
        -- UI:ApplyBackdrop with a palette colour.
        --
        -- THE TRAP THIS REPLACES, because it cost a whole unreadable panel: this
        -- line read ApplyBackdrop(..., C.bgRow), and bgRow is not in the palette.
        -- Indexing a missing key is legal Lua and yields nil, and ApplyBackdrop
        -- applies the backdrop UNCONDITIONALLY while only tinting when the colour
        -- is truthy -- so every row painted untinted WHITE under near-white text
        -- and nothing anywhere reported a fault. Test/test_ui_palette_keys.lua is
        -- now the gate for that whole class.
        local bg = btn:CreateTexture(nil, "BACKGROUND")
        bg:SetAllPoints()
        bg:SetColorTexture(0, 0, 0, 0)
        btn._bg = bg
        btn.sev = btn:CreateFontString(nil, "OVERLAY")
        UI:SetFont(btn.sev, 10, "OUTLINE")
        btn.sev:SetPoint("LEFT", 6, 0)
        btn.sev:SetWidth(40)
        btn.sev:SetJustifyH("LEFT")
        btn.text = btn:CreateFontString(nil, "OVERLAY")
        UI:SetFont(btn.text, 11)
        btn.text:SetPoint("LEFT", btn.sev, "RIGHT", 4, 0)
        btn.text:SetPoint("RIGHT", -76, 0)
        btn.text:SetJustifyH("LEFT")
        btn.text:SetWordWrap(false)

        -- SHOWN AND DISABLED, always. See the header: Phase 4 enables this and
        -- moves nothing.
        btn.fix = UI:CreateButton(btn, Copy("GEMS_KC_FIX_BUTTON"), 64, 20)
        btn.fix:SetPoint("RIGHT", -6, 0)
        btn.fix:SetAlpha(0.35)
        -- BEFORE Disable(), and it is the only reason the tooltip below is
        -- reachable at all. A disabled WoW Button does not fire OnEnter or OnLeave
        -- unless motion scripts are explicitly enabled on it, and every Fix button
        -- in this panel is disabled by design until Phase 4 -- so without this
        -- line the manual instruction, which is the entire value the column
        -- delivers today, could never be seen.
        btn.fix:SetMotionScriptsWhileDisabled(true)
        btn.fix:Disable()
    end

    local sev = row.severity or "info"
    btn.sev:SetText(SEV_LABELS[sev] or "")
    btn.sev:SetTextColor(SevColor(sev))
    btn.text:SetText(RowText(row))

    -- Three states, the same three RepairFrame uses: a section row is bgDeep, an
    -- ordinary row is transparent, and hover is bgRowHover over whichever of those
    -- the row started from. Reset first, because the ScrollBox reuses frames and a
    -- recycled section row would otherwise keep its header tint.
    local baseColor = nil
    if row.kind == "section" then
        baseColor = C.bgDeep
        btn._bg:SetColorTexture(C.bgDeep:GetRGBA())
        btn.text:SetTextColor(C.gripGreen:GetRGBA())
        btn.sev:SetText("")
    else
        btn._bg:SetColorTexture(0, 0, 0, 0)
        btn.text:SetTextColor(C.textPrimary:GetRGBA())
    end
    btn:SetScript("OnEnter", function(self)
        self._bg:SetColorTexture(C.bgRowHover:GetRGBA())
    end)
    btn:SetScript("OnLeave", function(self)
        if baseColor then
            self._bg:SetColorTexture(baseColor:GetRGBA())
        else
            self._bg:SetColorTexture(0, 0, 0, 0)
        end
    end)

    -- The status of a fix already attempted on this row, appended to the row text
    -- rather than put in the severity column: the column is 40 pixels and holds a
    -- four-character badge, while these are sentences. The text region already
    -- stops 76 pixels short of the right edge for the Fix button, so appending
    -- here cannot reach under it.
    local identity = KCH.RowIdentity(row)
    local status = identity and fixStatus[identity] or nil
    if status then
        btn.text:SetText(RowText(row) .. "   -- " .. Copy(status.copyKey, status.arg))
    end

    -- The tooltip is the whole point of a disabled button: it is where the manual
    -- instruction lives. A row with no manual fix says so rather than promising
    -- something no addon can do.
    local manualKey = KCH.ManualFixKeyFor(row)
    local plan = KCH.BuildFixPlan(row)

    -- THE BUTTON IS SHOWN ONLY WHERE IT HAS SOMETHING TRUE TO SAY, which is a
    -- narrowing of the earlier "every row except a section header". The disabled
    -- button's tooltip is a universal negative -- there is no supported way to
    -- take this key back -- and on a NOTE row that sentence contradicted the
    -- ENABLED Fix sitting one row above it on the same finding. The decision is
    -- KCH.FixButtonStateFor so a headless case can hold it; see CASE 7.
    local buttonState = KCH.FixButtonStateFor(row)
    btn.fix:SetShown(buttonState ~= KCH.FIX_BUTTON_STATES.none)

    -- BOTH STATES SET EXPLICITLY ON EVERY PASS, never just the one this row
    -- needs. The ScrollBox RECYCLES row frames, so a button left enabled from a
    -- fixable row would stay enabled while rendering an override row and fire
    -- KCP:ApplyFix against whatever row it is showing now.
    if plan then
        btn.fix:Enable()
        btn.fix:SetAlpha(1.0)
        btn.fix:SetScript("OnClick", function()
            KCP:ApplyFix(row)
        end)
    else
        btn.fix:Disable()
        btn.fix:SetAlpha(0.35)
        btn.fix:SetScript("OnClick", nil)
    end

    btn.fix:SetScript("OnEnter", function(self)
        if manualKey then
            UI:ShowTooltip(self, Copy("GEMS_KC_FIX_BUTTON"), Copy(manualKey))
        else
            UI:ShowTooltip(self, Copy("GEMS_KC_FIX_BUTTON"), Copy("GEMS_KC_FIX_UNAVAILABLE_TOOLTIP"))
        end
    end)
    btn.fix:SetScript("OnLeave", function()
        UI:HideTooltip()
    end)
end

-- ===========================================================================
-- Resolution
-- ===========================================================================
--
-- The panel's whole share of the fix is: read the live world, hand it to a pure
-- predicate, and perform the writes the pure planner described. Every decision --
-- what to write, whether it is still safe, what the inverse is -- is in
-- Engine/KeybindConflictHelper.lua where a headless test can reach it.

--- Build the observed table the pure predicates take. THE ONLY PLACE IN THIS FILE
--- THAT READS LIVE BINDING STATE.
---
--- Every call is pcall'd and a raised call yields a MISSING field, which the
--- predicates treat as a mismatch. That direction is deliberate: a read that blew
--- up has told us nothing, and "we could not look" must never be worth the same
--- as "we looked and it matched".
local function ReadObserved(plan)
    local observed = { modifierValues = {} }
    if type(plan) ~= "table" then
        return observed
    end
    if plan.kind == KCH.FIX_KINDS.base then
        local ok, action = pcall(GetBindingAction, plan.key, false)
        if ok and type(action) == "string" then
            observed.baseAction = action
        end
    elseif plan.kind == KCH.FIX_KINDS.modifier then
        for _, entry in ipairs(plan.actions or {}) do
            local ok, value = pcall(GetModifiedClick, entry.action)
            if ok and type(value) == "string" then
                observed.modifierValues[entry.action] = value
            end
        end
    end
    return observed
end

--- Perform the writes a plan describes.
---
--- SetBinding(key) with NO second argument unbinds every binding from the key,
--- and the third argument is deliberately omitted: mode is 1 for the loaded set
--- and 2 for the alternative one, which is NOT the binding-set constant
--- GetCurrentBindingSet returns. Passing GetCurrentBindingSet() there writes to
--- the wrong set on any character using per-character bindings. Omitting it
--- defaults to the loaded set, which is the one the user is looking at.
---
--- SaveBindings DOES take the binding-set constant, so SaveBindings(GetCurrentBindingSet())
--- is correct there -- it is what Blizzard_ClickBindingUI.lua itself calls.
---
--- SetBinding returns 1 on success and nil on failure, and a failed SetBinding
--- must not be followed by a SaveBindings: persisting after a write that did not
--- happen would write the OLD state back to disk as though it were intended.
--- @return boolean ok, string|nil err
local function ApplyPlan(plan)
    if plan.kind == KCH.FIX_KINDS.base then
        local ok, result = pcall(SetBinding, plan.key)
        if not ok then
            return false, tostring(result)
        end
        if not result then
            return false, "SetBinding returned nil"
        end
        pcall(SaveBindings, GetCurrentBindingSet())
        return true
    elseif plan.kind == KCH.FIX_KINDS.modifier then
        for _, entry in ipairs(plan.actions or {}) do
            local ok, err = pcall(SetModifiedClick, entry.action, "NONE")
            if not ok then
                return false, tostring(err)
            end
        end
        -- ONE SaveBindings after the whole loop, not one per action. Each call
        -- fires UPDATE_BINDINGS and the panel rebuilds on it.
        pcall(SaveBindings, GetCurrentBindingSet())
        return true
    end
    return false, "unknown plan kind"
end

--- The inverse writes. Mirrors ApplyPlan exactly, including the omitted mode
--- argument on SetBinding.
--- @return boolean ok, string|nil err
local function ApplyRevert(revert)
    if revert.kind == KCH.FIX_KINDS.base then
        local ok, result = pcall(SetBinding, revert.key, revert.restore)
        if not ok then
            return false, tostring(result)
        end
        if not result then
            return false, "SetBinding returned nil"
        end
        pcall(SaveBindings, GetCurrentBindingSet())
        return true
    elseif revert.kind == KCH.FIX_KINDS.modifier then
        for _, entry in ipairs(revert.actions or {}) do
            local ok, err = pcall(SetModifiedClick, entry.action, entry.restore)
            if not ok then
                return false, tostring(err)
            end
        end
        pcall(SaveBindings, GetCurrentBindingSet())
        return true
    end
    return false, "unknown revert kind"
end

--- Record a status against a row identity, for the button to render.
local function SetRowStatus(identity, copyKey, arg)
    if identity then
        fixStatus[identity] = { copyKey = copyKey, arg = arg }
    end
end

--- Push a revert, keeping at most ONE entry per key.
---
--- The list operation itself is KCH.PushRevertEntry, which is where it can be
--- tested without a client. This wrapper only guards the shape.
local function PushRevert(entry)
    if type(entry) ~= "table" or entry.revert == nil then
        return
    end
    KCH.PushRevertEntry(revertStack, entry)
end

--- Apply the fix for one row.
---
--- THE ORDER MATTERS AND EVERY STEP IN IT IS LOAD BEARING:
---   1. build the plan; a row with no plan is not fixable and we stop;
---   2. RE-READ the world and re-check the plan against it, because the panel may
---      have rendered minutes ago;
---   3. out of combat, write inline and record the revert;
---   4. in combat, mark the row queued FIRST so the button answers immediately,
---      then hand a closure to OOCQueue.
function KCP:ApplyFix(row)
    ResolveDeps()
    local plan = KCH.BuildFixPlan(row)
    if plan == nil then
        return
    end
    local identity = KCH.RowIdentity(row)

    local ok, reject = KCH.PlanMatchesObservedState(plan, ReadObserved(plan))
    if not ok then
        -- The world moved between the render and the click. Say which key, and
        -- write NOTHING.
        SetRowStatus(identity, KCH.CopyKeyFor("planReject", reject), plan.key)
        self:Rebuild()
        return
    end

    local queue = GRIPEMS.OOCQueue
    if not queue or not queue:IsRestricted() then
        local applied, err = ApplyPlan(plan)
        if applied then
            local revert = KCH.BuildRevertPlan(plan)
            if revert then
                PushRevert({ revert = revert, identity = identity, key = plan.key })
            end
            SetRowStatus(identity, "GEMS_KC_FIX_APPLIED")
        else
            GRIPEMS:Debug("keybind fix failed: " .. tostring(err))
            SetRowStatus(identity, "GEMS_KC_FIX_FAILED")
        end
        self:Rebuild()
        return
    end

    -- QUEUED, AND THE QUEUED STATE HAS TWO DIFFERENT TRUTHS. OOCQueue:Process
    -- skips every AUTOMATIC drain while autoReloadAtCombatEnd is false, so on
    -- those characters this does NOT apply when combat ends -- it waits for a
    -- manual drain. One queued message would be a lie on one of the two paths.
    local S = GRIPEMS.Settings
    local autoDrains = not (S and S:Get("autoReloadAtCombatEnd") == false)
    SetRowStatus(identity, autoDrains and "GEMS_KC_FIX_QUEUED" or "GEMS_KC_FIX_QUEUED_MANUAL")
    self:Rebuild()

    -- THE QUEUED CLOSURE RE-VALIDATES, and it is not optional. A fight lasts
    -- minutes and the user can rebind the key from the client's own panel during
    -- it. Same predicate as the inline path above -- deliberately not a second
    -- copy of the comparison.
    queue:Add(function()
        local stillOk, lateReject = KCH.PlanMatchesObservedState(plan, ReadObserved(plan))
        if not stillOk then
            SetRowStatus(identity, KCH.CopyKeyFor("planReject", lateReject), plan.key)
            if KCP.frame and KCP.frame:IsShown() then
                KCP:Rebuild()
            end
            return
        end
        local applied, err = ApplyPlan(plan)
        if applied then
            local revert = KCH.BuildRevertPlan(plan)
            if revert then
                PushRevert({ revert = revert, identity = identity, key = plan.key })
            end
            SetRowStatus(identity, "GEMS_KC_FIX_APPLIED")
        else
            GRIPEMS:Debug("keybind fix failed: " .. tostring(err))
            SetRowStatus(identity, "GEMS_KC_FIX_FAILED")
        end
        if KCP.frame and KCP.frame:IsShown() then
            KCP:Rebuild()
        end
        -- Dedup on (opType, key): two presses on one row during one fight collapse
        -- to a single write.
    end, GRIPEMS.Defaults.OOC_OP_KEYBINDFIX, plan.key)
end

--- Undo the most recent fix, or refuse and say why.
function KCP:UndoLast()
    ResolveDeps()
    if #revertStack == 0 then
        return
    end

    -- WALK DOWN, DO NOT JUST READ THE TOP.
    --
    -- Refusing without popping is right -- the revert becomes valid again the
    -- moment whatever claimed the key lets go, and discarding it would remove the
    -- user's only way back. But reading ONLY the top made that correctness
    -- expensive: one permanently-claimed key sat at the head and stranded every
    -- revert beneath it forever, with the Undo button lit and doing nothing. Fix
    -- two keys, rebind one of them by hand, and the other key's way back was gone.
    --
    -- Walking is safe here because PushRevert keeps keys UNIQUE, so no two entries
    -- describe the same key and skipping one can never reorder a pair that had to
    -- stay ordered. Each revert targets its own key and they do not compose.
    --
    -- The walk itself is KCH.SelectRevertIndex so a headless case can hold it; the
    -- live read stays here. Refusal reasons are captured per entry on the way past
    -- so every skipped entry is reported rather than silently stepped over.
    local rejects = {}
    local index, refused = KCH.SelectRevertIndex(revertStack, function(candidate)
        local ok, why = KCH.RevertMatchesObservedState(candidate.revert, ReadObserved(candidate.revert))
        if not ok then
            rejects[candidate] = why
        end
        return ok
    end)

    for _, refusedIndex in ipairs(refused) do
        local candidate = revertStack[refusedIndex]
        GRIPEMS:Print(Copy("GEMS_KC_UNDO_REFUSED", candidate.key or "?"))
        SetRowStatus(candidate.identity, KCH.CopyKeyFor("planReject", rejects[candidate]), candidate.key)
    end

    if not index then
        -- Nothing on the stack can be applied right now. Every entry stays put,
        -- because every one of them becomes valid again if its key is released.
        self:Rebuild()
        return
    end

    local entry = revertStack[index]
    table.remove(revertStack, index)
    local applied, err = ApplyRevert(entry.revert)
    if not applied then
        GRIPEMS:Debug("keybind undo failed: " .. tostring(err))
        SetRowStatus(entry.identity, "GEMS_KC_FIX_FAILED")
    elseif entry.identity then
        fixStatus[entry.identity] = nil
    end
    self:Rebuild()
end

-- ===========================================================================
-- Refresh
-- ===========================================================================

local function RefreshDataProvider()
    if not dataProvider then
        return
    end
    dataProvider:Flush()
    local report = KCP._report
    if not report then
        return
    end
    for _, section in ipairs(report.sections) do
        dataProvider:Insert({
            kind = "section",
            copyKey = section.copyKey,
            severity = nil,
        })
        for _, row in ipairs(section.rows) do
            if row.severity == nil or KCP._sevFilter[row.severity] then
                dataProvider:Insert(row)
            end
        end
    end
end

--- Every row in the current report that KCH can build a plan for.
---
--- Read off the REPORT rather than off the ScrollBox: the scroll box only holds
--- the rows currently materialised plus whatever the severity chips let through,
--- and "Fix All" over the visible subset would silently do less than it says.
--- @return table Array of rows
function KCP:CollectPlannableRows()
    local out = {}
    local report = self._report
    if not report or type(report.rows) ~= "table" or not KCH then
        return out
    end
    for _, row in ipairs(report.rows) do
        if KCH.BuildFixPlan(row) ~= nil then
            out[#out + 1] = row
        end
    end
    return out
end

--- Rebuild everything: gather the keys, run them through the helper, repaint.
function KCP:Rebuild()
    ResolveDeps()
    if not KC or not KCH then
        return
    end
    self._report = KCH.BuildReport(BuildEntries())
    if not self.frame then
        return
    end

    local counts = self._report.counts
    summaryLabel:SetText(
        string.format(
            "%s %d   %s %d   %s %d   %s %d",
            SEV_LABELS.critical,
            counts.critical,
            SEV_LABELS.error,
            counts.error,
            SEV_LABELS.warning,
            counts.warning,
            SEV_LABELS.info,
            counts.info
        )
    )
    if #self._report.rows == 0 then
        summaryLabel:SetText(Copy("GEMS_KC_NO_FINDINGS"))
    end

    -- The context block, in the order the brief fixed: limits, then unloaded
    -- addons, then any capability that could not be read. All three are shown
    -- whenever they apply, not only when something is wrong, because a panel that
    -- lists nothing reads as a panel that saw everything.
    local lines = { Copy("GEMS_KC_CONTEXT_HEADER") }
    for _, limit in ipairs(self._report.limits) do
        lines[#lines + 1] = "- " .. Copy(limit.copyKey)
    end
    if self._report.addons and self._report.addons.unloadedCount > 0 then
        lines[#lines + 1] = "- " .. Copy("GEMS_KC_ADDONS_UNLOADED", self._report.addons.unloadedCount)
    end
    local missing = {}
    for name, present in pairs(self._report.capabilities or {}) do
        if present == false then
            missing[#missing + 1] = name
        end
    end
    if #missing > 0 then
        table.sort(missing)
        lines[#lines + 1] = "- " .. Copy("GEMS_KC_CAPABILITY_MISSING", table.concat(missing, ", "))
    end
    contextLabel:SetText(table.concat(lines, "\n"))

    -- Both frame-level buttons are re-derived here rather than toggled at the
    -- point of change, so they can never disagree with the report on screen.
    local fixAllBtn = self.frame._fixAllBtn
    if fixAllBtn then
        if #self:CollectPlannableRows() > 0 then
            fixAllBtn:Enable()
            fixAllBtn:SetAlpha(1.0)
        else
            fixAllBtn:Disable()
            fixAllBtn:SetAlpha(0.35)
        end
    end
    if undoBtn then
        if #revertStack > 0 then
            undoBtn:Enable()
            undoBtn:SetAlpha(1.0)
        else
            undoBtn:Disable()
            undoBtn:SetAlpha(0.35)
        end
    end

    RefreshDataProvider()
end

-- ===========================================================================
-- Construction
-- ===========================================================================

local function CreatePanel()
    if KCP.frame then
        return
    end
    ResolveDeps()
    local C = UI.Colors

    local f = UI:ReclaimFrame("GRIPEMSKeybindConflictFrame", "Frame", UIParent, "BackdropTemplate")
    f:SetSize(680, 520)
    f:SetPoint("CENTER")
    f:SetFrameStrata("DIALOG")
    f:SetClampedToScreen(true)
    UI:ApplyBackdrop(f, UI.Backdrops.panel, C.bgMain, C.border)
    if GRIPEMS.UI and GRIPEMS.UI.RegisterPanelFrame then
        GRIPEMS.UI:RegisterPanelFrame(f, "panel", "panel.keybindConflict")
    end
    f:SetMovable(true)
    f:Hide()
    KCP.frame = f
    tinsert(UISpecialFrames, "GRIPEMSKeybindConflictFrame")

    -- Title bar
    local tb = CreateFrame("Frame", nil, f, "BackdropTemplate")
    tb:SetHeight(30)
    tb:SetPoint("TOPLEFT")
    tb:SetPoint("TOPRIGHT")
    UI:ApplyBackdrop(tb, UI.Backdrops.panelNoBorder, C.bgDeep)
    tb:EnableMouse(true)
    tb:RegisterForDrag("LeftButton")
    tb:SetScript("OnDragStart", function()
        f:StartMoving()
    end)
    tb:SetScript("OnDragStop", function()
        f:StopMovingOrSizing()
    end)

    local tt = tb:CreateFontString(nil, "OVERLAY")
    UI:SetFont(tt, 13, "OUTLINE")
    tt:SetPoint("LEFT", 12, 0)
    tt:SetText(Copy("GEMS_KC_TITLE"))
    tt:SetTextColor(C.gripGreen:GetRGBA())

    local xb = CreateFrame("Button", nil, tb, "BackdropTemplate")
    xb:SetSize(24, 24)
    UI:RegisterLargeTarget(xb)
    xb:SetPoint("TOPRIGHT", -6, -3)
    UI:ApplyBackdrop(xb, UI.Backdrops.panel, C.bgButton, C.border)
    local xl = xb:CreateFontString(nil, "OVERLAY")
    UI:SetFont(xl, 14)
    xl:SetPoint("CENTER", 0, 1)
    xl:SetText("X")
    xl:SetTextColor(C.textSecondary:GetRGBA())
    xb:SetScript("OnClick", function()
        KCP:Hide()
    end)
    xb:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.accent:GetRGBA())
        xl:SetTextColor(C.textPrimary:GetRGBA())
    end)
    xb:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgButton:GetRGBA())
        xl:SetTextColor(C.textSecondary:GetRGBA())
    end)
    f._titleCloseBtn = xb

    summaryLabel = f:CreateFontString(nil, "OVERLAY")
    UI:SetFont(summaryLabel, 12)
    summaryLabel:SetPoint("TOPLEFT", 12, -36)

    -- The probe row. The canonical form is shown next to the raw input because
    -- CanonicalizeKey reorders modifiers, and a user who typed SHIFT-ALT-Q needs
    -- to see that ALT-SHIFT-Q is what was actually queried.
    local probeLabel = f:CreateFontString(nil, "OVERLAY")
    UI:SetFont(probeLabel, 11)
    probeLabel:SetPoint("TOPLEFT", 12, -58)
    probeLabel:SetText(Copy("GEMS_KC_PROBE_LABEL"))

    probeBox = CreateFrame("EditBox", nil, f, "InputBoxTemplate")
    probeBox:SetSize(150, 20)
    probeBox:SetPoint("LEFT", probeLabel, "RIGHT", 8, 0)
    probeBox:SetAutoFocus(false)
    probeBox:SetScript("OnEnterPressed", function(self)
        local raw = self:GetText() or ""
        KCP._probeKey = raw
        local canonical = KC and KC.CanonicalizeKey(raw) or nil
        probeResultLabel:SetText(canonical and Copy("GEMS_KC_PROBE_CANONICAL", canonical) or "")
        self:ClearFocus()
        KCP:Rebuild()
    end)
    probeBox:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
    end)
    probeBox:SetScript("OnEnter", function(self)
        UI:ShowTooltip(self, Copy("GEMS_KC_PROBE_LABEL"), Copy("GEMS_KC_PROBE_HINT"))
    end)
    probeBox:SetScript("OnLeave", function()
        UI:HideTooltip()
    end)
    GRIPEMS.Focus:HookEditBox(probeBox)
    KCP.probeBox = probeBox

    probeResultLabel = f:CreateFontString(nil, "OVERLAY")
    UI:SetFont(probeResultLabel, 10)
    probeResultLabel:SetPoint("LEFT", probeBox, "RIGHT", 8, 0)
    probeResultLabel:SetTextColor(C.textSecondary:GetRGBA())

    -- Severity filter chips, same construction and same order as RepairFrame.
    -- No registry of the chip frames: unlike RepairFrame there is no filter
    -- reset here, so nothing would ever read it back.
    KCP._sevFilter = { critical = true, error = true, warning = true, info = true }
    local x = 8
    for _, sev in ipairs(SEV_ORDER) do
        local btn = UI:CreateButton(f, SEV_LABELS[sev], 60, 20)
        btn:SetPoint("TOPLEFT", f, "TOPLEFT", x, -84)
        local function RefreshChip()
            if KCP._sevFilter[sev] then
                btn.label:SetTextColor(SevColor(sev))
                UI:ApplyBackdrop(btn, UI.Backdrops.panel, C.bgButton, C.border)
            else
                btn.label:SetTextColor(C.textMuted:GetRGBA())
                UI:ApplyBackdrop(btn, UI.Backdrops.panel, C.bgDeep, C.border)
            end
        end
        btn:SetScript("OnClick", function()
            KCP._sevFilter[sev] = not KCP._sevFilter[sev]
            RefreshChip()
            RefreshDataProvider()
        end)
        btn:SetScript("OnEnter", function(self)
            UI:ShowTooltip(self, SEV_LABELS[sev], Copy(KCH.CopyKeyFor("severity", sev)))
        end)
        btn:SetScript("OnLeave", function()
            UI:HideTooltip()
            RefreshChip()
        end)
        RefreshChip()
        x = x + 66
    end

    local closeBtn = UI:CreateButton(f, Copy("GEMS_KC_REFRESH"), 90, 26)
    closeBtn:SetPoint("BOTTOMRIGHT", -10, 10)
    closeBtn:SetScript("OnClick", function()
        KCP:Rebuild()
    end)
    f._refreshBtn = closeBtn

    -- Fix All. Enabled by Rebuild whenever at least one rendered row has a plan.
    local fixAllBtn = UI:CreateButton(f, Copy("GEMS_KC_FIX_ALL_BUTTON"), 90, 26)
    fixAllBtn:SetPoint("RIGHT", closeBtn, "LEFT", -8, 0)
    fixAllBtn:SetAlpha(0.35)
    -- Still needed even now that the button can be enabled: it spends most of its
    -- life disabled, and a disabled Button fires no motion scripts, so without
    -- this the tooltip explaining WHY it is disabled never appears and the button
    -- reads as simply broken.
    fixAllBtn:SetMotionScriptsWhileDisabled(true)
    fixAllBtn:Disable()
    fixAllBtn:SetScript("OnClick", function()
        -- THIS DOES NOT WRITE. It stages the list and asks. Only the popup's
        -- OnAccept iterates it, and the copy names the exact count so the user is
        -- agreeing to a number rather than to a word.
        local pending = KCP:CollectPlannableRows()
        if #pending == 0 then
            return
        end
        KCP._pendingFixAll = pending
        GRIPEMS.Popup:Show("GRIPEMS_KC_FIX_ALL", Copy("GEMS_KC_FIX_ALL_CONFIRM_BODY", #pending))
    end)
    fixAllBtn:SetScript("OnEnter", function(self)
        if self:IsEnabled() then
            UI:ShowTooltip(self, Copy("GEMS_KC_FIX_ALL_BUTTON"), Copy("GEMS_KC_FIX_ALL_TOOLTIP"))
        else
            UI:ShowTooltip(self, Copy("GEMS_KC_FIX_ALL_BUTTON"), Copy("GEMS_KC_FIX_ALL_NONE_TOOLTIP"))
        end
    end)
    fixAllBtn:SetScript("OnLeave", function()
        UI:HideTooltip()
    end)
    f._fixAllBtn = fixAllBtn

    -- Undo, bottom LEFT so it is nowhere near Fix All. See the header for why this
    -- is a revalidating revert list and not GRIPEMS.UndoStack, and why there is no
    -- Redo beside it.
    undoBtn = UI:CreateButton(f, Copy("GEMS_KC_UNDO_BUTTON"), 90, 26)
    undoBtn:SetPoint("BOTTOMLEFT", 10, 10)
    undoBtn:SetAlpha(0.35)
    undoBtn:SetMotionScriptsWhileDisabled(true)
    undoBtn:Disable()
    undoBtn:SetScript("OnClick", function()
        KCP:UndoLast()
    end)
    undoBtn:SetScript("OnEnter", function(self)
        if self:IsEnabled() then
            UI:ShowTooltip(self, Copy("GEMS_KC_UNDO_BUTTON"), Copy("GEMS_KC_UNDO_TOOLTIP"))
        else
            UI:ShowTooltip(self, Copy("GEMS_KC_UNDO_BUTTON"), Copy("GEMS_KC_UNDO_NONE_TOOLTIP"))
        end
    end)
    undoBtn:SetScript("OnLeave", function()
        UI:HideTooltip()
    end)
    f._undoBtn = undoBtn

    contextLabel = f:CreateFontString(nil, "OVERLAY")
    UI:SetFont(contextLabel, 9)
    contextLabel:SetPoint("BOTTOMLEFT", 12, 44)
    contextLabel:SetPoint("RIGHT", f, "RIGHT", -12, 0)
    contextLabel:SetJustifyH("LEFT")
    contextLabel:SetTextColor(C.textMuted:GetRGBA())
    contextLabel:SetHeight(90)

    scrollBox = CreateFrame("Frame", nil, f, "WowScrollBoxList")
    scrollBox:SetPoint("TOPLEFT", 8, -110)
    scrollBox:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -26, 140)
    local sb = CreateFrame("EventFrame", nil, f, "MinimalScrollBar")
    sb:SetPoint("TOPLEFT", scrollBox, "TOPRIGHT", 2, 0)
    sb:SetPoint("BOTTOMLEFT", scrollBox, "BOTTOMRIGHT", 2, 0)
    local sv = CreateScrollBoxListLinearView()
    sv:SetElementExtent(ROW_HEIGHT)
    sv:SetElementInitializer("Button", function(btn, d)
        InitRow(btn, d)
    end)
    ScrollUtil.InitScrollBoxListWithScrollBar(scrollBox, sb, sv)
    dataProvider = CreateDataProvider()
    scrollBox:SetDataProvider(dataProvider)

    f:HookScript("OnShow", function(self)
        local Focus = GRIPEMS.Focus
        if not Focus then
            return
        end
        Focus:PushContext("KeybindConflictPanel", {
            self._fixAllBtn,
            self._undoBtn,
            self._refreshBtn,
            self._titleCloseBtn,
        })
    end)
    f:HookScript("OnHide", function()
        local Focus = GRIPEMS.Focus
        if not Focus then
            return
        end
        Focus:PopContext("KeybindConflictPanel")
    end)

    -- THE LOAD-ON-DEMAND CASE, which the research names as producing the worst
    -- bug reports: the keybind works at login and stops an hour later when some
    -- UI opens and its addon finally loads. Rebuilding on ADDON_LOADED while the
    -- panel is open is what makes that visible instead of mysterious.
    --
    -- UPDATE_BINDINGS is what makes a LANDED FIX VISIBLY LAND. SaveBindings fires
    -- it, so the panel repaints itself off the world it just changed rather than
    -- off the report it rendered before the change. It also catches the user
    -- editing bindings in the client's own Key Bindings panel while ours is open,
    -- which is the same drift the plan predicates refuse on.
    --
    -- Not a loop: Engine.lua also listens and calls
    -- KeybindManager:ScheduleLoadKeybinds, which pushes overrides through a secure
    -- snippet and never calls SaveBindings.
    local watcher = CreateFrame("Frame")
    watcher:RegisterEvent("ADDON_LOADED")
    watcher:RegisterEvent("UPDATE_BINDINGS")
    watcher:SetScript("OnEvent", function()
        if KCP.frame and KCP.frame:IsShown() then
            KCP:Rebuild()
        end
    end)

    -- Row backgrounds here are raw BACKGROUND textures painted in InitRow, so they
    -- are in neither _backdropBindings nor the panel registry and the RebindBackdrops
    -- theme walk cannot reach them. Without this a live theme change leaves every
    -- row on the previous preset's colours until something else forces a repaint.
    -- Closes Backlog KEYBIND-PANEL-ROWS-STALE-AFTER-LIVE-THEME-CHANGE.
    if UI.OnPaletteChanged then
        UI:OnPaletteChanged(function()
            if KCP.frame and KCP.frame:IsShown() then
                KCP:Rebuild()
            end
        end)
    end
end

-- ===========================================================================
-- Public API
-- ===========================================================================

function KCP:Show()
    ResolveDeps()
    CreatePanel()
    self:Rebuild()
    self.frame:Show()
end

function KCP:Hide()
    if self.frame then
        self.frame:Hide()
    end
end

function KCP:IsShown()
    return self.frame ~= nil and self.frame:IsShown()
end

function KCP:Toggle()
    if self:IsShown() then
        self:Hide()
    else
        self:Show()
    end
end
