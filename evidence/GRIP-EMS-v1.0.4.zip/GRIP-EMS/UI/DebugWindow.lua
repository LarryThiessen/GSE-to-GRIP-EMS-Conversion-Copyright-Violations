-- GRIP-EMS: Debug Window
-- ScrollingMessageFrame-based debug log with copy and clear functionality

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS")
local UI = GRIPEMS.UI

-- Upvalue for Defaults (available after Defaults.lua loads, which is before UI/)
local function D() return GRIPEMS.Defaults end

GRIPEMS.DebugWindow = {}
local DW = GRIPEMS.DebugWindow

DW.messages = {}       -- buffer of all debug messages (strings)
DW.MAX_MESSAGES = 500  -- ring buffer limit

---------------------------------------------------------------------------
-- Init: lazily create the debug window frame
---------------------------------------------------------------------------
function DW:Init()
    if DW.frame then return end

    local C = UI.Colors
    local defaults = D()

    -- Main frame
    local frame = CreateFrame("Frame", "GRIPEMS_DebugWindow", UIParent,
        "BackdropTemplate")
    frame:SetSize(defaults.DEBUG_WINDOW_WIDTH, defaults.DEBUG_WINDOW_HEIGHT)
    frame:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", 20, 200)
    frame:SetFrameStrata("HIGH")
    frame:SetBackdrop(UI.Backdrops.panel)
    frame:SetBackdropColor(C.bgMain:GetRGBA())
    frame:SetBackdropBorderColor(C.border:GetRGBA())
    frame:SetMovable(true)
    frame:SetResizable(true)
    frame:SetResizeBounds(300, 150)
    frame:SetClampedToScreen(true)
    frame:Hide()

    ---------------------------------------------------------------------------
    -- Title bar (28px)
    ---------------------------------------------------------------------------
    local titleBar = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    titleBar:SetHeight(28)
    titleBar:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, 0)
    titleBar:SetPoint("TOPRIGHT", frame, "TOPRIGHT", 0, 0)
    titleBar:SetBackdrop(UI.Backdrops.panelNoBorder)
    titleBar:SetBackdropColor(C.bgDeep:GetRGBA())

    -- Make title bar the drag region
    titleBar:EnableMouse(true)
    titleBar:RegisterForDrag("LeftButton")
    titleBar:SetScript("OnDragStart", function()
        frame:StartMoving()
    end)
    titleBar:SetScript("OnDragStop", function()
        frame:StopMovingOrSizing()
    end)

    -- Title text
    local titleText = titleBar:CreateFontString(nil, "OVERLAY")
    UI:SetFont(titleText, 12, "OUTLINE")
    titleText:SetPoint("LEFT", titleBar, "LEFT", 8, 0)
    titleText:SetText(L["GEMS_DEBUG_WINDOW_TITLE"])
    titleText:SetTextColor(C.gripGreen:GetRGBA())

    -- Close button
    local closeBtn = CreateFrame("Button", nil, titleBar, "BackdropTemplate")
    closeBtn:SetSize(20, 20)
    closeBtn:SetPoint("TOPRIGHT", titleBar, "TOPRIGHT", -4, -4)
    closeBtn:SetBackdrop(UI.Backdrops.panel)
    closeBtn:SetBackdropColor(C.bgButton:GetRGBA())
    closeBtn:SetBackdropBorderColor(C.border:GetRGBA())
    local closeLbl = closeBtn:CreateFontString(nil, "OVERLAY")
    UI:SetFont(closeLbl, 12)
    closeLbl:SetPoint("CENTER", 0, 1)
    closeLbl:SetText("X")
    closeLbl:SetTextColor(C.textSecondary:GetRGBA())
    closeBtn:SetScript("OnClick", function() frame:Hide() end)
    closeBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.accent:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
        closeLbl:SetTextColor(C.textPrimary:GetRGBA())
    end)
    closeBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
        closeLbl:SetTextColor(C.textSecondary:GetRGBA())
    end)

    ---------------------------------------------------------------------------
    -- Button bar (below title, 24px)
    ---------------------------------------------------------------------------
    local buttonBar = CreateFrame("Frame", nil, frame)
    buttonBar:SetHeight(24)
    buttonBar:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, -28)
    buttonBar:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -8, -28)

    -- Clear button
    local clearBtn = CreateFrame("Button", nil, buttonBar, "BackdropTemplate")
    clearBtn:SetSize(60, 22)
    clearBtn:SetPoint("LEFT", buttonBar, "LEFT", 0, 0)
    clearBtn:SetBackdrop(UI.Backdrops.panel)
    clearBtn:SetBackdropColor(C.bgButton:GetRGBA())
    clearBtn:SetBackdropBorderColor(C.border:GetRGBA())
    local clearLbl = clearBtn:CreateFontString(nil, "OVERLAY")
    UI:SetFont(clearLbl, 10)
    clearLbl:SetPoint("CENTER")
    clearLbl:SetText(L["GEMS_DEBUG_CLEAR"])
    clearLbl:SetTextColor(C.textSecondary:GetRGBA())
    clearBtn:SetScript("OnClick", function()
        DW:Clear()
    end)
    clearBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.accent:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
    end)
    clearBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
    end)

    -- Copy button
    local copyBtn = CreateFrame("Button", nil, buttonBar, "BackdropTemplate")
    copyBtn:SetSize(60, 22)
    copyBtn:SetPoint("LEFT", clearBtn, "RIGHT", 4, 0)
    copyBtn:SetBackdrop(UI.Backdrops.panel)
    copyBtn:SetBackdropColor(C.bgButton:GetRGBA())
    copyBtn:SetBackdropBorderColor(C.border:GetRGBA())
    local copyLbl = copyBtn:CreateFontString(nil, "OVERLAY")
    UI:SetFont(copyLbl, 10)
    copyLbl:SetPoint("CENTER")
    copyLbl:SetText(L["GEMS_DEBUG_COPY"])
    copyLbl:SetTextColor(C.textSecondary:GetRGBA())
    copyBtn:SetScript("OnClick", function()
        DW:CopyToClipboard()
    end)
    copyBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.accent:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
    end)
    copyBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
    end)

    ---------------------------------------------------------------------------
    -- ScrollingMessageFrame (fills remaining space)
    ---------------------------------------------------------------------------
    local scrollFrame = CreateFrame("ScrollingMessageFrame", nil, frame)
    scrollFrame:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, -(28 + 24 + 4))
    scrollFrame:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -8, 8)
    scrollFrame:SetFontObject(GameFontNormal)
    scrollFrame:SetJustifyH("LEFT")
    scrollFrame:SetFading(false)
    scrollFrame:SetMaxLines(DW.MAX_MESSAGES)
    scrollFrame:SetHyperlinksEnabled(false)
    scrollFrame:EnableMouseWheel(true)
    scrollFrame:SetScript("OnMouseWheel", function(self, delta)
        if delta > 0 then
            self:ScrollUp()
        else
            self:ScrollDown()
        end
    end)
    DW.scrollFrame = scrollFrame

    ---------------------------------------------------------------------------
    -- Resize grip (bottom-right corner)
    ---------------------------------------------------------------------------
    local resizeGrip = CreateFrame("Button", nil, frame)
    resizeGrip:SetSize(16, 16)
    resizeGrip:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -2, 2)
    resizeGrip:SetNormalTexture(
        "Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    resizeGrip:SetHighlightTexture(
        "Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    resizeGrip:SetPushedTexture(
        "Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
    resizeGrip:SetScript("OnMouseDown", function()
        frame:StartSizing("BOTTOMRIGHT")
    end)
    resizeGrip:SetScript("OnMouseUp", function()
        frame:StopMovingOrSizing()
    end)

    DW.frame = frame
end

---------------------------------------------------------------------------
-- Message management
---------------------------------------------------------------------------

--- Add a debug message to the buffer and scroll frame.
--- @param msg string Formatted debug message
function DW:AddMessage(msg)
    -- Ring buffer: trim oldest if over limit
    if #DW.messages >= DW.MAX_MESSAGES then
        table.remove(DW.messages, 1)
    end
    table.insert(DW.messages, msg)

    if DW.scrollFrame then
        DW.scrollFrame:AddMessage(msg, 0.6, 0.6, 0.6)
    end
end

--- Clear all buffered messages and the scroll frame.
function DW:Clear()
    wipe(DW.messages)
    if DW.scrollFrame then
        DW.scrollFrame:Clear()
    end
end

--- Copy debug log to clipboard via ExportFrame or chat hint.
function DW:CopyToClipboard()
    local text = table.concat(DW.messages, "\n")
    -- WoW has no direct clipboard API. Show via ExportFrame.
    if GRIPEMS.ExportFrame then
        GRIPEMS.ExportFrame:Show("Debug Log", text)
    else
        GRIPEMS:Print(L["GEMS_DEBUG_COPY_HINT"])
    end
end

---------------------------------------------------------------------------
-- Show / Hide / Toggle
---------------------------------------------------------------------------

--- Show the debug window, creating it if needed. Replays buffered messages.
function DW:Show()
    if not DW.frame then DW:Init() end
    DW.frame:Show()
    -- Replay buffered messages into scrollFrame
    if DW.scrollFrame then
        DW.scrollFrame:Clear()
        for _, msg in ipairs(DW.messages) do
            DW.scrollFrame:AddMessage(msg, 0.6, 0.6, 0.6)
        end
    end
end

--- Hide the debug window.
function DW:Hide()
    if DW.frame then DW.frame:Hide() end
end

--- Toggle the debug window visibility.
function DW:Toggle()
    if DW.frame and DW.frame:IsShown() then
        DW:Hide()
    else
        DW:Show()
    end
end

--- Check if the debug window is currently shown.
--- @return boolean
function DW:IsShown()
    return DW.frame and DW.frame:IsShown()
end
