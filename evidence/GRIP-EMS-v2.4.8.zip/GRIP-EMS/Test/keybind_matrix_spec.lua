-- GRIP-EMS: Test spec for the secure vehicle keybind driver matrix (FIX B, v2.1.14)
--
-- Created:    2026-06-05
-- Updated:    2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.
--
-- Registers tests in TestSuite under category "keybind_matrix" covering the Lua
-- surface of Engine/KeybindManager.lua's secure-driver matrix path. The restricted
-- environment (the _onattributechanged snippet) cannot run headless, so these
-- assert the Lua seams that feed it:
--   1  resolution -- _ResolveFinalKeybinds merges per-spec + per-loadout overlay,
--                    honoring the "__suppress__" sentinel (and the no-loadout case).
--   2  flatten    -- _BuildMatrixList / applyBinding produce the correct flat
--                    { key, target } list (plain + present SHIFT/CTRL/ALT variants),
--                    skip sequences whose button is not yet created, and reduce to
--                    exactly the base key for a no-override sequence (regression).
--   3  push        -- _WriteMatrixToDriver writes bindcount + a bindkey<i> attribute
--                    and one frame ref per entry, and clears on an empty list.
--   8  priority    -- the isPriority literal in the driver snippet's SOURCE TEXT.
--                    Source-text coverage of one of the six SetBindingClick sites;
--                    the other five are transient SecureHandlerExecute strings and
--                    are unreachable. See the test body for the full boundary.
--   9  restore     -- Engine:_RunEnteringWorldRestore bootstraps once per login
--                    but re-applies keybinds on EVERY world load, schedules the
--                    settle re-push, and queues instead of pushing inline while
--                    restricted (Discord 1537091347683745882).
-- NOT HERE -- all six sites, as source text, are covered by
-- Test/test_keybind_bind_priority_pin.lua, which runs in SET A under CI. An
-- in-game spec has no io and no headless driver loads this file, so a file-reading
-- case here could never execute. That guard also asserts EXPECTED_BIND_PRIORITY
-- below equals the literal the source actually passes, so the two halves of the
-- pin cannot drift. See the block above GROUP 8 for the full reasoning.

local ADDON_NAME, GRIPEMS = ...

local TS = GRIPEMS.TestSuite
if not TS then
    return
end

local CATEGORY = "keybind_matrix"

-- The isPriority literal every sequence-keybind SetBindingClick site in
-- Engine/KeybindManager.lua must pass. Non-priority is the deliberate state
-- as of 2026-08-11: the flip to true was investigated and REJECTED because
-- TempoAdvisor hold mode binds the same key by construction at priority true,
-- and VehicleKeybinds binds at priority true in five places including two
-- ACTIONBUTTON overrides the suspend watchdog depends on. Changing this
-- constant is the single edit that flips the pin, and both cases below read
-- it, so the in-game pin and the source-text pin can never disagree.
local EXPECTED_BIND_PRIORITY = "false"

-- Assertion helper: returns false (and marks the test failed) on mismatch so the
-- caller can early-return. Avoids TestSuite's file-local currentResult, which is
-- not visible from a spec file.
local function eq(self, expected, actual, label)
    if expected ~= actual then
        self:Fail((label or "value") .. ": expected " .. tostring(expected) .. ", got " .. tostring(actual))
        return false
    end
    return true
end

-- ===========================================================================
-- GROUP 1 -- per-spec + per-loadout resolution (_ResolveFinalKeybinds)
-- ===========================================================================

TS:Register("KB matrix: resolution overlays active loadout and honors __suppress__", CATEGORY, function(self)
    local KM = GRIPEMS.KeybindManager
    if not KM or not KM._ResolveFinalKeybinds then
        self:Skip("KeybindManager._ResolveFinalKeybinds not available")
        return
    end
    local specBinds = {
        ["F1"] = "SeqA",
        ["F2"] = "SeqB",
        _byLoadout = {
            [123] = {
                ["F2"] = "SeqC", -- overlay overrides the per-spec F2
                ["F3"] = "SeqD", -- overlay adds F3
                ["F1"] = "__suppress__", -- overlay hides the per-spec F1
            },
        },
    }
    local final = KM:_ResolveFinalKeybinds(specBinds, 123)
    if not eq(self, nil, final["F1"], "F1 suppressed by overlay") then
        return
    end
    if not eq(self, "SeqC", final["F2"], "F2 overridden by overlay") then
        return
    end
    if not eq(self, "SeqD", final["F3"], "F3 added by overlay") then
        return
    end
    self:Pass()
end)

TS:Register("KB matrix: resolution with no active loadout is per-spec only", CATEGORY, function(self)
    local KM = GRIPEMS.KeybindManager
    if not KM or not KM._ResolveFinalKeybinds then
        self:Skip("KeybindManager._ResolveFinalKeybinds not available")
        return
    end
    local specBinds = {
        ["F1"] = "SeqA",
        ["F2"] = "SeqB",
        _byLoadout = { [123] = { ["F2"] = "SeqC" } },
    }
    local final = KM:_ResolveFinalKeybinds(specBinds, nil)
    if not eq(self, "SeqA", final["F1"], "F1 from per-spec layer") then
        return
    end
    if not eq(self, "SeqB", final["F2"], "F2 from per-spec layer (overlay not applied)") then
        return
    end
    if not eq(self, nil, final["F3"], "F3 absent without active loadout") then
        return
    end
    self:Pass()
end)

TS:Register(
    "KB matrix: resolution with an active loadout that has no overlay falls through to per-spec",
    CATEGORY,
    function(self)
        local KM = GRIPEMS.KeybindManager
        if not KM or not KM._ResolveFinalKeybinds then
            self:Skip("KeybindManager._ResolveFinalKeybinds not available")
            return
        end
        -- Active loadout is 123, but the only overlay is for 999, so loadoutOverlay
        -- resolves nil and the result is the per-spec layer untouched.
        local specBinds = {
            ["F1"] = "SeqA",
            _byLoadout = { [999] = { ["F1"] = "SeqZ" } },
        }
        local final = KM:_ResolveFinalKeybinds(specBinds, 123)
        if not eq(self, "SeqA", final["F1"], "F1 from per-spec (overlay 999 not applied for active 123)") then
            return
        end
        self:Pass()
    end
)

-- ===========================================================================
-- GROUP 2 -- flatten (_BuildMatrixList / applyBinding)
-- ===========================================================================

TS:Register("KB matrix: flatten emits plain key + present SHIFT variant", CATEGORY, function(self)
    local Engine = GRIPEMS.Engine
    local KM = GRIPEMS.KeybindManager
    local D = GRIPEMS.Defaults
    if not Engine or not KM or not D or not KM._BuildMatrixList then
        self:Skip("Engine/KeybindManager/Defaults not available")
        return
    end
    local name = "_TS_KbVariant"
    local sanitized = Engine:SanitizeName(name)
    local baseName = D.BUTTON_PREFIX .. sanitized
    local variantName = baseName .. D.VARIANT_BUTTON_SUFFIX .. 2 -- override index 1 -> suffix 2

    -- Save and stub the Engine + _G state, then restore BEFORE asserting so a
    -- failed assertion still leaves the environment clean.
    local savedSeq = Engine.sequences[name]
    local savedBase = _G[baseName]
    local savedVariant = _G[variantName]

    local baseStub = {}
    local variantStub = {}
    Engine.sequences[name] = {
        data = {
            defaultVersion = 1,
            versions = { { variantOverrides = { { modifier = "shift" } } } },
        },
    }
    _G[baseName] = baseStub
    _G[variantName] = variantStub

    local list = KM:_BuildMatrixList({ ["F5"] = name })

    Engine.sequences[name] = savedSeq
    _G[baseName] = savedBase
    _G[variantName] = savedVariant

    if not eq(self, 2, #list, "list length (plain + shift)") then
        return
    end
    if not eq(self, "F5", list[1].key, "list[1] is the plain key") then
        return
    end
    if not eq(self, baseStub, list[1].target, "list[1] targets the base button") then
        return
    end
    if not eq(self, "SHIFT-F5", list[2].key, "list[2] is the SHIFT-prefixed key") then
        return
    end
    if not eq(self, variantStub, list[2].target, "list[2] targets the shift variant button") then
        return
    end
    self:Pass()
end)

TS:Register("KB matrix: flatten resolves multiple variants to _v2/_v3 in modifier order", CATEGORY, function(self)
    local Engine = GRIPEMS.Engine
    local KM = GRIPEMS.KeybindManager
    local D = GRIPEMS.Defaults
    if not Engine or not KM or not D or not KM._BuildMatrixList then
        self:Skip("Engine/KeybindManager/Defaults not available")
        return
    end
    local name = "_TS_KbMultiVariant"
    local sanitized = Engine:SanitizeName(name)
    local baseName = D.BUTTON_PREFIX .. sanitized
    local shiftName = baseName .. D.VARIANT_BUTTON_SUFFIX .. 2 -- override index 1 -> suffix 2
    local ctrlName = baseName .. D.VARIANT_BUTTON_SUFFIX .. 3 -- override index 2 -> suffix 3

    local savedSeq = Engine.sequences[name]
    local savedBase = _G[baseName]
    local savedShift = _G[shiftName]
    local savedCtrl = _G[ctrlName]

    local baseStub, shiftStub, ctrlStub = {}, {}, {}
    Engine.sequences[name] = {
        data = {
            defaultVersion = 1,
            versions = { { variantOverrides = { { modifier = "shift" }, { modifier = "ctrl" } } } },
        },
    }
    _G[baseName] = baseStub
    _G[shiftName] = shiftStub
    _G[ctrlName] = ctrlStub

    local list = KM:_BuildMatrixList({ ["G"] = name })

    Engine.sequences[name] = savedSeq
    _G[baseName] = savedBase
    _G[shiftName] = savedShift
    _G[ctrlName] = savedCtrl

    -- Order: plain first, then D.VARIANT_MODIFIERS order (shift, ctrl, alt). The
    -- suffix is override-index + 1, so index 1 -> _v2 and index 2 -> _v3. A
    -- constant-suffix or wrong-index regression would break list[2]/list[3].
    if not eq(self, 3, #list, "list length (plain + shift + ctrl)") then
        return
    end
    if not eq(self, "G", list[1].key, "list[1] plain key") then
        return
    end
    if not eq(self, baseStub, list[1].target, "list[1] base button") then
        return
    end
    if not eq(self, "SHIFT-G", list[2].key, "list[2] SHIFT key") then
        return
    end
    if not eq(self, shiftStub, list[2].target, "list[2] is the _v2 (override index 1) button") then
        return
    end
    if not eq(self, "CTRL-G", list[3].key, "list[3] CTRL key") then
        return
    end
    if not eq(self, ctrlStub, list[3].target, "list[3] is the _v3 (override index 2) button") then
        return
    end
    self:Pass()
end)

TS:Register("KB matrix: flatten with no overrides binds exactly the base key (regression)", CATEGORY, function(self)
    local Engine = GRIPEMS.Engine
    local KM = GRIPEMS.KeybindManager
    local D = GRIPEMS.Defaults
    if not Engine or not KM or not D or not KM._BuildMatrixList then
        self:Skip("Engine/KeybindManager/Defaults not available")
        return
    end
    local name = "_TS_KbBase"
    local sanitized = Engine:SanitizeName(name)
    local baseName = D.BUTTON_PREFIX .. sanitized

    local savedSeq = Engine.sequences[name]
    local savedBase = _G[baseName]

    local baseStub = {}
    Engine.sequences[name] = {
        data = { defaultVersion = 1, versions = { { variantOverrides = {} } } },
    }
    _G[baseName] = baseStub

    local list = KM:_BuildMatrixList({ ["F6"] = name })

    Engine.sequences[name] = savedSeq
    _G[baseName] = savedBase

    if not eq(self, 1, #list, "list length (base key only)") then
        return
    end
    if not eq(self, "F6", list[1].key, "list[1] is exactly the base key") then
        return
    end
    if not eq(self, baseStub, list[1].target, "list[1] targets the base button") then
        return
    end
    self:Pass()
end)

TS:Register("KB matrix: flatten skips a sequence whose button is not yet created", CATEGORY, function(self)
    local Engine = GRIPEMS.Engine
    local KM = GRIPEMS.KeybindManager
    local D = GRIPEMS.Defaults
    if not Engine or not KM or not D or not KM._BuildMatrixList then
        self:Skip("Engine/KeybindManager/Defaults not available")
        return
    end
    local name = "_TS_KbAbsent"
    local sanitized = Engine:SanitizeName(name)
    local baseName = D.BUTTON_PREFIX .. sanitized

    local savedSeq = Engine.sequences[name]
    local savedBase = _G[baseName]

    Engine.sequences[name] = { data = { defaultVersion = 1, versions = { {} } } }
    _G[baseName] = nil -- button not created yet (BindIfConfigured rebuilds on activation)

    local list, count = KM:_BuildMatrixList({ ["F7"] = name })

    Engine.sequences[name] = savedSeq
    _G[baseName] = savedBase

    if not eq(self, 0, #list, "absent button contributes no matrix entries") then
        return
    end
    if not eq(self, 0, count, "count excludes the absent-button sequence") then
        return
    end
    self:Pass()
end)

TS:Register(
    "KB matrix: flatten binds present sequences while skipping absent ones in one pass",
    CATEGORY,
    function(self)
        local Engine = GRIPEMS.Engine
        local KM = GRIPEMS.KeybindManager
        local D = GRIPEMS.Defaults
        if not Engine or not KM or not D or not KM._BuildMatrixList then
            self:Skip("Engine/KeybindManager/Defaults not available")
            return
        end
        local presentName = "_TS_KbPresent"
        local absentName = "_TS_KbMissing"
        local presentBtn = D.BUTTON_PREFIX .. Engine:SanitizeName(presentName)
        local absentBtn = D.BUTTON_PREFIX .. Engine:SanitizeName(absentName)

        local savedPresentSeq = Engine.sequences[presentName]
        local savedAbsentSeq = Engine.sequences[absentName]
        local savedPresentG = _G[presentBtn]
        local savedAbsentG = _G[absentBtn]

        local presentStub = {}
        Engine.sequences[presentName] = { data = { defaultVersion = 1, versions = { { variantOverrides = {} } } } }
        Engine.sequences[absentName] = { data = { defaultVersion = 1, versions = { { variantOverrides = {} } } } }
        _G[presentBtn] = presentStub
        _G[absentBtn] = nil -- present sequence binds; absent one is skipped in the SAME pass

        local list, count = KM:_BuildMatrixList({ ["F8"] = presentName, ["F9"] = absentName })

        Engine.sequences[presentName] = savedPresentSeq
        Engine.sequences[absentName] = savedAbsentSeq
        _G[presentBtn] = savedPresentG
        _G[absentBtn] = savedAbsentG

        -- Only the present sequence contributes, so the single entry must be its key
        -- (proves per-sequence skip, not abort-whole-loop on the first missing button).
        if not eq(self, 1, #list, "only the present sequence contributes an entry") then
            return
        end
        if not eq(self, "F8", list[1].key, "the present sequence's key is bound") then
            return
        end
        if not eq(self, presentStub, list[1].target, "the present sequence's base button") then
            return
        end
        if not eq(self, 1, count, "count reflects only the present sequence") then
            return
        end
        self:Pass()
    end
)

TS:Register(
    "KB matrix: flatten skips a disabled (dormant) sequence even with its button in _G",
    CATEGORY,
    function(self)
        local Engine = GRIPEMS.Engine
        local KM = GRIPEMS.KeybindManager
        local D = GRIPEMS.Defaults
        if not Engine or not KM or not D or not KM._BuildMatrixList then
            self:Skip("Engine/KeybindManager/Defaults not available")
            return
        end
        local name = "_TS_KbDisabled"
        local baseName = D.BUTTON_PREFIX .. Engine:SanitizeName(name)

        local savedSeq = Engine.sequences[name]
        local savedBase = _G[baseName]

        -- Dormant sequence: data.disabled set, base button's _G slot still populated
        -- (mirrors Engine's disable path, which clears only variant slots). Without the
        -- disabled guard the key would be re-bound to the orphaned no-op button.
        local baseStub = {}
        Engine.sequences[name] = {
            data = { defaultVersion = 1, versions = { { variantOverrides = {} } }, disabled = true },
        }
        _G[baseName] = baseStub

        local list, count = KM:_BuildMatrixList({ ["F10"] = name })

        Engine.sequences[name] = savedSeq
        _G[baseName] = savedBase

        if not eq(self, 0, #list, "a disabled sequence contributes no matrix entries despite its _G button") then
            return
        end
        if not eq(self, 0, count, "count excludes the disabled sequence") then
            return
        end
        self:Pass()
    end
)

-- ===========================================================================
-- GROUP 3 -- driver translation (_WriteMatrixToDriver)
-- ===========================================================================

TS:Register("KB matrix: push writes bindcount + bindkey<i> and one frame ref per entry", CATEGORY, function(self)
    local KM = GRIPEMS.KeybindManager
    if not KM or not KM._WriteMatrixToDriver then
        self:Skip("KeybindManager._WriteMatrixToDriver not available")
        return
    end
    local refs = {}
    local mockDriver = {
        attrs = {},
        SetAttribute = function(s, k, v)
            s.attrs[k] = v
        end,
    }
    local function recorder(_, label, ref)
        refs[#refs + 1] = { label = label, ref = ref }
    end
    local btnA = {}
    local btnB = {}
    KM._WriteMatrixToDriver(mockDriver, {
        { key = "F5", target = btnA },
        { key = "SHIFT-F5", target = btnB },
    }, recorder)

    if not eq(self, 2, mockDriver.attrs.bindcount, "bindcount") then
        return
    end
    if not eq(self, "F5", mockDriver.attrs.bindkey1, "bindkey1") then
        return
    end
    if not eq(self, "SHIFT-F5", mockDriver.attrs.bindkey2, "bindkey2") then
        return
    end
    if not eq(self, 2, #refs, "one frame ref per entry") then
        return
    end
    if not eq(self, "bindtarget1", refs[1].label, "frame ref 1 label") then
        return
    end
    if not eq(self, btnA, refs[1].ref, "frame ref 1 target") then
        return
    end
    if not eq(self, "bindtarget2", refs[2].label, "frame ref 2 label") then
        return
    end
    if not eq(self, btnB, refs[2].ref, "frame ref 2 target") then
        return
    end
    self:Pass()
end)

TS:Register("KB matrix: push of an empty list clears (bindcount 0, no frame refs)", CATEGORY, function(self)
    local KM = GRIPEMS.KeybindManager
    if not KM or not KM._WriteMatrixToDriver then
        self:Skip("KeybindManager._WriteMatrixToDriver not available")
        return
    end
    local refs = {}
    local mockDriver = {
        attrs = {},
        SetAttribute = function(s, k, v)
            s.attrs[k] = v
        end,
    }
    local function recorder(_, label, ref)
        refs[#refs + 1] = { label = label, ref = ref }
    end
    KM._WriteMatrixToDriver(mockDriver, {}, recorder)

    if not eq(self, 0, mockDriver.attrs.bindcount, "bindcount is 0 for an empty list") then
        return
    end
    if not eq(self, 0, #refs, "no frame refs for an empty list") then
        return
    end
    self:Pass()
end)

TS:Register(
    "KB matrix: pushSecureMatrix in combat queues a rebuild and writes no driver attributes",
    CATEGORY,
    function(self)
        local KM = GRIPEMS.KeybindManager
        local OOC = GRIPEMS.OOCQueue
        if not KM or not KM._PushSecureMatrix or not OOC then
            self:Skip("KeybindManager._PushSecureMatrix or OOCQueue not available")
            return
        end
        -- Force the combat gate to "restricted": pushSecureMatrix must early-return
        -- BEFORE any protected attribute / frame-ref write (writing secure attributes
        -- in combat would taint) and instead queue a full LoadKeybinds rebuild. Stub
        -- and restore OOCQueue's gate + Add; the queued closure is captured, never run.
        local savedIsRestricted = OOC.IsRestricted
        local savedAdd = OOC.Add
        local queued = false
        OOC.IsRestricted = function()
            return true
        end
        OOC.Add = function(_, fn)
            queued = (type(fn) == "function")
        end

        local ok, err = pcall(function()
            KM._PushSecureMatrix({ { key = "F5", target = {} } })
        end)

        OOC.IsRestricted = savedIsRestricted
        OOC.Add = savedAdd

        if
            not eq(self, true, ok, "pushSecureMatrix must not error on the restricted path (" .. tostring(err) .. ")")
        then
            return
        end
        if not eq(self, true, queued, "restricted pushSecureMatrix queues a LoadKeybinds rebuild via OOCQueue:Add") then
            return
        end
        self:Pass()
    end
)

-- ===========================================================================
-- GROUP 4 -- skyride slot derivation (_GetSkyrideSlotForKey)
-- ===========================================================================

TS:Register(
    "KB matrix: skyride slot derivation maps default UI / ElvUI / BT4 bindings and vehicle override",
    CATEGORY,
    function(self)
        local KM = GRIPEMS.KeybindManager
        if not KM or not KM._GetSkyrideSlotForKey then
            self:Skip("KeybindManager._GetSkyrideSlotForKey not available")
            return
        end
        -- Stub getBindingAction with a fixed action; a nil action means "pass a nil
        -- getBindingAction" (the nil-getter guard). vehicleKeys covers BOTH the empty
        -- shape {} (RefreshSkyridePassAttrs passes {} when VehicleKeybinds is absent)
        -- and a populated shape (the override-wins tier).
        local function got(key, action, vkeys)
            local g
            if action ~= nil then
                g = function()
                    return action
                end
            end
            return KM._GetSkyrideSlotForKey(key, g, vkeys)
        end
        if not eq(self, 3, got("X", "ACTIONBUTTON9", { ["X"] = 3 }), "vehicleKeys override wins") then
            return
        end
        if not eq(self, 4, got("4", "ACTIONBUTTON4", {}), "ACTIONBUTTON4 -> 4") then
            return
        end
        if not eq(self, 7, got("7", "CLICK ElvUI_Bar1Button7:LeftButton", {}), "ElvUI_Bar1Button7 -> 7") then
            return
        end
        if not eq(self, 12, got("F12", "CLICK BT4Button12:Keybind", {}), "BT4Button12 -> 12") then
            return
        end
        if not eq(self, nil, got("0", "ACTIONBUTTON13", {}), "ACTIONBUTTON13 out of range -> nil") then
            return
        end
        if not eq(self, nil, got("Q", "", {}), "empty action -> nil") then
            return
        end
        if not eq(self, nil, got("Q", nil, {}), "nil getBindingAction -> nil") then
            return
        end
        if not eq(self, nil, got("B", "TOGGLEBACKPACK", {}), "TOGGLEBACKPACK -> nil") then
            return
        end
        self:Pass()
    end
)

-- ===========================================================================
-- GROUP 5 -- suspend watchdog verdict (_SuspendWatchdogVerdict)
-- ===========================================================================

TS:Register(
    "KB matrix: suspend watchdog verdict covers heal, reclear, enter heal, enter clear and asymmetric vk",
    CATEGORY,
    function(self)
        local KM = GRIPEMS.KeybindManager
        if not KM or not KM._SuspendWatchdogVerdict then
            self:Skip("KeybindManager._SuspendWatchdogVerdict not available")
            return
        end
        -- Each case drives the pure helper with plain values, positionally:
        -- { label, state, anyRealSource, vkActive, healed, glidingActive, enterHealed,
        --   expected driver, expected vk }. A nil state (case 5) is the pre-first-dispatch
        -- login shape; nil expectations assert the field stays unset.
        local cases = {
            { "stale suspend heals", "suspend", false, false, false, false, false, "heal", nil },
            { "heal then real source reclears", "suspend", true, false, true, false, false, "reclear", nil },
            { "missed exit deactivates vk", "none", false, true, false, false, false, nil, "deactivate" },
            { "missed enter heals + activates", "none", true, false, false, true, false, "enterheal", "activate" },
            { "nil state enter heals", nil, true, false, false, true, false, "enterheal", "activate" },
            { "rest after enter heal clears", "none", false, false, false, false, true, "enterclear", nil },
            { "no double enter heal", "none", true, false, false, true, true, nil, nil },
            { "skyride stale vk force-activates", "skyride", true, false, false, true, false, nil, "activate" },
            { "skyride live vk needs nothing", "skyride", true, true, false, true, false, nil, nil },
            { "skyride grounded stale vk needs nothing", "skyride", true, false, false, false, false, nil, nil },
            { "at rest empty verdict", "none", false, false, false, false, false, nil, nil },
        }
        for _, c in ipairs(cases) do
            local verdict = KM._SuspendWatchdogVerdict(c[2], c[3], c[4], c[5], c[6], c[7])
            if not eq(self, c[8], verdict.driver, c[1] .. " (driver)") then
                return
            end
            if not eq(self, c[9], verdict.vk, c[1] .. " (vk)") then
                return
            end
        end
        self:Pass()
    end
)

-- ===========================================================================
-- GROUP 6 -- vehicle-keybind skyride yield (writeVKMatrix vkseq + autodismount)
-- ===========================================================================

-- Install or restore a function on a read-only API global for the duration of a
-- single test. Routing the assignment through local parameters keeps the
-- intentional, immediately-restored stub from tripping luacheck's read-only
-- global guard (the TestSuite SetApiField precedent, applied to a bare global).
local function setApiGlobal(host, key, fn)
    host[key] = fn
end

TS:Register("KB matrix: writeVKMatrix flags vkseq for sequence-overlap keys", CATEGORY, function(self)
    local VK = GRIPEMS.VehicleKeybinds
    local KM = GRIPEMS.KeybindManager
    if not VK or not VK._WriteVKMatrix or not KM then
        self:Skip("VehicleKeybinds._WriteVKMatrix or KeybindManager not available")
        return
    end
    -- writeVKMatrix reads the sequence-keybind keys from KM._lastMatrixList to
    -- decide which VK entries also belong to the sequence layer (the vkseq<i>
    -- overlap flag the skyride yield reads). Mock that list, then restore it
    -- BEFORE asserting so a failed assertion still leaves the environment clean.
    local savedList = KM._lastMatrixList
    KM._lastMatrixList = {
        { key = "F5", target = {} },
        { key = "SHIFT-F5", target = {} },
    }
    local mockDriver = {
        attrs = {},
        SetAttribute = function(s, k, v)
            s.attrs[k] = v
        end,
    }
    -- Entry 1 (F5) overlaps a sequence keybind; entry 2 (G) does not.
    VK._WriteVKMatrix(mockDriver, {
        { key = "F5", slot = 3 },
        { key = "G", slot = 4 },
    })

    KM._lastMatrixList = savedList

    if not eq(self, 2, mockDriver.attrs.vkcount, "vkcount") then
        return
    end
    if not eq(self, "F5", mockDriver.attrs.vkkey1, "vkkey1") then
        return
    end
    if not eq(self, 3, mockDriver.attrs.vkslot1, "vkslot1") then
        return
    end
    if not eq(self, "1", mockDriver.attrs.vkseq1, "vkseq1 set for overlap key F5") then
        return
    end
    if not eq(self, "G", mockDriver.attrs.vkkey2, "vkkey2") then
        return
    end
    if not eq(self, 4, mockDriver.attrs.vkslot2, "vkslot2") then
        return
    end
    if not eq(self, nil, mockDriver.attrs.vkseq2, "vkseq2 nil for non-overlap key G") then
        return
    end
    self:Pass()
end)

TS:Register("KB matrix: VK RefreshAutoDismountAttr mirrors autoDismountFlying CVar", CATEGORY, function(self)
    local VK = GRIPEMS.VehicleKeybinds
    if not VK or not VK.RefreshAutoDismountAttr then
        self:Skip("VehicleKeybinds.RefreshAutoDismountAttr not available")
        return
    end
    local OOC = GRIPEMS.OOCQueue
    if OOC and OOC.IsRestricted and OOC.IsRestricted() then
        self:Skip("RefreshAutoDismountAttr queues in combat; run out of combat")
        return
    end
    local owner = _G.GRIPEMS_VehicleKeybindOwner
    if not owner or not owner.GetAttribute then
        self:Skip("VK owner frame not present")
        return
    end
    -- Stub GetCVar via the local-parameter helper (luacheck-clean), read the
    -- owner's autodismount attribute for the on/off cases, then restore the real
    -- getter and re-run so the live attribute returns to its true value.
    local origGetCVar = _G.GetCVar
    setApiGlobal(_G, "GetCVar", function(name)
        if name == "autoDismountFlying" then
            return "1"
        end
        return origGetCVar and origGetCVar(name)
    end)
    VK:RefreshAutoDismountAttr()
    local onResult = owner:GetAttribute("autodismount")

    setApiGlobal(_G, "GetCVar", function(name)
        if name == "autoDismountFlying" then
            return "0"
        end
        return origGetCVar and origGetCVar(name)
    end)
    VK:RefreshAutoDismountAttr()
    local offResult = owner:GetAttribute("autodismount")

    setApiGlobal(_G, "GetCVar", origGetCVar)
    VK:RefreshAutoDismountAttr()

    if not eq(self, "1", onResult, "CVar on -> autodismount '1'") then
        return
    end
    if not eq(self, nil, offResult, "CVar off -> autodismount nil") then
        return
    end
    self:Pass()
end)

-- ===========================================================================
-- GROUP 7 -- vehicle-keybind skyride cast resolution (VK:RefreshSkyrideCastAttrs)
-- ===========================================================================

TS:Register("KB matrix: VK RefreshSkyrideCastAttrs resolves /cast per slot, clears off-bar", CATEGORY, function(self)
    local VK = GRIPEMS.VehicleKeybinds
    if not VK or not VK.RefreshSkyrideCastAttrs or not VK._WriteVKMatrix then
        self:Skip("VehicleKeybinds.RefreshSkyrideCastAttrs not available")
        return
    end
    local OOC = GRIPEMS.OOCQueue
    if OOC and OOC.IsRestricted and OOC.IsRestricted() then
        self:Skip("RefreshSkyrideCastAttrs writes protected attributes; run out of combat")
        return
    end
    local owner = _G.GRIPEMS_VehicleKeybindOwner
    local cast1 = _G.GRIPEMS_VKSkyCast1
    local cast2 = _G.GRIPEMS_VKSkyCast2
    if not owner or not owner.GetAttribute or not cast1 or not cast2 then
        self:Skip("VK owner / cast buttons not present")
        return
    end
    -- Save real state; restore runs BEFORE asserting so a failed eq leaves it clean.
    local sCount = owner:GetAttribute("vkcount")
    local sKey1 = owner:GetAttribute("vkkey1")
    local sKey2 = owner:GetAttribute("vkkey2")
    local sSlot1 = owner:GetAttribute("vkslot1")
    local sSlot2 = owner:GetAttribute("vkslot2")
    local sSeq1 = owner:GetAttribute("vkseq1")
    local sSeq2 = owner:GetAttribute("vkseq2")
    local sMt1 = cast1:GetAttribute("macrotext")
    local sMt2 = cast2:GetAttribute("macrotext")
    local origGAI = _G.GetActionInfo
    local origGSN = C_Spell and C_Spell.GetSpellName
    setApiGlobal(_G, "GetActionInfo", function(index)
        return "spell", index
    end)
    if C_Spell then
        setApiGlobal(C_Spell, "GetSpellName", function(id)
            return "Spell" .. tostring(id)
        end)
    end

    VK._WriteVKMatrix(owner, { { key = "1", slot = 4 }, { key = "G", slot = 5 } })
    VK:RefreshSkyrideCastAttrs(5)
    local on1 = cast1:GetAttribute("macrotext")
    local on2 = cast2:GetAttribute("macrotext")
    VK:RefreshSkyrideCastAttrs(0)
    local off1 = cast1:GetAttribute("macrotext")

    owner:SetAttribute("vkcount", sCount)
    owner:SetAttribute("vkkey1", sKey1)
    owner:SetAttribute("vkkey2", sKey2)
    owner:SetAttribute("vkslot1", sSlot1)
    owner:SetAttribute("vkslot2", sSlot2)
    owner:SetAttribute("vkseq1", sSeq1)
    owner:SetAttribute("vkseq2", sSeq2)
    cast1:SetAttribute("macrotext", sMt1)
    cast2:SetAttribute("macrotext", sMt2)
    setApiGlobal(_G, "GetActionInfo", origGAI)
    if C_Spell then
        setApiGlobal(C_Spell, "GetSpellName", origGSN)
    end

    local base = (NUM_ACTIONBAR_PAGES + 5 - 1) * NUM_ACTIONBAR_BUTTONS
    if not eq(self, "/cast Spell" .. (base + 4), on1, "slot 4 -> /cast Spell" .. (base + 4)) then
        return
    end
    if not eq(self, "/cast Spell" .. (base + 5), on2, "slot 5 -> /cast Spell" .. (base + 5)) then
        return
    end
    if not eq(self, nil, off1, "offset 0 clears cast macrotext") then
        return
    end
    self:Pass()
end)

-- ===========================================================================
-- GROUP 8 -- override-binding priority in the secure driver snippet
-- ===========================================================================

TS:Register("KB matrix: the driver snippet binds sequence keys at non-priority", CATEGORY, function(self)
    local driver = _G.GRIPEMS_VehicleDriver
    if not driver or not driver.GetAttribute then
        self:Skip("GRIPEMS_VehicleDriver not present (in-game only)")
        return
    end
    local snippet = driver:GetAttribute("_onattributechanged")
    if type(snippet) ~= "string" or snippet == "" then
        self:Skip("driver snippet attribute is not readable as a string")
        return
    end
    -- WHAT THIS COVERS, AND WHAT IT DEMONSTRABLY DOES NOT.
    --
    -- COVERS: the SOURCE TEXT of the _onattributechanged snippet, which is a plain
    -- string attribute on the named driver frame and therefore readable. That is
    -- ONE of the six SetBindingClick sites in Engine/KeybindManager.lua.
    --
    -- DOES NOT COVER:
    --   * The other five sites. At RUNTIME they are unreachable: they live in
    --     SecureHandlerExecute string literals built at call time (the
    --     pushSecureMatrix re-apply and the four HealStuckSuspend branches) and are
    --     never stored anywhere a spec could read them, so flipping five of six
    --     passes this test. They ARE reachable as source text, and that is where
    --     they are covered -- Test/test_keybind_bind_priority_pin.lua reads
    --     Engine/KeybindManager.lua as a file and asserts all six agree. It runs in
    --     SET A under CI; this case is the in-game half of the same pin. See the
    --     block above this group for why that check cannot live in this file.
    --   * That the snippet actually BINDS at this priority. The restricted
    --     environment does not run headless and cannot be driven from a spec;
    --     this asserts a literal in a string, not a keypress outcome. Neither half
    --     of the pin closes that one.
    --
    -- WHY IT ASSERTS false. Non-priority is the current, deliberate state as of
    -- 2026-08-11. The flip to priority = true was investigated and PARKED: hold
    -- mode in Engine/TempoAdvisor.lua binds the same key as a sequence keybind by
    -- construction and relies on priority = true to win that contest, so raising
    -- the sequence path would make the two last-writer-wins. See the Investigation
    -- A comment at the TempoAdvisor bind site. If that decision is ever taken,
    -- this expectation changes WITH it, deliberately -- which is the point of
    -- pinning it here rather than leaving the boolean unwatched.
    local calls = 0
    for _ in string.gmatch(snippet, "SetBindingClick%(") do
        calls = calls + 1
    end
    if not eq(self, 1, calls, "SetBindingClick calls in the driver snippet") then
        return
    end
    local priority = string.match(snippet, "SetBindingClick%(%s*(%a+)%s*,")
    if not eq(self, EXPECTED_BIND_PRIORITY, priority, "the snippet's isPriority argument") then
        return
    end
    self:Pass()
end)

-- ===========================================================================
-- WHERE THE SIX-SITE COVERAGE LIVES -- deliberately NOT a case in this file
-- ===========================================================================
--
-- Source-text coverage of all six sequence-keybind bind sites is in
-- Test/test_keybind_bind_priority_pin.lua, and it runs in SET A, which
-- .github/workflows/lint.yml enforces via "cowork_util.py alltest --sets ac".
--
-- It was briefly written as a GROUP 9 case here, and that version could not
-- execute in ANY lane:
--   * in-game there is no io, so a file-reading case skips at its own guard;
--   * the lua_headless harness loads exactly one EMS spec and it is not this one;
--   * the alltest SET C classifier lists this file as in-game-only and skips it.
-- A case that cannot run is worse than no case, because its body claims coverage
-- it never delivers, so it was deleted rather than left as decoration. SET A runs
-- each Test/test_*.lua with the EMS repo root as the working directory, which is
-- exactly the condition a file-reading guard needs.
--
-- THE COUPLING, which is what keeps this file honest from over there: the SET A
-- guard asserts that EXPECTED_BIND_PRIORITY above is declared exactly once AND
-- that its value equals the literal every bind site in Engine/KeybindManager.lua
-- actually passes. Editing the constant here and nothing else therefore fails CI,
-- and so does flipping the source and not the constant. GROUP 8 below reads the
-- same constant, so all three move together or none of them does.

-- ===========================================================================
-- GROUP 9 -- entering-world restore (Engine:_RunEnteringWorldRestore)
-- ===========================================================================
--
-- NUMBERING NOTE: the "GROUP 9" named in the block above is the DELETED
-- six-site priority case, not this group. That number was free again, and
-- these cases are unrelated to it.
--
-- These drive the REAL Engine:_RunEnteringWorldRestore against stubs and
-- assert the SCENARIO a player reports rather than the mechanism that
-- delivers it: after a loading screen -- a /reload, or zoning into a delve or
-- a dungeon -- the sequence keybind still fires. ScanExisting and
-- RestoreSavedSequences are bootstrap-class and must run once per login;
-- LoadKeybinds is idempotent and must run on EVERY world load. Grouping all
-- three behind the same flag is what left a saved key visible in /gems while
-- the press did nothing (Discord 1537091347683745882).

-- True when Engine:_RunEnteringWorldRestore and every collaborator it touches
-- are present. Kept separate from the stub installer so a missing module
-- skips instead of erroring mid-install with the environment half-stubbed.
local function enteringWorldReady()
    return GRIPEMS.Engine
        and GRIPEMS.Engine._RunEnteringWorldRestore
        and GRIPEMS.Engine._ReapplyKeybindsAfterLoad
        and GRIPEMS.KeybindManager
        and GRIPEMS.MacroManager
        and GRIPEMS.OOCQueue
        and GRIPEMS.OOCQueue.Add
        and C_Timer
        and C_Timer.After
end

--- Stub every collaborator the entering-world restore path calls and return
--- (counters, undo). Counters record call counts plus the captured OOCQueue
--- entry and settle timer; the timer is captured rather than run so the suite
--- never leaves a real deferred rebuild behind. undo() restores everything,
--- including Engine._initialLoadComplete, and MUST be called BEFORE any
--- assertion so a failed eq still leaves the environment clean.
--- @param restricted boolean value OOCQueue.IsRestricted should report
--- @return table counters, function undo
local function stubEnteringWorld(restricted)
    local Engine = GRIPEMS.Engine
    local KM = GRIPEMS.KeybindManager
    local MM = GRIPEMS.MacroManager
    local OOC = GRIPEMS.OOCQueue

    local savedFlag = Engine._initialLoadComplete
    local savedScan = MM.ScanExisting
    local savedRestore = Engine.RestoreSavedSequences
    local savedLoad = KM.LoadKeybinds
    local savedSchedule = KM.ScheduleLoadKeybinds
    local savedIsRestricted = OOC.IsRestricted
    local savedAdd = OOC.Add
    local savedAfter = C_Timer.After

    local counters = { scan = 0, restore = 0, load = 0, schedule = 0 }

    MM.ScanExisting = function()
        counters.scan = counters.scan + 1
    end
    Engine.RestoreSavedSequences = function()
        counters.restore = counters.restore + 1
    end
    KM.LoadKeybinds = function()
        counters.load = counters.load + 1
    end
    KM.ScheduleLoadKeybinds = function()
        counters.schedule = counters.schedule + 1
    end
    OOC.IsRestricted = function()
        return restricted and true or false
    end
    OOC.Add = function(_, fn, opType, key)
        counters.queued = { fn = fn, opType = opType, key = key }
    end
    setApiGlobal(C_Timer, "After", function(delay, fn)
        counters.delay = delay
        counters.timer = fn
    end)

    local function undo()
        Engine._initialLoadComplete = savedFlag
        MM.ScanExisting = savedScan
        Engine.RestoreSavedSequences = savedRestore
        KM.LoadKeybinds = savedLoad
        KM.ScheduleLoadKeybinds = savedSchedule
        OOC.IsRestricted = savedIsRestricted
        OOC.Add = savedAdd
        setApiGlobal(C_Timer, "After", savedAfter)
    end

    return counters, undo
end

TS:Register(
    "KB matrix: entering-world restore bootstraps once and re-applies keybinds on every load",
    CATEGORY,
    function(self)
        if not enteringWorldReady() then
            self:Skip("Engine._RunEnteringWorldRestore or one of its collaborators is not available")
            return
        end
        local Engine = GRIPEMS.Engine
        local counters, undo = stubEnteringWorld(false)

        -- Call 1 is a fresh login: the flag is falsy, so bootstrap runs.
        Engine._initialLoadComplete = nil
        local ok1, err1 = pcall(function()
            Engine:_RunEnteringWorldRestore()
        end)
        local scan1, restore1, load1 = counters.scan, counters.restore, counters.load

        -- Call 2 is a zone change in the SAME session: the addon's Lua state did
        -- not reset, so the flag is still true. Bootstrap must stay skipped and
        -- the keybind push must happen anyway.
        local ok2, err2 = pcall(function()
            Engine:_RunEnteringWorldRestore()
        end)
        local scan2, restore2, load2 = counters.scan, counters.restore, counters.load

        undo()

        if not eq(self, true, ok1, "first world load must not error (" .. tostring(err1) .. ")") then
            return
        end
        if not eq(self, true, ok2, "second world load must not error (" .. tostring(err2) .. ")") then
            return
        end
        if not eq(self, 1, scan1, "call 1: ScanExisting invoked exactly once") then
            return
        end
        if not eq(self, 1, restore1, "call 1: RestoreSavedSequences invoked exactly once") then
            return
        end
        if not eq(self, 1, load1, "call 1: LoadKeybinds invoked exactly once") then
            return
        end
        if not eq(self, 1, scan2, "call 2: ScanExisting invoked ZERO further times") then
            return
        end
        if not eq(self, 1, restore2, "call 2: RestoreSavedSequences invoked ZERO further times") then
            return
        end
        if not eq(self, 2, load2, "call 2: LoadKeybinds invoked exactly once more (zone-change regression)") then
            return
        end
        self:Pass()
    end
)

TS:Register(
    "KB matrix: entering-world restore schedules a settle re-push that reaches ScheduleLoadKeybinds",
    CATEGORY,
    function(self)
        if not enteringWorldReady() then
            self:Skip("Engine._RunEnteringWorldRestore or one of its collaborators is not available")
            return
        end
        local Engine = GRIPEMS.Engine
        local counters, undo = stubEnteringWorld(false)

        -- Past bootstrap, so only the keybind half runs. C_Timer.After is stubbed
        -- to CAPTURE the callback rather than run it; the case then invokes it by
        -- hand, which is what the loading screen ending does in game.
        Engine._initialLoadComplete = true
        local ok, err = pcall(function()
            Engine:_RunEnteringWorldRestore()
        end)
        local delay, timer = counters.delay, counters.timer
        local scheduleBefore = counters.schedule
        if type(timer) == "function" then
            timer()
        end
        local scheduleAfter = counters.schedule

        undo()

        if not eq(self, true, ok, "settle scheduling must not error (" .. tostring(err) .. ")") then
            return
        end
        if not eq(self, "function", type(timer), "a settle callback was scheduled") then
            return
        end
        if not eq(self, 1.5, delay, "settle delay is KEYBIND_LOAD_SETTLE_SECONDS") then
            return
        end
        if not eq(self, 0, scheduleBefore, "ScheduleLoadKeybinds has not run before the settle fires") then
            return
        end
        if not eq(self, 1, scheduleAfter, "the settle callback reaches ScheduleLoadKeybinds") then
            return
        end
        self:Pass()
    end
)

TS:Register(
    "KB matrix: entering-world restore queues the keybind push instead of pushing inline while restricted",
    CATEGORY,
    function(self)
        local D = GRIPEMS.Defaults
        if not enteringWorldReady() or not D then
            self:Skip("Engine._RunEnteringWorldRestore or one of its collaborators is not available")
            return
        end
        local Engine = GRIPEMS.Engine
        local counters, undo = stubEnteringWorld(true)

        -- Restricted (an in-combat /reload): the push must not run inline. The
        -- queued closure is drained by hand the way PLAYER_REGEN_ENABLED,
        -- restriction lift or the periodic ticker drains it in game.
        Engine._initialLoadComplete = true
        local ok, err = pcall(function()
            Engine:_RunEnteringWorldRestore()
        end)
        local inlineLoads = counters.load
        local queued = counters.queued
        if queued and type(queued.fn) == "function" then
            queued.fn()
        end
        local drainedLoads = counters.load

        undo()

        if not eq(self, true, ok, "restricted path must not error (" .. tostring(err) .. ")") then
            return
        end
        if not eq(self, 0, inlineLoads, "restricted: LoadKeybinds is NOT called inline") then
            return
        end
        if not eq(self, "table", type(queued), "restricted: an entry was added to the OOC queue instead") then
            return
        end
        if not eq(self, "__enteringworld_loadkeybinds__", queued.key, "queued under the entering-world key") then
            return
        end
        if not eq(self, D.OOC_OP_GENERIC, queued.opType, "queued as a generic OOC op") then
            return
        end
        if not eq(self, 1, drainedLoads, "draining the queued entry performs the keybind push") then
            return
        end
        self:Pass()
    end
)
