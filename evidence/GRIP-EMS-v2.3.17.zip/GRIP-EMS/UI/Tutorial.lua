-- GRIP-EMS: Tutorial (Accessibility Tour)
-- Created: 2026-04-21
-- Updated: 2026-06-21
-- Patch: 12.0.7.68256 Midnight (Retail LIVE)
--
-- First-run walkthrough. Eight-step popover tour anchored to MainFrame
-- and SequenceEditor landmarks. Auto-starts once per account the first
-- time MainFrame shows and Settings.accessibility.tutorialSeen is false.
-- Re-runs on demand via /gems tour. Flag reset via /gems tour reset.
-- Palette-aware (UI:OnPaletteChanged) and reduce-motion-aware
-- (accessibility.reduceMotion). Every cross-module frame lookup is
-- pcall-wrapped; unresolved anchors fall back to MainFrame centered.

local ADDON_NAME, GRIPEMS = ...

GRIPEMS.Tutorial = {}
local T = GRIPEMS.Tutorial

GRIPEMS.UI = GRIPEMS.UI or {}
local UI = GRIPEMS.UI
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)
local C = UI.Colors

T._shown = false
T._stepIndex = 1
T._active = false
T._popover = nil
T._combatRetries = 0

local MAX_COMBAT_RETRIES = 3

-- Anchor helpers (closures run at Show time, never at file load).
local function mainFrame()
    return _G.GRIPEMS_MainFrame
end

local function seTabButton(name)
    local SE = GRIPEMS.SequenceEditor
    if not (SE and SE.tabButtons) then
        return nil
    end
    return SE.tabButtons[name]
end

local function resolveAnchor(fn)
    local ok, result = pcall(fn)
    if ok and result then
        return result
    end
    return mainFrame()
end

local function listAnchor()
    local mf = mainFrame()
    return (mf and (mf.leftPanel or mf.sequenceListFrame)) or mf
end

local function disableAnchor()
    local SE = GRIPEMS.SequenceEditor
    return SE and SE.disableBtn
end

local function importAnchor()
    local SE = GRIPEMS.SequenceEditor
    if SE and SE.importBtn then
        return SE.importBtn
    end
    local mf = mainFrame()
    return mf and mf.settingsBtn
end

local function settingsAnchor()
    local mf = mainFrame()
    return mf and mf.settingsBtn
end

-- Step table. 8 entries, order matters.
local TOUR_STEPS = {
    {
        key = "welcome",
        titleKey = "ACCESS_TOUR_WELCOME_TITLE",
        bodyKey = "ACCESS_TOUR_WELCOME_BODY",
        anchor = mainFrame,
        point = "CENTER",
        relativePoint = "CENTER",
        x = 0,
        y = 0,
    },
    {
        key = "sequence_list",
        titleKey = "ACCESS_TOUR_LIST_TITLE",
        bodyKey = "ACCESS_TOUR_LIST_BODY",
        anchor = listAnchor,
        point = "LEFT",
        relativePoint = "RIGHT",
        x = 12,
        y = 0,
    },
    {
        key = "tab_steps",
        titleKey = "ACCESS_TOUR_STEPS_TITLE",
        bodyKey = "ACCESS_TOUR_STEPS_BODY",
        anchor = function()
            return seTabButton("Steps")
        end,
        point = "TOPLEFT",
        relativePoint = "BOTTOMLEFT",
        x = 0,
        y = -6,
    },
    {
        key = "tab_macros",
        titleKey = "ACCESS_TOUR_MACROS_TITLE",
        bodyKey = "ACCESS_TOUR_MACROS_BODY",
        anchor = function()
            return seTabButton("Macros")
        end,
        point = "TOPLEFT",
        relativePoint = "BOTTOMLEFT",
        x = 0,
        y = -6,
    },
    {
        key = "tab_keybind",
        titleKey = "ACCESS_TOUR_KEYBIND_TITLE",
        bodyKey = "ACCESS_TOUR_KEYBIND_BODY",
        anchor = function()
            return seTabButton("Keybind")
        end,
        point = "TOPLEFT",
        relativePoint = "BOTTOMLEFT",
        x = 0,
        y = -6,
    },
    {
        key = "test_disable",
        titleKey = "ACCESS_TOUR_TEST_TITLE",
        bodyKey = "ACCESS_TOUR_TEST_BODY",
        anchor = disableAnchor,
        point = "TOP",
        relativePoint = "BOTTOM",
        x = 0,
        y = -6,
    },
    {
        key = "import",
        titleKey = "ACCESS_TOUR_IMPORT_TITLE",
        bodyKey = "ACCESS_TOUR_IMPORT_BODY",
        anchor = importAnchor,
        point = "TOP",
        relativePoint = "BOTTOM",
        x = 0,
        y = -6,
    },
    {
        key = "done",
        titleKey = "ACCESS_TOUR_DONE_TITLE",
        bodyKey = "ACCESS_TOUR_DONE_BODY",
        anchor = settingsAnchor,
        point = "TOP",
        relativePoint = "BOTTOM",
        x = 0,
        y = -6,
    },
}

-- Palette: mutate in place via SetRGBA so HighContrast and DeuteranopiaSafe
-- recolour without a reload.
local function applyPalette(p)
    if not p then
        return
    end
    local bg = C.bgDeep or C.bgRowSelected or C.bgMain
    if p.SetBackdropColor and bg then
        p:SetBackdropColor(bg:GetRGBA())
    end
    if p.SetBackdropBorderColor and C.border then
        p:SetBackdropBorderColor(C.border:GetRGBA())
    end
    if p.title and C.textPrimary then
        p.title:SetTextColor(C.textPrimary:GetRGBA())
    end
    if p.body and C.textPrimary then
        p.body:SetTextColor(C.textPrimary:GetRGBA())
    end
end

local function reduceMotion()
    local S = GRIPEMS.Settings
    if not (S and S.Get) then
        return false
    end
    local a = S:Get("accessibility")
    return type(a) == "table" and a.reduceMotion and true or false
end

local function buildPopover()
    if T._popover then
        return T._popover
    end
    local p = CreateFrame("Frame", "GRIPEMS_TutorialPopover", UIParent, "BackdropTemplate")
    p:SetFrameStrata("TOOLTIP")
    p:SetFrameLevel(101)
    p:SetSize(320, 180)
    p:SetClampedToScreen(true)
    p:EnableMouse(true)
    p:Hide()
    if not tContains(UISpecialFrames, "GRIPEMS_TutorialPopover") then
        tinsert(UISpecialFrames, "GRIPEMS_TutorialPopover")
    end
    UI:ApplyBackdrop(p, UI.Backdrops.panel, C.bgDeep or C.bgRowSelected, C.border)

    local title = p:CreateFontString(nil, "OVERLAY")
    UI:SetFont(title, 14, "OUTLINE")
    title:SetPoint("TOPLEFT", p, "TOPLEFT", 12, -12)
    title:SetPoint("TOPRIGHT", p, "TOPRIGHT", -32, -12)
    title:SetJustifyH("LEFT")
    title:SetTextColor(C.textPrimary:GetRGBA())
    p.title = title

    local body = p:CreateFontString(nil, "OVERLAY")
    UI:SetFont(body, 12)
    body:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -8)
    body:SetWidth(280)
    body:SetJustifyH("LEFT")
    body:SetJustifyV("TOP")
    body:SetWordWrap(true)
    body:SetNonSpaceWrap(true)
    body:SetTextColor(C.textPrimary:GetRGBA())
    p.body = body

    local closeX = CreateFrame("Button", nil, p, "UIPanelCloseButton")
    closeX:SetPoint("TOPRIGHT", p, "TOPRIGHT", -2, -2)
    closeX:SetScript("OnClick", function()
        T:Stop(true)
    end)
    p.closeX = closeX

    local backBtn = UI:CreateButton(p, L["ACCESS_TOUR_BACK"], 70, 22)
    backBtn:SetPoint("BOTTOMLEFT", p, "BOTTOMLEFT", 10, 10)
    backBtn:SetScript("OnClick", function()
        T:Back()
    end)
    p.backBtn = backBtn

    local skipBtn = UI:CreateButton(p, L["ACCESS_TOUR_SKIP"], 60, 22)
    skipBtn:SetPoint("BOTTOM", p, "BOTTOM", 0, 10)
    skipBtn:SetScript("OnClick", function()
        T:Stop(true)
    end)
    p.skipBtn = skipBtn

    local nextBtn = UI:CreateButton(p, L["ACCESS_TOUR_NEXT"], 70, 22)
    nextBtn:SetPoint("BOTTOMRIGHT", p, "BOTTOMRIGHT", -10, 10)
    nextBtn:SetScript("OnClick", function()
        T:Next()
    end)
    p.nextBtn = nextBtn

    p:EnableKeyboard(true)
    p:SetScript("OnKeyDown", function(self, key)
        local Focus = GRIPEMS.Focus
        if key == "ESCAPE" then
            T:Stop(true)
            pcall(self.SetPropagateKeyboardInput, self, false)
            return
        elseif key == "ENTER" or key == "SPACE" then
            if Focus then
                Focus:Activate()
            end
            pcall(self.SetPropagateKeyboardInput, self, false)
            return
        elseif key == "TAB" and Focus then
            Focus:Cycle(IsShiftKeyDown() and -1 or 1)
            pcall(self.SetPropagateKeyboardInput, self, false)
            return
        end
        pcall(self.SetPropagateKeyboardInput, self, true)
    end)

    p:SetScript("OnHide", function()
        T._active = false
        local Focus = GRIPEMS.Focus
        if Focus and Focus.PopContext then
            pcall(function()
                Focus:PopContext("Tutorial")
            end)
        end
        local S = GRIPEMS.Settings
        if S and S.Get and S.Set then
            local a = S:Get("accessibility") or {}
            a.tutorialSeen = true
            S:Set("accessibility", a)
        end
    end)

    if UI.OnPaletteChanged then
        UI:OnPaletteChanged(function()
            if T._popover then
                applyPalette(T._popover)
            end
        end)
    end

    T._popover = p
    return p
end

local function anchorPopover(p, step)
    p:ClearAllPoints()
    local anchor = resolveAnchor(step.anchor)
    if anchor then
        p:SetPoint(step.point or "CENTER", anchor, step.relativePoint or "CENTER", step.x or 0, step.y or 0)
    else
        p:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    end
end

local function showWithMotion(p)
    local target = (GRIPEMS.UI and GRIPEMS.UI.GetOverlayAlpha and GRIPEMS.UI:GetOverlayAlpha()) or 1.0
    p:SetAlpha(0)
    p:Show()
    if reduceMotion() then
        p:SetAlpha(target)
        return
    end
    if type(UIFrameFadeIn) == "function" then
        UIFrameFadeIn(p, 0.12, 0, target)
    else
        p:SetAlpha(target)
    end
end

local function isLastStep()
    return T._stepIndex >= #TOUR_STEPS
end

local function renderStep()
    local p = T._popover
    if not p then
        return
    end
    local step = TOUR_STEPS[T._stepIndex]
    if not step then
        T:Stop(true)
        return
    end
    p.title:SetText(L[step.titleKey] or "")
    p.body:SetText(L[step.bodyKey] or "")
    anchorPopover(p, step)

    if T._stepIndex == 1 then
        if p.backBtn.Disable then
            p.backBtn:Disable()
        end
        p.backBtn:SetAlpha(0.4)
    else
        if p.backBtn.Enable then
            p.backBtn:Enable()
        end
        p.backBtn:SetAlpha(1.0)
    end

    if p.nextBtn.label then
        if isLastStep() then
            p.nextBtn.label:SetText(L["ACCESS_TOUR_DONE"] or "Done")
        else
            p.nextBtn.label:SetText(L["ACCESS_TOUR_NEXT"] or "Next")
        end
    end

    applyPalette(p)
end

--- Start the tour if preconditions are met. Called from MainFrame OnShow.
function T:MaybeStart()
    if T._shown then
        return
    end
    -- Never auto-start over a test-initiated window open: the suite
    -- bootstraps and closes the frame and must stay side-effect free. The
    -- flag holds for the whole TestSuite run, so every spec that toggles
    -- the window is covered. A real first open still starts the tour.
    if GRIPEMS.TestSuite and GRIPEMS.TestSuite._running then
        return
    end
    local inCombat = false
    pcall(function()
        inCombat = InCombatLockdown and InCombatLockdown() or false
    end)
    if inCombat then
        if T._combatRetries < MAX_COMBAT_RETRIES then
            T._combatRetries = T._combatRetries + 1
            if type(C_Timer) == "table" and C_Timer.After then
                C_Timer.After(0.3, function()
                    T:MaybeStart()
                end)
            end
        end
        return
    end
    local S = GRIPEMS.Settings
    if not (S and S.Get) then
        return
    end
    local a = S:Get("accessibility")
    if type(a) ~= "table" then
        return
    end
    if a.tutorialSeen then
        return
    end
    if not mainFrame() then
        return
    end
    T._shown = true
    T:Start()
end

--- Show the popover starting at step 1.
function T:Start()
    if not mainFrame() then
        return
    end
    local p = buildPopover()
    T._stepIndex = 1
    T._active = true
    renderStep()
    local Focus = GRIPEMS.Focus
    if Focus and Focus.PushContext then
        pcall(function()
            Focus:PushContext("Tutorial", { p.backBtn, p.skipBtn, p.nextBtn })
        end)
    end
    showWithMotion(p)
end

--- Hide the popover. If persist is true, flip tutorialSeen to true.
--- @param persist boolean
function T:Stop(persist)
    T._active = false
    local p = T._popover
    if p then
        p:Hide()
    end
    local Focus = GRIPEMS.Focus
    if Focus and Focus.PopContext then
        pcall(function()
            Focus:PopContext("Tutorial")
        end)
    end
    if persist then
        local S = GRIPEMS.Settings
        if S and S.Get and S.Set then
            local a = S:Get("accessibility") or {}
            a.tutorialSeen = true
            S:Set("accessibility", a)
        end
    end
end

--- Advance to the next step. Closes if past the last step.
function T:Next()
    if not T._active then
        return
    end
    T._stepIndex = T._stepIndex + 1
    if T._stepIndex > #TOUR_STEPS then
        T:Stop(true)
        return
    end
    renderStep()
end

--- Step back. Clamped at step 1.
function T:Back()
    if not T._active then
        return
    end
    if T._stepIndex <= 1 then
        return
    end
    T._stepIndex = T._stepIndex - 1
    renderStep()
end

--- Clear the tutorialSeen flag so the tour runs again on next login.
--- Invoked by /gems tour reset.
function T:Reset()
    local S = GRIPEMS.Settings
    if S and S.Get and S.Set then
        local a = S:Get("accessibility") or {}
        a.tutorialSeen = false
        S:Set("accessibility", a)
    end
    T._shown = false
    T._combatRetries = 0
    if GRIPEMS.Print then
        GRIPEMS:Print(L["ACCESS_TOUR_RESET_TOAST"] or "Tutorial reset.")
    end
end
