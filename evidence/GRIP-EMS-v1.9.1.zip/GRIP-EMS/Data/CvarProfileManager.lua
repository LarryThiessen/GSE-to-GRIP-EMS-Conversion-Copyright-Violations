-- GRIP-EMS: CVar Profile Manager
-- Context-aware CVar profile switching with OOC-safe application.
-- Phase 2 of CVar Health Dashboard.

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS")
local D = GRIPEMS.Defaults

GRIPEMS.CvarProfileManager = {}
local CPM = GRIPEMS.CvarProfileManager

-- Pending What Changed entries (cleared on dismiss)
CPM.pendingChanges = nil

--------------------------------------------------------------------------------
-- Utility
--------------------------------------------------------------------------------

--- Check if a CVar is flagged as secure by the client.
--- Uses C_CVar.GetCVarInfo (12.0+) with pcall for safety.
--- GetCVarInfo returns 7 positional values (not a table):
---   1=value(string), 2=defaultValue(string), 3=bool, 4=bool,
---   5=isSecure(bool), 6=bool, 7=bool.
--- @param cvarName string
--- @return boolean
function CPM.IsCVarSecure(cvarName)
    if not (C_CVar and C_CVar.GetCVarInfo) then return false end
    local ok, _, _, _, _, isSecure = pcall(C_CVar.GetCVarInfo, cvarName)
    if ok then return isSecure or false end
    return false
end

--- Look up the General (Phase 1) recommended value for a CVar.
--- @param cvarName string
--- @return string|nil recommended value
function CPM:GetGeneralRecommendation(cvarName)
    for _, section in ipairs(D.CVAR_SECTIONS) do
        for _, rec in ipairs(section.cvars) do
            if rec.cvar == cvarName then
                return rec.recommended
            end
        end
    end
    return nil
end

--- Get the effective recommendation for a CVar (profile override or General).
--- @param cvarName string
--- @return string|nil recommended value
function CPM:GetEffectiveRecommendation(cvarName)
    if cvarName == "SpellQueueWindow" then
        local SQWO = GRIPEMS.SQWOptimizer
        if SQWO and SQWO:IsActive() and SQWO.lastAppliedSQW then
            return tostring(SQWO.lastAppliedSQW)
        end
    end
    -- Hold Mode: when active, hold CVars are managed by HoldModeManager
    local TA = GRIPEMS.TempoAdvisor
    if TA and TA.HoldModeManager and TA.HoldModeManager.active then
        if cvarName == "ActionButtonUseKeyHeldSpell" then
            return "1"
        elseif cvarName == "UseKeyHeldSpellErrorPollTime" then
            return tostring(TA:GetHoldModePollRate())
        end
    end
    local S = GRIPEMS.Settings
    if S then
        local activeKey = S:Get("cvarActiveProfile")
        local profile = self:GetProfile(activeKey)
        if profile and profile.overrides and profile.overrides[cvarName] ~= nil then
            return profile.overrides[cvarName]
        end
    end
    return self:GetGeneralRecommendation(cvarName)
end

--------------------------------------------------------------------------------
-- Profile Lookup
--------------------------------------------------------------------------------

--- Look up a profile definition by key.
--- Checks built-in profiles first, then custom profiles in SavedVariables.
--- @param profileKey string|nil
--- @return table|nil profile {key, label, desc, icon, overrides}
function CPM:GetProfile(profileKey)
    if not profileKey then
        return nil
    end

    for _, p in ipairs(D.CVAR_PROFILES) do
        if p.key == profileKey then
            return p
        end
    end

    local S = GRIPEMS.Settings
    local custom = S and S:Get("cvarProfiles") or {}
    if custom[profileKey] then
        return custom[profileKey]
    end

    return nil
end

--- Resolve which profile key applies for a given context key.
--- Checks user overrides first, then built-in map, then context fallback chain.
--- @param contextKey string
--- @return string|nil profileKey (nil = General)
function CPM:ResolveProfile(contextKey)
    local S = GRIPEMS.Settings
    if not S then
        return nil
    end

    -- User override map takes priority
    local userMap = S:Get("cvarProfileMap") or {}
    if userMap[contextKey] then
        return userMap[contextKey]
    end

    -- Built-in map
    if D.CVAR_PROFILE_MAP[contextKey] then
        return D.CVAR_PROFILE_MAP[contextKey]
    end

    -- Walk the fallback chain (reuses existing CONTEXT_FALLBACKS)
    local chain = D.CONTEXT_FALLBACKS and D.CONTEXT_FALLBACKS[contextKey]
    if chain then
        for _, fallback in ipairs(chain) do
            if userMap[fallback] then
                return userMap[fallback]
            end
            if D.CVAR_PROFILE_MAP[fallback] then
                return D.CVAR_PROFILE_MAP[fallback]
            end
        end
    end

    return nil -- General (no profile)
end

--------------------------------------------------------------------------------
-- Profile Application
--------------------------------------------------------------------------------

--- Apply a profile: set override CVars, revert previous profile's CVars to General.
--- Combat-safe: secure CVars queue via OOCQueue.
--- @param profileKey string|nil Profile key to apply, nil = revert to General
function CPM:ApplyProfile(profileKey)
    local S = GRIPEMS.Settings
    if not S then
        return
    end

    local oldKey = S:Get("cvarActiveProfile")
    local oldProfile = self:GetProfile(oldKey)
    local newProfile = self:GetProfile(profileKey)

    -- Collect CVars to change: union of old overrides (revert) and new overrides (apply)
    local changes = {}

    -- Step 1: Revert old profile overrides to General recommendations
    if oldProfile and oldProfile.overrides then
        for cvar, _ in pairs(oldProfile.overrides) do
            local generalRec = self:GetGeneralRecommendation(cvar)
            if generalRec then
                changes[cvar] = generalRec
            end
        end
    end

    -- Step 2: Apply new profile overrides (overwrites any revert from Step 1)
    if newProfile and newProfile.overrides then
        for cvar, val in pairs(newProfile.overrides) do
            changes[cvar] = val
        end
    end

    -- Step 3: Apply changes (combat-safe)
    local applied, queued = 0, 0
    for cvar, val in pairs(changes) do
        -- SQW Optimizer takes priority over profiles for SpellQueueWindow
        if not (cvar == "SpellQueueWindow" and GRIPEMS.SQWOptimizer and GRIPEMS.SQWOptimizer:IsActive()) then
            local current = GetCVar(cvar)
            if current and not D.CvarMatch(current, val) then
                if CPM.IsCVarSecure(cvar) and InCombatLockdown() then
                    -- Queue secure CVars for OOC application
                    GRIPEMS.OOCQueue:Add(function()
                        SetCVar(cvar, val)
                    end, "cvar_profile", cvar)
                    queued = queued + 1
                else
                    SetCVar(cvar, val)
                    applied = applied + 1
                end
            end
        end -- SQW optimizer skip guard
    end

    -- Update state
    S:Set("cvarActiveProfile", profileKey)

    -- Fire callback for UI refresh
    if GRIPEMS.Fire then
        GRIPEMS:Fire("CVAR_PROFILE_CHANGED", profileKey, oldKey)
    end

    -- Logging
    local label = newProfile and newProfile.label or L["GEMS_CVAR_PROFILE_GENERAL"]
    if applied > 0 or queued > 0 then
        GRIPEMS:Debug(string.format("CVar profile: %s (%d applied, %d queued)", tostring(label), applied, queued))
    end
    if queued > 0 then
        GRIPEMS:Print(string.format(L["GEMS_CVAR_PROFILE_QUEUED"], queued))
    end
end

--- Manually select a profile. Sets manual override flag.
--- @param profileKey string|nil Profile key, nil = General
function CPM:SetManualProfile(profileKey)
    local S = GRIPEMS.Settings
    if not S then
        return
    end

    S:Set("cvarManualOverride", true)
    self:ApplyProfile(profileKey)

    local profile = self:GetProfile(profileKey)
    local label = profile and profile.label or L["GEMS_CVAR_PROFILE_GENERAL"]
    GRIPEMS:Print(string.format(L["GEMS_CVAR_PROFILE_SWITCHED"], tostring(label)))
end

--- Clear manual override and re-evaluate current context.
function CPM:ClearManualOverride()
    local S = GRIPEMS.Settings
    if not S then
        return
    end

    S:Set("cvarManualOverride", false)

    -- Re-evaluate context if auto-switch is on
    if S:Get("cvarAutoSwitchEnabled") and GRIPEMS.Engine then
        local ctx = GRIPEMS.Engine.currentContext
        if ctx then
            local profileKey = self:ResolveProfile(ctx)
            local currentKey = S:Get("cvarActiveProfile")
            if profileKey ~= currentKey then
                self:ApplyProfile(profileKey)
            end
        end
    end
end

--------------------------------------------------------------------------------
-- Custom Profile CRUD
--------------------------------------------------------------------------------

--- Create a custom profile.
--- @param label string Display name for the profile
--- @param cloneFrom string|nil Profile key to clone overrides from
--- @return string|nil key The generated profile key, or nil on failure
function CPM:CreateProfile(label, cloneFrom)
    local S = GRIPEMS.Settings
    if not S or not label or label == "" then
        return nil
    end

    -- Generate key: custom_ + sanitized lowercase alphanumeric (max 32 chars)
    local sanitized = label:lower():gsub("[^%a%d]", "")
    if sanitized == "" then
        sanitized = "profile"
    end
    sanitized = sanitized:sub(1, 32)
    local baseKey = "custom_" .. sanitized

    -- Dedup: append _N if key exists
    local custom = S:Get("cvarProfiles") or {}
    local key = baseKey
    local n = 1
    while custom[key] do
        key = baseKey .. "_" .. n
        n = n + 1
    end

    -- Clone overrides from source profile if provided
    local overrides = {}
    if cloneFrom then
        local source = self:GetProfile(cloneFrom)
        if source and source.overrides then
            for cvar, val in pairs(source.overrides) do
                overrides[cvar] = val
            end
        end
    end

    -- Store in cvarProfiles
    custom[key] = { key = key, label = label, overrides = overrides }
    S:Set("cvarProfiles", custom)

    if GRIPEMS.Fire then
        GRIPEMS:Fire("CVAR_PROFILE_CHANGED", key)
    end

    return key
end

--- Delete a custom profile.
--- @param profileKey string Must start with "custom_"
function CPM:DeleteProfile(profileKey)
    local S = GRIPEMS.Settings
    if not S or not profileKey then
        return
    end

    -- Guard: only custom profiles can be deleted
    if profileKey:sub(1, 7) ~= "custom_" then
        return
    end

    -- If this is the active profile, revert to General first
    if S:Get("cvarActiveProfile") == profileKey then
        self:ApplyProfile(nil)
    end

    -- Remove from cvarProfiles
    local custom = S:Get("cvarProfiles") or {}
    custom[profileKey] = nil
    S:Set("cvarProfiles", custom)

    -- Clean up cvarProfileMap (remove any context mappings referencing this key)
    local profileMap = S:Get("cvarProfileMap") or {}
    local changed = false
    for ctx, pk in pairs(profileMap) do
        if pk == profileKey then
            profileMap[ctx] = nil
            changed = true
        end
    end
    if changed then
        S:Set("cvarProfileMap", profileMap)
    end

    if GRIPEMS.Fire then
        GRIPEMS:Fire("CVAR_PROFILE_CHANGED", nil, profileKey)
    end
end

--- Rename a custom profile (label only, key is immutable).
--- @param profileKey string Must start with "custom_"
--- @param newLabel string New display name
function CPM:RenameProfile(profileKey, newLabel)
    local S = GRIPEMS.Settings
    if not S or not profileKey or not newLabel or newLabel == "" then
        return
    end

    if profileKey:sub(1, 7) ~= "custom_" then
        return
    end

    local custom = S:Get("cvarProfiles") or {}
    if not custom[profileKey] then
        return
    end

    custom[profileKey].label = newLabel
    S:Set("cvarProfiles", custom)

    if GRIPEMS.Fire then
        GRIPEMS:Fire("CVAR_PROFILE_CHANGED", profileKey)
    end
end

--- Set or remove an override value on a custom profile.
--- @param profileKey string Must start with "custom_"
--- @param cvarName string CVar name
--- @param value string|nil Value to set, nil removes the override
function CPM:SetProfileOverride(profileKey, cvarName, value)
    local S = GRIPEMS.Settings
    if not S or not profileKey or not cvarName then
        return
    end

    if profileKey:sub(1, 7) ~= "custom_" then
        return
    end

    local custom = S:Get("cvarProfiles") or {}
    if not custom[profileKey] then
        return
    end

    if not custom[profileKey].overrides then
        custom[profileKey].overrides = {}
    end

    if value == nil then
        custom[profileKey].overrides[cvarName] = nil
    else
        custom[profileKey].overrides[cvarName] = tostring(value)
    end
    S:Set("cvarProfiles", custom)

    -- If this profile is currently active, re-apply
    if S:Get("cvarActiveProfile") == profileKey then
        self:ApplyProfile(profileKey)
    end
end

--------------------------------------------------------------------------------
-- Context Profile Map
--------------------------------------------------------------------------------

--- Set or clear a user override in the context-to-profile map.
--- @param contextKey string Context key (e.g. "Raid", "MythicPlus")
--- @param profileKey string|nil Profile key, nil clears the override
function CPM:SetContextMapping(contextKey, profileKey)
    local S = GRIPEMS.Settings
    if not S or not contextKey then
        return
    end

    local profileMap = S:Get("cvarProfileMap") or {}
    profileMap[contextKey] = profileKey
    S:Set("cvarProfileMap", profileMap)

    -- If this context is currently active and auto-switch is on, re-evaluate
    if S:Get("cvarAutoSwitchEnabled") and not S:Get("cvarManualOverride") then
        local Engine = GRIPEMS.Engine
        if Engine and Engine.currentContext == contextKey then
            local resolved = self:ResolveProfile(contextKey)
            local currentKey = S:Get("cvarActiveProfile")
            if resolved ~= currentKey then
                self:ApplyProfile(resolved)
            end
        end
    end
end

--------------------------------------------------------------------------------
-- Slash Command Handler
--------------------------------------------------------------------------------

--- Handle /gems cvar subcommands.
--- @param args string Arguments after "cvar"
function CPM:HandleSlashCommand(args)
    local sub, rest = (args or ""):match("^(%S+)%s*(.*)")
    sub = sub and sub:lower() or ""

    if sub == "profile" then
        local key = rest and rest:match("^%S+") or nil
        if not key or key == "general" then
            self:SetManualProfile(nil)
        else
            local profile = self:GetProfile(key)
            if profile then
                self:SetManualProfile(key)
            else
                GRIPEMS:Print(string.format(L["GEMS_CVAR_PROFILE_NOT_FOUND"], tostring(key)))
            end
        end
    elseif sub == "auto" then
        local S = GRIPEMS.Settings
        if S then
            local enabled = not S:Get("cvarAutoSwitchEnabled")
            S:Set("cvarAutoSwitchEnabled", enabled)
            if enabled then
                self:ClearManualOverride()
            end
            local state = enabled and "ON" or "OFF"
            GRIPEMS:Print(string.format(L["GEMS_CVAR_AUTO_TOGGLED"], state))
        end
    elseif sub == "changes" then
        if self.pendingChanges and #self.pendingChanges > 0 then
            for _, c in ipairs(self.pendingChanges) do
                local arrow = c.was .. " -> " .. (c.now or "?")
                GRIPEMS:Print(tostring(c.label) .. ": " .. arrow)
            end
        else
            GRIPEMS:Print(L["GEMS_CVAR_NO_CHANGES"])
        end
    else
        GRIPEMS:Print("Usage: /gems cvar profile [key|general]")
        GRIPEMS:Print("       /gems cvar auto")
        GRIPEMS:Print("       /gems cvar changes")
    end
end

--------------------------------------------------------------------------------
-- Context-Aware Auto-Switching
--------------------------------------------------------------------------------

--- Initialize the CVar Profile Manager.
--- Registers CONTEXT_CHANGED callback for auto-switching.
function CPM:Initialize()
    if GRIPEMS.RegisterCallback then
        GRIPEMS.RegisterCallback(self, "CONTEXT_CHANGED", "OnContextChanged")
    end
end

--- Handle context change: resolve and apply the appropriate profile.
--- Respects manual override and auto-switch toggle.
--- @param event string callback event name ("CONTEXT_CHANGED")
--- @param newContext string
--- @param oldContext string|nil
function CPM:OnContextChanged(event, newContext, oldContext)
    local S = GRIPEMS.Settings
    if not S then
        return
    end

    -- If auto-switching is disabled, do nothing
    if not S:Get("cvarAutoSwitchEnabled") then
        return
    end

    -- If user manually selected a profile, respect it
    if S:Get("cvarManualOverride") then
        return
    end

    local newProfileKey = self:ResolveProfile(newContext)
    local currentKey = S:Get("cvarActiveProfile")

    if newProfileKey == currentKey then
        return
    end

    self:ApplyProfile(newProfileKey)
end

--------------------------------------------------------------------------------
-- What Changed Detection
--------------------------------------------------------------------------------

--- Detect CVar changes since last session and take a new snapshot.
--- Called from Core.lua PLAYER_LOGIN handler (runs always, not gated behind
--- autoFixCVars, so What Changed detection works regardless of auto-fix setting).
function CPM:DetectChanges()
    local S = GRIPEMS.Settings
    if not S then
        return
    end

    local snapshot = S:Get("cvarSnapshot") or {}
    local changes = {}
    local newSnapshot = {}

    for _, section in ipairs(D.CVAR_SECTIONS) do
        for _, rec in ipairs(section.cvars) do
            local current = GetCVar(rec.cvar)
            newSnapshot[rec.cvar] = current

            if snapshot[rec.cvar] and snapshot[rec.cvar] ~= current then
                table.insert(changes, {
                    cvar = rec.cvar,
                    label = rec.label,
                    section = section.label,
                    was = snapshot[rec.cvar],
                    now = current,
                    recommended = rec.recommended,
                    critical = rec.critical,
                })
            end
        end
    end

    -- Always save a fresh snapshot
    S:Set("cvarSnapshot", newSnapshot)

    if #changes > 0 then
        self.pendingChanges = changes
        if GRIPEMS.Fire then
            GRIPEMS:Fire("CVAR_CHANGES_DETECTED", changes)
        end
        GRIPEMS:Print(string.format(L["GEMS_CVAR_CHANGES_DETECTED"], #changes))
    end
end
