-- GRIP-EMS: MinimapButton
-- Created: 2026-03-18
-- Updated: 2026-06-21
-- Patch: 12.0.7.68256 Midnight (Retail LIVE)

-- GRIP-EMS: Minimap Button
-- LibDataBroker launcher + LibDBIcon minimap button registration

local ADDON_NAME, GRIPEMS = ...
local UI = GRIPEMS.UI
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

local LDB = LibStub("LibDataBroker-1.1", true)
local LDBIcon = LibStub("LibDBIcon-1.0", true)
local QTip = LibStub("LibQTip-2.0", true)

if not LDB or not LDBIcon then
    GRIPEMS:Debug("LibDataBroker or LibDBIcon not found, minimap button disabled.")
    return
end

local tooltip = nil

---------------------------------------------------------------------------
-- GameTooltip fallback (used when LibQTip is not available)
---------------------------------------------------------------------------
local function ShowFallbackTooltip(frame)
    GameTooltip:SetOwner(frame, "ANCHOR_NONE")
    GameTooltip:SetPoint("TOPRIGHT", frame, "BOTTOMRIGHT")
    GameTooltip:AddDoubleLine("|cFF00CC66GRIP|r-EMS", "v" .. (GRIPEMS.version or "dev"), 1, 1, 1, 0.6, 0.6, 0.6)
    GameTooltip:AddLine(" ")
    local count = 0
    if GRIPEMS.Engine and GRIPEMS.Engine.GetActiveCount then
        count = GRIPEMS.Engine:GetActiveCount()
    end
    GameTooltip:AddDoubleLine(L["GEMS_UI_ACTIVE_SEQUENCES_LABEL"], tostring(count), 0.8, 0.8, 0.8, 0, 0.8, 0.4)
    if GRIPEMS.Engine and GRIPEMS.Engine.currentContext then
        GameTooltip:AddDoubleLine(L["GEMS_UI_CONTEXT_LABEL"], GRIPEMS.Engine.currentContext, 0.8, 0.8, 0.8, 0, 0.8, 0.4)
    end
    GameTooltip:AddLine(" ")
    GameTooltip:AddLine(L["GEMS_UI_MINIMAP_LEFT"], 0.5, 0.5, 0.5)
    GameTooltip:AddLine(L["GEMS_UI_MINIMAP_RIGHT"], 0.5, 0.5, 0.5)
    GameTooltip:Show()
end

---------------------------------------------------------------------------
-- LibQTip rich tooltip
---------------------------------------------------------------------------
local function ShowQTipTooltip(frame)
    if tooltip then
        QTip:ReleaseTooltip(tooltip)
        tooltip = nil
    end

    tooltip = QTip:AcquireTooltip("GRIPEMS_MinimapTip", 2)

    -- Header
    tooltip:AddHeadingRow("|cFF00CC66GRIP|r-EMS", "v" .. (GRIPEMS.version or "dev"))

    tooltip:AddSeparator()

    -- Active sequences
    local count = GRIPEMS.Engine and GRIPEMS.Engine.GetActiveCount and GRIPEMS.Engine:GetActiveCount() or 0
    local row = tooltip:AddRow(L["GEMS_UI_ACTIVE_SEQUENCES_LABEL"], tostring(count))
    local cell = row:GetCell(2)
    if cell then
        cell:SetTextColor(0, 0.8, 0.4, 1)
    end

    -- Active context
    if GRIPEMS.Engine and GRIPEMS.Engine.currentContext then
        row = tooltip:AddRow(L["GEMS_UI_CONTEXT_LABEL"], GRIPEMS.Engine.currentContext)
        cell = row:GetCell(2)
        if cell then
            cell:SetTextColor(0, 0.8, 0.4, 1)
        end
    end

    -- OOC queue
    local oocCount = GRIPEMS.OOCQueue and GRIPEMS.OOCQueue.GetCount and GRIPEMS.OOCQueue:GetCount() or 0
    row = tooltip:AddRow(L["GEMS_UI_MINIMAP_OOC_QUEUE"], string.format(L["GEMS_UI_MINIMAP_OOC_PENDING"], oocCount))
    cell = row:GetCell(2)
    if cell then
        if oocCount > 0 then
            cell:SetTextColor(1, 0.8, 0, 1)
        else
            cell:SetTextColor(0, 0.8, 0.4, 1)
        end
    end

    tooltip:AddSeparator()

    -- Party EMS users
    local T = GRIPEMS.Transmission
    if T and T.GetKnownUsers then
        local users = T:GetKnownUsers()
        local hasUsers = false
        for sender, info in pairs(users) do
            if not hasUsers then
                row = tooltip:AddRow(L["GEMS_UI_MINIMAP_PARTY_USERS"])
                cell = row:GetCell(1)
                if cell then
                    cell:SetTextColor(1, 0.84, 0, 1)
                end
                hasUsers = true
            end
            tooltip:AddRow(sender, info.version or "?")
        end
        if not hasUsers then
            tooltip:AddRow(L["GEMS_UI_MINIMAP_PARTY_USERS"], L["GEMS_UI_MINIMAP_PARTY_NONE"])
        end
    end

    tooltip:AddSeparator()

    -- Hint rows
    row = tooltip:AddRow(L["GEMS_UI_MINIMAP_LEFT"])
    row:SetTextColor(0.5, 0.5, 0.5, 1)

    row = tooltip:AddRow(L["GEMS_UI_MINIMAP_RIGHT"])
    row:SetTextColor(0.5, 0.5, 0.5, 1)

    tooltip:SmartAnchorTo(frame)
    tooltip:Show()
end

---------------------------------------------------------------------------
-- Broker object
---------------------------------------------------------------------------
local broker = LDB:NewDataObject("GRIP-EMS", {
    type = "launcher",
    text = "GRIP-EMS",
    icon = "Interface\\Icons\\Ability_Rogue_MasterOfSubtlety",
    OnClick = function(self, button)
        if button == "LeftButton" then
            UI:ToggleMainFrame()
        elseif button == "RightButton" then
            GRIPEMS:Print(L["GEMS_UI_MINIMAP_RIGHTCLICK_SOON"])
        end
    end,
    OnEnter = function(self)
        if QTip then
            ShowQTipTooltip(self)
        else
            ShowFallbackTooltip(self)
        end
    end,
    OnLeave = function(self)
        if tooltip then
            QTip:ReleaseTooltip(tooltip)
            tooltip = nil
        else
            GameTooltip:Hide()
        end
    end,
})

---------------------------------------------------------------------------
-- Registration (called from Core.lua ADDON_LOADED)
---------------------------------------------------------------------------

--- Initialize the minimap button using LibDBIcon.
--- Uses GRIP_EMS_DB.minimapButton for hide/show persistence.
function UI:InitMinimapButton()
    if not GRIP_EMS_DB then
        return
    end
    if not GRIP_EMS_DB.minimapButton then
        GRIP_EMS_DB.minimapButton = { hide = false }
    end
    LDBIcon:Register("GRIP-EMS", broker, GRIP_EMS_DB.minimapButton)
end
