-- GRIP-EMS: Headless test for reset-path tracker repaint
--
-- Created:    2026-08-02
-- Updated:    2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.
--
-- Guards COMBAT-RESET-DOES-NOT-MATCH-HUD-TRACKER-DISPLAY. The five Lua-side
-- reset paths (Engine:ResetStep plus the four event-handler reset loops for
-- combat drop, target change, gear change and spec change) all wrote
-- btn:SetAttribute("step", 1) and then fired nothing. The HUD counter and icon
-- (TrackerHUD:OnStepAdvanced -> TrackerHUD:UpdateIcon) and the bar overlay
-- (BarIntegration:OnStepAdvanced) repaint only on SEQUENCE_STEP_ADVANCED, whose
-- sole fire site is inside Engine:UpdateButtonIcon -- so after a reset the
-- display kept showing the pre-reset step while the engine sat at step 1.
-- TrackerHUD's own combat-exit re-sync is gated on the frame being HIDDEN, so
-- with trackerShowMode=ALWAYS nothing ever repainted.
--
-- The fix has the five reset paths call Engine:UpdateButtonIcon(btn, true). The
-- new second parameter suppresses ONLY the "stepComplete" accessibility cue: a
-- reset changed the step but nothing was cast, and firing the cue on every
-- combat drop, target swap, gear swap and spec change would be an audible and
-- visual regression for the users who turned it on. The icon refresh and the
-- SEQUENCE_STEP_ADVANCED fire both still happen -- that is what repaints the
-- counter, the HUD icon and the bar overlay.
--
-- Secure-side resets (resetTimer, reset modifiers) are OUT OF SCOPE and are not
-- covered here: those flip _shouldReset inside the PreClick snippet, the click
-- proceeds, and CallMethod('UpdateIcon') already repaints on the way out.
--
-- Loads the REAL modules (Engine/StepFunctions.lua + Engine/Engine.lua) via
-- loadfile + setfenv into a no-op stub sandbox, the same technique as
-- test_stepadv_numsteps_domain.lua. No secure frames are created; both the fire
-- path and the four event handlers are pure Lua and safe headless.
--
-- Run from the EMS root:  lua Test/test_step_reset_notifies_ui.lua
-- Exit code 0 = all passed, 1 = at least one failure.
--
-- Cases:
--   C1   ResetStep fires SEQUENCE_STEP_ADVANCED with step == 1
--   C2   ResetStep records NO stepComplete cue
--   C3   PLAYER_REGEN_ENABLED + resetOnCombat fires step 1, no cue
--   C4   PLAYER_REGEN_ENABLED without resetOnCombat fires nothing, step unmoved
--   C5   PLAYER_TARGET_CHANGED + resetOnTarget fires step 1
--   C6   a second PLAYER_TARGET_CHANGED on the SAME GUID fires nothing
--        (the 12.0 soft-target dedup still wins after this fix)
--   C7   PLAYER_EQUIPMENT_CHANGED + resetOnGear fires step 1
--   C8   PLAYER_SPECIALIZATION_CHANGED for unit "player" + resetOnSpec fires 1
--   C9   PLAYER_SPECIALIZATION_CHANGED for unit "party1" fires nothing
--   C10  CONTROL: UpdateButtonIcon with NO second argument DOES play the cue
--
-- WHY C10 EXISTS, and why it is last. Every "no cue" assertion in C1 to C9 is
-- also satisfied by a build that deleted the cue outright, or by a harness whose
-- Sound stub is never reachable -- the test would then stay green through
-- exactly the regression it is here to catch. C10 drives the same function on
-- the same fixture with the argument omitted and asserts the cue WAS recorded,
-- so the zeroes above describe a suppression rather than an absence.
--
-- STUB AUDIT.
--   env.GRIPEMS_EngineEvent  a RECORDING frame, rawset into the sandbox BEFORE
--                            the load. Engine.lua opens the event block with
--                            local engineFrame = _G["GRIPEMS_EngineEvent"] or
--                            CreateFrame(...), and in a stub sandbox that key
--                            resolves to the catch-all stub, which is TRUTHY --
--                            so CreateFrame never runs and the OnEvent handler
--                            is thrown away. Capturing it in SetScript is the
--                            only way to reach the four reset loops at all.
--                            LIVE: a real Frame. MATCHES in the shape used
--                            (UnregisterAllEvents / RegisterEvent / SetScript);
--                            anything else falls through to the catch-all stub.
--   env.UnitGUID             returns a test-controlled string so C5's "the
--                            target really changed" and C6's "it did not" are
--                            both expressible. LIVE: the client's target GUID.
--                            Required, not cosmetic: against the catch-all stub
--                            every call returns the SAME table, so the dedup
--                            guard would swallow C5.
--   GRIPEMS.OOCQueue         IsRestricted() returns FALSE here, unlike the
--                            model file. The target and gear handlers return
--                            early when restricted, and the icon branch of
--                            UpdateButtonIcon is OOC-gated -- true would make
--                            C5 and C7 vacuous. Add runs its function inline so
--                            ResetStep's queued doReset is observable in line.
--   GRIPEMS.Sound            records every cue key it is asked to play. LIVE:
--                            Core/Sound.lua S:Play, which is audio AND a visual
--                            complement. MATCHES in call shape.
--   Engine.UpdateLoadout     counter no-ops. Both are unrelated post-reset side
--   Engine.HealOverrideSteps calls on the spec-change arm, below the reset loop
--                            C8 asserts on; the real ones walk loadout state
--                            and the whole SavedVariables store. Stubbed for
--                            isolation, exactly as the model file stubs
--                            Deactivate/ActivateSequence for its D2 case.
--   GRIPEMS.SpellCache       ABSENT (nil), so UpdateButtonIcon's icon branch
--                            runs its OOC gate and step/version lookups and
--                            then stops at its own "if SC then" guard. The
--                            branch is exercised; no icon is resolved, and no
--                            case below asserts on one.

local ADDON_NAME = "GRIP-EMS"

-- ---------------------------------------------------------------------------
-- Minimal assertion + runner harness.
-- ---------------------------------------------------------------------------

local tests = {}

local function test(name, fn)
    tests[#tests + 1] = { name = name, fn = fn }
end

local function assertEqual(expected, actual, label)
    if expected ~= actual then
        error((label or "value") .. ": expected " .. tostring(expected) .. ", got " .. tostring(actual), 2)
    end
end

local function assertTrue(cond, label)
    if not cond then
        error((label or "condition") .. " failed", 2)
    end
end

-- ---------------------------------------------------------------------------
-- Sandbox: a self-referential no-op stub backs every unknown global so the real
-- modules load without a WoW client. Real stdlib falls through to _G.
-- ---------------------------------------------------------------------------

local stub = {}
setmetatable(stub, {
    __index = function()
        return stub
    end,
    __call = function()
        return stub
    end,
})

local env = setmetatable({}, {
    __index = function(_, k)
        local v = rawget(_G, k)
        if v ~= nil then
            return v
        end
        return stub
    end,
})
env._G = env

-- AceLocale stand-in: every key echoes back so any L["KEY"] format is inert.
local LOCALE = setmetatable({}, {
    __index = function(_, k)
        return k
    end,
})
env.LibStub = function()
    return {
        GetLocale = function()
            return LOCALE
        end,
    }
end

-- ---------------------------------------------------------------------------
-- Recording frame + target GUID control. Both must exist BEFORE the load: the
-- frame is read at module scope, and the handler closes over the sandbox.
-- ---------------------------------------------------------------------------

local scripts = {}

local recordFrame = setmetatable({
    UnregisterAllEvents = function() end,
    RegisterEvent = function() end,
    SetScript = function(_, kind, fn)
        scripts[kind] = fn
    end,
}, {
    __index = function()
        return stub
    end,
})

rawset(env, "GRIPEMS_EngineEvent", recordFrame)

local targetGUID = "GUID-INITIAL"
rawset(env, "UnitGUID", function()
    return targetGUID
end)

-- ---------------------------------------------------------------------------
-- GRIPEMS control table. Fire records the whole payload; Sound records cues.
-- ---------------------------------------------------------------------------

local fired = {}
local cues = {}
local sideCalls = { keybinds = 0, loadout = 0, healOverride = 0 }

local GRIPEMS = {
    version = "headless",
    Print = function() end,
    Debug = function() end,
    Defaults = {
        STEP_SEQUENTIAL = "Sequential",
        STEP_RANDOM = "Random",
        STEP_PRIORITY = "Priority",
        STEP_REVERSE_PRIORITY = "ReversePriority",
        ATTR_TYPE_MACRO = "macro",
        MAX_MACROTEXT_LENGTH = 255,
        MAX_SAB_MACROTEXT_LENGTH = 255,
        CONTEXT_NONE = "none",
        OOC_OP_RESET = "reset",
    },
    OOCQueue = {
        -- FALSE, unlike the model file: the target and gear handlers return
        -- early when restricted, and the icon branch is OOC-gated.
        IsRestricted = function()
            return false
        end,
        -- ResetStep queues doReset here; run it synchronously so the reset is
        -- observable in line.
        Add = function(_, fn)
            fn()
        end,
    },
    MacroManager = {
        UpdateIcon = function() end,
        UpdateStubBody = function() end,
    },
    KeybindManager = {
        ScheduleLoadKeybinds = function()
            sideCalls.keybinds = sideCalls.keybinds + 1
        end,
        LoadKeybinds = function() end,
    },
    Sound = {
        Play = function(_, key)
            cues[#cues + 1] = key
        end,
    },
    -- Engine.lua registers a corrupt-sequence popup at module scope (Popup:Define);
    -- no path here shows it, so a no-op definer is enough to load the file.
    Popup = {
        Define = function() end,
        Show = function() end,
    },
}

function GRIPEMS:Fire(event, seqName, step, numSteps)
    fired[#fired + 1] = { event = event, seqName = seqName, step = step, numSteps = numSteps }
end

-- ---------------------------------------------------------------------------
-- Load the REAL modules into the sandbox. StepFunctions first: Engine captures
-- GRIPEMS.StepFunctions as a file-scope upvalue at load, so it must exist first.
-- ---------------------------------------------------------------------------

local function loadModule(candidates)
    for _, path in ipairs(candidates) do
        -- loadfile is dev-harness file I/O, intentionally outside the addon WoW std.
        -- selene: allow(undefined_variable)
        local chunk = loadfile(path)
        if chunk then
            setfenv(chunk, env)
            chunk(ADDON_NAME, GRIPEMS)
            return true
        end
    end
    return false
end

assert(
    loadModule({
        "Engine/StepFunctions.lua",
        "../Engine/StepFunctions.lua",
        "GRIP/EMS/Engine/StepFunctions.lua",
    }),
    "could not locate Engine/StepFunctions.lua (run from the EMS root)"
)
assert(
    loadModule({
        "Engine/Engine.lua",
        "../Engine/Engine.lua",
        "GRIP/EMS/Engine/Engine.lua",
    }),
    "could not locate Engine/Engine.lua (run from the EMS root)"
)

local Engine = GRIPEMS.Engine
assert(Engine ~= nil, "Engine loaded")
assert(GRIPEMS.StepFunctions ~= nil, "StepFunctions loaded")
assert(type(Engine.UpdateButtonIcon) == "function", "UpdateButtonIcon defined")
assert(type(Engine.ResetStep) == "function", "ResetStep defined")

local onEvent = scripts.OnEvent
assert(type(onEvent) == "function", "captured the engineFrame OnEvent handler")

Engine.sequences = {}

-- Post-reset side calls on the spec-change arm; see the STUB AUDIT above.
function Engine:UpdateLoadout()
    sideCalls.loadout = sideCalls.loadout + 1
end

function Engine:HealOverrideSteps()
    sideCalls.healOverride = sideCalls.healOverride + 1
end

-- ---------------------------------------------------------------------------
-- Fixtures + helpers.
-- ---------------------------------------------------------------------------

-- A three-step Sequential sequence in the versioned format GetActiveVersion
-- reads. Sequential does not expand, so the execution denominator is 3 and any
-- step index below is directly readable.
local function makeSequence(fields)
    local ver = {
        steps = { "/cast Alpha", "/cast Bravo", "/cast Charlie" },
        stepFunction = "Sequential",
        compiledLabels = { "Alpha", "Bravo", "Charlie" },
        keyPress = "",
        keyRelease = "",
    }
    for k, v in pairs(fields or {}) do
        ver[k] = v
    end
    return { versions = { ver }, defaultVersion = 1 }
end

-- Register a sequence with a fake button (no secure frame -- every path here is
-- pure Lua) seeded to a step OTHER than 1, so "moved to 1" is observable.
local function registerSequence(name, seqData, startStep)
    local btn = {
        seqName = name,
        seqData = seqData,
        _attrs = { step = startStep },
    }
    function btn:GetAttribute(key)
        return self._attrs[key]
    end
    function btn:SetAttribute(key, value)
        self._attrs[key] = value
    end
    Engine.sequences[name] = { data = seqData, button = btn }
    return btn
end

local function clearSequences()
    for k in pairs(Engine.sequences) do
        Engine.sequences[k] = nil
    end
end

local function resetCapture()
    for i = #fired, 1, -1 do
        fired[i] = nil
    end
    for i = #cues, 1, -1 do
        cues[i] = nil
    end
end

-- Only the repaint event; anything else the load or a handler emits is ignored.
local function stepFires()
    local out = {}
    for _, f in ipairs(fired) do
        if f.event == "SEQUENCE_STEP_ADVANCED" then
            out[#out + 1] = f
        end
    end
    return out
end

local function countCue(key)
    local n = 0
    for _, c in ipairs(cues) do
        if c == key then
            n = n + 1
        end
    end
    return n
end

-- ---------------------------------------------------------------------------
-- Cases.
-- ---------------------------------------------------------------------------

test("C1: Engine:ResetStep fires SEQUENCE_STEP_ADVANCED with step 1", function()
    clearSequences()
    resetCapture()
    local btn = registerSequence("C1_Seq", makeSequence(), 3)
    Engine:ResetStep("C1_Seq")
    local advs = stepFires()
    assertEqual(1, #advs, "exactly one SEQUENCE_STEP_ADVANCED fired")
    assertEqual("C1_Seq", advs[1].seqName, "the event names the sequence that was reset")
    assertEqual(1, advs[1].step, "the repaint reports step 1, the POST-reset value")
    assertEqual(3, advs[1].numSteps, "the denominator is the unchanged execution count")
    assertEqual(1, btn:GetAttribute("step"), "and the button attribute really moved to 1")
end)

test("C2: Engine:ResetStep plays no stepComplete cue", function()
    clearSequences()
    resetCapture()
    registerSequence("C2_Seq", makeSequence(), 4)
    Engine:ResetStep("C2_Seq")
    assertEqual(1, #stepFires(), "the repaint fired, so the cue assertion below is not vacuous")
    assertEqual(0, countCue("stepComplete"), "a reset cast nothing: no stepComplete cue")
    assertEqual(0, #cues, "and no other cue either")
end)

test("C3: PLAYER_REGEN_ENABLED with resetOnCombat fires step 1 and plays no cue", function()
    clearSequences()
    resetCapture()
    local btn = registerSequence("C3_Seq", makeSequence({ resetOnCombat = true }), 5)
    onEvent(recordFrame, "PLAYER_REGEN_ENABLED")
    local advs = stepFires()
    assertEqual(1, #advs, "the combat-drop reset repainted exactly once")
    assertEqual("C3_Seq", advs[1].seqName, "the event names the reset sequence")
    assertEqual(1, advs[1].step, "the repaint reports step 1")
    assertEqual(1, btn:GetAttribute("step"), "the button attribute moved to 1")
    assertEqual(0, countCue("stepComplete"), "leaving combat is not a cast: no cue")
end)

test("C4: PLAYER_REGEN_ENABLED without resetOnCombat fires nothing and leaves the step", function()
    clearSequences()
    resetCapture()
    local btnOff = registerSequence("C4_Off", makeSequence({ resetOnCombat = false }), 5)
    local btnNil = registerSequence("C4_Nil", makeSequence(), 6)
    onEvent(recordFrame, "PLAYER_REGEN_ENABLED")
    assertEqual(0, #stepFires(), "an opted-out sequence is not repainted")
    assertEqual(5, btnOff:GetAttribute("step"), "resetOnCombat=false leaves the step where it was")
    assertEqual(6, btnNil:GetAttribute("step"), "an absent resetOnCombat leaves the step where it was")
    assertEqual(0, #cues, "and no cue")
end)

test("C5: PLAYER_TARGET_CHANGED with resetOnTarget fires step 1", function()
    clearSequences()
    resetCapture()
    -- The dedup guard returns before the loop unless the target identity really
    -- changed, so seed the cache with a DIFFERENT GUID than UnitGUID returns.
    targetGUID = "GUID-C5"
    Engine._lastTargetGUID = "GUID-PREVIOUS"
    local btn = registerSequence("C5_Seq", makeSequence({ resetOnTarget = true }), 2)
    onEvent(recordFrame, "PLAYER_TARGET_CHANGED")
    local advs = stepFires()
    assertEqual(1, #advs, "the target-change reset repainted exactly once")
    assertEqual("C5_Seq", advs[1].seqName, "the event names the reset sequence")
    assertEqual(1, advs[1].step, "the repaint reports step 1")
    assertEqual(1, btn:GetAttribute("step"), "the button attribute moved to 1")
    assertEqual(0, countCue("stepComplete"), "a target swap is not a cast: no cue")
end)

test("C6: a second PLAYER_TARGET_CHANGED on the same GUID fires nothing (dedup still wins)", function()
    clearSequences()
    resetCapture()
    targetGUID = "GUID-C6"
    Engine._lastTargetGUID = nil
    local btn = registerSequence("C6_Seq", makeSequence({ resetOnTarget = true }), 7)
    onEvent(recordFrame, "PLAYER_TARGET_CHANGED")
    assertEqual(1, #stepFires(), "the first, real target change repainted (non-vacuity control)")
    -- 12.0 soft-targeting pulses this event every 2-3s with the GUID unchanged.
    -- The fix must not turn that pulse into a repaint storm.
    resetCapture()
    btn:SetAttribute("step", 4)
    onEvent(recordFrame, "PLAYER_TARGET_CHANGED")
    assertEqual(0, #stepFires(), "the deduped pulse repaints nothing")
    assertEqual(4, btn:GetAttribute("step"), "and it does not touch the step either")
end)

test("C7: PLAYER_EQUIPMENT_CHANGED with resetOnGear fires step 1", function()
    clearSequences()
    resetCapture()
    local btn = registerSequence("C7_Seq", makeSequence({ resetOnGear = true }), 3)
    onEvent(recordFrame, "PLAYER_EQUIPMENT_CHANGED", 16)
    local advs = stepFires()
    assertEqual(1, #advs, "the gear-change reset repainted exactly once")
    assertEqual("C7_Seq", advs[1].seqName, "the event names the reset sequence")
    assertEqual(1, advs[1].step, "the repaint reports step 1")
    assertEqual(1, btn:GetAttribute("step"), "the button attribute moved to 1")
    assertEqual(0, countCue("stepComplete"), "a gear swap is not a cast: no cue")
end)

test("C8: PLAYER_SPECIALIZATION_CHANGED for the player with resetOnSpec fires step 1", function()
    clearSequences()
    resetCapture()
    local before = sideCalls.keybinds
    local btn = registerSequence("C8_Seq", makeSequence({ resetOnSpec = true }), 6)
    onEvent(recordFrame, "PLAYER_SPECIALIZATION_CHANGED", "player")
    local advs = stepFires()
    assertEqual(1, #advs, "the spec-change reset repainted exactly once")
    assertEqual("C8_Seq", advs[1].seqName, "the event names the reset sequence")
    assertEqual(1, advs[1].step, "the repaint reports step 1")
    assertEqual(1, btn:GetAttribute("step"), "the button attribute moved to 1")
    assertEqual(0, countCue("stepComplete"), "a spec change is not a cast: no cue")
    assertTrue(sideCalls.keybinds > before, "the arm ran past the reset loop (keybind reload reached)")
end)

test("C9: PLAYER_SPECIALIZATION_CHANGED for a party member fires nothing", function()
    clearSequences()
    resetCapture()
    local before = sideCalls.keybinds
    local btn = registerSequence("C9_Seq", makeSequence({ resetOnSpec = true }), 6)
    onEvent(recordFrame, "PLAYER_SPECIALIZATION_CHANGED", "party1")
    assertEqual(0, #stepFires(), "a group member's spec change repaints nothing")
    assertEqual(6, btn:GetAttribute("step"), "and leaves the step where it was")
    assertEqual(before, sideCalls.keybinds, "the whole unit == player arm was skipped")
    assertEqual(0, #cues, "and no cue")
end)

test("C10 (control): UpdateButtonIcon with NO second argument still plays the stepComplete cue", function()
    clearSequences()
    resetCapture()
    -- Without this row every "no cue" assertion above is equally satisfied by a
    -- build that deleted the cue outright, or by a Sound stub the code never
    -- reaches. This is the real advance path -- the button UpdateIcon method,
    -- the variant-button UpdateIcon method and the TempoAdvisor hold button all
    -- call UpdateButtonIcon with one argument -- and it MUST still cue.
    local btn = registerSequence("C10_Seq", makeSequence(), 2)
    Engine:UpdateButtonIcon(btn)
    local advs = stepFires()
    assertEqual(1, #advs, "the advance path fires the same repaint event")
    assertEqual(2, advs[1].step, "and reports the button's live step, which it does not touch")
    assertEqual(1, countCue("stepComplete"), "the real advance DOES play the cue")

    -- Same function, same button, silent arm: only the cue changes.
    resetCapture()
    Engine:UpdateButtonIcon(btn, true)
    assertEqual(1, #stepFires(), "the silent call still fires the repaint event")
    assertEqual(0, countCue("stepComplete"), "and suppresses only the cue")
end)

-- ---------------------------------------------------------------------------
-- Run.
-- ---------------------------------------------------------------------------

local passed = 0
local failed = 0
for _, t in ipairs(tests) do
    local ok, err = pcall(t.fn)
    if ok then
        passed = passed + 1
        print("PASS  " .. t.name)
    else
        failed = failed + 1
        print("FAIL  " .. t.name .. " -- " .. tostring(err))
    end
end
print(string.format("RESULT %d passed, %d failed", passed, failed))
os.exit(failed > 0 and 1 or 0)
