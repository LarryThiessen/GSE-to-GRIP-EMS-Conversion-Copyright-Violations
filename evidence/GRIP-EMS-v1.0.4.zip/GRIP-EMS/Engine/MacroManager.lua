-- GRIP-EMS: Macro Manager
-- CRUD operations for WoW macro stubs that /click the sequencer buttons

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS")
local D = GRIPEMS.Defaults

-- MacroManager module: creates, updates, and deletes the WoW macros that act
-- as stubs for GRIP-EMS sequences. Each active sequence gets one per-character
-- macro whose body is:
--   #showtooltip
--   /click [button:1] GRIPEMS_SeqName LeftButton t; GRIPEMS_SeqName
-- The [button:1] conditional targets left-click events; the trailing bare name
-- is a fallback for virtual button and keyboard-only usage. The macro stub
-- is what the player drags to their action bar; clicking it triggers the
-- SecureActionButton which executes the current step's attributes.
-- All write operations go through OOCQueue to handle combat lockdown.
GRIPEMS.MacroManager = {
    stubs = {},  -- seqName -> macroId mapping
}
local MM = GRIPEMS.MacroManager

--- Truncate a sequence name to fit within the macro name limit.
--- Format: "GEMS:<name>" must fit in MAX_MACRO_NAME (16) chars.
--- If a collision exists in the stubs table, appends a numeric suffix.
--- @param seqName string The sequence name to truncate
--- @return string The truncated macro name
function MM:TruncateName(seqName)
    if not seqName then return D.MACRO_PREFIX end
    local prefixLen = #D.MACRO_PREFIX
    local maxNameLen = D.MAX_MACRO_NAME - prefixLen
    local truncated = D.MACRO_PREFIX .. seqName:sub(1, maxNameLen)

    -- Check for collisions with existing stubs
    local suffix = 1
    local maxSuffix = 99
    while suffix <= maxSuffix do
        local collision = false
        for existingSeq, _ in pairs(self.stubs) do
            if existingSeq ~= seqName then
                local existingMacroName = self:GetMacroName(existingSeq)
                if existingMacroName == truncated then
                    collision = true
                    break
                end
            end
        end
        if not collision then break end
        -- Append numeric suffix, shrinking the name portion to fit
        local suffixStr = tostring(suffix)
        local shrunkLen = D.MAX_MACRO_NAME - prefixLen - #suffixStr
        if shrunkLen < 1 then shrunkLen = 1 end
        truncated = D.MACRO_PREFIX .. seqName:sub(1, shrunkLen) .. suffixStr
        suffix = suffix + 1
    end
    return truncated
end

--- Get the macro display name for a sequence (without collision resolution).
--- Used internally for collision detection.
--- @param seqName string The sequence name
--- @return string The basic macro name (may collide)
function MM:GetMacroName(seqName)
    if not seqName then return D.MACRO_PREFIX end
    local prefixLen = #D.MACRO_PREFIX
    local maxNameLen = D.MAX_MACRO_NAME - prefixLen
    return D.MACRO_PREFIX .. seqName:sub(1, maxNameLen)
end

--- Create a macro stub for a sequence. Queues via OOCQueue if in combat.
--- @param seqName string The sequence name
--- @return number|nil The macro ID if created immediately, nil if queued or failed
--- @return string|nil Error message if creation failed
function MM:CreateStub(seqName)
    if not seqName or seqName == "" then
        return nil, L["GEMS_ERR_NO_NAME"]
    end

    -- Check if stub already exists
    if self.stubs[seqName] then
        return self.stubs[seqName], nil
    end

    local function doCreate()
        -- Check available slots
        local available = self:GetAvailableSlots()
        if available <= 0 then
            local _, perChar = GetNumMacros()
            GRIPEMS:Print(string.format(L["GEMS_ERR_NO_MACRO_SLOTS"],
                perChar, D.MAX_PER_CHAR_MACROS))
            return
        end

        local macroName = self:TruncateName(seqName)
        local buttonName = D.BUTTON_PREFIX .. GRIPEMS.Engine:SanitizeName(seqName)
        local body = string.format(D.MACRO_BODY_TEMPLATE, buttonName, buttonName)

        local ok, result = pcall(CreateMacro, macroName, D.QUESTION_MARK_ICON, body, true)
        if ok and result then
            self.stubs[seqName] = result
            GRIPEMS:Debug(string.format(L["GEMS_MACRO_CREATED"], macroName, result))
        else
            local errMsg = not ok and tostring(result) or "unknown error"
            GRIPEMS:Print(string.format(L["GEMS_ERR_MACRO_CREATE_FAILED"], seqName)
                .. " (" .. errMsg .. ")")
        end
    end

    GRIPEMS.OOCQueue:Add(doCreate)
    return nil, nil
end

--- Delete the macro stub for a sequence. Queues via OOCQueue if in combat.
--- @param seqName string The sequence name
function MM:DeleteStub(seqName)
    if not seqName or not self.stubs[seqName] then return end

    local function doDelete()
        -- Scan for our macro by body content (immune to index shifts)
        local _, perChar = GetNumMacros()
        local accountSlots = D.MAX_ACCOUNT_MACROS
        local targetBtn = D.BUTTON_PREFIX
            .. GRIPEMS.Engine:SanitizeName(seqName)
        for i = accountSlots + 1, accountSlots + perChar do
            local _, _, body = GetMacroInfo(i)
            if body and body:find(targetBtn, 1, true) then
                DeleteMacro(i)
                break
            end
        end
        self.stubs[seqName] = nil
    end

    GRIPEMS.OOCQueue:Add(doDelete)
end

--- Update the icon of a macro stub. Queues via OOCQueue if in combat.
--- @param seqName string The sequence name
--- @param iconFileID number The icon texture fileID
function MM:UpdateIcon(seqName, iconFileID)
    if not seqName or not self.stubs[seqName] then return end
    if not iconFileID then return end
    local macroId = self.stubs[seqName]

    local function doUpdate()
        EditMacro(macroId, nil, iconFileID, nil)
    end

    GRIPEMS.OOCQueue:Add(doUpdate)
end

--- Scan all per-character macros on login and reclaim any GRIP-EMS stubs.
--- Rebuilds the stubs table from found macros whose body starts with
--- "/click GRIPEMS_". Called on PLAYER_ENTERING_WORLD.
function MM:ScanExisting()
    -- Clear stale entries before rescanning
    wipe(self.stubs)

    -- Build reverse lookup: sanitized -> original sequence name
    local sanitizedToOriginal = {}
    if _G.GRIP_EMS_CHAR and _G.GRIP_EMS_CHAR.sequences then
        for origName, _ in pairs(_G.GRIP_EMS_CHAR.sequences) do
            local sanitized = GRIPEMS.Engine:SanitizeName(origName)
            sanitizedToOriginal[sanitized] = origName
        end
    end

    local _, perChar = GetNumMacros()
    local accountSlots = D.MAX_ACCOUNT_MACROS
    local found = 0

    for i = accountSlots + 1, accountSlots + perChar do
        local name, _, body = GetMacroInfo(i)
        if name and body then
            local buttonMatch = body:match("; " .. D.BUTTON_PREFIX .. "(%S+)")
            if not buttonMatch then
                buttonMatch = body:match("/click " .. D.BUTTON_PREFIX .. "(%S+)")
            end
            if buttonMatch then
                local sanitizedName = buttonMatch:gsub("%s+LeftButton.*$", "")
                -- Map back to original sequence name (spaces, not underscores)
                local seqName = sanitizedToOriginal[sanitizedName] or sanitizedName
                self.stubs[seqName] = i
                found = found + 1
            end
        end
    end

    if found > 0 then
        GRIPEMS:Debug(string.format(L["GEMS_MACROS_SCANNED"], found))
    end
end

--- Return the number of available per-character macro slots.
--- @return number Available slots
function MM:GetAvailableSlots()
    local _, perChar = GetNumMacros()
    return D.MAX_PER_CHAR_MACROS - perChar
end
