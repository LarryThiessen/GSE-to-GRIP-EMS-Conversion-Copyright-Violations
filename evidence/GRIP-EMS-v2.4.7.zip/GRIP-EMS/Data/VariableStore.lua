-- GRIP-EMS: VariableStore
-- Created: 2026-03-19
-- Updated: 2026-08-17
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)

-- GRIP-EMS: Variable Store
-- Account-wide variable definitions: CRUD, evaluation, event re-evaluation

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)
local D = GRIPEMS.Defaults

-- VariableStore module: manages user-defined Lua functions stored account-wide
-- in GRIP_EMS_DB.variables. Variables are referenced in step macrotext as
-- ~varname~ and substituted at compile time by Engine:CompileSteps.
-- Each variable can optionally register for WoW events to trigger
-- re-evaluation, which fires VARIABLE_UPDATED if the value changed.
GRIPEMS.VariableStore = {}
local VS = GRIPEMS.VariableStore

-- Internal state
local cachedValues = {} -- name -> last evaluated value
local eventFrame = nil -- hidden frame for event registration
local consolidationTimer = nil -- C_Timer handle for event batching
local pendingReeval = {} -- set of varNames needing re-evaluation
local registeredEvents = {} -- event name -> true, tracks currently registered events
VS._cachedFunctSrc = {} -- name -> last seen source text for function-type vars
local cachedFunctFn = {} -- name -> compiled function for function-type vars
local localeRiskFlags = {} -- name -> { spellName, spellID } or nil (runtime only)
local privateAuraFlags = {} -- name -> { spellName, spellID } or nil (runtime only, private aura detection)
VS._sandboxBlocked = {} -- blocked global name -> integer hit count (runtime telemetry)
local sandboxLogged = {} -- blocked global name -> true, one debug line per name per session

--- Get the variables table from SavedVariables (lazy, nil-safe).
--- @return table variables table (may be empty)
local function GetStore()
    if _G.GRIP_EMS_DB and GRIP_EMS_DB.variables then
        return GRIP_EMS_DB.variables
    end
    return {}
end

--- Get a writable reference to the variables table.
--- Creates the table if it does not exist.
--- @return table variables table
local function GetOrCreateStore()
    if not _G.GRIP_EMS_DB then
        _G.GRIP_EMS_DB = {}
    end
    if not GRIP_EMS_DB.variables then
        GRIP_EMS_DB.variables = {}
    end
    return GRIP_EMS_DB.variables
end

--- Check if a variable's evaluated value is a known spell name (locale risk).
--- Sets or clears localeRiskFlags[name] accordingly.
--- @param name string Variable name
--- @param value any Evaluated value
local function CheckLocaleRisk(name, value)
    if type(value) ~= "string" then
        localeRiskFlags[name] = nil
        return
    end
    local SC = GRIPEMS.SpellCache
    if not SC or not SC.ready then
        return
    end
    local trimmed = value:match("^%s*(.-)%s*$")
    if not trimmed or trimmed == "" then
        localeRiskFlags[name] = nil
        return
    end
    local spellID = SC:GetSpellID(trimmed)
    if spellID then
        localeRiskFlags[name] = { spellName = trimmed, spellID = spellID }
    else
        localeRiskFlags[name] = nil
    end
end

--- Check if a variable's evaluated value is a Private aura
--- spell name (addon detection blindness risk).
--- Sets or clears privateAuraFlags[name] accordingly.
--- @param name string Variable name
--- @param value any Evaluated value
local function CheckPrivateAuraRisk(name, value)
    if type(value) ~= "string" then
        privateAuraFlags[name] = nil
        return
    end
    local SC = GRIPEMS.SpellCache
    if not SC or not SC.ready then
        return
    end
    local trimmed = value:match("^%s*(.-)%s*$")
    if not trimmed or trimmed == "" then
        privateAuraFlags[name] = nil
        return
    end
    local spellID = SC:GetSpellID(trimmed)
    if not spellID then
        privateAuraFlags[name] = nil
        return
    end
    if C_UnitAuras and C_UnitAuras.AuraIsPrivate then
        local ok, isPrivate = pcall(C_UnitAuras.AuraIsPrivate, spellID)
        if ok and isPrivate then
            privateAuraFlags[name] = { spellName = trimmed, spellID = spellID }
            return
        end
    end
    privateAuraFlags[name] = nil
end

--- Tag the evaluated result of a variable with spell/item/toy ID tokens.
--- Stores taggedValue and valueLocale on the variable definition in SavedVariables.
--- @param name string Variable name
--- @param evaluatedValue any Evaluated value (only strings are tagged)
local function TagVariableValue(name, evaluatedValue)
    if type(evaluatedValue) ~= "string" then
        return
    end
    local SC = GRIPEMS.SpellCache
    if not SC or not SC.TranslateMacrotext then
        return
    end
    local tagged = SC:TranslateMacrotext(evaluatedValue, "toIDs")
    if tagged == evaluatedValue then
        return
    end -- no translatable content
    local varData = GetStore()[name]
    if varData then
        varData.taggedValue = tagged
        varData.valueLocale = GetLocale()
    end
end

--- Heal all variables whose valueLocale differs from the current locale.
--- Translates taggedValue back to current locale spell names and re-tags.
--- @return number healed Count of healed variables
function VS:HealLocaleVariables()
    local SC = GRIPEMS.SpellCache
    if not SC or not SC.TranslateMacrotext then
        return 0
    end
    local currentLocale = GetLocale()
    local healed = 0
    for name, varData in pairs(GetStore()) do
        if varData.taggedValue and varData.valueLocale and varData.valueLocale ~= currentLocale then
            local newValue = SC:TranslateMacrotext(varData.taggedValue, "toNames")
            if newValue and newValue ~= varData.taggedValue then
                varData.cachedValue = newValue
                varData.taggedValue = SC:TranslateMacrotext(newValue, "toIDs")
                varData.valueLocale = currentLocale
                healed = healed + 1
            end
        end
    end
    if healed > 0 and GRIPEMS.DebugWindow then
        GRIPEMS.DebugWindow:AddMessage("Healed " .. healed .. " variable(s) for locale " .. currentLocale)
    end
    return healed
end

--- Initialize the VariableStore module.
--- Called from Core.lua after SavedVariables are available.
function VS:Initialize()
    -- Evaluate all existing variables to populate cache
    self:EvaluateAll()
    -- Build event registration for all variable event triggers
    self:RebuildEventRegistration()
    GRIPEMS:Debug("VariableStore initialized.")
end

--- Get a variable definition by name.
--- @param name string Variable name
--- @return table|nil varDef or nil if not found
function VS:Get(name)
    if not name then
        return nil
    end
    local store = GetStore()
    return store[name]
end

--- Get all variable definitions.
--- @return table name -> varDef mapping
function VS:GetAll()
    return GetStore()
end

--- Save or update a variable definition.
--- @param name string Variable name
--- @param varDef table Variable definition table
function VS:Set(name, varDef)
    if not name or not varDef then
        return
    end
    local store = GetOrCreateStore()

    varDef.name = name
    varDef.updatedAt = time()
    if not varDef.createdAt then
        varDef.createdAt = time()
    end
    if varDef.author == nil then
        varDef.author = UnitName("player") or ""
    end
    if varDef.version == nil then
        varDef.version = "1"
    end
    if varDef.eventsEnabled == nil then
        varDef.eventsEnabled = true
    end

    local isNew = (store[name] == nil)
    store[name] = varDef

    -- Invalidate compiled function cache to force fresh loadstring
    VS._cachedFunctSrc[name] = nil
    cachedFunctFn[name] = nil

    -- Re-evaluate immediately
    local value = self:Evaluate(name)
    cachedValues[name] = value
    CheckLocaleRisk(name, value)
    CheckPrivateAuraRisk(name, value)
    TagVariableValue(name, value)

    -- Rebuild event registrations (events may have changed)
    self:RebuildEventRegistration()

    if isNew and GRIPEMS.Fire then
        GRIPEMS:Fire("VARIABLE_CREATED", name)
    end
    if GRIPEMS.Fire then
        GRIPEMS:Fire("VARIABLE_UPDATED", name, value)
    end

    GRIPEMS:Debug(string.format(L["GEMS_VAR_SAVED"], name))
end

--- Delete a variable by name.
--- @param name string Variable name
function VS:Delete(name)
    if not name then
        return
    end
    local store = GetOrCreateStore()
    if not store[name] then
        return
    end

    store[name] = nil
    cachedValues[name] = nil
    VS._cachedFunctSrc[name] = nil
    cachedFunctFn[name] = nil
    localeRiskFlags[name] = nil
    privateAuraFlags[name] = nil

    self:RebuildEventRegistration()

    if GRIPEMS.Fire then
        GRIPEMS:Fire("VARIABLE_DELETED", name)
    end

    GRIPEMS:Debug(string.format(L["GEMS_VAR_DELETED"], name))
end

--- Rename a variable and update all sequence references.
--- @param oldName string Current variable name
--- @param newName string New variable name
--- @return boolean success
--- @return string|nil error message
function VS:Rename(oldName, newName)
    if not oldName or not newName then
        return false, "Missing name"
    end

    local validName, nameErr = self:ValidateName(newName)
    if not validName then
        return false, nameErr
    end

    local store = GetOrCreateStore()
    if not store[oldName] then
        return false, string.format("Variable '%s' not found", oldName)
    end
    if store[newName] then
        return false, string.format(L["GEMS_VAR_NAME_EXISTS"], newName)
    end

    -- Move the definition
    local varDef = store[oldName]
    varDef.name = newName
    varDef.updatedAt = time()
    store[newName] = varDef
    store[oldName] = nil

    -- Move cached value, compiled function cache, and locale risk flag
    cachedValues[newName] = cachedValues[oldName]
    cachedValues[oldName] = nil
    VS._cachedFunctSrc[newName] = VS._cachedFunctSrc[oldName]
    VS._cachedFunctSrc[oldName] = nil
    cachedFunctFn[newName] = cachedFunctFn[oldName]
    cachedFunctFn[oldName] = nil
    localeRiskFlags[newName] = localeRiskFlags[oldName]
    localeRiskFlags[oldName] = nil
    privateAuraFlags[newName] = privateAuraFlags[oldName]
    privateAuraFlags[oldName] = nil

    -- Update all sequence references: replace ~oldName~ with ~newName~
    local oldPattern = "~" .. oldName .. "~"
    local newPattern = "~" .. newName .. "~"
    if _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.sequences then
        for _, seqData in pairs(GRIP_EMS_CHAR.sequences) do
            -- Update versioned steps (T2-2+ layout)
            if seqData.versions and type(seqData.versions) == "table" then
                for _, ver in ipairs(seqData.versions) do
                    if ver and ver.steps then
                        for i, step in ipairs(ver.steps) do
                            if type(step) == "string" and step:find(oldPattern, 1, true) then
                                ver.steps[i] = step:gsub(oldPattern, newPattern)
                            end
                        end
                    end
                end
            end
            -- Fallback: legacy flat steps (pre-T2-2 un-migrated data)
            if seqData.steps then
                for i, step in ipairs(seqData.steps) do
                    if type(step) == "string" and step:find(oldPattern, 1, true) then
                        seqData.steps[i] = step:gsub(oldPattern, newPattern)
                    end
                end
            end
        end
    end

    self:RebuildEventRegistration()

    if GRIPEMS.Fire then
        GRIPEMS:Fire("VARIABLE_DELETED", oldName)
        GRIPEMS:Fire("VARIABLE_CREATED", newName)
        GRIPEMS:Fire("VARIABLE_UPDATED", newName, cachedValues[newName])
    end

    return true
end

--- Build the explicit whitelist environment a variable function body runs in.
--- Anything not seeded here resolves to nil through the __index below, which
--- records the read on VS._sandboxBlocked and logs it once per name per
--- session. Sibling implementation: Engine/RecommendationEvaluator.lua
--- BuildSandbox -- the two are deliberately duplicated, not shared, so each
--- evaluator's surface can move without dragging the other with it.
---
--- Four seed sources, in order:
---   1) the RecommendationEvaluator whitelist (same Layer 1 helpers, same
---      safe Lua and WoW globals),
---   2) every helper the VariablesTab Insert Helper picker offers. The picker
---      inserts them NAMESPACED (GRIPEMS.HasBuff(0, "player")), so the env
---      carries a GRIPEMS facade holding exactly those six helpers -- never
---      the real GRIPEMS namespace, which reaches Engine, Settings and the
---      SavedVariables accessors,
---   3) base Lua values the picker set does not cover,
---   4) read-only WoW query API -- the spell / aura / item / unit state a real
---      variable body actually asks about. Every entry is a NAMED function.
---
--- Deliberately ABSENT, and not to be added: _G, getfenv, setfenv, loadstring,
--- load, dofile, require, rawset, setmetatable, getmetatable, collectgarbage,
--- newproxy, coroutine, debug, SendChatMessage, RunMacro, RunMacroText,
--- C_AddOns, and every Set-prefixed CVar or config API. A whitelist excludes
--- them by construction; this list exists so a later reader knows the omission
--- was a decision.
---
--- C_ NAMESPACES ARE EXPOSED AS FACADES HOLDING NAMED FUNCTIONS ONLY, never as
--- the real table. The concrete reason is PickupSpell: it sits on C_Spell
--- alongside the query functions this sandbox wants, and it is an ACTION
--- primitive -- it puts a spell on the cursor. Seeding `C_Spell = C_Spell` to
--- get GetSpellCooldown would hand every variable body PickupSpell with it, and
--- the same shape recurs across the C_ namespaces. A facade takes the reads and
--- leaves the verbs behind.
---
--- C_Timer IS ABSENT IN EVERY FORM, and not merely an oversight to correct
--- later. Scheduling from a variable body is a persistence primitive: a
--- variable would be able to outlive its own evaluation and keep running after
--- the macrotext that referenced it is gone. Variables are pure reads --
--- evaluate, return a value, finish. Nothing here should be able to schedule.
--- @param name string Variable name (carried into the blocked-global log line)
--- @return table env Fresh environment table
--- Read one named function off a C_ namespace without raising when the
--- namespace itself is absent on an older client. Returns nil in that case,
--- which is exactly what the env should carry: the body sees a nil and can
--- test for it, rather than the whole env build erroring at seed time.
--- @param ns table|nil The C_ namespace global
--- @param key string Function name to lift off it
--- @return function|nil
local function PickAPI(ns, key)
    if type(ns) ~= "table" then
        return nil
    end
    local fn = ns[key]
    if type(fn) ~= "function" then
        return nil
    end
    return fn
end

local function BuildVariableSandbox(name)
    -- Source 2: the Insert Helper picker snippets call through this facade.
    local helpers = {
        HasBuff = GRIPEMS.HasBuff,
        HasDebuff = GRIPEMS.HasDebuff,
        SpellReady = GRIPEMS.SpellReady,
        SpellOnCooldown = GRIPEMS.SpellOnCooldown,
        SpellEnabled = GRIPEMS.SpellEnabled,
        IsRestricted = GRIPEMS.IsRestricted,
    }
    local env = {
        -- Source 1: RecommendationEvaluator BuildSandbox, key for key.
        HasBuff = GRIPEMS.HasBuff,
        HasDebuff = GRIPEMS.HasDebuff,
        SpellReady = GRIPEMS.SpellReady,
        SpellOnCooldown = GRIPEMS.SpellOnCooldown,
        SpellEnabled = GRIPEMS.SpellEnabled,
        IsRestricted = GRIPEMS.IsRestricted,
        math = math,
        string = string,
        table = table,
        tonumber = tonumber,
        tostring = tostring,
        ipairs = ipairs,
        pairs = pairs,
        select = select,
        type = type,
        unpack = unpack,
        UnitHealth = UnitHealth,
        UnitHealthMax = UnitHealthMax,
        UnitPower = UnitPower,
        UnitPowerMax = UnitPowerMax,
        UnitName = UnitName,
        UnitExists = UnitExists,
        GetTime = GetTime,
        -- Source 2: namespaced facade for the picker snippets.
        GRIPEMS = helpers,
        -- Source 3: base Lua values the picker set does not cover.
        next = next,
        pcall = pcall,
        error = error,
        assert = assert,
        rawget = rawget,
        rawequal = rawequal,
        floor = floor,
        ceil = ceil,
        abs = abs,
        max = max,
        min = min,
        date = date,
        time = time,
        wipe = wipe,
        strsplit = strsplit,
        strjoin = strjoin,
        strtrim = strtrim,
        format = format,
        -- Taken off the string library rather than read as bare globals: WoW's
        -- gsub / gmatch ARE string.gsub / string.gmatch, so the value is
        -- identical, and the generated selene std omits those two bare names.
        gsub = string.gsub,
        gmatch = string.gmatch,
        strfind = strfind,
        -- Source 4: read-only WoW query API, flat globals. Reading a global
        -- that does not exist on this client yields nil and never raises, so
        -- these need no guard; the dotted ones below do.
        IsSpellKnown = IsSpellKnown,
        IsPlayerSpell = IsPlayerSpell,
        -- DEPRECATED BUT LIVE. The API surface marks this one deprecated with
        -- C_SpellBook.IsSpellInSpellBook as its replacement; it still exists and
        -- still returns a boolean, so it stays. No watch item is needed: the day
        -- Blizzard removes it, the global reads nil, the sandbox records the name
        -- on VS._sandboxBlocked and logs it, and the removal reports itself. The
        -- sibling case is the bare GetItemCooldown noted at the facade below.
        IsSpellKnownOrOverridesKnown = IsSpellKnownOrOverridesKnown,
        UnitAffectingCombat = UnitAffectingCombat,
        UnitCastingInfo = UnitCastingInfo,
        UnitChannelInfo = UnitChannelInfo,
        UnitClass = UnitClass,
        UnitLevel = UnitLevel,
        UnitIsDead = UnitIsDead,
        UnitIsDeadOrGhost = UnitIsDeadOrGhost,
        UnitGUID = UnitGUID,
        UnitPowerType = UnitPowerType,
        UnitCreatureType = UnitCreatureType,
        UnitClassification = UnitClassification,
        GetShapeshiftForm = GetShapeshiftForm,
        IsStealthed = IsStealthed,
        IsMounted = IsMounted,
        IsFlying = IsFlying,
        IsIndoors = IsIndoors,
        IsInRaid = IsInRaid,
        IsInGroup = IsInGroup,
        GetNumGroupMembers = GetNumGroupMembers,
    }

    -- Source 4, continued: the C_ namespaces. NAMED FUNCTIONS ONLY -- see the
    -- PickupSpell note in the header block above for why the real tables are
    -- never seeded. Each facade is built fresh per env so a body cannot mutate
    -- one and have the change reach the next evaluation.
    local spellAPI = {
        GetSpellCooldown = PickAPI(C_Spell, "GetSpellCooldown"),
        GetSpellCharges = PickAPI(C_Spell, "GetSpellCharges"),
        IsSpellUsable = PickAPI(C_Spell, "IsSpellUsable"),
        GetSpellInfo = PickAPI(C_Spell, "GetSpellInfo"),
        IsCurrentSpell = PickAPI(C_Spell, "IsCurrentSpell"),
    }
    local auraAPI = {
        GetAuraDataBySpellName = PickAPI(C_UnitAuras, "GetAuraDataBySpellName"),
        GetPlayerAuraBySpellID = PickAPI(C_UnitAuras, "GetPlayerAuraBySpellID"),
    }
    local itemAPI = {
        GetItemCount = PickAPI(C_Item, "GetItemCount"),
        -- DEPRECATED BUT LIVE, in its BARE form. C_Item.GetItemCooldown -- what
        -- this facade entry lifts -- is current; it is the bare global of the
        -- same name that the API surface marks deprecated, with this very
        -- function as its replacement. So the facade is already on the right
        -- side of that move, and the flat alias below is kept only because the
        -- deprecated global returns the identical triple. Same self-reporting
        -- property as IsSpellKnownOrOverridesKnown above: nothing to watch.
        GetItemCooldown = PickAPI(C_Item, "GetItemCooldown"),
    }
    env.C_Spell = spellAPI
    env.C_UnitAuras = auraAPI
    env.C_Item = itemAPI
    -- Flat aliases, so a body written without the namespace still works.
    --
    -- THE RULE: a flat alias exists ONLY where the C_ function's return shape is
    -- IDENTICAL to that of the retired global of the same bare name. Where the
    -- shapes differ there is no alias, and the bare name resolves nil.
    --
    -- Why the rule is worth the inconvenience. A nil is loud: it is recorded on
    -- VS._sandboxBlocked and logged by name, so the author is told. A
    -- differently shaped value is silent -- `local start, dur =
    -- GetSpellCooldown(id)` against the modern function puts a table in start
    -- and nil in dur, raises nothing, and never reaches the telemetry, because
    -- __index only sees names that resolve nil. Dropping the alias is the only
    -- thing that makes this failure class visible at all.
    --
    -- DROPPED for shape drift, each returning ONE TABLE where the retired global
    -- returned a tuple: GetSpellCooldown (SpellCooldownInfo), GetSpellCharges
    -- (SpellChargeInfo), GetSpellInfo (SpellInfo). All three remain reachable
    -- dotted as C_Spell.<name>, which is unambiguous about which API is meant.
    --
    -- KEPT, with the reason each is safe:
    --   IsSpellUsable           no retired global of this BARE name; the old
    --                           one was IsUsableSpell, a different name
    --   IsCurrentSpell          boolean before and after
    --   GetAuraDataBySpellName  no retired global of this bare name
    --   GetPlayerAuraBySpellID  no retired global of this bare name
    --   GetItemCount            deprecated global still returns number count
    --   GetItemCooldown         deprecated global still returns the same
    --                           start, duration, enable triple
    env.IsSpellUsable = spellAPI.IsSpellUsable
    env.IsCurrentSpell = spellAPI.IsCurrentSpell
    env.GetAuraDataBySpellName = auraAPI.GetAuraDataBySpellName
    env.GetPlayerAuraBySpellID = auraAPI.GetPlayerAuraBySpellID
    env.GetItemCount = itemAPI.GetItemCount
    env.GetItemCooldown = itemAPI.GetItemCooldown
    -- UnitHealthPercent: tostring round-trip launders the WoW "secret number"
    -- taint on UnitHealth/UnitHealthMax outputs so the resulting value can be
    -- compared in insecure code without taint cascade. Same body as the
    -- RecommendationEvaluator sibling.
    env.UnitHealthPercent = function(unit)
        unit = unit or "player"
        if not UnitExists(unit) then
            return 0
        end
        local hMaxRaw = UnitHealthMax(unit) or 0
        local hCurRaw = UnitHealth(unit) or 0
        local hMax = tonumber(tostring(hMaxRaw)) or 0
        local hCur = tonumber(tostring(hCurRaw)) or 0
        if hMax <= 0 then
            return 0
        end
        return hCur / hMax * 100
    end
    helpers.UnitHealthPercent = env.UnitHealthPercent
    -- Blocked-global recorder. Counts EVERY hit so the telemetry shows how hot
    -- the read is, but logs only the FIRST hit per distinct name: a variable
    -- evaluated 200 times per fight must not emit 200 debug lines.
    setmetatable(env, {
        __index = function(_, key)
            local keyName = tostring(key)
            VS._sandboxBlocked[keyName] = (VS._sandboxBlocked[keyName] or 0) + 1
            if not sandboxLogged[keyName] then
                sandboxLogged[keyName] = true
                GRIPEMS:Debug(string.format(L["GEMS_VAR_SANDBOX_BLOCKED"], tostring(name), keyName))
            end
            return nil
        end,
    })
    return env
end

--- Get the blocked-global telemetry recorded by the variable sandbox.
--- Shallow copy so callers (Variables tab, test suite) can read the counts
--- without holding a reference to the private table.
--- @return table blocked global name -> integer hit count
function VS:GetSandboxBlocked()
    local copy = {}
    for key, count in pairs(VS._sandboxBlocked) do
        copy[key] = count
    end
    return copy
end

--- Evaluate a single variable by name.
--- Uses pcall + loadstring with "return " prefix so expressions work.
--- @param name string Variable name
--- @return any value Result of evaluation, or nil on failure
--- @return string|nil err Error message on failure
function VS:Evaluate(name)
    if not name then
        return nil, "No name"
    end
    local store = GetStore()
    local varDef = store[name]
    if not varDef then
        return nil, "Not found"
    end
    if varDef.disabled then
        return nil, "Disabled"
    end
    if not varDef.funct or varDef.funct == "" then
        return nil, "Empty function"
    end

    -- Cache check: reuse compiled function if source text has not changed
    local fn
    if VS._cachedFunctSrc[name] == varDef.funct and cachedFunctFn[name] then
        fn = cachedFunctFn[name]
    else
        -- NOTE: pcall catches runtime errors but not infinite loops.
        -- WoW's coroutine watchdog kills runaway scripts after ~8 seconds,
        -- which prevents a permanent freeze but still causes a noticeable hang.
        -- A timeout mechanism is not feasible in WoW's single-threaded Lua.
        --
        -- The body runs under an EXPLICIT WHITELIST environment built by
        -- BuildVariableSandbox above. Any global not on that whitelist -- every
        -- other addon's namespace, every SavedVariables global, the loader and
        -- metatable primitives -- resolves to nil and is recorded on
        -- VS._sandboxBlocked plus logged once per name per session.
        -- Engine/RecommendationEvaluator.lua BuildSandbox is the sibling
        -- implementation of the same pattern.
        local loadErr
        fn, loadErr = loadstring("return " .. varDef.funct)
        if not fn then
            GRIPEMS:Debug(string.format(L["GEMS_VAR_EVAL_ERROR"], name, tostring(loadErr)))
            return nil, loadErr
        end
        -- Order matters: the env must be attached BEFORE the two cache
        -- assignments below, or the cache-hit path at the top of this function
        -- serves an unsandboxed function on every later evaluation. Functions
        -- the body itself creates inherit this env at closure-creation time, so
        -- the auto-call of a function-typed result further down is sandboxed too.
        if setfenv then
            setfenv(fn, BuildVariableSandbox(name))
        end
        VS._cachedFunctSrc[name] = varDef.funct
        cachedFunctFn[name] = fn
    end

    local ok, result = pcall(fn)
    if not ok then
        GRIPEMS:Debug(string.format(L["GEMS_VAR_EVAL_ERROR"], name, tostring(result)))
        return nil, result
    end

    -- Function-type variables (e.g. "function() return X end") need auto-calling.
    -- loadstring("return function()...end") returns the function itself; call it
    -- to get the actual value, matching legacy evaluator behavior.
    if type(result) == "function" then
        ok, result = pcall(result)
        if not ok then
            GRIPEMS:Debug(string.format(L["GEMS_VAR_EVAL_ERROR"], name, tostring(result)))
            return nil, result
        end
    end

    return result
end

--- Evaluate all enabled variables and return a name -> value table.
--- @return table name -> value mapping (skips disabled variables)
function VS:EvaluateAll()
    local store = GetStore()
    local results = {}
    for name, varDef in pairs(store) do
        if not varDef.disabled then
            local value = self:Evaluate(name)
            results[name] = value
            cachedValues[name] = value
        end
    end
    return results
end

--- Validate a variable name.
--- @param name string Name to validate
--- @return boolean valid
--- @return string|nil error message
function VS:ValidateName(name)
    if not name or name == "" then
        return false, L["GEMS_VAR_NAME_EMPTY"]
    end
    if type(name) ~= "string" then
        return false, L["GEMS_VAR_INVALID_NAME"]
    end
    if #name > D.VAR_MAX_NAME then
        return false, string.format(L["GEMS_VAR_NAME_TOO_LONG"], D.VAR_MAX_NAME)
    end
    if not name:match("^[%w_]+$") then
        return false, L["GEMS_VAR_INVALID_NAME"]
    end
    return true
end

--- Validate a function body string (loadstring test, no execution).
--- @param funcStr string Function body to validate
--- @return boolean valid
--- @return string|nil error message
function VS:ValidateFunction(funcStr)
    if not funcStr or funcStr == "" then
        return true -- empty is valid (just evaluates to nil)
    end
    if type(funcStr) ~= "string" then
        return false, "function body must be a string"
    end
    if #funcStr > D.VAR_MAX_FUNC then
        return false, string.format(L["GEMS_VAR_FUNC_TOO_LONG"], D.VAR_MAX_FUNC)
    end
    -- No setfenv here on purpose: this loadstring COMPILES and never calls the
    -- chunk, so there is no environment for it to reach. The sandbox belongs on
    -- the execution site in VS:Evaluate. Do not "fix" this to match.
    local fn, err = loadstring("return " .. funcStr)
    if not fn then
        return false, err
    end
    return true
end

--- Scan all sequences for references to a variable (~name~ pattern).
--- Checks versioned steps (T2-2+) and legacy flat steps as fallback.
--- @param name string Variable name to search for
--- @return table Array of sequence names that reference this variable
function VS:GetReferences(name)
    if not name then
        return {}
    end
    local refs = {}
    local pattern = "~" .. name .. "~"
    if _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.sequences then
        for seqName, seqData in pairs(GRIP_EMS_CHAR.sequences) do
            local found = false
            -- Check versioned steps (T2-2+ layout)
            if seqData.versions and type(seqData.versions) == "table" then
                for _, ver in ipairs(seqData.versions) do
                    if ver and ver.steps then
                        for _, step in ipairs(ver.steps) do
                            if type(step) == "string" and step:find(pattern, 1, true) then
                                found = true
                                break
                            end
                        end
                    end
                    if found then
                        break
                    end
                end
            end
            -- Fallback: legacy flat steps (pre-T2-2 un-migrated data)
            if not found and seqData.steps then
                for _, step in ipairs(seqData.steps) do
                    if type(step) == "string" and step:find(pattern, 1, true) then
                        found = true
                        break
                    end
                end
            end
            if found then
                refs[#refs + 1] = seqName
            end
        end
    end
    table.sort(refs)
    return refs
end

--- Rebuild event registration based on all variable definitions.
--- Parses each varDef.events string, registers unique events on a hidden frame.
function VS:RebuildEventRegistration()
    -- Reuse surviving C++ frame across /reload, or create on first call
    eventFrame = eventFrame or _G["GRIPEMS_VarStoreEvent"] or CreateFrame("Frame", "GRIPEMS_VarStoreEvent")
    eventFrame:UnregisterAllEvents()
    eventFrame:SetScript("OnEvent", function(_, event)
        VS:OnVariableEvent(event)
    end)

    -- Collect unique events from all variable definitions
    local store = GetStore()
    local uniqueEvents = {}
    for _, varDef in pairs(store) do
        if not varDef.disabled and (varDef.eventsEnabled ~= false) and varDef.events and varDef.events ~= "" then
            for eventName in varDef.events:gmatch("[^,]+") do
                eventName = eventName:match("^%s*(.-)%s*$") -- trim whitespace
                if eventName ~= "" then
                    uniqueEvents[eventName] = true
                end
            end
        end
    end

    -- Selective diff: unregister removed events
    for event in pairs(registeredEvents) do
        if not uniqueEvents[event] then
            eventFrame:UnregisterEvent(event)
        end
    end

    -- Register new events
    for event in pairs(uniqueEvents) do
        if not registeredEvents[event] then
            local ok = pcall(function()
                eventFrame:RegisterEvent(event)
            end)
            if not ok then
                GRIPEMS:Debug("Invalid event for variable: " .. event)
                uniqueEvents[event] = nil
            end
        end
    end

    -- Update tracking table
    registeredEvents = uniqueEvents
end

--- Handle a WoW event that a variable is listening to.
--- Queues affected variables for re-evaluation with consolidation timer.
--- @param event string WoW event name
function VS:OnVariableEvent(event)
    -- Find all variables listening to this event
    local store = GetStore()
    for name, varDef in pairs(store) do
        if not varDef.disabled and (varDef.eventsEnabled ~= false) and varDef.events and varDef.events ~= "" then
            for eventName in varDef.events:gmatch("[^,]+") do
                eventName = eventName:match("^%s*(.-)%s*$")
                if eventName == event then
                    pendingReeval[name] = true
                    break
                end
            end
        end
    end

    -- Start consolidation timer if not already running
    if next(pendingReeval) and not consolidationTimer then
        if C_Timer and C_Timer.NewTimer then
            consolidationTimer = C_Timer.NewTimer(D.VAR_CONSOLIDATION, function()
                VS:ProcessPendingReeval()
                consolidationTimer = nil
            end)
        end
    end
end

--- Process all pending variable re-evaluations.
--- Fires VARIABLE_UPDATED only if the value actually changed.
--- Uses type-aware comparison to avoid false positives from table/function
--- values whose tostring() address changes on every loadstring call.
function VS:ProcessPendingReeval()
    local toReeval = pendingReeval
    pendingReeval = {}

    for name in pairs(toReeval) do
        local newValue = self:Evaluate(name)
        CheckLocaleRisk(name, newValue)
        CheckPrivateAuraRisk(name, newValue)
        TagVariableValue(name, newValue)
        local oldValue = cachedValues[name]

        local changed = false
        local tNew = type(newValue)
        local tOld = type(oldValue)

        if tNew ~= tOld then
            changed = true
        elseif tNew == "table" then
            -- Shallow comparison: only top-level key/value pairs are checked.
            -- Nested table changes (e.g., t.sub.field = x) will NOT trigger
            -- VARIABLE_UPDATED. Variables should return simple types (string,
            -- number, boolean) for reliable change detection.
            for k, v in pairs(newValue) do
                if oldValue[k] ~= v then
                    changed = true
                    break
                end
            end
            if not changed then
                for k in pairs(oldValue) do
                    if newValue[k] == nil then
                        changed = true
                        break
                    end
                end
            end
        elseif tNew == "function" or tNew == "userdata" or tNew == "thread" then
            -- Non-comparable types: compare source text instead of identity
            local store = GetStore()
            local varDef = store[name]
            local src = varDef and varDef.funct or ""
            local cachedSrc = VS._cachedFunctSrc and VS._cachedFunctSrc[name]
            if src ~= cachedSrc then
                changed = true
                VS._cachedFunctSrc = VS._cachedFunctSrc or {}
                VS._cachedFunctSrc[name] = src
            end
        else
            -- Primitives: string, number, boolean, nil
            changed = (newValue ~= oldValue)
        end

        if changed then
            cachedValues[name] = newValue
            if GRIPEMS.Fire then
                GRIPEMS:Fire("VARIABLE_UPDATED", name, newValue)
            end
        end
    end
end

--- Get the locale risk flag for a variable (if its value is a known spell name).
--- @param name string Variable name
--- @return table|nil { spellName, spellID } or nil if no risk
function VS:GetLocaleRisk(name)
    return localeRiskFlags[name]
end

--- Get the private-aura risk flag for a variable (if its value
--- is a known spell name for a Private aura).
--- @param name string Variable name
--- @return table|nil { spellName, spellID } or nil if no risk
function VS:GetPrivateAuraRisk(name)
    return privateAuraFlags[name]
end

--- Get the cached value of a variable (last evaluated result).
--- @param name string Variable name
--- @return any Cached value, or nil if not cached
function VS:GetCachedValue(name)
    return cachedValues[name]
end
