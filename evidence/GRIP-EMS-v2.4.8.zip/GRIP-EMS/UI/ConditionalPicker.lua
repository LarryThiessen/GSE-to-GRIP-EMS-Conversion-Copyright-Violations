-- GRIP-EMS: Conditional Picker
-- Created: 2026-05-10
-- Updated: 2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.
--
-- Popup widget triggered by the [v] button next to the Cond box in the
-- IF detail pane. Renders three tabs (Combat-relevant / General-purpose /
-- UI-state) of categorized conditional rows. On Apply, builds a
-- comma-separated AND token list and inserts at the cursor in the target
-- Cond box. The picker is ADDITIVE -- it inserts tokens; it does not
-- replace the box. Re-opening on a non-empty Cond box does not round-trip
-- existing text into the picker tree (spec section 10.7).

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

GRIPEMS.ConditionalPicker = {}
local CP = GRIPEMS.ConditionalPicker

---------------------------------------------------------------------------
-- Constants
---------------------------------------------------------------------------
local PICKER_WIDTH = 420
local PICKER_HEIGHT = 480
local TAB_HEIGHT = 22
local ROW_HEIGHT = 24
local FOOTER_HEIGHT = 32
local CONTENT_PAD = 8
local SCROLL_RIGHT_PAD = 22

---------------------------------------------------------------------------
-- State
---------------------------------------------------------------------------
CP._frame = nil
CP._targetEditBox = nil
CP._anchorFrame = nil
CP._onApply = nil
CP._activeTab = "combat"

-- rowState: shared across opens (param values persist; selected/negate
-- are reset on each Open call so a stale tickbox doesn't leak through).
CP._rowState = {}

---------------------------------------------------------------------------
-- State helpers
---------------------------------------------------------------------------

local function defaultParamValue(row)
    if not row.paramType then
        return nil
    elseif row.paramType == "integer" then
        return (row.paramOptions and row.paramOptions.min) or 1
    elseif row.paramType == "modkey" then
        return (row.paramOptions and row.paramOptions[1]) or "shift"
    elseif row.paramType == "petname" then
        return ""
    elseif row.paramType == "spellname" then
        return ""
    elseif row.paramType == "itemtype" then
        return (row.paramOptions and row.paramOptions[1]) or ""
    elseif row.paramType == "houselocation" then
        return (row.paramOptions and row.paramOptions[1]) or "inside"
    end
    return nil
end

local function ensureRowState()
    local data = GRIPEMS.ConditionalPickerData
    if not data then
        return
    end
    for _, row in ipairs(data.rows) do
        local st = CP._rowState[row.key]
        if not st then
            CP._rowState[row.key] = {
                selected = false,
                negate = false,
                paramValue = defaultParamValue(row),
            }
        end
    end
end

local function resetSelections()
    for _, st in pairs(CP._rowState) do
        st.selected = false
        st.negate = false
        -- paramValue persists across opens so a user's last spec:N stays.
    end
end

---------------------------------------------------------------------------
-- Token assembly
---------------------------------------------------------------------------

local function buildToken(row, st)
    local key = row.key
    local token

    if row.paramType == "integer" then
        local v = st.paramValue or (row.paramOptions and row.paramOptions.min) or 1
        token = key .. ":" .. tostring(v)
    elseif row.paramType == "modkey" then
        local v = st.paramValue or "shift"
        token = key .. ":" .. v
    elseif row.paramType == "petname" then
        local v = st.paramValue or ""
        if v == "" then
            token = key
        else
            token = key .. ":" .. v
        end
    elseif row.paramType == "spellname" then
        local v = st.paramValue or ""
        if v == "" then
            token = key
        else
            token = key .. ":" .. v
        end
    elseif row.paramType == "itemtype" then
        local v = st.paramValue or ""
        if v == "" then
            token = key
        else
            token = key .. ":" .. v
        end
    elseif row.paramType == "houselocation" then
        local v = st.paramValue or "inside"
        token = key .. ":" .. v
    elseif row.paramType == "specname" then
        -- H1.5: paramValue is integer-as-string ("1", "2", ...)
        local v = st.paramValue or "1"
        token = key .. ":" .. tostring(v)
    elseif row.paramType == "formname" then
        local v = st.paramValue or "1"
        token = key .. ":" .. tostring(v)
    elseif row.paramType == "stancename" then
        local v = st.paramValue or "1"
        token = key .. ":" .. tostring(v)
    elseif row.paramType == "petfamily" then
        -- H1.5: paramValue is the family/demon name (e.g. "Cat", "Imp")
        -- or "" for the bare-key case ("pet" with no argument matches
        -- "any pet exists").
        local v = st.paramValue or ""
        if v == "" then
            token = key
        else
            token = key .. ":" .. tostring(v)
        end
    else
        token = key
    end

    -- Spec section 5.2: double-negation collapse.
    if st.negate then
        if token:sub(1, 2) == "no" then
            token = token:sub(3)
        else
            token = "no" .. token
        end
    end

    return token
end

-- H4b: export for ConditionalBuilder.lua to reuse the canonical
-- per-paramType token-assembly logic without duplication.
CP._buildToken = buildToken

---------------------------------------------------------------------------
-- Cursor insertion
---------------------------------------------------------------------------

-- DEAD CODE since H1.2; superseded by replace-on-Apply in doApply.
-- Retained in case a future H4 modal builder wants cursor-insert semantics.
-- luacheck: push ignore insertAtCursor
local function insertAtCursor(eb, text)
    if not eb or not text or text == "" then
        return
    end
    eb:SetFocus()
    eb:Insert(text)
end
-- luacheck: pop

local function doApply()
    local data = GRIPEMS.ConditionalPickerData
    if not data then
        return
    end
    -- H1.2 safety: Apply is gated when the round-trip detected a
    -- multi-bracket OR group. The button is also SetEnabled(false) in
    -- CP:Open, but this is the structural backstop.
    if CP._roundtripBlocked then
        return
    end

    local tokens = {}
    for _, row in ipairs(data.rows) do
        local st = CP._rowState[row.key]
        if st and st.selected then
            tokens[#tokens + 1] = buildToken(row, st)
        end
    end

    if CP._targetEditBox then
        -- H1.2: replace-on-Apply. Previous behavior concatenated at the
        -- cursor and would duplicate tokens on re-Apply. The picker now
        -- owns the Cond box; round-trip parsing keeps prior context.
        local joined = table.concat(tokens, ",")
        CP._targetEditBox:SetText(joined)
        local handler = CP._targetEditBox:GetScript("OnTextChanged")
        if handler then
            pcall(handler, CP._targetEditBox, true)
        end
    end

    if CP._onApply then
        pcall(CP._onApply)
    end

    CP:Close()
end

---------------------------------------------------------------------------
-- Row rendering
---------------------------------------------------------------------------

local _rowFrames = {}

local function clearRows()
    for _, rf in ipairs(_rowFrames) do
        rf:Hide()
        rf:SetParent(nil)
        rf:ClearAllPoints()
    end
    wipe(_rowFrames)
end

-- DEAD CODE since H1.2; superseded by buildEnumDropdown via the buildParamInput
-- dispatcher. Retained for potential future restoration.
-- luacheck: push ignore buildIntegerInput
local function buildIntegerInput(parent, st, opts)
    local UI = GRIPEMS.UI
    local C = UI.Colors
    local fontPath = UI:GetFontPath()
    local minV = opts and opts.min or 1
    local maxV = opts and opts.max or 10

    local box = CreateFrame("EditBox", nil, parent, "BackdropTemplate")
    box:SetSize(36, 18)
    box:SetAutoFocus(false)
    box:SetMaxLetters(3)
    box:SetNumeric(true)
    UI:ApplyBackdrop(box, UI.Backdrops.panel, C.bgInput, C.border)
    box:SetTextInsets(4, 4, 1, 1)
    box:SetFont(fontPath, 10, "")
    box:SetTextColor(C.textPrimary:GetRGBA())
    box:SetText(tostring(st.paramValue or minV))
    box:SetScript("OnTextChanged", function(self)
        local n = tonumber(self:GetText() or "")
        if n then
            if n < minV then
                n = minV
            end
            if n > maxV then
                n = maxV
            end
            st.paramValue = n
        end
    end)
    box:SetScript("OnEnterPressed", function(self)
        self:ClearFocus()
    end)
    box:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
    end)
    GRIPEMS.Focus:HookEditBox(box)
    return box, 36
end
-- luacheck: pop

-- DEAD CODE since H1.2; superseded by buildEnumDropdown via the buildParamInput
-- dispatcher. Retained for potential future restoration.
-- luacheck: push ignore buildModkeyInput
local function buildModkeyInput(parent, st, opts)
    local UI = GRIPEMS.UI
    local C = UI.Colors
    local container = CreateFrame("Frame", nil, parent)
    local entries = opts or {}
    local btnW = 26
    container:SetSize(#entries * btnW, 18)

    local btns = {}
    local function refresh()
        for _, b in ipairs(btns) do
            if b._key == st.paramValue then
                b:SetBackdropColor(C.bgRowSelected:GetRGBA())
                b._lbl:SetTextColor(C.textPrimary:GetRGBA())
            else
                b:SetBackdropColor(0, 0, 0, 0)
                b._lbl:SetTextColor(C.textSecondary:GetRGBA())
            end
        end
    end

    for i, name in ipairs(entries) do
        local b = CreateFrame("Button", nil, container, "BackdropTemplate")
        b:SetSize(btnW, 18)
        b:SetBackdrop(UI.Backdrops.panelNoBorder)
        b:SetPoint("LEFT", container, "LEFT", (i - 1) * btnW, 0)
        local lbl = b:CreateFontString(nil, "OVERLAY")
        UI:SetFont(lbl, 9)
        lbl:SetPoint("CENTER", b, "CENTER")
        lbl:SetText(name)
        b._key = name
        b._lbl = lbl
        b:SetScript("OnClick", function(self)
            st.paramValue = self._key
            refresh()
        end)
        btns[#btns + 1] = b
    end
    refresh()
    return container, container:GetWidth()
end
-- luacheck: pop

local function buildTextInput(parent, st, placeholder)
    local UI = GRIPEMS.UI
    local C = UI.Colors
    local fontPath = UI:GetFontPath()
    local box = CreateFrame("EditBox", nil, parent, "BackdropTemplate")
    box:SetSize(96, 18)
    box:SetAutoFocus(false)
    box:SetMaxLetters(40)
    UI:ApplyBackdrop(box, UI.Backdrops.panel, C.bgInput, C.border)
    box:SetTextInsets(4, 4, 1, 1)
    box:SetFont(fontPath, 10, "")
    box:SetTextColor(C.textPrimary:GetRGBA())
    box:SetText(tostring(st.paramValue or ""))
    box:SetScript("OnTextChanged", function(self)
        st.paramValue = self:GetText() or ""
    end)
    box:SetScript("OnEnterPressed", function(self)
        self:ClearFocus()
    end)
    box:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
    end)
    if placeholder and placeholder ~= "" then
        local hint = box:CreateFontString(nil, "OVERLAY")
        UI:SetFont(hint, 9)
        hint:SetPoint("LEFT", box, "LEFT", 6, 0)
        hint:SetText(placeholder)
        hint:SetTextColor(C.textSecondary:GetRGBA())
        hint:SetAlpha(0.55)
        local function refreshHint()
            if (box:GetText() or "") == "" then
                hint:Show()
            else
                hint:Hide()
            end
        end
        box:HookScript("OnTextChanged", refreshHint)
        refreshHint()
    end
    GRIPEMS.Focus:HookEditBox(box)
    return box, 96
end

local function buildEnumDropdown(parent, st, opts)
    local UI = GRIPEMS.UI
    local C = UI.Colors

    -- H1.5: opts may be either a list of plain strings (back-compat:
    -- modkey, integer, itemtype, houselocation) or a list of
    -- { name = "...", value = "..." } pairs (new: specname, formname,
    -- stancename, petfamily). The display label is the human-friendly
    -- name; the canonical value is what gets stored in st.paramValue
    -- and emitted into the conditional token. Plain strings degenerate
    -- to name == value so the legacy callers keep working.
    local function getDisplayName(entry)
        if type(entry) == "table" then
            return entry.name or tostring(entry.value or "")
        end
        return tostring(entry)
    end

    local function getCanonicalValue(entry)
        if type(entry) == "table" then
            return entry.value or entry.name or ""
        end
        return entry
    end

    local function findDisplayNameForValue(optsList, value)
        if not optsList or value == nil then
            return tostring(value or "")
        end
        for _, entry in ipairs(optsList) do
            if getCanonicalValue(entry) == value then
                return getDisplayName(entry)
            end
        end
        return tostring(value)
    end

    local btn = CreateFrame("Button", nil, parent, "BackdropTemplate")
    btn:SetSize(96, 18)
    btn:SetBackdrop(UI.Backdrops.panel)
    btn:SetBackdropColor(C.bgInput:GetRGBA())
    btn:SetBackdropBorderColor(C.border:GetRGBA())

    local lbl = btn:CreateFontString(nil, "OVERLAY")
    UI:SetFont(lbl, 10)
    lbl:SetPoint("LEFT", btn, "LEFT", 4, 0)
    local initialDisplay
    if st.paramValue ~= nil and st.paramValue ~= "" then
        initialDisplay = findDisplayNameForValue(opts, st.paramValue)
    else
        initialDisplay = (opts and getDisplayName(opts[1])) or ""
    end
    lbl:SetText(initialDisplay)
    lbl:SetTextColor(C.textPrimary:GetRGBA())
    btn._lbl = lbl

    local arrow = btn:CreateFontString(nil, "OVERLAY")
    UI:SetFont(arrow, 9)
    arrow:SetPoint("RIGHT", btn, "RIGHT", -4, 0)
    arrow:SetText("v")
    arrow:SetTextColor(C.textSecondary:GetRGBA())

    -- H1.3.1 click-outside-close: a transparent click-eater frame at DIALOG
    -- strata, below the menu's FULLSCREEN_DIALOG strata. Clicks on the menu
    -- pass through to the menu (it's on top); clicks elsewhere hit the eater
    -- which hides the menu. The eater is shown when the menu opens (via the
    -- OnClick handler below) and hidden by the menu's OnHide.
    local menuEater = CreateFrame("Button", nil, UIParent)
    menuEater:SetAllPoints(UIParent)
    menuEater:SetFrameStrata("DIALOG")
    menuEater:RegisterForClicks("AnyDown")
    menuEater:Hide()
    menuEater:SetScript("OnClick", function()
        if btn._menu then
            btn._menu:Hide()
        end
    end)
    btn._menuEater = menuEater

    btn:SetScript("OnClick", function(self)
        -- H1.3.1 toggle: a second click on the trigger closes the open menu
        -- instead of stacking a second one on top.
        if self._menu and self._menu:IsShown() then
            self._menu:Hide()
            return
        end

        local menu = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
        UI:ApplyBackdrop(menu, UI.Backdrops.panel, C.bgMain, C.border)
        menu:SetFrameStrata("FULLSCREEN_DIALOG")
        local rowH = 18
        menu:SetSize(self:GetWidth(), rowH * (opts and #opts or 0) + 4)
        menu:SetPoint("TOPLEFT", self, "BOTTOMLEFT", 0, -2)

        self._menu = menu
        menu:SetScript("OnHide", function(m)
            if self._menu == m then
                self._menu = nil
            end
            if self._menuEater and self._menuEater:IsShown() then
                self._menuEater:Hide()
            end
        end)

        for i, entry in ipairs(opts or {}) do
            local displayName = getDisplayName(entry)
            local canonicalValue = getCanonicalValue(entry)
            local item = CreateFrame("Button", nil, menu, "BackdropTemplate")
            item:SetSize(menu:GetWidth() - 4, rowH)
            item:SetPoint("TOPLEFT", menu, "TOPLEFT", 2, -((i - 1) * rowH + 2))
            item:SetBackdrop(UI.Backdrops.panelNoBorder)
            -- H1.3.1 default visibility: paint bgInput on creation and on
            -- leave so items are always legible. Without this the panelNoBorder
            -- backdrop renders against the white WHITE8x8 default and items
            -- appear white-on-white in their default state.
            item:SetBackdropColor(C.bgInput:GetRGBA())
            local itemLbl = item:CreateFontString(nil, "OVERLAY")
            UI:SetFont(itemLbl, 10)
            itemLbl:SetPoint("LEFT", item, "LEFT", 4, 0)
            itemLbl:SetText(displayName)
            itemLbl:SetTextColor(C.textPrimary:GetRGBA())
            item:SetScript("OnEnter", function(s)
                s:SetBackdropColor(C.bgRowHover:GetRGBA())
            end)
            item:SetScript("OnLeave", function(s)
                s:SetBackdropColor(C.bgInput:GetRGBA())
            end)
            item:SetScript("OnClick", function()
                st.paramValue = canonicalValue
                lbl:SetText(displayName)
                menu:Hide()
            end)
        end

        menu:Show()
        if self._menuEater then
            self._menuEater:Show()
        end
    end)
    return btn, 96
end

local function buildParamInput(parent, row, st, modalToHide)
    local opts = row.paramOptions
    if row.paramType == "integer" then
        -- H1.2: unified dropdown for enumerable integer ranges. Build a string
        -- list across [min, max] and route through buildEnumDropdown so the
        -- visible widget matches the modkey / itemtype / houselocation surface.
        local intOpts = opts or { min = 1, max = 4 }
        local minV = intOpts.min or 1
        local maxV = intOpts.max or 10
        local choices = {}
        for v = minV, maxV do
            choices[#choices + 1] = tostring(v)
        end
        return buildEnumDropdown(parent, st, choices)
    elseif row.paramType == "modkey" then
        -- H1.2: unified dropdown for modifier-key choice. Replaces the
        -- transparent button-row that rendered invisible in the inactive state.
        return buildEnumDropdown(parent, st, opts or {
            "shift",
            "ctrl",
            "alt",
            "lshift",
            "rshift",
            "lctrl",
            "rctrl",
            "lalt",
            "ralt",
        })
    elseif row.paramType == "petname" then
        return buildTextInput(parent, st, "name")
    elseif row.paramType == "spellname" then
        -- H1.6: trigger button opens SpellPicker in callback mode so the
        -- player browses / searches instead of typing a spell name.
        -- Callback receives the chosen entry and stores entry.name in
        -- st.paramValue. The trigger label reflects current value or a
        -- localized hint when empty.
        local UI = GRIPEMS.UI
        local C = UI.Colors
        local btn = CreateFrame("Button", nil, parent, "BackdropTemplate")
        btn:SetSize(96, 18)
        btn:SetBackdrop(UI.Backdrops.panel)
        btn:SetBackdropColor(C.bgInput:GetRGBA())
        btn:SetBackdropBorderColor(C.border:GetRGBA())
        local lbl = btn:CreateFontString(nil, "OVERLAY")
        UI:SetFont(lbl, 10)
        lbl:SetPoint("LEFT", btn, "LEFT", 4, 0)
        lbl:SetPoint("RIGHT", btn, "RIGHT", -12, 0)
        lbl:SetJustifyH("LEFT")
        lbl:SetWordWrap(false)
        lbl:SetTextColor(C.textPrimary:GetRGBA())
        local function refreshLabel()
            local v = tostring(st.paramValue or "")
            if v ~= "" then
                lbl:SetText(v)
            else
                lbl:SetText(L["GEMS_IF_PICKER_SEARCH_SPELL_HINT"] or "Search spell...")
            end
        end
        refreshLabel()
        local arrow = btn:CreateFontString(nil, "OVERLAY")
        UI:SetFont(arrow, 9)
        arrow:SetPoint("RIGHT", btn, "RIGHT", -4, 0)
        arrow:SetText("v")
        arrow:SetTextColor(C.textSecondary:GetRGBA())
        btn:SetScript("OnClick", function(self)
            local SP = GRIPEMS.SpellPicker
            if not SP then
                return
            end
            -- Phase H1.7: hide the parent modal while SP is open so the wider
            -- chrome does not bleed out around the narrower SP frame (both
            -- share FrameStrata DIALOG). onCloseCallback re-shows it on every
            -- SP close path (Apply, Cancel, X, Esc).
            -- H4c: modalToHide defaults to CP._frame for picker callers;
            -- ConditionalBuilder passes CB._frame so the hide/show handoff
            -- follows the active surface instead of always being the picker.
            local hideTarget = modalToHide or CP._frame
            if hideTarget and hideTarget:IsShown() then
                hideTarget:Hide()
            end
            SP:Show(nil, self, {
                hideConditionals = true,
                insertCallback = function(spellEntry)
                    st.paramValue = (spellEntry and spellEntry.name) or ""
                    refreshLabel()
                    SP:Hide()
                end,
                onCloseCallback = function()
                    if hideTarget then
                        hideTarget:Show()
                    end
                end,
            })
        end)
        return btn, 96
    elseif row.paramType == "itemtype" then
        return buildEnumDropdown(parent, st, opts)
    elseif row.paramType == "houselocation" then
        return buildEnumDropdown(parent, st, opts)
    elseif row.paramType == "specname" then
        -- H1.5: dynamic per-class spec list. GetSpecializationInfo
        -- returns the player's spec names by index; we build
        -- "<i> - <SpecName>" labels with integer-as-string canonical.
        local choices = {}
        local numSpecs = GetNumSpecializations and GetNumSpecializations() or 0
        for i = 1, numSpecs do
            local _, specName = GetSpecializationInfo(i)
            local label = i .. " - " .. (specName or ("Spec " .. i))
            choices[#choices + 1] = { name = label, value = tostring(i) }
        end
        if #choices == 0 then
            -- Fallback when the spec API is unavailable (e.g. inspect
            -- before login data arrives): plain integer dropdown 1-4.
            for i = 1, 4 do
                choices[#choices + 1] = { name = tostring(i), value = tostring(i) }
            end
        end
        return buildEnumDropdown(parent, st, choices)
    elseif row.paramType == "formname" then
        -- H1.5: per-class form dropdown. Druid is the modern user;
        -- other classes get a fallback integer dropdown 0-10 so the
        -- conditional remains editable even where forms do not apply.
        local data = GRIPEMS.ConditionalPickerData
        local _, classFile = UnitClass("player")
        local list = data and data.CLASS_FORMS and data.CLASS_FORMS[classFile]
        if list and #list > 0 then
            return buildEnumDropdown(parent, st, list)
        end
        local choices = {}
        for i = 0, 10 do
            choices[#choices + 1] = tostring(i)
        end
        return buildEnumDropdown(parent, st, choices)
    elseif row.paramType == "stancename" then
        -- H1.5: per-class stance dropdown. Warrior / DK / Monk are
        -- the modern users; other classes fall back to integer 1-3.
        local data = GRIPEMS.ConditionalPickerData
        local _, classFile = UnitClass("player")
        local list = data and data.CLASS_STANCES and data.CLASS_STANCES[classFile]
        if list and #list > 0 then
            return buildEnumDropdown(parent, st, list)
        end
        local choices = {}
        for i = 1, 3 do
            choices[#choices + 1] = tostring(i)
        end
        return buildEnumDropdown(parent, st, choices)
    elseif row.paramType == "petfamily" then
        -- H1.5: per-class pet dropdown. Hunter -> pet families;
        -- Warlock -> demon pet names; other classes -> free-text
        -- input so unusual conditional usage stays expressible.
        -- H1.5.1: when a class-specific list exists, render a composite
        -- with a small Family / Name toggle. Family mode shows the
        -- canonical dropdown; Name mode shows a free-text box for
        -- targeting a specific summoned pet by literal name (useful
        -- when multiple pets share the same family).
        local UI = GRIPEMS.UI
        local C = UI.Colors
        local data = GRIPEMS.ConditionalPickerData
        local _, classFile = UnitClass("player")
        local list
        if classFile == "HUNTER" and data and data.HUNTER_PET_FAMILIES then
            list = data.HUNTER_PET_FAMILIES
        elseif classFile == "WARLOCK" and data and data.WARLOCK_PETS then
            list = data.WARLOCK_PETS
        end
        if not list then
            return buildTextInput(parent, st, "name")
        end

        local function getCanon(entry)
            if type(entry) == "table" then
                return entry.value or entry.name or ""
            end
            return tostring(entry)
        end
        local function valueInList(v)
            if v == nil or v == "" then
                return true
            end
            for _, e in ipairs(list) do
                if getCanon(e) == v then
                    return true
                end
            end
            return false
        end
        if st.familyMode == nil then
            st.familyMode = valueInList(st.paramValue)
        end

        local container = CreateFrame("Frame", nil, parent)
        container:SetSize(124, 18)

        local toggle = CreateFrame("Button", nil, container, "BackdropTemplate")
        toggle:SetSize(22, 18)
        toggle:SetBackdrop(UI.Backdrops.panel)
        toggle:SetBackdropColor(C.bgInput:GetRGBA())
        toggle:SetBackdropBorderColor(C.border:GetRGBA())
        toggle:SetPoint("LEFT", container, "LEFT", 0, 0)
        local toggleLbl = toggle:CreateFontString(nil, "OVERLAY")
        UI:SetFont(toggleLbl, 9)
        toggleLbl:SetPoint("CENTER", toggle, "CENTER")
        toggleLbl:SetTextColor(C.textPrimary:GetRGBA())

        local dropdownBtn = buildEnumDropdown(container, st, list)
        dropdownBtn:ClearAllPoints()
        dropdownBtn:SetPoint("LEFT", toggle, "RIGHT", 4, 0)

        local textBox = buildTextInput(container, st, "name")
        textBox:ClearAllPoints()
        textBox:SetPoint("LEFT", toggle, "RIGHT", 4, 0)

        local function applyMode()
            if st.familyMode then
                toggleLbl:SetText(L["GEMS_IF_PICKER_PETMODE_FAMILY"] or "F")
                dropdownBtn:Show()
                textBox:Hide()
            else
                toggleLbl:SetText(L["GEMS_IF_PICKER_PETMODE_NAME"] or "N")
                dropdownBtn:Hide()
                textBox:Show()
                textBox:SetText(tostring(st.paramValue or ""))
            end
        end
        applyMode()

        toggle:SetScript("OnClick", function()
            st.familyMode = not st.familyMode
            if st.familyMode and not valueInList(st.paramValue) then
                st.paramValue = nil
            end
            applyMode()
        end)
        toggle:SetScript("OnEnter", function(self)
            if UI.ShowTooltip then
                UI:ShowTooltip(self, L["GEMS_IF_PICKER_PETMODE_TOOLTIP"] or "Toggle family list / custom pet name")
            end
        end)
        toggle:SetScript("OnLeave", function()
            if UI.HideTooltip then
                UI:HideTooltip()
            end
        end)

        return container, 124
    end
    return nil, 0
end

-- H4c: export for ConditionalBuilder.lua to reuse the canonical
-- paramType-to-widget dispatcher. The 4th arg (modalToHide) lets the
-- modal pass its own frame for SpellPicker hide-while-open handoff so
-- the builder modal hides instead of the picker.
CP._buildParamInput = buildParamInput

local function createRow(parent, row, yOffset)
    local UI = GRIPEMS.UI
    local C = UI.Colors

    local rf = CreateFrame("Frame", nil, parent)
    rf:SetHeight(ROW_HEIGHT)
    rf:SetPoint("LEFT", parent, "LEFT", 6, 0)
    rf:SetPoint("RIGHT", parent, "RIGHT", -6, 0)
    rf:SetPoint("TOP", parent, "TOP", 0, yOffset)

    local st = CP._rowState[row.key]

    -- Tickbox
    local tick = CreateFrame("CheckButton", nil, rf, "UICheckButtonTemplate")
    tick:SetSize(20, 20)
    tick:SetPoint("LEFT", rf, "LEFT", 0, 0)
    tick:SetChecked(st.selected and true or false)
    tick:SetScript("OnClick", function(self)
        st.selected = self:GetChecked() and true or false
    end)

    -- Label
    local label = rf:CreateFontString(nil, "OVERLAY")
    UI:SetFont(label, 11)
    label:SetPoint("LEFT", tick, "RIGHT", 4, 0)
    label:SetText(L[row.labelKey] or row.key)
    label:SetTextColor(C.textPrimary:GetRGBA())

    -- Tooltip on hover (anchor on the label area frame)
    rf:EnableMouse(true)
    rf:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText(L[row.labelKey] or row.key, 1, 1, 1)
        local body = L[row.tooltipKey]
        if body and body ~= "" then
            GameTooltip:AddLine(body, 0.9, 0.9, 0.9, true)
        end
        GameTooltip:Show()
    end)
    rf:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)

    -- Negation toggle (H1.2: bumped 16->18px + font 9->10 + primary text color
    -- so the "not" affordance is legible on the dark backdrop). H1.3.1: hover
    -- tooltip describes the negation prefix (mod:shift -> nomod:shift, harm
    -- -> noharm) per spec section 5.2 (DeMorgan). The rf row-tooltip above
    -- hides via rf:OnLeave before negBox:OnEnter fires; GameTooltip is
    -- single-instance so SetOwner reassigns cleanly.
    local negBox
    if row.negatable then
        negBox = CreateFrame("CheckButton", nil, rf, "UICheckButtonTemplate")
        negBox:SetSize(18, 18)
        negBox:SetPoint("RIGHT", rf, "RIGHT", -4, 0)
        negBox:SetChecked(st.negate and true or false)
        negBox:SetScript("OnClick", function(self)
            st.negate = self:GetChecked() and true or false
        end)
        local function showNegateTooltip(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText(L["GEMS_IF_PICKER_NEGATE"] or "not", 1, 1, 1)
            local body = L["GEMS_IF_PICKER_NEGATE_TOOLTIP"]
            if body and body ~= "" then
                GameTooltip:AddLine(body, 0.9, 0.9, 0.9, true)
            end
            GameTooltip:Show()
        end
        local function hideNegateTooltip()
            GameTooltip:Hide()
        end
        negBox:SetScript("OnEnter", showNegateTooltip)
        negBox:SetScript("OnLeave", hideNegateTooltip)
        local negLbl = rf:CreateFontString(nil, "OVERLAY")
        UI:SetFont(negLbl, 10)
        negLbl:SetPoint("RIGHT", negBox, "LEFT", -2, 0)
        negLbl:SetText(L["GEMS_IF_PICKER_NEGATE"] or "not")
        negLbl:SetTextColor(C.textPrimary:GetRGBA())
    end

    -- Param input
    if row.paramType then
        local input = buildParamInput(rf, row, st)
        if input then
            input:ClearAllPoints()
            local rightAnchor = negBox or rf
            local rightPad = negBox and -28 or -4
            input:SetPoint("RIGHT", rightAnchor, "LEFT", rightPad, 0)
        end
    end

    return rf
end

---------------------------------------------------------------------------
-- Tab rendering
---------------------------------------------------------------------------

local function renderActiveTab()
    local frame = CP._frame
    if not frame or not frame.scrollChild then
        return
    end
    clearRows()

    local data = GRIPEMS.ConditionalPickerData
    if not data then
        return
    end

    -- H1.3 fix: pin scrollChild width to scrollFrame's actual width.
    -- Without this, scrollChild's SetSize(1, 1) wins over the TOPLEFT +
    -- TOPRIGHT anchors for size-computation purposes (Blizzard ScrollFrame
    -- quirk), causing rf.RIGHT to collapse to rf.LEFT. RIGHT-anchored
    -- children (negBox, buildEnumDropdown buttons, etc.) then render
    -- outside the visible area and get clipped to a 2px sliver on the
    -- left edge. CP:Open is now structured so renderActiveTab runs
    -- AFTER frame:Show() so GetWidth() returns the resolved width.
    if frame.scrollFrame then
        local sfWidth = frame.scrollFrame:GetWidth()
        if sfWidth and sfWidth > 0 then
            frame.scrollChild:SetWidth(sfWidth)
        end
    end

    local rows = data.byCategory[CP._activeTab] or {}
    local content = frame.scrollChild

    for i, row in ipairs(rows) do
        local rf = createRow(content, row, -((i - 1) * (ROW_HEIGHT + 2)) - 4)
        _rowFrames[#_rowFrames + 1] = rf
    end
    content:SetHeight(#rows * (ROW_HEIGHT + 2) + 8)
end

local function refreshTabButtons()
    local frame = CP._frame
    if not frame or not frame.tabBtns then
        return
    end
    local C = GRIPEMS.UI.Colors
    for _, btn in ipairs(frame.tabBtns) do
        if btn._tabKey == CP._activeTab then
            btn:SetBackdropColor(C.bgRowSelected:GetRGBA())
            btn._lbl:SetTextColor(C.textPrimary:GetRGBA())
        else
            btn:SetBackdropColor(0, 0, 0, 0)
            btn._lbl:SetTextColor(C.textSecondary:GetRGBA())
        end
    end
end

local function setActiveTab(key)
    CP._activeTab = key
    refreshTabButtons()
    renderActiveTab()
end

---------------------------------------------------------------------------
-- Frame creation (lazy, single instance)
---------------------------------------------------------------------------

local function createFrame()
    if CP._frame then
        return CP._frame
    end

    local UI = GRIPEMS.UI
    local C = UI.Colors

    local frame = CreateFrame("Frame", "GRIPEMS_ConditionalPicker", UIParent, "BackdropTemplate")
    frame:SetSize(PICKER_WIDTH, PICKER_HEIGHT)
    frame:SetFrameStrata("DIALOG")
    frame:SetClampedToScreen(true)
    UI:ApplyBackdrop(frame, UI.Backdrops.panel, C.bgMain, C.border)
    if UI.RegisterPanelFrame then
        UI:RegisterPanelFrame(frame, "panel", "panel.conditionalPicker")
    end
    frame:Hide()

    if not tContains(UISpecialFrames, "GRIPEMS_ConditionalPicker") then
        tinsert(UISpecialFrames, "GRIPEMS_ConditionalPicker")
    end

    -- Movable via title drag
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", function(self)
        self:StartMoving()
    end)
    frame:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
    end)

    -- Title
    local title = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(title, 12)
    title:SetPoint("TOPLEFT", frame, "TOPLEFT", CONTENT_PAD, -6)
    title:SetText(L["GEMS_IF_PICKER_TITLE"] or "Conditional picker")
    title:SetTextColor(C.textPrimary:GetRGBA())

    -- Close button
    local closeBtn = CreateFrame("Button", nil, frame)
    closeBtn:SetSize(16, 16)
    closeBtn:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -4, -4)
    closeBtn:SetNormalTexture("Interface\\Buttons\\UI-Panel-MinimizeButton-Up")
    closeBtn:SetScript("OnClick", function()
        CP:Close()
    end)
    frame.closeBtn = closeBtn

    -- Tab strip
    local tabKeys = {
        { key = "combat", labelKey = "GEMS_IF_PICKER_TAB_COMBAT", fallback = "Combat-relevant" },
        { key = "general", labelKey = "GEMS_IF_PICKER_TAB_GENERAL", fallback = "General-purpose" },
        { key = "ui", labelKey = "GEMS_IF_PICKER_TAB_UI", fallback = "UI-state" },
    }
    local tabBtns = {}
    local tabAreaWidth = PICKER_WIDTH - CONTENT_PAD * 2
    local tabBtnWidth = math.floor(tabAreaWidth / #tabKeys)
    for i, t in ipairs(tabKeys) do
        local b = CreateFrame("Button", nil, frame, "BackdropTemplate")
        b:SetSize(tabBtnWidth, TAB_HEIGHT)
        b:SetBackdrop(UI.Backdrops.panelNoBorder)
        b:SetPoint("TOPLEFT", frame, "TOPLEFT", CONTENT_PAD + (i - 1) * tabBtnWidth, -28)
        local lbl = b:CreateFontString(nil, "OVERLAY")
        UI:SetFont(lbl, 10)
        lbl:SetPoint("CENTER", b, "CENTER")
        lbl:SetText(L[t.labelKey] or t.fallback)
        b._lbl = lbl
        b._tabKey = t.key
        b:SetScript("OnClick", function(self)
            setActiveTab(self._tabKey)
        end)
        tabBtns[i] = b
    end
    frame.tabBtns = tabBtns

    -- Scrollable content area
    local scrollFrame = CreateFrame("ScrollFrame", nil, frame, "UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT", frame, "TOPLEFT", CONTENT_PAD, -54)
    scrollFrame:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -SCROLL_RIGHT_PAD, FOOTER_HEIGHT + 4)
    frame.scrollFrame = scrollFrame

    local scrollChild = CreateFrame("Frame", nil, scrollFrame)
    scrollChild:SetSize(1, 1)
    scrollChild:SetPoint("TOPLEFT", scrollFrame, "TOPLEFT", 0, 0)
    scrollChild:SetPoint("TOPRIGHT", scrollFrame, "TOPRIGHT", 0, 0)
    scrollFrame:SetScrollChild(scrollChild)
    frame.scrollChild = scrollChild

    -- Footer: Apply / Convert / Cancel
    local applyBtn = UI:CreateButton(frame, L["GEMS_IF_PICKER_APPLY"] or "Apply", 70, 22)
    applyBtn:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -CONTENT_PAD, 6)
    applyBtn:SetScript("OnClick", doApply)
    frame.applyBtn = applyBtn

    -- H4c: picker -> builder escalation. Routes the picker's current
    -- selections into ConditionalBuilder as a single seeded clause via a
    -- synthetic AST shape mirroring MS.ParseCondBoxInput output. The
    -- picker closes before the builder opens; both share FrameStrata
    -- DIALOG so coexisting frames would bleed at runtime.
    local convertBtn = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    convertBtn:SetSize(140, 22)
    convertBtn:SetText(L["GEMS_IF_BUILDER_CONVERT_TO_OR"] or "Convert to OR group")
    convertBtn:SetPoint("RIGHT", applyBtn, "LEFT", -6, 0)
    convertBtn:SetScript("OnClick", function()
        local targetEditBox = CP._targetEditBox
        local CB = GRIPEMS.ConditionalBuilder
        if not targetEditBox or not CB or not CB.Open then
            return
        end
        local conditionals = {}
        local pickerData = GRIPEMS.ConditionalPickerData
        if pickerData and pickerData.rows then
            for _, row in ipairs(pickerData.rows) do
                local st = CP._rowState[row.key]
                if st and st.selected then
                    conditionals[#conditionals + 1] = {
                        key = row.key,
                        args = st.paramValue and { tostring(st.paramValue) } or nil,
                        neg = st.negate and true or false,
                    }
                end
            end
        end
        local syntheticParsed = {
            ast = {
                clauses = {
                    [1] = {
                        value = "",
                        conditions = {
                            [1] = { conditionals = conditionals },
                        },
                    },
                },
            },
            errors = {},
        }
        local onApplyClosure = CP._onApply
        CP:Close()
        CB:Open(targetEditBox, syntheticParsed, onApplyClosure, nil)
    end)
    frame.convertBtn = convertBtn

    local cancelBtn = UI:CreateButton(frame, L["GEMS_IF_PICKER_CANCEL"] or "Cancel", 70, 22)
    cancelBtn:SetPoint("RIGHT", convertBtn, "LEFT", -6, 0)
    cancelBtn:SetScript("OnClick", function()
        CP:Close()
    end)
    frame.cancelBtn = cancelBtn

    -- H1.2: round-trip warning label. Hidden by default; CP:Open shows it
    -- when the parsed Cond box content has multi-bracket OR groups (Phase H4
    -- modal builder territory). Anchored right against cancelBtn so the
    -- buttons do not overlap. Wrap-on lets long translated strings flow.
    local roundtripWarn = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(roundtripWarn, 10)
    roundtripWarn:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", CONTENT_PAD, 8)
    roundtripWarn:SetPoint("BOTTOMRIGHT", cancelBtn, "BOTTOMLEFT", -8, 0)
    roundtripWarn:SetText(
        L["GEMS_IF_PICKER_OR_GROUP_WARNING"]
            or "Multi-bracket OR groups not editable in picker (Phase H4); use Cancel to keep current value."
    )
    if C.textWarning then
        roundtripWarn:SetTextColor(C.textWarning:GetRGBA())
    else
        roundtripWarn:SetTextColor(1, 0.7, 0.2, 1)
    end
    roundtripWarn:SetJustifyH("LEFT")
    roundtripWarn:SetWordWrap(true)
    roundtripWarn:Hide()
    frame.roundtripWarn = roundtripWarn

    -- ESC closes
    frame:EnableKeyboard(true)
    frame:SetScript("OnKeyDown", function(self, key)
        -- Suspenders layer: independent of the Focus flag, query WoW
        -- directly for any focused EditBox. If found, propagate the key
        -- and let the EditBox handle it.
        if GetCurrentKeyBoardFocus and GetCurrentKeyBoardFocus() then
            pcall(self.SetPropagateKeyboardInput, self, true)
            return
        end
        if key == "ESCAPE" then
            CP:Close()
            self:SetPropagateKeyboardInput(false)
        else
            self:SetPropagateKeyboardInput(true)
        end
    end)

    CP._frame = frame
    return frame
end

---------------------------------------------------------------------------
-- Public API
---------------------------------------------------------------------------

--- Open the conditional picker anchored to anchorFrame, targeting targetEditBox.
--- @param targetEditBox EditBox The Cond box (or other free-text EditBox) to insert into
--- @param anchorFrame Frame|nil Optional frame to anchor the popup to (defaults to targetEditBox)
--- @param onApply function|nil Optional callback fired after Apply (used by StepListView to refresh preview)
function CP:Open(targetEditBox, anchorFrame, onApply)
    if not targetEditBox then
        return
    end
    ensureRowState()
    resetSelections()

    self._targetEditBox = targetEditBox
    self._anchorFrame = anchorFrame or targetEditBox
    self._onApply = onApply
    self._activeTab = "combat"
    self._roundtripBlocked = false

    -- H1.2 round-trip: parse the existing Cond box content via the Phase A
    -- grammar parser and hydrate row state so reopening on a non-empty box
    -- shows the user where they left off. Multi-bracket OR groups are not
    -- editable in the picker (Phase H4 modal builder is the path) -- detect
    -- and disable Apply with an inline warning instead of silently dropping
    -- the OR groups on Apply. Unrecognized conditionals (e.g. @focus
    -- targeting prefixes) are silently skipped on the round-trip; on Apply
    -- the Cond box is replaced wholesale so they are lost. Documented v1
    -- trade-off; the OR-group warning surface covers the multi-clause path.
    local existing = (targetEditBox:GetText() or ""):gsub("^%s+", ""):gsub("%s+$", "")
    if existing ~= "" then
        local MS = GRIPEMS.MacroSyntax
        local data = GRIPEMS.ConditionalPickerData
        if MS and MS.ParseCondBoxInput and data and data.byKey then
            local parsed = MS.ParseCondBoxInput(existing)
            if parsed and parsed.ast and parsed.ast.clauses then
                -- H4b: H1.2 multi-clause detection block retained for defense-
                -- in-depth. StepListView [v] OnClick now routes multi-clause
                -- input to ConditionalBuilder, so this branch is structurally
                -- unreachable. The check `#parsed.ast.clauses > 1` is also
                -- dead (the parser always produces one clauses[1]; the correct
                -- signal would be `#clauses[1].conditions > 1`). Kept for
                -- backstop in case ConditionalBuilder fails to load.
                if #parsed.ast.clauses > 1 then
                    -- Multi-bracket OR -- block Apply so the user has to
                    -- explicitly Cancel or empty the box and re-pick.
                    self._roundtripBlocked = true
                elseif #parsed.ast.clauses == 1 then
                    -- ParseCondBoxInput nests one extra level: each clause
                    -- has .conditions, and each entry there has a
                    -- .conditionals array with the actual key/neg/args.
                    local conds = parsed.ast.clauses[1].conditions or {}
                    for _, cond in ipairs(conds) do
                        local conditionals = cond.conditionals or {}
                        for _, c in ipairs(conditionals) do
                            local row = c.key and data.byKey[c.key] or nil
                            if row then
                                local st = CP._rowState[row.key]
                                if st then
                                    st.selected = true
                                    st.negate = c.neg and true or false
                                    if row.paramType then
                                        local v = c.args
                                        if type(v) == "table" then
                                            v = v[1]
                                        end
                                        if v ~= nil and v ~= "" then
                                            -- H1.5: specname / formname / stancename
                                            -- store integer-as-string canonical so the
                                            -- dropdown can match it back to a per-class
                                            -- label entry. The tonumber coerce strips
                                            -- whitespace and normalises numeric forms;
                                            -- tostring then gives the canonical "1" /
                                            -- "2" / ... string.
                                            if
                                                row.paramType == "integer"
                                                or row.paramType == "specname"
                                                or row.paramType == "formname"
                                                or row.paramType == "stancename"
                                            then
                                                st.paramValue = tostring(tonumber(v) or v)
                                            else
                                                st.paramValue = tostring(v)
                                            end
                                        end
                                    end
                                end
                            end
                            -- Unrecognized keys + targeting prefixes
                            -- (c.key == nil) silently skipped here; the
                            -- replace-on-Apply path documents the loss.
                        end
                    end
                end
            end
        end
    end

    local frame = createFrame()
    frame:ClearAllPoints()
    frame:SetPoint("TOPLEFT", self._anchorFrame, "BOTTOMLEFT", 0, -4)

    -- H1.3 fix: Show + Raise FIRST so the layout engine resolves the
    -- frame's bounds (frame:GetWidth() and friends return 0 until the
    -- frame is shown). renderActiveTab calls scrollFrame:GetWidth()
    -- to pin scrollChild width; that only works after Show().
    frame:Show()
    frame:Raise()
    setActiveTab(self._activeTab)

    -- Apply gating + warning surface for multi-clause originals.
    if frame.applyBtn then
        frame.applyBtn:SetEnabled(not self._roundtripBlocked)
    end
    if frame.roundtripWarn then
        frame.roundtripWarn:SetShown(self._roundtripBlocked)
    end
end

--- Close the picker (no-op if not open).
function CP:Close()
    if self._frame then
        self._frame:Hide()
    end
    clearRows()
    self._targetEditBox = nil
    self._anchorFrame = nil
    self._onApply = nil
end
