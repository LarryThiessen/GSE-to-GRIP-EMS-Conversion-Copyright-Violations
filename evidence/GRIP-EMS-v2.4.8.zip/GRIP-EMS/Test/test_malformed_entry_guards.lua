-- GRIP-EMS: Headless test for malformed-entry guards (wave 2)
--
-- Created:    2026-07-10
-- Updated:    2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.
--
-- Standalone (Lua 5.1) test for the wave-2 malformed-entry guards: corrupt
-- data (bad import / hand-edited SavedVariables) can leave non-table entries
-- in an actions array, or a non-table children field on a node. Wave 1
-- guarded the compiler, the repair walker, and the detail rows; this wave
-- guards the deep copy (editor open/save, export, signing), the
-- cross-sequence embed scan, the export-as-text emitter, the clear-interleave
-- auto-fix, and the working-copy serializer. Loads the REAL modules via
-- loadfile + setfenv into a sandbox.
--
-- Run from the EMS root:  lua Test/test_malformed_entry_guards.lua
-- Exit code 0 = all passed, 1 = at least one failure.
--
-- Cases:
--   W1  DeepCopyActions drops malformed entries, keeps table nodes in order
--   W2  DeepCopyActions drops a corrupt (non-table) children field
--   W3  DeepCopyActions recursion drops malformed nested loop children
--   W4  CheckCrossSeq embed scan survives corrupt trees (entry + field shapes)
--   W5  clear-interleave auto-fix survives a malformed entry and still fixes
--   W6  _serializeActions/_serializeNode serialize corrupt trees without error
--   W7  ExportAsText emits a corrupt sequence without error
--   F1  CompileActions survives field-shape corruption (wave 3)
--   F2  ValidateActions reports one error per field-shape class, never throws
--   F3  NodeSummary renders field-shape-corrupt nodes without error
--   F4  SanitizeActionNode coerces field shapes (heal-on-save)
--   F5  DeepCopyActions heals field shapes via sanitize
--   W8  CheckActions survives field-shape corruption and still reports
--   W9  CommitSelected legacy pcall containment rolls back partial stats
--   W10 ExportAsText emits an IF node with non-text variable and label
--   W11 ExportAsText emits a sequence whose author fields are not text
--   W12 ExportAsText emits a version whose keyPress / keyRelease are not text
--   W13 D.DisplayText coerces for display and honours its nil fallback
--   W14 a COLLECTION whose payload.Sequences is a scalar previews and imports
--   W15 CommitSelected tolerates a non-table modifierChain on a native entry
--   W16 GE.ImportNative tolerates non-table chain fields
--   W17 ExportAsText survives non-table stored steps / actions / versions
--   W18 GE.BuildExportList survives a malformed stored steps, and a
--       well-formed NEIGHBOUR in the same call still reports its real count
--   W19 GE.PrepareExportVersions returns nil steps for absent, a table for
--       every accepted shape, and never raises on a scalar steps
--   W20 GE.Export completes on a well-formed sequence (first fixture on this
--       function: ResolveExportContext + PrepareExportVersions + BuildInsights
--       + GetLocale in one call)
--   W22 GE.ResolveVariableDeps survives a malformed stored steps, and a
--       well-formed NEIGHBOUR in the same call still resolves its variable
--   W23 GE.DetectMissingEmbeddedDeps survives a malformed stored steps, and a
--       well-formed NEIGHBOUR in the same call still produces its one warning
--   W24 the ExportPreview readers survive a SCALAR stored versions across
--       GE.BuildExportList, GE.ResolveVariableDeps and
--       GE.DetectMissingEmbeddedDeps, neighbour results intact
--   W25 the GRIPExport readers survive a SCALAR versions on a stored seqData
--       (GE.PrepareExportVersions, GE.ResolveExportContext) and on the wire
--       (GE.ImportNative)
--   W27 RA:Analyze does not raise on a scalar .versions AND still reports
--       the CheckStructure "Missing versions" issue -- the arc's headline
--       claim, and its first behavioural proof
--   W35 the readiness repair that moves a /cast out of keyPress into step 1 is
--       driven END TO END over five shapes of ver.steps (absent, number,
--       boolean, string, empty table): the analyzer must REPORT for every
--       shape, the fix closure must not raise, the repaired version must carry
--       the moved text with keyPress cleared, and the RE-ANALYSIS must stop
--       reporting. Four of the five raised before 15r fixed the closure
--   W28 RA:AnalyzeAll survives one corrupt entry and still analyzes its
--       well-formed neighbour
--   W29 RA:CheckCrossSeq's three versions walks survive a scalar entry,
--       including the recursive walk of an embed TARGET's own versions
--   W30 D.NewSequenceFromTemplate falls back to D.NewVersion for a scalar
--       template versions instead of raising, and (pass 15j) completes on a
--       template whose versions[1] carries an absent or SCALAR steps array
--   W31 the ImportPreview readers survive a scalar versions, in the native
--       COLLECTION preview and on the commit path
--   W26 every pass-15c, 15d and 15e site carries the type() guard, and no
--       bare-truthiness .versions read in any of the SEVEN scanned shapes
--       survives in any of the NINETEEN shipped files that mention the field.
--       15f made the bareness rule receiver-scoped: a match is cleared only by
--       a type() test on the expression it dereferences, not by any table
--       type-test on the line. A SOURCE pin, not a behavioural one: fifteen of
--       the nineteen files are not loaded by this harness at all
--   W21 the unknown-global census is EMPTY of anything not on ALLOWED_UNKNOWN
--       (registered LAST so it observes every case above it)
--
-- 15o: SHAPES EIGHT AND NINE WERE BOTH ANCHOR FAILURES, NOT UNIMAGINED SHAPES,
-- and that is the most useful thing this arc has learned about its own method.
--
--   BARE_NOTLEN (eight)   BARE_GATE already encoded the NEGATIVE gate. What it
--                         could not see was a negative gate whose continuation
--                         is not " then" -- the anchor, not the shape.
--   BARE_CONJGATE (nine)  BARE_POSGATE and BARE_ANDGATE already encoded the
--                         POSITIVE gate. What neither could see was the field
--                         as one conjunct among several, because one anchors
--                         on "if" immediately left and the other on "then"
--                         immediately right -- again the anchor, not the
--                         shape.
--
-- Twice now, the gate held a correct idea of the danger and a too-narrow idea
-- of how it is spelled. A pass that asks "what dangerous shape have we not
-- thought of" will not find either; a pass that asks "what have we not
-- examined" finds both.
--
-- BOTH LIVED IN D, AND THE ONE FOUND AFTER D EXISTED WAS FOUND BY D. Stated
-- precisely, because the two are not the same story and flattening them would
-- overclaim: BARE_NOTLEN was found in 15m by a person reading shipped code,
-- BEFORE the residual bucket existed -- and it had been sitting in the
-- unexamined remainder for five passes with nothing anywhere measuring how big
-- that remainder was. 15n built the bucket, printed D, and BARE_CONJGATE was
-- read straight out of the listing. So the vindication of the residual
-- approach is not "the bucket found both"; it is that both were in D, the
-- bucket is what makes D readable, and the first shape found after it existed
-- was found by counting what the gate had no opinion about rather than by
-- anyone thinking harder about shapes.
--
-- .stepLabels IS THE LEAST DEFENDED OF THE FIVE CENSUSED FIELDS. 15n measured
-- C3 = 0 for it: ZERO receiver-scoped type() tests, in EITHER the '== "table"'
-- or the '~= "table"' form, anywhere in shipped code -- the only field of the
-- five with none at all. Its 28 in-code mentions were held up entirely by
-- whoever happened to write each site correctly. 15o's Import/GRIPExport.lua:97
-- fix takes it from zero to exactly ONE, which changes the ranking not at all.
-- The next pass looking for somewhere to spend effort should start there.

local ADDON_NAME = "GRIP-EMS"

-- ---------------------------------------------------------------------------
-- Minimal assertion + runner harness.
-- ---------------------------------------------------------------------------

local tests = {}

local function test(name, fn)
    tests[#tests + 1] = { name = name, fn = fn }
end

local function assertEqual(expected, actual, label)
    if expected ~= actual then
        error((label or "value") .. ": expected " .. tostring(expected) .. ", got " .. tostring(actual), 2)
    end
end

local function assertTrue(cond, label)
    if not cond then
        error((label or "condition") .. " failed", 2)
    end
end

-- ---------------------------------------------------------------------------
-- Sandbox: a self-referential no-op stub backs every unknown global, so the
-- modules load without a real WoW client. Real stdlib falls through to _G.
--
-- STUB AUDIT (pass 10). Two inert-stub incidents in two passes -- the locale
-- echo, and an unstubbed GetBuildInfo -- were both found by an UNRELATED
-- change making them fail, never by a test failing on its own. A stub that
-- returns a plausible-but-inert value makes fixtures green for the wrong
-- reason, and green is the expected colour, so nothing surfaces it.
--
-- What each stub returns HERE versus what the live client returns:
--
--   stub (catch-all)  RETIRED as the fallback (pass 11). Still defined for
--                     GRIPEMS.UI.Colors, but env.__index no longer returns it.
--   env.__index       WOW_GLOBALS lookup, else nil (pass 11)
--                     LIVE: nil for an undefined global. MATCHES now. Before
--                     pass 11 it returned the self-referential stub, so
--                     "if SomeGlobal then" was always TRUE and an API-absent
--                     branch could never run. The ten globals this harness
--                     actually reads are stubbed explicitly; anything new
--                     fails loudly by name instead of silently succeeding.
--   LOCALE            real enUS.lua values, echo fallback for absent keys
--                     LIVE: real values for every key. Differs only for keys
--                     genuinely absent from enUS.lua -- fixed this pass.
--   env.GetBuildInfo  "12.0.7", "68256", nil, 120007
--                     LIVE: same shape. MATCHES.
--   env.GetTime       0            LIVE: monotonic seconds. Differs in VALUE,
--                     not in type; nothing under test branches on it.
--   env.time          0            LIVE: epoch seconds. Same note.
--   env.strlower      string.lower LIVE: same. MATCHES.
--   env.strtrim       trims        LIVE: same. MATCHES.
--   GRIPEMS.UI.Colors colourStub for every key, GetRGBA -> 1,1,1,1
--                     LIVE: real colour objects. Differs in value only.
--   GRIPEMS.MacroManager.TruncateName  identity
--                     LIVE: truncates to the macro-name limit. DIFFERS --
--                     any test of truncation behaviour is inert here.
--   GRIPEMS.Serialization  registry-backed pass-through (pass 11)
--                     LIVE: real Encode/Decode. Differs in ENCODING only --
--                     it round-trips, which is what the decode-side rails
--                     need. Before pass 11 this was {} with nil methods, so
--                     LI.Preview / LI.Import / LI.CommitSelected were
--                     unreachable from this file entirely; W14 and W15 exist
--                     because that changed.
--   GRIPEMS.SpellCache     ready = true plus three identity/no-op methods --
--                     RecoverHandleTokensInText and TranslateMacrotext return
--                     their input unchanged, NormalizeVersionLocale does
--                     nothing (pass 11, defined below alongside Serialization)
--                     LIVE: real spell-tag translation and locale
--                     normalisation. DIFFERS in BEHAVIOUR -- any translation
--                     assertion is inert here -- but the methods EXIST, so
--                     cases do call it. Pass 13 correction: this row still
--                     read "{} -- every method is nil ... no case may call
--                     it" three passes after that stopped being true, and
--                     W16's chain-walk assertions depend on the real stub.
--   GRIPEMS.Engine    sequences store plus Activate / RegisterSequenceOnly /
--                     Deactivate / GetActiveVersion / MigrateSequenceFormat
--                     LIVE: the real engine. Differs in that nothing is
--                     compiled or bound; GetActiveVersion mirrors the real
--                     default-version resolution, which is all the export
--                     and commit rails read. Pass 15 correction: this row
--                     said "mirrors the real ... resolution" while
--                     MigrateSequenceFormat was "function() end", the same
--                     inert-stub class as Serialization and SpellCache two
--                     rows up. It is now a real flat-to-versions[1] wrap
--                     mirroring Engine.lua:858-887; see the note at the stub.
--                     Pass 15b: GetActiveVersion's head check is type()-guarded
--                     here too, mirroring the Engine.lua:735 fix. This file
--                     never loads Engine.lua, so the stub is the ONLY thing
--                     W24 resolves through -- the real function is pinned in
--                     Test/test_stepadv_numsteps_domain.lua case G1.
--   GRIPEMS.SpellValidator ValidateStep -> the empty result shape,
--                     ExtractAllSpells -> {}, ValidateSpell -> an unknown
--                     verdict (pass 15i, added for W27 / W28)
--                     LIVE: the real validator, resolving each step against
--                     the spellbook, the item cache and the tooltip cache.
--                     DIFFERS in BEHAVIOUR -- it reports NO spells at all, so
--                     every RA:CheckSpells issue is inert here and no case may
--                     assert on one. It does NOT mask the guard the two new
--                     cases pin: CheckSpells still walks the versions read at
--                     RepairAnalyzer.lua:187 before it ever calls the stub, so
--                     reverting that read to bare truthiness still fails them.
--                     Without the stub the two cases raised at
--                     RepairAnalyzer.lua:201 on their WELL-FORMED control rows
--                     -- an UNGUARDED "SV:ValidateStep" -- which is the loud
--                     failure the nil catch-all is designed to produce.
--   GRIPEMS.VariableStore  GetAll -> {}, GetCachedValue -> nil,
--                     GetReferences -> {}, Get -> nil (pass 13)
--                     LIVE: the real store. DIFFERS -- it reports NO
--                     variables, so the variable half of BuildExportList and
--                     the variable bundle in GE.Export are inert here. The
--                     sequence half, which W18 pins, is unaffected.
--   env.GetLocale     "enUS"       LIVE: the client locale string. Differs
--                     in VALUE only. Restored in pass 13 -- see the
--                     WOW_GLOBALS note below.
--   env.GetMacroIndexByName  0 (no such macro)
--                     LIVE: the real slot index, 0 when absent. Differs in
--                     VALUE; the absent answer is the realistic headless one.
--   env.GetMacroInfo  nil          LIVE: name, icon, body for a used slot.
--                     DIFFERS -- the harness reports an empty macro list, so
--                     macro-bundle behaviour is inert. Needed at all only
--                     because BuildExportList calls it UNGUARDED.
--   env.GetNumMacros  0, 0         LIVE: account, character counts. Same note.
--   env.UnitName      "Sataana"    LIVE: the player name. Differs in VALUE.
--
-- SCOPE: this table describes THIS harness. test_frg1_v2_reader.lua has
-- carried a working Serialization stub all along, so that row was never a
-- general finding -- it was specific to this file, and pass 11 closed it.
--
-- RECOUNT (pass 13; the old "3 of 12" counted SpellCache as methods-nil,
-- which had not been true since pass 11). Nineteen rows now:
--   MATCHES live in shape and value (4): env.__index, env.GetBuildInfo,
--     env.strlower, env.strtrim.
--   Differs in VALUE only, nothing branches on it (6): env.GetTime, env.time,
--     UI.Colors, env.GetLocale, env.GetMacroIndexByName, env.UnitName.
--   Differs in ENCODING only, round-trips (1): Serialization.
--   Differs in BEHAVIOUR, so anything asserting on that behaviour is inert
--     (5): MacroManager.TruncateName, SpellCache, VariableStore,
--     env.GetMacroInfo, env.GetNumMacros.
--   Partial by construction (2): LOCALE (real enUS values, echo fallback for
--     absent keys), Engine (store and version resolution only).
--   Retired (1): the self-referential catch-all, kept only for UI.Colors.
-- So five behaviour-differing rows, not three, and none of them is
-- methods-nil. The two that produced live incidents, the catch-all and
-- env.__index, are both fixed. Enumerating the rest is the finding; fixing
-- them is its own pass.
--
-- PASS 12 CORRECTION, and it matters for how these numbers are read. The nil
-- catch-all did not make the API-existence branches testable in BOTH
-- directions -- it flipped them from always-TRUE to always-FALSE. Under the
-- old self-referential stub, "if <sibling addon global> then" was taken and
-- the three sibling-addon globals were read; under nil that branch is false
-- and they are never read at all. So this harness now exercises the
-- API-ABSENT path exclusively. That is the intended direction -- an absent
-- optional API is the realistic default and the branch that used to be dead
-- is the one now covered -- but the API-PRESENT path is uncovered here by
-- construction, and no count in this table should be read as "both branches
-- are exercised".
-- ---------------------------------------------------------------------------

local stub = {}
setmetatable(stub, {
    __index = function()
        return stub
    end,
    __call = function()
        return stub
    end,
})

-- Every WoW global this harness's loaded modules actually read, recorded by
-- instrumenting the catch-all and running the suite (pass 11 EDIT 7 steps a-c,
-- driver at outputs/pass11_unknown_globals.lua), re-censused in pass 12 after
-- the decode-side modules landed. Each is given a realistically-SHAPED value.
--
-- PASS 13 CORRECTION, the same class of error as the SpellCache row above.
-- Pass 12 removed six names on the grounds that a census "showed they are
-- never served", and the suite stayed green. That measured the FIXTURES, not
-- the MODULES. Grepped over the ten modules this harness loads:
--   GetLocale            READ UNGUARDED at GRIPExport.lua:561, :759 and :765,
--                        ImportPreview.lua:173, RepairAnalyzer.lua:1131 and
--                        -- missing from this list until pass 14 --
--                        ExportPreview.lua:449, "locale = GetLocale()" inside
--                        GE.BuildCollectionPayload. That is the very module
--                        pass 13 added to MODULES, so the sixth site was in
--                        the loaded set on the same pass that wrote the list.
--   GetMacroIndexByName  READ UNGUARDED at GRIPExport.lua:1213 (the
--                        LegacyImport:962 and ImportPreview:959 reads are
--                        "X and X(...)"-guarded, so those tolerate nil)
--   UnitName             READ UNGUARDED at Data/Defaults.lua:3938
-- A driver calling GE.Export on a WELL-FORMED sequence raises
-- "GRIPExport.lua:558: attempt to call global 'GetLocale' (a nil value)" with
-- the stub absent -- which is exactly what blocked W20 below. The accurate
-- statement is: no fixture reached those reads, and the reads exist. All
-- three are restored, with realistic return shapes.
--
-- The other three of the six stay out, and the CONCLUSION there is still
-- right -- but pass 13's supporting claim for one of them was not, and that
-- was the dangerous half. Re-grepped over the whole repo in pass 14:
--   UnitFullName   one site, LegacyMigrate.lua:297
--   BNGetInfo      one site, Identity.lua:61
--   GetRealmName   FIVE product sites, not "only in Identity.lua:62":
--                    Core/ThemeTransport.lua:107  guarded, "X and X() or ''"
--                    Core/ThemeTransport.lua:162  guarded, same form
--                    Core/TraceLog.lua:94         guarded, same form
--                    Engine/Identity.lua:62       UNGUARDED
--                    Libs/AceDB-3.0/AceDB-3.0.lua:254  UNGUARDED, and at
--                      MODULE SCOPE, so it runs on load before any fixture
-- None of these files is in MODULES below, so the stub stays out and the
-- ruling is unchanged. The wrong supporting claim mattered anyway: a later
-- pass adding AceDB-3.0 to MODULES would read "only in Identity.lua:62", not
-- add the stub, and take a module-scope raise on load. If one of these files
-- is ever added, the nil catch-all fails loudly by name, which is the design.
--
-- GetMacroInfo and GetNumMacros are here for a different reason: ExportPreview
-- joined MODULES in pass 13, and that module reads GetMacroInfo UNGUARDED at
-- TWO sites, not the one this note originally named --
--   ExportPreview.lua:168  GE.BuildExportList's macro scan
--   ExportPreview.lua:622  GE.BuildCollectionPayload's macro bundle
--
-- PASS 15 CORRECTION, and it is the same shape of error pass 14 corrected
-- three times: an enumeration that names some sites and reads as exhaustive.
-- The note said "GRIPExport's own macro bundle is guarded ... so the stub is an
-- ExportPreview requirement at both sites", which named ONE GRIPExport site and
-- implied it was the only one. Re-grepped across all TEN modules in the MODULES
-- list below (ten rows, twenty candidate paths), the GetMacroInfo readers are
-- FIVE, not two:
--   ExportPreview.lua:168   UNGUARDED  GE.BuildExportList's macro scan
--   ExportPreview.lua:622   UNGUARDED  GE.BuildCollectionPayload's bundle
--   RepairAnalyzer.lua:1061 UNGUARDED  RA:CheckStubs, behind an
--                             "if MM.stubs[seqName]" data gate only -- the
--                             MacroManager stub above carries stubs = {}, so
--                             no fixture reaches it and its absence would not
--                             have surfaced here either
--   GRIPExport.lua:639      GUARDED    inside the "... and GetMacroInfo then"
--                             test at GRIPExport.lua:635, the one site this
--                             note already named
--   GRIPExport.lua:1215     UNGUARDED  GE.ExportAsText's macro section, behind
--                             a "slot > 0" test on GetMacroIndexByName and a
--                             non-empty macNames argument, neither of which is
--                             a guard on GetMacroInfo itself
-- Four of the five are unguarded and only one of those four is the site the
-- note credited. The CONCLUSION is unchanged and must not be softened: the
-- stub is required, and it is required by ExportPreview at both of its sites
-- regardless of what the other three do.
--
-- With the list explicit, the catch-all below returns nil rather than the
-- self-referential stub. That matters: under the stub, "if SomeGlobal then"
-- was always TRUE, so an API-absent branch could never run and an API-present
-- branch ran against a table instead of a real return. nil restores the live
-- shape for an absent global, and a newly-read global now fails loudly by
-- name instead of silently succeeding.
local WOW_GLOBALS = {
    MAX_ACCOUNT_MACROS = 120,
    MAX_CHARACTER_MACROS = 18,
    VIDEO_OPTIONS_DISABLED = "Disabled",
    VIDEO_OPTIONS_FAIR = "Fair",
    VIDEO_OPTIONS_HIGH = "High",
    VIDEO_OPTIONS_LOW = "Low",
    VIDEO_OPTIONS_MEDIUM = "Medium",
    VIDEO_OPTIONS_ULTRA = "Ultra",
    VIDEO_OPTIONS_ULTRA_HIGH = "Ultra High",
    wipe = function(t)
        for k in pairs(t) do
            t[k] = nil
        end
        return t
    end,
    -- Read by the decode-side modules added in pass 11 (LegacyImport,
    -- ImportPreview) and by GE.ImportNative, so it is absent from the pass-11
    -- recording, which ran before those modules were loaded. It surfaced as a
    -- loud "attempt to call global 'UnitClass' (a nil value)" -- the nil
    -- catch-all working as designed. A pass-12 census of what this harness
    -- actually serves shows UnitClass alone among that batch is reached (14
    -- times); the six others added alongside it were never served and are
    -- gone.
    UnitClass = function()
        return "Mage", "MAGE", 8
    end,
    -- Restored in pass 13. See the PASS 13 CORRECTION above: these three are
    -- read UNGUARDED by loaded modules, so their absence was a harness gap
    -- masked by fixture coverage, not evidence that nothing reads them.
    GetLocale = function()
        return "enUS"
    end,
    GetMacroIndexByName = function()
        -- Live returns the slot index, 0 when no macro carries that name.
        -- 0 is the realistic headless answer: this harness creates no macros.
        return 0
    end,
    UnitName = function()
        return "Sataana"
    end,
    -- BuildExportList's macro scan calls GetMacroInfo UNGUARDED across all
    -- MAX_ACCOUNT_MACROS + MAX_CHARACTER_MACROS slots. nil name = empty slot.
    GetMacroInfo = function()
        return nil
    end,
    GetNumMacros = function()
        return 0, 0
    end,
    -- FIRST CATCH OF THE W21 CENSUS GATE (pass 14). RepairAnalyzer.lua calls this
    -- UNGUARDED at :1599 (CheckConcurrent) and :100 (the StubFix closure).
    -- CheckConcurrent is reached from RA:Analyze:1620, which GE.BuildInsights
    -- invokes at GRIPExport.lua:394 inside a pcall -- so the "attempt to call
    -- global 'InCombatLockdown' (a nil value)" was SWALLOWED, insights.health
    -- was silently never populated, and the census counted the read once while
    -- every fixture stayed green. Exactly the hole W21 exists to close: a nil
    -- that never raises is a nil nothing notices. false = out of combat, the
    -- realistic headless answer, and the branch the live client takes at rest.
    InCombatLockdown = function()
        return false
    end,
}

local UNKNOWN_GLOBALS = {}
local env = setmetatable({}, {
    __index = function(_, k)
        local v = rawget(_G, k)
        if v ~= nil then
            return v
        end
        if WOW_GLOBALS[k] ~= nil then
            return WOW_GLOBALS[k]
        end
        UNKNOWN_GLOBALS[k] = (UNKNOWN_GLOBALS[k] or 0) + 1
        return nil
    end,
})
_G.__EMS_UNKNOWN_GLOBALS = UNKNOWN_GLOBALS
env._G = env

-- Globals the loaded modules legitimately read while ABSENT, each with the
-- reason it is allowed to stay absent. W21 at the very end of this file fails
-- on anything read but not listed here, so this table is the whole contract:
-- an allowlist with reasons is reviewable, a printed warning is not.
--
-- WHY W21 EXISTS. The census above (UNKNOWN_GLOBALS) has recorded every
-- unknown global read since pass 11, and until pass 14 NOTHING asserted on it
-- -- the only consumer was outputs/pass11_unknown_globals.lua, a one-off
-- driver. So the design property the note above claims, "a newly-read global
-- now fails loudly by name instead of silently succeeding", only held when the
-- nil happened to RAISE. A newly-read global behind an "X and X()" guard, or
-- one whose nil return is tolerated, or one whose raise lands inside a pcall,
-- was counted and then ignored. That is the hole pass 12 fell into: it removed
-- six stubs, the suite stayed green, and three of the six were in fact read
-- unguarded by loaded modules. InCombatLockdown above is the same class, found
-- by turning the census into a gate.
--
-- ADDING TO THIS TABLE IS A DECISION, NOT A FORMALITY. The question is not
-- "does the suite go green again" -- it is "does the LIVE client ever serve
-- nil here, and does the product do the right thing when it does". If the read
-- is unguarded, the answer is no and the fix is a WOW_GLOBALS stub, not a row
-- here.
local ALLOWED_UNKNOWN = {
    -- Guarded "if X and X.GetSpecialization then" at GRIPExport.lua:174 and
    -- :360; absent is the optional-API branch this harness covers by design.
    C_SpecializationInfo = true,
    -- Guarded "X and X.GetSpellName" / "X and X.GetSpellInfo" at
    -- RepairAnalyzer.lua:278, GRIPExport.lua:945, LegacyImport.lua:1988.
    C_Spell = true,
    -- A per-character SavedVariable, not a WoW API. Every read is
    -- "_G.GRIP_EMS_CHAR and ..." (RepairAnalyzer.lua:1199,
    -- LegacyImport.lua:976 and :991, ImportPreview.lua:985, :1276 and :1365);
    -- absent is a real live state -- a fresh install that has not saved yet.
    GRIP_EMS_CHAR = true,
    -- The ACCOUNT SavedVariable, same class as GRIP_EMS_CHAR above and first
    -- read from this harness in pass 15i. In the loaded set the read reached is
    -- Data/Defaults.lua:3960, D.NewSequenceFromTemplate's privacy default:
    --   (GRIP_EMS_DB and GRIP_EMS_DB.config and GRIP_EMS_DB.config.privacyDefault)
    --       or D.PRIVACY_MODE_DEFAULT
    -- Fully guarded, and absent is a real live state -- the global does not
    -- exist until the SavedVariable loads. The product does the right thing
    -- when it is nil: it falls back to D.PRIVACY_MODE_DEFAULT, which W30
    -- ASSERTS rather than assumes, so this row is an observed behaviour and not
    -- a claim. The GRIPExport reads at :221 and :237 sit behind a
    -- GRIPEMS.Identity test that is nil here, and :619 behind a non-empty
    -- privacyMode, so none of the three is reached from this file.
    GRIP_EMS_DB = true,
    -- Guarded "... and GetCurrentRegionName then" at GRIPExport.lua:627 and
    -- ExportPreview.lua:579; absent simply omits payload.region.
    GetCurrentRegionName = true,
    -- Guarded "if UnitLevel then" at GRIPExport.lua:139; absent omits
    -- bc.playerLevel from the export build context.
    UnitLevel = true,
}

-- Locale lookups resolve to the key name itself, so string.format on them
-- never errors.
-- Real locale values, loaded from Locale/enUS.lua rather than hand-copied.
-- The echo fallback alone returns the KEY, which carries no %s or %d, so
-- string.format silently ignores its arguments and can NEVER raise -- any
-- fixture whose behaviour depends on a specifier is inert and looks green.
-- A hand-maintained list of the keys that matter is the same drift problem
-- one level up: enUS.lua holds 315 occurrences of %s, and a list covering
-- nineteen of them goes stale the moment a string gains a specifier.
-- LOADED_LOCALE is populated below, once the loader exists.
local LOADED_LOCALE = {}

local LOCALE = setmetatable({}, {
    __index = function(_, k)
        -- Echo fallback is kept deliberately: a key absent from enUS.lua must
        -- return the key, not nil, or unrelated cases fail on a nil index.
        return LOADED_LOCALE[k] or k
    end,
})

env.LibStub = function()
    return {
        GetLocale = function()
            return LOCALE
        end,
        -- Locale/enUS.lua writes its strings through NewLocale, so handing it
        -- LOADED_LOCALE is what fills the real values in.
        NewLocale = function()
            return LOADED_LOCALE
        end,
    }
end
env.strlower = string.lower
env.strtrim = function(s)
    return (tostring(s):gsub("^%s+", ""):gsub("%s+$", ""))
end
-- Unstubbed WoW globals fall through to the catch-all, which hands back a
-- TABLE. The export footer formats GetBuildInfo() into a "%s", so with real
-- format strings now in LOCALE_FORMATS an unstubbed GetBuildInfo raises
-- "bad argument #3 to 'format'". That is a harness gap, not a product
-- defect -- the live client returns a string here.
env.GetBuildInfo = function()
    return "12.0.7", "68256", nil, 120007
end
env.GetTime = function()
    return 0
end
env.time = function()
    return 0
end

local colourStub = {
    GetRGBA = function()
        return 1, 1, 1, 1
    end,
}

local GRIPEMS = {
    Debug = function() end,
    UI = {
        Colors = setmetatable({}, {
            __index = function()
                return colourStub
            end,
        }),
    },
    -- The commit rails call these three. As a bare { sequences = {} } stub,
    -- W15 died on GetActiveVersion AFTER clearing the guard it exists to pin,
    -- which is the same inert-stub class as Serialization and SpellCache.
    Engine = {
        sequences = {},
        ActivateSequence = function(self, name, seqData)
            self.sequences[name] = { data = seqData }
        end,
        RegisterSequenceOnly = function(self, name, seqData)
            self.sequences[name] = { data = seqData }
        end,
        DeactivateSequence = function(self, name)
            self.sequences[name] = nil
        end,
        -- The head check is type(), mirroring Engine.lua:735 as fixed in pass
        -- 15b. It was bare truthiness here because the live one was, and the
        -- two must not drift: this stub is what W24's GE.BuildExportList rows
        -- resolve through, so a stub that still indexed a scalar would keep
        -- reporting the OLD product behaviour after the product was fixed.
        -- The real function is pinned directly, against the REAL Engine.lua, by
        -- case G1 in Test/test_stepadv_numsteps_domain.lua -- this file never
        -- loads Engine.lua, so nothing here can pin it.
        GetActiveVersion = function(_, seqData)
            if not seqData or type(seqData.versions) ~= "table" then
                return nil
            end
            return seqData.versions[seqData.defaultVersion or 1] or seqData.versions[1]
        end,
        -- PASS 15: was "function() end". That no-op is the same inert-stub
        -- class as the Serialization and SpellCache rows above, and it made
        -- ONE product arm unreachable in effect: GE.ImportNative's format-v1
        -- FLAT fallback (GRIPExport.lua:860-864) migrates seqData.steps into
        -- versions[1] through this call, and the no-op left seqData.versions
        -- nil, so GetActiveVersion at :923 returned nil and every flat import
        -- ended at :925 with "Imported sequence has no steps" -- the
        -- well-formed control included. A control that cannot complete proves
        -- nothing, so W25's ImportNative rows would have been inert.
        -- Mirrors Engine.lua:858-887: already-versioned is a no-op, otherwise
        -- the flat fields are wrapped into versions[1] and cleared.
        MigrateSequenceFormat = function(_, seqData)
            if not seqData then
                return seqData
            end
            if seqData.versions and type(seqData.versions) == "table" and next(seqData.versions) then
                return seqData
            end
            seqData.versions = {
                {
                    steps = seqData.steps or {},
                    -- The literal, exactly as Engine.lua:870 writes it: the
                    -- Defaults local is declared BELOW this table, so a D
                    -- reference here would resolve as a global and be nil.
                    stepFunction = seqData.stepFunction or "Sequential",
                    resetOnCombat = seqData.resetOnCombat or false,
                    resetOnTarget = seqData.resetOnTarget or false,
                    resetOnGear = seqData.resetOnGear or false,
                    resetOnSpec = seqData.resetOnSpec or false,
                    resetTimer = seqData.resetTimer or 0,
                },
            }
            seqData.defaultVersion = 1
            seqData.steps = nil
            seqData.stepFunction = nil
            seqData.resetOnCombat = nil
            seqData.resetOnTarget = nil
            seqData.resetOnGear = nil
            seqData.resetOnSpec = nil
            seqData.resetTimer = nil
            return seqData
        end,
    },
    MacroManager = {
        stubs = {},
        -- CheckCrossSeq groups sequence names by truncated stub name.
        TruncateName = function(_, name)
            return name
        end,
    },
    -- ExportPreview captures VS at file scope and BuildExportList calls
    -- VS:GetAll() unconditionally, so without this the module loads but W18's
    -- first call raises on a nil index. Reports no variables, which leaves the
    -- variable half of the export list inert and the sequence half -- the half
    -- W18 pins -- untouched.
    VariableStore = {
        GetAll = function()
            return {}
        end,
        GetCachedValue = function() end,
        GetReferences = function()
            return {}
        end,
        Get = function() end,
    },
    -- PASS 15i. RA:CheckSpells is the FIRST check RA:Analyze runs
    -- (RepairAnalyzer.lua:1599) and it calls SV:ValidateStep UNGUARDED at :201
    -- for every step of every version, so W27 and W28 -- the first fixtures in
    -- this file to drive RA:Analyze at all -- raised "attempt to index upvalue
    -- 'SV' (a nil value)" on their WELL-FORMED control rows without this.
    --
    -- Data/SpellValidator.lua is NOT added to MODULES instead, deliberately:
    -- the real module reads C_SpellBook, C_Item, Enum and a populated
    -- SpellCache.byName, none of which this harness stands up, and C_Spell is
    -- an ALLOWED_UNKNOWN row that three loaded modules still depend on being
    -- absent. Loading it would trade one honest stub for a much larger set of
    -- new stubs.
    --
    -- WHAT THIS DIFFERS ON, stated plainly because that is what the STUB AUDIT
    -- block above exists for: it reports NO spells and NO extracted references,
    -- so EVERY CheckSpells issue -- "Unknown spell", "Spell not learned",
    -- "Stale tooltip", "Item in non-/use command" -- is INERT here and no case
    -- may assert on one. What it does NOT neutralise is the guard W27 and W28
    -- exist for: CheckSpells still runs its "for vi, ver in ipairs(...)" over
    -- the versions read at RepairAnalyzer.lua:187, which is the FIRST .versions
    -- dereference on the Analyze path and the one that used to raise. Reverting
    -- :187 to bare truthiness still turns both cases red through this stub.
    SpellValidator = {
        -- LIVE: parses the macrotext and returns real rows, each with a
        -- D.SPELL_STATUS_* verdict. HERE: the empty shape, which is also what
        -- the real function returns for a non-string or empty step.
        ValidateStep = function()
            return { spells = {}, tooltipSpells = {}, hasVariable = false }
        end,
        -- LIVE: an array of { name = string, command = string }. HERE: empty.
        ExtractAllSpells = function()
            return {}
        end,
        -- ValidateSpell is defined just below the table rather than in it: it
        -- has to read GRIPEMS.Defaults, and inside this constructor the
        -- GRIPEMS local is not yet in scope, so the name would resolve as a
        -- GLOBAL and the census would count it.
    },
    Serialization = {},
    -- Ported from the sibling harness alongside the Serialization stub. As {}
    -- with nil methods this stopped GE.ImportNative at GRIPExport.lua:780 on
    -- NormalizeVersionLocale, BEFORE the chain walks at :833 -- so W16's
    -- "no ipairs error" assertions passed vacuously until this landed.
    SpellCache = {
        ready = true,
        RecoverHandleTokensInText = function(_, text)
            return text
        end,
        TranslateMacrotext = function(_, text)
            return text
        end,
        NormalizeVersionLocale = function() end,
    },
}

-- Unreachable while SpellValidator.ExtractAllSpells returns empty (its only
-- caller is the loop at RepairAnalyzer.lua:241), and defined anyway so a later
-- fixture meets a real function rather than a nil. Assigned here so the closure
-- captures the GRIPEMS local as an upvalue; Defaults is loaded further down, so
-- the lookup has to happen at CALL time and not at definition time.
GRIPEMS.SpellValidator.ValidateSpell = function(_, spellName)
    local DD = GRIPEMS.Defaults
    return { name = spellName, status = DD and DD.SPELL_STATUS_UNKNOWN }
end

-- Registry-backed Serialization stub, ported verbatim from the sibling
-- harness (test_frg1_v2_reader.lua). Before pass 11 this was {} with nil
-- methods, which meant every DECODE-side rail -- LI.Preview, LI.Import,
-- LI.CommitSelected -- was unreachable from this file. Encode parks the table
-- and returns "<prefix>#<index>"; Decode resolves the index back. Prefixes
-- are probed longest-first, matching the real detector, so the 7-char
-- encrypted legacy prefix cannot be shadowed by the 6-char one.
local REGISTRY = {}
local PREFIX_ORDER = {
    "GEMSCP1_PREFIX",
    "GRIP1_PREFIX",
    "GSE3_ENCRYPTED_PREFIX",
    "FRG1_PREFIX",
    "EMS1_PREFIX",
    "GSE3_PREFIX",
}
local FORMAT_OF = {
    GEMSCP1_PREFIX = "GEMSCP1",
    GRIP1_PREFIX = "GRIP1",
    GSE3_ENCRYPTED_PREFIX = "GSE3ENC",
    FRG1_PREFIX = "FRG1",
    EMS1_PREFIX = "EMS1",
    GSE3_PREFIX = "GSE3",
}

local function matchPrefix(str)
    local DD = GRIPEMS.Defaults
    for _, key in ipairs(PREFIX_ORDER) do
        local prefix = DD and DD[key]
        if prefix and str:sub(1, #prefix) == prefix then
            return key, prefix
        end
    end
    return nil
end

GRIPEMS.Serialization = {
    Encode = function(tbl, prefix)
        REGISTRY[#REGISTRY + 1] = tbl
        return true, prefix .. "#" .. tostring(#REGISTRY)
    end,
    Decode = function(str)
        local key, prefix = matchPrefix(str)
        if not key then
            return false, "Unknown format"
        end
        local idx = tonumber(str:sub(#prefix + 2))
        local tbl = idx and REGISTRY[idx]
        if not tbl then
            return false, "Decode failed"
        end
        return true, tbl, FORMAT_OF[key]
    end,
    DetectFormat = function(str)
        local key = matchPrefix(str)
        return key and FORMAT_OF[key] or nil
    end,
}

-- ---------------------------------------------------------------------------
-- Load the REAL modules into the sandbox. Defaults first (the others capture
-- module locals from GRIPEMS at file scope).
-- ---------------------------------------------------------------------------

local function loadModule(candidates)
    for _, path in ipairs(candidates) do
        -- loadfile is dev-harness file I/O, intentionally outside the addon WoW std.
        -- selene: allow(undefined_variable)
        local chunk = loadfile(path)
        if chunk then
            setfenv(chunk, env)
            chunk(ADDON_NAME, GRIPEMS)
            return true
        end
    end
    return false
end

local MODULES = {
    -- The real locale first: every module below captures L at file scope, and
    -- loading enUS.lua the same way real modules are loaded covers all 3290
    -- keys instead of a hand-copied subset.
    { "Locale/enUS.lua", "../Locale/enUS.lua" },
    { "Data/Defaults.lua", "../Data/Defaults.lua" },
    { "Engine/MacroSyntax.lua", "../Engine/MacroSyntax.lua" },
    { "Engine/ActionCompiler.lua", "../Engine/ActionCompiler.lua" },
    { "Data/RepairAnalyzer.lua", "../Data/RepairAnalyzer.lua" },
    { "UI/StepListView.lua", "../UI/StepListView.lua" },
    { "Import/GRIPExport.lua", "../Import/GRIPExport.lua" },
    -- Pass 13: the export DIALOG path. It defines GE.BuildExportList on the
    -- GRIPExport table, so it must load after GRIPExport. Absent from this
    -- list until now, which is why the two stored-shape sites it carries had
    -- never had a fixture despite being the first thing the dialog calls.
    { "Import/ExportPreview.lua", "../Import/ExportPreview.lua" },
    -- Decode-side rails, reachable only since the Serialization stub above
    -- replaced the empty table. W14 and W15 drive these.
    { "Import/LegacyImport.lua", "../Import/LegacyImport.lua" },
    { "Import/ImportPreview.lua", "../Import/ImportPreview.lua" },
}
for _, candidates in ipairs(MODULES) do
    assertTrue(loadModule(candidates), "could not locate " .. candidates[1] .. " (run from the EMS root)")
end

local D = GRIPEMS.Defaults
local RA = GRIPEMS.RepairAnalyzer
local SLV = GRIPEMS.StepListView
local GE = GRIPEMS.GRIPExport
assertTrue(D ~= nil, "Defaults loaded")
assertTrue(GRIPEMS.ActionCompiler ~= nil, "ActionCompiler loaded")
assertTrue(RA ~= nil, "RepairAnalyzer loaded")
assertTrue(SLV ~= nil, "StepListView loaded")
assertTrue(GE ~= nil, "GRIPExport loaded")

-- Prime RepairAnalyzer's lazy dependency resolution while the engine stub is
-- still empty (ResolveDeps runs inside AnalyzeAll; zero sequences = no-op scan).
RA:AnalyzeAll()

-- ---------------------------------------------------------------------------
-- Fixtures.
-- ---------------------------------------------------------------------------

local A = "/cast Alpha"
local B = "/cast Bravo"
local C = "/cast Charlie"

local function action(macro, extra)
    local node = { type = D.ACTION_TYPE_ACTION, macro = macro }
    for k, v in pairs(extra or {}) do
        node[k] = v
    end
    return node
end

--- A version whose actions carry every corrupt shape this wave guards:
--- non-table entries (number/boolean), a numeric loop children field, and
--- an IF whose true branch holds a malformed entry and whose false branch
--- IS a malformed value.
local function makeCorruptActions()
    return {
        action(A),
        5,
        true,
        { type = D.ACTION_TYPE_LOOP, ["repeat"] = 1, stepFunction = D.STEP_SEQUENTIAL, children = 7 },
        {
            type = D.ACTION_TYPE_IF,
            variable = "combat",
            children = { { action(B), 5 }, 9 },
        },
    }
end

local function installCorruptSequence()
    GRIPEMS.Engine.sequences["CorruptSeq"] = {
        data = {
            name = "CorruptSeq",
            versions = {
                {
                    stepFunction = D.STEP_SEQUENTIAL,
                    steps = { A },
                    actions = makeCorruptActions(),
                },
            },
        },
    }
end

-- ---------------------------------------------------------------------------
-- Cases.
-- ---------------------------------------------------------------------------

test("W1: DeepCopyActions drops malformed entries, keeps table nodes in order", function()
    local src = { action(A), 5, true, action(C) }
    local copy = D.DeepCopyActions(src)
    assertEqual(2, #copy, "copy length")
    assertEqual(A, copy[1].macro, "node 1")
    assertEqual(C, copy[2].macro, "node 2")
    copy[1].macro = "/cast Changed"
    assertEqual(A, src[1].macro, "copy is independent of the source")
end)

test("W2: DeepCopyActions drops a corrupt (non-table) children field", function()
    local copy = D.DeepCopyActions({
        { type = D.ACTION_TYPE_IF, variable = "combat", children = 5 },
        { type = D.ACTION_TYPE_LOOP, ["repeat"] = 2, children = true },
    })
    assertEqual(2, #copy, "both nodes copied")
    assertEqual(nil, copy[1].children, "IF corrupt children dropped")
    assertEqual(nil, copy[2].children, "Loop corrupt children dropped")
end)

test("W3: DeepCopyActions recursion drops malformed nested loop children", function()
    local copy = D.DeepCopyActions({
        {
            type = D.ACTION_TYPE_LOOP,
            ["repeat"] = 1,
            stepFunction = D.STEP_SEQUENTIAL,
            children = { action(A), 5, action(C) },
        },
    })
    assertEqual(1, #copy, "loop node copied")
    assertEqual(2, #copy[1].children, "malformed nested child dropped")
    assertEqual(A, copy[1].children[1].macro, "nested node 1")
    assertEqual(C, copy[1].children[2].macro, "nested node 2")
end)

test("W4: CheckCrossSeq embed scan survives corrupt trees", function()
    installCorruptSequence()
    local ok, err = pcall(function()
        RA:CheckCrossSeq({})
    end)
    assertTrue(ok, "CheckCrossSeq raised: " .. tostring(err))
end)

test("W5: clear-interleave auto-fix survives a malformed entry and still fixes", function()
    RA._currentName = "ClearILSeq"
    local seqData = {
        name = "ClearILSeq",
        versions = {
            {
                stepFunction = D.STEP_SEQUENTIAL,
                steps = {},
                actions = {
                    action(A, { interval = 2 }),
                    5,
                    action(B, { interval = 2 }),
                },
            },
        },
    }
    local issues = {}
    RA:CheckStructure(seqData, issues)
    local fixIssue
    for _, issue in ipairs(issues) do
        if issue.fixFn and issue.title == "Empty steps array" then
            fixIssue = issue
            break
        end
    end
    assertTrue(fixIssue ~= nil, "fixable empty-steps issue offered")
    local ok, err = pcall(fixIssue.fixFn, seqData)
    assertTrue(ok, "fix closure raised: " .. tostring(err))
    assertEqual(nil, seqData.versions[1].actions[1].interval, "interval cleared on node 1")
    assertEqual(nil, seqData.versions[1].actions[3].interval, "interval cleared on node 3")
    assertEqual(2, #seqData.versions[1].steps, "steps recompiled from the two enabled actions")
end)

test("W6: serializer handles corrupt trees without error", function()
    local s = SLV:_serializeActions({ action(A), 5, true, action(C) })
    assertTrue(type(s) == "string", "serialized to a string")
    assertTrue(s:find("Alpha", 1, true) ~= nil, "node 1 serialized")
    assertTrue(s:find("Charlie", 1, true) ~= nil, "node 2 serialized")
    assertEqual("", SLV:_serializeNode(5), "non-table node serializes empty")
    local s2 = SLV:_serializeNode({ type = D.ACTION_TYPE_IF, variable = "combat", children = 9 })
    assertTrue(type(s2) == "string", "corrupt children field tolerated")
    assertTrue(s2:find("t{", 1, true) == nil, "no branch payload emitted for corrupt children")
end)

test("W7: ExportAsText emits a corrupt sequence without error", function()
    installCorruptSequence()
    local ok, result = pcall(GE.ExportAsText, { "CorruptSeq" }, {}, {})
    assertTrue(ok, "ExportAsText raised: " .. tostring(result))
    if type(result) == "string" then
        assertTrue(result:find(A, 1, true) ~= nil, "well-formed action emitted")
    end
end)

test("W10: ExportAsText emits an IF node with non-text variable and label", function()
    -- Built DIRECTLY, not routed through LegacyImport: the point is that the
    -- EMITTER survives a node the producer did not build. The import-side
    -- coercion is pinned separately in test_frg1_v2_reader.lua (A40).
    -- node.variable reaches emitActionTree's "If " concatenation and
    -- node.label reaches the prefix concatenation two lines above it; both
    -- were bare before this guard, and a table passes the
    -- "label and label ~= ''" test on both halves.
    GRIPEMS.Engine.sequences["IfShapeSeq"] = {
        data = {
            name = "IfShapeSeq",
            versions = {
                {
                    stepFunction = D.STEP_SEQUENTIAL,
                    steps = { A },
                    actions = { { type = D.ACTION_TYPE_IF, variable = {}, label = {}, children = { {}, {} } } },
                },
            },
        },
    }
    local ok, result = pcall(GE.ExportAsText, { "IfShapeSeq" }, {}, {})
    assertTrue(ok, "ExportAsText raised: " .. tostring(result))
    assertTrue(type(result) == "string", "export returned text")
    assertTrue(result:find("If ", 1, true) ~= nil, "the IF node still emitted a line")
    GRIPEMS.Engine.sequences["IfShapeSeq"] = nil
end)

test("W11: ExportAsText emits a sequence whose author fields are not text", function()
    -- seqData.author was concatenated bare and seqData.originalAuthor was fed
    -- to string.format("%s", ...), which on Lua 5.1 RAISES on a table rather
    -- than coercing it. originalAuthor sat behind "x and x ~= ''", the same
    -- truthiness guard that hid the node.label and action.unit defects.
    GRIPEMS.Engine.sequences["AuthorShapeSeq"] = {
        data = {
            name = "AuthorShapeSeq",
            author = {},
            originalAuthor = {},
            versions = {
                {
                    stepFunction = D.STEP_SEQUENTIAL,
                    steps = { A },
                    actions = { action(A) },
                },
            },
        },
    }
    local ok, result = pcall(GE.ExportAsText, { "AuthorShapeSeq" }, {}, {})
    assertTrue(ok, "ExportAsText raised: " .. tostring(result))
    assertTrue(type(result) == "string", "export returned text")
    assertTrue(result:find(A, 1, true) ~= nil, "the well-formed action still emitted")

    -- The originalAuthor half needs a locale value that actually carries a
    -- "%s". LOCALE_FORMATS now supplies one globally, so no local override is
    -- needed here -- the first export call above already exercises the guard.
    GRIPEMS.Engine.sequences["AuthorShapeSeq"] = nil
end)

test("W12: ExportAsText emits a version whose keyPress / keyRelease are not text", function()
    -- GRIPExport.lua type-checks ver.keyPress at :686 ("if ver.keyPress and
    -- type(ver.keyPress) == 'string' then", the variable-bundle gmatch) and
    -- once read it bare at :1093 -- one file, two opinions. A table raised
    -- "attempt to concatenate field 'keyPress'".
    --
    -- PASS 15 CORRECTION, both halves. The line numbers were :636 and :1033
    -- and both were wrong -- and NOT by the eleven lines this file shifted, so
    -- they were already wrong before pass 14 rather than stale: :636 is
    -- "local maxMacros = (MAX_ACCOUNT_MACROS or 120) + ...", :683 minus 11 is
    -- an unrelated gmatch loop, :1033 is a doc-comment line and :1090 minus 11
    -- is a comment. The "two opinions" framing is HISTORICAL as well: :1093 is
    -- no longer a bare read, it is "local keyPressText = D.ExecText(ver.keyPress)",
    -- so the file now holds one opinion expressed two ways -- type-check then
    -- gmatch at :686, coerce-or-drop through D.ExecText at :1093. This case
    -- pins the :1093 half; D.ExecText itself is pinned directly in W13.
    local function installVer(kp, kr)
        GRIPEMS.Engine.sequences["KeyShapeSeq"] = {
            data = {
                name = "KeyShapeSeq",
                versions = {
                    {
                        stepFunction = D.STEP_SEQUENTIAL,
                        steps = { A },
                        actions = { action(A) },
                        keyPress = kp,
                        keyRelease = kr,
                    },
                },
            },
        }
    end

    installVer({}, true)
    local ok, result = pcall(GE.ExportAsText, { "KeyShapeSeq" }, {}, {})
    assertTrue(ok, "ExportAsText raised on non-text key blocks: " .. tostring(result))
    assertTrue(type(result) == "string", "export returned text")
    assertTrue(result:find(A, 1, true) ~= nil, "the well-formed action still emitted")

    -- A well-formed pair still emits both label lines with unchanged text.
    installVer("/cast Alpha", "/cast Beta")
    local ok2, result2 = pcall(GE.ExportAsText, { "KeyShapeSeq" }, {}, {})
    assertTrue(ok2, "ExportAsText raised on well-formed key blocks: " .. tostring(result2))
    assertTrue(result2:find("/cast Alpha", 1, true) ~= nil, "the keyPress text still emits")
    assertTrue(result2:find("/cast Beta", 1, true) ~= nil, "the keyRelease text still emits")

    GRIPEMS.Engine.sequences["KeyShapeSeq"] = nil
end)

test("W13: D.DisplayText coerces for display and honours its nil fallback", function()
    -- The DISPLAY half of the coerce-or-drop rule. It shipped with no caller
    -- and no fixture, so this is its first execution. Tested DIRECTLY, not
    -- through the export path, so it cannot silently start depending on a
    -- particular call site.
    assertEqual("Unknown", D.DisplayText(nil, "Unknown"), "nil returns the fallback")
    assertEqual("", D.DisplayText(nil), "nil with no fallback returns empty")
    assertEqual("Sataana", D.DisplayText("Sataana", "Unknown"), "a string passes through")
    assertEqual("", D.DisplayText("", "Unknown"), "an empty string is NOT the nil case")
    assertEqual("42", D.DisplayText(42, "Unknown"), "a number coerces")
    assertEqual("true", D.DisplayText(true, "Unknown"), "a boolean coerces")
    -- Pass 11 ruling: false is ABSENT, not text. No text field in this
    -- codebase carries false as a legitimate display value, and rendering the
    -- literal "false" into an export listing reads as an addon bug.
    assertEqual("Unknown", D.DisplayText(false, "Unknown"), "false is absent, not text")
    assertEqual("", D.DisplayText("", "Unknown"), "an empty string is still NOT the nil case")
    local coerced = D.DisplayText({}, "Unknown")
    assertTrue(type(coerced) == "string" and coerced ~= "", "a table coerces to a non-empty string")
    assertTrue(coerced:find("table:", 1, true) ~= nil, "the table coercion is tostring's form")

    -- ExecText is the other half: it DROPS rather than coercing, because its
    -- output reaches a live macro.
    assertEqual("", D.ExecText({}), "ExecText drops a table")
    assertEqual("", D.ExecText(42), "ExecText drops a number")
    assertEqual("/cast Alpha", D.ExecText("/cast Alpha"), "ExecText passes a string through")
end)

test("W14: a COLLECTION whose payload.Sequences is a NUMBER previews and imports", function()
    -- LegacyImport:280 and ImportPreview:339 guard with bare truthiness --
    -- "if not payload or not payload.Sequences then" -- and then call pairs()
    -- on the field. pairs raises on a number exactly as ipairs does. This rail
    -- was unreachable from this harness until the Serialization stub landed.
    local LIm = GRIPEMS.LegacyImport
    local Ser = GRIPEMS.Serialization
    local function encoded(payload)
        local _, str = Ser.Encode({ type = "COLLECTION", payload = payload }, D.GSE3_PREFIX)
        return str
    end

    for _, shape in ipairs({ 42, true, "text" }) do
        local okP, prev = pcall(LIm.Preview, encoded({ Sequences = shape }))
        assertTrue(okP, "Preview raised on Sequences=" .. type(shape) .. ": " .. tostring(prev))
        local okI, res = pcall(LIm.Import, encoded({ Sequences = shape }))
        assertTrue(okI, "Import raised on Sequences=" .. type(shape) .. ": " .. tostring(res))
    end

    -- Control: a well-formed COLLECTION still previews its entry, so the rows
    -- above are not passing because nothing reached the walk.
    local okC, prevC = pcall(
        LIm.Preview,
        encoded({
            Sequences = {
                W14Seq = {
                    MacroVersions = {
                        {
                            StepFunction = "Sequential",
                            KeyPress = {},
                            KeyRelease = {},
                            Actions = { { Type = "Action", type = "macro", macro = "/cast Fireball" } },
                        },
                    },
                    MetaData = { Default = 1, Author = "MrSataana" },
                },
            },
        })
    )
    assertTrue(okC, "Preview raised on the well-formed control: " .. tostring(prevC))
    assertTrue(type(prevC) == "table" and prevC.ok == true, "the control previews ok")
    assertTrue(#prevC.sequences > 0, "the control produced an entry, so the walk really ran")
end)

test("W15: CommitSelected tolerates a non-table modifierChain on a native entry", function()
    -- BuildSeqDataFromGRIP1 is a file-local in ImportPreview, so its
    -- modifierChain / forkedFromChain ipairs walks could not be driven at all
    -- until the Serialization stub landed. CommitSelected is the public way in.
    local LIm = GRIPEMS.LegacyImport

    local function commitWith(chainShape, forkShape)
        local entry = {
            name = "W15Seq",
            -- isCollection routes to the BuildSeqDataFromGRIP1 arm where
            -- seqObj IS the sequence payload; without it CommitSelected takes
            -- the single-sequence arm and reads entry.seqObj.sequence instead.
            isCollection = true,
            seqObj = {
                versions = { { stepFunction = D.STEP_SEQUENTIAL, steps = { A } } },
                defaultVersion = 1,
                -- Same gate as the GRIPExport and LegacyImport twins: the
                -- chain walks sit behind a non-empty originalAuthor, so
                -- without it the fixture never reaches the guard.
                originalAuthor = "Someone",
                modifierChain = chainShape,
                forkedFromChain = forkShape,
            },
        }
        -- CommitSelected takes (preview, selections) and commits nothing
        -- without an explicit per-index selection, so the second argument is
        -- required or the walk is never reached.
        return pcall(
            LIm.CommitSelected,
            { ok = true, format = "GRIP1", sequences = { entry }, variables = {} },
            { sequences = { { selected = true, action = "import" } }, variables = {} }
        )
    end

    for _, shape in ipairs({ 42, true, "text" }) do
        local ok, res = commitWith(shape, nil)
        assertTrue(ok, "CommitSelected raised on modifierChain=" .. type(shape) .. ": " .. tostring(res))
        local ok2, res2 = commitWith(nil, shape)
        assertTrue(ok2, "CommitSelected raised on forkedFromChain=" .. type(shape) .. ": " .. tostring(res2))
        GRIPEMS.Engine.sequences["W15Seq"] = nil
    end

    -- Control: a well-formed chain still copies through, so the rows above are
    -- not passing because the entry was rejected before the walk.
    local okC, resC = commitWith({ { editor = "Someone" } }, nil)
    assertTrue(okC, "CommitSelected raised on the well-formed control: " .. tostring(resC))
    GRIPEMS.Engine.sequences["W15Seq"] = nil
end)

test("W16: GE.ImportNative tolerates non-table chain fields", function()
    -- GRIPExport carries its own copy of the modifierChain / forkedFromChain
    -- ipairs walks. The malformed rows assert on the ABSENCE of an ipairs
    -- error rather than on overall success, because that error is the specific
    -- guard under test and a broader assertion would also catch unrelated
    -- failures. The well-formed control completes the import and returns the
    -- name, which is what proves the walks are actually reached.
    local Ser = GRIPEMS.Serialization
    local function importWith(chainShape, forkShape)
        local _, str = Ser.Encode({
            format = "GRIP-EMS",
            version = D.GRIP_FORMAT_VERSION,
            name = "W16Seq",
            sequence = {
                versions = { { stepFunction = D.STEP_SEQUENTIAL, steps = { A } } },
                defaultVersion = 1,
                -- The chain walks sit behind "if seq.originalAuthor and
                -- seq.originalAuthor ~= ''", the same gate LegacyImport uses.
                -- Without it the whole provenance block is skipped and the
                -- fixture never reaches the guard it exists to pin.
                originalAuthor = "Someone",
                modifierChain = chainShape,
                forkedFromChain = forkShape,
            },
        }, D.EMS1_PREFIX)
        -- ImportNative returns (success, name, seqData); it does NOT register
        -- the sequence, so the control below checks its return value rather
        -- than the Engine store.
        local ok, ret, name = pcall(GE.ImportNative, str)
        return ok, tostring(ret), name
    end

    for _, shape in ipairs({ 42, true, "text" }) do
        local _, err = importWith(shape, nil)
        assertTrue(err:find("ipairs", 1, true) == nil, "modifierChain " .. type(shape) .. " hit ipairs: " .. err)
        local _, err2 = importWith(nil, shape)
        assertTrue(err2:find("ipairs", 1, true) == nil, "forkedFromChain " .. type(shape) .. " hit ipairs: " .. err2)
    end

    -- Control: a well-formed chain must complete the import, which proves the
    -- rows above are not passing because nothing reached the walks.
    local ctlOk, ctlRet, ctlName = importWith({ { editor = "Someone" } }, { "Origin" })
    assertTrue(ctlOk, "the well-formed control raised: " .. ctlRet)
    assertEqual("true", ctlRet, "the control import succeeded")
    assertEqual("W16Seq", ctlName, "the control returned the imported name")
end)

test("W17: ExportAsText survives a stored version whose steps / actions / versions are not tables", function()
    -- The export emitter reads these three off a STORED seqData. Measured
    -- before the guards: steps = 42 or true raised at the length operator,
    -- steps = "text" cleared the length operator and raised one line down at
    -- ipairs instead, and versions = 42 raised on the vCount read.
    local function exportWith(versionsShape)
        GRIPEMS.Engine.sequences["W17Seq"] = {
            data = { name = "W17Seq", versions = versionsShape, defaultVersion = 1 },
        }
        local ok, res = pcall(GE.ExportAsText, { "W17Seq" }, {}, {})
        GRIPEMS.Engine.sequences["W17Seq"] = nil
        return ok, res
    end

    for _, shape in ipairs({ 42, true, "text" }) do
        local ok, res = exportWith({ { steps = shape } })
        assertTrue(ok, "steps=" .. type(shape) .. " raised: " .. tostring(res))
        local okA, resA = exportWith({ { steps = { A }, actions = shape } })
        assertTrue(okA, "actions=" .. type(shape) .. " raised: " .. tostring(resA))
    end
    local okV, resV = exportWith(42)
    assertTrue(okV, "versions=number raised: " .. tostring(resV))

    -- Control, on a non-zero observable: a well-formed sequence must emit its
    -- step text, and the falsify row below must NOT.
    local okC, resC = exportWith({ { steps = { A }, stepFunction = D.STEP_SEQUENTIAL } })
    assertTrue(okC and type(resC) == "string", "the control raised: " .. tostring(resC))
    assertTrue(resC:find(A, 1, true) ~= nil, "the control emitted its step text")
    local _, resE = exportWith({ { steps = {} } })
    assertTrue(
        type(resE) == "string" and resE:find(A, 1, true) == nil,
        "control-falsify: an empty step array must NOT emit the step text"
    )
end)

test("W18: BuildExportList survives a malformed stored steps and still counts its neighbour", function()
    -- The export DIALOG's first call, and the widest blast radius in this
    -- family: BuildExportList walks pairs(Engine.sequences) -- EVERY stored
    -- sequence -- so before the guards ONE malformed entry failed the whole
    -- dialog, not just its own row. Measured before them: steps = 42 or true
    -- raised at the length operator, steps = "text" cleared it and raised four
    -- lines down at the version-scan ipairs instead.
    --
    -- The NEIGHBOUR is the point. A single-sequence fixture cannot tell "the
    -- guard worked" from "the call died before anything was counted", so every
    -- row below carries a well-formed second sequence and asserts its real,
    -- non-zero step count out of the SAME call.
    local saved = GRIPEMS.Engine.sequences
    local function listWith(stepsShape)
        GRIPEMS.Engine.sequences = {
            W18Bad = {
                data = {
                    name = "W18Bad",
                    defaultVersion = 1,
                    versions = { { steps = stepsShape, stepFunction = D.STEP_SEQUENTIAL } },
                },
            },
            W18Good = {
                data = {
                    name = "W18Good",
                    defaultVersion = 1,
                    versions = { { steps = { A, B }, stepFunction = D.STEP_SEQUENTIAL } },
                },
            },
        }
        local ok, res = pcall(GE.BuildExportList)
        local byName = {}
        if ok and type(res) == "table" then
            for _, s in ipairs(res.sequences or {}) do
                byName[s.name] = s
            end
        end
        return ok, res, byName
    end

    -- ABSENT is the shape that must keep working unchanged, so it is a row too.
    for _, shape in ipairs({ "ABSENT", 42, true, "text" }) do
        local value = (shape ~= "ABSENT") and shape or nil
        local ok, res, byName = listWith(value)
        assertTrue(ok, "steps=" .. tostring(shape) .. " raised: " .. tostring(res))
        assertTrue(byName.W18Bad ~= nil, "the malformed entry still produced a row for " .. tostring(shape))
        assertEqual(0, byName.W18Bad.stepCount, "malformed steps counts 0 for " .. tostring(shape))
        assertTrue(byName.W18Good ~= nil, "the neighbour survived the malformed entry for " .. tostring(shape))
        assertEqual(2, byName.W18Good.stepCount, "the neighbour still reports its real count")
    end

    -- Same field one level up: the legacy FLAT seqData.steps fallbacks in this
    -- function read a different field and were masked by the version-scan raise
    -- above. Measured to raise on their own once that was closed.
    for _, shape in ipairs({ 42, true, "text" }) do
        GRIPEMS.Engine.sequences = {
            W18Flat = {
                data = {
                    name = "W18Flat",
                    defaultVersion = 1,
                    steps = shape,
                    versions = { { steps = { A }, stepFunction = D.STEP_SEQUENTIAL } },
                },
            },
        }
        local ok, res = pcall(GE.BuildExportList)
        assertTrue(ok, "legacy flat steps=" .. type(shape) .. " raised: " .. tostring(res))
        assertEqual(1, res.sequences[1].stepCount, "the version-level count is unaffected by the flat field")
    end

    -- CONTROL on a non-zero observable: two well-formed sequences, both
    -- counted, and the variable scan actually reaching a step.
    GRIPEMS.Engine.sequences = {
        W18Good = {
            data = {
                name = "W18Good",
                defaultVersion = 1,
                versions = { { steps = { A, B }, stepFunction = D.STEP_SEQUENTIAL } },
            },
        },
        W18Also = {
            data = {
                name = "W18Also",
                defaultVersion = 1,
                versions = { { steps = { A, B, C }, stepFunction = D.STEP_SEQUENTIAL } },
            },
        },
    }
    local okC, resC = pcall(GE.BuildExportList)
    assertTrue(okC, "the well-formed control raised: " .. tostring(resC))
    assertEqual(2, #resC.sequences, "both control sequences listed")
    local counts = {}
    for _, s in ipairs(resC.sequences) do
        counts[s.name] = s.stepCount
    end
    assertEqual(2, counts.W18Good, "control W18Good counts 2")
    assertEqual(3, counts.W18Also, "control W18Also counts 3")

    -- CONTROL-FALSIFY: empty step arrays must produce 0, so the counts above
    -- are being read off the steps and not off some constant.
    GRIPEMS.Engine.sequences = {
        W18Empty = {
            data = {
                name = "W18Empty",
                defaultVersion = 1,
                versions = { { steps = {}, stepFunction = D.STEP_SEQUENTIAL } },
            },
        },
    }
    local okF, resF = pcall(GE.BuildExportList)
    assertTrue(okF, "the falsify control raised: " .. tostring(resF))
    assertEqual(0, resF.sequences[1].stepCount, "control-falsify: an empty step array counts 0")

    GRIPEMS.Engine.sequences = saved
end)

test("W19: PrepareExportVersions keeps absent steps nil and never raises on a scalar", function()
    -- ipairs is harsher than the length operator: a string steps clears a "#"
    -- but still raises here. Measured before the guard: 42, true AND "text"
    -- all raised "bad argument #1 to 'ipairs'" on the walk below the guard.
    --
    -- ABSENT must stay nil, not become an empty table. GE.BuildInsights reads
    -- exportVersions[n].steps with a truthiness guard on the strength of that,
    -- so turning absent into {} here would be a silent behaviour change even
    -- though nothing would raise.
    local function prep(stepsShape)
        local seqData = {
            name = "W19Seq",
            defaultVersion = 1,
            versions = { { steps = stepsShape, stepFunction = D.STEP_SEQUENTIAL } },
        }
        local ok, res = pcall(GE.PrepareExportVersions, seqData)
        return ok, res
    end

    local okAbsent, evAbsent = prep(nil)
    assertTrue(okAbsent, "absent steps raised: " .. tostring(evAbsent))
    assertEqual("nil", type(evAbsent[1].steps), "absent steps stays nil, never an empty table")

    for _, shape in ipairs({ 42, true, "text" }) do
        local ok, ev = prep(shape)
        assertTrue(ok, "steps=" .. type(shape) .. " raised: " .. tostring(ev))
        assertEqual("nil", type(ev[1].steps), "a scalar steps is dropped, not copied through")
        assertTrue(ev[1].stepFunction == D.STEP_SEQUENTIAL, "the rest of the version still copied")
    end

    -- The downstream contract EDIT 3 documents: BuildInsights must accept what
    -- PrepareExportVersions produces for every one of those shapes.
    for _, shape in ipairs({ 42, true, "text" }) do
        local _, ev = prep(shape)
        local okI, ins = pcall(GE.BuildInsights, "W19Seq", { defaultVersion = 1 }, ev)
        assertTrue(okI, "BuildInsights raised on a dropped steps: " .. tostring(ins))
        assertEqual(0, ins.stepCount, "a dropped steps reports 0 steps")
    end

    -- CONTROL on a non-zero observable: a well-formed steps must survive as a
    -- TABLE of the right length and reach BuildInsights as a real count.
    local okC, evC = prep({ A, B })
    assertTrue(okC, "the well-formed control raised: " .. tostring(evC))
    assertEqual("table", type(evC[1].steps), "control steps is a table")
    assertEqual(2, #evC[1].steps, "control steps kept both entries")
    local _, insC = pcall(GE.BuildInsights, "W19Seq", { defaultVersion = 1 }, evC)
    assertEqual(2, insC.stepCount, "control reaches BuildInsights as a real count")

    -- CONTROL-FALSIFY: an empty steps array is still a TABLE and still counts
    -- 0, so the control above is reading the length and not the type alone.
    local _, evF = prep({})
    assertEqual("table", type(evF[1].steps), "an empty steps array is still a table")
    assertEqual(0, #evF[1].steps, "control-falsify: an empty steps array counts 0")
end)

test("W20: GE.Export completes on a well-formed sequence", function()
    -- FIRST fixture on GE.Export. One call reaches PrepareExportVersions,
    -- ResolveExportContext, BuildDependenciesField, BuildInsights, GetLocale
    -- and the encoder -- the cluster with no coverage before this pass.
    --
    -- Its own upstream gate is a MISSING STUB, not a payload field: with
    -- GetLocale absent from WOW_GLOBALS this raised at GRIPExport.lua:558,
    -- before any site under test, which is why that stub was restored. The
    -- malformed rows at the end also pin the :94 nil-out branch: without it a
    -- scalar steps survived PrepareExportVersions and raised at :445 in
    -- BuildDependenciesField, which no other fixture reaches.
    local saved = GRIPEMS.Engine.sequences
    local Ser = GRIPEMS.Serialization
    local function exportWith(stepsShape)
        GRIPEMS.Engine.sequences = {
            W20Seq = {
                data = {
                    name = "W20Seq",
                    defaultVersion = 1,
                    privacyMode = D.PRIVACY_MODE_PUBLIC,
                    versions = { { steps = stepsShape, stepFunction = D.STEP_SEQUENTIAL } },
                },
            },
        }
        return pcall(GE.Export, "W20Seq")
    end

    -- CONTROL on a non-zero observable, decoded back out of the payload rather
    -- than asserted on the opaque encoded string.
    local ok, success, encoded = exportWith({ A, B })
    assertTrue(ok, "Export raised on a well-formed sequence: " .. tostring(success))
    assertEqual(true, success, "Export reports success")
    assertTrue(type(encoded) == "string" and encoded ~= "", "Export returned a non-empty string")
    local okD, payload = Ser.Decode(encoded)
    assertTrue(okD, "the exported string did not decode back")
    assertEqual("GRIP-EMS", payload.format, "payload carries the native format tag")
    assertEqual("enUS", payload.locale, "GetLocale reached and served -- the read is real")
    assertEqual(2, #payload.sequence.versions[1].steps, "PrepareExportVersions carried both steps")
    assertEqual(2, payload.sequence.insights.stepCount, "BuildInsights counted them")
    assertTrue(payload.wowPatch ~= nil, "ResolveExportContext filled the build context")

    -- CONTROL-FALSIFY: an empty step array must export with a ZERO count, so
    -- the 2s above are read off the steps rather than off the payload shape.
    local okF, successF, encodedF = exportWith({})
    assertTrue(okF and successF == true, "Export raised on the falsify control: " .. tostring(successF))
    local _, payloadF = Ser.Decode(encodedF)
    assertEqual(0, payloadF.sequence.insights.stepCount, "control-falsify: no steps reports 0")

    -- A malformed stored steps must not take the whole export down either.
    for _, shape in ipairs({ 42, true, "text" }) do
        local okM, successM = exportWith(shape)
        assertTrue(okM, "Export raised on steps=" .. type(shape) .. ": " .. tostring(successM))
        assertEqual(true, successM, "Export still succeeds on a malformed stored steps")
    end

    GRIPEMS.Engine.sequences = saved
end)

-- ---------------------------------------------------------------------------
-- Wave 3: field-shape corruption (a node table whose FIELD has the wrong
-- type). Entry-shape corruption is covered by W1-W7 above.
-- ---------------------------------------------------------------------------

local DLT = "/cast Delta"

--- Actions carrying every field-shape class wave 3 guards: scalar children
--- on a Loop and an IF, non-number repeat (unconvertible and numeric-string),
--- non-string variable, scalar IF branch, non-number clicks, numeric-string
--- interval, and a non-string macro.
local function makeFieldCorruptActions()
    return {
        action(A),
        { type = D.ACTION_TYPE_LOOP, ["repeat"] = "x", stepFunction = D.STEP_SEQUENTIAL, children = 7 },
        { type = D.ACTION_TYPE_LOOP, ["repeat"] = "3", stepFunction = D.STEP_SEQUENTIAL, children = { action(C) } },
        { type = D.ACTION_TYPE_IF, variable = 5, children = 9 },
        { type = D.ACTION_TYPE_IF, variable = "combat", children = { 9, { action(DLT) } } },
        { type = D.ACTION_TYPE_PAUSE, clicks = "many" },
        action(B, { interval = "4" }),
        { type = D.ACTION_TYPE_ACTION, macro = 5 },
    }
end

test("F1: CompileActions survives field-shape corruption", function()
    local AC = GRIPEMS.ActionCompiler
    local ok, steps = pcall(AC.CompileActions, makeFieldCorruptActions(), nil)
    assertTrue(ok, "CompileActions raised: " .. tostring(steps))
    assertTrue(type(steps) == "table", "steps table returned")
    local charlieCount = 0
    local bravoCount = 0
    local sawAlpha = false
    local sawDelta = false
    for _, s in ipairs(steps) do
        if s == C then
            charlieCount = charlieCount + 1
        end
        if s == B then
            bravoCount = bravoCount + 1
        end
        if s == A then
            sawAlpha = true
        end
        if type(s) == "string" and s:find("Delta", 1, true) then
            sawDelta = true
        end
    end
    assertTrue(sawAlpha, "well-formed action compiled")
    assertEqual(3, charlieCount, "numeric-string repeat healed to 3 iterations")
    assertTrue(sawDelta, "IF false branch behind a scalar true branch compiled")
    assertEqual(1, bravoCount, "numeric-string interval healed into one interleave copy")
    assertEqual(8, #steps, "7 base steps plus 1 interleave copy")
    for si, s in ipairs(steps) do
        assertTrue(type(s) == "string", "step " .. tostring(si) .. " is a string, never a raw corrupt macro")
    end
    local ok2, steps2 = pcall(AC.CompileActions, 5, nil)
    assertTrue(ok2, "scalar actions field raised: " .. tostring(steps2))
    assertEqual(0, #steps2, "scalar actions field compiles to nothing")
end)

test("F2: ValidateActions reports one error per field-shape class, never throws", function()
    local AC = GRIPEMS.ActionCompiler
    local ok, isValid, errors = pcall(AC.ValidateActions, makeFieldCorruptActions())
    assertTrue(ok, "ValidateActions raised: " .. tostring(isValid))
    assertEqual(false, isValid, "field-shape corrupt tree is invalid")
    local blob = table.concat(errors, "\n")
    assertTrue(blob:find("loop repeat has invalid type", 1, true) ~= nil, "repeat class reported")
    assertTrue(blob:find("children field has invalid type", 1, true) ~= nil, "children class reported")
    assertTrue(blob:find("if variable has invalid type", 1, true) ~= nil, "variable class reported")
    assertTrue(blob:find("IF true branch has invalid type", 1, true) ~= nil, "branch class reported")
    assertTrue(blob:find("pause clicks has invalid type", 1, true) ~= nil, "clicks class reported")
    assertTrue(blob:find("action macro has invalid type", 1, true) ~= nil, "macro class reported")
    assertTrue(
        blob:find("if has empty variable", 1, true) == nil,
        "empty-variable co-fire suppressed when the type error fired"
    )
    local okE, validE, errE = pcall(AC.ValidateActions, { { type = D.ACTION_TYPE_EMBED, sequence = 5 } })
    assertTrue(okE, "corrupt embed validation raised: " .. tostring(validE))
    assertEqual(false, validE, "corrupt embed tree is invalid")
    assertTrue(table.concat(errE, "\n"):find("embed sequence has invalid type", 1, true) ~= nil, "embed class reported")
    local ok2, isValid2 = pcall(AC.ValidateActions, 5)
    assertTrue(ok2, "scalar actions field raised in validation")
    assertEqual(true, isValid2, "scalar actions field returns clean (head guard)")
end)

test("F3: NodeSummary renders field-shape-corrupt nodes without error", function()
    for idx, node in ipairs(makeFieldCorruptActions()) do
        local ok, summary = pcall(D.NodeSummary, node)
        assertTrue(ok, "NodeSummary raised on node " .. tostring(idx) .. ": " .. tostring(summary))
        assertTrue(type(summary) == "string", "summary is a string for node " .. tostring(idx))
    end
    local expectLoop = string.format("x%d %s, %d actions", D.ACTION_LOOP_DEFAULT_REPEAT, D.STEP_SEQUENTIAL, 0)
    assertEqual(
        expectLoop,
        D.NodeSummary({ type = D.ACTION_TYPE_LOOP, ["repeat"] = "x", children = 7 }),
        "corrupt loop renders defaults"
    )
    assertEqual(
        "[no cond] ? 0 : 0",
        D.NodeSummary({ type = D.ACTION_TYPE_IF, variable = 5, children = 9 }),
        "corrupt IF renders no-cond zero counts"
    )
    local ok3, sfSummary =
        pcall(D.NodeSummary, { type = D.ACTION_TYPE_LOOP, ["repeat"] = 2, stepFunction = {}, children = {} })
    assertTrue(ok3, "table stepFunction raised: " .. tostring(sfSummary))
    local ivSummary = D.NodeSummary(action(A, { interval = "4" }))
    assertTrue(ivSummary:find("IL:4", 1, true) ~= nil, "numeric-string interval renders the IL suffix")
    assertEqual(
        "(none)",
        D.NodeSummary({ type = D.ACTION_TYPE_EMBED, sequence = 5 }),
        "corrupt embed sequence renders (none)"
    )
end)

test("F4: SanitizeActionNode coerces field shapes", function()
    local node = {
        type = D.ACTION_TYPE_LOOP,
        ["repeat"] = "3",
        clicks = "2",
        interval = "4",
        variable = 5,
        macro = 5,
        sequence = true,
        stepFunction = 7,
        children = 5,
        label = "  keep me  ",
    }
    D.SanitizeActionNode(node)
    assertEqual(3, node["repeat"], "numeric-string repeat healed")
    assertEqual(2, node.clicks, "numeric-string clicks healed")
    assertEqual(4, node.interval, "numeric-string interval healed")
    assertEqual(nil, node.variable, "non-string variable dropped")
    assertEqual(nil, node.macro, "non-string macro dropped")
    assertEqual(nil, node.sequence, "non-string sequence dropped")
    assertEqual(nil, node.stepFunction, "non-string stepFunction dropped")
    assertEqual(nil, node.children, "non-table children dropped")
    assertEqual("keep me", node.label, "label clamp unchanged")
    local unconv = { type = D.ACTION_TYPE_LOOP, ["repeat"] = "x", clicks = true }
    D.SanitizeActionNode(unconv)
    assertEqual(nil, unconv["repeat"], "unconvertible repeat dropped")
    assertEqual(nil, unconv.clicks, "unconvertible clicks dropped")
end)

test("F5: DeepCopyActions heals field shapes via sanitize", function()
    local copy = D.DeepCopyActions({
        {
            type = D.ACTION_TYPE_LOOP,
            ["repeat"] = "3",
            stepFunction = D.STEP_SEQUENTIAL,
            children = { action(A, { interval = "4" }) },
        },
        { type = D.ACTION_TYPE_IF, variable = 5, children = { { action(B) }, {} } },
    })
    assertEqual(3, copy[1]["repeat"], "loop repeat healed in copy")
    assertEqual(4, copy[1].children[1].interval, "nested interval healed in copy")
    assertEqual(nil, copy[2].variable, "corrupt variable dropped in copy")
    assertEqual(B, copy[2].children[1][1].macro, "IF true branch preserved")
end)

test("W8: CheckActions survives field-shape corruption and still reports", function()
    local seqData = {
        name = "FieldCorruptSeq",
        versions = {
            { stepFunction = D.STEP_SEQUENTIAL, steps = { A }, actions = makeFieldCorruptActions() },
        },
    }
    local issues = {}
    local ok, err = pcall(function()
        RA:CheckActions(seqData, issues)
    end)
    assertTrue(ok, "CheckActions raised: " .. tostring(err))
    local titles = {}
    for _, issue in ipairs(issues) do
        titles[#titles + 1] = tostring(issue.title)
    end
    local blob = table.concat(titles, "|")
    assertTrue(blob:find("Invalid LOOP count", 1, true) ~= nil, "corrupt repeat lands in the loop-count report")
    assertTrue(blob:find("Invalid PAUSE clicks", 1, true) ~= nil, "corrupt clicks lands in the clicks report")
    assertTrue(blob:find("Action tree error", 1, true) ~= nil, "ValidateActions errors surfaced")
end)

test("W9: CommitSelected legacy pcall containment rolls back partial stats", function()
    -- ImportPreview.lua defines LI.CommitSelected on the LegacyImport table,
    -- so seed a stub LegacyImport whose ProcessSequence mutates counters and
    -- then raises mid-compile (mirroring a corrupt legacy payload), load the
    -- REAL ImportPreview.lua, and drive CommitSelected through the legacy
    -- branch. The rollback must restore every counter; the failed sequence
    -- contributes exactly one warning.
    GRIPEMS.LegacyImport = GRIPEMS.LegacyImport or {}
    local LI = GRIPEMS.LegacyImport
    LI.ProcessSequence = function(name, seqObj, results, opts)
        results.count = results.count + 1
        results.names[#results.names + 1] = name
        results.stepCounts[name] = 3
        results.stepFunctions[name] = "Sequential"
        results.contextOverridesImported = results.contextOverridesImported + 1
        results.warnings[#results.warnings + 1] = "partial work before the failure"
        error("mid-compile corruption")
    end
    assertTrue(
        loadModule({ "Import/ImportPreview.lua", "../Import/ImportPreview.lua" }),
        "could not locate Import/ImportPreview.lua (run from the EMS root)"
    )
    local preview = {
        ok = true,
        format = "LEGACY",
        sequences = { { name = "JunkSeq", seqObj = {} } },
        variables = {},
    }
    local selections = { sequences = { { selected = true, action = "import" } } }
    local ok, success, results = pcall(LI.CommitSelected, preview, selections)
    assertTrue(ok, "CommitSelected raised: " .. tostring(success))
    assertEqual(true, success, "commit reports success")
    assertEqual(0, results.count, "count rolled back")
    assertEqual(0, #results.names, "names rolled back")
    assertEqual(nil, results.stepCounts["JunkSeq"], "stepCounts entry rolled back")
    assertEqual(nil, results.stepFunctions["JunkSeq"], "stepFunctions entry rolled back")
    assertEqual(0, results.contextOverridesImported, "context override count rolled back")
    assertEqual(1, #results.warnings, "exactly one failure warning")
    assertTrue(tostring(results.warnings[1]):find("JunkSeq", 1, true) ~= nil, "warning names the sequence")
end)

-- ---------------------------------------------------------------------------
-- Pass 14: the two stored-shape readers pass 13 deferred. Both drive the REAL
-- functions through this sandbox, not a reconstruction, and both keep the
-- malformed entry and a well-formed NEIGHBOUR in the SAME Engine.sequences
-- table and the SAME call -- "it did not raise" is also what a guard that
-- silently skipped everything would produce, so the neighbour's result is the
-- non-zero observable that separates the two.
-- ---------------------------------------------------------------------------

test("W22: ResolveVariableDeps survives a malformed stored steps and still resolves its neighbour", function()
    -- Five callers, only one of them the multi-select export dialog:
    -- ExportFrame.lua:188, SequenceList.lua:917, SequenceEditor.lua:458,
    -- Core.lua:809 and PublicAPI.lua:259. Pass 13 deferred this on the reason
    -- that it "runs only over the sequences the user SELECTED" -- true, and
    -- irrelevant, because four of those five hand it a name the user just
    -- right-clicked, typed or asked for over the plugin API.
    local saved = GRIPEMS.Engine.sequences
    local VARSTEP = "/cast ~MyVar~"

    local function resolveWith(versionSteps, flatSteps)
        GRIPEMS.Engine.sequences = {
            W22Bad = {
                data = {
                    name = "W22Bad",
                    defaultVersion = 1,
                    steps = flatSteps,
                    versions = { { steps = versionSteps, stepFunction = D.STEP_SEQUENTIAL } },
                },
            },
            W22Good = {
                data = {
                    name = "W22Good",
                    defaultVersion = 1,
                    versions = { { steps = { VARSTEP }, stepFunction = D.STEP_SEQUENTIAL } },
                },
            },
        }
        -- BOTH names, so the malformed entry and the neighbour share one call.
        return pcall(GE.ResolveVariableDeps, { "W22Bad", "W22Good" })
    end

    -- Versioned steps. ABSENT is a row too: it must keep working unchanged.
    for _, shape in ipairs({ "ABSENT", 42, true, "text" }) do
        local value = (shape ~= "ABSENT") and shape or nil
        local ok, deps = resolveWith(value, nil)
        assertTrue(ok, "versions[1].steps=" .. tostring(shape) .. " raised: " .. tostring(deps))
        assertEqual(true, deps.MyVar, "the neighbour still resolved for versions steps=" .. tostring(shape))
    end

    -- Legacy FLAT seqData.steps, the second guard in this function. It reads a
    -- different field and was masked by the version-scan raise above.
    for _, shape in ipairs({ 42, true, "text" }) do
        local ok, deps = resolveWith({ A }, shape)
        assertTrue(ok, "flat seqData.steps=" .. type(shape) .. " raised: " .. tostring(deps))
        assertEqual(true, deps.MyVar, "the neighbour still resolved for flat steps=" .. type(shape))
    end

    -- CONTROL-FALSIFY: with no variable reference anywhere the set comes back
    -- EMPTY, so the rows above are reading a real scan and not a constant.
    GRIPEMS.Engine.sequences = {
        W22Plain = {
            data = {
                name = "W22Plain",
                defaultVersion = 1,
                versions = { { steps = { A }, stepFunction = D.STEP_SEQUENTIAL } },
            },
        },
    }
    local okF, depsF = pcall(GE.ResolveVariableDeps, { "W22Plain" })
    assertTrue(okF, "the falsify control raised: " .. tostring(depsF))
    assertEqual(nil, next(depsF), "control-falsify: a step with no ~var~ resolves to an empty set")

    -- CONTROL on the FLAT reader specifically: it resolves on its own, so the
    -- flat rows above are pinning a live branch rather than a dead one.
    GRIPEMS.Engine.sequences = {
        W22Flat = { data = { name = "W22Flat", steps = { VARSTEP } } },
    }
    local okL, depsL = pcall(GE.ResolveVariableDeps, { "W22Flat" })
    assertTrue(okL, "the flat control raised: " .. tostring(depsL))
    assertEqual(true, depsL.MyVar, "the legacy flat steps reader really resolves")

    -- The EMPTY array is a caller-produced shape as well: ExportFrame.lua:182
    -- builds selectedNames from the checked rows, so deselecting everything
    -- hands this function {}. "#selectedSeqNames > 0" is false for it, so it
    -- takes the already-a-set branch with nothing in it.
    local okE, depsE = pcall(GE.ResolveVariableDeps, {})
    assertTrue(okE, "an empty selection raised: " .. tostring(depsE))
    assertEqual(nil, next(depsE), "an empty selection resolves to an empty set")

    GRIPEMS.Engine.sequences = saved
end)

test("W23: DetectMissingEmbeddedDeps survives a malformed stored steps and still warns for its neighbour", function()
    -- One caller (ExportFrame.lua:209), which is the part of the pass-13 note
    -- that was true. It is reachable anyway: pass 13 made the export dialog
    -- OPEN on a malformed store, so the raise moved from BuildExportList to
    -- the first selection change the user makes in it.
    local saved = GRIPEMS.Engine.sequences
    -- Ghost is deliberately NOT in the selected array, so a scan that runs
    -- produces exactly one warning and a scan that does not produces zero.
    local CLICKSTEP = "/click GRIPEMS_Ghost"

    local function detectWith(versionSteps, flatSteps)
        GRIPEMS.Engine.sequences = {
            W23Bad = {
                data = {
                    name = "W23Bad",
                    defaultVersion = 1,
                    steps = flatSteps,
                    versions = { { steps = versionSteps, stepFunction = D.STEP_SEQUENTIAL } },
                },
            },
            W23Good = {
                data = {
                    name = "W23Good",
                    defaultVersion = 1,
                    versions = { { steps = { CLICKSTEP }, stepFunction = D.STEP_SEQUENTIAL } },
                },
            },
        }
        return pcall(GE.DetectMissingEmbeddedDeps, { "W23Bad", "W23Good" })
    end

    for _, shape in ipairs({ "ABSENT", 42, true, "text" }) do
        local value = (shape ~= "ABSENT") and shape or nil
        local ok, warnings = detectWith(value, nil)
        assertTrue(ok, "versions[1].steps=" .. tostring(shape) .. " raised: " .. tostring(warnings))
        assertEqual(1, #warnings, "the neighbour still warned once for versions steps=" .. tostring(shape))
        assertTrue(
            tostring(warnings[1]):find("Ghost", 1, true) ~= nil,
            "the warning names the unselected reference for " .. tostring(shape)
        )
    end

    for _, shape in ipairs({ 42, true, "text" }) do
        local ok, warnings = detectWith({ A }, shape)
        assertTrue(ok, "flat seqData.steps=" .. type(shape) .. " raised: " .. tostring(warnings))
        assertEqual(1, #warnings, "the neighbour still warned once for flat steps=" .. type(shape))
    end

    -- CONTROL-FALSIFY: select Ghost as well and the same store warns ZERO
    -- times, so the 1s above are read off the scan and not off the row count.
    GRIPEMS.Engine.sequences = {
        W23Good = {
            data = {
                name = "W23Good",
                defaultVersion = 1,
                versions = { { steps = { CLICKSTEP }, stepFunction = D.STEP_SEQUENTIAL } },
            },
        },
    }
    local okF, warnF = pcall(GE.DetectMissingEmbeddedDeps, { "W23Good", "Ghost" })
    assertTrue(okF, "the falsify control raised: " .. tostring(warnF))
    assertEqual(0, #warnF, "control-falsify: a SELECTED reference produces no warning")

    -- CONTROL on the FLAT reader specifically.
    GRIPEMS.Engine.sequences = {
        W23Flat = { data = { name = "W23Flat", steps = { CLICKSTEP } } },
    }
    local okL, warnL = pcall(GE.DetectMissingEmbeddedDeps, { "W23Flat" })
    assertTrue(okL, "the flat control raised: " .. tostring(warnL))
    assertEqual(1, #warnL, "the legacy flat steps reader really scans")

    -- Same caller-produced empty-selection shape as W22: ExportFrame.lua:182
    -- hands this function {} when the user deselects every row.
    local okE, warnE = pcall(GE.DetectMissingEmbeddedDeps, {})
    assertTrue(okE, "an empty selection raised: " .. tostring(warnE))
    assertEqual(0, #warnE, "an empty selection produces no warnings")

    GRIPEMS.Engine.sequences = saved
end)

-- ---------------------------------------------------------------------------
-- Pass 15: the .versions guard family. Eight type() guards read a versions
-- field, and before this pass NOT ONE of them was falsifiable -- measured by
-- reverting each to bare truthiness on its own, running the suite, and
-- restoring byte-identically: 28 passed / 0 failed every time.
--   ExportPreview.lua :40   GE.BuildExportList versionCount
--   ExportPreview.lua :58   GE.BuildExportList variable scan
--   ExportPreview.lua :97   GE.BuildExportList embedded scan
--   ExportPreview.lua :264  GE.ResolveVariableDeps
--   ExportPreview.lua :392  GE.DetectMissingEmbeddedDeps
--   GRIPExport.lua    :24   GE.PrepareExportVersions
--   GRIPExport.lua    :167  GE.ResolveExportContext versionCount
--   GRIPExport.lua    :771  GE.ImportNative, ahead of NormalizeVersionLocale
-- The suite held exactly ONE fixture with a scalar versions -- W17's
-- exportWith(42) -- and it reaches GE.ExportAsText only, which is why
-- GRIPExport :1067 and :1084 DO go red when reverted and these eight did not.
-- The steps family has two scalar fixtures and is fully pinned; the versions
-- family had none of its own, so a later pass "simplifying" any of the eight
-- back to truthiness would have shipped green.
--
-- W24 takes the five ExportPreview sites, W25 the three GRIPExport ones.
--
-- PASS 15c -- THE SWEEP THAT PRODUCED THAT LIST OF EIGHT WAS SHAPE-LIMITED, and
-- the limit is worth recording because it is invisible from the list itself.
-- Pass 15 enumerated the family by walking sites that ALREADY CARRIED a type()
-- guard and asking of each "is this falsifiable?". That question cannot be
-- asked of a site carrying NO guard at all, so a whole half of the family was
-- structurally outside the sweep. Swept for the complementary shape -- bare
-- truthiness head-checking .versions and then applying "#" -- six more live
-- reads came back, none of them among the eight:
--   Core/Core.lua          the /gems decompress preview (decoded is user-pasted)
--   UI/ContextTab.lua      x2, the version context menu and the tab refresh
--   UI/SequenceList.lua    the "Live: Vn" row tag
--   UI/SequenceEditor.lua  x2, SwitchToVersion's bound and RefreshVersionBar
-- Same failure as ExportPreview.lua:40 and GRIPExport.lua:167 carried before
-- pass 15: a number or boolean raises "attempt to get length of field
-- 'versions'", a string fabricates a count from its character length. All six
-- now carry the type() form; case W26 below pins them.
--
-- The SequenceList one is the sharpest lesson. Pass 15b guarded
-- Engine:GetActiveVersion, and the line two statements below that call re-read
-- the RAW field -- so the Engine fix did not make that surface safe, it
-- RELOCATED the raise out of the Engine and into the list builder. A guard on
-- an accessor says nothing about callers that bypass the accessor.
--
-- FOUR SITES LOOK LIKE THIS FAMILY AND ARE ALREADY SAFE. Do not "fix" them:
--   GRIPExport.lua   :1120  the local is bound from a type() test at :1119
--   ImportPreview.lua :515  the local is bound from a type() test at :512
--   SequenceList.lua  :972  inside "if ver then" -- unreachable for a scalar
--   SequenceList.lua  :988  inside "if ver then" -- unreachable for a scalar
-- Their bare-truthiness text is correct in context; rewriting them would add a
-- redundant test and cost the reader the reason the existing one is enough.
-- ---------------------------------------------------------------------------

test("W24: the ExportPreview readers survive a scalar stored versions", function()
    -- Same rule as W18 / W22 / W23: the malformed entry and a well-formed
    -- NEIGHBOUR go into the same Engine.sequences table and the SAME call, so
    -- "it did not raise" is separated from "it skipped everything".
    --
    -- THE FULL MATRIX RUNS AGAINST GE.BuildExportList AS OF PASS 15b, and the
    -- reason it could not before is worth keeping. A number or boolean
    -- seqData.versions used to never reach ExportPreview's guards at all:
    -- BuildExportList resolves the active version at ExportPreview.lua:43, one
    -- line past the :40 guard, and Engine:GetActiveVersion head-checked with
    -- bare truthiness at what was Engine.lua:621 in the PRE-FIX tree (that
    -- number is a frozen quote from the pre-fix run), now :735 ("not
    -- seqData.versions" as it read before the fix) and then
    -- INDEXED the field at four sites below it. Measured with all eight
    -- ExportPreview / GRIPExport guards intact: "attempt to index field
    -- 'versions' (a number value)" and "(a boolean value)", raised inside the
    -- Engine, upstream of every guard this case exists to pin. Only a string
    -- survived, because a string indexes to nil through the string metatable.
    --
    -- Pass 15 recorded that and deliberately did NOT assert it, on the grounds
    -- that pinning a raise would turn this case red the day Engine.lua was
    -- fixed. Pass 15b is that day: Engine.lua:735 is now
    -- "type(seqData.versions) ~= 'table'", matching the sibling guard at
    -- Engine:GetActiveVersionIndex, so all three shapes resolve to nil and reach
    -- the three sites in this function. THAT FIX IS NOT PINNED HERE -- this file
    -- never loads Engine.lua, so the rows below resolve through the Engine STUB
    -- above and would stay green even if the product regressed. Case G1 in
    -- Test/test_stepadv_numsteps_domain.lua, which loads the REAL Engine.lua, is
    -- what pins it. Both are in SET A, so CI runs them together.
    --
    -- ExportPreview.lua:40 is still pinned by VALUE and not by a raise, because
    -- "#" does not raise on a string -- it fabricates 4 from the character
    -- length. The number and boolean rows pin it by raise as well now.
    local saved = GRIPEMS.Engine.sequences
    local VARSTEP = "/cast ~MyVar~"
    local CLICKSTEP = "/click GRIPEMS_Ghost"

    local function listHas(arr, want)
        for _, v in ipairs(arr or {}) do
            if v == want then
                return true
            end
        end
        return false
    end

    local function goodData(steps)
        return {
            data = {
                name = "W24Good",
                defaultVersion = 1,
                versions = { { steps = steps, stepFunction = D.STEP_SEQUENTIAL } },
            },
        }
    end

    local function badData(versionsShape)
        return { data = { name = "W24Bad", defaultVersion = 1, versions = versionsShape } }
    end

    -- ENTRY POINT 1 -- GE.BuildExportList, three guard sites in one call.
    for _, shape in ipairs({ 42, true, "text" }) do
        GRIPEMS.Engine.sequences = {
            W24Bad = badData(shape),
            W24Good = goodData({ VARSTEP, CLICKSTEP }),
        }
        local okL, resL = pcall(GE.BuildExportList)
        assertTrue(okL, "BuildExportList raised on versions=" .. type(shape) .. ": " .. tostring(resL))
        local byName = {}
        for _, s in ipairs(resL.sequences or {}) do
            byName[s.name] = s
        end
        local tag = " for versions=" .. type(shape)
        assertTrue(byName.W24Bad ~= nil, "the malformed entry still produced a row" .. tag)
        -- ExportPreview.lua:40. For a string this is the ONLY thing that fails on a revert --
        -- "#" does not raise on a string, it fabricates 4 from the character
        -- length. For a number and a boolean the revert raises instead.
        assertEqual(0, byName.W24Bad.versionCount, ":40 -- a scalar versions counts 0 versions" .. tag)
        assertEqual(0, byName.W24Bad.stepCount, "a scalar versions counts 0 steps" .. tag)
        assertEqual(0, #byName.W24Bad.varDeps, "the malformed entry contributes no variable deps" .. tag)
        assertEqual(0, #byName.W24Bad.embeddedDeps, "the malformed entry contributes no embedded deps" .. tag)
        assertTrue(byName.W24Good ~= nil, "the neighbour survived the malformed entry" .. tag)
        assertEqual(1, byName.W24Good.versionCount, "the neighbour still reports its real version count" .. tag)
        assertEqual(2, byName.W24Good.stepCount, "the neighbour still reports its real step count" .. tag)
        assertTrue(listHas(byName.W24Good.varDeps, "MyVar"), ":58 -- the neighbour's variable scan ran" .. tag)
        assertTrue(listHas(byName.W24Good.embeddedDeps, "Ghost"), ":97 -- the neighbour's embedded scan ran" .. tag)
    end

    -- CONTROL-FALSIFY for this entry point: the well-formed sequence ALONE. A
    -- guard that quietly skipped every sequence cannot produce these numbers.
    GRIPEMS.Engine.sequences = { W24Good = goodData({ VARSTEP, CLICKSTEP }) }
    local okS, resS = pcall(GE.BuildExportList)
    assertTrue(okS, "the solo control raised: " .. tostring(resS))
    assertEqual(1, #resS.sequences, "the solo control lists exactly one sequence")
    assertEqual(1, resS.sequences[1].versionCount, "the solo control counts its one version")
    assertEqual(2, resS.sequences[1].stepCount, "the solo control counts both steps")
    assertTrue(listHas(resS.sequences[1].varDeps, "MyVar"), "the solo control resolves its variable")
    assertTrue(listHas(resS.sequences[1].embeddedDeps, "Ghost"), "the solo control resolves its embedded ref")

    -- ENTRY POINT 2 -- GE.ResolveVariableDeps (ExportPreview.lua:264). It never calls
    -- GetActiveVersion, so the full 42 / true / "text" matrix reaches the guard.
    for _, shape in ipairs({ 42, true, "text" }) do
        GRIPEMS.Engine.sequences = {
            W24Bad = badData(shape),
            W24Good = goodData({ VARSTEP }),
        }
        local ok, deps = pcall(GE.ResolveVariableDeps, { "W24Bad", "W24Good" })
        assertTrue(ok, "ResolveVariableDeps raised on versions=" .. type(shape) .. ": " .. tostring(deps))
        assertEqual(true, deps.MyVar, "the neighbour still resolved for versions=" .. type(shape))
    end

    GRIPEMS.Engine.sequences = { W24Good = goodData({ VARSTEP }) }
    local okRS, depsRS = pcall(GE.ResolveVariableDeps, { "W24Good" })
    assertTrue(okRS, "the solo ResolveVariableDeps control raised: " .. tostring(depsRS))
    assertEqual(true, depsRS.MyVar, "the solo control resolves its variable")

    -- ENTRY POINT 3 -- GE.DetectMissingEmbeddedDeps (ExportPreview.lua:392). Ghost is
    -- deliberately NOT selected, so a scan that runs warns once and a scan that
    -- does not warns zero times.
    for _, shape in ipairs({ 42, true, "text" }) do
        GRIPEMS.Engine.sequences = {
            W24Bad = badData(shape),
            W24Good = goodData({ CLICKSTEP }),
        }
        local ok, warnings = pcall(GE.DetectMissingEmbeddedDeps, { "W24Bad", "W24Good" })
        assertTrue(ok, "DetectMissingEmbeddedDeps raised on versions=" .. type(shape) .. ": " .. tostring(warnings))
        assertEqual(1, #warnings, "the neighbour still warned once for versions=" .. type(shape))
        assertTrue(
            tostring(warnings[1]):find("Ghost", 1, true) ~= nil,
            "the warning names the unselected reference for versions=" .. type(shape)
        )
    end

    GRIPEMS.Engine.sequences = { W24Good = goodData({ CLICKSTEP }) }
    local okDS, warnDS = pcall(GE.DetectMissingEmbeddedDeps, { "W24Good" })
    assertTrue(okDS, "the solo DetectMissingEmbeddedDeps control raised: " .. tostring(warnDS))
    assertEqual(1, #warnDS, "the solo control produces its one warning")

    GRIPEMS.Engine.sequences = saved
end)

test("W25: the GRIPExport readers survive a scalar versions, stored and on the wire", function()
    -- ENTRY POINT 1 -- GE.PrepareExportVersions (GRIPExport.lua:24), an ipairs. ipairs raises
    -- on a number, a boolean AND a string, so all three shapes reach it.
    local function prep(versionsShape)
        return pcall(GE.PrepareExportVersions, {
            name = "W25Seq",
            defaultVersion = 1,
            versions = versionsShape,
        })
    end

    for _, shape in ipairs({ 42, true, "text" }) do
        local ok, ev = prep(shape)
        assertTrue(ok, "PrepareExportVersions raised on versions=" .. type(shape) .. ": " .. tostring(ev))
        assertEqual("table", type(ev), "a scalar versions still returns the export-versions table")
        assertEqual(0, #ev, "a scalar versions produces no export versions")
    end

    -- CONTROL on a non-zero observable: a real versions table must survive the
    -- same walk with BOTH versions and their steps carried through.
    local okC, evC = prep({
        { steps = { A, B }, stepFunction = D.STEP_SEQUENTIAL },
        { steps = { C }, stepFunction = D.STEP_SEQUENTIAL },
    })
    assertTrue(okC, "the PrepareExportVersions control raised: " .. tostring(evC))
    assertEqual(2, #evC, "the control carried both versions")
    assertEqual(2, #evC[1].steps, "the control carried version 1's steps")
    assertEqual(1, #evC[2].steps, "the control carried version 2's steps")

    -- CONTROL-FALSIFY: one version in, one version out, so the 2 above is read
    -- off the table and not off a constant.
    local _, evF = prep({ { steps = { A }, stepFunction = D.STEP_SEQUENTIAL } })
    assertEqual(1, #evF, "control-falsify: a one-version table produces one export version")

    -- ENTRY POINT 2 -- GE.ResolveExportContext (GRIPExport.lua:167), a length operator. "#"
    -- raises on a number and a boolean and DOES NOT raise on a string, so the
    -- string row is pinned by value: nil guarded, 4 unguarded.
    for _, shape in ipairs({ 42, true, "text" }) do
        local ok, bc = pcall(GE.ResolveExportContext, { name = "W25Seq", versions = shape })
        assertTrue(ok, "ResolveExportContext raised on versions=" .. type(shape) .. ": " .. tostring(bc))
        assertEqual(nil, bc.versionCount, "a scalar versions leaves versionCount absent for " .. type(shape))
        -- Non-zero observable: the rest of the build context still filled, so
        -- the row above is not passing on an empty table from an early return.
        assertEqual("12.0.7", bc.wowPatch, "the build context still resolved for versions=" .. type(shape))
    end

    local okRC, bcC = pcall(GE.ResolveExportContext, {
        name = "W25Seq",
        versions = { { steps = { A } }, { steps = { B } } },
    })
    assertTrue(okRC, "the ResolveExportContext control raised: " .. tostring(bcC))
    assertEqual(2, bcC.versionCount, "the control counts both versions")

    -- CONTROL-FALSIFY: an EMPTY versions table is still a table, so it counts 0
    -- rather than staying absent -- which is what separates "the guard dropped
    -- it" (nil) from "the count really ran" (0).
    local _, bcF = pcall(GE.ResolveExportContext, { name = "W25Seq", versions = {} })
    assertEqual(0, bcF.versionCount, "control-falsify: an empty versions table counts 0, not nil")

    -- ENTRY POINT 4 -- GE.Export (GRIPExport.lua:524), added in pass 15i. The interleave
    -- pre-check reads seqData.versions[seqData.defaultVersion or 1] directly
    -- off the STORED sequence, one line below the store lookup and upstream of
    -- PrepareExportVersions, so it is the FIRST .versions read on the export
    -- path and neither of the two entry points above can stand in for it.
    -- W20 drives GE.Export on a well-formed sequence only; a scalar had never
    -- reached this function.
    -- GRIPEMS.Serialization is read through the table rather than through the
    -- "Ser" local: that local is declared further down, at entry point 3, and a
    -- Lua local is not in scope above its declaration.
    local savedExp = GRIPEMS.Engine.sequences
    for _, shape in ipairs({ 42, true, "text" }) do
        GRIPEMS.Engine.sequences = {
            W25Exp = {
                data = {
                    name = "W25Exp",
                    defaultVersion = 1,
                    privacyMode = D.PRIVACY_MODE_PUBLIC,
                    versions = shape,
                },
            },
        }
        local okE, successE, encodedE = pcall(GE.Export, "W25Exp")
        assertTrue(okE, "Export raised on versions=" .. type(shape) .. ": " .. tostring(successE))
        assertEqual(true, successE, "the scalar-versions export still COMPLETED for " .. type(shape))
        local okDE, payloadE = GRIPEMS.Serialization.Decode(encodedE)
        assertTrue(okDE, "the exported string did not decode back for " .. type(shape))
        assertEqual(0, #payloadE.sequence.versions, "a scalar versions exports no versions for " .. type(shape))
        assertEqual(nil, payloadE.sequence.versionCount, "and leaves versionCount absent for " .. type(shape))
    end

    -- CONTROL-FALSIFY for this entry point: the same call on a WELL-FORMED
    -- stored sequence carries its version through, so the zeroes above are read
    -- off the payload rather than off an export that always ships empty.
    GRIPEMS.Engine.sequences = {
        W25Exp = {
            data = {
                name = "W25Exp",
                defaultVersion = 1,
                privacyMode = D.PRIVACY_MODE_PUBLIC,
                versions = { { steps = { A, B }, stepFunction = D.STEP_SEQUENTIAL } },
            },
        },
    }
    local okEC, successEC, encodedEC = pcall(GE.Export, "W25Exp")
    GRIPEMS.Engine.sequences = savedExp
    assertTrue(okEC and successEC == true, "the GE.Export control raised: " .. tostring(successEC))
    local _, payloadEC = GRIPEMS.Serialization.Decode(encodedEC)
    assertEqual(1, #payloadEC.sequence.versions, "control-falsify: one stored version exports one version")
    assertEqual(1, payloadEC.sequence.versionCount, "control-falsify: and counts it")

    -- ENTRY POINT 3 -- GE.ImportNative (GRIPExport.lua:775), a scalar versions ON THE WIRE.
    -- W16's encode helper shape: build the payload through
    -- GRIPEMS.Serialization.Encode with D.EMS1_PREFIX, then pcall ImportNative.
    --
    -- THE POSITIVE CONTROL HAD TO BE MADE TO COMPLETE. A first probe of the
    -- flat-payload path returned "Imported sequence has no steps" for the
    -- well-formed control as well as for every malformed shape, so it never
    -- distinguished anything. Cause: the Engine stub's MigrateSequenceFormat
    -- was "function() end", so GRIPExport.lua:864 migrated nothing, seqData
    -- carried no versions, and GetActiveVersion at :923 returned nil. The stub
    -- is now a real flat-to-versions[1] wrap (see the note at its definition),
    -- which is what makes the rows below complete rather than merely not raise.
    local Ser = GRIPEMS.Serialization
    local normCalls = 0
    -- The swap below is sound and stays as it is: Import/GRIPExport.lua:16 binds
    -- "local SC = GRIPEMS.SpellCache", a TABLE reference, so replacing the field
    -- is observed by the module under test -- the passing assertEqual(2,
    -- normCalls) further down is the proof of that.
    --
    -- What needed fixing is the RESTORE PATH. The runner pcalls each case, so a
    -- failing assertion between the swap and the restore aborts this case and
    -- SKIPS the restore, leaving the counting stub installed for every case
    -- registered after W25. Measured today: W21 is the only case after it and
    -- reads no SpellCache method, so the leak currently costs nothing -- but
    -- that is a property of the REGISTRATION ORDER, not of this fixture, and it
    -- stops being true the moment a case is inserted between W25 and W21. The
    -- body is therefore pcall-wrapped and re-raised after the restore.
    local savedNorm = GRIPEMS.SpellCache.NormalizeVersionLocale
    GRIPEMS.SpellCache.NormalizeVersionLocale = function()
        normCalls = normCalls + 1
    end

    local okBody, errBody = pcall(function()
        local function importWith(versionsShape, flatSteps)
            normCalls = 0
            local _, str = Ser.Encode({
                format = "GRIP-EMS",
                version = D.GRIP_FORMAT_VERSION,
                name = "W25Seq",
                sequence = {
                    versions = versionsShape,
                    steps = flatSteps,
                    stepFunction = D.STEP_SEQUENTIAL,
                    defaultVersion = 1,
                },
            }, D.EMS1_PREFIX)
            return pcall(GE.ImportNative, str)
        end

        for _, shape in ipairs({ 42, true, "text" }) do
            local ok, success, nameOrErr, seqData = importWith(shape, { A })
            assertTrue(ok, "ImportNative raised on wire versions=" .. type(shape) .. ": " .. tostring(success))
            assertEqual(true, success, "the scalar-versions import still COMPLETED for " .. type(shape))
            assertEqual("W25Seq", nameOrErr, "the completed import returned its name for " .. type(shape))
            assertEqual(1, #seqData.versions, "the flat fallback built exactly one version for " .. type(shape))
            assertEqual(1, #seqData.versions[1].steps, "the flat fallback carried its one step for " .. type(shape))
            assertEqual(0, normCalls, "a scalar versions is never walked, so NormalizeVersionLocale never fired")
        end

        -- CONTROL on a non-zero observable: a real versions table completes AND
        -- is actually WALKED -- one NormalizeVersionLocale call per version,
        -- which is the guarded ipairs at GRIPExport.lua:775 observed directly rather than
        -- inferred.
        local okI, successI, nameI, seqDataI = importWith({
            { steps = { A, B }, stepFunction = D.STEP_SEQUENTIAL },
            { steps = { C }, stepFunction = D.STEP_SEQUENTIAL },
        }, nil)
        assertTrue(okI, "the ImportNative control raised: " .. tostring(successI))
        assertEqual(true, successI, "the well-formed control import succeeded")
        assertEqual("W25Seq", nameI, "the control returned the imported name")
        assertEqual(2, #seqDataI.versions, "the control carried both versions")
        assertEqual(2, normCalls, "GRIPExport.lua:775 -- the guarded walk visited every version")

        -- CONTROL-FALSIFY: a scalar versions with NO flat steps must NOT
        -- complete, so the successes above come from the flat fallback and not
        -- from a path that succeeds regardless of payload.
        local okF, successF, errF = importWith(42, nil)
        assertTrue(okF, "the ImportNative falsify control raised: " .. tostring(successF))
        assertEqual(false, successF, "control-falsify: no versions and no steps cannot import")
        assertEqual("Payload has no sequence steps or versions", errF, "control-falsify: right reason")
    end)

    GRIPEMS.SpellCache.NormalizeVersionLocale = savedNorm
    if not okBody then
        -- level 0: no position prefix is added by THIS error(), so the failing
        -- assertion's own file:line survives into the runner output instead of
        -- being re-attributed to this wrapper line.
        error(errBody, 0)
    end
end)

-- ---------------------------------------------------------------------------
-- Pass 15i: BEHAVIOURAL proof for the half of the .versions family this
-- harness can already reach. Every pass from 15c onward has said W26 "proves
-- the guard is WRITTEN, not that it WORKS", and the head of that case said no
-- fixture exists because the harness does not load the files. That was true of
-- the 15c/15d file set and it stopped being true for the 15e one: the MODULES
-- table above loads Data/Defaults.lua, Data/RepairAnalyzer.lua,
-- Import/GRIPExport.lua, Import/ExportPreview.lua and Import/ImportPreview.lua,
-- and RA is already DRIVEN from this file -- RA:AnalyzeAll at the priming call
-- above, RA:CheckCrossSeq in W4, RA:CheckStructure in W5, RA:CheckActions in
-- W8 -- with well-formed data. What was missing was fixtures that pass a
-- SCALAR. No new harness is needed for any of the five cases below.
--
-- Twenty-two of the forty-five guards the arc shipped live in modules this
-- file loads: RepairAnalyzer 16, ImportPreview 3, GRIPExport 2, Defaults 1.
-- The per-guard tally of what these cases do and do not reach is in the
-- rewritten note at the head of W26; do not keep a second copy of it here.
-- ---------------------------------------------------------------------------

--- Return the first issue in `issues` whose title matches, or nil.
--- Shared by W27, W28 and W29: all three read RepairAnalyzer's issue lists and
--- the alternative is three copies of the same six lines.
local function findIssue(issues, title)
    for _, issue in ipairs(issues or {}) do
        if issue.title == title then
            return issue
        end
    end
    return nil
end

test("W27: RA:Analyze survives a scalar .versions AND still reports it", function()
    -- THE HEADLINE OF THE 15e ARC, and its first behavioural proof. The module
    -- whose JOB is detecting corrupt sequences used to CRASH on the corruption.
    -- RA:Analyze (RepairAnalyzer.lua:1620) runs its checks in a fixed order:
    --   :1626  CheckSpells            walks seqData.versions   <- raised here
    --   :1627  CheckLegacySlotNames   walks seqData.versions   <- or here
    --   :1628  CheckStructure         REPORTS "Missing versions"
    -- so the one check that names the problem sat two checks downstream of the
    -- two that died on it. CheckStructure's guard at :472 was correct the whole
    -- time and unreachable for exactly the input it was written for.
    --
    -- DRIVEN THROUGH RA:Analyze, NOT through RA:CheckStructure, because the
    -- ORDERING is the defect. Calling the reporting check directly -- which is
    -- what W5 above does -- steps over the two checks that raised and would
    -- have stayed green through the entire defect.
    --
    -- The id prefix, title, detail, severity and category asserted below are
    -- read off RepairAnalyzer.lua:472-480 (the I() call) and :51-53 (NextID's
    -- "%s_%03d" format), not off the brief that commissioned this case.
    local MISSING = "Missing versions"

    -- nil cannot be an ipairs element, so the shapes are carried as ROWS and
    -- read off .value -- an absent key yields nil, which IS the first shape.
    local SHAPES = {
        { label = "nil" },
        { label = "number", value = 5 },
        { label = "boolean", value = true },
        { label = "string", value = "abc" },
        -- An empty TABLE is not a shape confusion; it is the other half of the
        -- same guard ("or #seqData.versions == 0") and it must report too.
        { label = "empty table", value = {} },
    }

    for _, row in ipairs(SHAPES) do
        local seqData = { name = "W27Seq", defaultVersion = 1, versions = row.value }
        local ok, issues = pcall(RA.Analyze, RA, seqData, "W27Seq")
        -- The error text is quoted so a regression names the RAISE at its own
        -- file:line, instead of surfacing one assertion later as a nil index.
        assertTrue(ok, "RA:Analyze raised on versions=" .. row.label .. ": " .. tostring(issues))
        local tag = " for versions=" .. row.label
        local issue = findIssue(issues, MISSING)
        -- THIS IS THE WHOLE POINT. Not "it did not raise" -- it REPORTED.
        assertTrue(issue ~= nil, "no '" .. MISSING .. "' issue reported" .. tag)
        assertEqual(RA.CAT_STRUCTURE, issue.category, "category" .. tag)
        assertEqual(RA.SEVERITY_CRITICAL, issue.severity, "severity" .. tag)
        assertEqual("No versions table or empty", issue.detail, "detail" .. tag)
        assertEqual(true, issue.fixable, "fixable flag" .. tag)
        assertEqual("STRUCT_", tostring(issue.id):sub(1, 7), "id prefix" .. tag)
    end

    -- CONTROL: a REAL one-version table must NOT report it, so no row above can
    -- pass by way of an analyzer that reports the issue unconditionally.
    local goodData = {
        name = "W27Seq",
        defaultVersion = 1,
        versions = { { stepFunction = D.STEP_SEQUENTIAL, steps = { A }, keyPress = "", keyRelease = "" } },
    }
    local okG, issuesG = pcall(RA.Analyze, RA, goodData, "W27Seq")
    assertTrue(okG, "RA:Analyze raised on the well-formed control: " .. tostring(issuesG))
    assertEqual(nil, findIssue(issuesG, MISSING), "the well-formed control reports no '" .. MISSING .. "'")

    -- CONTROL-FALSIFY on the fix closure. The issue reported above is the real
    -- fixable one from RepairAnalyzer.lua:481, not a look-alike: applying it
    -- replaces the scalar with a stamped default version, and the RE-analysis
    -- of the repaired sequence stops reporting.
    local fixData = { name = "W27Seq", defaultVersion = 1, versions = 5 }
    local okX, issuesX = pcall(RA.Analyze, RA, fixData, "W27Seq")
    assertTrue(okX, "the fix-closure probe raised: " .. tostring(issuesX))
    local fixIssue = findIssue(issuesX, MISSING)
    assertTrue(fixIssue ~= nil and fixIssue.fixFn ~= nil, "the reported issue carries its fix closure")
    local okF, errF = pcall(fixIssue.fixFn, fixData)
    assertTrue(okF, "the fix closure raised: " .. tostring(errF))
    assertEqual("table", type(fixData.versions), "the fix replaced the scalar with a table")
    assertEqual(1, #fixData.versions, "the fix stamped exactly one default version")
    local okR, issuesR = pcall(RA.Analyze, RA, fixData, "W27Seq")
    assertTrue(okR, "the re-analysis raised: " .. tostring(issuesR))
    assertEqual(nil, findIssue(issuesR, MISSING), "the repaired sequence no longer reports it")

    -- ---- PASS 15l EDIT 1: IS THE .steps FAMILY LIVE AT ALL? --------------
    -- W32 below measured 57 genuinely-bare .steps sites and said, in its own
    -- header, that reachability of a corrupt shape at each of them is a
    -- SEPARATE question nobody had answered. This probe answers it for exactly
    -- one site, BEFORE a single .steps site is touched, because 15e already
    -- shipped a guard for an unreachable line once (SequenceEditor:138) and
    -- 15j had to measure instead of assert to undo it.
    --
    -- The shape is deliberately NOT a corrupt versions -- W27's five rows above
    -- already own that. It is a WELL-FORMED one-element versions array whose
    -- single version carries a SCALAR steps. It therefore reaches
    -- RepairAnalyzer.lua:187 -- the .versions type() guard 15e shipped -- with
    -- a real table, passes straight through it, and lands on :191
    --     for si, step in ipairs(ver.steps or {}) do
    -- where "or {}" substitutes for nil and false and NOT for 5.
    --
    -- IF THIS PROBE PASSES ON AN UNFIXED RepairAnalyzer the .steps family is
    -- not live from this entry point, the 57 need re-triage, and no fix in
    -- this pass is justified. It does not pass; the raise is quoted in the
    -- 15l report and the guard that removes it is at :191.
    local scalarStepsData = {
        name = "W27Seq",
        defaultVersion = 1,
        versions = { { stepFunction = D.STEP_SEQUENTIAL, steps = 5, keyPress = "", keyRelease = "" } },
    }
    local okS, issuesS = pcall(RA.Analyze, RA, scalarStepsData, "W27Seq")
    assertTrue(okS, "RA:Analyze raised on a version whose steps is a NUMBER: " .. tostring(issuesS))

    -- ---- PASS 15l EDIT 3: ONE FIXTURE PER GUARDED .steps SITE -------------
    -- The probe above proves the FAMILY is live by dying at the first site.
    -- These rows exist so every OTHER site 15l guarded can be control-falsified
    -- on its own: with all thirteen guards in place nothing raises, and with any
    -- ONE of them reverted the raise names that line and this case goes red.
    --
    -- Ten of the thirteen are reachable from RA:Analyze and live here. The
    -- eleventh is CheckCrossSeq's variable walk, which AnalyzeAll alone reaches,
    -- and it is in W28. The measured revert-by-revert table is in the 15l report.
    --
    -- WHY THE STRING ROW IS NOT REDUNDANT WITH THE NUMBER ROW. `#` works on a
    -- string, so a string steps slides through every LENGTH read and only dies
    -- at the ipairs walks, while a number dies at both. Two shapes, two halves
    -- of the family; a single shape would have left the length guards untested
    -- for one and the walk guards untested for the other.
    local STEPS_SHAPES = {
        { label = "number", value = 5 },
        { label = "boolean", value = true },
        { label = "string", value = "/cast Alpha" },
    }
    for _, row in ipairs(STEPS_SHAPES) do
        local d = {
            name = "W27Steps",
            defaultVersion = 1,
            versions = { { stepFunction = D.STEP_SEQUENTIAL, steps = row.value, keyPress = "", keyRelease = "" } },
        }
        local okA, issuesA = pcall(RA.Analyze, RA, d, "W27Steps")
        assertTrue(okA, "RA:Analyze raised on steps=" .. row.label .. ": " .. tostring(issuesA))
        local tag = " for steps=" .. row.label
        -- NOT "it did not raise" -- it REPORTED, the same standard W27's
        -- .versions rows are held to. CheckStructure's own "Empty steps array"
        -- sat behind two checks that died before it could say anything.
        assertTrue(findIssue(issuesA, "Empty steps array") ~= nil, "no 'Empty steps array' issue reported" .. tag)
    end

    -- CONTROL for the rows above: a REAL steps array must NOT be reported empty,
    -- so no row can pass by way of an analyzer that reports it unconditionally.
    local okE, issuesE = pcall(RA.Analyze, RA, {
        name = "W27Steps",
        defaultVersion = 1,
        versions = { { stepFunction = D.STEP_SEQUENTIAL, steps = { A }, keyPress = "", keyRelease = "" } },
    }, "W27Steps")
    assertTrue(okE, "RA:Analyze raised on the well-formed steps control: " .. tostring(issuesE))
    assertEqual(nil, findIssue(issuesE, "Empty steps array"), "the well-formed steps control is not reported empty")

    -- taggedSteps is the SIBLING field, and it is half of two of the guarded
    -- lines (CheckStructure and CheckLocale both compare #taggedSteps against
    -- #steps). Both comparisons sit behind a truthiness test on taggedSteps, so
    -- a scalar-steps row cannot reach either one and they need their own rows.
    -- Row 1 puts the scalar on taggedSteps, row 2 on steps: reverting either
    -- half of either line reddens this case.
    local TAGGED_SHAPES = {
        { label = "scalar taggedSteps beside a real steps", tagged = 7, steps = { A } },
        { label = "real taggedSteps beside a scalar steps", tagged = { A }, steps = 5 },
    }
    for _, row in ipairs(TAGGED_SHAPES) do
        local d = {
            name = "W27Tagged",
            defaultVersion = 1,
            versions = {
                {
                    stepFunction = D.STEP_SEQUENTIAL,
                    steps = row.steps,
                    taggedSteps = row.tagged,
                    keyPress = "",
                    keyRelease = "",
                },
            },
        }
        local okT, issuesT = pcall(RA.Analyze, RA, d, "W27Tagged")
        assertTrue(okT, "RA:Analyze raised on " .. row.label .. ": " .. tostring(issuesT))
    end

    -- CONTROL for the two rows above, and the one that matters most: the guards
    -- must not have DISABLED the mismatch detection they wrap. A genuine
    -- two-tagged-versus-one-step version still reports both of its issues.
    local okM, issuesM = pcall(RA.Analyze, RA, {
        name = "W27Tagged",
        defaultVersion = 1,
        versions = {
            {
                stepFunction = D.STEP_SEQUENTIAL,
                steps = { A },
                taggedSteps = { A, A },
                keyPress = "",
                keyRelease = "",
            },
        },
    }, "W27Tagged")
    assertTrue(okM, "RA:Analyze raised on the taggedSteps mismatch control: " .. tostring(issuesM))
    assertTrue(findIssue(issuesM, "Orphaned taggedSteps") ~= nil, "CheckStructure still reports a REAL tag mismatch")
    assertTrue(findIssue(issuesM, "taggedSteps count mismatch") ~= nil, "CheckLocale still reports a REAL tag mismatch")
end)

test("W35: the keyPress->step repair closure survives every corrupt .steps shape", function()
    -- THE FIXTURE THE 15r FIX NEVER GOT. RepairAnalyzer.lua:1242 offers a
    -- readiness repair -- "Content in keyPress not steps" -- that moves a /cast
    -- or /use sitting in the keyPress block into step 1. 15r fixed the closure
    -- and shipped it with no test. This is that test.
    --
    -- WHY THE CLOSURE COULD DIE WHERE A READ WOULD NOT. Everything upstream of
    -- the closure works on a SANITISED LOCAL:
    --     local steps = type(ver.steps) == "table" and ver.steps or {}
    -- so the analysis never touches the raw field. The closure does. It WRITES:
    --     v.steps[1] = v[fld]
    -- and a write is strictly less tolerant than a read. Indexing a string for a
    -- READ is legal -- it resolves through the string metatable and yields nil --
    -- which is exactly why the "abc" shape sails through every scan-time site in
    -- this module and still died here. ASSIGNING into a string is not legal. That
    -- asymmetry is the reason a fix-closure needs its own fixture and cannot
    -- inherit confidence from the scan-time cases around it.
    --
    -- MEASURED, driven through RA:Analyze and then the returned issue's fixFn, on
    --   { name = "P", defaultVersion = 1,
    --     versions = { { keyPress = "/cast Fireball", steps = SHAPE } } }
    --
    -- OBSERVED RED, this pass, by reverting 15r's three-line normalisation and
    -- running this case once per shape -- the runner aborts a case at its first
    -- failed assertion, so the rows were reordered between runs to observe each
    -- on its own. Quoted from those runs:
    --     steps absent   the fix closure raised for steps=absent:
    --                    Data/RepairAnalyzer.lua:1267: attempt to index field
    --                    'steps' (a nil value)
    --     steps = 5      ... for steps=number: ... (a number value)
    --     steps = true   ... for steps=boolean: ... (a boolean value)
    --     steps = "abc"  ... for steps=string: ... (a string value)
    --     steps = {}     PASSES. Putting the empty-table row first moved the
    --                    failure to the "absent" row behind it, which is how
    --                    that row was confirmed rather than assumed.
    -- RESULT 39 passed, 1 failed on every one of those runs; with the
    -- normalisation restored, RESULT 40 passed, 0 failed.
    --
    -- The 15r report measured the same four raises at fa88d31 and named the line
    -- :1243. It is :1267 here: same statement, moved down by the comment 15r
    -- wrote above it. Recorded as observed rather than back-dated.
    --
    -- FOUR OF FIVE SHAPES RAISED AND ONE DID NOT, which is what makes the empty
    -- table worth keeping as a row rather than dropping as the "already worked"
    -- case: it is the shape the original author wrote the closure for, and it is
    -- the row that proves the normalisation did not break the path that was fine.
    --
    -- WHAT WAS NEVER BROKEN, and asserted here anyway because it is half the
    -- claim: RA:Analyze REPORTED the issue correctly for every one of the five
    -- shapes, before and after. Only the repair died. A case that only asserted
    -- "the fixFn did not raise" would pass just as well against an analyzer that
    -- had quietly stopped reporting the issue at all, so the issue-exists and
    -- carries-a-fixFn assertions come first for every shape.
    --
    -- AND THE RE-ANALYSIS AT THE FOOT OF EACH ROW is what makes this a REPAIR
    -- test rather than a no-raise test: the repaired data is fed back through
    -- RA:Analyze and the issue has to be GONE. A closure that swallowed its own
    -- error and changed nothing would satisfy every other assertion here.
    local RDY_TITLE = "Content in keyPress not steps"

    -- `present` rather than a nil `value`, because a Lua array literal cannot
    -- carry nil as an element -- the absent-field shape has to be modelled by
    -- NOT WRITING the field, not by writing nil into the row table.
    local RDY_SHAPES = {
        { label = "absent", present = false },
        { label = "number", present = true, value = 5 },
        { label = "boolean", present = true, value = true },
        { label = "string", present = true, value = "abc" },
        { label = "empty table", present = true, value = {} },
    }

    for _, row in ipairs(RDY_SHAPES) do
        local tag = " for steps=" .. row.label
        local ver = { keyPress = "/cast Fireball" }
        if row.present then
            ver.steps = row.value
        end
        local seqData = { name = "P", defaultVersion = 1, versions = { ver } }

        local okA, issuesA = pcall(RA.Analyze, RA, seqData, "P")
        assertTrue(okA, "RA:Analyze raised" .. tag .. ": " .. tostring(issuesA))

        -- The analyzer half of the claim, asserted for EVERY shape.
        local issue = findIssue(issuesA, RDY_TITLE)
        assertTrue(issue ~= nil, "no '" .. RDY_TITLE .. "' issue reported" .. tag)
        assertTrue(issue.fixFn ~= nil, "the reported issue carries no fix closure" .. tag)

        -- The repair half. This is the assertion 15r's fix exists to satisfy and
        -- the one that goes red if the normalisation is reverted.
        local okF, errF = pcall(issue.fixFn, seqData)
        assertTrue(okF, "the fix closure raised" .. tag .. ": " .. tostring(errF))

        local fixedVer = seqData.versions[1]
        assertEqual("table", type(fixedVer.steps), "steps is not a table after the repair" .. tag)
        assertEqual("/cast Fireball", fixedVer.steps[1], "the keyPress text did not land in step 1" .. tag)
        assertEqual("", fixedVer.keyPress, "keyPress was not cleared" .. tag)

        local okR, issuesR = pcall(RA.Analyze, RA, seqData, "P")
        assertTrue(okR, "the re-analysis raised" .. tag .. ": " .. tostring(issuesR))
        assertEqual(nil, findIssue(issuesR, RDY_TITLE), "the repaired sequence still reports it" .. tag)
    end

    -- CONTROL that can fail: a well-formed version with a REAL steps array and no
    -- cast in keyPress must report NO such issue. Without it every row above
    -- would pass against an analyzer that reported the issue unconditionally, and
    -- the "the repaired sequence still reports it" assertions would be the only
    -- thing standing between this case and a permanently-green tautology.
    local goodData = {
        name = "P",
        defaultVersion = 1,
        versions = { { stepFunction = D.STEP_SEQUENTIAL, steps = { A }, keyPress = "", keyRelease = "" } },
    }
    local okC, issuesC = pcall(RA.Analyze, RA, goodData, "P")
    assertTrue(okC, "RA:Analyze raised on the well-formed control: " .. tostring(issuesC))
    assertEqual(nil, findIssue(issuesC, RDY_TITLE), "the well-formed control reports a '" .. RDY_TITLE .. "'")
end)

test("W28: RA:AnalyzeAll survives one corrupt entry and still analyzes its neighbour", function()
    -- The reachability argument in the 15e commit body, never driven until now.
    -- RA:AnalyzeAll (RepairAnalyzer.lua:1647) loops EVERY registered sequence
    -- and calls RA:Analyze on each with no pcall between them, so before the
    -- guards a single corrupt entry took the whole health scan down and every
    -- well-formed sequence in the store lost its report with it.
    local saved = GRIPEMS.Engine.sequences

    local function goodEntry(name)
        return {
            data = {
                name = name,
                defaultVersion = 1,
                -- keyPress is absent ON PURPOSE: it is the non-zero observable.
                -- RepairAnalyzer.lua:576 reports "Nil keyPress" for it, so the
                -- neighbour's list cannot be present-but-empty and still pass.
                versions = { { stepFunction = D.STEP_SEQUENTIAL, steps = { A } } },
            },
        }
    end

    for _, shape in ipairs({ 42, true, "text" }) do
        GRIPEMS.Engine.sequences = {
            W28Bad = { data = { name = "W28Bad", defaultVersion = 1, versions = shape } },
            W28Good = goodEntry("W28Good"),
        }
        local ok, all = pcall(RA.AnalyzeAll, RA)
        -- Restore BEFORE asserting. The runner pcalls each case, so a failing
        -- assertion aborts this one, and a leaked sequences table would then be
        -- observed by every case registered after it.
        GRIPEMS.Engine.sequences = saved
        assertTrue(ok, "AnalyzeAll raised on versions=" .. type(shape) .. ": " .. tostring(all))
        local tag = " for versions=" .. type(shape)
        assertTrue(all.W28Bad ~= nil, "the corrupt entry still produced an issue list" .. tag)
        assertTrue(findIssue(all.W28Bad, "Missing versions") ~= nil, "the corrupt entry is REPORTED" .. tag)
        assertTrue(all.W28Good ~= nil, "the neighbour still got its issues" .. tag)
        assertTrue(findIssue(all.W28Good, "Nil keyPress") ~= nil, "the neighbour's own scan really ran" .. tag)
        assertEqual(nil, findIssue(all.W28Good, "Missing versions"), "the neighbour is not mis-reported" .. tag)
    end

    -- ---- PASS 15l: the ONE guarded .steps site W27 cannot reach ------------
    -- CheckCrossSeq's shared-variable walk reads entry.data.versions[n].steps
    -- for every registered sequence, and CheckCrossSeq runs from AnalyzeAll
    -- ONLY -- RA:Analyze never calls it. So the versions here are WELL-FORMED
    -- one-element arrays carrying a SCALAR steps: the entry has to survive the
    -- per-sequence Analyze first (it does, as of this pass) and then be walked
    -- a second time by the cross-sequence pass, which is where the last
    -- unguarded walk was. Reverting that one guard reddens this case and
    -- nothing in W27.
    for _, shape in ipairs({ 5, true, "text" }) do
        GRIPEMS.Engine.sequences = {
            W28Steps = {
                data = {
                    name = "W28Steps",
                    defaultVersion = 1,
                    versions = { { stepFunction = D.STEP_SEQUENTIAL, steps = shape } },
                },
            },
            W28Good = goodEntry("W28Good"),
        }
        local okX, allX = pcall(RA.AnalyzeAll, RA)
        GRIPEMS.Engine.sequences = saved
        assertTrue(okX, "AnalyzeAll raised on a version whose steps is " .. type(shape) .. ": " .. tostring(allX))
        local tag = " for steps=" .. type(shape)
        assertTrue(allX.W28Steps ~= nil, "the scalar-steps entry still produced an issue list" .. tag)
        assertTrue(findIssue(allX.W28Steps, "Empty steps array") ~= nil, "the scalar steps is REPORTED" .. tag)
        assertTrue(findIssue(allX.W28Good, "Nil keyPress") ~= nil, "the neighbour's own scan really ran" .. tag)
    end

    -- CONTROL-FALSIFY: the well-formed sequence ALONE. A scan that quietly
    -- skipped every entry could not produce the neighbour rows above either.
    GRIPEMS.Engine.sequences = { W28Good = goodEntry("W28Good") }
    local okS, allS = pcall(RA.AnalyzeAll, RA)
    GRIPEMS.Engine.sequences = saved
    assertTrue(okS, "the solo control raised: " .. tostring(allS))
    assertTrue(allS.W28Good ~= nil, "the solo control analyzed its one sequence")
    assertTrue(findIssue(allS.W28Good, "Nil keyPress") ~= nil, "the solo control reports the same issue")
    assertEqual(nil, allS.W28Bad, "the solo control has no corrupt entry to report")
end)

test("W29: RA:CheckCrossSeq walks a store holding a scalar .versions entry", function()
    -- THREE of RepairAnalyzer's sixteen guards are versions walks inside
    -- CheckCrossSeq: :1514 (the outer EMBED chain scan), :1525 (the shared
    -- variable scan) and :1494 (the RECURSIVE walk of an embed TARGET's own
    -- versions, inside the scanEmbeds closure). Line 815 above already calls
    -- this function, but with an EMPTY allIssues table and whatever store the
    -- earlier cases left behind, so none of the three had met a scalar.
    --
    -- :1494 IS THE ONE THAT NEEDS THE FIXTURE BUILT DELIBERATELY. It is only
    -- reached when a node EMBEDS a sequence that EXISTS and has not been
    -- visited (RepairAnalyzer.lua:1490-1493), and it then walks THAT
    -- sequence's versions -- so the scalar has to sit on the embed TARGET, not
    -- on a bystander entry. A first draft of this case embedded only a missing
    -- target and reverting :1494 stayed green: the walk was never entered.
    -- Each neighbour therefore carries TWO embeds, one missing and one
    -- resolving to the scalar entry.
    local saved = GRIPEMS.Engine.sequences
    local EMBED_TARGET = "W29Missing"
    local VARSTEP = "/cast ~W29Var~"

    local function goodEntry(name)
        return {
            data = {
                name = name,
                defaultVersion = 1,
                versions = {
                    {
                        stepFunction = D.STEP_SEQUENTIAL,
                        -- RepairAnalyzer.lua:1553 reads ver.steps. TWO sequences must reference
                        -- the same MISSING variable before "Shared variable
                        -- deleted" is emitted at :1588 -- hence two neighbours.
                        steps = { VARSTEP },
                        -- RepairAnalyzer.lua:1543 reads ver.actions and hands them to scanEmbeds.
                        -- The first embed is missing, so :1509 reports it; the
                        -- second RESOLVES to the scalar-versions entry and
                        -- drives the recursive walk at :1523.
                        actions = {
                            { type = D.ACTION_TYPE_EMBED, sequence = EMBED_TARGET },
                            { type = D.ACTION_TYPE_EMBED, sequence = "W29Bad" },
                        },
                    },
                },
            },
        }
    end

    for _, shape in ipairs({ 42, true, "text" }) do
        GRIPEMS.Engine.sequences = {
            W29Bad = { data = { name = "W29Bad", defaultVersion = 1, versions = shape } },
            W29GoodA = goodEntry("W29GoodA"),
            W29GoodB = goodEntry("W29GoodB"),
        }
        local allIssues = {}
        local ok, err = pcall(RA.CheckCrossSeq, RA, allIssues)
        GRIPEMS.Engine.sequences = saved
        assertTrue(ok, "CheckCrossSeq raised on versions=" .. type(shape) .. ": " .. tostring(err))
        local tag = " for versions=" .. type(shape)
        assertTrue(
            findIssue(allIssues.W29GoodA, "Broken EMBED chain") ~= nil,
            "RepairAnalyzer.lua:1514 -- the neighbour's embed walk still ran" .. tag
        )
        assertTrue(
            findIssue(allIssues.W29GoodA, "Shared variable deleted") ~= nil,
            ":1588 -- the neighbour's variable walk still ran" .. tag
        )
        assertTrue(
            findIssue(allIssues.W29GoodB, "Shared variable deleted") ~= nil,
            ":1588 -- and it saw BOTH referrers, not just one" .. tag
        )
        assertEqual(nil, allIssues.W29Bad, "the scalar entry contributes no cross-seq issues" .. tag)
    end

    -- CONTROL-FALSIFY: with BOTH embed targets present in the store, the broken
    -- chain issue must disappear -- so the rows above read the real scan and
    -- not an issue this fixture produces whatever the store contains. W29Bad
    -- stays in with its scalar versions, because removing it would merely turn
    -- the second embed into a second broken chain and prove nothing.
    GRIPEMS.Engine.sequences = {
        W29Bad = { data = { name = "W29Bad", defaultVersion = 1, versions = 42 } },
        W29GoodA = goodEntry("W29GoodA"),
        W29GoodB = goodEntry("W29GoodB"),
        [EMBED_TARGET] = { data = { name = EMBED_TARGET, defaultVersion = 1, versions = {} } },
    }
    local allF = {}
    local okF, errF = pcall(RA.CheckCrossSeq, RA, allF)
    GRIPEMS.Engine.sequences = saved
    assertTrue(okF, "the falsify control raised: " .. tostring(errF))
    assertEqual(nil, findIssue(allF.W29GoodA, "Broken EMBED chain"), "control-falsify: a present target is not broken")
    assertTrue(
        findIssue(allF.W29GoodA, "Shared variable deleted") ~= nil,
        "control-falsify: the variable scan is unaffected by the embed target"
    )
end)

test("W30: D.NewSequenceFromTemplate falls back to D.NewVersion on a scalar template versions", function()
    -- Data/Defaults.lua:3918-3919, the guard this case pins. Both levels are
    -- type()-tested as of 15k: the container at :3918, the element at :3919.
    --
    -- WHAT WAS ALREADY CORRECT, recorded so this row is not read as three new
    -- fixes. 'abc' never raised: ("abc")[1] resolves through the string
    -- metatable to nil, so the "or D.NewVersion" fallback already ran and the
    -- function silently returned the default version. 5 and true DID raise,
    -- "attempt to index field 'versions' (a number value)" / "(a boolean
    -- value)". So this case pins behaviour that was already right for one of
    -- the three inputs and is newly right for the other two.
    local FALLBACK_ROWS = {
        { label = "number", value = 5 },
        { label = "boolean", value = true },
        { label = "string", value = "abc" },
    }

    for _, row in ipairs(FALLBACK_ROWS) do
        local ok, seqData = pcall(D.NewSequenceFromTemplate, "W30Seq", { versions = row.value })
        assertTrue(ok, "NewSequenceFromTemplate raised on template versions=" .. row.label .. ": " .. tostring(seqData))
        local tag = " for template versions=" .. row.label
        assertEqual("table", type(seqData.versions), "the new sequence still got a versions table" .. tag)
        assertEqual(1, #seqData.versions, "exactly one version" .. tag)
        local v = seqData.versions[1]
        -- The fallback is D.NewVersion, field by field, exactly as the
        -- constructor reads it at Data/Defaults.lua:3927-3935.
        assertEqual(D.NewVersion.stepFunction or "Sequential", v.stepFunction, "fell back for stepFunction" .. tag)
        assertEqual(D.NewVersion.keyPress or "", v.keyPress, "fell back for keyPress" .. tag)
        assertEqual(D.NewVersion.keyRelease or "", v.keyRelease, "fell back for keyRelease" .. tag)
        assertEqual(D.NewVersion.resetTimer or 0, v.resetTimer, "fell back for resetTimer" .. tag)
        assertEqual(D.NewVersion.resetOnCombat or false, v.resetOnCombat, "fell back for resetOnCombat" .. tag)
        -- The privacy default read at Data/Defaults.lua:3960 resolves through an
        -- ABSENT GRIP_EMS_DB here, which is why that name is on
        -- ALLOWED_UNKNOWN. Asserted rather than assumed: the allowlist claim is
        -- "the product does the right thing when the global is nil", and this
        -- is the observation behind it.
        assertEqual(D.PRIVACY_MODE_DEFAULT, seqData.privacyMode, "the privacy default fell back" .. tag)
    end

    -- CONTROL: a REAL template's version 1 is carried through INSTEAD of the
    -- fallback, so the rows above are not passing because this constructor
    -- always returns D.NewVersion's values.
    --
    -- NOTE ON THE steps FIELD, and it is a finding rather than a fixture
    -- detail. Data/Defaults.lua:3976 copied the template's steps with a BARE
    -- "for i, step in ipairs(ver1.steps)" -- no type() test and no "or {}".
    -- A first draft of this control omitted steps and raised "bad argument #1
    -- to 'ipairs' (table expected, got nil)", one line past the guard this case
    -- exists to pin. It is not in the .versions family and this pass changes no
    -- shipped file, so it is recorded here and left alone: a template whose
    -- versions[1] carries no steps array still takes this constructor down. The
    -- scalar rows above never meet it because their ver1 is D.NewVersion, which
    -- does carry one.
    --
    -- PASS 15j: FIXED, and pinned by the STEPS SHAPES block at the end of this
    -- case. The paragraph above stands as the record of how it was found and
    -- why 15i correctly left it; it is no longer the current state of the file.
    local okC, seqC = pcall(D.NewSequenceFromTemplate, "W30Seq", {
        versions = {
            {
                stepFunction = "W30StepFn",
                steps = {},
                keyPress = "/startattack",
                keyRelease = "/stopcasting",
                resetTimer = 42,
                resetOnCombat = true,
            },
        },
    })
    assertTrue(okC, "NewSequenceFromTemplate raised on the well-formed control: " .. tostring(seqC))
    assertEqual("W30StepFn", seqC.versions[1].stepFunction, "the control carried the template stepFunction")
    assertEqual("/startattack", seqC.versions[1].keyPress, "the control carried the template keyPress")
    assertEqual("/stopcasting", seqC.versions[1].keyRelease, "the control carried the template keyRelease")
    assertEqual(42, seqC.versions[1].resetTimer, "the control carried the template resetTimer")
    assertEqual(true, seqC.versions[1].resetOnCombat, "the control carried the template resetOnCombat")

    -- STEPS SHAPES (pass 15j). The finding the control above recorded, now the
    -- shipped fix and its fixture. Data/Defaults.lua:3976 walked the template's steps
    -- with a bare "ipairs(ver1.steps)"; it is now type()-tested.
    --
    -- WHY type() AND NOT "or {}", because this arc spent four passes proving
    -- "or {}" is NOT a type guard and the weaker idiom must not be copied just
    -- because it is shorter. Decided from the source: ver1 is
    --   type(tmplVer1) == "table" and tmplVer1 or D.NewVersion
    -- so on the corrupt-template path ver1 IS the caller's own table, with
    -- nothing between the argument and the ipairs that validates it. A template
    -- carrying steps = 5 is exactly as reachable as one carrying no steps at
    -- all -- and "or {}" substitutes for nil and false only, so a SCALAR is
    -- truthy, passes straight through, and ipairs raises on number, boolean AND
    -- string. The scalar rows below are the ones "or {}" would still fail.
    --
    -- STATUS: LATENT, not live, and the distinction matters -- overstating it is
    -- the mistake 15e made with SequenceEditor:138. Both shipped callers pass a
    -- shape this never bit: Core.lua:181 passes the well-formed D.TestSequence,
    -- and UI/SequenceEditor.lua:4533 passes no template at all (so tmpl is
    -- D.NewSequence). No shipped caller hands it a corrupt template today.
    local STEPS_ROWS = {
        { label = "absent" },
        { label = "number", value = 5 },
        { label = "boolean", value = true },
        { label = "string", value = "abc" },
    }

    for _, row in ipairs(STEPS_ROWS) do
        local tmpl = {
            versions = {
                { stepFunction = "W30StepsFn", keyPress = "/startattack", steps = row.value },
            },
        }
        local okS, seqS = pcall(D.NewSequenceFromTemplate, "W30Seq", tmpl)
        local tag = " for template steps=" .. row.label
        assertTrue(okS, "NewSequenceFromTemplate raised" .. tag .. ": " .. tostring(seqS))
        -- NOT merely "it did not raise": the constructor RAN TO COMPLETION and
        -- produced a usable sequence, with an empty steps array rather than a
        -- missing one, and with the rest of the template still carried through.
        assertEqual("table", type(seqS.versions[1].steps), "version 1 still got a steps table" .. tag)
        assertEqual(0, #seqS.versions[1].steps, "and it is empty, since nothing was copyable" .. tag)
        assertEqual("W30StepsFn", seqS.versions[1].stepFunction, "the template stepFunction still carried" .. tag)
        assertEqual("/startattack", seqS.versions[1].keyPress, "the template keyPress still carried" .. tag)
    end

    -- CONTROL: a REAL steps array is still copied, element for element, so the
    -- empty arrays above are not what this constructor produces for everything.
    local okT, seqT = pcall(D.NewSequenceFromTemplate, "W30Seq", {
        versions = { { stepFunction = "W30StepsFn", steps = { "/cast Alpha", "/cast Bravo" } } },
    })
    assertTrue(okT, "NewSequenceFromTemplate raised on the real-steps control: " .. tostring(seqT))
    assertEqual(2, #seqT.versions[1].steps, "the control copied both template steps")
    assertEqual("/cast Alpha", seqT.versions[1].steps[1], "step 1 is the template's own text")
    assertEqual("/cast Bravo", seqT.versions[1].steps[2], "step 2 is the template's own text")

    -- VERSIONS[1] SHAPES (pass 15k), and this block exists because the 15j fix
    -- ABOVE was not enough. The FALLBACK_ROWS at the head of this case pass a
    -- scalar CONTAINER (versions = 5) and the guard that catches them is
    --   type(tmpl.versions) == "table" and tmpl.versions[1] or D.NewVersion
    -- which type-tests the container and stops there. A template carrying
    -- versions = {5} passes that test -- the container IS a table -- and still
    -- binds ver1 to a number. ver1.stepFunction is then read at
    -- Data/Defaults.lua:3927, FORTY-NINE LINES ABOVE the steps walk 15j had just
    -- fixed at :3976. 15j moved the crash earlier; it did not remove it, which
    -- is the same lesson 15b, 15c and 15d each reached from the other side.
    -- Both levels are type()-tested as of 15k.
    --
    -- IT IS ALSO THE FIRST LIVE INSTANCE OF LIMIT 3 IN W26's BOUNDARY NOTE --
    -- "a receiver bound to a local several lines earlier". ver1 is that local:
    -- W26 scans one line at a time and cannot connect the binding at :3919 to
    -- the eight reads at :3927-3935, so no pattern it carries could ever have
    -- reported this. The limit has been recorded as theoretical since 15g and
    -- this is a real defect sitting inside it.
    --
    -- WHAT FALSIFIES WHAT, measured on 2026-07-28 by reverting the guard to the
    -- 15j single-level form in Data/Defaults.lua and running this file:
    --   5     RAISED   "attempt to index local 'ver1' (a number value)"  :3920
    --   true  RAISED   "attempt to index local 'ver1' (a boolean value)" :3920
    --   'abc' DID NOT RAISE -- ("abc").stepFunction resolves through the string
    --         metatable to nil, so every "or" fallback ran -- but it is still
    --         falsified here, by keyPress: the string path produced "" from the
    --         or-fallback where the real D.NewVersion carries
    --         "/stopmacro [channeling]". Recorded the same way the FALLBACK_ROWS
    --         note above records its own already-correct input: a row that
    --         passes for a different reason than the others is worth naming.
    local VER1_ROWS = {
        { label = "number", value = 5 },
        { label = "boolean", value = true },
        { label = "string", value = "abc" },
    }

    for _, row in ipairs(VER1_ROWS) do
        local okV, seqV = pcall(D.NewSequenceFromTemplate, "W30Seq", { versions = { row.value } })
        local tag = " for template versions[1]=" .. row.label
        assertTrue(okV, "NewSequenceFromTemplate raised" .. tag .. ": " .. tostring(seqV))
        -- Ran to COMPLETION and fell back to D.NewVersion field by field, not
        -- merely "did not raise". keyPress is the load-bearing one: it is the
        -- only field whose D.NewVersion value differs from the "or" fallback
        -- the constructor writes, so it is what separates a real fallback from
        -- an accidental one on the string row.
        assertEqual("table", type(seqV.versions), "the new sequence still got a versions table" .. tag)
        assertEqual(1, #seqV.versions, "exactly one version" .. tag)
        local v = seqV.versions[1]
        assertEqual(D.NewVersion.stepFunction, v.stepFunction, "fell back to D.NewVersion for stepFunction" .. tag)
        assertEqual(D.NewVersion.keyPress, v.keyPress, "fell back to D.NewVersion for keyPress" .. tag)
        assertEqual(D.NewVersion.keyRelease, v.keyRelease, "fell back to D.NewVersion for keyRelease" .. tag)
        assertEqual(D.NewVersion.resetTimer, v.resetTimer, "fell back to D.NewVersion for resetTimer" .. tag)
        assertEqual(D.NewVersion.resetOnCombat, v.resetOnCombat, "fell back to D.NewVersion for resetOnCombat" .. tag)
        assertEqual("table", type(v.steps), "version 1 still got a steps table" .. tag)
        assertEqual(0, #v.steps, "and it is empty, since D.NewVersion carries no steps" .. tag)
    end

    -- CONTROL: the well-formed template above is unaffected by the second
    -- type() test, so the fallbacks are not what this constructor now produces
    -- for everything. Asserted on the SAME shape the 15j control uses, and the
    -- keyPress it carries is deliberately NOT D.NewVersion's.
    local okW, seqW = pcall(D.NewSequenceFromTemplate, "W30Seq", {
        versions = { { stepFunction = "W30Ver1Fn", keyPress = "/startattack", steps = { "/cast Alpha" } } },
    })
    assertTrue(okW, "NewSequenceFromTemplate raised on the well-formed versions[1] control: " .. tostring(seqW))
    assertEqual("W30Ver1Fn", seqW.versions[1].stepFunction, "the control carried the template stepFunction")
    assertEqual("/startattack", seqW.versions[1].keyPress, "the control carried the template keyPress")
    assertEqual(1, #seqW.versions[1].steps, "the control copied the template step")
end)

test("W33: D.CopyVersion survives a scalar steps", function()
    -- Data/Defaults.lua:4002, gated on BARE TRUTHINESS through 15j:
    --   if ver.steps then
    --       copy.steps = {}
    --       for i, step in ipairs(ver.steps) do
    -- The only test above it is that ver ITSELF is a table (:3990), which is
    -- the parent-versus-field split 15d named: it says nothing about the field
    -- being dereferenced. A version carrying steps = 5 passed the bare gate and
    -- raised in the ipairs at :4004. It is type()-tested as of 15k.
    --
    -- 15j's report put the bare gate at :3987, a line that is not the gate. The
    -- numbers used here are the real ones, read out of the file rather than
    -- carried forward from the report: the gate is :4002, the loop :3994.
    --
    -- ALL THREE SCALARS RAISED under the bare gate -- ipairs demands a table and
    -- rejects number, boolean AND string, so unlike the versions[1] block above
    -- there is no already-correct input here.
    local SCALAR_ROWS = {
        { label = "number", value = 5 },
        { label = "boolean", value = true },
        { label = "string", value = "abc" },
    }

    for _, row in ipairs(SCALAR_ROWS) do
        local okC, copy = pcall(D.CopyVersion, { stepFunction = "W33Fn", keyPress = "/w33", steps = row.value })
        local tag = " for steps=" .. row.label
        assertTrue(okC, "CopyVersion raised" .. tag .. ": " .. tostring(copy))
        -- The copy is USABLE, not merely non-raising: every scalar field the
        -- shallow pass copies is still there.
        assertEqual("W33Fn", copy.stepFunction, "the shallow copy still carried stepFunction" .. tag)
        assertEqual("/w33", copy.keyPress, "the shallow copy still carried keyPress" .. tag)
        -- And the malformed field is carried through UNCHANGED by the pairs
        -- pass rather than silently promoted to an empty table. The guard skips
        -- the deep copy; it does not repair the data, and a caller that wants
        -- repair should not be able to mistake this for it.
        assertEqual(row.value, copy.steps, "the scalar steps is carried, not replaced" .. tag)
    end

    -- nil AND false behave exactly as they did under the bare gate. This is the
    -- half of the change that must NOT be observable, and it is asserted rather
    -- than assumed.
    local okN, copyN = pcall(D.CopyVersion, { stepFunction = "W33Fn" })
    assertTrue(okN, "CopyVersion raised on an absent steps: " .. tostring(copyN))
    assertEqual(nil, copyN.steps, "an absent steps stays absent, exactly as under the bare gate")
    local okF, copyF = pcall(D.CopyVersion, { stepFunction = "W33Fn", steps = false })
    assertTrue(okF, "CopyVersion raised on steps=false: " .. tostring(copyF))
    assertEqual(false, copyF.steps, "a false steps is carried, not replaced by an empty table")

    -- The head check at Data/Defaults.lua:3990 is unchanged and still returns an empty table.
    assertEqual("table", type(D.CopyVersion(5)), "a scalar VERSION still returns an empty table")
    assertEqual("table", type(D.CopyVersion(nil)), "a nil version still returns an empty table")

    -- CONTROL: a real steps array is still DEEP-copied, element for element and
    -- without aliasing the source, so the pass-through rows above are not what
    -- CopyVersion does to everything.
    local src = { stepFunction = "W33Fn", steps = { "/cast Alpha", "/cast Bravo" } }
    local deep = D.CopyVersion(src)
    assertEqual(2, #deep.steps, "the control deep-copied both steps")
    assertEqual("/cast Alpha", deep.steps[1], "step 1 is the source's own text")
    assertEqual("/cast Bravo", deep.steps[2], "step 2 is the source's own text")
    deep.steps[1] = "/cast Changed"
    assertEqual("/cast Alpha", src.steps[1], "the deep copy does not alias the source array")
end)

test("W31: the ImportPreview readers survive a scalar versions, in a collection preview and on commit", function()
    -- EDIT 5 of pass 15i, the half that is NOT already covered. Checked first,
    -- and two of the four named sites needed nothing:
    --   GRIPExport.lua  :1120  ALREADY COVERED by W17's exportWith(42) -- the
    --                          only scalar-versions fixture the suite held
    --                          before pass 15, and it reaches GE.ExportAsText,
    --                          which is where :1119/:1120 live. Nothing added.
    --   ImportPreview.lua :1360 NOT FALSIFIABLE, and not for want of a fixture.
    --                          It walks a seqData whose versions field is built
    --                          as a table LITERAL twenty-two lines above it
    --                          (ImportPreview.lua:1338, the RAW-format arm of
    --                          CommitSelected), so no input can make that field
    --                          a scalar. Reverting the guard changes nothing
    --                          observable. It stays SOURCE-ONLY by construction
    --                          and W26 is what pins it; inventing a fixture
    --                          that reached it would mean faking the literal.
    -- What IS added here: ImportPreview :512 with :515 (entry point 1) and
    -- :1174 (entry point 2).
    local LIm = GRIPEMS.LegacyImport
    local Ser = GRIPEMS.Serialization
    local saved = GRIPEMS.Engine.sequences

    -- ENTRY POINT 1 -- LI.Preview into LI._PreviewNativePayload's COLLECTION
    -- arm (:512 binds payloadVersions, :515 reads its count). The malformed
    -- entry and a well-formed NEIGHBOUR go into the SAME payload and the same
    -- call, so "it did not raise" stays separated from "it skipped everything".
    local function previewWith(versionsShape)
        local _, str = Ser.Encode({
            format = "GRIP-EMS",
            version = D.GRIP_FORMAT_VERSION,
            type = "COLLECTION",
            sequences = {
                W31Bad = { versions = versionsShape, defaultVersion = 1 },
                W31Good = {
                    defaultVersion = 1,
                    versions = { { stepFunction = D.STEP_SEQUENTIAL, steps = { A, B } } },
                },
            },
        }, D.EMS1_PREFIX)
        return pcall(LIm.Preview, str)
    end

    for _, shape in ipairs({ 42, true, "text" }) do
        local ok, prev = previewWith(shape)
        assertTrue(ok, "Preview raised on collection versions=" .. type(shape) .. ": " .. tostring(prev))
        local tag = " for versions=" .. type(shape)
        assertTrue(type(prev) == "table" and prev.ok == true, "the collection still previewed" .. tag)
        local byName = {}
        for _, e in ipairs(prev.sequences or {}) do
            byName[e.name] = e
        end
        assertTrue(byName.W31Bad ~= nil, "the malformed entry still produced a preview row" .. tag)
        -- ImportPreview.lua:515. A string does not raise on "#" -- it fabricates 4 from the
        -- character length -- so for that shape this is the assertion that
        -- fails on a revert; for a number and a boolean :512's index raises.
        assertEqual(0, byName.W31Bad.versionCount, "ImportPreview.lua:515 -- a scalar versions counts 0" .. tag)
        assertEqual(0, byName.W31Bad.stepCount, "ImportPreview.lua:512 -- and 0 steps, the index never ran" .. tag)
        assertEqual(0, byName.W31Bad.freeformCount, "and no freeform steps" .. tag)
        assertTrue(byName.W31Good ~= nil, "the neighbour survived the malformed entry" .. tag)
        assertEqual(1, byName.W31Good.versionCount, "the neighbour still reports its real version count" .. tag)
        assertEqual(2, byName.W31Good.stepCount, "the neighbour still reports its real step count" .. tag)
    end

    -- CONTROL-FALSIFY for entry point 1: a REAL two-version payload counts 2,
    -- so the numbers above are read off the payload and not off a constant.
    local _, strF = Ser.Encode({
        format = "GRIP-EMS",
        version = D.GRIP_FORMAT_VERSION,
        type = "COLLECTION",
        sequences = {
            W31Good = {
                defaultVersion = 1,
                versions = {
                    { stepFunction = D.STEP_SEQUENTIAL, steps = { A, B } },
                    { stepFunction = D.STEP_SEQUENTIAL, steps = { C } },
                },
            },
        },
    }, D.EMS1_PREFIX)
    local okF, prevF = pcall(LIm.Preview, strF)
    assertTrue(okF, "the falsify control raised: " .. tostring(prevF))
    assertEqual(1, #prevF.sequences, "control-falsify: one sequence in, one row out")
    assertEqual(2, prevF.sequences[1].versionCount, "control-falsify: a two-version payload counts 2, not 0")

    -- ENTRY POINT 2 -- LI.CommitSelected into BuildSeqDataFromGRIP1, whose
    -- ipairs walk at ImportPreview.lua:1203 hands every version to NormalizeVersionLocale.
    -- BuildSeqDataFromGRIP1 copies seq.versions RAW (:1119), so a scalar on the
    -- wire lands in seqData.versions and the guard at :1203 is the only thing
    -- between it and ipairs. Observed through a COUNTING SpellCache stub, the
    -- same technique W25 uses on the GRIPExport twin: the walk is watched
    -- directly rather than inferred from the absence of a raise.
    local normCalls = 0
    local savedNorm = GRIPEMS.SpellCache.NormalizeVersionLocale
    GRIPEMS.SpellCache.NormalizeVersionLocale = function()
        normCalls = normCalls + 1
    end

    local okBody, errBody = pcall(function()
        local function commitWith(versionsShape)
            normCalls = 0
            local entry = {
                name = "W31Seq",
                -- isCollection routes to the BuildSeqDataFromGRIP1 arm, where
                -- seqObj IS the sequence payload. Same gate W15 documents.
                isCollection = true,
                seqObj = { versions = versionsShape, defaultVersion = 1 },
            }
            return pcall(
                LIm.CommitSelected,
                { ok = true, format = "GRIP1", sequences = { entry }, variables = {} },
                { sequences = { { selected = true, action = "import" } }, variables = {} }
            )
        end

        for _, shape in ipairs({ 42, true, "text" }) do
            local ok, res = commitWith(shape)
            GRIPEMS.Engine.sequences["W31Seq"] = nil
            assertTrue(ok, "CommitSelected raised on versions=" .. type(shape) .. ": " .. tostring(res))
            assertEqual(0, normCalls, "ImportPreview.lua:1203 -- a scalar versions is never walked for " .. type(shape))
        end

        -- CONTROL on a non-zero observable: a real versions table IS walked --
        -- one NormalizeVersionLocale call per version, which is the guarded
        -- ipairs at ImportPreview.lua:1203 watched directly.
        local okC, resC = commitWith({
            { stepFunction = D.STEP_SEQUENTIAL, steps = { A, B } },
            { stepFunction = D.STEP_SEQUENTIAL, steps = { C } },
        })
        GRIPEMS.Engine.sequences["W31Seq"] = nil
        assertTrue(okC, "the CommitSelected control raised: " .. tostring(resC))
        assertEqual(2, normCalls, ":1174 -- the guarded walk visited every version")
    end)

    GRIPEMS.SpellCache.NormalizeVersionLocale = savedNorm
    GRIPEMS.Engine.sequences = saved
    if not okBody then
        -- level 0, same reason as W25: keep the failing assertion's own
        -- file:line instead of re-attributing it to this wrapper.
        error(errBody, 0)
    end
end)

-- ---------------------------------------------------------------------------
-- Pass 15c: the six complementary sites -- the half of the .versions family
-- that the pass-15 sweep could not see. See the W24 header for the full list
-- and for the four look-alikes that are already safe.
--
-- PASS 15d -- THE PASS-15c SWEEP WAS TWO-OPERATOR, and that is the limit this
-- case now records. 15c enumerated the complementary shape by walking bare
-- truthiness head-checks that were followed by "#" or by ipairs. Those are two
-- of the three ways a scalar .versions gets dereferenced; the third is a plain
-- INDEX, and a head check followed by an index fell outside the sweep
-- entirely. One such site was live:
--
--   UI/SequenceEditor.lua  SE:GetEditingVersion
--       if not seqData or not seqData.versions then   -- bare truthiness
--       return seqData.versions[idx] or seqData.versions[1]
--
-- Probed on the real bytes: versions=5 RAISES, versions=true RAISES,
-- versions='abc' returns nil. And it sits on a path 15c NEWLY MADE REACHABLE.
-- Before 15c, SE:SwitchVersion raised at the length operator and execution
-- never got this far. After 15c that line yields maxVer=1, idx=1 clears the
-- range check, LoadVersionIntoEditor runs, and it calls GetEditingVersion --
-- which was the only unsafe link left on the path. Same lesson the
-- SequenceList site taught in the W24 header, one layer further out: guarding
-- a caller does not remove a raise, it RELOCATES it to the first unguarded
-- read downstream. Pass 15d also closed a second shape the 15c pattern could
-- not match, the parenthesised spelling in UI/TrackerHUD.lua x2 that the 15c
-- header flagged as known residue.
--
-- Sites closed in 15d, all now type()-tested and pinned below:
--   UI/SequenceEditor.lua  x4  GetEditingVersion (INDEX), version dropdown,
--                              live badge menu, delete-version
--   UI/PopupEditor.lua     x2  version dropdown, RefreshVersionBar
--   UI/ContextTab.lua      x1  version context menu
--   UI/TrackerHUD.lua      x2  the parenthesised badge counts
--   Data/SpellCache.lua    x1  CollectUnresolvedSpellRefs (ipairs)
--
-- PASS 15e -- THE FAMILY IS CLOSED, AND THE FILE SET IS NO LONGER THE EDIT SET.
-- 15b, 15c and 15d each ran the same method: pick a spelling, grep for it, fix
-- the matches, write a boundary note naming what was still open. That method
-- guarantees a next pass, because the pattern you grep for IS the blind spot --
-- 15c missed the INDEX shape, 15d missed the "or {}" shape. 15e stops adding one
-- more pattern to one more edit set. It fixed every known site in every shipped
-- file, including the two files earlier briefs froze (Engine/Engine.lua and
-- Import/ImportPreview.lua -- the freeze was lifted for that pass), and this
-- case now scans ALL NINETEEN shipped .lua files that mention .versions rather
-- than only the files an edit pass happened to touch. A site can no longer
-- survive by living in a file nobody edited.
--
-- The shape 15e closed that NO pass had scanned is the "or {}" FALLBACK, and it
-- was strictly more exposed than the length shape 15c fixed. "or {}" substitutes
-- for nil and false ONLY; a scalar is truthy, passes straight through, and
-- ipairs then raises on number, boolean AND string -- where "#" at least
-- tolerates a string. Measured in Lua 5.1 on 2026-07-28, with
-- t = { versions = <scalar> }:
--     #t.versions          number RAISES, boolean RAISES, string returns length
--     t.versions[1]        number RAISES, boolean RAISES, string returns nil
--     ipairs(t.versions)   number RAISES, boolean RAISES, string RAISES
--     next / pairs         number RAISES, boolean RAISES, string RAISES
--
-- Sites closed in 15e: Core/Core.lua x3, Core/PublicAPI.lua x1,
-- Data/Defaults.lua x1, Data/SpellCache.lua x3, Data/RepairAnalyzer.lua x16,
-- Engine/Engine.lua x5, Import/GRIPExport.lua x2, Import/ImportPreview.lua x3,
-- UI/PopupEditor.lua x5, UI/SequenceEditor.lua x5, UI/SequenceList.lua x1.
-- ---------------------------------------------------------------------------

-- ===========================================================================
-- THE BARE-TRUTHINESS SCANNER, LIFTED TO FILE SCOPE AND PARAMETERISED BY FIELD
-- NAME (pass 15k).
--
-- WHY IT MOVED. Every mechanism below was written inside W26 and every one of
-- them spelled "versions" literally -- the seven patterns, the guard needle,
-- and the file set. W32 measures the SAME defect family on a DIFFERENT field,
-- and the one thing that must not happen is a second copy of a lexer that took
-- four passes (15e receiver-blind, 15f receiver-scoped, 15g lexical, 15h
-- token-bounded) to get right. A second copy would drift from the first inside
-- one pass, and the drift would be invisible: both would report zero.
--
-- WHAT CHANGED, AND WHAT DID NOT. The field is now an argument, the patterns
-- are BUILT from it rather than hand-written, the allowlist is an argument, and
-- scan() takes an optional stats table so a caller can COUNT what it saw
-- instead of only being told whether anything was bare. Nothing else moved:
-- codeSpans, normaliseCode, startsInCode, leftBounded and guardedInCode are
-- byte-for-byte the 15h functions with four spaces of indentation removed, and
-- the comments that document each mechanism moved WITH the function they
-- document rather than being summarised. The scan loop is unchanged except for
-- the stats increments, which are all inside "if stats then".
--
-- THE ACCEPTANCE TEST FOR THE LIFT IS THAT NOTHING MOVES. With field
-- "versions", W26 must still report the same 26 matched / 24 cleared /
-- 2 allowlisted / 0 offenders over its nineteen files, and the confusion corpus
-- must still be 36 rows / 23 flagged / 12 clean / 1 allowlisted with every row
-- passing. W26 now PRINTS its census so that number is reproducible from a
-- suite run rather than from a comment -- see the foot of that case.
--
-- 15m: THOSE FOUR NUMBERS WERE THE 15k ACCEPTANCE TEST AND THEY ARE NOT THE
-- CURRENT ONES. Adding an EIGHTH shape moved them to 28 / 26 / 2 / 0 and the
-- corpus to 40 / 25 / 14 / 1. That is a DENOMINATOR CHANGE, not drift: the
-- paragraph above stays exactly as written because it is the record of what
-- 15k had to prove, and the side-by-side is at the head of W26 so a reader who
-- meets 28 here can see where the two extra lines came from. Do not "correct"
-- the numbers above -- they are not stale, they are dated.
-- ===========================================================================

local function readSource(relPath)
    for _, prefix in ipairs({ "", "../", "GRIP/EMS/" }) do
        local fh = io.open(prefix .. relPath, "r")
        if fh then
            local src = fh:read("*a")
            fh:close()
            return src
        end
    end
    return nil
end

-- ===========================================================================
-- 15o: THE COUNT WAS RECONCILED BEFORE THE NINTH PATTERN WAS WRITTEN, and
-- this block is that reconciliation. Read it before quoting any number for the
-- ninth shape, because THREE different true numbers were in circulation for it
-- and none of them was the shape's count.
--
-- THE DISAGREEMENT. 15n reported FIVE instances of the conjunctive positive
-- gate. A hand grep on 2026-07-28 --
--     if [A-Za-z0-9_.]+\.(actions|stepLabels|steps) and
-- over shipped .lua excluding Test, Libs and Tools -- returned TEN. Five and
-- ten cannot both be the number of instances of one shape.
--
-- THEY ARE NOT COUNTING THE SAME THING, and both are correct under their own
-- denominator. Measured on 2026-07-28 against the shipped 15n gate:
--
--   FIVE   is a D-BUCKET COUNT. All five fields, in code, but only the lines
--          that survived B (matched by one of the eight patterns) and C
--          (explained by a written rule). It is the count of instances the
--          gate had NO OPINION about -- which is exactly what D means and
--          exactly why the residual bucket surfaced the shape at all.
--   TEN    is an ALL-BUCKET COUNT over THREE of the five fields. It applies no
--          bucket filter, so it includes instances already in B and in C, and
--          it drops .versions and .taggedSteps entirely. It also has no word
--          boundary before "if", so it counts the "elseif X.f and" spelling --
--          correctly, since that is the same gate.
--   TWENTY-FIVE is the SHAPE COUNT: every instance of "if <dotted>.<field> and"
--          in shipped .lua (Test, Libs, Tools excluded) across all five
--          censused fields, independent of which bucket it fell into.
--
-- SO, IN THE WORDS THE BRIEF ASKED FOR: 15n's five was a D-bucket count and
-- not a shape count. That is a labelling defect of the same kind as
-- "W32: .steps census" naming a scan narrower than the one it runs. It is the
-- third disagreement in this arc that turned out to be definitional -- 11 vs
-- 17 was dotted versus camelCase, 261 vs 305 was the same -- and it will keep
-- happening until every count states its denominator in the same breath.
--
-- THE TWO PUBLISHED NUMBERS RECONCILE EXACTLY, not approximately:
--     .steps 5 + .actions 4 + .stepLabels 1                  = 10  (the grep)
--     .versions 14 + .taggedSteps 1                          = 15  (dropped)
--     10 + 15                                                = 25  (the shape)
--     of those 25: 2 in B, 18 in C, 5 in D                   = 25  (15n's five)
-- The ten file:line pairs the grep returned are the SAME ten this walk
-- attributes to those three fields -- set identity, not just an equal count.
--
-- WHERE EVERY ONE OF THE 25 SITS, and why it is not in D if it is not:
--
--   B, 2 instances. Already matched, on the SAME receiver, by BARE_LEN, so the
--   ninth pattern dedupes against them and adds nothing:
--       Import/LegacyImport.lua:656   if compiled.steps and #compiled.steps > 0
--       Engine/Engine.lua:2837        if ver.actions and #ver.actions > 0 and ...
--   Both are conjunctive positive gates AND length reads at once; the length
--   operator is simply the anchor that got there first.
--
--   C, 18 instances, all C3 -- a receiver-scoped 'type(E) == "table"' on the
--   same line. Fourteen are .versions, written
--       if seqData.versions and type(seqData.versions) == "table" then
--   which is redundant but safe; three are the .steps "elseif" spelling
--   (Import/ImportPreview.lua:211, UI/RawTab.lua:572, UI/RawTab.lua:651) and
--   one is Data/RepairAnalyzer.lua:1043 for .actions. NONE of them is a defect
--   and none becomes one when the ninth pattern starts matching them: the
--   pattern will match, the bareness rule will CLEAR them, and they move from
--   C to B with the verdict unchanged.
--
--   D, 5 instances -- 15n's five, named:
--       Import/ImportPreview.lua:775  .steps
--       Engine/TempoAdvisor.lua:987   .actions
--       UI/RawTab.lua:675             .actions
--       Import/GRIPExport.lua:97      .stepLabels
--       Core/Core.lua:1101            .taggedSteps
--   Three of these five GATE THEN DEREFERENCE and are fixed in this pass; the
--   other two are reported and left, because a fix applied without reading the
--   site moves a crash instead of removing it.
--
-- ONE PHYSICAL LINE CAN SIT IN TWO BUCKETS AT ONCE and Import/GRIPExport.lua:97
-- is the proof: "if ver.stepLabels and verCopy.steps then" is in B for .steps
-- (BARE_ANDGATE matches "and verCopy.steps then") and in D for .stepLabels
-- (nothing anchors ver.stepLabels). The buckets are per FIELD, not per line,
-- and any total that adds them across fields is counting lines twice on
-- purpose. That is why 25 is stated as field-instances.
--
-- THE MIDDLE-CONJUNCT SPELLING IS MEASURED HERE AND DELIBERATELY NOT COVERED.
-- "if a and X.f and b then" -- the field as a conjunct with something ahead of
-- it as well as behind -- exists 7 times over the same file set (4 .steps,
-- 3 .actions) and EVERY ONE of the seven is already matched by BARE_LEN,
-- because all seven continue with "#". So it hides nothing today. A middle
-- conjunct whose continuation is NOT "#" would be invisible to all nine
-- shapes; that is named residue for a later pass, not a claim that none
-- exists.
-- ===========================================================================

-- THE SEVEN BARE-TRUTHINESS SHAPES -- EIGHT AS OF 15m, NINE AS OF 15o; see the
-- BARE_NOTLEN block below the seven and the BARE_CONJGATE block after it.
-- 15c's sweep encoded two operators, "#"
-- and ipairs; 15d added the gate spelling that makes a plain INDEX visible;
-- 15e adds the three that were still unencoded. All seven are scanned:
--
--   BARE_LEN     (a) inline truthiness then "#". Matches
--                    "seqData.versions and #" and the local-bound
--                    "payloadVersions and #" spelling alike.
--   BARE_PAREN   (b) the parenthesised spelling,
--                    "(seqData and seqData.versions) and #seqData.versions".
--                    The closing paren sits between the field name and the
--                    operator, so (a) cannot see it -- this is exactly why
--                    the two TrackerHUD sites survived 15c.
--   BARE_GATE    (c) a NEGATIVE head check on the field, "not X.versions
--                    then", which is the gate spelling that precedes every
--                    "#", ipairs and INDEX read fixed in 15d. Gating on the
--                    gate rather than on the downstream read is what makes
--                    the INDEX shape visible at all: an index expression has
--                    no operator token to grep for.
--   BARE_ANDGATE (d) the CONJUNCTIVE positive gate,
--                    "and entry.data.versions then". It was added in 15d for
--                    diagnostic quality on the SpellCache site -- a revert
--                    there slips past (a), (b) and (c) and would otherwise be
--                    caught only by the PRESENCE assert, which names the file
--                    but NOT the line. 15d had to NARROW it so it could not
--                    match the bare positive gate, which was still live then.
--                    THAT NARROWING IS GONE: after 15e no conjunctive bare
--                    gate exists in shipped code either, so it flags freely.
--   BARE_POSGATE (e) 15e. The BARE positive gate, "if X.versions then",
--                    immediately above an ipairs or an index over the same
--                    field -- the undo/redo and rename snapshot builders.
--   BARE_ORFALL  (f) 15e, and the shape NO earlier pass scanned. "or {}"
--                    substitutes for nil and false ONLY: a scalar is truthy,
--                    passes straight through, and ipairs then raises on
--                    number, boolean AND string. Strictly more exposed than
--                    the length shape (a), where a string at least survives.
--   BARE_INDEX   (g) 15e. The same-expression index,
--                    "seqData.versions and seqData.versions[i]".
--   BARE_NOTLEN  (h) 15m. THE EIGHTH SHAPE, and it existed in shipped code
--                    for BOTH fields while seven passes counted without it.
--                    A NEGATIVE gate whose continuation is NOT " then":
--                        if not X.steps or #X.steps == 0 then
--                        if not seq.versions or type(seq.versions) ~= "table" then
--                    (c) BARE_GATE anchors on " then" straight after the
--                    field and therefore sees neither. (a) BARE_LEN wants
--                    " and #" and (f) BARE_ORFALL wants " or {}", so neither
--                    sees the first one either. "not 5" is FALSE, so control
--                    falls through to the second disjunct and the length
--                    operator runs on the scalar and raises -- the same raise
--                    (a) exists for, written with "or" instead of "and".
--
--                    THE NAME IS NARROWER THAN THE SHAPE, said plainly here
--                    rather than discovered later. The pattern matches
--                    "not <receiver> or " and NOT "not <receiver> or #": the
--                    continuation is deliberately unconstrained, because the
--                    two shipped .versions instances continue with
--                    " or type(...)" and not with " or #", and a pattern that
--                    demanded "#" would have left the .versions denominator
--                    exactly as short as it was. "NOTLEN" is the .steps
--                    spelling of the shape and is kept as the name because
--                    that is the instance that raises; the SHAPE is the
--                    negative gate that BARE_GATE cannot see. Measured: over
--                    both file sets on 2026-07-28 the wider form matches the
--                    SAME twelve .steps sites the "or #" form does, and two
--                    more .versions sites -- so the widening costs nothing and
--                    buys the part of this pass that matters. Same precedent
--                    as W32's own "WHAT THE LABEL ON THIS CASE HIDES" note.
--   BARE_CONJGATE (i) 15o. THE NINTH SHAPE, and like the eighth it is an
--                    ANCHOR failure and not an unimagined shape. The
--                    CONJUNCTIVE POSITIVE GATE with the field as the HEAD
--                    conjunct:
--                        if X.f and <more> then
--                    (e) BARE_POSGATE anchors the field adjacent to "if" and
--                    demands " then" straight after it. (d) BARE_ANDGATE
--                    anchors it adjacent to "then" and demands "and " straight
--                    before it. A gate carrying the field as ONE conjunct
--                    among several satisfies neither anchor, which is the
--                    SAME adjacency failure BARE_NOTLEN had against
--                    BARE_GATE. That is twice now that an anchor, not a
--                    shape, was the blind spot.
--
--                    IT IS TRUTHINESS, so a scalar passes: "if ver.stepLabels
--                    and verCopy.steps then" is entered by a stepLabels of 7,
--                    and the index three lines down raises.
--
--                    THE NAME SAYS "GATE" AND THE PATTERN SAYS "if ", and the
--                    "elseif X.f and" spelling is caught by the same string --
--                    "elseif" ENDS in "if" -- exactly as BARE_POSGATE and
--                    BARE_GATE have always caught their own elseif spellings.
--                    Three of the eighteen instances this shape clears are
--                    elseif lines; that is not a widening, it is what a
--                    substring anchor has always done here.
--
--                    WHAT IT DOES NOT COVER, stated rather than discovered
--                    later: the MIDDLE conjunct, "if a and X.f and b then".
--                    Measured 7 instances over the same file set and every one
--                    is already matched by BARE_LEN because every one
--                    continues with "#". A middle conjunct that does NOT
--                    continue with "#" is invisible to all nine shapes and is
--                    named residue for a later pass. See the 15o
--                    reconciliation block above for the working.
--
-- 15f: EVERY PATTERN NOW CAPTURES ITS RECEIVER. Through 15e a pattern told
-- the caller only THAT a line matched, never WHAT was dereferenced, and the
-- 15e bareness rule was built on that missing information -- see scan()
-- below for what that cost. Each pattern now wraps the dereferenced
-- expression in a capture. NOTHING ELSE ABOUT THEM CHANGED: every prefix
-- class added here is a "*" quantifier that may match empty, so the set of
-- lines each pattern matches is exactly the set it matched in 15e -- this
-- edit makes the receiver visible, it does not widen or narrow a shape.
--
-- The receiver has two spellings and both are captured whole: a FIELD READ
-- ("seqData.versions", "entry.data.versions") and a LOCAL
-- ("payloadVersions"). For (a) and (b) the captured expression is the one
-- the truthiness test reads, which in both spellings is also the one "#" is
-- applied to. For (c), (d) and (e) it is the gated field. For (f) it is the
-- expression the "or {}" substitutes for. For (g) it is the INDEXED
-- expression rather than the tested one, because the index is the operation
-- that raises.
--
-- 15k: BUILT FROM THE FIELD NAME rather than hand-written. Each shape is the
-- 15f string with "versions" replaced by the argument and "[Vv]ersions" by the
-- same either-case class built from its first letter -- that class exists so
-- (a) and (b) also see the LOCAL-BOUND spelling ("payloadVersions and #"),
-- which is a camelCase suffix and not a dotted field read. THE PATTERNS ARE
-- NOT ESCAPED and do not need to be: the field name is required to be a plain
-- identifier, which contains no Lua pattern magic. That is enforced rather
-- than trusted, because a field name carrying a "-" or a "." would silently
-- widen every one of the seven into something that matches far more than the
-- caller asked for.
--
-- 15m: BARE_NOTLEN IS APPENDED, NOT INSERTED, and that is the same rule the
-- order note below states. Receivers are deduplicated per line by whichever
-- shape matches FIRST, so putting the eighth anywhere but the end would
-- reclassify existing sites between shapes without changing a single verdict --
-- and every earlier census would stop being comparable to this one for a
-- reason that has nothing to do with the code being scanned.
--
-- 15o: BARE_CONJGATE IS APPENDED FOR THE SAME REASON, and here the reason is
-- load-bearing rather than theoretical, because the ninth shape genuinely
-- CO-OCCURS with two earlier ones. Two of its 25 instances --
-- Import/LegacyImport.lua:656 and Engine/Engine.lua:2837 -- are conjunctive
-- gates AND length reads on the same receiver, and BARE_LEN gets there first.
-- Appended, they stay attributed to BARE_LEN and every earlier per-shape count
-- still means what it meant. Inserted anywhere ahead of BARE_LEN they would
-- move, and "BARE_LEN (n)" in five passes of census output would silently stop
-- being comparable. ONE ROW OF THE ATTRIBUTION ASSERT PINS THIS ORDERING AND
-- IT IS THE FOURTH: the dual-match probe "if ver.versions and #ver.versions >
-- 0 then", which is matched by BARE_LEN and by BARE_CONJGATE on the SAME
-- receiver, so nothing but the order of this list decides which shape claims
-- it. Appended, it attributes to BARE_LEN; move BARE_CONJGATE to the front and
-- that row alone goes red. Rows 1 to 3 pin a DIFFERENT question -- that the
-- ninth shape did not swallow BARE_POSGATE's or BARE_ANDGATE's spellings --
-- and 15p measured that they stay green through a full reorder. Do not read
-- the four rows as one set; see the note above ATTRIBUTION itself.
local PATTERN_ORDER = {
    "BARE_LEN",
    "BARE_PAREN",
    "BARE_GATE",
    "BARE_ANDGATE",
    "BARE_POSGATE",
    "BARE_ORFALL",
    "BARE_INDEX",
    "BARE_NOTLEN",
    "BARE_CONJGATE",
}

-- 15m: THE ONE PER-SHAPE EXCEPTION IN THE CLEAR-CHECK, and it is deliberately
-- a table keyed by shape name rather than a flag threaded through the rule,
-- so that "which shapes accept the negated guard" is answerable by reading one
-- line instead of by tracing an argument.
--
-- WHY THE SPLIT IS CORRECT AND MUST NOT BE COLLAPSED. The seven shapes above
-- all sit in POSITIVE contexts -- "X.f and #X.f", "if X.f then",
-- "ipairs(X.f or {})", "X.f and X.f[i]". In every one of them the guard that
-- makes the read safe is 'type(X.f) == "table"' used as a CONJUNCT, and
-- 'type(X.f) ~= "table"' is the OPPOSITE test: on a table it short-circuits
-- the whole and-chain to false, and on a SCALAR it is true and execution
-- proceeds straight into the bare read. It does not protect anything. That is
-- why corpus row 12 pins it as MUST_FLAG and why that row must keep passing.
--
-- BARE_NOTLEN is inherently a NEGATIVE, early-bail gate, and there the
-- correct guard IS the negated form: 'if not X.f or type(X.f) ~= "table" then
-- return end' bails on nil, on false and on every scalar, which is exactly
-- what the site needs. Both shipped .versions instances are written that way
-- (Import/ImportPreview.lua:140 and :1264) and both are SAFE. A rule that
-- refused "~=" here would report two offenders that are correct code, and the
-- only way back to green would be to allowlist correct code -- which is how a
-- gate stops meaning anything.
--
-- SO: for BARE_NOTLEN a match clears on EITHER form, for the other seven only
-- on "==". Both forms go through the SAME code-span and left-token-boundary
-- tests -- the loosening is which needle is looked for, not where it may be
-- found. The corpus carries the pair in both directions (rows 38/39 clear a
-- BARE_NOTLEN line, row 40 still flags a positive shape carrying "~=") so a
-- later pass cannot collapse the two into one rule in either direction.
--
-- THE RESIDUAL RISK, NAMED. Accepting "~=" widens the known CEILING -- the
-- gate checks that a guard CO-OCCURS with a read, not that it DOMINATES it --
-- by one shape: 'if not X.f or #X.f == 0 or type(X.f) ~= "table" then' would
-- clear while the "#" still runs first. It is the same single limit already
-- recorded at the foot of W26 and no new mechanism, so it is not patched here.
-- A stricter rule is available to a later pass and is written down rather than
-- left to be re-derived: require the guard occurrence to start BEFORE the
-- first dereference of the same receiver on the line. Both shipped instances
-- already satisfy that ordering; nothing in the tree needs it yet.
--
-- 15o: BARE_CONJGATE IS NOT ADDED TO THIS TABLE, and that is a decision rather
-- than an omission. It is a POSITIVE gate -- "if X.f and <more> then" enters
-- the block when X.f is truthy -- so it belongs with the other seven
-- positives and clears on 'type(E) == "table"' ONLY. Writing
-- 'if X.f and type(X.f) ~= "table" then' does not protect the block; it
-- selects for the case where X.f is a truthy NON-table, which is the crash
-- case, and a rule that cleared it would clear the exact defect the shape
-- exists to find. Corpus rows 41 to 43 pin the split in both directions for
-- this shape exactly as rows 37 to 40 pin it for BARE_NOTLEN, so it cannot be
-- collapsed later in either direction.
local NEGATED_GUARD_CLEARS = { BARE_NOTLEN = true }

local function buildPatterns(field)
    if type(field) ~= "string" or not field:find("^%a[%w_]*$") then
        error("buildPatterns: field must be a plain Lua identifier, got: " .. tostring(field), 0)
    end
    local eitherCase = "[" .. field:sub(1, 1):upper() .. field:sub(1, 1):lower() .. "]" .. field:sub(2)
    local shapes = {
        BARE_LEN = "([%w_%.]*" .. eitherCase .. ") and #",
        BARE_PAREN = "([%w_%.]*" .. eitherCase .. ")%) and #",
        BARE_GATE = "not ([%w_%.]+%." .. field .. ") then",
        BARE_ANDGATE = "and ([%w_%.]+%." .. field .. ") then",
        BARE_POSGATE = "if ([%w_%.]+%." .. field .. ") then",
        BARE_ORFALL = "([%w_%.]*%." .. field .. ") or {}",
        BARE_INDEX = "%." .. field .. " and ([%w_%.]+%." .. field .. ")%[",
        -- 15m. Built from the field exactly as the seven are, and using the
        -- SAME either-case class as BARE_LEN and BARE_PAREN so it sees the
        -- local-bound spelling ("not compiledSteps or #compiledSteps") as well
        -- as the dotted field read. The receiver is captured, so the
        -- receiver-scoped bareness rule, the code-span test and the left token
        -- boundary all apply to it unchanged.
        BARE_NOTLEN = "not ([%w_%.]*" .. eitherCase .. ") or ",
        -- 15o. Built from the field exactly as the eight above are. It anchors
        -- on "if " like BARE_POSGATE and on the DOTTED field read like
        -- BARE_GATE, BARE_ANDGATE and BARE_POSGATE -- the either-case class is
        -- deliberately NOT used, because a conjunctive gate over a LOCAL
        -- ("if compiledSteps and ...") carries no field read at all and would
        -- widen this shape into every local whose name happens to end in the
        -- field.
        --
        -- THE TRAILING SPACE AFTER "and" IS THE WORD BOUNDARY. Without it
        -- "if X.f android" satisfies the pattern. Measured over the shipped
        -- tree on 2026-07-28 the two forms match the SAME 25 instances -- no
        -- line ends immediately after the "and" -- so the boundary costs
        -- nothing and is kept because the cost of NOT having one is a false
        -- site in a census that asserts nothing and would be believed.
        --
        -- IT CANNOT SWALLOW BARE_POSGATE OR BARE_ANDGATE. BARE_POSGATE demands
        -- " then" in the position this demands " and ", and BARE_ANDGATE
        -- demands "and " in the position this demands "if ". The three anchors
        -- are mutually exclusive AT AN OCCURRENCE; where a LINE carries more
        -- than one of them, PATTERN_ORDER and the per-line receiver dedupe
        -- decide, and this shape is last.
        BARE_CONJGATE = "if ([%w_%.]+%." .. field .. ") and ",
    }
    -- ORDER IS LOAD-BEARING and is the 15e order, unchanged. Receivers are
    -- deduplicated per line by scan(), so whichever shape matches a receiver
    -- FIRST is the one the census attributes it to; reordering this list would
    -- silently reclassify sites without changing any verdict.
    local out = {}
    for i, name in ipairs(PATTERN_ORDER) do
        out[i] = { name = name, pattern = shapes[name], negatedClears = NEGATED_GUARD_CLEARS[name] or false }
    end
    return out
end

-- -----------------------------------------------------------------------
-- 15g: THE LINE LEXER, and it is a different KIND of fix from the two
-- passes before it. 15e was token-level and 15f was receiver-level, but
-- BOTH were still character matching over RAW LINE TEXT, and raw text
-- cannot tell a READ from a REMARK ABOUT A READ. Four confusions were
-- MEASURED on the shipped 15f W26 on 2026-07-28, each by appending one
-- line to UI/RawTab.lua and running this suite:
--
--   1  a bare read with the guard text in a TRAILING COMMENT
--      -> GREEN. A HOLE: prose cleared a live read.
--   2  a bare read with the guard text in a STRING LITERAL
--      -> GREEN. A HOLE, same class.
--   3  a COMMENTED-OUT bare read
--      -> RED. A FALSE POSITIVE: dead text reported as a live site.
--   4  a CORRECT guard written 'type(E)=="table"', no spaces
--      -> RED. A FALSE POSITIVE: the needle was a fixed literal.
--
-- 1 and 2 are holes -- the gate says clean when it is not. 3 and 4 are
-- noise -- the gate says dirty when it is not, and noise is how
-- allowlists grow until a gate stops meaning anything. All four have ONE
-- root cause, so they get ONE fix rather than four more patterns: work
-- out which spans of the line are CODE, then require both the pattern
-- match and the guard to START inside one.
--
-- codeSpans() walks the line once, left to right, and returns
-- {startIndex, endIndex} pairs over the ORIGINAL string. It EXCLUDES
-- 'single' and "double" quoted strings (backslash escapes honoured),
-- [[long]] strings and their [=[ levelled ]=] form (the closing bracket
-- must match the opening level), "--" line comments to end of line, and
-- --[[ long comments ]] in both their levelled forms.
--
-- IT NEVER REWRITES THE LINE. Spans are returned OVER the original text
-- and the original text is what the offender message carries, so the
-- diagnostic still shows the developer exactly what they wrote.
--
-- WHY SPANS AND NOT BLANKING, which is the trap this edit exists to
-- avoid: THE GUARD NEEDLE ITSELF ENDS IN A STRING LITERAL. Blanking or
-- masking string contents would destroy the '== "table"' in every one of
-- the 24 shipped clears and flag all 24 of them. Spans avoid that
-- entirely, because an occurrence is judged by where it STARTS -- at
-- "type(", which is code -- and never by whether it happens to CONTAIN a
-- string.
--
-- A construct that OPENS on this line and does not close on it -- an
-- unterminated long string or long comment -- is out of reach for a
-- line-based scan. The remainder of the line is treated as non-code and
-- the limit is recorded in the boundary note at the head of W26.
local function codeSpans(line)
    local spans = {}
    local n = #line
    local i, spanStart = 1, 1
    local function closeSpan(stop)
        if stop >= spanStart then
            spans[#spans + 1] = { spanStart, stop }
        end
    end
    while i <= n do
        local c = line:sub(i, i)
        if c == "-" and line:sub(i + 1, i + 1) == "-" then
            -- A comment, either the levelled long form or to end of line.
            local level = line:match("^%-%-%[(=*)%[", i)
            closeSpan(i - 1)
            if not level then
                return spans
            end
            local close = line:find("%]" .. string.rep("=", #level) .. "%]", i + 4 + #level)
            if not close then
                return spans
            end
            i = close + #level + 2
            spanStart = i
        elseif c == "[" and line:match("^%[(=*)%[", i) then
            -- A long string. The closing bracket must carry the same level.
            local level = line:match("^%[(=*)%[", i)
            closeSpan(i - 1)
            local close = line:find("%]" .. string.rep("=", #level) .. "%]", i + 2 + #level)
            if not close then
                return spans
            end
            i = close + #level + 2
            spanStart = i
        elseif c == "'" or c == '"' then
            -- A short string. A backslash consumes the character after it,
            -- so an escaped quote does not close the literal.
            closeSpan(i - 1)
            local j, closed = i + 1, false
            while j <= n do
                local d = line:sub(j, j)
                if d == "\\" then
                    j = j + 2
                elseif d == c then
                    closed = true
                    break
                else
                    j = j + 1
                end
            end
            if not closed then
                return spans
            end
            i = j + 1
            spanStart = i
        else
            i = i + 1
        end
    end
    closeSpan(n)
    return spans
end

-- 15g: THE GUARD SPELLINGS LUA TREATS AS ONE TEST. Confusion 4 above is a
-- GENUINE, CORRECT guard that the 15f gate called a defect, because the
-- needle was a fixed literal and the developer wrote no spaces around
-- "==". These three are the same test to Lua and must all clear:
--
--   type(E) == "table"      the canonical form, which every shipped line uses
--   type(E)=="table"        any run of spaces, or none, around "==", after
--                           "type(" and before ")"
--   type(E) == 'table'      single-quoted, which Lua accepts identically
--
-- Both sides are normalised the same way -- every whitespace run removed,
-- both quote characters folded to one -- and then compared with PLAIN
-- find. THE COPY THAT IS NORMALISED IS THE WHOLE LINE, NOT THE CODE-SPAN
-- TEXT, and that is forced by the same trap as above: the needle ends in
-- the string literal "table", which by construction is NOT inside a code
-- span, so normalising span text alone would match nothing at all and
-- flag all 24 shipped clears. POSITION is what carries the code/text
-- distinction and position is preserved -- map[i] is the ORIGINAL index
-- of normalised character i -- so an occurrence found here is still
-- judged by where it STARTS.
--
-- IT IS NOT LOOSENED FURTHER THAN THAT. 'type(E) ~= "table"' does not
-- normalise to the needle and MUST NOT clear: it is the OPPOSITE test,
-- and a line carrying it over a bare read is a real defect. The corpus
-- pins that as a MUST_FLAG row so the loosening cannot drift.
local function normaliseCode(text)
    local out, map = {}, {}
    for i = 1, #text do
        local c = text:sub(i, i)
        if not c:find("%s") then
            if c == "'" then
                c = '"'
            end
            out[#out + 1] = c
            map[#out] = i
        end
    end
    return table.concat(out), map
end

local function startsInCode(spans, idx)
    if not idx then
        return false
    end
    for _, span in ipairs(spans) do
        if idx >= span[1] and idx <= span[2] then
            return true
        end
    end
    return false
end

-- 15h: THE NEEDLE HAD NO LEFT TOKEN BOUNDARY. It is a plain substring
-- search, so ANY identifier ENDING in "type" satisfied it. MEASURED on the
-- shipped 15g gate on 2026-07-28, appended to UI/RawTab.lua:
--     local n = myvaluetype(entry.data.versions) == "table"
--         and entry.data.versions and #entry.data.versions or 0
--         -> GREEN. A HOLE. myvaluetype() is not type() and the read is
--            bare. The control -- the same shape carrying a real but
--            unrelated guard, 'type(other.versions) == "table"' -- correctly
--            went RED, so the hole was the boundary and nothing else.
-- THE LIKELIHOOD HERE IS LOW AND THAT WAS MEASURED, not assumed: a census
-- of the shipped tree on 2026-07-28 (Core, Data, Engine, Import, UI, Locale)
-- found 1072 occurrences of "type(" and every one of them is the BARE
-- global -- not a single call site spells it "<something>type(". So this
-- rule cannot move any real site, and it is fixed anyway because it is the
-- same class as every other defect in this arc: a text match with no notion
-- of where a token BEGINS.
--
-- THE BOUNDARY IS TESTED ON THE ORIGINAL LINE, THROUGH THE INDEX MAP, AND
-- THAT IS THE TRAP IN THIS FIX. normaliseCode collapses every whitespace run
-- to nothing, so a perfectly good 'and type(x.versions)' normalises to
-- 'andtype(x.versions)'; a boundary test against the NORMALISED copy would
-- see "d" immediately before "type(" and reject a REAL guard, turning
-- shipped clears red. map[s] is the ORIGINAL index of the occurrence and it
-- exists precisely so the question "what did the developer actually write to
-- the left of this" can still be asked against what was written. It is asked
-- there, not against the normalised copy.
--
-- REJECTING "." IS DELIBERATE and not an accident of the character class:
-- 'D.type(x)' calls a FIELD named type, not the global, so it must not
-- clear. Letters, digits and "_" are rejected for the same reason -- they
-- continue an identifier leftwards. Start of line, whitespace, "(", ",",
-- "=", "{" and every operator are accepted.
local function leftBounded(line, idx)
    if not idx then
        return false
    end
    if idx <= 1 then
        return true
    end
    return not line:sub(idx - 1, idx - 1):find("[%w_%.]")
end

-- The receiver is cleared only by a guard occurrence that STARTS in code and
-- whose "type" is a token in its own right. Every occurrence is walked, not
-- just the first, so guard text in a comment or a string sitting ahead of a
-- real guard cannot mask it.
--
-- 15m: alsoNegated adds the SECOND needle, 'type(E) ~= "table"', and is passed
-- true by exactly one shape -- see NEGATED_GUARD_CLEARS above for why that
-- shape and no other. The needle is normalised, span-tested and
-- token-bounded by the same code the canonical form goes through; nothing
-- about WHERE a guard may be found changes, only WHICH text counts as one.
-- With alsoNegated false this function is byte-for-byte the 15h behaviour.
local function guardedInCode(line, norm, map, spans, receiver, alsoNegated)
    -- normaliseCode returns TWO values (the text and its index map). Each call
    -- is parenthesised so only the text lands in the list -- an unparenthesised
    -- call in a table constructor would put the MAP in as a second needle.
    local needles = { (normaliseCode("type(" .. receiver .. ') == "table"')) }
    if alsoNegated then
        needles[#needles + 1] = (normaliseCode("type(" .. receiver .. ') ~= "table"'))
    end
    for _, needle in ipairs(needles) do
        local pos = 1
        while true do
            local s = norm:find(needle, pos, true)
            if not s then
                break
            end
            pos = s + 1
            local orig = map[s]
            if startsInCode(spans, orig) and leftBounded(line, orig) then
                return true
            end
        end
    end
    return false
end

-- 15k: THE CENSUS RECORD a scanner fills when a caller asks for one. Passing
-- no stats table is the 15h behaviour exactly: every increment below is inside
-- an "if stats", so a caller that only wants the offender list pays nothing and
-- observes nothing new. matched == cleared + allowlisted + offenders always,
-- and that identity is what makes the four numbers checkable against each other
-- rather than four separate claims.
-- 15n: matchedLines is the SET of "<label>:<lineNo>" keys a scan matched at
-- least once, and it exists for exactly one reason: the residual bucket below
-- needs to subtract "already matched by a pattern" from "mentions the field",
-- and matched/cleared/allowlisted/offenders are per-MATCH counts, not per-LINE
-- ones. A line carrying two bare receivers contributes 2 to matched and 1 to
-- this set. Adding it changes no verdict -- it is filled inside the same
-- "if stats" as every other counter, so a caller passing no stats table
-- observes nothing new -- and it does not disturb the
-- matched == cleared + allowlisted + offenders identity, which is still the
-- only arithmetic anything asserts against.
local function newScanStats()
    return { matched = 0, cleared = 0, allowlisted = 0, offenders = 0, bare = {}, byShape = {}, matchedLines = {} }
end

-- THE BARENESS RULE, and it is one rule for all seven patterns rather than a
-- per-pattern special case. (15m: it is one rule for all EIGHT, with one
-- narrow per-shape extension -- BARE_NOTLEN also clears on the NEGATED guard,
-- because a negative early-bail gate is the one context where 'type(E) ~=
-- "table"' is the correct guard rather than the opposite test. The scoping,
-- the code-span test and the token boundary are identical for both needles;
-- see NEGATED_GUARD_CLEARS above for the full argument and for the corpus
-- rows that pin the split in both directions.) It has to exist at all because BARE_ORFALL as
-- written matches the FIXED form too:
-- 'type(X.versions) == "table" and X.versions or {}' also contains
-- ".versions or {}". Something must clear the fixed forms.
--
-- WHAT 15e USED, AND WHY IT WAS WRONG. 15e cleared any line carrying BOTH
-- the text "type(" and the text '== "table"'. That rule asks "does this LINE
-- mention a table type-test anywhere". The question that has to be asked is
-- "is the expression being DEREFERENCED the one that was type-tested". They
-- are not the same question, and the difference IS the 15d finding:
-- SpellCache 2290, 2327 and 2388 were dangerous precisely because
-- 'if type(seqData) == "table" then' guarded the PARENT while .versions
-- stayed bare. The 15e rule cleared exactly that shape. Measured on the
-- shipped W26 on 2026-07-28, appended to UI/RawTab.lua:
--     local _probeB = entry.data.versions and #entry.data.versions or 0
--         -> RED, "UI/RawTab.lua:765"
--     local _probeA = type(entry) == "table" and entry.data.versions
--         and #entry.data.versions or 0
--         -> GREEN. A HOLE. type(entry) says nothing about
--            entry.data.versions; it raises on a scalar exactly as _probeB
--            does, and W26 could not see it because the line happened to
--            carry the two tokens the rule keyed on.
--
-- THE 15f RULE IS RECEIVER-SCOPED. For a match whose captured receiver is E,
-- the line is NOT bare only if it contains the literal text
-- 'type(E) == "table"' -- E being that exact captured expression, compared
-- with plain find (fourth argument true) and never as a pattern, because E
-- contains dots and would otherwise match any character there. This is
-- strictly STRICTER than the token rule: every line the receiver-scoped rule
-- clears was also cleared by the token rule, and the parent-type-test shape
-- above is no longer among them.
--
-- IT IS EVALUATED PER MATCH, NOT PER LINE. A line may match more than one
-- pattern, or the same pattern at more than one position, and a line that
-- correctly guards one receiver while baring another has to be flagged for
-- the bare one. Judged receivers are deduplicated within the line so two
-- patterns finding the SAME bare receiver report it once.
--
-- THE 15g RULE IS LEXICAL ON TOP OF THAT, and the per-match,
-- dedupe-by-receiver structure is unchanged from 15f. The spans are
-- computed ONCE per line, and then:
--
--   * a PATTERN MATCH counts as a site only if its START index falls
--     inside a code span. A commented-out read is text, not a site --
--     that is confusion 3, and it stops firing here.
--   * a GUARD OCCURRENCE clears the receiver only if ITS start index
--     falls inside a code span. Guard text in a comment or in a string
--     no longer clears a live read -- that is confusions 1 and 2.
--
-- A match rejected for starting outside code is NOT recorded in judged:
-- the same receiver read for real elsewhere on the line must still be
-- judged on its own merits.
--
-- SAFE_LOOKALIKE is unchanged and is still consulted AFTER the bareness
-- rule, so an allowlisted line has to be genuinely bare to be counted --
-- which is what keeps the liveness assert at the foot of W26 honest.
--
-- 15k: makeScanner() binds a FIELD and an ALLOWLIST and returns the scan
-- closure plus the pattern set it was built with, so a caller can print the
-- exact shapes its verdict rests on. The closure body is the 15h scan()
-- verbatim apart from the stats increments.
local function makeScanner(field, safeLookalike)
    local patterns = buildPatterns(field)
    local allow = safeLookalike or {}
    local function scan(src, label, offenders, seenSafe, stats)
        local lineNo = 0
        for line in (src .. "\n"):gmatch("(.-)\n") do
            lineNo = lineNo + 1
            local trimmed = line:gsub("^%s*(.-)%s*$", "%1")
            local spans = codeSpans(line)
            local norm, map = normaliseCode(line)
            local judged = {}
            for _, shape in ipairs(patterns) do
                local pos = 1
                while true do
                    local s, e, receiver = line:find(shape.pattern, pos)
                    if not s then
                        break
                    end
                    pos = e + 1
                    if startsInCode(spans, s) then
                        receiver = receiver or ""
                        if not judged[receiver] then
                            judged[receiver] = true
                            if stats then
                                stats.matched = stats.matched + 1
                                stats.matchedLines[label .. ":" .. lineNo] = true
                            end
                            if not guardedInCode(line, norm, map, spans, receiver, shape.negatedClears) then
                                if allow[trimmed] then
                                    seenSafe[trimmed] = (seenSafe[trimmed] or 0) + 1
                                    if stats then
                                        stats.allowlisted = stats.allowlisted + 1
                                    end
                                else
                                    offenders[#offenders + 1] = label .. ":" .. lineNo .. "  " .. trimmed
                                    if stats then
                                        stats.offenders = stats.offenders + 1
                                        stats.byShape[shape.name] = (stats.byShape[shape.name] or 0) + 1
                                        stats.bare[#stats.bare + 1] = {
                                            file = label,
                                            line = lineNo,
                                            shape = shape.name,
                                            receiver = receiver,
                                            text = trimmed,
                                        }
                                    end
                                end
                            elseif stats then
                                stats.cleared = stats.cleared + 1
                            end
                        end
                    end
                end
            end
        end
    end
    return scan, patterns
end

-- ===========================================================================
-- 15n: THE RESIDUAL BUCKET, and it is the first structural answer this arc has
-- had to the one limit every pass restated and no pass could discharge.
--
-- THE SHAPE SET HAS BEEN INCOMPLETE TWICE, and BOTH gaps were found by a
-- person reading code, never by the gate:
--
--   15e  BARE_ORFALL, "X.f or {}". No earlier pass scanned it. "or {}"
--        substitutes for nil and false only, so a scalar passes straight
--        through and ipairs raises on it.
--   15m  BARE_NOTLEN, the negative gate whose continuation is not " then".
--        It had been in shipped code for BOTH fields through five passes that
--        each reported zero offenders and were each, on their own terms,
--        correct: the denominator was short and nothing measured the shortfall.
--
-- A PATTERN SCAN CANNOT TELL YOU ABOUT A SHAPE NOBODY HAS THOUGHT OF. It can
-- only ever answer "how many of the shapes I already know are present", and
-- both times above the answer was zero while the tree was not clean. The
-- corpus absorbs a confusion once it is known; it has no way to surface one
-- that is not.
--
-- SO STOP ENUMERATING DANGEROUS SHAPES AND ENUMERATE THE REMAINDER. The
-- precedent is the Hub's --census: every mention lands in exactly one bucket
-- and the buckets sum, so the unexamined part of the file set has a NUMBER
-- instead of being invisible.
--
--   A  lines mentioning the field, in code
--   B  of A, matched by a pattern
--   C  of A, EXPLAINED without a pattern, by a rule written down below
--   D  of A, RESIDUAL -- neither matched nor explained
--
-- D IS NOT A DEFECT COUNT. It is the set of lines the gate HAS NO OPINION
-- ABOUT. Most of D is ordinary code and always will be. The point is that
-- shape eight lived in D for five passes, and shape nine -- if there is one --
-- is in D now, where a human can read it. Every D line is printed with its
-- file, line and text for that reason, and D is never summarised.
--
-- NOTHING HERE IS ASSERTED. Not A, not B, not C, not D, not any per-rule
-- count. This is measurement, exactly like W32 and exactly like the Hub
-- census: make the number reproducible before anyone acts on it. Turning any
-- of it into a gate would only teach the next reader to grow an allowlist
-- until it went green again.
--
-- THE C RULES, stated so they can be argued with rather than trusted. A line
-- is EXPLAINED only when EVERY occurrence of the field on it that is a genuine
-- read or write of THAT field is covered by one of these:
--
--   C1 WRITE. The field name is followed, past spaces and tabs, by a single
--      "=" that is not "==". 'X.f = v' stores; it does not dereference the
--      field. 'X.f.g = v' and 'X.f[i] = v' are NOT writes to the field -- both
--      dereference X.f first -- and neither matches this rule, because the
--      character after the field name is "." or "[" and not "=".
--
--   C2 NOT THIS FIELD. The occurrence is a lexical artifact and names no
--      field: either the character after the field name continues an
--      identifier ('.stepsCount' when the field is "steps"), or the character
--      before the dot is another dot ('a..steps' is concatenation, not an
--      index). A line whose only occurrences are artifacts mentions the field
--      nowhere.
--
--   C3 FIELD-SCOPED type() TEST. The occurrence is a read whose receiver
--      carries its own 'type(<receiver>) == "table"' -- or '~= "table"', which
--      is the same test written as an early bail -- on the same line, found by
--      guardedInCode() and therefore subject to the SAME code-span test and
--      the SAME left token boundary as every clear the gates already grant.
--      IT IS RECEIVER-SCOPED, so the 15d shape that started this arc --
--      'type(seqData) == "table"' guarding the PARENT while .versions stays
--      bare -- is NOT explained by it and lands in D.
--
-- A LINE WHOSE ONLY MENTION SITS IN A COMMENT OR A STRING never reaches C at
-- all: A is defined over code spans, so codeSpans() has already removed it
-- from the denominator. The raw-versus-code split is printed alongside so that
-- deletion is visible rather than silent.
--
-- WHERE THE RECEIVER CANNOT BE READ -- 'f(x).steps', where the expression to
-- the left of the dot is not a plain dotted name -- C3 is not attempted and
-- the line lands in D. That is deliberate: an unresolvable receiver is exactly
-- the case where "is this guarded" cannot be answered, and D is where
-- unanswered questions belong.
-- ===========================================================================

-- Every occurrence of "." .. field that STARTS IN CODE on one line, with the
-- three facts the C rules need about each: is it this field at all, is it a
-- write, and what is the receiver expression a guard would have to name.
local function fieldOccurrences(line, field, spans)
    local out = {}
    local needle = "." .. field
    local flen = #field
    local pos = 1
    while true do
        local s = line:find(needle, pos, true)
        if not s then
            break
        end
        pos = s + 1
        if startsInCode(spans, s) then
            local after = line:sub(s + 1 + flen, s + 1 + flen)
            local before = line:sub(s - 1, s - 1)
            local rest = line:sub(s + 1 + flen)
            local occ = {
                start = s,
                -- C2: an identifier character after the name continues a
                -- LONGER name, and a dot before the dot is concatenation.
                isField = not (after:find("^[%w_]") or before == "."),
                -- C1: "=" that is not "==". A "~", "<" or ">" ahead of the
                -- "=" fails the first test, so the comparison operators are
                -- excluded by the same check rather than by a second list.
                isWrite = rest:find("^[ \t]*=") ~= nil and rest:find("^[ \t]*==") == nil,
            }
            if occ.isField then
                local prefix = line:sub(1, s - 1):match("([%w_%.]+)$")
                -- A prefix that itself begins with "." is the tail of an
                -- expression this walk cannot see the head of -- 'f(x).data'
                -- captures ".data" -- so the receiver is left unresolvable
                -- rather than guessed.
                if prefix and prefix:sub(1, 1) ~= "." then
                    occ.receiver = prefix .. needle
                end
            end
            out[#out + 1] = occ
        end
    end
    return out
end

-- A, B, C and D over a file set, plus the per-rule split of C and the full D
-- listing. matchedLines is the set filled by scan(); passing the set rather
-- than re-running the patterns is what keeps B EXACTLY the lines the gate
-- matched, with no second implementation to drift.
local function residualBuckets(field, fileSet, sources, matchedLines)
    local res = {
        rawA = 0,
        A = 0,
        B = 0,
        C = 0,
        D = 0,
        matchedOutsideA = 0,
        cWrite = 0,
        cToken = 0,
        cGuarded = 0,
        dLines = {},
        perFileD = {},
        perFileDOrder = {},
    }
    for _, rel in ipairs(fileSet) do
        local lineNo = 0
        for line in (sources[rel] .. "\n"):gmatch("(.-)\n") do
            lineNo = lineNo + 1
            local key = rel .. ":" .. lineNo
            local spans = codeSpans(line)
            local occs = fieldOccurrences(line, field, spans)
            -- The RAW denominator, so a hand grep reconciles and so the lines
            -- codeSpans() removes from A are a printed number rather than a
            -- silent deletion.
            if line:find("." .. field, 1, true) then
                res.rawA = res.rawA + 1
            end
            if #occs > 0 then
                res.A = res.A + 1
                if matchedLines[key] then
                    res.B = res.B + 1
                else
                    local norm, map = normaliseCode(line)
                    local real, allExplained, allWrite, anyGuard = 0, true, true, false
                    for _, occ in ipairs(occs) do
                        if occ.isField then
                            real = real + 1
                            local guarded = occ.receiver ~= nil
                                and guardedInCode(line, norm, map, spans, occ.receiver, true)
                            if guarded then
                                anyGuard = true
                            end
                            if not occ.isWrite then
                                allWrite = false
                                if not guarded then
                                    allExplained = false
                                end
                            end
                        end
                    end
                    if real == 0 then
                        res.C = res.C + 1
                        res.cToken = res.cToken + 1
                    elseif allExplained and allWrite then
                        res.C = res.C + 1
                        res.cWrite = res.cWrite + 1
                    elseif allExplained and anyGuard then
                        res.C = res.C + 1
                        res.cGuarded = res.cGuarded + 1
                    else
                        res.D = res.D + 1
                        if not res.perFileD[rel] then
                            res.perFileDOrder[#res.perFileDOrder + 1] = rel
                        end
                        res.perFileD[rel] = (res.perFileD[rel] or 0) + 1
                        res.dLines[#res.dLines + 1] =
                            { file = rel, line = lineNo, text = line:gsub("^%s*(.-)%s*$", "%1") }
                    end
                end
            elseif matchedLines[key] then
                -- A pattern match on a line with no CODE mention of the dotted
                -- field. BARE_LEN, BARE_PAREN and BARE_NOTLEN use the
                -- either-case class and so also see the LOCAL-BOUND spelling
                -- ('not compiledSteps or #compiledSteps'), which contains no
                -- ".steps" at all. Printed rather than folded into B, because
                -- B is defined as a subset of A and this is not one.
                res.matchedOutsideA = res.matchedOutsideA + 1
            end
        end
    end
    return res
end

local function printResidual(field, res)
    print(string.format("  ---- .%s A/B/C/D residual bucket -- MEASUREMENT ONLY, nothing here is asserted ----", field))
    print(
        string.format(
            "    raw lines mentioning .%s (code + comment + string)     : %d   [%d removed by codeSpans]",
            field,
            res.rawA,
            res.rawA - res.A
        )
    )
    print(string.format("    A  lines mentioning .%s, in CODE                       : %d", field, res.A))
    print(string.format("    B  of A, matched by a pattern                          : %d", res.B))
    print(string.format("    C  of A, EXPLAINED without a pattern                   : %d", res.C))
    print(string.format("         C1 WRITE           '.%s' then a single '='       : %d", field, res.cWrite))
    print(string.format("         C2 NOT THIS FIELD  '.%sXxx' or '..%s'            : %d", field, field, res.cToken))
    print(string.format("         C3 TYPE-TESTED      receiver-scoped type() test   : %d", res.cGuarded))
    print(string.format("    D  of A, RESIDUAL -- neither matched nor explained     : %d", res.D))
    print(
        string.format(
            "    buckets sum: A == B + C + D  ->  %d == %d  (%s)",
            res.A,
            res.B + res.C + res.D,
            res.A == res.B + res.C + res.D and "yes" or "NO -- the bucketing is broken, read it"
        )
    )
    print(
        string.format(
            "    pattern matches on lines with NO code mention of .%s   : %d  (local-bound spellings)",
            field,
            res.matchedOutsideA
        )
    )
    print("    D IS NOT A DEFECT COUNT. It is the set of lines the gate has no opinion about.")
    if res.D == 0 then
        print("    ---- D listing: EMPTY ----")
        return
    end
    print("    ---- D listing, per file ----")
    for _, rel in ipairs(res.perFileDOrder) do
        print(string.format("      %-32s %3d", rel, res.perFileD[rel]))
    end
    print(string.format("    ---- D listing, every line (%d) ----", res.D))
    for _, d in ipairs(res.dLines) do
        print(string.format("      %s:%d  %s", d.file, d.line, d.text))
    end
end

test("W26: no bare-truthiness .versions read survives in any shipped file", function()
    -- =====================================================================
    -- 15n: THE SHAPE SET HAS BEEN INCOMPLETE TWICE, AND BOTH TIMES A PERSON
    -- FOUND IT, NOT THIS GATE. Read this before quoting "offenders=0" as
    -- though it meant the field is clean.
    --
    --   15e  BARE_ORFALL, "X.versions or {}", scanned by no earlier pass.
    --   15m  BARE_NOTLEN, the negative gate whose continuation is not
    --        " then", live in shipped code for BOTH fields through five
    --        passes that each reported zero and were each correct on their
    --        own terms.
    --
    -- Neither was surfaced by adding a pattern; both were surfaced by someone
    -- reading code and noticing a spelling. A pattern scan answers only "how
    -- many of the shapes I already know are present", so it can report zero
    -- while the tree is not clean, and it did -- twice.
    --
    -- SO THIS CASE NOW ALSO PRINTS A RESIDUAL BUCKET, at its foot, next to the
    -- four census numbers. Every in-code mention of the field lands in exactly
    -- one of A (mentions), B (matched by a pattern), C (explained by a written
    -- rule) or D (neither), and the four sum. D IS NOT A DEFECT COUNT -- it is
    -- the set of lines this gate HAS NO OPINION ABOUT, and it must not be
    -- driven to zero. It exists so that the THIRD missing shape is found by
    -- counting rather than by luck: BARE_ORFALL sat in D until 15e and
    -- BARE_NOTLEN sat in D until 15m, and in both cases nothing anywhere
    -- recorded how big that unexamined remainder was. Now it has a number and
    -- a printed listing a human can read. See the block above buildPatterns()
    -- for the C rules and why each is provable rather than a judgement call.
    --
    -- WHAT IS ASSERTED HERE IS UNCHANGED: zero offenders, the pinned needles,
    -- a live allowlist. A, B, C and D assert nothing, exactly like W32.
    --
    -- 15m: THE DENOMINATOR CHANGED. READ THIS BEFORE COMPARING ANY NUMBER
    -- IN THIS CASE AGAINST A PASS BEFORE 15m.
    --
    --                     15c..15l (7 shapes)     15m (8 shapes)
    --   matched                    26                   28
    --   cleared                    24                   26
    --   allowlisted                 2                    2
    --   offenders                   0                    0
    --   corpus rows          36 / 23 / 12 / 1     40 / 25 / 14 / 1
    --
    -- BOTH COLUMNS ARE TRUE. Nothing in the nineteen files changed for this
    -- and no site moved between buckets: the left column is what SEVEN
    -- patterns could see and the right is what EIGHT can. The two extra
    -- matched lines are two extra CLEARED lines -- offenders is still zero,
    -- which is the number that carries the verdict.
    --
    -- WHAT THE SEVEN COULD NOT SEE, and it is the finding this pass exists
    -- for. Both lines are in Import/ImportPreview.lua and both are SAFE:
    --     :140   if not seq or not seq.versions or type(seq.versions) ~= "table" then
    --     :1264  if not seq.versions or type(seq.versions) ~= "table" or not next(seq.versions) then
    -- They are the eighth shape -- a NEGATIVE gate whose continuation is not
    -- " then" -- and BARE_GATE anchors on " then", so no pattern in the set
    -- matched either of them. THEY WERE NEVER AMONG THE 26. So "26 matched,
    -- 24 cleared, 2 allowlisted, 0 offenders", quoted verbatim in five
    -- consecutive passes, was TRUE AND ITS DENOMINATOR WAS TWO LINES SHORT.
    -- The .versions family was clean by the discipline of whoever wrote those
    -- two lines, not because this gate had checked them. That distinction is
    -- the whole reason the arc kept going after 15h reported zero.
    --
    -- THE ONE NUMBER THAT COULD HAVE INVALIDATED FIVE PASSES IS offenders,
    -- and it is still 0 with the eighth shape scanning. Had either new line
    -- been bare, the correct report would have been that a .versions site had
    -- been bare all along and every "residue is zero" claim since 15e was
    -- wrong. It was not. Measured 2026-07-28, this pass, in that order.
    --
    -- 15o: THE DENOMINATOR MOVED AGAIN, AND THE SAME NUMBER STILL CARRIES THE
    -- VERDICT. A NINTH shape joins the set, so read this before comparing any
    -- number here against a pass before 15o. The 15m column above is kept
    -- exactly as written; this is a third column, not a correction.
    --
    --                     15m (8 shapes)          15o (9 shapes)
    --   matched                    28                   42
    --   cleared                    26                   40
    --   allowlisted                 2                    2
    --   offenders                   0                    0
    --   corpus rows          40 / 25 / 14 / 1     44 / 28 / 15 / 1
    --
    -- THE FOURTEEN NEW MATCHES ARE FOURTEEN NEW CLEARS. Every .versions
    -- instance of the ninth shape is written
    --     if seqData.versions and type(seqData.versions) == "table" then
    -- -- redundant, and safe -- so all fourteen were already in C3 and simply
    -- move to B. offenders is STILL 0 with the ninth shape scanning, and that
    -- is again the one number that could have invalidated the arc: had any of
    -- the fourteen been bare, the correct report would have been that a
    -- .versions site had been bare through six passes. It was not.
    --
    -- ALL FIVE FIELDS, A/B/C/D, 15n NEXT TO 15o. The middle column is the
    -- ninth PATTERN alone and the right column adds the THREE FIXES, so the
    -- two effects are separable rather than summed. Fields are kept apart:
    -- these are per-field buckets and adding them across fields double-counts
    -- lines that mention two fields.
    --
    --   field         pass    A     B     C  (C1/C2/C3)     D
    --   .versions     15n    237    28    71 ( 4/ 1/66)    138
    --                 +9th   237    42    57 ( 4/ 1/52)    138
    --                 +fix   237    42    57 ( 4/ 1/52)    138   (no .versions site fixed)
    --   .steps        15n    274    65    71 (13/16/42)    138
    --                 +9th   274    69    68 (13/16/39)    137
    --                 +fix   274    68    69 (13/16/40)    137
    --   .actions      15n     62    14     8 ( 3/ 0/ 5)     40
    --                 +9th    62    17     7 ( 3/ 0/ 4)     38
    --                 +fix    62    16     8 ( 3/ 0/ 5)     38
    --   .stepLabels   15n     28     5     7 ( 7/ 0/ 0)     16
    --                 +9th    28     6     7 ( 7/ 0/ 0)     15
    --                 +fix    28     5     8 ( 7/ 0/ 1)     15
    --   .taggedSteps  15n     31     7    14 ( 8/ 3/ 3)     10
    --                 +9th    31     8    14 ( 8/ 3/ 3)      9
    --                 +fix    31     8    14 ( 8/ 3/ 3)      9
    --
    -- A NEVER MOVES, and that is the check on the other three: no line was
    -- added to or removed from any file set this pass, so any A that had moved
    -- would mean the walk changed rather than the code.
    --
    -- D FELL BY EXACTLY FIVE, one per D-bucket instance of the ninth shape --
    -- .steps 138->137, .actions 40->38, .stepLabels 16->15, .taggedSteps
    -- 10->9, .versions unchanged at 138. That is the residual bucket doing the
    -- job it was built for: it is not a defect count, it is the reading list,
    -- and five of its lines have now been read.
    --
    -- A FIX MOVES A LINE BACK OUT OF B, which looks backwards and is not. The
    -- fixed spelling 'if type(X.f) == "table" and ...' no longer matches ANY
    -- of the nine shapes -- there is no bare read left to match -- so the line
    -- lands in C3 instead. B down one and C3 up one, per fix, is what a
    -- successful fix looks like in these buckets.
    --
    -- matched / cleared / allowlisted / BARE, same three columns:
    --   .versions      28/26/2/0   ->  42/40/2/0   ->  42/40/2/0
    --   .steps         79/ 9/0/70  ->  83/12/0/71  ->  82/12/0/70
    --   .actions       15/ 0/0/15  ->  18/ 1/0/17  ->  17/ 1/0/16
    --   .stepLabels     5/ 0/0/5   ->   6/ 0/0/6   ->   5/ 0/0/5
    --   .taggedSteps    7/ 0/0/7   ->   8/ 0/0/8   ->   8/ 0/0/8
    --
    -- type()-tested occurrences in code, '== "table"' / '~= "table"',
    -- 15n -> 15o: .steps 48/13 -> 49/13, .actions 5/6 -> 6/6, .stepLabels
    -- 0/0 -> 1/0, .taggedSteps 3/0 -> 3/0. The .stepLabels row is the one to
    -- read: see the head-of-file note on why that field is the least defended
    -- of the five.
    --
    -- TWO NINTH-SHAPE SITES ARE REPORTED AND NOT FIXED, deliberately, because
    -- a fix applied without reading the site moves a crash instead of removing
    -- it and this arc has rediscovered that three times:
    --   Engine/TempoAdvisor.lua:987  if ver.actions and (stepFunction == ...
    --   Core/Core.lua:1101           if version.taggedSteps and version.stepsLocale then
    -- Both are still printed by W34 under BARE_CONJGATE. They are the next
    -- pass, not this one.
    -- =====================================================================
    --
    -- WHAT THIS CASE CAN AND CANNOT DO, up front, so a green is not read for
    -- more than it carries.
    --
    -- THIS CASE ITSELF DRIVES NOTHING. It reads BYTES. That has not changed and
    -- must not be read as having changed -- but the claim this note carried
    -- from 15c through 15h, that NO site in the family has behavioural proof
    -- and that the harness each would need does not exist, WAS STALE BY 15e AND
    -- IS CORRECTED HERE IN 15i. It was written for the 15c/15d file set, which
    -- was almost entirely UI. The 15e set is not: twenty-two of the forty-five
    -- guards this arc shipped live in modules the MODULES table above ALREADY
    -- LOADS, and RepairAnalyzer was already being DRIVEN from this file -- the
    -- priming RA:AnalyzeAll, W4's RA:CheckCrossSeq, W5's RA:CheckStructure,
    -- W8's RA:CheckActions -- with well-formed data. Nothing was missing but
    -- fixtures that pass a SCALAR. W27 to W31 are those fixtures.
    --
    -- WHAT IS BEHAVIOURALLY PROVEN, twenty guards (sixteen after 15i, four more
    -- in 15j). Every row was MEASURED on 2026-07-28 by reverting that one line
    -- to bare truthiness, running the suite, and restoring byte-identically
    -- (sha256 verified). A row is listed here only if a case OTHER than this one
    -- went red, and only if it went red with a RAISE naming that line. NOT EVERY
    -- ROW'S PROOF LIVES IN THIS FILE: the four Engine rows are pinned from
    -- Test/test_stepadv_numsteps_domain.lua, which loads the real Engine.lua --
    -- this file never does, and its Engine STUB could not pin them:
    --   RepairAnalyzer 13   :174 CheckSpells, :697 CheckLimits, :850
    --                       CheckVariables, :1015 CheckActions, :1065
    --                       CheckConfig, :1105 CheckLocale, :1192 and :1238
    --                       CheckReadiness, :1270 CheckPostSub, :1340
    --                       CheckStateSync  -> W27 and W28
    --                       :1454, :1474, :1485 CheckCrossSeq  -> W28 and W29
    --   Defaults 1          :3918 NewSequenceFromTemplate  -> W30
    --   GRIPExport 1        :524 GE.Export's interleave pre-check  -> W25
    --   ImportPreview 1     :1174 BuildSeqDataFromGRIP1's locale walk  -> W31
    --   Engine 4 (15j)      :2724 UpdateSequenceData, the SAVE path  -> E1
    --                       :2983 HealLocaleSteps  -> E2
    --                       :3068 HealOverrideSteps  -> E3
    --                       :3201 DuplicateSequence  -> E4
    --                       all four in Test/test_stepadv_numsteps_domain.lua
    -- One guard shipped in 15j is NOT one of the forty-five and so is not
    -- counted in any total here: Data/Defaults.lua:3976, the template steps
    -- walk. It is in the .steps family, not the .versions one. Proven the same
    -- way, by the STEPS SHAPES block in W30 above.
    -- 15k ADDS TWO MORE GUARDS THAT ARE NOT AMONG THE FORTY-FIVE, and the
    -- running total is deliberately unmoved at twenty. Data/Defaults.lua:4002
    -- (D.CopyVersion's steps deep-copy) is .steps family, proven by W33.
    -- Data/Defaults.lua:3919's ver1 element test is .versions family but is a
    -- NEW guard rather than one of the forty-five the 15c-to-15e sweep fixed;
    -- it is proven by the VERSIONS[1] SHAPES block in W30. The forty-five row
    -- for this file is the CONTAINER test, which still stands and is still
    -- proven by W30's FALLBACK_ROWS -- it just no longer stands alone.
    -- Two further reads that are not 15e needles but are what make two of the
    -- look-alikes safe are proven the same way: GRIPExport :1119 (-> W17) and
    -- ImportPreview :512 (-> W31).
    --
    -- WHAT REMAINS SOURCE-ONLY THOUGH ITS MODULE IS LOADED BY SOME HARNESS,
    -- seven guards, each with the measured reason it stayed green when reverted:
    --   RepairAnalyzer :397, :404, :439  CheckLegacySlotNames. NOT REACHABLE
    --       FROM THIS HARNESS BY DESIGN. The function builds slotNameMap from
    --       C_Spell.GetSpellName and returns at :284 when the map is empty, and
    --       C_Spell is an ALLOWED_UNKNOWN row precisely because this harness
    --       covers the API-ABSENT branch. Reaching these three means stubbing
    --       C_Spell, which flips that stance for GRIPExport :942 and
    --       LegacyImport :1850 as well. That is a harness decision, not a
    --       fixture, and it is not taken here.
    --   GRIPExport :1120 and ImportPreview :515  THE TWO LOOK-ALIKES. Both read
    --       a LOCAL that a type() test one or three lines above already bound
    --       to nil for a scalar, so reverting either ALONE changes no observable
    --       -- measured green. They are unfalsifiable in isolation by
    --       construction; their protectors (:1119 and :512) are proven above.
    --   ImportPreview :1360  UNREACHABLE BY CONSTRUCTION. Its seqData.versions
    --       is built as a table LITERAL at ImportPreview.lua:1338, twenty-two
    --       lines above, in the RAW arm of CommitSelected. No input makes that
    --       field a scalar, so no fixture can falsify it without faking the
    --       literal.
    --   Engine :1407  THE THIRD LOOK-ALIKE, measured in 15j from
    --       Test/test_stepadv_numsteps_domain.lua -- the file that DOES load the
    --       real Engine, so this is a measured result and not a file-not-loaded
    --       excuse. The line is
    --           if resolvedVer and type(sequenceData.versions) == "table" then
    --       and resolvedVer is Engine:GetActiveVersion(sequenceData) from :1405,
    --       whose own head check (Engine.lua:735, pinned by G1 in that file)
    --       already returns nil for EVERY non-table versions. The first operand
    --       is therefore false in exactly the cases where the second would
    --       matter. Reverting it alone left that whole file at 23 passed / 0
    --       failed, byte-restored and sha256-verified. Same shape as the two
    --       look-alikes above: unfalsifiable in isolation, protector proven.
    --
    -- WHAT REMAINS SOURCE-ONLY BECAUSE THE FILE IS NOT LOADED BY ANY HARNESS,
    -- eighteen guards (twenty-three before 15j discharged the Engine row below).
    -- What each would need:
    --   Core/Core.lua      x3  load Core.lua and drive the /gems decompress arm
    --                          of the slash dispatcher.
    --   Core/PublicAPI.lua x1  stand up GRIPEMS.API plus a live Engine.sequences.
    --   Data/SpellCache.lua x3 load SpellCache AND populate SC.byName plus a
    --                          live Engine.sequences with bound buttons.
    --   Engine/Engine.lua  x5  DISCHARGED IN 15j, and kept here as the record of
    --                          what this note used to claim. It read: "the real
    --                          Engine, secure buttons and a live SavedVariables
    --                          surface (see G1, below)". Two of those three were
    --                          not needed. Four of the five are now
    --                          behaviourally proven from
    --                          Test/test_stepadv_numsteps_domain.lua (E1 to E4,
    --                          listed above) and the fifth, Engine.lua:1407, is the
    --                          look-alike listed in the previous block. No
    --                          secure button was required for any of them; what
    --                          WAS required was a real GRIP_EMS_CHAR table,
    --                          because the sandbox's catch-all stub is truthy
    --                          and let two of the walks pass their own guard and
    --                          then iterate nothing.
    --   UI/ContextTab.lua      load the UI file AND stand up enough of the
    --   UI/SequenceList.lua    frame / AceGUI surface for the callbacks that
    --   UI/SequenceEditor.lua  hold these reads to be callable at all.
    --   UI/PopupEditor.lua     Eleven guards across the five UI files.
    --   UI/TrackerHUD.lua
    -- No fixture is faked for any of them. Same honesty W24 keeps about the
    -- Engine: W24's rows resolve through the Engine STUB, so they cannot pin
    -- the real function, and G1 in Test/test_stepadv_numsteps_domain.lua --
    -- which loads the REAL Engine.lua -- is what pins it.
    --
    -- THE 15i NEXT-CANDIDATE NOTE IS DISCHARGED, and the measurement it asked
    -- for is what settled it. It read: "Engine/Engine.lua IS loaded by
    -- Test/test_stepadv_numsteps_domain.lua, so its FIVE guards are probably
    -- reachable from THAT file ... Anyone picking it up should measure first --
    -- revert one of the five, run that file, and see whether anything goes red
    -- -- because 'the module is loaded' is exactly the assumption this note was
    -- wrong about for four passes." Pass 15j measured, and "probably" was right
    -- for four of the five and WRONG for the fifth. E1 to E4 in that file pin
    -- Engine.lua:2724, :2983, :3068 and :3201, each falsified by reverting its own line
    -- and seeing exactly one case go red with a raise naming it. :1407 stayed
    -- green under revert, and the reason is structural rather than a missing
    -- fixture, so it is recorded above as a look-alike and NOT counted. A
    -- truthful four of five is what this note is for.
    --
    -- THE NEXT CANDIDATE after 15j, on the same terms. The eighteen remaining
    -- source-only guards all sit in files no harness loads, and eleven of the
    -- eighteen are in the five UI files -- which need an AceGUI / frame surface
    -- stood up before their callbacks are callable at all, a much larger step
    -- than the one 15j took. The cheapest next three are Core/PublicAPI.lua x1
    -- (stand up GRIPEMS.API over a live Engine.sequences) and Data/SpellCache.lua
    -- x3. Measure first, the same way: revert one line, run, see what reddens.
    --
    -- Twenty of forty-five behaviourally proven, twenty-five source-only.
    -- Source-only split: seven whose module a harness loads but which are
    -- unfalsifiable or out of reach for the measured reasons above
    -- (RepairAnalyzer :397/:404/:439, GRIPExport :1120, ImportPreview :515 and
    -- :1331, Engine :1407), and eighteen in files no harness loads
    -- (Core/Core.lua x3, Core/PublicAPI.lua x1, Data/SpellCache.lua x3, and
    -- eleven across the five UI files).
    --
    -- What THIS case reaches is the product SOURCE, and that is what it asserts
    -- on. Precedent: Test/test_slash_builtin_drift.lua reads Core/Core.lua with
    -- io.open and asserts on its text. A source pin is strictly WEAKER than a
    -- behavioural one -- it proves the guard is WRITTEN, not that it WORKS --
    -- but it is the only thing that covers all forty-five, and it is fully
    -- falsifiable: revert any one of the sites and this case names the file and
    -- the line. The 2026-07-28 sweep confirmed that too -- all twenty-four
    -- reverts turned this case red, including the six no behavioural case sees.
    --
    -- THE 15c KNOWN-RESIDUE NOTE IS DISCHARGED. It read: "UI/TrackerHUD.lua:653
    -- and :730 carry the same defect in a parenthesised spelling, which the
    -- narrow pattern below does not match. Widen the pattern in the same commit
    -- that fixes them, not before: a scan that ships red proves nothing." Pass
    -- 15d fixed both and the pattern is widened here, in that same commit.
    --
    -- WHAT THIS SCAN COVERS AFTER 15e, replacing the 15d boundary note that
    -- said two shapes were still unscanned. None are.
    --   * ALL SEVEN SPELLINGS are scanned: the inline "#" read, the
    --     parenthesised "#" read, the NEGATIVE gate, the CONJUNCTIVE positive
    --     gate, the BARE POSITIVE gate, the "or {}" FALLBACK, and the
    --     same-expression INDEX. BARE_ANDGATE is no longer narrowed for
    --     diagnostics only -- after 15e no conjunctive bare gate exists either,
    --     so it can flag freely.
    --   * THE FILE SET IS EVERY SHIPPED .lua THAT MENTIONS THE FIELD, all
    --     nineteen of them, not just the files an edit pass touched. Twelve of
    --     the nineteen carry no needles at all: they are in the list purely so
    --     ABSENCE is enforced there. That is the point of growing the set -- 15c
    --     missed TrackerHUD and 15d missed Engine.lua because neither file was
    --     in the scan set of the pass before it.
    --   * RESIDUE IS ZERO. The only allowlisted lines are UI/SequenceList.lua
    --     972 and 988. Both sit inside "if ver then", and since 15b a scalar
    --     .versions cannot produce a truthy ver, so neither line is reachable
    --     with one.
    --   * THE ONE THING THIS STILL CANNOT PROVE is a SIXTH... a SEVENTH... an
    --     Nth spelling nobody has thought of. A pattern scan can only find the
    --     shapes it encodes, and no amount of green here rules out a shape that
    --     was never written down. The mitigation is not a better pattern, it is
    --     the file set: every file that touches the field is now under
    --     observation, so a novel spelling has to be written into a file this
    --     case already reads, where the next widening will see it.
    --   * NOR CAN IT SEE A GUARD SPLIT ACROSS LINES. The scan reads one line at
    --     a time, so 'if type(x) == "table"' on one line and a bare read on its
    --     continuation are invisible to each other -- in BOTH directions. The
    --     shipped instance is UI/TrackerHUD.lua 742-743, where the type test and
    --     the "#" read sit on separate lines of one wrapped expression; it goes
    --     unflagged not because the scan understands it but because the wrap
    --     also breaks every pattern (BARE_LEN needs "versions and #" on one
    --     line). What pins that pair is the PRESENCE needle, which carries the
    --     newline and is matched across it with plain find. The badge block at
    --     TrackerHUD 659 is the other spelling -- test and read on ONE line --
    --     and that one the receiver-scoped rule does judge. A bare read written
    --     on a continuation line would be missed today.
    --   * NOR A RECEIVER BOUND TO A LOCAL SEVERAL LINES EARLIER. The scan reads
    --     text, not bindings. Import/ImportPreview.lua 515 and
    --     Import/GRIPExport.lua 1120 are the local-receiver instances that the
    --     scan's own vocabulary covers: both read a LOCAL named versions, and
    --     both are safe. But the type() test that makes them safe is the one on
    --     the binding -- ImportPreview 512 and GRIPExport 1119, three lines and
    --     one line above them -- and the scan cannot see it. Stronger still,
    --     ImportPreview 513 and 526 are genuinely BARE truthiness reads on that
    --     local ("payloadVersions and payloadVersions[...]"), safe for the same
    --     reason and matched by NO pattern here, because BARE_INDEX requires the
    --     dotted ".versions" spelling. On all four the scan is trusting the
    --     reader, and the hand audit of 2026-07-28 is that reader.
    --   * 15f RECORD, so the next pass does not re-derive it. The 15e bareness
    --     rule was RECEIVER-BLIND -- it cleared any line carrying "type(" and
    --     '== "table"' anywhere, which is not the question that needed asking
    --     (see scan() below). It was specified that way by the brief that
    --     commissioned 15e, and the code implemented the specification exactly.
    --     The hole was MEASURED on the shipped 15e W26 on 2026-07-28 before it
    --     was fixed, with the probe row now standing at PROBE line 16, and again
    --     on the real UI/RawTab.lua. THE PRODUCT WAS CLEAN WHEN THE HOLE WAS
    --     FOUND: all 76 shipped lines carrying both tokens were read by hand on
    --     2026-07-28 and every one type-tests the FIELD it dereferences, so this
    --     is a GATE fix, not a defect fix. Nothing in the nineteen files changed
    --     for it, and the receiver-scoped rule reports the same zero.
    --   * THE SCAN IS LEXICAL AS OF 15g. Up to and including 15f it was a
    --     literal search over RAW LINE TEXT with no notion of which part of a
    --     line was code, so it could not tell a read from a remark about a
    --     read, nor one correct spelling of the guard from another. It now
    --     computes the CODE SPANS of each line -- strings and comments
    --     excluded, in all their forms -- and requires BOTH the pattern match
    --     and the guard to START inside one; and it compares the guard after
    --     normalising whitespace and quote style on both sides, so
    --     'type(E)=="table"' and "type(E) == 'table'" clear exactly as the
    --     canonical form does while 'type(E) ~= "table"' still does not. The
    --     four confusions this closed were MEASURED on the shipped 15f gate
    --     and are now permanent rows in the confusion corpus below, which is
    --     where the next one goes too. THE PRODUCT WAS CLEAN AGAIN: over the
    --     nineteen files the lexical scan reports the same 26 matched, 24
    --     cleared, 2 allowlisted, 0 offenders, and none of the 24 clears ever
    --     depended on a comment.
    --   * THE NEEDLE IS TOKEN-BOUNDED ON THE LEFT AS OF 15h. Through 15g the
    --     guard search was a plain SUBSTRING search, so any identifier ENDING
    --     in "type" satisfied it -- 'myvaluetype(E) == "table"' cleared a bare
    --     read of E, MEASURED GREEN on the shipped 15g gate against the real
    --     UI/RawTab.lua, with 'type(other.versions) == "table"' over the same
    --     read correctly RED as the control. An occurrence now also requires
    --     that the character immediately to its left is not a letter, digit,
    --     "_" or "." -- the dot because 'D.type(x)' calls a FIELD named type
    --     and not the global. THAT TEST IS MADE AGAINST THE ORIGINAL TEXT
    --     THROUGH THE INDEX MAP, never against the normalised copy, because
    --     normalisation removes whitespace runs and so DESTROYS token
    --     boundaries: 'and type(x.versions)' normalises to
    --     'andtype(x.versions)' and a boundary test there would reject real
    --     guards. THE PRODUCT WAS CLEAN ONCE MORE: all 24 shipped clears were
    --     re-measured under the rule and every one carries "(" or a space
    --     before "type(" in what was actually written, so the verdict over the
    --     nineteen files is unchanged at 26 matched, 24 cleared, 2 allowlisted,
    --     0 offenders. Nothing shipped was edited for this.
    --   * THE CORPUS NOW COVERS EVERY CONFUSION FOUND IN 15e, 15f, 15g AND 15h,
    --     thirty-six rows of it, including the ten lexer behaviours that were
    --     already CORRECT in 15g and had never been pinned. THE RULE FROM HERE,
    --     stated plainly: A FURTHER FIND IS A ROW, NOT A PASS. The gate now has
    --     lexical spans, receiver scoping and token boundaries; a newly noticed
    --     confusion that any of those three already handles is banked as a
    --     corpus row in the commit that notices it and nothing else changes.
    --     Only a confusion that needs a NEW MECHANISM -- something none of the
    --     three can express, such as the cross-line limits below -- earns
    --     another pass.
    --   * THE CEILING, and it is the LAST one -- measured on the shipped 15h
    --     gate on 2026-07-28 and deliberately NOT patched. Two lines clear that
    --     a dominance-aware reader would flag:
    --         if not type(x.versions) == "table" then ... bare read ...
    --         local f = function() return type(x.versions) == "table" end
    --             local n = x.versions and #x.versions or 0
    --     Neither is a shape confusion, and no eighth pattern would fix them.
    --     They are the same single limit: THE GATE CHECKS THAT A GUARD
    --     CO-OCCURS WITH A READ ON ONE LINE. IT CANNOT CHECK THAT THE GUARD
    --     DOMINATES THE READ. Dominance is a control-flow property and this
    --     scan is one line of text; same-line co-occurrence is a good proxy
    --     ONLY because the shipped style writes guard and read in one
    --     expression. Neither shape exists in shipped code -- "not type(" is
    --     zero across every shipped .lua -- so there is nothing to fix and no
    --     corpus row is added for either: a row would pin a confusion the gate
    --     is not built to resolve, and the RULE stated below is that a find
    --     needing a NEW MECHANISM earns a pass, not a row. This one earns
    --     neither, because the mitigation is not a better pattern. IT IS
    --     BEHAVIOURAL COVERAGE -- a guard that does not dominate its read
    --     raises when the read runs, and a case that drives the read sees it.
    --     That is what pass 15i starts, and sixteen of forty-five is how far it
    --     got; 15j took it to twenty. The live tally is in the note at the head
    --     of this case -- these two sentences are the record of each pass and
    --     are not the running total.
    --   * WHAT IS STILL OUT OF REACH, all four of them, unchanged by 15h --
    --     none of the eleven rows it banked is a new limit, ten being pinned
    --     behaviours and one a fix -- so the next pass does not have to
    --     re-derive the list:
    --       1. AN Nth SPELLING NOBODY HAS WRITTEN DOWN. A pattern scan finds
    --          the shapes it encodes and no green here rules out one that was
    --          never written. The mitigation is the file set, not the pattern.
    --       2. A GUARD SPLIT ACROSS LINES. UI/TrackerHUD.lua 742-743 is the
    --          shipped instance; it is unflagged not because the scan
    --          understands it but because the wrap also breaks every pattern.
    --       3. A RECEIVER BOUND TO A LOCAL SEVERAL LINES EARLIER.
    --          Import/ImportPreview.lua 513 and 526 are the shipped instances.
    --          The scan reads text, not bindings.
    --       4. A STRING OR COMMENT CONSTRUCT THAT OPENS ON ONE LINE AND CLOSES
    --          ON ANOTHER. codeSpans() is line-scoped: an unterminated long
    --          string or long comment ends the code spans for that line, and
    --          the CONTINUATION lines are lexed from scratch as if they began
    --          in code. A bare read written inside a multi-line long string
    --          would be reported, and a guard written there would clear.
    --
    -- 15k BOUNDARY NOTE, three entries, and the first is the one that matters.
    --
    --   * LIMIT 3 IS NO LONGER THEORETICAL. It has been carried since 15g as
    --     "a receiver bound to a local several lines earlier -- the scan reads
    --     text, not bindings", illustrated only by ImportPreview 513 and 526,
    --     which are SAFE. As of this pass it has a REAL DEFECT inside it, and
    --     that is worth more than a limit that stays hypothetical.
    --     Data/Defaults.lua:3927 read ver1.stepFunction where ver1 was bound
    --     eight lines earlier by
    --         local ver1 = type(tmpl.versions) == "table" and tmpl.versions[1]
    --             or D.NewVersion
    --     -- the 15e guard, which type-tests the CONTAINER and says nothing
    --     about the element. A template carrying versions = {5} clears it and
    --     binds ver1 to a number, and the raise lands FORTY-NINE LINES ABOVE
    --     the steps walk 15j had just fixed. This case could never have
    --     reported it: the binding is on one line, the eight reads are on
    --     others, and no pattern here spans lines. The needle for that site is
    --     now two needles, both pinned in SITES, and the behaviour is pinned by
    --     the VERSIONS[1] SHAPES block in W30. THE GENERAL LESSON, which is not
    --     specific to this file: a source gate that clears a guarded BINDING
    --     says nothing about the reads of the local it binds, and this arc has
    --     now shipped one defect of exactly that shape.
    --
    --   * THE SCANNER IS FIELD-PARAMETERISED. Everything this case runs on --
    --     the seven shapes, codeSpans, normaliseCode, the left token boundary,
    --     the receiver-scoped bareness rule -- moved to file scope above and is
    --     built from a FIELD NAME argument. For "versions" nothing moved: 26
    --     matched, 24 cleared, 2 allowlisted, 0 offenders over the same
    --     nineteen files, and the corpus is still 36 rows / 23 / 12 / 1 with
    --     every row passing. That is now PRINTED by this case rather than
    --     asserted in prose -- see the census at its foot.
    --
    -- 15m BOUNDARY NOTE, one entry, and LIMIT 1 IS NO LONGER THEORETICAL
    -- EITHER.
    --
    --   * "AN Nth SPELLING NOBODY HAS WRITTEN DOWN" -- limit 1 in the list
    --     above, carried since 15e as the thing a pattern scan can never rule
    --     out -- WAS FOUND, in shipped code, for BOTH fields at once. It is
    --     the negative gate whose continuation is not " then", now scanned as
    --     BARE_NOTLEN. The mitigation the limit named was THE FILE SET: "a
    --     novel spelling has to be written into a file this case already
    --     reads, where the next widening will see it." That is exactly how it
    --     surfaced -- 15l walked into two of them in Data/RepairAnalyzer.lua
    --     (:510 and :1281) while fixing the .steps family, correctly said the
    --     62 it reported was a FLOOR and not a total, and did not measure how
    --     far the floor was from the total. This pass measured: for .steps the
    --     floor was short by TWELVE, not by the four the shape was first
    --     noticed at, and for .versions it was short by two. The limit is not
    --     discharged -- there may be a NINTH spelling and the same argument
    --     applies to it -- but it is no longer hypothetical, and the record of
    --     what it cost is here rather than in a commit message.
    --
    --   * .steps IS MEASURED AND IS NOT GATED. W32 below points the same
    --     machinery at the .steps family: 25 files, 74 matched, 73 bare,
    --     triaged by hand into 57 genuinely bare, 15 safe by construction and
    --     1 safe by binding. IT ASSERTS NOTHING AND MUST NOT BE TURNED INTO A
    --     GATE until those 57 are fixed or allowlisted with reasons. Only two
    --     .steps sites are guarded in shipped code today, both in
    --     Data/Defaults.lua (:3976 from 15j, :4002 from 15k), and neither is
    --     counted in the forty-five: they are a different family and blurring
    --     the two totals is exactly what this note exists to prevent.
    -- 15k: readSource() moved to file scope, unchanged, so W32 can read the
    -- .steps file set with the same prefix ladder.
    local function countOf(src, needle)
        local n, pos = 0, 1
        while true do
            local s, e = src:find(needle, pos, true)
            if not s then
                return n
            end
            n = n + 1
            pos = e + 1
        end
    end

    -- EVERY SHIPPED .lua THAT MENTIONS .versions, all nineteen. Files with
    -- needles carry a guard whose TEXT is pinned, plus how many times that text
    -- must appear in the file -- the counts matter, because several files hold
    -- two or more sites with byte-identical guard text and a "1" there would
    -- pass with one of them reverted. Files with an EMPTY needle list are here
    -- for the ABSENCE scan alone: nothing in them is pinned, but a bare read
    -- introduced into one is reported with its file and line. Twelve of the
    -- nineteen are in that second group.
    local SITES = {
        {
            file = "Core/Core.lua",
            needles = {
                { 'if type(decoded.versions) == "table" then', 1 },
                { "verCount = #decoded.versions", 1 },
                -- 15e: the two /gems maintenance walks, both under a parent-only
                -- "if type(seqData) == \"table\" then" that never checked the field.
                { 'for _, version in ipairs(type(seqData.versions) == "table" and seqData.versions or {}) do', 2 },
                -- 15e: the analytics first-step-advance probe (INDEX shape).
                { 'local v1 = type(d.versions) == "table" and d.versions[1] or nil', 1 },
            },
        },
        {
            file = "Core/PublicAPI.lua",
            needles = {
                -- 15e: the plugin-facing API surface, parenthesised "or {}".
                { 'local versions = (data and type(data.versions) == "table" and data.versions) or {}', 1 },
            },
        },
        {
            file = "Data/Defaults.lua",
            needles = {
                -- 15e: INDEX shape. The D.NewVersion fallback is inside the
                -- needle on purpose -- it must not be silently changed.
                --
                -- 15k: SPLIT IN TWO, and the needle text changed because the
                -- SOURCE changed -- not because this pin was relaxed. The 15e
                -- form type-tested tmpl.versions, the CONTAINER, and left ver1
                -- itself unguarded; a template carrying versions = {5} passed it
                -- and raised at :3920. Both levels are now tested and BOTH lines
                -- are pinned, so reverting either half is a red here. The
                -- D.NewVersion fallback is still inside a needle, verbatim.
                { 'local tmplVer1 = type(tmpl.versions) == "table" and tmpl.versions[1]', 1 },
                { 'local ver1 = type(tmplVer1) == "table" and tmplVer1 or D.NewVersion', 1 },
            },
        },
        {
            file = "Data/RepairAnalyzer.lua",
            needles = {
                -- 15e: sixteen sites in the one file whose JOB is to detect
                -- corrupt sequences and which crashed on the corruption --
                -- RA:Analyze calls CheckSpells first, so CheckStructure's
                -- correct guard never got to report "Missing versions".
                -- 2 since RA:CheckEmpower landed. It takes the same
                -- surface.activeVersionOnly version pick as RA:CheckSpells, so the
                -- guarded form appears twice. This count grows because a SAFE read
                -- was ADDED, which is exactly what this census exists to track.
                { 'versionsToCheck = type(seqData.versions) == "table" and seqData.versions or {}', 2 },
                { 'for i, v in ipairs(type(seqData.versions) == "table" and seqData.versions or {}) do', 2 },
                { 'for vi, ver in ipairs(type(seqData.versions) == "table" and seqData.versions or {}) do', 6 },
                { 'for _, ver in ipairs(type(seqData.versions) == "table" and seqData.versions or {}) do', 2 },
                { 'local v = type(sd.versions) == "table" and sd.versions[vi] or nil', 1 },
                -- The RELOCATION guard. Once CheckReadiness skips instead of
                -- raising, execution reaches this length read, so the raise
                -- MOVES here unless it is guarded in the same pass.
                { 'if type(seqData.versions) == "table" and #seqData.versions == 1 then', 1 },
                { 'for _, tv in ipairs(type(t.data.versions) == "table" and t.data.versions or {}) do', 1 },
                { 'for _, ver in ipairs(type(entry.data.versions) == "table" and entry.data.versions or {}) do', 2 },
            },
        },
        {
            file = "Data/VariableStore.lua",
            needles = {},
        },
        {
            file = "Engine/Engine.lua",
            needles = {
                -- 15e: the freeze on this file was lifted for that pass. The
                -- count-3 needle covers THE SAVE PATH (UpdateSequenceData), the
                -- locale heal walk and the override re-translate walk.
                { 'if resolvedVer and type(sequenceData.versions) == "table" then', 1 },
                { 'for _, version in ipairs(type(seqData.versions) == "table" and seqData.versions or {}) do', 3 },
                { 'if type(src.versions) == "table" then', 1 },
            },
        },
        {
            file = "Engine/Identity.lua",
            needles = {},
        },
        {
            file = "Engine/MacroManager.lua",
            needles = {},
        },
        {
            file = "Import/ExportPreview.lua",
            needles = {},
        },
        {
            file = "Import/GRIPExport.lua",
            needles = {
                {
                    'local ilVer = type(seqData.versions) == "table"'
                        .. " and seqData.versions[seqData.defaultVersion or 1] or nil",
                    1,
                },
                -- 15e: the local-bound length read two lines under an already
                -- correct type() test. Safe as it stood, rewritten anyway so the
                -- allowlist stays at exactly the two SequenceList lines.
                { 'local vCount = (type(versions) == "table" and #versions) or 0', 1 },
            },
        },
        {
            file = "Import/ImportPreview.lua",
            needles = {
                -- 15e: freeze lifted here too. Both walks run on payload data
                -- straight off the wire.
                { 'for _, ver in ipairs(type(seqData.versions) == "table" and seqData.versions or {}) do', 2 },
                -- 15e: the same local-bound length read as GRIPExport's.
                { 'local versionCount = (type(payloadVersions) == "table" and #payloadVersions) or 0', 1 },
            },
        },
        {
            file = "UI/ContextTab.lua",
            needles = {
                { 'local numVersions = (type(seqData.versions) == "table" and #seqData.versions) or 0', 2 },
                -- 15d: the version context menu gate above "for i = 1, #entry.data.versions".
                { 'if not entry or not entry.data or type(entry.data.versions) ~= "table" then', 1 },
            },
        },
        {
            file = "UI/PopupEditor.lua",
            needles = {
                -- 15d: TWO sites with byte-identical text at different
                -- indentation -- the version dropdown and RefreshVersionBar.
                -- The count is 2 on purpose: a "1" here would pass with one of
                -- them reverted, which is exactly the mistake ContextTab's
                -- count guards against.
                { 'if not entry or not entry.data or type(entry.data.versions) ~= "table" then', 2 },
                -- 15e: LoadSequence's two INDEX reads. Distinct needles: the
                -- second is the "[1]" retry that runs when the active index
                -- misses, and a shared needle would pass with it reverted.
                {
                    'local ver = type(seqData.versions) == "table"'
                        .. " and seqData.versions[inst.activeVersionIndex] or nil",
                    1,
                },
                { 'ver = type(seqData.versions) == "table" and seqData.versions[1] or nil', 1 },
                -- 15e: the undo/redo snapshot builder's bare POSITIVE gate.
                { 'if type(oldData.versions) == "table" then', 1 },
                -- 15e: the revert-to-saved INDEX read. Exceeds 120 columns
                -- type()-tested, so stylua wraps it and the needle carries the
                -- newline plus the continuation indent.
                {
                    'local savedVer = type(savedEntry.data.versions) == "table"'
                        .. " and savedEntry.data.versions[inst.activeVersionIndex]"
                        .. "\n            or nil",
                    1,
                },
                -- 15e: SwitchToVersion's INDEX read.
                { 'local ver = type(entry.data.versions) == "table" and entry.data.versions[idx] or nil', 1 },
            },
        },
        {
            file = "UI/RawTab.lua",
            needles = {},
        },
        {
            file = "UI/SequenceEditor.lua",
            needles = {
                { 'local maxVer = (type(seqData.versions) == "table" and #seqData.versions) or 1', 1 },
                { 'local total = (type(entry.data.versions) == "table" and #entry.data.versions) or 1', 1 },
                -- 15d: the INDEX-shaped site. This is the one the two-operator
                -- 15c sweep could not see, and the one 15c newly made reachable.
                { 'if not seqData or type(seqData.versions) ~= "table" then', 1 },
                -- 15d: the three Init-scope gates, each above a "#" read. Named
                -- locals, so each needle is unambiguous on its own.
                { 'if not vbEntry or not vbEntry.data or type(vbEntry.data.versions) ~= "table" then', 1 },
                { 'if not lbEntry or not lbEntry.data or type(lbEntry.data.versions) ~= "table" then', 1 },
                { 'if not dlEntry or not dlEntry.data or type(dlEntry.data.versions) ~= "table" then', 1 },
                -- 15e: the reverse embed scan's bare POSITIVE gate. This site
                -- was NOT in the 15e brief's enumeration -- it was found by the
                -- widened scan itself, which is the whole argument for scanning
                -- every file rather than only the ones an edit pass touched.
                { 'if type(otherData.versions) == "table" then', 1 },
                -- 15e: the Add Version and Duplicate Version early bails. 15d
                -- called these correctly unguarded because a scalar raises AT
                -- the table.insert -- true, and it means the buttons were
                -- themselves raise sites. The raise moved up one line, it did
                -- not go away.
                { 'if type(avEntry.data.versions) ~= "table" then', 1 },
                { 'if type(dvEntry.data.versions) ~= "table" then', 1 },
                -- 15e: BOTH undo/redo snapshot builders (rename and save).
                -- Count 2: a "1" would pass with one of them reverted.
                { 'if type(oldData.versions) == "table" then', 2 },
            },
        },
        {
            file = "UI/SequenceList.lua",
            needles = {
                { 'local versionCount = (type(seqData.versions) == "table" and #seqData.versions) or 1', 1 },
                -- 15e: the list-rename snapshot builder's bare POSITIVE gate.
                { 'if type(oldData.versions) == "table" then', 1 },
            },
        },
        {
            file = "UI/TrackerHUD.lua",
            needles = {
                -- 15d: the two parenthesised badge counts. Both exceed stylua's
                -- 120-column limit once type()-tested, so both are wrapped and
                -- each needle carries its own newline and indentation. The
                -- trailing "or 0" is inside the needle on purpose: the 0
                -- fallback is preserved, not silently promoted to 1.
                {
                    'local versionCount = (type(seqData) == "table" and type(seqData.versions) == "table"'
                        .. " and #seqData.versions)\n                or 0",
                    1,
                },
                {
                    'and type(liveData.versions) == "table"\n                    and #liveData.versions\n                ) or 0',
                    1,
                },
            },
        },
        {
            file = "UI/VariantsTab.lua",
            needles = {},
        },
        {
            file = "Data/SpellCache.lua",
            needles = {
                -- 15d: the ipairs-shaped site in CollectUnresolvedSpellRefs.
                { 'if entry and entry.button and entry.data and type(entry.data.versions) == "table" then', 1 },
                -- 15e: the three SavedVariables migration walks -- pending-tag,
                -- locale-renormalize and bare-name macro heal. All three read
                -- GRIP_EMS_CHAR.sequences directly, and the CORRECT pattern was
                -- already in this same file 2000 lines above them.
                { 'for _, version in ipairs(type(seqData.versions) == "table" and seqData.versions or {}) do', 3 },
            },
        },
    }

    -- The two declared-safe look-alikes that live in the scanned files, keyed by
    -- their exact trimmed text rather than by line number so an unrelated edit
    -- above them does not turn this case red. Both sit inside "if ver then", so
    -- a scalar versions never reaches them. If either line's text changes, this
    -- case goes red on purpose: the reason it was safe has to be re-checked.
    local SAFE_LOOKALIKE = {
        ["contextVersions = srcData.versions and #srcData.versions or 0,"] = true,
        ["contextVersions = tgtData.versions and #tgtData.versions or 0,"] = true,
    }

    -- 15k: THE SEVEN SHAPES, THE LEXER, THE TOKEN BOUNDARY AND THE BARENESS
    -- RULE ALL MOVED TO FILE SCOPE and are now built from a FIELD NAME. The
    -- comments that documented each of them moved with it, verbatim -- read
    -- buildPatterns(), codeSpans(), normaliseCode(), leftBounded(),
    -- guardedInCode() and makeScanner() above this case for the four passes of
    -- reasoning behind them. NOTHING WAS RESPELLED FOR .versions: this case
    -- names the field it always scanned and takes the same closure it always
    -- ran. The census printed at the foot of this case is what holds that
    -- claim to account.
    local scan, PATTERNS = makeScanner("versions", SAFE_LOOKALIKE)

    -- =====================================================================
    -- THE CONFUSION CORPUS.
    --
    -- THE RULE FOR THE NEXT PASS, and it is the entire point of this table:
    -- ANY NEWLY DISCOVERED CONFUSION IS ADDED HERE AS A ROW, IN THE SAME
    -- COMMIT THAT FIXES IT, AND ROWS ARE NEVER DELETED. If a confusion is
    -- worth a pass, it is worth a permanent row; a confusion that is only
    -- ever fixed is a confusion that can come back.
    --
    -- WHY IT REPLACES WHAT WAS HERE. Every confusion found in 15e, 15f and
    -- 15g was found BY HAND, once, and then turned into a one-off probe row
    -- asserted BY INDEX -- probeOff[8], probeOff[9], "nothing past index 9".
    -- Three passes in, those asserts named positions instead of reasons: a
    -- regression reported "probeOff[8] mismatch" and the reader had to
    -- reconstruct which confusion that index stood for, and every new row
    -- renumbered the ones after it. Each row here carries the pass that found
    -- it and its own reason, and every assertion below quotes that reason, so
    -- a failure names WHAT REGRESSED.
    --
    -- IT STILL CONTROL-FALSIFIES THE SCANNER, which is what the probe block
    -- existed for and that job is not dropped. A scan that never matches
    -- anything reports zero offenders for every input -- exactly what a
    -- reverted guard would also produce -- so the MUST_FLAG rows prove it
    -- flags every shape it claims to cover before its verdict on the real
    -- files is trusted. THE LOAD-BEARING MUST_NOT_FLAG ROW IS THE FIXED
    -- "or {}" FORM: it DOES match BARE_ORFALL and stays unflagged only
    -- because the bareness rule in scan() clears it, so if that rule ever
    -- stops working this table goes red HERE rather than silently exempting
    -- every real site in the nineteen files. (The 15e comment this replaces
    -- attributed that role to probe line "(n)". It was wrong: (n) was the
    -- INDEX row and (m) was the "or {}" one. Naming the row instead of
    -- numbering it is how that class of error stops happening.)
    local MUST_FLAG, MUST_NOT_FLAG, MUST_ALLOWLIST = "MUST_FLAG", "MUST_NOT_FLAG", "MUST_ALLOWLIST"
    local CORPUS = {
        -- ---- 15e: the seven bare-truthiness shapes -----------------------
        {
            line = "    local n = seqData.versions and #seqData.versions or 0",
            expect = MUST_FLAG,
            why = "15e -- bare read, no guard anywhere",
        },
        {
            line = "    local n = (seqData and seqData.versions) and #seqData.versions or 0",
            expect = MUST_FLAG,
            why = "15e -- parenthesised bare read",
        },
        {
            line = "    if not seqData or not seqData.versions then",
            expect = MUST_FLAG,
            why = "15e -- negative gate ahead of an index",
        },
        {
            line = "    if entry and entry.data and entry.data.versions then",
            expect = MUST_FLAG,
            why = "15e -- conjunctive positive gate ahead of an ipairs",
        },
        {
            line = "    if oldData.versions then",
            expect = MUST_FLAG,
            why = "15e -- bare positive gate ahead of an ipairs",
        },
        {
            line = "    for _, v in ipairs(x.versions or {}) do",
            expect = MUST_FLAG,
            why = "15e -- bare 'or {}' fallback",
        },
        {
            line = "    local v = seqData.versions and seqData.versions[i]",
            expect = MUST_FLAG,
            why = "15e -- same-expression index",
        },
        -- ---- 15f: the receiver-blind bareness rule ------------------------
        {
            line = '    local _probeA = type(entry) == "table" and entry.data.versions and #entry.data.versions or 0',
            expect = MUST_FLAG,
            why = "15f -- type() on the PARENT, field bare",
        },
        {
            line = '    local n = type(node.children) == "table" and rec.versions and #rec.versions or 0',
            expect = MUST_FLAG,
            why = "15f -- unrelated table type() test on the same line",
        },
        -- ---- 15g: code versus text, and the spelling of the guard ---------
        {
            line = "    local _probeC = entry.data.versions and #entry.data.versions or 0"
                .. ' -- guarded above by type(entry.data.versions) == "table"',
            expect = MUST_FLAG,
            why = "15g -- guard text in a trailing COMMENT, read bare",
        },
        {
            line = '    local msg = [[type(entry.data.versions) == "table"]]'
                .. " local n = entry.data.versions and #entry.data.versions or 0",
            expect = MUST_FLAG,
            why = "15g -- guard text in a STRING literal, read bare",
        },
        {
            line = '    local n = type(rec.versions) ~= "table" and rec.versions and #rec.versions or 0',
            expect = MUST_FLAG,
            why = "15g -- 'type(E) ~= \"table\"' on the line, read bare (the OPPOSITE test must never clear)",
        },
        {
            line = '    for _, v in ipairs(type(a.versions) == "table" and a.versions or {}) do'
                .. " local n = b.versions and #b.versions or 0 end",
            expect = MUST_FLAG,
            why = "15g -- one receiver guarded, a second receiver bare",
        },
        -- ---- MUST NOT FLAG: the fixed forms, one per shape ----------------
        {
            line = '    local n = type(rec.versions) == "table" and #rec.versions or 0',
            expect = MUST_NOT_FLAG,
            why = "15e -- canonical guard, field-scoped",
        },
        {
            line = '    for _, v in ipairs(type(x.versions) == "table" and x.versions or {}) do',
            expect = MUST_NOT_FLAG,
            why = "15e -- the fixed 'or {}' form, THE LOAD-BEARING CLEAR: it matches BARE_ORFALL and only the rule clears it",
        },
        {
            line = '    local n = (type(seqData.versions) == "table" and #seqData.versions) or 0',
            expect = MUST_NOT_FLAG,
            why = "15e -- the fixed inline length read",
        },
        {
            line = '    local n = (type(seqData) == "table" and type(seqData.versions) == "table"'
                .. " and #seqData.versions)",
            expect = MUST_NOT_FLAG,
            why = "15e -- the fixed parenthesised length read, parent AND field tested",
        },
        {
            line = '    if not seqData or type(seqData.versions) ~= "table" then',
            expect = MUST_NOT_FLAG,
            why = "15e -- the fixed negative gate",
        },
        {
            line = '    if entry and entry.data and type(entry.data.versions) == "table" then',
            expect = MUST_NOT_FLAG,
            why = "15e -- the fixed conjunctive positive gate",
        },
        {
            line = '    if type(oldData.versions) == "table" then',
            expect = MUST_NOT_FLAG,
            why = "15e -- the fixed bare positive gate",
        },
        {
            line = '    local v = type(seqData.versions) == "table" and seqData.versions[i] or nil',
            expect = MUST_NOT_FLAG,
            why = "15e -- the fixed same-expression index",
        },
        {
            line = '    local _probeG = type(entry.data.versions)=="table"'
                .. " and entry.data.versions and #entry.data.versions or 0",
            expect = MUST_NOT_FLAG,
            why = "15g -- guard with no spaces around '=='",
        },
        {
            line = "    for _, v in ipairs(type(x.versions) == 'table' and x.versions or {}) do",
            expect = MUST_NOT_FLAG,
            why = "15g -- guard with single-quoted 'table'",
        },
        {
            line = "    -- local old = entry.data.versions and #entry.data.versions or 0",
            expect = MUST_NOT_FLAG,
            why = "15g -- a commented-out bare read is dead text, not a live site",
        },
        -- ---- MUST ALLOWLIST -----------------------------------------------
        {
            line = "        contextVersions = srcData.versions and #srcData.versions or 0,",
            expect = MUST_ALLOWLIST,
            why = "15b -- the UI/SequenceList contextVersions shape",
        },
        -- ---- 15h: the token boundary, and ten pinned lexer behaviours -----
        --
        -- APPENDED, NOT INTERLEAVED. Rows are identified by index in the loop
        -- below, so inserting these into the sections they belong to by topic
        -- would renumber every row after the insertion point and invalidate
        -- every regression report ever filed against the old numbers. Grouping
        -- is a convenience; the `why` on each row is the identity.
        --
        -- ONLY ONE OF THESE ELEVEN IS A NEW FIX. Row 4 below is the 15h token
        -- boundary: it was GREEN on the shipped 15g gate and is RED for the
        -- first time in this pass. THE OTHER TEN WERE ALREADY CORRECT IN 15g
        -- and were verified BY HAND against it on 2026-07-28, each by appending
        -- the line to UI/RawTab.lua and running the suite. They are banked so
        -- that a later edit to codeSpans() cannot quietly undo any of them --
        -- which is exactly what the corpus rule at the head of this table asks
        -- for, and the 15g self-audit named the short-string gap (row 2) as the
        -- one it knew it had left unpinned.
        --
        -- ROWS 5 THROUGH 11 ARE LEXER-PROPERTY ROWS rather than defect rows.
        -- They exist so a future edit to codeSpans() cannot quietly NARROW what
        -- counts as code, and each pairs a false-green risk against the
        -- false-red risk of over-correcting for it: rows 5 to 10 fail if the
        -- lexer stops seeing real code as code, and row 11 -- the
        -- clear-direction twin of row 5, with the site BEFORE the "--"-bearing
        -- string and its guard AFTER it -- fails if the lexer truncates the line
        -- at a "--" that is only string CONTENT.
        {
            line = "    local msg = \"type(entry.data.versions) == 'table'\""
                .. " local n = entry.data.versions and #entry.data.versions or 0",
            expect = MUST_FLAG,
            why = "15h -- guard inside a short DOUBLE-quoted string, read bare",
        },
        {
            line = "    local msg = 'type(entry.data.versions) == \"table\"'"
                .. " local n = entry.data.versions and #entry.data.versions or 0",
            expect = MUST_FLAG,
            why = "15h -- guard inside a short SINGLE-quoted string, read bare (the gap the 15g self-audit named)",
        },
        {
            line = '    --[[ type(entry.data.versions) == "table" ]]'
                .. " local n = entry.data.versions and #entry.data.versions or 0",
            expect = MUST_FLAG,
            why = "15h -- guard inside a LONG comment, read bare after it closes",
        },
        {
            line = '    local n = myvaluetype(entry.data.versions) == "table"'
                .. " and entry.data.versions and #entry.data.versions or 0",
            expect = MUST_FLAG,
            why = "15h -- an identifier ENDING in 'type' satisfying the needle: the token-boundary hole, GREEN on 15g",
        },
        {
            line = '    local sep = "--" local n = entry.data.versions and #entry.data.versions or 0',
            expect = MUST_FLAG,
            why = "15h -- a '--' inside a STRING does not truncate the line: the read after it is still code",
        },
        {
            line = "    local s = [[long]] local n = entry.data.versions and #entry.data.versions or 0",
            expect = MUST_FLAG,
            why = "15h -- a CLOSED [[long string]] earlier on the line: the read after it is still code",
        },
        {
            line = "    local s = [==[levelled]==] local n = entry.data.versions and #entry.data.versions or 0",
            expect = MUST_FLAG,
            why = "15h -- a CLOSED [==[levelled]==] string earlier on the line: the read after it is still code",
        },
        {
            line = '    local s = "]]" local n = entry.data.versions and #entry.data.versions or 0',
            expect = MUST_FLAG,
            why = "15h -- a ']]' inside a short string does not confuse the closer: the read after it is still code",
        },
        {
            line = '    local s = "a\\"b" local n = entry.data.versions and #entry.data.versions or 0',
            expect = MUST_FLAG,
            why = "15h -- an ESCAPED quote inside a string does not end it early: the read after it is still code",
        },
        {
            line = "    local n = entry.data.versions and #entry.data.versions or 0" .. ' local s = "unterminated',
            expect = MUST_FLAG,
            why = "15h -- an UNTERMINATED string still leaves the code BEFORE it judged",
        },
        {
            line = "    if entry.data.versions then"
                .. ' local sep = "--" local ok = type(entry.data.versions) == "table" end',
            expect = MUST_NOT_FLAG,
            why = "15h -- site BEFORE a '--'-bearing string, its real guard AFTER it: truncating at that '--' would flag this",
        },
        -- ---- 15m: the eighth shape, and the two-directional split ---------
        --
        -- APPENDED, NOT INTERLEAVED, for the reason stated above rows 25-35.
        --
        -- ROWS 37 TO 40 ARE A SET AND ARE ONLY MEANINGFUL TOGETHER. 37 proves
        -- the eighth shape is SEEN at all -- without it, the pattern could be
        -- silently broken and every other row here would still pass, because
        -- no other row exercises it. 38 and 39 prove the per-shape clear
        -- accepts BOTH forms of the guard on a negative gate. 40 is the twin
        -- of 38 and is the row that stops the split being collapsed: it is a
        -- POSITIVE shape carrying the negated guard over a bare read, and it
        -- must still FLAG. Row 12 already pins that for the length shape; 40
        -- pins it for the "or {}" shape as well, so a future edit that makes
        -- "~=" clear everywhere goes red in two places rather than one.
        {
            line = "    if not seqData.versions or #seqData.versions == 0 then",
            expect = MUST_FLAG,
            why = "15m -- the eighth shape itself: a negative gate with a LENGTH continuation, no guard anywhere",
        },
        {
            line = '    if not seq.versions or type(seq.versions) ~= "table" or not next(seq.versions) then',
            expect = MUST_NOT_FLAG,
            why = "15m -- BARE_NOTLEN cleared by the NEGATED guard (Import/ImportPreview.lua:1264 verbatim)",
        },
        {
            line = '    if not ver.versions or (type(ver.versions) == "table" and #ver.versions == 0) then',
            expect = MUST_NOT_FLAG,
            why = "15m -- BARE_NOTLEN cleared by the CANONICAL guard: the eighth shape did not lose the '==' form",
        },
        {
            line = '    for _, v in ipairs(type(x.versions) ~= "table" and x.versions or {}) do',
            expect = MUST_FLAG,
            why = "15m -- a POSITIVE shape carrying '~=' over a bare read STILL FLAGS: the twin of row 38, the split must not collapse",
        },
        -- ---- 15o: the ninth shape, and its clear-check split --------------
        --
        -- APPENDED, NOT INTERLEAVED, for the reason stated above rows 25-35.
        --
        -- ROWS 41 TO 44 ARE A SET. 41 proves the ninth shape is SEEN at all --
        -- without it the pattern could be silently broken and every other row
        -- here would still pass, because no other row exercises it. 42 proves
        -- the canonical guard clears it. 43 is the row that stops the
        -- clear-check split being collapsed FROM THE OTHER SIDE: the ninth is
        -- a POSITIVE gate, so 'type(E) ~= "table"' must NOT clear it, and a
        -- future edit that adds BARE_CONJGATE to NEGATED_GUARD_CLEARS goes red
        -- here. 44 pins the "elseif" spelling, which the pattern catches
        -- because "elseif" ends in "if" -- if a later edit anchors the shape at
        -- start-of-token instead, three of the eighteen sites it clears today
        -- go silently unseen and this row is what says so.
        {
            line = "    if ver.versions and SC and SC._WalkVersions then",
            expect = MUST_FLAG,
            why = "15o -- the ninth shape itself: the field as HEAD conjunct of a positive gate, no guard anywhere",
        },
        {
            line = '    if seqData.versions and type(seqData.versions) == "table" then',
            expect = MUST_NOT_FLAG,
            why = "15o -- BARE_CONJGATE cleared by the CANONICAL guard (Import/ExportPreview.lua:40 verbatim)",
        },
        {
            line = '    if rec.versions and type(rec.versions) ~= "table" then',
            expect = MUST_FLAG,
            why = "15o -- the ninth is a POSITIVE gate: '~=' must NOT clear it, the twin of rows 12 and 40",
        },
        {
            line = "    elseif newSeqData.versions and SC._WalkVersions then",
            expect = MUST_FLAG,
            why = "15o -- the 'elseif' spelling of the ninth shape is the same gate and must be seen",
        },
    }

    -- Every row is driven through the REAL scan(), one row per call so a flag
    -- is attributable to the row that provoked it, and every assertion carries
    -- the row's own reason rather than its index.
    local corpusFlagged, corpusClean, corpusAllowed = 0, 0, 0
    for idx, row in ipairs(CORPUS) do
        local rowOff, rowSafe = {}, {}
        scan(row.line, "CORPUS", rowOff, rowSafe)
        local trimmed = row.line:gsub("^%s*(.-)%s*$", "%1")
        local safeHits = 0
        for _, count in pairs(rowSafe) do
            safeHits = safeHits + count
        end
        local where = "confusion corpus row " .. idx .. " [" .. row.expect .. "] " .. row.why .. "  ||  " .. trimmed
        if row.expect == MUST_FLAG then
            corpusFlagged = corpusFlagged + 1
            assertTrue(#rowOff > 0, where .. "  ->  NOT FLAGGED, the confusion is back")
            assertEqual(0, safeHits, where .. "  ->  absorbed by the allowlist instead of flagged")
        elseif row.expect == MUST_NOT_FLAG then
            corpusClean = corpusClean + 1
            assertTrue(#rowOff == 0, where .. "  ->  FLAGGED: " .. table.concat(rowOff, " | "))
            assertEqual(0, safeHits, where .. "  ->  cleared by the allowlist rather than on its own merits")
        elseif row.expect == MUST_ALLOWLIST then
            corpusAllowed = corpusAllowed + 1
            assertTrue(#rowOff == 0, where .. "  ->  FLAGGED: " .. table.concat(rowOff, " | "))
            assertEqual(1, rowSafe[trimmed], where .. "  ->  not counted against the allowlist")
        else
            error("confusion corpus row " .. idx .. " carries an unknown expectation: " .. tostring(row.expect), 0)
        end
    end

    -- The counts, asserted SEPARATELY from the per-row loop. A row that
    -- silently disappears passes every assertion above it -- there is simply
    -- one fewer -- so the size of the corpus is pinned in its own right.
    -- 15m: 36 -> 40 rows, 23 -> 25 flagged, 12 -> 14 clean, 1 allowlisted
    -- unchanged. The four new rows are the eighth shape and its clear-check
    -- split; the old numbers are kept in this comment because five passes of
    -- reports quote them and a reader meeting 40 should be able to see where
    -- the four came from without a git log.
    -- 15o: 40 -> 44 rows, 25 -> 28 flagged, 14 -> 15 clean, 1 allowlisted
    -- unchanged. The four new rows are the NINTH shape, its canonical clear,
    -- its must-not-clear negated twin and its "elseif" spelling. Same rule as
    -- above: the older lines stay because reports quote them.
    assertEqual(44, #CORPUS, "confusion corpus: a row went missing -- rows are added, never deleted")
    assertEqual(28, corpusFlagged, "confusion corpus: MUST_FLAG row count")
    assertEqual(15, corpusClean, "confusion corpus: MUST_NOT_FLAG row count")
    assertEqual(1, corpusAllowed, "confusion corpus: MUST_ALLOWLIST row count")

    -- 15o: SHAPE ATTRIBUTION, and it is a different question from every row
    -- above. The corpus asks "is this line flagged"; a NINTH pattern that
    -- swallowed BARE_POSGATE's or BARE_ANDGATE's spellings would keep every
    -- corpus row green and still silently reclassify sites between shapes,
    -- which is the one failure mode that makes five passes of per-shape counts
    -- incomparable without changing a single verdict. So the anchors are
    -- driven separately and each must be attributed to ITS OWN shape.
    --
    -- byShape is only filled for OFFENDERS, so each probe is deliberately a
    -- bare, unguarded line -- a cleared line would attribute nothing.
    --
    -- 15p CORRECTION, AND IT NARROWS WHAT ROWS 1 TO 3 ARE ENTITLED TO CLAIM.
    -- 15o reported that this assert pins the append-not-insert decision for
    -- PATTERN_ORDER. With only rows 1 to 3 present it does not, and the
    -- measurement is unambiguous: moving BARE_CONJGATE to the FRONT of
    -- PATTERN_ORDER, changing nothing else, left the suite fully green while
    -- reclassifying two real sites (.steps BARE_LEN 14 -> 13 with
    -- BARE_CONJGATE 0 -> 1, .actions BARE_LEN 5 -> 4 with BARE_CONJGATE
    -- 1 -> 2). Not one assertion moved. Two structural reasons, both recorded
    -- here so the next pass does not re-derive them:
    --   a) all three original probes are .versions lines and this case scans
    --      field=versions, but the only two BARE_LEN co-occurrences in the
    --      tree are on .steps (Import/LegacyImport.lua:656) and .actions
    --      (Engine/Engine.lua:2837). Those live in W32 and W34, and those two
    --      censuses assert nothing.
    --   b) no probe line carried a "#" continuation, so BARE_LEN could never
    --      fire on any of them regardless of order.
    --
    -- SO THE ROWS DO TWO DIFFERENT JOBS AND MUST NOT BE READ AS ONE SET.
    -- Rows 1 to 3 pin that the ninth shape did not swallow BARE_POSGATE's or
    -- BARE_ANDGATE's spellings -- their original reason, unchanged and still
    -- worth having. Row 4 is the ONLY row that pins PATTERN_ORDER itself: it
    -- is matched by BARE_LEN and by BARE_CONJGATE on the SAME receiver, so
    -- nothing but the order of PATTERN_ORDER decides which shape claims it,
    -- and it is the only row that goes red on a reorder. In the appended
    -- order it attributes to BARE_LEN; with BARE_CONJGATE moved to the front
    -- it fails with "must be attributed to BARE_LEN: expected 1, got 0".
    local ATTRIBUTION = {
        { line = "    if oldData.versions then", shape = "BARE_POSGATE" },
        { line = "    if entry and entry.data and entry.data.versions then", shape = "BARE_ANDGATE" },
        { line = "    if entry.data.versions and SC._WalkVersions then", shape = "BARE_CONJGATE" },
        { line = "    if ver.versions and #ver.versions > 0 then", shape = "BARE_LEN" },
    }
    for _, probe in ipairs(ATTRIBUTION) do
        local probeOff, probeSafe = {}, {}
        local probeStats = newScanStats()
        scan(probe.line, "ATTRIBUTION", probeOff, probeSafe, probeStats)
        assertEqual(1, #probeOff, "shape attribution: expected exactly one offender for " .. probe.line)
        assertEqual(
            1,
            probeStats.byShape[probe.shape] or 0,
            "shape attribution: " .. probe.line .. "  ->  must be attributed to " .. probe.shape
        )
    end

    -- Now the real files. ABSENCE runs BEFORE presence on purpose: the absence
    -- error carries the offending file AND line, and the presence assert only
    -- carries a file name, so running presence first would downgrade the
    -- diagnostic for exactly the regression this case exists to catch.
    local sources = {}
    local offenders = {}
    local seenSafe = {}
    -- 15k: the same scan, now also counting. The stats table is an OUT
    -- parameter and changes no verdict -- every increment is inside an
    -- "if stats" in makeScanner() -- and it exists so the four numbers this
    -- gate has been quoted at in prose since 15g are PRINTED by the gate
    -- itself. A number in a comment cannot be re-measured; this one can.
    local fileStats = newScanStats()
    for _, site in ipairs(SITES) do
        local src = readSource(site.file)
        assertTrue(src ~= nil, "could not locate " .. site.file .. " (run from the EMS root)")
        sources[site.file] = src
        scan(src, site.file, offenders, seenSafe, fileStats)
    end

    -- ABSENCE: nothing outside the allowlist still reads the field this way.
    if #offenders > 0 then
        error("bare-truthiness .versions reads remain:\n    " .. table.concat(offenders, "\n    "), 0)
    end

    -- PRESENCE: the guard is written, and written the expected number of times.
    -- Without this a site could be DELETED outright -- no read at all -- and the
    -- absence scan above would still report clean.
    for _, site in ipairs(SITES) do
        for _, needle in ipairs(site.needles) do
            local want = needle[2]
            local got = countOf(sources[site.file], needle[1])
            assertEqual(want, got, site.file .. " -- guard text occurrences for: " .. needle[1])
        end
    end

    -- The allowlist must be LIVE. If a rename made an entry dead, the absence
    -- result above would be clean for the wrong reason.
    for text in pairs(SAFE_LOOKALIKE) do
        assertEqual(1, seenSafe[text], "declared-safe look-alike no longer found verbatim: " .. text)
    end

    -- 15k CENSUS, PRINTED AND NOT ASSERTED. The verdict this case delivers is
    -- the offender list above; these four numbers are the WORKING that produced
    -- it, and they are printed so the "26 matched, 24 cleared, 2 allowlisted,
    -- 0 offenders" quoted throughout the boundary note is reproducible from a
    -- suite run rather than from a comment written three passes ago.
    -- 15m: THE LINE THIS PRINTS NOW READS 28 / 26 / 2 / 0, AND patterns=8.
    -- The boundary note above still says 26 / 24 in the paragraphs that record
    -- what 15g, 15h and 15k each proved, because each was true when written;
    -- the side-by-side that reconciles them is at the head of this case. This
    -- is precisely why the census is printed at all -- a number in a comment
    -- cannot be re-measured when the denominator moves, and this one can. It is
    -- deliberately NOT an assertion: a legitimate edit that adds a guarded read
    -- moves "matched" and "cleared" together and must not redden a gate whose
    -- job is to find BARE reads. What is asserted is what matters -- zero
    -- offenders, the pinned needles, and a live allowlist.
    print(
        string.format(
            "  W26 CENSUS  field=versions  files=%d  patterns=%d  matched=%d  cleared=%d  allowlisted=%d  offenders=%d",
            #SITES,
            #PATTERNS,
            fileStats.matched,
            fileStats.cleared,
            fileStats.allowlisted,
            fileStats.offenders
        )
    )

    -- 15n RESIDUAL BUCKET, PRINTED AND NOT ASSERTED, exactly like the four
    -- numbers above it. THE DENOMINATOR IS THIS CASE'S OWN FILE SET -- the
    -- nineteen SITES rows and nothing else -- so A/B/C/D are commensurable
    -- with the matched/cleared/allowlisted/offenders line and with every
    -- .versions number this arc has quoted. W32's .steps set is derived from
    -- the TOC instead and is a different denominator; the two must not be
    -- added together.
    --
    -- B IS TAKEN FROM THE GATE'S OWN MATCH SET, not re-derived. Whatever the
    -- eight patterns matched is what B counts, so B can never drift from the
    -- verdict above it.
    --
    -- WHAT THIS ADDS THAT THE FOUR NUMBERS DO NOT. "offenders=0" answers "how
    -- many of the shapes I know about are unguarded". It cannot answer "how
    -- much of this file set has the gate never had an opinion on", and that
    -- second number is where BARE_ORFALL sat until 15e and where BARE_NOTLEN
    -- sat until 15m. D is that number. It is not a defect count and must not
    -- be driven to zero; it is the reading list for whoever looks for shape
    -- nine.
    local versionFiles = {}
    for i, site in ipairs(SITES) do
        versionFiles[i] = site.file
    end
    print("")
    printResidual("versions", residualBuckets("versions", versionFiles, sources, fileStats.matchedLines))
    print("")
end)

test("W32: .steps census -- MEASUREMENT ONLY, this case asserts nothing and never fails", function()
    -- ===================================================================
    -- 15n: THIS CENSUS NOW COUNTS WHAT IT HAS NO OPINION ABOUT. The pattern
    -- set has been incomplete TWICE -- BARE_ORFALL, added in 15e, and
    -- BARE_NOTLEN, added in 15m -- and BOTH gaps were found by a person
    -- reading shipped code, never by this scanner. That is not a criticism of
    -- the scanner; it is what a pattern scan IS. It can only ever report how
    -- many of the shapes already written down are present, so "BARE=n" is a
    -- floor and never a total, and for .steps the floor was short by TWELVE
    -- as recently as one pass ago.
    --
    -- The residual bucket printed at the foot of this case is the structural
    -- answer, and it is the Hub --census pattern: A (in-code mentions of the
    -- field) splits into B (matched by a pattern), C (explained by a written
    -- rule -- write, non-field token, or receiver-scoped type() test) and D
    -- (neither), and A == B + C + D is printed so the split is checkable.
    --
    -- D IS NOT A DEFECT COUNT. It is the set of lines the gate has no opinion
    -- about, most of it ordinary code, and it must not be driven to zero.
    -- Its value is that shape eight lived in D for five passes while every
    -- number this case printed was true, and shape nine -- if it exists -- is
    -- in D now, where a reader can see it. That is why D is listed line by
    -- line and never summarised.
    --
    -- READ THIS BEFORE "FIXING" ANYTHING THIS CASE PRINTS.
    --
    -- THIS IS NOT A GATE AND MUST NOT BECOME ONE UNTIL THE SITES IT PRINTS
    -- HAVE BEEN TRIAGED. It asserts nothing, it cannot fail, and that is
    -- deliberate. The precedent is the Hub's audit-diff-header-freshness
    -- --census mode: make the number reproducible BEFORE anyone acts on it.
    -- A blind fix wave over fifty-odd sites is how a pass ships a regression,
    -- and this arc has already watched three passes rediscover that a fix
    -- applied without reading the site MOVES a crash instead of removing it
    -- (15b, 15c, 15d from one side; 15j from the other -- see W30).
    --
    -- WHAT WOULD MAKE IT A GATE, when someone is ready: triage the printed
    -- sites, fix the genuinely bare ones, add a SAFE_LOOKALIKE-style
    -- allowlist for the rest WITH the reason each is safe, then turn the
    -- offender list into an error() exactly as W26 does. Not before. Turning
    -- this red first would only teach the next reader to add allowlist rows
    -- until it goes green again, which is how a gate stops meaning anything.
    --
    -- WHY .steps AT ALL. It is the next .versions and it is BIGGER. The
    -- project already knows a scalar steps is a real shape -- W17, W18 and
    -- W19 exist precisely for it, and 15j fixed Data/Defaults.lua:3976 and
    -- 15k fixed :4002 for it -- but no scan has ever COVERED the field,
    -- because every pattern W26 carried spelled ".versions" literally. The
    -- machinery is field-parameterised as of 15k, so pointing it at .steps
    -- costs one call and no second copy of the lexer.
    --
    -- HOW THE FILE SET IS DERIVED, and it is not the nineteen W26 uses. Every
    -- .lua the TOC loads, minus Libs/ (vendored) and Test/ (this harness and
    -- its siblings), that mentions the field at all. Deriving it from the TOC
    -- rather than listing it means a new shipped file is in the census the
    -- day it ships, which is the failure 15c and 15d each hit from the other
    -- direction: 15c missed TrackerHUD and 15d missed Engine.lua because
    -- neither was in the scan set of the pass before it.
    --
    -- SCANNED WITH NO ALLOWLIST. W26 carries two declared-safe rows; this
    -- case carries none, because nothing in the .steps family has been
    -- declared safe yet. Every bare site is printed, including the ones a
    -- reader will conclude are fine. That is the point of a census.
    --
    -- ---- THE MEASUREMENT, 2026-07-28, AND WHERE IT CONTRADICTS THE BRIEF ----
    --
    -- The brief that commissioned this pass carried a hand measurement. It was
    -- right about the shape of the problem and wrong about three of the five
    -- numbers, so both are recorded: a census whose provenance is "someone
    -- counted once" is exactly what this case exists to replace.
    --
    --   files                 25          BRIEF SAID 25   agrees
    --   lines touching .steps 305 raw     BRIEF SAID 261  CONTRADICTED. 274 of
    --                         274 code                    the 305 carry the
    --                                                     mention inside a code
    --                                                     span; neither number
    --                                                     is 261 and the brief
    --                                                     does not say which of
    --                                                     the two it meant.
    --   "X.steps or {}"       32 matched  BRIEF SAID 32   agrees, and so does
    --                         31 bare                     the 31-unfixed split:
    --                                                     the one clear is
    --                                                     Data/Defaults.lua:3976,
    --                                                     shipped by 15j.
    --   "if X.steps then"     8 bare      BRIEF SAID 9    RECONCILED, not
    --                                                     contradicted: the
    --                                                     ninth was
    --                                                     Data/Defaults.lua:4002
    --                                                     and EDIT 1b of this
    --                                                     pass type()-tested it.
    --                                                     Nine was correct when
    --                                                     the brief was written.
    --   "X.steps and #X.steps" 17 bare    BRIEF SAID 11   RECONCILED. Eleven are
    --                                                     the dotted spelling;
    --                                                     the other six read a
    --                                                     LOCAL whose name ends
    --                                                     in "Steps"
    --                                                     (compiledSteps,
    --                                                     vCompiledSteps,
    --                                                     effSteps, steps,
    --                                                     SLV.workingSteps),
    --                                                     which BARE_LEN sees
    --                                                     through its
    --                                                     either-case class and
    --                                                     a ".steps" grep does
    --                                                     not.
    --   same-expression index 0           BRIEF SAID 0    agrees.
    --   already type()-tested 35 "=="     BRIEF SAID 33   CONTRADICTED, and the
    --                          7 "~="                     brief's number does
    --                                                     not name which form it
    --                                                     counted. Both are
    --                                                     printed separately
    --                                                     below so the next pass
    --                                                     compares like with
    --                                                     like. One of the 35 is
    --                                                     new in this pass
    --                                                     (Defaults.lua:4002).
    --
    -- The brief's headline -- "roughly 51 bare sites against 33 guarded" -- is
    -- LOW. The measured count is 73 bare, and the extra twenty-two are the six
    -- camelCase-local length reads plus the sixteen the brief's four shape
    -- categories did not add up to in the first place (32 + 9 + 11 + 0 = 52,
    -- against 73 across five shapes; the brief did not count BARE_GATE or
    -- BARE_ANDGATE at all, which are 2 and 15).
    --
    -- ---- TRIAGE OF ALL 73 BARE SITES ------------------------------------
    --
    -- DONE BY READING EVERY SITE, not by pattern, on 2026-07-28. Each was read
    -- with its enclosing function and the binding of its receiver traced to
    -- either caller data or a constructor. The three buckets are the ones this
    -- arc has learned to separate, and the fourth is empty for a stated reason
    -- rather than by omission.
    --
    --   GENUINELY BARE        57   reachable with a scalar, no guard anywhere
    --   SAFE BY CONSTRUCTION  15   the table is built by a constructor in this
    --                              file that cannot emit a scalar
    --   SAFE BY BINDING        1   the receiver is module state that is only
    --                              ever assigned a table
    --   UNCLASSIFIED           0   see the note at the end of this block
    --
    -- SAFE BY CONSTRUCTION, fifteen, and NONE of them should be "fixed":
    --   Import/GRIPExport.lua :100 :279 :282 :331 :444 :672
    --       All six read exportVersions[n].steps, and GE.PrepareExportVersions
    --       makes that field nil-or-table BY CONSTRUCTION: :61 type()-tests
    --       ver.steps, :72 replaces a table with a freshly translated table,
    --       and the else arm at :94 NILS anything else -- absent or scalar --
    --       precisely so the pairs() copy at the head of that loop cannot
    --       launder a scalar downstream. GRIPExport.lua already carries that
    --       argument in a MEASURED comment at :263-275 which names these very
    --       lines and says do not re-flag them. This census re-derived it
    --       independently and agrees. (That comment cites :332/:445/:673; those
    --       are the ipairs lines, the census names the gate line one above.
    --       Same sites, not a stale reference.)
    --   Import/LegacyImport.lua :645 :656
    --   Import/ImportPreview.lua :772 :793
    --   Import/ImportFrame.lua :644
    --       All five read compiled.steps where compiled is LI.CompileMacroVersion's
    --       return. All THREE of its return statements set steps to the local
    --       table built at LegacyImport.lua:1406 -- including the nil-argument
    --       early return -- so the field is a table on every path.
    --   Import/ImportPreview.lua :1304
    --       cv is entry.compiledVersions[1] in the RAW arm. The only producer of
    --       compiledVersions in the tree is Import/RawImport.lua:246, which sets
    --       steps to a locally built array, under format = "RAW" (:231) -- the
    --       same arm this branch tests.
    --   Engine/TempoAdvisor.lua :443, Engine/Engine.lua :1545 :1810
    --       (this row carried the pre-15t 1443 1708 until 15u-polish;
    --       the swept values were already at lines 5936 and 6113 in this file)
    --       compiledSteps / vCompiledSteps are computed, never caller data:
    --       Engine:CompileSteps returns {} or a fresh array, and
    --       ResolveFitAndExpand returns expandFunc(resolved) over a fresh
    --       array. SF:RunExpander rejects a non-table return outright
    --       (StepFunctions.lua:478), so no expander can leak a scalar here.
    --
    -- SAFE BY BINDING, one, and it does not fit the bucket cleanly:
    --   UI/SequenceEditor.lua :3002  SLV.workingSteps
    --       Every assignment to that field in the tree is a table --
    --       StepListView.lua :20 :2347 :5297 :5709 assign {}, and :5309 restores
    --       a prior snapshot of the same field. It is MODULE STATE, not a local
    --       bound table-or-nil by a type() test above it, so the bucket name
    --       fits it only loosely. Recorded that way rather than forced into
    --       "construction": the taxonomy has a gap and pretending otherwise
    --       would hide it from the pass that fixes these.
    --
    -- GENUINELY BARE, fifty-seven. Everything printed below that is not one of
    -- the sixteen named above. THREE OF THEM DO NOT RAISE AT THE SITE and are
    -- called out because their failure is not local:
    --   Engine/Engine.lua:869, Import/ImportPreview.lua:1296,
    --   Import/GRIPExport.lua:860
    --       Each STORES a scalar steps into a sequence table rather than
    --       dereferencing it. Traced rather than waved at: :1296 and :860 both
    --       land in seqData.steps, which reaches Engine:MigrateSequenceFormat,
    --       whose :869 copies it into versions[1].steps, which
    --       Engine:ActivateSequence reads at :1324 and lengths at :1327. So all
    --       three are on a path to a real raise -- just not on their own line.
    --       15u NOTE: :1324 / :1327 IS the sixth site named in the CORRECTED
    --       15t block below -- this row had already walked to it and stopped
    --       one step short of calling it unguarded.
    --
    -- WHY UNCLASSIFIED IS ZERO, stated so it is not read as a claim of
    -- omniscience. Every one of the 73 was opened and its receiver traced; the
    -- five constructors the "safe" verdicts rest on were each READ to their
    -- return statements (LI.CompileMacroVersion, RawImport's preview builder,
    -- Engine:CompileSteps, ResolveFitAndExpand + SF:RunExpander,
    -- GE.PrepareExportVersions), and the three propagating sites above were
    -- traced to a downstream length operator. Nothing was left as a guess. What
    -- this triage does NOT claim is that all 57 are LIVE: reachability of a
    -- corrupt shape at each call site is a separate question, and it is the
    -- question the fixing pass has to answer per site -- 15j's W30 note calls
    -- that the LATENT/live distinction and 15e got it wrong once already.
    --
    -- ==== PASS 15l: THE QUESTION ABOVE IS ANSWERED FOR ONE MODULE ========
    --
    -- ANSWER: THE FAMILY IS LIVE. Measured 2026-07-28, before any .steps site
    -- was touched, by adding to W27 a sequence whose versions is a WELL-FORMED
    -- one-element array carrying steps = 5. RA:Analyze died:
    --     Data/RepairAnalyzer.lua:191: bad argument #1 to 'ipairs'
    --     (table expected, got number)
    -- That is a sequence a user can own -- one bad import, one hand-edited
    -- SavedVariables -- opening the health scan whose entire job is telling
    -- them about it. The 57 stop being candidates and become a demonstrated
    -- defect class. The LATENT/live distinction still stands for the other 46
    -- sites; it is settled for RepairAnalyzer's and for the shape itself.
    --
    -- WHAT THE LABEL ON THIS CASE HIDES, and the 67 / 5 / 1 split.
    -- "W32: .steps census" is a NARROWER name than the scan. buildPatterns
    -- builds "[%w_%.]*[Ss]teps" from the field name, exactly as the .versions
    -- run did, so it matches ANY identifier ending in steps or Steps -- which
    -- is DELIBERATE (it is how the .versions run caught the local-bound
    -- "payloadVersions" spelling) and is a superset by design, not a bug. Of
    -- the 73 bare sites:
    --     67  receivers of the form <something>.steps -- the field proper
    --      5  bare LOCALS: compiledSteps (TempoAdvisor:443, Engine:1545),
    --         vCompiledSteps (Engine:1810), steps (Engine:2255),
    --         effSteps (Engine:2913)
    --      1  a SIBLING FIELD that is not .steps at all: SLV.workingSteps
    --         (UI/SequenceEditor.lua:3002)
    --
    -- THE DISAGREEMENT WITH THE 15k BRIEF IS DEFINITIONAL, NOT DRIFT, and it
    -- is recorded here so nobody re-litigates it a fourth time. Every number
    -- the two sides disagree on has the SAME cause: one denominator requires a
    -- literal dot and the other does not.
    --     length reads   brief 11, here 17   = 11 dotted + 5 bare locals + 1
    --                                          sibling field. Exactly.
    --     lines          brief 261, here 305 raw / 274 code -- same cause,
    --                                          plus the raw-versus-code split.
    --     type()-tested  brief 33, here 35 "==" + 7 "~=" -- same cause.
    -- Re-ran both spellings to confirm. Neither measurement is wrong; they
    -- count different things, and only this one says which.
    --
    -- FIXED AND PROVEN THIS PASS -- Data/RepairAnalyzer.lua ONLY, thirteen
    -- guards, all written in the type() form because "or {}" substitutes for
    -- nil and false and NOT for a scalar:
    --     :191 :412 :727 :878 :1338 :1408 :1553   the ipairs walks
    --     :1229                                   the CheckReadiness binding
    --     :510  :1308                             the "empty steps" gates
    --     :596  :1155                             the taggedSteps comparisons,
    --                                             BOTH halves of each line
    --     :1172                                   the missing-taggedSteps elseif
    -- Twelve of the thirteen are BEHAVIOURALLY PROVEN: each was reverted alone,
    -- the suite went red with the raise naming that line, and the file was
    -- byte-restored and sha256-verified. The thirteenth, :412, is SOURCE-ONLY
    -- for a measured reason that is ALREADY on the record for the three
    -- .versions guards in the same function (see the note at the head of W26):
    -- CheckLegacySlotNames builds slotNameMap from C_Spell.GetSpellName and
    -- returns at :284 when the map is empty, and C_Spell is an ALLOWED_UNKNOWN
    -- row precisely because this harness covers the API-absent branch.
    -- Reverting RepairAnalyzer.lua:412 alone left the suite at 38 passed / 0 failed -- measured,
    -- not assumed. It ships guarded anyway rather than left as the one bare
    -- .steps walk in a function whose sibling .versions walks are guarded.
    --
    -- A CENSUS BLIND SPOT, found by walking into it. TWO of the thirteen --
    -- RepairAnalyzer.lua:510 and :1308 -- are NOT among the 73 and never were. Both are written
    --     not X.steps or #X.steps == 0
    -- and no pattern sees that: BARE_GATE wants "not X.steps then" and BARE_LEN
    -- wants "X.steps and #". `not 5` is false, so the length operator runs on
    -- the scalar and raises, which is how the W27 probe found them -- it walked
    -- into RepairAnalyzer.lua:510 the moment :191 was guarded. THE PATTERN SET IS NOT COMPLETE
    -- AND THE COUNT BELOW IS THEREFORE A FLOOR, not a total. A pass that wants
    -- the real number adds a "not X.steps or #" shape first; this one did not,
    -- because changing the pattern set and the sites in the same pass would
    -- make neither number comparable to 15k's.
    --
    -- THE COUNT AFTER THIS PASS: matched 74 -> 71, cleared 1 -> 9, BARE 73 ->
    -- 62. The eight walks stay MATCHED and become CLEARED (the receiver now
    -- carries its type() test on the same line); the three length reads stop
    -- matching at all, because what precedes " and #" is now '"table"' and not
    -- an identifier ending in Steps. 73 - 11 = 62; RepairAnalyzer.lua:510 and :1308 do not move
    -- the number because they were never in it.
    --
    -- The other two printed numbers moved too, both as they should:
    --   type()-tested   35 "==" -> 48, 7 "~=" -> 9. Thirteen new "==" (seven
    --                   walks, one binding, TWO on each of RepairAnalyzer.lua:596 and :1155, one
    --                   elseif) and two new "~=" (RepairAnalyzer.lua:510, :1308). Adds up exactly.
    --   lines mentioning  305 raw -> 312, 274 CODE -> 274. Seven new prose
    --                   mentions and not one new code mention: the guards
    --                   rewrote lines that already mentioned the field. That
    --                   split earned its keep here -- a raw-only count would
    --                   read as seven new reads.
    --
    -- STILL NOT A GATE, and the bar has not moved. 62 bare sites remain across
    -- 24 other files, none of them triaged for LIVENESS the way this module now
    -- has been. (15m: that 62 is now 70 -- twelve the eighth shape made visible,
    -- minus the four it fixed. Still not a gate, and the bar still has not
    -- moved. See the 15m block at the foot of this note.) Turning this case red before they are fixed or allowlisted WITH
    -- THE REASON EACH IS SAFE would teach the next reader to grow an allowlist
    -- until it goes green, which is how a gate stops meaning anything. The 15
    -- SAFE BY CONSTRUCTION and 1 SAFE BY BINDING rows above are the start of
    -- that allowlist, not the end of it.
    --
    -- MEASURED, NOT FIXED, and named so the next pass does not have to
    -- rediscover them. All are in this module and all are the .steps family,
    -- and NONE is falsifiable from W27 or W28, which is why none was touched:
    --   RepairAnalyzer.lua:806 :808 :844  pass ver.steps to E:AllStepsBakeKpKr and
    --                   MM:BuildStubBody rather than dereferencing it. The
    --                   raise, if any, is in Engine / MacroManager -- the
    --                   modules those passes own -- and the gate above them
    --                   (MM.stubs[n]) is empty in this harness.
    --   :1065 :1078 :1193  same shape, into MM:BuildStubBody / MM:CreateStub.
    --   :1243  a fixFn body: sd.versions[vi].steps[1] = ... indexed the field
    --          without a type() test, so APPLYING that fix on a scalar steps
    --          raised inside the closure. Reachable only when keyPress carries
    --          a /cast or /use.
    --
    --          CLOSED. 15s CORRECTS TWO CLAIMS THIS BULLET USED TO MAKE.
    --
    --          FIRST: "STILL NOT DONE AFTER 15m" is no longer true. 15r fixed
    --          the closure. It now normalises the raw field to a fresh table
    --          before writing -- "if type(v.steps) ~= 'table' then v.steps = {}
    --          end" ahead of "v.steps[1] = v[fld]" -- so every corrupt shape
    --          lands on the same repair the empty table already got.
    --
    --          SECOND: "no existing case drives a fixFn on corrupt data" was
    --          ALREADY WRONG WHEN IT WAS WRITTEN, and it is worth saying so
    --          plainly because that false claim is the whole reason this site
    --          went two passes without a fixture. This same file drove a fix
    --          closure on corrupt data in TWO places at the time:
    --            test_malformed_entry_guards.lua:966  W5 pulls the "Empty steps array" issue out of
    --                   CheckStructure's list and pcalls its fixFn on a seqData
    --                   whose actions array carries a bare 5 at index 2.
    --            test_malformed_entry_guards.lua:2426  W27's CONTROL-FALSIFY block pcalls the "Missing
    --                   versions" fixFn on versions = 5, then RE-ANALYSES the
    --                   repaired data to prove the fix took.
    --          The harness this site needed was sitting in the file the whole
    --          time; only the fixture was missing.
    --
    --          THE FIXTURE NOW EXISTS: see W35 below, which drives this exact
    --          closure end to end over five shapes of ver.steps (absent, 5,
    --          true, "abc", {}) and re-analyses the repaired data. Reverting
    --          15r's normalisation reddens W35 by name.
    --
    -- ==== PASS 15m: THE EIGHTH SHAPE, AND HOW FAR THE FLOOR WAS FROM THE ====
    -- ==== TOTAL                                                          ====
    --
    -- 15l ended with "THE PATTERN SET IS NOT COMPLETE AND THE COUNT BELOW IS
    -- THEREFORE A FLOOR, not a total. A pass that wants the real number adds a
    -- 'not X.steps or #' shape first; this one did not, because changing the
    -- pattern set and the sites in the same pass would make neither number
    -- comparable to 15k's." That was the right call and this is that pass. The
    -- comparability problem it named is handled the only way it can be: BOTH
    -- columns are printed here, and the pattern-set change is stated rather
    -- than absorbed.
    --
    -- THE DENOMINATOR CHANGE, .steps, files=25 throughout:
    --
    --                          15l (7 shapes)   15m +shape   15m +shape+fixes
    --   matched                      71             83             79
    --   cleared                       9              9              9
    --   allowlisted                   0              0              0
    --   BARE                         62             74             70
    --   type()-tested '=="table"'    48             48             48
    --   type()-tested '~="table"'     9              9             13
    --   lines mentioning .steps  312/274        312/274        312/274
    --
    -- READ THE MIDDLE COLUMN FIRST. It is the same tree 15l left, scanned with
    -- one more shape: +12 matched, all 12 BARE. THE FLOOR WAS SHORT BY TWELVE,
    -- NOT BY FOUR. 15l noticed the shape at two RepairAnalyzer sites and this
    -- brief named four more; the scan found twelve, because BARE_NOTLEN uses
    -- the same either-case class BARE_LEN does and therefore sees the
    -- LOCAL-BOUND spelling as well as the dotted one -- the same superset that
    -- caught "payloadVersions" in the .versions run, and the same 67/5/1 split
    -- the note above already records for this field.
    --
    -- ALL TWELVE, as printed by the run below before this pass fixed anything:
    --      4 dotted <receiver>.steps  -- FIXED THIS PASS, all four:
    --          Engine/Engine.lua:2840          RecompileSequence
    --          Import/GRIPExport.lua:921       ImportNative's post-import check
    --          UI/SequenceEditor.lua:5234      SE:AutoDetectIcon
    --          UI/SequenceEditor.lua:6345      SE:UpdatePreview
    --      8 bare LOCALS ending in steps/Steps -- NOT FIXED AT 15l, named so
    --        the next pass does not re-derive them. Read this list together
    --        with the CORRECTED 15t block below it: three of the eight are
    --        now fixed, and the "8" is a BARE_NOTLEN match count, never a
    --        hazard count:
    --          Engine/TempoAdvisor.lua:285   compiledSteps
    --          Engine/TempoAdvisor.lua:938   steps
    --          Engine/BarIntegration.lua:465 steps
    --          Engine/Engine.lua:254         steps          (now :313)
    --          Engine/Engine.lua:307         steps          (now :370)
    --          Engine/Engine.lua:459         compiledSteps  (now :553)
    --          Engine/Engine.lua:1640        effectiveSteps
    --          UI/TrackerHUD.lua:918         steps
    --        The three Engine numbers carrying a "(now :N)" marker are the
    --        PRE-15t values this census run actually printed and are frozen as
    --        that run's own record; the marker is the swept current-tree
    --        pointer, READ at 15u against the line's own text. Every other
    --        number in this block is already current-tree.
    --        Five of the eight read a local the triage above already argued is
    --        SAFE BY CONSTRUCTION for its OTHER read sites (compiledSteps at
    --        TempoAdvisor:443 and Engine:1545, vCompiledSteps at Engine:1810).
    --        THAT ARGUMENT IS NOT AUTOMATICALLY TRANSFERRED to these lines: a
    --        different line binds a differently-produced local, and this arc
    --        has already shipped one defect from assuming a guarded BINDING
    --        says something about a later READ (Data/Defaults.lua:3927, 15k).
    --        Each of the eight has to be traced on its own. None was, here.
    --
    -- CORRECTED 15t. The list above is the BARE_NOTLEN residue, and its
    -- denominator is "lines shaped 'not <something ending in steps> or'".
    -- That denominator was never wrong; it was read as if it were "every
    -- unguarded .steps-family length read", which it is not. Three sites of
    -- the same hazard sit outside it:
    --     Engine/Engine.lua:155   CompileSteps head, "if not steps then".
    --                             (PRE-15t, frozen as the run's own record;
    --                             the fixed head is now at :192, and the :162
    --                             and :163 raise sites below are likewise
    --                             frozen quotes from the 914109d run.)
    --                             No "#", no field name, no length operator
    --                             on the line, so every one of the nine
    --                             shapes is blind to it. Raises at :162 on a
    --                             number and a boolean and at :163 on a
    --                             string. FIXED 15t.
    --     Engine/Engine.lua:2255  "if steps and #steps > 0 then" -- the
    --                             POSITIVE form. Same hazard, opposite
    --                             polarity, invisible to a pattern written
    --                             for "not ... or".
    --     Engine/Engine.lua:2913  "if effSteps and #effSteps > 0 then",
    --                             same positive form.
    -- Of the eight above, three are now FIXED 15t (Engine:313, Engine:370,
    -- Engine:553) and each was measured raising directly on a number, a
    -- boolean and a string before the fix. The remaining five --
    -- TempoAdvisor:285, TempoAdvisor:938, BarIntegration:465, Engine:1640,
    -- TrackerHUD:918 -- plus Engine:2255 and Engine:2913 are unfixed here
    -- for one reason and it is not scope: none of the three .lua suites
    -- loads the file that would drive them, so a fix there cannot be
    -- falsified in the same pass that ships it, and this arc does not ship
    -- guards it cannot redden. Ship target: 15v, which brings those files
    -- under a harness first and fixes second. 15t named 15u for that job;
    -- 15u swept the pointers and named two further sites instead, and did
    -- NOT build the harness. Recorded so the target is not quietly re-aimed
    -- a third time.
    --
    -- EVERY Engine/Engine.lua NUMBER IN THIS FILE IS NOW SWEPT to the
    -- CURRENT tree at 15u, except the few explicitly marked PRE-FIX or
    -- carrying a "(now :N)" marker. Each swept value was READ at the line it
    -- names and checked against that line's own text.
    --
    -- THE OFFSET RULE THIS BLOCK USED TO CARRY WAS WRONG, and it is spelled
    -- out rather than deleted because the wrong version was also written
    -- into a commit body. It said the four guards "moved everything below
    -- the first of them down by exactly 56 lines" and invited the reader to
    -- apply +56 by hand. The four guards created FOUR bands, and git's own
    -- hunk headers say so:
    --     old 159..250  ->  +23      @@ -152,7 +152,30 @@
    --     old 258..303  ->  +37      @@ -251,7 +274,21 @@
    --     old 311..455  ->  +41      @@ -304,7 +341,11 @@
    --     old 463..end  ->  +56      @@ -456,7 +497,22 @@
    -- The six spot-checks offered as evidence -- 641, 2735, 2738, 1538,
    -- 2153, 2811 -- are ALL above old 462, so all six landed in the +56
    -- band. The sample was drawn entirely from the bucket it confirmed, and
    -- a spot-check that never crosses a boundary cannot detect one.
    -- Applying the retired +56 to the four pre-15t guard heads 155, 254,
    -- 307 and 459 gives 211, 310, 363, 515; the measured 15t values are
    -- 178, 291, 348, 515. Three of the four disagree.
    --
    -- 15u THEN SHIFTED THE FILE AGAIN (+68 / -22, net +46, FIVE bands), so
    -- the four guard heads now read Engine.lua:192, :313, :370 and :553.
    -- 15u's own bands are recorded in the head note of
    -- Test/test_stepadv_numsteps_domain.lua. A pointer is checked by reading
    -- the line it points at; adding an offset is not reading, and that is
    -- why this pass swept the citations instead of recording one more
    -- constant for the next reader to misapply.
    --
    -- 15u ADDS A FIFTH SITE AND A SIXTH, both outside every pattern and both
    -- outside the eight:
    --     Engine/Engine.lua:47    ResolveFitAndExpand, a file-local helper with
    --                             NO shape test, reaching ipairs at :65. Nine of
    --                             the twelve activation and recompile compile
    --                             branches route through it.
    --     Engine/Engine.lua:1324  ActivateSequence, "local steps = ver and
    --                             ver.steps or {}" then "#steps" at :1327. The
    --                             twin of Engine:2840 in RecompileSequence,
    --                             which IS shape-tested. Only one twin was
    --                             fixed.
    -- Neither is guarded in 15u, and the blocker is measured rather than
    -- asserted: unconditional-error probes at fccd100 showed ActivateSequence is
    -- not entered past :1315 by any suite, and both variant blocks are unreached,
    -- so a guard at either site could not be reddened in the pass that shipped
    -- it. Ship target 15v: a SET B fixture that stubs CreateFrame (four stubs
    -- already exist under GRIP/Hub/Tools/lua_headless/) and walks
    -- ActivateSequence from :1302 to :1513, then the guards, then the seven
    -- remaining .steps sites.
    --
    -- AND THE COUNT MOVES AGAIN, which is the point of this whole block. "Eight"
    -- was eight BARE_NOTLEN matches. 15t named three more. 15u names two more.
    -- The number will keep moving until someone enumerates by ANCHOR -- every
    -- function whose parameter or local is a steps-family value -- instead of by
    -- match shape.
    --
    -- THE GENERAL FORM, because this is the third time a count in this arc
    -- has been read past its denominator: a residue list is a statement
    -- about the pattern that produced it. "Eight" was always eight
    -- BARE_NOTLEN matches. It was never eight hazards.
    --
    -- THE FOUR FIXES, and why they LEAVE the census rather than moving into
    -- "cleared". Each was rewritten to the type() form:
    --     if not ver.steps or #ver.steps == 0            ->
    --     if type(ver.steps) ~= "table" or #ver.steps == 0
    -- which no longer contains "not <something ending in steps> or", so it
    -- stops matching BARE_NOTLEN entirely -- matched 83 -> 79 and BARE 74 -> 70
    -- together. That is the same bookkeeping 15l recorded for its three length
    -- reads ("stop matching at all, because what precedes ' and #' is now
    -- '\"table\"'"), and it is why the '~= "table"' count is the number that
    -- actually shows the four fixes: 9 -> 13. A reader tracking only BARE
    -- would see 62 -> 70 and read it as eight regressions; it is twelve
    -- newly-VISIBLE sites minus the four fixed.
    --
    -- WHAT THE FOUR FIXES ARE WORTH, measured, and it is less than a green
    -- suite suggests. NONE of the four is behaviourally proven. Each was
    -- reverted alone and all three .lua suites plus the 46-file headless suite
    -- stayed green, so the revert is a measured NULL -- and then each was
    -- probed with an unconditional error() at the site to separate "not
    -- reached" from "reached with well-formed data", because a green revert
    -- alone cannot tell those apart and this note would otherwise claim the
    -- weaker of the two:
    --     Engine/Engine.lua:2840     REACHED, SET A only. The probe reddened 8
    --                                cases in
    --                                Test/test_stepadv_numsteps_domain.lua,
    --                                which drives the real RecompileSequence,
    --                                and was silent across the 46-file headless
    --                                suite. Every fixture carries a well-formed
    --                                table steps, so the bare read never raised.
    --     Import/GRIPExport.lua:921  REACHED, SET A AND SET B. The probe
    --                                reddened W16 and W25 in this file and
    --                                test_signature_v2.lua plus
    --                                test_talent_coalesce_provenance.lua
    --                                headless. W25 drives a SCALAR versions,
    --                                which makes GetActiveVersion return nil,
    --                                so "not ver" short-circuits ahead of the
    --                                steps read; no fixture anywhere carries a
    --                                well-formed version whose steps is a
    --                                scalar. This is the single best-covered of
    --                                the four and the cheapest one to prove.
    --     UI/SequenceEditor.lua:5234 NOT REACHED. The file IS loaded headless
    --     UI/SequenceEditor.lua:6345 by test_v0_upgrade_guard.lua,
    --                                so this is not a file-not-loaded excuse --
    --                                the probes were silent across all four
    --                                suites because SE:AutoDetectIcon and
    --                                SE:UpdatePreview are never called.
    -- SOURCE-ONLY, all four, and no fixture was fabricated for any of them.
    -- The two REACHED rows are the cheapest next behavioural proofs in this
    -- family and are the ones a later pass should take first: each needs one
    -- fixture carrying a well-formed version whose steps is a scalar.
    --
    -- THE RUNNING TOTALS STAY SEPARATE, which is the rule the note above
    -- states and this pass does not bend. .versions is still TWENTY of
    -- forty-five behaviourally proven -- these four are .steps and change it by
    -- nothing. The .steps family is counted on its own: 15l proved twelve of
    -- its thirteen RepairAnalyzer guards behaviourally and 15m adds four
    -- guards and zero proofs.
    -- ===================================================================
    local FIELD = "steps"

    -- The file set, straight out of the TOC.
    local toc = readSource("GRIP-EMS.toc")
    assertTrue(toc ~= nil, "could not locate GRIP-EMS.toc (run from the EMS root)")
    local fileSet, sources, skipped = {}, {}, 0
    for raw in (toc .. "\n"):gmatch("(.-)\n") do
        local entry = raw:gsub("^%s*(.-)%s*$", "%1"):gsub("\\", "/")
        if entry ~= "" and entry:sub(1, 1) ~= "#" and entry:sub(-4):lower() == ".lua" then
            local skip = entry:sub(1, 5) == "Libs/" or entry:sub(1, 5) == "Test/"
            if not skip then
                local src = readSource(entry)
                if src == nil then
                    skipped = skipped + 1
                elseif src:find("." .. FIELD, 1, true) then
                    fileSet[#fileSet + 1] = entry
                    sources[entry] = src
                end
            end
        end
    end

    -- MENTIONS, split code versus text. A raw grep counts prose, and this arc
    -- spent a whole pass (15g) on the difference between a READ and a REMARK
    -- ABOUT A READ. Both numbers are printed: the raw one so a hand grep
    -- reconciles, the code one because it is the only one that means anything.
    local mentionsRaw, mentionsCode, perFile = 0, 0, {}
    for _, rel in ipairs(fileSet) do
        local rawLines, codeLines, lineNo = 0, 0, 0
        for line in (sources[rel] .. "\n"):gmatch("(.-)\n") do
            lineNo = lineNo + 1
            local pos, hitRaw, hitCode = 1, false, false
            while true do
                local s = line:find("." .. FIELD, pos, true)
                if not s then
                    break
                end
                pos = s + 1
                hitRaw = true
                if startsInCode(codeSpans(line), s) then
                    hitCode = true
                end
            end
            if hitRaw then
                rawLines = rawLines + 1
            end
            if hitCode then
                codeLines = codeLines + 1
            end
        end
        perFile[rel] = { raw = rawLines, code = codeLines }
        mentionsRaw = mentionsRaw + rawLines
        mentionsCode = mentionsCode + codeLines
    end

    -- TYPE-TESTED OCCURRENCES, counted separately from "cleared". They are not
    -- the same number and conflating them is easy: "cleared" counts only the
    -- type-tested reads that ALSO match one of the seven bare shapes, which is
    -- a small subset. Most guarded reads in this family are written in a shape
    -- no bare pattern matches at all ('if type(ver.steps) ~= "table" then
    -- return end'), so they are invisible to matched/cleared and would look
    -- like an absence of guarding if only those two were printed.
    local guardEq, guardNe = 0, 0
    for _, rel in ipairs(fileSet) do
        for line in (sources[rel] .. "\n"):gmatch("(.-)\n") do
            local spans = codeSpans(line)
            for _, form in ipairs({ { "==", 0 }, { "~=", 1 } }) do
                local pos = 1
                while true do
                    local s = line:find("type%([%w_%.]*[Ss]teps%)%s*" .. form[1] .. "%s*[\"']table[\"']", pos)
                    if not s then
                        break
                    end
                    pos = s + 1
                    if startsInCode(spans, s) then
                        if form[2] == 0 then
                            guardEq = guardEq + 1
                        else
                            guardNe = guardNe + 1
                        end
                    end
                end
            end
        end
    end

    local scan, patterns = makeScanner(FIELD, {})
    local offenders, seenSafe = {}, {}
    local stats = newScanStats()
    for _, rel in ipairs(fileSet) do
        scan(sources[rel], rel, offenders, seenSafe, stats)
    end

    print("")
    print("  ================ W32 .steps CENSUS -- MEASUREMENT ONLY ================")
    print(string.format("  field=%s   files=%d   unreadable-toc-entries=%d", FIELD, #fileSet, skipped))
    print(
        string.format("  lines mentioning .%s : %d raw, %d with the mention in CODE", FIELD, mentionsRaw, mentionsCode)
    )
    print(
        string.format(
            "  matched=%d  cleared=%d  allowlisted=%d  BARE=%d   (matched == cleared + allowlisted + bare)",
            stats.matched,
            stats.cleared,
            stats.allowlisted,
            stats.offenders
        )
    )

    print(
        string.format(
            "  type()-tested occurrences in CODE: %d written '== \"table\"', %d written '~= \"table\"'",
            guardEq,
            guardNe
        )
    )

    print("  ---- pattern set (built from the field name by buildPatterns) ----")
    for _, shape in ipairs(patterns) do
        print(string.format("    %-13s %s", shape.name, shape.pattern))
    end

    print("  ---- file set (raw / code mentions) ----")
    for _, rel in ipairs(fileSet) do
        print(string.format("    %-32s %3d / %3d", rel, perFile[rel].raw, perFile[rel].code))
    end

    print("  ---- bare sites, grouped by shape ----")
    for _, name in ipairs(PATTERN_ORDER) do
        local n = stats.byShape[name] or 0
        print(string.format("    %s  (%d)", name, n))
        for _, site in ipairs(stats.bare) do
            if site.shape == name then
                print(string.format("      %s:%d  [%s]  %s", site.file, site.line, site.receiver, site.text))
            end
        end
    end

    -- 15n: THE RESIDUAL BUCKET over the SAME file set this case already
    -- derived. Everything above measures the shapes that ARE encoded; the four
    -- lines below measure what is left, which is the only part of this file set
    -- that has ever hidden a shape. It asserts nothing, like the rest of W32.
    --
    -- The "lines mentioning" pair printed near the top of this census is the
    -- SAME walk A uses -- an in-code plain-substring occurrence of "." .. FIELD
    -- -- so A must equal the CODE figure there. If it ever does not, one of the
    -- two walks has been edited and the other has not.
    print("")
    printResidual(FIELD, residualBuckets(FIELD, fileSet, sources, stats.matchedLines))
    print("  =======================================================================")
    print("")
end)

test("W34: .actions/.stepLabels/.taggedSteps/.Actions/.ElseActions census -- MEASUREMENT ONLY", function()
    -- ===================================================================
    -- READ THIS BEFORE "FIXING" ANYTHING THIS CASE PRINTS. Every word of
    -- W32's opening note applies here unchanged: THIS IS NOT A GATE AND MUST
    -- NOT BECOME ONE until the sites it prints have been triaged, fixed or
    -- allowlisted WITH the reason each is safe. It asserts nothing and cannot
    -- fail. Three passes in this arc have already rediscovered that a fix
    -- applied without reading the site MOVES a crash instead of removing it.
    --
    -- WHY THESE THREE FIELDS AND NOT OTHERS. They are the SIBLING FIELDS OF
    -- .steps on the same version table -- a version carries steps, actions,
    -- stepLabels and taggedSteps together -- so the corrupt-import path that
    -- made .steps a scalar reaches all four by exactly the same route. That is
    -- the whole argument for scanning them, and it is an argument about the
    -- data model, not about anything measured yet.
    --
    -- IT COSTS ONE CALL PER FIELD. The scanner has been field-parameterised
    -- since 15k, so nothing here is new machinery: the same nine shapes, the
    -- same codeSpans, the same left token boundary, the same receiver-scoped
    -- bareness rule and the same A/B/C/D bucketing that W26 and W32 print.
    --
    -- THE FILE SET IS DERIVED THE SAME WAY W32 DERIVES ITS OWN -- every .lua
    -- in the TOC that is not Libs/ or Test/ and that mentions the field -- so
    -- a new shipped file joins the census the moment it is added to the TOC.
    -- The walk is repeated here rather than hoisted out of W32, because
    -- rewriting a shipped case to serve a new one is how a census stops being
    -- comparable to the runs already quoted against it.
    --
    -- A MEASURED ZERO IS A RESULT. If a field carries no bare sites, this case
    -- says so with a number rather than by staying silent.
    --
    -- THE RUNNING TOTALS STAY SEPARATE. .versions is still twenty of
    -- forty-five behaviourally proven; .steps is counted on its own; these
    -- three fields have ZERO behavioural proofs and this pass adds none --
    -- it fixes nothing and asserts nothing.
    -- ===================================================================
    local toc = readSource("GRIP-EMS.toc")
    assertTrue(toc ~= nil, "could not locate GRIP-EMS.toc (run from the EMS root)")

    -- 15p: the two WIRE-FORMAT sibling fields join the list. "Actions" and
    -- "ElseActions" are the capitalised names a decoded legacy payload carries
    -- on an If action, and they are read bare in Import/LegacyImport.lua by
    -- exactly the route this census exists to find. W34 IS AND STAYS
    -- MEASUREMENT ONLY -- adding them asserts nothing and gates nothing.
    --
    -- ONE WRINKLE A READER MUST HAVE BEFORE INTERPRETING THE OUTPUT.
    -- buildPatterns builds BARE_LEN, BARE_PAREN and BARE_NOTLEN from an
    -- EITHER-CASE class on the first character of the field name. For the
    -- field "Actions" that class is [Aa]ctions -- byte for byte the same class
    -- the field "actions" produces. Those THREE shapes are therefore NOT
    -- disjoint between "Actions" and "actions", and their counts MUST NOT be
    -- added together across the two blocks; the same line can be counted in
    -- both. The other six shapes anchor on the literal dotted field name and
    -- ARE disjoint. Report both blocks as measured and do not attempt to
    -- reconcile the overlapping three.
    for _, FIELD in ipairs({ "actions", "stepLabels", "taggedSteps", "Actions", "ElseActions" }) do
        local fileSet, sources, skipped = {}, {}, 0
        for raw in (toc .. "\n"):gmatch("(.-)\n") do
            local entry = raw:gsub("^%s*(.-)%s*$", "%1"):gsub("\\", "/")
            if entry ~= "" and entry:sub(1, 1) ~= "#" and entry:sub(-4):lower() == ".lua" then
                local skip = entry:sub(1, 5) == "Libs/" or entry:sub(1, 5) == "Test/"
                if not skip then
                    local src = readSource(entry)
                    if src == nil then
                        skipped = skipped + 1
                    elseif src:find("." .. FIELD, 1, true) then
                        fileSet[#fileSet + 1] = entry
                        sources[entry] = src
                    end
                end
            end
        end

        -- Mentions, split raw versus code, by the same walk W32 prints.
        local mentionsRaw, mentionsCode, perFile = 0, 0, {}
        for _, rel in ipairs(fileSet) do
            local rawLines, codeLines = 0, 0
            for line in (sources[rel] .. "\n"):gmatch("(.-)\n") do
                local pos, hitRaw, hitCode = 1, false, false
                while true do
                    local s = line:find("." .. FIELD, pos, true)
                    if not s then
                        break
                    end
                    pos = s + 1
                    hitRaw = true
                    if startsInCode(codeSpans(line), s) then
                        hitCode = true
                    end
                end
                if hitRaw then
                    rawLines = rawLines + 1
                end
                if hitCode then
                    codeLines = codeLines + 1
                end
            end
            perFile[rel] = { raw = rawLines, code = codeLines }
            mentionsRaw = mentionsRaw + rawLines
            mentionsCode = mentionsCode + codeLines
        end

        -- type()-tested occurrences, counted separately from "cleared" for the
        -- reason W32 records: most guarded reads in these families are written
        -- in a shape no bare pattern matches at all, so matched/cleared alone
        -- would read as an absence of guarding.
        local guardEq, guardNe = 0, 0
        local eitherCase = "[" .. FIELD:sub(1, 1):upper() .. FIELD:sub(1, 1):lower() .. "]" .. FIELD:sub(2)
        for _, rel in ipairs(fileSet) do
            for line in (sources[rel] .. "\n"):gmatch("(.-)\n") do
                local spans = codeSpans(line)
                for _, form in ipairs({ { "==", 0 }, { "~=", 1 } }) do
                    local pos = 1
                    while true do
                        local s =
                            line:find("type%([%w_%.]*" .. eitherCase .. "%)%s*" .. form[1] .. "%s*[\"']table[\"']", pos)
                        if not s then
                            break
                        end
                        pos = s + 1
                        if startsInCode(spans, s) then
                            if form[2] == 0 then
                                guardEq = guardEq + 1
                            else
                                guardNe = guardNe + 1
                            end
                        end
                    end
                end
            end
        end

        local scan, patterns = makeScanner(FIELD, {})
        local offenders, seenSafe = {}, {}
        local stats = newScanStats()
        for _, rel in ipairs(fileSet) do
            scan(sources[rel], rel, offenders, seenSafe, stats)
        end

        print("")
        print(string.format("  ================ W34 .%s CENSUS -- MEASUREMENT ONLY ================", FIELD))
        print(string.format("  field=%s   files=%d   unreadable-toc-entries=%d", FIELD, #fileSet, skipped))
        print(
            string.format(
                "  lines mentioning .%s : %d raw, %d with the mention in CODE",
                FIELD,
                mentionsRaw,
                mentionsCode
            )
        )
        print(
            string.format(
                "  matched=%d  cleared=%d  allowlisted=%d  BARE=%d   (matched == cleared + allowlisted + bare)",
                stats.matched,
                stats.cleared,
                stats.allowlisted,
                stats.offenders
            )
        )
        print(
            string.format(
                "  type()-tested occurrences in CODE: %d written '== \"table\"', %d written '~= \"table\"'",
                guardEq,
                guardNe
            )
        )

        print("  ---- file set (raw / code mentions) ----")
        for _, rel in ipairs(fileSet) do
            print(string.format("    %-32s %3d / %3d", rel, perFile[rel].raw, perFile[rel].code))
        end

        print("  ---- bare sites, grouped by shape ----")
        for _, name in ipairs(PATTERN_ORDER) do
            local n = stats.byShape[name] or 0
            print(string.format("    %s  (%d)", name, n))
            for _, site in ipairs(stats.bare) do
                if site.shape == name then
                    print(string.format("      %s:%d  [%s]  %s", site.file, site.line, site.receiver, site.text))
                end
            end
        end
        if stats.offenders == 0 then
            print(string.format("    NO BARE SITES for .%s under the nine shapes -- a measured zero.", FIELD))
        end

        print("")
        printResidual(FIELD, residualBuckets(FIELD, fileSet, sources, stats.matchedLines))
        print(string.format("  ---- pattern set for .%s (built by buildPatterns) ----", FIELD))
        for _, shape in ipairs(patterns) do
            print(string.format("    %-13s %s", shape.name, shape.pattern))
        end
        print("  =======================================================================")
        print("")
    end
end)

-- ---------------------------------------------------------------------------
-- Census gate. Registered LAST on purpose: the runner below executes in
-- registration order, so this case sees the census every case above it built.
-- ---------------------------------------------------------------------------

test("W21: no unknown global is read outside ALLOWED_UNKNOWN", function()
    local offenders = {}
    for name, count in pairs(UNKNOWN_GLOBALS) do
        if not ALLOWED_UNKNOWN[name] then
            offenders[#offenders + 1] = { name = name, count = count }
        end
    end
    table.sort(offenders, function(a, b)
        return a.name < b.name
    end)
    if #offenders > 0 then
        local lines = {}
        for _, o in ipairs(offenders) do
            lines[#lines + 1] = "    " .. o.name .. "  read " .. tostring(o.count) .. "x"
        end
        error(
            "unknown globals read by the loaded modules, not on ALLOWED_UNKNOWN:\n"
                .. table.concat(lines, "\n")
                .. "\n  The harness serves each of these as nil. Decide per name: if the read"
                .. " is UNGUARDED, add a realistically-shaped WOW_GLOBALS stub (that is how"
                .. " InCombatLockdown was resolved); if the live client can genuinely serve"
                .. " nil there and the product does the right thing, add an ALLOWED_UNKNOWN"
                .. " row with the reason. Do not delete this assertion.",
            0
        )
    end

    -- The other direction. An ALLOWED_UNKNOWN row that nothing reads any more
    -- is a standing exemption for a name no longer under observation, so it
    -- must be pruned rather than left to cover a future unguarded read.
    local stale = {}
    for name in pairs(ALLOWED_UNKNOWN) do
        if UNKNOWN_GLOBALS[name] == nil then
            stale[#stale + 1] = name
        end
    end
    table.sort(stale)
    assertTrue(#stale == 0, "ALLOWED_UNKNOWN rows nothing reads any more -- prune them: " .. table.concat(stale, ", "))
end)

-- ---------------------------------------------------------------------------
-- Run.
-- ---------------------------------------------------------------------------

local passed = 0
local failed = 0
for _, t in ipairs(tests) do
    local ok, err = pcall(t.fn)
    if ok then
        passed = passed + 1
        print("PASS  " .. t.name)
    else
        failed = failed + 1
        print("FAIL  " .. t.name .. " -- " .. tostring(err))
    end
end
print(string.format("RESULT %d passed, %d failed", passed, failed))
os.exit(failed > 0 and 1 or 0)
