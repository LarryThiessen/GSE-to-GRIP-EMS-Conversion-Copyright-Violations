-- GRIP-EMS: Conditional Builder
-- Modal dialog for multi-bracket OR group editing.
-- Created: 2026-05-11
-- Updated: 2026-06-21
-- Patch: 12.0.7.68256 Midnight (Retail LIVE)
--
-- Sibling to ConditionalPicker (single-clause AND popup). Opens
-- when StepListView [v] detects multi-bracket input.
-- Phase H4b ships the chrome + read-only multi-clause viewer.
-- Phase H4c flips it to interactive; H4d adds Targeting tab.

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

GRIPEMS.ConditionalBuilder = {}
local CB = GRIPEMS.ConditionalBuilder

---------------------------------------------------------------------------
-- Constants
---------------------------------------------------------------------------
local MODAL_WIDTH = 520
local MODAL_HEIGHT = 600
local CLAUSE_MIN_HEIGHT = 180
local CLAUSE_HEADER_HEIGHT = 22
local FOOTER_HEIGHT = 32
local CONTENT_PAD = 8

---------------------------------------------------------------------------
-- State
---------------------------------------------------------------------------
CB._frame = nil
CB._targetEditBox = nil
CB._anchorFrame = nil
CB._onApply = nil
CB._parsed = nil
CB._clauses = {}

-- Per-clause state shape (see H4 spec doc "State model"):
--   _clauses[i] = {
--       rowState = { [key] = { selected, negate, paramValue } },
--       targeting = { mode, unitArg },
--       activeTab = "combat",
--       frame = <sub-frame ref>,
--   }

---------------------------------------------------------------------------
-- Forward declarations
---------------------------------------------------------------------------
-- H4c: forward-declared so closures inside createFrame and
-- renderClauseSubFrame can resolve them as locals at parse time. Each is
-- assigned later via `function foo()` (no `local` keyword) so the
-- assignment writes back into the forward-declared local instead of
-- creating a fresh shadow. The pair is necessary because:
--   - createFrame's Apply OnClick + addBtn OnClick reference helpers
--     that depend on buildJoinedOutput / renderClauseSubFrame.
--   - rerenderClauseStack and renderClauseSubFrame form a circular ref
--     (rerender drives render; render's Remove OnClick calls rerender).
local renderClauseSubFrame
local buildJoinedOutput

---------------------------------------------------------------------------
-- Clause-state helpers
---------------------------------------------------------------------------

local function isClauseEmpty(clauseState)
    if not clauseState then
        return true
    end
    -- H4d: a clause with a targeting prefix is non-empty even if zero
    -- rows are selected. `[@focus]` is valid WoW syntax (sets the cast
    -- target for the bracket without participating in true/false logic).
    if clauseState.targeting and clauseState.targeting.mode then
        local m = clauseState.targeting.mode
        if m == "@focus" or m == "@cursor" or m == "@none" then
            return false
        end
        -- @unit and target= require a non-empty unitArg to emit a valid
        -- token; treat them as empty until unitArg is set so the Apply
        -- gate prevents bare `@` or bare `target=` from being emitted.
        if (m == "@unit" or m == "target=") and clauseState.targeting.unitArg ~= "" then
            return false
        end
    end
    if not clauseState.rowState then
        return true
    end
    for _, st in pairs(clauseState.rowState) do
        if st.selected then
            return false
        end
    end
    return true
end

local function ensureClauseRowState(clauseState)
    local data = GRIPEMS.ConditionalPickerData
    if not data then
        return
    end
    for _, row in ipairs(data.rows) do
        if not clauseState.rowState[row.key] then
            clauseState.rowState[row.key] = {
                selected = false,
                negate = false,
                paramValue = nil,
            }
        end
    end
end

---------------------------------------------------------------------------
-- Refresh helpers
---------------------------------------------------------------------------

local function refreshClauseEmptyWarn(clauseState)
    if not clauseState or not clauseState.frame then
        return
    end
    local warnLbl = clauseState.frame._emptyWarn
    if warnLbl then
        warnLbl:SetShown(isClauseEmpty(clauseState))
    end
end

local function refreshApplyGate()
    if not CB._frame or not CB._frame.applyBtn then
        return
    end
    local anyEmpty = false
    for _, cs in ipairs(CB._clauses) do
        if isClauseEmpty(cs) then
            anyEmpty = true
            break
        end
    end
    CB._frame.applyBtn:SetEnabled(not anyEmpty)
end

local function refreshBuilderPreview()
    if CB._frame and CB._frame.previewLabel then
        CB._frame.previewLabel:SetText(
            string.format(L["GEMS_IF_BUILDER_PREVIEW"] or "Preview: %s", buildJoinedOutput())
        )
    end
end

local function rerenderClauseStack()
    if not CB._frame or not CB._frame.scrollContent then
        return
    end
    -- H4c.3: iterate scrollContent's actual children rather than
    -- CB._clauses. The Lua reference graph and the WoW parent-child
    -- graph diverge when any path removes a clauseState from
    -- CB._clauses BEFORE its sub-frame is hidden (the Remove
    -- handler at L335-L344 does exactly this). Iterating
    -- GetChildren catches orphans regardless of whether their
    -- clauseState is still in CB._clauses. Idempotent: Hide on
    -- already-hidden frame is no-op; ClearAllPoints on
    -- already-cleared frame is no-op.
    local children = { CB._frame.scrollContent:GetChildren() }
    for _, child in ipairs(children) do
        if child then
            child:Hide()
            child:ClearAllPoints()
        end
    end
    -- Nil the frame refs on remaining clauses so the render loop
    -- below assigns fresh sub-frames. The children-sweep above
    -- already hid them; this just synchronizes the Lua side.
    for _, cs in ipairs(CB._clauses) do
        cs.frame = nil
    end
    local y = 0
    for i, cs in ipairs(CB._clauses) do
        cs.frame = renderClauseSubFrame(CB._frame.scrollContent, i, cs)
        if cs.frame then
            cs.frame:ClearAllPoints()
            cs.frame:SetPoint("TOPLEFT", CB._frame.scrollContent, "TOPLEFT", 0, -y)
            y = y + cs.frame:GetHeight() + 6
        end
    end
    CB._frame.scrollContent:SetHeight(y > 0 and y or 1)
end

---------------------------------------------------------------------------
-- Frame factory
---------------------------------------------------------------------------

local function createFrame()
    if CB._frame then
        return CB._frame
    end

    local UI = GRIPEMS.UI
    local C = UI.Colors

    local frame = CreateFrame("Frame", "GRIPEMS_ConditionalBuilder", UIParent, "BackdropTemplate")
    frame:SetSize(MODAL_WIDTH, MODAL_HEIGHT)
    frame:SetFrameStrata("DIALOG")
    frame:SetToplevel(true)
    frame:EnableMouse(true)
    frame:SetMovable(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", frame.StartMoving)
    frame:SetScript("OnDragStop", frame.StopMovingOrSizing)

    -- H4c: palette-aware backdrop. Routes through the shared UI helper +
    -- registers the modal for contrast-preset repaints so the builder
    -- chrome matches the picker (Phase 3 #12 Pass A parity). The raw
    -- SetBackdrop block was H4b chrome; H4c replaces it with the shared
    -- helper so the modal repaints when the user switches contrast.
    UI:ApplyBackdrop(frame, UI.Backdrops.panel, C.bgPanel, C.border)
    if UI.RegisterPanelFrame then
        UI:RegisterPanelFrame(frame, "panel", "panel.conditionalBuilder")
    end

    local header = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    header:SetPoint("TOP", frame, "TOP", 0, -10)
    header:SetText(L["GEMS_IF_BUILDER_TITLE"] or "Conditional builder")
    frame.header = header

    local closeBtn = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
    closeBtn:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -4, -4)
    closeBtn:SetScript("OnClick", function()
        CB:Close()
    end)
    frame.closeBtn = closeBtn

    local contentLbl = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    contentLbl:SetPoint("TOPLEFT", frame, "TOPLEFT", CONTENT_PAD, -32)
    contentLbl:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -CONTENT_PAD, -32)
    contentLbl:SetJustifyH("LEFT")
    contentLbl:SetWordWrap(true)
    frame.contentLbl = contentLbl

    local scrollFrame = CreateFrame("ScrollFrame", nil, frame, "UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT", frame, "TOPLEFT", CONTENT_PAD, -64)
    scrollFrame:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -CONTENT_PAD - 22, FOOTER_HEIGHT + 24)

    local scrollContent = CreateFrame("Frame", nil, scrollFrame)
    scrollContent:SetSize(MODAL_WIDTH - 2 * CONTENT_PAD - 22, 1)
    scrollFrame:SetScrollChild(scrollContent)
    frame.scrollFrame = scrollFrame
    frame.scrollContent = scrollContent

    local previewLabel = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    previewLabel:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", CONTENT_PAD, FOOTER_HEIGHT + 4)
    previewLabel:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -CONTENT_PAD, FOOTER_HEIGHT + 4)
    previewLabel:SetJustifyH("LEFT")
    previewLabel:SetWordWrap(true)
    frame.previewLabel = previewLabel

    local applyBtn = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    applyBtn:SetSize(90, 22)
    applyBtn:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -CONTENT_PAD, CONTENT_PAD)
    applyBtn:SetText(L["GEMS_IF_BUILDER_APPLY"] or "Apply")
    applyBtn:SetScript("OnClick", function()
        if CB._targetEditBox then
            -- H4c: emit the rebuilt joined output, then fire OnTextChanged
            -- so the existing path-badge + live validation hooks repaint.
            -- Wrapped in pcall because OnTextChanged is allowed to mutate
            -- the editbox and downstream callers tolerate spurious calls.
            local joined = buildJoinedOutput()
            CB._targetEditBox:SetText(joined)
            local handler = CB._targetEditBox:GetScript("OnTextChanged")
            if handler then
                pcall(handler, CB._targetEditBox, true)
            end
        end
        if CB._onApply then
            CB._onApply()
        end
        CB:Close()
    end)
    frame.applyBtn = applyBtn

    local cancelBtn = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    cancelBtn:SetSize(90, 22)
    cancelBtn:SetPoint("BOTTOMRIGHT", applyBtn, "BOTTOMLEFT", -6, 0)
    cancelBtn:SetText(L["GEMS_IF_BUILDER_CANCEL"] or "Cancel")
    cancelBtn:SetScript("OnClick", function()
        CB:Close()
    end)
    frame.cancelBtn = cancelBtn

    -- H4c: Add OR clause button. Appends a fresh empty clause to CB._clauses,
    -- re-renders the stack, and refreshes the Apply gate. The new clause
    -- starts empty so Apply auto-disables until the user adds a condition
    -- or removes the new clause. Anchored above the preview FontString
    -- (which sits at the modal footer above the Apply/Cancel buttons).
    local addBtn = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    addBtn:SetSize(140, 22)
    addBtn:SetText(L["GEMS_IF_BUILDER_ADD_OR_CLAUSE"] or "+ Add OR clause")
    addBtn:SetPoint("BOTTOM", previewLabel, "TOP", 0, 8)
    addBtn:SetScript("OnClick", function()
        local newClause = {
            rowState = {},
            targeting = { mode = nil, unitArg = "" },
            activeTab = "combat",
            frame = nil,
        }
        ensureClauseRowState(newClause)
        CB._clauses[#CB._clauses + 1] = newClause
        rerenderClauseStack()
        refreshBuilderPreview()
        refreshApplyGate()
    end)
    frame.addBtn = addBtn

    tinsert(UISpecialFrames, "GRIPEMS_ConditionalBuilder")

    CB._frame = frame
    return frame
end

---------------------------------------------------------------------------
-- Per-clause sub-frame factory
---------------------------------------------------------------------------

-- H4c: assignment (not `local function`) writes back into the forward-
-- declared local so rerenderClauseStack -- declared earlier in the file --
-- can call this function via the captured upvalue.
function renderClauseSubFrame(parent, clauseIndex, clauseState)
    local data = GRIPEMS.ConditionalPickerData
    if not data then
        return nil
    end

    local UI = GRIPEMS.UI
    local C = UI and UI.Colors

    local sub = CreateFrame("Frame", nil, parent, "BackdropTemplate")
    local subWidth = (parent:GetWidth() > 0 and parent:GetWidth()) or (MODAL_WIDTH - 2 * CONTENT_PAD - 22)
    sub:SetSize(subWidth, CLAUSE_MIN_HEIGHT)
    if sub.SetBackdrop then
        sub:SetBackdrop({
            edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
            tile = false,
            edgeSize = 10,
            insets = { left = 2, right = 2, top = 2, bottom = 2 },
        })
        sub:SetBackdropBorderColor(0.3, 0.3, 0.3, 0.8)
    end

    local headerFmt = L["GEMS_IF_BUILDER_CLAUSE_HEADER"] or "OR clause %d"
    local headerLbl = sub:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    headerLbl:SetPoint("TOPLEFT", sub, "TOPLEFT", 6, -4)
    headerLbl:SetText(string.format(headerFmt, clauseIndex))
    sub.headerLbl = headerLbl

    local removeBtn = CreateFrame("Button", nil, sub, "UIPanelButtonTemplate")
    removeBtn:SetSize(70, 18)
    removeBtn:SetPoint("TOPRIGHT", sub, "TOPRIGHT", -6, -4)
    removeBtn:SetText(L["GEMS_IF_BUILDER_REMOVE_CLAUSE"] or "Remove")
    -- H4c: Remove disabled while only one clause remains so the user
    -- cannot empty the modal. rerenderClauseStack repaints this state
    -- whenever the clause count changes (Add OR clause / Remove path).
    removeBtn:SetEnabled(#CB._clauses > 1)
    removeBtn:SetScript("OnClick", function()
        for i = 1, #CB._clauses do
            if CB._clauses[i] == clauseState then
                table.remove(CB._clauses, i)
                rerenderClauseStack()
                refreshBuilderPreview()
                refreshApplyGate()
                break
            end
        end
    end)
    sub.removeBtn = removeBtn

    -- H4c: empty-clause warning. Shown when the clause has zero selected
    -- rows; hidden as soon as the user ticks anything. Apply auto-gates
    -- while any clause is empty so the modal cannot emit []-bracket
    -- artifacts. Anchored RIGHT to removeBtn's LEFT so the warning sits
    -- inside the clause sub-frame, to the left of the Remove button.
    local emptyWarn = sub:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    emptyWarn:SetPoint("RIGHT", removeBtn, "LEFT", -8, 0)
    emptyWarn:SetText(L["GEMS_IF_BUILDER_EMPTY_CLAUSE_WARN"] or "Add a condition or remove this clause")
    if C and C.textWarning then
        emptyWarn:SetTextColor(C.textWarning:GetRGBA())
    else
        emptyWarn:SetTextColor(1, 0.7, 0.2, 1)
    end
    emptyWarn:Hide()
    sub._emptyWarn = emptyWarn

    local tabs = {
        { key = "combat", label = "Combat" },
        { key = "general", label = "General" },
        { key = "ui", label = "UI-state" },
        { key = "targeting", label = L["GEMS_IF_BUILDER_TARGETING_TAB"] or "Targeting" },
    }
    local tabFrames = {}
    local prevTab = nil
    for _, tab in ipairs(tabs) do
        local tabBtn = CreateFrame("Button", nil, sub, "UIPanelButtonTemplate")
        tabBtn:SetSize(80, 18)
        if prevTab then
            tabBtn:SetPoint("LEFT", prevTab, "RIGHT", 2, 0)
        else
            tabBtn:SetPoint("TOPLEFT", sub, "TOPLEFT", 6, -CLAUSE_HEADER_HEIGHT - 4)
        end
        tabBtn:SetText(tab.label)
        local tabKey = tab.key
        tabBtn:SetScript("OnClick", function()
            clauseState.activeTab = tabKey
            -- H4c: re-render the whole stack so this clause's row area
            -- updates to the new tab. Other clauses keep their per-clause
            -- state intact (rerenderClauseStack only rebuilds frames, it
            -- does not mutate clauseState fields).
            rerenderClauseStack()
            refreshApplyGate()
        end)
        tabFrames[tab.key] = tabBtn
        prevTab = tabBtn
    end
    sub.tabFrames = tabFrames

    local rowArea = CreateFrame("Frame", nil, sub)
    rowArea:SetPoint("TOPLEFT", sub, "TOPLEFT", 6, -CLAUSE_HEADER_HEIGHT * 2 - 8)
    rowArea:SetPoint("BOTTOMRIGHT", sub, "BOTTOMRIGHT", -6, 6)
    sub.rowArea = rowArea

    local activeTab = clauseState.activeTab or "combat"
    local y = 0
    if activeTab == "targeting" then
        -- H4d: Targeting tab renders 6 radio options + a shared
        -- unitArg EditBox. Per-clause radio selection is mutually
        -- exclusive (one targeting prefix per bracket max; WoW
        -- evaluates only the last targeting in a bracket if multiple
        -- are present, but we enforce single-selection in the UI to
        -- avoid silent loss).
        local radios = {
            { mode = nil, label = L["GEMS_IF_BUILDER_TARGETING_NONE"] or "(none)" },
            { mode = "@focus", label = "@focus" },
            { mode = "@cursor", label = "@cursor" },
            { mode = "@none", label = "@none" },
            { mode = "@unit", label = "@unit" },
            { mode = "target=", label = "target=" },
        }
        local radioBtns = {}
        local function refreshRadioState()
            for _, btn in ipairs(radioBtns) do
                btn:SetChecked(btn._mode == clauseState.targeting.mode)
            end
        end
        local function refreshUnitBoxVisibility()
            local shown = clauseState.targeting.mode == "@unit" or clauseState.targeting.mode == "target="
            if rowArea._unitBox then
                rowArea._unitBox:SetShown(shown)
                if shown then
                    rowArea._unitBox:SetText(clauseState.targeting.unitArg or "")
                end
            end
            -- H4-cleanup: also toggle the hint label. The hint is parented
            -- to rowArea (not to unitBox) so its visibility inherits from
            -- rowArea regardless of unitBox visibility; without this
            -- explicit Show/Hide, the hint floats next to the invisible
            -- unitBox on @focus / @cursor / @none / (none) modes.
            if rowArea._unitHint then
                rowArea._unitHint:SetShown(shown)
            end
        end
        for _, entry in ipairs(radios) do
            local btn = CreateFrame("CheckButton", nil, rowArea, "UIRadioButtonTemplate")
            btn:SetSize(18, 18)
            btn:SetPoint("TOPLEFT", rowArea, "TOPLEFT", 0, -y)
            btn._mode = entry.mode
            btn:SetChecked(entry.mode == clauseState.targeting.mode)
            btn:SetScript("OnClick", function(self)
                clauseState.targeting.mode = self._mode
                if self._mode ~= "@unit" and self._mode ~= "target=" then
                    -- Reset unitArg when switching to a well-known
                    -- mode or (none); the EditBox is hidden anyway.
                    clauseState.targeting.unitArg = ""
                end
                refreshRadioState()
                refreshUnitBoxVisibility()
                refreshBuilderPreview()
                refreshClauseEmptyWarn(clauseState)
                refreshApplyGate()
            end)
            local lbl = rowArea:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
            lbl:SetPoint("LEFT", btn, "RIGHT", 4, 0)
            lbl:SetText(entry.label)
            radioBtns[#radioBtns + 1] = btn
            y = y + 22
        end
        -- Shared unitArg EditBox; only one shows at a time because
        -- @unit and target= are mutually exclusive radio options.
        local unitBox = CreateFrame("EditBox", nil, rowArea, "BackdropTemplate")
        unitBox:SetSize(140, 18)
        unitBox:SetPoint("TOPLEFT", rowArea, "TOPLEFT", 24, -y)
        unitBox:SetAutoFocus(false)
        unitBox:SetMaxLetters(20)
        unitBox:SetFontObject("GameFontHighlightSmall")
        unitBox:SetTextInsets(4, 4, 1, 1)
        if unitBox.SetBackdrop then
            unitBox:SetBackdrop({
                bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
                edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
                tile = true,
                tileSize = 16,
                edgeSize = 8,
                insets = { left = 2, right = 2, top = 2, bottom = 2 },
            })
            unitBox:SetBackdropColor(0.05, 0.05, 0.05, 0.9)
            unitBox:SetBackdropBorderColor(0.4, 0.4, 0.4, 1)
        end
        unitBox:SetScript("OnTextChanged", function(self)
            clauseState.targeting.unitArg = self:GetText() or ""
            refreshBuilderPreview()
            refreshClauseEmptyWarn(clauseState)
            refreshApplyGate()
        end)
        unitBox:SetScript("OnEscapePressed", function(self)
            self:ClearFocus()
        end)
        unitBox:SetScript("OnEnterPressed", function(self)
            self:ClearFocus()
        end)
        GRIPEMS.Focus:HookEditBox(unitBox)
        local hint = rowArea:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        hint:SetPoint("LEFT", unitBox, "RIGHT", 6, 0)
        hint:SetText(L["GEMS_IF_BUILDER_TARGETING_UNIT_HINT"] or "Custom unit (e.g. raid1, party2, arena1)")
        rowArea._unitBox = unitBox
        rowArea._unitHint = hint
        refreshUnitBoxVisibility()
        y = y + 22
    else
        for _, row in ipairs(data.rows) do
            if row.category == activeTab then
                local rowFrame = CreateFrame("Frame", nil, rowArea)
                -- H4c.1: rowArea is two-point anchored so GetWidth returns 0 on
                -- first render (WoW resolves anchors next frame tick). The sub
                -- frame has explicit width via sub:SetSize(subWidth, ...) so its
                -- GetWidth is deterministic from creation. Subtract 12 for the
                -- 6px left + 6px right padding the rowArea inherits.
                local rowWidth = (sub:GetWidth() > 0 and sub:GetWidth() - 12) or (subWidth - 12)
                rowFrame:SetSize(rowWidth, 18)
                rowFrame:SetPoint("TOPLEFT", rowArea, "TOPLEFT", 0, -y)

                local tickbox = CreateFrame("CheckButton", nil, rowFrame, "UICheckButtonTemplate")
                tickbox:SetSize(18, 18)
                tickbox:SetPoint("LEFT", rowFrame, "LEFT", 0, 0)
                local st = clauseState.rowState[row.key]
                tickbox:SetChecked(st and st.selected or false)
                tickbox:SetScript("OnClick", function(self)
                    local checked = self:GetChecked()
                    local rs = clauseState.rowState[row.key]
                    if rs then
                        rs.selected = checked and true or false
                    end
                    refreshBuilderPreview()
                    refreshClauseEmptyWarn(clauseState)
                    refreshApplyGate()
                end)

                local lbl = rowFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
                lbl:SetPoint("LEFT", tickbox, "RIGHT", 4, 0)
                lbl:SetText(L[row.labelKey] or row.key)

                local negate = CreateFrame("CheckButton", nil, rowFrame, "UICheckButtonTemplate")
                negate:SetSize(14, 14)
                negate:SetPoint("RIGHT", rowFrame, "RIGHT", -4, 0)
                negate:SetChecked(st and st.negate or false)
                negate:SetScript("OnClick", function(self)
                    local rs = clauseState.rowState[row.key]
                    if rs then
                        rs.negate = self:GetChecked() and true or false
                    end
                    refreshBuilderPreview()
                end)

                local negateLbl = rowFrame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
                negateLbl:SetPoint("RIGHT", negate, "LEFT", -2, 0)
                negateLbl:SetText("no")

                if row.paramType then
                    -- H4c: reuse the canonical picker dispatcher so paramType
                    -- rows render the same widget here as inside the picker.
                    -- The 4th arg points the SpellPicker hide-while-open
                    -- handoff at the builder modal instead of the picker.
                    local CP = GRIPEMS.ConditionalPicker
                    if CP and CP._buildParamInput then
                        local widget = CP._buildParamInput(rowFrame, row, clauseState.rowState[row.key], CB._frame)
                        if widget then
                            widget:ClearAllPoints()
                            widget:SetPoint("LEFT", lbl, "RIGHT", 8, 0)
                            if widget.SetEnabled then
                                widget:SetEnabled(true)
                            end
                            -- Refresh preview on widget OnHide (dropdown
                            -- close, SpellPicker close, etc.). HookScript
                            -- preserves the dispatcher's internal teardown
                            -- handlers per WoW API contract.
                            widget:HookScript("OnHide", function()
                                refreshBuilderPreview()
                            end)
                        end
                    end
                end

                y = y + 20
            end
        end
    end

    -- H4c.1: dynamic sub-frame height. The fixed CLAUSE_MIN_HEIGHT
    -- (180px) clips multi-row tabs (Combat has 17 rows = 340px;
    -- General has 17 rows; UI-state has 10 rows = 200px). Rows then
    -- leak past the sub-frame border because WoW does not clip
    -- children by default, and subsequent clauses get positioned
    -- via cs.frame:GetHeight() (the fixed 180px) so clause N+1
    -- overlays clause N's underflow. The modal's outer scrollFrame
    -- handles total-stack overflow when clauses cumulatively exceed
    -- modal height.
    local rowsHeight = (y > 0 and y) or 1
    local subTotalHeight = CLAUSE_HEADER_HEIGHT * 2 + 8 + rowsHeight + 6
    sub:SetHeight(math.max(subTotalHeight, CLAUSE_MIN_HEIGHT))

    refreshClauseEmptyWarn(clauseState)

    return sub
end

---------------------------------------------------------------------------
-- AST -> clause hydration
---------------------------------------------------------------------------

local function hydrateClauseFromAST(clauseState, conditionEntry)
    local data = GRIPEMS.ConditionalPickerData
    if not data or not data.byKey then
        return
    end
    local conditionals = conditionEntry and conditionEntry.conditionals or {}
    for _, c in ipairs(conditionals) do
        local row = c.key and data.byKey[c.key] or nil
        if row then
            local v = c.args
            if type(v) == "table" then
                v = v[1]
            end
            local pv = nil
            if v ~= nil and v ~= "" then
                if
                    row.paramType == "integer"
                    or row.paramType == "specname"
                    or row.paramType == "formname"
                    or row.paramType == "stancename"
                then
                    pv = tostring(tonumber(v) or v)
                else
                    pv = tostring(v)
                end
            end
            clauseState.rowState[row.key] = {
                selected = true,
                negate = c.neg and true or false,
                paramValue = pv,
            }
        elseif c.key == nil and c.target then
            -- H4d: targeting prefix. MacroSyntax.parseConditional returns
            -- target as the FULL raw string including "@" or "target="
            -- prefix. Map back to mode + unitArg for the radio UI.
            -- Multiple targeting prefixes in one bracket would overwrite
            -- earlier ones (WoW evaluates only the last); we follow the
            -- same behavior implicitly since each iteration overwrites
            -- mode + unitArg.
            local t = c.target
            if t == "@focus" or t == "@cursor" or t == "@none" then
                clauseState.targeting.mode = t
                clauseState.targeting.unitArg = ""
            elseif t:sub(1, 7) == "target=" then
                clauseState.targeting.mode = "target="
                clauseState.targeting.unitArg = t:sub(8)
            elseif t:sub(1, 1) == "@" then
                clauseState.targeting.mode = "@unit"
                clauseState.targeting.unitArg = t:sub(2)
            end
        end
        -- Unknown keys (c.key == nil and c.target == nil) silently skipped.
    end
end

---------------------------------------------------------------------------
-- Joined output assembly
---------------------------------------------------------------------------

-- H4c: assignment (not `local function`) writes back into the forward-
-- declared local so closures in createFrame's Apply OnClick and the
-- refreshBuilderPreview helper -- both declared earlier in the file --
-- can call this function via the captured upvalue.
function buildJoinedOutput()
    local CP = GRIPEMS.ConditionalPicker
    local data = GRIPEMS.ConditionalPickerData
    if not CP or not CP._buildToken or not data then
        return ""
    end
    local brackets = {}
    for _, cs in ipairs(CB._clauses) do
        local tokens = {}
        -- H4d: targeting prefix emits FIRST in the bracket per WoW
        -- convention. Targeting prefixes (@unit, target=unit) are NOT
        -- booleans -- they set the temporary cast target for the
        -- bracket and never participate in true/false logic.
        local targetingToken = nil
        local tmode = cs.targeting and cs.targeting.mode
        if tmode == "@focus" or tmode == "@cursor" or tmode == "@none" then
            targetingToken = tmode
        elseif tmode == "@unit" and cs.targeting.unitArg ~= "" then
            targetingToken = "@" .. cs.targeting.unitArg
        elseif tmode == "target=" and cs.targeting.unitArg ~= "" then
            targetingToken = "target=" .. cs.targeting.unitArg
        end
        if targetingToken then
            tokens[#tokens + 1] = targetingToken
        end
        for _, row in ipairs(data.rows) do
            local st = cs.rowState[row.key]
            if st and st.selected then
                tokens[#tokens + 1] = CP._buildToken(row, st)
            end
        end
        if #tokens > 0 then
            brackets[#brackets + 1] = "[" .. table.concat(tokens, ",") .. "]"
        end
    end
    return table.concat(brackets, "")
end

---------------------------------------------------------------------------
-- Public API
---------------------------------------------------------------------------

--- Open the conditional builder modal anchored center-screen.
--- @param targetEditBox EditBox The Cond box to read content from and write back on Apply
--- @param parsed table The MS.ParseCondBoxInput AST for the existing input
--- @param onApply function|nil Optional callback fired after Apply
--- @param anchorFrame Frame|nil Optional anchor reference (unused; modal opens center-screen)
function CB:Open(targetEditBox, parsed, onApply, anchorFrame)
    if not targetEditBox or not parsed then
        return
    end
    self._targetEditBox = targetEditBox
    self._anchorFrame = anchorFrame or targetEditBox
    self._onApply = onApply
    self._parsed = parsed
    self._clauses = {}

    local conditions = (
        parsed.ast
        and parsed.ast.clauses
        and parsed.ast.clauses[1]
        and parsed.ast.clauses[1].conditions
    ) or {}
    for i, condEntry in ipairs(conditions) do
        local cs = {
            rowState = {},
            targeting = { mode = nil, unitArg = "" },
            activeTab = "combat",
            frame = nil,
        }
        hydrateClauseFromAST(cs, condEntry)
        -- H4c: hydrate only fills rows that the AST mentions. Round out
        -- every defined row with an empty default so the param-input
        -- dispatcher always finds a non-nil rowState entry (the contract
        -- the picker dispatcher expects when row.paramType is set).
        ensureClauseRowState(cs)
        self._clauses[i] = cs
    end

    -- H4c: if the parsed AST has zero conditions, allocate one empty
    -- clause so the modal opens with an editable surface. The Convert-
    -- to-OR entry path from the picker may pass a synthetic AST with
    -- zero selected rows (the user clicked Convert without ticking
    -- anything); the empty-clause warning + Apply gate cover that case.
    if #self._clauses == 0 then
        local cs = {
            rowState = {},
            targeting = { mode = nil, unitArg = "" },
            activeTab = "combat",
            frame = nil,
        }
        ensureClauseRowState(cs)
        self._clauses[1] = cs
    end

    local frame = createFrame()
    frame:ClearAllPoints()
    frame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    frame:Show()
    frame:Raise()

    if frame.contentLbl then
        frame.contentLbl:SetText(targetEditBox:GetText() or "")
    end

    -- H4c: lay out clauses + paint preview + apply gate through the
    -- canonical helpers so the initial paint matches Add OR clause /
    -- Remove clause / tab-switch flows. rerenderClauseStack is now the
    -- single render path; the H4b inline layout loop was duplicate.
    rerenderClauseStack()
    refreshBuilderPreview()
    refreshApplyGate()
end

--- Close the modal (no-op if not open).
function CB:Close()
    -- H4c.3: defensive Hide of ALL scrollContent children.
    -- Supersedes the H4c.2 CB._clauses iteration -- same
    -- fragility class as the rerenderClauseStack fix.
    -- The children-sweep catches orphan sub-frames whose
    -- clauseState was removed from CB._clauses before
    -- CB:Close fired (Remove + Close in rapid succession),
    -- AND it handles the Esc-close path on the NEXT open
    -- since rerenderClauseStack's identical sweep cleans
    -- prior-session orphans.
    if self._frame and self._frame.scrollContent then
        local children = { self._frame.scrollContent:GetChildren() }
        for _, child in ipairs(children) do
            if child then
                child:Hide()
                child:ClearAllPoints()
            end
        end
    end
    if self._frame then
        self._frame:Hide()
    end
    self._targetEditBox = nil
    self._anchorFrame = nil
    self._onApply = nil
    self._parsed = nil
    self._clauses = {}
end
