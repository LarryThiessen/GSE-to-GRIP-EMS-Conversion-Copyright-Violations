-- GRIP-EMS: Theme data module (Phase A foundation)
--
-- Created:    2026-04-22
-- Updated:    2026-06-21
-- Patch: 12.0.7.68256 Midnight (Retail LIVE)
--
-- Pure-data module. Publishes three tables under GRIPEMS.UI:
--   UI.DEFAULT_THEME   -- per-class default spec (bg / border / text / alpha / font / size / flags / color)
--   UI.ELEMENT_CLASSES -- 45-string whitelist array used by Theme.ValidateSpec
--   UI.APPLY_FN        -- group -> function(frame, spec, multipliers) dispatch table
--
-- Defaults chosen to reproduce current v1.9.9 B.3 visuals exactly. Values mirror
-- UI.Presets.Default in UI/Util.lua so Theme.ApplyTheme with empty overrides is a
-- pixel-identical re-write. See ThemingEditor_Design_2026-04-22.md section 4.2
-- (backward-compat invariant) and Appendix A (full 45-class table).
--
-- Loaded BEFORE Core/Theme.lua and Core/Core.lua via GRIP-EMS.toc.

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

-- Per-class session-scoped dedupe for missing-LSM-texture chat notices.
-- Reset on /reload when this chunk re-evaluates. See backlog entry
-- A11Y-THEME-TEXTURE-MISSING-NOTIFY.
local _missingTextureNotified = {}

GRIPEMS.UI = GRIPEMS.UI or {}
local UI = GRIPEMS.UI

---------------------------------------------------------------------------
-- The 45-class whitelist. Keep this list in sync with Appendix A.
---------------------------------------------------------------------------
UI.ELEMENT_CLASSES = {
    -- Panels (15)
    "panel.main",
    "panel.sequenceEditor",
    "panel.stepList",
    "panel.variables",
    "panel.keybind",
    "panel.spellPicker",
    "panel.popupEditor",
    "panel.repair",
    "panel.settings",
    "panel.help",
    "panel.logs",
    "panel.profileMgr",
    "panel.import",
    "panel.export",
    "panel.utility",
    -- Overlays (9)
    "overlay.toast.info",
    "overlay.toast.warn",
    "overlay.toast.error",
    "overlay.modal.dim",
    "overlay.tooltip",
    "overlay.dragPreview",
    "overlay.menu",
    "overlay.hud",
    "overlay.splash",
    -- Rows (4)
    "row.default",
    "row.selected",
    "row.hover",
    "row.error",
    -- Buttons (2)
    "button.default",
    "button.primary",
    -- Text (4)
    "text.body",
    "text.heading",
    "text.muted",
    "text.log",
    -- Emphasis (10)
    "emphasis.focusRing",
    "emphasis.dropTarget",
    "emphasis.dragSource",
    "emphasis.recordArmed",
    "emphasis.recordCapturing",
    "emphasis.error",
    "emphasis.warning",
    "emphasis.success",
    "emphasis.disabled",
    "emphasis.readonly",
    -- Global (1)
    "global.addonFont",
}

-- Reverse lookup for O(1) whitelist membership checks in Theme.ValidateSpec.
UI.ELEMENT_CLASS_SET = {}
for i = 1, #UI.ELEMENT_CLASSES do
    UI.ELEMENT_CLASS_SET[UI.ELEMENT_CLASSES[i]] = true
end

---------------------------------------------------------------------------
-- Default spec table. Sparse per-class overrides in profile.theming.elements
-- layer on top of this; anything not overridden resolves to the entry below.
-- Color tuples are {r, g, b, a} in [0, 1]. Font is an LSM key string.
---------------------------------------------------------------------------
local PANEL_BG = { 0.086, 0.129, 0.243, 1 }
-- Brightened in v2.1.11 so the default opaque panel border clears the WCAG 3:1 non-text
-- contrast minimum against PANEL_BG (was 0.2/0.2/0.333 = 1.32:1; now 3.45:1). Translucent
-- panels are exempt from the check (see Core/Theme.lua CheckContrast Case 5).
local PANEL_BORDER = { 0.440, 0.440, 0.640, 1 }
local BG_MAIN = { 0.102, 0.102, 0.180, 1 }
local BG_INPUT = { 0.059, 0.090, 0.161, 1 }
local BG_BUTTON = { 0.118, 0.176, 0.290, 1 }
local BG_SAVE = { 0.100, 0.280, 0.150, 1 }
local BG_ROW_HOVER = { 0.059, 0.204, 0.376, 1 }
local BG_ROW_SELECTED = { 0.325, 0.204, 0.514, 1 }
local ACCENT = { 0.914, 0.271, 0.376, 1 }
local TEXT_PRIMARY = { 0.933, 0.933, 1.000, 1 }
local TEXT_MUTED = { 0.533, 0.533, 0.667, 1 }
local TEXT_WARNING = { 1.000, 0.800, 0.000, 1 }
local TEXT_ERROR = { 1.000, 0.267, 0.267, 1 }
local TEXT_SUCCESS = { 0.000, 0.800, 0.400, 1 }
local KEYBIND_GOLD = { 1.000, 0.843, 0.000, 1 }
local FOCUS_RING = { 1.000, 0.850, 0.100, 1 }
local BORDER_FOCUS = { 0.333, 0.333, 0.667, 1 }

local function panelSpec()
    return {
        bg = { PANEL_BG[1], PANEL_BG[2], PANEL_BG[3], PANEL_BG[4] },
        border = { PANEL_BORDER[1], PANEL_BORDER[2], PANEL_BORDER[3], PANEL_BORDER[4] },
        alpha = 1.0,
    }
end

UI.DEFAULT_THEME = {
    -- Panels: all share the panel backdrop. Individual tabs can diverge via
    -- per-class overrides; defaults stay uniform across panels. The panel border
    -- was brightened in v2.1.11 to meet the WCAG 3:1 non-text contrast minimum
    -- against PANEL_BG -- a deliberate change from the pre-v2.0.0 border.
    ["panel.main"] = panelSpec(),
    ["panel.sequenceEditor"] = panelSpec(),
    ["panel.stepList"] = panelSpec(),
    ["panel.variables"] = panelSpec(),
    ["panel.keybind"] = panelSpec(),
    ["panel.spellPicker"] = panelSpec(),
    ["panel.popupEditor"] = panelSpec(),
    ["panel.repair"] = panelSpec(),
    ["panel.settings"] = panelSpec(),
    ["panel.help"] = panelSpec(),
    ["panel.logs"] = panelSpec(),
    ["panel.profileMgr"] = panelSpec(),
    ["panel.import"] = panelSpec(),
    ["panel.export"] = panelSpec(),
    ["panel.utility"] = panelSpec(),
    -- Overlays: toasts float above the panel stack; modal dimmer is a translucent black sheet.
    ["overlay.toast.info"] = {
        bg = { BG_MAIN[1], BG_MAIN[2], BG_MAIN[3], 0.95 },
        border = { PANEL_BORDER[1], PANEL_BORDER[2], PANEL_BORDER[3], 1 },
        text = { TEXT_PRIMARY[1], TEXT_PRIMARY[2], TEXT_PRIMARY[3], 1 },
        alpha = 1.0,
    },
    ["overlay.toast.warn"] = {
        bg = { BG_MAIN[1], BG_MAIN[2], BG_MAIN[3], 0.95 },
        border = { TEXT_WARNING[1], TEXT_WARNING[2], TEXT_WARNING[3], 1 },
        text = { TEXT_WARNING[1], TEXT_WARNING[2], TEXT_WARNING[3], 1 },
        alpha = 1.0,
    },
    ["overlay.toast.error"] = {
        bg = { BG_MAIN[1], BG_MAIN[2], BG_MAIN[3], 0.95 },
        border = { TEXT_ERROR[1], TEXT_ERROR[2], TEXT_ERROR[3], 1 },
        text = { TEXT_ERROR[1], TEXT_ERROR[2], TEXT_ERROR[3], 1 },
        alpha = 1.0,
    },
    ["overlay.modal.dim"] = { bg = { 0, 0, 0, 0.6 }, alpha = 1.0 },
    ["overlay.tooltip"] = {
        bg = { PANEL_BG[1], PANEL_BG[2], PANEL_BG[3], 1 },
        border = { PANEL_BORDER[1], PANEL_BORDER[2], PANEL_BORDER[3], 1 },
        text = { TEXT_PRIMARY[1], TEXT_PRIMARY[2], TEXT_PRIMARY[3], 1 },
        alpha = 1.0,
    },
    ["overlay.dragPreview"] = {
        bg = { PANEL_BG[1], PANEL_BG[2], PANEL_BG[3], 0.5 },
        border = { ACCENT[1], ACCENT[2], ACCENT[3], 1 },
        alpha = 0.8,
    },
    ["overlay.menu"] = {
        bg = { PANEL_BG[1], PANEL_BG[2], PANEL_BG[3], 0.95 },
        border = { PANEL_BORDER[1], PANEL_BORDER[2], PANEL_BORDER[3], 1 },
        text = { TEXT_PRIMARY[1], TEXT_PRIMARY[2], TEXT_PRIMARY[3], 1 },
        alpha = 1.0,
    },
    ["overlay.hud"] = {
        bg = { PANEL_BG[1], PANEL_BG[2], PANEL_BG[3], 0.7 },
        border = { PANEL_BORDER[1], PANEL_BORDER[2], PANEL_BORDER[3], 0.8 },
        text = { TEXT_PRIMARY[1], TEXT_PRIMARY[2], TEXT_PRIMARY[3], 1 },
        alpha = 1.0,
    },
    ["overlay.splash"] = {
        bg = { PANEL_BG[1], PANEL_BG[2], PANEL_BG[3], 1 },
        border = { PANEL_BORDER[1], PANEL_BORDER[2], PANEL_BORDER[3], 1 },
        text = { TEXT_PRIMARY[1], TEXT_PRIMARY[2], TEXT_PRIMARY[3], 1 },
        alpha = 1.0,
    },
    -- Rows.
    ["row.default"] = { bg = { 0, 0, 0, 0 }, border = { BG_BUTTON[1], BG_BUTTON[2], BG_BUTTON[3], 0.5 } },
    ["row.selected"] = {
        bg = { BG_ROW_SELECTED[1], BG_ROW_SELECTED[2], BG_ROW_SELECTED[3], 1 },
        border = { BORDER_FOCUS[1], BORDER_FOCUS[2], BORDER_FOCUS[3], 1 },
    },
    ["row.hover"] = {
        bg = { BG_ROW_HOVER[1], BG_ROW_HOVER[2], BG_ROW_HOVER[3], 1 },
        border = { PANEL_BORDER[1], PANEL_BORDER[2], PANEL_BORDER[3], 1 },
    },
    ["row.error"] = {
        bg = { TEXT_ERROR[1], TEXT_ERROR[2], TEXT_ERROR[3], 0.2 },
        border = { TEXT_ERROR[1], TEXT_ERROR[2], TEXT_ERROR[3], 1 },
    },
    -- Buttons.
    ["button.default"] = {
        bg = { BG_BUTTON[1], BG_BUTTON[2], BG_BUTTON[3], 1 },
        border = { PANEL_BORDER[1], PANEL_BORDER[2], PANEL_BORDER[3], 1 },
        text = { TEXT_PRIMARY[1], TEXT_PRIMARY[2], TEXT_PRIMARY[3], 1 },
        alpha = 1.0,
    },
    ["button.primary"] = {
        bg = { BG_SAVE[1], BG_SAVE[2], BG_SAVE[3], 1 },
        border = { PANEL_BORDER[1], PANEL_BORDER[2], PANEL_BORDER[3], 1 },
        text = { TEXT_PRIMARY[1], TEXT_PRIMARY[2], TEXT_PRIMARY[3], 1 },
        alpha = 1.0,
    },
    -- Text. Font baseline is the LSM Blizzard UI font matching accessibility.fontName default.
    ["text.body"] = {
        font = "Friz Quadrata TT",
        fontSize = 12,
        fontFlags = "",
        color = { TEXT_PRIMARY[1], TEXT_PRIMARY[2], TEXT_PRIMARY[3], 1 },
    },
    ["text.heading"] = {
        font = "Friz Quadrata TT",
        fontSize = 14,
        fontFlags = "OUTLINE",
        color = { KEYBIND_GOLD[1], KEYBIND_GOLD[2], KEYBIND_GOLD[3], 1 },
    },
    ["text.muted"] = {
        font = "Friz Quadrata TT",
        fontSize = 11,
        fontFlags = "",
        color = { TEXT_MUTED[1], TEXT_MUTED[2], TEXT_MUTED[3], 1 },
    },
    -- text.log: ScrollingMessageFrame surfaces (DebugWindow). Default 10pt matches
    -- GameFontNormal baseline so empty overrides render pixel-identical to v1.9.9.
    ["text.log"] = {
        font = "Friz Quadrata TT",
        fontSize = 10,
        fontFlags = "",
        color = { TEXT_PRIMARY[1], TEXT_PRIMARY[2], TEXT_PRIMARY[3], 1 },
    },
    -- Emphasis. Focus ring is color-only; thickness and animation are locked per A.2 spec.
    ["emphasis.focusRing"] = { color = { FOCUS_RING[1], FOCUS_RING[2], FOCUS_RING[3], 1 } },
    ["emphasis.dropTarget"] = {
        bg = { TEXT_SUCCESS[1], TEXT_SUCCESS[2], TEXT_SUCCESS[3], 0.25 },
        border = { TEXT_SUCCESS[1], TEXT_SUCCESS[2], TEXT_SUCCESS[3], 1 },
        alpha = 1.0,
    },
    ["emphasis.dragSource"] = { bg = { 0, 0, 0, 0.3 }, alpha = 0.6 },
    ["emphasis.recordArmed"] = {
        bg = { KEYBIND_GOLD[1], KEYBIND_GOLD[2], KEYBIND_GOLD[3], 0.25 },
        border = { KEYBIND_GOLD[1], KEYBIND_GOLD[2], KEYBIND_GOLD[3], 1 },
        alpha = 1.0,
    },
    ["emphasis.recordCapturing"] = {
        bg = { ACCENT[1], ACCENT[2], ACCENT[3], 0.4 },
        border = { ACCENT[1], ACCENT[2], ACCENT[3], 1 },
        alpha = 1.0,
    },
    ["emphasis.error"] = {
        bg = { TEXT_ERROR[1], TEXT_ERROR[2], TEXT_ERROR[3], 0.2 },
        border = { TEXT_ERROR[1], TEXT_ERROR[2], TEXT_ERROR[3], 1 },
        text = { TEXT_ERROR[1], TEXT_ERROR[2], TEXT_ERROR[3], 1 },
    },
    ["emphasis.warning"] = {
        bg = { TEXT_WARNING[1], TEXT_WARNING[2], TEXT_WARNING[3], 0.2 },
        border = { TEXT_WARNING[1], TEXT_WARNING[2], TEXT_WARNING[3], 1 },
        text = { TEXT_WARNING[1], TEXT_WARNING[2], TEXT_WARNING[3], 1 },
    },
    ["emphasis.success"] = {
        bg = { TEXT_SUCCESS[1], TEXT_SUCCESS[2], TEXT_SUCCESS[3], 0.2 },
        border = { TEXT_SUCCESS[1], TEXT_SUCCESS[2], TEXT_SUCCESS[3], 1 },
        text = { TEXT_SUCCESS[1], TEXT_SUCCESS[2], TEXT_SUCCESS[3], 1 },
    },
    ["emphasis.disabled"] = { alpha = 0.5, text = { 0.5, 0.5, 0.5, 1 } },
    ["emphasis.readonly"] = {
        bg = { BG_INPUT[1], BG_INPUT[2], BG_INPUT[3], 1 },
        border = { PANEL_BORDER[1], PANEL_BORDER[2], PANEL_BORDER[3], 0.5 },
    },
    -- Global addon font fallback.
    ["global.addonFont"] = { font = "Friz Quadrata TT", fontFlags = "" },
}

---------------------------------------------------------------------------
-- Group dispatcher. Maps the class-name prefix ("panel", "overlay", "row",
-- "button", "text", "emphasis", "global") to the WoW API call sequence that
-- renders a resolved spec onto a frame. See design section 5.2.
--
-- Each function takes (frame, spec, mult) where mult is the B.3 multiplier
-- bundle {panelAlpha, overlayAlpha, bgOpacity, borderOpacity} -- callers
-- compose finalAlpha per design section 4.1.
---------------------------------------------------------------------------
local function applyPanel(frame, spec, mult)
    if not frame or not spec then
        return
    end
    if frame.GetBackdrop and frame.SetBackdrop then
        local hasTexture = spec.bgTexture or spec.borderTexture
        if hasTexture then
            -- Second-chance snapshot: capture pre-theming backdrop if
            -- UI:RegisterElement missed it (frame's backdrop set post-register).
            if not frame._emsDefaultBackdrop then
                local baseline = frame:GetBackdrop()
                if type(baseline) == "table" then
                    frame._emsDefaultBackdrop = {
                        bgFile = baseline.bgFile,
                        edgeFile = baseline.edgeFile,
                        tile = baseline.tile,
                        tileSize = baseline.tileSize,
                        edgeSize = baseline.edgeSize,
                        insets = baseline.insets and {
                            left = baseline.insets.left,
                            right = baseline.insets.right,
                            top = baseline.insets.top,
                            bottom = baseline.insets.bottom,
                        } or nil,
                    }
                end
            end
            local current = frame:GetBackdrop()
            if type(current) == "table" then
                local LSM = LibStub and LibStub("LibSharedMedia-3.0", true)
                local newBd = {
                    bgFile = current.bgFile,
                    edgeFile = current.edgeFile,
                    tile = current.tile,
                    tileSize = current.tileSize,
                    edgeSize = current.edgeSize,
                    insets = current.insets,
                }
                -- Per-field revert: if a texture field is nil in the incoming
                -- spec and the frame has a pre-theming snapshot, fall back to
                -- the snapshot value. This lets users clear one texture field
                -- without the cleared side re-inheriting its prior textured
                -- value. See backlog entry A11Y-THEME-TEXTURE-PARTIAL-REVERT.
                if not spec.bgTexture and frame._emsDefaultBackdrop then
                    newBd.bgFile = frame._emsDefaultBackdrop.bgFile
                end
                if not spec.borderTexture and frame._emsDefaultBackdrop then
                    newBd.edgeFile = frame._emsDefaultBackdrop.edgeFile
                end
                local classKey = frame._emsElementClass or "?"
                if LSM and spec.bgTexture then
                    local path = LSM:Fetch("background", spec.bgTexture, true)
                    if path then
                        newBd.bgFile = path
                    else
                        -- Texture key not registered with LSM. Revert this
                        -- field to the pre-theming snapshot so a missing
                        -- texture renders the v1.9.9 default rather than
                        -- silently keeping a previously-applied texture
                        -- from an earlier ApplyTheme pass. See backlog
                        -- A11Y-THEME-TEXTURE-MISSING-REVERT-TO-SNAPSHOT.
                        if frame._emsDefaultBackdrop then
                            newBd.bgFile = frame._emsDefaultBackdrop.bgFile
                        end
                        local notifyKey = classKey .. ":bg:" .. tostring(spec.bgTexture)
                        if not _missingTextureNotified[notifyKey] then
                            _missingTextureNotified[notifyKey] = true
                            if DEFAULT_CHAT_FRAME and DEFAULT_CHAT_FRAME.AddMessage then
                                local fmt = L["ACCESS_THEMING_TEXTURE_MISSING"]
                                    or "EMS: theme texture '%s' is not registered with LibSharedMedia. Default rendered."
                                DEFAULT_CHAT_FRAME:AddMessage(
                                    string.format(fmt, tostring(spec.bgTexture)),
                                    1,
                                    0.85,
                                    0.1
                                )
                            end
                        end
                    end
                end
                if LSM and spec.borderTexture then
                    local path = LSM:Fetch("border", spec.borderTexture, true)
                    if path then
                        newBd.edgeFile = path
                    else
                        -- Texture key not registered with LSM. Revert this
                        -- field to the pre-theming snapshot so a missing
                        -- texture renders the v1.9.9 default rather than
                        -- silently keeping a previously-applied texture
                        -- from an earlier ApplyTheme pass. See backlog
                        -- A11Y-THEME-TEXTURE-MISSING-REVERT-TO-SNAPSHOT.
                        if frame._emsDefaultBackdrop then
                            newBd.edgeFile = frame._emsDefaultBackdrop.edgeFile
                        end
                        local notifyKey = classKey .. ":border:" .. tostring(spec.borderTexture)
                        if not _missingTextureNotified[notifyKey] then
                            _missingTextureNotified[notifyKey] = true
                            if DEFAULT_CHAT_FRAME and DEFAULT_CHAT_FRAME.AddMessage then
                                local fmt = L["ACCESS_THEMING_TEXTURE_MISSING"]
                                    or "EMS: theme texture '%s' is not registered with LibSharedMedia. Default rendered."
                                DEFAULT_CHAT_FRAME:AddMessage(
                                    string.format(fmt, tostring(spec.borderTexture)),
                                    1,
                                    0.85,
                                    0.1
                                )
                            end
                        end
                    end
                end
                pcall(frame.SetBackdrop, frame, newBd)
                frame._emsTexturedState = true
            end
        elseif frame._emsTexturedState and frame._emsDefaultBackdrop then
            -- Restore: spec has no texture fields and frame was previously
            -- textured. SetBackdrop back to the snapshot captured at
            -- RegisterElement time (or second-chance snapshot above).
            pcall(frame.SetBackdrop, frame, frame._emsDefaultBackdrop)
            frame._emsTexturedState = false
        end
    end
    if spec.bg and frame.SetBackdropColor then
        local r, g, b, a = spec.bg[1], spec.bg[2], spec.bg[3], spec.bg[4]
        local classA = spec.alpha or 1.0
        pcall(frame.SetBackdropColor, frame, r, g, b, a * classA * (mult.bgOpacity or 1.0))
    end
    if spec.border and frame.SetBackdropBorderColor then
        local r, g, b, a = spec.border[1], spec.border[2], spec.border[3], spec.border[4]
        local classA = spec.alpha or 1.0
        pcall(frame.SetBackdropBorderColor, frame, r, g, b, a * classA * (mult.borderOpacity or 1.0))
    end
    -- Frame-level SetAlpha is applied separately by UI:ApplyLiveAlphas so panelAlpha
    -- only multiplies once; do NOT call SetAlpha here or alpha double-multiplies.
end

local function applyOverlay(frame, spec, mult)
    if not frame or not spec then
        return
    end
    if spec.bg and frame.SetBackdropColor then
        local r, g, b, a = spec.bg[1], spec.bg[2], spec.bg[3], spec.bg[4]
        local classA = spec.alpha or 1.0
        pcall(frame.SetBackdropColor, frame, r, g, b, a * classA * (mult.bgOpacity or 1.0))
    end
    if spec.border and frame.SetBackdropBorderColor then
        local r, g, b, a = spec.border[1], spec.border[2], spec.border[3], spec.border[4]
        local classA = spec.alpha or 1.0
        pcall(frame.SetBackdropBorderColor, frame, r, g, b, a * classA * (mult.borderOpacity or 1.0))
    end
    if spec.text and frame._emsTextRef and frame._emsTextRef.SetTextColor then
        pcall(frame._emsTextRef.SetTextColor, frame._emsTextRef, spec.text[1], spec.text[2], spec.text[3], spec.text[4])
    end
end

local function applyRow(frame, spec, mult)
    if not frame or not spec then
        return
    end
    if spec.bg and frame.SetBackdropColor then
        local r, g, b, a = spec.bg[1], spec.bg[2], spec.bg[3], spec.bg[4]
        pcall(frame.SetBackdropColor, frame, r, g, b, a * (mult.bgOpacity or 1.0))
    end
    if spec.border and frame.SetBackdropBorderColor then
        local r, g, b, a = spec.border[1], spec.border[2], spec.border[3], spec.border[4]
        pcall(frame.SetBackdropBorderColor, frame, r, g, b, a * (mult.borderOpacity or 1.0))
    end
end

local function applyButton(frame, spec, mult)
    applyPanel(frame, spec, mult)
    if spec.text and frame.label and frame.label.SetTextColor then
        pcall(frame.label.SetTextColor, frame.label, spec.text[1], spec.text[2], spec.text[3], spec.text[4])
    end
end

local function applyText(frame, spec, mult)
    if not frame or not spec then
        return
    end
    if spec.font and spec.fontSize and frame.SetFont then
        local path = spec.font
        if LibStub then
            local LSM = LibStub("LibSharedMedia-3.0", true)
            if LSM then
                local resolved = LSM:Fetch("font", spec.font, true)
                if resolved then
                    path = resolved
                end
            end
        end
        pcall(frame.SetFont, frame, path, spec.fontSize, spec.fontFlags or "")
    end
    if spec.color and frame.SetTextColor then
        pcall(frame.SetTextColor, frame, spec.color[1], spec.color[2], spec.color[3], spec.color[4])
    end
end

local function applyEmphasis(frame, spec, mult)
    -- emphasis.focusRing forwards to UI.FocusRing:SetColor (section 9.2).
    if frame and frame._emsElementClass == "emphasis.focusRing" then
        local FR = GRIPEMS.UI and GRIPEMS.UI.FocusRing
        if FR and FR.SetColor and spec.color then
            pcall(FR.SetColor, FR, spec.color[1], spec.color[2], spec.color[3], spec.color[4])
        end
        return
    end
    -- Generic emphasis: backdrop + border, plus text ref if present.
    applyPanel(frame, spec, mult)
    if spec.text and frame and frame._emsTextRef and frame._emsTextRef.SetTextColor then
        pcall(frame._emsTextRef.SetTextColor, frame._emsTextRef, spec.text[1], spec.text[2], spec.text[3], spec.text[4])
    end
end

local function applyGlobal(frame, spec, mult)
    -- global.addonFont: no per-frame apply. Consumers read UI.DEFAULT_THEME["global.addonFont"]
    -- as the LSM fallback; the dispatcher is a no-op here but keeps the group-table complete.
end

UI.APPLY_FN = {
    panel = applyPanel,
    overlay = applyOverlay,
    row = applyRow,
    button = applyButton,
    text = applyText,
    emphasis = applyEmphasis,
    global = applyGlobal,
}

-- end of Data/Theme.lua
