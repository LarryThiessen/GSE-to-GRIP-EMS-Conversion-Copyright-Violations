-- GRIP-EMS: Conditional Picker Data
-- Created: 2026-05-10
-- Updated: 2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.
--
-- Table-driven catalog of WoW macro conditionals exposed by the IF Cond
-- box picker popup (UI/ConditionalPicker.lua). Spec section 4 lists the
-- canonical conditionals; spec section 10.7 defines the picker tab
-- categorization. Adding a new conditional = one row here + matching
-- locale keys in Locale/enUS.lua (and the other ten locales).

local ADDON_NAME, GRIPEMS = ...

GRIPEMS.ConditionalPickerData = {}
local D = GRIPEMS.ConditionalPickerData

-- Tab category keys.
--   "combat"  -> Combat-relevant tab (spec 4.1 + 4.2 combat-axis subset)
--   "general" -> General-purpose tab (spec 4.2 OOC-axis subset)
--   "ui"      -> UI-state tab (spec 4.3)
D.CATEGORY_COMBAT = "combat"
D.CATEGORY_GENERAL = "general"
D.CATEGORY_UI = "ui"

-- paramType:
--   nil             token = key as-is (e.g. "combat")
--   "integer"       spinner; paramOptions = {min = N, max = M}; emits "<key>:<n>"
--   "modkey"        sub-checkboxes (pick exactly one); paramOptions = list of names; emits "<key>:<name>"
--   "petname"       free-text EditBox (autocomplete from pet journal); emits "<key>:<text>", or bare "<key>" if empty
--   "spellname"     free-text EditBox (used by known:); emits "<key>:<text>", or bare "<key>" if empty
--   "itemtype"      dropdown; paramOptions = list of equip-type names; emits "<key>:<name>"
--   "houselocation" dropdown; paramOptions = list of location enums; emits "<key>:<name>"
--
-- negatable: when true, the picker shows a "no" tickbox per row that
-- prepends "no" (or strips a leading "no" per spec section 5.2 double
-- negation collapse).

D.MODKEY_OPTIONS = {
    "shift",
    "ctrl",
    "alt",
    "lshift",
    "rshift",
    "lctrl",
    "rctrl",
    "lalt",
    "ralt",
}

D.ITEMTYPE_OPTIONS = {
    "Sword",
    "Mace",
    "Axe",
    "Dagger",
    "Polearm",
    "Staff",
    "Fist Weapon",
    "Bow",
    "Crossbow",
    "Gun",
    "Wand",
    "Shield",
    "Cloth",
    "Leather",
    "Mail",
    "Plate",
}

D.HOUSE_OPTIONS = { "inside", "plot", "editor", "neighborhood" }

-- H1.5: class-aware data tables. Used by the buildParamInput
-- dispatcher when row.paramType is "specname" / "formname" /
-- "stancename" / "petfamily". Dropdown shows the display name;
-- paramValue stores the canonical conditional value.

-- Druid forms. Indices per GetShapeshiftFormID() observation.
D.CLASS_FORMS = {
    DRUID = {
        { name = "Bear", value = "1" },
        { name = "Cat", value = "2" },
        { name = "Travel", value = "3" },
        { name = "Moonkin", value = "4" },
        { name = "Tree", value = "5" },
        { name = "Aquatic", value = "6" },
        { name = "Flight", value = "7" },
    },
}

-- Stances per class. Warrior + DK + Monk are the modern users.
D.CLASS_STANCES = {
    WARRIOR = {
        { name = "Battle Stance", value = "1" },
        { name = "Defensive Stance", value = "2" },
        { name = "Berserker Stance", value = "3" },
    },
    DEATHKNIGHT = {
        { name = "Blood Presence", value = "1" },
        { name = "Frost Presence", value = "2" },
        { name = "Unholy Presence", value = "3" },
    },
    MONK = {
        { name = "Fierce Tiger", value = "1" },
        { name = "Sturdy Ox", value = "2" },
        { name = "Wise Serpent", value = "3" },
    },
}

-- Hunter pet families. Major families covering Tenacity / Cunning / Ferocity.
-- Less common families can be hand-typed in the Cond box; this list
-- covers ~80% of in-use cases. Future iteration may expand.
D.HUNTER_PET_FAMILIES = {
    { name = "Bear", value = "Bear" },
    { name = "Bird of Prey", value = "Bird of Prey" },
    { name = "Boar", value = "Boar" },
    { name = "Cat", value = "Cat" },
    { name = "Crab", value = "Crab" },
    { name = "Devilsaur", value = "Devilsaur" },
    { name = "Hyena", value = "Hyena" },
    { name = "Raptor", value = "Raptor" },
    { name = "Ravager", value = "Ravager" },
    { name = "Scorpid", value = "Scorpid" },
    { name = "Serpent", value = "Serpent" },
    { name = "Spider", value = "Spider" },
    { name = "Tallstrider", value = "Tallstrider" },
    { name = "Turtle", value = "Turtle" },
    { name = "Wolf", value = "Wolf" },
    { name = "Spirit Beast", value = "Spirit Beast" },
}

-- Warlock demon pet names. Modern Warlock pet roster.
D.WARLOCK_PETS = {
    { name = "Imp", value = "Imp" },
    { name = "Voidwalker", value = "Voidwalker" },
    { name = "Felhunter", value = "Felhunter" },
    { name = "Succubus", value = "Succubus" },
    { name = "Felguard", value = "Felguard" },
}

D.rows = {
    -- Combat-relevant ---------------------------------------------------
    {
        key = "combat",
        category = "combat",
        labelKey = "GEMS_IF_PICKER_COMBAT_LABEL",
        tooltipKey = "GEMS_IF_PICKER_COMBAT_TOOLTIP",
        negatable = true,
    },
    {
        key = "nocombat",
        category = "combat",
        labelKey = "GEMS_IF_PICKER_NOCOMBAT_LABEL",
        tooltipKey = "GEMS_IF_PICKER_NOCOMBAT_TOOLTIP",
        negatable = true,
    },
    {
        key = "harm",
        category = "combat",
        labelKey = "GEMS_IF_PICKER_HARM_LABEL",
        tooltipKey = "GEMS_IF_PICKER_HARM_TOOLTIP",
        negatable = true,
    },
    {
        key = "help",
        category = "combat",
        labelKey = "GEMS_IF_PICKER_HELP_LABEL",
        tooltipKey = "GEMS_IF_PICKER_HELP_TOOLTIP",
        negatable = true,
    },
    {
        key = "dead",
        category = "combat",
        labelKey = "GEMS_IF_PICKER_DEAD_LABEL",
        tooltipKey = "GEMS_IF_PICKER_DEAD_TOOLTIP",
        negatable = true,
    },
    {
        key = "stealth",
        category = "combat",
        labelKey = "GEMS_IF_PICKER_STEALTH_LABEL",
        tooltipKey = "GEMS_IF_PICKER_STEALTH_TOOLTIP",
        negatable = true,
    },
    {
        key = "pvpcombat",
        category = "combat",
        labelKey = "GEMS_IF_PICKER_PVPCOMBAT_LABEL",
        tooltipKey = "GEMS_IF_PICKER_PVPCOMBAT_TOOLTIP",
        negatable = true,
    },
    {
        key = "channeling",
        category = "combat",
        labelKey = "GEMS_IF_PICKER_CHANNELING_LABEL",
        tooltipKey = "GEMS_IF_PICKER_CHANNELING_TOOLTIP",
        negatable = true,
    },
    {
        key = "pet",
        category = "combat",
        labelKey = "GEMS_IF_PICKER_PET_LABEL",
        tooltipKey = "GEMS_IF_PICKER_PET_TOOLTIP",
        negatable = true,
        paramType = "petfamily",
    },
    {
        key = "nopet",
        category = "combat",
        labelKey = "GEMS_IF_PICKER_NOPET_LABEL",
        tooltipKey = "GEMS_IF_PICKER_NOPET_TOOLTIP",
        negatable = true,
    },
    {
        key = "petbattle",
        category = "combat",
        labelKey = "GEMS_IF_PICKER_PETBATTLE_LABEL",
        tooltipKey = "GEMS_IF_PICKER_PETBATTLE_TOOLTIP",
        negatable = true,
    },
    {
        key = "mod",
        category = "combat",
        labelKey = "GEMS_IF_PICKER_MOD_LABEL",
        tooltipKey = "GEMS_IF_PICKER_MOD_TOOLTIP",
        negatable = true,
        paramType = "modkey",
        paramOptions = D.MODKEY_OPTIONS,
    },
    {
        key = "button",
        category = "combat",
        labelKey = "GEMS_IF_PICKER_BUTTON_LABEL",
        tooltipKey = "GEMS_IF_PICKER_BUTTON_TOOLTIP",
        negatable = true,
        paramType = "integer",
        paramOptions = { min = 1, max = 5 },
    },
    {
        key = "party",
        category = "combat",
        labelKey = "GEMS_IF_PICKER_PARTY_LABEL",
        tooltipKey = "GEMS_IF_PICKER_PARTY_TOOLTIP",
        negatable = true,
    },
    {
        key = "raid",
        category = "combat",
        labelKey = "GEMS_IF_PICKER_RAID_LABEL",
        tooltipKey = "GEMS_IF_PICKER_RAID_TOOLTIP",
        negatable = true,
    },
    {
        key = "exists",
        category = "combat",
        labelKey = "GEMS_IF_PICKER_EXISTS_LABEL",
        tooltipKey = "GEMS_IF_PICKER_EXISTS_TOOLTIP",
        negatable = true,
    },
    {
        key = "unithasvehicleui",
        category = "combat",
        labelKey = "GEMS_IF_PICKER_UNITVEHICLE_LABEL",
        tooltipKey = "GEMS_IF_PICKER_UNITVEHICLE_TOOLTIP",
        negatable = true,
    },
    -- General-purpose ---------------------------------------------------
    {
        key = "mounted",
        category = "general",
        labelKey = "GEMS_IF_PICKER_MOUNTED_LABEL",
        tooltipKey = "GEMS_IF_PICKER_MOUNTED_TOOLTIP",
        negatable = true,
    },
    {
        key = "swimming",
        category = "general",
        labelKey = "GEMS_IF_PICKER_SWIMMING_LABEL",
        tooltipKey = "GEMS_IF_PICKER_SWIMMING_TOOLTIP",
        negatable = true,
    },
    {
        key = "flying",
        category = "general",
        labelKey = "GEMS_IF_PICKER_FLYING_LABEL",
        tooltipKey = "GEMS_IF_PICKER_FLYING_TOOLTIP",
        negatable = true,
    },
    {
        key = "flyable",
        category = "general",
        labelKey = "GEMS_IF_PICKER_FLYABLE_LABEL",
        tooltipKey = "GEMS_IF_PICKER_FLYABLE_TOOLTIP",
        negatable = true,
    },
    {
        key = "advflyable",
        category = "general",
        labelKey = "GEMS_IF_PICKER_ADVFLYABLE_LABEL",
        tooltipKey = "GEMS_IF_PICKER_ADVFLYABLE_TOOLTIP",
        negatable = true,
    },
    {
        key = "indoors",
        category = "general",
        labelKey = "GEMS_IF_PICKER_INDOORS_LABEL",
        tooltipKey = "GEMS_IF_PICKER_INDOORS_TOOLTIP",
        negatable = true,
    },
    {
        key = "outdoors",
        category = "general",
        labelKey = "GEMS_IF_PICKER_OUTDOORS_LABEL",
        tooltipKey = "GEMS_IF_PICKER_OUTDOORS_TOOLTIP",
        negatable = true,
    },
    {
        key = "resting",
        category = "general",
        labelKey = "GEMS_IF_PICKER_RESTING_LABEL",
        tooltipKey = "GEMS_IF_PICKER_RESTING_TOOLTIP",
        negatable = true,
    },
    {
        key = "group",
        category = "general",
        labelKey = "GEMS_IF_PICKER_GROUP_LABEL",
        tooltipKey = "GEMS_IF_PICKER_GROUP_TOOLTIP",
        negatable = true,
    },
    {
        key = "nogroup",
        category = "general",
        labelKey = "GEMS_IF_PICKER_NOGROUP_LABEL",
        tooltipKey = "GEMS_IF_PICKER_NOGROUP_TOOLTIP",
        negatable = true,
    },
    {
        key = "spec",
        category = "general",
        labelKey = "GEMS_IF_PICKER_SPEC_LABEL",
        tooltipKey = "GEMS_IF_PICKER_SPEC_TOOLTIP",
        negatable = true,
        paramType = "specname",
    },
    {
        key = "form",
        category = "general",
        labelKey = "GEMS_IF_PICKER_FORM_LABEL",
        tooltipKey = "GEMS_IF_PICKER_FORM_TOOLTIP",
        negatable = true,
        paramType = "formname",
    },
    {
        key = "stance",
        category = "general",
        labelKey = "GEMS_IF_PICKER_STANCE_LABEL",
        tooltipKey = "GEMS_IF_PICKER_STANCE_TOOLTIP",
        negatable = true,
        paramType = "stancename",
    },
    {
        key = "equipped",
        category = "general",
        labelKey = "GEMS_IF_PICKER_EQUIPPED_LABEL",
        tooltipKey = "GEMS_IF_PICKER_EQUIPPED_TOOLTIP",
        negatable = true,
        paramType = "itemtype",
        paramOptions = D.ITEMTYPE_OPTIONS,
    },
    {
        key = "worn",
        category = "general",
        labelKey = "GEMS_IF_PICKER_WORN_LABEL",
        tooltipKey = "GEMS_IF_PICKER_WORN_TOOLTIP",
        negatable = true,
        paramType = "itemtype",
        paramOptions = D.ITEMTYPE_OPTIONS,
    },
    {
        key = "known",
        category = "general",
        labelKey = "GEMS_IF_PICKER_KNOWN_LABEL",
        tooltipKey = "GEMS_IF_PICKER_KNOWN_TOOLTIP",
        negatable = true,
        paramType = "spellname",
    },
    {
        key = "canexitvehicle",
        category = "general",
        labelKey = "GEMS_IF_PICKER_CANEXITVEHICLE_LABEL",
        tooltipKey = "GEMS_IF_PICKER_CANEXITVEHICLE_TOOLTIP",
        negatable = true,
    },
    -- UI-state ----------------------------------------------------------
    {
        key = "bonusbar",
        category = "ui",
        labelKey = "GEMS_IF_PICKER_BONUSBAR_LABEL",
        tooltipKey = "GEMS_IF_PICKER_BONUSBAR_TOOLTIP",
        negatable = true,
        paramType = "integer",
        paramOptions = { min = 0, max = 5 },
    },
    {
        key = "overridebar",
        category = "ui",
        labelKey = "GEMS_IF_PICKER_OVERRIDEBAR_LABEL",
        tooltipKey = "GEMS_IF_PICKER_OVERRIDEBAR_TOOLTIP",
        negatable = true,
    },
    {
        key = "possessbar",
        category = "ui",
        labelKey = "GEMS_IF_PICKER_POSSESSBAR_LABEL",
        tooltipKey = "GEMS_IF_PICKER_POSSESSBAR_TOOLTIP",
        negatable = true,
    },
    {
        key = "vehicleui",
        category = "ui",
        labelKey = "GEMS_IF_PICKER_VEHICLEUI_LABEL",
        tooltipKey = "GEMS_IF_PICKER_VEHICLEUI_TOOLTIP",
        negatable = true,
    },
    {
        key = "extrabar",
        category = "ui",
        labelKey = "GEMS_IF_PICKER_EXTRABAR_LABEL",
        tooltipKey = "GEMS_IF_PICKER_EXTRABAR_TOOLTIP",
        negatable = true,
    },
    {
        key = "cursor",
        category = "ui",
        labelKey = "GEMS_IF_PICKER_CURSOR_LABEL",
        tooltipKey = "GEMS_IF_PICKER_CURSOR_TOOLTIP",
        negatable = true,
    },
    {
        key = "actionbar",
        category = "ui",
        labelKey = "GEMS_IF_PICKER_ACTIONBAR_LABEL",
        tooltipKey = "GEMS_IF_PICKER_ACTIONBAR_TOOLTIP",
        negatable = true,
        paramType = "integer",
        paramOptions = { min = 1, max = 6 },
    },
    {
        key = "bar",
        category = "ui",
        labelKey = "GEMS_IF_PICKER_BAR_LABEL",
        tooltipKey = "GEMS_IF_PICKER_BAR_TOOLTIP",
        negatable = true,
        paramType = "integer",
        paramOptions = { min = 1, max = 6 },
    },
    {
        key = "shapeshift",
        category = "ui",
        labelKey = "GEMS_IF_PICKER_SHAPESHIFT_LABEL",
        tooltipKey = "GEMS_IF_PICKER_SHAPESHIFT_TOOLTIP",
        negatable = true,
    },
    {
        key = "house",
        category = "ui",
        labelKey = "GEMS_IF_PICKER_HOUSE_LABEL",
        tooltipKey = "GEMS_IF_PICKER_HOUSE_TOOLTIP",
        negatable = true,
        paramType = "houselocation",
        paramOptions = D.HOUSE_OPTIONS,
    },
}

-- Convenience: rows grouped by category for tab rendering.
D.byCategory = { combat = {}, general = {}, ui = {} }
for _, row in ipairs(D.rows) do
    local bucket = D.byCategory[row.category]
    if bucket then
        bucket[#bucket + 1] = row
    end
end

-- Index for quick lookup by key.
D.byKey = {}
for _, row in ipairs(D.rows) do
    D.byKey[row.key] = row
end
