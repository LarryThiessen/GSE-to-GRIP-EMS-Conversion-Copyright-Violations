-- GRIP-EMS: RecommendationEvaluator
-- Created: 2026-05-26
-- Updated: 2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.
--
-- Evaluates per-sequence recommend functions (verData.recommendSource with a
-- seqData.recommendSource fallback) and fires VARIANT_RECOMMENDATION_UPDATED
-- whenever the recommended variant flips. The function returns one of
-- "plain"/"shift"/"ctrl"/"alt" -- any other value silently degrades to nil
-- (base variant armed) so a misbehaving recommend function never blocks
-- macro execution or writes to SavedVariables.
--
-- Module shape mirrors Engine/TempoAdvisor.lua (the canonical sibling that
-- fires TEMPO_RECOMMENDATION_UPDATED). Single VARIABLE_UPDATED listener fans
-- out to every referencing sequence via VariableStore:GetReferences, debounced
-- 200 ms per sequence so rapid stat flicker does not spam the event surface.

local _, GRIPEMS = ...
GRIPEMS.RecommendationEvaluator = {}
local RE = GRIPEMS.RecommendationEvaluator

-- Lazy module accessor (avoid load-order dependency on Defaults)
local function D()
    return GRIPEMS.Defaults
end

-- Module-local state. All state lives on the RE table so a /reload retains
-- nothing across sessions (compiled functions live on the verData table and
-- are wiped by Engine cleanup).
RE._cachedResult = {}
RE._scheduledTimers = {}
RE._debounceFrame = nil

-- Sandbox env exposed to the recommend function. Includes the Layer 1
-- condition helpers also offered by the VariablesTab Insert Helper picker
-- plus a whitelist of safe Lua and WoW globals. WoW's runtime restricts
-- file I/O and combat-restricted API on its own, so no additional sandbox
-- beyond this explicit whitelist is required.
local function BuildSandbox()
    local env = {
        HasBuff = GRIPEMS.HasBuff,
        HasDebuff = GRIPEMS.HasDebuff,
        SpellReady = GRIPEMS.SpellReady,
        SpellOnCooldown = GRIPEMS.SpellOnCooldown,
        SpellEnabled = GRIPEMS.SpellEnabled,
        IsRestricted = GRIPEMS.IsRestricted,
        math = math,
        string = string,
        table = table,
        tonumber = tonumber,
        tostring = tostring,
        ipairs = ipairs,
        pairs = pairs,
        select = select,
        type = type,
        unpack = unpack,
        UnitHealth = UnitHealth,
        UnitHealthMax = UnitHealthMax,
        UnitPower = UnitPower,
        UnitPowerMax = UnitPowerMax,
        UnitName = UnitName,
        UnitExists = UnitExists,
        GetTime = GetTime,
    }
    -- UnitHealthPercent: tostring round-trip launders the WoW "secret
    -- number" taint on UnitHealth/UnitHealthMax outputs so the resulting
    -- value can be compared in insecure code without taint cascade. Same
    -- technique TempoAdvisor uses (UntaintNumber).
    env.UnitHealthPercent = function(unit)
        unit = unit or "player"
        if not UnitExists(unit) then
            return 0
        end
        local hMaxRaw = UnitHealthMax(unit) or 0
        local hCurRaw = UnitHealth(unit) or 0
        local hMax = tonumber(tostring(hMaxRaw)) or 0
        local hCur = tonumber(tostring(hCurRaw)) or 0
        if hMax <= 0 then
            return 0
        end
        return hCur / hMax * 100
    end
    return env
end

-- Registers the VARIABLE_UPDATED callback. Called once at PLAYER_LOGIN via the
-- self-bootstrap frame below; subsequent calls are no-ops because the
-- CallbackHandler dot-notation registration is idempotent on (target, event).
function RE:Initialize()
    if GRIPEMS.RegisterCallback then
        GRIPEMS.RegisterCallback(self, "VARIABLE_UPDATED", "OnVariableUpdate")
    end
    RE._debounceFrame = RE._debounceFrame or CreateFrame("Frame")
    if GRIPEMS.Debug then
        GRIPEMS:Debug("RecommendationEvaluator initialized.")
    end
end

-- Compile the recommend function for one version. Resolves verData.recommendSource
-- first, then falls back to seqData.recommendSource. Caches the compiled
-- function on verData._recommendFunc so Evaluate is a single pcall at
-- runtime. Returns the compiled function or nil. Never raises.
function RE:CompileForVersion(seqName, verIdx, seqData, verData)
    if not verData then
        return nil
    end
    local src = verData.recommendSource
    if (type(src) ~= "string" or src == "") and seqData then
        src = seqData.recommendSource
    end
    if type(src) ~= "string" or src == "" then
        verData._recommendFunc = nil
        return nil
    end
    local chunkName = "GRIPEMS_RecommendSource:" .. tostring(seqName) .. ":v" .. tostring(verIdx or 0)
    local fn, loadErr = loadstring(src, chunkName)
    if not fn then
        if GRIPEMS.Debug then
            GRIPEMS:Debug(
                string.format(
                    "[RE] compile error in '%s' v%s: %s",
                    tostring(seqName),
                    tostring(verIdx),
                    tostring(loadErr)
                )
            )
        end
        verData._recommendFunc = nil
        return nil
    end
    if setfenv then
        setfenv(fn, BuildSandbox())
    end
    verData._recommendFunc = fn
    return fn
end

-- Returns the active version's compiled recommend function for the given
-- sequence, or nil. Uses the same Engine:GetActiveVersion accessor as the
-- variant button compile site.
local function GetActiveRecommendFunc(seqName)
    local Engine = GRIPEMS.Engine
    if not Engine or not Engine.sequences then
        return nil
    end
    local entry = Engine.sequences[seqName]
    if not entry or not entry.data then
        return nil
    end
    local ver = Engine.GetActiveVersion and Engine:GetActiveVersion(entry.data) or nil
    if ver and ver._recommendFunc then
        return ver._recommendFunc
    end
    return nil
end

-- pcall the cached function and return one of the four canonical modifier
-- strings, or nil. Never raises; never spams chat on bad return -- the debug
-- channel records the rejection so power users can inspect it via /gems debug.
function RE:Evaluate(seqName)
    local fn = GetActiveRecommendFunc(seqName)
    if not fn then
        return nil
    end
    local ok, result = pcall(fn)
    if not ok then
        if GRIPEMS.Debug then
            GRIPEMS:Debug(string.format("[RE] runtime error in '%s': %s", tostring(seqName), tostring(result)))
        end
        return nil
    end
    local Defs = D()
    if not Defs then
        return nil
    end
    if
        result == Defs.VARIANT_MOD_PLAIN
        or result == Defs.VARIANT_MOD_SHIFT
        or result == Defs.VARIANT_MOD_CTRL
        or result == Defs.VARIANT_MOD_ALT
    then
        return result
    end
    return nil
end

-- VARIABLE_UPDATED fan-out. Walks the variable's referencing sequences and
-- schedules a debounced re-eval for each. The reverse lookup itself is
-- VariableStore:GetReferences which scans steps for ~varName~; recommend
-- functions usually re-use those same helpers so the reverse index is a
-- good first approximation. Sequences whose recommend function does NOT
-- depend on this variable still re-eval; the cached compare-and-fire in
-- _ScheduleReeval keeps the event surface quiet when nothing changes.
function RE:OnVariableUpdate(_, varName)
    local seen = {}
    -- Pass A: variable-referencing sequences (existing path)
    local VS = GRIPEMS.VariableStore
    if VS and VS.GetReferences and varName then
        local refs = VS:GetReferences(varName) or {}
        for _, seqName in ipairs(refs) do
            if not seen[seqName] then
                seen[seqName] = true
                self:_ScheduleReeval(seqName)
            end
        end
    end
    -- Pass B: every sequence with a compiled _recommendFunc on the
    -- active version (covers Layer-1-direct recommend functions like
    -- HasBuff / UnitHealthPercent that do not appear in VS:GetReferences).
    local Engine = GRIPEMS.Engine
    if Engine and Engine.sequences then
        for seqName, entry in pairs(Engine.sequences) do
            if not seen[seqName] and entry and entry.data then
                local ver = Engine.GetActiveVersion and Engine:GetActiveVersion(entry.data)
                if ver and ver._recommendFunc then
                    seen[seqName] = true
                    self:_ScheduleReeval(seqName)
                end
            end
        end
    end
end

-- Sets a single debounced timer per sequence. The 200 ms window collapses
-- VARIABLE_UPDATED bursts from event-driven re-eval consolidation
-- (VariableStore L520-580 batches). On fire, compares the new evaluation
-- against the cached previous result and fires VARIANT_RECOMMENDATION_UPDATED
-- only on a real change.
function RE:_ScheduleReeval(seqName)
    if not seqName then
        return
    end
    if RE._scheduledTimers[seqName] then
        return
    end
    RE._scheduledTimers[seqName] = true
    local debounceMs = (D() and D().RECOMMENDATION_DEBOUNCE_MS) or 200
    local delay = debounceMs / 1000
    if not (C_Timer and C_Timer.After) then
        RE._scheduledTimers[seqName] = nil
        return
    end
    C_Timer.After(delay, function()
        RE._scheduledTimers[seqName] = nil
        local newMod = RE:Evaluate(seqName)
        local oldMod = RE._cachedResult[seqName]
        if newMod ~= oldMod then
            RE._cachedResult[seqName] = newMod
            if GRIPEMS.Fire then
                GRIPEMS:Fire("VARIANT_RECOMMENDATION_UPDATED", seqName, oldMod, newMod)
            end
        end
    end)
end

-- Read-only accessor for TrackerHUD / BarIntegration consumers. Returns the
-- last cached recommendation ("plain"/"shift"/"ctrl"/"alt") or nil.
function RE:GetCachedRecommendation(seqName)
    if not seqName then
        return nil
    end
    return RE._cachedResult[seqName]
end

-- Self-bootstrap. PLAYER_LOGIN fires after Core.lua's ADDON_LOADED handler
-- has set up CallbackHandler-1.0 + GRIPEMS:Fire, so we register exactly
-- once and then unregister to keep the event surface minimal.
do
    local bootstrap = CreateFrame("Frame")
    bootstrap:RegisterEvent("PLAYER_LOGIN")
    bootstrap:SetScript("OnEvent", function(self)
        self:UnregisterAllEvents()
        if RE.Initialize then
            RE:Initialize()
        end
    end)
end
