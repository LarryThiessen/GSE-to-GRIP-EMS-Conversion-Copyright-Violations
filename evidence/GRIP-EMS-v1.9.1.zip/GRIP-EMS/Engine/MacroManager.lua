-- GRIP-EMS: Macro Manager
-- CRUD operations for WoW macro stubs that /click the sequencer buttons

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS")
local D = GRIPEMS.Defaults

-- MacroManager module: creates, updates, and deletes the WoW macros that act
-- as stubs for GRIP-EMS sequences. Each active sequence gets one per-character
-- macro whose body is:
--   #showtooltip
--   /click [button:1] GRIPEMS_SeqName LeftButton t; GRIPEMS_SeqName
-- The [button:1] conditional targets left-click events; the trailing bare name
-- is a fallback for virtual button and keyboard-only usage. The macro stub
-- is what the player drags to their action bar; clicking it triggers the
-- SecureActionButton which executes the current step's attributes.
-- All write operations go through OOCQueue to handle combat lockdown.
GRIPEMS.MacroManager = {
    stubs = {}, -- seqName -> macroId mapping
}
local MM = GRIPEMS.MacroManager

--- Truncate a sequence name to fit within the macro name limit.
--- Format: "GEMS:<name>" must fit in MAX_MACRO_NAME (16) chars.
--- If a collision exists in the stubs table, appends a numeric suffix.
--- @param seqName string The sequence name to truncate
--- @return string The truncated macro name
function MM:TruncateName(seqName)
    if not seqName then
        return D.MACRO_PREFIX
    end
    local prefixLen = #D.MACRO_PREFIX
    local maxNameLen = D.MAX_MACRO_NAME - prefixLen
    local truncated = D.MACRO_PREFIX .. seqName:sub(1, maxNameLen)

    -- Check for collisions with existing stubs
    local suffix = 1
    local maxSuffix = 99
    while suffix <= maxSuffix do
        local collision = false
        for existingSeq, _ in pairs(self.stubs) do
            if existingSeq ~= seqName then
                local existingMacroName = self:GetMacroName(existingSeq)
                if existingMacroName == truncated then
                    collision = true
                    break
                end
            end
        end
        if not collision then
            break
        end
        -- Append numeric suffix, shrinking the name portion to fit
        local suffixStr = tostring(suffix)
        local shrunkLen = D.MAX_MACRO_NAME - prefixLen - #suffixStr
        if shrunkLen < 1 then
            shrunkLen = 1
        end
        truncated = D.MACRO_PREFIX .. seqName:sub(1, shrunkLen) .. suffixStr
        suffix = suffix + 1
    end
    return truncated
end

--- Get the macro display name for a sequence (without collision resolution).
--- Used internally for collision detection.
--- @param seqName string The sequence name
--- @return string The basic macro name (may collide)
function MM:GetMacroName(seqName)
    if not seqName then
        return D.MACRO_PREFIX
    end
    local prefixLen = #D.MACRO_PREFIX
    local maxNameLen = D.MAX_MACRO_NAME - prefixLen
    return D.MACRO_PREFIX .. seqName:sub(1, maxNameLen)
end

--- Build the macro stub body, fitting keyPress/keyRelease lines greedily
--- within the 255-char macro body limit. Lines are added top-down; once a
--- line does not fit, all remaining lines for that block are skipped.
--- Always includes #showtooltip and the /click line.
--- @param buttonName string The SecureActionButton global name
--- @param keyPress string|nil KeyPress block (multi-line)
--- @param keyRelease string|nil KeyRelease block (multi-line)
--- @return string The macro body text
function MM:BuildStubBody(buttonName, keyPress, keyRelease)
    local kp = keyPress or ""
    local kr = keyRelease or ""
    -- No keyPress/keyRelease: use default template
    if kp == "" and kr == "" then
        return string.format(D.MACRO_BODY_TEMPLATE, buttonName, buttonName)
    end
    local showtooltip = "#showtooltip"
    local clickLine = string.format("/click [button:1] %s LeftButton t; %s", buttonName, buttonName)
    -- Fixed cost: #showtooltip\n.../click line
    local fixedLen = #showtooltip + 1 + #clickLine
    if fixedLen > D.MAX_MACRO_BODY then
        -- Safety: use short /click form
        clickLine = "/click " .. buttonName
        fixedLen = #showtooltip + 1 + #clickLine
    end
    local remaining = D.MAX_MACRO_BODY - fixedLen
    -- Split keyPress into individual lines
    local kpLines = {}
    if kp ~= "" then
        for line in kp:gmatch("[^\n]+") do
            kpLines[#kpLines + 1] = line
        end
    end
    -- Fit keyPress lines top-down (inserted between #showtooltip and /click)
    local fittedKP = {}
    for _, line in ipairs(kpLines) do
        local cost = 1 + #line -- \n separator + line content
        if cost <= remaining then
            fittedKP[#fittedKP + 1] = line
            remaining = remaining - cost
        else
            break -- top-down order matters, stop on first miss
        end
    end
    -- Split keyRelease into individual lines
    local krLines = {}
    if kr ~= "" then
        for line in kr:gmatch("[^\n]+") do
            krLines[#krLines + 1] = line
        end
    end
    -- Fit keyRelease lines top-down (appended after /click)
    local fittedKR = {}
    for _, line in ipairs(krLines) do
        local cost = 1 + #line -- \n separator + line content
        if cost <= remaining then
            fittedKR[#fittedKR + 1] = line
            remaining = remaining - cost
        else
            break
        end
    end
    -- Assemble: #showtooltip, [kp lines...], /click, [kr lines...]
    local parts = { showtooltip }
    for _, line in ipairs(fittedKP) do
        parts[#parts + 1] = line
    end
    parts[#parts + 1] = clickLine
    for _, line in ipairs(fittedKR) do
        parts[#parts + 1] = line
    end
    -- Warn about dropped lines
    if #fittedKP < #kpLines then
        GRIPEMS:Print(
            (L["GEMS_WARN_KP_LINES_TRIMMED"] or "keyPress: %d of %d lines fit in macro stub (255-char limit)"):format(
                #fittedKP,
                #kpLines
            )
        )
    end
    if #fittedKR < #krLines then
        GRIPEMS:Print(
            (L["GEMS_WARN_KR_LINES_TRIMMED"] or "keyRelease: %d of %d lines fit in macro stub (255-char limit)"):format(
                #fittedKR,
                #krLines
            )
        )
    end
    return table.concat(parts, "\n")
end

--- Update an existing macro stub body (e.g., after keyPress changes).
--- @param seqName string The sequence name
--- @param keyPress string|nil KeyPress block
--- @param keyRelease string|nil KeyRelease block
function MM:UpdateStubBody(seqName, keyPress, keyRelease)
    if not seqName or not self.stubs[seqName] then
        return
    end
    local macroId = self.stubs[seqName]
    local buttonName = D.BUTTON_PREFIX .. GRIPEMS.Engine:SanitizeName(seqName)
    local body = self:BuildStubBody(buttonName, keyPress, keyRelease)
    local function doUpdate()
        EditMacro(macroId, nil, nil, body)
    end
    GRIPEMS.OOCQueue:Add(doUpdate, D.OOC_OP_GENERIC, seqName)
end

--- Create a macro stub for a sequence. Queues via OOCQueue if in combat.
--- @param seqName string The sequence name
--- @param keyPress string|nil KeyPress block for macro stub body
--- @param keyRelease string|nil KeyRelease block for macro stub body
--- @return number|nil The macro ID if created immediately, nil if queued or failed
--- @return string|nil Error message if creation failed
function MM:CreateStub(seqName, keyPress, keyRelease)
    if not seqName or seqName == "" then
        return nil, L["GEMS_ERR_NO_NAME"]
    end

    -- Check if stub already exists
    if self.stubs[seqName] then
        -- Refresh body with current keyPress/keyRelease (stub may have been
        -- reclaimed by ScanExisting with stale body from a previous session)
        if keyPress or keyRelease then
            self:UpdateStubBody(seqName, keyPress, keyRelease)
        end
        return self.stubs[seqName], nil
    end

    local function doCreate()
        -- Check available slots
        local available = self:GetAvailableSlots()
        if available <= 0 then
            local _, perChar = GetNumMacros()
            GRIPEMS:Print(string.format(L["GEMS_ERR_NO_MACRO_SLOTS"], perChar, D.MAX_PER_CHAR_MACROS))
            return
        end

        local macroName = self:TruncateName(seqName)
        local buttonName = D.BUTTON_PREFIX .. GRIPEMS.Engine:SanitizeName(seqName)
        local body = self:BuildStubBody(buttonName, keyPress, keyRelease)

        local ok, result = pcall(CreateMacro, macroName, D.QUESTION_MARK_ICON, body, true)
        if ok and result then
            self.stubs[seqName] = result
            -- Refresh keybind to route through macro stub (enables keyPress via keybind)
            if GRIPEMS.KeybindManager and not GRIPEMS.OOCQueue.IsRestricted() then
                GRIPEMS.KeybindManager:BindIfConfigured(seqName)
            end
            GRIPEMS:Debug(string.format(L["GEMS_MACRO_CREATED"], macroName, result))
        else
            local errMsg = not ok and tostring(result) or "unknown error"
            GRIPEMS:Print(string.format(L["GEMS_ERR_MACRO_CREATE_FAILED"], seqName) .. " (" .. errMsg .. ")")
        end
    end

    GRIPEMS.OOCQueue:Add(doCreate, D.OOC_OP_GENERIC, seqName)
    return nil, nil
end

--- Delete the macro stub for a sequence. Queues via OOCQueue if in combat.
--- @param seqName string The sequence name
function MM:DeleteStub(seqName)
    if not seqName or not self.stubs[seqName] then
        return
    end

    local function doDelete()
        -- Scan for our macro by body content (immune to index shifts)
        local _, perChar = GetNumMacros()
        local accountSlots = D.MAX_ACCOUNT_MACROS
        local targetBtn = D.BUTTON_PREFIX .. GRIPEMS.Engine:SanitizeName(seqName)
        for i = accountSlots + 1, accountSlots + perChar do
            local _, _, body = GetMacroInfo(i)
            local pos = body and body:find(targetBtn, 1, true)
            if pos then
                local afterChar = body:sub(pos + #targetBtn, pos + #targetBtn)
                if afterChar == "" or not afterChar:match("[%w_]") then
                    DeleteMacro(i)
                    break
                end
            end
        end
        self.stubs[seqName] = nil
    end

    GRIPEMS.OOCQueue:Add(doDelete, D.OOC_OP_GENERIC, seqName)
end

--- Update the icon of a macro stub. Queues via OOCQueue if in combat.
--- @param seqName string The sequence name
--- @param iconFileID number The icon texture fileID
function MM:UpdateIcon(seqName, iconFileID)
    if not seqName or not self.stubs[seqName] then
        return
    end
    if not iconFileID then
        return
    end
    local macroId = self.stubs[seqName]

    local function doUpdate()
        EditMacro(macroId, nil, iconFileID, nil)
    end

    GRIPEMS.OOCQueue:Add(doUpdate, D.OOC_OP_ICON, seqName)
end

--- Scan all per-character macros on login and reclaim any GRIP-EMS stubs.
--- Rebuilds the stubs table from found macros whose body starts with
--- "/click GRIPEMS_". Called on PLAYER_ENTERING_WORLD.
function MM:ScanExisting()
    -- Clear stale entries before rescanning
    wipe(self.stubs)

    -- Build reverse lookup: sanitized -> original sequence name
    local sanitizedToOriginal = {}
    if _G.GRIP_EMS_CHAR and _G.GRIP_EMS_CHAR.sequences then
        for origName, _ in pairs(_G.GRIP_EMS_CHAR.sequences) do
            local sanitized = GRIPEMS.Engine:SanitizeName(origName)
            sanitizedToOriginal[sanitized] = origName
        end
    end

    local _, perChar = GetNumMacros()
    local accountSlots = D.MAX_ACCOUNT_MACROS
    local found = 0

    for i = accountSlots + 1, accountSlots + perChar do
        local name, _, body = GetMacroInfo(i)
        if name and body then
            local buttonMatch = body:match("; " .. D.BUTTON_PREFIX .. "(%S+)")
            if not buttonMatch then
                buttonMatch = body:match("/click " .. D.BUTTON_PREFIX .. "(%S+)")
            end
            if buttonMatch then
                local sanitizedName = buttonMatch:gsub("%s+LeftButton.*$", "")
                -- Map back to original sequence name (spaces, not underscores)
                local seqName = sanitizedToOriginal[sanitizedName] or sanitizedName
                self.stubs[seqName] = i
                found = found + 1
            end
        end
    end

    if found > 0 then
        GRIPEMS:Debug(string.format(L["GEMS_MACROS_SCANNED"], found))
    end
end

--- Return the number of available per-character macro slots.
--- @return number Available slots
function MM:GetAvailableSlots()
    local _, perChar = GetNumMacros()
    return D.MAX_PER_CHAR_MACROS - perChar
end
