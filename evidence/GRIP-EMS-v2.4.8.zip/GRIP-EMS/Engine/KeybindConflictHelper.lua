-- GRIP-EMS: KeybindConflictHelper
-- Created: 2026-08-11
-- Updated: 2026-08-25 (Patch header swept to build 12.1.0.69273; 2026-08-12 Phase 4: fix plans, revert plans, staleness predicates)
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.

-- GRIP-EMS: Keybind Conflict Detection (presentation logic)
--
-- Engine/KeybindConflict.lua answers "what owns this key" and renders nothing.
-- UI/KeybindConflictPanel.lua renders and cannot run outside the client. This
-- file is everything in between: turning a CheckKey result into rows, tallying
-- severities, and mapping every published token to the locale key that carries
-- its copy.
--
-- IT RETURNS LOCALE KEYS AND NEVER LOCALISED STRINGS. The panel does the L
-- lookup. That single rule is what keeps this file loadable with no client, no
-- LibStub and no AceLocale, which in turn is what lets the contested-key case in
-- Test/test_keybind_conflict_panel.lua exist at all. A single L[...] here would
-- take that away.
--
-- No frames, no CreateFrame, and every WoW global reached through the deps table
-- that KeybindConflict.lua already threads -- this file passes deps straight
-- through and touches no global itself.
--
-- WHY THE COPY MAP IS DATA. The detection core deliberately emits machine tokens
-- with no copy attached. Mapping them in a table rather than in an if-chain makes
-- the mapping ENUMERABLE, so a test can walk KC's published sets and prove copy
-- exists for every token. That matters more than it sounds: the panel builds its
-- keys through CopyKeyFor rather than as literals, so audit-locale-references
-- has no literal to scan and is structurally blind to a missing one.

local _, GRIPEMS = ...

GRIPEMS.KeybindConflictHelper = {}
local KCH = GRIPEMS.KeybindConflictHelper

local KC = GRIPEMS.KeybindConflict

-- ===========================================================================
-- Token -> locale key
-- ===========================================================================

--- Every published token, mapped to the locale key carrying its copy.
---
--- Keyed by the TOKEN, the string that travels on the wire, not by the field
--- name it has on the KC table. For KC.STATUS and KC.LAYER_IDS those happen to
--- match; for KC.NOTE_REASONS they do not (field baseOwner, token
--- native_binding_owner), and keying by field name would look correct and miss
--- every note.
KCH.COPY_KEYS = {
    status = {
        clear = "GEMS_KC_STATUS_CLEAR",
        conflict = "GEMS_KC_STATUS_CONFLICT",
        unknown = "GEMS_KC_STATUS_UNKNOWN",
        masked = "GEMS_KC_STATUS_MASKED",
    },
    layer = {
        base = "GEMS_KC_LAYER_BASE",
        effective = "GEMS_KC_LAYER_EFFECTIVE",
        modifier = "GEMS_KC_LAYER_MODIFIER",
        clickbind = "GEMS_KC_LAYER_CLICKBIND",
    },
    noteReason = {
        masked_by_effective_override = "GEMS_KC_NOTE_MASKED",
        native_binding_owner = "GEMS_KC_NOTE_BASE_OWNER",
        cast_redirect = "GEMS_KC_NOTE_CAST_REDIRECT",
        click_binding_owner = "GEMS_KC_NOTE_CLICK_OWNER",
        layer_conflict = "GEMS_KC_NOTE_OTHER",
    },
    limit = {
        hooks_installed_at_load = "GEMS_KC_LIMIT_HOOKS_AT_LOAD",
        secure_handler_bindings_invisible = "GEMS_KC_LIMIT_SECURE_HANDLER",
        records_attempts_not_ownership = "GEMS_KC_LIMIT_ATTEMPTS_NOT_OWNERSHIP",
        deduplicated_stack_is_first_caller = "GEMS_KC_LIMIT_DEDUP_FIRST_CALLER",
        key_budget_exhausted = "GEMS_KC_LIMIT_KEY_BUDGET",
    },
    -- Descriptive copy for the severity filter chips. The BADGE text stays
    -- English and comes from UI.SEVERITY_LABELS, the same as RepairFrame; these
    -- are the sentences that say what the badge means.
    severity = {
        critical = "GEMS_KC_SEVERITY_CRITICAL",
        error = "GEMS_KC_SEVERITY_ERROR",
        warning = "GEMS_KC_SEVERITY_WARNING",
        info = "GEMS_KC_SEVERITY_INFO",
    },
    section = {
        sequence = "GEMS_KC_SECTION_SEQUENCE",
        vehicle = "GEMS_KC_SECTION_VEHICLE",
        petbattle = "GEMS_KC_SECTION_PETBATTLE",
        probe = "GEMS_KC_SECTION_PROBE",
    },
    -- Why a fix was REFUSED. Every one of these means the world moved between
    -- the moment the panel read it and the moment the user pressed the button,
    -- so the copy has to name the key or the action rather than say "failed".
    planReject = {
        base_changed = "GEMS_KC_PLAN_REJECT_BASE_CHANGED",
        modifier_changed = "GEMS_KC_PLAN_REJECT_MODIFIER_CHANGED",
        key_now_free = "GEMS_KC_PLAN_REJECT_KEY_NOW_FREE",
    },
}

--- The per-kind fallback, and the reason CopyKeyFor is total.
---
--- A nil copy key renders as a blank row, and a blank row in a diagnostics panel
--- reads as "nothing found" -- the single most damaging thing this panel could
--- say about a key that is actually contested. An unrecognised token gets a row
--- that admits it is unrecognised instead.
KCH.FALLBACK_KEYS = {
    status = "GEMS_KC_STATUS_UNRECOGNISED",
    layer = "GEMS_KC_LAYER_UNRECOGNISED",
    noteReason = "GEMS_KC_NOTE_UNRECOGNISED",
    limit = "GEMS_KC_LIMIT_UNRECOGNISED",
    severity = "GEMS_KC_SEVERITY_UNRECOGNISED",
    section = "GEMS_KC_SECTION_UNRECOGNISED",
    planReject = "GEMS_KC_UNRECOGNISED_PLAN_REJECT",
}

--- Used when even the KIND is unrecognised, which can only happen through a
--- caller typo. Still a real key, for the same reason.
KCH.FALLBACK_KEY = "GEMS_KC_UNRECOGNISED"

--- The locale key for one token. TOTAL: never returns nil, for any input.
--- @param kind string|nil One of the KCH.COPY_KEYS sub-table names
--- @param token string|nil A published token
--- @return string A locale key, mapped or fallback
function KCH.CopyKeyFor(kind, token)
    local set = kind ~= nil and KCH.COPY_KEYS[kind] or nil
    if set == nil then
        return KCH.FALLBACK_KEY
    end
    if token ~= nil then
        local mapped = set[token]
        if mapped ~= nil then
            return mapped
        end
    end
    return KCH.FALLBACK_KEYS[kind] or KCH.FALLBACK_KEY
end

-- ===========================================================================
-- Manual fixes
-- ===========================================================================

--- The locale key for the manual instruction on a row's disabled Fix button, or
--- nil when the row has no manual fix.
---
--- EXACTLY TWO ROWS HAVE ONE, and both come straight out of the resolution
--- section of the research record, where they were measured as supported
--- sequences rather than inferred:
---   * a base layer holding a native binding -> the user clears it in the
---     client's own Key Bindings panel;
---   * a modifier layer holding a cast redirect -> the user sets that
---     modified-click action to None in the client's combat settings.
---
--- THERE IS DELIBERATELY NO ENTRY FOR AN OVERRIDE-LAYER CONFLICT. There is no
--- supported way to clear another addon's override binding, so offering an
--- instruction for it would be promising something that cannot be done. A row
--- with no manual fix shows the disabled button with no tooltip promise, which is
--- the honest state.
---
--- DERIVED FROM THE PLAN, NOT COMPUTED SEPARATELY, and that is a Phase 4 change
--- with a reason. The two used to be independent and they DISAGREED: this
--- function keyed off row.reason, which NOTE rows carry, so a note row was
--- offered a manual instruction while KCH.BuildFixPlan -- which needs the
--- layer row's action or entries and a note row has neither -- returned nil for
--- it. Two rows for one finding, one promising a fix the other could not build.
---
--- The disagreement is resolved in the direction that puts the fix copy on the
--- row that holds the fix DATA. A note row loses nothing by it, but NOT for the
--- reason first written here, which claimed the note copy already spells out the
--- manual step. Checked against the strings: GEMS_KC_NOTE_BASE_OWNER does say it
--- ("Clear it in the game's Key Bindings panel to hand the key back"), and
--- GEMS_KC_NOTE_CAST_REDIRECT does NOT -- it describes the symptom and names no
--- remedy at all.
---
--- The reason nothing is lost is STRUCTURAL, and it is the stronger argument.
--- KC.CheckKey emits a note only for a layer whose own status is masked or
--- conflict, and noteReasonFor returns the masked token FIRST, so a note carrying
--- baseOwner or castRedirect can only come from a layer at status conflict. That
--- layer always emits its own layer row in the same section, and that row is
--- exactly the one BuildFixPlan serves. The instruction did not disappear; it
--- moved off a row that cannot act onto the row that can.
---
--- Deriving rather than re-deriving also makes the biconditional structural
--- instead of coincidental, so the two cannot drift apart again.
--- @param row table A row produced by KCH.BuildReport
--- @return string|nil
function KCH.ManualFixKeyFor(row)
    local plan = KCH.BuildFixPlan(row)
    if plan == nil then
        return nil
    end
    if plan.kind == KCH.FIX_KINDS.base then
        return "GEMS_KC_FIX_MANUAL_BASE"
    elseif plan.kind == KCH.FIX_KINDS.modifier then
        return "GEMS_KC_FIX_MANUAL_CAST_REDIRECT"
    end
    return nil
end

--- The three states a row's Fix button can be in.
KCH.FIX_BUTTON_STATES = {
    actionable = "actionable",
    unavailable = "unavailable",
    none = "none",
}

--- Whether a row gets a Fix button at all, and what it may claim.
---
--- THIS EXISTS BECAUSE THE DISABLED BUTTON CARRIES A UNIVERSAL NEGATIVE. Its
--- tooltip reads "There is no supported way for an addon to take this key back for
--- you", and until this function existed EVERY non-section row fell through to
--- that sentence. On most of them it was merely noise -- a row reading "Base:
--- Clear" does not need to be told the key cannot be reclaimed. On one row it was
--- FALSE, and falsest exactly where the feature matters most: a NOTE row restates
--- a finding whose LAYER row sits directly above it, and after Phase 4 made
--- ManualFixKeyFor derive from BuildFixPlan that layer row carries an ENABLED Fix.
--- The panel offered the fix and denied one existed, in the same section, for the
--- same finding.
---
--- So the sentence is now reserved for rows where it is TRUE: a layer row whose
--- status is conflict and for which no plan can be built. That is the override
--- case on the effective layer, which is what the copy was written for -- there is
--- no supported way to clear another addon's override binding.
---
--- Every other row returns none and renders no button. A button is a claim; a row
--- with nothing to claim should not make one.
--- @param row table|nil A row produced by KCH.BuildReport
--- @return string One of KCH.FIX_BUTTON_STATES
function KCH.FixButtonStateFor(row)
    if type(row) ~= "table" then
        return KCH.FIX_BUTTON_STATES.none
    end
    if KCH.BuildFixPlan(row) ~= nil then
        return KCH.FIX_BUTTON_STATES.actionable
    end
    if row.kind == "layer" and row.status == KC.STATUS.conflict then
        return KCH.FIX_BUTTON_STATES.unavailable
    end
    return KCH.FIX_BUTTON_STATES.none
end

-- ===========================================================================
-- The revert stack, as list operations
-- ===========================================================================
--
-- These live here rather than in the panel for the reason the whole module
-- exists: the panel cannot be tested without a client, and the bug these two
-- functions encode was invisible to every headless case until one was written for
-- it. They touch no WoW API -- one mutates an array the caller owns, the other
-- reads it and asks a predicate the caller supplies.

--- Push a revert entry, keeping at most ONE entry per key.
---
--- Newest wins. A second entry for a key the user has already fixed once
--- describes a world that no longer exists: fix a key, rebind it by hand, fix it
--- again, and the older entry would restore the command the USER replaced.
---
--- Uniqueness is also load-bearing for KCH.SelectRevertIndex below. With one
--- entry per key, skipping a stuck entry can never reorder two reverts that had
--- to stay ordered relative to each other.
--- @param stack table Array of entries carrying a .key
--- @param entry table The entry to push
--- @return table stack The same array, for chaining
function KCH.PushRevertEntry(stack, entry)
    if type(stack) ~= "table" or type(entry) ~= "table" then
        return stack
    end
    for index = #stack, 1, -1 do
        local existing = stack[index]
        if type(existing) == "table" and existing.key == entry.key then
            table.remove(stack, index)
        end
    end
    stack[#stack + 1] = entry
    return stack
end

--- The index of the newest revert that may be applied right now, plus every
--- index that refused on the way there.
---
--- THE BUG THIS REPLACES, and it is worth stating because the behaviour it
--- corrects looked correct. Refusing a revert WITHOUT discarding it is right: the
--- revert becomes valid again the moment whatever claimed the key lets go, and
--- discarding it would remove the user's only way back. But an implementation
--- that reads ONLY the top of the stack turns that virtue into a trap. One
--- permanently-claimed key sits at the head and strands every revert beneath it
--- forever, with the Undo button lit and doing nothing. Fix two keys, rebind one
--- of them by hand, and the OTHER key's way back is gone.
---
--- So: walk down, return the first index that passes, and report the ones that
--- did not so the caller can tell the user about each rather than skipping any
--- of them in silence. Nothing is removed here; removal is the caller's job and
--- only on success.
--- @param stack table Array of entries carrying a .revert
--- @param isValid function fn(entry) -> boolean, ... -- the caller's live check
--- @return number|nil index The applicable entry, or nil when none is
--- @return table refused Indices that refused, newest first
function KCH.SelectRevertIndex(stack, isValid)
    local refused = {}
    if type(stack) ~= "table" or type(isValid) ~= "function" then
        return nil, refused
    end
    for index = #stack, 1, -1 do
        if isValid(stack[index]) then
            return index, refused
        end
        refused[#refused + 1] = index
    end
    return nil, refused
end

-- ===========================================================================
-- Fix plans
-- ===========================================================================
--
-- PURE DATA AND PURE FUNCTIONS, every one of them. Nothing in this section calls
-- a WoW global, looks up a locale string or touches a frame. That is not style:
-- it is what lets the resolution logic -- the part of this feature that WRITES to
-- the client's binding registry -- be covered by a headless test at all. The
-- panel supplies the observed world and performs the writes; everything about
-- WHAT to write and WHETHER it is still safe to write it lives here.
--
-- THE SHAPE OF THE DANGER. A plan is captured when the panel renders and executed
-- when the user clicks, and in between the user can rebind the key from the
-- client's own Key Bindings panel, another addon can claim it, or a whole fight
-- can pass with the fix sitting in the out-of-combat queue. So a plan is never
-- executed on trust: it carries what it SAW, and the predicates below re-check
-- that against what is there now.

--- The two kinds of fix that exist. There is deliberately no third for the
--- override layer.
KCH.FIX_KINDS = { base = "base", modifier = "modifier" }

--- Why a plan or a revert was refused. Machine tokens in the same style as
--- KC.NOTE_REASONS, mapped to copy through KCH.COPY_KEYS.planReject.
KCH.PLAN_REJECT = {
    baseChanged = "base_changed",
    modifierChanged = "modifier_changed",
    keyNowFree = "key_now_free",
}

-- A separator that cannot occur inside a canonical key. Canonical keys are
-- upper-case letters, digits and the hyphen that joins modifier prefixes, so the
-- pipe is unambiguous.
local IDENTITY_SEP = "|"

--- A stable identity for one row, or nil for a row that cannot be identified.
---
--- This is the panel's fix-status key, and it has to survive a Rebuild: a status
--- keyed by table reference would be lost the moment the report is rebuilt, which
--- is exactly what happens immediately after a fix lands.
---
--- KNOWN AND HARMLESS COLLISION: two attribution rows for the same key produce
--- the same identity, because an attribution row carries no layerId to separate
--- them. It costs nothing -- an attribution row is never fixable and never
--- carries a status -- and the alternative is threading a row index through
--- BuildReport for the benefit of rows that will never use it.
--- @param row table A row produced by KCH.BuildReport
--- @return string|nil
function KCH.RowIdentity(row)
    if type(row) ~= "table" then
        return nil
    end
    local kind = row.kind
    if type(kind) ~= "string" or kind == "" then
        return nil
    end
    local key = row.key or row.rawKey
    if type(key) ~= "string" or key == "" then
        return nil
    end
    return kind .. IDENTITY_SEP .. key .. IDENTITY_SEP .. (row.layerId or "")
end

--- Build the fix plan for one row, or nil when the row is not fixable. PURE: it
--- reads the row and calls nothing.
---
--- BASE. Clearing the native binding off the key. plan.previous is the command
--- string the base layer read off GetBindingAction, and it is what a revert
--- restores, so a base row with no action is NOT fixable -- a plan with a nil
--- previous is a fix that cannot be undone.
---
--- MODIFIER. Setting every cast-redirect action on this key back to NONE, and
--- BOTH halves of that sentence are load bearing.
---
---   EVERY REDIRECT, NOT JUST SELFCAST. The research record names
---   SetModifiedClick("SELFCAST", "NONE") because SELFCAST was what the probe
---   character happened to have. KC.CheckKey flags this layer when ANY of
---   SELFCAST, FOCUSCAST or MOUSEOVERCAST is held by the key's modifier set, and
---   more than one can hit the same key. Fixing only SELFCAST would report
---   success and leave the sequence still redirecting.
---
---   ONLY REDIRECTS. row.entries also carries the non-redirect actions that
---   merely share the modifier -- CHATLINK and DRESSUP on SHIFT are the measured
---   ones. Those do not consume a keypress; they are ordinary user configuration
---   that has nothing to do with this conflict. Clearing one would destroy a
---   setting the user never asked us to touch. castRedirect == true is the whole
---   filter.
---
--- EVERYTHING ELSE IS nil, the override layer included. There is no supported way
--- to clear another addon's override binding.
--- @param row table A row produced by KCH.BuildReport
--- @return table|nil plan
function KCH.BuildFixPlan(row)
    if type(row) ~= "table" or row.kind ~= "layer" or row.status ~= KC.STATUS.conflict then
        return nil
    end
    if row.layerId == KC.LAYER_IDS.base then
        if type(row.action) ~= "string" or row.action == "" then
            return nil
        end
        return { kind = KCH.FIX_KINDS.base, key = row.key, previous = row.action }
    elseif row.layerId == KC.LAYER_IDS.modifier then
        if type(row.entries) ~= "table" then
            return nil
        end
        local actions = {}
        for _, entry in ipairs(row.entries) do
            if entry.castRedirect == true and type(entry.action) == "string" and entry.action ~= "" then
                actions[#actions + 1] = { action = entry.action, previous = entry.modifier }
            end
        end
        if #actions == 0 then
            return nil
        end
        return { kind = KCH.FIX_KINDS.modifier, key = row.key, actions = actions }
    end
    return nil
end

--- Does the world still look the way the plan captured it? PURE.
---
--- observed is supplied by the caller and shaped
---     { baseAction = <string or nil>, modifierValues = { ACTIONNAME = <string>, ... } }
---
--- A nil observed, a missing field or a raised read all count as a MISMATCH. That
--- direction is deliberate: refusing a fix that would have been fine costs the
--- user one click, while applying a fix against a world nobody actually looked at
--- clears a binding they never saw the panel offer to clear.
--- @param plan table A plan from KCH.BuildFixPlan
--- @param observed table|nil The live reading the caller took
--- @return boolean ok, string|nil rejectToken
function KCH.PlanMatchesObservedState(plan, observed)
    if type(plan) ~= "table" then
        return false, KCH.PLAN_REJECT.baseChanged
    end
    if plan.kind == KCH.FIX_KINDS.base then
        if type(observed) ~= "table" or observed.baseAction ~= plan.previous then
            return false, KCH.PLAN_REJECT.baseChanged
        end
        return true
    elseif plan.kind == KCH.FIX_KINDS.modifier then
        if type(observed) ~= "table" or type(observed.modifierValues) ~= "table" then
            return false, KCH.PLAN_REJECT.modifierChanged
        end
        for _, entry in ipairs(plan.actions or {}) do
            if observed.modifierValues[entry.action] ~= entry.previous then
                return false, KCH.PLAN_REJECT.modifierChanged
            end
        end
        return true
    end
    -- An unrecognised plan kind can only come from a caller bug, and the safe
    -- answer to "may I write?" when the question is malformed is no.
    return false, KCH.PLAN_REJECT.baseChanged
end

--- The inverse of a plan. PURE.
--- @param plan table A plan from KCH.BuildFixPlan
--- @return table|nil revert
function KCH.BuildRevertPlan(plan)
    if type(plan) ~= "table" then
        return nil
    end
    if plan.kind == KCH.FIX_KINDS.base then
        return { kind = KCH.FIX_KINDS.base, key = plan.key, restore = plan.previous }
    elseif plan.kind == KCH.FIX_KINDS.modifier then
        local actions = {}
        for _, entry in ipairs(plan.actions or {}) do
            actions[#actions + 1] = { action = entry.action, restore = entry.previous }
        end
        return { kind = KCH.FIX_KINDS.modifier, key = plan.key, actions = actions }
    end
    return nil
end

--- Is it still safe to undo? PURE, and STRICTER than the forward direction.
---
--- A base revert re-binds a command onto a key, so it is only valid while NOTHING
--- holds that key. If the user or another addon claimed it after the fix landed,
--- restoring would silently overwrite their binding -- an undo that destroys
--- something the user did AFTER the thing being undone is worse than no undo.
--- A modifier revert is only valid while every listed action still reads NONE,
--- for the same reason.
--- @param revert table A revert from KCH.BuildRevertPlan
--- @param observed table|nil The live reading the caller took
--- @return boolean ok, string|nil rejectToken
function KCH.RevertMatchesObservedState(revert, observed)
    if type(revert) ~= "table" then
        return false, KCH.PLAN_REJECT.keyNowFree
    end
    if revert.kind == KCH.FIX_KINDS.base then
        if type(observed) ~= "table" then
            return false, KCH.PLAN_REJECT.keyNowFree
        end
        local action = observed.baseAction
        if action == nil or action == "" then
            return true
        end
        return false, KCH.PLAN_REJECT.keyNowFree
    elseif revert.kind == KCH.FIX_KINDS.modifier then
        if type(observed) ~= "table" or type(observed.modifierValues) ~= "table" then
            return false, KCH.PLAN_REJECT.modifierChanged
        end
        for _, entry in ipairs(revert.actions or {}) do
            if observed.modifierValues[entry.action] ~= "NONE" then
                return false, KCH.PLAN_REJECT.modifierChanged
            end
        end
        return true
    end
    return false, KCH.PLAN_REJECT.keyNowFree
end

-- ===========================================================================
-- Report construction
-- ===========================================================================

-- Section order, so the panel is stable between rebuilds regardless of which
-- families happen to have entries this time.
local FAMILY_ORDER = { "sequence", "vehicle", "petbattle", "probe" }

--- Resolve the action EMS expects to own this entry's key.
---
--- Only the sequence family has one: KC.ExpectedActionForSequence reaches
--- Engine:SanitizeName through D.BUTTON_PREFIX, which is the same pair that named
--- the secure button in the first place, and reimplementing it here would let the
--- two drift.
---
--- Every other family passes nil, which switches KC.CheckKey into the
--- is-this-key-free query: with no expected owner the question stops being "does
--- EMS hold this key" and becomes "does anything". For the probe family that is
--- exactly what the user asked. For vehicle and pet-battle keys it is the honest
--- answer available: those are bound through the secure-handler path, which
--- attribution cannot see and for which no expected action string exists, so the
--- panel reports WHO CURRENTLY HOLDS the key rather than judging whether the
--- right module holds it.
local function expectedActionFor(entry, deps)
    if entry.family ~= "sequence" then
        return nil
    end
    if type(entry.seqName) ~= "string" or entry.seqName == "" then
        return nil
    end
    return KC.ExpectedActionForSequence(entry.seqName, deps)
end

--- Append a row and fold its severity into the tally. Every row goes through
--- here so the counts can never describe a different set of rows than the panel
--- renders.
local function addRow(report, section, row)
    report.rows[#report.rows + 1] = row
    section.rows[#section.rows + 1] = row
    if row.severity ~= nil and report.counts[row.severity] ~= nil then
        report.counts[row.severity] = report.counts[row.severity] + 1
    end
    return row
end

--- Find or create the section for a family, preserving FAMILY_ORDER.
local function sectionFor(report, byFamily, family)
    local existing = byFamily[family]
    if existing then
        return existing
    end
    local section = {
        family = family,
        copyKey = KCH.CopyKeyFor("section", family),
        rows = {},
    }
    byFamily[family] = section
    report.sections[#report.sections + 1] = section
    return section
end

--- Turn a list of keys to check into everything the panel renders.
---
--- entries is an array of
---     { family = "sequence" | "vehicle" | "petbattle" | "probe",
---       label = <display text the caller already has>,
---       key = <raw key string>,
---       seqName = <sequence name, sequence family only> }
---
--- NO SEVERITY IS COMPUTED HERE. Every severity on every row is either read off
--- the layer's own severity field, which KC.CheckKey already graded, or taken
--- from KC.SEVERITY. Grading in two places is how two panels end up disagreeing
--- about the same finding.
--- @param entries table Array of entries as above
--- @param deps table|nil Injected dependency overrides, threaded straight through
--- @return table report
function KCH.BuildReport(entries, deps)
    local report = {
        sections = {},
        rows = {},
        counts = { critical = 0, error = 0, warning = 0, info = 0 },
        limits = {},
        addons = nil,
        capabilities = nil,
    }
    if type(entries) ~= "table" then
        return report
    end

    -- THE LIMITS AND THE CAPABILITIES ARE PROPERTIES OF THE STATE, NOT OF A KEY,
    -- so they are collected ONCE, HERE, before anything iterates over entries.
    --
    -- They used to be harvested inside the per-entry loop, off each CheckKey
    -- result. That is wrong in the case that matters most: with nothing bound --
    -- the ordinary first-open state -- the loop never runs, so the four STRUCTURAL
    -- limits never got collected, and the panel rendered a header promising to
    -- name what it cannot see followed by nothing but an addon count. That reads
    -- as "the check saw everything else", which is the exact completeness this
    -- feature is not allowed to imply.
    --
    -- Measured before the fix: no entries -> 0 limits; one invalid key -> 0; one
    -- valid key -> 4; KC.GetAttributionState called directly -> 4.
    --
    -- The token list is READ OFF THE STATE and never re-derived. Which tokens are
    -- structural and which are conditional is decided in KC.GetAttributionState;
    -- a second copy of that decision here is how the two drift apart. There is
    -- deliberately no per-entry fallback either -- two sources for one field is
    -- the same failure with extra steps.
    local attributionState = KC.GetAttributionState(deps)
    if type(attributionState) == "table" and type(attributionState.limits) == "table" then
        for _, token in ipairs(attributionState.limits) do
            report.limits[#report.limits + 1] = {
                token = token,
                copyKey = KCH.CopyKeyFor("limit", token),
            }
        end
    end
    report.capabilities = KC.ProbeCapabilities(deps)

    local byFamily = {}
    -- Pre-create sections in the fixed order for every family that has an entry,
    -- so the panel does not reorder itself when a family happens to be empty.
    for _, family in ipairs(FAMILY_ORDER) do
        for _, entry in ipairs(entries) do
            if entry.family == family then
                sectionFor(report, byFamily, family)
                break
            end
        end
    end

    for _, entry in ipairs(entries) do
        local family = entry.family or "probe"
        local section = sectionFor(report, byFamily, family)
        local expectedAction = expectedActionFor(entry, deps)
        local result = KC.CheckKey(entry.key, expectedAction, deps)

        if result == nil then
            -- An unusable key string. Reachable from the probe box, where the user
            -- types freely, and it must produce a visible row rather than nothing:
            -- silence would read as "that key is fine".
            addRow(report, section, {
                kind = "invalid",
                family = family,
                label = entry.label,
                rawKey = entry.key,
                severity = KC.SEVERITY.warning,
                copyKey = "GEMS_KC_ROW_INVALID_KEY",
            })
        else
            local effective = nil
            for _, layer in ipairs(result.layers) do
                if layer.id == KC.LAYER_IDS.effective then
                    effective = layer
                end
            end

            -- The verdict row. Its severity is the EFFECTIVE layer's own grade,
            -- because the effective layer is the only one that decides the verdict
            -- and its grade is therefore already the verdict's grade.
            addRow(report, section, {
                kind = "verdict",
                family = family,
                label = entry.label,
                key = result.key,
                rawKey = entry.key,
                status = result.verdict,
                severity = (effective and effective.severity) or KC.SEVERITY.info,
                copyKey = KCH.CopyKeyFor("status", result.verdict),
                expectedAction = expectedAction,
            })

            -- One row per layer, including the clear ones. A layer that found
            -- nothing is evidence too, and hiding it makes the panel look like it
            -- only checked the layers that complained.
            for _, layer in ipairs(result.layers) do
                addRow(report, section, {
                    kind = "layer",
                    family = family,
                    label = entry.label,
                    key = result.key,
                    layerId = layer.id,
                    status = layer.status,
                    severity = layer.severity,
                    copyKey = KCH.CopyKeyFor("layer", layer.id),
                    statusCopyKey = KCH.CopyKeyFor("status", layer.status),
                    action = layer.action,
                    applicable = layer.applicable,
                    capabilityMissing = layer.capabilityMissing,
                    entries = layer.entries,
                })
            end

            -- Context notes: the layers that found something real and did not drive
            -- the verdict.
            for _, note in ipairs(result.notes) do
                addRow(report, section, {
                    kind = "note",
                    family = family,
                    label = entry.label,
                    key = result.key,
                    layerId = note.id,
                    reason = note.reason,
                    severity = note.severity,
                    copyKey = KCH.CopyKeyFor("noteReason", note.reason),
                })
            end

            -- Attribution, newest first, exactly as KC.GetAttribution ordered it.
            -- Graded info without exception: a record proves who CALLED, never who
            -- WON, so it can never be the loudest thing on a key.
            if type(result.attribution) == "table" then
                for _, record in ipairs(result.attribution) do
                    addRow(report, section, {
                        kind = "attribution",
                        family = family,
                        label = entry.label,
                        key = result.key,
                        severity = KC.SEVERITY.info,
                        copyKey = KCH.CopyKeyFor("layer", record.layer),
                        addon = record.addon,
                        file = record.file,
                        line = record.line,
                        func = record.func,
                        fn = record.fn,
                        target = record.target,
                        isPriority = record.isPriority,
                        cleared = record.cleared,
                        count = record.count,
                        reacquired = record.reacquired,
                    })
                end
            end
        end
    end

    -- Installed-but-not-loaded addons. nil from KC.ListUnloadedAddons means the
    -- enumeration API was unavailable, which is NOT the same as "none", so the
    -- field stays nil and the panel omits the line rather than claiming zero.
    local unloaded = KC.ListUnloadedAddons(deps)
    if unloaded ~= nil then
        report.addons = { unloadedCount = #unloaded }
    end

    return report
end
