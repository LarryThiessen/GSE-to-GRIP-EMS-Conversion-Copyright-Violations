-- GRIP-EMS: RawImport
-- Created: 2026-04-03
-- Updated: 2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.

-- GRIP-EMS: Raw Macrotext Import
-- Detects when pasted text is raw macro lines (not encoded) and parses
-- them into a sequence. Supports /cast, /use, /castsequence, and other
-- common macro commands pasted from Wowhead, Discord, or forum posts.

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

GRIPEMS.RawImport = {}
local RI = GRIPEMS.RawImport

---------------------------------------------------------------------------
-- Known macro commands (lowercase, without leading /)
---------------------------------------------------------------------------
local CASTABLE_COMMANDS = {
    ["cast"] = true,
    ["use"] = true,
    ["castsequence"] = true,
    ["stopmacro"] = true,
    ["cancelaura"] = true,
    ["cancelform"] = true,
    ["startattack"] = true,
    ["petattack"] = true,
    ["click"] = true,
    ["stopcasting"] = true,
    ["equipslot"] = true,
    ["equip"] = true,
    ["usetoy"] = true,
}

-- Commands whose lines become keyPress candidates rather than steps
local KEYPRESS_COMMANDS = {
    ["stopmacro"] = true,
    ["cancelaura"] = true,
    ["cancelform"] = true,
    ["startattack"] = true,
    ["petattack"] = true,
    ["stopcasting"] = true,
}

---------------------------------------------------------------------------
-- Utility: strip conditionals from a macro argument
-- Removes [bracketed conditionals] and leading/trailing whitespace.
---------------------------------------------------------------------------
local function StripConditionals(text)
    -- Remove all [bracketed] sections
    local result = text:gsub("%b[]", "")
    return result:match("^%s*(.-)%s*$") or ""
end

---------------------------------------------------------------------------
-- Utility: parse a /cast or /use line into spell step(s)
-- Handles semicolons (fallback lists), conditionals, and ! toggle prefix.
---------------------------------------------------------------------------
local function ParseCastLine(argText)
    local steps = {}
    -- Split by semicolons (each is a separate spell/conditional group)
    for part in argText:gmatch("[^;]+") do
        local stripped = StripConditionals(part)
        if stripped ~= "" then
            -- Trim whitespace
            stripped = stripped:match("^%s*(.-)%s*$") or stripped
            if stripped ~= "" then
                steps[#steps + 1] = "/cast " .. stripped
            end
        end
    end
    return steps
end

---------------------------------------------------------------------------
-- Utility: parse a /castsequence line into individual spell steps
-- Strips reset= clause and splits by comma.
---------------------------------------------------------------------------
local function ParseCastSequenceLine(argText)
    local steps = {}
    -- Strip reset= clause
    local cleaned = argText:gsub("reset=%S+%s*", "")
    -- Strip conditionals
    cleaned = StripConditionals(cleaned)
    -- Split by comma
    for spell in cleaned:gmatch("[^,]+") do
        spell = spell:match("^%s*(.-)%s*$") or spell
        if spell ~= "" then
            steps[#steps + 1] = "/cast " .. spell
        end
    end
    return steps
end

---------------------------------------------------------------------------
-- IsRawMacro: detect whether pasted text looks like raw macro lines
---------------------------------------------------------------------------

--- Determine if the given text looks like raw macro lines.
--- @param text string The pasted text
--- @return boolean true if text appears to be raw macro lines
function RI:IsRawMacro(text)
    if not text or text == "" then
        return false
    end

    -- Encoded strings start with "!" prefix
    if text:sub(1, 1) == "!" then
        return false
    end

    -- Base64-like strings: mostly alphanumeric with no meaningful newlines
    local stripped = text:gsub("%s+", "")
    local alphaRatio = #stripped > 0 and select(2, stripped:gsub("[%w%+/=]", "")) / #stripped or 0
    if #stripped > 20 and alphaRatio > 0.9 then
        return false
    end

    -- Count lines starting with known macro commands
    local macroLineCount = 0
    local totalLines = 0
    for line in text:gmatch("[^\r\n]+") do
        local trimmed = line:match("^%s*(.-)%s*$") or ""
        if trimmed ~= "" then
            totalLines = totalLines + 1
            local cmd = trimmed:match("^/(%w+)")
            if cmd and CASTABLE_COMMANDS[cmd:lower()] then
                macroLineCount = macroLineCount + 1
            end
        end
    end

    return macroLineCount >= 2
end

---------------------------------------------------------------------------
-- Parse: convert raw macro text into import-compatible previewData
---------------------------------------------------------------------------

--- Parse raw macro lines into a previewData table compatible with LI.Preview().
--- @param text string Raw macro text
--- @return table|nil previewData in standard import preview format, or nil on failure
function RI:Parse(text)
    if not text or text == "" then
        return nil
    end

    local D = GRIPEMS.Defaults

    local steps = {}
    local keyPressLines = {}
    local tooltipSpell = nil

    -- Count lines for debug message
    local lineCount = 0
    for _ in text:gmatch("[^\r\n]+") do
        lineCount = lineCount + 1
    end
    GRIPEMS:Debug(string.format(L["GEMS_RAWIMPORT_DETECTED"], lineCount))

    for line in text:gmatch("[^\r\n]+") do
        local trimmed = line:match("^%s*(.-)%s*$") or ""
        if trimmed:match("^#showtooltip") then
            -- Extract tooltip spell name for sequence naming
            local spellName = trimmed:match("^#showtooltip%s+(.+)")
            if spellName then
                tooltipSpell = spellName:match("^%s*(.-)%s*$")
            end
        elseif trimmed ~= "" then
            local cmd = trimmed:match("^/(%w+)")
            if cmd then
                local cmdLower = cmd:lower()
                local argText = trimmed:match("^/%w+%s*(.*)") or ""

                if cmdLower == "cast" or cmdLower == "use" then
                    local castSteps = ParseCastLine(argText)
                    for _, s in ipairs(castSteps) do
                        steps[#steps + 1] = s
                    end
                elseif cmdLower == "castsequence" then
                    local seqSteps = ParseCastSequenceLine(argText)
                    for _, s in ipairs(seqSteps) do
                        steps[#steps + 1] = s
                    end
                elseif KEYPRESS_COMMANDS[cmdLower] then
                    keyPressLines[#keyPressLines + 1] = trimmed
                elseif
                    cmdLower == "equip"
                    or cmdLower == "equipslot"
                    or cmdLower == "usetoy"
                    or cmdLower == "click"
                then
                    steps[#steps + 1] = trimmed
                elseif CASTABLE_COMMANDS[cmdLower] then
                    -- Other recognized commands become steps
                    steps[#steps + 1] = trimmed
                else
                    -- Unrecognized /command: include as raw step
                    steps[#steps + 1] = trimmed
                end
            else
                -- Non-command line: include as raw step text
                steps[#steps + 1] = trimmed
            end
        end
    end

    if #steps == 0 then
        GRIPEMS:Print(L["GEMS_RAWIMPORT_NO_SPELLS"])
        return nil
    end

    GRIPEMS:Debug(string.format(L["GEMS_RAWIMPORT_RESULT"], #steps))

    -- Build keyPress text from accumulated lines
    local keyPressText = ""
    if #keyPressLines > 0 then
        keyPressText = table.concat(keyPressLines, "\n")
    end

    -- Determine sequence name
    local seqName = L["GEMS_RAWIMPORT_NAME"]
    if tooltipSpell and tooltipSpell ~= "" then
        seqName = tooltipSpell
    end

    -- Build previewData in the same format as LI.Preview() returns
    local previewData = {
        ok = true,
        format = "RAW",
        totalSequences = 1,
        totalVariables = 0,
        newSequences = 1,
        existingSequences = 0,
        sequences = {
            {
                name = seqName,
                icon = D.QUESTION_MARK_ICON,
                status = "new",
                conflictAction = "import",
                versionCount = 1,
                stepCount = #steps,
                spellWarnCount = 0,
                seqObj = nil,
                compiledVersions = {
                    {
                        steps = steps,
                        stepFunction = "Sequential",
                        keyPress = keyPressText,
                        keyRelease = "",
                    },
                },
            },
        },
        variables = {},
    }

    return previewData
end
