-- GRIP-EMS: Spell Cache
-- Runtime spell name cache built from C_SpellBook API for autocomplete and validation

local ADDON_NAME, GRIPEMS = ...
-- Upvalue accessor for Defaults
local function D() return GRIPEMS.Defaults end

GRIPEMS.SpellCache = {}
local SC = GRIPEMS.SpellCache

-- Cache structure (runtime only, never saved to SavedVariables)
SC.spells = {}   -- sorted array of { name, spellID, iconID [, isPet] }
SC.byName = {}   -- lowercase name -> entry lookup
SC.ready = false -- true after first successful scan

-- Debounce timer handle (cancelled/replaced on re-trigger)
local debounceTimer = nil

---------------------------------------------------------------------------
-- Scan
---------------------------------------------------------------------------

--- Scan the player's spellbook and build the sorted spell cache.
--- Clears and rebuilds spells array and byName lookup from scratch.
function SC:Scan()
    wipe(self.spells)
    wipe(self.byName)

    -- Guard: some spellbook entries return actionID values outside the
    -- signed 32-bit range that FindSpellOverrideByID rejects.
    local function SafeOverrideID(actionID)
        if not actionID or actionID > 2147483647 or actionID < 0 then
            return actionID
        end
        return FindSpellOverrideByID(actionID) or actionID
    end

    local numSkillLines = C_SpellBook.GetNumSpellBookSkillLines()
    if not numSkillLines then
        self.ready = true
        GRIPEMS:Debug("SpellCache: no skill lines available")
        return
    end

    -- Scan player spellbook tabs
    for i = 1, numSkillLines do
        local info = C_SpellBook.GetSpellBookSkillLineInfo(i)
        if info then
            -- Skip hidden, guild, and off-spec tabs
            if not info.shouldHide and not info.isGuild and not info.offSpecID then
                local offset = info.itemIndexOffset or 0
                local count = info.numSpellBookItems or 0

                for slot = offset + 1, offset + count do
                    local itemInfo = C_SpellBook.GetSpellBookItemInfo(slot, Enum.SpellBookSpellBank.Player)
                    if itemInfo then
                        -- Skip passives, off-spec, and non-castable types
                        if not itemInfo.isPassive
                            and not itemInfo.isOffSpec
                            and (itemInfo.itemType == Enum.SpellBookItemType.Spell
                                or itemInfo.itemType == Enum.SpellBookItemType.Flyout)
                        then
                            -- actionID is the BASE slot ID, but name is the OVERRIDE name.
                            -- Resolve to the override spell ID so name<->ID stay consistent.
                            -- e.g. BM Hunter: actionID=56641 (Steady Shot base), but name="Barbed Shot"
                            -- FindSpellOverrideByID(56641) -> 217200 (Barbed Shot) -> matches name.
                            local entry = {
                                name = itemInfo.name,
                                spellID = SafeOverrideID(itemInfo.actionID),
                                iconID = itemInfo.iconID,
                            }
                            table.insert(self.spells, entry)
                        end
                    end
                end
            end
        end
    end

    -- Scan pet spells if applicable (Hunter, Warlock, etc.)
    local numPetSpells = C_SpellBook.HasPetSpells()
    if numPetSpells then
        for i = 1, numPetSpells do
            local petInfo = C_SpellBook.GetSpellBookItemInfo(i, Enum.SpellBookSpellBank.Pet)
            if petInfo and not petInfo.isPassive then
                local entry = {
                    name = petInfo.name .. " (Pet)",
                    spellID = SafeOverrideID(petInfo.actionID),
                    iconID = petInfo.iconID,
                    isPet = true,
                }
                table.insert(self.spells, entry)
            end
        end
    end

    -- Sort alphabetically by name (case-insensitive)
    table.sort(self.spells, function(a, b)
        return strlower(a.name) < strlower(b.name)
    end)

    -- Build byName lookup
    for _, entry in ipairs(self.spells) do
        self.byName[strlower(entry.name)] = entry
    end

    self.ready = true
    GRIPEMS:Debug(string.format("SpellCache: scanned %d spells", #self.spells))
end

---------------------------------------------------------------------------
-- Prefix Search
---------------------------------------------------------------------------

--- Search for spells whose name starts with the given prefix.
--- Returns up to maxResults matches from the sorted cache.
--- @param prefix string The prefix to match against spell names
--- @param maxResults number|nil Maximum results to return (default from Defaults)
--- @return table Array of matching { name, spellID, iconID } entries
function SC:PrefixSearch(prefix, maxResults)
    if not prefix then return {} end
    prefix = strlower(prefix)
    maxResults = maxResults or D().AUTOCOMPLETE_MAX_RESULTS

    -- Caller enforces min-chars threshold (see handleTabAutocomplete)

    local results = {}
    local prefixLen = #prefix
    for _, entry in ipairs(self.spells) do
        if strlower(entry.name):sub(1, prefixLen) == prefix then
            table.insert(results, entry)
            if #results >= maxResults then
                break
            end
        end
    end

    return results
end

---------------------------------------------------------------------------
-- Icon Lookup
---------------------------------------------------------------------------

--- Get the icon ID for a spell by name.
--- Checks the cache first (fast), falls back to C_Spell.GetSpellTexture.
--- @param spellName string The spell name to look up
--- @return number|nil iconID The file ID of the spell icon, or nil
function SC:GetIcon(spellName)
    if not spellName then return nil end

    local entry = self.byName[strlower(spellName)]
    if entry then
        return entry.iconID
    end

    -- Fallback: try the API directly (handles spells not in spellbook)
    local iconID = C_Spell.GetSpellTexture(spellName)
    return iconID
end

---------------------------------------------------------------------------
-- Spell ID Lookup
---------------------------------------------------------------------------

--- Get the spell ID for a spell by name.
--- Checks cache first (fast), falls back to C_Spell.GetSpellInfo.
--- @param spellName string The spell name to look up
--- @return number|nil spellID The spell ID, or nil if not found
function SC:GetSpellID(spellName)
    if not spellName then return nil end

    local entry = self.byName[strlower(spellName)]
    if entry then
        return entry.spellID
    end

    -- Fallback: WoW API (handles spells not in spellbook)
    local info = C_Spell.GetSpellInfo(spellName)
    return info and info.spellID or nil
end

--- Normalize a spell ID to its base (talent-portable) form.
--- Strips talent overrides so stored ID works across talent changes.
--- @param spellID number The spell ID to normalize
--- @return number|nil baseID The base spell ID, or nil if input is nil
function SC:GetBaseSpellID(spellID)
    if not spellID then return nil end
    local baseID = C_SpellBook.FindBaseSpellByID(spellID)
    return baseID or spellID
end

---------------------------------------------------------------------------
-- Macro Text Translation (locale-safe export/import)
---------------------------------------------------------------------------

-- Commands whose spell arguments need locale translation
local TRANSLATABLE_COMMANDS = {
    ["/cast"] = true,
    ["/use"] = true,
    ["/castsequence"] = true,
    ["/castrandom"] = true,
    ["/userandom"] = true,
    ["/cancelaura"] = true,
}

--- Consume all leading [conditional] blocks from a string.
--- Returns the conditionals prefix and the remaining text.
--- @param text string Text that may start with [cond] blocks
--- @return string condPrefix All consumed [cond] blocks with trailing space
--- @return string rest Remaining text after conditionals
local function ConsumeConditionals(text)
    local condParts = {}
    local pos = 1
    local len = #text

    while pos <= len do
        -- Skip whitespace
        while pos <= len and text:sub(pos, pos) == " " do
            pos = pos + 1
        end
        -- Check for opening bracket
        if pos <= len and text:sub(pos, pos) == "[" then
            -- Find the balanced close bracket
            local close = text:find("%]", pos + 1)
            if close then
                condParts[#condParts + 1] = text:sub(pos, close)
                pos = close + 1
            else
                break -- unbalanced bracket, stop
            end
        else
            break
        end
    end

    if #condParts == 0 then
        return "", text
    end

    local condPrefix = table.concat(condParts, " ")
    local rest = text:sub(pos)
    -- Preserve any space between last conditional and spell list
    if rest:sub(1, 1) == " " then
        condPrefix = condPrefix .. " "
        rest = rest:sub(2)
    else
        condPrefix = condPrefix .. " "
    end

    return condPrefix, rest
end

--- Translate a single spell reference between name and ID tag.
--- @param ref string A spell name or {spell:ID} tag
--- @param direction string "toIDs" or "toNames"
--- @return string translated The translated reference
local function TranslateSpellRef(ref, direction)
    -- Trim whitespace
    local trimmed = ref:match("^%s*(.-)%s*$")
    if not trimmed or trimmed == "" then return ref end

    if direction == "toIDs" then
        -- Already a tag? keep as-is
        if trimmed:match("^{spell:%d+}$") then
            return ref
        end
        -- Already numeric? keep as-is
        if tonumber(trimmed) then return ref end
        -- Check for ! prefix (e.g. !Steady Shot)
        local bangPrefix = ""
        local lookupName = trimmed
        if trimmed:sub(1, 1) == "!" then
            bangPrefix = "!"
            lookupName = trimmed:sub(2)
        end
        -- Check for (Rank N) suffix
        local rankSuffix = ""
        local baseName = lookupName
        local nameNoRank, rank = lookupName:match("^(.-)(%s*%(Rank%s+%d+%))$")
        if nameNoRank then
            baseName = nameNoRank
            rankSuffix = rank
        end
        -- Look up spell ID
        local spellID = SC:GetSpellID(baseName)
        if spellID then
            -- NOTE: Do NOT normalize to base spell ID here. FindBaseSpellByID
            -- walks the full replacement chain (e.g. Barbed Shot -> Steady Shot)
            -- which loses the actual spell identity. WoW /cast handles talent
            -- overrides natively, so the spell's own ID is correct for export.
            -- Preserve leading whitespace from original ref
            local leading = ref:match("^(%s*)")
            return leading .. bangPrefix .. "{spell:" .. spellID .. "}" .. rankSuffix
        end
        -- Lookup failed (item, unknown) -- keep original
        return ref

    elseif direction == "toNames" then
        -- Match {spell:ID} tag
        local id = trimmed:match("^{spell:(%d+)}$")
        if not id then
            -- Check with ! prefix
            local bangID = trimmed:match("^!{spell:(%d+)}$")
            if bangID then
                local name = C_Spell.GetSpellName(tonumber(bangID))
                if name then
                    local leading = ref:match("^(%s*)")
                    return leading .. "!" .. name
                end
            end
            return ref -- not a tag, pass through
        end
        local name = C_Spell.GetSpellName(tonumber(id))
        if name then
            local leading = ref:match("^(%s*)")
            return leading .. name
        end
        -- GetSpellName returned nil, keep tag as-is
        return ref
    end

    return ref
end

--- Translate macrotext between localized names and spell ID tags.
--- Used at export/import boundaries for locale-safe sharing.
--- @param macrotext string The macro text to translate
--- @param direction string "toIDs" (export) or "toNames" (import)
--- @return string translated The translated macrotext
function SC:TranslateMacrotext(macrotext, direction)
    if not macrotext or macrotext == "" then return macrotext end

    local lines = {}
    for line in (macrotext .. "\n"):gmatch("([^\n]*)\n") do
        lines[#lines + 1] = line
    end

    for i, line in ipairs(lines) do
        -- Match command: leading whitespace + /command + space + rest
        local prefix, cmd, sep, rest = line:match("^(%s*)(/%a+)(%s+)(.*)")
        if cmd and TRANSLATABLE_COMMANDS[cmd:lower()] then
            -- Consume [conditional] blocks from rest
            local condPrefix, spellPart = ConsumeConditionals(rest)

            -- For /castsequence: consume reset=... clause
            local resetClause = ""
            if cmd:lower() == "/castsequence" then
                local reset, afterReset = spellPart:match("^(reset=%S+%s*)(.*)")
                if reset then
                    resetClause = reset
                    spellPart = afterReset
                end
            end

            -- Determine delimiter: /castsequence uses comma, others use semicolon
            local delimiter
            if cmd:lower() == "/castsequence" then
                delimiter = ","
            else
                delimiter = ";"
            end

            -- Split spell references by delimiter
            local refs = {}
            local pos = 1
            local spLen = #spellPart
            while pos <= spLen do
                local delimPos = spellPart:find(delimiter, pos, true)
                if delimPos then
                    refs[#refs + 1] = spellPart:sub(pos, delimPos - 1)
                    pos = delimPos + 1
                else
                    refs[#refs + 1] = spellPart:sub(pos)
                    pos = spLen + 1
                end
            end

            -- For non-castsequence commands, each semicolon-delimited ref
            -- may itself contain comma-separated spells (e.g. /castrandom A, B; C)
            -- But actually /cast and friends use semicolons for fallback casts only.
            -- /castsequence uses commas. Keep it simple: one delimiter per command type.

            -- Translate each ref
            for j, ref in ipairs(refs) do
                -- For /castsequence: each comma-delimited entry is one spell
                -- For others: each semicolon-delimited entry may have conditionals
                if cmd:lower() ~= "/castsequence" and ref:find("%[") then
                    -- This ref has its own conditionals (fallback with conditions)
                    -- Preserve leading whitespace (e.g. space after ; delimiter)
                    local leading = ref:match("^(%s*)") or ""
                    local innerCond, innerSpell = ConsumeConditionals(ref)
                    innerSpell = TranslateSpellRef(innerSpell, direction)
                    refs[j] = leading .. innerCond .. innerSpell
                else
                    refs[j] = TranslateSpellRef(ref, direction)
                end
            end

            -- Reassemble
            lines[i] = prefix .. cmd .. sep .. condPrefix .. resetClause
                .. table.concat(refs, delimiter)
        end
        -- Non-translatable lines pass through unchanged
    end

    return table.concat(lines, "\n")
end

---------------------------------------------------------------------------
-- Validation
---------------------------------------------------------------------------

--- Check if a spell name corresponds to a known valid spell.
--- Checks cache first, falls back to C_Spell.DoesSpellExist.
--- @param spellName string The spell name to validate
--- @return boolean True if the spell exists
function SC:IsValidSpell(spellName)
    if not spellName then return false end

    -- Fast path: check cache
    if self.byName[strlower(spellName)] then
        return true
    end

    -- Fallback: WoW API (handles items, macros, etc.)
    return C_Spell.DoesSpellExist(spellName)
end

---------------------------------------------------------------------------
-- Macro Command Autocomplete
---------------------------------------------------------------------------

-- WoW macro commands for autocomplete (source: warcraft.wiki.gg/Macro_commands)
-- Includes all combat, targeting, pet, character, chat, system, and
-- metacommands that users might write in macro sequences.
SC.macroCommands = {
    -- Metacommands (# prefix)
    "#show",
    "#showtooltip",
    -- Battle pets
    "/dismisspet",
    "/randomfavoritepet",
    "/randompet",
    "/summonpet",
    -- Character / movement
    "/dismount",
    "/equip",
    "/equipset",
    "/equipslot",
    "/follow",
    "/leavevehicle",
    -- Chat (commonly used in macros)
    "/emote",
    "/guild",
    "/officer",
    "/party",
    "/raid",
    "/reply",
    "/rw",
    "/say",
    "/tell",
    "/whisper",
    "/yell",
    -- Combat
    "/cancelaura",
    "/cancelform",
    "/cancelqueuedspell",
    "/cast",
    "/castrandom",
    "/castsequence",
    "/changeactionbar",
    "/click",
    "/startattack",
    "/stopattack",
    "/stopcasting",
    "/stopmacro",
    "/stopspelltarget",
    "/swapactionbar",
    "/use",
    "/userandom",
    "/usetoy",
    -- Pet
    "/petassist",
    "/petattack",
    "/petautocastoff",
    "/petautocaston",
    "/petautocasttoggle",
    "/petdefensive",
    "/petdismiss",
    "/petfollow",
    "/petmoveto",
    "/petpassive",
    "/petstay",
    -- PvP
    "/duel",
    "/forfeit",
    "/pvp",
    -- Raid / party
    "/clearworldmarker",
    "/invite",
    "/readycheck",
    "/targetmarker",
    "/worldmarker",
    -- System
    "/dump",
    "/logout",
    "/played",
    "/random",
    "/reload",
    "/run",
    "/script",
    -- Targeting
    "/assist",
    "/clearfocus",
    "/cleartarget",
    "/focus",
    "/target",
    "/targetenemy",
    "/targetenemyplayer",
    "/targetexact",
    "/targetfriend",
    "/targetfriendplayer",
    "/targetlastenemy",
    "/targetlastfriend",
    "/targetlasttarget",
    "/targetparty",
    "/targetraid",
}

--- Search macro commands by prefix.
--- Handles both "/" and "#" prefixed commands.
--- @param prefix string The prefix to match (must start with "/" or "#")
--- @param maxResults number|nil Maximum results (default from Defaults)
--- @return table Array of { name } entries matching the prefix
function SC:MacroCommandSearch(prefix, maxResults)
    if not prefix then return {} end
    local firstChar = prefix:sub(1, 1)
    if firstChar ~= "/" and firstChar ~= "#" then return {} end
    prefix = strlower(prefix)
    maxResults = maxResults or D().AUTOCOMPLETE_MAX_RESULTS

    local results = {}
    for _, cmd in ipairs(self.macroCommands) do
        if strlower(cmd):sub(1, #prefix) == prefix then
            table.insert(results, { name = cmd })
            if #results >= maxResults then break end
        end
    end
    return results
end

---------------------------------------------------------------------------
-- Macro Text Spell Extraction
---------------------------------------------------------------------------

--- Extract the first castable spell name from a macro text string.
--- Handles /cast, /use, /castrandom, /castsequence with conditionals,
--- reset= clauses, rank syntax, and multi-line text.
--- @param macrotext string The macro text to parse
--- @return string|nil spellName The first spell name found, or nil
function SC:ParseSpellFromMacrotext(macrotext)
    if not macrotext or macrotext == "" then return nil end

    -- Commands that don't cast spells -- skip these lines
    local skipPrefixes = {
        "^%s*#show", "^%s*/stopcasting", "^%s*/stopattack",
        "^%s*/stopmacro", "^%s*/cancelaura", "^%s*/cancelform",
        "^%s*/startattack", "^%s*/target", "^%s*/focus",
        "^%s*/clearfocus", "^%s*/cleartarget",
    }

    for line in macrotext:gmatch("[^\r\n]+") do
        -- Check if this line should be skipped
        local skip = false
        local lineLower = line:lower()
        for _, pat in ipairs(skipPrefixes) do
            if lineLower:match(pat) then
                skip = true
                break
            end
        end

        if not skip then
            -- Match /cast, /use, /castrandom, /castsequence (case-insensitive)
            local cmdMatch = line:match("^%s*/[Cc][Aa][Ss][Tt]%s") or
                             line:match("^%s*/[Uu][Ss][Ee]%s") or
                             line:match("^%s*/[Cc][Aa][Ss][Tt][Rr][Aa][Nn][Dd][Oo][Mm]%s") or
                             line:match("^%s*/[Cc][Aa][Ss][Tt][Ss][Ee][Qq][Uu][Ee][Nn][Cc][Ee]%s")

            if cmdMatch then
                -- Strip the command prefix
                local rest = line:match("^%s*/[%a]+%s+(.*)")
                if rest then
                    -- Strip [conditionals] blocks
                    rest = rest:gsub("%[.-%]", "")
                    -- Strip reset=... clause (for /castsequence)
                    rest = rest:gsub("reset=%S+%s*", "")
                    -- Trim leading/trailing whitespace
                    rest = rest:match("^%s*(.-)%s*$")

                    if rest and rest ~= "" then
                        -- For /castsequence: take only the first spell (before comma)
                        local spell = rest:match("^([^,;]+)")
                        if spell then
                            spell = spell:match("^%s*(.-)%s*$")
                            -- Strip "(Rank N)" suffix
                            spell = spell:gsub("%s*%(Rank%s+%d+%)%s*$", "")
                            -- Strip trailing semicolons
                            spell = spell:gsub(";+%s*$", "")
                            spell = spell:match("^%s*(.-)%s*$")
                            if spell and spell ~= "" then
                                return spell
                            end
                        end
                    end
                end
            end
        end
    end

    return nil
end

---------------------------------------------------------------------------
-- Event-Driven Refresh with Debounce
---------------------------------------------------------------------------

--- Schedule a debounced cache rescan. Cancels any pending timer.
local function ScheduleRescan()
    if debounceTimer then
        debounceTimer:Cancel()
        debounceTimer = nil
    end
    debounceTimer = C_Timer.NewTimer(D().SPELL_CACHE_DEBOUNCE, function()
        debounceTimer = nil
        SC:Scan()
    end)
end

--- Register events that trigger spell cache refresh.
--- Called once during addon initialization.
function SC:RegisterEvents()
    local eventFrame = CreateFrame("Frame")
    eventFrame:RegisterEvent("SPELLS_CHANGED")
    eventFrame:RegisterEvent("TRAIT_CONFIG_UPDATED")
    eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")

    eventFrame:SetScript("OnEvent", function(_, event)
        ScheduleRescan()
    end)

    SC.eventFrame = eventFrame
end

-- Auto-register events when file loads (Core.lua has already created GRIPEMS)
SC:RegisterEvents()
