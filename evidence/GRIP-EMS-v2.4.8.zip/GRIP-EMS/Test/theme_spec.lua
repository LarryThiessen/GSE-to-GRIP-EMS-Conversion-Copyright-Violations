-- GRIP-EMS: Test spec for per-element theming (Phase B)
--
-- Created:    2026-04-22
-- Updated:    2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.
--
-- Registers 8 tests in TestSuite under category "theme" covering the
-- taxonomy invariants (ELEMENT_CLASSES count, ELEMENT_CLASS_SET coverage,
-- DEFAULT_THEME coverage, APPLY_FN coverage), the import/export
-- round-trip, unknown-class rejection, version mismatch rejection, and
-- the Phase A empty-elements ApplyTheme invariant.

local ADDON_NAME, GRIPEMS = ...

local TS = GRIPEMS.TestSuite
if not TS then
    return
end

local EXPECTED_CLASS_COUNT = 45
local GROUPS = { "panel", "overlay", "row", "button", "text", "emphasis", "global" }

local function UI()
    return GRIPEMS.UI
end
local function Theme()
    return GRIPEMS.Theme
end

local function deepCopy(t)
    if type(t) ~= "table" then
        return t
    end
    local r = {}
    for k, v in pairs(t) do
        r[k] = deepCopy(v)
    end
    return r
end

TS:Register("Theme: ELEMENT_CLASSES count matches taxonomy", "theme", function(self)
    local u = UI()
    if not (u and u.ELEMENT_CLASSES) then
        self:Fail("UI.ELEMENT_CLASSES missing")
        return
    end
    if #u.ELEMENT_CLASSES == EXPECTED_CLASS_COUNT then
        self:Pass()
    else
        self:Fail("expected " .. EXPECTED_CLASS_COUNT .. " classes, got " .. tostring(#u.ELEMENT_CLASSES))
    end
end)

TS:Register("Theme: ELEMENT_CLASS_SET covers every ELEMENT_CLASSES entry", "theme", function(self)
    local u = UI()
    if not (u and u.ELEMENT_CLASSES and u.ELEMENT_CLASS_SET) then
        self:Fail("taxonomy tables missing")
        return
    end
    for i = 1, #u.ELEMENT_CLASSES do
        local c = u.ELEMENT_CLASSES[i]
        if not u.ELEMENT_CLASS_SET[c] then
            self:Fail("class missing from set: " .. tostring(c))
            return
        end
    end
    self:Pass()
end)

TS:Register("Theme: DEFAULT_THEME has an entry for every class", "theme", function(self)
    local u = UI()
    if not (u and u.ELEMENT_CLASSES and u.DEFAULT_THEME) then
        self:Fail("taxonomy or defaults missing")
        return
    end
    for i = 1, #u.ELEMENT_CLASSES do
        local c = u.ELEMENT_CLASSES[i]
        if type(u.DEFAULT_THEME[c]) ~= "table" then
            self:Fail("no DEFAULT_THEME entry for " .. tostring(c))
            return
        end
    end
    self:Pass()
end)

TS:Register("Theme: APPLY_FN has a function for every group", "theme", function(self)
    local u = UI()
    if not (u and u.APPLY_FN) then
        self:Fail("UI.APPLY_FN missing")
        return
    end
    for i = 1, #GROUPS do
        if type(u.APPLY_FN[GROUPS[i]]) ~= "function" then
            self:Fail("APPLY_FN missing for group " .. GROUPS[i])
            return
        end
    end
    self:Pass()
end)

TS:Register("Theme: export/import round-trip preserves overrides", "theme", function(self)
    local u = UI()
    local TE = u and u.ThemingEditor
    local S = GRIPEMS.Settings
    if not (TE and TE.ExportCurrent and TE.ImportString and S and S.db and S.db.profile) then
        self:Fail("export/import API missing")
        return
    end
    local theming = S.db.profile.theming or { preset = "default", elements = {}, savedThemes = {} }
    S.db.profile.theming = theming
    theming.elements = theming.elements or {}
    theming.savedThemes = theming.savedThemes or {}

    local savedElements = deepCopy(theming.elements)
    local savedPreset = theming.preset

    local ok, err = pcall(function()
        theming.elements = {}
        theming.elements["panel.main"] = { bg = { 0.1, 0.2, 0.3, 0.4 } }
        local exported, expErr = TE.ExportCurrent()
        if not exported then
            error("export returned nil: " .. tostring(expErr))
        end
        theming.elements = {}
        local impOk, impErr = TE.ImportString(exported)
        if not impOk then
            error("import failed: " .. tostring(impErr))
        end
        local entry = theming.elements["panel.main"]
        if type(entry) ~= "table" or type(entry.bg) ~= "table" or entry.bg[1] ~= 0.1 then
            error("round-tripped data mismatch")
        end
    end)

    theming.elements = savedElements
    theming.preset = savedPreset

    if ok then
        self:Pass()
    else
        self:Fail(tostring(err))
    end
end)

TS:Register("Theme: ValidateSpec rejects unknown class", "theme", function(self)
    local T = Theme()
    if not (T and T.ValidateSpec) then
        self:Fail("Theme.ValidateSpec missing")
        return
    end
    local ok = T.ValidateSpec({ version = 1, elements = { ["not.a.real.class"] = { bg = { 0, 0, 0, 1 } } } })
    if ok then
        self:Fail("unknown class was accepted")
    else
        self:Pass()
    end
end)

TS:Register("Theme: ValidateSpec rejects unsupported version", "theme", function(self)
    local T = Theme()
    if not (T and T.ValidateSpec) then
        self:Fail("Theme.ValidateSpec missing")
        return
    end
    local ok = T.ValidateSpec({ version = 999, elements = {} })
    if ok then
        self:Fail("unsupported version was accepted")
    else
        self:Pass()
    end
end)

TS:Register("Theme: ApplyTheme with empty elements does not error", "theme", function(self)
    local T = Theme()
    local S = GRIPEMS.Settings
    if not (T and T.ApplyTheme and S and S.db and S.db.profile) then
        self:Fail("Theme.ApplyTheme or Settings missing")
        return
    end
    local theming = S.db.profile.theming or { preset = "default", elements = {}, savedThemes = {} }
    S.db.profile.theming = theming
    local saved = theming.elements
    theming.elements = {}
    -- Suppress the live contrast toast: ApplyTheme fires Theme.CheckAndWarn per class
    -- (fire-and-forget), which would pop a real ContrastToast onto the player's screen
    -- during /gems test. Stub ShowContrastWarning for the duration of the apply.
    local u = UI()
    local TE = u and u.ThemingEditor
    local origShow = TE and TE.ShowContrastWarning
    if TE then
        TE.ShowContrastWarning = function() end
    end
    local ok, err = pcall(T.ApplyTheme)
    if TE then
        TE.ShowContrastWarning = origShow
    end
    theming.elements = saved or {}
    if ok then
        self:Pass()
    else
        self:Fail("ApplyTheme errored: " .. tostring(err))
    end
end)

TS:Register("Theme: translucent panel bg skips border contrast check", "theme", function(self)
    local T = Theme()
    local S = GRIPEMS.Settings
    if not (T and T.CheckContrast and S and S.db and S.db.profile) then
        self:Fail("theme API or settings missing")
        return
    end
    local theming = S.db.profile.theming or { preset = "default", elements = {}, savedThemes = {} }
    S.db.profile.theming = theming
    theming.elements = theming.elements or {}
    local savedElements = {}
    for k, v in pairs(theming.elements) do
        savedElements[k] = v
    end
    local run = pcall(function()
        -- Translucent bg (alpha < 1): indeterminate over the game world -> skipped.
        theming.elements["panel.main"] = { bg = { 0.086, 0.129, 0.243, 0.34 } }
        local okT, _, kindT = T.CheckContrast("panel.main")
        if okT ~= true or kindT ~= "translucent_skip" then
            error("translucent panel.main should skip: ok=" .. tostring(okT) .. " kind=" .. tostring(kindT))
        end
        -- Opaque bg (alpha 1): the brightened default border now clears 3:1 -> passes cleanly.
        theming.elements["panel.main"] = { bg = { 0.086, 0.129, 0.243, 1 } }
        local okO, _, kindO = T.CheckContrast("panel.main")
        if okO ~= true or kindO ~= nil then
            error("opaque default panel.main should pass 3:1: ok=" .. tostring(okO) .. " kind=" .. tostring(kindO))
        end
    end)
    theming.elements = {}
    for k, v in pairs(savedElements) do
        theming.elements[k] = v
    end
    if run then
        self:Pass()
    else
        self:Fail("translucent skip test errored; see trace")
    end
end)

TS:Register("Theme: applyPanel restores default backdrop when textures cleared", "theme", function(self)
    local u = UI()
    if not (u and u.APPLY_FN and u.APPLY_FN.panel) then
        self:Fail("UI.APPLY_FN.panel missing")
        return
    end
    local applyPanel = u.APPLY_FN.panel
    local frame = {
        _applied = {},
        GetBackdrop = function(self)
            return self._applied[#self._applied] or self._initial
        end,
        SetBackdrop = function(self, bd)
            self._applied[#self._applied + 1] = bd
        end,
        SetBackdropColor = function(self, r, g, b, a) end,
        SetBackdropBorderColor = function(self, r, g, b, a) end,
    }
    frame._initial = {
        bgFile = "Interface/Tooltips/UI-Tooltip-Background",
        edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
        tile = true,
        tileSize = 16,
        edgeSize = 16,
        insets = { left = 4, right = 4, top = 4, bottom = 4 },
    }
    local mult = { bgOpacity = 1.0, borderOpacity = 1.0 }
    applyPanel(frame, { bg = { 0, 0, 0, 1 }, bgTexture = "EMS-Test-Missing" }, mult)
    if not frame._emsTexturedState then
        self:Fail("expected _emsTexturedState true after textured apply")
        return
    end
    if
        type(frame._emsDefaultBackdrop) ~= "table"
        or frame._emsDefaultBackdrop.bgFile ~= "Interface/Tooltips/UI-Tooltip-Background"
    then
        self:Fail("_emsDefaultBackdrop snapshot missing or wrong bgFile")
        return
    end
    applyPanel(frame, { bg = { 0, 0, 0, 1 } }, mult)
    if frame._emsTexturedState then
        self:Fail("expected _emsTexturedState false after restore")
        return
    end
    local last = frame._applied[#frame._applied]
    if type(last) ~= "table" or last.bgFile ~= "Interface/Tooltips/UI-Tooltip-Background" then
        self:Fail("restored backdrop did not match snapshot bgFile")
        return
    end
    applyPanel(frame, { bg = { 0, 0, 0, 1 } }, mult)
    if frame._emsTexturedState then
        self:Fail("re-apply of default spec flipped state back to true")
        return
    end
    self:Pass()
end)

TS:Register("Theme: CheckContrast returns texture_unknown when panel bg is textured", "theme", function(self)
    local T = Theme()
    local u = UI()
    local S = GRIPEMS.Settings
    if not (T and T.CheckContrast and u and u.ELEMENT_CLASS_SET and S and S.db and S.db.profile) then
        self:Fail("theme API or settings missing")
        return
    end
    local theming = S.db.profile.theming or { preset = "default", elements = {}, savedThemes = {} }
    S.db.profile.theming = theming
    theming.elements = theming.elements or {}
    local savedElements = {}
    for k, v in pairs(theming.elements) do
        savedElements[k] = v
    end
    local run = pcall(function()
        -- text.body maps to panel.sequenceEditor per Core/Theme.lua
        -- TEXT_CLASS_PANEL (A11Y-THEME-CONTRAST-NON-MAIN-PANEL-BLOCKER).
        -- Setting bgTexture on panel.sequenceEditor is what triggers the
        -- texture_unknown blocker for text.body contrast checks.
        theming.elements["panel.sequenceEditor"] = { bgTexture = "Blizzard Parchment" }
        local ok, _, warnKind, _, fixTarget = T.CheckContrast("text.body")
        if warnKind ~= "texture_unknown" then
            error("expected warnKind texture_unknown, got " .. tostring(warnKind))
        end
        if not (type(fixTarget) == "table" and fixTarget.class == "panel.sequenceEditor") then
            error(
                "expected fixTarget.class panel.sequenceEditor, got "
                    .. tostring(fixTarget and fixTarget.class or "nil")
            )
        end
        if ok ~= true then
            error("expected ok true for texture_unknown verdict")
        end
        theming.elements["panel.sequenceEditor"] = nil
        local _, _, warn2, _, _ = T.CheckContrast("text.body")
        if warn2 == "texture_unknown" then
            error("texture_unknown should clear after bgTexture removed")
        end
    end)
    theming.elements = {}
    for k, v in pairs(savedElements) do
        theming.elements[k] = v
    end
    if run then
        self:Pass()
    else
        self:Fail("CheckContrast texture_unknown test errored; see trace")
    end
end)

TS:Register("Theme: ValidateSpec rejects texture fields outside panel.* classes", "theme", function(self)
    local T = Theme()
    if not (T and T.ValidateSpec) then
        self:Fail("Theme.ValidateSpec missing")
        return
    end
    local okPanel = T.ValidateSpec({
        version = 1,
        elements = { ["panel.main"] = { bgTexture = "Blizzard Parchment" } },
    })
    if not okPanel then
        self:Fail("bgTexture on panel.main should be accepted")
        return
    end
    local okOverlay = T.ValidateSpec({
        version = 1,
        elements = { ["overlay.toast.info"] = { bgTexture = "Blizzard Parchment" } },
    })
    if okOverlay then
        self:Fail("bgTexture on overlay.toast.info should be rejected")
        return
    end
    local okRow = T.ValidateSpec({
        version = 1,
        elements = { ["row.default"] = { borderTexture = "Blizzard Tooltip" } },
    })
    if okRow then
        self:Fail("borderTexture on row.default should be rejected")
        return
    end
    local okText = T.ValidateSpec({
        version = 1,
        elements = { ["text.body"] = { bgTexture = "Blizzard Parchment" } },
    })
    if okText then
        self:Fail("bgTexture on text.body should be rejected")
        return
    end
    self:Pass()
end)

TS:Register("Theme: applyPanel per-field revert keeps kept texture and reverts cleared texture", "theme", function(self)
    local u = UI()
    if not (u and u.APPLY_FN and u.APPLY_FN.panel) then
        self:Fail("UI.APPLY_FN.panel missing")
        return
    end
    local applyPanel = u.APPLY_FN.panel
    local frame = {
        _applied = {},
        GetBackdrop = function(self)
            return self._applied[#self._applied] or self._initial
        end,
        SetBackdrop = function(self, bd)
            self._applied[#self._applied + 1] = bd
        end,
        SetBackdropColor = function(self, r, g, b, a) end,
        SetBackdropBorderColor = function(self, r, g, b, a) end,
    }
    frame._emsElementClass = "test.mock.panel"
    frame._initial = {
        bgFile = "DEFAULT_BG",
        edgeFile = "DEFAULT_EDGE",
        tile = true,
        tileSize = 16,
        edgeSize = 16,
        insets = { left = 4, right = 4, top = 4, bottom = 4 },
    }
    local mult = { bgOpacity = 1.0, borderOpacity = 1.0 }
    applyPanel(frame, { bg = { 0, 0, 0, 1 }, bgTexture = "BG_ONE", borderTexture = "EDGE_ONE" }, mult)
    if not frame._emsDefaultBackdrop then
        self:Fail("expected _emsDefaultBackdrop snapshot after first apply")
        return
    end
    if frame._emsDefaultBackdrop.bgFile ~= "DEFAULT_BG" or frame._emsDefaultBackdrop.edgeFile ~= "DEFAULT_EDGE" then
        self:Fail("snapshot did not capture initial backdrop correctly")
        return
    end
    applyPanel(frame, { bg = { 0, 0, 0, 1 }, borderTexture = "EDGE_TWO" }, mult)
    local afterPartial = frame._applied[#frame._applied]
    if type(afterPartial) ~= "table" then
        self:Fail("expected a new backdrop written on partial clear")
        return
    end
    if afterPartial.bgFile ~= "DEFAULT_BG" then
        self:Fail("bgFile did not revert to snapshot on bgTexture clear; got " .. tostring(afterPartial.bgFile))
        return
    end
    applyPanel(frame, { bg = { 0, 0, 0, 1 }, bgTexture = "BG_TWO" }, mult)
    local afterSwap = frame._applied[#frame._applied]
    if type(afterSwap) ~= "table" then
        self:Fail("expected a new backdrop written on swap direction")
        return
    end
    if afterSwap.edgeFile ~= "DEFAULT_EDGE" then
        self:Fail("edgeFile did not revert to snapshot on borderTexture clear; got " .. tostring(afterSwap.edgeFile))
        return
    end
    self:Pass()
end)

TS:Register("Theme: CheckAndWarn dedupes texture_unknown and clears on transition", "theme", function(self)
    local T = Theme()
    local u = UI()
    local S = GRIPEMS.Settings
    if not (T and T.CheckAndWarn and u and u.ThemingEditor and S and S.db and S.db.profile) then
        self:Fail("Theme API or UI.ThemingEditor missing")
        return
    end
    local TE = u.ThemingEditor
    if type(TE.ShowContrastWarning) ~= "function" or type(TE.ClearContrastSilence) ~= "function" then
        self:Fail("TE.ShowContrastWarning or TE.ClearContrastSilence missing")
        return
    end

    local theming = S.db.profile.theming or { preset = "default", elements = {}, savedThemes = {} }
    S.db.profile.theming = theming
    theming.elements = theming.elements or {}
    local savedElements = {}
    for k, v in pairs(theming.elements) do
        savedElements[k] = v
    end

    T._lastBlocker = T._lastBlocker or {}
    local savedLastBlocker = {}
    for k, v in pairs(T._lastBlocker) do
        savedLastBlocker[k] = v
    end
    T._lastBlocker["text.body"] = nil

    local origShow = TE.ShowContrastWarning
    local origClear = TE.ClearContrastSilence
    local showCalls = {}
    local clearCalls = {}
    TE.ShowContrastWarning = function(class, _msg, _fix, _target)
        showCalls[#showCalls + 1] = class
    end
    TE.ClearContrastSilence = function(class)
        clearCalls[#clearCalls + 1] = class
    end

    local run = pcall(function()
        -- text.body maps to panel.sequenceEditor per Core/Theme.lua
        -- TEXT_CLASS_PANEL (A11Y-THEME-CONTRAST-NON-MAIN-PANEL-BLOCKER).
        theming.elements["panel.sequenceEditor"] = { bgTexture = "Blizzard Parchment" }

        T.CheckAndWarn("text.body")
        if #showCalls ~= 1 or showCalls[1] ~= "text.body" then
            error("first call should emit advisory once; got " .. tostring(#showCalls) .. " calls")
        end
        if T._lastBlocker["text.body"] ~= "panel.sequenceEditor" then
            error(
                "first call should set _lastBlocker['text.body'] = 'panel.sequenceEditor'; got "
                    .. tostring(T._lastBlocker["text.body"])
            )
        end

        T.CheckAndWarn("text.body")
        if #showCalls ~= 1 then
            error("second call with same blocker should dedupe; got " .. tostring(#showCalls) .. " calls")
        end

        theming.elements["panel.sequenceEditor"] = nil
        T.CheckAndWarn("text.body")
        if T._lastBlocker["text.body"] ~= nil then
            error(
                "transition out of blocker should clear _lastBlocker['text.body']; got "
                    .. tostring(T._lastBlocker["text.body"])
            )
        end

        theming.elements["panel.sequenceEditor"] = { bgTexture = "Blizzard Parchment" }
        T.CheckAndWarn("text.body")
        if #showCalls ~= 2 then
            error("re-apply after transition-clear should re-emit advisory; got " .. tostring(#showCalls) .. " calls")
        end
        if T._lastBlocker["text.body"] ~= "panel.sequenceEditor" then
            error("re-apply should re-set _lastBlocker['text.body'] = 'panel.sequenceEditor'")
        end
    end)

    TE.ShowContrastWarning = origShow
    TE.ClearContrastSilence = origClear
    theming.elements = {}
    for k, v in pairs(savedElements) do
        theming.elements[k] = v
    end
    T._lastBlocker = {}
    for k, v in pairs(savedLastBlocker) do
        T._lastBlocker[k] = v
    end

    if run then
        self:Pass()
    else
        self:Fail("dedupe/transition test errored; see trace")
    end
end)

-- end of Test/theme_spec.lua
