-- GRIP-EMS: MacroRecorder
-- Created: 2026-04-03
-- Updated: 2026-06-21
-- Patch: 12.0.7.68256 Midnight (Retail LIVE)

-- GRIP-EMS: Macro Recorder
-- Records spell casts via ExecutionTracer callbacks and builds sequences
-- from the recording. Does NOT register its own UNIT_SPELLCAST_SUCCEEDED.

local ADDON_NAME, GRIPEMS = ...

GRIPEMS.MacroRecorder = {}
local MR = GRIPEMS.MacroRecorder
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

---------------------------------------------------------------------------
-- State
---------------------------------------------------------------------------
MR.isRecording = false
MR.recordedSpells = {} -- array of { spellID, spellName, timestamp }
MR.MAX_RECORDING = 100 -- max steps before auto-stop

-- Optional UI callback for live count updates
MR.onCountUpdate = nil

---------------------------------------------------------------------------
-- Filter table: spellIDs to always exclude
---------------------------------------------------------------------------
MR.FILTER_SPELLS = {
    [6603] = true, -- Auto Attack
    [75] = true, -- Auto Shot
}

---------------------------------------------------------------------------
-- Settings accessor
---------------------------------------------------------------------------

--- Get recorder settings from profile.
--- @return table Recorder settings { dedup = bool }
function MR:GetSettings()
    local S = GRIPEMS.Settings
    if not S then
        return { dedup = false }
    end
    return {
        dedup = S:Get("recorderDedup") or false,
    }
end

---------------------------------------------------------------------------
-- Recording control
---------------------------------------------------------------------------

--- Start recording spell casts via ExecutionTracer callback.
function MR:Start()
    if MR.isRecording then
        return
    end
    MR.isRecording = true
    MR.recordedSpells = {}

    local ET = GRIPEMS.ExecutionTracer
    if ET then
        -- Ensure ET is active
        if not ET:IsActive() then
            ET:Start()
        end
        ET:RegisterCastCallback("MacroRecorder", function(spellID, spellName, timestamp)
            if not MR.isRecording then
                return
            end
            if MR.FILTER_SPELLS[spellID] then
                return
            end

            -- Dedup consecutive identical casts (if setting enabled)
            local settings = MR:GetSettings()
            if settings.dedup then
                local last = MR.recordedSpells[#MR.recordedSpells]
                if last and last.spellID == spellID then
                    return
                end
            end

            MR.recordedSpells[#MR.recordedSpells + 1] = {
                spellID = spellID,
                spellName = spellName,
                timestamp = timestamp,
            }

            -- Auto-stop at max
            if #MR.recordedSpells >= MR.MAX_RECORDING then
                MR:Stop()
                GRIPEMS:Print(L["GEMS_RECORDER_MAX_REACHED"])
            end

            -- Update UI count if visible
            if MR.onCountUpdate then
                MR:onCountUpdate(#MR.recordedSpells)
            end
        end)
    end
end

--- Stop recording spell casts.
function MR:Stop()
    if not MR.isRecording then
        return
    end
    MR.isRecording = false

    local ET = GRIPEMS.ExecutionTracer
    if ET then
        ET:UnregisterCastCallback("MacroRecorder")
    end
end

--- Toggle recording on/off.
function MR:Toggle()
    if MR.isRecording then
        MR:Stop()
    else
        MR:Start()
    end
end

---------------------------------------------------------------------------
-- Data accessors
---------------------------------------------------------------------------

--- Build step array from recorded spells.
--- Returns array of step tables compatible with EMS sequence format.
--- @return table Array of step tables (each step is a single-element array)
function MR:BuildSteps()
    local steps = {}
    for i, entry in ipairs(MR.recordedSpells) do
        steps[i] = {
            "/cast " .. entry.spellName,
        }
    end
    return steps
end

--- Get recorded spell count.
--- @return number Count of recorded spells
function MR:GetCount()
    return #MR.recordedSpells
end

--- Placeholder: will update recorder UI count display.
--- UI code can override this with a real implementation.
--- @param count number Current number of recorded spells
function MR:onCountUpdate(count) -- luacheck: no unused args
end

--- Clear all recording state and unregister callback.
function MR:Clear()
    MR.recordedSpells = {}
    MR.isRecording = false
    local ET = GRIPEMS.ExecutionTracer
    if ET then
        ET:UnregisterCastCallback("MacroRecorder")
    end
end
