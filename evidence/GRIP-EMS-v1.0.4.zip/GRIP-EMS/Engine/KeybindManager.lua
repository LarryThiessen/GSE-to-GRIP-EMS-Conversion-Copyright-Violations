-- GRIP-EMS: Keybind Manager
-- Override-binding keybind system for sequence execution

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS")
local D = GRIPEMS.Defaults

-- KeybindManager module: manages per-spec override bindings that route
-- keypresses to GRIP-EMS SecureActionButtons. Uses SetOverrideBindingClick
-- (not SetBindingClick) because override bindings are temporary, never saved
-- to the user's binding set, auto-wiped on /reload, and can be bulk-cleared
-- via ClearOverrideBindings(owner). All binding changes are nocombat-restricted
-- and go through OOCQueue when in combat lockdown.
--
-- Data model: GRIP_EMS_CHAR.keybinds[specIndex][key] = seqName
-- Keybinds are stored by sequence name (not button name) so renames work.
-- One sequence = one keybind per spec. Reassigning replaces the old key.
GRIPEMS.KeybindManager = {}
local KM = GRIPEMS.KeybindManager
KM.suspended = false
KM._pendingSpecLoad = false

-- Owner frame for all override bindings. ClearOverrideBindings(keybindOwner)
-- clears every binding we set. Individual keys cleared via
-- SetOverrideBinding(keybindOwner, false, key).
local keybindOwner = CreateFrame("Frame", "GRIPEMS_KeybindOwner", UIParent)
keybindOwner:Hide()

--- Return the current specialization index, or 0 if no spec is chosen.
--- Uses C_SpecializationInfo.GetSpecialization() (the non-deprecated 12.0+ API).
--- @return number Spec index (1-4) or 0 for unspecced characters
local function GetCurrentSpec()
    return C_SpecializationInfo.GetSpecialization() or 0
end

--- Return the current specialization index for external callers.
--- Internal code uses the local GetCurrentSpec() directly for speed.
--- @return number Spec index (1-4) or 0 for unspecced characters
function KM:GetCurrentSpec()
    return GetCurrentSpec()
end

--- Set an override keybinding for a sequence in the current spec.
--- Validates the sequence exists, clears any previous binding for this sequence,
--- and applies the new binding. Queues via OOCQueue if in combat.
--- @param seqName string Sequence name (must exist in Engine.sequences)
--- @param key string WoW key string (e.g. "CTRL-F12", "SHIFT-G", "F5")
function KM:SetKeybind(seqName, key)
    if not seqName or not key then return end
    if type(key) ~= "string" or key == "" then return end

    -- Validate sequence exists
    if not GRIPEMS.Engine or not GRIPEMS.Engine.sequences[seqName] then
        GRIPEMS:Print(string.format(L["GEMS_NOT_FOUND"], seqName))
        return
    end

    local spec = GetCurrentSpec()

    -- Ensure subtables exist
    if not _G.GRIP_EMS_CHAR then return end
    GRIP_EMS_CHAR.keybinds = GRIP_EMS_CHAR.keybinds or {}
    GRIP_EMS_CHAR.keybinds[spec] = GRIP_EMS_CHAR.keybinds[spec] or {}
    local specBinds = GRIP_EMS_CHAR.keybinds[spec]

    -- Clear any existing key bound to THIS sequence (one seq = one keybind)
    for existingKey, existingSeq in pairs(specBinds) do
        if existingSeq == seqName then
            specBinds[existingKey] = nil
            if not InCombatLockdown() then
                SetOverrideBinding(keybindOwner, false, existingKey)
            end
            break
        end
    end

    -- Clear any existing sequence bound to the TARGET key
    if specBinds[key] then
        specBinds[key] = nil
        if not InCombatLockdown() then
            SetOverrideBinding(keybindOwner, false, key)
        end
    end

    -- Store the new binding
    specBinds[key] = seqName

    -- Apply the override binding if out of combat
    if not InCombatLockdown() then
        local buttonName = D.BUTTON_PREFIX .. GRIPEMS.Engine:SanitizeName(seqName)
        SetOverrideBindingClick(keybindOwner, false, key, buttonName, "LeftButton")
        GRIPEMS:Print(string.format(L["GEMS_BIND_SUCCESS"], seqName, key))
    else
        -- Queue a full reload for when combat ends
        GRIPEMS.OOCQueue:Add(function() KM:LoadKeybinds() end)
        GRIPEMS:Print(string.format(L["GEMS_BIND_SUCCESS"], seqName, key))
    end

    if GRIPEMS.Fire then GRIPEMS:Fire("KEYBIND_CHANGED", seqName, key) end

    -- Safety-net: refresh SequenceList directly (matches delete path pattern)
    local SL = GRIPEMS.SequenceList
    if SL and SL.RefreshDataProvider then
        SL:RefreshDataProvider()
    end
end

--- Clear the keybinding for a sequence in the current spec.
--- Removes the override binding and deletes the saved data entry.
--- @param seqName string Sequence name
function KM:ClearKeybind(seqName)
    if not seqName then return end

    local spec = GetCurrentSpec()
    if not GRIP_EMS_CHAR or not GRIP_EMS_CHAR.keybinds then return end
    local specBinds = GRIP_EMS_CHAR.keybinds[spec]
    if not specBinds then
        GRIPEMS:Print(string.format(L["GEMS_UNBIND_NO_BIND"], seqName))
        return
    end

    -- Find the key bound to this sequence
    local foundKey = nil
    for key, boundSeq in pairs(specBinds) do
        if boundSeq == seqName then
            foundKey = key
            break
        end
    end

    if not foundKey then
        GRIPEMS:Print(string.format(L["GEMS_UNBIND_NO_BIND"], seqName))
        return
    end

    -- Clear the override binding if out of combat
    if not InCombatLockdown() then
        SetOverrideBinding(keybindOwner, false, foundKey)
    end

    -- Remove from saved data
    specBinds[foundKey] = nil
    GRIPEMS:Print(string.format(L["GEMS_UNBIND_SUCCESS"], seqName))

    if GRIPEMS.Fire then GRIPEMS:Fire("KEYBIND_CHANGED", seqName, nil) end

    -- Safety-net: refresh SequenceList directly (matches delete path pattern)
    local SL = GRIPEMS.SequenceList
    if SL and SL.RefreshDataProvider then
        SL:RefreshDataProvider()
    end
end

--- Schedule a debounced LoadKeybinds call. Coalesces multiple rapid calls
--- (e.g., PLAYER_SPECIALIZATION_CHANGED + ACTIVE_TALENT_GROUP_CHANGED firing
--- together on a single spec change) into one deferred LoadKeybinds execution.
function KM:ScheduleLoadKeybinds()
    if self._pendingSpecLoad then return end
    self._pendingSpecLoad = true
    C_Timer.After(0, function()
        KM._pendingSpecLoad = false
        KM:LoadKeybinds()
    end)
end

--- Load all keybindings for the current spec. Clears all existing overrides
--- first, then reapplies from saved data. Skips sequences whose buttons
--- don't exist yet (BindIfConfigured catches those on activation).
--- Queues itself via OOCQueue if called during combat.
function KM:LoadKeybinds()
    if InCombatLockdown() then
        GRIPEMS.OOCQueue:Add(function() KM:LoadKeybinds() end)
        return
    end
    if self.suspended then
        GRIPEMS:Debug("LoadKeybinds skipped: keybinds suspended")
        return
    end

    local spec = GetCurrentSpec()
    if spec == 0 then
        GRIPEMS:Debug("LoadKeybinds deferred: spec not yet known")
        C_Timer.After(1, function() KM:LoadKeybinds() end)
        return
    end

    -- Wipe all existing override bindings owned by our frame
    ClearOverrideBindings(keybindOwner)
    if not GRIP_EMS_CHAR or not GRIP_EMS_CHAR.keybinds then return end
    local specBinds = GRIP_EMS_CHAR.keybinds[spec]
    if not specBinds or not next(specBinds) then
        GRIPEMS:Debug("No keybinds for spec " .. spec)
        return
    end

    local count = 0
    for key, seqName in pairs(specBinds) do
        local sanitized = GRIPEMS.Engine:SanitizeName(seqName)
        local buttonName = D.BUTTON_PREFIX .. sanitized
        if _G[buttonName] then
            SetOverrideBindingClick(keybindOwner, false, key,
                buttonName, "LeftButton")
            count = count + 1
        else
            -- Button doesn't exist yet (sequence not activated).
            -- BindIfConfigured will catch it when activated later.
            GRIPEMS:Debug("Keybind " .. key .. " -> " .. seqName
                .. ": button not found, will bind on activation")
        end
    end

    GRIPEMS:Debug(string.format(L["GEMS_KEYBINDS_LOADED"], count, spec))
end

--- Clear all override bindings without removing saved data.
--- Used before spec change cleanup so LoadKeybinds can reapply for new spec.
function KM:UnloadKeybinds()
    ClearOverrideBindings(keybindOwner)
end

--- Apply the saved keybinding for a sequence after its button is created.
--- Called by Engine:ActivateSequence after the button exists in _G.
--- @param seqName string Sequence name
function KM:BindIfConfigured(seqName)
    if not seqName then return end
    if InCombatLockdown() then
        GRIPEMS.OOCQueue:Add(function() KM:BindIfConfigured(seqName) end)
        return
    end

    local spec = GetCurrentSpec()
    if not GRIP_EMS_CHAR or not GRIP_EMS_CHAR.keybinds then return end
    local specBinds = GRIP_EMS_CHAR.keybinds[spec]
    if not specBinds then return end

    for key, boundSeq in pairs(specBinds) do
        if boundSeq == seqName then
            local sanitized = GRIPEMS.Engine:SanitizeName(seqName)
            local buttonName = D.BUTTON_PREFIX .. sanitized
            if _G[buttonName] then
                SetOverrideBindingClick(keybindOwner, false, key,
                    buttonName, "LeftButton")
                GRIPEMS:Debug("Keybind " .. key .. " applied for " .. seqName)
            else
                GRIPEMS:Debug("BindIfConfigured: button " .. buttonName
                    .. " not found for " .. seqName
                    .. ", binding deferred to LoadKeybinds")
            end
            break  -- one sequence = one keybind
        end
    end
end

--- Clear the live override binding for a sequence without removing saved data.
--- Called by Engine:DeactivateSequence before the button is destroyed.
--- The saved entry remains so re-activation restores the binding.
--- @param seqName string Sequence name
function KM:UnbindSequence(seqName)
    if not seqName then return end
    if InCombatLockdown() then return end

    local spec = GetCurrentSpec()
    if not GRIP_EMS_CHAR or not GRIP_EMS_CHAR.keybinds then return end
    local specBinds = GRIP_EMS_CHAR.keybinds[spec]
    if not specBinds then return end

    for key, boundSeq in pairs(specBinds) do
        if boundSeq == seqName then
            SetOverrideBinding(keybindOwner, false, key)
            break
        end
    end
end

--- Remove ALL saved keybind data for a sequence across every spec.
--- Called on permanent deletion (not deactivation).
--- Does NOT clear live override bindings (DeactivateSequence handles that).
--- @param seqName string Sequence name
function KM:PurgeKeybinds(seqName)
    if not seqName then return end
    if not GRIP_EMS_CHAR or not GRIP_EMS_CHAR.keybinds then return end
    for _, specBinds in pairs(GRIP_EMS_CHAR.keybinds) do
        for key, boundSeq in pairs(specBinds) do
            if boundSeq == seqName then
                specBinds[key] = nil
            end
        end
    end
end

--- Get the key string bound to a sequence in the current spec.
--- @param seqName string Sequence name
--- @return string|nil The key string, or nil if no binding exists
function KM:GetKeybind(seqName)
    if not seqName then return nil end

    local spec = GetCurrentSpec()
    if not GRIP_EMS_CHAR or not GRIP_EMS_CHAR.keybinds then return nil end
    local specBinds = GRIP_EMS_CHAR.keybinds[spec]
    if not specBinds then return nil end

    for key, boundSeq in pairs(specBinds) do
        if boundSeq == seqName then
            return key
        end
    end
    return nil
end

--- Return a copy of the current spec's keybind table for display.
--- @return table|nil Copy of {key = seqName} table, or nil if empty
function KM:GetAllKeybinds()
    local spec = GetCurrentSpec()
    if not GRIP_EMS_CHAR or not GRIP_EMS_CHAR.keybinds then return nil end
    local specBinds = GRIP_EMS_CHAR.keybinds[spec]
    if not specBinds then return nil end

    -- Return a shallow copy to avoid external mutation
    local copy = {}
    for key, seqName in pairs(specBinds) do
        copy[key] = seqName
    end
    return copy
end

--- Suspend all keybinds (e.g., vehicle, pet battle, override bar).
--- Clears all override bindings but preserves saved data for restore.
--- Guards with InCombatLockdown and queues via OOCQueue if needed.
--- @param reason string Human-readable reason for debug logging
function KM:SuspendKeybinds(reason)
    if self.suspended then return end
    self.suspended = true
    if not InCombatLockdown() then
        ClearOverrideBindings(keybindOwner)
        GRIPEMS:Debug(string.format(L["GEMS_KEYBINDS_SUSPENDED"], reason))
    else
        GRIPEMS.OOCQueue:Add(function()
            if KM.suspended then
                ClearOverrideBindings(keybindOwner)
                GRIPEMS:Debug(string.format(L["GEMS_KEYBINDS_SUSPENDED"], reason))
            end
        end)
    end
end

--- Restore keybinds after vehicle/pet battle/override bar ends.
--- Reapplies all saved bindings for the current spec via LoadKeybinds.
--- Guards with InCombatLockdown and queues via OOCQueue if needed.
--- @param reason string Human-readable reason for debug logging
function KM:RestoreKeybinds(reason)
    if not self.suspended then return end
    self.suspended = false
    if not InCombatLockdown() then
        self:LoadKeybinds()
        GRIPEMS:Debug(string.format(L["GEMS_KEYBINDS_RESTORED"], reason))
    else
        GRIPEMS.OOCQueue:Add(function()
            if not KM.suspended then
                KM:LoadKeybinds()
                GRIPEMS:Debug(string.format(L["GEMS_KEYBINDS_RESTORED"], reason))
            end
        end)
    end
end
