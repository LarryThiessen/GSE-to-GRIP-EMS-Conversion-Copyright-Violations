-- GRIP-EMS: Main Window Frame
-- Split-panel main window with title bar, movable/resizable, position persistence

local ADDON_NAME, GRIPEMS = ...
local UI = GRIPEMS.UI
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS")

-- Upvalues for Defaults (available after Defaults.lua loads, which is before UI/)
local function D()
    return GRIPEMS.Defaults
end

local VALID_ANCHORS = {
    TOPLEFT = true,
    TOP = true,
    TOPRIGHT = true,
    LEFT = true,
    CENTER = true,
    RIGHT = true,
    BOTTOMLEFT = true,
    BOTTOM = true,
    BOTTOMRIGHT = true,
}

---------------------------------------------------------------------------
-- Frame creation
---------------------------------------------------------------------------

--- Build the main GRIPEMS window. Called once at file load time.
local function CreateMainFrame()
    local C = UI.Colors
    local defaults = D()

    local frame = UI:ReclaimFrame("GRIPEMS_MainFrame", "Frame", UIParent, "BackdropTemplate")
    frame:SetSize(defaults.MAIN_FRAME_WIDTH, defaults.MAIN_FRAME_HEIGHT)
    frame:SetPoint("CENTER")
    frame:SetFrameStrata("HIGH")
    UI:ApplyBackdrop(frame, UI.Backdrops.panel, C.bgMain, C.border)
    frame:SetClampedToScreen(true)
    frame:Hide()

    -- ESC to close
    if not tContains(UISpecialFrames, "GRIPEMS_MainFrame") then
        tinsert(UISpecialFrames, "GRIPEMS_MainFrame")
    end

    -- Movable via title bar (set up below)
    frame:SetMovable(true)

    -- Resizable
    frame:SetResizable(true)
    frame:SetResizeBounds(defaults.MAIN_FRAME_MIN_WIDTH, defaults.MAIN_FRAME_MIN_HEIGHT)

    ---------------------------------------------------------------------------
    -- Title bar (40px)
    ---------------------------------------------------------------------------
    local titleBar = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    titleBar:SetHeight(D().TITLE_BAR_HEIGHT)
    titleBar:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, 0)
    titleBar:SetPoint("TOPRIGHT", frame, "TOPRIGHT", 0, 0)
    UI:ApplyBackdrop(titleBar, UI.Backdrops.panelNoBorder, C.bgDeep)
    frame.titleBar = titleBar

    -- Make title bar the drag region
    titleBar:EnableMouse(true)
    titleBar:RegisterForDrag("LeftButton")
    titleBar:SetScript("OnDragStart", function()
        frame:StartMoving()
    end)
    titleBar:SetScript("OnDragStop", function()
        frame:StopMovingOrSizing()
    end)

    -- Title text
    local titleText = titleBar:CreateFontString(nil, "OVERLAY")
    UI:SetFont(titleText, 14, "OUTLINE")
    titleText:SetPoint("LEFT", titleBar, "LEFT", 12, 0)
    titleText:SetText(L["GEMS_UI_TITLE"])
    titleText:SetTextColor(C.gripGreen:GetRGBA())
    frame.titleText = titleText

    -- Version text
    local versionText = titleBar:CreateFontString(nil, "OVERLAY")
    UI:SetFont(versionText, 10)
    versionText:SetPoint("LEFT", titleText, "RIGHT", 8, 0)
    versionText:SetText("v" .. (GRIPEMS.version or "dev"))
    versionText:SetTextColor(C.textMuted:GetRGBA())
    frame.versionText = versionText

    -- Close button (themed dark-UI X)
    local closeBtn = CreateFrame("Button", nil, titleBar, "BackdropTemplate")
    closeBtn:SetSize(24, 24)
    closeBtn:SetPoint("TOPRIGHT", titleBar, "TOPRIGHT", -6, -8)
    UI:ApplyBackdrop(closeBtn, UI.Backdrops.panel, C.bgButton, C.border)
    local closeLbl = closeBtn:CreateFontString(nil, "OVERLAY")
    UI:SetFont(closeLbl, 14)
    closeLbl:SetPoint("CENTER", 0, 1)
    closeLbl:SetText("X")
    closeLbl:SetTextColor(C.textSecondary:GetRGBA())
    closeBtn:SetScript("OnClick", function()
        frame:Hide()
    end)
    closeBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.accent:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
        closeLbl:SetTextColor(C.textPrimary:GetRGBA())
    end)
    closeBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
        closeLbl:SetTextColor(C.textSecondary:GetRGBA())
    end)
    frame.closeBtn = closeBtn

    -- Minimize button (left of close button)
    local minimizeBtn = CreateFrame("Button", nil, titleBar, "BackdropTemplate")
    minimizeBtn:SetSize(24, 24)
    minimizeBtn:SetPoint("RIGHT", closeBtn, "LEFT", -4, 0)
    UI:ApplyBackdrop(minimizeBtn, UI.Backdrops.panel, C.bgButton, C.border)
    local minLbl = minimizeBtn:CreateFontString(nil, "OVERLAY")
    UI:SetFont(minLbl, 14)
    minLbl:SetPoint("CENTER", 0, 1)
    minLbl:SetText("_")
    minLbl:SetTextColor(C.textSecondary:GetRGBA())
    minimizeBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.accent:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
        minLbl:SetTextColor(C.textPrimary:GetRGBA())
    end)
    minimizeBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
        minLbl:SetTextColor(C.textSecondary:GetRGBA())
    end)
    frame.minimizeBtn = minimizeBtn
    frame.minimizeLbl = minLbl

    -- Settings button (left of minimize button)
    local settingsBtn = CreateFrame("Button", nil, titleBar, "BackdropTemplate")
    settingsBtn:SetSize(24, 24)
    settingsBtn:SetPoint("RIGHT", minimizeBtn, "LEFT", -4, 0)
    UI:ApplyBackdrop(settingsBtn, UI.Backdrops.panel, C.bgButton, C.border)
    local settingsIcon = settingsBtn:CreateTexture(nil, "ARTWORK")
    settingsIcon:SetSize(16, 16)
    settingsIcon:SetPoint("CENTER")
    settingsIcon:SetTexture("Interface\\Icons\\INV_Misc_Gear_01")
    settingsIcon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    settingsBtn:SetScript("OnClick", function()
        if GRIPEMS.SettingsPanel then
            GRIPEMS.SettingsPanel:Open()
        end
    end)
    settingsBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.accent:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
        UI:ShowTooltip(self, L["GEMS_UI_SETTINGS_BTN"], L["GEMS_UI_SETTINGS_BTN_DESC"])
    end)
    settingsBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
        UI:HideTooltip()
    end)
    frame.settingsBtn = settingsBtn

    ---------------------------------------------------------------------------
    -- Resize grip (bottom-right corner)
    ---------------------------------------------------------------------------
    local resizeGrip = CreateFrame("Button", nil, frame)
    resizeGrip:SetSize(16, 16)
    resizeGrip:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -2, 2)
    resizeGrip:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    resizeGrip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    resizeGrip:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
    resizeGrip:SetScript("OnMouseDown", function()
        frame:StartSizing("BOTTOMRIGHT")
    end)
    resizeGrip:SetScript("OnMouseUp", function()
        frame:StopMovingOrSizing()
    end)
    resizeGrip:SetScript("OnEnter", function(self)
        UI:ShowTooltip(self, L["GEMS_UI_RESIZE"], L["GEMS_UI_RESIZE_DESC"])
    end)
    resizeGrip:SetScript("OnLeave", function()
        UI:HideTooltip()
    end)
    frame.resizeGrip = resizeGrip

    ---------------------------------------------------------------------------
    -- Left panel (fixed 280px default, bgPanel color)
    ---------------------------------------------------------------------------
    local leftPanel = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    leftPanel:SetWidth(D().LEFT_PANEL_WIDTH)
    leftPanel:SetPoint("TOPLEFT", frame, "TOPLEFT", 1, -D().TITLE_BAR_HEIGHT)
    leftPanel:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 1, 1)
    UI:ApplyBackdrop(leftPanel, UI.Backdrops.panel, C.bgPanel, C.border)
    frame.leftPanel = leftPanel

    -- Placeholder text for left panel
    local leftPlaceholder = leftPanel:CreateFontString(nil, "OVERLAY")
    UI:SetFont(leftPlaceholder, 11)
    leftPlaceholder:SetPoint("CENTER")
    leftPlaceholder:SetText(L["GEMS_UI_SEQUENCE_LIST_PLACEHOLDER"])
    leftPlaceholder:SetTextColor(C.textMuted:GetRGBA())
    frame.leftPlaceholder = leftPlaceholder

    ---------------------------------------------------------------------------
    -- Divider (4px wide, between panels)
    ---------------------------------------------------------------------------
    local divider = CreateFrame("Frame", nil, frame)
    divider:SetWidth(4)
    divider:SetPoint("TOPLEFT", leftPanel, "TOPRIGHT", 0, 0)
    divider:SetPoint("BOTTOMLEFT", leftPanel, "BOTTOMRIGHT", 0, 0)
    frame.divider = divider

    ---------------------------------------------------------------------------
    -- Right panel (fills remaining space)
    ---------------------------------------------------------------------------
    local rightPanel = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    rightPanel:SetPoint("TOPLEFT", divider, "TOPRIGHT", 0, 0)
    rightPanel:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -1, 1)
    UI:ApplyBackdrop(rightPanel, UI.Backdrops.panelNoBorder, C.bgMain)
    frame.rightPanel = rightPanel

    -- Placeholder text for right panel
    local rightPlaceholder = rightPanel:CreateFontString(nil, "OVERLAY")
    UI:SetFont(rightPlaceholder, 12)
    rightPlaceholder:SetPoint("CENTER")
    rightPlaceholder:SetText(L["GEMS_UI_SELECT_SEQUENCE"])
    rightPlaceholder:SetTextColor(C.textMuted:GetRGBA())
    frame.rightPlaceholder = rightPlaceholder

    ---------------------------------------------------------------------------
    -- Minimize / Restore
    ---------------------------------------------------------------------------
    frame.minimized = false
    frame.restoreHeight = nil

    local function DoMinimize()
        frame.restoreHeight = frame:GetHeight()
        frame:SetResizable(false)
        frame:SetHeight(defaults.MINIMIZED_HEIGHT)
        leftPanel:Hide()
        rightPanel:Hide()
        divider:Hide()
        resizeGrip:Hide()
        minLbl:SetText("[ ]")
        frame.minimized = true
    end

    local function DoRestore()
        frame:SetHeight(frame.restoreHeight or defaults.MAIN_FRAME_HEIGHT)
        frame:SetResizable(true)
        frame:SetResizeBounds(defaults.MAIN_FRAME_MIN_WIDTH, defaults.MAIN_FRAME_MIN_HEIGHT)
        leftPanel:Show()
        rightPanel:Show()
        divider:Show()
        resizeGrip:Show()
        minLbl:SetText("_")
        frame.minimized = false
    end

    minimizeBtn:SetScript("OnClick", function()
        if frame.minimized then
            DoRestore()
        else
            DoMinimize()
        end
        -- Persist state
        local sv = GRIP_EMS_CHAR and GRIP_EMS_CHAR.ui and GRIP_EMS_CHAR.ui.mainFrame
        if sv then
            sv.minimized = frame.minimized
        end
    end)

    frame.DoMinimize = DoMinimize
    frame.DoRestore = DoRestore

    ---------------------------------------------------------------------------
    -- Layout update on resize
    ---------------------------------------------------------------------------
    frame:SetScript("OnSizeChanged", function(self, width, height)
        -- Left panel stays fixed width, right panel adjusts automatically via anchors
    end)

    ---------------------------------------------------------------------------
    -- Position/size persistence
    ---------------------------------------------------------------------------
    frame:SetScript("OnHide", function(self)
        local sv = GRIP_EMS_CHAR and GRIP_EMS_CHAR.ui and GRIP_EMS_CHAR.ui.mainFrame
        if not sv then
            return
        end
        local point, _, _, x, y = self:GetPoint(1)
        sv.point = point
        sv.x = x
        sv.y = y
        if not self.minimized then
            sv.width = self:GetWidth()
            sv.height = self:GetHeight()
        end
        sv.minimized = self.minimized
    end)

    return frame
end

---------------------------------------------------------------------------
-- Initialize: create the frame
---------------------------------------------------------------------------
local mainFrame

---------------------------------------------------------------------------
-- Position restore (called from Core.lua on PLAYER_LOGIN)
---------------------------------------------------------------------------

--- Restore saved window position and size from SavedVariables.
function UI:RestoreMainFramePosition()
    local sv = GRIP_EMS_CHAR and GRIP_EMS_CHAR.ui and GRIP_EMS_CHAR.ui.mainFrame
    if not sv then
        return
    end

    local defaults = D()
    local width = sv.width or defaults.MAIN_FRAME_WIDTH
    local height = sv.height or defaults.MAIN_FRAME_HEIGHT

    -- Clamp to minimum size
    if width < defaults.MAIN_FRAME_MIN_WIDTH then
        width = defaults.MAIN_FRAME_MIN_WIDTH
    end
    if height < defaults.MAIN_FRAME_MIN_HEIGHT then
        height = defaults.MAIN_FRAME_MIN_HEIGHT
    end

    mainFrame:SetSize(width, height)

    if sv.point and sv.x and sv.y and VALID_ANCHORS[sv.point] then
        mainFrame:ClearAllPoints()
        mainFrame:SetPoint(sv.point, UIParent, sv.point, sv.x, sv.y)
    end

    -- Restore minimized state
    if sv.minimized and mainFrame.DoMinimize then
        mainFrame.restoreHeight = height
        mainFrame.DoMinimize()
    end
end

---------------------------------------------------------------------------
-- Toggle function
---------------------------------------------------------------------------

--- Initialize the left and right panel content (list + editor).
--- Called from UI:ToggleMainFrame() on first open (lazy-create).
function UI:InitPanels()
    if GRIPEMS.SequenceList then
        GRIPEMS.SequenceList:Init(GRIPEMS_MainFrame.leftPanel)
    end
    if GRIPEMS.SequenceEditor then
        GRIPEMS.SequenceEditor:Init(GRIPEMS_MainFrame.rightPanel)
    end
    -- Initial data load
    if GRIPEMS.SequenceList then
        GRIPEMS.SequenceList:RefreshDataProvider()
    end
end

--- Toggle the main window open/closed (lazy-creates on first open).
function UI:ToggleMainFrame()
    if not mainFrame then
        mainFrame = CreateMainFrame()
        UI:RestoreMainFramePosition()
        UI:InitPanels()
        -- Register with ConsolePort cursor navigation (nil-safe)
        if ConsolePort and ConsolePort.AddInterfaceCursorFrame then
            ConsolePort:AddInterfaceCursorFrame(mainFrame)
        end
    end
    if GRIPEMS_MainFrame:IsShown() then
        GRIPEMS_MainFrame:Hide()
    else
        GRIPEMS_MainFrame:Show()
    end
end

---------------------------------------------------------------------------
-- Addon Compartment functions (declared in TOC, implemented here)
---------------------------------------------------------------------------

--- Called when the addon compartment button is clicked.
function GRIPEMS_OnCompartmentClick(addonName, buttonName)
    if buttonName == "RightButton" then
        MenuUtil.CreateContextMenu(nil, function(_, rootDescription)
            rootDescription:CreateTitle(L["GEMS_UI_TITLE"])
            rootDescription:CreateButton(L["GEMS_UI_REMOTE_BROWSER_TITLE"], function()
                if GRIPEMS.RemoteBrowser then
                    GRIPEMS.RemoteBrowser:Toggle()
                end
            end)
        end)
        return
    end
    UI:ToggleMainFrame()
end

--- Called when the mouse enters the addon compartment button.
function GRIPEMS_OnCompartmentEnter(addonName, menuButtonFrame)
    GameTooltip:SetOwner(menuButtonFrame, "ANCHOR_LEFT")
    GameTooltip:AddDoubleLine(
        "|cFF00CC66GRIP|r - Enhanced Macro Sequencer",
        "v" .. (GRIPEMS.version or "dev"),
        1,
        1,
        1,
        0.6,
        0.6,
        0.6
    )
    GameTooltip:AddLine(" ")
    local count = 0
    if GRIPEMS.Engine and GRIPEMS.Engine.GetActiveCount then
        count = GRIPEMS.Engine:GetActiveCount()
    end
    GameTooltip:AddDoubleLine(L["GEMS_UI_ACTIVE_SEQUENCES_LABEL"], tostring(count), 0.8, 0.8, 0.8, 0, 0.8, 0.4)
    if GRIPEMS.Engine and GRIPEMS.Engine.currentContext then
        GameTooltip:AddDoubleLine(
            L["GEMS_UI_CONTEXT_LABEL"],
            GRIPEMS.Engine.currentContext or "none",
            0.8,
            0.8,
            0.8,
            0,
            0.8,
            0.4
        )
    end
    GameTooltip:AddLine(" ")
    GameTooltip:AddLine(L["GEMS_UI_MINIMAP_LEFT"], 0.5, 0.5, 0.5)
    GameTooltip:Show()
end

--- Called when the mouse leaves the addon compartment button.
function GRIPEMS_OnCompartmentLeave(addonName, menuButtonFrame)
    GameTooltip:Hide()
end
