-- GRIP-EMS: Test spec for Simplified Mode (Phase 4 item 18 S3)
--
-- Created:    2026-04-24
-- Updated:    2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.
--
-- Registers 8 tests in TestSuite under category "simplified" covering
-- the tab whitelist filter, keybind capture-row visibility + locked-edit
-- hint, action-bar column shape, per-widget delay lockout, Activate
-- return contract, preset snapshot round-trip, density rejection, and
-- uiScale rejection. Run in-game with /gems test simplified.

local ADDON_NAME, GRIPEMS = ...
local TS = GRIPEMS.TestSuite
if not TS then
    return
end

local function getL()
    local ok, L = pcall(function()
        return LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)
    end)
    if ok and type(L) == "table" then
        return L
    end
    return setmetatable({}, {
        __index = function(_, k)
            return k
        end,
    })
end

-- Walk the AceConfig options tree for "GRIP-EMS" and return a leaf set
-- function by args-key path. On any miss returns nil plus a diagnostic
-- string naming the break depth and the keys present there, so a failing
-- test reports the real tree shape instead of a static guess.
local function getSetter(...)
    local ACR = LibStub and LibStub("AceConfigRegistry-3.0", true)
    if not ACR then
        return nil, "AceConfigRegistry-3.0 not loaded"
    end
    -- Fetch through the public API. AceConfigRegistry validates the getter
    -- args: uiType must be cmd/dropdown/dialog, and uiName must carry a
    -- version number (pattern letter-hyphen-digit, e.g. "MyLib-1.0").
    local okReq, node = pcall(ACR.GetOptionsTable, ACR, "GRIP-EMS", "dialog", "GRIP-EMS-TestSuite-1.0")
    if not okReq then
        return nil, "GetOptionsTable errored: " .. tostring(node)
    end
    if type(node) ~= "table" then
        return nil, "GetOptionsTable returned " .. type(node)
    end
    for depth, k in ipairs({ ... }) do
        if not (node and type(node.args) == "table" and node.args[k]) then
            local present = {}
            if node and type(node.args) == "table" then
                for kk in pairs(node.args) do
                    present[#present + 1] = tostring(kk)
                end
                table.sort(present)
            end
            local keys = "[" .. table.concat(present, ", ") .. "]"
            return nil, "no '" .. tostring(k) .. "' at depth " .. depth .. "; keys present: " .. keys
        end
        node = node.args[k]
    end
    if type(node.set) ~= "function" then
        return nil, "leaf reached but .set is " .. type(node.set)
    end
    return node.set
end

local function accProfile()
    local s = GRIPEMS.Settings
    return s and s.db and s.db.profile and s.db.profile.accessibility
end

local SNAP_KEYS = { "simplifiedMode", "simplifiedDelay", "density", "uiScale", "accessibilityPresetOn" }

local function snap(a)
    local s = { _preset = a._accessibilityPresetSimplifiedSnapshot }
    for _, k in ipairs(SNAP_KEYS) do
        s[k] = a[k]
    end
    return s
end

local function restore(a, s)
    for _, k in ipairs(SNAP_KEYS) do
        a[k] = s[k]
    end
    a._accessibilityPresetSimplifiedSnapshot = s._preset
    -- Re-apply the restored scale to the live frames. The uiScale setter
    -- applies immediately (UI:ApplyUIScale), so a raw profile write-back
    -- leaves every registered frame at the last tested scale -- observed
    -- live 2026-07-16: the window-open sweep ended with the window stuck
    -- at 1.75x until reload. Restore must undo the APPLIED state, not
    -- just the stored value.
    if GRIPEMS.UI and GRIPEMS.UI.ApplyUIScale then
        pcall(GRIPEMS.UI.ApplyUIScale, GRIPEMS.UI)
    end
end

local function runCase(self, body, cleanup)
    local a = accProfile()
    if not a then
        self:Fail("accessibility profile missing")
        return
    end
    local s = snap(a)
    local ok, err = pcall(body, a)
    if cleanup then
        pcall(cleanup)
    end
    restore(a, s)
    if ok then
        self:Pass()
    else
        self:Fail(tostring(err))
    end
end

TS:Register("Simplified: RelayoutSimplified keeps 2 of 6 tabs active", "simplified", function(self)
    local SE = GRIPEMS.SequenceEditor
    if not (SE and SE.RelayoutSimplified and SE.SwitchTab) then
        self:Fail("SequenceEditor RelayoutSimplified/SwitchTab missing")
        return
    end
    if not SE.tabButtons then
        self:Skip("editor not built yet -- open the Sequence Editor once, then re-run /gems test simplified")
        return
    end
    runCase(self, function(a)
        a.simplifiedMode = true
        SE._simplifiedUnlocked = false
        SE:RelayoutSimplified()
        local active, count = {}, 0
        for name, tab in pairs(SE.tabButtons) do
            if tab._isActive then
                active[name] = true
                count = count + 1
            end
        end
        if count ~= 2 then
            error("expected 2 active tabs, got " .. tostring(count))
        end
        if not (active.Steps and active.Keybind) then
            error("active tab set should be {Steps, Keybind}")
        end
        for _, name in ipairs({ "Macros", "Context", "Variables", "Raw" }) do
            if active[name] then
                error("tab " .. name .. " must be inactive in Simplified Mode")
            end
        end
        local before = SE.activeTab
        SE:SwitchTab("Macros")
        if SE.activeTab ~= before and SE.activeTab ~= "Steps" and SE.activeTab ~= "Keybind" then
            error("SwitchTab('Macros') leaked activeTab to " .. tostring(SE.activeTab))
        end
    end, function()
        pcall(SE.RelayoutSimplified, SE)
    end)
end)

TS:Register("Simplified: keybind capture row stays shown while locked", "simplified", function(self)
    local SE = GRIPEMS.SequenceEditor
    local KT = GRIPEMS.KeybindTab
    if not (SE and SE.RelayoutSimplified) then
        self:Fail("SequenceEditor RelayoutSimplified missing")
        return
    end
    if not (KT and KT.captureRow and KT.RefreshDisplay) then
        self:Skip("keybind tab not built yet -- open the Sequence Editor once, then re-run /gems test simplified")
        return
    end
    runCase(self, function(a)
        a.simplifiedMode = true
        SE._simplifiedUnlocked = false
        SE:RelayoutSimplified()
        KT:RefreshDisplay()
        if not KT.captureRow:IsShown() then
            error("capture row must stay shown in Simplified Mode")
        end
        if GRIPEMS.StepListView and GRIPEMS.StepListView.editScrollFrame then
            if not (SE._simplifiedLockedHint and SE._simplifiedLockedHint:IsShown()) then
                error("locked-edit hint must be shown while Simplified Mode is locked")
            end
            if GRIPEMS.StepListView.UpdateEditArea then
                pcall(GRIPEMS.StepListView.UpdateEditArea, GRIPEMS.StepListView)
                if GRIPEMS.StepListView.editScrollFrame:IsShown() then
                    error("edit scroll frame must stay hidden while locked even after UpdateEditArea")
                end
            end
            if GRIPEMS.StepListView.actionBar and SE.UpdateTabContent and SE.activeTab == "Steps" then
                SE:UpdateTabContent()
                if GRIPEMS.StepListView.actionBar:IsShown() then
                    error("action bar must stay hidden in Simplified Mode after a tab-content refresh")
                end
            end
        end
        SE._simplifiedUnlocked = true
        SE:RelayoutSimplified()
        if SE._simplifiedLockedHint and SE._simplifiedLockedHint:IsShown() then
            error("locked-edit hint must hide once the session is unlocked")
        end
    end, function()
        SE._simplifiedUnlocked = false
        pcall(SE.RelayoutSimplified, SE)
    end)
end)

TS:Register("Simplified: action bar wires 3 buttons at 60x60 with locale labels", "simplified", function(self)
    local SE = GRIPEMS.SequenceEditor
    if not (SE and SE.RelayoutSimplified) then
        self:Fail("SequenceEditor RelayoutSimplified missing")
        return
    end
    if not SE.tabButtons then
        self:Skip("editor not built yet -- open the Sequence Editor once, then re-run /gems test simplified")
        return
    end
    runCase(self, function(a)
        a.simplifiedMode = true
        SE:RelayoutSimplified()
        local bar = SE.simplifiedActionBar
        if type(bar) ~= "table" then
            error("simplifiedActionBar not constructed")
        end
        local wired = 0
        for _, k in ipairs({ "runBtn", "unlockBtn", "closeBtn" }) do
            local btn = bar[k]
            if type(btn) ~= "table" then
                error("bar." .. k .. " missing")
            end
            wired = wired + 1
            local w = btn.GetWidth and btn:GetWidth() or 0
            local h = btn.GetHeight and btn:GetHeight() or 0
            if math.abs(w - 60) > 0.5 or math.abs(h - 60) > 0.5 then
                error(k .. " expected 60x60, got " .. tostring(w) .. "x" .. tostring(h))
            end
            if not (btn.label and btn.label.GetText) then
                error(k .. " label fontstring missing")
            end
        end
        if wired ~= 3 then
            error("expected exactly 3 wired buttons, got " .. tostring(wired))
        end
        if bar.GetFrameLevel then
            local SLV = GRIPEMS.StepListView
            local refs = {
                scrollBox = SLV and SLV.scrollBox,
                editScrollFrame = SLV and SLV.editScrollFrame,
                stepActionBar = SLV and SLV.actionBar,
            }
            for name, ref in pairs(refs) do
                if ref and ref.GetFrameLevel and bar:GetFrameLevel() <= ref:GetFrameLevel() then
                    error("simplified bar must render above editor content; frame level <= " .. name)
                end
            end
        end
        local L = getL()
        local want = {
            runBtn = L["ACCESS_SIMPLIFIED_RUN_BUTTON"],
            unlockBtn = L["ACCESS_SIMPLIFIED_UNLOCK_BUTTON"],
            closeBtn = L["ACCESS_HELP_CLOSE"],
        }
        for k, exp in pairs(want) do
            local got = bar[k].label:GetText() or ""
            if got ~= exp then
                error(k .. " label expected '" .. tostring(exp) .. "', got '" .. tostring(got) .. "'")
            end
        end
    end, function()
        pcall(SE.RelayoutSimplified, SE)
    end)
end)

TS:Register("Simplified: _lastActivateAt is a widget-keyed table after one activation", "simplified", function(self)
    local Focus = GRIPEMS.Focus
    if not (Focus and Focus.PushContext and Focus.PopContext and Focus.Activate) then
        self:Fail("Focus manager API missing")
        return
    end
    local widget = {
        IsVisible = function()
            return true
        end,
        IsEnabled = function()
            return true
        end,
        Click = function() end,
    }
    runCase(self, function(a)
        a.simplifiedMode = true
        a.simplifiedDelay = 500
        Focus._lastActivateAt = nil
        Focus:PushContext("simplified_spec", { widget }, { onActivate = function() end })
        Focus:TopContext().cursor = 1
        Focus:Activate()
        if type(Focus._lastActivateAt) ~= "table" then
            error("_lastActivateAt must be a table after activation; got " .. type(Focus._lastActivateAt))
        end
        if Focus._lastActivateAt[widget] == nil then
            error("_lastActivateAt must be keyed on widget identity; key not found")
        end
        if type(Focus._lastActivateAt[widget]) ~= "number" then
            error("_lastActivateAt[widget] must be a number timestamp")
        end
    end, function()
        pcall(Focus.PopContext, Focus, "simplified_spec")
        Focus._lastActivateAt = nil
    end)
end)

TS:Register("Simplified: Focus Activate returns consumed-state (hit true, empty false)", "simplified", function(self)
    local Focus = GRIPEMS.Focus
    if not (Focus and Focus.PushContext and Focus.PopContext and Focus.Activate and Focus.TopContext) then
        self:Fail("Focus manager API missing")
        return
    end
    local clicked = false
    local widget = {
        IsVisible = function()
            return true
        end,
        IsEnabled = function()
            return true
        end,
        Click = function()
            clicked = true
        end,
    }
    runCase(self, function(a)
        a.simplifiedMode = false
        Focus._listCursor = nil
        Focus:PushContext("focus_ret_spec", { widget }, {})
        Focus:TopContext().cursor = nil
        if Focus:Activate() ~= false then
            error("Activate with no cursor must return false so callers can propagate the key")
        end
        Focus:TopContext().cursor = 1
        if Focus:Activate() ~= true then
            error("Activate on a clickable widget must return true")
        end
        if not clicked then
            error("Activate true-path must have clicked the widget")
        end
    end, function()
        pcall(Focus.PopContext, Focus, "focus_ret_spec")
        Focus._listCursor = nil
    end)
end)

TS:Register("Simplified: accessibilityPresetOn round-trips simplifiedMode/density/uiScale", "simplified", function(self)
    local setPreset, diag = getSetter("accessibility", "general", "accessibilityMode", "toggle")
    if type(setPreset) ~= "function" then
        self:Fail("accessibility.general.accessibilityMode.toggle setter missing -- " .. tostring(diag))
        return
    end
    runCase(self, function(a)
        a.simplifiedMode = false
        a.density = "normal"
        a.uiScale = 1.0
        a.accessibilityPresetOn = false
        a._accessibilityPresetSimplifiedSnapshot = nil
        setPreset({}, true)
        if a.simplifiedMode ~= true then
            error("ON: simplifiedMode expected true, got " .. tostring(a.simplifiedMode))
        end
        if a.density ~= "large" then
            error("ON: density expected 'large', got " .. tostring(a.density))
        end
        if a.uiScale ~= 1.5 then
            error("ON: uiScale expected 1.5, got " .. tostring(a.uiScale))
        end
        local sns = a._accessibilityPresetSimplifiedSnapshot
        if type(sns) ~= "table" then
            error("ON: snapshot table expected, got " .. type(sns))
        end
        if sns.simplified ~= false or sns.density ~= "normal" or sns.scale ~= 1.0 then
            error("ON: snapshot did not capture pre-ON values")
        end
        setPreset({}, false)
        if a.simplifiedMode ~= false or a.density ~= "normal" or a.uiScale ~= 1.0 then
            error("OFF: fields did not restore to pre-ON values")
        end
        if a._accessibilityPresetSimplifiedSnapshot ~= nil then
            error("OFF: snapshot must be cleared, got " .. type(a._accessibilityPresetSimplifiedSnapshot))
        end
    end)
end)

TS:Register("Simplified: density=normal is rejected with toast when simplifiedMode is on", "simplified", function(self)
    local setDensity, diag = getSetter("accessibility", "general", "density", "largeTargets")
    if type(setDensity) ~= "function" then
        self:Fail("accessibility.general.density.largeTargets setter missing -- " .. tostring(diag))
        return
    end
    local captured = {}
    local origPrint = GRIPEMS.Print
    runCase(self, function(a)
        a.simplifiedMode = true
        a.density = "large"
        GRIPEMS.Print = function(_, msg)
            captured[#captured + 1] = msg
        end
        setDensity({}, false)
        if a.density ~= "large" then
            error("density must remain 'large' after rejected setter call, got " .. tostring(a.density))
        end
        local expected = getL()["ACCESS_SIMPLIFIED_DENSITY_REJECT"]
        local hit = false
        for i = 1, #captured do
            if captured[i] == expected then
                hit = true
                break
            end
        end
        if not hit then
            error("expected toast not observed; captured " .. tostring(#captured) .. " line(s)")
        end
    end, function()
        GRIPEMS.Print = origPrint
    end)
end)

TS:Register("Simplified: uiScale rejects sub-1.25 but accepts 1.25 and 1.75", "simplified", function(self)
    local setScale, diag = getSetter("accessibility", "general", "theming", "uiScale")
    if type(setScale) ~= "function" then
        self:Fail("accessibility.general.theming.uiScale setter missing -- " .. tostring(diag))
        return
    end
    local origPrint = GRIPEMS.Print
    runCase(self, function(a)
        a.simplifiedMode = true
        a.uiScale = 1.5
        GRIPEMS.Print = function() end
        setScale({}, 0.9)
        if a.uiScale ~= 1.5 then
            error("uiScale=0.9 must be rejected; expected 1.5, got " .. tostring(a.uiScale))
        end
        setScale({}, 1.25)
        if math.abs((a.uiScale or 0) - 1.25) > 1e-6 then
            error("uiScale=1.25 must be accepted; got " .. tostring(a.uiScale))
        end
        setScale({}, 1.75)
        if math.abs((a.uiScale or 0) - 1.75) > 1e-6 then
            error("uiScale=1.75 must be accepted; got " .. tostring(a.uiScale))
        end
    end, function()
        GRIPEMS.Print = origPrint
    end)
end)

-- end of Test/simplified_mode_spec.lua
