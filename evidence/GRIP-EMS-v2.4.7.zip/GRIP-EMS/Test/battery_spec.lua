-- GRIP-EMS: Test spec for the release-gate battery (v2.3.6 Phase 7)
--
-- Created:    2026-07-10
-- Updated:    2026-08-17
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
--
-- Registers 14 tests in TestSuite under category "battery" covering the
-- structurally assertable release gates: junk-entry compilation, malformed
-- field shapes, repair analysis of corrupt trees, heal semantics, injected
-- probe sequences, signature verification, simplified-mode restore and
-- unlock, colorize round-trip plus the large-buffer gate, the stacking
-- mask cvar write path, the raw serializer sparse-key round-trip, the
-- quick-edit re-sign flush, and the in-place step-function body rebuild.
-- Run in-game with /gems test battery.

local ADDON_NAME, GRIPEMS = ...
local TS = GRIPEMS.TestSuite
if not TS then
    return
end

local function accProfile()
    local s = GRIPEMS.Settings
    return s and s.db and s.db.profile and s.db.profile.accessibility
end

-- Two well-formed interleave actions with junk entries between them. A
-- number and a boolean in the array are the malformed shapes a corrupt
-- import or a hand-edited SavedVariables file produces.
local function junkActions()
    return {
        { type = "action", macro = "/cast Arcane Shot", macroTagged = "/cast Arcane Shot", interval = 2 },
        5,
        true,
        { type = "action", macro = "/cast Steady Shot", macroTagged = "/cast Steady Shot", interval = 2 },
    }
end

-- One node per malformed field shape (string repeat, scalar children,
-- boolean clicks) plus one valid action node.
local function shapeActions()
    return {
        { type = "loop", ["repeat"] = "x", children = { { type = "action", macro = "/cast Arcane Shot" } } },
        { type = "loop", children = 7 },
        { type = "pause", clicks = true },
        { type = "action", macro = "/cast Steady Shot" },
    }
end

-- Reused across runs: WoW frames are never destroyed, so a per-run
-- CreateFrame would leak one dead frame per battery execution.
local maskWatcher

local function stepsContain(steps, needle)
    for _, step in ipairs(type(steps) == "table" and steps or {}) do
        if step == needle then
            return true
        end
    end
    return false
end

-- Save/restore for the editor state the simplified-mode cases mutate.
-- Replicates the simplified_mode_spec save/restore pattern locally: the
-- body runs inside pcall, state restores even on assert failure, and the
-- failure re-raises through Fail afterwards. The active tab is restored
-- too: the simplified ON pass force-switches restricted tabs to Steps and
-- persists that choice, so the relayout alone does not put it back.
local function runEditorCase(self, a, SE, body)
    local savedMode = a.simplifiedMode
    local savedUnlock = SE._simplifiedUnlocked
    local savedTab = SE.activeTab
    local ok, err = pcall(body)
    a.simplifiedMode = savedMode
    SE._simplifiedUnlocked = savedUnlock
    pcall(SE.RelayoutSimplified, SE)
    if savedTab and SE.activeTab ~= savedTab and SE.SwitchTab then
        pcall(SE.SwitchTab, SE, savedTab)
    end
    if ok then
        self:Pass()
    else
        self:Fail(tostring(err))
    end
end

TS:Register("battery: junk entries compile to nothing", "battery", function(self)
    local AC = GRIPEMS.ActionCompiler
    if not AC then
        self:Skip("ActionCompiler not loaded")
        return
    end
    local ok, steps = pcall(AC.CompileActions, junkActions(), nil)
    if not ok then
        self:Fail("CompileActions errored: " .. tostring(steps))
        return
    end
    if type(steps) ~= "table" or #steps ~= 2 then
        self:Fail("expected exactly 2 steps, got " .. tostring(type(steps) == "table" and #steps or steps))
        return
    end
    if steps[1] ~= "/cast Arcane Shot" or steps[2] ~= "/cast Steady Shot" then
        self:Fail("macros missing or out of order: " .. tostring(steps[1]) .. " / " .. tostring(steps[2]))
        return
    end
    self:Pass()
end)

TS:Register("battery: field shapes compile without error and report per class", "battery", function(self)
    local AC = GRIPEMS.ActionCompiler
    if not AC then
        self:Skip("ActionCompiler not loaded")
        return
    end
    local actions = shapeActions()
    local ok, steps = pcall(AC.CompileActions, actions, nil)
    if not ok then
        self:Fail("CompileActions errored: " .. tostring(steps))
        return
    end
    if not stepsContain(steps, "/cast Steady Shot") then
        self:Fail("valid action macro missing from compiled steps")
        return
    end
    local okV, validOrErr, errors = pcall(AC.ValidateActions, actions)
    if not okV then
        self:Fail("ValidateActions errored: " .. tostring(validOrErr))
        return
    end
    local invalidType = false
    for _, e in ipairs(type(errors) == "table" and errors or {}) do
        if e:find("invalid type", 1, true) then
            invalidType = true
            break
        end
    end
    if not invalidType then
        self:Fail("expected at least one invalid-type validation error")
        return
    end
    self:Pass()
end)

TS:Register("battery: repair analyzer survives corrupt trees", "battery", function(self)
    local RA = GRIPEMS.RepairAnalyzer
    if not RA then
        self:Skip("RepairAnalyzer not loaded")
        return
    end
    -- Junk scalars in steps alongside the corrupt action tree: CheckLimits
    -- must report them as malformed instead of raising on the length
    -- operator (Lua 5.1 # on a number/boolean errors).
    local seqData = {
        versions = { { actions = shapeActions(), steps = { "/cast Arcane Shot", 42, true } } },
    }
    local ok, issues = pcall(RA.Analyze, RA, seqData, "_TS_BatteryRepair", nil)
    if not ok then
        self:Fail("Analyze errored: " .. tostring(issues))
        return
    end
    if type(issues) ~= "table" or #issues == 0 then
        self:Fail("expected the corrupt tree to report at least one issue")
        return
    end
    local malformed = 0
    for _, issue in ipairs(issues) do
        if issue.title == "Malformed step entry" then
            malformed = malformed + 1
        end
    end
    if malformed ~= 2 then
        self:Fail("expected 2 malformed-step reports, got " .. tostring(malformed))
        return
    end
    self:Pass()
end)

TS:Register("battery: heal semantics drop junk and coerce scalars", "battery", function(self)
    local D = GRIPEMS.Defaults
    if not (D and D.DeepCopyActions and D.SanitizeActionNode) then
        self:Skip("Defaults deep-copy helpers not loaded")
        return
    end
    local healed = D.DeepCopyActions(junkActions())
    if #healed ~= 2 then
        self:Fail("expected exactly 2 table nodes after deep-copy, got " .. tostring(#healed))
        return
    end
    for i, node in ipairs(healed) do
        if type(node) ~= "table" then
            self:Fail("node " .. i .. " is not a table after deep-copy")
            return
        end
    end
    -- SanitizeActionNode semantics (Data/Defaults.lua): numeric fields read
    -- through tonumber and DROP when unconvertible; a non-table children
    -- field DROPS. "x" and true are unconvertible, so repeat and clicks
    -- become nil; a convertible numeric string coerces to a number.
    local shapes = shapeActions()
    D.SanitizeActionNode(shapes[1])
    if shapes[1]["repeat"] ~= nil then
        self:Fail("unconvertible repeat should drop, got " .. tostring(shapes[1]["repeat"]))
        return
    end
    if type(shapes[1].children) ~= "table" then
        self:Fail("well-formed children must survive sanitize")
        return
    end
    D.SanitizeActionNode(shapes[2])
    if shapes[2].children ~= nil then
        self:Fail("scalar children should drop, got " .. tostring(shapes[2].children))
        return
    end
    D.SanitizeActionNode(shapes[3])
    if shapes[3].clicks ~= nil then
        self:Fail("boolean clicks should drop, got " .. tostring(shapes[3].clicks))
        return
    end
    local coerced = { type = "loop", ["repeat"] = "3" }
    D.SanitizeActionNode(coerced)
    if coerced["repeat"] ~= 3 then
        self:Fail("convertible repeat should coerce to a number, got " .. tostring(coerced["repeat"]))
        return
    end
    self:Pass()
end)

TS:Register("battery: injected probe sequences export and analyze clean", "battery", function(self)
    local Engine = GRIPEMS.Engine
    local RA = GRIPEMS.RepairAnalyzer
    if not (Engine and Engine.sequences and RA) then
        self:Skip("Engine or RepairAnalyzer not loaded")
        return
    end
    local probeName = "GRIPProbe EntryJunk"
    local entry = Engine.sequences[probeName]
    if not (entry and entry.data) then
        self:Skip("probe sequences not injected on this install")
        return
    end
    local ok, issues = pcall(RA.Analyze, RA, entry.data, probeName, nil)
    if not ok then
        self:Fail("Analyze errored on probe: " .. tostring(issues))
        return
    end
    local GE = GRIPEMS.GRIPExport
    if GE and GE.Export then
        local okExport, err = pcall(GE.Export, probeName)
        if not okExport then
            self:Fail("Export errored on probe: " .. tostring(err))
            return
        end
    end
    self:Pass()
end)

TS:Register("battery: untouched signature stays verified", "battery", function(self)
    local Engine = GRIPEMS.Engine
    local I = GRIPEMS.Identity
    if not (Engine and Engine.sequences and I and I.VerifySequence) then
        self:Skip("Engine or Identity not loaded")
        return
    end
    -- Deterministic scan order. Candidates are UNTOUCHED signed sequences,
    -- filtered to mirror every non-verdict branch of Identity:VerifySequence:
    -- non-empty originalAuthor and originalSignature (else "unknown" or
    -- "damaged" -- legacy/forge/no-provenance imports carry a non-empty
    -- currentSignatureV2 with an EMPTY originalSignature and are legitimate,
    -- not gate failures), a known-or-empty signatureAlgorithm (a future
    -- scheme degrades to "unknown"), no fork lineage ("forked"), and no
    -- modifier-chain growth ("modified"). A candidate passing this filter
    -- can only verify or report tampering, and tampering IS a gate failure.
    local KNOWN_ALGOS = { ALG_V0_DJB2 = true, ALG_V1_SHA256 = true, ALG_V2_SHA256 = true }
    local names = {}
    for name in pairs(Engine.sequences) do
        names[#names + 1] = name
    end
    table.sort(names)
    local target
    for _, name in ipairs(names) do
        local entry = Engine.sequences[name]
        local data = entry and entry.data
        local algo = data and data.signatureAlgorithm
        if
            data
            and type(data.currentSignatureV2) == "string"
            and data.currentSignatureV2 ~= ""
            and type(data.originalAuthor) == "string"
            and data.originalAuthor ~= ""
            and type(data.originalSignature) == "string"
            and data.originalSignature ~= ""
            and (algo == nil or algo == "" or KNOWN_ALGOS[algo])
            and not name:find("^_TS_")
            and not name:find("^GRIPProbe")
            and not data.forkedFrom
            and (not data.modifierChain or #data.modifierChain <= 1)
        then
            target = data
            break
        end
    end
    if not target then
        self:Skip("no untouched signed sequence on this install")
        return
    end
    local verdict = I:VerifySequence(target)
    if verdict ~= "verified" then
        self:Fail("expected verified, got " .. tostring(verdict))
        return
    end
    self:Pass()
end)

TS:Register("battery: simplified OFF restores the editor surfaces", "battery", function(self)
    local a = accProfile()
    local SE = GRIPEMS.SequenceEditor
    local SLV = GRIPEMS.StepListView
    if not a then
        self:Skip("accessibility profile not loaded")
        return
    end
    if not (SE and SE.RelayoutSimplified) then
        self:Skip("SequenceEditor not loaded")
        return
    end
    if not SE.tabButtons then
        self:Skip("editor not built yet -- open the Sequence Editor once, then re-run /gems test battery")
        return
    end
    runEditorCase(self, a, SE, function()
        a.simplifiedMode = true
        SE._simplifiedUnlocked = false
        SE:RelayoutSimplified()
        if SE.activeTab == "Steps" and SLV and SLV.actionBar and SLV.actionBar:IsShown() then
            error("step action bar must hide while Simplified Mode is on")
        end
        a.simplifiedMode = false
        SE:RelayoutSimplified()
        for name, tab in pairs(SE.tabButtons) do
            if not tab._isActive then
                error("tab " .. tostring(name) .. " must reactivate when Simplified Mode turns off")
            end
        end
        if SE.activeTab == "Steps" and SLV and SLV.actionBar and not SLV.actionBar:IsShown() then
            error("step action bar must show again when Simplified Mode turns off")
        end
    end)
end)

TS:Register("battery: unlock reopens the editor while simplified", "battery", function(self)
    local a = accProfile()
    local SE = GRIPEMS.SequenceEditor
    local SLV = GRIPEMS.StepListView
    if not a then
        self:Skip("accessibility profile not loaded")
        return
    end
    if not (SE and SE.RelayoutSimplified) then
        self:Skip("SequenceEditor not loaded")
        return
    end
    if not (SE.tabButtons and SLV and SLV.editScrollFrame) then
        self:Skip("editor not built yet -- open the Sequence Editor once, then re-run /gems test battery")
        return
    end
    runEditorCase(self, a, SE, function()
        a.simplifiedMode = true
        SE._simplifiedUnlocked = false
        SE:RelayoutSimplified()
        if SLV.editScrollFrame:IsShown() then
            error("edit scroll frame must stay hidden while Simplified Mode is locked")
        end
        if not (SE._simplifiedLockedHint and SE._simplifiedLockedHint:IsShown()) then
            error("locked-edit hint must show while Simplified Mode is locked")
        end
        SE._simplifiedUnlocked = true
        SE:RelayoutSimplified()
        if SE._simplifiedLockedHint and SE._simplifiedLockedHint:IsShown() then
            error("locked-edit hint must hide once the session is unlocked")
        end
        -- The edit area reopens only where reopening is defined: a single
        -- flat-mode step selected on the Steps tab with the edit box built.
        -- Multi-select and outline editing contexts keep the frame hidden
        -- by design, so assert only in the flat single-selection state.
        if
            SE.activeTab == "Steps"
            and not SLV.hasActions
            and SLV.selectedIndex
            and SLV.editBox
            and not (SLV.IsMultiSelect and SLV:IsMultiSelect())
            and not SLV.editScrollFrame:IsShown()
        then
            error("edit scroll frame must show once unlocked with a step selected")
        end
    end)
end)

TS:Register("battery: colorize strip round-trip is lossless", "battery", function(self)
    local SH = GRIPEMS.SyntaxHighlight
    if not (SH and SH.Colorize and SH.Strip) then
        self:Skip("SyntaxHighlight not loaded")
        return
    end
    local small = "return { 1, 2, 3 }"
    local colored = SH:Colorize(small)
    if type(colored) ~= "string" then
        self:Skip("Colorize did not return a string for string input")
        return
    end
    local stripped = SH:Strip(colored)
    if stripped ~= small then
        self:Fail("round-trip not lossless: got '" .. tostring(stripped) .. "'")
        return
    end
    self:Pass()
end)

TS:Register("battery: large-buffer colorize gate holds", "battery", function(self)
    local SH = GRIPEMS.SyntaxHighlight
    local D = GRIPEMS.Defaults
    if not (SH and SH.Colorize) then
        self:Skip("SyntaxHighlight not loaded")
        return
    end
    if not (D and type(D.SH_MAX_COLORIZE_CHARS) == "number") then
        self:Skip("SH_MAX_COLORIZE_CHARS not defined")
        return
    end
    local big = string.rep("a", D.SH_MAX_COLORIZE_CHARS + 5000)
    local out = SH:Colorize(big)
    if out ~= big then
        self:Fail("large buffer must pass through the colorize gate unchanged")
        return
    end
    self:Pass()
end)

TS:Register("battery: in-place step-function flip rebuilds the click body", "battery", function(self)
    if self:_SkipIfCombat() then
        return
    end
    local D = GRIPEMS.Defaults
    local Engine = GRIPEMS.Engine
    local SF = GRIPEMS.StepFunctions
    if not (D and Engine and SF and SF.Sequential and SF.Random) then
        self:Skip("Defaults, Engine, or StepFunctions not loaded")
        return
    end
    local name = "_TS_BatteryBodySwap"
    if Engine.sequences[name] then
        Engine:DeactivateSequence(name)
    end
    local seqData = D.NewSequenceFromTemplate(name, D.TestSequence)
    local ok, err = pcall(function()
        seqData.versions[1].stepFunction = D.STEP_SEQUENTIAL
        Engine:ActivateSequence(name, seqData)
        local entry = Engine.sequences[name]
        if not (entry and entry.data and entry.button) then
            error("sequence not active after ActivateSequence")
        end
        local ver = entry.data.versions and entry.data.versions[1]
        if not ver then
            error("template has no versions[1]")
        end
        if entry.button._emsClickBody ~= SF.Sequential.BuildClickBody() then
            error("activation should wrap and stamp the Sequential body")
        end
        -- In-place mutation, exactly as the step-function dropdown does:
        -- the same table goes back into UpdateSequenceData, so the old/new
        -- comparison cannot see the change -- the wrapped-body check must.
        ver.stepFunction = D.STEP_RANDOM
        Engine:UpdateSequenceData(name, entry.data)
        local rebuilt = Engine.sequences[name]
        if not (rebuilt and rebuilt.button and rebuilt.button._emsClickBody) then
            error("sequence lost its button across the rebuild")
        end
        if rebuilt.button._emsClickBody ~= SF.Random.BuildClickBody() then
            error("in-place Sequential to Random flip did not re-wrap the click body")
        end
    end)
    if Engine.sequences[name] then
        pcall(Engine.DeactivateSequence, Engine, name)
    end
    if ok then
        self:Pass()
    else
        self:Fail(tostring(err))
    end
end)

TS:Register("battery: quick-edit re-sign heals persisted toggles", "battery", function(self)
    if self:_SkipIfCombat() then
        return
    end
    local D = GRIPEMS.Defaults
    local Engine = GRIPEMS.Engine
    local I = GRIPEMS.Identity
    local SE = GRIPEMS.SequenceEditor
    if not (D and Engine and I and I.StampOriginal and I.VerifySequence) then
        self:Skip("Defaults, Engine, or Identity not loaded")
        return
    end
    if not (SE and SE._FlushQuickResign) then
        self:Skip("SequenceEditor quick-resign helper not loaded")
        return
    end
    local name = "_TS_BatteryQuickEdit"
    if Engine.sequences[name] then
        Engine:DeactivateSequence(name)
    end
    local seqData = D.NewSequenceFromTemplate(name, D.TestSequence)
    local ok, err = pcall(function()
        Engine:ActivateSequence(name, seqData)
        local entry = Engine.sequences[name]
        local data = entry and entry.data
        if not data then
            error("sequence not active after ActivateSequence")
        end
        if not data.originalAuthor or data.originalAuthor == "" then
            if not I:StampOriginal(data) then
                error("StampOriginal declined to stamp a fresh sequence")
            end
        end
        local before = I:VerifySequence(data)
        if before ~= "verified" then
            error("fresh stamp should verify, got " .. tostring(before))
        end
        local ver = data.versions and data.versions[1]
        if not ver then
            error("template has no versions[1]")
        end
        -- Simulate the quick persist: mutate signed content in place (as
        -- the step-function dropdown does), then run the flush the
        -- debounce timer runs.
        local sigBefore = data.originalSignatureV2
        ver.stepFunction = ver.stepFunction == "Random" and "Sequential" or "Random"
        SE:_FlushQuickResign(name)
        if data.originalSignatureV2 == sigBefore then
            error("flush must re-sign the owned V2 signature over the new content")
        end
        local verdict = I:VerifySequence(data)
        if verdict ~= "modified" then
            error("quick-edit flush should leave 'modified', got " .. tostring(verdict))
        end
        if not (data.modifierChain and #data.modifierChain == 2) then
            error(
                "expected exactly 2 chain entries after one flush, got "
                    .. tostring(data.modifierChain and #data.modifierChain)
            )
        end
    end)
    if Engine.sequences[name] then
        pcall(Engine.DeactivateSequence, Engine, name)
    end
    if ok then
        self:Pass()
    else
        self:Fail(tostring(err))
    end
end)

TS:Register("battery: raw serializer round-trips sparse tables", "battery", function(self)
    local RT = GRIPEMS.RawTab
    if not (RT and RT.SerializeTable) then
        self:Skip("RawTab not loaded")
        return
    end
    -- stepLabels is stored sparse (a label only at each labeled index) and
    -- is signed content -- the serializer must emit bracketed numeric keys
    -- or a raw Apply silently deletes the labels.
    local fixture = {
        versions = {
            {
                steps = { "/cast Arcane Shot", "/cast Steady Shot" },
                stepLabels = { [1] = "opener", [5] = "finisher" },
            },
        },
        -- A loop node carries a "repeat" field. "repeat" is a Lua reserved
        -- word, so if the serializer emits it as a bare key the whole blob
        -- fails to loadstring -- this actions fixture is the regression guard.
        actions = {
            {
                type = "loop",
                ["repeat"] = 2,
                stepFunction = "Sequential",
                [1] = {
                    type = "action",
                    macro = "/cast Arcane Shot",
                    interval = 2,
                },
            },
        },
    }
    local text = RT:SerializeTable(fixture)
    local fn, parseErr = loadstring("return " .. text)
    if not fn then
        self:Fail("serialized text does not parse: " .. tostring(parseErr))
        return
    end
    local ok, parsed = pcall(fn)
    if not (ok and type(parsed) == "table") then
        self:Fail("parse execution failed: " .. tostring(parsed))
        return
    end
    local ver = parsed.versions and parsed.versions[1]
    if not (ver and type(ver.steps) == "table" and ver.steps[2] == "/cast Steady Shot") then
        self:Fail("dense steps array lost in round-trip")
        return
    end
    local labels = ver.stepLabels
    if type(labels) ~= "table" or labels[1] ~= "opener" or labels[5] ~= "finisher" then
        self:Fail("sparse stepLabels lost in round-trip")
        return
    end
    local labelCount = 0
    for _ in pairs(labels) do
        labelCount = labelCount + 1
    end
    if labelCount ~= 2 then
        self:Fail("expected exactly 2 labels after round-trip, got " .. labelCount)
        return
    end
    -- Reserved-word key guard: the loop node's ["repeat"] must survive and
    -- the nested action child's macro must be byte-exact. A bare "repeat"
    -- key emission makes the fixture above fail to loadstring entirely.
    local loopNode = parsed.actions and parsed.actions[1]
    if type(loopNode) ~= "table" or loopNode["repeat"] ~= 2 then
        self:Fail("loop repeat field lost in round-trip")
        return
    end
    local child = loopNode[1]
    if type(child) ~= "table" or child.macro ~= "/cast Arcane Shot" then
        self:Fail("loop action child macro lost in round-trip")
        return
    end
    self:Pass()
end)

TS:Register("battery: stacking mask reads and writes without taint", "battery", function(self)
    if self:_SkipIfCombat() then
        return
    end
    local D = GRIPEMS.Defaults
    if not (D and D.CvarReadState and D.CvarApply) then
        self:Skip("Defaults cvar helpers not loaded")
        return
    end
    if not (CVarCallbackRegistry and CVarCallbackRegistry.SetCVarBitfieldMask) then
        self:Skip("mask write API absent (pre-12.0.7 client)")
        return
    end
    local rec = { cvar = "nameplateStackingTypes", isMask = true, maskEnum = "NamePlateStackType" }
    local original = D.CvarReadState(rec)
    if type(original) ~= "number" then
        self:Skip("mask read API absent (pre-12.0.7 client)")
        return
    end
    maskWatcher = maskWatcher or CreateFrame("Frame")
    local watcher = maskWatcher
    local blockedEvents = 0
    -- Count only THIS addon's blocked actions: SetCVar dispatches
    -- CVAR_UPDATE synchronously, so an unrelated addon's handler blocked
    -- inside that dispatch must not fail the gate.
    watcher:SetScript("OnEvent", function(_, _, blockedAddon)
        if blockedAddon == ADDON_NAME then
            blockedEvents = blockedEvents + 1
        end
    end)
    watcher:RegisterEvent("ADDON_ACTION_BLOCKED")
    local ok, err = pcall(function()
        local applied = D.CvarApply(rec, original)
        if not applied then
            error("CvarApply reported failure for the mask write")
        end
        local reread = D.CvarReadState(rec)
        if reread ~= original then
            error("mask changed across the write: wrote " .. tostring(original) .. ", read " .. tostring(reread))
        end
        if blockedEvents > 0 then
            error("mask write fired " .. blockedEvents .. " ADDON_ACTION_BLOCKED event(s)")
        end
    end)
    watcher:UnregisterAllEvents()
    watcher:SetScript("OnEvent", nil)
    if ok then
        self:Pass()
    else
        self:Fail(tostring(err))
    end
end)
