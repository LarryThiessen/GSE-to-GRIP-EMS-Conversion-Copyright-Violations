-- GRIP-EMS: Spanish (Latin America) Locale (Machine Translated, Needs Review)
-- All user-facing strings translated to Latin American Spanish (esMX).

local L = LibStub("AceLocale-3.0"):NewLocale("GRIP-EMS", "esMX")
if not L then
    return
end

-- General
L["GRIP - Enhanced Macro Sequencer"] = "GRIP - Secuenciador de Macros Mejorado" -- MT

-- Slash command help
L["GEMS_HELP_HEADER"] = "Comandos disponibles:" -- MT
L["GEMS_HELP_NONE"] = "  /gems - Abrir ventana principal (o mostrar ayuda si la interfaz no está cargada)" -- MT
L["GEMS_HELP_HELP"] = "  /gems help - Este mensaje de ayuda" -- MT
L["GEMS_HELP_CREATE"] = "  /gems create [nombre] - Crear una secuencia de prueba (predeterminado: TestSeq)" -- MT
L["GEMS_HELP_DELETE"] = "  /gems delete <nombre> - Eliminar una secuencia y su macro asociada" -- MT
L["GEMS_HELP_LIST"] = "  /gems list - Listar todas las secuencias activas" -- MT
L["GEMS_HELP_TEST"] = "  /gems test <nombre> - Avanzar paso manualmente (debug)" -- MT
L["GEMS_HELP_RESET"] = "  /gems reset <nombre> - Reiniciar secuencia al paso 1" -- MT
L["GEMS_HELP_DEBUG"] = "  /gems debug - Alternar modo debug" -- MT
L["GEMS_HELP_STATUS"] = "  /gems status - Mostrar estado del motor" -- MT
L["GEMS_HELP_TESTLOCALE"] = "  /gems testlocale - Ejecutar prueba de traducción de locale" -- MT
L["GEMS_HELP_TESTSPELLID"] = "  /gems testspellid - Ejecutar pruebas de resolución de ID de hechizo" -- MT

-- Slash command responses
L["GEMS_VERSION"] = "|cFF00CC66GRIP|r - Enhanced Macro Sequencer |cFFAAAAAAv%s|r" -- MT
L["GEMS_DEBUG_ENABLED"] = "Modo debug |cFF00FF00activado|r." -- MT
L["GEMS_DEBUG_DISABLED"] = "Modo debug |cFFFF4444desactivado|r." -- MT
L["GEMS_UNKNOWN_CMD"] = "Comando desconocido '%s'. Escribe /gems help para ver los comandos disponibles." -- MT

-- Sequence creation/deletion
L["GEMS_CREATED"] = "Secuencia |cFF00FF00'%s'|r creada con %d pasos (%s)." -- MT
L["GEMS_DELETED"] = "Secuencia |cFF00FF00'%s'|r eliminada." -- MT
L["GEMS_ALREADY_EXISTS"] = "La secuencia '%s' ya existe. Elimínala primero con /gems delete %s" -- MT
L["GEMS_NOT_FOUND"] = "Secuencia '%s' no encontrada." -- MT
L["GEMS_DELETE_NEED_NAME"] = "Uso: /gems delete <nombre>" -- MT

-- Sequence list
L["GEMS_LIST_HEADER"] = "Secuencias activas (%d):" -- MT
L["GEMS_LIST_ENTRY"] = "  |cFF00FF00%s|r - %d pasos, paso %d/%d (%s)" -- MT
L["GEMS_LIST_EMPTY"] = "Sin secuencias activas. Usa /gems create para crear una." -- MT

-- Sequence test/reset
L["GEMS_TEST_NEED_NAME"] = "Uso: /gems test <nombre>" -- MT
L["GEMS_TEST_ADVANCED"] = "|cFF00FF00%s|r: avanzado al paso %d/%d." -- MT
L["GEMS_RESET_NEED_NAME"] = "Uso: /gems reset <nombre>" -- MT
L["GEMS_RESET_DONE"] = "|cFF00FF00%s|r: reiniciado al paso 1." -- MT

-- Status
L["GEMS_STATUS_HEADER"] = "--- Estado de GRIP-EMS ---" -- MT
L["GEMS_STATUS_SEQUENCES"] = "Secuencias activas: %d" -- MT
L["GEMS_STATUS_MACROS"] = "Espacios de macro: %d/%d usados por personaje" -- MT
L["GEMS_STATUS_KEYDOWN"] = "ActionButtonUseKeyDown: %s (botones anulados: verdadero)" -- MT
L["GEMS_STATUS_SQW"] = "SpellQueueWindow: %s ms" -- MT
L["GEMS_STATUS_OOC"] = "Cola OOC: %d pendiente" -- MT

-- Step function descriptions
L["GEMS_STEPFUNC_SEQUENTIAL_DESC"] = "Cicla a través de los pasos en orden: 1, 2, 3, ..., N, 1, ..." -- MT
L["GEMS_STEPFUNC_RANDOM_DESC"] = "Elige un paso aleatorio cada pulsación" -- MT
L["GEMS_STEPFUNC_PRIORITY_DESC"] = "Prioridad pre-expandida: los pasos superiores aparecen más a menudo (round-robin ponderado)" -- MT
L["GEMS_STEPFUNC_REVERSEPRIORITY_DESC"] =
    "Inverted priority: later steps (bottom of list) fire more often than earlier ones"

-- Validation errors
L["GEMS_STEP_TOO_LONG"] = "El paso %d excede el límite de texto de macro (%d caracteres, máximo %d)." -- MT
L["GEMS_STEP_NIL"] = "El paso %d es nulo." -- MT
L["GEMS_ERR_NO_NAME"] = "El nombre de la secuencia es obligatorio." -- MT

-- Macro manager
L["GEMS_ERR_NO_MACRO_SLOTS"] = "Sin espacios de macro disponibles (%d/%d macros por personaje usadas)." -- MT
L["GEMS_ERR_MACRO_CREATE_FAILED"] = "No se pudo crear la macro asociada para la secuencia '%s'." -- MT
L["GEMS_MACRO_CREATED"] = "Macro asociada '%s' creada (espacio %d)." -- MT
L["GEMS_MACROS_SCANNED"] = "Recuperadas %d macros asociadas existentes de GRIP-EMS." -- MT
L["GEMS_WARN_KP_LINES_TRIMMED"] = "keyPress: %d de %d líneas caben en la macro asociada (límite de 255 caracteres)" -- MT
L["GEMS_WARN_KR_LINES_TRIMMED"] = "keyRelease: %d de %d líneas caben en la macro asociada (límite de 255 caracteres)" -- MT
L["GEMS_WARN_KP_STEP_OVERFLOW"] = "keyPress: cabe en %d/%d pasos (%d pasos se ejecutan sin keyPress debido al límite de 255 caracteres)" -- MT
L["GEMS_KP_STATUS_ALL_FIT"] = "Cabe en todos los %d pasos" -- MT
L["GEMS_KP_STATUS_PARTIAL"] = "Cabe en %d/%d pasos (límite de 255 caracteres)" -- MT
L["GEMS_KP_STATUS_NONE"] = "Demasiado largo para cualquier paso (0/%d)" -- MT

-- OOC Queue
L["GEMS_OOC_QUEUED"] = "Operación en cola para procesamiento fuera de combate." -- MT
L["GEMS_OOC_PROCESSED"] = "Se procesaron %d operaciones en cola." -- MT
L["GEMS_OOC_REPLACED"] = "Cola OOC: reemplazado %s por %s" -- MT
L["GEMS_OOC_PRIORITY_PROCESSED"] = "Cola OOC: procesados %d elementos (orden de prioridad)" -- MT

-- Keybind manager
L["GEMS_HELP_BIND"] = "  /gems bind <nombre> <tecla> - Asignar una tecla para disparar una secuencia (p. ej. CTRL-F12)" -- MT
L["GEMS_HELP_UNBIND"] = "  /gems unbind <nombre> - Eliminar la asignación de tecla de una secuencia" -- MT
L["GEMS_HELP_BINDS"] = "  /gems binds - Listar todas las asignaciones de teclas para la especialización actual" -- MT
L["GEMS_BIND_SUCCESS"] = "Asignado |cFF00FF00'%s'|r a |cFFFFFF00%s|r. Presiona la tecla para disparar la secuencia." -- MT
L["GEMS_BIND_NEED_ARGS"] = "Uso: /gems bind <nombre> <tecla> (p. ej. /gems bind TestSeq CTRL-F12)" -- MT
L["GEMS_UNBIND_SUCCESS"] = "Desasignado |cFF00FF00'%s'|r." -- MT
L["GEMS_UNBIND_NO_BIND"] = "La secuencia '%s' no tiene asignación de tecla." -- MT
L["GEMS_UNBIND_NEED_NAME"] = "Uso: /gems unbind <nombre>" -- MT
L["GEMS_BINDS_HEADER"] = "Asignaciones de teclas (especialización %d):" -- MT
L["GEMS_BINDS_ENTRY"] = "  |cFFFFFF00%s|r -> |cFF00FF00%s|r" -- MT
L["GEMS_BINDS_EMPTY"] = "Sin asignaciones de teclas. Usa /gems bind <nombre> <tecla>." -- MT
L["GEMS_KEYBINDS_LOADED"] = "Cargadas %d asignaciones de teclas para la especialización %d." -- MT
L["GEMS_STATUS_KEYBINDS"] = "Keybindings: %d for current spec" -- MT

-- Import/Export
L["GEMS_HELP_IMPORT"] = "  /gems import - Open import window (paste export strings)" -- MT
L["GEMS_HELP_EXPORT"] = "  /gems export <name> - Export a sequence as GRIP string" -- MT
L["GEMS_IMPORT_ENTRY"] = "  - '%s' (%d steps)" -- MT
L["GEMS_IMPORT_FAILED"] = "Import failed: %s" -- MT
L["GEMS_IMPORT_WARNING"] = "Warning: %s" -- MT
L["GEMS_IMPORT_USAGE"] = "Usage: /gems import (opens paste window for export strings)" -- MT
L["GEMS_EXPORT_USAGE"] = "Usage: /gems export <name>" -- MT
L["GEMS_EXPORT_RESULT"] = "Export: %s" -- MT
L["GEMS_EXPORT_FAILED"] = "Export failed: %s" -- MT
L["GEMS_IMPORT_PASTE_INSTRUCTIONS"] = "Paste an export string below, then click Import." -- MT
L["GEMS_IMPORT_PASTE_LABEL"] = "Export String" -- MT
L["GEMS_IMPORT_CLEAR"] = "Clear" -- MT
L["GEMS_IMPORT_SHORT_STRING"] = "Hint: Use /gems import (no args) to open the paste window for long strings." -- MT
L["GEMS_IMPORT_USE_FRAME"] =
    "Tip: The string may have been truncated. Use |cFFFFFF00/gems import|r to open the paste window."
L["GEMS_IMPORT_UNKNOWN_FORMAT"] = "Unknown import format" -- MT
L["GEMS_IMPORT_ACTION_SKIPPED"] = "Skipped action: %s" -- MT
L["GEMS_IMPORT_EMBED_SKIPPED"] = "Embedded sequence '%s' skipped (not available)" -- MT
L["GEMS_IMPORT_PAUSE_CONVERTED"] = "Pause converted to %d empty step(s)" -- MT
L["GEMS_IMPORT_INTERVAL_PRESERVED"] = "Preserved %d interleave action(s)" -- MT
L["GEMS_ACTION_INTERLEAVE_EVERY"] = "Every:" -- MT
L["GEMS_ACTION_INTERLEAVE_STEPS"] = "steps" -- MT

-- UI strings (Phase 3)
L["GEMS_HELP_OPEN"] = "  /gems open - Open/close the main window" -- MT
L["GEMS_UI_TITLE"] = "GRIP-EMS" -- MT
L["GEMS_UI_SELECT_SEQUENCE"] = "Select a sequence to edit" -- MT
L["GEMS_UI_SEQUENCE_LIST_PLACEHOLDER"] = "Sequence list loading..." -- MT
L["GEMS_UI_NO_SEQUENCES"] = "No sequences found. Create one or import." -- MT
L["GEMS_UI_RESIZE"] = "Resize" -- MT
L["GEMS_UI_RESIZE_DESC"] = "Drag to resize the window" -- MT
L["GEMS_UI_MINIMAP_LEFT"] = "Left-click: Open/Close" -- MT
L["GEMS_UI_MINIMAP_RIGHT"] = "Right-click: Quick menu" -- MT
L["GEMS_UI_MINIMAP_RIGHTCLICK_SOON"] = "Right-click quick menu coming soon." -- MT
L["GEMS_UI_MINIMAP_OOC_QUEUE"] = "OOC Queue" -- MT
L["GEMS_UI_MINIMAP_OOC_PENDING"] = "%d pending" -- MT
L["GEMS_UI_MINIMAP_PARTY_USERS"] = "Party Users" -- MT
L["GEMS_UI_MINIMAP_PARTY_NONE"] = "none detected" -- MT

-- UI strings (Phase 3A-2): Search
L["GEMS_UI_SEARCH"] = "Search..." -- MT
L["GEMS_UI_SEARCH_DESC"] = "Filter sequences by name" -- MT

-- UI strings (Phase 3A-2): Buttons
L["GEMS_UI_NEW"] = "New" -- MT
L["GEMS_UI_NEW_DESC"] = "Create a new sequence" -- MT
L["GEMS_UI_IMPORT_BTN"] = "Import" -- MT
L["GEMS_UI_IMPORT_BTN_DESC"] = "Import a sequence from an export string" -- MT

-- UI strings (Phase 3A-2): Context menu
L["GEMS_UI_DUPLICATE"] = "Duplicate" -- MT
L["GEMS_UI_DELETE"] = "Delete" -- MT
L["GEMS_UI_EXPORT_CTX"] = "Export" -- MT
L["GEMS_UI_RENAME"] = "Rename" -- MT

-- UI strings (Phase 3A-2): Editor header
L["GEMS_UI_SEQ_ICON"] = "Icon" -- MT
L["GEMS_UI_STEP_FUNCTION"] = "Step Function" -- MT
L["GEMS_UI_RESET_COMBAT"] = "Reset on Combat End" -- MT
L["GEMS_UI_RESET_COMBAT_DESC"] = "Reset step counter when combat ends" -- MT
L["GEMS_UI_RESET_TARGET"] = "Reset on Target Change" -- MT
L["GEMS_UI_RESET_TARGET_DESC"] = "Reset step counter when target changes (out of combat only)" -- MT
L["GEMS_UI_RESET_GEAR"] = "Gear Change" -- MT
L["GEMS_UI_RESET_GEAR_DESC"] = "Reset step counter when equipment changes (out of combat only)" -- MT
L["GEMS_UI_RESET_SPEC"] = "Spec Change" -- MT
L["GEMS_UI_RESET_SPEC_DESC"] = "Reset step counter when specialization changes" -- MT
L["GEMS_UI_RESET_TIMER"] = "Timer (sec)" -- MT
L["GEMS_UI_RESET_TIMER_DESC"] = "Reset step counter after this many seconds of inactivity (0 = disabled)" -- MT
L["GEMS_UI_KEYPRESS"] = "KeyPress" -- MT
L["GEMS_UI_KEYPRESS_DESC"] =
    "Commands that run on key-down, before each step fires (e.g. /stopmacro [channeling]). Combined into each step's macrotext when the total fits within 255 characters. Steps that exceed the limit run without KeyPress -- check the Preview tab to see which steps fit."
L["GEMS_UI_KEYRELEASE"] = "KeyRelease" -- MT
L["GEMS_UI_KEYRELEASE_DESC"] =
    "Commands that run on key-up, after each step fires. Combined into each step's macrotext when the total fits within 255 characters. Steps that exceed the limit run without KeyRelease -- check the Preview tab to see which steps fit."

-- UI strings: Metadata section
L["GEMS_EDITOR_METADATA"] = "Metadata" -- MT
L["GEMS_EDITOR_METADATA_AUTHOR"] = "Author" -- MT
L["GEMS_EDITOR_METADATA_DESCRIPTION"] = "Description" -- MT
L["GEMS_EDITOR_METADATA_HELP"] = "Help Text" -- MT
L["GEMS_EDITOR_METADATA_HELPLINK"] = "Help Link" -- MT
L["GEMS_EDITOR_METADATA_CLASS"] = "Class" -- MT
L["GEMS_EDITOR_METADATA_SPEC"] = "Spec" -- MT
L["GEMS_EDITOR_METADATA_CREATED"] = "Created" -- MT
L["GEMS_EDITOR_METADATA_UPDATED"] = "Updated" -- MT

-- UI strings: Dependencies section
L["GEMS_DEPS_HEADER"] = "Dependencies" -- MT
L["GEMS_DEPS_VARIABLES"] = "Variables" -- MT
L["GEMS_DEPS_SEQUENCES"] = "Sequences" -- MT
L["GEMS_DEPS_EMBEDDED_BY"] = "Embedded By" -- MT
L["GEMS_DEPS_NONE"] = "(none)" -- MT
L["GEMS_DEPS_NOT_EMBEDDED"] = "Not embedded by any sequence" -- MT

-- UI strings (Phase 3A-2): Tabs
L["GEMS_UI_TAB_STEPS"] = "Steps" -- MT
L["GEMS_UI_TAB_KEYBIND"] = "Keybind" -- MT
L["GEMS_UI_TAB_VARIABLES"] = "Variables" -- MT
L["GEMS_UI_TAB_RAW"] = "Raw" -- MT
L["GEMS_UI_TAB_COMING_SOON"] = "Coming soon" -- MT

-- UI strings (Phase 3A-2): Step list
L["GEMS_UI_STEP_NUM"] = "#%d" -- MT
L["GEMS_UI_NO_STEPS"] = "No steps defined." -- MT
L["GEMS_UI_ADD_STEP_HINT"] = "No steps. Click '+ Add' to create one." -- MT

-- UI strings (Phase 3A-2): Dialogs
L["GEMS_UI_NEW_SEQ_DESC"] = "Enter a name for the new sequence:" -- MT
L["GEMS_UI_DELETE_CONFIRM"] = "Are you sure you want to delete '%s'? This cannot be undone." -- MT
L["GEMS_UI_DUP_DESC"] = "Enter a name for the duplicate:" -- MT
L["GEMS_UI_RENAME_DESC"] = "Enter the new name:" -- MT
L["GEMS_UI_NAME_EXISTS"] = "A sequence named '%s' already exists." -- MT
L["GEMS_UI_NAME_EMPTY"] = "Sequence name cannot be empty." -- MT

-- UI strings (Phase 3A-2): Status text in rows
L["GEMS_UI_ROW_SUBTITLE"] = "%s | %d steps" -- MT

-- UI strings (Phase 3A-2): Sort
L["GEMS_UI_SORT_ALPHA"] = "A-Z" -- MT
L["GEMS_UI_SORT_CLASS"] = "Class" -- MT
L["GEMS_UI_SORT_UPDATED"] = "Recent" -- MT
L["GEMS_UI_SORT_ALPHA_TIP"] = "Alphabetical" -- MT
L["GEMS_UI_SORT_CLASS_TIP"] = "By Class" -- MT
L["GEMS_UI_SORT_UPDATED_TIP"] = "Recently Updated" -- MT
L["GEMS_UI_SORT_HINT"] = "Sort" -- MT
L["GEMS_UI_SORT_CYCLE"] = "Click to cycle sort mode" -- MT

-- Spell validation (v1.1.0)
L["GEMS_SPELL_WARN_BANNER"] = "%d spell(s) may be invalid in this sequence" -- MT
L["GEMS_SPELL_VALIDATE_SUMMARY"] = "%d sequence(s) checked: %d clean, %d with warnings" -- MT
L["GEMS_SPELL_VALIDATE_CLEAN"] = "All sequences validated -- no issues found" -- MT
L["GEMS_SPELL_VALIDATE_SEQ"] = "  %s: %d unknown, %d talent-gated" -- MT
L["GEMS_SPELL_STATUS_LABEL"] = "%d spell(s) may be invalid" -- MT
L["GEMS_SPELL_INFO_LABEL"] = "%d known but unlearned" -- MT
L["GEMS_IMPORT_FREEFORM_WARN"] =
    "'%s': %d step(s) contain raw macro commands that cannot be auto-translated across locales"
L["GEMS_IMPORT_FREEFORM_LABEL"] = "%d freeform" -- MT
L["GEMS_IMPORT_ICON_AUTO"] = "(auto-detected)" -- MT
L["GEMS_IMPORT_PICK_AUTO"] = "[auto]" -- MT
L["GEMS_IMPORT_PICK_VAR_DEPS"] = "Uses %d vars" -- MT
L["GEMS_SPELL_TOOLTIP_UNKNOWN"] = "Not found: %s" -- MT
L["GEMS_SPELL_TOOLTIP_KNOWN"] = "Not in spellbook: %s" -- MT
L["GEMS_SPELL_TOOLTIP_COSMETIC"] = "|cff888888#showtooltip: %s|r" -- MT

-- Rotation Preview (v1.1.0)
L["GEMS_PLUGIN_LOADED"] = "Plugin sequences loaded for: %s" -- MT
L["GEMS_PLUGIN_NOT_FOUND"] = "Plugin not registered: %s" -- MT
L["GEMS_PLUGIN_REGISTERED"] = "Plugin registered: %s v%s (%d sequences)" -- MT
L["GEMS_PLUGIN_SKIP_EXISTS"] = "Plugin %s: skipping '%s' (user version exists)" -- MT

L["GEMS_PREVIEW_ICONS"] = "Icons" -- MT
L["GEMS_PREVIEW_TEXT"] = "Text" -- MT
L["GEMS_PREVIEW_TOGGLE_TIP"] = "Switch preview mode" -- MT
L["GEMS_PREVIEW_RANDOM_HINT"] = "Random -- any of these may execute" -- MT
L["GEMS_PREVIEW_STEP_TOOLTIP"] = "Step %d: %s" -- MT
L["GEMS_PREVIEW_SPELL_TOOLTIP"] = "Spell: %s" -- MT
L["GEMS_PREVIEW_COMPILED"] = "Compiled" -- MT
L["GEMS_PREVIEW_COMPILED_TIP"] = "Show compiled macrotext per step (what WoW executes)" -- MT
L["GEMS_PREVIEW_KP_FIT"] = "%d/%d steps fit keyPress+keyRelease" -- MT
L["GEMS_PREVIEW_KP_DROPPED"] = "Steps in red had keyPress/keyRelease dropped (overflow)" -- MT
L["GEMS_PREVIEW_COPY"] = "Copy" -- MT
L["GEMS_PREVIEW_COPY_TIP"] = "Copy rotation preview to clipboard" -- MT

-- UI strings (Phase 3A-2): Editor misc
L["GEMS_UI_ICON_HINT"] = "Click to change icon" -- MT
L["GEMS_UI_DUPLICATE_FAILED"] = "Duplicate failed." -- MT
L["GEMS_UI_COPY_SUFFIX"] = "_copy" -- MT

-- UI strings (Phase 3A-2): Step function labels
L["GEMS_UI_SF_SEQUENTIAL"] = "Sequential" -- MT
L["GEMS_UI_SF_RANDOM"] = "Random" -- MT
L["GEMS_UI_SF_PRIORITY"] = "Priority" -- MT
L["GEMS_UI_SF_REVERSEPRIORITY"] = "Rev. Priority" -- MT

-- UI strings (Phase 3B-1): Step editor
L["GEMS_UI_ADD_STEP"] = "+ Add" -- MT
L["GEMS_UI_ADD_STEP_DESC"] = "Add a new empty step after the selected step" -- MT
L["GEMS_UI_DUP_STEP"] = "Dup" -- MT
L["GEMS_UI_DUP_STEP_DESC"] = "Duplicate the selected step" -- MT
L["GEMS_UI_MOVE_UP"] = "Up" -- MT
L["GEMS_UI_MOVE_UP_DESC"] = "Move the selected step up" -- MT
L["GEMS_UI_MOVE_DOWN"] = "Down" -- MT
L["GEMS_UI_MOVE_DOWN_DESC"] = "Move the selected step down" -- MT
L["GEMS_UI_DEL_STEP"] = "Del" -- MT
L["GEMS_UI_DEL_STEP_DESC"] = "Delete the selected step" -- MT
L["GEMS_UI_STEP_HEADER"] = "Step %d:" -- MT
L["GEMS_UI_SELECT_STEP"] = "Select a step to edit" -- MT
L["GEMS_UI_DELETE_STEP_CONFIRM"] = "Delete step %d? This cannot be undone." -- MT
L["GEMS_UI_CTX_DUP_STEP"] = "Duplicate Step" -- MT
L["GEMS_UI_CTX_MOVE_UP"] = "Move Up" -- MT
L["GEMS_UI_CTX_MOVE_DOWN"] = "Move Down" -- MT
L["GEMS_UI_CTX_DELETE_STEP"] = "Delete Step" -- MT
L["GEMS_UI_DRAG_HANDLE_DESC"] = "Drag to reorder" -- MT
L["GEMS_UI_EXPORT_BTN_EDITOR"] = "Export" -- MT
L["GEMS_UI_EXPORT_BTN_EDITOR_DESC"] = "Export this sequence as a GRIP string" -- MT
L["GEMS_UI_NAME_TOOLTIP"] = "Sequence Name" -- MT
L["GEMS_UI_NAME_EDIT_HINT"] = "Click to rename. Press Enter to confirm, Escape to cancel." -- MT
L["GEMS_UI_SAVE_PROMPT"] = "Save changes to '%s'?" -- MT
L["GEMS_UI_SAVE"] = "Save" -- MT
L["GEMS_UI_SAVE_BTN_DESC"] = "Save changes to this sequence" -- MT
L["GEMS_UI_DISCARD"] = "Discard" -- MT
L["GEMS_UI_DISCARD_BTN_DESC"] = "Discard changes and revert to last saved state" -- MT
L["GEMS_UI_SAVE_COMBAT"] = "Unavailable in combat" -- MT

-- Version bar (UX-4)
L["GEMS_VERSION_OF"] = "Version %d of %d" -- MT
L["GEMS_VERSION_LABEL"] = "Version %d" -- MT
L["GEMS_VERSION_DEFAULT_SUFFIX"] = " (Default)" -- MT
L["GEMS_VERSION_DEFAULT_MARKER"] = " (*)" -- MT
L["GEMS_VERSION_TOOLTIP_TITLE"] = "Version" -- MT
L["GEMS_VERSION_TOOLTIP_DESC"] = "Select which version to edit" -- MT
L["GEMS_VERSION_ADD_TITLE"] = "Add Version" -- MT
L["GEMS_VERSION_ADD_DESC"] = "Create a new empty version" -- MT
L["GEMS_VERSION_DUP_TITLE"] = "Duplicate Version" -- MT
L["GEMS_VERSION_DUP_DESC"] = "Copy current version to a new version" -- MT
L["GEMS_VERSION_DEL_TITLE"] = "Delete Version" -- MT
L["GEMS_VERSION_DEL_DESC"] = "Remove current version" -- MT
L["GEMS_VERSION_DEFAULT_TITLE"] = "Set Default" -- MT
L["GEMS_VERSION_DEFAULT_DESC"] = "Make current version the default for execution" -- MT

-- Phase 3B-2: Keybind tab
L["GEMS_UI_CURRENT_KEYBIND"] = "Current Keybind" -- MT
L["GEMS_UI_KEYBIND_DISPLAY_NONE"] = "None" -- MT
L["GEMS_UI_SET_KEYBIND"] = "Set Keybind" -- MT
L["GEMS_UI_CHANGE_KEYBIND"] = "Change" -- MT
L["GEMS_UI_CLEAR_KEYBIND"] = "Clear" -- MT
L["GEMS_UI_PRESS_KEY"] = "Press a key..." -- MT
L["GEMS_UI_KEYBIND_HINT"] =
    "Keybinds are per-spec override bindings stored in your GRIP-EMS profile. They do not modify your WoW keybind settings."
L["GEMS_UI_CAPTURE_COMBAT"] = "Cannot capture keybinds during combat." -- MT
L["GEMS_UI_SPEC_KEYBINDS"] = "Keybinds by Spec" -- MT
L["GEMS_UI_CURRENT_SPEC"] = "(current)" -- MT
L["GEMS_UI_LOADOUT_COMING_SOON"] = "Per-talent-loadout keybinds: coming soon" -- MT
L["GEMS_UI_CAPTURE_ESC_HINT"] = "(Press ESC to cancel)" -- MT
L["GEMS_UI_KEYBIND_CONFLICT"] = "%s was bound to '%s' and has been reassigned." -- MT
L["GEMS_UI_KEYBIND_CP_CONFLICT"] = "%s is bound to '%s' in ConsolePort. It will be overridden during active sequences." -- MT
L["GEMS_UI_GAMEPAD_HINT"] = "Controller detected -- gamepad buttons supported in capture" -- MT

-- Phase 3B-2: Macros tab
L["GEMS_UI_TAB_MACROS"] = "Macros" -- MT
L["GEMS_UI_MACRO_STUB_SECTION"] = "Macro Stub" -- MT
L["GEMS_UI_STUB_INFO"] = "%s (slot %d)" -- MT
L["GEMS_UI_STUB_NONE"] = "No macro stub" -- MT
L["GEMS_UI_SLOTS_USED"] = "%d/%d per-character macro slots used" -- MT
L["GEMS_UI_REFRESH_STUBS"] = "Refresh" -- MT
L["GEMS_UI_REFRESH_STUBS_DESC"] = "Re-scan for existing GRIP-EMS macro stubs" -- MT
L["GEMS_UI_CLEAN_ORPHANS"] = "Clean Orphans" -- MT
L["GEMS_UI_CLEAN_ORPHANS_DESC"] = "Delete macro stubs for sequences that no longer exist" -- MT
L["GEMS_UI_CLEAN_CONFIRM"] = "Delete %d orphan macro stub(s)? This cannot be undone." -- MT
L["GEMS_UI_ORPHANS_CLEANED"] = "Cleaned %d orphan macro stub(s)." -- MT
L["GEMS_UI_NO_ORPHANS"] = "No orphan stubs found." -- MT
L["GEMS_UI_STUB_LIST_HEADER"] = "All Stubs (%d)" -- MT
L["GEMS_UI_NO_STUBS"] = "No macro stubs found." -- MT
L["GEMS_UI_STUBS_MORE"] = "%d more stub(s) not shown" -- MT

-- Phase 3B-2: Priority preview

-- Phase 3C-1: Spell autocomplete

-- Phase 3C-2: Icon picker
L["GEMS_UI_ICON_PICKER_TITLE"] = "Choose Icon" -- MT
L["GEMS_UI_AUTO_DETECT"] = "Auto-Detect" -- MT
L["GEMS_UI_AUTO_DETECT_DESC"] = "Automatically detect icon from the first /cast spell" -- MT

-- Context version selection (T2-1)
L["GEMS_CONTEXT_CHANGED"] = "Context changed: %s" -- MT
L["GEMS_CONTEXT_NONE_LABEL"] = "None" -- MT
L["GEMS_CONTEXT_RELOAD"] = "Context switch reloaded %d sequence(s)" -- MT

-- Context tab (T2-1b)
L["GEMS_UI_TAB_CONTEXT"] = "Context" -- MT
L["GEMS_CONTEXT_DEFAULT_LABEL"] = "Default Version: %d" -- MT
L["GEMS_CONTEXT_CURRENT_INFO"] = "Current Context: %s" -- MT
L["GEMS_CONTEXT_VIEWING"] = "Assignments for Version %d" -- MT
L["GEMS_CONTEXT_NO_VERSIONS"] = "Add a second version to configure context overrides." -- MT
L["GEMS_CONTEXT_HINT"] =
    "Check the content types where this version should be active. Unchecked contexts fall back to broader categories (e.g. Mythic+ falls back to Dungeon, then Default)."
L["GEMS_CONTEXT_CONFLICT_MSG"] = "%s is currently assigned to Version %d.\nReassign to Version %d?" -- MT
L["GEMS_CONTEXT_ASSIGNED_OTHER"] = "(Version %d)" -- MT
L["GEMS_CONTEXT_GROUP_RAIDS"] = "Raids" -- MT
L["GEMS_CONTEXT_GROUP_DUNGEONS"] = "Dungeons" -- MT
L["GEMS_CONTEXT_GROUP_PVP"] = "PvP" -- MT
L["GEMS_CONTEXT_GROUP_ARENA_MAPS"] = "Arena Maps" -- MT
L["GEMS_CONTEXT_GROUP_BG_MAPS"] = "Battleground Maps" -- MT
L["GEMS_CONTEXT_GROUP_OTHER"] = "Other" -- MT
L["GEMS_CONTEXT_WRONG_VERSION"] = "%s is assigned to Version %d. Switch to that version to modify it." -- MT

-- Context group buttons and fallback chain (v1.2.0 S19)
L["GEMS_CONTEXT_SELECT_ALL"] = "All" -- MT
L["GEMS_CONTEXT_CLEAR_ALL"] = "None" -- MT
L["GEMS_CONTEXT_FALLBACK_NONE"] = "No active context -- Default Version %d" -- MT
L["GEMS_CONTEXT_FALLBACK_MATCH"] = " (v%d)" -- MT
L["GEMS_CONTEXT_FALLBACK_DEFAULT"] = "Default" -- MT
L["GEMS_CONTEXT_FALLBACK_SEP"] = " > " -- MT
L["GEMS_SETTINGS_CONTEXT_HEADER"] = "Context Detection" -- MT
L["GEMS_SETTINGS_CONTEXT_DESC"] = "Configure how the addon detects content type for automatic version switching." -- MT
L["GEMS_SETTINGS_MPLUS_MID"] = "Mythic+ Mid Tier" -- MT
L["GEMS_SETTINGS_MPLUS_MID_DESC"] = "Key level where Mythic+ context switches from Low to Mid tier." -- MT
L["GEMS_SETTINGS_MPLUS_HIGH"] = "Mythic+ High Tier" -- MT
L["GEMS_SETTINGS_MPLUS_HIGH_DESC"] = "Key level where Mythic+ context switches from Mid to High tier." -- MT
L["GEMS_SETTINGS_DELVES_HIGH"] = "Delves High Tier" -- MT
L["GEMS_SETTINGS_DELVES_HIGH_DESC"] = "Delve tier where context switches from Low to High." -- MT

-- Context migration (T2-3)

-- Phase 2B: Migration
L["GEMS_HELP_MIGRATE"] = "  /gems migrate - Migrate sequences from another sequencer" -- MT
L["GEMS_UI_MIGRATE_BTN"] = "Migrate" -- MT
L["GEMS_UI_MIGRATE_BTN_DESC"] = "Import all sequences from another sequencer" -- MT
L["GEMS_MIGRATE_NO_SOURCE"] = "No compatible sequencer found for migration." -- MT
L["GEMS_MIGRATE_SOURCE_DISABLED"] =
    "A compatible sequencer was found but is disabled. Enable it in the AddOns list and /reload to migrate."
L["GEMS_MIGRATE_FAILED"] = "Migration failed: %s" -- MT
L["GEMS_MIGRATE_CONFIRM"] =
    "Migrate all sequences from your previous sequencer?\n\nFound %d sequences. Existing sequences with the same name will be skipped."
L["GEMS_DELETE_COMBAT"] = "Cannot delete sequences during combat." -- MT
L["GEMS_MIGRATE_COMBAT"] = "Cannot migrate during combat. Try again after combat." -- MT
L["GEMS_MIGRATE_EMPTY"] = "No sequences found in source library." -- MT
L["GEMS_MIGRATE_SKIPPED"] = "%s (already exists, skipped)" -- MT
L["GEMS_MIGRATE_KEYBINDS"] = "Keybinds: %d migrated, %d skipped, %d conflicts" -- MT
L["GEMS_MIGRATE_AO_WARNING"] =
    "%d action bar overrides found but not migrated. EMS uses keybind overrides. Rebind these sequences via /gems bind."

-- Phase 2C: Export frame
L["GEMS_EXPORT_FRAME_LABEL"] = "Exported: %s" -- MT
L["GEMS_EXPORT_FRAME_HINT"] = "Press Ctrl+C to copy, then paste into another player's import window." -- MT

-- Phase 3C-3: Variable system
L["GEMS_VAR_EVAL_ERROR"] = "Variable '%s' evaluation failed: %s" -- MT
L["GEMS_VAR_INVALID_NAME"] = "Variable name must be alphanumeric (a-z, 0-9, underscore)" -- MT
L["GEMS_VAR_NAME_TOO_LONG"] = "Variable name exceeds %d characters" -- MT
L["GEMS_VAR_FUNC_TOO_LONG"] = "Variable function exceeds %d characters" -- MT
L["GEMS_VAR_NAME_EMPTY"] = "Variable name cannot be empty" -- MT
L["GEMS_VAR_NAME_EXISTS"] = "Variable '%s' already exists" -- MT
L["GEMS_VAR_DELETED"] = "Variable '%s' deleted" -- MT
L["GEMS_VAR_SAVED"] = "Variable '%s' saved" -- MT
L["GEMS_VAR_IMPORT_PAUSE"] = "Pause with variable converted to comment" -- MT
L["GEMS_VAR_IMPORT_SKIPPED"] = "Skipped %d variable(s) (already exist)." -- MT
L["GEMS_VAR_RECOMPILE"] = "Recompiling '%s' (variable changed)" -- MT

-- Phase 3C-3b: Variables Tab UI
L["GEMS_VAR_TAB_EMPTY"] = "No variables defined. Click New to create one." -- MT
L["GEMS_VAR_NEW"] = "New Variable" -- MT
L["GEMS_VAR_NAME_LABEL"] = "Name" -- MT
L["GEMS_VAR_FUNC_LABEL"] = "Function Body" -- MT
L["GEMS_VAR_FUNC_PLACEHOLDER"] = "return GetHaste() > 20" -- MT
L["GEMS_VAR_EVENTS_LABEL"] = "Events (comma-separated)" -- MT
L["GEMS_VAR_EVENTS_PLACEHOLDER"] = "SPELL_CAST_SUCCESS, UNIT_AURA" -- MT
L["GEMS_VAR_COMMENTS_LABEL"] = "Comments" -- MT
L["GEMS_VAR_DISABLED_LABEL"] = "Disabled" -- MT
L["GEMS_VAR_SAVE"] = "Save" -- MT
L["GEMS_VAR_TEST"] = "Test" -- MT
L["GEMS_VAR_TEST_RESULT"] = "Variable '%s' = %s" -- MT
L["GEMS_VAR_TEST_ERROR"] = "Variable '%s' error: %s" -- MT
L["GEMS_VAR_VALID"] = "Valid" -- MT
L["GEMS_VAR_INVALID"] = "Error: %s" -- MT
L["GEMS_VAR_USED_BY"] = "Used by: %s" -- MT
L["GEMS_VAR_NOT_USED"] = "Not referenced by any sequence" -- MT
L["GEMS_VAR_DELETE_CONFIRM"] = "Delete variable '%s'?" -- MT
L["GEMS_VAR_DELETE_REFS_WARN"] = "This variable is used by %d sequence(s). Delete anyway?" -- MT
L["GEMS_VAR_RENAME"] = "Rename Variable" -- MT
L["GEMS_VAR_EVENTS_BROWSE"] = "Browse Events" -- MT
L["GEMS_VAR_NEW_DESC"] = "Create a new variable" -- MT
L["GEMS_VAR_SAVE_DESC"] = "Save changes to this variable" -- MT
L["GEMS_VAR_TEST_DESC"] = "Evaluate the function and show the result" -- MT
L["GEMS_VAR_DELETE_DESC"] = "Delete this variable permanently" -- MT
L["GEMS_VAR_EVENTS_BROWSE_TIP"] = "Click to browse available events" -- MT
L["GEMS_VAR_EVENTS_ENABLED_DESC"] =
    "When unchecked, event triggers for this variable are paused. The event list is preserved."
L["GEMS_VAR_LOCALE_WARN"] = "Variable evaluates to spell name '%s'. For locale safety, use: %s" -- MT
L["GEMS_VAR_FUNC_HELP"] =
    "For locale-safe variables, use C_Spell.GetSpellName(spellID) instead of hardcoded spell name strings. Example: C_Spell.GetSpellName(133) instead of 'Fireball'."

-- Raw tab
L["GEMS_RAW_TITLE"] = "Raw Data" -- MT
L["GEMS_RAW_EDIT"] = "Edit" -- MT
L["GEMS_RAW_APPLY"] = "Apply" -- MT
L["GEMS_RAW_CANCEL"] = "Cancel" -- MT
L["GEMS_RAW_INVALID"] = "Invalid: %s" -- MT
L["GEMS_RAW_MISSING_FIELD"] = "Missing required field: %s" -- MT
L["GEMS_RAW_APPLIED"] = "Changes applied" -- MT
L["GEMS_RAW_NAME_IGNORED"] = "Name change ignored. Use Rename from context menu." -- MT
L["GEMS_RAW_NO_SEQUENCE"] = "No sequence selected" -- MT
L["GEMS_RAW_READONLY_HINT"] = "Click Edit to modify. Changes are validated before applying." -- MT
L["GEMS_RAW_CANCEL_DESC"] = "Close without applying changes" -- MT
L["GEMS_RAW_EDIT_DESC"] = "Parse and apply the Lua table as sequence data" -- MT

-- Step action bar (Save + hint)
L["GEMS_STEP_SAVE"] = "Save" -- MT
L["GEMS_STEP_SAVE_DESC"] = "Save all step changes to the sequence" -- MT
L["GEMS_STEP_UNSAVED_HINT"] = "Unsaved changes" -- MT

-- Engine debug
L["GEMS_SEQ_ACTIVATED"] = "Sequence '%s' activated (%d steps)." -- MT
L["GEMS_SEQ_DEACTIVATED"] = "Sequence '%s' deactivated." -- MT
L["GEMS_STEP_RESET"] = "Sequence '%s' step reset to 1." -- MT
L["GEMS_STEP_ADVANCED"] = "Sequence '%s' step advanced to %d/%d." -- MT
L["GEMS_COMBAT_RESET"] = "Sequence '%s' reset (combat drop)." -- MT
L["GEMS_TARGET_RESET"] = "Sequence '%s' reset (target change)." -- MT
L["GEMS_GEAR_RESET"] = "%s: reset on gear change (was step %d, slot %d)." -- MT
L["GEMS_SPEC_RESET"] = "%s: reset on spec change (was step %d)." -- MT
L["GEMS_RESTORED"] = "Restored %d saved sequence(s)." -- MT
L["GEMS_KEYBINDS_SUSPENDED"] = "Keybinds suspended: %s" -- MT
L["GEMS_KEYBINDS_RESTORED"] = "Keybinds restored: %s" -- MT

-- Settings panel (T1-1 + T1-7)
L["GEMS_HELP_SETTINGS"] = "  /gems settings|config|options - Open settings panel" -- MT
L["GEMS_SETTINGS_HEADER_DESC"] = "Configure GRIP - Enhanced Macro Sequencer behavior and display." -- MT
L["GEMS_SETTINGS_GENERAL"] = "General" -- MT
L["GEMS_SETTINGS_OOC_DELAY"] = "OOC Queue Delay (sec)" -- MT
L["GEMS_SETTINGS_OOC_DELAY_DESC"] =
    "Seconds between out-of-combat queue polls. Lower = faster processing of queued operations after combat. Changes take effect after /reload. Default: 7s."
L["GEMS_SETTINGS_RESET_OOC"] = "Reset on Combat End (default)" -- MT
L["GEMS_SETTINGS_RESET_OOC_DESC"] =
    "Default value for 'Reset on Combat End' when creating new sequences. Existing sequences are not affected."
L["GEMS_SETTINGS_UI"] = "Display" -- MT
L["GEMS_SETTINGS_HIDE_LOGIN"] = "Hide Login Message" -- MT
L["GEMS_SETTINGS_HIDE_LOGIN_DESC"] = "Suppress the 'GRIP-EMS vX.X' message on login." -- MT
L["GEMS_SETTINGS_DEBUG"] = "Debug Mode" -- MT
L["GEMS_SETTINGS_DEBUG_DESC"] = "Show debug messages in chat. Also toggleable via /gems debug." -- MT
L["GEMS_SETTINGS_INFO"] = "Info" -- MT
L["GEMS_SETTINGS_VERSION_INFO"] = "GRIP-EMS v%s | %d active sequence(s)" -- MT

-- About info (T1-5)
L["GEMS_ABOUT_AUTHOR"] = "Author: Sataana (MrSataana)" -- MT
L["GEMS_ABOUT_LINKS"] =
    "Guide: jesperlive.github.io/grip-ems-guide/\nCurseForge: curseforge.com/wow/addons/grip-enhanced-macro-sequencer\nWago: addons.wago.io/addons/qGZODqNd\nWoWInterface: wowinterface.com/downloads/info27081"
L["GEMS_ABOUT_KEYBINDS"] = "Active keybinds: %d" -- MT
L["GEMS_ABOUT_OOC_QUEUE"] = "Cola OOC: %d pendiente" -- MT
L["GEMS_ABOUT_SOURCE_STATUS"] = "Migration source: %s" -- MT
L["GEMS_ABOUT_MACRO_SLOTS"] = "Macro slots: %d / %d per-character" -- MT
L["GEMS_UI_ACTIVE_SEQUENCES_LABEL"] = "Active sequences" -- MT
L["GEMS_UI_CONTEXT_LABEL"] = "Context" -- MT
L["GEMS_LOGIN_ACTIVE"] = "|cFF888888  %d active sequence(s)|r" -- MT
L["GEMS_UI_SETTINGS_BTN"] = "Settings" -- MT
L["GEMS_UI_SETTINGS_BTN_DESC"] = "Open GRIP-EMS settings panel" -- MT

-- Migration report (T1-9)
L["GEMS_REPORT_HEADER_MIGRATE"] = "--- GRIP-EMS Migration Report ---" -- MT
L["GEMS_REPORT_HEADER_IMPORT"] = "--- GRIP-EMS Import Report ---" -- MT
L["GEMS_REPORT_IMPORTED"] = "Imported: %d sequence(s), %d variable(s)" -- MT
L["GEMS_REPORT_SKIPPED"] = "Skipped: %d (already exist)" -- MT
L["GEMS_REPORT_SEQ_ENTRY"] = "  + %s (%d steps, %s)" -- MT
L["GEMS_REPORT_LIMITATIONS"] = "Known limitations:" -- MT
L["GEMS_REPORT_VERSIONS_DROPPED"] = "  - %d extra version(s) not imported (only default version supported)" -- MT
L["GEMS_REPORT_PAUSES_CONVERTED"] = "  - %d pause action(s) converted to %d empty step(s)" -- MT
L["GEMS_REPORT_EMBEDS_SKIPPED"] = "  - %d embedded sequence ref(s) skipped (not yet supported)" -- MT
L["GEMS_REPORT_TRUNCATED"] = "  - %d step(s) exceeded 255 chars and were truncated" -- MT
L["GEMS_REPORT_TIP_VERIFY"] = "Tip: Open each migrated sequence and verify steps look correct." -- MT
L["GEMS_REPORT_TIP_VERSIONS"] = "Use /gems to open the editor and configure context version overrides." -- MT

-- Guide (T1-10)
L["GEMS_GUIDE_TITLE"] = "GRIP-EMS Interactive Guide" -- MT
L["GEMS_GUIDE_PATH"] = "Copy this URL and open it in your browser:" -- MT
L["GEMS_GUIDE_TIP"] = "Local file: Interface/AddOns/GRIP-EMS/Guide/GRIP-EMS_Guide.html" -- MT
L["GEMS_GUIDE_URL"] = "https://jesperlive.github.io/grip-ems-guide/" -- MT
L["GEMS_GUIDE_CLICK"] = "|cff4ecca3|HGRIPEMSguide|h[Click here to open GRIP-EMS Guide]|h|r" -- MT
L["GEMS_HELP_GUIDE"] = "  /gems guide - GRIP-EMS Interactive Guide" -- MT

-- Import preview (T2-4)
L["GEMS_IMPORT_PREVIEW_TITLE"] = "Import Preview" -- MT
L["GEMS_IMPORT_PREVIEW_SEQ_HEADER"] = "Sequences (%d)" -- MT
L["GEMS_IMPORT_PREVIEW_VAR_HEADER"] = "Variables (%d)" -- MT
L["GEMS_IMPORT_PREVIEW_NEW"] = "New" -- MT
L["GEMS_IMPORT_PREVIEW_EXISTS"] = "Exists" -- MT
L["GEMS_IMPORT_PREVIEW_IDENTICAL"] = "Identical" -- MT
L["GEMS_IMPORT_PREVIEW_DIFFERENT"] = "Different" -- MT
L["GEMS_IMPORT_PREVIEW_IMPORT_SELECTED"] = "Import Selected (%d)" -- MT
L["GEMS_IMPORT_PREVIEW_CANCEL"] = "Cancel" -- MT
L["GEMS_IMPORT_PREVIEW_SELECT_ALL"] = "Select All" -- MT
L["GEMS_IMPORT_PREVIEW_DESELECT_ALL"] = "Deselect All" -- MT
L["GEMS_IMPORT_PREVIEW_EMPTY"] = "No sequences or variables found in this string." -- MT
L["GEMS_IMPORT_PREVIEW_DESC"] = "Parse the pasted text and show importable sequences" -- MT
L["GEMS_IMPORT_CLEAR_DESC"] = "Clear the paste box" -- MT
L["GEMS_IMPORT_SELECT_ALL_DESC"] = "Select all sequences for import" -- MT
L["GEMS_IMPORT_DESELECT_ALL_DESC"] = "Deselect all sequences" -- MT
L["GEMS_IMPORT_CANCEL_DESC"] = "Return to paste stage" -- MT
L["GEMS_IMPORT_COMMIT_DESC"] = "Import the selected sequences" -- MT
L["GEMS_IMPORT_PREVIEW_SUMMARY"] = "Imported %d sequence(s), %d variable(s)" -- MT
L["GEMS_IMPORT_PREVIEW_BTN"] = "Preview" -- MT
L["GEMS_IMPORT_PREVIEW_HEADER"] = "%d sequences, %d variables" -- MT
L["GEMS_IMPORT_PREVIEW_NEW_COUNT"] = "%d new" -- MT
L["GEMS_IMPORT_PREVIEW_EXISTING_COUNT"] = "%d existing" -- MT
L["GEMS_IMPORT_PREVIEW_INFO"] = "%d versions, %d steps" -- MT
L["GEMS_IMPORT_PREVIEW_ACTION_SKIP"] = "Skip" -- MT
L["GEMS_IMPORT_PREVIEW_ACTION_REPLACE"] = "Replace" -- MT
L["GEMS_IMPORT_PREVIEW_ACTION_RENAME"] = "Rename" -- MT

-- Advanced Export (T2-12)
L["GEMS_EXPORT_PICK_TITLE"] = "Export Sequences" -- MT
L["GEMS_EXPORT_PICK_HEADER"] = "%d sequences, %d variables available" -- MT
L["GEMS_EXPORT_PICK_SEQ_HEADER"] = "Sequences (%d)" -- MT
L["GEMS_EXPORT_PICK_VAR_HEADER"] = "Variables (%d)" -- MT
L["GEMS_EXPORT_PICK_INFO"] = "%d versions, %d steps" -- MT
L["GEMS_EXPORT_PICK_VAR_DEPS"] = "(+%d vars)" -- MT
L["GEMS_EXPORT_PICK_USED_BY"] = "used by: %s" -- MT
L["GEMS_EXPORT_PICK_AUTO"] = "auto" -- MT
L["GEMS_EXPORT_PICK_SELECT_ALL"] = "Select All" -- MT
L["GEMS_EXPORT_PICK_DESELECT_ALL"] = "Deselect All" -- MT
L["GEMS_EXPORT_PICK_EXPORT_SELECTED"] = "Export Selected (%d)" -- MT
L["GEMS_EXPORT_PICK_BACK"] = "Back" -- MT
L["GEMS_EXPORT_PICK_DISPLAY_HEADER"] = "Exported %d sequences, %d variables" -- MT
L["GEMS_EXPORT_PICK_EMBEDDED_WARN"] = "%s uses %s (not selected)" -- MT
L["GEMS_EXPORT_PICK_LOCALE_WARN"] = "Variables with locale-dependent spell names may not work in other game languages" -- MT
L["GEMS_EXPORT_COPY_TEXT"] = "Copy as Text" -- MT
L["GEMS_EXPORT_COPY_TEXT_DESC"] = "Copy a readable summary to clipboard" -- MT
L["GEMS_EXPORT_META_TITLE"] = "Export Metadata" -- MT
L["GEMS_EXPORT_META_SUBTITLE"] = "Review and customize before exporting %d sequences" -- MT
L["GEMS_EXPORT_META_NAME"] = "Collection Name" -- MT
L["GEMS_EXPORT_META_AUTHOR"] = "Author" -- MT
L["GEMS_EXPORT_META_DESC"] = "Description" -- MT
L["GEMS_EXPORT_META_URL"] = "URL / Link" -- MT
L["GEMS_EXPORT_META_TALENT"] = "Talent Loadout" -- MT
L["GEMS_EXPORT_META_INCLUDE_AUTHOR"] = "Include author" -- MT
L["GEMS_EXPORT_META_INCLUDE_DESC"] = "Include description" -- MT
L["GEMS_EXPORT_META_INCLUDE_TALENT"] = "Include talent string" -- MT
L["GEMS_EXPORT_META_INCLUDE_URL"] = "Include URL" -- MT
L["GEMS_EXPORT_META_GENERATE"] = "Generate Export String" -- MT
L["GEMS_EXPORT_META_BACK"] = "Back to Selection" -- MT
L["GEMS_IMPORT_COLLECTION_HEADER"] = "Collection: %s by %s" -- MT
L["GEMS_UI_EXPORT_MULTI"] = "Export Multiple..." -- MT
L["GEMS_HELP_EXPORTALL"] = "  /gems exportall - Open multi-select export window" -- MT
L["GEMS_EXPORT_GENERATE_DESC"] = "Generate the export string from selected sequences" -- MT
L["GEMS_EXPORT_COPY_DESC"] = "Copy the export string to clipboard" -- MT
L["GEMS_EXPORT_SELECT_ALL_DESC"] = "Select all sequences for export" -- MT
L["GEMS_EXPORT_DESELECT_ALL_DESC"] = "Deselect all sequences" -- MT
L["GEMS_EXPORT_BACK_DESC"] = "Return to selection" -- MT
L["GEMS_EXPORT_CLOSE_DESC"] = "Close export window" -- MT

-- Transmission (T2-9)
L["GEMS_HELP_SEND"] = "  /gems send <name> <player> - Send a sequence to another player" -- MT
L["GEMS_HELP_ACCEPT"] = "  /gems accept - Accept the most recent incoming sequence" -- MT
L["GEMS_HELP_VALIDATE"] = "  /gems validate - Validate all sequences for stale/invalid spells" -- MT
L["GEMS_SEND_USAGE"] = "Usage: /gems send <name> <player>" -- MT
L["GEMS_SEND_SUCCESS"] = "Sent '%s' to %s" -- MT
L["GEMS_SEND_FAILED"] = "Send failed: %s" -- MT
L["GEMS_SEND_DISABLED"] = "P2P sharing is disabled in settings." -- MT
L["GEMS_SEND_NO_SEQ"] = "No sequence named '%s' found." -- MT
L["GEMS_RECEIVE_ANNOUNCE"] = "Received sequence from %s. Opening import..." -- MT
L["GEMS_RECEIVE_AUTO"] = "Auto-imported '%s' from %s (friend)." -- MT
L["GEMS_REQUEST_SENT"] = "Requesting '%s' from %s..." -- MT
L["GEMS_REQUEST_FULFILLED"] = "Sent '%s' to %s (requested)." -- MT
L["GEMS_VERSION_ANNOUNCE"] = "GRIP-EMS user detected: %s (v%s)" -- MT
L["GEMS_ACCEPT_USAGE"] = "No pending sequences to accept." -- MT
L["GEMS_UI_SEND_PLAYER"] = "Send to Player" -- MT
L["GEMS_UI_SEND_BTN"] = "Send" -- MT
L["GEMS_UI_SEND_BTN_DESC"] = "Send this sequence to another player" -- MT
L["GEMS_SEND_DIALOG_TEXT"] = "Send '%s' to:" -- MT
L["GEMS_SEND_DIALOG_ACCEPT"] = "Send" -- MT
L["GEMS_SEND_DIALOG_KNOWN"] = "Known users:" -- MT
L["GEMS_META_SENT"] = "Metadata sync request sent for '%s'." -- MT
L["GEMS_META_NEWER"] = "Newer version of '%s' available from %s, requesting..." -- MT
L["GEMS_META_CURRENT"] = "Local '%s' is up to date (remote from %s)." -- MT
L["GEMS_SPELLCACHE_SENT"] = "Spell cache broadcast sent to group." -- MT
L["GEMS_SPELLCACHE_MERGED"] = "Merged %d spell cache entries from %s." -- MT
L["GEMS_P2P_ENABLED"] = "Enable P2P Sharing" -- MT
L["GEMS_P2P_ENABLED_DESC"] = "Allow sending and receiving sequences with other GRIP-EMS users." -- MT
L["GEMS_P2P_AUTO_FRIENDS"] = "Auto-Accept from Friends" -- MT
L["GEMS_P2P_AUTO_FRIENDS_DESC"] = "Automatically import sequences received from friends without prompting." -- MT
L["GEMS_P2P_ANNOUNCE"] = "Announce Received" -- MT
L["GEMS_P2P_ANNOUNCE_DESC"] = "Print a chat message when receiving a sequence from another player." -- MT
L["GEMS_IMPORT_FROM"] = "Import from %s" -- MT

-- Block list (T2-9)
L["GEMS_BLOCK_ADDED"] = "Blocked %s from P2P transmission." -- MT
L["GEMS_BLOCK_REMOVED"] = "Unblocked %s." -- MT
L["GEMS_BLOCK_NOT_FOUND"] = "%s is not blocked." -- MT
L["GEMS_BLOCK_LIST_EMPTY"] = "No players blocked." -- MT
L["GEMS_BLOCK_LIST_HEADER"] = "Blocked players:" -- MT
L["GEMS_SETTINGS_BLOCKED_PLAYERS"] = "Blocked Players" -- MT
L["GEMS_SETTINGS_BLOCKED_PLAYERS_DESC"] = "Players on this list cannot send you sequences." -- MT
L["GEMS_HELP_BLOCK"] = "  /gems block <player> - Block a player from P2P transmission" -- MT
L["GEMS_HELP_UNBLOCK"] = "  /gems unblock <player> - Unblock a player" -- MT
L["GEMS_HELP_BLOCKLIST"] = "  /gems blocklist - List all blocked players" -- MT

-- Tracker HUD (T2-7)
L["GEMS_TRACKER_TOGGLE"] = "Tracker HUD %s." -- MT
L["GEMS_TRACKER_LOCKED"] = "Tracker locked." -- MT
L["GEMS_TRACKER_UNLOCKED"] = "Tracker unlocked." -- MT
L["GEMS_TRACKER_HEADER"] = "Tracker HUD" -- MT
L["GEMS_TRACKER_ICONSIZE_DESC"] = "Set the size of each sequence icon (pixels)" -- MT
L["GEMS_TRACKER_ORIENTATION_DESC"] = "Stack icons horizontally or vertically" -- MT
L["GEMS_TRACKER_SHOWNAME_DESC"] = "Show sequence name below each icon" -- MT
L["GEMS_TRACKER_SHOWMODS_DESC"] = "Show active modifier keys (Alt/Shift/Ctrl)" -- MT
L["GEMS_TRACKER_LOCK_DESC"] = "Lock the tracker frame position" -- MT
L["GEMS_TRACKER_SHOWMODE_DESC"] = "Choose when to show the Tracker HUD" -- MT
L["GEMS_TRACKER_MODE_ALWAYS"] = "Always" -- MT
L["GEMS_TRACKER_MODE_COMBAT"] = "In Combat" -- MT
L["GEMS_TRACKER_MODE_TARGET"] = "Has Target" -- MT
L["GEMS_TRACKER_MODE_NEVER"] = "Never" -- MT
L["GEMS_TRACKER_SCALE_DESC"] = "Scale the Tracker HUD frame" -- MT
L["GEMS_TRACKER_PREVIEW_HINT"] = "Preview shows current state. Combat variables may differ." -- MT
L["GEMS_HELP_TRACKER"] = "  /gems tracker [lock] - Toggle tracker HUD" -- MT

-- Debug window (T1-6)
L["GEMS_HELP_DEBUGWINDOW"] = "  /gems debugwindow - Toggle debug message window" -- MT
L["GEMS_DEBUG_WINDOW_TITLE"] = "GRIP-EMS Debug" -- MT
L["GEMS_DEBUG_CLEAR"] = "Clear" -- MT
L["GEMS_DEBUG_COPY"] = "Copy" -- MT
L["GEMS_DEBUG_COPY_HINT"] = "Use /gems export or Ctrl+C from the export frame to copy debug output." -- MT
L["GEMS_UI_WHATSNEW_DISMISS"] = "Don't show again" -- MT
L["GEMS_WHATSNEW_DISMISS_DESC"] = "Don't show this again for this version" -- MT
L["GEMS_DEBUG_CLOSE_DESC"] = "Close debug window" -- MT
L["GEMS_DEBUG_CLEAR_DESC"] = "Clear all debug messages" -- MT
L["GEMS_DEBUG_COPY_DESC"] = "Copy all messages to clipboard" -- MT

-- Locale Phase 2e
L["GEMS_HELP_REVALIDATE"] = "  /gems revalidate - Force re-tag all sequences with spell IDs" -- MT

-- Click rate (v1.2.0 S01)
L["GEMS_SETTINGS_CLICK_RATE"] = "Click Rate (ms)" -- MT
L["GEMS_SETTINGS_CLICK_RATE_DESC"] =
    "Minimum milliseconds between key presses. Lower = faster sequencing. Default: 250ms."
L["GEMS_SETTINGS_CHAR_OVERRIDES"] = "Character Overrides" -- MT
L["GEMS_SETTINGS_CHAR_CLICK_RATE"] = "Per-Character Click Rate (ms)" -- MT
L["GEMS_SETTINGS_CHAR_CLICK_RATE_DESC"] =
    "Override click rate for this character only. Set to 0 to use the global value."
L["GEMS_STATUS_CLICK_RATE"] = "Click Rate: %dms (effective)" -- MT

-- Macro reset modifiers (v1.2.0 S01)
L["GEMS_SETTINGS_MACRO_RESET"] = "Macro Reset" -- MT
L["GEMS_RESET_MOD_DESC"] = "Reset step counter to 1 when this modifier is held during a key press." -- MT
L["GEMS_UI_RESET_MODS_HEADER"] = "Reset Modifier Overrides" -- MT
L["GEMS_UI_RESET_MODS_ENABLE"] = "Use per-sequence overrides" -- MT
L["GEMS_UI_RESET_MODS_GLOBAL"] = "(using global settings)" -- MT
L["GEMS_RESET_MOD_LEFTBUTTON"] = "Left Click" -- MT
L["GEMS_RESET_MOD_RIGHTBUTTON"] = "Right Click" -- MT
L["GEMS_RESET_MOD_MIDDLEBUTTON"] = "Middle Click" -- MT
L["GEMS_RESET_MOD_BUTTON4"] = "Mouse Button 4" -- MT
L["GEMS_RESET_MOD_BUTTON5"] = "Mouse Button 5" -- MT
L["GEMS_RESET_MOD_LEFTALT"] = "Left Alt" -- MT
L["GEMS_RESET_MOD_RIGHTALT"] = "Right Alt" -- MT
L["GEMS_RESET_MOD_ALT"] = "Any Alt" -- MT
L["GEMS_RESET_MOD_LEFTCONTROL"] = "Left Control" -- MT
L["GEMS_RESET_MOD_RIGHTCONTROL"] = "Right Control" -- MT
L["GEMS_RESET_MOD_CONTROL"] = "Any Control" -- MT
L["GEMS_RESET_MOD_LEFTSHIFT"] = "Left Shift" -- MT
L["GEMS_RESET_MOD_RIGHTSHIFT"] = "Right Shift" -- MT
L["GEMS_RESET_MOD_SHIFT"] = "Any Shift" -- MT
L["GEMS_RESET_MOD_ANYMOD"] = "Any Modifier" -- MT
L["GEMS_RESET_MOD_MOUSE_HEADER"] = "Mouse Buttons" -- MT
L["GEMS_RESET_MOD_ALT_HEADER"] = "Alt Keys" -- MT
L["GEMS_RESET_MOD_CONTROL_HEADER"] = "Control Keys" -- MT
L["GEMS_RESET_MOD_SHIFT_HEADER"] = "Shift Keys" -- MT
L["GEMS_RESET_MOD_ANY_HEADER"] = "Combination" -- MT

-- Corrupt sequence recovery
L["GEMS_CORRUPT_TITLE"] = "Corrupt Sequence Detected" -- MT
L["GEMS_CORRUPT_TEXT"] = "The sequence '%s' could not be loaded.\n\nError: %s\n\nChoose an action:" -- MT
L["GEMS_CORRUPT_DELETE"] = "Delete" -- MT
L["GEMS_CORRUPT_SKIP"] = "Skip" -- MT
L["GEMS_CORRUPT_EXPORT"] = "Export Raw" -- MT
L["GEMS_CORRUPT_SUMMARY"] = "Corrupt sequences: %d deleted, %d skipped, %d exported" -- MT
L["GEMS_CORRUPT_NONE"] = "No corrupt sequences found." -- MT

-- Execution Tracer (v1.2.0 S03-B)
L["GEMS_TRACE_CAST"] = "[Trace] %s (ID: %d)%s" -- MT
L["GEMS_TRACE_STARTED"] = "Execution tracing started" -- MT
L["GEMS_TRACE_STOPPED"] = "Execution tracing stopped" -- MT

-- CVar health (v1.2.0 S01)
L["GEMS_SETTINGS_CVAR_HEALTH"] = "CVar Health" -- MT
L["GEMS_SETTINGS_CVAR_DESC"] =
    "Game variables that affect macro sequencer performance. Green = optimal, yellow = suboptimal, red = critical."
L["GEMS_SETTINGS_CVAR_AUTOFIX"] = "Auto-Fix CVars on Login" -- MT
L["GEMS_SETTINGS_CVAR_AUTOFIX_DESC"] = "Automatically set recommended CVar values when you log in." -- MT
L["GEMS_SETTINGS_CVAR_FIX"] = "Fix" -- MT

-- Comparison Frame (v1.2.0 S04-B)
L["GEMS_IMPORT_COMPARE"] = "Compare" -- MT
L["GEMS_UI_COMPARE_WITH"] = "Compare with..." -- MT
L["GEMS_COMPARE_TITLE"] = "Sequence Comparison" -- MT
L["GEMS_COMPARE_LEFT_LABEL"] = "Existing" -- MT
L["GEMS_COMPARE_RIGHT_LABEL"] = "Incoming" -- MT
L["GEMS_COMPARE_STEPS"] = "%d steps" -- MT
L["GEMS_COMPARE_NO_STEPS"] = "No steps" -- MT
L["GEMS_COMPARE_CLOSE_DESC"] = "Close comparison view" -- MT

-- Sequence autocomplete (v1.2.0 S07b)
L["GEMS_AUTOCOMPLETE_SEQUENCES"] = "Sequences" -- MT
L["GEMS_AUTOCOMPLETE_CLICK_INSERT"] = "/click GRIPEMS_%s" -- MT

-- Popup Editor (v1.2.0 S07a)
L["GEMS_UI_OPEN_NEW_WINDOW"] = "Open in New Window" -- MT
L["GEMS_UI_POPUP_TITLE"] = "GRIP-EMS Editor" -- MT
L["GEMS_UI_POPUP_CLOSE_DIRTY"] = "This editor has unsaved changes.\nSave before closing?" -- MT
L["GEMS_UI_POPUP_MAX_REACHED"] = "Maximum editor windows reached (%d)." -- MT

-- Editor Colours (v1.2.0 S08a)
L["GEMS_SETTINGS_EDITOR_COLOURS"] = "Editor Colours" -- MT
L["GEMS_SETTINGS_SYNTAX_COMMAND"] = "Slash Commands" -- MT
L["GEMS_SETTINGS_SYNTAX_COMMAND_DESC"] = "Colour for /cast, /use, /click, etc." -- MT
L["GEMS_SETTINGS_SYNTAX_CONDITIONAL"] = "Conditionals" -- MT
L["GEMS_SETTINGS_SYNTAX_CONDITIONAL_DESC"] = "Colour for [mod:shift], [talent:X], etc." -- MT
L["GEMS_SETTINGS_SYNTAX_VARIABLE"] = "Variables" -- MT
L["GEMS_SETTINGS_SYNTAX_VARIABLE_DESC"] = "Colour for ~variable~ references." -- MT
L["GEMS_SETTINGS_SYNTAX_COMMENT"] = "Comments" -- MT
L["GEMS_SETTINGS_SYNTAX_COMMENT_DESC"] = "Colour for -- comment lines." -- MT
L["GEMS_SETTINGS_SYNTAX_RESET"] = "Reset Conditions" -- MT
L["GEMS_SETTINGS_SYNTAX_RESET_DESC"] = "Colour for reset=target/combat/5." -- MT
L["GEMS_SETTINGS_SYNTAX_NUMBER"] = "Numbers" -- MT
L["GEMS_SETTINGS_SYNTAX_NUMBER_DESC"] = "Colour for numeric values." -- MT

-- Floating Menu (v1.2.0 S09a)
L["GEMS_FLOATING_HEADER"] = "Floating Menu" -- MT
L["GEMS_FLOATING_SHOW_DESC"] = "Show the floating quick-access menu bar" -- MT
L["GEMS_FLOATING_DIRECTION_DESC"] = "Direction buttons expand from the anchor" -- MT
L["GEMS_FLOATING_LOCK_DESC"] = "Lock the floating menu position" -- MT
L["GEMS_FLOATING_SCALE_DESC"] = "Scale the floating menu frame" -- MT
L["GEMS_FLOATING_LOCKED"] = "Floating menu locked." -- MT
L["GEMS_FLOATING_UNLOCKED"] = "Floating menu unlocked." -- MT
L["GEMS_FLOATING_BTN_SEQUENCES"] = "Sequences" -- MT
L["GEMS_FLOATING_BTN_IMPORT"] = "Import" -- MT
L["GEMS_FLOATING_BTN_EXPORT"] = "Export" -- MT
L["GEMS_FLOATING_BTN_VARIABLES"] = "Variables" -- MT
L["GEMS_FLOATING_BTN_TRACKER"] = "Tracker" -- MT
L["GEMS_FLOATING_BTN_OPTIONS"] = "Options" -- MT
L["GEMS_FLOATING_BTN_COLLAPSE"] = "Collapse" -- MT
L["GEMS_FLOATING_BTN_EXPAND"] = "Expand" -- MT
L["GEMS_FLOATING_BTN_CLOSE"] = "Close" -- MT
L["GEMS_FLOATING_DIR_UP"] = "Up" -- MT
L["GEMS_FLOATING_DIR_DOWN"] = "Down" -- MT
L["GEMS_FLOATING_DIR_LEFT"] = "Left" -- MT
L["GEMS_FLOATING_DIR_RIGHT"] = "Right" -- MT
L["GEMS_HELP_MENU"] = "  /gems menu - Toggle floating menu bar" -- MT

-- Support tab (v1.2.0 S10-B)
L["GEMS_SETTINGS_SUPPORT"] = "Support" -- MT
L["GEMS_SUPPORT_CREDITS"] = "Created by Sataana (MrSataana / JesperLive)" -- MT
L["GEMS_SUPPORT_DISCORD"] = "Discord: discord.gg/grip-ems" -- MT
L["GEMS_SUPPORT_SYSTEM_HEADER"] = "System Info" -- MT
L["GEMS_SUPPORT_CREDITS_HEADER"] = "Credits" -- MT
L["GEMS_SUPPORT_DISCORD_HEADER"] = "Community" -- MT
L["GEMS_HELP_COMPRESS"] = "  /gems compress <name> - Encode sequence (dev)" -- MT
L["GEMS_HELP_DECOMPRESS"] = "  /gems decompress <string> - Decode string (dev)" -- MT

-- Remote Browser (v1.2.0 S13b)
L["GEMS_UI_REMOTE_BROWSER_TITLE"] = "Remote Macro Browser" -- MT
L["GEMS_UI_REMOTE_PLAYERS_HEADER"] = "Players with EMS" -- MT
L["GEMS_UI_REMOTE_REFRESH"] = "Refresh" -- MT
L["GEMS_UI_REMOTE_SEQUENCES_FROM"] = "Sequences from %s" -- MT
L["GEMS_UI_REMOTE_WAITING"] = "Waiting for response..." -- MT
L["GEMS_UI_REMOTE_NO_PLAYERS"] = "No EMS users detected. Join a group to discover players." -- MT
L["GEMS_UI_REMOTE_NO_SEQUENCES"] = "No sequences available from this player." -- MT
L["GEMS_UI_REMOTE_IMPORT"] = "Import" -- MT
L["GEMS_UI_REMOTE_REQUEST_SENT"] = "Requested %s from %s" -- MT
L["GEMS_UI_REMOTE_LIST_RECEIVED"] = "Received sequence list from %s (%d sequences)" -- MT
L["GEMS_HELP_BROWSE"] = "  /gems browse - Open remote sequence browser" -- MT
L["GEMS_BROWSE_REFRESH_DESC"] = "Refresh the list of party members and their sequences" -- MT
L["GEMS_BROWSE_IMPORT_DESC"] = "Import this sequence to your library" -- MT
L["GEMS_BROWSE_CLOSE_DESC"] = "Close the browser" -- MT

-- Recorder
L["GEMS_UI_RECORD"] = "Record" -- MT
L["GEMS_UI_RECORDING"] = "Recording..." -- MT
L["GEMS_UI_RECORDING_COUNT"] = "Recording (%d)" -- MT
L["GEMS_RECORDER_MAX_REACHED"] = "Recording stopped: maximum step limit reached." -- MT
L["GEMS_RECORDER_STOPPED"] = "Recording stopped: %d spells captured." -- MT
L["GEMS_RECORDER_CREATE_CONFIRM"] = "Recording captured %d spells. Create a new sequence from this recording?" -- MT
L["GEMS_RECORDER_CREATE_YES"] = "Create Sequence" -- MT
L["GEMS_RECORDER_CREATE_NO"] = "Discard" -- MT
L["GEMS_RECORDER_EMPTY"] = "No spells were recorded." -- MT
L["GEMS_SETTINGS_RECORDER_HEADER"] = "Recorder" -- MT
L["GEMS_SETTINGS_RECORDER_DEDUP"] = "Deduplicate consecutive identical casts" -- MT
L["GEMS_SETTINGS_RECORDER_DEDUP_DESC"] =
    "When enabled, consecutive casts of the same spell are collapsed into a single step."

-- Spell Cache Viewer (v1.2.0 S16)
L["GEMS_SPELLCACHE_TITLE"] = "Spell Cache" -- MT
L["GEMS_SPELLCACHE_TAB_SPELLS"] = "Spells" -- MT
L["GEMS_SPELLCACHE_TAB_ITEMS"] = "Items" -- MT
L["GEMS_SPELLCACHE_TAB_TOYS"] = "Toys" -- MT
L["GEMS_SPELLCACHE_SEARCH"] = "Search..." -- MT
L["GEMS_SPELLCACHE_REFRESH"] = "Refresh" -- MT
L["GEMS_SPELLCACHE_CLEAR_OVERRIDES"] = "Clear Overrides" -- MT
L["GEMS_SPELLCACHE_CLEAR_CONFIRM"] = "Remove all spell name overrides? This cannot be undone." -- MT
L["GEMS_SPELLCACHE_SHOWING"] = "Showing %d of %d" -- MT
L["GEMS_SPELLCACHE_SCANNING"] = "Scanning..." -- MT
L["GEMS_SPELLCACHE_NOT_AVAILABLE"] = "Spell Cache viewer not available." -- MT
L["GEMS_SPELLCACHE_OVERRIDE_CLEARED"] = "Spell name overrides cleared." -- MT
L["GEMS_HELP_SPELLCACHE"] = "|cFF00CC66/gems spellcache|r -- Open spell cache viewer" -- MT
L["GEMS_HELP_MAPINFO"] = "|cFF00CC66/gems mapinfo|r -- Show current map/instance IDs" -- MT

-- Inline string localization (v1.2.0 S22-D)
L["GEMS_UI_STUB_PREVIEW"] = "Macro Stub Preview" -- MT
L["GEMS_UI_EMPTY_HINT"] = "Import or create a sequence to get started" -- MT
L["GEMS_UI_KEYBIND_TOOLTIP"] = "Keybind: %s" -- MT

-- Vehicle / Pet Battle Keybinds (v1.2.0 S23)
L["GEMS_VEHICLE_KEYBINDS_HEADER"] = "Vehicle / Override Bar Keybinds" -- MT
L["GEMS_PET_BATTLE_KEYBINDS_HEADER"] = "Pet Battle Keybinds" -- MT
L["GEMS_VEHICLE_SLOT"] = "Slot %d" -- MT
L["GEMS_VEHICLE_KEYBINDS_APPLIED"] = "Vehicle keybinds applied: %d binding(s)" -- MT
L["GEMS_VEHICLE_KEYBINDS_CLEARED"] = "Vehicle keybinds cleared" -- MT
L["GEMS_PET_BATTLE_KEYBINDS_APPLIED"] = "Pet battle keybinds applied: %d binding(s)" -- MT
L["GEMS_PET_BATTLE_KEYBINDS_CLEARED"] = "Pet battle keybinds cleared" -- MT
L["GEMS_PET_BATTLE_ABILITY"] = "Ability %d" -- MT
L["GEMS_PET_BATTLE_SWAP"] = "Swap Pet" -- MT
L["GEMS_PET_BATTLE_PASS"] = "Pass Turn" -- MT
L["GEMS_PET_BATTLE_FORFEIT"] = "Forfeit" -- MT
L["GEMS_BAR_INTEGRATION_HEADER"] = "Action Bar Integration" -- MT
L["GEMS_BAR_INTEGRATION_DESC"] = "Show sequence icons on action bar buttons" -- MT
L["GEMS_BAR_INTEGRATION_TRACKED"] = "Bar integration: %d buttons tracked (%s)" -- MT
L["GEMS_UI_NOT_BOUND"] = "Not bound" -- MT

-- Feature: Click Rate Diagnostics (/gems diag)
L["GEMS_DIAG_HEADER"] = "--- Execution Diagnostics ---" -- MT
L["GEMS_DIAG_CPS"] = "Real-time CPS: %.1f" -- MT
L["GEMS_DIAG_CONFIGURED"] = "Configured click rate: %dms (effective)" -- MT
L["GEMS_DIAG_TOTAL"] = "Total casts tracked: %d" -- MT
L["GEMS_DIAG_TRACER"] = "Tracer: %s" -- MT
L["GEMS_DIAG_TRACER_ON"] = "active" -- MT
L["GEMS_DIAG_TRACER_OFF"] = "inactive" -- MT
L["GEMS_DIAG_TOP_SPELLS"] = "Top spells:" -- MT
L["GEMS_DIAG_SPELL_ROW"] = "  %d. %s (ID: %d) -- %d casts" -- MT
L["GEMS_DIAG_NO_DATA"] = "No cast data yet. Use a sequence first." -- MT
L["GEMS_HELP_DIAG"] = "Show execution diagnostics (CPS, top spells)" -- MT
L["GEMS_HELP_MEMCHECK"] = "Memory diagnostics (GC, table sizes, heap)" -- MT
L["GEMS_HELP_PERF"] = "Performance profiling (OnUpdate, frames, timings)" -- MT
L["GEMS_HELP_MONITOR"] = "300-frame continuous profiler (hooks key functions)" -- MT

-- Feature: Optimal MS Advisor (/gems msadvisor)
L["GEMS_MSADVISOR_HEADER"] = "--- MS Advisor%s ---" -- MT
L["GEMS_MSADVISOR_GCD"] = "Base GCD: %dms (%.1f%% haste)" -- MT
L["GEMS_MSADVISOR_LAG"] = "World latency: %dms" -- MT
L["GEMS_MSADVISOR_SQW"] = "Spell Queue Window: %dms" -- MT
L["GEMS_MSADVISOR_RECOMMEND"] = "Recommended click rate: %dms" -- MT
L["GEMS_MSADVISOR_CURRENT"] = "Current configured: %dms" -- MT
L["GEMS_MSADVISOR_DELTA"] = "Delta: %+dms (%s)" -- MT
L["GEMS_MSADVISOR_FASTER"] = "you could click faster" -- MT
L["GEMS_MSADVISOR_SLOWER"] = "you are clicking faster than GCD allows" -- MT
L["GEMS_MSADVISOR_GOOD"] = "well-matched" -- MT
L["GEMS_MSADVISOR_ROTATION"] = "Sequence '%s': %d steps, full rotation ~%dms" -- MT
L["GEMS_MSADVISOR_NOT_FOUND"] = "Secuencia '%s' no encontrada." -- MT
L["GEMS_HELP_MSADVISOR"] = "Recommend optimal click rate based on haste" -- MT

-- Feature: Dormant Sequence Lazy Loading
L["GEMS_DORMANT_LOADED"] = "  %d sequence(s) registered as dormant (different class)" -- MT
L["GEMS_DORMANT_LABEL"] = "(dormant)" -- MT
L["GEMS_HELP_LOADCLASS"] = "Activate dormant sequences for a class ID" -- MT
L["GEMS_LOADCLASS_ALREADY"] = "Class %d sequences are already loaded." -- MT
L["GEMS_LOADCLASS_DONE"] = "Activated %d dormant sequence(s) for class %d." -- MT
L["GEMS_LOADCLASS_USAGE"] = "Usage: /gems loadclass <classID> (1=Warrior, 2=Paladin, ...)" -- MT
L["GEMS_UI_ACTIVATE"] = "Activate" -- MT

-- Feature: Raw Macrotext Import
L["GEMS_RAWIMPORT_DETECTED"] = "Raw macro text detected. Parsing %d lines..." -- MT
L["GEMS_RAWIMPORT_RESULT"] = "Parsed %d steps from raw macro text." -- MT
L["GEMS_RAWIMPORT_NAME"] = "Imported Macro" -- MT
L["GEMS_RAWIMPORT_NO_SPELLS"] = "No castable lines found in pasted text." -- MT

-- Feature: Step Spell Picker
L["GEMS_SPELLPICKER_TITLE"] = "Spell Picker" -- MT
L["GEMS_SPELLPICKER_SEARCH"] = "Search spells..." -- MT
L["GEMS_SPELLPICKER_ALL"] = "All" -- MT
L["GEMS_SPELLPICKER_CLASS"] = "Class" -- MT
L["GEMS_SPELLPICKER_PET"] = "Pet Abilities" -- MT
L["GEMS_SPELLPICKER_ITEMS"] = "Items" -- MT
L["GEMS_SPELLPICKER_GEAR"] = "Gear" -- MT
L["GEMS_SPELLPICKER_CONSUMABLES"] = "Consumables" -- MT
L["GEMS_SPELLPICKER_TOYS"] = "Toys" -- MT
L["GEMS_SPELLPICKER_SPEC"] = "Spec" -- MT
L["GEMS_SPELLPICKER_RACE"] = "Race" -- MT
L["GEMS_SPELLPICKER_GENERAL"] = "General" -- MT
L["GEMS_SPELLPICKER_PROF"] = "Prof" -- MT
L["GEMS_SPELLPICKER_OTHER"] = "Other" -- MT
L["GEMS_SPELLPICKER_MOUNTS"] = "Mounts" -- MT
L["GEMS_SPELLPICKER_COMPANIONS"] = "Companions" -- MT
L["GEMS_SPELLPICKER_CONDITIONALS"] = "Conditionals" -- MT
L["GEMS_SPELLPICKER_CUSTOM"] = "Custom:" -- MT
L["GEMS_SPELLPICKER_INSERT"] = "Insert" -- MT
L["GEMS_SPELLPICKER_NO_RESULTS"] = "No matching spells" -- MT
L["GEMS_SPELLPICKER_FAVORITES"] = "Favorites" -- MT
L["GEMS_SPELLPICKER_WARBANK_NOTE"] = "Warbank items only visible at a banker" -- MT
L["GEMS_HELP_SPELLPICKER"] = "Spell picker available via icon button on each step" -- MT

-- Feature: Gear-Aware Variables
L["GEMS_GEAR_VAR_HEADER"] = "Gear variables (auto-detected use-effects):" -- MT
L["GEMS_GEAR_VAR_ROW"] = "  ~%s~ = %s" -- MT
L["GEMS_GEAR_VAR_NONE"] = "No equipped use-effects detected." -- MT
L["GEMS_GEAR_VAR_UPDATED"] = "Gear variables updated (%d use-effects detected)." -- MT

-- CVar Health Dashboard (v1.9.0)
L["GEMS_CVAR_FIX_ALL"] = "Fix All"  -- MT
L["GEMS_CVAR_FIX_ALL_CRITICAL"] = "Fix All Critical"  -- MT
L["GEMS_CVAR_FIX_ALL_SECTION"] = "Fix All in Section"  -- MT
L["GEMS_CVAR_AUTOFIX_ENTRY"] = "Auto-fix on login"  -- MT
L["GEMS_CVAR_AUTOFIX_COUNT"] = "GEMS: Auto-fixed %d CVars on login."  -- MT
L["GEMS_CVAR_HEALTH_SCORE"] = "CVar Health: %d/100"  -- MT
L["GEMS_CVAR_SECURE_TAG"] = " (secure)"  -- MT
L["GEMS_CVAR_COMBAT_DISABLED"] = "Cannot change secure CVars in combat."  -- MT
L["GEMS_CVAR_INFORMATIONAL"] = " (informational)"  -- MT
L["GEMS_CVAR_YOUR_CHOICE"] = "(your choice)"  -- MT
L["GEMS_CVAR_WILL_CHANGE"] = "Will change from %s to %s."  -- MT
L["GEMS_CVAR_SET_VALUE"] = "Set Value"  -- MT
L["GEMS_CVAR_SECTION_MACRO"] = "Macro Sequencing"  -- MT
L["GEMS_CVAR_SECTION_COMBAT"] = "Combat & Targeting"  -- MT
L["GEMS_CVAR_SECTION_NAMEPLATES"] = "Nameplates"  -- MT
L["GEMS_CVAR_SECTION_RAIDING"] = "Raiding"  -- MT
L["GEMS_CVAR_SECTION_DUNGEON"] = "Dungeons & M+"  -- MT
L["GEMS_CVAR_SECTION_SOLO"] = "Solo Play & Open World"  -- MT
L["GEMS_CVAR_SECTION_UI"] = "UI & Quality of Life"  -- MT
L["GEMS_CVAR_SECTION_FPS"] = "FPS & Performance"  -- MT
L["GEMS_CVAR_SECTION_VISUAL"] = "Visual Quality"  -- MT
L["GEMS_CVAR_SECTION_SOUND"] = "Sound"  -- MT
L["GEMS_CVAR_SECTION_FCT"] = "Floating Combat Text"  -- MT
L["GEMS_CVAR_SECTION_ACCESS"] = "Accessibility"  -- MT
L["GEMS_CVAR_SECTION_DRAGON"] = "Dragonriding & Advanced Flying"  -- MT
L["GEMS_CVAR_MACRO_KEYDOWN"] = "Key Down Casting"  -- MT
L["GEMS_CVAR_MACRO_KEYDOWN_DESC"] = "Fire abilities on key press, not release. If 0, every macro keypress has 50-100ms extra delay. Mandatory for sequencing."  -- MT
L["GEMS_CVAR_MACRO_KEYHELD"] = "Hold to Cast"  -- MT
L["GEMS_CVAR_MACRO_KEYHELD_DESC"] = "Press-and-hold auto-repeats the ability. Preference-based, not a blanket recommendation. Informational."  -- MT
L["GEMS_CVAR_MACRO_SPELLQUEUE"] = "Spell Queue Window"  -- MT
L["GEMS_CVAR_MACRO_SPELLQUEUE_DESC"] = "Milliseconds before GCD ends that the next spell can be queued. 400ms is optimal for most players."  -- MT
L["GEMS_CVAR_MACRO_LOCKBARS"] = "Lock Action Bars"  -- MT
L["GEMS_CVAR_MACRO_LOCKBARS_DESC"] = "Prevents accidental drag-off of macro stubs from action bars during combat."  -- MT
L["GEMS_CVAR_MACRO_MULTIBARS"] = "Multi Action Bars"  -- MT
L["GEMS_CVAR_MACRO_MULTIBARS_DESC"] = "Bitfield for additional action bars (0=none, 15=all). More bars = more room for macro stubs. Informational."  -- MT
L["GEMS_CVAR_MACRO_AUTOPUSH"] = "Auto Push Spells"  -- MT
L["GEMS_CVAR_MACRO_AUTOPUSH_DESC"] = "Auto-places new spells on bars. Recommend OFF -- new spells from leveling push macro stubs off the bar."  -- MT
L["GEMS_CVAR_MACRO_SELFCAST"] = "Auto Self Cast"  -- MT
L["GEMS_CVAR_MACRO_SELFCAST_DESC"] = "Auto-cast beneficial spells on self when no valid target. Important for macro steps with self-heals."  -- MT
L["GEMS_CVAR_MACRO_AUTOSTAND"] = "Auto Stand"  -- MT
L["GEMS_CVAR_MACRO_AUTOSTAND_DESC"] = "Auto-stand when casting. Without this, macro sequences fail silently while sitting."  -- MT
L["GEMS_CVAR_MACRO_AUTOUNSHIFT"] = "Auto Unshift"  -- MT
L["GEMS_CVAR_MACRO_AUTOUNSHIFT_DESC"] = "Auto-leave shapeshift/stealth when casting incompatible spells. Without this, Druid/Rogue macro steps fail silently."  -- MT
L["GEMS_CVAR_MACRO_STOPATTACK"] = "Stop Attack on Switch"  -- MT
L["GEMS_CVAR_MACRO_STOPATTACK_DESC"] = "Keep auto-attacking when switching targets. If 1, target-switching mid-sequence stops melee auto-attacks."  -- MT
L["GEMS_CVAR_MACRO_ICONRATE"] = "Icon Update Rate"  -- MT
L["GEMS_CVAR_MACRO_ICONRATE_DESC"] = "How often action bar icons refresh (seconds). 0.05 = 20 updates/sec, smoother than default 0.1."  -- MT
L["GEMS_CVAR_MACRO_CDCOUNT"] = "Cooldown Countdown"  -- MT
L["GEMS_CVAR_MACRO_CDCOUNT_DESC"] = "Show numeric cooldown timers on action buttons. Critical for seeing exact remaining cooldown on the sequence button."  -- MT
L["GEMS_CVAR_MACRO_SECTOGGLE"] = "Secure Ability Toggle"  -- MT
L["GEMS_CVAR_MACRO_SECTOGGLE_DESC"] = "Prevents double-click toggling abilities off. Protects against rapid keypresses deactivating toggle abilities."  -- MT
L["GEMS_CVAR_MACRO_EMPTAP"] = "Empower Tap Controls"  -- MT
L["GEMS_CVAR_MACRO_EMPTAP_DESC"] = "Tap-tap vs hold-release for empowered spells (Evoker). Hold-release works better with sequences."  -- MT
L["GEMS_CVAR_MACRO_EMPHOLD"] = "Empower Hold Stage"  -- MT
L["GEMS_CVAR_MACRO_EMPHOLD_DESC"] = "Percentage of first empower stage required before auto-release [0.0-1.0]. Evoker-specific."  -- MT
L["GEMS_CVAR_MACRO_HELDPOLL"] = "Held Spell Poll Time"  -- MT
L["GEMS_CVAR_MACRO_HELDPOLL_DESC"] = "Milliseconds between retry attempts when held-spell casting fails. Lower = faster retry, more responsive."  -- MT
L["GEMS_CVAR_MACRO_PRECAST"] = "Preemptive Cast"  -- MT
L["GEMS_CVAR_MACRO_PRECAST_DESC"] = "Preemptive cast visual triggering based on spell release timing. Undocumented visual feature."  -- MT
L["GEMS_CVAR_COMBAT_SOFTENEMY"] = "Soft Target Enemy"  -- MT
L["GEMS_CVAR_COMBAT_SOFTENEMY_DESC"] = "When soft targeting activates for enemies. 0=off, 1=gamepad, 2=KBM, 3=always. Recommend 3 for auto-acquire."  -- MT
L["GEMS_CVAR_COMBAT_SOFTARC"] = "Soft Target Arc"  -- MT
L["GEMS_CVAR_COMBAT_SOFTARC_DESC"] = "Directional constraint for enemy soft target. 0=must face directly, 1=front arc, 2=anywhere."  -- MT
L["GEMS_CVAR_COMBAT_SOFTRANGE"] = "Soft Target Range"  -- MT
L["GEMS_CVAR_COMBAT_SOFTRANGE_DESC"] = "Max range for soft target enemy detection (yards). 45yd covers most ranged abilities."  -- MT
L["GEMS_CVAR_COMBAT_SOFTFORCE"] = "Soft Target Force"  -- MT
L["GEMS_CVAR_COMBAT_SOFTFORCE_DESC"] = "Auto-hardlock soft target. Without this, soft targeting shows the target but spells fire at nothing."  -- MT
L["GEMS_CVAR_COMBAT_SOFTFRIEND"] = "Soft Target Friend"  -- MT
L["GEMS_CVAR_COMBAT_SOFTFRIEND_DESC"] = "Soft targeting for friendlies. 0=off. Healers may want 3 (always). DPS should leave at 0."  -- MT
L["GEMS_CVAR_COMBAT_SOFTLOCKED"] = "Soft With Locked"  -- MT
L["GEMS_CVAR_COMBAT_SOFTLOCKED_DESC"] = "Allow soft target while having a hard-locked target. 2=always allows soft target preview."  -- MT
L["GEMS_CVAR_COMBAT_SOFTMATCH"] = "Soft Match Locked"  -- MT
L["GEMS_CVAR_COMBAT_SOFTMATCH_DESC"] = "Match soft target to locked target. Keeps the soft target indicator synced with your actual target."  -- MT
L["GEMS_CVAR_COMBAT_TABNEW"] = "New Tab Targeting"  -- MT
L["GEMS_CVAR_COMBAT_TABNEW_DESC"] = "Use modern (7.2+) tab-targeting algorithm. Prioritizes enemies in front of you and in combat."  -- MT
L["GEMS_CVAR_COMBAT_COMBATLOCK"] = "Combat Target Lock"  -- MT
L["GEMS_CVAR_COMBAT_COMBATLOCK_DESC"] = "Lock tab-target to in-combat enemies. Prevents jumping to distant mobs not yet pulled."  -- MT
L["GEMS_CVAR_COMBAT_LOCKRELAX"] = "Lock Relaxation"  -- MT
L["GEMS_CVAR_COMBAT_LOCKRELAX_DESC"] = "Smart relaxation of combat lock when no in-combat targets are available."  -- MT
L["GEMS_CVAR_COMBAT_PVPPRIO"] = "PvP Target Priority"  -- MT
L["GEMS_CVAR_COMBAT_PVPPRIO_DESC"] = "In PvP, prioritize players and important PvP targets. 1=players first."  -- MT
L["GEMS_CVAR_COMBAT_ATTACKER"] = "Target Attacker"  -- MT
L["GEMS_CVAR_COMBAT_ATTACKER_DESC"] = "Auto-target enemies that attack you. Essential for solo play where mobs aggro."  -- MT
L["GEMS_CVAR_COMBAT_AUTOENEMY"] = "Auto Target Enemy"  -- MT
L["GEMS_CVAR_COMBAT_AUTOENEMY_DESC"] = "Auto-target nearest enemy when casting offensive spells with no target. Ensures macros fire."  -- MT
L["GEMS_CVAR_COMBAT_DESELECT"] = "Deselect on Click"  -- MT
L["GEMS_CVAR_COMBAT_DESELECT_DESC"] = "Clear target when clicking terrain. If 1, clicking ground mid-fight drops your target."  -- MT
L["GEMS_CVAR_COMBAT_LEFTCLICK"] = "Interact Left Click"  -- MT
L["GEMS_CVAR_COMBAT_LEFTCLICK_DESC"] = "Left-click interacts with NPCs. Standard behavior most players expect."  -- MT
L["GEMS_CVAR_COMBAT_HIGHLIGHT"] = "Combat Highlight"  -- MT
L["GEMS_CVAR_COMBAT_HIGHLIGHT_DESC"] = "Next-spell-to-cast highlight. Competes visually with sequence tracking. Recommend OFF."  -- MT
L["GEMS_CVAR_COMBAT_PROCS"] = "Proc Overlays"  -- MT
L["GEMS_CVAR_COMBAT_PROCS_DESC"] = "Show proc/spell alert overlays (glowing borders). Important for seeing procs that affect macro priority."  -- MT
L["GEMS_CVAR_COMBAT_PROCOPACITY"] = "Proc Overlay Opacity"  -- MT
L["GEMS_CVAR_COMBAT_PROCOPACITY_DESC"] = "Opacity of spell alert overlays. Default 0.65 is good. Increase to 0.8-1.0 if hard to see."  -- MT
L["GEMS_CVAR_COMBAT_LOC"] = "Loss of Control"  -- MT
L["GEMS_CVAR_COMBAT_LOC_DESC"] = "Show loss-of-control banner when stunned/silenced. Helps understand why a macro sequence appears stuck."  -- MT
L["GEMS_CVAR_COMBAT_MOUSEOVER"] = "Mouseover Casting"  -- MT
L["GEMS_CVAR_COMBAT_MOUSEOVER_DESC"] = "Cast on unit under cursor without targeting. Huge for healers. Informational, not auto-fix."  -- MT
L["GEMS_CVAR_COMBAT_FRIENDARC"] = "Friend Soft Arc"  -- MT
L["GEMS_CVAR_COMBAT_FRIENDARC_DESC"] = "Directional constraint for friendly soft target. Mirrors SoftTargetEnemyArc. Only if SoftTargetFriend is on."  -- MT
L["GEMS_CVAR_COMBAT_FRIENDRANGE"] = "Friend Soft Range"  -- MT
L["GEMS_CVAR_COMBAT_FRIENDRANGE_DESC"] = "Max range for soft target friend detection. 45yd covers all healing spells."  -- MT
L["GEMS_CVAR_NAMEPLATES_SHOWALL"] = "Show All Nameplates"  -- MT
L["GEMS_CVAR_NAMEPLATES_SHOWALL_DESC"] = "Show ALL nameplates (enemies, friendly NPCs, pets). Master toggle. Most combat players want this on."  -- MT
L["GEMS_CVAR_NAMEPLATES_SHOWENEMY"] = "Show Enemy Nameplates"  -- MT
L["GEMS_CVAR_NAMEPLATES_SHOWENEMY_DESC"] = "Show enemy nameplates. Must be on for any combat awareness."  -- MT
L["GEMS_CVAR_NAMEPLATES_SHOWSELF"] = "Show Self Nameplate"  -- MT
L["GEMS_CVAR_NAMEPLATES_SHOWSELF_DESC"] = "Show personal resource display (health/mana bar under your character). Many players don't know this exists."  -- MT
L["GEMS_CVAR_NAMEPLATES_MAXDIST"] = "Max Distance"  -- MT
L["GEMS_CVAR_NAMEPLATES_MAXDIST_DESC"] = "Max nameplate render distance. 60yd is the cap and default. Lower values save GPU but lose awareness."  -- MT
L["GEMS_CVAR_NAMEPLATES_PLAYERDIST"] = "Player Max Distance"  -- MT
L["GEMS_CVAR_NAMEPLATES_PLAYERDIST_DESC"] = "Max distance for player nameplates specifically. Keep equal to nameplateMaxDistance."  -- MT
L["GEMS_CVAR_NAMEPLATES_MINALPHA"] = "Min Opacity"  -- MT
L["GEMS_CVAR_NAMEPLATES_MINALPHA_DESC"] = "Minimum opacity for distant nameplates. Default 0.6 makes far nameplates hard to see. 0.8 is better."  -- MT
L["GEMS_CVAR_NAMEPLATES_MAXALPHA"] = "Max Opacity"  -- MT
L["GEMS_CVAR_NAMEPLATES_MAXALPHA_DESC"] = "Maximum opacity for nearby nameplates. 1.0 = fully opaque. No reason to lower."  -- MT
L["GEMS_CVAR_NAMEPLATES_MINSCALE"] = "Min Scale"  -- MT
L["GEMS_CVAR_NAMEPLATES_MINSCALE_DESC"] = "Minimum scale for distant nameplates. Lower values make far nameplates too small to read."  -- MT
L["GEMS_CVAR_NAMEPLATES_MAXSCALE"] = "Max Scale"  -- MT
L["GEMS_CVAR_NAMEPLATES_MAXSCALE_DESC"] = "Maximum scale for nearby nameplates."  -- MT
L["GEMS_CVAR_NAMEPLATES_SELSCALE"] = "Selected Scale"  -- MT
L["GEMS_CVAR_NAMEPLATES_SELSCALE_DESC"] = "Scale multiplier for your current target's nameplate. Default 1.2 makes the target visually distinct."  -- MT
L["GEMS_CVAR_NAMEPLATES_OCCLUDED"] = "Occluded Opacity"  -- MT
L["GEMS_CVAR_NAMEPLATES_OCCLUDED_DESC"] = "Opacity for nameplates behind walls/objects. Default 0.4 is nearly invisible. 0.6 keeps them readable."  -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPH"] = "Horizontal Overlap"  -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPH_DESC"] = "Horizontal stacking overlap. Lower = more spread. 0.8 is the default stacking behavior."  -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPV"] = "Vertical Overlap"  -- MT
L["GEMS_CVAR_NAMEPLATES_OVERLAPV_DESC"] = "Vertical stacking overlap. Controls how nameplates stack vertically in AoE packs."  -- MT
L["GEMS_CVAR_NAMEPLATES_CASTBARS"] = "Nameplate Cast Bars"  -- MT
L["GEMS_CVAR_NAMEPLATES_CASTBARS_DESC"] = "Show cast bars on nameplates. Essential for interrupting."  -- MT
L["GEMS_CVAR_NAMEPLATES_CLASSCOLOR"] = "Class Color Bars"  -- MT
L["GEMS_CVAR_NAMEPLATES_CLASSCOLOR_DESC"] = "Color enemy nameplate health bars by class. Important for PvP target identification."  -- MT
L["GEMS_CVAR_NAMEPLATES_DEBUFFS"] = "Friendly Debuffs"  -- MT
L["GEMS_CVAR_NAMEPLATES_DEBUFFS_DESC"] = "Show debuffs on friendly nameplates. Useful for healers and dispellers."  -- MT
L["GEMS_CVAR_NAMEPLATES_MINIONS"] = "Enemy Minions"  -- MT
L["GEMS_CVAR_NAMEPLATES_MINIONS_DESC"] = "Show minion nameplates. Off by default to reduce clutter. Enable in M+ if minion health matters."  -- MT
L["GEMS_CVAR_NAMEPLATES_MINUS"] = "Trivial Enemies"  -- MT
L["GEMS_CVAR_NAMEPLATES_MINUS_DESC"] = "Show nameplates for trivial (minus) enemies. Useful in open world for seeing all mobs."  -- MT
L["GEMS_CVAR_NAMEPLATES_TOTEMS"] = "Enemy Totems"  -- MT
L["GEMS_CVAR_NAMEPLATES_TOTEMS_DESC"] = "Show enemy totem nameplates. Important in PvP -- totems are kill targets."  -- MT
L["GEMS_CVAR_NAMEPLATES_FRIENDLY"] = "Friendly Players"  -- MT
L["GEMS_CVAR_NAMEPLATES_FRIENDLY_DESC"] = "Show friendly player nameplates. Off in PvE to reduce clutter. On in PvP for awareness."  -- MT
L["GEMS_CVAR_NAMEPLATES_AURASCALE"] = "Aura Icon Scale"  -- MT
L["GEMS_CVAR_NAMEPLATES_AURASCALE_DESC"] = "Scale multiplier for buff/debuff icons on nameplates. 1.2 makes DoT tracking easier at a glance."  -- MT
L["GEMS_CVAR_NAMEPLATES_NAMEONLY"] = "Name Only Friendly"  -- MT
L["GEMS_CVAR_NAMEPLATES_NAMEONLY_DESC"] = "Strip friendly nameplates to name-only (no health bar). Reduces visual noise in raids."  -- MT
L["GEMS_CVAR_NAMEPLATES_ATBASE"] = "Position at Base"  -- MT
L["GEMS_CVAR_NAMEPLATES_ATBASE_DESC"] = "Position non-target nameplates at base of character instead of overhead. 0=overhead (standard)."  -- MT
L["GEMS_CVAR_NAMEPLATES_OFFSCREEN"] = "Show Offscreen"  -- MT
L["GEMS_CVAR_NAMEPLATES_OFFSCREEN_DESC"] = "Show nameplates for off-screen targets. Can be useful but also cluttery."  -- MT
L["GEMS_CVAR_NAMEPLATES_RADIAL"] = "Radial Position"  -- MT
L["GEMS_CVAR_NAMEPLATES_RADIAL_DESC"] = "Show target nameplate radially around screen edge when off-screen. 0=off."  -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTNP"] = "Soft Target Nameplate"  -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTNP_DESC"] = "Always show nameplate for soft-targeted enemy."  -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTSIZE"] = "Soft Target Size"  -- MT
L["GEMS_CVAR_NAMEPLATES_SOFTSIZE_DESC"] = "Size of the soft target indicator on nameplates. Default 19 can be hard to see. 25 is better."  -- MT
L["GEMS_CVAR_NAMEPLATES_DEBUFFPAD"] = "Debuff Padding"  -- MT
L["GEMS_CVAR_NAMEPLATES_DEBUFFPAD_DESC"] = "Padding between debuff list and health bar. 0 = compact."  -- MT
L["GEMS_CVAR_NAMEPLATES_MOTION"] = "Stacking Behavior"  -- MT
L["GEMS_CVAR_NAMEPLATES_MOTION_DESC"] = "Nameplate stacking. 0=overlapping, 1=stacking (vertical column), 2=spreading (default fan-out)."  -- MT
L["GEMS_CVAR_NAMEPLATES_MOTIONSPD"] = "Stacking Speed"  -- MT
L["GEMS_CVAR_NAMEPLATES_MOTIONSPD_DESC"] = "Animation speed for nameplates moving into stacked/spread positions. Higher = faster snapping."  -- MT
L["GEMS_CVAR_RAIDING_COMBATLOG"] = "Advanced Combat Logging"  -- MT
L["GEMS_CVAR_RAIDING_COMBATLOG_DESC"] = "Enable advanced combat logging (CLEU extra data). Required for accurate Warcraft Logs analysis."  -- MT
L["GEMS_CVAR_RAIDING_THREATWARN"] = "Threat Warning"  -- MT
L["GEMS_CVAR_RAIDING_THREATWARN_DESC"] = "Threat warning display. 0=off, 1=dungeons, 2=party, 3=always."  -- MT
L["GEMS_CVAR_RAIDING_THREATNUM"] = "Numeric Threat"  -- MT
L["GEMS_CVAR_RAIDING_THREATNUM_DESC"] = "Show numeric threat values on target/focus frames. Useful for tanks and threat-conscious DPS."  -- MT
L["GEMS_CVAR_RAIDING_THREATSOUND"] = "Threat Sounds"  -- MT
L["GEMS_CVAR_RAIDING_THREATSOUND_DESC"] = "Play sounds on threat transitions (aggro gain/loss)."  -- MT
L["GEMS_CVAR_RAIDING_THREATTEXT"] = "Threat World Text"  -- MT
L["GEMS_CVAR_RAIDING_THREATTEXT_DESC"] = "Show threat floaters in combat (the aggro text)."  -- MT
L["GEMS_CVAR_RAIDING_TIMELINE"] = "Encounter Timeline"  -- MT
L["GEMS_CVAR_RAIDING_TIMELINE_DESC"] = "Enable the boss encounter timeline. Shows upcoming boss abilities."  -- MT
L["GEMS_CVAR_RAIDING_TIMEROLE"] = "Timeline Role Filter"  -- MT
L["GEMS_CVAR_RAIDING_TIMEROLE_DESC"] = "Hide encounter timeline events irrelevant to your role. Reduces noise for DPS/healers."  -- MT
L["GEMS_CVAR_RAIDING_WARNINGS"] = "Encounter Warnings"  -- MT
L["GEMS_CVAR_RAIDING_WARNINGS_DESC"] = "Show encounter warning messages (boss ability alerts)."  -- MT
L["GEMS_CVAR_RAIDING_WARNHIDE"] = "Hide Non-Target Warns"  -- MT
L["GEMS_CVAR_RAIDING_WARNHIDE_DESC"] = "Hide boss warnings not targeting you. 0=show all (safer). 1=less noise for experienced raiders."  -- MT
L["GEMS_CVAR_RAIDING_AGGRO"] = "Aggro Highlight"  -- MT
L["GEMS_CVAR_RAIDING_AGGRO_DESC"] = "Highlight raid frames when that player has aggro."  -- MT
L["GEMS_CVAR_RAIDING_RDEBUFFS"] = "Raid Frame Debuffs"  -- MT
L["GEMS_CVAR_RAIDING_RDEBUFFS_DESC"] = "Show debuffs on raid frames. Essential for healers and dispellers."  -- MT
L["GEMS_CVAR_RAIDING_HEALPRED"] = "Incoming Heals"  -- MT
L["GEMS_CVAR_RAIDING_HEALPRED_DESC"] = "Show incoming heal predictions on raid frames."  -- MT
L["GEMS_CVAR_RAIDING_POWERBARS"] = "Raid Power Bars"  -- MT
L["GEMS_CVAR_RAIDING_POWERBARS_DESC"] = "Show mana/rage/energy bars on raid frames. Off by default to save space."  -- MT
L["GEMS_CVAR_RAIDING_RCLASSCOLOR"] = "Raid Class Colors"  -- MT
L["GEMS_CVAR_RAIDING_RCLASSCOLOR_DESC"] = "Color raid frame health bars by class. Makes it easier to identify players at a glance."  -- MT
L["GEMS_CVAR_RAIDING_DISPONLY"] = "Dispellable Only"  -- MT
L["GEMS_CVAR_RAIDING_DISPONLY_DESC"] = "Filter to only show debuffs you can dispel. 0=show all."  -- MT
L["GEMS_CVAR_RAIDING_ROLEDEBUFF"] = "Role Debuff Size"  -- MT
L["GEMS_CVAR_RAIDING_ROLEDEBUFF_DESC"] = "Show role-relevant debuffs at larger size. Tank debuffs bigger for tanks, healer debuffs for healers."  -- MT
L["GEMS_CVAR_RAIDING_BIGDEF"] = "Center Big Defensives"  -- MT
L["GEMS_CVAR_RAIDING_BIGDEF_DESC"] = "Show big defensive cooldowns (Ironbark, Pain Suppression) centered on the raid frame."  -- MT
L["GEMS_CVAR_RAIDING_DISPTYPE"] = "Dispel Indicator"  -- MT
L["GEMS_CVAR_RAIDING_DISPTYPE_DESC"] = "Dispel indicator style. 0=none, 1=icon, 2=icon+highlight."  -- MT
L["GEMS_CVAR_RAIDING_HEALTHTEXT"] = "Health Text Mode"  -- MT
L["GEMS_CVAR_RAIDING_HEALTHTEXT_DESC"] = "Health text display mode. none, health, losthealth, or perc. Preference-based."  -- MT
L["GEMS_CVAR_RAIDING_SORTMODE"] = "Raid Sort Mode"  -- MT
L["GEMS_CVAR_RAIDING_SORTMODE_DESC"] = "Raid frame sort mode. role (tanks/healers/DPS), group, or alphabetical."  -- MT
L["GEMS_CVAR_RAIDING_KEEPGRP"] = "Keep Groups Together"  -- MT
L["GEMS_CVAR_RAIDING_KEEPGRP_DESC"] = "Keep raid groups visually separated. 0=intermix, 1=group blocks."  -- MT
L["GEMS_CVAR_RAIDING_TANKASSIST"] = "Tank and Assist"  -- MT
L["GEMS_CVAR_RAIDING_TANKASSIST_DESC"] = "Show main tank and main assist units in raid frames."  -- MT
L["GEMS_CVAR_RAIDING_FINDSELF"] = "Find Yourself"  -- MT
L["GEMS_CVAR_RAIDING_FINDSELF_DESC"] = "Highlight your own character in raid frames."  -- MT
L["GEMS_CVAR_RAIDING_CASTBUFFS"] = "Castable Buffs"  -- MT
L["GEMS_CVAR_RAIDING_CASTBUFFS_DESC"] = "Show only buffs you can cast (raid only). 0=show all."  -- MT
L["GEMS_CVAR_RAIDING_DISPDEBUFFS"] = "Show Dispel Debuffs"  -- MT
L["GEMS_CVAR_RAIDING_DISPDEBUFFS_DESC"] = "Show only debuffs you can dispel (raid only)."  -- MT
L["GEMS_CVAR_RAIDING_RAIDSETTINGS"] = "Raid Graphics Settings"  -- MT
L["GEMS_CVAR_RAIDING_RAIDSETTINGS_DESC"] = "Enable separate graphics settings for raids. Biggest single raid FPS improvement. Many players miss this."  -- MT
L["GEMS_CVAR_RAIDING_NOFILTER"] = "No Buff/Debuff Filter"  -- MT
L["GEMS_CVAR_RAIDING_NOFILTER_DESC"] = "Disable ALL buff/debuff filtering on target frame. 0=normal filtering. 1=see everything."  -- MT
L["GEMS_CVAR_RAIDING_SPELLCLUTTER"] = "Spell Visual Clutter"  -- MT
L["GEMS_CVAR_RAIDING_SPELLCLUTTER_DESC"] = "Spell visual density. 1=essential only, 2=reduced, 3=some, 4=everything. Lower = cleaner raids."  -- MT
L["GEMS_CVAR_RAIDING_MYSPELLS"] = "Emphasize My Spells"  -- MT
L["GEMS_CVAR_RAIDING_MYSPELLS_DESC"] = "Tone down other players' spell effects while keeping yours at full. Essential in 20-man raids."  -- MT
L["GEMS_CVAR_RAIDING_COMBATWARN"] = "Combat Warnings"  -- MT
L["GEMS_CVAR_RAIDING_COMBATWARN_DESC"] = "Master toggle for combat warning UI (boss timeline + warnings)."  -- MT
L["GEMS_CVAR_DUNGEON_DPSRESET"] = "DPS Meter Reset"  -- MT
L["GEMS_CVAR_DUNGEON_DPSRESET_DESC"] = "Auto-reset damage meter on new instance entry. Clean data per dungeon without manual reset."  -- MT
L["GEMS_CVAR_DUNGEON_ENTRANCE"] = "Dungeon Entrances"  -- MT
L["GEMS_CVAR_DUNGEON_ENTRANCE_DESC"] = "Show dungeon entrance icons on the world map."  -- MT
L["GEMS_CVAR_DUNGEON_CLUTTER"] = "Unit Clutter Filter"  -- MT
L["GEMS_CVAR_DUNGEON_CLUTTER_DESC"] = "Limit unit clutter (NPC stacking reduction) to instances only."  -- MT
L["GEMS_CVAR_DUNGEON_ENEMYCAST"] = "Enemy Cast Bars"  -- MT
L["GEMS_CVAR_DUNGEON_ENEMYCAST_DESC"] = "Show enemy cast bars on arena frames. Also affects M+ party awareness."  -- MT
L["GEMS_CVAR_DUNGEON_LOGTIME"] = "Log Retention Time"  -- MT
L["GEMS_CVAR_DUNGEON_LOGTIME_DESC"] = "Seconds to keep combat log entries. 300s default. Increase to 600 for long M+ pulls."  -- MT
L["GEMS_CVAR_DUNGEON_LOGFILE"] = "Unique Log Filenames"  -- MT
L["GEMS_CVAR_DUNGEON_LOGFILE_DESC"] = "Use timestamped combat log filenames. Prevents overwriting previous logs."  -- MT
L["GEMS_CVAR_DUNGEON_DIMINISH"] = "CC Diminishing Returns"  -- MT
L["GEMS_CVAR_DUNGEON_DIMINISH_DESC"] = "Show crowd control diminishing returns on enemy frames."  -- MT
L["GEMS_CVAR_SOLO_AUTOLOOT"] = "Auto Loot"  -- MT
L["GEMS_CVAR_SOLO_AUTOLOOT_DESC"] = "Auto-loot items. Default OFF means clicking each item individually. Almost every player wants this ON."  -- MT
L["GEMS_CVAR_SOLO_LOOTRATE"] = "Loot Speed"  -- MT
L["GEMS_CVAR_SOLO_LOOTRATE_DESC"] = "Milliseconds between auto-loot ticks. Default 150ms feels sluggish. 50ms loots almost instantly."  -- MT
L["GEMS_CVAR_SOLO_LOOTMOUSE"] = "Loot at Cursor"  -- MT
L["GEMS_CVAR_SOLO_LOOTMOUSE_DESC"] = "Open loot window at mouse cursor. Saves mouse travel."  -- MT
L["GEMS_CVAR_SOLO_AELOOT"] = "AoE Looting"  -- MT
L["GEMS_CVAR_SOLO_AELOOT_DESC"] = "Disable area-of-effect looting. 0=AoE loot enabled (loot all nearby corpses at once)."  -- MT
L["GEMS_CVAR_SOLO_DISMOUNT"] = "Auto Dismount"  -- MT
L["GEMS_CVAR_SOLO_DISMOUNT_DESC"] = "Auto-dismount when casting."  -- MT
L["GEMS_CVAR_SOLO_DISMOUNTFLY"] = "Dismount While Flying"  -- MT
L["GEMS_CVAR_SOLO_DISMOUNTFLY_DESC"] = "Auto-dismount while flying (you will fall). Default OFF is sane."  -- MT
L["GEMS_CVAR_SOLO_TOT"] = "Target of Target"  -- MT
L["GEMS_CVAR_SOLO_TOT_DESC"] = "Show target-of-target frame. Essential for tanks (see what the boss targets) and DPS."  -- MT
L["GEMS_CVAR_SOLO_TCASTBAR"] = "Target Cast Bar"  -- MT
L["GEMS_CVAR_SOLO_TCASTBAR_DESC"] = "Show your target's cast bar. Essential for interrupting."  -- MT
L["GEMS_CVAR_SOLO_QUESTWATCH"] = "Auto Quest Watch"  -- MT
L["GEMS_CVAR_SOLO_QUESTWATCH_DESC"] = "Auto-track quests in the objective tracker when obtained."  -- MT
L["GEMS_CVAR_SOLO_QUESTPOI"] = "Quest POI on Map"  -- MT
L["GEMS_CVAR_SOLO_QUESTPOI_DESC"] = "Show quest points of interest on the world map."  -- MT
L["GEMS_CVAR_SOLO_PARTYPETS"] = "Show Party Pets"  -- MT
L["GEMS_CVAR_SOLO_PARTYPETS_DESC"] = "Show pet frames in party UI. Off by default to save screen space."  -- MT
L["GEMS_CVAR_SOLO_INTERACT"] = "Soft Interact"  -- MT
L["GEMS_CVAR_SOLO_INTERACT_DESC"] = "Soft targeting for interactive objects. 0=off, 1=gamepad, 3=always. Huge QoL for questing."  -- MT
L["GEMS_CVAR_SOLO_INTERARC"] = "Interact Arc"  -- MT
L["GEMS_CVAR_SOLO_INTERARC_DESC"] = "Directional constraint for interact soft target. 0=must face directly, 1=front arc, 2=anywhere."  -- MT
L["GEMS_CVAR_SOLO_INTERRANGE"] = "Interact Range"  -- MT
L["GEMS_CVAR_SOLO_INTERRANGE_DESC"] = "Max range for soft interact detection (yards). 10 is the default and cap."  -- MT
L["GEMS_CVAR_SOLO_INTERICON"] = "Interact Icon"  -- MT
L["GEMS_CVAR_SOLO_INTERICON_DESC"] = "Show icon indicator for soft interact targets. Keep on for visual feedback."  -- MT
L["GEMS_CVAR_SOLO_AUTOINTER"] = "Auto Move to Interact"  -- MT
L["GEMS_CVAR_SOLO_AUTOINTER_DESC"] = "Auto-move to interact target. Can be disorienting in combat areas. Informational."  -- MT
L["GEMS_CVAR_SOLO_QUESTITEMS"] = "Quest Item Interact"  -- MT
L["GEMS_CVAR_SOLO_QUESTITEMS_DESC"] = "Allow quest item use as an interaction. Enables using quest items directly from soft-interact."  -- MT
L["GEMS_CVAR_UI_TUTORIALS"] = "Tutorial Popups"  -- MT
L["GEMS_CVAR_UI_TUTORIALS_DESC"] = "Display tutorial popups. Experienced players should disable -- tutorials interrupt gameplay."  -- MT
L["GEMS_CVAR_UI_NPE"] = "New Player Tutorials"  -- MT
L["GEMS_CVAR_UI_NPE_DESC"] = "Display New Player Experience tutorials. Disable for experienced players."  -- MT
L["GEMS_CVAR_UI_LOADTIPS"] = "Loading Screen Tips"  -- MT
L["GEMS_CVAR_UI_LOADTIPS_DESC"] = "Show tips on loading screens. Low-cost, occasionally useful."  -- MT
L["GEMS_CVAR_UI_COMPARE"] = "Compare Items"  -- MT
L["GEMS_CVAR_UI_COMPARE_DESC"] = "Always show item comparison tooltips when hovering gear."  -- MT
L["GEMS_CVAR_UI_TOOLTIPS"] = "Detailed Tooltips"  -- MT
L["GEMS_CVAR_UI_TOOLTIPS_DESC"] = "Show verbose/detailed tooltips with stats."  -- MT
L["GEMS_CVAR_UI_TRANSMOG"] = "Missing Transmog Source"  -- MT
L["GEMS_CVAR_UI_TRANSMOG_DESC"] = "Show if you are missing a transmog appearance source. Hidden gem for collectors."  -- MT
L["GEMS_CVAR_UI_SSFORMAT"] = "Screenshot Format"  -- MT
L["GEMS_CVAR_UI_SSFORMAT_DESC"] = "Screenshot file format. TGA is lossless, JPEG saves disk space but looks worse."  -- MT
L["GEMS_CVAR_UI_SSQUALITY"] = "Screenshot Quality"  -- MT
L["GEMS_CVAR_UI_SSQUALITY_DESC"] = "JPEG quality (1-10). Default 3 is very low. If using JPEG, use 10."  -- MT
L["GEMS_CVAR_UI_ZOOM"] = "Camera Zoom Distance"  -- MT
L["GEMS_CVAR_UI_ZOOM_DESC"] = "Max camera zoom-out multiplier. Default 1.9 feels close. 2.6 gives more battlefield awareness."  -- MT
L["GEMS_CVAR_UI_EDGEFLASH"] = "Screen Edge Flash"  -- MT
L["GEMS_CVAR_UI_EDGEFLASH_DESC"] = "Red flash at screen edges while in combat with map open. Safety reminder."  -- MT
L["GEMS_CVAR_UI_BUBBLES"] = "Chat Bubbles"  -- MT
L["GEMS_CVAR_UI_BUBBLES_DESC"] = "Show in-game speech bubbles."  -- MT
L["GEMS_CVAR_UI_BIGNUMS"] = "Break Up Numbers"  -- MT
L["GEMS_CVAR_UI_BIGNUMS_DESC"] = "Use commas in large numbers (1,000,000 vs 1000000)."  -- MT
L["GEMS_CVAR_UI_BUFFDUR"] = "Buff Durations"  -- MT
L["GEMS_CVAR_UI_BUFFDUR_DESC"] = "Show remaining duration on buff icons."  -- MT
L["GEMS_CVAR_UI_COMBOPT"] = "Combo Point Location"  -- MT
L["GEMS_CVAR_UI_COMBOPT_DESC"] = "Combo point display. 1=on target frame, 2=on self (below personal resource display)."  -- MT
L["GEMS_CVAR_UI_FSTACK"] = "Frame Stack Debug"  -- MT
L["GEMS_CVAR_UI_FSTACK_DESC"] = "Enable frame stack tooltip (developer tool). Shows frame names on hover. Useful for debugging."  -- MT
L["GEMS_CVAR_UI_RAWMOUSE"] = "Raw Mouse Input"  -- MT
L["GEMS_CVAR_UI_RAWMOUSE_DESC"] = "Raw mouse input bypass. Deprecated/broken as of 2024 patches. Informational only."  -- MT
L["GEMS_CVAR_UI_TAINT"] = "Taint Log"  -- MT
L["GEMS_CVAR_UI_TAINT_DESC"] = "Taint debugging log. 0=off, 1=log to file, 2=log+chat. Addon developers set to 1 for debugging."  -- MT
L["GEMS_CVAR_UI_BAGS"] = "Combined Bags"  -- MT
L["GEMS_CVAR_UI_BAGS_DESC"] = "Display all bags as one combined inventory view. Added in Dragonflight. Much cleaner management."  -- MT
L["GEMS_CVAR_UI_ROTATEMM"] = "Rotate Minimap"  -- MT
L["GEMS_CVAR_UI_ROTATEMM_DESC"] = "Rotate minimap to match player facing direction instead of fixed north-up. Preference-based."  -- MT
L["GEMS_CVAR_FPS_MAXFPS"] = "Max FPS"  -- MT
L["GEMS_CVAR_FPS_MAXFPS_DESC"] = "FPS cap. Should match your monitor's refresh rate. Going higher wastes GPU."  -- MT
L["GEMS_CVAR_FPS_BGFPS"] = "Background FPS"  -- MT
L["GEMS_CVAR_FPS_BGFPS_DESC"] = "Background FPS cap (game not focused). 30 saves power/heat. Lower to 8 for maximum savings."  -- MT
L["GEMS_CVAR_FPS_LOADFPS"] = "Loading Screen FPS"  -- MT
L["GEMS_CVAR_FPS_LOADFPS_DESC"] = "Loading screen FPS cap. Low is fine -- no gameplay during loads."  -- MT
L["GEMS_CVAR_FPS_USEMAXFPS"] = "Enable FPS Cap"  -- MT
L["GEMS_CVAR_FPS_USEMAXFPS_DESC"] = "Enable the FPS cap. Default OFF means uncapped FPS (wastes GPU, causes heat)."  -- MT
L["GEMS_CVAR_FPS_VSYNC"] = "Vertical Sync"  -- MT
L["GEMS_CVAR_FPS_VSYNC_DESC"] = "Prevents screen tearing but adds input lag. For competitive play, disable and use FPS cap instead."  -- MT
L["GEMS_CVAR_FPS_TARGETFPS"] = "Target FPS"  -- MT
L["GEMS_CVAR_FPS_TARGETFPS_DESC"] = "Target FPS for dynamic quality scaling. Game auto-lowers settings to hit this."  -- MT
L["GEMS_CVAR_FPS_USETARGET"] = "Use Target FPS"  -- MT
L["GEMS_CVAR_FPS_USETARGET_DESC"] = "Enable target FPS system. Can cause jarring quality fluctuations. Prefer static settings."  -- MT
L["GEMS_CVAR_FPS_LATENCY"] = "GPU Frame Latency"  -- MT
L["GEMS_CVAR_FPS_LATENCY_DESC"] = "Max frames CPU can queue ahead of GPU. Default 3 = ~50ms lag at 60fps. 1 = ~16ms, worth it for macros."  -- MT
L["GEMS_CVAR_FPS_RSCALE"] = "Render Scale"  -- MT
L["GEMS_CVAR_FPS_RSCALE_DESC"] = "Render resolution multiplier. 1.0 = native. Below 1.0 = blurry but faster. Above 1.0 = supersampling."  -- MT
L["GEMS_CVAR_FPS_DYNSCALE"] = "Dynamic Render Scale"  -- MT
L["GEMS_CVAR_FPS_DYNSCALE_DESC"] = "Auto-lower render scale when GPU-bound. Beta feature -- can cause hitching. Leave off unless needed."  -- MT
L["GEMS_CVAR_FPS_LOWLAT"] = "Low Latency Mode"  -- MT
L["GEMS_CVAR_FPS_LOWLAT_DESC"] = "Low latency rendering. 0=none, 2=Reflex (NVIDIA), 4=XeLL (Intel). AMD users leave at 0."  -- MT
L["GEMS_CVAR_FPS_MULTITHREAD"] = "Multi-Thread Rendering"  -- MT
L["GEMS_CVAR_FPS_MULTITHREAD_DESC"] = "Multi-threaded rendering. Disabling significantly reduces framerate. Never set to 0."  -- MT
L["GEMS_CVAR_FPS_SPELLCLUTTER"] = "Spell Visual Density"  -- MT
L["GEMS_CVAR_FPS_SPELLCLUTTER_DESC"] = "Global spell visual density. 1=essential only, 4=everything. Lower = max FPS gain."  -- MT
L["GEMS_CVAR_FPS_PARTICLES"] = "Particle Density"  -- MT
L["GEMS_CVAR_FPS_PARTICLES_DESC"] = "Particle effect density (percentage). Reducing to 50 improves FPS in particle-heavy fights."  -- MT
L["GEMS_CVAR_FPS_WEATHER"] = "Weather Density"  -- MT
L["GEMS_CVAR_FPS_WEATHER_DESC"] = "Weather effect density. Reducing removes rain/snow particles."  -- MT
L["GEMS_CVAR_FPS_ANIMLOD"] = "Animation Frame Skip"  -- MT
L["GEMS_CVAR_FPS_ANIMLOD_DESC"] = "Skip animation frames for distant characters. Saves CPU with no visible impact."  -- MT
L["GEMS_CVAR_FPS_VFXDENSITY"] = "VFX Density Filter"  -- MT
L["GEMS_CVAR_FPS_VFXDENSITY_DESC"] = "Alternative spell visual density control. Works alongside spellClutter as a second-pass filter."  -- MT
L["GEMS_CVAR_VISUAL_QUALITY"] = "Graphics Quality"  -- MT
L["GEMS_CVAR_VISUAL_QUALITY_DESC"] = "Master graphics quality preset (1-10). Changes all sub-settings at once. Informational."  -- MT
L["GEMS_CVAR_VISUAL_SHADOWS"] = "Shadow Quality"  -- MT
L["GEMS_CVAR_VISUAL_SHADOWS_DESC"] = "Shadow quality (1-5). Shadows are GPU-expensive. Lowering to 1-2 gives significant FPS gains."  -- MT
L["GEMS_CVAR_VISUAL_SSAO"] = "Ambient Occlusion"  -- MT
L["GEMS_CVAR_VISUAL_SSAO_DESC"] = "Screen-space ambient occlusion quality. Adds depth to shadows. 0=off (fastest), 4=highest."  -- MT
L["GEMS_CVAR_VISUAL_VIEWDIST"] = "View Distance"  -- MT
L["GEMS_CVAR_VISUAL_VIEWDIST_DESC"] = "View distance (1-10). Lowering to 5 saves GPU with little visual impact in instanced content."  -- MT
L["GEMS_CVAR_VISUAL_GROUND"] = "Ground Clutter"  -- MT
L["GEMS_CVAR_VISUAL_GROUND_DESC"] = "Grass/ground detail density (1-10). Pure cosmetic -- lowering has zero gameplay impact and saves FPS."  -- MT
L["GEMS_CVAR_VISUAL_TEXRES"] = "Texture Resolution"  -- MT
L["GEMS_CVAR_VISUAL_TEXRES_DESC"] = "Texture resolution quality (1-3). Affects VRAM usage. Lower if VRAM-limited."  -- MT
L["GEMS_CVAR_VISUAL_LIQUID"] = "Water Quality"  -- MT
L["GEMS_CVAR_VISUAL_LIQUID_DESC"] = "Water rendering quality. Lower = less reflective water, better FPS near water."  -- MT
L["GEMS_CVAR_VISUAL_PROJTEX"] = "Projected Textures"  -- MT
L["GEMS_CVAR_VISUAL_PROJTEX_DESC"] = "Spell ground effects (Healing Rain, Consecration). MUST be on -- without it, boss mechanics are invisible."  -- MT
L["GEMS_CVAR_VISUAL_OUTLINE"] = "Outline Mode"  -- MT
L["GEMS_CVAR_VISUAL_OUTLINE_DESC"] = "Character/NPC outline mode. 0=none, 1=thin, 2=normal. Helps with visibility."  -- MT
L["GEMS_CVAR_VISUAL_AA"] = "Anti-Aliasing"  -- MT
L["GEMS_CVAR_VISUAL_AA_DESC"] = "Anti-aliasing mode. 0=none, 1=FXAA low, 2=FXAA high, 3=CMAA. CMAA is best quality-to-cost ratio."  -- MT
L["GEMS_CVAR_VISUAL_GLOW"] = "Glow Effect"  -- MT
L["GEMS_CVAR_VISUAL_GLOW_DESC"] = "Full-screen glow effect. Subtle but adds atmosphere."  -- MT
L["GEMS_CVAR_VISUAL_DEATH"] = "Death Effect"  -- MT
L["GEMS_CVAR_VISUAL_DEATH_DESC"] = "Death desaturation effect. Greyscale when dead."  -- MT
L["GEMS_CVAR_VISUAL_SHARPEN"] = "Sharpening Pass"  -- MT
L["GEMS_CVAR_VISUAL_SHARPEN_DESC"] = "Enable sharpening even without FSR upscaling. Makes image crisper at native resolution. Hidden CVar."  -- MT
L["GEMS_CVAR_VISUAL_SHARPNESS"] = "Sharpening Strength"  -- MT
L["GEMS_CVAR_VISUAL_SHARPNESS_DESC"] = "Sharpening strength [0.0-2.0]. Only active when ResampleAlwaysSharpen=1 or FSR is enabled."  -- MT
L["GEMS_CVAR_VISUAL_FARCLIP"] = "Far Clip Plane"  -- MT
L["GEMS_CVAR_VISUAL_FARCLIP_DESC"] = "Max render distance in world units. Lower = less distant geometry = better FPS. 800 is sufficient."  -- MT
L["GEMS_CVAR_SOUND_MASTER"] = "Master Sound Toggle"  -- MT
L["GEMS_CVAR_SOUND_MASTER_DESC"] = "Master sound toggle. Must be on for any audio."  -- MT
L["GEMS_CVAR_SOUND_MASTERVOL"] = "Master Volume"  -- MT
L["GEMS_CVAR_SOUND_MASTERVOL_DESC"] = "Master volume (0.0-1.0). 0.8 gives headroom for Discord/Spotify alongside WoW."  -- MT
L["GEMS_CVAR_SOUND_SFX"] = "SFX Volume"  -- MT
L["GEMS_CVAR_SOUND_SFX_DESC"] = "Sound effects volume. Keep at 1.0 for combat audio cues."  -- MT
L["GEMS_CVAR_SOUND_MUSIC"] = "Music Volume"  -- MT
L["GEMS_CVAR_SOUND_MUSIC_DESC"] = "Music volume. Lower during raids/dungeons to hear boss ability audio cues."  -- MT
L["GEMS_CVAR_SOUND_AMBIENCE"] = "Ambience Volume"  -- MT
L["GEMS_CVAR_SOUND_AMBIENCE_DESC"] = "Ambient sound volume. Lower in raids -- ambient noise can mask important combat audio."  -- MT
L["GEMS_CVAR_SOUND_DIALOG"] = "Dialog Volume"  -- MT
L["GEMS_CVAR_SOUND_DIALOG_DESC"] = "Voice/dialog volume (boss VO, quest narration)."  -- MT
L["GEMS_CVAR_SOUND_BGAUDIO"] = "Background Audio"  -- MT
L["GEMS_CVAR_SOUND_BGAUDIO_DESC"] = "Play sound when WoW is in background. Important for queue pops and ready checks while alt-tabbed."  -- MT
L["GEMS_CVAR_SOUND_ENCWARN"] = "Encounter Warning Sounds"  -- MT
L["GEMS_CVAR_SOUND_ENCWARN_DESC"] = "Play sounds for encounter/boss warnings."  -- MT
L["GEMS_CVAR_SOUND_ENCVOL"] = "Encounter Warning Volume"  -- MT
L["GEMS_CVAR_SOUND_ENCVOL_DESC"] = "Volume for encounter warning sounds (0.0-1.0)."  -- MT
L["GEMS_CVAR_SOUND_ERRSPEECH"] = "Error Speech"  -- MT
L["GEMS_CVAR_SOUND_ERRSPEECH_DESC"] = "Error voice (not enough mana, etc). Disable -- macro sequences hitting cooldowns trigger this rapidly."  -- MT
L["GEMS_CVAR_SOUND_GAMEPLAY"] = "Gameplay SFX"  -- MT
L["GEMS_CVAR_SOUND_GAMEPLAY_DESC"] = "Enable gameplay-specific sound effects."  -- MT
L["GEMS_CVAR_FCT_ENABLE"] = "Floating Combat Text"  -- MT
L["GEMS_CVAR_FCT_ENABLE_DESC"] = "Master toggle for floating combat text. Off by default! Enable to see damage/healing numbers."  -- MT
L["GEMS_CVAR_FCT_DAMAGE"] = "Damage Numbers"  -- MT
L["GEMS_CVAR_FCT_DAMAGE_DESC"] = "Show damage numbers on hostile targets."  -- MT
L["GEMS_CVAR_FCT_AUTOS"] = "Auto-Attack Numbers"  -- MT
L["GEMS_CVAR_FCT_AUTOS_DESC"] = "Show ALL auto-attack numbers (not just crits/procs)."  -- MT
L["GEMS_CVAR_FCT_HEALING"] = "Healing Numbers"  -- MT
L["GEMS_CVAR_FCT_HEALING_DESC"] = "Show healing numbers on targets."  -- MT
L["GEMS_CVAR_FCT_ABSSELF"] = "Self Absorbs"  -- MT
L["GEMS_CVAR_FCT_ABSSELF_DESC"] = "Show shield/absorb amounts applied to yourself."  -- MT
L["GEMS_CVAR_FCT_ABSTARGET"] = "Target Absorbs"  -- MT
L["GEMS_CVAR_FCT_ABSTARGET_DESC"] = "Show shield/absorb amounts applied to your target."  -- MT
L["GEMS_CVAR_FCT_PERIODIC"] = "Periodic Damage"  -- MT
L["GEMS_CVAR_FCT_PERIODIC_DESC"] = "Show DoT/HoT tick numbers."  -- MT
L["GEMS_CVAR_FCT_DODGEMISS"] = "Dodge/Parry/Miss"  -- MT
L["GEMS_CVAR_FCT_DODGEMISS_DESC"] = "Show dodge/parry/miss text. Useful for seeing when abilities are avoided."  -- MT
L["GEMS_CVAR_FCT_LOWRES"] = "Low Resource Warning"  -- MT
L["GEMS_CVAR_FCT_LOWRES_DESC"] = "Show low mana/health warnings."  -- MT
L["GEMS_CVAR_FCT_FLOATMODE"] = "Float Direction"  -- MT
L["GEMS_CVAR_FCT_FLOATMODE_DESC"] = "Float direction. 1=up, 2=down, 3=arc. 1 (up) is standard."  -- MT
L["GEMS_CVAR_FCT_DIRSCALE"] = "Directional Scale"  -- MT
L["GEMS_CVAR_FCT_DIRSCALE_DESC"] = "Directional damage number movement scale. 0=no directional movement. 1.0=default."  -- MT
L["GEMS_CVAR_FCT_PETMELEE"] = "Pet Melee Damage"  -- MT
L["GEMS_CVAR_FCT_PETMELEE_DESC"] = "Show pet melee damage numbers. Important for pet-class macros (BM Hunter, Demo Warlock)."  -- MT
L["GEMS_CVAR_FCT_PETSPELL"] = "Pet Spell Damage"  -- MT
L["GEMS_CVAR_FCT_PETSPELL_DESC"] = "Show pet spell damage numbers."  -- MT
L["GEMS_CVAR_FCT_REACTIVES"] = "Reactive Procs"  -- MT
L["GEMS_CVAR_FCT_REACTIVES_DESC"] = "Show reactive ability procs (Overpower, Revenge). Helps spot procs macro sequences should react to."  -- MT
L["GEMS_CVAR_FCT_ENERGY"] = "Energy Gains"  -- MT
L["GEMS_CVAR_FCT_ENERGY_DESC"] = "Show energy/rage/mana gain numbers. Off by default -- can be very spammy."  -- MT
L["GEMS_CVAR_FCT_AURAS"] = "Buff/Debuff Text"  -- MT
L["GEMS_CVAR_FCT_AURAS_DESC"] = "Show buff/debuff application text. Off by default -- very spammy in group content."  -- MT
L["GEMS_CVAR_FCT_HEALERS"] = "Healer Names"  -- MT
L["GEMS_CVAR_FCT_HEALERS_DESC"] = "Show name of healer who healed you."  -- MT
L["GEMS_CVAR_ACCESS_COLORBLIND"] = "Colorblind Mode"  -- MT
L["GEMS_CVAR_ACCESS_COLORBLIND_DESC"] = "Colorblind mode. 0=off, 1=Protanopia, 2=Deuteranopia, 3=Tritanopia. Informational."  -- MT
L["GEMS_CVAR_ACCESS_CENTERED"] = "Keep Centered"  -- MT
L["GEMS_CVAR_ACCESS_CENTERED_DESC"] = "Keep character head at screen center as a motion reference point. Reduces motion sickness."  -- MT
L["GEMS_CVAR_ACCESS_REDUCEMOVE"] = "Reduce Movement"  -- MT
L["GEMS_CVAR_ACCESS_REDUCEMOVE_DESC"] = "Reduce camera movement without player input. Helps with motion sickness but can feel unresponsive."  -- MT
L["GEMS_CVAR_ACCESS_FOCAL"] = "Focal Circle"  -- MT
L["GEMS_CVAR_ACCESS_FOCAL_DESC"] = "Show a focal circle when mounted. Reduces motion sickness during fast movement."  -- MT
L["GEMS_CVAR_ACCESS_TEXTCONTRAST"] = "Quest Text Contrast"  -- MT
L["GEMS_CVAR_ACCESS_TEXTCONTRAST_DESC"] = "Increase text contrast in quest UIs. Helps with readability."  -- MT
L["GEMS_CVAR_ACCESS_CAA"] = "Combat Audio Alerts"  -- MT
L["GEMS_CVAR_ACCESS_CAA_DESC"] = "Audio cues for combat events (health thresholds, ability readiness). Useful for visually impaired players."  -- MT
L["GEMS_CVAR_DRAGON_DYNFOV"] = "Dynamic FOV"  -- MT
L["GEMS_CVAR_DRAGON_DYNFOV_DESC"] = "Dynamic field-of-view based on gliding speed. Creates a sense of speed. Disable if motion sickness."  -- MT
L["GEMS_CVAR_DRAGON_MAXPITCH"] = "Max Pitch Rate"  -- MT
L["GEMS_CVAR_DRAGON_MAXPITCH_DESC"] = "Maximum pitch rate for keyboard dragonriding. Default 5 can feel sluggish. 6-7 is more responsive."  -- MT
L["GEMS_CVAR_DRAGON_MAXTURN"] = "Max Turn Rate"  -- MT
L["GEMS_CVAR_DRAGON_MAXTURN_DESC"] = "Maximum turn rate for keyboard dragonriding. Default 8 can feel slow. 10 improves maneuverability."  -- MT
L["GEMS_CVAR_DRAGON_MINPITCH"] = "Min Pitch Rate"  -- MT
L["GEMS_CVAR_DRAGON_MINPITCH_DESC"] = "Minimum pitch rate. Affects fine-grained pitch control. Slightly higher gives more precise control."  -- MT
L["GEMS_CVAR_DRAGON_PITCHCTRL"] = "Pitch Control Mode"  -- MT
L["GEMS_CVAR_DRAGON_PITCHCTRL_DESC"] = "How forward/back inputs affect pitch. 3=toggle. Most comfortable for keyboard players."  -- MT

-- Feature: CVar Profiles & Context-Aware Switching (Phase 2)
L["GEMS_CVAR_PROFILE_GENERAL"] = "General (Default)"  -- MT
L["GEMS_CVAR_PROFILE_RAID"] = "Raid"  -- MT
L["GEMS_CVAR_PROFILE_RAID_DESC"] = "Optimized for raid encounters: tighter plate range, stacking nameplate motion"  -- MT
L["GEMS_CVAR_PROFILE_MPLUS"] = "Mythic+"  -- MT
L["GEMS_CVAR_PROFILE_MPLUS_DESC"] = "Optimized for Mythic+ dungeons: enemy minion plates, tighter range"  -- MT
L["GEMS_CVAR_PROFILE_SOLO"] = "Solo / Open World"  -- MT
L["GEMS_CVAR_PROFILE_SOLO_DESC"] = "Optimized for solo content: full visuals, wider interact arc, plates off"  -- MT
L["GEMS_CVAR_PROFILE_PVP"] = "PvP"  -- MT
L["GEMS_CVAR_PROFILE_PVP_DESC"] = "Optimized for PvP: friendly plates on, enemy minions, stacking motion"  -- MT
L["GEMS_CVAR_PROFILE_ACTIVE"] = "Active Profile: %s"  -- MT
L["GEMS_CVAR_PROFILE_SELECT"] = "Select Profile"  -- MT
L["GEMS_CVAR_PROFILE_AUTO"] = "Auto (context-aware)"  -- MT
L["GEMS_CVAR_PROFILE_AUTOSWITCH"] = "Auto-switch by context"  -- MT
L["GEMS_CVAR_PROFILE_AUTOSWITCH_DESC"] = "Automatically switch CVar profile when entering raids, dungeons, PvP, or open world"  -- MT
L["GEMS_CVAR_PROFILE_MANAGE"] = "Manage Profiles..."  -- MT
L["GEMS_CVAR_PROFILE_CREATE"] = "Create Profile"  -- MT
L["GEMS_CVAR_PROFILE_CREATE_NAME"] = "Profile Name:"  -- MT
L["GEMS_CVAR_PROFILE_CLONE_FROM"] = "Clone From:"  -- MT
L["GEMS_CVAR_PROFILE_DELETE"] = "Delete Profile"  -- MT
L["GEMS_CVAR_PROFILE_DELETE_CONFIRM"] = "Delete custom profile \"%s\"? This cannot be undone."  -- MT
L["GEMS_CVAR_PROFILE_OVERRIDE"] = "Profile Override"  -- MT
L["GEMS_CVAR_PROFILE_OVERRIDE_NONE"] = "No override (use General)"  -- MT
L["GEMS_CVAR_PROFILE_ADD_OVERRIDE"] = "Add Override..."  -- MT
L["GEMS_CVAR_PROFILE_SWITCHED"] = "CVar profile switched to: %s"  -- MT
L["GEMS_CVAR_PROFILE_QUEUED"] = "%d secure CVars queued (applied out of combat)"  -- MT
L["GEMS_CVAR_CHANGES_DETECTED"] = "%d CVars changed since last session"  -- MT
L["GEMS_CVAR_CHANGES_DISMISS"] = "Dismiss"  -- MT
L["GEMS_CVAR_CHANGES_FIX_ALL"] = "Fix All Changed"  -- MT
L["GEMS_CVAR_CHANGES_CAUSE_PATCH"] = "Likely: game patch reset"  -- MT
L["GEMS_CVAR_CHANGES_CAUSE_ADDON"] = "Likely: changed by addon/UI"  -- MT
L["GEMS_CVAR_CHANGES_CAUSE_AUTOFIX"] = "Auto-fixed by EMS"  -- MT
L["GEMS_CVAR_CHANGES_CAUSE_UNKNOWN"] = "Changed since last session"  -- MT
L["GEMS_CVAR_PROFILE_NOT_FOUND"] = "Unknown profile: %s"  -- MT
L["GEMS_CVAR_AUTO_TOGGLED"] = "CVar auto-switch: %s"  -- MT
L["GEMS_CVAR_NO_CHANGES"] = "No CVar changes detected since last session"  -- MT
L["GEMS_CVAR_PROFILE_RENAME"] = "Rename"  -- MT
L["GEMS_CVAR_PROFILE_OVERRIDES"] = "Overrides (%d)"  -- MT
L["GEMS_CVAR_PROFILE_NO_OVERRIDES"] = "No overrides"  -- MT
L["GEMS_CVAR_MAP_HEADER"] = "Context Profile Map"  -- MT
L["GEMS_CVAR_MAP_DESC"] = "Choose which CVar profile applies for each context"  -- MT
L["GEMS_CVAR_MAP_DEFAULT"] = "Default (%s)"  -- MT
L["GEMS_CVAR_MAP_NONE"] = "General (no profile)"  -- MT

-- SQW Optimizer
L["GEMS_SQW_OPTIMIZER"] = "Dynamic SQW Optimizer"  -- MT
L["GEMS_SQW_OPTIMIZER_DESC"] = "Automatically adjusts SpellQueueWindow based on network latency"  -- MT
L["GEMS_SQW_BUFFER"] = "Safety Buffer (ms)"  -- MT
L["GEMS_SQW_BUFFER_DESC"] = "Higher = fewer gaps, lower = more responsive. 100ms recommended."  -- MT
L["GEMS_SQW_LIVE"] = "SQW: %dms (latency: %dms + buffer: %dms)"  -- MT
L["GEMS_SQW_ADVISORY"] = "Recommended click rate: %dms"  -- MT
L["GEMS_SQW_ADVISORY_DETAIL"] = "GCD: %dms, SQW: %dms, Latency: %dms"  -- MT
L["GEMS_SQW_ADVISORY_DELTA"] = "Your setting: %dms (%dms %s than optimal)"  -- MT
L["GEMS_SQW_MANAGED"] = "Managed by SQW Optimizer"  -- MT
L["GEMS_SQW_ENABLED"] = "SQW Optimizer enabled"  -- MT
L["GEMS_SQW_DISABLED"] = "SQW Optimizer disabled (SQW reverted to %d)"  -- MT
L["GEMS_SQW_STATUS"] = "SQW: %dms | Latency: %dms | Buffer: %dms | Advisory: %dms"  -- MT
L["GEMS_SQW_BUFFER_SET"] = "SQW buffer set to %dms"  -- MT
L["GEMS_SQW_BUFFER_RANGE"] = "Buffer must be between 50 and 200"  -- MT
L["GEMS_SQW_SLOWER"] = "slower"  -- MT
L["GEMS_SQW_FASTER"] = "faster"  -- MT
