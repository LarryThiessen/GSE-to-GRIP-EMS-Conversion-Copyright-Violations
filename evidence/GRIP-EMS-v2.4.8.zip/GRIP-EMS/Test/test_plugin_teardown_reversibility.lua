-- GRIP-EMS: Headless reversibility test for the Plugin API v2 teardown journal
--
-- Created:    2026-06-24
-- Updated:    2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.
--
-- Standalone (Lua 5.1) test proving the Plugin API v2 HARD REQUIREMENT: disabling
-- a plugin reverts everything it did, created, or changed -- EMS returns to its
-- default-installed state. One plugin contributes the FULL v2 surface through its
-- handle (variable provider, condition, step function, layout provider, view,
-- panel, classic-chrome toggle, plugin setting + setting override, CVar profile
-- request, owned sequence, import provider, export provider). The test asserts
-- every contribution is live after enable, that DisablePlugin returns each
-- registry / engine / settings / CVar surface to its pre-register baseline, and
-- that a re-enable rebuilds the surface and a second disable cleans up again.
--
-- EMS ships its in-game tests as *_spec.lua run via /gems test; the test_*.lua
-- files are the headless suite the CI lint workflow runs (Test/test_*.lua under
-- lua5.1). This loads the REAL Core/PluginAPI.lua + Engine/StepFunctions.lua +
-- Core/PublicAPI.lua into a sandbox with the real LibStub + CallbackHandler bus
-- and minimal Engine / Settings / CvarProfileManager / chrome stubs, so only the
-- table-and-journal teardown path actually executes. The frame-reparent panel
-- path runs against a 4-method fake frame (SetParent / GetParent / ClearAllPoints
-- / SetAllPoints), the exact surface _reparent touches; in-client frame behavior
-- stays in the /gems test smoke pass.
--
-- Run from the EMS root:  lua Test/test_plugin_teardown_reversibility.lua
-- Exit code 0 = all passed, 1 = at least one failure.

local ADDON_NAME = "GRIP-EMS"

-- ---------------------------------------------------------------------------
-- Minimal assertion + runner harness (matches Test/test_reparent_into_loop.lua).
-- ---------------------------------------------------------------------------

local tests = {}

local function test(name, fn)
    tests[#tests + 1] = { name = name, fn = fn }
end

local function assertEqual(expected, actual, label)
    if expected ~= actual then
        error((label or "value") .. ": expected " .. tostring(expected) .. ", got " .. tostring(actual), 2)
    end
end

local function assertTrue(cond, label)
    if not cond then
        error((label or "condition") .. " failed", 2)
    end
end

-- True when an ordered provider array holds an entry whose .id matches.
local function arrayHasId(arr, wantId)
    if type(arr) ~= "table" then
        return false
    end
    for i = 1, #arr do
        if arr[i] and arr[i].id == wantId then
            return true
        end
    end
    return false
end

-- ---------------------------------------------------------------------------
-- Headless bootstrap: real bus + real plugin/public API, minimal data stubs.
-- Mirrors the standalone harness in Test/public_api_spec.lua, extended with the
-- engine write path, a settings writer with defaults, a CVar profile manager, a
-- persistent DB table, and a classic-chrome stand-in.
-- ---------------------------------------------------------------------------

if not _G.strmatch then
    _G.strmatch = string.match
end
if not _G.securecallfunction then
    _G.securecallfunction = function(fn, ...)
        return fn(...)
    end
end

-- Locate a repo file from the EMS root, the Test dir, or the Hub root.
local function loadModule(relPath)
    local prefixes = { "", "../", "GRIP/EMS/" }
    for _, prefix in ipairs(prefixes) do
        -- loadfile is dev-harness file I/O, intentionally outside the WoW std.
        -- selene: allow(undefined_variable)
        local chunk = loadfile(prefix .. relPath)
        if chunk then
            return chunk
        end
    end
    error("could not locate " .. relPath .. " (run from the EMS repo root)")
end

-- Headless LibStub + CallbackHandler-1.0. The real libraries live under Libs/,
-- which is gitignored (fetched by .pkgmeta at release) and so is absent from a
-- fresh CI checkout -- a test_*.lua run by the lint workflow cannot loadfile
-- them. This inline pair is the same contract the modules below use: a
-- LibStub(major) lookup plus a CallbackHandler bus whose New embeds
-- RegisterCallback / UnregisterCallback / UnregisterAllCallbacks into the target
-- and returns a registry with Fire.
local stub = _G.LibStub
if not stub then
    stub = { libs = {}, minors = {} }
    function stub:NewLibrary(major, minor)
        if self.minors[major] then
            return nil
        end
        self.minors[major], self.libs[major] = minor, self.libs[major] or {}
        return self.libs[major]
    end
    function stub:GetLibrary(major, silent)
        if not self.libs[major] and not silent then
            error(string.format("Cannot find a library instance of %q.", tostring(major)), 2)
        end
        return self.libs[major], self.minors[major]
    end
    setmetatable(stub, { __call = stub.GetLibrary })
    _G.LibStub = stub
end

local CallbackHandler = stub:NewLibrary("CallbackHandler-1.0", 8)
if CallbackHandler then
    function CallbackHandler.New(_, target, regName, unregName, unregAllName)
        regName = regName or "RegisterCallback"
        unregName = unregName or "UnregisterCallback"
        if unregAllName == nil then
            unregAllName = "UnregisterAllCallbacks"
        end
        local events = setmetatable({}, {
            __index = function(t, key)
                t[key] = {}
                return t[key]
            end,
        })
        local registry = { events = events }
        function registry:Fire(eventname, ...)
            local handlers = rawget(events, eventname)
            if not handlers then
                return
            end
            for _, method in pairs(handlers) do
                method(eventname, ...)
            end
        end
        target[regName] = function(self, eventname, method, arg)
            if type(method) == "function" then
                if arg ~= nil then
                    events[eventname][self] = function(...)
                        return method(arg, ...)
                    end
                else
                    events[eventname][self] = method
                end
            else
                local name = method or eventname
                if arg ~= nil then
                    events[eventname][self] = function(...)
                        return self[name](self, arg, ...)
                    end
                else
                    events[eventname][self] = function(...)
                        return self[name](self, ...)
                    end
                end
            end
        end
        target[unregName] = function(self, eventname)
            if rawget(events, eventname) then
                events[eventname][self] = nil
            end
        end
        if unregAllName then
            target[unregAllName] = function(...)
                for i = 1, select("#", ...) do
                    local who = select(i, ...)
                    for _, callbacks in pairs(events) do
                        callbacks[who] = nil
                    end
                end
            end
        end
        return registry
    end
end

-- Minimal AceLocale: every key resolves to itself.
local locale = setmetatable({}, {
    __index = function(_, key)
        return key
    end,
})
stub.libs["AceLocale-3.0"] = {
    GetLocale = function()
        return locale
    end,
}
stub.minors["AceLocale-3.0"] = 1

local GRIPEMS = {
    version = "headless",
    Print = function() end,
    Debug = function() end,
}

-- Event bus, created exactly as Core.lua does.
local cbRegistry = stub("CallbackHandler-1.0"):New(GRIPEMS)
function GRIPEMS:Fire(event, ...)
    cbRegistry:Fire(event, ...)
end

-- Persistent account DB: plugin enable-state + owned-sequence buckets live here.
_G.GRIP_EMS_DB = {}

-- Engine stub: the read surface PublicAPI touches plus the write path the owned-
-- sequence authoring methods route through (ActivateSequence / DeactivateSequence
-- / UpdateSequenceData).
GRIPEMS.Engine = {
    sequences = {},
    currentContext = "none",
    GetActiveVersion = function(_, seqData)
        if not seqData or not seqData.versions then
            return nil
        end
        local idx = seqData.defaultVersion or 1
        return seqData.versions[idx] or seqData.versions[1]
    end,
    GetSequenceList = function(self)
        local list = {}
        for name, entry in pairs(self.sequences) do
            local version = self:GetActiveVersion(entry.data)
            list[#list + 1] = {
                name = name,
                stepCount = (version and version.steps) and #version.steps or 0,
                stepFunction = version and version.stepFunction or "sequential",
            }
        end
        table.sort(list, function(a, b)
            return a.name < b.name
        end)
        return list
    end,
    ActivateSequence = function(self, name, data)
        self.sequences[name] = { data = data }
    end,
    DeactivateSequence = function(self, name)
        self.sequences[name] = nil
    end,
    UpdateSequenceData = function(self, name, data)
        if self.sequences[name] then
            self.sequences[name].data = data
        end
    end,
}

-- Settings stub: a values overlay plus a defaults.profile table (the
-- OverrideSetting known-key check reads defaults.profile[key]). cvarActiveProfile
-- starts at the General baseline so the CVar-request revert has a prior id to
-- restore to.
GRIPEMS.Settings = {
    defaults = { profile = { _TS_rev_knob = "default" } },
    values = { _TS_rev_knob = "userValue", cvarActiveProfile = "General", debug = false },
    Get = function(self, key)
        local v = self.values[key]
        if v ~= nil then
            return v
        end
        return self.defaults.profile[key]
    end,
    Set = function(self, key, value)
        self.values[key] = value
    end,
}

-- CvarProfileManager stub: GetProfile resolves a profile by id; ApplyProfile
-- records the touched CVars and flips cvarActiveProfile; UndoPrevious records the
-- restore. Two built-in-shaped profiles: General (no overrides) and the test
-- profile that overrides two CVars.
GRIPEMS.CvarProfileManager = {
    profiles = {
        General = { overrides = {} },
        _TS_RevProfile = { overrides = { _TS_cvar_a = "1", _TS_cvar_b = "2" } },
    },
    captured = {},
    undone = {},
    GetProfile = function(self, key)
        return self.profiles[key]
    end,
    ApplyProfile = function(self, key)
        local profile = self.profiles[key]
        if profile and profile.overrides then
            for cvar in pairs(profile.overrides) do
                self.captured[cvar] = true
            end
        end
        GRIPEMS.Settings:Set("cvarActiveProfile", key)
    end,
    UndoPrevious = function(self, cvar)
        self.undone[cvar] = true
        self.captured[cvar] = nil
    end,
}

-- MacroManager stub (Phase B): mimics the real out-of-combat synchronous CreateStub.
-- stubs is the authoritative seqName -> slot map; CreateStub returns an existing slot
-- or assigns the next one synchronously; DeleteStub clears it. EnsureSequenceMacro
-- passes extra kp/kr/steps args the stub harmlessly ignores.
GRIPEMS.MacroManager = {
    stubs = {},
    _slotSeq = 100,
    GetAvailableSlots = function()
        return 18
    end,
    CreateStub = function(self, seqName)
        if self.stubs[seqName] then
            return self.stubs[seqName]
        end
        self._slotSeq = self._slotSeq + 1
        self.stubs[seqName] = self._slotSeq
        return self.stubs[seqName]
    end,
    DeleteStub = function(self, seqName)
        self.stubs[seqName] = nil
    end,
}

-- Defaults stand-in: StepFunctions.lua reads these at load and run; the preview
-- and step-function constants mirror the public_api_spec harness.
GRIPEMS.Defaults = {
    PREVIEW_MODE_ICONS = "icons",
    PREVIEW_MODE_TEXT = "text",
    PREVIEW_MODE_COMPILED = "compiled",
    STEP_SEQUENTIAL = "Sequential",
    STEP_RANDOM = "Random",
    STEP_PRIORITY = "Priority",
    STEP_REVERSE_PRIORITY = "ReversePriority",
    ATTR_TYPE_MACRO = "macro",
    MAX_MACROTEXT_LENGTH = 255,
}

-- Classic chrome stand-in: SetClassicChrome toggles SetShown on these four named
-- children of _G.GRIPEMS_MainFrame. Each records its shown state so the test can
-- assert the chrome is hidden after the plugin enables and shown again on disable.
local function makeChromePiece()
    local piece = { shown = true }
    function piece:SetShown(s)
        self.shown = s
    end
    return piece
end
_G.GRIPEMS_MainFrame = {
    leftPanel = makeChromePiece(),
    divider = makeChromePiece(),
    rightPanel = makeChromePiece(),
    titleBar = makeChromePiece(),
}

-- Load the REAL registrar, the REAL step-function module, then the REAL public
-- API into this sandbox.
loadModule("Core/PluginAPI.lua")(ADDON_NAME, GRIPEMS)
loadModule("Engine/StepFunctions.lua")(ADDON_NAME, GRIPEMS)
loadModule("Core/PublicAPI.lua")(ADDON_NAME, GRIPEMS)

-- Mirror the in-game boot state: MainFrame.lua registers the "classic" layout
-- provider at load. The disable path restores uiLayout to "classic", so it must
-- exist for that restore to resolve.
GRIPEMS.API.UI:RegisterLayoutProvider("classic", { id = "classic", name = "Classic" })

local PA = GRIPEMS.PluginAPI

-- ---------------------------------------------------------------------------
-- A 4-method fake frame -- the exact surface _reparent touches (SetParent,
-- ClearAllPoints, SetAllPoints) plus GetParent (MountPanel / UnmountPanel capture
-- and restore the parent). A content panel ("variables") registers this as its
-- mountable content root so the mount / unmount reparent path runs headlessly.
-- ---------------------------------------------------------------------------

local function makeFakeFrame(name)
    local f = { _name = name, _parent = nil }
    function f:SetParent(p)
        self._parent = p
    end
    function f:GetParent()
        return self._parent
    end
    function f:ClearAllPoints() end
    function f:SetAllPoints() end
    return f
end

local classicParent = makeFakeFrame("classicParent")
local panelFrame = makeFakeFrame("variablesPanel")
panelFrame._parent = classicParent
local panelHost = makeFakeFrame("modernHost")
-- Register the content panel's root so MountPanel reparents a real (fake) frame
-- rather than recording a deferred-mount intent.
GRIPEMS:RegisterMountablePanel("variables", panelFrame)

-- ---------------------------------------------------------------------------
-- The full-surface plugin. Every contribution is made through the handle inside
-- OnEnable, so enabling rebuilds the surface and disabling tears it down -- the
-- real lifecycle, exercised on every enable / disable cycle below.
-- ---------------------------------------------------------------------------

local PLUGIN_ID = "_TS_RevPlugin"
local VAR_ID = "_TS_rev_var"
local COND_ID = "_TS_rev_cond"
local SF_ID = "_TS_rev_sf"
local LAYOUT_ID = "_TS_rev_layout"
local VIEW_ID = "_TS_rev_view"
local PANEL_ID = "variables"
local SETTING_KEY = "_TS_rev_setting"
local OVERRIDE_KEY = "_TS_rev_knob"
local CVAR_PROFILE = "_TS_RevProfile"
local SEQ_NAME = "_TS_RevSeq"
local IMPORT_ID = "_TS_rev_import"
local EXPORT_ID = "_TS_rev_export"

local onEnableRuns = 0
local onDisableRuns = 0
-- Set by the plugin's /gems subcommand handler (Phase C) so dispatch can be observed.
local slashFired = nil

local meta = {
    name = "Reversibility Test Plugin",
    version = "1.0",
    OnEnable = function(handle)
        onEnableRuns = onEnableRuns + 1
        handle:RegisterVariableProvider({
            id = VAR_ID,
            name = "RevVar",
            Resolve = function(_, n)
                if n == "_TS_rev_q" then
                    return "rev_answer"
                end
                return nil
            end,
        })
        handle:RegisterCondition({
            id = COND_ID,
            name = "RevCond",
            Evaluate = function()
                return true
            end,
        })
        handle:RegisterStepFunction({
            id = SF_ID,
            name = "RevSF",
            Expand = function(_, s)
                return s
            end,
        })
        handle:RegisterLayoutProvider({ id = LAYOUT_ID, name = "RevLayout" })
        handle:RegisterView(VIEW_ID, { id = VIEW_ID, name = "RevView" })
        handle:SetActiveView(VIEW_ID)
        handle:MountPanel(PANEL_ID, panelHost)
        handle:SetClassicChrome(false)
        handle:RegisterSetting({ key = SETTING_KEY, type = "toggle", name = "RevSetting" })
        handle:OverrideSetting(OVERRIDE_KEY, "pluginValue")
        handle:RequestCVarProfile(CVAR_PROFILE)
        handle:CreateSequence(SEQ_NAME, {
            versions = { { stepFunction = "sequential", steps = { "/cast Test" } } },
            defaultVersion = 1,
        })
        handle:EnsureSequenceMacro(SEQ_NAME)
        -- Plugin /gems subcommand (Phase C): the handler records its argument string so
        -- DispatchSlashCommand can be observed in assertSurfacePresent.
        handle:RegisterSlashCommand("tprevslash", function(argString)
            slashFired = argString
        end, "Test slash help")
        -- Inline validation: a duplicate sub, a non-function handler, and a built-in
        -- collision must each be rejected (parens truncate the (false, reason) return to the
        -- ok value). The IsBuiltinSlashCommand stub flags only "list" and is left in place --
        -- harmless across re-enable cycles since it never flags tprevslash.
        assertEqual(false, (handle:RegisterSlashCommand("tprevslash", function() end)), "duplicate slash sub rejected")
        assertEqual(
            false,
            (handle:RegisterSlashCommand("tprevslash2", "not a function")),
            "non-function slash handler rejected"
        )
        GRIPEMS.IsBuiltinSlashCommand = function(s)
            return s == "list"
        end
        assertEqual(false, (handle:RegisterSlashCommand("list", function() end)), "built-in slash collision rejected")
        handle:RegisterImportProvider({
            id = IMPORT_ID,
            name = "RevImport",
            Parse = function()
                return nil
            end,
        })
        handle:RegisterExportProvider({
            id = EXPORT_ID,
            name = "RevExport",
            Serialize = function()
                return nil
            end,
        })
    end,
    OnDisable = function()
        onDisableRuns = onDisableRuns + 1
    end,
}

-- Assert the full surface is LIVE (after an enable).
local function assertSurfacePresent(label)
    assertTrue(arrayHasId(GRIPEMS._variableProviders, VAR_ID), label .. ": variable provider registered")
    assertEqual("rev_answer", GRIPEMS:ResolvePluginVariable("_TS_rev_q"), label .. ": variable resolves")
    assertTrue(GRIPEMS._conditions[COND_ID] ~= nil, label .. ": condition registered")
    assertTrue(GRIPEMS._stepFunctions[SF_ID] ~= nil, label .. ": step function registered")
    assertTrue(GRIPEMS._layoutProviders[LAYOUT_ID] ~= nil, label .. ": layout provider registered")
    assertTrue(GRIPEMS._views[VIEW_ID] ~= nil, label .. ": view registered")
    assertEqual(VIEW_ID, GRIPEMS.API.UI:GetActiveView(), label .. ": active view set")
    assertEqual(panelHost, panelFrame:GetParent(), label .. ": panel mounted into the host")
    assertEqual(false, GRIPEMS_MainFrame.leftPanel.shown, label .. ": classic chrome hidden")
    assertTrue(PA.settingsDefs[SETTING_KEY] ~= nil, label .. ": plugin setting registered")
    assertEqual("pluginValue", GRIPEMS.Settings:Get(OVERRIDE_KEY), label .. ": setting overridden")
    assertEqual(CVAR_PROFILE, GRIPEMS.Settings:Get("cvarActiveProfile"), label .. ": CVar profile applied")
    assertTrue(GRIPEMS.Engine.sequences[SEQ_NAME] ~= nil, label .. ": owned sequence active")
    assertEqual(
        PLUGIN_ID,
        GRIPEMS.Engine.sequences[SEQ_NAME].data.ownerPlugin,
        label .. ": owned sequence stamped with the owner"
    )
    assertTrue(GRIP_EMS_DB.pluginOwned[PLUGIN_ID][SEQ_NAME] ~= nil, label .. ": owned sequence in the bucket")
    assertTrue(GRIPEMS.MacroManager.stubs[SEQ_NAME] ~= nil, label .. ": sequence macro created")
    assertTrue(GRIPEMS.PluginAPI.slashCommands["tprevslash"] ~= nil, label .. ": plugin slash command registered")
    slashFired = nil
    assertEqual(
        true,
        (GRIPEMS.PluginAPI:DispatchSlashCommand("tprevslash", "hi")),
        label .. ": dispatch claims the sub"
    )
    assertEqual("hi", slashFired, label .. ": dispatch ran the handler with its arg string")
    assertEqual(
        false,
        (GRIPEMS.PluginAPI:DispatchSlashCommand("tprevslash_nope")),
        label .. ": an unregistered sub is not claimed"
    )
    assertTrue(arrayHasId(GRIPEMS._importProviders, IMPORT_ID), label .. ": import provider registered")
    assertTrue(arrayHasId(GRIPEMS._exportProviders, EXPORT_ID), label .. ": export provider registered")
    assertEqual(true, PA.plugins[PLUGIN_ID].enabled, label .. ": plugin marked enabled")
end

-- Assert EMS is back to its default-installed state (after a disable).
local function assertSurfaceDefault(label)
    assertEqual(false, arrayHasId(GRIPEMS._variableProviders, VAR_ID), label .. ": variable provider removed")
    assertEqual(nil, GRIPEMS:ResolvePluginVariable("_TS_rev_q"), label .. ": variable no longer resolves")
    assertEqual(nil, GRIPEMS._conditions[COND_ID], label .. ": condition removed")
    assertEqual(nil, GRIPEMS._stepFunctions[SF_ID], label .. ": step function removed")
    assertEqual(nil, GRIPEMS._layoutProviders[LAYOUT_ID], label .. ": layout provider removed")
    assertEqual(nil, GRIPEMS._views[VIEW_ID], label .. ": view removed")
    assertEqual(nil, GRIPEMS.API.UI:GetActiveView(), label .. ": active view restored to default")
    assertEqual(classicParent, panelFrame:GetParent(), label .. ": panel restored to its original parent")
    assertEqual(true, GRIPEMS_MainFrame.leftPanel.shown, label .. ": classic chrome shown again")
    assertEqual(nil, PA.settingsDefs[SETTING_KEY], label .. ": plugin setting unregistered")
    assertEqual("userValue", GRIPEMS.Settings:Get(OVERRIDE_KEY), label .. ": overridden setting restored")
    assertEqual("General", GRIPEMS.Settings:Get("cvarActiveProfile"), label .. ": CVar profile restored")
    assertEqual(true, GRIPEMS.CvarProfileManager.undone._TS_cvar_a, label .. ": CVar a undone")
    assertEqual(true, GRIPEMS.CvarProfileManager.undone._TS_cvar_b, label .. ": CVar b undone")
    assertEqual(nil, GRIPEMS.Engine.sequences[SEQ_NAME], label .. ": owned sequence deactivated")
    assertEqual(nil, GRIP_EMS_DB.pluginOwned[PLUGIN_ID][SEQ_NAME], label .. ": owned sequence dropped from bucket")
    assertEqual(nil, GRIPEMS.MacroManager.stubs[SEQ_NAME], label .. ": sequence macro deleted")
    assertEqual(nil, GRIPEMS.PluginAPI.slashCommands["tprevslash"], label .. ": plugin slash command removed")
    assertEqual(false, arrayHasId(GRIPEMS._importProviders, IMPORT_ID), label .. ": import provider removed")
    assertEqual(false, arrayHasId(GRIPEMS._exportProviders, EXPORT_ID), label .. ": export provider removed")
    assertEqual(false, PA.plugins[PLUGIN_ID].enabled, label .. ": plugin marked disabled")
end

-- ---------------------------------------------------------------------------
-- Cases.
-- ---------------------------------------------------------------------------

test("register contributes the full v2 surface", function()
    local handle, reason = GRIPEMS.API:RegisterPlugin(PLUGIN_ID, meta)
    assertTrue(handle ~= nil, "RegisterPlugin returned a handle (" .. tostring(reason) .. ")")
    assertEqual(1, onEnableRuns, "OnEnable ran exactly once at registration")
    assertSurfacePresent("after register")
end)

test("disable reverts the full v2 surface to default-installed", function()
    local ok = GRIPEMS.DisablePlugin(PLUGIN_ID)
    assertEqual(true, ok, "DisablePlugin returns true")
    assertEqual(1, onDisableRuns, "OnDisable ran exactly once")
    assertSurfaceDefault("after disable")
    -- The journal is reset to an empty shape after a disable replay.
    assertEqual(0, #PA.journal[PLUGIN_ID].registries.variableProviders, "journal variableProviders cleared")
    assertEqual(0, #PA.journal[PLUGIN_ID].ownedSequences, "journal ownedSequences cleared")
    assertEqual(0, #PA.journal[PLUGIN_ID].createdMacros, "journal createdMacros cleared")
    assertEqual(0, #PA.journal[PLUGIN_ID].registries.slashCommands, "journal slashCommands cleared")
end)

test("re-enable rebuilds the surface, second disable cleans up again", function()
    -- Reset the CVar undo ledger so the second-disable assertions read only the
    -- second cycle's restores.
    GRIPEMS.CvarProfileManager.undone = {}
    local ok = GRIPEMS.EnablePlugin(PLUGIN_ID)
    assertEqual(true, ok, "EnablePlugin returns true")
    assertEqual(2, onEnableRuns, "OnEnable ran again on re-enable")
    assertSurfacePresent("after re-enable")

    local ok2 = GRIPEMS.DisablePlugin(PLUGIN_ID)
    assertEqual(true, ok2, "second DisablePlugin returns true")
    assertEqual(2, onDisableRuns, "OnDisable ran again")
    assertSurfaceDefault("after second disable")
end)

-- Reload survival: the pre-plugin base snapshot for an overridden key must persist
-- across a /reload so a later disable reverts to the genuine pre-plugin value, not the
-- plugin's own override. A reload drops the in-memory base store (PA.settingOverrides)
-- but leaves the account SavedVariables (_G.GRIP_EMS_DB) and the already-overridden live
-- value intact; re-applying the override on reload must source the base from SV, not
-- re-derive it from the live value. Uses a fresh key + plugin so it is independent of the
-- full-surface plugin exercised above.
test("plugin setting base snapshot survives a reload", function()
    local RELOAD_PLUGIN = "_TS_ReloadPlugin"
    local RELOAD_KEY = "_TS_reload_knob"
    local DEFAULT_VALUE = "reloadDefault"

    -- 1) A known default for the key, with no user value set, so the captured base
    --    is this default.
    GRIPEMS.Settings.defaults.profile[RELOAD_KEY] = DEFAULT_VALUE

    -- 2) A plugin whose OnEnable overrides the key. After enable the live value is the
    --    plugin's override and the pre-plugin base is persisted to SV.
    local reloadHandle = GRIPEMS.API:RegisterPlugin(RELOAD_PLUGIN, {
        name = "Reload Survival Plugin",
        version = "1.0",
        OnEnable = function(handle)
            handle:OverrideSetting(RELOAD_KEY, "OVR")
        end,
    })
    assertTrue(reloadHandle ~= nil, "RegisterPlugin returned a handle")
    assertEqual("OVR", GRIPEMS.Settings:Get(RELOAD_KEY), "live value is the override after enable")
    assertEqual(DEFAULT_VALUE, PA.settingOverrides[RELOAD_KEY].base, "base captured as the pre-plugin default")
    assertTrue(GRIP_EMS_DB.pluginSettingBase[RELOAD_KEY] ~= nil, "base snapshot persisted to SavedVariables")

    -- 3) Simulate a reload: drop the in-memory base store but leave the SV bucket and the
    --    already-overridden live value untouched, exactly as a real /reload does.
    PA.settingOverrides = {}
    assertEqual("OVR", GRIPEMS.Settings:Get(RELOAD_KEY), "live value still the override after reload")

    -- 4) OnEnable re-applies the override on reload. The base must come from SV
    --    (DEFAULT_VALUE), not be re-derived from the overridden live value ("OVR").
    reloadHandle:OverrideSetting(RELOAD_KEY, "OVR")
    assertEqual(DEFAULT_VALUE, PA.settingOverrides[RELOAD_KEY].base, "base re-sourced from SV, not the live value")

    -- 5) Disabling the plugin now reverts to the genuine pre-plugin value.
    local ok = GRIPEMS.DisablePlugin(RELOAD_PLUGIN)
    assertEqual(true, ok, "DisablePlugin returns true")
    assertEqual(DEFAULT_VALUE, GRIPEMS.Settings:Get(RELOAD_KEY), "disable reverts to the pre-plugin default")
end)

-- Orphan-base reconcile (prune pass): a plugin removed while still enabled leaves a
-- persisted setting-override base with no active override -- the addon is gone, so its
-- DisablePlugin never ran to clear it. ReconcileOrphanSettingBases, called once after all
-- enabled plugins have re-applied their overrides, drops every such orphaned base while
-- leaving an active key's base and every live value untouched. Fresh keys + plugins so it
-- is independent of the scenarios above.
test("orphaned plugin setting base is pruned, active override is kept", function()
    GRIPEMS.Settings.defaults.profile.orphanKey = "od"
    GRIPEMS.Settings.defaults.profile.activeKey = "ad"

    -- Two plugins each override a distinct key, so both capture and persist a base.
    GRIPEMS.API:RegisterPlugin("gone_plugin", {
        name = "Gone Plugin",
        version = "1.0",
        OnEnable = function(handle)
            handle:OverrideSetting("orphanKey", "OVRo")
        end,
    })
    local stayHandle = GRIPEMS.API:RegisterPlugin("stay_plugin", {
        name = "Stay Plugin",
        version = "1.0",
        OnEnable = function(handle)
            handle:OverrideSetting("activeKey", "OVRa")
        end,
    })
    assertEqual("od", PA.settingOverrides.orphanKey.base, "orphanKey base captured as its default")
    assertTrue(GRIP_EMS_DB.pluginSettingBase.orphanKey ~= nil, "orphanKey base persisted to SavedVariables")
    assertEqual("ad", PA.settingOverrides.activeKey.base, "activeKey base captured as its default")
    assertTrue(GRIP_EMS_DB.pluginSettingBase.activeKey ~= nil, "activeKey base persisted to SavedVariables")

    -- Simulate a reload: drop the in-memory override map. The SV bases and the already-
    -- overridden live values survive, exactly as a real /reload leaves them.
    PA.settingOverrides = {}

    -- Only the surviving plugin re-applies its override; gone_plugin was removed, so it
    -- never re-applies -- its base is now orphaned (persisted, but no active override).
    stayHandle:OverrideSetting("activeKey", "OVRa")

    GRIPEMS.ReconcileOrphanSettingBases()

    assertEqual(nil, GRIP_EMS_DB.pluginSettingBase.orphanKey, "orphaned base pruned by reconcile")
    assertTrue(GRIP_EMS_DB.pluginSettingBase.activeKey ~= nil, "active base kept by reconcile")
    assertTrue(PA.settingOverrides.activeKey ~= nil, "active override left untouched by reconcile")
    assertEqual("OVRo", GRIPEMS.Settings:Get("orphanKey"), "orphaned live value NOT reverted (prune only)")

    -- The stale base is gone, so a new plugin's first capture of the same key reads the
    -- current live value, not the orphaned "od" snapshot.
    GRIPEMS.API:RegisterPlugin("new_plugin", {
        name = "New Plugin",
        version = "1.0",
        OnEnable = function(handle)
            handle:OverrideSetting("orphanKey", "OVRn")
        end,
    })
    assertEqual("OVRo", PA.settingOverrides.orphanKey.base, "new capture reads current live, not the stale base")
end)

-- ---------------------------------------------------------------------------
-- Run.
-- ---------------------------------------------------------------------------

local passed = 0
local failed = 0
for _, t in ipairs(tests) do
    local ok, err = pcall(t.fn)
    if ok then
        passed = passed + 1
        print("PASS  " .. t.name)
    else
        failed = failed + 1
        print("FAIL  " .. t.name .. " -- " .. tostring(err))
    end
end
print(string.format("RESULT %d passed, %d failed", passed, failed))
-- os.exit is dev-harness only; the game client never loads a test_*.lua file.
-- selene: allow(undefined_variable)
os.exit(failed > 0 and 1 or 0)
