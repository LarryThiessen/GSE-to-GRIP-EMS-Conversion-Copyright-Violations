-- GRIP-EMS: GearVariables
-- Created: 2026-04-03
-- Updated: 2026-06-21
-- Patch: 12.0.7.68256 Midnight (Retail LIVE)

-- GRIP-EMS: Gear-Aware Variables
-- System-level read-only variables that resolve to equipped item use-effect
-- spell names. E.g. ~trinket1~ resolves to "Spymasters Web".
-- Scans all equipment slots for on-use effects via C_Item.GetItemSpell.
-- Re-scans on PLAYER_EQUIPMENT_CHANGED and PLAYER_LOGIN.

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

GRIPEMS.GearVariables = {}
local GV = GRIPEMS.GearVariables

---------------------------------------------------------------------------
-- Slot definitions: variable name -> equipment slot ID
---------------------------------------------------------------------------
GV.SLOT_INFO = {
    { var = "head", slotID = 1 },
    { var = "neck", slotID = 2 },
    { var = "chest", slotID = 5 },
    { var = "waist", slotID = 6 },
    { var = "legs", slotID = 7 },
    { var = "feet", slotID = 8 },
    { var = "wrist", slotID = 9 },
    { var = "hands", slotID = 10 },
    { var = "ring1", slotID = 11 },
    { var = "ring2", slotID = 12 },
    { var = "trinket1", slotID = 13 },
    { var = "trinket2", slotID = 14 },
    { var = "back", slotID = 15 },
    { var = "mainhand", slotID = 16 },
    { var = "offhand", slotID = 17 },
}

---------------------------------------------------------------------------
-- Internal cache: var name -> { spellName, spellID, itemID } or nil
---------------------------------------------------------------------------
GV._cache = {}

---------------------------------------------------------------------------
-- Public methods
---------------------------------------------------------------------------

--- Scan all equipment slots for on-use effects and update the cache.
function GV:Scan()
    wipe(self._cache)

    for _, slot in ipairs(self.SLOT_INFO) do
        local itemID = GetInventoryItemID("player", slot.slotID)
        if itemID then
            local spellName, spellID = C_Item.GetItemSpell(itemID)
            if spellName and spellID then
                self._cache[slot.var] = {
                    spellName = spellName,
                    spellID = spellID,
                    itemID = itemID,
                }
            end
        end
    end

    -- Debug output
    local count = 0
    for _ in pairs(self._cache) do
        count = count + 1
    end
    GRIPEMS:Debug(string.format(L["GEMS_GEAR_VAR_UPDATED"], count))
end

--- Get the spell name for a gear variable.
--- @param varName string Variable name (e.g. "trinket1")
--- @return string|nil spellName Spell name or nil if slot has no use-effect
function GV:Get(varName)
    local entry = self._cache[varName]
    if entry then
        return entry.spellName
    end
    return nil
end

--- Get all active gear variables as a varName -> spellName table.
--- @return table mapping of active variable names to spell names
function GV:GetAll()
    local result = {}
    for varName, entry in pairs(self._cache) do
        result[varName] = entry.spellName
    end
    return result
end

--- Get full cache entry for a slot (for tooltips: item name, spell name, ID).
--- @param varName string Variable name
--- @return table|nil Full cache entry { spellName, spellID, itemID }
function GV:GetSlotInfo(varName)
    return self._cache[varName]
end

---------------------------------------------------------------------------
-- Event handling: re-scan on gear changes
---------------------------------------------------------------------------
local eventFrame = _G["GRIPEMS_GearVarEvent"] or CreateFrame("Frame", "GRIPEMS_GearVarEvent")

eventFrame:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")
eventFrame:RegisterEvent("PLAYER_LOGIN")

eventFrame:SetScript("OnEvent", function(self, event)
    GV:Scan()
    if GRIPEMS.Fire then
        GRIPEMS:Fire("GEAR_VARIABLES_UPDATED")
    end
end)
