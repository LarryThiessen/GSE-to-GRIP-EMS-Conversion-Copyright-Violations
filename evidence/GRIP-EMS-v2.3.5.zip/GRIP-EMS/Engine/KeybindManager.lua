-- GRIP-EMS: KeybindManager
-- Created: 2026-03-18
-- Updated: 2026-06-23
-- Patch: 12.0.7.68256 Midnight (Retail LIVE)
-- 2026-06-08: PruneKeybindsForLoadout takes an isDeletion flag so the manual
--   manage-popup "X" clear uses neutral wording and skips the keybindsLKG
--   overwrite; only a real TRAIT_CONFIG_DELETED salvages into the snapshot.

-- GRIP-EMS: Keybind Manager
-- Override-binding keybind system for sequence execution

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)
local D = GRIPEMS.Defaults

-- KeybindManager module: manages per-spec override bindings that route
-- keypresses directly to GRIP-EMS SecureActionButtons via
-- SetOverrideBindingClick. Direct binding is required because
-- SetOverrideBindingMacro triggers the 11.0.2 macro chaining restriction
-- (macro /click -> button macrotext = blocked). keyPress lines execute
-- only when the player clicks the macro stub on their action bar. Override bindings are temporary, never saved to the user's binding
-- set, auto-wiped on /reload, and can be bulk-cleared via
-- ClearOverrideBindings(owner). All binding changes are nocombat-restricted
-- and go through OOCQueue when in combat lockdown.
--
-- Data model (v2; v1 is per-spec only):
--   GRIP_EMS_CHAR.keybinds[specIndex][key]            = seqName  (per-spec fallback layer)
--   GRIP_EMS_CHAR.keybinds[specIndex]._byLoadout[id]  = { [key] = seqName }  (per-loadout overlay)
--   GRIP_EMS_CHAR.keybindSchemaVersion = 2 (set by KM:_MigrateToV2 on first v2 session)
-- Per-loadout overlay wins over per-spec layer at LoadKeybinds time.
-- Suppress sentinel "__suppress__" in a per-loadout entry removes the matching per-spec key for that loadout.
-- Keybinds are stored by sequence name (not button name) so renames work.
-- One sequence = one keybind per spec OR per loadout layer.
GRIPEMS.KeybindManager = {}
local KM = GRIPEMS.KeybindManager

-- Settle window (seconds) for the keybind-loss heal-offer warning. The
-- login-race empty self-heals well inside this; a persistent loss does not.
local KEYBIND_LOSS_SETTLE_SECONDS = 3

KM._pendingSpecLoad = false

-- Dedicated secure handler that OWNS the EMS sequence keybinds and
-- symmetrically suspends/restores them on vehicle / possess / override /
-- skyriding / pet battle enter AND exit. RegisterAttributeDriver re-evaluates
-- the conditional on a throttled OnUpdate (<=0.2s) in addition to state events
-- (including UPDATE_BONUS_ACTIONBAR), so the exit transition is caught even
-- when no discrete Lua event fires -- the gap the earlier Lua heartbeat papered
-- over. The driver settles to "none" at rest, so a spurious login-time bar-swap
-- suspend self-heals. This frame is dedicated to EMS sequence keybinds:
-- ClearBindings() on it never touches VehicleKeybinds (its own owner) or any
-- other binding owner.
local vehicleDriver = _G["GRIPEMS_VehicleDriver"]
    or CreateFrame("Frame", "GRIPEMS_VehicleDriver", UIParent, "SecureHandlerAttributeTemplate")

-- The snippet attribute name MUST carry the leading underscore
-- ("_onattributechanged"); the non-underscore form is a silent no-op.
-- emsstate semantics: "none" == at rest, EMS bindings ACTIVE; "suspend" ==
-- vehicle / possess / override (FULL suspend, EMS bindings dropped);
-- "petbattle" == pet battle (also dropped); "skyride" == skyriding bar active,
-- where EMS bindings stay live ONLY when autodismount == "1" (the mirror of the
-- autoDismountFlying CVar) so each press can route by target attackability.
-- The autodismount branch below re-dispatches the CURRENT emsstate so a CVar
-- toggle takes effect immediately without waiting for a bar swap; value can be
-- nil on that re-dispatch before the first driver evaluation, which safely
-- falls through to no apply and the next pushSecureMatrix re-applies.
-- Only a GENUINE driver dispatch retires the watchdog's missed-enter force
-- flag: the synthetic autodismount re-dispatch re-asserts the very state the
-- force is healing around (stale "none" mid-flight), so it must not clear it
-- -- otherwise any CVar toggle or matrix rebuild during a healed flight would
-- silently resurrect the missed-enter bug until landing.
-- emsstate records the current state for the OOC re-apply path (the
-- pushSecureMatrix SecureHandlerExecute body). Stale bindkey<i>/bindtarget<i>
-- attributes left over from a larger previous matrix are never read because the
-- loop is bounded by bindcount.
vehicleDriver:SetAttribute(
    "_onattributechanged",
    [=[
    local synthetic = (name == "autodismount")
    if name == "autodismount" then
        name = "emsvehicle"
        value = self:GetAttribute("emsstate")
    end
    if name == "emsvehicle" then
        self:SetAttribute("emsstate", value)
        if not synthetic then
            self:SetAttribute("skyrideforce", nil)
        end
        self:ClearBindings()
        local apply = (value == "none")
            or (value == "skyride" and self:GetAttribute("autodismount") == "1")
        if apply then
            local n = self:GetAttribute("bindcount") or 0
            for i = 1, n do
                local key = self:GetAttribute("bindkey"..i)
                local target = self:GetFrameRef("bindtarget"..i)
                if key and target then
                    self:SetBindingClick(false, key, target, "LeftButton")
                end
            end
        end
    end
]=]
)

-- bonusbar:5 is the skyriding bar; UPDATE_BONUS_ACTIONBAR is in the driver's
-- event eval set, so [bonusbar:5] flips on skyriding ENTER and EXIT. It now maps
-- to its own "skyride" state instead of "suspend": in that state sequence keys
-- stay bound ONLY when the autodismount attribute (mirror of the
-- autoDismountFlying CVar) is "1", and the click body routes each press by
-- target attackability. vehicle / possess / override keep FULL suspend.
-- petbattle is checked after the vehicle group so a pet battle reads
-- "petbattle". Everything else settles to "none".
RegisterAttributeDriver(
    vehicleDriver,
    "emsvehicle",
    "[vehicleui][possessbar][overridebar] suspend; [petbattle] petbattle; [bonusbar:5] skyride; none"
)

--- Return the variant-button global name set for a sequence. (IC-VAR-02 Phase 1)
--- Result is keyed by modifier ("plain"/"shift"/"ctrl"/"alt"), with values
--- being the button global name (or nil if no variant exists for that
--- modifier). The "plain" entry always points to the base button; other
--- modifiers populate only if the sequence's active version has a matching
--- variantOverride entry.
--- @param seqName string Sequence name
--- @return table { plain=name, shift=name|nil, ctrl=name|nil, alt=name|nil }
local function getVariantButtonsForSequence(seqName)
    local result = { plain = nil, shift = nil, ctrl = nil, alt = nil }
    if not GRIPEMS.Engine or not GRIPEMS.Engine.sequences then
        return result
    end
    local entry = GRIPEMS.Engine.sequences[seqName]
    if not entry then
        return result
    end
    local sanitized = GRIPEMS.Engine:SanitizeName(seqName)
    local baseName = D.BUTTON_PREFIX .. sanitized
    result.plain = baseName
    if not entry.data then
        return result
    end
    local ver = GRIPEMS.Engine:GetActiveVersion(entry.data)
    if not ver or not ver.variantOverrides then
        return result
    end
    for ovIdx, override in ipairs(ver.variantOverrides) do
        local mod = override.modifier
        if mod and mod ~= "plain" and D.VARIANT_MODIFIER_SET and D.VARIANT_MODIFIER_SET[mod] then
            result[mod] = baseName .. D.VARIANT_BUTTON_SUFFIX .. (ovIdx + 1)
        end
    end
    return result
end

--- Collect the override-binding matrix entries for a sequence's variant matrix
--- into a flat builder list. The single base key maps to variant 1 (the base
--- button). Each non-plain modifier with a matching variantOverride maps its
--- prefixed key (SHIFT-key / CTRL-key / ALT-key) to the variant button.
--- Sequences with no overrides contribute exactly the base key -> base button
--- (byte-identical matrix to pre-FIX-B behavior). Only pairs whose named
--- SecureActionButton currently exists in _G are emitted; the secure driver
--- binds them as CLICK bindings (SetBindingClick). Never SetBindingMacro --
--- 11.0.2 blocks macro chaining (macro body /click -> button macrotext), so the
--- key is wired straight to the SecureActionButton with no macro intermediary.
--- @param key string WoW key string (the base key without modifier prefix)
--- @param seqName string Sequence name
--- @param list table Builder array; { key, target } pairs are appended in place
local function applyBinding(key, seqName, list)
    local buttons = getVariantButtonsForSequence(seqName)
    local plainName = buttons.plain
    if plainName and _G[plainName] then
        list[#list + 1] = { key = key, target = _G[plainName] }
    end
    for _, mod in ipairs(D.VARIANT_MODIFIERS) do
        local vName = buttons[mod]
        if vName and _G[vName] then
            local prefixedKey = D.VARIANT_MODIFIER_PREFIX[mod] .. key
            list[#list + 1] = { key = prefixedKey, target = _G[vName] }
        end
    end
end

-- While skyriding, a key whose game binding (or EMS vehicle-keybind
-- config) drives an action slot must still be able to reach that slot's
-- ability when the press routes to the pass branch. Patterns cover the
-- default UI plus ElvUI / Bartender4 bar-1 click bindings.
local SKYRIDE_SLOT_PATTERNS = {
    "^ACTIONBUTTON(%d+)$",
    "^CLICK ElvUI_Bar1Button(%d+)",
    "^CLICK BT4Button(%d+)",
}

--- Derive the action-bar slot index (1-12) a key would drive while the
--- skyriding bonus bar is active, or nil when the key has none.
--- @param key string WoW key string from a matrix entry
--- @param getBindingAction function GetBindingAction or a test stub
--- @param vehicleKeys table { [key] = slotIndex } from VehicleKeybinds (may be empty)
--- @return number|nil
function KM._GetSkyrideSlotForKey(key, getBindingAction, vehicleKeys)
    if vehicleKeys and vehicleKeys[key] then
        return vehicleKeys[key]
    end
    local action = getBindingAction and getBindingAction(key, false)
    if not action or action == "" then
        return nil
    end
    for _, pat in ipairs(SKYRIDE_SLOT_PATTERNS) do
        local n = string.match(action, pat)
        if n then
            n = tonumber(n)
            if n and n >= 1 and n <= 12 then
                return n
            end
        end
    end
    return nil
end

--- Translate a matrix list onto a secure handler frame: a bindcount attribute, a
--- bindkey<i> attribute per entry, and a bindtarget<i> frame ref per entry. The
--- setFrameRef parameter is the live SecureHandlerSetFrameRef in production;
--- exposed as KM._WriteMatrixToDriver so the translation can be asserted against
--- a mock driver + recorder (the restricted env cannot run headless).
--- @param driver table Secure handler frame (or mock) exposing SetAttribute
--- @param list table Array of { key, target } entries
--- @param setFrameRef function fn(driver, label, ref) -- SecureHandlerSetFrameRef or a test recorder
local function writeMatrixToDriver(driver, list, setFrameRef)
    driver:SetAttribute("bindcount", #list)
    for i, entry in ipairs(list) do
        driver:SetAttribute("bindkey" .. i, entry.key)
        setFrameRef(driver, "bindtarget" .. i, entry.target)
    end
end
KM._WriteMatrixToDriver = writeMatrixToDriver

--- Push a flat keybind matrix to the secure vehicle driver, then re-apply it
--- immediately when the driver is at rest. `list` is an array of
--- { key = <wow key string>, target = <named SecureActionButton frame> } pairs.
--- Every attribute write, frame ref, and SecureHandlerExecute is protected and
--- OOC-only, so when restricted this queues a full rebuild via OOCQueue and
--- returns; the driver itself keeps re-evaluating IN combat (that is the point).
--- @param list table Array of { key, target } entries (may be empty to clear)
local function pushSecureMatrix(list)
    if GRIPEMS.OOCQueue.IsRestricted() then
        GRIPEMS.OOCQueue:Add(function()
            KM:LoadKeybinds()
        end, D.OOC_OP_GENERIC)
        return
    end
    writeMatrixToDriver(vehicleDriver, list, SecureHandlerSetFrameRef)
    -- Cache the list for the attribute refreshers (RefreshSkyridePassAttrs reads
    -- it to resolve each bound button's skyride pass-through ability).
    KM._lastMatrixList = list
    -- Immediate at-rest re-apply. When the driver is settled at "none" -- or at
    -- "skyride" with autodismount on -- push the new matrix live now; when it is
    -- "suspend"/"petbattle" (or skyride with autodismount off), clear only and let
    -- the next applying transition re-apply from the freshly written attributes.
    SecureHandlerExecute(
        vehicleDriver,
        [=[
        local st = self:GetAttribute("emsstate")
        self:ClearBindings()
        local apply = (st == nil) or (st == "none")
            or (st == "skyride" and self:GetAttribute("autodismount") == "1")
        if apply then
            local n = self:GetAttribute("bindcount") or 0
            for i = 1, n do
                local key = self:GetAttribute("bindkey"..i)
                local target = self:GetFrameRef("bindtarget"..i)
                if key and target then
                    self:SetBindingClick(false, key, target, "LeftButton")
                end
            end
        end
    ]=]
    )
    -- Mirror the autoDismountFlying CVar and resolve per-button skyride pass
    -- text; both are OOC-queued internally and no-op outside the skyriding bar.
    KM:RefreshAutoDismountAttr()
    KM:RefreshSkyridePassAttrs()
    if GRIPEMS.VehicleKeybinds and GRIPEMS.VehicleKeybinds._PushMatrix then
        GRIPEMS.VehicleKeybinds:_PushMatrix()
    end
end
KM._PushSecureMatrix = pushSecureMatrix

--- Resolve, per bound button, the "/cast <name>" pass-through text for
--- the skyriding ability its key would drive, and store it as the
--- button's skyridepass attribute. Resolution is live-only: outside the
--- skyriding bonus bar (offset ~= 5) every attribute clears. Slot math is
--- the formula Blizzard's own Surge Forward tutorial uses:
--- (NUM_ACTIONBAR_PAGES + GetBonusBarOffset() - 1) * NUM_ACTIONBAR_BUTTONS + slot.
--- C_Spell.GetSpellName returns the client-locale name, so localized
--- clients cast correctly. OOC-queued; mount transitions are OOC.
function KM:RefreshSkyridePassAttrs()
    if GRIPEMS.OOCQueue.IsRestricted() then
        GRIPEMS.OOCQueue:Add(function()
            KM:RefreshSkyridePassAttrs()
        end, D.OOC_OP_GENERIC)
        return
    end
    local offset = (C_ActionBar and C_ActionBar.GetBonusBarOffset and C_ActionBar.GetBonusBarOffset()) or 0
    -- While the watchdog force is up, resolve pass text against the skyriding bar even when the readable offset is stale.
    if offset ~= 5 and vehicleDriver:GetAttribute("skyrideforce") == "1" then
        offset = 5
    end
    local list = KM._lastMatrixList
    if list then
        local vkKeys = (GRIPEMS.VehicleKeybinds and GRIPEMS.VehicleKeybinds:GetAllKeybinds()) or {}
        for _, entry in ipairs(list) do
            local passText = nil
            if offset == 5 then
                local slot = KM._GetSkyrideSlotForKey(entry.key, GetBindingAction, vkKeys)
                if slot then
                    local base = (NUM_ACTIONBAR_PAGES + offset - 1) * NUM_ACTIONBAR_BUTTONS
                    local aType, aID = GetActionInfo(base + slot)
                    if aType == "spell" and aID then
                        local spellName = C_Spell.GetSpellName(aID)
                        if spellName and spellName ~= "" then
                            passText = "/cast " .. spellName
                        end
                    end
                end
            end
            entry.target:SetAttribute("skyridepass", passText)
        end
    end
    -- Phase 2: resolve the VehicleKeybinds skyride cast buttons against the SAME bridged
    -- offset so VK-only / autodismount-off overlap keys reach the skyride ability by name
    -- under ElvUI. VK holds no skyrideforce visibility of its own, so the offset is passed.
    if GRIPEMS.VehicleKeybinds and GRIPEMS.VehicleKeybinds.RefreshSkyrideCastAttrs then
        GRIPEMS.VehicleKeybinds:RefreshSkyrideCastAttrs(offset)
    end
end

--- Mirror the game CVar autoDismountFlying onto the driver as the
--- "autodismount" attribute. The driver snippet re-applies or clears
--- skyride-state bindings when this flips, so EMS follows the same
--- Auto Dismount in Flight option the default UI uses. Also mirrors
--- autoUnshift as the "autounshift" attribute; the click body reads it
--- live per press to decide whether the skyride prefix carries
--- /cancelform (druid skyriding Travel Form unshift). An autounshift
--- attribute change deliberately does NOT re-dispatch the driver because
--- it never affects which keys are bound, only the composed prefix.
function KM:RefreshAutoDismountAttr()
    if GRIPEMS.OOCQueue.IsRestricted() then
        GRIPEMS.OOCQueue:Add(function()
            KM:RefreshAutoDismountAttr()
        end, D.OOC_OP_GENERIC)
        return
    end
    local on = GetCVar and GetCVar("autoDismountFlying") == "1"
    vehicleDriver:SetAttribute("autodismount", on and "1" or nil)
    local unshift = GetCVar and GetCVar("autoUnshift") == "1"
    vehicleDriver:SetAttribute("autounshift", unshift and "1" or nil)
    if GRIPEMS.VehicleKeybinds and GRIPEMS.VehicleKeybinds.RefreshAutoDismountAttr then
        GRIPEMS.VehicleKeybinds:RefreshAutoDismountAttr()
    end
end

--- Pure decision helper for the OOC suspend watchdog (Phase SKYRIDE-WATCHDOG /
--- SKYRIDE-ENTER-WATCHDOG). Given the driver's emsstate, an offset-free reality
--- check, whether the VehicleKeybinds layer is live, whether the watchdog has
--- already healed, the offset-free isGliding signal, and whether the watchdog
--- already force-applied around a missed enter, decide what each keybind layer
--- needs. No WoW API calls -- headless-drivable with plain values.
---   driver = "heal"       state is a real suspend value but reality shows no source
---                         -> force the EMS sequence bindings back live.
---   driver = "reclear"    we previously healed, but a real suspend source returned
---                         -> re-run driver policy for the current state (clear;
---                         re-apply only for skyride with autodismount on).
---   driver = "enterheal"  state reads at rest but the player IS skyriding (the
---                         missed-enter case) -> force the skyride layers up.
---   driver = "enterclear" we previously enter-healed and the player is back at
---                         rest -> retire the force and restore at-rest policy.
---   vk     = "activate"   the user's vehicle keybinds must bind even though
---                         vkstate went stale. Pairs with "enterheal" when both
---                         layers missed the enter, and fires on its own when
---                         only the vehicle layer is stale while skyriding (the
---                         sequence driver already holds "skyride") -- the
---                         asymmetric overlap case.
---   vk     = "deactivate" no real source but the vehicle-keybind override is still
---                         live (the missed-exit case) -> clear it. Independent of the
---                         driver layer: it fires even at state "none".
--- glidingActive true implies anyRealSource true (isGliding is in the reality
--- check's truth set), so "activate" and "deactivate" cannot collide.
--- Each field is nil when its layer needs no action.
--- @param state string|nil The driver emsstate attribute value
--- @param anyRealSource boolean Offset-free reality check (a genuine suspend source exists)
--- @param vkActive boolean VehicleKeybinds:IsActive()
--- @param healed boolean KM._watchdogHealed (did the watchdog already force bindings live)
--- @param glidingActive boolean Offset-free isGliding signal (actively skyriding right now)
--- @param enterHealed boolean KM._enterHealed (did the watchdog already heal a missed enter)
--- @return table { driver = "heal"|"reclear"|"enterheal"|"enterclear"|nil, vk = "activate"|"deactivate"|nil }
function KM._SuspendWatchdogVerdict(state, anyRealSource, vkActive, healed, glidingActive, enterHealed)
    local verdict = {}
    local suspended = state ~= nil and state ~= "none"
    if suspended and not anyRealSource then
        verdict.driver = "heal"
    elseif suspended and anyRealSource and healed then
        verdict.driver = "reclear"
    end
    if not suspended and glidingActive and not enterHealed then
        verdict.driver = "enterheal"
        verdict.vk = "activate"
    elseif not suspended and not glidingActive and enterHealed then
        verdict.driver = "enterclear"
    end
    -- Asymmetric skyride enter: the sequence driver caught it (emsstate is a
    -- real suspend value, e.g. "skyride") but the vehicle driver missed it
    -- (vkActive false), so the enter-heal branch above -- gated on
    -- not-suspended -- never fired. An overlapped key (one physical key bound
    -- as BOTH a sequence keybind and a vehicle keybind) is then dead: the
    -- vehicle layer never set its priority ACTIONBUTTON override and nothing
    -- else carries the slot. glidingActive scopes this to skyriding (isGliding
    -- is false for ground vehicles and seated mounts), so the "suspend" and
    -- "petbattle" states never reach here.
    if suspended and glidingActive and not vkActive then
        verdict.vk = "activate"
    end
    if not anyRealSource and vkActive then
        verdict.vk = "deactivate"
    end
    return verdict
end

-- Tracks whether the watchdog forced EMS sequence bindings back live around a
-- stale suspend. Set on a heal, cleared on a reclear or a genuine "none"
-- transition. Lets the watchdog undo its own work without ever forging the
-- driver's emsstate attribute (the driver owns that).
KM._watchdogHealed = false

-- Tracks whether the watchdog force-applied the skyride layers around a
-- missed enter (state stuck at rest while genuinely skyriding).
KM._enterHealed = false

--- OOC suspend watchdog (Phase SKYRIDE-WATCHDOG). Builds an OFFSET-FREE picture of
--- reality and reconciles BOTH keybind layers against it when skyriding exit
--- signals go missing (a skyriding dismount fires no UNIT_EXITED_VEHICLE and its
--- bar-swap event is unreliable):
---   LAYER 1 (driver)  a missed exit can leave emsstate stuck at "suspend" /
---                     "petbattle" (or the bar page stuck at bonus offset 5) on
---                     foot, so [bonusbar:5] holds suspend and the sequence key
---                     stays dropped.
---   LAYER 2 (vehicle) a missed exit can leave VehicleKeybinds' override binding
---                     live on foot; override bindings OUTRANK the secure driver,
---                     so the key stays eaten even where the driver healed itself.
--- GetBonusBarOffset is deliberately EXCLUDED from the truth set -- it is the one
--- input that goes stale after a messy dismount; it is read for the debug line only.
--- OOC-only and never queued: every binding call is nocombat-restricted, so a
--- trigger that lands in combat defers to PLAYER_REGEN_ENABLED, which re-runs this.
--- The watchdog also heals the ENTER side (Phase SKYRIDE-ENTER-WATCHDOG): a fresh
--- login can leave both drivers stuck at rest through the session's first
--- skyriding mount, so when the state reads at rest but the player IS skyriding
--- the watchdog force-applies the skyride layers, including activating
--- VehicleKeybinds. The enter heal is gated on isGliding ONLY: canGlide stays
--- false-positive-prone on the ground, and isGliding reads false for steady-flight
--- flyers and seated mounts, where the sequence keys are correct as-is. The force
--- is retired by any real driver dispatch (the snippet clears it) or by the
--- enterclear branch below. Never writes emsstate -- the driver owns it.
function KM:HealStuckSuspend()
    if GRIPEMS.OOCQueue.IsRestricted() then
        return
    end

    -- Offset-free reality check. canGlide guards a GROUNDED skyriding Travel Form
    -- druid or a hovering dracthyr (isGliding is false but the bar is legitimate);
    -- on foot after a normal dismount canGlide reads false. Every C_ read is guarded
    -- so a missing API degrades to false instead of erroring. airborne carries the
    -- bare isGliding signal for the enter-heal gate.
    local gliding = false
    local airborne = false
    if C_PlayerInfo and C_PlayerInfo.GetGlidingInfo then
        local isGliding, canGlide = C_PlayerInfo.GetGlidingInfo()
        gliding = (isGliding or canGlide) or false
        airborne = isGliding or false
    end
    local anyRealSource = (IsMounted and IsMounted())
        or gliding
        or (UnitHasVehicleUI and UnitHasVehicleUI("player"))
        or (HasVehicleActionBar and HasVehicleActionBar())
        or (C_ActionBar and C_ActionBar.HasOverrideActionBar and C_ActionBar.HasOverrideActionBar())
        or (C_ActionBar and C_ActionBar.IsPossessBarVisible and C_ActionBar.IsPossessBarVisible())
        or (C_PetBattles and C_PetBattles.IsInBattle and C_PetBattles.IsInBattle())
        or false

    -- Diagnosis only -- offset is NEVER part of the truth set above.
    local offset = (C_ActionBar and C_ActionBar.GetBonusBarOffset and C_ActionBar.GetBonusBarOffset()) or 0

    local state = vehicleDriver:GetAttribute("emsstate")
    local vkActive = (GRIPEMS.VehicleKeybinds and GRIPEMS.VehicleKeybinds:IsActive()) or false
    local verdict =
        KM._SuspendWatchdogVerdict(state, anyRealSource, vkActive, KM._watchdogHealed, airborne, KM._enterHealed)

    if verdict.vk == "activate" then
        -- Missed enter: the user's vehicle keybinds never bound because vkstate
        -- went stale; apply them regardless of the state attribute.
        GRIPEMS.VehicleKeybinds:ForceApply()
    end

    if verdict.vk == "deactivate" then
        GRIPEMS.VehicleKeybinds:Deactivate()
        GRIPEMS:Debug("skyride watchdog: cleared stale vehicle keybinds (offset=" .. tostring(offset) .. ")")
    end

    -- A real bar returned: lift any watchdog force-clear so the secure VK
    -- driver re-applies. ClearSuppress re-dispatches vkstate, so the driver
    -- re-binds on the spot when the bar is genuinely up.
    if
        anyRealSource
        and GRIPEMS.VehicleKeybinds
        and GRIPEMS.VehicleKeybinds.IsSuppressed
        and GRIPEMS.VehicleKeybinds:IsSuppressed()
    then
        GRIPEMS.VehicleKeybinds:ClearSuppress()
    end

    if verdict.driver == "heal" then
        -- Same bindcount/bindkey/bindtarget reapply loop the _onattributechanged
        -- none-branch uses, without the state guard: clear then bind unconditionally.
        SecureHandlerExecute(
            vehicleDriver,
            [=[
            self:ClearBindings()
            local n = self:GetAttribute("bindcount") or 0
            for i = 1, n do
                local key = self:GetAttribute("bindkey"..i)
                local target = self:GetFrameRef("bindtarget"..i)
                if key and target then
                    self:SetBindingClick(false, key, target, "LeftButton")
                end
            end
        ]=]
        )
        KM._watchdogHealed = true
        local msg = string.format(
            "skyride watchdog: healed stuck suspend (state=%s offset=%s)",
            tostring(state),
            tostring(offset)
        )
        GRIPEMS:Debug(msg)
    elseif verdict.driver == "reclear" then
        -- Re-run the driver's own apply decision for the CURRENT state instead of
        -- assuming clear: suspend/petbattle want bindings down, but skyride with
        -- autodismount == "1" wants them live (per-press routing). A plain clear
        -- here would drop routing for the rest of the flight after a heal->remount.
        SecureHandlerExecute(
            vehicleDriver,
            [=[
            local st = self:GetAttribute("emsstate")
            self:ClearBindings()
            if st == "skyride" and self:GetAttribute("autodismount") == "1" then
                local n = self:GetAttribute("bindcount") or 0
                for i = 1, n do
                    local key = self:GetAttribute("bindkey"..i)
                    local target = self:GetFrameRef("bindtarget"..i)
                    if key and target then
                        self:SetBindingClick(false, key, target, "LeftButton")
                    end
                end
            end
        ]=]
        )
        KM._watchdogHealed = false
        GRIPEMS:Debug("skyride watchdog: re-cleared (real suspend source returned)")
    elseif verdict.driver == "enterheal" then
        -- Missed enter: the driver never dispatched skyride, so force the
        -- skyride policy by hand -- clear, then bind only when autodismount
        -- is on (the same apply rule the snippet's skyride branch uses). The
        -- force attribute keeps the click bodies and pass-attr resolution on
        -- the skyride path until a real dispatch retires it.
        KM:RefreshAutoDismountAttr()
        vehicleDriver:SetAttribute("skyrideforce", "1")
        SecureHandlerExecute(
            vehicleDriver,
            [=[
            self:ClearBindings()
            if self:GetAttribute("autodismount") == "1" then
                local n = self:GetAttribute("bindcount") or 0
                for i = 1, n do
                    local key = self:GetAttribute("bindkey"..i)
                    local target = self:GetFrameRef("bindtarget"..i)
                    if key and target then
                        self:SetBindingClick(false, key, target, "LeftButton")
                    end
                end
            end
        ]=]
        )
        KM:RefreshSkyridePassAttrs()
        KM._enterHealed = true
        GRIPEMS:Debug(
            "skyride watchdog: healed missed skyride enter (state="
                .. tostring(state)
                .. " offset="
                .. tostring(offset)
                .. ")"
        )
    elseif verdict.driver == "enterclear" then
        -- Back at rest after an enter heal with no real dispatch in between:
        -- retire the force and restore at-rest policy (clear, then bind
        -- unconditionally -- the same body the heal branch uses).
        vehicleDriver:SetAttribute("skyrideforce", nil)
        SecureHandlerExecute(
            vehicleDriver,
            [=[
            self:ClearBindings()
            local n = self:GetAttribute("bindcount") or 0
            for i = 1, n do
                local key = self:GetAttribute("bindkey"..i)
                local target = self:GetFrameRef("bindtarget"..i)
                if key and target then
                    self:SetBindingClick(false, key, target, "LeftButton")
                end
            end
        ]=]
        )
        KM:RefreshSkyridePassAttrs()
        KM._enterHealed = false
        GRIPEMS:Debug("skyride watchdog: cleared missed-enter force (back at rest)")
    elseif state == "none" or state == nil then
        -- A genuine none transition ran; the driver owns bindings again.
        KM._watchdogHealed = false
    end
end

--- Hand the secure driver to a sequence button as the "emsdriver" frame
--- ref so the WrapScript click body can read emsstate. Must run out of
--- combat (button creation already is).
--- @param btn table SecureActionButton frame
function KM:AttachDriverRef(btn)
    SecureHandlerSetFrameRef(btn, "emsdriver", vehicleDriver)
end

--- Merge the per-spec fallback layer with the active loadout's overlay into the
--- final {key=seqName} map (Section 4.3): the _byLoadout subtable is skipped in
--- the base pass, then the active overlay overrides, with the "__suppress__"
--- sentinel removing a matching per-spec key. Pulled out of LoadKeybinds so the
--- resolution can be asserted directly.
--- @param specBinds table The GRIP_EMS_CHAR.keybinds[spec] table
--- @param activeLoadoutID number|nil Active loadout configID, or nil
--- @return table final {key = seqName} map
function KM:_ResolveFinalKeybinds(specBinds, activeLoadoutID)
    local final = {}
    for k, v in pairs(specBinds) do
        if k ~= "_byLoadout" then
            final[k] = v
        end
    end
    local loadoutOverlay = nil
    if specBinds._byLoadout and activeLoadoutID then
        loadoutOverlay = specBinds._byLoadout[activeLoadoutID]
    end
    if loadoutOverlay then
        for k, v in pairs(loadoutOverlay) do
            if v == "__suppress__" then
                final[k] = nil
            else
                final[k] = v
            end
        end
    end
    return final
end

--- Flatten a resolved {key=seqName} map into the secure-driver matrix list
--- (plain key -> base button, each present modifier's prefixed key -> variant
--- button). Sequences whose base button is not yet in _G are skipped and logged;
--- BindIfConfigured rebuilds on activation. Returns the list plus the count of
--- sequences with a live button (for the debug line). Pulled out of LoadKeybinds
--- for direct assertion.
--- @param final table {key = seqName} map
--- @return table list, number count
function KM:_BuildMatrixList(final)
    local list = {}
    local count = 0
    local sequences = GRIPEMS.Engine and GRIPEMS.Engine.sequences
    for key, seqName in pairs(final) do
        local entry = sequences and sequences[seqName]
        local disabled = entry and entry.data and entry.data.disabled
        local sanitized = GRIPEMS.Engine:SanitizeName(seqName)
        local buttonName = D.BUTTON_PREFIX .. sanitized
        -- A disabled (dormant) sequence keeps its keybind data for re-enable but
        -- must NOT bind. Engine's disable path leaves the base button's _G slot
        -- populated (only variant slots clear) and keeps the dormant entry in
        -- Engine.sequences, so the _G[buttonName] gate alone would re-bind the key
        -- to an orphaned, type=nil button -- consuming the key instead of letting
        -- it fall through. Deactivated sequences need no such guard: they are gone
        -- from Engine.sequences, so getVariantButtonsForSequence yields no button
        -- and applyBinding emits nothing.
        if _G[buttonName] and not disabled then
            applyBinding(key, seqName, list)
            count = count + 1
        else
            -- Button not created yet (BindIfConfigured rebuilds on activation), or
            -- the sequence is disabled. Either way it contributes no live binding.
            GRIPEMS:Debug("Keybind " .. key .. " -> " .. seqName .. ": no live button, skipped")
        end
    end
    return list, count
end

--- Return the current specialization index, or 0 if no spec is chosen.
--- Uses C_SpecializationInfo.GetSpecialization() (the non-deprecated 12.0+ API).
--- @return number Spec index (1-4) or 0 for unspecced characters
local function GetCurrentSpec()
    return C_SpecializationInfo.GetSpecialization() or 0
end

--- Return the current specialization index for external callers.
--- Internal code uses the local GetCurrentSpec() directly for speed.
--- @return number Spec index (1-4) or 0 for unspecced characters
function KM:GetCurrentSpec()
    return GetCurrentSpec()
end

--- Bootstrap entry: run the v1-to-v2 SV migration once per character.
--- Idempotent; safe to call from Engine bootstrap and from individual
--- LoadKeybinds paths.
function KM:Initialize()
    self:_MigrateToV2()
end

--- One-way migration from per-spec (v1) to per-spec + per-loadout overlay (v2).
--- The migration is a NO-OP rename: existing per-spec entries stay; an empty
--- _byLoadout subtable is initialized on each spec entry; keybindSchemaVersion
--- is stamped to 2. See Research/PerLoadout_Keybind_Design_2026-05-25.md Section 5.2.
function KM:_MigrateToV2()
    if not _G.GRIP_EMS_CHAR then
        return
    end
    if GRIP_EMS_CHAR.keybindSchemaVersion == 2 then
        return
    end
    GRIP_EMS_CHAR.keybinds = GRIP_EMS_CHAR.keybinds or {}
    for _, specEntry in pairs(GRIP_EMS_CHAR.keybinds) do
        if type(specEntry) == "table" then
            specEntry._byLoadout = specEntry._byLoadout or {}
        end
    end
    GRIP_EMS_CHAR.keybindSchemaVersion = 2
    GRIPEMS:Debug("KeybindManager: migrated SV to schema v2 (per-loadout layer)")
end

--- Resolve the user-meaningful active loadout configID for the current spec.
--- Uses C_ClassTalents.GetLastSelectedSavedConfigID, which is the pointer the
--- Blizzard Talent UI dropdown uses to mark the active loadout. Returns nil
--- when no spec is chosen OR no saved loadout has been applied yet.
--- @return number|nil Active loadout configID, or nil.
function KM:_GetActiveLoadoutID()
    local currentSpec = C_SpecializationInfo and C_SpecializationInfo.GetSpecialization()
    if not currentSpec or currentSpec == 0 then
        return nil
    end
    local specID = nil
    if C_SpecializationInfo and C_SpecializationInfo.GetSpecializationInfo then
        specID = C_SpecializationInfo.GetSpecializationInfo(currentSpec)
    end
    if not specID then
        return nil
    end
    if not (C_ClassTalents and C_ClassTalents.GetLastSelectedSavedConfigID) then
        return nil
    end
    local configID = C_ClassTalents.GetLastSelectedSavedConfigID(specID)
    -- Starter Build returns the sentinel -2 (Constants.TraitConsts.STARTER_BUILD_TRAIT_CONFIG_ID),
    -- which is not a saved-loadout bucket key. Coerce negative sentinels to nil so the
    -- per-spec fallback layer applies and the loss guard's nil branch owns the verdict
    -- (the benign-switch branch would otherwise suppress the warning -- silent loss).
    if configID and configID < 0 then
        return nil
    end
    return configID
end

--- Return a human-readable name for a loadout configID.
--- Uses C_Traits.GetConfigInfo(id).name with a defensive fallback to
--- "Loadout #<id>" when the field is nil. Returns nil only when the input
--- loadoutID is nil.
--- @param loadoutID number|nil
--- @return string|nil
function KM:_GetActiveLoadoutName(loadoutID)
    if not loadoutID then
        return nil
    end
    local info = C_Traits and C_Traits.GetConfigInfo and C_Traits.GetConfigInfo(loadoutID)
    if info and info.name and info.name ~= "" then
        return info.name
    end
    return "Loadout #" .. tostring(loadoutID)
end

--- Set an override keybinding for a sequence. Dispatches between the per-spec
--- fallback layer and the per-loadout overlay based on the
--- GRIP_EMS_CHAR.keybindsPerLoadout flag and active-loadout resolvability.
--- Validates the sequence exists; per-layer methods clear prior bindings and
--- queue via OOCQueue if in combat.
--- @param seqName string Sequence name (must exist in Engine.sequences)
--- @param key string WoW key string (e.g. "CTRL-F12", "SHIFT-G", "F5")
function KM:SetKeybind(seqName, key)
    if not (_G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.keybindsPerLoadout) then
        return self:_SetKeybindPerSpec(seqName, key)
    end
    local activeLoadoutID = self:_GetActiveLoadoutID()
    if not activeLoadoutID then
        return self:_SetKeybindPerSpec(seqName, key)
    end
    return self:_SetKeybindPerLoadout(seqName, key, activeLoadoutID)
end

--- Per-spec fallback-layer write. This is the original v1 SetKeybind body.
--- Writes to GRIP_EMS_CHAR.keybinds[spec][key] = seqName.
--- @param seqName string Sequence name
--- @param key string WoW key string
function KM:_SetKeybindPerSpec(seqName, key)
    if not seqName or not key then
        return
    end
    if type(key) ~= "string" or key == "" then
        return
    end

    -- Validate sequence exists
    if not GRIPEMS.Engine or not GRIPEMS.Engine.sequences[seqName] then
        GRIPEMS:Print(string.format(L["GEMS_NOT_FOUND"], seqName))
        return
    end

    local spec = GetCurrentSpec()

    -- Ensure subtables exist
    if not _G.GRIP_EMS_CHAR then
        return
    end
    GRIP_EMS_CHAR.keybinds = GRIP_EMS_CHAR.keybinds or {}
    GRIP_EMS_CHAR.keybinds[spec] = GRIP_EMS_CHAR.keybinds[spec] or {}
    local specBinds = GRIP_EMS_CHAR.keybinds[spec]

    -- Clear any existing key bound to THIS sequence (one seq = one keybind).
    -- SV-only; the driver matrix rebuild below drops any stale live binding.
    for existingKey, existingSeq in pairs(specBinds) do
        if existingKey ~= "_byLoadout" and existingSeq == seqName then
            specBinds[existingKey] = nil
            break
        end
    end

    -- Clear any existing sequence bound to the TARGET key (SV-only)
    if specBinds[key] then
        specBinds[key] = nil
    end

    -- Store the new binding
    specBinds[key] = seqName

    -- The secure driver owns the live bindings; route every mutation through one
    -- coalesced matrix rebuild. LoadKeybinds skips not-yet-created buttons and
    -- BindIfConfigured re-triggers a rebuild on activation, so the old
    -- pendingBinds defer (BUG-029) is subsumed. ScheduleLoadKeybinds OOC-queues
    -- the rebuild when restricted.
    self:ScheduleLoadKeybinds()
    GRIPEMS:Print(string.format(L["GEMS_BIND_SUCCESS"], seqName, key))

    if GRIPEMS.Fire then
        GRIPEMS:Fire("KEYBIND_CHANGED", seqName, key)
    end
end

--- Per-loadout-overlay write. Writes to
--- GRIP_EMS_CHAR.keybinds[spec]._byLoadout[loadoutID][key] = seqName.
--- The per-spec fallback layer is NEVER mutated by this method.
--- Sweeps for collisions only within the per-loadout subtable.
--- @param seqName string Sequence name
--- @param key string WoW key string
--- @param loadoutID number Loadout configID to write to
function KM:_SetKeybindPerLoadout(seqName, key, loadoutID)
    if not seqName or not key or not loadoutID then
        return
    end
    if type(key) ~= "string" or key == "" then
        return
    end

    -- Validate sequence exists
    if not GRIPEMS.Engine or not GRIPEMS.Engine.sequences[seqName] then
        GRIPEMS:Print(string.format(L["GEMS_NOT_FOUND"], seqName))
        return
    end

    local spec = GetCurrentSpec()

    -- Ensure subtables exist
    if not _G.GRIP_EMS_CHAR then
        return
    end
    GRIP_EMS_CHAR.keybinds = GRIP_EMS_CHAR.keybinds or {}
    GRIP_EMS_CHAR.keybinds[spec] = GRIP_EMS_CHAR.keybinds[spec] or {}
    local specBinds = GRIP_EMS_CHAR.keybinds[spec]
    specBinds._byLoadout = specBinds._byLoadout or {}
    specBinds._byLoadout[loadoutID] = specBinds._byLoadout[loadoutID] or {}
    local loadoutBinds = specBinds._byLoadout[loadoutID]

    -- Clear any existing key bound to THIS sequence in the per-loadout layer
    -- (one seq = one keybind per loadout). Per-spec layer untouched. SV-only;
    -- the driver matrix rebuild below drops any stale live binding.
    for existingKey, existingSeq in pairs(loadoutBinds) do
        if existingSeq == seqName then
            loadoutBinds[existingKey] = nil
            break
        end
    end

    -- Clear any existing sequence bound to the TARGET key in the per-loadout layer (SV-only)
    if loadoutBinds[key] then
        loadoutBinds[key] = nil
    end

    -- Store the new binding in the per-loadout overlay
    loadoutBinds[key] = seqName

    -- Route through one coalesced matrix rebuild. LoadKeybinds merges only the
    -- ACTIVE loadout's overlay, so a write to a non-active loadout updates SV and
    -- the rebuild leaves the live set unchanged; the next rebuild after that
    -- loadout becomes active picks it up. ScheduleLoadKeybinds OOC-queues the
    -- rebuild when restricted.
    self:ScheduleLoadKeybinds()
    GRIPEMS:Print(string.format(L["GEMS_BIND_SUCCESS"], seqName, key))

    if GRIPEMS.Fire then
        GRIPEMS:Fire("KEYBIND_CHANGED", seqName, key)
    end
end

--- Slash --loadout flag overload: bind seqName -> key in an explicitly-specified
--- loadout (not the active one). Validates the loadoutID via
--- C_Traits.GetConfigInfo. Does NOT touch live override bindings unless the
--- target loadout happens to be the active one (LoadKeybinds will rebuild on
--- next switch).
--- @param seqName string Sequence name
--- @param key string WoW key string
--- @param explicitLoadoutID number Target loadout configID
function KM:_SetKeybindForLoadout(seqName, key, explicitLoadoutID)
    if not explicitLoadoutID then
        return
    end
    local info = C_Traits and C_Traits.GetConfigInfo and C_Traits.GetConfigInfo(explicitLoadoutID)
    if not info then
        GRIPEMS:Print(string.format(L["GEMS_BIND_LOADOUT_NOT_FOUND"], tostring(explicitLoadoutID)))
        return
    end
    self:_SetKeybindPerLoadout(seqName, key, explicitLoadoutID)
end

--- Write the "__suppress__" sentinel into _byLoadout[loadoutID][perSpecKey] so
--- a per-spec binding is removed for ONE loadout only. Other loadouts continue
--- to inherit the per-spec binding.
--- @param perSpecKey string The key string whose per-spec binding should be hidden
--- @param loadoutID number Target loadout configID
function KM:_SuppressKeybindForLoadout(perSpecKey, loadoutID)
    if not perSpecKey or not loadoutID then
        return
    end
    if not _G.GRIP_EMS_CHAR or not GRIP_EMS_CHAR.keybinds then
        return
    end
    local spec = GetCurrentSpec()
    local specBinds = GRIP_EMS_CHAR.keybinds[spec]
    if not specBinds then
        return
    end
    specBinds._byLoadout = specBinds._byLoadout or {}
    specBinds._byLoadout[loadoutID] = specBinds._byLoadout[loadoutID] or {}
    specBinds._byLoadout[loadoutID][perSpecKey] = "__suppress__"
    self:ScheduleLoadKeybinds()
    if GRIPEMS.Fire then
        GRIPEMS:Fire("KEYBIND_CHANGED")
    end
end

--- Remove the "__suppress__" sentinel for a per-spec key in a specific loadout.
--- The per-spec binding becomes visible again under that loadout.
--- @param perSpecKey string The key string whose suppression should be lifted
--- @param loadoutID number Target loadout configID
function KM:_UnsuppressKeybindForLoadout(perSpecKey, loadoutID)
    if not perSpecKey or not loadoutID then
        return
    end
    if not _G.GRIP_EMS_CHAR or not GRIP_EMS_CHAR.keybinds then
        return
    end
    local spec = GetCurrentSpec()
    local specBinds = GRIP_EMS_CHAR.keybinds[spec]
    if not specBinds or not specBinds._byLoadout then
        return
    end
    local loadoutBinds = specBinds._byLoadout[loadoutID]
    if not loadoutBinds then
        return
    end
    if loadoutBinds[perSpecKey] == "__suppress__" then
        loadoutBinds[perSpecKey] = nil
    end
    self:ScheduleLoadKeybinds()
    if GRIPEMS.Fire then
        GRIPEMS:Fire("KEYBIND_CHANGED")
    end
end

--- Clear the keybinding for a sequence. Dispatches between the per-spec
--- fallback layer and the per-loadout overlay based on the
--- GRIP_EMS_CHAR.keybindsPerLoadout flag and active-loadout resolvability.
--- The per-loadout case routes to _ClearKeybindForLoadout so the active
--- overlay entry is cleared, not just the per-spec layer.
--- @param seqName string Sequence name
function KM:ClearKeybind(seqName)
    if not (_G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.keybindsPerLoadout) then
        return self:_ClearKeybindPerSpec(seqName)
    end
    local activeLoadoutID = self:_GetActiveLoadoutID()
    if not activeLoadoutID then
        return self:_ClearKeybindPerSpec(seqName)
    end
    return self:_ClearKeybindForLoadout(seqName, activeLoadoutID)
end

--- Clear the keybinding for a sequence in the current spec (per-spec layer only).
--- Removes the override binding and deletes the saved data entry.
--- Per-loadout overlay entries are NOT touched here; use _ClearKeybindForLoadout
--- with an explicit loadoutID to clear per-loadout entries.
--- @param seqName string Sequence name
function KM:_ClearKeybindPerSpec(seqName)
    if not seqName then
        return
    end

    local spec = GetCurrentSpec()
    if not GRIP_EMS_CHAR or not GRIP_EMS_CHAR.keybinds then
        return
    end
    local specBinds = GRIP_EMS_CHAR.keybinds[spec]
    if not specBinds then
        GRIPEMS:Print(string.format(L["GEMS_UNBIND_NO_BIND"], seqName))
        return
    end

    -- Find the key bound to this sequence in the per-spec layer (skip _byLoadout)
    local foundKey = nil
    for key, boundSeq in pairs(specBinds) do
        if key ~= "_byLoadout" and boundSeq == seqName then
            foundKey = key
            break
        end
    end

    if not foundKey then
        GRIPEMS:Print(string.format(L["GEMS_UNBIND_NO_BIND"], seqName))
        return
    end

    -- Remove from saved data, then rebuild the driver matrix (the driver owns the
    -- live binding; the rebuild drops the now-removed key).
    specBinds[foundKey] = nil
    self:ScheduleLoadKeybinds()
    GRIPEMS:Print(string.format(L["GEMS_UNBIND_SUCCESS"], seqName))

    if GRIPEMS.Fire then
        GRIPEMS:Fire("KEYBIND_CHANGED", seqName, nil)
    end
end

--- Slash --loadout flag overload: walks specBinds._byLoadout[loadoutID] for any
--- binding to seqName and removes it. Validates the loadoutID via
--- C_Traits.GetConfigInfo. Schedules LoadKeybinds so the live overrides
--- rebuild from the merged final table.
--- @param seqName string Sequence name
--- @param loadoutID number Target loadout configID
function KM:_ClearKeybindForLoadout(seqName, loadoutID)
    if not seqName or not loadoutID then
        return
    end
    local info = C_Traits and C_Traits.GetConfigInfo and C_Traits.GetConfigInfo(loadoutID)
    if not info then
        GRIPEMS:Print(string.format(L["GEMS_BIND_LOADOUT_NOT_FOUND"], tostring(loadoutID)))
        return
    end
    if not _G.GRIP_EMS_CHAR or not GRIP_EMS_CHAR.keybinds then
        GRIPEMS:Print(string.format(L["GEMS_UNBIND_NO_BIND"], seqName))
        return
    end
    local spec = GetCurrentSpec()
    local specBinds = GRIP_EMS_CHAR.keybinds[spec]
    if not specBinds or not specBinds._byLoadout then
        GRIPEMS:Print(string.format(L["GEMS_UNBIND_NO_BIND"], seqName))
        return
    end
    local loadoutBinds = specBinds._byLoadout[loadoutID]
    if not loadoutBinds then
        GRIPEMS:Print(string.format(L["GEMS_UNBIND_NO_BIND"], seqName))
        return
    end

    local foundKey = nil
    for key, boundSeq in pairs(loadoutBinds) do
        if boundSeq == seqName then
            foundKey = key
            break
        end
    end

    if not foundKey then
        GRIPEMS:Print(string.format(L["GEMS_UNBIND_NO_BIND"], seqName))
        return
    end

    loadoutBinds[foundKey] = nil
    -- Reap the bucket when its last binding clears: an emptied
    -- _byLoadout[loadoutID] table otherwise persists in SavedVariables
    -- forever (orphaned-bucket residue observed in live SVs for stale
    -- loadout IDs). The _byLoadout container itself stays -- schema-v2
    -- spec tables carry it as structure and Set recreates buckets on
    -- demand.
    if next(loadoutBinds) == nil then
        specBinds._byLoadout[loadoutID] = nil
    end
    GRIPEMS:Print(string.format(L["GEMS_UNBIND_SUCCESS"], seqName))
    self:ScheduleLoadKeybinds()
    if GRIPEMS.Fire then
        GRIPEMS:Fire("KEYBIND_CHANGED", seqName, nil)
    end
end

--- Schedule a debounced LoadKeybinds call. Coalesces multiple rapid calls
--- (e.g., PLAYER_SPECIALIZATION_CHANGED + ACTIVE_TALENT_GROUP_CHANGED firing
--- together on a single spec change) into one deferred LoadKeybinds execution.
function KM:ScheduleLoadKeybinds()
    if self._pendingSpecLoad then
        return
    end
    self._pendingSpecLoad = true
    if C_Timer and C_Timer.After then
        C_Timer.After(0, function()
            KM._pendingSpecLoad = false
            KM:LoadKeybinds()
        end)
    end
end

--- True if the raw spec table holds ANY binding -- a per-spec key (not the
--- _byLoadout container) OR a non-empty per-loadout overlay bucket. Pure;
--- headless-drivable.
function KM._RawSpecHasBinds(specBinds)
    if type(specBinds) ~= "table" then
        return false
    end
    for k in pairs(specBinds) do
        if k ~= "_byLoadout" then
            return true
        end
    end
    if type(specBinds._byLoadout) == "table" then
        for _, bucket in pairs(specBinds._byLoadout) do
            if type(bucket) == "table" and next(bucket) ~= nil then
                return true
            end
        end
    end
    return false
end

--- Decide what LoadKeybinds does given the resolved-map size and whether
--- raw SV still holds binds. "heal-offer" fires ONLY when binds exist in SV
--- but the live set resolved empty (the routing-loss signature). Pure.
function KM._ResolveLoadVerdict(finalCount, rawHasBinds)
    if finalCount > 0 then
        return "load"
    end
    if rawHasBinds then
        return "heal-offer"
    end
    return "empty-ok"
end

--- Arm a debounced heal-offer warning only on a fresh episode -- not while
--- a timer is already pending and not after we already warned this episode.
--- Pure; headless-drivable.
function KM._ShouldArmHealOffer(verdict, armed, warned)
    return verdict == "heal-offer" and not armed and not warned
end

--- A resolved (non-nil) active loadout that is NOT where the last-known-good
--- binds lived is a benign empty, not a loss: either a deliberate switch to
--- a different loadout, or a first-of-session load onto a real loadout with
--- no prior-good snapshot to compare against. The genuine losses fall
--- through: a nil resolution (activeLoadoutID == nil) and a same-loadout
--- vanish (activeLoadoutID == lkgLoadoutID). Pure; headless-drivable.
function KM._IsBenignLoadoutSwitch(activeLoadoutID, lkgLoadoutID)
    return activeLoadoutID ~= nil and activeLoadoutID ~= lkgLoadoutID
end

--- Load all keybindings for the current spec. Clears all existing overrides
--- first, then reapplies from the resolution-order merge of the per-spec
--- fallback layer and the per-loadout overlay (Section 4.3 of the design doc).
--- Skips sequences whose buttons don't exist yet (BindIfConfigured catches
--- those on activation). Queues itself via OOCQueue if called during combat.
function KM:LoadKeybinds()
    if GRIPEMS.OOCQueue.IsRestricted() then
        GRIPEMS.OOCQueue:Add(function()
            KM:LoadKeybinds()
        end, D.OOC_OP_GENERIC)
        return
    end
    local spec = GetCurrentSpec()
    if spec == 0 then
        GRIPEMS:Debug("LoadKeybinds deferred: spec not yet known")
        if C_Timer and C_Timer.After then
            C_Timer.After(1, function()
                KM:LoadKeybinds()
            end)
        end
        return
    end

    -- The secure driver owns the live bindings. Build the flat matrix and hand it
    -- to the driver via pushSecureMatrix; the driver clears and
    -- re-applies. An empty matrix push IS the clear path, so push {} on every
    -- no-bind early-out instead of leaving stale driver bindings live.
    if not GRIP_EMS_CHAR or not GRIP_EMS_CHAR.keybinds then
        pushSecureMatrix({})
        return
    end
    local specBinds = GRIP_EMS_CHAR.keybinds[spec]
    if not specBinds or not next(specBinds) then
        GRIPEMS:Debug("No keybinds for spec " .. spec)
        pushSecureMatrix({})
        return
    end

    -- Resolution order (Section 4.3): per-spec fallback layer, then the active
    -- loadout overlay, with "__suppress__" removing a matching per-spec key.
    local activeLoadoutID = self:_GetActiveLoadoutID()
    local final = self:_ResolveFinalKeybinds(specBinds, activeLoadoutID)

    -- Flatten final{} into one matrix list (plain + present variant buttons per
    -- sequence), then push the whole list to the driver in a single operation.
    local list, count = self:_BuildMatrixList(final)

    -- SEQUENCE-KEYBIND-LOSS guard + self-heal. finalCount is the RESOLVED
    -- map size (not live-button count), so a buttons-not-ready transient is
    -- not flagged.
    local finalCount = 0
    for _ in pairs(final) do
        finalCount = finalCount + 1
    end
    local rawHasBinds = KM._RawSpecHasBinds(specBinds)
    local verdict = KM._ResolveLoadVerdict(finalCount, rawHasBinds)

    if finalCount > 0 then
        -- Snapshot the last known good resolved set for /gems binds restore.
        local snap = {}
        for k, v in pairs(final) do
            snap[k] = v
        end
        GRIP_EMS_CHAR.keybindsLKG = {
            binds = snap,
            spec = spec,
            loadoutID = activeLoadoutID,
            count = finalCount,
        }
    end

    pushSecureMatrix(list)

    if verdict == "heal-offer" then
        KM._lastLoadUnexpectedlyEmpty = true
        local lkg = _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.keybindsLKG
        local lkgLoadoutID = lkg and lkg.loadoutID or nil
        if KM._IsBenignLoadoutSwitch(activeLoadoutID, lkgLoadoutID) then
            -- A benign empty (a deliberate switch to a different loadout, or a
            -- first-of-session load onto a real loadout with no prior-good
            -- snapshot): the prior loadout's binds are intact, so do not warn. A
            -- context change also ends any pending heal-offer episode, so a real
            -- loss that armed the timer moments earlier does not fire after the
            -- player switches away.
            KM._healOfferArmed = false
            KM._healOfferWarned = false
            GRIPEMS:Debug(
                string.format(
                    "keybind-loss guard: benign loadout switch (active=%s lkg=%s) -- no warning",
                    tostring(activeLoadoutID),
                    tostring(lkgLoadoutID)
                )
            )
        elseif KM._ShouldArmHealOffer(verdict, KM._healOfferArmed, KM._healOfferWarned) then
            KM._healOfferArmed = true
            local snapSpec, snapLoadout = spec, activeLoadoutID
            GRIPEMS:Debug(
                string.format(
                    "keybind-loss guard: empty-with-raw armed, settling (spec=%s activeLoadout=%s perLoadout=%s)",
                    tostring(spec),
                    tostring(activeLoadoutID),
                    tostring(_G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.keybindsPerLoadout)
                )
            )
            if C_Timer and C_Timer.After then
                C_Timer.After(KEYBIND_LOSS_SETTLE_SECONDS, function()
                    if not KM._healOfferArmed then
                        return
                    end
                    -- Active self-heal: re-resolve once before warning. The settle window
                    -- exists for late trait data (login race, lastSelected propagation,
                    -- external pointer writers) and NO event fires when the pointer
                    -- populates -- re-running the load is the only catch-up. _healOfferArmed
                    -- stays true across the call: the arming branch cannot re-arm, and the
                    -- benign branch clearing it marks a context change.
                    KM:LoadKeybinds()
                    if not KM._lastLoadUnexpectedlyEmpty then
                        GRIPEMS:Debug("keybind-loss guard: settle re-resolve healed the empty load")
                        return
                    end
                    if not KM._healOfferArmed then
                        -- A benign context change during the settle window ended the episode.
                        return
                    end
                    KM._healOfferArmed = false
                    KM._healOfferWarned = true
                    GRIPEMS:Print(L["GEMS_KEYBINDS_LOST_WARN"])
                    GRIPEMS:Print(L["GEMS_KEYBINDS_LOST_HINT"])
                    GRIPEMS:Debug(
                        string.format(
                            "keybind-loss guard: confirmed empty after settle (spec=%s activeLoadout=%s)",
                            tostring(snapSpec),
                            tostring(snapLoadout)
                        )
                    )
                end)
            end
        end
    else
        KM._lastLoadUnexpectedlyEmpty = false
        KM._healOfferArmed = false
        KM._healOfferWarned = false
        GRIPEMS:Debug(string.format(L["GEMS_KEYBINDS_LOADED"], count, spec))
    end

    if GRIPEMS.Fire then
        GRIPEMS:Fire("KEYBIND_CHANGED")
    end
end

--- Apply the saved keybinding for a sequence after its button is created.
--- Called by Engine:ActivateSequence after the button exists in _G. The secure
--- driver owns the live bindings, so this triggers one coalesced matrix rebuild;
--- LoadKeybinds now includes the just-created button. Subsumes the old
--- per-sequence applyBinding + pendingBinds defer (BUG-029): the SV already holds
--- the binding, and the rebuild picks it up now that the button exists.
--- @param seqName string Sequence name
function KM:BindIfConfigured(seqName)
    if not seqName then
        return
    end
    self:ScheduleLoadKeybinds()
end

--- Clear the live override binding for a sequence without removing saved data.
--- Called by Engine:DeactivateSequence/doDisable before the button is torn down.
--- The saved keybind entry remains so re-activation restores the binding. The
--- secure driver owns the live bindings, so this triggers one coalesced matrix
--- rebuild. ScheduleLoadKeybinds defers via C_Timer.After(0), so the rebuild runs
--- AFTER the sequence has been removed from Engine.sequences and its button torn
--- down -- getVariantButtonsForSequence then yields no button for it and the key
--- (plus its SHIFT/CTRL/ALT variant prefixes) is dropped from the new matrix.
--- @param seqName string Sequence name
function KM:UnbindSequence(seqName)
    if not seqName then
        return
    end
    self:ScheduleLoadKeybinds()
end

--- Remove ALL saved keybind data for a sequence across every spec AND every
--- per-loadout overlay. Called on permanent deletion (not deactivation).
--- Does NOT clear live override bindings (DeactivateSequence handles that).
--- @param seqName string Sequence name
function KM:PurgeKeybinds(seqName)
    if not seqName then
        return
    end
    if not GRIP_EMS_CHAR or not GRIP_EMS_CHAR.keybinds then
        return
    end
    for _, specBinds in pairs(GRIP_EMS_CHAR.keybinds) do
        if type(specBinds) == "table" then
            for key, boundSeq in pairs(specBinds) do
                if key ~= "_byLoadout" and boundSeq == seqName then
                    specBinds[key] = nil
                end
            end
            if specBinds._byLoadout then
                for _, loadoutBinds in pairs(specBinds._byLoadout) do
                    if type(loadoutBinds) == "table" then
                        for key, boundSeq in pairs(loadoutBinds) do
                            if boundSeq == seqName then
                                loadoutBinds[key] = nil
                            end
                        end
                    end
                end
            end
        end
    end
end

--- Remove the per-loadout overlay for a loadout from every spec entry. Shared
--- by two distinct callers, told apart by isDeletion:
---   * isDeletion=true  -- the real TRAIT_CONFIG_DELETED event (LoadoutManager).
---     The loadout is gone, so salvage its wiped overlay binds into the
---     keybindsLKG snapshot (recoverable via /gems binds restore) and tell the
---     user the binds came off a deleted loadout.
---   * isDeletion=false -- the manual "X" in the manage-loadouts popup, which
---     deliberately clears a STILL-EXISTING loadout's overlay. Use neutral
---     wording and do NOT touch keybindsLKG: clobbering it with a non-active
---     loadout's binds would degrade a later real-loss /gems binds restore for
---     the active loadout whose resolved set the snapshot holds.
--- The per-spec fallback layer is NOT touched in either case. Live override
--- bindings are NOT cleared here; LoadKeybinds rebuilds the live set from the
--- (now smaller) data.
--- @param deletedLoadoutID number The loadout configID whose overlay to remove
--- @param isDeletion boolean True for a real deletion; false/nil for a manual clear
function KM:PruneKeybindsForLoadout(deletedLoadoutID, isDeletion)
    if not deletedLoadoutID then
        return
    end
    if not GRIP_EMS_CHAR or not GRIP_EMS_CHAR.keybinds then
        return
    end
    local salvaged = {}
    local salvagedCount = 0
    for _, specBinds in pairs(GRIP_EMS_CHAR.keybinds) do
        if type(specBinds) == "table" and specBinds._byLoadout then
            local bucket = specBinds._byLoadout[deletedLoadoutID]
            if type(bucket) == "table" then
                for key, seqName in pairs(bucket) do
                    if seqName ~= "__suppress__" then
                        salvaged[key] = seqName
                        salvagedCount = salvagedCount + 1
                    end
                end
            end
            specBinds._byLoadout[deletedLoadoutID] = nil
        end
    end
    if salvagedCount == 0 then
        return
    end
    if isDeletion then
        -- Real deletion: keep the wiped binds recoverable via /gems binds
        -- restore -- a deleted/recreated loadout otherwise loses its overlay
        -- binds for good.
        GRIP_EMS_CHAR.keybindsLKG = {
            binds = salvaged,
            spec = GetCurrentSpec(),
            loadoutID = deletedLoadoutID,
            count = salvagedCount,
        }
        GRIPEMS:Print(string.format(L["GEMS_KEYBINDS_PRUNED_NOTICE"], salvagedCount))
    else
        -- Manual clear: the loadout still exists and the user asked for this.
        -- Neutral wording, and leave keybindsLKG alone so a non-active loadout's
        -- deliberate clear cannot clobber the active loadout's last-known-good
        -- snapshot.
        GRIPEMS:Print(string.format(L["GEMS_KEYBINDS_CLEARED_NOTICE"], salvagedCount))
    end
end

--- Get the key string EFFECTIVELY bound to a sequence in the current spec,
--- including the active loadout's overlay if per-loadout mode is on. Returns
--- the per-loadout key when both layers bind the sequence (overlay wins).
--- @param seqName string Sequence name
--- @return string|nil The key string, or nil if no binding exists
function KM:GetKeybind(seqName)
    if not seqName then
        return nil
    end

    local spec = GetCurrentSpec()
    if not GRIP_EMS_CHAR or not GRIP_EMS_CHAR.keybinds then
        return nil
    end
    local specBinds = GRIP_EMS_CHAR.keybinds[spec]
    if not specBinds then
        return nil
    end

    local perSpecKey = nil
    for key, boundSeq in pairs(specBinds) do
        if key ~= "_byLoadout" and boundSeq == seqName then
            perSpecKey = key
            break
        end
    end

    -- Active loadout overlay (if any) wins
    if specBinds._byLoadout then
        local activeLoadoutID = self:_GetActiveLoadoutID()
        if activeLoadoutID then
            local loadoutBinds = specBinds._byLoadout[activeLoadoutID]
            if loadoutBinds then
                for key, boundSeq in pairs(loadoutBinds) do
                    if boundSeq == seqName then
                        return key
                    end
                end
            end
        end
    end

    return perSpecKey
end

--- Return a copy of the resolved final keybinds for the current spec --
--- per-spec layer merged with the active loadout overlay (per Section 4.3
--- of the design doc). When per-loadout mode is off OR no active loadout,
--- returns the per-spec layer only.
--- @return table|nil Copy of {key = seqName} table, or nil if empty
function KM:GetAllKeybinds()
    local spec = GetCurrentSpec()
    if not GRIP_EMS_CHAR or not GRIP_EMS_CHAR.keybinds then
        return nil
    end
    local specBinds = GRIP_EMS_CHAR.keybinds[spec]
    if not specBinds then
        return nil
    end

    local final = {}
    for key, seqName in pairs(specBinds) do
        if key ~= "_byLoadout" then
            final[key] = seqName
        end
    end
    if specBinds._byLoadout then
        local activeLoadoutID = self:_GetActiveLoadoutID()
        if activeLoadoutID then
            local loadoutBinds = specBinds._byLoadout[activeLoadoutID]
            if loadoutBinds then
                for key, seqName in pairs(loadoutBinds) do
                    if seqName == "__suppress__" then
                        final[key] = nil
                    else
                        final[key] = seqName
                    end
                end
            end
        end
    end
    return final
end

--- Return a copy of the per-spec fallback layer for the current spec ONLY
--- (skips the _byLoadout overlay). Used by the Keybinds tab to render
--- "fallback bindings always active" rows.
--- @return table|nil Copy of {key = seqName} table, or nil if empty
function KM:GetPerSpecKeybinds()
    local spec = GetCurrentSpec()
    if not GRIP_EMS_CHAR or not GRIP_EMS_CHAR.keybinds then
        return nil
    end
    local specBinds = GRIP_EMS_CHAR.keybinds[spec]
    if not specBinds then
        return nil
    end
    local copy = {}
    for key, seqName in pairs(specBinds) do
        if key ~= "_byLoadout" then
            copy[key] = seqName
        end
    end
    return copy
end

--- Return a copy of the per-loadout overlay for a given loadoutID under the
--- current spec, or nil if no overlay exists.
--- @param loadoutID number Loadout configID
--- @return table|nil Copy of {key = seqName} table, or nil
function KM:GetPerLoadoutKeybinds(loadoutID)
    if not loadoutID then
        return nil
    end
    local spec = GetCurrentSpec()
    if not GRIP_EMS_CHAR or not GRIP_EMS_CHAR.keybinds then
        return nil
    end
    local specBinds = GRIP_EMS_CHAR.keybinds[spec]
    if not specBinds or not specBinds._byLoadout then
        return nil
    end
    local loadoutBinds = specBinds._byLoadout[loadoutID]
    if not loadoutBinds then
        return nil
    end
    local copy = {}
    for key, seqName in pairs(loadoutBinds) do
        copy[key] = seqName
    end
    return copy
end

--- Enumerate every loadoutID with at least one entry in the _byLoadout overlay
--- for a given spec (default: current spec). Returns an array of
--- { id = loadoutID, name = name-or-fallback, bindingCount = N } records.
--- @param specIndex number? Spec index, defaults to current spec
--- @return table Array (may be empty) of { id, name, bindingCount } records
function KM:GetAllLoadoutsWithBindings(specIndex)
    local result = {}
    specIndex = specIndex or GetCurrentSpec()
    if specIndex == 0 then
        return result
    end
    if not GRIP_EMS_CHAR or not GRIP_EMS_CHAR.keybinds then
        return result
    end
    local specBinds = GRIP_EMS_CHAR.keybinds[specIndex]
    if not specBinds or not specBinds._byLoadout then
        return result
    end
    for loadoutID, loadoutBinds in pairs(specBinds._byLoadout) do
        if type(loadoutBinds) == "table" then
            local count = 0
            for _ in pairs(loadoutBinds) do
                count = count + 1
            end
            table.insert(result, {
                id = loadoutID,
                name = self:_GetActiveLoadoutName(loadoutID) or ("Loadout #" .. tostring(loadoutID)),
                bindingCount = count,
            })
        end
    end
    return result
end

--- Re-apply the last-known-good keybind snapshot (the self-heal). Writes
--- each saved key->seq through SetKeybind (which routes to the per-loadout
--- overlay when that mode is on and a loadout resolves, else per-spec), then
--- the scheduled LoadKeybinds rebuilds the live set. Returns the count.
function KM:RestoreLastKnownKeybinds()
    if not _G.GRIP_EMS_CHAR or not GRIP_EMS_CHAR.keybindsLKG then
        GRIPEMS:Print(L["GEMS_KEYBINDS_RESTORE_NONE"])
        return 0
    end
    local snap = GRIP_EMS_CHAR.keybindsLKG.binds
    if type(snap) ~= "table" or next(snap) == nil then
        GRIPEMS:Print(L["GEMS_KEYBINDS_RESTORE_NONE"])
        return 0
    end
    local n = 0
    for key, seqName in pairs(snap) do
        if GRIPEMS.Engine and GRIPEMS.Engine.sequences[seqName] then
            self:SetKeybind(seqName, key)
            n = n + 1
        end
    end
    GRIPEMS:Print(string.format(L["GEMS_KEYBINDS_RESTORE_DONE"], n))
    return n
end

--- Bulk-copy every entry from one loadout overlay into another (current spec).
--- Validates both IDs via C_Traits.GetConfigInfo. Existing target entries
--- collide-overwrite; suppress sentinels are copied verbatim.
--- @param sourceLoadoutID number Source loadout configID
--- @param targetLoadoutID number Target loadout configID
function KM:CopyKeybindsFromLoadout(sourceLoadoutID, targetLoadoutID)
    if not sourceLoadoutID or not targetLoadoutID then
        return
    end
    if sourceLoadoutID == targetLoadoutID then
        return
    end
    local srcInfo = C_Traits and C_Traits.GetConfigInfo and C_Traits.GetConfigInfo(sourceLoadoutID)
    if not srcInfo then
        GRIPEMS:Print(string.format(L["GEMS_BIND_LOADOUT_NOT_FOUND"], tostring(sourceLoadoutID)))
        return
    end
    local tgtInfo = C_Traits and C_Traits.GetConfigInfo and C_Traits.GetConfigInfo(targetLoadoutID)
    if not tgtInfo then
        GRIPEMS:Print(string.format(L["GEMS_BIND_LOADOUT_NOT_FOUND"], tostring(targetLoadoutID)))
        return
    end
    if not _G.GRIP_EMS_CHAR then
        return
    end
    GRIP_EMS_CHAR.keybinds = GRIP_EMS_CHAR.keybinds or {}
    local spec = GetCurrentSpec()
    GRIP_EMS_CHAR.keybinds[spec] = GRIP_EMS_CHAR.keybinds[spec] or {}
    local specBinds = GRIP_EMS_CHAR.keybinds[spec]
    specBinds._byLoadout = specBinds._byLoadout or {}
    local srcBinds = specBinds._byLoadout[sourceLoadoutID]
    if not srcBinds then
        return
    end
    specBinds._byLoadout[targetLoadoutID] = specBinds._byLoadout[targetLoadoutID] or {}
    local tgtBinds = specBinds._byLoadout[targetLoadoutID]
    for key, seqName in pairs(srcBinds) do
        tgtBinds[key] = seqName
    end
    self:ScheduleLoadKeybinds()
    if GRIPEMS.Fire then
        GRIPEMS:Fire("KEYBIND_CHANGED")
    end
end
