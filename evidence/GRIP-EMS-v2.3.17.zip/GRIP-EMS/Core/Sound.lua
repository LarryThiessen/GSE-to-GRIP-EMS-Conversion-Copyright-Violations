-- GRIP-EMS: Sound cue module (LibSharedMedia-backed)
-- Created: 2026-04-23
-- Updated: 2026-06-21
-- Patch: 12.0.7.68256 Midnight (Retail LIVE)
--
-- Semantic audio cues for validation outcomes, imports, info toasts, and
-- sequence step advances. LSM dropdowns in Settings let the player swap
-- any registered sound into any cue slot. Disabled by default; all calls
-- are silent no-ops when disabled, LSM is missing, or SOUNDKIT is not
-- present. Per-cue rate limiter caps to 2 Hz so rapid step advances do
-- not spam.

local ADDON_NAME, GRIPEMS = ...
GRIPEMS.Sound = GRIPEMS.Sound or {}
local S = GRIPEMS.Sound

local CUE_SETTING = {
    error = "soundCueError",
    success = "soundCueSuccess",
    info = "soundCueInfo",
    stepComplete = "soundCueStepComplete",
}

-- Phase 4 item 22 Phase 2: per-cue Blizzard channel routing. Maps a cueKey
-- to the per-cue channel setting key on accessibility. Falls back to the
-- legacy global accessibility.soundCuesChannel and finally to "Master".
local CUE_CHANNEL = {
    error = "soundCueErrorChannel",
    success = "soundCueSuccessChannel",
    info = "soundCueInfoChannel",
    stepComplete = "soundCueStepCompleteChannel",
}

local CUE_DEFAULTS = {
    ["GRIPEMS Error"] = (SOUNDKIT and SOUNDKIT.GAME_ERROR_SOUND) or 847,
    ["GRIPEMS Success"] = (SOUNDKIT and SOUNDKIT.IG_QUEST_COMPLETE) or 878,
    ["GRIPEMS Info"] = (SOUNDKIT and SOUNDKIT.TUTORIAL_POPUP_SHOW) or 906,
    ["GRIPEMS Step Complete"] = (SOUNDKIT and SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON) or 856,
}

local MIN_GAP_MS = 500
S._lastPlayMs = {}

local function nowMs()
    return (GetTimePreciseSec and GetTimePreciseSec() * 1000) or (GetTime() * 1000)
end

local CUE_COLORS = {
    error = { 1.00, 0.27, 0.27, 0.85 },
    success = { 0.27, 0.85, 0.27, 0.85 },
    info = { 0.30, 0.65, 1.00, 0.85 },
    stepComplete = { 1.00, 0.84, 0.00, 0.85 },
}

local visualFrame

local function ensureVisualFrame()
    if visualFrame then
        return visualFrame
    end
    local f = CreateFrame("Frame", "GRIPEMS_SoundVisual", UIParent)
    f:SetFrameStrata("TOOLTIP")
    f:SetFrameLevel(100)
    f:EnableMouse(false)
    f:SetSize(80, 80)
    f:SetPoint("TOP", UIParent, "TOP", 0, -120)

    f.bg = f:CreateTexture(nil, "OVERLAY")
    f.bg:SetAllPoints(true)
    f.bg:SetColorTexture(1, 1, 1, 0)

    f:Hide()
    visualFrame = f
    return f
end

--- Fire the visual flash for a cue. Always called only after the
--- caller has confirmed the cue rate-limiter allowed this event.
--- Respects flickerSafe and reduceMotion alpha damping; never
--- skips the flash entirely (the user opted in by enabling the
--- soundCuesVisualComplement toggle).
--- @param cueKey string  one of the four CUE_SETTING keys
local function flashVisual(cueKey)
    local color = CUE_COLORS[cueKey]
    if not color then
        return
    end
    local a = GRIPEMS
        and GRIPEMS.Settings
        and GRIPEMS.Settings.db
        and GRIPEMS.Settings.db.profile
        and GRIPEMS.Settings.db.profile.accessibility
    if not a then
        return
    end

    local alpha = color[4]
    if a.flickerSafe then
        alpha = 0.3
    elseif a.reduceMotion then
        alpha = 0.6
    end

    local f = ensureVisualFrame()
    f.bg:SetColorTexture(color[1], color[2], color[3], alpha)
    f:Show()

    if C_Timer and C_Timer.After then
        C_Timer.After(0.6, function()
            if f and f:IsShown() then
                f:Hide()
            end
        end)
    end
end

--- Register the four fallback sounds under LSM so the dropdowns always
--- have a working default. Safe to call multiple times; LSM:Register is
--- idempotent on identical (category, name, data) tuples.
function S:RegisterFallbacks()
    local LSM = LibStub and LibStub("LibSharedMedia-3.0", true)
    if not LSM then
        return
    end
    for name, fileOrID in pairs(CUE_DEFAULTS) do
        pcall(LSM.Register, LSM, "sound", name, fileOrID)
    end
end

--- Play a cue by semantic key. No-op when neither soundCuesEnabled
--- nor soundCuesVisualComplement is on, when the same cue was played
--- within MIN_GAP_MS, or (for the sound path) when LSM isn't loaded.
--- The shared rate limiter ensures visual and sound stay synchronized.
--- @param cueKey string  one of "error" / "success" / "info" / "stepComplete"
--- @param opts table?  optional table; opts.forcePlay = true bypasses the rate limiter
function S:Play(cueKey, opts)
    local setting = CUE_SETTING[cueKey]
    if not setting then
        return
    end
    local a = GRIPEMS
        and GRIPEMS.Settings
        and GRIPEMS.Settings.db
        and GRIPEMS.Settings.db.profile
        and GRIPEMS.Settings.db.profile.accessibility
    if not a then
        return
    end

    -- Visual and sound are independent toggles. Bail only if neither
    -- is on -- a Deaf user can have sound off and visual on.
    if not a.soundCuesEnabled and not a.soundCuesVisualComplement then
        return
    end

    -- Rate limiter is shared: if the cue is rate-limited, BOTH outputs
    -- are suppressed so visual and sound stay synchronized.
    local now = nowMs()
    if not (opts and opts.forcePlay) then
        local last = self._lastPlayMs[cueKey]
        if last and (now - last) < MIN_GAP_MS then
            return
        end
    end
    self._lastPlayMs[cueKey] = now

    -- Visual complement (Deaf/HoH path)
    if a.soundCuesVisualComplement then
        flashVisual(cueKey)
    end

    -- Sound (existing path)
    if a.soundCuesEnabled then
        local LSM = LibStub and LibStub("LibSharedMedia-3.0", true)
        if not LSM then
            return
        end

        -- Phase 4 item 22 Phase 2: per-sequence LSM override.
        -- Active sequence comes from Engine._lastClickedSequence (the same
        -- convention TempoAdvisor / ExecutionTracer / TempoOverlay use). When
        -- the active sequence carries seqData.soundCues[cueKey], that LSM key
        -- wins. Empty string and nil both mean "fall through to global."
        local lsmName
        local eng = GRIPEMS and GRIPEMS.Engine
        local seqName = eng and eng._lastClickedSequence
        if
            seqName
            and eng.sequences
            and eng.sequences[seqName]
            and eng.sequences[seqName].data
            and eng.sequences[seqName].data.soundCues
        then
            local override = eng.sequences[seqName].data.soundCues[cueKey]
            if override and override ~= "" then
                lsmName = override
            end
        end
        if not lsmName or lsmName == "" then
            lsmName = a[setting]
        end
        if not lsmName or lsmName == "" then
            return
        end

        local sound = LSM:Fetch("sound", lsmName)
        if not sound then
            return
        end

        -- Per-cue channel with global fallback and "Master" backstop.
        local channelKey = CUE_CHANNEL[cueKey]
        local channel = (channelKey and a[channelKey]) or a.soundCuesChannel or "Master"

        if type(sound) == "number" then
            pcall(PlaySound, sound, channel)
        else
            pcall(PlaySoundFile, sound, channel)
        end
    end
end

--- Call once during addon init. Registers fallbacks; safe before
--- ADDON_LOADED finishes because LSM:Register tolerates early calls.
function S:Init()
    if self._initialized then
        return
    end
    self:RegisterFallbacks()
    self._initialized = true
end

-- end of Core/Sound.lua
