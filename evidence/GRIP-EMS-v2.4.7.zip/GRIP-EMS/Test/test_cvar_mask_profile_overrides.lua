-- GRIP-EMS: Headless test for mask-aware CVar profile overrides
--
-- Created:    2026-07-19
-- Updated:    2026-08-17
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
--
-- Standalone (Lua 5.1) test for the CvarProfileManager mask threading: profile
-- overrides may now carry INTEGER mask values (nameplateStackingTypes) that
-- must route through the Settings bitfield API (D.CvarApply /
-- D.CvarReadState), never plain GetCVar/SetCVar. Drives the REAL
-- Data/Defaults.lua + Data/CvarProfileManager.lua via loadfile + setfenv into
-- a sandbox that stubs Settings.GetCVarMask, CVarCallbackRegistry
-- (SetCVarBitfieldMask + GetCVarBitfieldDefault), GetCVar and SetCVar, the
-- same technique as test_spellcache_overrides.lua.
--
-- Run from the EMS root:  lua Test/test_cvar_mask_profile_overrides.lua
-- Exit code 0 = all passed, 1 = at least one failure.
--
-- Cases:
--   T1  D.CvarRecByName resolves the stacking rec case-insensitively and
--       returns nil for an unknown name
--   T2  applying the raid (mask 1) and pvp (mask 3) profile overrides routes
--       through the mask write stub and never the string SetCVar stub
--   T3  capture-then-revert round-trips the INTEGER mask through read + apply
--       (Undo and Redo both stay on the bitfield API)
--   T4  an integer override without a mask rec is skipped with a debug
--       warning; plain string overrides still route through SetCVar
--   T5  mask overrides normalize to INTEGERS at both ends: SetProfileOverride
--       stores the integer mask, GetEffectiveRecommendation returns it even
--       for a legacy stringified SavedVariables value
--   T6  a non-numeric mask override is skipped by ApplyProfile and never
--       reaches the raw string layer

local ADDON_NAME = "GRIP-EMS"

-- ---------------------------------------------------------------------------
-- Minimal assertion + runner harness (mirrors TestSuite Pass/Fail semantics).
-- ---------------------------------------------------------------------------

local tests = {}

local function test(name, fn)
    tests[#tests + 1] = { name = name, fn = fn }
end

local function assertEqual(expected, actual, label)
    if expected ~= actual then
        error((label or "value") .. ": expected " .. tostring(expected) .. ", got " .. tostring(actual), 2)
    end
end

local function assertTrue(cond, label)
    if not cond then
        error((label or "condition") .. ": expected true", 2)
    end
end

-- ---------------------------------------------------------------------------
-- Sandbox: a self-referential no-op stub backs every unknown global so the
-- real modules load without a WoW client. Real stdlib falls through to _G.
-- The CVar surface is stubbed explicitly below so routing is observable.
-- ---------------------------------------------------------------------------

local stub = {}
setmetatable(stub, {
    __index = function()
        return stub
    end,
    __call = function()
        return stub
    end,
})

local env = setmetatable({}, {
    __index = function(_, k)
        local v = rawget(_G, k)
        if v ~= nil then
            return v
        end
        return stub
    end,
})
env._G = env

-- AceLocale stand-in: every key echoes back so any L["KEY"] format is inert.
local LOCALE = setmetatable({}, {
    __index = function(_, k)
        return k
    end,
})
env.LibStub = function()
    return {
        GetLocale = function()
            return LOCALE
        end,
    }
end
env.strlower = string.lower

-- ---------------------------------------------------------------------------
-- Observable CVar surface: raw string layer (GetCVar/SetCVar) and mask layer
-- (Settings.GetCVarMask / CVarCallbackRegistry). Every write is recorded so
-- the tests can assert which layer a value routed through.
-- ---------------------------------------------------------------------------

local liveMasks = {}
local liveStrings = {}
local maskWrites = {}
local stringWrites = {}
local debugLog = {}

env.Enum = { NamePlateStackType = { None = 0, Enemy = 1, Friendly = 2 } }
env.Settings = {
    GetCVarMask = function(cvar)
        return liveMasks[cvar]
    end,
}
env.CVarCallbackRegistry = {
    SetCVarBitfieldMask = function(_, cvar, mask)
        maskWrites[#maskWrites + 1] = { cvar = cvar, mask = mask }
        liveMasks[cvar] = mask
    end,
    GetCVarBitfieldDefault = function(_, cvar)
        return liveMasks[cvar] ~= nil and 0 or nil
    end,
}
env.GetCVar = function(cvar)
    return liveStrings[cvar]
end
env.SetCVar = function(cvar, val)
    stringWrites[#stringWrites + 1] = { cvar = cvar, val = val }
    liveStrings[cvar] = val
end
env.GetCVarDefault = function()
    return nil
end
env.InCombatLockdown = function()
    return false
end

local svStore = {}
local GRIPEMS = {
    version = "headless",
    Print = function() end,
    Debug = function(_, fmt, ...)
        local ok, msg = pcall(string.format, tostring(fmt), ...)
        debugLog[#debugLog + 1] = ok and msg or tostring(fmt)
    end,
    Fire = function() end,
    Settings = {
        Get = function(_, key)
            return svStore[key]
        end,
        Set = function(_, key, value)
            svStore[key] = value
        end,
    },
}

-- ---------------------------------------------------------------------------
-- Load the REAL modules into the sandbox, in dependency order.
-- ---------------------------------------------------------------------------

local function loadModule(candidates)
    for _, path in ipairs(candidates) do
        -- loadfile is dev-harness file I/O, intentionally outside the addon WoW std.
        -- selene: allow(undefined_variable)
        local chunk = loadfile(path)
        if chunk then
            setfenv(chunk, env)
            chunk(ADDON_NAME, GRIPEMS)
            return true
        end
    end
    return false
end

assert(
    loadModule({
        "Data/Defaults.lua",
        "../Data/Defaults.lua",
        "GRIP/EMS/Data/Defaults.lua",
    }),
    "could not locate Data/Defaults.lua (run from the EMS root)"
)
assert(
    loadModule({
        "Data/CvarProfileManager.lua",
        "../Data/CvarProfileManager.lua",
        "GRIP/EMS/Data/CvarProfileManager.lua",
    }),
    "could not locate Data/CvarProfileManager.lua (run from the EMS root)"
)

local D = GRIPEMS.Defaults
local CPM = GRIPEMS.CvarProfileManager
assert(D and D.CvarRecByName, "D.CvarRecByName missing")
assert(CPM and CPM.ApplyProfile, "CPM:ApplyProfile missing")

local function wipeTable(t)
    for k in pairs(t) do
        t[k] = nil
    end
end

local function reset()
    wipeTable(svStore)
    wipeTable(liveMasks)
    wipeTable(liveStrings)
    wipeTable(maskWrites)
    wipeTable(stringWrites)
    wipeTable(debugLog)
    liveMasks.nameplateStackingTypes = 0
    liveStrings.nameplateMaxDistance = "60"
    liveStrings.nameplatePlayerMaxDistance = "60"
    liveStrings.nameplateShowFriendlyPlayers = "0"
    liveStrings.nameplateShowEnemyMinions = "0"
end

local function assertNoStringWriteFor(cvar, label)
    for _, w in ipairs(stringWrites) do
        assertTrue(w.cvar ~= cvar, (label or "no SetCVar for ") .. cvar)
    end
end

local function maskWritesFor(cvar)
    local out = {}
    for _, w in ipairs(maskWrites) do
        if w.cvar == cvar then
            out[#out + 1] = w.mask
        end
    end
    return out
end

-- ---------------------------------------------------------------------------
-- Cases.
-- ---------------------------------------------------------------------------

test("T1 CvarRecByName -- case-insensitive hit, nil miss", function()
    local rec = D.CvarRecByName("nameplateStackingTypes")
    assertTrue(rec ~= nil, "rec found")
    assertEqual("nameplateStackingTypes", rec.cvar, "rec.cvar")
    assertEqual(true, rec.isMask, "rec.isMask")
    assertEqual(1, rec.recommended, "recommended stays integer 1 (Enemy)")
    assertEqual(rec, D.CvarRecByName("NAMEPLATESTACKINGTYPES"), "upper-case lookup")
    assertEqual(rec, D.CvarRecByName("NamePlateStackingTypes"), "mixed-case lookup")
    assertEqual(nil, D.CvarRecByName("noSuchCvarAnywhere"), "unknown name")
    assertEqual(nil, D.CvarRecByName(nil), "nil name")
end)

test("T2 raid (1) and pvp (3) overrides route through the mask stub only", function()
    reset()
    CPM:ApplyProfile("raid")
    local masks = maskWritesFor("nameplateStackingTypes")
    assertEqual(1, #masks, "one mask write for raid")
    assertEqual(1, masks[1], "raid applies mask 1 (Enemy)")
    assertNoStringWriteFor("nameplateStackingTypes", "raid: mask cvar leaked into SetCVar for ")

    reset()
    CPM:ApplyProfile("pvp")
    masks = maskWritesFor("nameplateStackingTypes")
    assertEqual(1, #masks, "one mask write for pvp")
    assertEqual(3, masks[1], "pvp applies mask 3 (Enemy + Friendly)")
    assertNoStringWriteFor("nameplateStackingTypes", "pvp: mask cvar leaked into SetCVar for ")
    -- the scalar overrides in the same profile still use the string layer
    local sawScalar = false
    for _, w in ipairs(stringWrites) do
        if w.cvar == "nameplateShowFriendlyPlayers" and w.val == "1" then
            sawScalar = true
        end
    end
    assertTrue(sawScalar, "scalar profile override still routes through SetCVar")
end)

test("T3 capture-then-revert round-trips the integer mask", function()
    reset()
    CPM:CapturePrevious("nameplateStackingTypes")
    local prevVal = CPM:GetPrevious("nameplateStackingTypes")
    assertEqual("number", type(prevVal), "captured type")
    assertEqual(0, prevVal, "captured integer mask")

    liveMasks.nameplateStackingTypes = 1 -- simulate a later mask change
    assertEqual(true, CPM:UndoPrevious("nameplateStackingTypes"), "undo succeeds")
    local masks = maskWritesFor("nameplateStackingTypes")
    assertEqual(0, masks[#masks], "undo restored mask 0 via the bitfield API")
    assertEqual(0, liveMasks.nameplateStackingTypes, "live mask reverted")
    assertEqual(1, CPM:GetRedo("nameplateStackingTypes"), "redo cache holds the pre-undo integer")

    assertEqual(true, CPM:RedoPrevious("nameplateStackingTypes"), "redo succeeds")
    masks = maskWritesFor("nameplateStackingTypes")
    assertEqual(1, masks[#masks], "redo re-applied mask 1 via the bitfield API")
    assertEqual(0, CPM:GetPrevious("nameplateStackingTypes"), "prev cache holds the pre-redo integer")
    assertNoStringWriteFor("nameplateStackingTypes", "round-trip: mask cvar leaked into SetCVar for ")
end)

test("T4 integer-without-mask-rec guard skips + warns; strings still SetCVar", function()
    reset()
    -- seed a live value for the rec-less cvar so ONLY the guard (not the
    -- current == nil short-circuit) can be what blocks the write
    liveStrings.totallyUnknownCvar = "7"
    svStore.cvarProfiles = {
        custom_guardtest = {
            key = "custom_guardtest",
            label = "Guard Test",
            overrides = {
                ["nameplateMaxDistance"] = 41, -- integer on a NON-mask rec: must be skipped
                ["totallyUnknownCvar"] = 5, -- integer with NO rec at all: must be skipped
                ["nameplateShowEnemyMinions"] = "1", -- plain string: must reach SetCVar
            },
        },
    }
    CPM:ApplyProfile("custom_guardtest")
    assertNoStringWriteFor("nameplateMaxDistance", "integer override reached SetCVar for ")
    assertNoStringWriteFor("totallyUnknownCvar", "rec-less integer reached SetCVar for ")
    assertEqual(0, #maskWrites, "no mask writes for scalar-only profile")
    local warnedMax = false
    local warnedUnknown = false
    for _, msg in ipairs(debugLog) do
        if msg:find("skipped integer override", 1, true) then
            if msg:find("nameplateMaxDistance", 1, true) then
                warnedMax = true
            end
            if msg:find("totallyUnknownCvar", 1, true) then
                warnedUnknown = true
            end
        end
    end
    assertTrue(warnedMax, "guard warned for the non-mask rec integer")
    assertTrue(warnedUnknown, "guard warned for the rec-less integer")
    local sawScalar = false
    for _, w in ipairs(stringWrites) do
        if w.cvar == "nameplateShowEnemyMinions" and w.val == "1" then
            sawScalar = true
        end
    end
    assertTrue(sawScalar, "plain string override still routes through SetCVar")
end)

test("T5 mask overrides normalize to integers at both ends", function()
    reset()
    svStore.cvarProfiles = {
        custom_masknorm = {
            key = "custom_masknorm",
            label = "Mask Norm",
            -- legacy stringified SavedVariables value (pre-normalization)
            overrides = { ["nameplateStackingTypes"] = "3" },
        },
    }
    svStore.cvarActiveProfile = "custom_masknorm"
    local eff = CPM:GetEffectiveRecommendation("nameplateStackingTypes")
    assertEqual("number", type(eff), "effective type")
    assertEqual(3, eff, "effective value")
    -- new writes through SetProfileOverride store the INTEGER mask
    CPM:SetProfileOverride("custom_masknorm", "nameplateStackingTypes", "2")
    local stored = svStore.cvarProfiles.custom_masknorm.overrides["nameplateStackingTypes"]
    assertEqual("number", type(stored), "stored type")
    assertEqual(2, stored, "stored value")
    -- scalar overrides still stringify
    CPM:SetProfileOverride("custom_masknorm", "nameplateMaxDistance", 41)
    local scalar = svStore.cvarProfiles.custom_masknorm.overrides["nameplateMaxDistance"]
    assertEqual("string", type(scalar), "scalar stored type")
    assertEqual("41", scalar, "scalar stored value")
end)

test("T6 non-numeric mask override is skipped, never raw-written", function()
    reset()
    svStore.cvarProfiles = {
        custom_badmask = {
            key = "custom_badmask",
            label = "Bad Mask",
            overrides = { ["nameplateStackingTypes"] = "on" },
        },
    }
    CPM:ApplyProfile("custom_badmask")
    assertEqual(0, #maskWrites, "no mask write for a non-numeric override")
    assertNoStringWriteFor("nameplateStackingTypes", "non-numeric mask override leaked into SetCVar for ")
    local warned = false
    for _, msg in ipairs(debugLog) do
        if msg:find("skipped non-numeric override", 1, true) and msg:find("nameplateStackingTypes", 1, true) then
            warned = true
        end
    end
    assertTrue(warned, "skip warning emitted")
end)

-- ---------------------------------------------------------------------------
-- Run.
-- ---------------------------------------------------------------------------

local passed = 0
local failed = 0
for _, t in ipairs(tests) do
    local ok, err = pcall(t.fn)
    if ok then
        passed = passed + 1
        print("PASS  " .. t.name)
    else
        failed = failed + 1
        print("FAIL  " .. t.name .. " -- " .. tostring(err))
    end
end
print(string.format("RESULT %d passed, %d failed", passed, failed))
os.exit(failed > 0 and 1 or 0)
