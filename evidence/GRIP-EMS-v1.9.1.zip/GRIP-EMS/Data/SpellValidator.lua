-- GRIP-EMS: SpellValidator
-- Spell validation for import, editor, and batch contexts.
-- Detects stale, talent-gated, renamed, or removed spells in sequences.

local ADDON_NAME, GRIPEMS = ...
local function D()
    return GRIPEMS.Defaults
end
local function SC()
    return GRIPEMS.SpellCache
end
local function Engine()
    return GRIPEMS.Engine
end

GRIPEMS.SpellValidator = {}
local SV = GRIPEMS.SpellValidator

-- Known macro placeholders (no-op in /castsequence, always valid)
local MACRO_PLACEHOLDERS = { ["null"] = true }

---------------------------------------------------------------------------
-- Spell Extraction
---------------------------------------------------------------------------

-- Casting command patterns (case-insensitive via :lower())
local castPatterns = {
    { pattern = "^%s*/castsequence%s", cmd = "castsequence" },
    { pattern = "^%s*/castrandom%s", cmd = "castrandom" },
    { pattern = "^%s*/cast%s", cmd = "cast" },
    { pattern = "^%s*/use%s", cmd = "use" },
}

--- Clean a raw spell token: strip (Rank N), semicolons, whitespace.
--- @param token string Raw spell name token
--- @return string|nil Cleaned spell name or nil if empty
local function CleanSpellToken(token)
    if not token then
        return nil
    end
    token = token:gsub("%s*%(Rank%s+%d+%)%s*$", "")
    token = token:gsub(";+%s*$", "")
    token = token:gsub("^!", "")
    token = token:match("^%s*(.-)%s*$")
    if token == "" then
        return nil
    end
    return token
end

--- Extract ALL spell/item references from a macrotext string.
--- Unlike SC:ParseSpellFromMacrotext, this processes every line and every
--- spell in /castsequence comma lists.
--- @param macrotext string The macro text to parse
--- @return table Array of { name=string, command=string }
function SV:ExtractAllSpells(macrotext)
    local results = {}
    if not macrotext or macrotext == "" then
        return results
    end

    for line in macrotext:gmatch("[^\r\n]+") do
        local lineLower = line:lower()

        -- Tooltip extraction: #showtooltip / #show with spell args
        local skip = false
        local tooltipRest = nil
        local ttMatch = lineLower:match("^%s*#showtooltip%s+(.*)")
        if ttMatch then
            tooltipRest = line:match("^%s*#showtooltip%s+(.*)")
        else
            ttMatch = lineLower:match("^%s*#show%s+(.*)")
            if ttMatch then
                tooltipRest = line:match("^%s*#show%s+(.*)")
            end
        end
        if tooltipRest then
            tooltipRest = tooltipRest:gsub("%[.-%]", "")
            tooltipRest = tooltipRest:match("^%s*(.-)%s*$")
            if tooltipRest and tooltipRest ~= "" then
                for token in tooltipRest:gmatch("[^;]+") do
                    local spell = CleanSpellToken(token)
                    if spell then
                        if spell ~= "" then
                            results[#results + 1] = {
                                name = spell,
                                command = "showtooltip",
                            }
                        end
                    end
                end
            end
            skip = true
        end

        -- Check skip prefixes (lazy via D() to avoid load-time dependency)
        for _, pat in ipairs(D().SKIP_SPELL_PREFIXES) do
            if lineLower:match(pat) then
                skip = true
                break
            end
        end

        if not skip then
            -- Try each casting command pattern
            local matchedCmd = nil
            for _, entry in ipairs(castPatterns) do
                if lineLower:match(entry.pattern) then
                    matchedCmd = entry.cmd
                    break
                end
            end

            if matchedCmd then
                -- Strip the command prefix (use original case line)
                local rest = line:match("^%s*/[%a]+%s+(.*)")
                if rest then
                    -- Strip [conditionals] blocks
                    rest = rest:gsub("%[.-%]", "")
                    -- Strip reset=... clause (for /castsequence)
                    rest = rest:gsub("reset=%S+%s*", "")
                    -- Trim
                    rest = rest:match("^%s*(.-)%s*$")

                    if rest and rest ~= "" then
                        if matchedCmd == "castsequence" or matchedCmd == "castrandom" then
                            -- Extract ALL spells in comma-separated list
                            for token in rest:gmatch("[^,]+") do
                                local spell = CleanSpellToken(token)
                                if spell then
                                    results[#results + 1] = { name = spell, command = matchedCmd }
                                end
                            end
                        else
                            -- /cast, /use: split on semicolons (conditional fallthrough branches)
                            for branch in rest:gmatch("[^;]+") do
                                -- Take first token before comma within each branch
                                local spell = CleanSpellToken(branch:match("^([^,]+)"))
                                if spell then
                                    -- BUG-052: /use <number> is inventory slot, not spell
                                    if matchedCmd == "use" then
                                        local num = tonumber(spell)
                                        if num and tostring(num) == spell then
                                            spell = nil
                                        end
                                    end
                                    if spell then
                                        results[#results + 1] = { name = spell, command = matchedCmd }
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end

    return results
end

---------------------------------------------------------------------------
-- Single Spell Validation
---------------------------------------------------------------------------

--- Validate a single spell or item reference.
--- @param spellName string The spell/item name to validate
--- @param command string The macro command that referenced it (cast, use, etc.)
--- @return table { name=string, status=string, icon=number|nil }
function SV:ValidateSpell(spellName, command)
    local result = { name = spellName, status = D().SPELL_STATUS_UNKNOWN, icon = nil }

    -- Macro placeholders (e.g. "null" in /castsequence) are always valid
    if MACRO_PLACEHOLDERS[strlower(spellName)] then
        result.status = D().SPELL_STATUS_VALID
        return result
    end

    -- Fast path: in spellbook cache
    if SC().byName[strlower(spellName)] then
        result.status = D().SPELL_STATUS_VALID
        result.icon = SC():GetIcon(spellName)
        return result
    end

    -- API check: spell exists but not in spellbook (talent-gated, wrong spec)
    local exists = C_Spell.DoesSpellExist(spellName)
    if exists and not issecretvalue(exists) then
        result.status = D().SPELL_STATUS_KNOWN
        result.icon = SC():GetIcon(spellName)
        return result
    end

    -- /use can target items
    if command == "use" then
        local itemID, _, _, _, itemIcon = C_Item.GetItemInfoInstant(spellName)
        if itemID then
            result.status = D().SPELL_STATUS_ITEM
            result.icon = itemIcon or D().QUESTION_MARK_ICON
            return result
        end
        -- Some abilities use /use syntax -- already checked via DoesSpellExist above
    end

    -- Unknown: not a spell, not an item
    result.icon = D().QUESTION_MARK_ICON
    return result
end

---------------------------------------------------------------------------
-- Step Validation
---------------------------------------------------------------------------

--- Validate all spells in a single macro step.
--- @param macrotext string The step macro text
--- @return table { spells=array, hasVariable=bool }
function SV:ValidateStep(macrotext)
    local result = { spells = {}, tooltipSpells = {}, hasVariable = false }
    if not macrotext or macrotext == "" then
        return result
    end

    -- Check for variable references
    if macrotext:match(D().VAR_PATTERN) then
        result.hasVariable = true
        result.spells[#result.spells + 1] = {
            name = "(variable)",
            status = D().SPELL_STATUS_VARIABLE,
            icon = nil,
        }
    end

    local extracted = self:ExtractAllSpells(macrotext)
    for _, entry in ipairs(extracted) do
        local validated = self:ValidateSpell(entry.name, entry.command)
        if entry.command == "showtooltip" then
            if validated.status == D().SPELL_STATUS_UNKNOWN or validated.status == D().SPELL_STATUS_KNOWN then
                validated.status = D().SPELL_STATUS_TOOLTIP_STALE
            end
            result.tooltipSpells[#result.tooltipSpells + 1] = validated
        else
            result.spells[#result.spells + 1] = validated
        end
    end

    return result
end

---------------------------------------------------------------------------
-- Sequence Validation
---------------------------------------------------------------------------

local function AccumulateCounts(stepResult, result)
    for _, spell in ipairs(stepResult.spells) do
        if spell.status == D().SPELL_STATUS_UNKNOWN then
            result.unknownCount = result.unknownCount + 1
        elseif spell.status == D().SPELL_STATUS_KNOWN then
            result.knownCount = result.knownCount + 1
        end
    end
    for _, spell in ipairs(stepResult.tooltipSpells) do
        if spell.status == D().SPELL_STATUS_TOOLTIP_STALE then
            result.tooltipStaleCount = result.tooltipStaleCount + 1
        end
    end
end

--- Validate an entire sequence (active version).
--- @param seqData table Sequence data (versioned format)
--- @return table { steps=array, staleCount=number, unknownCount=number, knownCount=number }
function SV:ValidateSequence(seqData)
    local result = {
        steps = {},
        staleCount = 0,
        unknownCount = 0,
        knownCount = 0,
        tooltipStaleCount = 0,
    }

    local ver = Engine():GetActiveVersion(seqData)
    if not ver then
        GRIPEMS:Debug("SpellValidator: no active version for sequence -- skipping validation")
        return result
    end

    -- Validate main steps
    local steps = ver.steps or {}
    for i = 1, #steps do
        local resolved = Engine():SubstituteVariables(steps[i])
        local stepResult = self:ValidateStep(resolved)
        result.steps[#result.steps + 1] = stepResult
        AccumulateCounts(stepResult, result)
    end

    -- Validate keyPress if present
    local kp = ver.keyPress
    if kp and kp ~= "" then
        local resolved = Engine():SubstituteVariables(kp)
        local stepResult = self:ValidateStep(resolved)
        AccumulateCounts(stepResult, result)
    end

    -- Validate keyRelease if present
    local kr = ver.keyRelease
    if kr and kr ~= "" then
        local resolved = Engine():SubstituteVariables(kr)
        local stepResult = self:ValidateStep(resolved)
        AccumulateCounts(stepResult, result)
    end

    result.staleCount = result.unknownCount + result.knownCount
    return result
end

---------------------------------------------------------------------------
-- Batch Validation
---------------------------------------------------------------------------

--- Validate every sequence in Engine().sequences.
--- @return table { sequences = { [name] = ValidateSequence result } }
function SV:ValidateAll()
    local result = { sequences = {} }
    for name, entry in pairs(Engine().sequences) do
        if entry.data then
            result.sequences[name] = self:ValidateSequence(entry.data)
        end
    end
    return result
end

---------------------------------------------------------------------------
-- Event-Driven Revalidation
---------------------------------------------------------------------------

local revalTimer = nil

--- Debounced handler for spell cache refresh.
--- Waits SPELL_VALIDATE_DEBOUNCE seconds, then revalidates all sequences
--- and fires SPELL_VALIDATION_UPDATED so UI can refresh.
function SV:OnSpellCacheRefreshed()
    if revalTimer then
        revalTimer:Cancel()
        revalTimer = nil
    end
    revalTimer = C_Timer.NewTimer(D().SPELL_VALIDATE_DEBOUNCE, function()
        revalTimer = nil
        SV:ValidateAll()
        if GRIPEMS.Fire then
            GRIPEMS:Fire("SPELL_VALIDATION_UPDATED")
        end
    end)
end

--- Register for SPELL_CACHE_REFRESHED callback.
--- Must be called AFTER Core.lua ADDON_LOADED creates the CallbackHandler.
function SV:RegisterCallbacks()
    if GRIPEMS.RegisterCallback then
        GRIPEMS.RegisterCallback(SV, "SPELL_CACHE_REFRESHED", "OnSpellCacheRefreshed")
    end
end
