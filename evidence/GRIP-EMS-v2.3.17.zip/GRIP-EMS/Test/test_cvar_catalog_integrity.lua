-- GRIP-EMS: Headless test for D.CVAR_SECTIONS catalog integrity
--
-- Created:    2026-07-19
-- Updated:    2026-07-21
-- Patch: 12.0.7 Midnight (Retail LIVE)
--
-- Standalone (Lua 5.1) guard for the CVar recommendation catalog. Since
-- D.CvarRecByName resolves recs by name (case-insensitive, last-seen wins on
-- collision), a duplicate cvar entry silently shadows the earlier one and the
-- health dashboard double-counts the cvar. This test loads the REAL
-- Data/Defaults.lua via loadfile + setfenv (same technique as
-- test_cvar_mask_profile_overrides.lua) and fails on any duplicate.
--
-- Run from the EMS root:  lua Test/test_cvar_catalog_integrity.lua
-- Exit code 0 = all passed, 1 = at least one failure.
--
-- Cases:
--   T1  no case-insensitive duplicate cvar names across all sections
--       (caught the spellClutter Raiding/FPS duplication removed in v2.3.11)
--   T2  D.CvarRecByName resolves every catalog entry back to that exact rec
--   T3  every built-in profile override resolves to a registry rec, string
--       values differ from the General recommendation and are listed option
--       values, toggle-rec overrides are "0" or "1", integer values are
--       mask-threaded (rec.isMask)
--   T4  mask recs typed end to end: maskEnum string, integer
--       recommended listed among integer option values; scalar recs keep string options
--   T5  range recs typed end to end: min/max/step numbers, min < max, step > 0,
--       recommended numeric and within [min,max]; mutually exclusive with options/isMask
--   T6  toggle recs typed end to end: toggle == true, recommended "0" or "1" string,
--       mutually exclusive with options / range / isMask
--   T7  every non-isMask rec carries EXACTLY one shape (options / range / toggle);
--       zero-shape allowlist (KNOWN_NONE) is empty -- no shapeless rec today

local ADDON_NAME = "GRIP-EMS"

-- ---------------------------------------------------------------------------
-- Minimal assertion + runner harness (mirrors TestSuite Pass/Fail semantics).
-- ---------------------------------------------------------------------------

local tests = {}

local function test(name, fn)
    tests[#tests + 1] = { name = name, fn = fn }
end

local function assertTrue(cond, label)
    if not cond then
        error((label or "condition") .. ": expected true", 2)
    end
end

-- ---------------------------------------------------------------------------
-- Sandbox: a self-referential no-op stub backs every unknown global so the
-- real module loads without a WoW client. Real stdlib falls through to _G.
-- ---------------------------------------------------------------------------

local stub = {}
setmetatable(stub, {
    __index = function()
        return stub
    end,
    __call = function()
        return stub
    end,
})

local env = setmetatable({}, {
    __index = function(_, k)
        local v = rawget(_G, k)
        if v ~= nil then
            return v
        end
        return stub
    end,
})
env._G = env

-- AceLocale stand-in: every key echoes back so any L["KEY"] format is inert.
local LOCALE = setmetatable({}, {
    __index = function(_, k)
        return k
    end,
})
env.LibStub = function()
    return {
        GetLocale = function()
            return LOCALE
        end,
    }
end
env.strlower = string.lower

local GRIPEMS = {
    version = "headless",
    Print = function() end,
    Debug = function() end,
    Fire = function() end,
}

local function loadModule(candidates)
    for _, path in ipairs(candidates) do
        -- loadfile is dev-harness file I/O, intentionally outside the addon WoW std.
        -- selene: allow(undefined_variable)
        local chunk = loadfile(path)
        if chunk then
            setfenv(chunk, env)
            chunk(ADDON_NAME, GRIPEMS)
            return true
        end
    end
    return false
end

assert(
    loadModule({
        "Data/Defaults.lua",
        "../Data/Defaults.lua",
        "GRIP/EMS/Data/Defaults.lua",
    }),
    "could not locate Data/Defaults.lua (run from the EMS root)"
)

local D = GRIPEMS.Defaults
assert(D and D.CVAR_SECTIONS and D.CvarRecByName, "D.CVAR_SECTIONS / D.CvarRecByName missing")

-- ---------------------------------------------------------------------------
-- Cases.
-- ---------------------------------------------------------------------------

test("T1 no duplicate cvar names across sections (case-insensitive)", function()
    local seen = {}
    local dupes = {}
    for _, section in ipairs(D.CVAR_SECTIONS) do
        for _, rec in ipairs(section.cvars or {}) do
            if type(rec.cvar) == "string" then
                local key = string.lower(rec.cvar)
                if seen[key] then
                    dupes[#dupes + 1] = rec.cvar .. " (sections: " .. seen[key] .. " + " .. tostring(section.key) .. ")"
                else
                    seen[key] = tostring(section.key)
                end
            end
        end
    end
    assertTrue(#dupes == 0, "duplicate cvar entries: " .. table.concat(dupes, ", "))
end)

test("T2 CvarRecByName resolves every catalog entry to itself", function()
    local broken = {}
    for _, section in ipairs(D.CVAR_SECTIONS) do
        for _, rec in ipairs(section.cvars or {}) do
            if type(rec.cvar) == "string" and D.CvarRecByName(rec.cvar) ~= rec then
                broken[#broken + 1] = rec.cvar
            end
        end
    end
    assertTrue(#broken == 0, "by-name lookup shadowed for: " .. table.concat(broken, ", "))
end)

test("T3 built-in profile overrides resolve to registry recs", function()
    local problems = {}
    for _, profile in ipairs(D.CVAR_PROFILES) do
        for cvarName, value in pairs(profile.overrides or {}) do
            local where = tostring(profile.key) .. "/" .. tostring(cvarName)
            local rec = D.CvarRecByName(cvarName)
            if not rec then
                problems[#problems + 1] = where .. ": no registry rec"
            elseif type(value) == "string" then
                if value == rec.recommended then
                    problems[#problems + 1] = where .. ": override equals the General recommendation (dead weight)"
                end
                if type(rec.options) == "table" then
                    local listed = false
                    for _, opt in ipairs(rec.options) do
                        if opt.value == value then
                            listed = true
                        end
                    end
                    if not listed then
                        problems[#problems + 1] = where .. ": value " .. value .. " not among the rec's options"
                    end
                end
                if rec.toggle and value ~= "0" and value ~= "1" then
                    problems[#problems + 1] = where .. ": toggle override must be the string 0 or 1"
                end
            elseif type(value) == "number" then
                if not rec.isMask then
                    problems[#problems + 1] = where .. ": integer override on a non-mask rec"
                end
            end
        end
    end
    assertTrue(#problems == 0, "profile override problems: " .. table.concat(problems, ", "))
end)

test("T4 mask recs typed end to end (isMask contract)", function()
    local problems = {}
    for _, section in ipairs(D.CVAR_SECTIONS) do
        for _, rec in ipairs(section.cvars or {}) do
            local where = tostring(section.key) .. "/" .. tostring(rec.cvar)
            if rec.isMask then
                if type(rec.maskEnum) ~= "string" or rec.maskEnum == "" then
                    problems[#problems + 1] = where .. ": isMask without maskEnum string"
                end
                if type(rec.recommended) ~= "number" then
                    problems[#problems + 1] = where .. ": mask recommended must be an integer"
                end
                local recListed = false
                for _, opt in ipairs(rec.options or {}) do
                    if type(opt.value) ~= "number" then
                        problems[#problems + 1] = where
                            .. ": mask option value "
                            .. tostring(opt.value)
                            .. " is not a number"
                    elseif opt.value == rec.recommended then
                        recListed = true
                    end
                end
                if not recListed then
                    problems[#problems + 1] = where .. ": recommended mask not among option values"
                end
            elseif type(rec.options) == "table" then
                for _, opt in ipairs(rec.options) do
                    if type(opt.value) ~= "string" then
                        problems[#problems + 1] = where
                            .. ": scalar option value "
                            .. tostring(opt.value)
                            .. " is not a string"
                    end
                end
            end
        end
    end
    assertTrue(#problems == 0, "mask typing problems: " .. table.concat(problems, ", "))
end)

test("T5 range recs typed end to end (range contract)", function()
    local problems = {}
    for _, section in ipairs(D.CVAR_SECTIONS) do
        for _, rec in ipairs(section.cvars or {}) do
            local where = tostring(section.key) .. "/" .. tostring(rec.cvar)
            if type(rec.range) == "table" then
                if rec.options ~= nil then
                    problems[#problems + 1] = where .. ": has both range and options (shapes are mutually exclusive)"
                end
                if rec.isMask then
                    problems[#problems + 1] = where .. ": has both range and isMask (shapes are mutually exclusive)"
                end
                local mn, mx, st = rec.range.min, rec.range.max, rec.range.step
                if type(mn) ~= "number" or type(mx) ~= "number" or type(st) ~= "number" then
                    problems[#problems + 1] = where .. ": range min/max/step must all be numbers"
                elseif mn >= mx then
                    problems[#problems + 1] = where .. ": range min must be less than max"
                elseif st <= 0 then
                    problems[#problems + 1] = where .. ": range step must be greater than zero"
                end
                if rec.range.bigStep ~= nil and type(rec.range.bigStep) ~= "number" then
                    problems[#problems + 1] = where .. ": range bigStep must be a number when present"
                end
                if rec.recommended ~= nil then
                    local rn = tonumber(rec.recommended)
                    if rn == nil then
                        problems[#problems + 1] = where .. ": range recommended is not numeric"
                    elseif type(mn) == "number" and type(mx) == "number" and (rn < mn or rn > mx) then
                        problems[#problems + 1] = where .. ": recommended is outside the range bounds"
                    end
                end
            end
        end
    end
    assertTrue(#problems == 0, "range typing problems: " .. table.concat(problems, ", "))
end)

test("T6 toggle recs typed end to end (toggle contract)", function()
    local problems = {}
    for _, section in ipairs(D.CVAR_SECTIONS) do
        for _, rec in ipairs(section.cvars or {}) do
            local where = tostring(section.key) .. "/" .. tostring(rec.cvar)
            if rec.toggle ~= nil then
                if rec.toggle ~= true then
                    problems[#problems + 1] = where .. ": toggle must be boolean true"
                end
                if rec.options ~= nil then
                    problems[#problems + 1] = where .. ": has both toggle and options (mutually exclusive)"
                end
                if rec.range ~= nil then
                    problems[#problems + 1] = where .. ": has both toggle and range (mutually exclusive)"
                end
                if rec.isMask then
                    problems[#problems + 1] = where .. ": has both toggle and isMask (mutually exclusive)"
                end
                if rec.recommended ~= nil and rec.recommended ~= "0" and rec.recommended ~= "1" then
                    problems[#problems + 1] = where .. ": toggle recommended must be the string 0 or 1"
                end
            end
        end
    end
    assertTrue(#problems == 0, "toggle typing problems: " .. table.concat(problems, ", "))
end)

test("T7 shape exhaustiveness (every non-isMask rec has exactly one shape)", function()
    -- Non-isMask recs carry EXACTLY one of options / range / toggle. The
    -- zero-shape allowlist is empty: every non-mask rec today has a shape.
    -- A dropped bulk conversion (options removed, toggle = true not set)
    -- leaves a rec with zero shapes and trips this test.
    local KNOWN_NONE = {}
    local problems = {}
    for _, section in ipairs(D.CVAR_SECTIONS) do
        for _, rec in ipairs(section.cvars or {}) do
            local where = tostring(section.key) .. "/" .. tostring(rec.cvar)
            if not rec.isMask and not KNOWN_NONE[string.lower(tostring(rec.cvar))] then
                local shapes = 0
                if type(rec.options) == "table" then
                    shapes = shapes + 1
                end
                if type(rec.range) == "table" then
                    shapes = shapes + 1
                end
                if rec.toggle == true then
                    shapes = shapes + 1
                end
                if shapes ~= 1 then
                    problems[#problems + 1] = where .. ": expected one shape, got " .. tostring(shapes)
                end
            end
        end
    end
    assertTrue(#problems == 0, "shape exhaustiveness problems: " .. table.concat(problems, ", "))
end)

-- ---------------------------------------------------------------------------
-- Run.
-- ---------------------------------------------------------------------------

local passed = 0
local failed = 0
for _, t in ipairs(tests) do
    local ok, err = pcall(t.fn)
    if ok then
        passed = passed + 1
        print("PASS  " .. t.name)
    else
        failed = failed + 1
        print("FAIL  " .. t.name .. " -- " .. tostring(err))
    end
end
print(string.format("RESULT %d passed, %d failed", passed, failed))
os.exit(failed > 0 and 1 or 0)
