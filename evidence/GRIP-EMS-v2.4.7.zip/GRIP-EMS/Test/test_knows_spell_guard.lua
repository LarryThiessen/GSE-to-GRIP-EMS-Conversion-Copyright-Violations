-- GRIP-EMS: Headless test for the KnowsSpell namespace guard
--
-- Created:    2026-08-02
-- Updated:    2026-08-17
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
--
-- Guards BUG-KNOWSSPELL-GUARDS-NONEXISTENT-C-SPELL-ISSPELLKNOWN. GRIPEMS.KnowsSpell
-- opened with "if not (C_Spell and C_Spell.IsSpellKnown) then return false end" and
-- then pcall'd C_Spell.IsSpellKnown on both the number branch and the string branch.
-- C_Spell.IsSpellKnown does not exist on any flavour: the live API surface lists five
-- C_Spell.IsSpell* functions and IsSpellKnown is not among them, the wiki has no
-- API_C_Spell.IsSpellKnown page, and the name is absent from the live GlobalAPI dump.
-- The guard therefore tripped on every call and the helper answered false for every
-- input. The real function lives on a different namespace:
--
--     isKnown = C_SpellBook.IsSpellKnown(spellID [, spellBank])
--
-- spellBank is optional and defaults to Enum.SpellBookSpellBank.Player.
--
-- SCOPE. This is a LATENT defect, not a live one, and this file does not pretend
-- otherwise. KnowsSpell has no production caller today: MacroConditionalBaker rewrites
-- the variable's SOURCE TEXT to [known:X] at compile time and the GAME evaluates that
-- conditional, so the baked path never enters this function; and the runtime
-- fall-through path cannot reach it either, because the variable sandbox in
-- Data/VariableStore.lua exposes six helpers (HasBuff, HasDebuff, SpellReady,
-- SpellOnCooldown, SpellEnabled, IsRestricted) and KnowsSpell is not one of them. The
-- helper is wrong in shipped code and would silently answer false the moment anyone
-- exposed it. Wiring it into the sandbox is a separate product decision, out of scope
-- here, and deliberately not done.
--
-- WHY IsSpellKnown AND NOT IsSpellInSpellBook. Data/SpellValidator.lua reaches for
-- C_SpellBook.IsSpellInSpellBook in SV:_PlayerHasSpell, and copying that here would be
-- wrong: IsSpellInSpellBook reports true for spells the player has NOT learned, such as
-- override spells granted by an aura, while the game's own [known:] conditional is
-- documented against IsPlayerSpell semantics. Using it would ship a bake-versus-runtime
-- divergence -- the baked [known:] and the runtime helper would disagree on exactly the
-- aura-override spells this addon deals with constantly. C9 below pins the argument
-- count for the same reason: [known:] is evaluated against the player only, so the
-- default Player bank is the match and a Pet-bank fallback must not land silently.
--
-- Loads the REAL module (Engine/Conditions.lua) via loadfile + setfenv, the same
-- technique as test_step_reset_notifies_ui.lua. Conditions.lua is a pure-function file
-- -- module scope is "local ADDON_NAME, GRIPEMS = ...", one numeric constant, and
-- function definitions -- so there is no frame to create and no event to register.
--
-- Run from the EMS root:  lua Test/test_knows_spell_guard.lua
-- Exit code 0 = all passed, 1 = at least one failure.
--
-- Cases:
--   C1   numeric id, API true  -> true, and the API was really consulted
--   C2   numeric id, API false -> false, and the false came FROM the API
--   C3   string input -> SpellCache resolves it and the RESOLVED id reaches the API
--   C4   string input SpellCache cannot resolve -> false, API never called
--   C5   GRIPEMS.SpellCache absent + string input -> false, no error
--   C6   API raises -> pcall absorbs it, false, nothing propagates
--   C7   nil / boolean / table input -> false for each, API never called
--   C8   DIRECTION FENCE: no C_SpellBook, phantom C_Spell.IsSpellKnown returning true
--        -> must still be FALSE
--   C9   ARGUMENT FENCE: the API is called with exactly ONE argument, both branches
--   C10  the return is a real boolean on the true path, the false path, and when the
--        API hands back a truthy non-boolean
--
-- HARNESS DIVERGENCE FROM THE MODEL FILE, AND WHY IT IS REQUIRED.
--   test_step_reset_notifies_ui.lua backs every unknown global with a self-referential
--   no-op stub that is TRUTHY and CALLABLE. That sandbox cannot express this test at
--   all: C_SpellBook would resolve to the stub, C_SpellBook.IsSpellKnown would resolve
--   to the stub, pcall would return (true, stub), and KnowsSpell would answer true for
--   every input in every case -- including C8, whose whole job is to observe the
--   ABSENCE of a namespace. So this file uses a strict sandbox instead: unknown globals
--   are nil, real stdlib falls through to _G, and C_Spell / C_SpellBook are rawset per
--   case. That is safe here only because Conditions.lua touches no API at module scope;
--   do not copy this sandbox into a test for a file that does.
--
-- STUB AUDIT.
--   env.C_SpellBook   a table carrying ONE field, IsSpellKnown, pointing at a recording
--                     function. Set per case, absent by default. The recorder captures
--                     select("#", ...) at the call boundary, not just the first value,
--                     because C9 asserts on the argument COUNT -- a spellBank argument
--                     appearing later would show up there as argc 2 and nowhere else.
--                     LIVE: the real C_SpellBook, whose IsSpellKnown(spellID, spellBank)
--                     returns a boolean. MATCHES in the shape used.
--   env.C_Spell       ABSENT in every case except C8, where it is present and carries a
--                     fake IsSpellKnown returning true. This is the reverted-namespace
--                     trap, not a convenience stub: it exists so that a build reading
--                     C_Spell scores a visible true and fails C8.
--                     LIVE: the real C_Spell, which has NO IsSpellKnown field at all --
--                     so the C8 fixture is deliberately MORE permissive than the client.
--   GRIPEMS.SpellCache
--                     a table with GetSpellID(self, name) doing a plain map lookup and
--                     recording the name. Absent in C5. LIVE: Data/SpellCache.lua, whose
--                     GetSpellID walks the built name cache and returns a spell ID or
--                     nil. MATCHES in call shape (colon call, returns id or nil); the
--                     cache build, override resolution and pet bank are all irrelevant
--                     here -- KnowsSpell only consumes the id-or-nil return.
--   No Sound, Popup, OOCQueue, Engine or frame stubs are present, and none are needed:
--   Conditions.lua defines pure functions on the GRIPEMS table and reaches for nothing
--   else at load. A stub that is not required is a stub that can hide a regression.

local ADDON_NAME = "GRIP-EMS"

-- ---------------------------------------------------------------------------
-- Minimal assertion + runner harness.
-- ---------------------------------------------------------------------------

local tests = {}

local function test(name, fn)
    tests[#tests + 1] = { name = name, fn = fn }
end

local function assertEqual(expected, actual, label)
    if expected ~= actual then
        error((label or "value") .. ": expected " .. tostring(expected) .. ", got " .. tostring(actual), 2)
    end
end

local function assertTrue(cond, label)
    if not cond then
        error((label or "condition") .. " failed", 2)
    end
end

-- ---------------------------------------------------------------------------
-- Strict sandbox. Unknown globals are nil, NOT a truthy stub -- see the HARNESS
-- DIVERGENCE note above. Real stdlib falls through to _G.
-- ---------------------------------------------------------------------------

local env = setmetatable({}, {
    __index = function(_, k)
        return rawget(_G, k)
    end,
})
env._G = env

-- ---------------------------------------------------------------------------
-- GRIPEMS control table. Conditions.lua only writes helper functions onto it.
-- ---------------------------------------------------------------------------

local GRIPEMS = {
    version = "headless",
    Print = function() end,
    Debug = function() end,
}

-- ---------------------------------------------------------------------------
-- Load the REAL module into the sandbox.
-- ---------------------------------------------------------------------------

local function loadModule(candidates)
    for _, path in ipairs(candidates) do
        -- loadfile is dev-harness file I/O, intentionally outside the addon WoW std.
        -- selene: allow(undefined_variable)
        local chunk = loadfile(path)
        if chunk then
            setfenv(chunk, env)
            chunk(ADDON_NAME, GRIPEMS)
            return true
        end
    end
    return false
end

assert(
    loadModule({
        "Engine/Conditions.lua",
        "../Engine/Conditions.lua",
        "GRIP/EMS/Engine/Conditions.lua",
    }),
    "could not locate Engine/Conditions.lua (run from the EMS root)"
)

assert(type(GRIPEMS.KnowsSpell) == "function", "KnowsSpell defined")

-- ---------------------------------------------------------------------------
-- Fixtures.
-- ---------------------------------------------------------------------------

-- Every call into the stubbed API lands here as { argc = n, first = firstArg }.
local calls = {}

-- Every SpellCache:GetSpellID call lands here as the name string it was handed.
local resolveCalls = {}

-- Records the FULL argument shape, not just the first value. C9 asserts on argc,
-- and a spellBank argument sneaking in later is visible nowhere else.
local function recordingKnown(returnValue, shouldRaise)
    return function(...)
        local argc = select("#", ...)
        local first
        if argc >= 1 then
            first = (select(1, ...))
        end
        calls[#calls + 1] = { argc = argc, first = first }
        if shouldRaise then
            error("simulated C_SpellBook.IsSpellKnown failure", 0)
        end
        return returnValue
    end
end

local function setSpellBook(fn)
    if fn then
        rawset(env, "C_SpellBook", { IsSpellKnown = fn })
    else
        rawset(env, "C_SpellBook", nil)
    end
end

local function setSpell(fn)
    if fn then
        rawset(env, "C_Spell", { IsSpellKnown = fn })
    else
        rawset(env, "C_Spell", nil)
    end
end

local function setSpellCache(map)
    if not map then
        GRIPEMS.SpellCache = nil
        return
    end
    GRIPEMS.SpellCache = {
        GetSpellID = function(_, name)
            resolveCalls[#resolveCalls + 1] = name
            return map[name]
        end,
    }
end

-- Baseline for every case: no namespaces, no cache, no recorded calls. Each case
-- then declares exactly the surface it needs, so nothing leaks across rows.
local function prepare()
    for i = #calls, 1, -1 do
        calls[i] = nil
    end
    for i = #resolveCalls, 1, -1 do
        resolveCalls[i] = nil
    end
    setSpellBook(nil)
    setSpell(nil)
    setSpellCache(nil)
end

-- ---------------------------------------------------------------------------
-- Cases.
-- ---------------------------------------------------------------------------

test("C1: numeric id with C_SpellBook.IsSpellKnown true reports true", function()
    prepare()
    setSpellBook(recordingKnown(true))
    local result = GRIPEMS.KnowsSpell(1122)
    assertEqual(true, result, "a known numeric spellID reports true")
    assertEqual(1, #calls, "and C_SpellBook.IsSpellKnown was actually consulted")
    assertEqual(1122, calls[1].first, "with the id it was handed, unchanged")
end)

test("C2: numeric id with C_SpellBook.IsSpellKnown false reports false", function()
    prepare()
    setSpellBook(recordingKnown(false))
    local result = GRIPEMS.KnowsSpell(2050)
    assertEqual(false, result, "an unknown numeric spellID reports false")
    -- Without the next line this row is equally satisfied by an always-false build,
    -- including the pre-fix one whose namespace guard never let the call through.
    assertEqual(1, #calls, "the false came FROM the API, not from a tripped guard")
    assertEqual(2050, calls[1].first, "and the id reached it unchanged")
end)

test("C3: string input resolves through SpellCache and forwards the RESOLVED id", function()
    prepare()
    setSpellBook(recordingKnown(true))
    setSpellCache({ ["Flash Heal"] = 2061 })
    local result = GRIPEMS.KnowsSpell("Flash Heal")
    assertEqual(true, result, "a resolvable spell name reports true")
    assertEqual(1, #resolveCalls, "SpellCache:GetSpellID was consulted exactly once")
    assertEqual("Flash Heal", resolveCalls[1], "with the name as written")
    assertEqual(1, #calls, "and the API was consulted exactly once")
    assertEqual(2061, calls[1].first, "with the RESOLVED id, never the name string")
end)

test("C4: string input SpellCache cannot resolve reports false and never calls the API", function()
    prepare()
    setSpellBook(recordingKnown(true))
    setSpellCache({})
    local result = GRIPEMS.KnowsSpell("Not A Real Spell")
    assertEqual(false, result, "an unresolvable name reports false")
    assertEqual(1, #resolveCalls, "the cache really was asked (non-vacuity)")
    assertEqual(0, #calls, "and nothing was forwarded to the API")
end)

test("C5: string input with GRIPEMS.SpellCache absent reports false without erroring", function()
    prepare()
    setSpellBook(recordingKnown(true))
    -- prepare() already cleared it; restated so a later prepare() change cannot
    -- silently turn this row into a test of something else.
    GRIPEMS.SpellCache = nil
    local ok, result = pcall(GRIPEMS.KnowsSpell, "Flash Heal")
    assertTrue(ok, "no error escaped KnowsSpell: " .. tostring(result))
    assertEqual(false, result, "a missing SpellCache reports false")
    assertEqual(0, #calls, "and nothing reached the API")
end)

test("C6: an API that raises is absorbed by pcall and reports false", function()
    prepare()
    setSpellBook(recordingKnown(nil, true))
    local ok, result = pcall(GRIPEMS.KnowsSpell, 8936)
    assertTrue(ok, "the error did not propagate out of KnowsSpell: " .. tostring(result))
    assertEqual(false, result, "a raising API reports false")
    assertEqual(1, #calls, "and the raise really happened inside the helper (non-vacuity)")
end)

test("C7: nil, boolean and table input each report false", function()
    prepare()
    setSpellBook(recordingKnown(true))
    assertEqual(false, GRIPEMS.KnowsSpell(nil), "nil input reports false")
    assertEqual(false, GRIPEMS.KnowsSpell(true), "boolean input reports false")
    assertEqual(false, GRIPEMS.KnowsSpell({}), "table input reports false")
    assertEqual(0, #calls, "and none of the three reached the API")
end)

test("C8 (direction fence): no C_SpellBook plus a phantom C_Spell.IsSpellKnown reports false", function()
    prepare()
    -- C_Spell.IsSpellKnown does not exist on any flavour. This fixture is more
    -- permissive than the real client on purpose: it hands a reverted build a
    -- working function to find, so reverting the namespace turns this row red.
    setSpellBook(nil)
    setSpell(recordingKnown(true))
    local result = GRIPEMS.KnowsSpell(1122)
    assertEqual(false, result, "with no C_SpellBook the helper reports false")
    assertEqual(0, #calls, "and never consults the phantom C_Spell.IsSpellKnown")
    assertEqual("boolean", type(result), "the guard path still returns a clean boolean")
end)

test("C9 (argument fence): the API is called with exactly one argument on both branches", function()
    prepare()
    setSpellBook(recordingKnown(true))
    GRIPEMS.KnowsSpell(1122)
    setSpellCache({ ["Flash Heal"] = 2061 })
    GRIPEMS.KnowsSpell("Flash Heal")
    assertEqual(2, #calls, "both the number branch and the string branch called through")
    -- [known:] is evaluated against the player only, so the default Player bank is
    -- the match for the bake. A Pet-bank fallback would arrive here as argc 2.
    assertEqual(1, calls[1].argc, "number branch passes the id and nothing else")
    assertEqual(1, calls[2].argc, "string branch passes the resolved id and nothing else")
end)

test("C10: the return is a real boolean on the true, false and truthy-non-boolean paths", function()
    prepare()
    setSpellBook(recordingKnown(true))
    local yes = GRIPEMS.KnowsSpell(1122)
    assertEqual("boolean", type(yes), "the true path returns a boolean")
    assertEqual(true, yes, "and it is true")

    prepare()
    setSpellBook(recordingKnown(false))
    local no = GRIPEMS.KnowsSpell(1122)
    assertEqual("boolean", type(no), "the false path returns a boolean, never nil")
    assertEqual(false, no, "and it is false")

    -- An API handing back a truthy non-boolean must be coerced, not passed through:
    -- user variable expressions compare these values directly.
    prepare()
    setSpellBook(recordingKnown({}))
    local coerced = GRIPEMS.KnowsSpell(1122)
    assertEqual("boolean", type(coerced), "a truthy non-boolean API return is coerced")
    assertEqual(true, coerced, "to literal true")
end)

-- ---------------------------------------------------------------------------
-- Run.
-- ---------------------------------------------------------------------------

local passed = 0
local failed = 0
for _, t in ipairs(tests) do
    local ok, err = pcall(t.fn)
    if ok then
        passed = passed + 1
        print("PASS  " .. t.name)
    else
        failed = failed + 1
        print("FAIL  " .. t.name .. " -- " .. tostring(err))
    end
end
print(string.format("RESULT %d passed, %d failed", passed, failed))
os.exit(failed > 0 and 1 or 0)
