-- GRIP-EMS: Test spec for the empower Repair diagnostics (RA:CheckEmpower)
--
-- Created:    2026-08-12
-- Updated:    2026-08-17
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
--
-- Registers tests in TestSuite under category "empower_repair" covering the
-- Data/RepairAnalyzer.lua RA:CheckEmpower check:
--   warning  -- a channeling conditional together with an empowered spell
--   quiet    -- conditional alone, and empowered spell alone, both silent
--   keyPress -- the conditional living in keyPress rather than in a step
--   info     -- the empowerTapControls sighting, once per sequence
--
-- WHY THE keyPress CASE IS THE ONE THAT MUST EXIST. It is not testing that new
-- sequences carry the conditional: the editor's New button does NOT copy the
-- D.NewVersion.keyPress template (UI/SequenceList.lua copies stepFunction, steps
-- and the five reset fields only, so keyPress is left nil and the field renders
-- empty -- confirmed in game on build 12.1.0.69273). It is testing that the
-- check reads keyPress AT ALL rather than only the steps array. A check that
-- walked steps alone would pass every other case here and still miss the entire
-- keyPress surface, which is exactly where Data/RepairAnalyzer.lua's own auto-fix
-- for "No versions table or empty" stamps D.NewVersion.keyPress.
--
-- Dual-mode: in-game it loads as a normal *_spec.lua via /gems test. Run directly
-- under plain Lua 5.1 (lua Test/empower_repair_spec.lua, from the EMS repo root)
-- it loads the REAL Data/RepairAnalyzer.lua into a stub sandbox with fake
-- SpellValidator / SpellCache / Engine dependencies and runs its own cases.
-- Exit code 0 = all passed, 1 = at least one failure.

local ADDON_NAME, GRIPEMS = ...

local standalone = false
if not GRIPEMS then
    standalone = true
end

-- ---------------------------------------------------------------------------
-- Fixtures shared by both modes.
-- ---------------------------------------------------------------------------

local EMPOWER_NAME = "Fire Breath"
local EMPOWER_ID = 357208
local PLAIN_NAME = "Living Flame"
local PLAIN_ID = 361469

local TITLE_WARN = "Channel conditional misses empower hold"
local TITLE_INFO = "Empower tap controls active"
local TITLE_INFO_RELEASE = "Empower release available"

local function CountTitle(issues, title)
    local n = 0
    for _, iss in ipairs(issues or {}) do
        if iss.title == title then
            n = n + 1
        end
    end
    return n
end

local function FirstDetail(issues, title)
    for _, iss in ipairs(issues or {}) do
        if iss.title == title then
            return iss.detail
        end
    end
    return nil
end

-- ---------------------------------------------------------------------------
-- Standalone bootstrap: load the REAL RepairAnalyzer into a stub sandbox.
-- ---------------------------------------------------------------------------

local RA, setTapCVar

if standalone then
    local stub = {}
    setmetatable(stub, {
        __index = function()
            return stub
        end,
        __call = function()
            return stub
        end,
    })

    local tapValue = "0"
    setTapCVar = function(v)
        tapValue = v
    end

    local env = setmetatable({}, {
        __index = function(_, k)
            local v = rawget(_G, k)
            if v ~= nil then
                return v
            end
            return stub
        end,
    })
    env._G = env
    env.wipe = function(t)
        for k in pairs(t) do
            t[k] = nil
        end
        return t
    end
    env.GetCVar = function()
        return tapValue
    end

    GRIPEMS = {
        Print = function() end,
        Debug = function() end,
    }

    -- Defaults: only what CheckEmpower and the module preamble actually touch.
    -- CvarRecByName returns nil so the read falls through to GetCVar, which is
    -- the same fallback branch Data/CvarProfileManager.lua's ReadOverrideCvar has.
    GRIPEMS.Defaults = {
        CvarRecByName = function()
            return nil
        end,
        CvarReadState = function()
            return tapValue
        end,
        CONTEXT_KEYS = {},
        SPELL_STATUS_UNKNOWN = "unknown",
        SPELL_STATUS_KNOWN = "known",
        SPELL_STATUS_TOOLTIP_STALE = "stale",
    }

    local path
    for _, p in ipairs({
        "Data/RepairAnalyzer.lua",
        "../Data/RepairAnalyzer.lua",
        "GRIP/EMS/Data/RepairAnalyzer.lua",
    }) do
        local f = io.open(p, "r")
        if f then
            f:close()
            path = p
            break
        end
    end
    assert(path, "could not locate Data/RepairAnalyzer.lua (run from the EMS root)")

    -- loadfile is dev-harness file I/O, intentionally outside the addon WoW std.
    -- selene: allow(undefined_variable)
    local chunk = assert(loadfile(path))
    setfenv(chunk, env)
    chunk(ADDON_NAME or "GRIP-EMS", GRIPEMS)

    RA = GRIPEMS.RepairAnalyzer
    assert(RA, "RepairAnalyzer loaded")

    -- Fake dependencies. ResolveDeps reads these off GRIPEMS, so they must exist
    -- before the warm call below.
    GRIPEMS.SpellValidator = {
        -- Minimal stand-in: pull the argument of every /cast or /use line.
        ExtractAllSpells = function(_, text)
            local out = {}
            if type(text) ~= "string" then
                return out
            end
            for line in text:gmatch("[^\r\n]+") do
                local rest = line:match("^%s*/cast%s+(.+)$") or line:match("^%s*/use%s+(.+)$")
                if rest then
                    rest = rest:gsub("%[.-%]", ""):gsub("^%s+", ""):gsub("%s+$", "")
                    if rest ~= "" then
                        out[#out + 1] = { name = rest, command = "cast" }
                    end
                end
            end
            return out
        end,
        ValidateStep = function()
            return { spells = {}, tooltipSpells = {} }
        end,
    }

    local empowerSet = { [EMPOWER_ID] = true }
    GRIPEMS.SpellCache = {
        ready = true,
        empowerIDs = empowerSet,
        hasEmpower = true,
        GetSpellID = function(_, name)
            if name == EMPOWER_NAME then
                return EMPOWER_ID
            elseif name == PLAIN_NAME then
                return PLAIN_ID
            end
            return nil
        end,
        IsEmpowerSpell = function(_, id)
            return id ~= nil and empowerSet[id] == true
        end,
        HasEmpowerSpells = function()
            return true
        end,
        PrefixSearch = function()
            return {}
        end,
    }

    GRIPEMS.Engine = {
        GetActiveVersion = function(_, seqData)
            return seqData and seqData.versions and seqData.versions[1]
        end,
    }

    -- Warm the module-local dependency upvalues. ResolveDeps is a file-local and
    -- is only reached through RA:Analyze, so drive it once with the mildest
    -- possible input. The result is discarded; only the side effect matters.
    pcall(RA.Analyze, RA, { versions = {} }, "warm", {})
end

-- ---------------------------------------------------------------------------
-- Cases. Each returns nil on success or a failure string, so the same bodies
-- serve the standalone runner and the in-game TestSuite registration.
-- ---------------------------------------------------------------------------

local function seq(ver)
    return { versions = { ver } }
end

local cases = {}
local function case(name, fn)
    cases[#cases + 1] = { name = name, fn = fn }
end

-- (iv) FIRST, because it is the one that must exist. See the header note.
case("keyPress carrying the conditional is read, and labelled as keyPress", function()
    local issues = {}
    RA:CheckEmpower(
        seq({
            keyPress = "/stopmacro [channeling]",
            steps = { "/cast " .. EMPOWER_NAME },
        }),
        issues,
        {}
    )
    local n = CountTitle(issues, TITLE_WARN)
    if n < 1 then
        return "expected a warning, got none (the check may be walking steps only)"
    end
    -- The conditional lives in keyPress and the empowered spell in the step, so
    -- BOTH surfaces must have been walked for this to fire at all.
    local detail = FirstDetail(issues, TITLE_WARN) or ""
    if not detail:find("keyPress", 1, true) and not detail:find("step", 1, true) then
        return "warning detail named neither surface: " .. detail
    end
    return nil
end)

-- (iv-b) The conditional and the spell in the SAME keyPress text, so the label
-- must be the keyPress label and not a step label.
case("conditional and empower in the same keyPress: labelled V1 keyPress", function()
    local issues = {}
    RA:CheckEmpower(
        seq({
            keyPress = "/cast [channeling] " .. EMPOWER_NAME,
            steps = {},
        }),
        issues,
        {}
    )
    if CountTitle(issues, TITLE_WARN) ~= 1 then
        return "expected exactly one warning, got " .. CountTitle(issues, TITLE_WARN)
    end
    local detail = FirstDetail(issues, TITLE_WARN) or ""
    if not detail:find("keyPress", 1, true) then
        return "expected the keyPress label, got: " .. detail
    end
    return nil
end)

-- (i)
case("channeling conditional plus an empowered spell fires the warning", function()
    local issues = {}
    RA:CheckEmpower(seq({ steps = { "/cast [channeling] " .. EMPOWER_NAME } }), issues, {})
    if CountTitle(issues, TITLE_WARN) ~= 1 then
        return "expected exactly one warning, got " .. CountTitle(issues, TITLE_WARN)
    end
    local detail = FirstDetail(issues, TITLE_WARN) or ""
    if not detail:find(EMPOWER_NAME, 1, true) then
        return "detail did not name the spell: " .. detail
    end
    return nil
end)

-- (i-b) The negated form counts too, and must not double-count.
case("nochanneling conditional fires exactly once, not twice", function()
    local issues = {}
    RA:CheckEmpower(seq({ steps = { "/cast [nochanneling] " .. EMPOWER_NAME } }), issues, {})
    if CountTitle(issues, TITLE_WARN) ~= 1 then
        return "expected exactly one warning, got " .. CountTitle(issues, TITLE_WARN)
    end
    return nil
end)

-- (ii)
case("conditional with NO empowered spell fires nothing", function()
    local issues = {}
    RA:CheckEmpower(seq({ steps = { "/cast [channeling] " .. PLAIN_NAME } }), issues, {})
    if CountTitle(issues, TITLE_WARN) ~= 0 then
        return "expected no warning, got " .. CountTitle(issues, TITLE_WARN)
    end
    return nil
end)

-- (iii)
case("empowered spell with NO conditional fires nothing", function()
    local issues = {}
    RA:CheckEmpower(seq({ steps = { "/cast " .. EMPOWER_NAME } }), issues, {})
    if CountTitle(issues, TITLE_WARN) ~= 0 then
        return "expected no warning, got " .. CountTitle(issues, TITLE_WARN)
    end
    return nil
end)

-- The conditional must be matched inside brackets only. A step that merely
-- contains the word must not trip the check.
case("the bare word channeling outside brackets does not fire", function()
    local issues = {}
    RA:CheckEmpower(seq({ steps = { "/cast " .. EMPOWER_NAME .. " channeling" } }), issues, {})
    if CountTitle(issues, TITLE_WARN) ~= 0 then
        return "expected no warning, got " .. CountTitle(issues, TITLE_WARN)
    end
    return nil
end)

-- Neither issue may carry a fix. The conditional cannot be corrected by editing
-- its text, and the CVar is the user's accessibility setting.
case("neither issue is fixable and neither carries a fixFn", function()
    local issues = {}
    RA:CheckEmpower(seq({ steps = { "/cast [channeling] " .. EMPOWER_NAME } }), issues, {})
    for _, iss in ipairs(issues) do
        if iss.fixable then
            return iss.title .. " is marked fixable"
        end
        if iss.fixFn ~= nil then
            return iss.title .. " carries a fixFn"
        end
    end
    return nil
end)

-- The release row. MEASURED 2026-08-13: the hold-at-max window is a flat 1000 ms
-- that does not scale with haste, so a version sitting on hold-only pays it on
-- every empower. The row is informational and per VERSION, and it is gated on an
-- empower actually being SEEN in that version, not merely on the setting.
case("hold on and release off with an empowered spell: the info row fires", function()
    local issues = {}
    RA:CheckEmpower(seq({ holdOnChannel = true, steps = { "/cast " .. EMPOWER_NAME } }), issues, {})
    local n = CountTitle(issues, TITLE_INFO_RELEASE)
    if n ~= 1 then
        return "expected exactly one release info issue, got " .. n
    end
    return nil
end)

case("hold on and release ALREADY on: no info row", function()
    local issues = {}
    RA:CheckEmpower(
        seq({ holdOnChannel = true, releaseAtMax = true, steps = { "/cast " .. EMPOWER_NAME } }),
        issues,
        {}
    )
    if CountTitle(issues, TITLE_INFO_RELEASE) ~= 0 then
        return "expected no release info issue once the release is already on"
    end
    return nil
end)

case("hold OFF: no info row, because there is nothing to add to", function()
    local issues = {}
    RA:CheckEmpower(seq({ steps = { "/cast " .. EMPOWER_NAME } }), issues, {})
    if CountTitle(issues, TITLE_INFO_RELEASE) ~= 0 then
        return "expected no release info issue with the hold off"
    end
    return nil
end)

-- The one that proves the gate is the empower SIGHTING and not the setting.
case("hold on but only a PLAIN spell: no info row", function()
    local issues = {}
    RA:CheckEmpower(seq({ holdOnChannel = true, steps = { "/cast " .. PLAIN_NAME } }), issues, {})
    if CountTitle(issues, TITLE_INFO_RELEASE) ~= 0 then
        return "expected no release info issue without an empowered spell in the version"
    end
    return nil
end)

if standalone then
    -- The tap-controls sighting is emitted once per SEQUENCE, not once per step.
    case("tap controls on: info fires ONCE across a multi-step sequence", function()
        setTapCVar("1")
        local issues = {}
        RA:CheckEmpower(
            seq({
                steps = {
                    "/cast " .. EMPOWER_NAME,
                    "/cast " .. EMPOWER_NAME,
                    "/cast " .. EMPOWER_NAME,
                },
            }),
            issues,
            {}
        )
        setTapCVar("0")
        local n = CountTitle(issues, TITLE_INFO)
        if n ~= 1 then
            return "expected exactly one info issue, got " .. n
        end
        return nil
    end)

    case("tap controls off: no info issue", function()
        setTapCVar("0")
        local issues = {}
        RA:CheckEmpower(seq({ steps = { "/cast " .. EMPOWER_NAME } }), issues, {})
        if CountTitle(issues, TITLE_INFO) ~= 0 then
            return "expected no info issue"
        end
        return nil
    end)

    case("tap controls on but NO empowered spell: no info issue", function()
        setTapCVar("1")
        local issues = {}
        RA:CheckEmpower(seq({ steps = { "/cast " .. PLAIN_NAME } }), issues, {})
        setTapCVar("0")
        if CountTitle(issues, TITLE_INFO) ~= 0 then
            return "expected no info issue without an empowered spell"
        end
        return nil
    end)

    -- Malformed shapes must not raise. The analyzer whose job is reporting
    -- corrupt sequences must never crash on the corruption.
    case("malformed versions and steps shapes do not raise", function()
        for _, bad in ipairs({
            { versions = 5 },
            { versions = { { steps = 7 } } },
            { versions = { { steps = { 5, true } } } },
            {},
        }) do
            local ok, err = pcall(RA.CheckEmpower, RA, bad, {}, {})
            if not ok then
                return "raised on a malformed shape: " .. tostring(err)
            end
        end
        return nil
    end)
end

-- ---------------------------------------------------------------------------
-- Mode dispatch.
-- ---------------------------------------------------------------------------

if standalone then
    local passed, failed = 0, 0
    for _, c in ipairs(cases) do
        local ok, res = pcall(c.fn)
        if ok and res == nil then
            passed = passed + 1
            print("PASS  " .. c.name)
        else
            failed = failed + 1
            print("FAIL  " .. c.name .. " -- " .. tostring(ok and res or res))
        end
    end
    print(string.format("RESULT %d passed, %d failed", passed, failed))
    os.exit(failed > 0 and 1 or 0)
else
    local TS = GRIPEMS.TestSuite
    if not TS then
        return
    end
    RA = GRIPEMS.RepairAnalyzer
    for _, c in ipairs(cases) do
        TS:Register(c.name, "empower_repair", function(self)
            if not RA or not RA.CheckEmpower then
                self:Skip("RepairAnalyzer:CheckEmpower not loaded")
                return
            end
            local res = c.fn()
            if res == nil then
                self:Pass()
            else
                self:Fail(res)
            end
        end)
    end
end
