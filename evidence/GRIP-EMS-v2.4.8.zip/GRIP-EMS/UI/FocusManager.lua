-- GRIP-EMS: Focus Manager
-- Created: 2026-04-19
-- Updated: 2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.
--
-- Central keyboard-focus registry with a context stack. Phase 2 #7 keystone.
-- Consumers: MainFrame + modal frames PushContext on Show, PopContext on Hide.
-- The MainFrame OnKeyDown routes TAB / ENTER / SPACE / ESC through the top
-- context. A list-row sub-region is maintained for the SequenceList so that
-- UP / DOWN can iterate rows while TAB still cycles the title-bar controls.
-- The EditBox-focus flag is owned here (relocated from SE.editBoxFocused).

local ADDON_NAME, GRIPEMS = ...

GRIPEMS.Focus = GRIPEMS.Focus or {}
local Focus = GRIPEMS.Focus

-- EditBox-focus flag (relocated from SequenceEditor). Any OnKeyDown handler
-- that needs to defer to typing should short-circuit on this.
Focus.editBoxFocused = false

Focus._stack = Focus._stack or {}
Focus._listeners = Focus._listeners or {}

-- List-row sub-region: a flat array of row widgets navigated by arrow keys.
-- _listRowSet maps widget -> index for O(1) "is this a row?" lookups.
Focus._listRows = Focus._listRows or {}
Focus._listRowSet = Focus._listRowSet or {}
Focus._listCursor = nil

-- Phase 2 #8 region registry (anchors for focus-ring draw calls).
Focus._regions = Focus._regions or {}

local function topContext()
    return Focus._stack[#Focus._stack]
end

local function isFocusable(widget)
    if not widget then
        return false
    end
    if widget.IsVisible and not widget:IsVisible() then
        return false
    end
    if widget.IsEnabled and widget:IsEnabled() == false then
        return false
    end
    if widget.GetParent then
        local parent = widget:GetParent()
        if parent and parent.IsVisible and not parent:IsVisible() then
            return false
        end
    end
    return true
end

local function fireListeners(current, prev)
    local listeners = Focus._listeners
    for i = 1, #listeners do
        local fn = listeners[i]
        if fn then
            pcall(fn, current, prev)
        end
    end
end

local function logWarning(msg)
    if type(GRIPEMS.Log) == "function" then
        GRIPEMS.Log(msg)
    elseif GRIPEMS.Debug then
        pcall(GRIPEMS.Debug, GRIPEMS, msg)
    end
end

--- Return the context on top of the stack, or nil.
function Focus:TopContext()
    return topContext()
end

--- Return the topmost context whose name matches, scanning from the top of
--- the stack down, or nil. Unlike TopContext this also finds a context that
--- a transient context (e.g. a modal popup) is currently sitting on top of,
--- so an owner can refresh its own targets in place while a popup is open.
--- @param name string
--- @return table|nil
function Focus:FindContext(name)
    if name == nil then
        return nil
    end
    for i = #self._stack, 1, -1 do
        local ctx = self._stack[i]
        if ctx and ctx.name == name then
            return ctx
        end
    end
    return nil
end

--- Push a new focus context onto the stack.
--- @param name string
--- @param targets table|nil Ordered array of widget tables
--- @param opts table|nil { onActivate = fn(widget) }
--- @return table The new context
function Focus:PushContext(name, targets, opts)
    local ctx = {
        name = name,
        targets = targets or {},
        opts = opts or {},
        cursor = nil,
    }
    self._stack[#self._stack + 1] = ctx
    self._listCursor = nil
    fireListeners(nil, nil)
    return ctx
end

--- Pop the top context if its name matches. No-op and warning on mismatch.
--- @param name string|nil
function Focus:PopContext(name)
    local top = topContext()
    if not top then
        return
    end
    if name and top.name ~= name then
        logWarning("Focus:PopContext mismatch: top=" .. tostring(top.name) .. " requested=" .. tostring(name))
        return
    end
    local prev = top.cursor and top.targets[top.cursor] or nil
    self._stack[#self._stack] = nil
    self._listCursor = nil
    local newTop = topContext()
    local current = newTop and newTop.cursor and newTop.targets[newTop.cursor] or nil
    fireListeners(current, prev)
end

--- Move the cursor within the top context, skipping non-focusable targets.
--- Wraps at ends. Fires listeners. Clears any active list cursor.
--- @param dir number 1 (forward) or -1 (backward)
--- @return table|nil
function Focus:Cycle(dir)
    local top = topContext()
    if not top or not top.targets or #top.targets == 0 then
        return nil
    end
    dir = (dir == -1) and -1 or 1
    local count = #top.targets
    local prev = top.cursor and top.targets[top.cursor] or nil
    local start = top.cursor or ((dir == 1) and 0 or (count + 1))
    local idx = start
    for _ = 1, count do
        idx = ((idx - 1 + dir) % count) + 1
        if isFocusable(top.targets[idx]) then
            top.cursor = idx
            self._listCursor = nil
            local current = top.targets[idx]
            fireListeners(current, prev)
            return current
        end
    end
    return nil
end

--- Activate the current widget. Calls opts.onActivate(widget) if present;
--- otherwise widget:Click("LeftButton", true). pcall-wrapped for taint safety.
--- Simplified Mode (Phase S2): applies a per-widget post-acceptance
--- lockout, reading the delay from accessibility.simplifiedDelay
--- (milliseconds). Each widget keeps its own stamp in
--- self._lastActivateAt so rapid alternation between Run / Unlock /
--- Close is never blocked. Rejected activations are swallowed --
--- no click, no flash -- but still report the press as consumed.
--- Default delay is 500 ms per GAG Motor Advanced; adjustable 250..1500.
--- On accepted activation, fires FocusRing:FlashActivate for visual
--- confirmation.
--- @return boolean consumed -- true when the press was aimed at a widget
--- (activated, or deliberately swallowed by the Simplified Mode lockout);
--- false when nothing is under the cursor, so callers may propagate the
--- key to the game (chat-open / jump dead-key fix).
function Focus:Activate()
    local widget
    local onActivate
    if self._listCursor and self._listRows[self._listCursor] then
        widget = self._listRows[self._listCursor]
        local top = topContext()
        if top and top.opts then
            onActivate = top.opts.onActivate
        end
    else
        local top = topContext()
        if not top or not top.cursor then
            return false
        end
        widget = top.targets[top.cursor]
        if top.opts then
            onActivate = top.opts.onActivate
        end
    end
    if not widget or not isFocusable(widget) then
        return false
    end

    -- Simplified Mode: per-widget post-acceptance lockout (spec 5.2).
    if widget then
        local acc = GRIPEMS.Settings
            and GRIPEMS.Settings.db
            and GRIPEMS.Settings.db.profile
            and GRIPEMS.Settings.db.profile.accessibility
        if acc and acc.simplifiedMode then
            local now = GetTime()
            local delayMs = acc.simplifiedDelay or 500
            self._lastActivateAt = self._lastActivateAt or {}
            local last = self._lastActivateAt[widget] or 0
            if (now - last) * 1000 < delayMs then
                return true
            end
            self._lastActivateAt[widget] = now
            local FR = GRIPEMS.UI and GRIPEMS.UI.FocusRing
            if FR and FR.FlashActivate then
                pcall(FR.FlashActivate, FR)
            end
        end
    end

    if type(onActivate) == "function" then
        pcall(onActivate, widget)
    elseif widget.Click then
        pcall(widget.Click, widget, "LeftButton", true)
    end
    return true
end

--- Clear every per-widget lockout timestamp. Called on MainFrame
--- hide and on profile switch so a new profile or a fresh session
--- starts with a clean activation map.
function Focus:ClearActivationLockouts()
    self._lastActivateAt = {}
end

--- Clear cursors in the top context (and any list cursor). Fires listeners.
function Focus:Clear()
    local top = topContext()
    local prev = nil
    if top and top.cursor then
        prev = top.targets[top.cursor]
        top.cursor = nil
    end
    if self._listCursor then
        prev = prev or self._listRows[self._listCursor]
        self._listCursor = nil
    end
    if prev then
        fireListeners(nil, prev)
    end
end

--- Return the currently focused widget (list row if set, else top-context
--- cursor), or nil.
function Focus:GetCurrent()
    if self._listCursor and self._listRows[self._listCursor] then
        return self._listRows[self._listCursor]
    end
    local top = topContext()
    if not top or not top.cursor then
        return nil
    end
    return top.targets[top.cursor]
end

--- Register a listener fired on any focus change.
--- @param fn function fn(current, prev)
function Focus:RegisterListener(fn)
    if type(fn) ~= "function" then
        return
    end
    self._listeners[#self._listeners + 1] = fn
end

--- Replace the list-row register with the given ordered widget array.
--- Called by SequenceList whenever its rows are (re)built.
--- @param rows table|nil Ordered array of row Button widgets
function Focus:UpdateListTargets(rows)
    rows = rows or {}
    self._listRows = rows
    local set = {}
    for i, w in ipairs(rows) do
        if w then
            set[w] = i
        end
    end
    self._listRowSet = set
    if self._listCursor and not self._listRows[self._listCursor] then
        self._listCursor = nil
    end
end

--- Move the list cursor forward or backward, skipping non-focusable rows.
--- Wraps at ends. Clears the top-context cursor so GetCurrent prefers the
--- list row.
--- @param dir number 1 or -1
--- @return table|nil
function Focus:CycleListRow(dir)
    local rows = self._listRows
    if not rows or #rows == 0 then
        return nil
    end
    dir = (dir == -1) and -1 or 1
    local count = #rows
    local prev = self._listCursor and rows[self._listCursor] or nil
    local start = self._listCursor or ((dir == 1) and 0 or (count + 1))
    local idx = start
    for _ = 1, count do
        idx = ((idx - 1 + dir) % count) + 1
        if isFocusable(rows[idx]) then
            self._listCursor = idx
            local top = topContext()
            if top then
                top.cursor = nil
            end
            local current = rows[idx]
            fireListeners(current, prev)
            return current
        end
    end
    return nil
end

--- Set the list cursor to a specific row (e.g. from a mouse-click handler).
--- Passing nil clears it.
--- @param widget table|nil
function Focus:SetListCurrent(widget)
    if widget == nil then
        if self._listCursor then
            local prev = self._listRows[self._listCursor]
            self._listCursor = nil
            fireListeners(nil, prev)
        end
        return
    end
    local idx = self._listRowSet[widget]
    if not idx then
        return
    end
    local prev = self._listCursor and self._listRows[self._listCursor] or nil
    self._listCursor = idx
    local top = topContext()
    if top then
        top.cursor = nil
    end
    fireListeners(widget, prev)
end

--- Return the currently focused list row widget, or nil.
function Focus:GetListCurrent()
    if not self._listCursor then
        return nil
    end
    return self._listRows[self._listCursor]
end

--- Return true if the widget is currently registered as a list row.
--- @param widget table|nil
function Focus:IsListRow(widget)
    return widget ~= nil and self._listRowSet[widget] ~= nil
end

--- Register a handler called when DELETE is pressed with a list row focused.
--- Stored out-of-band from the context stack because list rows cross modals.
--- @param fn function|nil fn(widget) -- pass nil to clear
function Focus:SetListDeleteHandler(fn)
    self._listDeleteHandler = (type(fn) == "function") and fn or nil
end

--- Invoke the list delete handler if a list row is focused. No-op otherwise.
--- pcall-wrapped for taint safety.
function Focus:Delete()
    if not self._listCursor then
        return
    end
    local widget = self._listRows[self._listCursor]
    if not widget or not self._listDeleteHandler then
        return
    end
    pcall(self._listDeleteHandler, widget)
end

--- Register a named UI region (Phase 2 #8 focus-ring anchor).
--- @param name string
--- @param frame table
function Focus:RegisterRegion(name, frame)
    self._regions[name] = frame
end

--- Return the frame registered under a region name, or nil.
--- @param name string
function Focus:GetRegion(name)
    return self._regions[name]
end

--- Back-compat writer for callers that wrote SE.editBoxFocused directly.
--- @param bool boolean
function Focus:SetEditBoxFocused(bool)
    self.editBoxFocused = bool and true or false
end

--- Wire an EditBox's OnEditFocusGained / OnEditFocusLost handlers
--- so the global Focus.editBoxFocused flag stays accurate.
--- Preserves any existing focus-gained / focus-lost script the
--- caller already attached (wraps, does not overwrite).
--- @param editBox EditBox
function Focus:HookEditBox(editBox)
    if not editBox then
        return
    end
    local oldGain = editBox:GetScript("OnEditFocusGained")
    editBox:SetScript("OnEditFocusGained", function(self, ...)
        Focus:SetEditBoxFocused(true)
        if oldGain then
            oldGain(self, ...)
        end
    end)
    local oldLost = editBox:GetScript("OnEditFocusLost")
    editBox:SetScript("OnEditFocusLost", function(self, ...)
        Focus:SetEditBoxFocused(false)
        if oldLost then
            oldLost(self, ...)
        end
    end)
end

--- Track an EditBox's most recent text selection so a consumer (the SpellPicker)
--- can re-create and replace it after the box loses keyboard focus. WoW clears the
--- highlight on blur and exposes no get-selection API, so the range is rebuilt from
--- the mousedown anchor (read one frame after the click, once WoW has moved the
--- cursor to the click point) and the cursor position at the moment focus is lost.
--- Stored on the EditBox as _gemsSelRange = { startPos, stopPos }, or nil when there
--- was no real selection. Consumers MUST clear it after use. Safe degradation: if the
--- anchor is never captured, _gemsSelRange stays nil and the consumer falls back to a
--- plain cursor insert.
--- @param editBox EditBox
function Focus:HookSelectionCapture(editBox)
    if not editBox then
        return
    end
    local oldMouseDown = editBox:GetScript("OnMouseDown")
    editBox:SetScript("OnMouseDown", function(self, ...)
        if C_Timer and C_Timer.After then
            C_Timer.After(0, function()
                self._gemsSelAnchor = self:GetCursorPosition()
            end)
        end
        if oldMouseDown then
            oldMouseDown(self, ...)
        end
    end)
    local oldLost = editBox:GetScript("OnEditFocusLost")
    editBox:SetScript("OnEditFocusLost", function(self, ...)
        local anchor = self._gemsSelAnchor
        local cursor = self:GetCursorPosition()
        -- Always record the caret so a no-selection pick can restore it (else
        -- Insert lands at the end of the box after SetFocus).
        self._gemsSelCursor = cursor
        if anchor and cursor and anchor ~= cursor then
            self._gemsSelRange = { math.min(anchor, cursor), math.max(anchor, cursor) }
        else
            self._gemsSelRange = nil
        end
        self._gemsSelAnchor = nil
        if oldLost then
            oldLost(self, ...)
        end
    end)
end

--- Back-compat reader for callers that read SE.editBoxFocused directly.
--- Belt-layer fallback: catches EditBoxes whose OnEditFocusGained
--- handlers were never wired through Focus:HookEditBox.
--- GetCurrentKeyBoardFocus returns the focused EditBox or nil.
--- @return boolean
function Focus:IsEditBoxFocused()
    if self.editBoxFocused then
        return true
    end
    local f = GetCurrentKeyBoardFocus and GetCurrentKeyBoardFocus()
    return f ~= nil
end
