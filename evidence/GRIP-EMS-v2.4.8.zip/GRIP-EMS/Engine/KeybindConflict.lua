-- GRIP-EMS: KeybindConflict
-- Created: 2026-08-11
-- Updated: 2026-08-25 (Patch header swept to build 12.1.0.69273; 2026-08-11 Phase 3: published vocabulary, self-file from ADDON_NAME)
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.

-- GRIP-EMS: Keybind Conflict Detection (detection core)
--
-- A sequence key can be consumed in five independent places, and the native Key
-- Bindings panel renders exactly one of them: the base binding table, the
-- override-binding layer, the modified-click registry, the click-binding
-- profile, and the autoSelfCast CVar pairing. This module is the pure-logic core
-- that answers "what actually owns this key" across those layers. It renders
-- nothing and resolves nothing.
--
-- "CHANGES NO GAME STATE" WAS TRUE OF THE WHOLE FILE UNTIL PHASE 2, and is now
-- true of only part of it. Which part still holds, precisely:
--   * DETECTION -- every layer function, KC.CheckKey, the binding-map sweep, the
--     capability probe and the addon enumeration -- is still read-only. It calls
--     nothing that mutates, sets no binding, and touches no CVar.
--   * ATTRIBUTION, at the foot of this file, does NOT hold. It installs
--     hooksecurefunc post-hooks on eleven binding globals plus
--     ClearOverrideBindings at file load, and those hooks are permanent for the
--     session. It still sets no binding and changes no binding state: a
--     hooksecurefunc post-hook cannot alter the call it follows, its arguments or
--     its return, so nothing a user or another addon does is affected. What
--     changed is that this file is no longer inert -- it now runs code on every
--     binding call in the session, and it accumulates a bounded in-memory buffer.
--
-- Two rules shape every function here:
--
--   1. Modifier order is canonical, and the reason is NOT the one an earlier
--      draft of this module gave. Measured on the live 12.0.7 client on
--      2026-08-11, in this order:
--        a. Key DISPATCH normalises to ALT, then CTRL, then SHIFT.
--        b. GetBindingAction RETRIEVAL does an exact string match and does not
--           normalise at all, so a binding is retrievable only under the literal
--           string it was registered with.
--        c. A binding registered under a non-canonical order is therefore INERT:
--           it was registered, it is invisible to a canonical query, and it DOES
--           NOT FIRE. Measured directly -- the same command under a non-canonical
--           order did nothing on a physical keypress, and the identical keypress
--           fired it once it was registered under the canonical order.
--      Querying the canonical form is therefore NECESSARY AND SUFFICIENT, so
--      every key string entering this module is routed through
--      KC.CanonicalizeKey first. Do NOT add permutation probing of the other
--      modifier orderings: (b) alone would justify it and only the fire test in
--      (c) rules it out, so a future reader WILL be tempted.
--   2. Every function that touches a WoW global takes an optional deps table as
--      its last parameter and resolves through it, so the whole module is
--      drivable from a spec with no client running. deps entries override the
--      live global of the same name; deps.strict = true suppresses the live
--      globals entirely (used to assert graceful degradation); deps.refresh
--      = true forces a capability re-probe without writing the production cache.
--      A missing global always degrades to a false capability and an "unknown"
--      layer status. It never raises, and it never reads as "clear".

local ADDON_NAME, GRIPEMS = ...

GRIPEMS.KeybindConflict = {}
local KC = GRIPEMS.KeybindConflict

-- ===========================================================================
-- Published vocabulary
-- ===========================================================================
--
-- Every token this module puts on the wire, enumerable. The panel maps a token
-- to copy, and a token that drifts silently -- renamed here, still spelled the
-- old way in the panel's map -- leaves the panel rendering NOTHING for a real
-- finding, which reads to the user as "no problem found". Publishing the sets
-- makes the mapping testable: a case can walk these tables and assert copy
-- exists for every token, instead of against a hand-written list that drifts
-- the same way the panel would.
--
-- These are the single source. The file-local constants below are assigned FROM
-- them rather than restated, so the two cannot disagree.

--- Layer and verdict statuses.
KC.STATUS = {
    clear = "clear",
    conflict = "conflict",
    unknown = "unknown",
    masked = "masked",
}

--- The four layer ids KC.CheckKey emits, in the order it emits them.
---
--- Published for the panel, NOT read by the layer functions themselves: those
--- still carry their own id = "base" style literals, because one of them is
--- checkBaseLayer and it is md5-pinned. Parity between this table and what
--- CheckKey actually emits is asserted against real output in
--- Test/test_keybind_conflict_panel.lua, which catches drift in either
--- direction without editing a pinned producer.
KC.LAYER_IDS = {
    base = "base",
    effective = "effective",
    modifier = "modifier",
    clickbind = "clickbind",
}

--- The reason tokens that can appear on a context note.
KC.NOTE_REASONS = {
    masked = "masked_by_effective_override",
    baseOwner = "native_binding_owner",
    castRedirect = "cast_redirect",
    clickOwner = "click_binding_owner",
    other = "layer_conflict",
}

-- Layer / verdict status vocabulary. Kept file-local for terse use below; the
-- values come from KC.STATUS so there is exactly one place to change them.
local STATUS_CLEAR = KC.STATUS.clear
local STATUS_CONFLICT = KC.STATUS.conflict
local STATUS_UNKNOWN = KC.STATUS.unknown

-- A layer that found something real, that is NOT costing the user anything right
-- now because a healthy EMS override sits on top of it, and that WOULD cost them
-- if that override ever failed to apply. It is evidence, not a problem: the
-- keypress reaches EMS today. It is also not "clear", because the finding is
-- genuine and the user is one failed override away from paying for it. Only the
-- reconciliation step in KC.CheckKey may assign this status -- no layer function
-- may reach it on its own, because no single layer knows what sits above it.
local STATUS_MASKED = KC.STATUS.masked

-- The field name carrying the provenance of a GetModifiedClickMap result. Action
-- names are always upper case, so a lower-case field cannot collide with one.
local SOURCE_FIELD = "source"

--- Resolve one dependency by global name. An injected deps entry wins; otherwise
--- the live global is read through _G, which yields nil for a missing global
--- instead of raising. deps.strict suppresses the _G fallback so a spec can
--- assert the "this global does not exist" path inside a running client.
--- @param deps table|nil Injected dependency overrides
--- @param name string Global name to resolve
--- @return any
local function dep(deps, name)
    if deps then
        local injected = deps[name]
        if injected ~= nil then
            return injected
        end
        if deps.strict then
            return nil
        end
    end
    return _G[name]
end

--- Pack a call's return values without losing embedded nils. GetBinding returns
--- command, category, key1, key2, ... and any of the key slots can come back nil,
--- which makes a bare { f() } plus # unreliable.
--- @return number count, table packed
local function packReturns(...)
    return select("#", ...), { ... }
end

--- Read one GetBinding row under a single pcall. Wrapping the call itself (rather
--- than pcall'ing packReturns with an already-evaluated row) is what keeps a
--- raising GetBinding from escaping the sweep.
--- @return number count, table packed
local function readBindingRow(getBinding, index)
    return packReturns(getBinding(index))
end

-- ===========================================================================
-- Canonical modifier order
-- ===========================================================================

--- WoW's canonical modifier prefix order, MEASURED rather than read off the
--- wiki: key dispatch honours ALT, then CTRL, then SHIFT, and a binding
--- registered in any other order never fires (probes P4 and P7 plus the fire
--- test, live client, 2026-08-11). This constant is the single source of that
--- order; nothing else in the module hardcodes it. Treat as immutable.
KC.MODIFIER_ORDER = { "ALT", "CTRL", "SHIFT" }

-- Membership lookup derived from MODIFIER_ORDER, so the order constant stays the
-- only place the modifier set is written down.
local MODIFIER_SET = {}
for _, modifier in ipairs(KC.MODIFIER_ORDER) do
    MODIFIER_SET[modifier] = true
end

-- Modified-click actions that redirect where a cast LANDS rather than swallowing
-- the keypress. Everything else in the registry is a mouse-click modifier and
-- does not consume a key.
local CAST_REDIRECT_ACTIONS = {
    SELFCAST = true,
    FOCUSCAST = true,
    MOUSEOVERCAST = true,
}

--- Consume the leading modifier tokens off an already-upper-cased string. A token
--- is only consumed while it is in MODIFIER_SET, so NUMPADMINUS and the bare "-"
--- key survive intact. Shared by KC.SplitKey and KC.ParseModifiedClickValue so
--- the two can never drift on what counts as a modifier prefix.
--- @param text string Upper-case string to consume from
--- @return table modifiers Set keyed by "ALT" / "CTRL" / "SHIFT"
--- @return string rest Remainder with every modifier prefix stripped
local function consumeModifierPrefix(text)
    local modifiers = {}
    local rest = text
    while true do
        local token, tail = string.match(rest, "^([A-Z]+)%-(.+)$")
        if token and MODIFIER_SET[token] then
            modifiers[token] = true
            rest = tail
        else
            break
        end
    end
    return modifiers, rest
end

--- Split a key string into its modifier set and its bare key. Accepts any casing
--- and any modifier ordering; the bare key is returned upper case. Leading tokens
--- are only consumed as modifiers when they are in MODIFIER_SET, so NUMPADMINUS
--- and the bare "-" key survive intact.
--- @param key string|nil WoW key string, any casing, any modifier order
--- @return table|nil modifiers Set keyed by "ALT" / "CTRL" / "SHIFT"
--- @return string|nil bare Upper-case key with every modifier prefix stripped
function KC.SplitKey(key)
    if type(key) ~= "string" then
        return nil
    end
    local upper = string.upper(key)
    if upper == "" then
        return nil
    end
    local modifiers, rest = consumeModifierPrefix(upper)
    if rest == "" then
        return nil
    end
    return modifiers, rest
end

--- Canonicalise a key string: upper case, modifiers emitted in MODIFIER_ORDER.
--- ctrl-alt-shift-t, SHIFT-ALT-CTRL-T and ALT-CTRL-SHIFT-T all return
--- ALT-CTRL-SHIFT-T. This is the module's single canonicaliser; every key string
--- entering any other function here goes through it first.
---
--- Why the canonical form is the ONLY form worth querying, in the order it was
--- measured on 2026-08-11: key dispatch normalises to ALT, CTRL, SHIFT;
--- GetBindingAction retrieval does an exact string match and never normalises;
--- therefore a binding registered under a non-canonical order is inert -- it was
--- registered, a canonical query cannot see it, and a physical keypress does not
--- fire it. Necessary AND sufficient. Do NOT extend this into permutation
--- probing of the other orderings: the retrieval behaviour on its own reads like
--- a coverage hole and only the fire test proves it is not one.
--- @param key string|nil WoW key string, any casing, any modifier order
--- @return string|nil Canonical form, or nil for nil / empty input
function KC.CanonicalizeKey(key)
    local modifiers, bare = KC.SplitKey(key)
    if not modifiers then
        return nil
    end
    local prefix = ""
    for _, modifier in ipairs(KC.MODIFIER_ORDER) do
        if modifiers[modifier] then
            prefix = prefix .. modifier .. "-"
        end
    end
    return prefix .. bare
end

-- ===========================================================================
-- Layer 1: the base binding table
-- ===========================================================================

--- Walk the whole binding table into a canonical key -> owners map.
--- GetNumBindings plus GetBinding enumerates Blizzard's full set plus the
--- Bindings.xml of every LOADED addon. GetBinding returns
--- command, category, key1, key2, ... so the key slots are read from the varargs
--- rather than assuming exactly two. Every value is a LIST: when two commands
--- claim the same canonical key both are retained, because reporting that
--- collision is the entire point of the sweep.
--- @param deps table|nil Injected dependency overrides
--- @return table|nil map canonicalKey -> { { command, category, slot }, ... };
---   nil when the binding enumeration API is unavailable (never an empty map,
---   so "no API" cannot be mistaken for "no bindings")
function KC.BuildBindingMap(deps)
    local getNumBindings = dep(deps, "GetNumBindings")
    local getBinding = dep(deps, "GetBinding")
    if type(getNumBindings) ~= "function" or type(getBinding) ~= "function" then
        return nil
    end
    local map = {}
    local okCount, total = pcall(getNumBindings)
    total = (okCount and tonumber(total)) or 0
    for index = 1, total do
        local okRow, count, packed = pcall(readBindingRow, getBinding, index)
        if okRow and count and count >= 3 then
            local command = packed[1]
            local category = packed[2]
            if type(command) == "string" and command ~= "" then
                for position = 3, count do
                    local raw = packed[position]
                    if type(raw) == "string" and raw ~= "" then
                        local canonical = KC.CanonicalizeKey(raw)
                        if canonical then
                            local owners = map[canonical]
                            if not owners then
                                owners = {}
                                map[canonical] = owners
                            end
                            owners[#owners + 1] = {
                                command = command,
                                category = category,
                                slot = position - 2,
                            }
                        end
                    end
                end
            end
        end
    end
    return map
end

-- ===========================================================================
-- Runtime capability probe
-- ===========================================================================

--- Probe which of the APIs this module wants actually exist in this client.
--- Cached on KC after the first call; deps.refresh forces a fresh probe and
--- deliberately does NOT write the cache, so a spec driving stubbed globals can
--- never poison the production capability table. Every probe is pcall-guarded: a
--- missing global means that capability is false and the caller degrades, never
--- an error.
--- @param deps table|nil Injected dependency overrides
--- @return table capabilities
function KC.ProbeCapabilities(deps)
    local forced = deps and deps.refresh
    if KC._capabilities and not forced then
        return KC._capabilities
    end
    local capabilities = {
        bindingAction = false, -- GetBindingAction
        bindingEnum = false, -- GetNumBindings + GetBinding
        modifiedClickRead = false, -- GetModifiedClick
        modifiedClickEnum = false, -- GetNumModifiedClickActions + GetModifiedClickAction
        modifiedClickIndexed = false, -- GetModifiedClickAction accepted an index
        clickBindings = false, -- C_ClickBindings
        cvarBool = false, -- GetCVarBool
    }
    local ok, err = pcall(function()
        capabilities.bindingAction = type(dep(deps, "GetBindingAction")) == "function"
        capabilities.bindingEnum = type(dep(deps, "GetNumBindings")) == "function"
            and type(dep(deps, "GetBinding")) == "function"
        capabilities.modifiedClickRead = type(dep(deps, "GetModifiedClick")) == "function"
        local getNumActions = dep(deps, "GetNumModifiedClickActions")
        local getAction = dep(deps, "GetModifiedClickAction")
        capabilities.modifiedClickEnum = type(getNumActions) == "function" and type(getAction) == "function"
        if capabilities.modifiedClickEnum then
            -- GetModifiedClickAction has no wiki page, so its parameter shape is
            -- established by calling it rather than assumed.
            local okCall, name = pcall(getAction, 1)
            capabilities.modifiedClickIndexed = okCall and type(name) == "string" and name ~= ""
        end
        capabilities.clickBindings = type(dep(deps, "C_ClickBindings")) == "table"
        capabilities.cvarBool = type(dep(deps, "GetCVarBool")) == "function"
    end)
    if not ok then
        capabilities.probeError = tostring(err)
    end
    if not forced then
        KC._capabilities = capabilities
    end
    return capabilities
end

--- Drop the cached capability table so the next ProbeCapabilities call re-probes.
--- Needed after any event that can change the loaded API surface, and by specs
--- that assert the caching behaviour itself.
--- @return boolean true once the cache is cleared
function KC.ResetCapabilities()
    KC._capabilities = nil
    return true
end

-- ===========================================================================
-- Layer 3: the modified-click registry
-- ===========================================================================

--- Parse one GetModifiedClick return value into its modifier set and its button
--- component.
---
--- MEASURED, and the wiki explicitly denies this is possible. API:SetModifiedClick
--- states the value "Must be one of: ALT, CTRL, SHIFT, NONE". On a stock live
--- client, 2026-08-11: CHATLINK returned SHIFT-BUTTON1, DRESSUP returned
--- CTRL-BUTTON1 and EXPANDITEM returned SHIFT-BUTTON2. Any code that equality-
--- tests this value against a bare modifier mis-handles those three, so every
--- consumer of GetModifiedClick in this module routes through here instead.
---
--- NONE yields an empty modifier set and no button. A bare SHIFT yields a set
--- containing SHIFT and no button. SHIFT-BUTTON1 yields both.
--- @param value string|nil A GetModifiedClick return value, any casing
--- @return table modifiers Set keyed by "ALT" / "CTRL" / "SHIFT"; empty for NONE
--- @return string|nil button Upper-case button component, or nil when absent
function KC.ParseModifiedClickValue(value)
    if type(value) ~= "string" then
        return {}, nil
    end
    local upper = string.upper(value)
    if upper == "" or upper == "NONE" then
        return {}, nil
    end
    local modifiers, rest = consumeModifierPrefix(upper)
    if rest == "" or rest == "NONE" then
        return modifiers, nil
    end
    if MODIFIER_SET[rest] then
        -- A bare modifier, or the trailing modifier of a modifier-only value.
        modifiers[rest] = true
        return modifiers, nil
    end
    return modifiers, rest
end

--- Fallback action list, used ONLY when the runtime enumeration is unavailable.
--- The runtime enumeration (GetNumModifiedClickActions + GetModifiedClickAction)
--- is authoritative whenever it is available, because this list cannot be.
---
--- These 22 entries are the set MEASURED off the live 12.0.7 client on
--- 2026-08-11, in enumeration order: GetNumModifiedClickActions returned 22 and
--- GetModifiedClickAction takes a 1-based index. This is NOT the wiki's list, and
--- it must not be "corrected" back into it -- the wiki is wrong in both
--- directions:
---   * REMOVED: SOCKETITEM. The wiki publishes it; it DOES NOT EXIST at runtime.
---   * ADDED, the eight the wiki omits entirely: MAILAUTOLOOTTOGGLE, EXPANDITEM,
---     PICKUPITEM, RECIPEWATCHTOGGLE, SHOWMULTICASTFLYOUT,
---     HOUSINGINVERTINCLUDECHILDREN, HOUSINGEXTRAINCREMENT and
---     TRANSFORMMANIPULATORSNAP.
--- The wiki is wrong twice about SHOWMULTICASTFLYOUT specifically: it omits the
--- action from the list AND states it was removed in Patch 4.0.1. It is present
--- and set to ALT. MOUSEOVERCAST is likewise absent from the wiki and is read and
--- written by Blizzard_ClickBindingUI.
KC.KNOWN_MODIFIED_CLICK_ACTIONS = {
    "SELFCAST",
    "FOCUSCAST",
    "MOUSEOVERCAST",
    "AUTOLOOTTOGGLE",
    "MAILAUTOLOOTTOGGLE",
    "STICKYCAMERA",
    "CHATLINK",
    "DRESSUP",
    "EXPANDITEM",
    "SPLITSTACK",
    "PICKUPACTION",
    "PICKUPITEM",
    "COMPAREITEMS",
    "OPENALLBAGS",
    "QUESTWATCHTOGGLE",
    "RECIPEWATCHTOGGLE",
    "TOKENWATCHTOGGLE",
    "SHOWITEMFLYOUT",
    "SHOWMULTICASTFLYOUT",
    "HOUSINGINVERTINCLUDECHILDREN",
    "HOUSINGEXTRAINCREMENT",
    "TRANSFORMMANIPULATORSNAP",
}

--- Build the action -> configured value map for the modified-click registry.
--- The returned table is flat (action name -> the upper-cased value the client
--- reported, or "UNKNOWN") plus a lower-case "source" field reporting which path
--- produced it, so a later UI phase can tell the user when the list is degraded
--- rather than presenting a guess as an inventory.
---
--- The value is NOT guaranteed to be a bare modifier: CHATLINK, DRESSUP and
--- EXPANDITEM all measured as compound modifier-plus-button strings. It is stored
--- verbatim so nothing is lost, and every value published here has been through
--- KC.ParseModifiedClickValue; read it back the same way rather than comparing it
--- to "ALT" / "CTRL" / "SHIFT".
--- @param deps table|nil Injected dependency overrides
--- @return table map action -> value, plus map.source = "runtime" | "fallback"
function KC.GetModifiedClickMap(deps)
    local capabilities = KC.ProbeCapabilities(deps)
    local getModifiedClick = dep(deps, "GetModifiedClick")
    local map = {}
    local names

    if capabilities.modifiedClickEnum and capabilities.modifiedClickIndexed then
        local getNumActions = dep(deps, "GetNumModifiedClickActions")
        local getAction = dep(deps, "GetModifiedClickAction")
        local okCount, total = pcall(getNumActions)
        total = (okCount and tonumber(total)) or 0
        local enumerated = {}
        for index = 1, total do
            local okName, name = pcall(getAction, index)
            if okName and type(name) == "string" and name ~= "" then
                enumerated[#enumerated + 1] = string.upper(name)
            end
        end
        if #enumerated > 0 then
            names = enumerated
            map[SOURCE_FIELD] = "runtime"
        end
    end

    if not names then
        names = KC.KNOWN_MODIFIED_CLICK_ACTIONS
        map[SOURCE_FIELD] = "fallback"
    end

    for _, name in ipairs(names) do
        local modifier = "UNKNOWN"
        if capabilities.modifiedClickRead then
            local okRead, value = pcall(getModifiedClick, name)
            if okRead and type(value) == "string" and value ~= "" then
                local upper = string.upper(value)
                -- Routed through the parser rather than published blind: a value
                -- only reaches the map when the parser can account for it as
                -- NONE, as a modifier set, or as a modifier-plus-button pair.
                local parsedModifiers, parsedButton = KC.ParseModifiedClickValue(upper)
                if upper == "NONE" or parsedButton ~= nil or next(parsedModifiers) ~= nil then
                    modifier = upper
                end
            end
        end
        map[name] = modifier
    end
    return map
end

-- ===========================================================================
-- The action string EMS expects to own a sequence key
-- ===========================================================================

--- Resolve one addon-side module by name. Deps-injectable exactly like dep(),
--- but reading off the addon table instead of _G, so a spec can drive this with
--- no client. deps.strict suppresses the addon fallback, which is how the
--- "module not loaded" path is asserted.
--- @param deps table|nil Injected dependency overrides
--- @param name string Field name on the addon table
--- @return any
local function addonDep(deps, name)
    if deps then
        local injected = deps[name]
        if injected ~= nil then
            return injected
        end
        if deps.strict then
            return nil
        end
    end
    return GRIPEMS[name]
end

--- The binding action EMS expects to own a given sequence's key, in the exact
--- shape GetBindingAction reports it.
---
--- MEASURED on the live client, 2026-08-11: a sequence binding reads back from
--- GetBindingAction(key, true) as CLICK GRIPEMS_<SanitisedName>:LeftButton. Two
--- pairs were captured off the client, and this function reproduces both:
---     ORCBM-PLMT16         ->  CLICK GRIPEMS_ORCBMPLMT16:LeftButton
---     Slowdog_BMH_MT_V1.1  ->  CLICK GRIPEMS_Slowdog_BMH_MT_V11:LeftButton
--- Read together the pairs prove the rule is NOT "strip every non-alphanumeric":
--- the dash and the dot are stripped while the UNDERSCORES SURVIVE.
---
--- The sanitisation is deliberately NOT reimplemented here. It is
--- Engine:SanitizeName, reached through the same D.BUTTON_PREFIX that
--- Engine:ActivateSequence uses when it names the secure button in the first
--- place. A second sanitiser would be free to drift from the one that actually
--- names the button, and this function would then predict, with total
--- confidence, an action string that no key on the client carries.
--- @param seqName string|nil Raw sequence name, unsanitised
--- @param deps table|nil Injected dependency overrides
--- @return string|nil Expected action string; nil for an unusable name, or when
---   the Engine / Defaults modules are not loaded (never a guessed string)
function KC.ExpectedActionForSequence(seqName, deps)
    if type(seqName) ~= "string" or seqName == "" then
        return nil
    end
    local engine = addonDep(deps, "Engine")
    local defaults = addonDep(deps, "Defaults")
    local sanitize = type(engine) == "table" and engine.SanitizeName or nil
    local prefix = type(defaults) == "table" and defaults.BUTTON_PREFIX or nil
    if type(sanitize) ~= "function" or type(prefix) ~= "string" then
        return nil
    end
    -- Called with engine as self: SanitizeName is declared with method syntax.
    local ok, sanitized = pcall(sanitize, engine, seqName)
    if not ok or type(sanitized) ~= "string" or sanitized == "" then
        return nil
    end
    return "CLICK " .. prefix .. sanitized .. ":LeftButton"
end

-- ===========================================================================
-- Per-key multi-layer probe
-- ===========================================================================

--- Layer 1 evidence: what the base (saved) binding table says owns the key.
local function checkBaseLayer(canonical, expectedAction, capabilities, deps)
    local layer = { id = "base", status = STATUS_UNKNOWN, capabilityMissing = false }
    if not capabilities.bindingAction then
        layer.reason = "GetBindingAction unavailable"
        layer.capabilityMissing = true
        return layer
    end
    local getBindingAction = dep(deps, "GetBindingAction")
    local ok, action = pcall(getBindingAction, canonical, false)
    if not ok then
        layer.reason = "GetBindingAction raised on the base lookup"
        layer.capabilityMissing = true
        return layer
    end
    if type(action) == "string" and action ~= "" then
        layer.action = action
    end
    if not layer.action then
        layer.status = STATUS_CLEAR
    elseif expectedAction ~= nil and layer.action == expectedAction then
        layer.status = STATUS_CLEAR
    else
        -- A native binding owns the key. An override can still win the keypress,
        -- so this is reportable and fixable rather than automatically fatal.
        layer.status = STATUS_CONFLICT
    end
    return layer
end

--- Layer 2 evidence: what actually receives the keypress once override bindings
--- are resolved. maskedBase is the override-detection primitive: when the
--- override-resolving lookup disagrees with the base lookup, an override is
--- masking the saved binding.
---
--- This is the layer the verdict is drawn from, and it is the only one that can
--- answer the question the user actually has: does pressing this key reach EMS.
--- It therefore has to produce a usable status in BOTH modes it is called in --
--- with an expected action ("does EMS hold this key") and without one ("does
--- anything hold this key"). It stays ignorant of the base layer's status; the
--- relationship between the two is drawn exactly once, in KC.CheckKey.
local function checkEffectiveLayer(canonical, expectedAction, capabilities, deps, baseLayer)
    local layer = {
        id = "effective",
        status = STATUS_UNKNOWN,
        capabilityMissing = false,
        ownedByExpected = false,
    }
    if not capabilities.bindingAction then
        layer.reason = "GetBindingAction unavailable"
        layer.capabilityMissing = true
        return layer
    end
    local getBindingAction = dep(deps, "GetBindingAction")
    local ok, action = pcall(getBindingAction, canonical, true)
    if not ok then
        layer.reason = "GetBindingAction raised on the override-resolving lookup"
        layer.capabilityMissing = true
        return layer
    end
    if type(action) == "string" and action ~= "" then
        layer.action = action
    end
    layer.maskedBase = (layer.action ~= baseLayer.action)
    if expectedAction == nil then
        -- The is-this-key-free query. With no expected owner supplied the
        -- question stops being "does EMS hold this key" and becomes "does
        -- anything hold it", so ANY owner is a conflict and an unowned key is
        -- clear. Reporting unknown here instead would make a free key and an
        -- occupied one indistinguishable to the verdict rule, which now reads
        -- this layer and nothing else.
        layer.reason = "no expected action supplied: reporting the current owner"
        if layer.action then
            layer.status = STATUS_CONFLICT
        else
            layer.status = STATUS_CLEAR
        end
        return layer
    end
    layer.ownedByExpected = (layer.action == expectedAction)
    if layer.ownedByExpected then
        layer.status = STATUS_CLEAR
    else
        layer.status = STATUS_CONFLICT
    end
    return layer
end

--- True when every modifier the action is configured under is held by the key,
--- and the action carries at least one modifier. The action's set comes from
--- KC.ParseModifiedClickValue, so a compound value such as SHIFT-BUTTON1 matches
--- a key carrying SHIFT on its SHIFT component alone, and NONE (an empty set)
--- never matches anything.
--- @param keyModifiers table Modifier set of the key under test
--- @param actionModifiers table Parsed modifier set of the configured value
--- @return boolean
local function heldByKey(keyModifiers, actionModifiers)
    local any = false
    for modifier in pairs(actionModifiers) do
        if not keyModifiers[modifier] then
            return false
        end
        any = true
    end
    return any
end

--- Layer 3 evidence: modified-click registry entries whose configured modifier is
--- present in this key's modifier set. The configured value is PARSED rather than
--- compared, because it is not always a bare modifier -- CHATLINK, DRESSUP and
--- EXPANDITEM measured as SHIFT-BUTTON1, CTRL-BUTTON1 and SHIFT-BUTTON2 on a
--- stock client. castRedirect separates the two mechanisms: SELFCAST / FOCUSCAST
--- / MOUSEOVERCAST redirect where the cast LANDS while the key still fires; every
--- other action is a mouse-click modifier that does not touch a keypress at all.
--- A later phase reports the two differently, so the flag is set explicitly on
--- every entry rather than inferred at render time.
local function checkModifierLayer(modifiers, capabilities, deps)
    local map = KC.GetModifiedClickMap(deps)
    local layer = {
        id = "modifier",
        status = STATUS_CLEAR,
        capabilityMissing = false,
        entries = {},
        source = map[SOURCE_FIELD],
        degraded = (map[SOURCE_FIELD] == "fallback"),
    }
    local redirectHit = false
    for name, value in pairs(map) do
        if name ~= SOURCE_FIELD and type(value) == "string" then
            local actionModifiers, actionButton = KC.ParseModifiedClickValue(value)
            if heldByKey(modifiers, actionModifiers) then
                local isRedirect = (CAST_REDIRECT_ACTIONS[name] == true)
                layer.entries[#layer.entries + 1] = {
                    action = name,
                    modifier = value,
                    button = actionButton,
                    castRedirect = isRedirect,
                }
                if isRedirect then
                    redirectHit = true
                end
            end
        end
    end
    if not capabilities.modifiedClickRead then
        layer.status = STATUS_UNKNOWN
        layer.reason = "GetModifiedClick unavailable"
        layer.capabilityMissing = true
    elseif redirectHit then
        layer.status = STATUS_CONFLICT
    end
    return layer
end

--- Layer 4 evidence: the click-binding profile, which only applies to mouse-button
--- binds. A keyboard key reports unknown with applicable = false; that is "not
--- asked", not "capability missing", and it never drags the verdict to unknown.
local function checkClickLayer(bare, modifiers, capabilities, deps)
    local layer = {
        id = "clickbind",
        status = STATUS_UNKNOWN,
        capabilityMissing = false,
        applicable = false,
    }
    if type(bare) ~= "string" or string.sub(bare, 1, 6) ~= "BUTTON" then
        layer.reason = "key is not a mouse button"
        return layer
    end
    layer.applicable = true
    if not capabilities.clickBindings then
        layer.reason = "C_ClickBindings unavailable"
        layer.capabilityMissing = true
        return layer
    end
    local clickBindings = dep(deps, "C_ClickBindings")
    local getBindingType = clickBindings and clickBindings.GetBindingType
    if type(getBindingType) ~= "function" then
        layer.reason = "C_ClickBindings.GetBindingType unavailable"
        layer.capabilityMissing = true
        return layer
    end
    local prefixParts = {}
    for _, modifier in ipairs(KC.MODIFIER_ORDER) do
        if modifiers[modifier] then
            prefixParts[#prefixParts + 1] = modifier
        end
    end
    local button = tonumber(string.match(bare, "^BUTTON(%d+)$"))
    local ok, bindingType = pcall(getBindingType, button, table.concat(prefixParts, "-"))
    if not ok or bindingType == nil then
        -- The parameter shape is not yet verified against a live client, so a
        -- rejected call is reported as unknown rather than guessed as clear.
        layer.reason = "C_ClickBindings.GetBindingType rejected the probe"
        layer.capabilityMissing = true
        return layer
    end
    layer.bindingType = bindingType
    local noneValue = 0
    local enumTable = dep(deps, "Enum")
    if
        type(enumTable) == "table"
        and type(enumTable.ClickBindingType) == "table"
        and enumTable.ClickBindingType.None ~= nil
    then
        noneValue = enumTable.ClickBindingType.None
    end
    if bindingType == noneValue then
        layer.status = STATUS_CLEAR
    else
        layer.status = STATUS_CONFLICT
    end
    return layer
end

--- Relate the base layer to the effective layer. This is the ONLY place in the
--- module where those two are compared, and it is deliberate: checkBaseLayer
--- reports pure evidence and stays ignorant of everything above it, which is what
--- keeps it independently testable. Teaching it about overrides would make its
--- output depend on a second lookup and there would then be no function left in
--- this module that answers "what does the SAVED binding table say" on its own.
---
--- A base conflict under a healthy EMS override is not a lost keypress. It is a
--- fall-through risk, so it is downgraded to STATUS_MASKED rather than dropped.
--- The native command is carried through UNCHANGED on baseLayer.action: naming
--- the command the key would fall through to is the entire point of the row.
--- @param baseLayer table Layer 1 result, mutated in place
--- @param effectiveLayer table Layer 2 result, read only
local function reconcileMaskedBase(baseLayer, effectiveLayer)
    if
        effectiveLayer.status == STATUS_CLEAR
        and effectiveLayer.ownedByExpected
        and baseLayer.status == STATUS_CONFLICT
    then
        baseLayer.status = STATUS_MASKED
    end
end

--- Grade one layer on the severity scale RepairFrame already renders, so a later
--- phase reuses that rendering instead of inventing a second scale. Called AFTER
--- reconciliation, because a base layer downgraded to masked grades differently
--- from the conflict it arrived as.
---
--- The grade is NOT the verdict and can never become it. KC.CheckKey draws the
--- verdict from the effective layer alone; this function only decides how loudly
--- each layer's own finding renders underneath that verdict. That separation is
--- what lets a modifier or clickbind conflict grade warning on a key whose
--- verdict is clear without the two contradicting each other.
---
--- Three outcomes reach the info tail, and a modifier or clickbind CONFLICT is
--- none of them: a layer that found nothing costing the user anything (clear, or
--- a base layer masked by a healthy override), a layer that was never applicable
--- (the click-binding layer on a keyboard key), and any status with no explicit
--- branch above.
---
--- KC.SEVERITY is declared at the foot of this file and read here at CALL time,
--- so the ordering is not a load-order bug.
--- @param layer table A layer result
--- @return string One of KC.SEVERITY's four values
local function severityForLayer(layer)
    local severity = KC.SEVERITY
    if layer.id == "effective" then
        -- The verdict layer: its status IS the user-facing problem, so it grades
        -- hardest. A lost keypress is an error, an unreadable one is a warning.
        if layer.status == STATUS_CONFLICT then
            return severity.error
        elseif layer.status == STATUS_UNKNOWN then
            return severity.warning
        elseif layer.status == STATUS_CLEAR then
            return severity.info
        end
    elseif layer.id == "base" then
        if layer.status == STATUS_CONFLICT then
            return severity.error
        elseif layer.status == STATUS_MASKED then
            -- Costs nothing today. What it buys the user is knowing which command
            -- this key falls through to if the override ever fails to apply.
            return severity.info
        end
    -- The two layers the effective layer STRUCTURALLY CANNOT SEE, which is the
    -- whole reason they grade above info. A modifier conflict is a cast redirect:
    -- the keypress still reaches EMS and the sequence still fires, and every spell
    -- in it is redirected to self, focus or mouseover. A clickbind conflict is a
    -- click binding already holding the same mouse button. Neither costs the
    -- keypress, which is exactly why neither is allowed to drive the verdict -- and
    -- both cost the user something a clear verdict would otherwise bury, which is
    -- exactly why info is the wrong grade. Warning is the grade that survives a
    -- clear verdict without contradicting it.
    elseif layer.id == "modifier" or layer.id == "clickbind" then
        if layer.status == STATUS_CONFLICT then
            return severity.warning
        end
    end
    if layer.capabilityMissing then
        return severity.warning
    end
    return severity.info
end

-- Machine-readable reason tokens for the notes list. Deliberately NOT prose and
-- deliberately NOT locale keys: the panel maps a token to whatever copy it
-- wants, and nothing here has to change when that copy is rewritten. The values
-- come from KC.NOTE_REASONS so the published set and these cannot disagree.
local NOTE_REASON_MASKED = KC.NOTE_REASONS.masked
local NOTE_REASON_BASE_OWNER = KC.NOTE_REASONS.baseOwner
local NOTE_REASON_CAST_REDIRECT = KC.NOTE_REASONS.castRedirect
local NOTE_REASON_CLICK_OWNER = KC.NOTE_REASONS.clickOwner
local NOTE_REASON_OTHER = KC.NOTE_REASONS.other

--- The reason token for one context layer.
--- @param layer table A layer result whose status is masked or conflict
--- @return string
local function noteReasonFor(layer)
    if layer.status == STATUS_MASKED then
        return NOTE_REASON_MASKED
    elseif layer.id == "base" then
        return NOTE_REASON_BASE_OWNER
    elseif layer.id == "modifier" then
        return NOTE_REASON_CAST_REDIRECT
    elseif layer.id == "clickbind" then
        return NOTE_REASON_CLICK_OWNER
    end
    return NOTE_REASON_OTHER
end

--- Probe one key across every layer that can consume it.
---
--- THE VERDICT COMES FROM THE EFFECTIVE LAYER ALONE, and the reason is worth
--- stating because the earlier rule -- conflict if ANY layer conflicts -- looks
--- more careful and is worse. The effective layer is the only one that determines
--- whether the keypress reaches EMS. Everything else is context and risk: real
--- findings, none of which is costing the user a keypress while EMS holds the
--- key. Under the old flat OR, both of the live EMS keys measured on 2026-08-11
--- reported conflict while working perfectly, because a native binding sat under
--- a healthy override in each case. A panel that lists two working keys as
--- problems trains the user to ignore it, which is the exact failure this feature
--- exists to prevent.
---
--- The other three layers keep their own status and are graded on KC.SEVERITY,
--- and any of them still holding a masked or conflict status is republished on
--- result.notes so a later phase can render it as context under a key that is
--- otherwise fine.
---
--- Two guarantees survive the change:
---   * "clear" is still unreachable while any capability is missing;
---   * a DETECTED conflict still outranks a missing capability, because a
---     detected conflict is a fact and a missing capability is only an absence.
---
--- FALL-THROUGH, measured 2026-08-11 and carried in the result rather than
--- dropped: a non-empty BASE action while the EFFECTIVE action is the expected
--- EMS action is not a lost keypress today. EMS holds the key. What it means is
--- that the key falls through to that native command the moment the EMS override
--- fails to apply, and the user then sees the WRONG thing happen rather than
--- nothing, which is far harder to report accurately. Both live EMS keys on the
--- probe character were in exactly that state:
---     key "5"          masks ACTIONBUTTON5
---     key "NUMPADPLUS" masks MINIMAPZOOMIN
--- So the base layer keeps the native command verbatim on layer.action instead of
--- collapsing it to a boolean, and a later UI phase can name the command the key
--- would fall through to. It surfaces at the BASE layer, where clearing the
--- native binding is a real and offerable fix -- never as a lost keypress at the
--- effective layer, which EMS still owns. That is precisely the state
--- STATUS_MASKED names, and reconcileMaskedBase is where the base layer is
--- moved into it.
--- @param key string Key string, any casing, any modifier order
--- @param expectedAction string|nil The binding action EMS expects to own the key
--- @param deps table|nil Injected dependency overrides
--- @return table|nil result { key, bareKey, modifiers, layers, verdict, notes, ... }
function KC.CheckKey(key, expectedAction, deps)
    local canonical = KC.CanonicalizeKey(key)
    if not canonical then
        return nil
    end
    local modifiers, bare = KC.SplitKey(key)
    local capabilities = KC.ProbeCapabilities(deps)

    local baseLayer = checkBaseLayer(canonical, expectedAction, capabilities, deps)
    local effectiveLayer = checkEffectiveLayer(canonical, expectedAction, capabilities, deps, baseLayer)
    local modifierLayer = checkModifierLayer(modifiers, capabilities, deps)
    local clickLayer = checkClickLayer(bare, modifiers, capabilities, deps)
    local layers = { baseLayer, effectiveLayer, modifierLayer, clickLayer }

    -- Reconcile FIRST: it is the only step that may move a layer's status, and
    -- both the grading and the verdict below must read the reconciled statuses.
    reconcileMaskedBase(baseLayer, effectiveLayer)

    local sawMissingCapability = false
    for _, layer in ipairs(layers) do
        layer.severity = severityForLayer(layer)
        if layer.capabilityMissing then
            sawMissingCapability = true
        end
    end

    -- The effective layer alone decides. It is the only layer that determines
    -- whether the keypress reaches EMS; every other layer is context and risk,
    -- and grading a working key as a problem is how a warning panel gets ignored.
    -- The missing-capability arm keeps the original guarantee intact: "clear" is
    -- returned only when nothing was unreadable, so an absence can never be
    -- reported as an all-clear.
    local verdict
    if effectiveLayer.status == STATUS_CONFLICT then
        verdict = STATUS_CONFLICT
    elseif effectiveLayer.status == STATUS_UNKNOWN or sawMissingCapability then
        verdict = STATUS_UNKNOWN
    else
        verdict = STATUS_CLEAR
    end

    -- Context rows: every layer that found something real and did NOT drive the
    -- verdict. The effective layer is excluded by identity because it IS the
    -- verdict, never context. Machine-readable only -- no prose and no locale
    -- keys, so the rendering phase owns the copy.
    local notes = {}
    for _, layer in ipairs(layers) do
        if layer ~= effectiveLayer and (layer.status == STATUS_MASKED or layer.status == STATUS_CONFLICT) then
            notes[#notes + 1] = {
                id = layer.id,
                severity = layer.severity,
                reason = noteReasonFor(layer),
            }
        end
    end

    -- PURELY ADDITIVE, and it must stay that way. Neither field is read anywhere
    -- above: the verdict, the notes, the layer statuses and the severities are all
    -- computed before either one is fetched, and none of them can be moved by what
    -- attribution did or did not see. Attribution is a best-effort string parse of
    -- a stack; the verdict was settled by measurement on a live client. Wiring the
    -- first into the second would let a missing hook change a keybind's diagnosis.
    return {
        key = canonical,
        rawKey = key,
        bareKey = bare,
        modifiers = modifiers,
        expectedAction = expectedAction,
        layers = layers,
        verdict = verdict,
        notes = notes,
        capabilities = capabilities,
        attribution = KC.GetAttribution(canonical, deps),
        attributionState = KC.GetAttributionState(deps),
    }
end

-- ===========================================================================
-- Installed-but-not-loaded addons
-- ===========================================================================

--- List every INSTALLED addon that is not currently loaded.
---
--- The honest limit, which must be surfaced rather than papered over: a disabled
--- addon's Bindings.xml was never parsed, its commands are not registered, and
--- Lua has no file read. The keys such an addon WOULD claim are therefore not
--- knowable from Lua at all. This function exists to NAME that uncertainty -- to
--- say "these N addons are installed and not loaded, enabling one can register
--- new bindings" -- and explicitly not to resolve it. Any caller that presents
--- this list as a conflict inventory is lying to the user.
--- @param deps table|nil Injected dependency overrides
--- @return table|nil List of { name, title, reason, loadable }; nil when the
---   addon enumeration API is unavailable
function KC.ListUnloadedAddons(deps)
    local addons = dep(deps, "C_AddOns")
    if type(addons) ~= "table" then
        return nil
    end
    local getNumAddOns = addons.GetNumAddOns
    local getAddOnInfo = addons.GetAddOnInfo
    local isAddOnLoaded = addons.IsAddOnLoaded
    if type(getNumAddOns) ~= "function" or type(getAddOnInfo) ~= "function" then
        return nil
    end
    if type(isAddOnLoaded) ~= "function" then
        return nil
    end
    local unloaded = {}
    local okCount, total = pcall(getNumAddOns)
    total = (okCount and tonumber(total)) or 0
    for index = 1, total do
        local okInfo, name, title, _, loadable, reason = pcall(getAddOnInfo, index)
        if okInfo and type(name) == "string" and name ~= "" then
            local okLoaded, loaded = pcall(isAddOnLoaded, index)
            if okLoaded and not loaded then
                unloaded[#unloaded + 1] = {
                    name = name,
                    title = title,
                    reason = reason,
                    loadable = loadable,
                }
            end
        end
    end
    return unloaded
end

-- ===========================================================================
-- Attribution: which addon CALLED a binding function
-- ===========================================================================
--
-- Everything above answers "what owns this key". None of it can answer "which
-- addon took it", because no WoW API enumerates override bindings or their
-- owners. This section adds that missing half: hook the binding globals with
-- hooksecurefunc and capture debugstack inside the hook.
--
-- ATTRIBUTION IS A HINT. DETECTION IS THE AUTHORITY. A hooksecurefunc post-hook
-- fires whether or not the call it follows took effect, so a record proves who
-- CALLED, never who WON. GetBindingAction remains the only authority on who holds
-- a key right now, and KC.CheckKey's verdict is drawn from the effective layer
-- alone. Everything recorded here is attached to a result as a separate field and
-- is read by nothing else in this module. A future reader who wires attribution
-- into the verdict has turned a best-effort string parse into a truth claim.
--
-- HOW MUCH THIS DEPENDS ON THE CALL SHAPE, learned the expensive way. Phase 2
-- shipped with a frame budget measured in a research probe that called debugstack
-- directly inside an inline hook. This module's capture sits six frames deeper, so
-- on the live client EVERY record attributed to GRIP-EMS / KeybindConflict.lua --
-- this file naming itself as the caller of every binding call in the session --
-- while all 41 headless cases stayed green, because the parser was tested against
-- hand-written fixtures and the recorder against a stubbed debugstack. Nothing
-- exercised the real capture depth. If the plumbing between the hook and
-- captureCaller is ever changed, KC.ATTRIBUTION_STACK_FRAMES must be re-measured
-- ON A CLIENT, and the GROUP 10 regression case built from that live capture is
-- what keeps the self-skip from being deleted as redundant.

--- Records retained per key. A ring, not a list: a bar-paging addon can rebind the
--- same key thousands of times in one session, and the useful history is the last
--- few DISTINCT callers rather than all of them.
KC.ATTRIBUTION_RING_SIZE = 4

--- Distinct keys that may hold a bucket. See the recorder for why exceeding this
--- refuses NEW buckets instead of evicting old ones.
KC.ATTRIBUTION_MAX_KEYS = 256

--- The debugstack arguments. BOTH PREVIOUS VALUES WERE WRONG IN OPPOSITE
--- DIRECTIONS, and the note that used to sit here named only one of them.
---
---   * 1 IS TOO FEW. debugstack(2, 1, 0) returns ONLY the leading frame, and in the
---     original probe shape that frame was "[C]: in function
---     'SetOverrideBindingClick'" -- the hooked function itself, naming no caller.
---     That much of the old note was and remains true.
---   * 6 WAS ALSO TOO FEW, and it is what shipped the bug. Six was measured in a
---     research probe that called debugstack DIRECTLY inside an inline hook, with
---     zero intervening Lua frames. This module does not have that call shape: the
---     capture sits behind captureCaller, a tail call, pcall, recordBindingCall or
---     recordModifiedClick, and the closure makeRecorder returns. That plumbing
---     consumes six frames BEFORE the hooked [C] function, so at a budget of 6 the
---     real caller was never inside the window at all.
---
--- MEASURED on the live 12.0.7 client, 2026-08-11, reading the capture back off the
--- account SavedVariables: the first frame that is not this module's own plumbing
--- sat at POSITION 9. 16 clears that with headroom for a deeper caller chain while
--- staying bounded.
---
--- THE LEVEL STAYS 2 AND TUNING IT IS NOT THE LEVER. With the self-skip in
--- KC.ParseCallerFromStack in place, the level no longer decides the answer:
--- lowering it only prepends frames that the self-skip then discards. If
--- attribution is ever wrong again, the thing to re-measure is the frame budget and
--- the self-skip, not this.
KC.ATTRIBUTION_STACK_LEVEL = 2
KC.ATTRIBUTION_STACK_FRAMES = 16

--- The file whose frames are this module's own plumbing. Matched as a SUBSTRING of
--- a stack line, after that line's separators are normalised to forward slashes,
--- and skipped by KC.ParseCallerFromStack.
---
--- MATCHED ON THE FILE, NEVER ON THE ADDON NAME, and the difference is not
--- cosmetic. This module binds nothing, so a frame from it can never be the
--- legitimate answer to "who called a binding function". Engine/VehicleKeybinds.lua
--- and Engine/PetBattleButtons.lua genuinely DO bind, and when they do the correct
--- attribution IS GRIP-EMS -- so skipping the whole addon would replace one wrong
--- answer with another.
---
--- AND ON THE QUALIFIED FILE, not the bare name. MEASURED against the bare
--- "KeybindConflict.lua": a third-party addon shipping a file of that name had its
--- frame skipped too. Fed a stack whose real caller frame was
--- Interface/AddOns/SomeOtherAddon/KeybindConflict.lua:42, the parser walked past it
--- and returned SomeOtherAddon / Main.lua / 7 -- the addon name survived while the
--- file and line pointed at the wrong place inside it, which is the worst shape of
--- wrong because it looks specific. The addon folder is part of the identity.
---
--- The match is separator-insensitive by normalising the LINE rather than by
--- carrying a second backslash-spelled constant, which is the same normalisation
--- the captures below already do and keeps one constant to keep correct.
---
--- THE ADDON FOLDER COMES FROM ADDON_NAME, not from a literal, and that is a
--- correctness requirement rather than tidiness. A stack frame carries the
--- FOLDER the addon is installed under. Hardcoding "GRIP-EMS" means that under a
--- folder named anything else -- a manual install, a second checkout, a packager
--- suffix -- the self frame stops matching, the skip stops firing, and the module
--- attributes every binding call in the session to its own file again. That is
--- precisely the blocker Phase 2-polish fixed, and it would come back SILENTLY:
--- no error, no missing capability, just a panel confidently naming GRIP-EMS as
--- the caller of everything.
KC.ATTRIBUTION_SELF_FILE = ADDON_NAME .. "/Engine/KeybindConflict.lua"

--- One row per hooked global. keyIndex / targetIndex / priorityIndex are ARGUMENT
--- POSITIONS, and they differ between the two families rather than being a
--- convention: the override family is (owner, isPriority, key, target) while the
--- base family is (key, target, ...) with no owner and no priority at all.
---
--- Every name here is hooked BY STRING, exactly as Engine/Transmission.lua hooks
--- SetItemRef. Hooking by string means this module never reads one of these as a
--- bare global, so none of them needs a .luacheckrc or wow.toml entry.
---
--- ClearOverrideBindings is deliberately ABSENT from this list: it invalidates
--- records rather than creating them, so it is hooked separately below.
KC.ATTRIBUTION_HOOKS = {
    { name = "SetOverrideBinding", layer = "override", keyIndex = 3, priorityIndex = 2, targetIndex = 4 },
    { name = "SetOverrideBindingClick", layer = "override", keyIndex = 3, priorityIndex = 2, targetIndex = 4 },
    { name = "SetOverrideBindingItem", layer = "override", keyIndex = 3, priorityIndex = 2, targetIndex = 4 },
    { name = "SetOverrideBindingSpell", layer = "override", keyIndex = 3, priorityIndex = 2, targetIndex = 4 },
    { name = "SetOverrideBindingMacro", layer = "override", keyIndex = 3, priorityIndex = 2, targetIndex = 4 },
    { name = "SetBinding", layer = "base", keyIndex = 1, targetIndex = 2 },
    { name = "SetBindingClick", layer = "base", keyIndex = 1, targetIndex = 2 },
    { name = "SetBindingItem", layer = "base", keyIndex = 1, targetIndex = 2 },
    { name = "SetBindingSpell", layer = "base", keyIndex = 1, targetIndex = 2 },
    { name = "SetBindingMacro", layer = "base", keyIndex = 1, targetIndex = 2 },
    { name = "SetModifiedClick", layer = "modifier", actionIndex = 1, valueIndex = 2 },
}

-- Hooked on its own because it is the only one that INVALIDATES. Kept file-local
-- rather than added to the descriptor list so no loop over that list has to carry
-- an "except this one" branch.
local CLEAR_OVERRIDE_HOOK = "ClearOverrideBindings"

--- Machine-readable limit tokens, the same shape as the NOTE_REASON_ constants
--- above: no prose and no locale keys, because the Phase 3 panel owns the copy.
--- A caller that renders these is telling the user the truth about what
--- attribution can and cannot see, which is the entire point of publishing them.
KC.ATTRIBUTION_LIMITS = {
    -- A hook sees only calls made AFTER it installs. Any addon that bound during
    -- its own load, before GRIP-EMS loaded, is invisible here.
    hooksInstalledAtLoad = "hooks_installed_at_load",
    -- A restricted-environment SetBindingClick inside a secure snippet is a
    -- DIFFERENT function from the global of the same name, so it never reaches
    -- these hooks. GRIP-EMS binds its own sequence keys that way and so does any
    -- other addon using the technique. GetBindingAction still DETECTS those
    -- bindings; only the name is missing.
    secureHandlerInvisible = "secure_handler_bindings_invisible",
    -- A post-hook fires whether or not the call took effect. A record proves who
    -- CALLED, not who WON.
    attemptsNotOwnership = "records_attempts_not_ownership",
    -- The dedup in the recorder means a repeated identical bind keeps the stack of
    -- the FIRST caller, not the most recent one. This holds ACROSS a clear: a
    -- record resurrected by the SAME OWNER's identical call after a
    -- ClearOverrideBindings still carries the original caller's stack, with
    -- reacquired counting the returns. A different owner never resurrects a record,
    -- so this token never means "the stack belongs to a different addon".
    dedupFirstCaller = "deduplicated_stack_is_first_caller",
    -- Reported only when the key budget refused a new bucket.
    keyBudgetExhausted = "key_budget_exhausted",
}

--- A fresh, empty attribution state.
---
--- This exists so a spec can install hooks into ITS OWN buffer and never touch
--- production state -- the same escape deps.refresh already gives
--- KC.ProbeCapabilities. Pass it as deps.state. Optional state.ringSize and
--- state.maxKeys override the module constants for that buffer only.
--- @return table
function KC.NewAttributionState()
    return {
        installed = false,
        installedAt = nil,
        hooked = {},
        missing = {},
        byKey = {},
        keyCount = 0,
        truncated = false,
        modifiedClick = {},
    }
end

--- Resolve the buffer a call should read or write: an injected one wins, otherwise
--- the production one, created on first use.
--- @param deps table|nil Injected dependency overrides
--- @return table
local function resolveAttributionState(deps)
    if deps and deps.state then
        return deps.state
    end
    if not KC._attribution then
        KC._attribution = KC.NewAttributionState()
    end
    return KC._attribution
end

--- Shallow copy of a list, so a published summary hands out its own tables rather
--- than live internals a caller could mutate.
local function copyList(list)
    local out = {}
    for index = 1, #list do
        out[index] = list[index]
    end
    return out
end

--- Shallow copy of one record, for the same reason copyList exists.
---
--- Shallow is the right depth and not a shortcut: every stored field is a string,
--- a number, a boolean or the owner FRAME, and the frame must stay the same object
--- because ClearOverrideBindings matches owners by identity. Deep-copying it would
--- silently break that match.
local function copyRecord(record)
    local out = {}
    for field, value in pairs(record) do
        out[field] = value
    end
    return out
end

--- Resolve the buffer a READER should look at. Unlike resolveAttributionState this
--- never creates one, and it honours deps.strict.
---
--- STRICT MEANS STRICT, the same way it does for every other dep in this module: a
--- spec asserting the degraded path must not be able to pass by quietly reading
--- production data. Before this existed, KC.GetAttribution({ strict = true }) fell
--- straight through to KC._attribution and returned real records.
--- @param deps table|nil Injected dependency overrides
--- @return table|nil
local function readerAttributionState(deps)
    if deps then
        if deps.state then
            return deps.state
        end
        if deps.strict then
            return nil
        end
    end
    return KC._attribution
end

--- Parse the first addon frame out of a debugstack capture.
---
--- Pure string work: it touches no global, which is what makes it the one function
--- in this section that is trivially testable against a verbatim measured fixture.
---
--- The tolerances are deliberate, not defensive padding:
---   * leading [C] frames are skipped. The first frame is always the hooked
---     function itself and names no caller.
---   * FRAMES FROM THIS MODULE'S OWN FILE ARE SKIPPED, and this one is load
---     bearing rather than tidy. Before it existed, every single record on the live
---     client attributed to GRIP-EMS / Engine/KeybindConflict.lua, because the
---     capture starts inside captureCaller and this function returns the FIRST
---     Interface/AddOns frame it sees. Widening the frame budget does NOT fix that
---     on its own -- measured at 20 frames on the live client, the answer was still
---     this file. The two fixes only work together.
---   * both / and \ separate path components.
---   * the path is accepted bare OR wrapped in square brackets. The research
---     record captured the bracketed rendering and the bare one is the more
---     common; guessing which is live is not acceptable when handling both costs
---     one alternation.
---   * the function name is accepted as 'Name', as `Name' and as "Name".
---   * a frame with a readable path but NO parseable function name still returns
---     addon, file and line with funcName nil. Losing the whole frame over a
---     missing function name would discard the part the panel actually needs.
--- Returns nil rather than a guess when no frame matches Interface/AddOns/<Name>/.
--- @param stack string|nil A debugstack capture
--- @return string|nil addon, string|nil file, number|nil line, string|nil funcName
function KC.ParseCallerFromStack(stack)
    if type(stack) ~= "string" or stack == "" then
        return nil
    end
    for rawLine in string.gmatch(stack, "[^\r\n]+") do
        -- A [C] frame can never carry an AddOns path, so that half is a documented
        -- guard rather than a filter that changes any outcome. The self-file half
        -- DOES change the outcome on every real capture: see the note above, and
        -- the regression case built from the live capture in the spec's GROUP 10.
        --
        -- Separators are normalised BEFORE the find so a backslash-rendered frame is
        -- still recognised as self. Without this the qualified constant would only
        -- match forward-slash renderings, which would make the skip silently
        -- one-sided rather than obviously broken.
        local normalisedLine = string.gsub(rawLine, "\\", "/")
        local isSelf = string.find(normalisedLine, KC.ATTRIBUTION_SELF_FILE, 1, true) ~= nil
        if not isSelf and not string.match(rawLine, "^%s*%[C%]") then
            local addon = string.match(rawLine, "Interface[/\\]+AddOns[/\\]+([^/\\%]]+)[/\\]")
            local file, lineText = string.match(rawLine, "Interface[/\\]+AddOns[/\\]+[^/\\]+[/\\]([^%]:]-)%]?:(%d+):")
            if addon and file and file ~= "" then
                local funcName = string.match(rawLine, "in function '([^']+)'")
                    or string.match(rawLine, "in function `([^']+)'")
                    or string.match(rawLine, 'in function "([^"]+)"')
                -- Separators are normalised so a bracketed forward-slash capture
                -- and a bare backslash capture of the same frame are equal.
                return (string.gsub(addon, "\\", "/")), (string.gsub(file, "\\", "/")), tonumber(lineText), funcName
            end
        end
    end
    return nil
end

--- Capture a stack and parse it, degrading to all-nil when debugstack is absent.
--- @return string|nil stack, string|nil addon, string|nil file, number|nil line, string|nil funcName
local function captureCaller(deps)
    local debugStack = dep(deps, "debugstack")
    if type(debugStack) ~= "function" then
        return nil
    end
    local ok, captured = pcall(debugStack, KC.ATTRIBUTION_STACK_LEVEL, KC.ATTRIBUTION_STACK_FRAMES, 0)
    if not ok or type(captured) ~= "string" or captured == "" then
        return nil
    end
    local addon, file, line, funcName = KC.ParseCallerFromStack(captured)
    return captured, addon, file, line, funcName
end

--- Read the clock, or nil when it is unavailable. Never raises.
local function attributionNow(deps)
    local getTime = dep(deps, "GetTime")
    if type(getTime) ~= "function" then
        return nil
    end
    local ok, value = pcall(getTime)
    if ok and type(value) == "number" then
        return value
    end
    return nil
end

--- Record one SetModifiedClick call.
---
--- Routed here and NOT into the key ring because the second argument is a modifier
--- value such as SHIFT, not a binding key. Storing it under the key space would put
--- a bare modifier where canonical keys live and corrupt every later lookup.
--- Keyed by ACTION name, one most-recent record each.
local function recordModifiedClick(state, row, deps, ...)
    local args = { ... }
    local action = args[row.actionIndex]
    if type(action) ~= "string" or action == "" then
        return
    end
    action = string.upper(action)
    local value = args[row.valueIndex]
    local existing = state.modifiedClick[action]
    if existing and existing.value == value then
        -- Same value again: refresh without paying for another stack walk, the
        -- same bargain the key ring makes.
        existing.count = (existing.count or 1) + 1
        existing.time = attributionNow(deps)
        return
    end
    local stack, addon, file, line, funcName = captureCaller(deps)
    state.modifiedClick[action] = {
        fn = row.name,
        layer = row.layer,
        action = action,
        value = value,
        addon = addon,
        file = file,
        line = line,
        func = funcName,
        stack = stack,
        time = attributionNow(deps),
        count = 1,
    }
end

--- Record one binding call. Called only from inside a pcall.
---
--- THE DEDUP KEEPS THE RING USEFUL. The newest record for the key is compared
--- FIRST, and an identical (fn, target, isPriority, owner) call only bumps a
--- counter and refreshes the timestamp -- INCLUDING when that record was cleared,
--- which is the clear-then-rebind cycle a bar-paging addon actually produces. Only
--- a genuinely new call pays for a capture and consumes a ring slot, and a
--- DIFFERENT owner is always a genuinely new call. The cost of that bargain is
--- published as the dedupFirstCaller limit token: a repeated bind keeps the FIRST
--- caller's stack.
---
--- The sentence above was FALSE as shipped in Phase 2, and it is worth saying so
--- rather than quietly correcting it. Cleared records were excluded from the dedup,
--- so every clear-then-rebind cycle captured a fresh stack and consumed a ring
--- slot, and four such cycles left the four-slot ring holding four near-identical
--- records instead of the last few distinct callers. The panel would have rendered
--- four duplicate rows. See the resurrection branch below for the measurement.
local function recordBindingCall(state, row, deps, ...)
    if row.actionIndex then
        return recordModifiedClick(state, row, deps, ...)
    end
    local args = { ... }
    local rawKey = args[row.keyIndex]
    -- Stored under the CANONICAL form so the ring is keyed exactly the way
    -- KC.CheckKey queries it. A key that does not canonicalise is dropped rather
    -- than stored raw, because a raw entry could never be found again.
    local canonical = KC.CanonicalizeKey(rawKey)
    if not canonical then
        return
    end
    local target = args[row.targetIndex]
    local owner, isPriority
    if row.priorityIndex then
        -- Override family only: arg 1 is the owner frame, arg 2 the priority flag.
        -- Holding the frame reference leaks NOTHING -- WoW frames are never garbage
        -- collected -- and it is what lets the ClearOverrideBindings hook match by
        -- identity. Do not "fix" this into a name string; the match would break.
        owner = args[1]
        isPriority = args[row.priorityIndex]
    end

    local ringSize = state.ringSize or KC.ATTRIBUTION_RING_SIZE
    local bucket = state.byKey[canonical]
    if not bucket then
        -- THE CAP REFUSES NEW BUCKETS RATHER THAN EVICTING OLD ONES. Evicting a
        -- bucket the user is already looking at, to make room for one they are not,
        -- is the worse failure. Existing buckets keep recording; only the budget
        -- flag changes, and it is published as a limit token.
        if state.keyCount >= (state.maxKeys or KC.ATTRIBUTION_MAX_KEYS) then
            state.truncated = true
            return
        end
        bucket = { records = {}, cursor = 0 }
        state.byKey[canonical] = bucket
        state.keyCount = state.keyCount + 1
    end

    -- OWNER IS PART OF THE DEDUP KEY, and leaving it out was a real defect rather
    -- than a missing nicety. MEASURED headless: AddonA binds key 1 with frameA onto
    -- ActionButton1 at priority true, AddonA calls ClearOverrideBindings(frameA),
    -- then AddonB binds the SAME key onto the SAME target at the SAME priority with
    -- frameB. The bucket held ONE record, naming AddonA and carrying frameA, with
    -- cleared false and reacquired 1 -- AddonB held the key and the record credited
    -- AddonA. It compounded: a later ClearOverrideBindings(frameA), from the addon
    -- that no longer held the key, matched that stale owner and marked the record
    -- released, so a live binding read as cleared. Both halves wrong at once, who
    -- owns it and whether it is live.
    --
    -- TWO ADDONS OVERRIDING ONE KEY ONTO ONE BUTTON IS THE ORDINARY SHAPE OF THE
    -- CONFLICT THIS MODULE EXISTS TO REPORT, so the defect sat precisely in the
    -- scenario the feature is for.
    --
    -- The owner-blindness predates the resurrection: the Phase 2 dedup already let
    -- B's identical triple bump A's count on the non-cleared path. Resurrection only
    -- extended it into the one path the cleared-record exclusion had accidentally
    -- kept correct. One comparison closes both, which is why it belongs HERE on the
    -- comparison and not inside the resurrection branch.
    --
    -- IT COSTS THE DEDUP NOTHING. A paging addon reuses one owner frame across every
    -- cycle, so owner matches and the clear-then-rebind saving Phase 2-polish
    -- restored is untouched. For the base family owner is nil on both sides, so nil
    -- equals nil and those rows dedup exactly as before -- treating a nil owner as a
    -- mismatch would break every base-family dedup instead.
    local newest = bucket.records[bucket.cursor]
    if
        newest
        and newest.fn == row.name
        and newest.target == target
        and newest.isPriority == isPriority
        and newest.owner == owner
    then
        -- A CLEARED record matching on all four -- fn, target, isPriority AND owner
        -- -- is RESURRECTED here, not skipped. The owner term is what makes that
        -- safe: only the addon that released the key can revive its own record, and
        -- a different addon binding the identical target opens its own.
        --
        -- The first version of this excluded cleared records, reasoning that a bind
        -- after a release is a new acquisition rather than a repeat. That reasoning
        -- was right about the SEMANTICS and it defeated the dedup entirely.
        -- MEASURED headless against the shipped code: fifty rebinds of one key with
        -- no clear between them cost ONE debugstack call; fifty clear-then-rebind
        -- cycles -- which is the pattern a bar-paging addon actually produces --
        -- cost FIFTY, and filled the four-slot ring with four near-identical
        -- records instead of the last few DISTINCT callers this ring exists to
        -- hold. The Phase 3 panel would have rendered four duplicate rows.
        --
        -- Resurrection keeps the semantics the original argued for. The key IS live
        -- again and the record says so: cleared goes back to false and clearedAt is
        -- dropped, so nothing reports a live key as released. What is no longer
        -- lost is the release history -- reacquired counts how many times this
        -- exact owner brought this exact binding back after a clear, which is a more
        -- useful signal than four indistinguishable ring entries.
        --
        -- Scale, so nobody over-corrects this later: debugstack measured 3.92
        -- microseconds on the live client, about 47 microseconds per twelve-key
        -- page change. That was never a frame-rate problem. The ring contents were
        -- the problem.
        if newest.cleared then
            newest.cleared = false
            newest.clearedAt = nil
            newest.reacquired = (newest.reacquired or 0) + 1
        end
        newest.count = (newest.count or 1) + 1
        newest.time = attributionNow(deps)
        return
    end

    local stack, addon, file, line, funcName = captureCaller(deps)
    bucket.cursor = (bucket.cursor % ringSize) + 1
    bucket.records[bucket.cursor] = {
        fn = row.name,
        layer = row.layer,
        key = canonical,
        rawKey = rawKey,
        isPriority = isPriority,
        target = target,
        owner = owner,
        addon = addon,
        file = file,
        line = line,
        func = funcName,
        stack = stack,
        time = attributionNow(deps),
        count = 1,
        cleared = false,
        -- Always present rather than appearing only after the first resurrection,
        -- so a renderer never has to distinguish "never reacquired" from "field
        -- absent on an older record".
        reacquired = 0,
    }
end

--- Mark every override record belonging to this owner frame as released.
---
--- A cleared record is a key the addon LET GO of. Reporting its owner as the
--- current holder would send the user chasing an addon that is no longer involved.
--- The record is marked rather than deleted, because "who released this, and when"
--- is the useful half of the fact. If the same owner rebinds the same target, the
--- recorder RESURRECTS this record instead of writing a new one -- see the dedup.
local function recordClearOverrides(state, deps, owner)
    if owner == nil then
        return
    end
    local clearedAt = attributionNow(deps)
    for _, bucket in pairs(state.byKey) do
        for _, record in ipairs(bucket.records) do
            if record.layer == "override" and record.owner == owner and not record.cleared then
                record.cleared = true
                record.clearedAt = clearedAt
            end
        end
    end
end

--- Build the closure hooksecurefunc will call. The ENTIRE body is inside a pcall:
--- this runs on every binding call in the session, and a hook that can raise turns
--- someone else's working keybind into a Lua error.
local function makeRecorder(state, row, deps)
    return function(...)
        pcall(recordBindingCall, state, row, deps, ...)
    end
end

--- Install the attribution hooks. Returns the state it wrote into.
---
--- IDEMPOTENT BY CONTRACT. hooksecurefunc cannot be undone, so a second install
--- would double every record for the rest of the session. An already-installed
--- state returns immediately.
---
--- Degrades rather than raising, in three separate places: hooksecurefunc itself
--- may be absent (headless, or a stripped environment), an individual global may be
--- absent (hooksecurefunc RAISES on a missing global, and a raise at file load
--- would take the whole module down), and the hook call itself is pcall'd. Anything
--- not hooked is named on state.missing rather than silently skipped.
--- @param deps table|nil Injected dependency overrides; deps.state selects a buffer
--- @return table state
function KC.InstallAttributionHooks(deps)
    local state = resolveAttributionState(deps)
    if state.installed then
        return state
    end
    -- Rebuilt on every attempt rather than appended to, so a retry after a failed
    -- install cannot leave duplicate names on either list.
    local hooked, missing = {}, {}
    local hookFn = dep(deps, "hooksecurefunc")
    if type(hookFn) ~= "function" then
        for _, row in ipairs(KC.ATTRIBUTION_HOOKS) do
            missing[#missing + 1] = row.name
        end
        missing[#missing + 1] = CLEAR_OVERRIDE_HOOK
        state.hooked = hooked
        state.missing = missing
        return state
    end
    for _, row in ipairs(KC.ATTRIBUTION_HOOKS) do
        if type(dep(deps, row.name)) == "function" then
            if pcall(hookFn, row.name, makeRecorder(state, row, deps)) then
                hooked[#hooked + 1] = row.name
            else
                missing[#missing + 1] = row.name
            end
        else
            missing[#missing + 1] = row.name
        end
    end
    if type(dep(deps, CLEAR_OVERRIDE_HOOK)) == "function" then
        local clearHook = function(owner)
            pcall(recordClearOverrides, state, deps, owner)
        end
        if pcall(hookFn, CLEAR_OVERRIDE_HOOK, clearHook) then
            hooked[#hooked + 1] = CLEAR_OVERRIDE_HOOK
        else
            missing[#missing + 1] = CLEAR_OVERRIDE_HOOK
        end
    else
        missing[#missing + 1] = CLEAR_OVERRIDE_HOOK
    end
    state.hooked = hooked
    state.missing = missing
    -- Installed means at least one hook actually landed. Flagging a run that hooked
    -- nothing as installed would block the retry that might succeed later.
    state.installed = #hooked > 0
    if state.installed then
        state.installedAt = attributionNow(deps)
    end
    return state
end

--- Publish what attribution can and cannot see.
---
--- The first four limit tokens are STRUCTURAL and therefore always present: they
--- describe the technique, not this session. key_budget_exhausted is conditional.
--- The lists are copies, so a renderer cannot mutate the live state through them.
--- deps.strict with no deps.state reports the empty, not-installed shape rather
--- than falling through to the production buffer.
--- @param deps table|nil Injected dependency overrides; deps.state selects a buffer
--- @return table { installed, installedAt, hooked, missing, truncated, keyCount, limits }
function KC.GetAttributionState(deps)
    local state = readerAttributionState(deps)
    local limits = {
        KC.ATTRIBUTION_LIMITS.hooksInstalledAtLoad,
        KC.ATTRIBUTION_LIMITS.secureHandlerInvisible,
        KC.ATTRIBUTION_LIMITS.attemptsNotOwnership,
        KC.ATTRIBUTION_LIMITS.dedupFirstCaller,
    }
    local truncated = (state ~= nil and state.truncated) or false
    if truncated then
        limits[#limits + 1] = KC.ATTRIBUTION_LIMITS.keyBudgetExhausted
    end
    return {
        installed = (state ~= nil and state.installed) or false,
        installedAt = state and state.installedAt or nil,
        hooked = copyList((state and state.hooked) or {}),
        missing = copyList((state and state.missing) or {}),
        truncated = truncated,
        keyCount = (state and state.keyCount) or 0,
        limits = limits,
    }
end

--- Every recorded call for one key, NEWEST FIRST.
---
--- nil means NOTHING WAS RECORDED. That is NOT the same as "nothing owns it": the
--- hooks were installed at load and cannot see a bind made before then, and they
--- never see a secure-handler bind at all. A caller that reads nil as "this key is
--- free" has inverted the meaning of the whole section. Ask KC.CheckKey what owns
--- a key; ask this what was seen being called.
---
--- The records are COPIES. KC.GetAttributionState has always copied its lists for
--- exactly this reason; this function handed out live buffer entries, so a caller
--- that adjusted a field on a returned record was editing the ring. Phase 3 is the
--- first consumer and has not been written, which makes this the moment to fix it
--- rather than after something depends on the aliasing.
--- @param key string Key string, any casing, any modifier order
--- @param deps table|nil Injected dependency overrides; deps.state selects a buffer
--- @return table|nil records Newest first, or nil when the key has no bucket
function KC.GetAttribution(key, deps)
    local state = readerAttributionState(deps)
    if not state then
        return nil
    end
    local canonical = KC.CanonicalizeKey(key)
    if not canonical then
        return nil
    end
    local bucket = state.byKey[canonical]
    if not bucket then
        return nil
    end
    local size = #bucket.records
    if size == 0 then
        return nil
    end
    local out = {}
    local index = bucket.cursor
    for _ = 1, size do
        local record = bucket.records[index]
        if record then
            out[#out + 1] = copyRecord(record)
        end
        index = index - 1
        if index < 1 then
            index = size
        end
    end
    return out
end

-- ===========================================================================
-- Severity scale
-- ===========================================================================

--- The four severities RepairFrame already renders, mapped to themselves so a
--- later phase reuses that rendering instead of inventing a second scale.
KC.SEVERITY = {
    critical = "critical",
    error = "error",
    warning = "warning",
    info = "info",
}

-- Install at FILE LOAD, deliberately, and this must remain the LAST statement in
-- the file -- everything it touches has to already exist.
--
-- WHY LOAD AND NOT AN EVENT. The .toc loads this file at line 88, which is before
-- every addon that loads after GRIP-EMS. Waiting for PLAYER_LOGIN would miss
-- nearly all of them, and an addon that bound before the hook installed is exactly
-- the case the hooksInstalledAtLoad limit token exists to admit to. Earlier is
-- strictly more coverage.
--
-- Under the headless driver hooksecurefunc does not exist, so this returns a state
-- with installed = false, names every hook on state.missing, and changes nothing.
KC.InstallAttributionHooks()
