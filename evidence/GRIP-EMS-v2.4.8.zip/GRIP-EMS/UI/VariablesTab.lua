-- GRIP-EMS: VariablesTab
-- Created: 2026-03-19
-- Updated: 2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.

-- GRIP-EMS: Variables Tab
-- Account-wide variable editor: list, editor, validation, and test

local ADDON_NAME, GRIPEMS = ...
local UI = GRIPEMS.UI
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

-- Upvalue accessor for Defaults
local function D()
    return GRIPEMS.Defaults
end

GRIPEMS.VariablesTab = {}
local VT = GRIPEMS.VariablesTab

-- Runtime state
VT.selectedVar = nil -- currently selected variable name

-- Insert Helper picker entries. Each entry inserts a Layer 1 condition
-- helper (see Engine/Conditions.lua) at the funcEdit cursor and, when
-- phStart is set, highlights the spellID placeholder so the user can
-- type the real ID over it. Module-local on purpose -- must not leak
-- onto the GRIPEMS namespace.
local HELPER_INSERTS = {
    {
        label = "HasBuff (player)",
        descKey = "GEMS_VAR_INSERT_HASBUFF_PLAYER_DESC",
        snippet = 'GRIPEMS.HasBuff(0, "player")',
        phStart = 16,
        phLen = 1,
    },
    {
        label = "HasBuff (target)",
        descKey = "GEMS_VAR_INSERT_HASBUFF_TARGET_DESC",
        snippet = 'GRIPEMS.HasBuff(0, "target")',
        phStart = 16,
        phLen = 1,
    },
    {
        label = "HasDebuff (player)",
        descKey = "GEMS_VAR_INSERT_HASDEBUFF_PLAYER_DESC",
        snippet = 'GRIPEMS.HasDebuff(0, "player")',
        phStart = 18,
        phLen = 1,
    },
    {
        label = "HasDebuff (target)",
        descKey = "GEMS_VAR_INSERT_HASDEBUFF_TARGET_DESC",
        snippet = 'GRIPEMS.HasDebuff(0, "target")',
        phStart = 18,
        phLen = 1,
    },
    {
        label = "SpellReady",
        descKey = "GEMS_VAR_INSERT_SPELLREADY_DESC",
        snippet = "GRIPEMS.SpellReady(0)",
        phStart = 19,
        phLen = 1,
    },
    {
        label = "SpellOnCooldown",
        descKey = "GEMS_VAR_INSERT_SPELLONCD_DESC",
        snippet = "GRIPEMS.SpellOnCooldown(0)",
        phStart = 24,
        phLen = 1,
    },
    {
        label = "SpellEnabled",
        descKey = "GEMS_VAR_INSERT_SPELLENABLED_DESC",
        snippet = "GRIPEMS.SpellEnabled(0)",
        phStart = 21,
        phLen = 1,
    },
    {
        label = "IsRestricted",
        descKey = "GEMS_VAR_INSERT_ISRESTRICTED_DESC",
        snippet = "GRIPEMS.IsRestricted()",
        phStart = nil,
        phLen = nil,
    },
}

-- Lua keywords that cannot be the tail of an expression. When
-- the funcEdit text ends with one of these as a complete identifier,
-- the smart-concat branch in VT:InsertHelper suppresses the " and "
-- prepend because the result would be invalid Lua (e.g.
-- "function() ... end and X" is a syntax error).
--
-- Note: `false`, `true`, `nil` are NOT in this set -- they ARE
-- valid expression tails (e.g. "false and X" is valid Lua and
-- short-circuits). Only block-closing or non-expression keywords
-- get suppressed.
local NON_EXPR_TAIL_KEYWORDS = {
    ["end"] = true,
    ["do"] = true,
    ["then"] = true,
    ["else"] = true,
    ["elseif"] = true,
    ["repeat"] = true,
    ["until"] = true,
    ["function"] = true,
    ["return"] = true,
    ["and"] = true,
    ["or"] = true,
    ["not"] = true,
    ["in"] = true,
    ["goto"] = true,
    ["break"] = true,
    ["if"] = true,
    ["for"] = true,
    ["while"] = true,
    ["local"] = true,
}

--- Detect if the EditBox text has an unclosed Lua long comment.
--- Walks the text once, tracking leveled long-bracket openings of the
--- form `--[=*[` and matching closes of the form `]=*]` with the same
--- equal-sign count. Returns true if the cursor would be inside any
--- unclosed long comment at end of text.
--- @param text string The full EditBox text
--- @return boolean true if the cursor is inside an unclosed long comment
local function isInLongComment(text)
    local n = #text
    local i = 1
    local openLevel = nil
    while i <= n do
        local c = text:sub(i, i)
        if openLevel == nil then
            if c == "-" and text:sub(i + 1, i + 1) == "-" and text:sub(i + 2, i + 2) == "[" then
                local j = i + 3
                local eqCount = 0
                while j <= n and text:sub(j, j) == "=" do
                    eqCount = eqCount + 1
                    j = j + 1
                end
                if j <= n and text:sub(j, j) == "[" then
                    openLevel = eqCount
                    i = j + 1
                else
                    i = i + 1
                end
            else
                i = i + 1
            end
        else
            if c == "]" then
                local j = i + 1
                local eqCount = 0
                while j <= n and text:sub(j, j) == "=" do
                    eqCount = eqCount + 1
                    j = j + 1
                end
                if j <= n and text:sub(j, j) == "]" and eqCount == openLevel then
                    openLevel = nil
                    i = j + 1
                else
                    i = i + 1
                end
            else
                i = i + 1
            end
        end
    end
    return openLevel ~= nil
end

--- Find the position of a real Lua line comment marker `--` in a
--- single line, ignoring `--` that appears inside string literals
--- (both "..." and '...' forms). Walks the line as a small state
--- machine tracking double-quote and single-quote nesting; honors
--- backslash-escapes inside strings.
--- @param line string A single line (no newlines)
--- @return number|nil 1-based position of the first real `--`, or nil
local function findRealLineComment(line)
    local i = 1
    local n = #line
    local inDoubleQuote = false
    local inSingleQuote = false
    while i <= n - 1 do
        local c = line:sub(i, i)
        if c == "\\" and (inDoubleQuote or inSingleQuote) and i < n then
            -- Skip escaped char inside a string
            i = i + 2
        elseif c == '"' and not inSingleQuote then
            inDoubleQuote = not inDoubleQuote
            i = i + 1
        elseif c == "'" and not inDoubleQuote then
            inSingleQuote = not inSingleQuote
            i = i + 1
        elseif c == "-" and line:sub(i + 1, i + 1) == "-" and not inDoubleQuote and not inSingleQuote then
            return i
        else
            i = i + 1
        end
    end
    return nil
end

---------------------------------------------------------------------------
-- Initialization
---------------------------------------------------------------------------

--- Build the variables tab UI inside the given parent frame (content area).
--- @param parentFrame Frame The content area that hosts tab content
function VT:Init(parentFrame)
    if not parentFrame then
        return
    end
    local C = UI.Colors

    VT.container = parentFrame

    -- Main frame that holds everything
    local frame = CreateFrame("Frame", nil, parentFrame)
    frame:SetAllPoints(parentFrame)
    frame:Hide()
    VT.frame = frame
    -- Phase C: expose this tab root as the mountable "variables" panel.
    if GRIPEMS.RegisterMountablePanel then
        GRIPEMS:RegisterMountablePanel("variables", VT.frame)
    end
    if GRIPEMS.UI and GRIPEMS.UI.RegisterElement then
        GRIPEMS.UI:RegisterElement(frame, "panel.variables")
    end

    -- Empty state label (centered, shown when no variables exist)
    local emptyLabel = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(emptyLabel, 11)
    emptyLabel:SetPoint("CENTER", frame, "CENTER", 0, 0)
    emptyLabel:SetText(L["GEMS_VAR_TAB_EMPTY"])
    emptyLabel:SetTextColor(C.textMuted:GetRGBA())
    VT.emptyLabel = emptyLabel

    -------------------------------------------------------------------
    -- Left side: Variable list (ScrollBox + New button)
    -------------------------------------------------------------------
    local listPanel = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    listPanel:SetWidth(D().VAR_LIST_WIDTH)
    listPanel:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, 0)
    listPanel:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 0, 0)
    UI:ApplyBackdrop(listPanel, UI.Backdrops.panel, C.bgDeep, C.border)
    VT.listPanel = listPanel

    -- ScrollBox for variable names
    local scrollBox = CreateFrame("Frame", nil, listPanel, "WoWScrollBoxList")
    scrollBox:SetPoint("TOPLEFT", listPanel, "TOPLEFT", 1, -1)
    scrollBox:SetPoint("BOTTOMRIGHT", listPanel, "BOTTOMRIGHT", -17, D().KEY_CAPTURE_BUTTON_HEIGHT + 8)
    VT.scrollBox = scrollBox

    -- ScrollBar
    local scrollBar = CreateFrame("EventFrame", nil, listPanel, "MinimalScrollBar")
    scrollBar:SetPoint("TOPLEFT", scrollBox, "TOPRIGHT", 2, -2)
    scrollBar:SetPoint("BOTTOMLEFT", scrollBox, "BOTTOMRIGHT", 2, 2)
    VT.scrollBar = scrollBar

    -- DataProvider + ScrollView
    local scrollView = CreateScrollBoxListLinearView()
    scrollView:SetElementExtent(D().VAR_EDITOR_ROW_HEIGHT)
    scrollView:SetElementInitializer("Button", function(button, data)
        VT:InitListRow(button, data)
    end)
    ScrollUtil.InitScrollBoxListWithScrollBar(scrollBox, scrollBar, scrollView)
    VT.scrollView = scrollView

    -- "New" button at bottom of list area (parented to frame, not listPanel)
    local newBtn = UI:CreateButton(frame, L["GEMS_VAR_NEW"], D().VAR_LIST_WIDTH - 8, D().KEY_CAPTURE_BUTTON_HEIGHT)
    newBtn:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 4, 4)
    newBtn:SetScript("OnClick", function()
        VT:CreateNewVariable()
    end)
    newBtn:SetScript("OnEnter", function(self)
        UI:ShowTooltip(self, L["GEMS_VAR_NEW"], L["GEMS_VAR_NEW_DESC"])
        self:SetBackdropColor(C.bgRowHover:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
    end)
    newBtn:SetScript("OnLeave", function(self)
        GameTooltip:Hide()
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
    end)
    VT.newBtn = newBtn

    -------------------------------------------------------------------
    -- Right side: Variable editor
    -------------------------------------------------------------------
    local editorPanel = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    editorPanel:SetPoint("TOPLEFT", listPanel, "TOPRIGHT", 0, 0)
    editorPanel:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", 0, 0)
    UI:ApplyBackdrop(editorPanel, UI.Backdrops.panel, C.bgPanel, C.border)
    editorPanel:Hide()
    VT.editorPanel = editorPanel

    local yOff = -8
    local fontPath = GRIPEMS.UI:GetFontPath()

    -- Name label + EditBox
    local nameLabel = editorPanel:CreateFontString(nil, "OVERLAY")
    UI:SetFont(nameLabel, 10)
    nameLabel:SetPoint("TOPLEFT", editorPanel, "TOPLEFT", 8, yOff)
    nameLabel:SetText(L["GEMS_VAR_NAME_LABEL"])
    nameLabel:SetTextColor(C.textSecondary:GetRGBA())

    local nameEdit = CreateFrame("EditBox", nil, editorPanel, "BackdropTemplate")
    nameEdit:SetHeight(D().NAME_EDITBOX_HEIGHT)
    nameEdit:SetPoint("TOPLEFT", nameLabel, "BOTTOMLEFT", 0, -2)
    nameEdit:SetPoint("RIGHT", editorPanel, "RIGHT", -8, 0)
    nameEdit:SetAutoFocus(false)
    UI:ApplyBackdrop(nameEdit, UI.Backdrops.panel, C.bgInput, C.border)
    nameEdit:SetTextInsets(6, 6, 2, 2)
    nameEdit:SetFont(fontPath, 12, "")
    nameEdit:SetTextColor(C.textPrimary:GetRGBA())
    nameEdit:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
    end)
    nameEdit:SetScript("OnEnterPressed", function(self)
        self:ClearFocus()
    end)
    nameEdit:SetScript("OnEditFocusGained", function(self)
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
    end)
    nameEdit:SetScript("OnEditFocusLost", function(self)
        self:SetBackdropBorderColor(C.border:GetRGBA())
    end)
    VT.nameEdit = nameEdit
    GRIPEMS.Focus:HookEditBox(nameEdit)

    -- Locale warning banner (between nameEdit and funcLabel)
    local localeWarnBanner = CreateFrame("Frame", nil, editorPanel, "BackdropTemplate")
    localeWarnBanner:SetHeight(0)
    localeWarnBanner:SetPoint("TOPLEFT", nameEdit, "BOTTOMLEFT", 0, -2)
    localeWarnBanner:SetPoint("RIGHT", editorPanel, "RIGHT", -8, 0)
    UI:ApplyBackdrop(localeWarnBanner, UI.Backdrops.panelNoBorder, C.bgInput)
    localeWarnBanner:EnableMouse(false)
    localeWarnBanner:Hide()
    VT.localeWarnBanner = localeWarnBanner

    local lwIcon = localeWarnBanner:CreateTexture(nil, "ARTWORK")
    lwIcon:SetSize(16, 16)
    lwIcon:SetPoint("LEFT", localeWarnBanner, "LEFT", 4, 0)
    lwIcon:SetTexture("Interface\\DialogFrame\\UI-Dialog-Icon-AlertNew")

    local lwText = localeWarnBanner:CreateFontString(nil, "OVERLAY")
    UI:SetFont(lwText, 11)
    lwText:SetPoint("LEFT", lwIcon, "RIGHT", 4, 0)
    lwText:SetPoint("RIGHT", localeWarnBanner, "RIGHT", -4, 0)
    lwText:SetJustifyH("LEFT")
    lwText:SetWordWrap(false)
    lwText:SetTextColor(C.textWarning:GetRGBA())
    VT.localeWarnText = lwText

    -- Private-aura warning banner (below localeWarnBanner; can co-display)
    local privateAuraBanner = CreateFrame("Frame", nil, editorPanel, "BackdropTemplate")
    privateAuraBanner:SetHeight(0)
    privateAuraBanner:SetPoint("TOPLEFT", localeWarnBanner, "BOTTOMLEFT", 0, -2)
    privateAuraBanner:SetPoint("RIGHT", editorPanel, "RIGHT", -8, 0)
    UI:ApplyBackdrop(privateAuraBanner, UI.Backdrops.panelNoBorder, C.bgInput)
    privateAuraBanner:EnableMouse(false)
    privateAuraBanner:Hide()
    VT.privateAuraBanner = privateAuraBanner

    local paIcon = privateAuraBanner:CreateTexture(nil, "ARTWORK")
    paIcon:SetSize(16, 16)
    paIcon:SetPoint("LEFT", privateAuraBanner, "LEFT", 4, 0)
    paIcon:SetTexture("Interface\\DialogFrame\\UI-Dialog-Icon-AlertNew")

    local paText = privateAuraBanner:CreateFontString(nil, "OVERLAY")
    UI:SetFont(paText, 11)
    paText:SetPoint("LEFT", paIcon, "RIGHT", 4, 0)
    paText:SetPoint("RIGHT", privateAuraBanner, "RIGHT", -4, 0)
    paText:SetJustifyH("LEFT")
    paText:SetWordWrap(false)
    paText:SetTextColor(C.textWarning:GetRGBA())
    VT.privateAuraText = paText

    yOff = yOff - 14 - D().NAME_EDITBOX_HEIGHT - 8

    -- Function Body label + MultiLine EditBox
    local funcLabel = editorPanel:CreateFontString(nil, "OVERLAY")
    UI:SetFont(funcLabel, 10)
    funcLabel:SetPoint("TOPLEFT", privateAuraBanner, "BOTTOMLEFT", 0, -2)
    funcLabel:SetText(L["GEMS_VAR_FUNC_LABEL"])
    funcLabel:SetTextColor(C.textSecondary:GetRGBA())
    funcLabel:EnableMouse(true)
    funcLabel:SetScript("OnEnter", function(self)
        UI:ShowTooltip(self, L["GEMS_VAR_FUNC_LABEL"], L["GEMS_VAR_FUNC_HELP"])
    end)
    funcLabel:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)

    -- Insert Helper button: anchored to the right of the funcLabel row
    -- (top-right of localeWarnBanner). Opens a picker of Layer 1 condition
    -- helpers and inserts the selected snippet at the funcEdit cursor.
    local insertHelperBtn = UI:CreateButton(editorPanel, L["GEMS_VAR_INSERT_HELPER"], 110, 18)
    insertHelperBtn:SetPoint("TOPRIGHT", localeWarnBanner, "BOTTOMRIGHT", -8, 4)
    insertHelperBtn:SetScript("OnClick", function(self)
        VT:ShowHelperPicker(self)
    end)
    insertHelperBtn:SetScript("OnEnter", function(self)
        UI:ShowTooltip(self, L["GEMS_VAR_INSERT_HELPER"], L["GEMS_VAR_INSERT_HELPER_TIP"])
        self:SetBackdropColor(C.bgRowHover:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
    end)
    insertHelperBtn:SetScript("OnLeave", function(self)
        GameTooltip:Hide()
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
    end)
    VT.insertHelperBtn = insertHelperBtn

    -- Container frame for function body (with backdrop)
    local funcContainer = CreateFrame("Frame", nil, editorPanel, "BackdropTemplate")
    funcContainer:SetHeight(D().VAR_FUNC_EDIT_HEIGHT)
    funcContainer:SetPoint("TOPLEFT", funcLabel, "BOTTOMLEFT", 0, -2)
    funcContainer:SetPoint("RIGHT", editorPanel, "RIGHT", -8, 0)
    UI:ApplyBackdrop(funcContainer, UI.Backdrops.panel, C.bgInput, C.border)

    -- ScrollFrame to make the EditBox scrollable
    local funcScroll = CreateFrame("ScrollFrame", nil, funcContainer, "UIPanelScrollFrameTemplate")
    funcScroll:SetPoint("TOPLEFT", funcContainer, "TOPLEFT", 4, -4)
    funcScroll:SetPoint("BOTTOMRIGHT", funcContainer, "BOTTOMRIGHT", -22, 4)
    UI:SkinLegacyScrollBar(funcScroll)

    local funcEdit = CreateFrame("EditBox", nil, funcScroll)
    funcEdit:SetWidth(funcScroll:GetWidth() or 200)
    funcEdit:SetMultiLine(true)
    funcEdit:SetAutoFocus(false)
    funcEdit:SetFont(fontPath, 11, "")
    funcEdit:SetTextColor(C.textPrimary:GetRGBA())
    funcEdit:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
    end)
    funcEdit:SetScript("OnEditFocusGained", function()
        funcContainer:SetBackdropBorderColor(C.borderFocus:GetRGBA())
    end)
    funcEdit:SetScript("OnEditFocusLost", function()
        funcContainer:SetBackdropBorderColor(C.border:GetRGBA())
        VT:ValidateFunctionBody()
    end)
    funcEdit:SetScript("OnTextChanged", function(self, userInput)
        if userInput then
            VT:ValidateFunctionBody()
        end
    end)
    funcScroll:SetScrollChild(funcEdit)
    funcScroll:SetScript("OnSizeChanged", function(self)
        local w = self:GetWidth()
        if w > 0 then
            funcEdit:SetWidth(w)
        end
    end)
    VT.funcEdit = funcEdit
    VT.funcContainer = funcContainer
    GRIPEMS.Focus:HookEditBox(funcEdit)

    -- Placeholder overlay for function body EditBox
    local funcPlaceholder = funcContainer:CreateFontString(nil, "OVERLAY")
    funcPlaceholder:SetFont(fontPath, 11, "")
    funcPlaceholder:SetPoint("TOPLEFT", funcContainer, "TOPLEFT", 8, -6)
    funcPlaceholder:SetText(L["GEMS_VAR_FUNC_PLACEHOLDER"])
    funcPlaceholder:SetTextColor(C.textMuted:GetRGBA())
    VT.funcPlaceholder = funcPlaceholder

    funcEdit:HookScript("OnEditFocusGained", function()
        funcPlaceholder:Hide()
    end)
    funcEdit:HookScript("OnEditFocusLost", function()
        if (funcEdit:GetText() or "") == "" then
            funcPlaceholder:Show()
        end
    end)
    funcEdit:HookScript("OnTextChanged", function()
        if (funcEdit:GetText() or "") == "" and not funcEdit:HasFocus() then
            funcPlaceholder:Show()
        else
            funcPlaceholder:Hide()
        end
    end)

    -- Validation result label (below function body)
    local validLabel = editorPanel:CreateFontString(nil, "OVERLAY")
    UI:SetFont(validLabel, 9)
    validLabel:SetPoint("TOPLEFT", funcContainer, "BOTTOMLEFT", 0, -2)
    validLabel:SetText("")
    VT.validLabel = validLabel

    yOff = yOff - 14 - D().VAR_FUNC_EDIT_HEIGHT - 18

    -- Events label + EditBox
    local eventsLabel = editorPanel:CreateFontString(nil, "OVERLAY")
    UI:SetFont(eventsLabel, 10)
    eventsLabel:SetPoint("TOPLEFT", editorPanel, "TOPLEFT", 8, yOff)
    eventsLabel:SetText(L["GEMS_VAR_EVENTS_LABEL"])
    eventsLabel:SetTextColor(C.textSecondary:GetRGBA())

    -- Events enabled checkbox (next to label)
    local cbEventsEnabled = CreateFrame("CheckButton", nil, editorPanel, "UICheckButtonTemplate")
    cbEventsEnabled:SetSize(22, 22)
    cbEventsEnabled:SetPoint("LEFT", eventsLabel, "RIGHT", 4, 0)
    cbEventsEnabled:SetChecked(true)
    cbEventsEnabled:SetScript("OnEnter", function(self)
        UI:ShowTooltip(self, L["GEMS_VAR_EVENTS_ENABLED_DESC"])
    end)
    cbEventsEnabled:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)
    VT.cbEventsEnabled = cbEventsEnabled

    local eventsEdit = CreateFrame("EditBox", nil, editorPanel, "BackdropTemplate")
    eventsEdit:SetHeight(D().NAME_EDITBOX_HEIGHT)
    eventsEdit:SetPoint("TOPLEFT", eventsLabel, "BOTTOMLEFT", 0, -2)
    eventsEdit:SetPoint("RIGHT", editorPanel, "RIGHT", -38, 0)
    eventsEdit:SetAutoFocus(false)
    UI:ApplyBackdrop(eventsEdit, UI.Backdrops.panel, C.bgInput, C.border)
    eventsEdit:SetTextInsets(6, 6, 2, 2)
    eventsEdit:SetFont(fontPath, 11, "")
    eventsEdit:SetTextColor(C.textPrimary:GetRGBA())
    eventsEdit:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
    end)
    eventsEdit:SetScript("OnEnterPressed", function(self)
        self:ClearFocus()
    end)
    eventsEdit:SetScript("OnEditFocusGained", function(self)
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
    end)
    eventsEdit:SetScript("OnEditFocusLost", function(self)
        self:SetBackdropBorderColor(C.border:GetRGBA())
    end)
    VT.eventsEdit = eventsEdit
    GRIPEMS.Focus:HookEditBox(eventsEdit)

    -- Event browse dropdown button (28x28, anchored right of eventsEdit)
    local eventsDropdownBtn = CreateFrame("Button", nil, editorPanel, "BackdropTemplate")
    eventsDropdownBtn:SetSize(28, D().NAME_EDITBOX_HEIGHT)
    eventsDropdownBtn:SetPoint("TOPLEFT", eventsEdit, "TOPRIGHT", 2, 0)
    UI:ApplyBackdrop(eventsDropdownBtn, UI.Backdrops.panel, C.bgInput, C.border)
    local btnArrow = eventsDropdownBtn:CreateFontString(nil, "OVERLAY")
    btnArrow:SetFont(fontPath, 12, "")
    btnArrow:SetPoint("CENTER")
    btnArrow:SetText("v")
    btnArrow:SetTextColor(C.textPrimary:GetRGBA())
    eventsDropdownBtn:SetScript("OnEnter", function(self)
        UI:ShowTooltip(self, L["GEMS_VAR_EVENTS_BROWSE"], L["GEMS_VAR_EVENTS_BROWSE_TIP"])
        self:SetBackdropColor(C.bgRowHover:GetRGBA())
    end)
    eventsDropdownBtn:SetScript("OnLeave", function(self)
        GameTooltip:Hide()
        self:SetBackdropColor(C.bgInput:GetRGBA())
    end)
    eventsDropdownBtn:SetScript("OnClick", function()
        VT:ToggleEventDropdown()
    end)
    VT.eventsDropdownBtn = eventsDropdownBtn

    -- Placeholder overlay for events EditBox
    local eventsPlaceholder = eventsEdit:CreateFontString(nil, "OVERLAY")
    eventsPlaceholder:SetFont(fontPath, 11, "")
    eventsPlaceholder:SetPoint("LEFT", eventsEdit, "LEFT", 6, 0)
    eventsPlaceholder:SetText(L["GEMS_VAR_EVENTS_PLACEHOLDER"])
    eventsPlaceholder:SetTextColor(C.textMuted:GetRGBA())
    VT.eventsPlaceholder = eventsPlaceholder

    eventsEdit:HookScript("OnEditFocusGained", function()
        eventsPlaceholder:Hide()
    end)
    eventsEdit:HookScript("OnEditFocusLost", function()
        if (eventsEdit:GetText() or "") == "" then
            eventsPlaceholder:Show()
        end
    end)
    eventsEdit:HookScript("OnTextChanged", function()
        if (eventsEdit:GetText() or "") == "" and not eventsEdit:HasFocus() then
            eventsPlaceholder:Show()
        else
            eventsPlaceholder:Hide()
        end
    end)

    yOff = yOff - 14 - D().NAME_EDITBOX_HEIGHT - 8

    -- Comments label + EditBox
    local commentsLabel = editorPanel:CreateFontString(nil, "OVERLAY")
    UI:SetFont(commentsLabel, 10)
    commentsLabel:SetPoint("TOPLEFT", editorPanel, "TOPLEFT", 8, yOff)
    commentsLabel:SetText(L["GEMS_VAR_COMMENTS_LABEL"])
    commentsLabel:SetTextColor(C.textSecondary:GetRGBA())

    local commentsEdit = CreateFrame("EditBox", nil, editorPanel, "BackdropTemplate")
    commentsEdit:SetHeight(D().NAME_EDITBOX_HEIGHT)
    commentsEdit:SetPoint("TOPLEFT", commentsLabel, "BOTTOMLEFT", 0, -2)
    commentsEdit:SetPoint("RIGHT", editorPanel, "RIGHT", -8, 0)
    commentsEdit:SetAutoFocus(false)
    UI:ApplyBackdrop(commentsEdit, UI.Backdrops.panel, C.bgInput, C.border)
    commentsEdit:SetTextInsets(6, 6, 2, 2)
    commentsEdit:SetFont(fontPath, 11, "")
    commentsEdit:SetTextColor(C.textPrimary:GetRGBA())
    commentsEdit:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
    end)
    commentsEdit:SetScript("OnEnterPressed", function(self)
        self:ClearFocus()
    end)
    commentsEdit:SetScript("OnEditFocusGained", function(self)
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
    end)
    commentsEdit:SetScript("OnEditFocusLost", function(self)
        self:SetBackdropBorderColor(C.border:GetRGBA())
    end)
    VT.commentsEdit = commentsEdit
    GRIPEMS.Focus:HookEditBox(commentsEdit)

    yOff = yOff - 14 - D().NAME_EDITBOX_HEIGHT - 8

    -- Disabled checkbox
    local cbDisabled = CreateFrame("CheckButton", nil, editorPanel, "UICheckButtonTemplate")
    cbDisabled:SetSize(22, 22)
    cbDisabled:SetPoint("TOPLEFT", editorPanel, "TOPLEFT", 6, yOff)
    VT.cbDisabled = cbDisabled

    local disabledLabel = editorPanel:CreateFontString(nil, "OVERLAY")
    UI:SetFont(disabledLabel, 10)
    disabledLabel:SetPoint("LEFT", cbDisabled, "RIGHT", 2, 0)
    disabledLabel:SetText(L["GEMS_VAR_DISABLED_LABEL"])
    disabledLabel:SetTextColor(C.textSecondary:GetRGBA())

    yOff = yOff - 28

    -- Button row: Save, Test, Delete
    local btnRow = CreateFrame("Frame", nil, editorPanel)
    btnRow:SetHeight(D().KEY_CAPTURE_BUTTON_HEIGHT + 4)
    btnRow:SetPoint("TOPLEFT", editorPanel, "TOPLEFT", 8, yOff)
    btnRow:SetPoint("RIGHT", editorPanel, "RIGHT", -8, 0)

    -- Save button (green)
    local saveBtn = UI:CreateButton(btnRow, L["GEMS_VAR_SAVE"], 60, D().KEY_CAPTURE_BUTTON_HEIGHT)
    saveBtn:SetPoint("LEFT", btnRow, "LEFT", 0, 0)
    saveBtn:SetBackdropColor(C.bgSave:GetRGBA())
    saveBtn:SetScript("OnClick", function()
        VT:SaveVariable()
    end)
    saveBtn:SetScript("OnEnter", function(self)
        UI:ShowTooltip(self, L["GEMS_VAR_SAVE"], L["GEMS_VAR_SAVE_DESC"])
        self:SetBackdropColor(C.bgSaveHover:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
    end)
    saveBtn:SetScript("OnLeave", function(self)
        GameTooltip:Hide()
        self:SetBackdropColor(C.bgSave:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
    end)
    VT.saveBtn = saveBtn

    -- Test button
    local testBtn = UI:CreateButton(btnRow, L["GEMS_VAR_TEST"], 60, D().KEY_CAPTURE_BUTTON_HEIGHT)
    testBtn:SetPoint("LEFT", saveBtn, "RIGHT", 4, 0)
    testBtn:SetScript("OnClick", function()
        VT:TestVariable()
    end)
    testBtn:SetScript("OnEnter", function(self)
        UI:ShowTooltip(self, L["GEMS_VAR_TEST"], L["GEMS_VAR_TEST_DESC"])
        self:SetBackdropColor(C.bgRowHover:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
    end)
    testBtn:SetScript("OnLeave", function(self)
        GameTooltip:Hide()
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
    end)
    VT.testBtn = testBtn

    -- Delete button
    local delBtn = UI:CreateButton(btnRow, L["GEMS_UI_DELETE"], 60, D().KEY_CAPTURE_BUTTON_HEIGHT)
    delBtn:SetPoint("LEFT", testBtn, "RIGHT", 4, 0)
    delBtn:SetScript("OnClick", function()
        VT:ConfirmDeleteVariable()
    end)
    delBtn:SetScript("OnEnter", function(self)
        UI:ShowTooltip(self, L["GEMS_UI_DELETE"], L["GEMS_VAR_DELETE_DESC"])
        self:SetBackdropColor(C.accent:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
    end)
    delBtn:SetScript("OnLeave", function(self)
        GameTooltip:Hide()
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
    end)
    VT.delBtn = delBtn

    yOff = yOff - D().KEY_CAPTURE_BUTTON_HEIGHT - 12

    -- Reference count label
    local refsLabel = editorPanel:CreateFontString(nil, "OVERLAY")
    UI:SetFont(refsLabel, 9)
    refsLabel:SetPoint("TOPLEFT", editorPanel, "TOPLEFT", 8, yOff)
    refsLabel:SetText("")
    refsLabel:SetTextColor(C.textMuted:GetRGBA())
    VT.refsLabel = refsLabel

    -- Register callbacks for variable events
    if GRIPEMS.RegisterCallback then
        GRIPEMS.RegisterCallback(VT, "VARIABLE_CREATED", "OnVariableChanged")
        GRIPEMS.RegisterCallback(VT, "VARIABLE_UPDATED", "OnVariableChanged")
        GRIPEMS.RegisterCallback(VT, "VARIABLE_DELETED", "OnVariableDeleted")
    end
end

---------------------------------------------------------------------------
-- ScrollBox row initializer
---------------------------------------------------------------------------

--- Initialize or update a list row for a variable entry.
--- @param button Button The row frame from ScrollBox
--- @param data table { name = string, disabled = boolean }
function VT:InitListRow(button, data)
    local C = UI.Colors

    if not button._gripInit then
        if not button.SetBackdrop then
            Mixin(button, BackdropTemplateMixin)
        end
        button:SetBackdrop(UI.Backdrops.panelNoBorder)

        -- Variable name label
        button.nameText = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(button.nameText, 11)
        button.nameText:SetPoint("LEFT", button, "LEFT", 6, 0)
        button.nameText:SetPoint("RIGHT", button, "RIGHT", -20, 0)
        button.nameText:SetJustifyH("LEFT")
        button.nameText:SetWordWrap(false)

        -- Disabled indicator (small dot)
        button.statusDot = button:CreateTexture(nil, "ARTWORK")
        button.statusDot:SetSize(6, 6)
        button.statusDot:SetPoint("RIGHT", button, "RIGHT", -6, 0)

        -- Hover/click handlers
        button:SetScript("OnEnter", function(self)
            if self._varName ~= VT.selectedVar then
                self:SetBackdropColor(C.bgRowHover:GetRGBA())
            end
        end)
        button:SetScript("OnLeave", function(self)
            if self._varName ~= VT.selectedVar then
                self:SetBackdropColor(0, 0, 0, 0)
            end
        end)
        button:SetScript("OnClick", function(self, mouseButton)
            if mouseButton == "RightButton" then
                VT:ShowContextMenu(self, self._varName)
            else
                VT:SelectVariable(self._varName)
            end
        end)
        button:RegisterForClicks("LeftButtonUp", "RightButtonUp")

        button._gripInit = true
    end

    button._varName = data.name

    -- Name text
    button.nameText:SetText(data.name)

    -- Status dot: yellow/orange for locale risk, green for enabled, gray for disabled
    local VS = GRIPEMS.VariableStore
    local localeRisk = VS and VS:GetLocaleRisk(data.name)
    if localeRisk then
        button.statusDot:SetColorTexture(C.textWarning:GetRGBA())
        button.nameText:SetTextColor(C.textPrimary:GetRGBA())
    elseif data.disabled then
        button.statusDot:SetColorTexture(C.textMuted:GetRGBA())
        button.nameText:SetTextColor(C.textMuted:GetRGBA())
    else
        button.statusDot:SetColorTexture(C.textSuccess:GetRGBA())
        button.nameText:SetTextColor(C.textPrimary:GetRGBA())
    end

    -- Selection highlight
    if data.name == VT.selectedVar then
        button:SetBackdropColor(C.bgRowSelected:GetRGBA())
    else
        button:SetBackdropColor(0, 0, 0, 0)
    end
end

---------------------------------------------------------------------------
-- List management
---------------------------------------------------------------------------

--- Rebuild the variable list DataProvider from VariableStore.
function VT:RefreshList()
    if not VT.scrollBox then
        return
    end
    local VS = GRIPEMS.VariableStore
    if not VS then
        return
    end

    local store = VS:GetAll()
    local list = {}
    for name, varDef in pairs(store) do
        list[#list + 1] = {
            name = name,
            disabled = varDef.disabled or false,
        }
    end
    table.sort(list, function(a, b)
        return a.name < b.name
    end)

    local dataProvider = CreateDataProvider(list)
    VT.scrollBox:SetDataProvider(dataProvider, ScrollBoxConstants.RetainScrollPosition)

    -- Toggle empty state (listPanel always visible for background + New btn)
    if #list == 0 then
        if VT.emptyLabel then
            VT.emptyLabel:Show()
        end
        if VT.scrollBox then
            VT.scrollBox:Hide()
        end
        if VT.scrollBar then
            VT.scrollBar:Hide()
        end
        if VT.editorPanel then
            VT.editorPanel:Hide()
        end
    else
        if VT.emptyLabel then
            VT.emptyLabel:Hide()
        end
        if VT.scrollBox then
            VT.scrollBox:Show()
        end
        if VT.scrollBar then
            VT.scrollBar:Show()
        end
    end
end

--- Create a new variable with a unique default name.
function VT:CreateNewVariable()
    local VS = GRIPEMS.VariableStore
    if not VS then
        return
    end

    -- Generate unique name
    local baseName = "myVar"
    local name = baseName
    local counter = 1
    local store = VS:GetAll()
    while store[name] do
        counter = counter + 1
        name = baseName .. counter
    end

    local varDef = {
        name = name,
        funct = "",
        events = "",
        comments = "",
        disabled = false,
    }
    VS:Set(name, varDef)
    VT:SelectVariable(name)
end

---------------------------------------------------------------------------
-- Selection and editor population
---------------------------------------------------------------------------

--- Select a variable and populate the editor panel.
--- @param name string Variable name to select
function VT:SelectVariable(name)
    VT.selectedVar = name

    local VS = GRIPEMS.VariableStore
    if not VS then
        return
    end
    local varDef = VS:Get(name)
    if not varDef then
        VT:ClearEditor()
        VT:RefreshList()
        return
    end

    -- Show editor panel
    if VT.editorPanel then
        VT.editorPanel:Show()
    end

    -- Populate fields
    if VT.nameEdit then
        VT.nameEdit:SetText(name)
    end
    if VT.funcEdit then
        VT.funcEdit:SetText(varDef.funct or "")
    end
    if VT.eventsEdit then
        VT.eventsEdit:SetText(varDef.events or "")
    end
    if VT.cbEventsEnabled then
        VT.cbEventsEnabled:SetChecked(varDef.eventsEnabled ~= false)
    end
    if VT.commentsEdit then
        VT.commentsEdit:SetText(varDef.comments or "")
    end
    if VT.cbDisabled then
        VT.cbDisabled:SetChecked(varDef.disabled or false)
    end

    -- Update placeholder visibility
    if VT.funcPlaceholder then
        VT.funcPlaceholder:SetShown((varDef.funct or "") == "")
    end
    if VT.eventsPlaceholder then
        VT.eventsPlaceholder:SetShown((varDef.events or "") == "")
    end

    -- Validate function body
    VT:ValidateFunctionBody()

    -- Update locale warning
    VT:UpdateLocaleWarning(name)
    VT:UpdatePrivateAuraWarning(name)

    -- Update references
    VT:UpdateReferences(name)

    -- Refresh list to update selection highlight
    VT:RefreshList()
end

--- Clear the editor panel.
function VT:ClearEditor()
    VT.selectedVar = nil
    if VT.editorPanel then
        VT.editorPanel:Hide()
    end
    if VT.nameEdit then
        VT.nameEdit:SetText("")
    end
    if VT.funcEdit then
        VT.funcEdit:SetText("")
    end
    if VT.eventsEdit then
        VT.eventsEdit:SetText("")
    end
    if VT.cbEventsEnabled then
        VT.cbEventsEnabled:SetChecked(true)
    end
    if VT.commentsEdit then
        VT.commentsEdit:SetText("")
    end
    if VT.cbDisabled then
        VT.cbDisabled:SetChecked(false)
    end
    if VT.validLabel then
        VT.validLabel:SetText("")
    end
    if VT.refsLabel then
        VT.refsLabel:SetText("")
    end
    if VT.localeWarnBanner then
        VT.localeWarnBanner:SetHeight(0)
        VT.localeWarnBanner:Hide()
    end
    -- Reset placeholders to visible for next editor open
    if VT.funcPlaceholder then
        VT.funcPlaceholder:Show()
    end
    if VT.eventsPlaceholder then
        VT.eventsPlaceholder:Show()
    end
end

---------------------------------------------------------------------------
-- Validation
---------------------------------------------------------------------------

--- Validate the function body in the editor and update the label.
function VT:ValidateFunctionBody()
    if not VT.funcEdit or not VT.validLabel then
        return
    end
    local C = UI.Colors
    local funcStr = VT.funcEdit:GetText() or ""

    if funcStr == "" then
        VT.validLabel:SetText("")
        return
    end

    local VS = GRIPEMS.VariableStore
    if not VS then
        return
    end

    local valid, err = VS:ValidateFunction(funcStr)
    local newState = valid and "valid" or "invalid"
    if valid then
        VT.validLabel:SetText(L["GEMS_VAR_VALID"])
        VT.validLabel:SetTextColor(C.textSuccess:GetRGBA())
        if VT._lastValidSoundState ~= "valid" then
            if GRIPEMS.Sound then
                GRIPEMS.Sound:Play("success")
            end
        end
    else
        VT.validLabel:SetText(string.format(L["GEMS_VAR_INVALID"], tostring(err)))
        VT.validLabel:SetTextColor(C.textError:GetRGBA())
        if VT._lastValidSoundState ~= "invalid" then
            if GRIPEMS.Sound then
                GRIPEMS.Sound:Play("error")
            end
        end
    end
    VT._lastValidSoundState = newState
end

--- Update the references label for a variable.
--- @param name string Variable name
function VT:UpdateReferences(name)
    if not VT.refsLabel then
        return
    end
    local C = UI.Colors
    local VS = GRIPEMS.VariableStore
    if not VS then
        return
    end

    local refs = VS:GetReferences(name)
    if #refs > 0 then
        VT.refsLabel:SetText(string.format(L["GEMS_VAR_USED_BY"], table.concat(refs, ", ")))
        VT.refsLabel:SetTextColor(C.textSecondary:GetRGBA())
    else
        VT.refsLabel:SetText(L["GEMS_VAR_NOT_USED"])
        VT.refsLabel:SetTextColor(C.textMuted:GetRGBA())
    end
end

--- Update the locale warning banner for a variable.
--- Shows a warning if the variable evaluates to a known spell name.
--- @param name string Variable name
function VT:UpdateLocaleWarning(name)
    if not VT.localeWarnBanner then
        return
    end
    local VS = GRIPEMS.VariableStore
    if not VS then
        VT.localeWarnBanner:SetHeight(0)
        VT.localeWarnBanner:Hide()
        return
    end
    local risk = VS:GetLocaleRisk(name)
    if risk then
        VT.localeWarnBanner:Show()
        VT.localeWarnBanner:SetHeight(24)
        if VT.localeWarnText then
            VT.localeWarnText:SetText(
                string.format(L["GEMS_VAR_LOCALE_WARN"], risk.spellName, "C_Spell.GetSpellName(" .. risk.spellID .. ")")
            )
        end
    else
        VT.localeWarnBanner:SetHeight(0)
        VT.localeWarnBanner:Hide()
    end
end

--- Update the private-aura warning banner for a variable.
--- Shows a warning if the variable evaluates to a spell name whose
--- aura is marked Private (addon detection cannot read it).
--- @param name string Variable name
function VT:UpdatePrivateAuraWarning(name)
    if not VT.privateAuraBanner then
        return
    end
    local VS = GRIPEMS.VariableStore
    if not VS then
        VT.privateAuraBanner:SetHeight(0)
        VT.privateAuraBanner:Hide()
        return
    end
    local risk = VS:GetPrivateAuraRisk(name)
    if risk then
        VT.privateAuraBanner:Show()
        VT.privateAuraBanner:SetHeight(24)
        if VT.privateAuraText then
            VT.privateAuraText:SetText(string.format(L["GEMS_VAR_PRIVATE_AURA_WARN"], risk.spellName, risk.spellID))
        end
    else
        VT.privateAuraBanner:SetHeight(0)
        VT.privateAuraBanner:Hide()
    end
end

---------------------------------------------------------------------------
-- Save / Test / Delete
---------------------------------------------------------------------------

--- Save the current editor state to VariableStore.
function VT:SaveVariable()
    if not VT.selectedVar then
        return
    end
    local VS = GRIPEMS.VariableStore
    if not VS then
        return
    end

    local name = VT.nameEdit and VT.nameEdit:GetText() or ""
    name = name:match("^%s*(.-)%s*$") or ""

    -- Validate name
    local validName, nameErr = VS:ValidateName(name)
    if not validName then
        GRIPEMS:Print(nameErr)
        return
    end

    -- If name changed, do a rename
    if name ~= VT.selectedVar then
        local ok, renameErr = VS:Rename(VT.selectedVar, name)
        if not ok then
            GRIPEMS:Print(renameErr or "Rename failed")
            return
        end
        VT.selectedVar = name
    end

    local varDef = {
        name = name,
        funct = VT.funcEdit and VT.funcEdit:GetText() or "",
        events = VT.eventsEdit and VT.eventsEdit:GetText() or "",
        eventsEnabled = VT.cbEventsEnabled and VT.cbEventsEnabled:GetChecked() or true,
        comments = VT.commentsEdit and VT.commentsEdit:GetText() or "",
        disabled = VT.cbDisabled and VT.cbDisabled:GetChecked() or false,
    }

    -- Preserve metadata from existing def
    local existing = VS:Get(name)
    if existing then
        varDef.createdAt = existing.createdAt
        varDef.author = existing.author
        varDef.version = existing.version
    end

    VS:Set(name, varDef)
    VT:SelectVariable(name)
    VT:UpdateLocaleWarning(name)
    VT:UpdatePrivateAuraWarning(name)
end

--- Test the function body: evaluate now and print result.
function VT:TestVariable()
    if not VT.selectedVar then
        return
    end
    local VS = GRIPEMS.VariableStore
    if not VS then
        return
    end

    -- Use the editor's current text (not the saved version)
    local funcStr = VT.funcEdit and VT.funcEdit:GetText() or ""
    if funcStr == "" then
        GRIPEMS:Print(string.format(L["GEMS_VAR_TEST_RESULT"], VT.selectedVar, "nil"))
        return
    end

    local fn, loadErr = loadstring("return " .. funcStr)
    if not fn then
        GRIPEMS:Print(string.format(L["GEMS_VAR_TEST_ERROR"], VT.selectedVar, tostring(loadErr)))
        return
    end

    local ok, result = pcall(fn)
    if ok and type(result) == "function" then
        ok, result = pcall(result)
    end
    if ok then
        GRIPEMS:Print(string.format(L["GEMS_VAR_TEST_RESULT"], VT.selectedVar, tostring(result)))
    else
        GRIPEMS:Print(string.format(L["GEMS_VAR_TEST_ERROR"], VT.selectedVar, tostring(result)))
    end
end

--- Confirm and delete the selected variable.
function VT:ConfirmDeleteVariable()
    if not VT.selectedVar then
        return
    end
    local VS = GRIPEMS.VariableStore
    if not VS then
        return
    end

    local name = VT.selectedVar
    local refs = VS:GetReferences(name)

    local confirmText
    if #refs > 0 then
        confirmText = string.format(L["GEMS_VAR_DELETE_REFS_WARN"], #refs)
    else
        confirmText = string.format(L["GEMS_VAR_DELETE_CONFIRM"], name)
    end

    GRIPEMS.Popup:Define("GRIPEMS_DELETE_VARIABLE", {
        text = confirmText,
        button1 = ACCEPT,
        button2 = CANCEL,
        OnAccept = function()
            -- Clear selection if deleting the selected variable
            if VT.selectedVar == name then
                VT.selectedVar = nil
                VT:ClearEditor()
            end
            VS:Delete(name)
            -- Safety-net refresh (callback may not fire if frame hidden)
            VT:RefreshList()
        end,
        timeout = 0,
        hideOnEscape = true,
    })
    GRIPEMS.Popup:Show("GRIPEMS_DELETE_VARIABLE")
end

---------------------------------------------------------------------------
-- Context menu (right-click on list row)
---------------------------------------------------------------------------

--- Show a context menu for a variable list row.
--- @param anchor Frame The row button
--- @param name string Variable name
function VT:ShowContextMenu(anchor, name)
    if not name then
        return
    end

    MenuUtil.CreateContextMenu(anchor, function(ownerRegion, rootDescription)
        -- Rename
        rootDescription:CreateButton(L["GEMS_VAR_RENAME"], function()
            VT:PromptRename(name)
        end)
        -- Delete
        rootDescription:CreateButton(L["GEMS_UI_DELETE"], function()
            VT.selectedVar = name
            VT:ConfirmDeleteVariable()
        end)
    end)
end

--- Show a rename dialog for a variable.
--- @param oldName string Current variable name
function VT:PromptRename(oldName)
    GRIPEMS.Popup:Define("GRIPEMS_RENAME_VARIABLE", {
        text = L["GEMS_VAR_RENAME"],
        hasEditBox = true,
        button1 = ACCEPT,
        button2 = CANCEL,
        OnShow = function(self)
            self.EditBox:SetText(oldName)
            self.EditBox:HighlightText()
        end,
        OnAccept = function(self)
            local newName = self.EditBox:GetText()
            newName = newName and newName:match("^%s*(.-)%s*$") or ""
            if newName == "" or newName == oldName then
                return
            end

            local VS = GRIPEMS.VariableStore
            if not VS then
                return
            end
            local ok, err = VS:Rename(oldName, newName)
            if ok then
                VT:SelectVariable(newName)
            else
                GRIPEMS:Print(err or "Rename failed")
            end
        end,
        timeout = 0,
        hideOnEscape = true,
    })
    GRIPEMS.Popup:Show("GRIPEMS_RENAME_VARIABLE")
end

---------------------------------------------------------------------------
-- Helper picker (Insert Helper button)
---------------------------------------------------------------------------

--- Open the helper picker menu anchored to the Insert Helper button.
--- Each entry inserts a Layer 1 condition helper at the funcEdit cursor
--- and (when applicable) auto-highlights the spellID placeholder so
--- the user can type the real ID over it.
--- @param anchor Frame The Insert Helper button
function VT:ShowHelperPicker(anchor)
    if not anchor then
        return
    end

    MenuUtil.CreateContextMenu(anchor, function(ownerRegion, rootDescription)
        for _, entry in ipairs(HELPER_INSERTS) do
            local btn = rootDescription:CreateButton(entry.label, function()
                VT:InsertHelper(entry.snippet, entry.phStart, entry.phLen)
            end)
            -- Hover tooltip showing the description. SetTooltip is the
            -- retail 12.0+ MenuUtil API; it is a no-op if the menu
            -- element does not implement it (older builds).
            if btn and btn.SetTooltip then
                btn:SetTooltip(function(tooltip, elementDescription)
                    GameTooltip_AddNormalLine(tooltip, entry.label)
                    GameTooltip_AddBlankLineToTooltip(tooltip)
                    GameTooltip_AddNormalLine(tooltip, L[entry.descKey])
                end)
            end
        end
    end)
end

--- Insert a helper snippet at the current funcEdit cursor position.
--- When phStart is provided, the placeholder character at that offset
--- (0-based, relative to snippet start) is highlighted so the user
--- can type the real value over it. When phStart is nil the cursor
--- lands at the end of the inserted snippet.
---
--- Smart-concat: if the cursor is at end-of-text AND the last
--- character closes an expression (word char, `)`, `]`, `}`, `"`, `'`),
--- prepend " and " before the snippet so two boolean helpers
--- compose as valid Lua. Trailing whitespace suppresses the prepend.
--- Mid-text insertion also falls through to raw insert.
---
--- Comment awareness: if the cursor's line contains a real Lua line
--- comment `--` (not inside a string literal), the snippet is
--- inserted BEFORE the comment with smart-concat applied to the
--- pre-comment code tail. The comment text is preserved.
---
--- Block-keyword suppression: when the trailing identifier is a
--- non-expression Lua keyword (NON_EXPR_TAIL_KEYWORDS), smart-concat
--- is suppressed so we do not produce `... end and X` style invalid Lua.
---
--- Long-comment suppression: when the cursor is inside an unclosed
--- `--[[ ... ]]` block, smart-concat is suppressed and raw insert
--- happens at cursor (validator will flag the result; user recovers).
---
--- @param snippet string Lua text to insert
--- @param phStart number|nil 0-based offset of the placeholder
--- @param phLen number|nil Length of the placeholder, defaults to 1
function VT:InsertHelper(snippet, phStart, phLen)
    local edit = VT.funcEdit
    if not edit or not snippet then
        return
    end

    local text = edit:GetText() or ""
    local pos = edit:GetCursorPosition() or #text

    -- Default: raw insert at cursor with no prefix or suffix.
    local insertPos, prefix, suffix = pos, "", ""

    -- Smart-concat / comment-aware analysis only when cursor is at
    -- end of non-empty content AND we are NOT inside a long comment.
    if pos == #text and #text > 0 and not isInLongComment(text) then
        local lastLine = text:match("[^\n]*$") or ""
        local commentPosInLine = findRealLineComment(lastLine)

        if commentPosInLine then
            -- Real line comment on this line. Insert BEFORE the
            -- comment so the comment text is preserved and the new
            -- helper goes in the actual code position.
            local lineStartByte = #text - #lastLine
            local commentAbsPos = lineStartByte + commentPosInLine - 1

            local codeBeforeComment = lastLine:sub(1, commentPosInLine - 1)
            local codeTrimmed = codeBeforeComment:match("^(.-)%s*$") or ""

            if #codeTrimmed == 0 then
                -- Comment at start of line (no code before it).
                -- Insert at commentAbsPos with a trailing space so
                -- the snippet does not merge with the `--`.
                insertPos = commentAbsPos
                suffix = " "
            else
                -- Code before comment exists. Decide if smart-concat
                -- applies based on the trimmed code's last char.
                local lastCodeChar = codeTrimmed:sub(-1)
                local trailingWord = codeTrimmed:match("([%a_][%w_]*)$") or ""
                if lastCodeChar:match("[%w%)%]%}\"']") and not NON_EXPR_TAIL_KEYWORDS[trailingWord] then
                    -- Smart-concat fires. Insert at end of trimmed
                    -- code so the existing whitespace between code
                    -- and `--` is preserved naturally in the suffix.
                    insertPos = lineStartByte + #codeTrimmed
                    prefix = " and "
                else
                    -- No smart-concat (closing token absent or
                    -- block keyword). Insert at end of trimmed
                    -- code with a leading space.
                    insertPos = lineStartByte + #codeTrimmed
                    prefix = " "
                end
            end
        else
            -- No real comment on this line. Standard smart-concat path.
            local lastChar = text:sub(-1)
            if lastChar:match("[%w%)%]%}\"']") then
                local trailingWord = text:match("([%a_][%w_]*)$") or ""
                if not NON_EXPR_TAIL_KEYWORDS[trailingWord] then
                    prefix = " and "
                end
            end
        end
    end

    local insertedSnippet = prefix .. snippet .. suffix
    local newText = text:sub(1, insertPos) .. insertedSnippet .. text:sub(insertPos + 1)

    edit:SetText(newText)
    edit:SetFocus()

    -- Unified placeholder offset math: absStart = insertPos + #prefix + phStart.
    -- Works for all paths (raw insert, smart-concat, comment-aware) because
    -- prefix length captures the offset shift uniformly.
    if phStart then
        local len = phLen or 1
        local absStart = insertPos + #prefix + phStart
        local absEnd = absStart + len
        edit:SetCursorPosition(absEnd)
        edit:HighlightText(absStart, absEnd)
    else
        edit:SetCursorPosition(insertPos + #prefix + #snippet)
    end

    -- SetText with userInput=false does not trigger the OnTextChanged
    -- validation handler; call manually so the validation label and
    -- success/error sound fire after insert.
    VT:ValidateFunctionBody()

    -- Hide placeholder overlay if it was visible.
    if VT.funcPlaceholder then
        VT.funcPlaceholder:Hide()
    end
end

---------------------------------------------------------------------------
-- Callbacks (registered in Init)
---------------------------------------------------------------------------

--- Handle VARIABLE_CREATED and VARIABLE_UPDATED callbacks.
function VT:OnVariableChanged(event, name, value)
    if VT.frame and VT.frame:IsShown() then
        VT:RefreshList()
        if name == VT.selectedVar then
            VT:UpdateReferences(name)
        end
    end
end

--- Handle VARIABLE_DELETED callback.
function VT:OnVariableDeleted(event, name)
    if VT.frame and VT.frame:IsShown() then
        if name == VT.selectedVar then
            VT:ClearEditor()
        end
        VT:RefreshList()
    end
end

---------------------------------------------------------------------------
-- Data flow methods (called by SequenceEditor)
---------------------------------------------------------------------------

--- Load sequence data -- no-op for Variables (account-wide).
--- @param name string Sequence name (unused)
function VT:LoadSequence(name)
    -- Variables are account-wide, not per-sequence. Refresh list.
    VT:RefreshList()
end

--- Clear the variables tab.
function VT:Clear()
    -- No per-sequence state to clear; just refresh
    VT:RefreshList()
end

--- Show the variables tab.
function VT:Show()
    if VT.frame then
        VT.frame:Show()
    end
    VT:RefreshList()
end

--- Hide the variables tab.
function VT:Hide()
    if VT.frame then
        VT.frame:Hide()
    end
    if VT.eventsDropdown then
        VT.eventsDropdown:Hide()
    end
end

---------------------------------------------------------------------------
-- Event Browse Dropdown
---------------------------------------------------------------------------

--- Build the event dropdown content from D().VARIABLE_EVENT_LIST.
--- Called once on first open (lazy-init). Populates scroll child with
--- category headers and clickable event rows.
function VT:BuildEventDropdown()
    local dropdown = VT.eventsDropdown
    if not dropdown then
        return
    end

    local C = UI.Colors
    local fontPath = GRIPEMS.UI:GetFontPath()
    local HEADER_HEIGHT = 18
    local ROW_HEIGHT = 20
    local eventList = D().VARIABLE_EVENT_LIST

    local scrollChild = dropdown.scrollChild
    local yOff = 0

    for _, category in ipairs(eventList) do
        -- Category header (non-clickable)
        local header = scrollChild:CreateFontString(nil, "OVERLAY")
        header:SetFont(fontPath, 10, "")
        header:SetPoint("TOPLEFT", scrollChild, "TOPLEFT", 8, -yOff)
        header:SetPoint("RIGHT", scrollChild, "RIGHT", -8, 0)
        header:SetText(category.name)
        header:SetTextColor(C.textMuted:GetRGBA())
        header:SetJustifyH("LEFT")
        yOff = yOff + HEADER_HEIGHT

        -- Event rows (clickable)
        for _, eventName in ipairs(category.events) do
            local row = CreateFrame("Button", nil, scrollChild, "BackdropTemplate")
            row:SetBackdrop(UI.Backdrops.panelNoBorder)
            row:SetBackdropColor(0, 0, 0, 0)
            row:SetHeight(ROW_HEIGHT)
            row:SetPoint("TOPLEFT", scrollChild, "TOPLEFT", 0, -yOff)
            row:SetPoint("RIGHT", scrollChild, "RIGHT", 0, 0)

            local label = row:CreateFontString(nil, "OVERLAY")
            label:SetFont(fontPath, 12, "")
            label:SetPoint("LEFT", row, "LEFT", 16, 0)
            label:SetText(eventName)
            label:SetTextColor(C.textPrimary:GetRGBA())
            label:SetJustifyH("LEFT")

            row:SetScript("OnEnter", function(self)
                self:SetBackdropColor(C.bgRowHover:GetRGBA())
            end)
            row:SetScript("OnLeave", function(self)
                self:SetBackdropColor(0, 0, 0, 0)
            end)
            row:SetScript("OnClick", function()
                VT:InsertEvent(eventName)
            end)

            yOff = yOff + ROW_HEIGHT
        end
    end

    scrollChild:SetHeight(yOff)
    dropdown._built = true
end

--- Insert an event name into the events EditBox.
--- Appends with ", " separator if text is non-empty. Skips duplicates.
--- @param eventName string The event name to insert
function VT:InsertEvent(eventName)
    local edit = VT.eventsEdit
    if not edit then
        return
    end

    local text = edit:GetText() or ""

    -- Check for duplicates (split by comma, trim, compare)
    for token in text:gmatch("[^,]+") do
        local trimmed = strtrim(token)
        if trimmed == eventName then
            return
        end
    end

    if text ~= "" then
        edit:SetText(text .. ", " .. eventName)
    else
        edit:SetText(eventName)
    end
end

--- Toggle the event browse dropdown panel visibility.
function VT:ToggleEventDropdown()
    local dropdown = VT.eventsDropdown

    -- Lazy-init: create the dropdown frame once
    if not dropdown then
        dropdown = CreateFrame("Frame", "GRIPEMS_EventDropdown", UIParent, "BackdropTemplate")
        dropdown:SetFrameStrata("DIALOG")
        local C = UI.Colors
        UI:ApplyBackdrop(dropdown, UI.Backdrops.panel, C.bgPanel, C.border)
        dropdown:SetClampedToScreen(true)
        dropdown:SetSize(260, 300)

        -- Escape key dismissal
        dropdown:EnableKeyboard(true)
        dropdown:SetScript("OnKeyDown", function(self, key)
            if key == "ESCAPE" then
                self:Hide()
                pcall(self.SetPropagateKeyboardInput, self, false)
            else
                pcall(self.SetPropagateKeyboardInput, self, true)
            end
        end)

        -- ScrollFrame
        local scrollFrame = CreateFrame("ScrollFrame", nil, dropdown, "UIPanelScrollFrameTemplate")
        scrollFrame:SetPoint("TOPLEFT", dropdown, "TOPLEFT", 4, -4)
        scrollFrame:SetPoint("BOTTOMRIGHT", dropdown, "BOTTOMRIGHT", -24, 4)

        local scrollChild = CreateFrame("Frame", nil, scrollFrame)
        scrollChild:SetWidth(scrollFrame:GetWidth() or 230)
        scrollFrame:SetScrollChild(scrollChild)
        UI:SkinLegacyScrollBar(scrollFrame)
        dropdown.scrollChild = scrollChild

        -- Update scrollChild width on size change
        scrollFrame:SetScript("OnSizeChanged", function(self)
            scrollChild:SetWidth(self:GetWidth())
        end)

        VT.eventsDropdown = dropdown
    end

    if dropdown:IsShown() then
        dropdown:Hide()
        return
    end

    -- Anchor below the dropdown button
    dropdown:ClearAllPoints()
    dropdown:SetPoint("TOPLEFT", VT.eventsDropdownBtn, "BOTTOMLEFT", 0, -2)

    -- Build content on first open
    if not dropdown._built then
        VT:BuildEventDropdown()
    end

    dropdown:Show()
end
