-- GRIP-EMS: Main Window Frame
-- Split-panel main window with title bar, movable/resizable, position persistence

local ADDON_NAME, GRIPEMS = ...
local UI = GRIPEMS.UI
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS")

-- Upvalues for Defaults (available after Defaults.lua loads, which is before UI/)
local function D() return GRIPEMS.Defaults end

---------------------------------------------------------------------------
-- Frame creation
---------------------------------------------------------------------------

--- Build the main GRIPEMS window. Called once at file load time.
local function CreateMainFrame()
    local C = UI.Colors
    local defaults = D()

    local frame = CreateFrame("Frame", "GRIPEMS_MainFrame", UIParent, "BackdropTemplate")
    frame:SetSize(defaults.MAIN_FRAME_WIDTH, defaults.MAIN_FRAME_HEIGHT)
    frame:SetPoint("CENTER")
    frame:SetFrameStrata("HIGH")
    frame:SetBackdrop(UI.Backdrops.panel)
    frame:SetBackdropColor(C.bgMain:GetRGBA())
    frame:SetBackdropBorderColor(C.border:GetRGBA())
    frame:SetClampedToScreen(true)
    frame:Hide()

    -- ESC to close
    tinsert(UISpecialFrames, "GRIPEMS_MainFrame")

    -- Movable via title bar (set up below)
    frame:SetMovable(true)

    -- Resizable
    frame:SetResizable(true)
    frame:SetResizeBounds(defaults.MAIN_FRAME_MIN_WIDTH, defaults.MAIN_FRAME_MIN_HEIGHT)

    ---------------------------------------------------------------------------
    -- Title bar (40px)
    ---------------------------------------------------------------------------
    local titleBar = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    titleBar:SetHeight(D().TITLE_BAR_HEIGHT)
    titleBar:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, 0)
    titleBar:SetPoint("TOPRIGHT", frame, "TOPRIGHT", 0, 0)
    titleBar:SetBackdrop(UI.Backdrops.panelNoBorder)
    titleBar:SetBackdropColor(C.bgDeep:GetRGBA())
    frame.titleBar = titleBar

    -- Make title bar the drag region
    titleBar:EnableMouse(true)
    titleBar:RegisterForDrag("LeftButton")
    titleBar:SetScript("OnDragStart", function()
        frame:StartMoving()
    end)
    titleBar:SetScript("OnDragStop", function()
        frame:StopMovingOrSizing()
    end)

    -- Title text
    local titleText = titleBar:CreateFontString(nil, "OVERLAY")
    UI:SetFont(titleText, 14, "OUTLINE")
    titleText:SetPoint("LEFT", titleBar, "LEFT", 12, 0)
    titleText:SetText(L["GEMS_UI_TITLE"])
    titleText:SetTextColor(C.gripGreen:GetRGBA())
    frame.titleText = titleText

    -- Version text
    local versionText = titleBar:CreateFontString(nil, "OVERLAY")
    UI:SetFont(versionText, 10)
    versionText:SetPoint("LEFT", titleText, "RIGHT", 8, 0)
    versionText:SetText("v" .. (GRIPEMS.version or "dev"))
    versionText:SetTextColor(C.textMuted:GetRGBA())
    frame.versionText = versionText

    -- Close button (themed dark-UI X)
    local closeBtn = CreateFrame("Button", nil, titleBar, "BackdropTemplate")
    closeBtn:SetSize(24, 24)
    closeBtn:SetPoint("TOPRIGHT", titleBar, "TOPRIGHT", -6, -8)
    closeBtn:SetBackdrop(UI.Backdrops.panel)
    closeBtn:SetBackdropColor(C.bgButton:GetRGBA())
    closeBtn:SetBackdropBorderColor(C.border:GetRGBA())
    local closeLbl = closeBtn:CreateFontString(nil, "OVERLAY")
    UI:SetFont(closeLbl, 14)
    closeLbl:SetPoint("CENTER", 0, 1)
    closeLbl:SetText("X")
    closeLbl:SetTextColor(C.textSecondary:GetRGBA())
    closeBtn:SetScript("OnClick", function() frame:Hide() end)
    closeBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.accent:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
        closeLbl:SetTextColor(C.textPrimary:GetRGBA())
    end)
    closeBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
        closeLbl:SetTextColor(C.textSecondary:GetRGBA())
    end)
    frame.closeBtn = closeBtn

    -- Settings button (left of close button)
    local settingsBtn = CreateFrame("Button", nil, titleBar, "BackdropTemplate")
    settingsBtn:SetSize(24, 24)
    settingsBtn:SetPoint("RIGHT", closeBtn, "LEFT", -4, 0)
    settingsBtn:SetBackdrop(UI.Backdrops.panel)
    settingsBtn:SetBackdropColor(C.bgButton:GetRGBA())
    settingsBtn:SetBackdropBorderColor(C.border:GetRGBA())
    local settingsIcon = settingsBtn:CreateTexture(nil, "ARTWORK")
    settingsIcon:SetSize(16, 16)
    settingsIcon:SetPoint("CENTER")
    settingsIcon:SetTexture("Interface\\Icons\\INV_Misc_Gear_01")
    settingsIcon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    settingsBtn:SetScript("OnClick", function()
        if GRIPEMS.SettingsPanel then
            GRIPEMS.SettingsPanel:Open()
        end
    end)
    settingsBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.accent:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
        UI:ShowTooltip(self, L["GEMS_UI_SETTINGS_BTN"],
            L["GEMS_UI_SETTINGS_BTN_DESC"])
    end)
    settingsBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
        UI:HideTooltip()
    end)
    frame.settingsBtn = settingsBtn

    ---------------------------------------------------------------------------
    -- Resize grip (bottom-right corner)
    ---------------------------------------------------------------------------
    local resizeGrip = CreateFrame("Button", nil, frame)
    resizeGrip:SetSize(16, 16)
    resizeGrip:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -2, 2)
    resizeGrip:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    resizeGrip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    resizeGrip:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
    resizeGrip:SetScript("OnMouseDown", function()
        frame:StartSizing("BOTTOMRIGHT")
    end)
    resizeGrip:SetScript("OnMouseUp", function()
        frame:StopMovingOrSizing()
    end)
    resizeGrip:SetScript("OnEnter", function(self)
        UI:ShowTooltip(self, L["GEMS_UI_RESIZE"], L["GEMS_UI_RESIZE_DESC"])
    end)
    resizeGrip:SetScript("OnLeave", function()
        UI:HideTooltip()
    end)
    frame.resizeGrip = resizeGrip

    ---------------------------------------------------------------------------
    -- Left panel (fixed 280px default, bgPanel color)
    ---------------------------------------------------------------------------
    local leftPanel = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    leftPanel:SetWidth(D().LEFT_PANEL_WIDTH)
    leftPanel:SetPoint("TOPLEFT", frame, "TOPLEFT", 1, -D().TITLE_BAR_HEIGHT)
    leftPanel:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 1, 1)
    leftPanel:SetBackdrop(UI.Backdrops.panel)
    leftPanel:SetBackdropColor(C.bgPanel:GetRGBA())
    leftPanel:SetBackdropBorderColor(C.border:GetRGBA())
    frame.leftPanel = leftPanel

    -- Placeholder text for left panel
    local leftPlaceholder = leftPanel:CreateFontString(nil, "OVERLAY")
    UI:SetFont(leftPlaceholder, 11)
    leftPlaceholder:SetPoint("CENTER")
    leftPlaceholder:SetText(L["GEMS_UI_SEQUENCE_LIST_PLACEHOLDER"])
    leftPlaceholder:SetTextColor(C.textMuted:GetRGBA())
    frame.leftPlaceholder = leftPlaceholder

    ---------------------------------------------------------------------------
    -- Divider (4px wide, between panels)
    ---------------------------------------------------------------------------
    local divider = CreateFrame("Frame", nil, frame)
    divider:SetWidth(4)
    divider:SetPoint("TOPLEFT", leftPanel, "TOPRIGHT", 0, 0)
    divider:SetPoint("BOTTOMLEFT", leftPanel, "BOTTOMRIGHT", 0, 0)
    frame.divider = divider

    ---------------------------------------------------------------------------
    -- Right panel (fills remaining space)
    ---------------------------------------------------------------------------
    local rightPanel = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    rightPanel:SetPoint("TOPLEFT", divider, "TOPRIGHT", 0, 0)
    rightPanel:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -1, 1)
    rightPanel:SetBackdrop(UI.Backdrops.panelNoBorder)
    rightPanel:SetBackdropColor(C.bgMain:GetRGBA())
    frame.rightPanel = rightPanel

    -- Placeholder text for right panel
    local rightPlaceholder = rightPanel:CreateFontString(nil, "OVERLAY")
    UI:SetFont(rightPlaceholder, 12)
    rightPlaceholder:SetPoint("CENTER")
    rightPlaceholder:SetText(L["GEMS_UI_SELECT_SEQUENCE"])
    rightPlaceholder:SetTextColor(C.textMuted:GetRGBA())
    frame.rightPlaceholder = rightPlaceholder

    ---------------------------------------------------------------------------
    -- Layout update on resize
    ---------------------------------------------------------------------------
    frame:SetScript("OnSizeChanged", function(self, width, height)
        -- Left panel stays fixed width, right panel adjusts automatically via anchors
    end)

    ---------------------------------------------------------------------------
    -- Position/size persistence
    ---------------------------------------------------------------------------
    frame:SetScript("OnHide", function(self)
        local sv = GRIP_EMS_CHAR and GRIP_EMS_CHAR.ui and GRIP_EMS_CHAR.ui.mainFrame
        if not sv then return end
        local point, _, _, x, y = self:GetPoint(1)
        sv.point = point
        sv.x = x
        sv.y = y
        sv.width = self:GetWidth()
        sv.height = self:GetHeight()
    end)

    return frame
end

---------------------------------------------------------------------------
-- Initialize: create the frame
---------------------------------------------------------------------------
local mainFrame = CreateMainFrame()

---------------------------------------------------------------------------
-- Position restore (called from Core.lua on PLAYER_LOGIN)
---------------------------------------------------------------------------

--- Restore saved window position and size from SavedVariables.
function UI:RestoreMainFramePosition()
    local sv = GRIP_EMS_CHAR and GRIP_EMS_CHAR.ui and GRIP_EMS_CHAR.ui.mainFrame
    if not sv then return end

    local defaults = D()
    local width = sv.width or defaults.MAIN_FRAME_WIDTH
    local height = sv.height or defaults.MAIN_FRAME_HEIGHT

    -- Clamp to minimum size
    if width < defaults.MAIN_FRAME_MIN_WIDTH then width = defaults.MAIN_FRAME_MIN_WIDTH end
    if height < defaults.MAIN_FRAME_MIN_HEIGHT then height = defaults.MAIN_FRAME_MIN_HEIGHT end

    mainFrame:SetSize(width, height)

    if sv.point and sv.x and sv.y then
        mainFrame:ClearAllPoints()
        mainFrame:SetPoint(sv.point, UIParent, sv.point, sv.x, sv.y)
    end
end

---------------------------------------------------------------------------
-- Toggle function
---------------------------------------------------------------------------

--- Initialize the left and right panel content (list + editor).
--- Called from Core.lua PLAYER_LOGIN after SavedVariables and position are ready.
function UI:InitPanels()
    if GRIPEMS.SequenceList then
        GRIPEMS.SequenceList:Init(GRIPEMS_MainFrame.leftPanel)
    end
    if GRIPEMS.SequenceEditor then
        GRIPEMS.SequenceEditor:Init(GRIPEMS_MainFrame.rightPanel)
    end
    -- Initial data load
    if GRIPEMS.SequenceList then
        GRIPEMS.SequenceList:RefreshDataProvider()
    end
end

--- Toggle the main window open/closed.
function UI:ToggleMainFrame()
    if GRIPEMS_MainFrame:IsShown() then
        GRIPEMS_MainFrame:Hide()
    else
        GRIPEMS_MainFrame:Show()
    end
end

---------------------------------------------------------------------------
-- Addon Compartment functions (declared in TOC, implemented here)
---------------------------------------------------------------------------

--- Called when the addon compartment button is clicked.
function GRIPEMS_OnCompartmentClick(addonName, buttonName)
    UI:ToggleMainFrame()
end

--- Called when the mouse enters the addon compartment button.
function GRIPEMS_OnCompartmentEnter(addonName, menuButtonFrame)
    GameTooltip:SetOwner(menuButtonFrame, "ANCHOR_LEFT")
    GameTooltip:AddDoubleLine(
        "|cFF00CC66GRIP|r - Enhanced Macro Sequencer",
        "v" .. (GRIPEMS.version or "dev"),
        1, 1, 1,  0.6, 0.6, 0.6
    )
    GameTooltip:AddLine(" ")
    local count = 0
    if GRIPEMS.Engine and GRIPEMS.Engine.GetActiveCount then
        count = GRIPEMS.Engine:GetActiveCount()
    end
    GameTooltip:AddDoubleLine(
        L["GEMS_UI_ACTIVE_SEQUENCES_LABEL"],
        tostring(count),
        0.8, 0.8, 0.8,  0, 0.8, 0.4
    )
    if GRIPEMS.Engine and GRIPEMS.Engine.currentContext then
        GameTooltip:AddDoubleLine(
            L["GEMS_UI_CONTEXT_LABEL"],
            GRIPEMS.Engine.currentContext or "none",
            0.8, 0.8, 0.8,  0, 0.8, 0.4
        )
    end
    GameTooltip:AddLine(" ")
    GameTooltip:AddLine(L["GEMS_UI_MINIMAP_LEFT"], 0.5, 0.5, 0.5)
    GameTooltip:Show()
end

--- Called when the mouse leaves the addon compartment button.
function GRIPEMS_OnCompartmentLeave(addonName, menuButtonFrame)
    GameTooltip:Hide()
end
