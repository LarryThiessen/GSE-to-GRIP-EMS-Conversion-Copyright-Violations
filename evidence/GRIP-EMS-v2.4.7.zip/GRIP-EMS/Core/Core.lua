-- GRIP-EMS: Core
-- Created: 2025 (pre-stamping)
-- Updated: 2026-08-17
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- Addon lifecycle, event routing, module bootstrap

local ADDON_NAME, GRIPEMS = ...

-- Make addon table global for SavedVariables access
_G.GRIPEMS = GRIPEMS

-- Version info
local rawVersion = C_AddOns.GetAddOnMetadata(ADDON_NAME, "Version")
if rawVersion and not rawVersion:find("@", 1, true) then
    -- Packager substitutes the tag name verbatim (e.g. "v2.0.2"); strip leading v
    -- so display sites that prepend their own "v" do not double it.
    rawVersion = rawVersion:gsub("^[Vv]", "")
    GRIPEMS.version = rawVersion
else
    GRIPEMS.version = "dev"
end
GRIPEMS.addonName = ADDON_NAME

-- Runtime state (cleared on reload)
GRIPEMS.state = {
    initialized = false,
}

-- Localization
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

-- Logging

--- Print a user-facing message with the GRIP-EMS green prefix.
--- @param msg string Message to display
function GRIPEMS:Print(msg)
    DEFAULT_CHAT_FRAME:AddMessage("|cff00cc66GRIP-EMS:|r " .. tostring(msg))
end

--- Print a debug message (gray prefix). Chat output only when debug mode is on.
--- Always buffers to DebugWindow when visible.
--- Accepts either a plain string or a format string plus varargs; the
--- string.format call is skipped entirely when nothing will be seen, so
--- hot-path callers can pass format-style args without paying for them.
--- @param fmt string Format string or plain message
function GRIPEMS:Debug(fmt, ...)
    local S = GRIPEMS.Settings
    local isDebug = S and S:Get("debug")
    local DW = GRIPEMS.DebugWindow
    local dwVisible = DW and DW.frame and DW.frame:IsShown()
    if not (isDebug or dwVisible) then
        return
    end
    local msg
    if select("#", ...) > 0 then
        msg = string.format(fmt, ...)
    else
        msg = tostring(fmt)
    end
    local timestamp = date("%H:%M:%S")
    local formatted = timestamp .. " " .. msg
    if DW then
        DW:AddMessage(formatted)
    end
    if isDebug then
        DEFAULT_CHAT_FRAME:AddMessage("|cff666666GRIP-EMS:|r " .. formatted)
    end
end

-- Slash command helpers

--- Parse slash command input into command and argument parts.
--- @param input string Raw slash command input
--- @return string cmd The first word (lowercased)
--- @return string arg The remainder after the first word (untrimmed case preserved)
local function ParseSlashInput(input)
    local trimmed = (input or ""):trim()
    local cmd, arg = trimmed:match("^(%S+)%s*(.*)")
    if not cmd then
        return "", ""
    end
    return cmd:lower(), arg or ""
end

--- Show all available slash commands with descriptions.
local function ShowHelp()
    GRIPEMS:Print(L["GEMS_HELP_HEADER"])
    GRIPEMS:Print(L["GEMS_HELP_NONE"])
    GRIPEMS:Print(L["GEMS_HELP_OPEN"])
    GRIPEMS:Print(L["GEMS_HELP_HELP"])
    GRIPEMS:Print(L["GEMS_HELP_CREATE"])
    GRIPEMS:Print(L["GEMS_HELP_DELETE"])
    GRIPEMS:Print(L["GEMS_HELP_LIST"])
    GRIPEMS:Print(L["GEMS_HELP_TEST"])
    GRIPEMS:Print(L["GEMS_HELP_RESET"])
    GRIPEMS:Print(L["GEMS_HELP_BIND"])
    GRIPEMS:Print(L["GEMS_HELP_BIND_LOADOUT_FLAG"])
    GRIPEMS:Print(L["GEMS_HELP_UNBIND"])
    GRIPEMS:Print(L["GEMS_HELP_BINDS"])
    GRIPEMS:Print(L["GEMS_HELP_SWAP"])
    GRIPEMS:Print(L["GEMS_HELP_UNPIN"])
    GRIPEMS:Print(L["GEMS_HELP_IMPORT"])
    GRIPEMS:Print(L["GEMS_HELP_EXPORT"])
    GRIPEMS:Print(L["GEMS_HELP_EXPORTALL"])
    GRIPEMS:Print(L["GEMS_HELP_MIGRATE"])
    GRIPEMS:Print(L["GEMS_HELP_GUIDE"])
    -- v2.0.0 Phase 3 item 10: add a localized GEMS_HELP_TOUR key and print it here when added.
    GRIPEMS:Print(L["GEMS_HELP_TRACKER"])
    GRIPEMS:Print(L["GEMS_HELP_MENU"])
    GRIPEMS:Print(L["GEMS_HELP_DEBUG"])
    GRIPEMS:Print(L["GEMS_HELP_DEBUGWINDOW"])
    GRIPEMS:Print(L["GEMS_HELP_STATUS"])
    GRIPEMS:Print(L["GEMS_HELP_APPLY"])
    GRIPEMS:Print(L["GEMS_HELP_VARIANTS"])
    GRIPEMS:Print(L["GEMS_HELP_TESTLOCALE"])
    GRIPEMS:Print(L["GEMS_HELP_TESTSPELLID"])
    GRIPEMS:Print(L["GEMS_HELP_SETTINGS"])
    GRIPEMS:Print("  /gems theme    - " .. (L["ACCESS_THEMING_SLASH_HINT"] or "Per-element theming editor"))
    GRIPEMS:Print(L["GEMS_HELP_SEND"])
    GRIPEMS:Print(L["GEMS_HELP_ACCEPT"])
    GRIPEMS:Print(L["GEMS_HELP_BLOCK"])
    GRIPEMS:Print(L["GEMS_HELP_UNBLOCK"])
    GRIPEMS:Print(L["GEMS_HELP_BLOCKLIST"])
    GRIPEMS:Print(L["GEMS_HELP_BROWSE"])
    GRIPEMS:Print(L["GEMS_HELP_VALIDATE"])
    GRIPEMS:Print(L["GEMS_HELP_REVALIDATE"])
    GRIPEMS:Print(L["GEMS_HELP_COMPRESS"])
    GRIPEMS:Print(L["GEMS_HELP_DECOMPRESS"])
    GRIPEMS:Print(L["GEMS_HELP_SPELLCACHE"])
    GRIPEMS:Print(L["GEMS_HELP_MAPINFO"])
    GRIPEMS:Print("/gems diag -- " .. L["GEMS_HELP_DIAG"])
    GRIPEMS:Print("/gems msadvisor [name] -- " .. L["GEMS_HELP_MSADVISOR"])
    GRIPEMS:Print("/gems memcheck -- " .. L["GEMS_HELP_MEMCHECK"])
    GRIPEMS:Print("/gems memory -- alias of /gems memcheck")
    GRIPEMS:Print("/gems perf -- " .. L["GEMS_HELP_PERF"])
    GRIPEMS:Print("/gems perftest [events N|scan|reanalyze] -- triple-mode profiler (no args = same as /gems perf)")
    GRIPEMS:Print("/gems monitor -- " .. L["GEMS_HELP_MONITOR"])
    GRIPEMS:Print("/gems debug reloadgate -- print ReloadGate pending/suppressed/panelHook state")
    GRIPEMS:Print("/gems loadclass [id] -- " .. L["GEMS_HELP_LOADCLASS"])
    GRIPEMS:Print(L["GEMS_KC_HELP_KEYS"])
    GRIPEMS:Print(L["GEMS_HELP_REPAIR"])
    GRIPEMS:Print(L["GEMS_HELP_REPAIRALL"])
    GRIPEMS:Print(L["GEMS_HELP_RECORD"])
    GRIPEMS:Print(L["GEMS_HELP_TRACE"])
    GRIPEMS:Print(L["GEMS_HELP_RESETUI"])
    -- Plugin subcommands (Plugin API v3 Phase C): list any /gems subcommands a plugin
    -- registered, surfacing each plugin-supplied helpText. Sorted for a stable order.
    if GRIPEMS.PluginAPI and GRIPEMS.PluginAPI.slashCommands then
        local subs = {}
        for sub in pairs(GRIPEMS.PluginAPI.slashCommands) do
            subs[#subs + 1] = sub
        end
        table.sort(subs)
        for _, sub in ipairs(subs) do
            local helpText = GRIPEMS.PluginAPI.slashCommands[sub].helpText
            GRIPEMS:Print("  /gems " .. sub .. (helpText and (" - " .. helpText) or ""))
        end
    end
end

--- Handle /gems create [name]: create and activate a test sequence.
--- @param arg string Optional sequence name (defaults to TestSeq)
local function HandleCreate(arg)
    local D = GRIPEMS.Defaults
    local seqName = (arg ~= "") and arg or D.TestSequence.name

    -- Reject the per-loadout suppress sentinel as a sequence name (Section 8.4
    -- of Research/PerLoadout_Keybind_Design_2026-05-25.md). Collision here
    -- would conflict with the _byLoadout overlay's "__suppress__" marker.
    if seqName == "__suppress__" then
        GRIPEMS:Print(string.format(L["GEMS_RESERVED_NAME"], seqName))
        return
    end

    -- Check if sequence already exists
    if GRIPEMS.Engine.sequences[seqName] then
        GRIPEMS:Print(string.format(L["GEMS_ALREADY_EXISTS"], seqName, seqName))
        return
    end

    -- Build sequence data from the test template
    local seqData = D.NewSequenceFromTemplate(seqName, D.TestSequence)

    GRIPEMS.Engine:ActivateSequence(seqName, seqData)
    local ver = GRIPEMS.Engine:GetActiveVersion(seqData)
    GRIPEMS:Print(
        string.format(L["GEMS_CREATED"], seqName, ver and #ver.steps or 0, ver and ver.stepFunction or "Sequential")
    )
end

--- Handle /gems delete <name>: deactivate a sequence and delete its macro stub.
--- @param arg string Sequence name (required)
local function HandleDelete(arg)
    if arg == "" then
        GRIPEMS:Print(L["GEMS_DELETE_NEED_NAME"])
        return
    end
    if not GRIPEMS.Engine.sequences[arg] then
        GRIPEMS:Print(string.format(L["GEMS_NOT_FOUND"], arg))
        return
    end
    -- Block delete during combat or restriction (protected APIs required)
    if GRIPEMS.OOCQueue.IsRestricted() then
        GRIPEMS:Print(L["GEMS_DELETE_COMBAT"])
        return
    end
    -- Clear UI state BEFORE engine cleanup so RefreshDataProvider
    -- sees clean selectedSequence during the SEQUENCE_DELETED callback
    local UI = GRIPEMS.UI
    if UI and UI.selectedSequence == arg then
        UI.selectedSequence = nil
        if GRIPEMS.SequenceEditor then
            GRIPEMS.SequenceEditor:Clear()
        end
    end
    -- Purge saved keybind data across ALL specs (permanent delete)
    local KM = GRIPEMS.KeybindManager
    if KM and KM.PurgeKeybinds then
        KM:PurgeKeybinds(arg)
    end
    -- Engine teardown: unbind live key, hide button, remove from
    -- engine.sequences + SavedVariables, delete macro stub,
    -- fire SEQUENCE_DELETED (triggers RefreshDataProvider via callback)
    GRIPEMS.Engine:DeactivateSequence(arg)
    GRIPEMS:Print(string.format(L["GEMS_DELETED"], arg))
end

--- Handle /gems list: print all active sequences with step info.
local function HandleList()
    local list = GRIPEMS.Engine:GetSequenceList()
    if #list == 0 then
        GRIPEMS:Print(L["GEMS_LIST_EMPTY"])
        return
    end
    GRIPEMS:Print(string.format(L["GEMS_LIST_HEADER"], #list))
    for _, entry in ipairs(list) do
        GRIPEMS:Print(
            string.format(
                L["GEMS_LIST_ENTRY"],
                entry.name,
                entry.stepCount,
                entry.currentStep,
                entry.stepCount,
                entry.stepFunction
            )
        )
    end
end

--- Handle /gems reset <name>: reset sequence to step 1.
--- @param arg string Sequence name (required)
local function HandleReset(arg)
    if arg == "" then
        GRIPEMS:Print(L["GEMS_RESET_NEED_NAME"])
        return
    end
    if not GRIPEMS.Engine.sequences[arg] then
        GRIPEMS:Print(string.format(L["GEMS_NOT_FOUND"], arg))
        return
    end
    GRIPEMS.Engine:ResetStep(arg)
    GRIPEMS:Print(string.format(L["GEMS_RESET_DONE"], arg))
end

--- Handle /gems debug [subcommand]: toggle debug mode or dispatch subcommands.
--- @param arg string Optional subcommand (e.g. "rowrefresh")
local function HandleDebug(arg)
    local sub = (arg or ""):lower():trim()

    if sub == "rowrefresh" then
        local SLV = GRIPEMS.StepListView
        if SLV and SLV.ToggleDebugRowRefresh then
            local state = SLV:ToggleDebugRowRefresh()
            GRIPEMS:Print("RefreshCurrentRow: " .. (state and "DISABLED" or "ENABLED"))
        else
            GRIPEMS:Print("StepListView not loaded")
        end
        return
    end

    -- G7-POLISH-SUPPRESS-CYCLE-DOC (L379): empirical introspection for the
    -- ReloadGate suppress cycle. Prints pending / suppressed / panelHookInstalled
    -- so Cowork can verify the first-panel-close-after-Later no-op semantics.
    if sub == "reloadgate" then
        local R = GRIPEMS.ReloadGate
        if not R then
            GRIPEMS:Print("ReloadGate module not loaded")
            return
        end
        local pendingCount = 0
        if type(R.pending) == "table" then
            for _ in pairs(R.pending) do
                pendingCount = pendingCount + 1
            end
        end
        GRIPEMS:Print(
            string.format(
                "ReloadGate state: pending=%d suppressed=%s panelHookInstalled=%s",
                pendingCount,
                tostring(R.suppressed),
                tostring(R._panelHookInstalled)
            )
        )
        return
    end

    -- Default: toggle debug mode (existing behavior)
    local S = GRIPEMS.Settings
    if not S then
        return
    end
    local current = S:Get("debug")
    S:Set("debug", not current)
    -- Auto-show/hide debug window when toggling debug mode
    local DW = GRIPEMS.DebugWindow
    if DW then
        if S:Get("debug") then
            DW:Show()
        end
    end
    if S:Get("debug") then
        GRIPEMS:Print(L["GEMS_DEBUG_ENABLED"])
    else
        GRIPEMS:Print(L["GEMS_DEBUG_DISABLED"])
    end
end

--- Handle /gems diag: display execution diagnostics (CPS, top spells, gear variables).
--- @param arg string Optional argument (unused currently)
local function HandleDiag(arg)
    local ET = GRIPEMS.ExecutionTracer
    if not ET then
        GRIPEMS:Print("ExecutionTracer not loaded")
        return
    end

    GRIPEMS:Print(L["GEMS_DIAG_HEADER"])

    -- Tracer active status
    local tracerActive = ET:IsActive()
    GRIPEMS:Print(
        string.format(L["GEMS_DIAG_TRACER"], tracerActive and L["GEMS_DIAG_TRACER_ON"] or L["GEMS_DIAG_TRACER_OFF"])
    )

    -- Real-time CPS
    local cps = ET:GetClickRate()
    GRIPEMS:Print(string.format(L["GEMS_DIAG_CPS"], cps))

    -- Total casts tracked
    local totalCasts = 0
    for _, stat in pairs(ET.spellStats) do
        totalCasts = totalCasts + stat.casts
    end
    GRIPEMS:Print(string.format(L["GEMS_DIAG_TOTAL"], totalCasts))

    -- Configured click rate
    local S = GRIPEMS.Settings
    local effectiveMS = S and S:GetEffectiveClickRate() or 250
    GRIPEMS:Print(string.format(L["GEMS_DIAG_CONFIGURED"], effectiveMS))

    if totalCasts == 0 then
        GRIPEMS:Print(L["GEMS_DIAG_NO_DATA"])
    else
        -- Top 5 spells
        local topSpells = ET:GetTopSpells(5)
        if #topSpells > 0 then
            GRIPEMS:Print(L["GEMS_DIAG_TOP_SPELLS"])
            for i, spell in ipairs(topSpells) do
                GRIPEMS:Print(string.format(L["GEMS_DIAG_SPELL_ROW"], i, spell.name, spell.spellID, spell.casts))
            end
        end
    end

    -- Gear variables section (Feature 5 integration)
    local GV = GRIPEMS.GearVariables
    if GV then
        local gearVars = GV:GetAll()
        local count = 0
        for _ in pairs(gearVars) do
            count = count + 1
        end
        if count > 0 then
            GRIPEMS:Print(L["GEMS_GEAR_VAR_HEADER"])
            for varName, spellName in pairs(gearVars) do
                GRIPEMS:Print(string.format(L["GEMS_GEAR_VAR_ROW"], varName, spellName))
            end
        end
    end
end

--- Handle /gems msadvisor [name]: recommend optimal click rate based on haste.
--- @param arg string Optional sequence name
local function HandleMSAdvisor(arg)
    -- Optimizer references
    local SQWO = GRIPEMS.SQWOptimizer
    local useOptimizer = SQWO and SQWO:IsActive()

    -- Haste and GCD.
    -- WoW 12.0+ secret-value defense: pcall the haste-scaled fallback
    -- because GetHaste() returns a secret-tagged number that fails
    -- arithmetic from addon-tainted code. Sister site of
    -- TempoAdvisor.lua:GetLiveGCD (4f93676) and
    -- SQWOptimizer.lua:GetCurrentGCD.
    local haste = GetHaste() or 0
    local gcdMS
    if useOptimizer then
        gcdMS = math.floor(SQWO:GetCurrentGCD())
    else
        local ok, calc = pcall(function()
            return math.max(750, math.floor(1500 / (1 + haste / 100)))
        end)
        gcdMS = (ok and calc) or math.max(750, 1500)
    end

    -- World latency
    local lagWorld
    if useOptimizer and SQWO.ewmaLatency then
        lagWorld = math.floor(SQWO.ewmaLatency)
    else
        local _, _, _, rawLag = GetNetStats()
        lagWorld = rawLag or 0
    end

    -- Spell queue window
    local sqw
    if useOptimizer and SQWO.lastAppliedSQW then
        sqw = SQWO.lastAppliedSQW
    else
        sqw = tonumber(C_CVar.GetCVar("SpellQueueWindow")) or 400
    end

    -- Recommended MS = GCD minus queue window plus network lag, floored at 100ms
    local recommended = math.max(100, gcdMS - sqw + lagWorld)

    -- Configured click rate
    local S = GRIPEMS.Settings
    local effectiveMS = S and S:GetEffectiveClickRate() or 250

    -- Delta and verdict
    local delta = effectiveMS - recommended
    local verdict
    if math.abs(delta) <= 50 then
        verdict = L["GEMS_MSADVISOR_GOOD"]
    elseif delta > 0 then
        verdict = L["GEMS_MSADVISOR_FASTER"]
    else
        verdict = L["GEMS_MSADVISOR_SLOWER"]
    end

    -- Header (with optional sequence name)
    local suffix = ""
    if arg and arg ~= "" then
        suffix = " [" .. arg .. "]"
    end
    GRIPEMS:Print(string.format(L["GEMS_MSADVISOR_HEADER"], suffix))

    -- Print diagnostics
    GRIPEMS:Print(string.format(L["GEMS_MSADVISOR_GCD"], gcdMS, haste))
    GRIPEMS:Print(string.format(L["GEMS_MSADVISOR_LAG"], lagWorld))
    GRIPEMS:Print(string.format(L["GEMS_MSADVISOR_SQW"], sqw))
    GRIPEMS:Print(string.format(L["GEMS_MSADVISOR_RECOMMEND"], recommended))
    GRIPEMS:Print(string.format(L["GEMS_MSADVISOR_CURRENT"], effectiveMS))
    GRIPEMS:Print(string.format(L["GEMS_MSADVISOR_DELTA"], delta, verdict))

    -- Sequence info if name provided
    if arg and arg ~= "" then
        if _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.sequences and GRIP_EMS_CHAR.sequences[arg] then
            local seqData = GRIP_EMS_CHAR.sequences[arg]
            local ver = GRIPEMS.Engine:GetActiveVersion(seqData)
            if ver and ver.steps then
                local stepCount = #ver.steps
                local rotationTime = stepCount * recommended
                GRIPEMS:Print(string.format(L["GEMS_MSADVISOR_ROTATION"], arg, stepCount, rotationTime))
            end
        else
            GRIPEMS:Print(string.format(L["GEMS_MSADVISOR_NOT_FOUND"], arg))
        end
    end
end

--- Handle /gems status: display engine diagnostics.
local function HandleStatus()
    local D = GRIPEMS.Defaults
    local activeCount = GRIPEMS.Engine:GetActiveCount()
    local _, perChar = GetNumMacros()
    local keyDown = GetCVar("ActionButtonUseKeyDown") or "?"
    local sqw = GetCVar("SpellQueueWindow") or "?"
    local oocCount = GRIPEMS.OOCQueue:GetCount()

    GRIPEMS:Print(L["GEMS_STATUS_HEADER"])
    GRIPEMS:Print(string.format(L["GEMS_STATUS_SEQUENCES"], activeCount))
    GRIPEMS:Print(string.format(L["GEMS_STATUS_MACROS"], perChar, D.MAX_PER_CHAR_MACROS))
    GRIPEMS:Print(string.format(L["GEMS_STATUS_KEYDOWN"], keyDown))
    GRIPEMS:Print(string.format(L["GEMS_STATUS_SQW"], sqw))
    GRIPEMS:Print(string.format(L["GEMS_STATUS_OOC"], oocCount))

    local corruptCount = GRIPEMS.Engine.corruptSequences and #GRIPEMS.Engine.corruptSequences or 0
    if corruptCount > 0 then
        GRIPEMS:Print(string.format("  Corrupt sequences: %d", corruptCount))
    end

    local KM = GRIPEMS.KeybindManager
    local bindCount = 0
    local binds = KM and KM:GetAllKeybinds()
    if binds then
        for _ in pairs(binds) do
            bindCount = bindCount + 1
        end
    end
    GRIPEMS:Print(string.format(L["GEMS_STATUS_KEYBINDS"], bindCount))

    -- Click rate
    local clickRate = GRIPEMS.Settings:GetEffectiveClickRate()
    GRIPEMS:Print(string.format(L["GEMS_STATUS_CLICK_RATE"], clickRate))

    -- Saved loadout (user-meaningful identity per Phase 1.5b-polish empirical
    -- model). C_ClassTalents.GetLastSelectedSavedConfigID(specID) updates on
    -- switch; C_ClassTalents.GetActiveConfigID() returns the persistent scratch
    -- slot which is stable across switches and not user-meaningful. The scratch
    -- slot is still tracked by Engine.currentLoadoutID for cache invalidation
    -- (Engine.lua L1808) but is intentionally not surfaced to end users.
    local currentSpecID = nil
    if PlayerUtil and PlayerUtil.GetCurrentSpecID then
        currentSpecID = PlayerUtil.GetCurrentSpecID()
    end
    if not currentSpecID then
        local idx = GetSpecialization and GetSpecialization()
        if idx and GetSpecializationInfo then
            currentSpecID = GetSpecializationInfo(idx)
        end
    end
    local lastSelID = currentSpecID
            and C_ClassTalents
            and C_ClassTalents.GetLastSelectedSavedConfigID
            and C_ClassTalents.GetLastSelectedSavedConfigID(currentSpecID)
        or nil
    local lastSelName = nil
    if lastSelID and lastSelID > 0 and C_Traits and C_Traits.GetConfigInfo then
        local info = C_Traits.GetConfigInfo(lastSelID)
        lastSelName = info and info.name or nil
    end
    if lastSelID and lastSelID > 0 then
        GRIPEMS:Print(string.format(L["GEMS_STATUS_LOADOUT"], lastSelID, lastSelName or "?"))
    else
        GRIPEMS:Print(L["GEMS_STATUS_LOADOUT_NONE"])
    end
    local LM = GRIPEMS.LoadoutManager
    local pending = LM and LM:GetPendingSwitch() or nil
    if pending then
        GRIPEMS:Print(string.format(L["GEMS_STATUS_PENDING_ACTIVE"], pending.configID, GetTime() - pending.startedAt))
    else
        GRIPEMS:Print(L["GEMS_STATUS_PENDING_NONE"])
    end

    -- CVar health
    local cvarOk, cvarWarn, cvarBad = 0, 0, 0
    for _, section in ipairs(D.CVAR_SECTIONS) do
        for _, rec in ipairs(section.cvars) do
            local match = D.CvarIsRecommended(rec)
            if match or rec.recommended == nil then
                cvarOk = cvarOk + 1
            elseif rec.critical then
                cvarBad = cvarBad + 1
            else
                cvarWarn = cvarWarn + 1
            end
        end
    end
    GRIPEMS:Print(string.format("  CVars: %d OK, %d warnings, %d critical", cvarOk, cvarWarn, cvarBad))

    -- GEMS_STATUS-SURFACE-CAUSE-COUNTS: summarize pendingChanges by cause so the
    -- user can see what kind of CVar drift is queued without opening the panel.
    local CPM = GRIPEMS.CvarProfileManager
    if CPM and CPM.pendingChanges and #CPM.pendingChanges > 0 then
        local byCause = {}
        for _, c in ipairs(CPM.pendingChanges) do
            local k = c.cause or "UNKNOWN"
            byCause[k] = (byCause[k] or 0) + 1
        end
        GRIPEMS:Print(string.format(L["GEMS_STATUS_CVAR_PENDING_LINE"], #CPM.pendingChanges))
        for cause, count in pairs(byCause) do
            local label = L["GEMS_CVAR_CHANGES_CAUSE_" .. cause] or cause
            GRIPEMS:Print(string.format(L["GEMS_STATUS_CVAR_CAUSE_LINE"], count, label))
        end
    end
end

--- Resolve a current-spec specID for the --loadout flag identifier lookup.
--- Mirrors the chain used by LoadoutManager.lua.
local function _GetCurrentSpecID()
    if PlayerUtil and PlayerUtil.GetCurrentSpecID then
        local id = PlayerUtil.GetCurrentSpecID()
        if id then
            return id
        end
    end
    local idx = GetSpecialization and GetSpecialization()
    if idx and GetSpecializationInfo then
        return (GetSpecializationInfo(idx))
    end
    return nil
end

--- Resolve a "--loadout <id-or-name>" identifier to a real loadout configID for
--- the current spec. Returns the configID on success, or nil on failure (after
--- printing GEMS_BIND_LOADOUT_NOT_FOUND).
local function _ResolveLoadoutIdent(identifier)
    if not identifier or identifier == "" then
        return nil
    end
    local asNumber = tonumber(identifier)
    if asNumber and C_Traits and C_Traits.GetConfigInfo and C_Traits.GetConfigInfo(asNumber) then
        return asNumber
    end
    local specID = _GetCurrentSpecID()
    if specID and C_ClassTalents and C_ClassTalents.GetConfigIDsBySpecID then
        local ids = C_ClassTalents.GetConfigIDsBySpecID(specID) or {}
        for _, cid in ipairs(ids) do
            local info = C_Traits and C_Traits.GetConfigInfo and C_Traits.GetConfigInfo(cid)
            if info and info.name == identifier then
                return cid
            end
        end
    end
    GRIPEMS:Print(string.format(L["GEMS_BIND_LOADOUT_NOT_FOUND"], identifier))
    return nil
end

--- Handle /gems bind <name> <key> [--loadout <id-or-name>]: bind a key to fire a
--- sequence. With the --loadout flag, the binding is written to the specified
--- loadout's overlay; otherwise routes through KM:SetKeybind (which dispatches
--- to per-spec or per-loadout based on the keybindsPerLoadout flag).
--- @param arg string Full slash arg
local function HandleBind(arg)
    if arg == "" then
        GRIPEMS:Print(L["GEMS_BIND_NEED_ARGS"])
        return
    end
    local before, after = arg, nil
    local flagStart, flagEnd = arg:find(" %-%-loadout ")
    if flagStart then
        before = arg:sub(1, flagStart - 1)
        after = arg:sub(flagEnd + 1)
    end
    local seqName, key = before:match("^(%S+)%s+(.+)")
    if not seqName or not key then
        GRIPEMS:Print(L["GEMS_BIND_NEED_ARGS"])
        return
    end
    key = key:upper():trim()
    if not GRIPEMS.Engine.sequences[seqName] then
        GRIPEMS:Print(string.format(L["GEMS_NOT_FOUND"], seqName))
        return
    end
    if after then
        local identifier = (after or ""):trim()
        if identifier == "" then
            GRIPEMS:Print(L["GEMS_BIND_NEED_ARGS"])
            return
        end
        local resolvedLoadoutID = _ResolveLoadoutIdent(identifier)
        if not resolvedLoadoutID then
            return
        end
        GRIPEMS.KeybindManager:_SetKeybindForLoadout(seqName, key, resolvedLoadoutID)
        return
    end
    GRIPEMS.KeybindManager:SetKeybind(seqName, key)
end

--- Handle /gems swap <name> <n>: pin a sequence's live (running) version to
--- index n until cleared. Out of combat it applies immediately; in combat the
--- secure reload defers through the OOC queue and applies when combat ends.
--- @param arg string Full slash arg "<sequenceName> <version#>"
local function HandleSwap(arg)
    local seqName, n = (arg or ""):match("^(%S+)%s+(%S+)")
    local idx = tonumber(n)
    if not seqName or not idx then
        GRIPEMS:Print(L["GEMS_SWAP_USAGE"])
        return
    end
    if not GRIPEMS.Engine.sequences[seqName] then
        GRIPEMS:Print(string.format(L["GEMS_NOT_FOUND"], seqName))
        return
    end
    if not GRIPEMS.Engine:SetVersionPin(seqName, idx) then
        GRIPEMS:Print(L["GEMS_SWAP_USAGE"])
        return
    end
    if GRIPEMS.OOCQueue:IsRestricted() then
        GRIPEMS:Print(string.format(L["GEMS_SWAP_DONE_COMBAT"], seqName, idx))
    else
        GRIPEMS:Print(string.format(L["GEMS_SWAP_DONE"], seqName, idx))
    end
end

--- Handle /gems unpin <name>: clear a sequence's version pin so it follows its
--- context override / default version again.
--- @param arg string Sequence name
local function HandleUnpin(arg)
    local seqName = (arg or ""):trim()
    if seqName == "" then
        GRIPEMS:Print(L["GEMS_UNPIN_USAGE"])
        return
    end
    if not GRIPEMS.Engine.sequences[seqName] then
        GRIPEMS:Print(string.format(L["GEMS_NOT_FOUND"], seqName))
        return
    end
    GRIPEMS.Engine:ClearVersionPin(seqName)
    GRIPEMS:Print(string.format(L["GEMS_UNPIN_DONE"], seqName))
end

--- Handle /gems unbind <name> [--loadout <id-or-name>]: remove a keybinding.
--- With the --loadout flag, only the per-loadout overlay entry is removed.
--- Without it, the per-spec layer entry is removed via KM:ClearKeybind.
--- @param arg string Full slash arg
local function HandleUnbind(arg)
    if arg == "" then
        GRIPEMS:Print(L["GEMS_UNBIND_NEED_NAME"])
        return
    end
    local before, after = arg, nil
    local flagStart, flagEnd = arg:find(" %-%-loadout ")
    if flagStart then
        before = arg:sub(1, flagStart - 1)
        after = arg:sub(flagEnd + 1)
    end
    local seqName = before:trim()
    if not GRIPEMS.Engine.sequences[seqName] then
        GRIPEMS:Print(string.format(L["GEMS_NOT_FOUND"], seqName))
        return
    end
    if after then
        local identifier = (after or ""):trim()
        if identifier == "" then
            GRIPEMS:Print(L["GEMS_UNBIND_NEED_NAME"])
            return
        end
        local resolvedLoadoutID = _ResolveLoadoutIdent(identifier)
        if not resolvedLoadoutID then
            return
        end
        GRIPEMS.KeybindManager:_ClearKeybindForLoadout(seqName, resolvedLoadoutID)
        return
    end
    GRIPEMS.KeybindManager:ClearKeybind(seqName)
end

--- Handle /gems binds: list all keybindings for the current spec.
--- With the "restore" argument, re-applies the last-known-good snapshot (the
--- keybind-loss self-heal) instead of listing.
--- @param arg string|nil Optional subcommand ("restore")
local function HandleBinds(arg)
    if arg and string.lower(arg) == "restore" then
        GRIPEMS.KeybindManager:RestoreLastKnownKeybinds()
        return
    end
    local KM = GRIPEMS.KeybindManager
    local spec = KM:GetCurrentSpec()
    local binds = KM:GetAllKeybinds()
    if not binds or not next(binds) then
        GRIPEMS:Print(L["GEMS_BINDS_EMPTY"])
        return
    end
    GRIPEMS:Print(string.format(L["GEMS_BINDS_HEADER"], spec))
    for key, seqName in pairs(binds) do
        GRIPEMS:Print(string.format(L["GEMS_BINDS_ENTRY"], key, seqName))
    end
end

--- Handle /gems import [string]: open paste frame, or direct-import if arg given.
--- With no arg, opens the AceGUI paste frame (recommended for long strings).
--- With an arg, attempts direct import as fallback for short/programmatic strings.
--- @param arg string Optional encoded import string
local function HandleImport(arg)
    if arg == "" then
        -- No arg: open paste frame
        GRIPEMS.ImportFrame:Show()
        return
    end

    -- If arg is short, warn that paste frame is recommended for real imports
    if #arg < 100 then
        GRIPEMS:Print(L["GEMS_IMPORT_SHORT_STRING"])
    end

    local LI = GRIPEMS.LegacyImport
    local ok, result = LI.Import(arg)
    if ok then
        GRIPEMS:PrintMigrationReport(result, "import")
    else
        GRIPEMS:Print(string.format(L["GEMS_IMPORT_FAILED"], tostring(result)))
        -- If direct import failed and it looks like truncation, suggest paste frame
        if #arg > 200 then
            GRIPEMS:Print(L["GEMS_IMPORT_USE_FRAME"])
        end
    end
end

--- Handle /gems export <name>: encode an active sequence as a GRIP string.
--- @param arg string Sequence name
local function HandleExport(arg)
    if arg == "" then
        GRIPEMS:Print(L["GEMS_EXPORT_USAGE"])
        return
    end

    local GE = GRIPEMS.GRIPExport
    local deps = GE.ResolveVariableDeps({ arg })
    if next(deps) then
        local EF = GRIPEMS.ExportFrame
        if EF then
            EF:Show(arg)
        end
    else
        local ok, result = GE.Export(arg)
        if ok then
            local EF = GRIPEMS.ExportFrame
            if EF then
                EF:Show(arg, result)
            else
                GRIPEMS:Print(string.format(L["GEMS_EXPORT_RESULT"], result))
            end
        else
            GRIPEMS:Print(string.format(L["GEMS_EXPORT_FAILED"], tostring(result)))
        end
    end
end

--- Handle /gems migrate: bulk-import all sequences from a compatible sequencer.
local function HandleMigrate()
    if not GRIPEMS.LegacyMigrate then
        GRIPEMS:Print("Migration module not loaded")
        return
    end
    local status = GRIPEMS.LegacyMigrate.GetSourceStatus()
    if status == "none" then
        GRIPEMS:Print(L["GEMS_MIGRATE_NO_SOURCE"])
        return
    elseif status == "disabled" then
        GRIPEMS:Print(L["GEMS_MIGRATE_SOURCE_DISABLED"])
        return
    end
    local ok, results = GRIPEMS.LegacyMigrate.MigrateAll(false)
    if ok then
        GRIPEMS:PrintMigrationReport(results, "migrate")
    else
        GRIPEMS:Print(string.format(L["GEMS_MIGRATE_FAILED"], tostring(results)))
    end
end

--- Print a structured migration/import report to chat and debug window.
--- @param results table Import results table from import or migration modules
--- @param source string "import" or "migrate"
function GRIPEMS:PrintMigrationReport(results, source)
    if not results then
        return
    end

    local function report(msg)
        GRIPEMS:Print(msg)
        GRIPEMS:Debug(msg)
    end

    -- 1) Header
    if source == "migrate" then
        report("|cFF00FF00" .. L["GEMS_REPORT_HEADER_MIGRATE"] .. "|r")
    else
        report("|cFF00FF00" .. L["GEMS_REPORT_HEADER_IMPORT"] .. "|r")
    end

    -- 2) Summary line
    local seqCount = results.count or 0
    local varCount = results.varsImported or 0
    report(string.format(L["GEMS_REPORT_IMPORTED"], seqCount, varCount))
    if source == "migrate" then
        local dormantCount = results.dormantCount or 0
        if dormantCount > 0 then
            report(string.format(L["GEMS_REPORT_DORMANT"], dormantCount))
        end
    end

    local skipped = results.skipped or 0
    local varsSkipped = results.varsSkipped or 0
    if skipped > 0 then
        report(string.format(L["GEMS_REPORT_SKIPPED"], skipped))
    end
    if varsSkipped > 0 then
        report(string.format(L["GEMS_VAR_IMPORT_SKIPPED"], varsSkipped))
    end

    -- 3) Sequence list
    if results.names and #results.names > 0 then
        for _, name in ipairs(results.names) do
            local stepCount = results.stepCounts and results.stepCounts[name] or 0
            local stepFunc = results.stepFunctions and results.stepFunctions[name] or "Sequential"
            report(string.format(L["GEMS_REPORT_SEQ_ENTRY"], name, stepCount, stepFunc))
        end
    end

    -- 4) Known limitations (only print lines where count > 0)
    local versionsDropped = results.versionsDropped or 0
    local pausesConverted = results.pausesConverted or 0
    local pauseSteps = results.pauseSteps or 0
    local embedsSkipped = results.embedsSkipped or 0
    local truncatedSteps = results.truncatedSteps or 0
    local encryptedSkipped = results.encryptedSkipped or 0

    if
        versionsDropped > 0
        or pausesConverted > 0
        or embedsSkipped > 0
        or truncatedSteps > 0
        or encryptedSkipped > 0
    then
        report("|cFFFFFF00" .. L["GEMS_REPORT_LIMITATIONS"] .. "|r")
        if versionsDropped > 0 then
            report(string.format(L["GEMS_REPORT_VERSIONS_DROPPED"], versionsDropped))
        end
        if pausesConverted > 0 then
            report(string.format(L["GEMS_REPORT_PAUSES_CONVERTED"], pausesConverted, pauseSteps))
        end
        if embedsSkipped > 0 then
            report(string.format(L["GEMS_REPORT_EMBEDS_SKIPPED"], embedsSkipped))
        end
        if truncatedSteps > 0 then
            report(string.format(L["GEMS_REPORT_TRUNCATED"], truncatedSteps))
        end
        if encryptedSkipped > 0 then
            report(string.format(L["GEMS_REPORT_ENCRYPTED_SKIPPED"], encryptedSkipped))
        end
    end

    -- 5) Warnings (per-sequence detail)
    if results.warnings and #results.warnings > 0 then
        for _, w in ipairs(results.warnings) do
            report(string.format(L["GEMS_IMPORT_WARNING"], w))
        end
    end

    -- 6) Keybind migration summary (migrate only)
    if source == "migrate" then
        local kbMigrated = results.keybindsMigrated or 0
        local kbSkipped = results.keybindsSkipped or 0
        local kbConflicts = results.keybindConflicts or 0
        if kbMigrated > 0 or kbSkipped > 0 or kbConflicts > 0 then
            report(string.format(L["GEMS_MIGRATE_KEYBINDS"], kbMigrated, kbSkipped, kbConflicts))
        end
        if results.aoWarning then
            report("|cFFFFFF00" .. results.aoWarning .. "|r")
        end
    end

    -- 7) Post-migration guidance (migrate only)
    if source == "migrate" then
        report("|cFF888888" .. L["GEMS_REPORT_TIP_VERIFY"] .. "|r")
        report("|cFF888888" .. L["GEMS_REPORT_TIP_VERSIONS"] .. "|r")
    end
end

--- Handle /gems testlocale: automated round-trip test of locale translation.
--- Translates spell names to IDs and back, reports pass/fail for each case.
local function HandleTestLocale()
    local SC = GRIPEMS.SpellCache
    if not SC then
        GRIPEMS:Print("|cFFFF4444SpellCache module not available.|r")
        return
    end

    if not SC.ready then
        GRIPEMS:Print("|cFFFFFF00Warning: Spell cache has not loaded yet." .. " Results may be incomplete.|r")
    end

    -- Auto-open debug window and clear it for clean test output
    local DW = GRIPEMS.DebugWindow
    if DW then
        DW:Show()
        DW:Clear()
    end
    -- Helper: output to both chat and debug window
    local function Out(msg)
        GRIPEMS:Print(msg)
        if DW then
            DW:AddMessage(msg)
        end
    end

    local tests = {
        { label = "Simple /cast", input = "/cast Kill Command" },
        { label = "/cast with ! prefix", input = "/cast !Barbed Shot" },
        {
            label = "/castsequence with reset",
            input = "/castsequence reset=target Barbed Shot, Cobra Shot," .. " Kill Command",
        },
        {
            label = "/cast with conditional + fallback",
            input = "/cast [mod:alt] Bestial Wrath; Kill Command",
        },
        { label = "/cancelaura", input = "/cancelaura Aspect of the Cheetah" },
        {
            label = "Conditional on each fallback branch",
            input = "/cast [talent:1/1] Kill Shot; [talent:1/2] Cobra Shot",
        },
        {
            label = "Multi-line macrotext (passthrough test)",
            input = "/stopmacro [channeling]\n/cast Kill Command",
        },
        { label = "/use with item (passthrough)", input = "/use 13" },
        {
            label = "/castsequence with conditionals",
            input = "/castsequence [mod:shift] reset=combat Barbed Shot," .. " Multi-Shot",
        },
    }

    -- Item tests
    local test10 = { label = "/use item by name (Healthstone)", input = "/use Healthstone" }
    table.insert(tests, test10)
    local test11 = { label = "/use numeric slot passthrough", input = "/use 13" }
    table.insert(tests, test11)

    -- Toy tests
    local test12 = { label = "/usetoy with apostrophe", input = "/usetoy Lil' Ragnaros" }
    table.insert(tests, test12)

    -- Edge case tests
    local test13 = { label = "Colon in spell name (Shadow Word: Pain)", input = "/cast Shadow Word: Pain" }
    table.insert(tests, test13)
    local test14 = { label = "#showtooltip passthrough (not translatable)", input = "#showtooltip Kill Command" }
    table.insert(tests, test14)
    local test15 = { label = "Empty conditional brackets", input = "/cast [] Bestial Wrath" }
    table.insert(tests, test15)
    local test16 = {
        label = "Multi-branch conditionals (3 fallbacks)",
        input = "/cast [mod:shift,@focus] Holy Light; [mod:alt] Flash of Light; Holy Shock",
    }
    table.insert(tests, test16)

    local passed = 0
    local total = #tests

    Out("--- Locale Round-Trip Test ---")

    for i, t in ipairs(tests) do
        local idVersion = SC:TranslateMacrotext(t.input, "toIDs")
        local roundTripped = SC:TranslateMacrotext(idVersion, "toNames")

        -- Show intermediate ID-tagged version (grey)
        local idDisplay = idVersion:gsub("\n", "\\n")
        Out(string.format("  [%d] IDs: |cFF888888%s|r", i, idDisplay))

        if roundTripped == t.input then
            passed = passed + 1
            Out(string.format("  [%d] |cFF00FF00PASS|r %s", i, t.label))
        else
            local origDisplay = t.input:gsub("\n", "\\n")
            local rtDisplay = roundTripped:gsub("\n", "\\n")
            Out(string.format("  [%d] |cFFFF4444FAIL|r %s", i, t.label))
            Out(string.format("       Original:     %s", origDisplay))
            Out(string.format("       Round-tripped: %s", rtDisplay))
        end
    end

    Out(string.format("--- %d/%d tests passed ---", passed, total))

    -- Cross-locale catalog resolution (the non-enUS import fix). The bundled
    -- English-keyed catalog must resolve an English spell name to an ID on ANY
    -- client locale -- this is what lets imported English macrotext localize.
    Out("")
    Out("--- Cross-Locale Catalog Resolution ---")
    if SC._CatalogIDForName then
        local catID = SC:_CatalogIDForName("Path of Frost")
        total = total + 1
        if type(catID) == "number" then
            passed = passed + 1
            Out(string.format("  |cFF00FF00PASS|r English 'Path of Frost' -> {spell:%d} on %s", catID, GetLocale()))
        else
            Out(string.format("  |cFFFF4444FAIL|r English 'Path of Frost' did not resolve on %s", GetLocale()))
        end
    else
        Out("  |cFFFFFF00SKIP|r SC:_CatalogIDForName not available (fix not loaded)")
    end

    -- Phase 2e: Healing simulation
    Out("")
    Out("--- Locale Healing Simulation ---")
    local SC2 = GRIPEMS.SpellCache
    local Engine = GRIPEMS.Engine

    if not Engine or not Engine.HealLocaleSteps then
        Out("|cFFFF4444Engine:HealLocaleSteps not available. Phase 2c missing.|r")
    elseif not SC2 or not SC2.ready then
        Out("|cFFFF4444SpellCache not ready. Cannot run healing sim.|r")
    elseif not _G.GRIP_EMS_CHAR or not GRIP_EMS_CHAR.sequences then
        Out("|cFFFF4444No sequences loaded. Cannot run healing sim.|r")
    else
        -- Pick the first sequence that has taggedSteps on any version
        local testName, testVersion
        for name, seqData in pairs(GRIP_EMS_CHAR.sequences) do
            if type(seqData) == "table" then
                for _, version in ipairs(type(seqData.versions) == "table" and seqData.versions or {}) do
                    if version.taggedSteps and version.stepsLocale then
                        testName = name
                        testVersion = version
                        break
                    end
                end
            end
            if testName then
                break
            end
        end

        if not testName then
            Out(
                "|cFFFFFF00No sequences with taggedSteps found."
                    .. " Run /gems revalidate first to tag existing sequences.|r"
            )
        else
            Out(string.format("  Using sequence: |cFF88CCFF%s|r", testName))

            -- Save original state
            local origSteps = {}
            for i, step in ipairs(testVersion.steps) do
                origSteps[i] = step
            end
            local origKeyPress = testVersion.keyPress
            local origKeyRelease = testVersion.keyRelease

            -- Fake a locale mismatch
            testVersion.stepsLocale = "xxXX"
            Out("  Set stepsLocale to 'xxXX' (fake mismatch)")

            -- Run healing
            Engine:HealLocaleSteps()
            Out("  Ran HealLocaleSteps()")

            -- Check results
            local healPassed = true
            if testVersion.stepsLocale ~= GetLocale() then
                Out(
                    string.format(
                        "  |cFFFF4444FAIL|r stepsLocale not updated" .. " (expected %s, got %s)",
                        GetLocale(),
                        testVersion.stepsLocale or "nil"
                    )
                )
                healPassed = false
            else
                Out(string.format("  |cFF00FF00PASS|r stepsLocale updated to %s", testVersion.stepsLocale))
            end

            -- Verify steps survived (should be identical since
            -- same locale: tag -> toNames -> same names)
            local stepsMatch = true
            for i, origStep in ipairs(origSteps) do
                if testVersion.steps[i] ~= origStep then
                    stepsMatch = false
                    Out(
                        string.format(
                            "  |cFFFF4444DIFF|r step[%d]: '%s' -> '%s'",
                            i,
                            origStep,
                            testVersion.steps[i] or "nil"
                        )
                    )
                end
            end
            if stepsMatch then
                Out("  |cFF00FF00PASS|r All steps match after heal")
            else
                Out("  |cFFFFFF00WARN|r Steps differ after heal" .. " (may be OK if spell names normalized)")
                healPassed = false
            end

            -- Verify keyPress/keyRelease survived
            if origKeyPress and origKeyPress ~= "" then
                if testVersion.keyPress == origKeyPress then
                    Out("  |cFF00FF00PASS|r keyPress preserved")
                else
                    Out(
                        string.format(
                            "  |cFFFF4444FAIL|r keyPress changed: '%s' -> '%s'",
                            origKeyPress,
                            testVersion.keyPress or "nil"
                        )
                    )
                    healPassed = false
                end
            end
            if origKeyRelease and origKeyRelease ~= "" then
                if testVersion.keyRelease == origKeyRelease then
                    Out("  |cFF00FF00PASS|r keyRelease preserved")
                else
                    Out(
                        string.format(
                            "  |cFFFF4444FAIL|r keyRelease changed: '%s' -> '%s'",
                            origKeyRelease,
                            testVersion.keyRelease or "nil"
                        )
                    )
                    healPassed = false
                end
            end

            -- No restore needed: HealLocaleSteps already set
            -- stepsLocale to GetLocale() and steps are correct.
            -- Restoring origLocale would create a mismatch.

            if healPassed then
                Out("  |cFF00FF00Healing simulation PASSED|r")
                passed = passed + 1
            else
                Out("  |cFFFF4444Healing simulation FAILED|r")
            end
            total = total + 1
        end
    end

    Out(string.format("--- Final: %d/%d tests passed ---", passed, total))
    if DW then
        Out("|cFF888888Use the Copy button in the Debug Window to copy results.|r")
    end
end

--- Handle /gems testspellid: test ResolveSpellIDsInMacrotext with numeric IDs.
--- Exercises the three patterns fixed in BUG-020:
--- (1) /Cast with capital C (case-insensitive), (2) /use alias, (3) conditions before ID.
local function HandleTestSpellID()
    local LI = GRIPEMS.LegacyImport
    if not LI or not LI.ResolveSpellIDsInMacrotext then
        GRIPEMS:Print("|cFFFF4444LegacyImport module not available.|r")
        return
    end

    -- Auto-open debug window and clear it for clean test output
    local DW = GRIPEMS.DebugWindow
    if DW then
        DW:Show()
        DW:Clear()
    end
    -- Helper: output to both chat and debug window
    local function Out(msg)
        GRIPEMS:Print(msg)
        if DW then
            DW:AddMessage(msg)
        end
    end

    -- Resolve spell names at runtime so tests work on any locale/class.
    -- If GetSpellName returns nil (player lacks the spell), both input
    -- and expected fall back to the numeric string, so the test still passes.
    local name34026 = C_Spell.GetSpellName(34026) or "34026"
    local name217200 = C_Spell.GetSpellName(217200) or "217200"
    local name19574 = C_Spell.GetSpellName(19574) or "19574"

    local tests = {
        {
            label = "/Cast capital C with numeric ID",
            input = "/Cast 34026",
            expected = "/Cast " .. name34026,
        },
        {
            label = "/use with numeric ID (passthrough, BUG-046)",
            input = "/use 217200",
            expected = "/use 217200",
        },
        {
            label = "/cast multi-condition + numeric ID",
            input = "/cast [mod:shift,@focus] 34026",
            expected = "/cast [mod:shift,@focus] " .. name34026,
        },
        {
            label = "/Cast semicolon fallback with conditions per segment",
            input = "/Cast [mod:alt] 19574; [nomod] 34026",
            expected = "/Cast [mod:alt] " .. name19574 .. "; [nomod] " .. name34026,
        },
        {
            label = "/use multi-condition (passthrough, BUG-046)",
            input = "/use [mod:ctrl,@player] 217200",
            expected = "/use [mod:ctrl,@player] 217200",
        },
        {
            label = "Passthrough: /castsequence resolved by its own branch",
            input = "/castsequence reset=target 217200, 34026",
            expected = "/castsequence reset=target " .. name217200 .. ", " .. name34026,
        },
        {
            label = "Multi-line: /Cast on line 2",
            input = "/stopmacro [channeling]\n/Cast 34026",
            expected = "/stopmacro [channeling]\n/Cast " .. name34026,
        },
    }

    local passed = 0
    local total = #tests

    Out("--- SpellID Resolution Test ---")

    for i, t in ipairs(tests) do
        local result = LI.ResolveSpellIDsInMacrotext(t.input)
        if result == t.expected then
            passed = passed + 1
            Out(string.format("  [%d] |cFF00FF00PASS|r %s", i, t.label))
        else
            Out(string.format("  [%d] |cFFFF4444FAIL|r %s", i, t.label))
            Out(string.format("       Expected: %s", t.expected))
            Out(string.format("       Got:      %s", result))
        end
    end

    Out(string.format("--- %d/%d tests passed ---", passed, total))
    if DW then
        Out("|cFF888888Use the Copy button in the Debug Window to copy results.|r")
    end
end

-- Slash command registration
SLASH_GRIPEMS1 = "/gems"
SLASH_GRIPEMS2 = "/gripems"
--- Handle /gems revalidate: force re-tag ALL sequences with spell IDs.
--- Recovery command for the spell-rename edge case: if a spell was renamed
--- in a WoW patch, existing taggedSteps contain the old ID. This re-tags
--- from current steps (which the user may have already fixed manually).
local function HandleRevalidate()
    local SC = GRIPEMS.SpellCache
    if not SC or not SC.ready then
        GRIPEMS:Print("|cFFFF4444SpellCache not ready. Try again shortly.|r")
        return
    end
    if not _G.GRIP_EMS_CHAR or not GRIP_EMS_CHAR.sequences then
        GRIPEMS:Print("|cFFFF4444No sequences loaded.|r")
        return
    end

    -- Auto-open debug window
    local DW = GRIPEMS.DebugWindow
    if DW then
        DW:Show()
        DW:Clear()
    end
    local function Out(msg)
        GRIPEMS:Print(msg)
        if DW then
            DW:AddMessage(msg)
        end
    end

    Out("--- Revalidate All Sequences ---")

    local retagged = 0
    local versions = 0
    for _, seqData in pairs(GRIP_EMS_CHAR.sequences) do
        if type(seqData) == "table" then
            for _, version in ipairs(type(seqData.versions) == "table" and seqData.versions or {}) do
                SC:NormalizeVersionLocale(version, seqData.classID)
                versions = versions + 1
            end
            retagged = retagged + 1
        end
    end

    -- Mark migration complete if not already
    if _G.GRIP_EMS_DB then
        GRIP_EMS_DB.taggedStepsMigrated = true
        GRIP_EMS_DB.pendingTagMigration = nil
    end

    Out(string.format("Revalidated %d sequence(s) (%d version(s)). All tags refreshed.", retagged, versions))

    -- Run SpellValidator to check for unknowns
    local SV = GRIPEMS.SpellValidator
    if SV then
        local results = SV:ValidateAll()
        local warn = 0
        for name, r in pairs(results.sequences) do
            if r.staleCount and r.staleCount > 0 then
                warn = warn + 1
                Out(
                    string.format(
                        "  |cFFFFFF00%s|r: %d unknown, %d talent-gated",
                        name,
                        r.unknownCount or 0,
                        r.knownCount or 0
                    )
                )
            end
        end
        if warn == 0 then
            Out("|cFF00FF00All sequences validated -- no issues found.|r")
        else
            Out(string.format("|cFFFFFF00%d sequence(s) have warnings (see above).|r", warn))
        end
    else
        Out("|cFF888888SpellValidator not loaded, skipping validation.|r")
    end

    if DW then
        Out("|cFF888888Use the Copy button in the Debug Window to copy results.|r")
    end
end

local function HandleMemcheck()
    -- Output helper: print + debug window
    local DW = GRIPEMS.DebugWindow
    if DW then
        DW:Show()
        DW:Clear()
    end
    local function Out(msg)
        GRIPEMS:Print(msg)
        if DW and DW.AddMessage then
            DW:AddMessage(msg)
        end
    end

    Out("--- Memory Diagnostics ---")

    -- 1) BEFORE GC
    UpdateAddOnMemoryUsage()
    local memBefore = GetAddOnMemoryUsage("GRIP-EMS") or 0
    Out(string.format("Memory BEFORE GC: %.2f MB", memBefore / 1024))

    -- 2) FORCED GC (2 cycles for weak tables)
    collectgarbage("collect")
    collectgarbage("collect")
    UpdateAddOnMemoryUsage()
    local memAfter = GetAddOnMemoryUsage("GRIP-EMS") or 0
    Out(string.format("Memory AFTER GC: %.2f MB (freed %.2f MB)", memAfter / 1024, (memBefore - memAfter) / 1024))

    -- 3) TABLE CENSUS
    Out("--- Table Census ---")
    local function CountPairs(t)
        if type(t) ~= "table" then
            return 0
        end
        local n = 0
        for _ in pairs(t) do
            n = n + 1
        end
        return n
    end

    local SC = GRIPEMS.SpellCache
    if SC then
        Out("  [SpellCache] spells: " .. (SC.spells and #SC.spells or 0) .. " entries")
        Out("  [SpellCache] byName: " .. CountPairs(SC.byName) .. " entries")
        Out("  [SpellCache] itemByName: " .. CountPairs(SC.itemByName) .. " entries")
        Out("  [SpellCache] toyByName: " .. CountPairs(SC.toyByName) .. " entries")
    end

    local eng = GRIPEMS.Engine
    if eng then
        Out("  [Engine] sequences: " .. CountPairs(eng.sequences) .. " entries")
    end

    local VS = GRIPEMS.VariableStore
    if VS and VS.GetAll then
        Out("  [VariableStore] variables: " .. CountPairs(VS:GetAll()) .. " entries")
    end

    if DW then
        Out("  [DebugWindow] messages: " .. (DW._count or 0) .. " entries")
    end

    local ET = GRIPEMS.ExecutionTracer
    if ET then
        if ET.history then
            Out("  [ExecutionTracer] history: " .. (ET._count or 0) .. " entries")
        end
        Out("  [ExecutionTracer] spellStats: " .. CountPairs(ET.spellStats) .. " entries")
        if ET._clickTimes then
            Out("  [ExecutionTracer] clickTimes: " .. #ET._clickTimes .. " entries")
        end
    end

    local T = GRIPEMS.Transmission
    if T then
        Out("  [Transmission] remoteLists: " .. CountPairs(T.remoteLists) .. " entries")
        Out("  [Transmission] pendingIncoming: " .. (T.GetPendingCount and T:GetPendingCount() or 0) .. " entries")
    end

    local MM = GRIPEMS.MacroManager
    if MM then
        Out("  [MacroManager] stubs: " .. CountPairs(MM.stubs) .. " entries")
    end

    local BI = GRIPEMS.BarIntegration
    if BI then
        Out("  [BarIntegration] trackedButtons: " .. CountPairs(BI.trackedButtons) .. " entries")
    end

    local TSuite = GRIPEMS.TestSuite
    if TSuite then
        Out("  [TestSuite] tests: " .. (TSuite.tests and #TSuite.tests or 0) .. " entries")
        Out("  [TestSuite] results: " .. (TSuite.results and #TSuite.results or 0) .. " entries")
    end

    -- 4) DEEP TABLE SIZER
    Out("--- Estimated Table Sizes ---")
    local function EstimateTableSize(t, seen, depth)
        if type(t) ~= "table" or depth > 10 then
            return 0
        end
        if seen[t] then
            return 0
        end
        seen[t] = true
        local bytes = 40 -- base table overhead
        for k, v in pairs(t) do
            bytes = bytes + 16 -- hash slot
            -- Key cost
            local kt = type(k)
            if kt == "string" then
                bytes = bytes + 24 + #k
            elseif kt == "number" then
                bytes = bytes + 8
            elseif kt == "table" then
                bytes = bytes + EstimateTableSize(k, seen, depth + 1)
            end
            -- Value cost
            local vt = type(v)
            if vt == "string" then
                bytes = bytes + 24 + #v
            elseif vt == "number" then
                bytes = bytes + 8
            elseif vt == "boolean" then
                bytes = bytes + 1
            elseif vt == "function" then
                bytes = bytes + 40
            elseif vt == "userdata" then
                bytes = bytes + 40
            elseif vt == "table" then
                bytes = bytes + EstimateTableSize(v, seen, depth + 1)
            end
        end
        -- Array portion
        local arrLen = #t
        if arrLen > 0 then
            bytes = bytes + arrLen * 8
        end
        return bytes
    end

    if SC and SC.spells then
        local sz = EstimateTableSize(SC.spells, {}, 1)
        Out(string.format("  [SpellCache] spells: ~%.1f KB estimated", sz / 1024))
    end
    if eng and eng.sequences then
        local sz = EstimateTableSize(eng.sequences, {}, 1)
        Out(string.format("  [Engine] sequences: ~%.1f KB estimated", sz / 1024))
    end
    if VS and VS.GetAll then
        local vsStore = VS:GetAll()
        if vsStore then
            local sz = EstimateTableSize(vsStore, {}, 1)
            Out(string.format("  [VariableStore] variables: ~%.1f KB estimated", sz / 1024))
        end
    end
    if ET and ET.spellStats then
        local sz = EstimateTableSize(ET.spellStats, {}, 1)
        Out(string.format("  [ExecutionTracer] spellStats: ~%.1f KB estimated", sz / 1024))
    end

    -- 5) FRAME COUNT
    Out("--- Frame Count ---")
    local frameCount = 0
    for k in pairs(_G) do
        if type(k) == "string" and k:find("^GRIPEMS_") then
            frameCount = frameCount + 1
        end
    end
    Out("  GRIPEMS_ global keys: " .. frameCount)

    -- 6) SAVEDVARIABLES SIZE
    Out("--- SavedVariables Size ---")
    if _G.GRIP_EMS_DB then
        local sz = EstimateTableSize(_G.GRIP_EMS_DB, {}, 1)
        Out(string.format("  GRIP_EMS_DB: ~%.1f KB estimated", sz / 1024))
    end
    if _G.GRIP_EMS_CHAR then
        local sz = EstimateTableSize(_G.GRIP_EMS_CHAR, {}, 1)
        Out(string.format("  GRIP_EMS_CHAR: ~%.1f KB estimated", sz / 1024))
    end
    if _G.GRIP_EMS_Settings then
        local sz = EstimateTableSize(_G.GRIP_EMS_Settings, {}, 1)
        Out(string.format("  GRIP_EMS_Settings: ~%.1f KB estimated", sz / 1024))
    end

    -- 7) LUA GC STATE
    local heapKB = collectgarbage("count")
    Out(string.format("Lua heap total: %.2f MB", heapKB / 1024))

    if DW then
        Out("|cFF888888Use the Copy button in the Debug Window to copy results.|r")
    end
end

--- Handle /gems perf: performance profiling diagnostics.
local function HandlePerf()
    local DW = GRIPEMS.DebugWindow
    if DW then
        DW:Show()
        DW:Clear()
    end
    local function Out(msg)
        GRIPEMS:Print(msg)
        if DW and DW.AddMessage then
            DW:AddMessage(msg)
        end
    end

    Out("=== GRIP-EMS Performance Report ===")

    -- Helper: count pairs in a table
    local function CountPairs(t)
        if type(t) ~= "table" then
            return 0
        end
        local n = 0
        for _ in pairs(t) do
            n = n + 1
        end
        return n
    end

    -- Helper: recursive frame walker
    local function WalkFrames(root, visitor, depth)
        depth = depth or 0
        if depth > 20 then
            return
        end
        local children = { root:GetChildren() }
        for _, child in ipairs(children) do
            visitor(child, depth)
            if child.GetChildren then
                WalkFrames(child, visitor, depth + 1)
            end
        end
    end

    -- Helper: parent chain string (2 levels)
    local function ParentChain(f)
        local parts = {}
        local cur = f
        for _ = 1, 3 do
            local nm = cur and cur.GetName and cur:GetName()
            if nm then
                parts[#parts + 1] = nm
            elseif cur and cur.GetDebugName and cur:GetDebugName() then
                parts[#parts + 1] = cur:GetDebugName()
            else
                parts[#parts + 1] = "(anon)"
            end
            cur = cur and cur.GetParent and cur:GetParent()
            if not cur then
                break
            end
        end
        return table.concat(parts, " < ")
    end

    ---------------------------------------------------------------------------
    -- 1) ONUPDATE SCAN
    ---------------------------------------------------------------------------
    pcall(function()
        Out("--- OnUpdate Scan ---")
        local onUpdateFrames = {}
        local roots = {}
        if _G.GRIPEMS_MainFrame then
            roots[#roots + 1] = _G.GRIPEMS_MainFrame
        end
        local extraNames = {
            "GRIPEMS_TrackerHUD",
            "GRIPEMS_FloatingMenu",
            "GRIPEMS_SpellPicker",
            "GRIPEMS_ComparisonFrame",
        }
        for _, name in ipairs(extraNames) do
            if _G[name] then
                roots[#roots + 1] = _G[name]
            end
        end
        for _, root in ipairs(roots) do
            if root:IsVisible() and root.GetScript and root:GetScript("OnUpdate") then
                onUpdateFrames[#onUpdateFrames + 1] = ParentChain(root)
            end
            WalkFrames(root, function(child)
                if child:IsVisible() and child.GetScript and child:GetScript("OnUpdate") then
                    onUpdateFrames[#onUpdateFrames + 1] = ParentChain(child)
                end
            end)
        end
        Out("  Visible frames with OnUpdate: " .. #onUpdateFrames)
        for _, chain in ipairs(onUpdateFrames) do
            Out("    " .. chain)
        end
    end)

    ---------------------------------------------------------------------------
    -- 2) CALLBACK AUDIT
    ---------------------------------------------------------------------------
    pcall(function()
        Out("--- Callback Audit ---")
        local cb = GRIPEMS.callbacks
        if cb and cb.events then
            local leaks = 0
            for event, handlers in pairs(cb.events) do
                local count = CountPairs(handlers)
                if count > 3 then
                    Out("  WARN: " .. event .. " has " .. count .. " handlers (possible leak)")
                    leaks = leaks + 1
                end
            end
            if leaks == 0 then
                Out("  All callback events have <= 3 handlers (OK)")
            end
        else
            Out("  No callbacks table found")
        end
    end)

    ---------------------------------------------------------------------------
    -- 3) ACTIVE TIMER/TICKER COUNT
    ---------------------------------------------------------------------------
    pcall(function()
        Out("--- Active Timers ---")
        local SV = GRIPEMS.SpellValidator
        if SV then
            Out("  SpellValidator.revalTimer: " .. (SV.revalTimer and "ACTIVE" or "idle"))
        end
        local SC = GRIPEMS.SpellCache
        if SC then
            Out("  SpellCache._debounceTimer: " .. (SC._debounceTimer and "ACTIVE" or "idle"))
        end
        local OOC = GRIPEMS.OOCQueue
        if OOC then
            Out(
                "  OOCQueue.ticker: "
                    .. (OOC.ticker and "ACTIVE" or "idle")
                    .. " (interval "
                    .. (GRIPEMS.Defaults.OOC_TICKER_INTERVAL or "?")
                    .. "s)"
            )
        end
        local SLV = GRIPEMS.StepListView
        if SLV then
            Out("  StepListView._refreshRowTimer: " .. (SLV._refreshRowTimer and "ACTIVE" or "idle"))
        end
    end)

    ---------------------------------------------------------------------------
    -- 4) FRAME COUNT
    ---------------------------------------------------------------------------
    pcall(function()
        Out("--- Frame Count ---")
        local totalVisible = 0
        local totalHidden = 0
        local mf = _G.GRIPEMS_MainFrame
        if mf then
            WalkFrames(mf, function(child)
                if child:IsVisible() then
                    totalVisible = totalVisible + 1
                else
                    totalHidden = totalHidden + 1
                end
            end)
        end
        local total = totalVisible + totalHidden
        Out(
            "  MainFrame children: " .. total .. " total (" .. totalVisible .. " visible, " .. totalHidden .. " hidden)"
        )
        if totalVisible > 500 then
            Out("  WARNING: visible frame count exceeds 500!")
        end

        -- Count GRIPEMS_ globals
        local globalCount = 0
        for k in pairs(_G) do
            if type(k) == "string" and k:find("^GRIPEMS_") then
                globalCount = globalCount + 1
            end
        end
        Out("  GRIPEMS_ global keys: " .. globalCount)
    end)

    ---------------------------------------------------------------------------
    -- 5) ANIMATION SCAN
    ---------------------------------------------------------------------------
    pcall(function()
        Out("--- Animation Scan ---")
        local playingAnims = {}
        local mf = _G.GRIPEMS_MainFrame
        if mf then
            local function checkAnims(f)
                if f:IsVisible() and f.GetAnimationGroups then
                    local groups = { f:GetAnimationGroups() }
                    for _, ag in ipairs(groups) do
                        if ag:IsPlaying() then
                            playingAnims[#playingAnims + 1] = {
                                frame = ParentChain(f),
                                looping = ag:GetLooping() or "NONE",
                            }
                        end
                    end
                end
            end
            checkAnims(mf)
            WalkFrames(mf, function(child)
                checkAnims(child)
            end)
        end
        Out("  Playing animations: " .. #playingAnims)
        for _, info in ipairs(playingAnims) do
            Out("    " .. info.frame .. " (loop: " .. tostring(info.looping) .. ")")
        end
    end)

    ---------------------------------------------------------------------------
    -- 6) MEMORY SNAPSHOT
    ---------------------------------------------------------------------------
    pcall(function()
        Out("--- Memory Snapshot ---")
        UpdateAddOnMemoryUsage()
        local mem = GetAddOnMemoryUsage("GRIP-EMS") or 0
        Out(string.format("  Addon memory: %.2f MB", mem / 1024))

        local SC = GRIPEMS.SpellCache
        if SC then
            Out("  SpellCache.spells: " .. (SC.spells and #SC.spells or 0))
            Out("  SpellCache.itemByName: " .. CountPairs(SC.itemByName))
            Out("  SpellCache.toyByName: " .. CountPairs(SC.toyByName))
            Out("  SpellCache.mounts: " .. (SC.mounts and #SC.mounts or 0))
            Out("  SpellCache.companions: " .. (SC.companions and #SC.companions or 0))
        end
        local eng = GRIPEMS.Engine
        if eng then
            Out("  Engine.sequences: " .. CountPairs(eng.sequences))
        end
        local SLV = GRIPEMS.StepListView
        if SLV and SLV.workingSteps then
            Out("  StepListView.workingSteps: " .. #SLV.workingSteps)
        end
    end)

    ---------------------------------------------------------------------------
    -- 7) ONUPDATE TIMING TEST (60-frame baseline)
    ---------------------------------------------------------------------------
    pcall(function()
        Out("--- OnUpdate Timing Test (60 frames) ---")
        local testFrame = CreateFrame("Frame")
        local samples = 0
        local totalTime = 0
        local lastTime = debugprofilestop()
        testFrame:SetScript("OnUpdate", function(self)
            local now = debugprofilestop()
            totalTime = totalTime + (now - lastTime)
            lastTime = now
            samples = samples + 1
            if samples >= 60 then
                self:SetScript("OnUpdate", nil)
                local avg = totalTime / 60
                Out(string.format("  Avg frame time: %.2f ms (60 frames, %.1f fps equiv)", avg, 1000 / avg))
            end
        end)
        -- Results print asynchronously after 60 frames
        Out("  (measuring -- results appear after 60 frames)")
    end)

    ---------------------------------------------------------------------------
    -- 8) GUI-SPECIFIC TIMING
    ---------------------------------------------------------------------------
    pcall(function()
        local mf = _G.GRIPEMS_MainFrame
        if not mf or not mf:IsShown() then
            Out("--- GUI Timing: MainFrame not shown, skipped ---")
            return
        end
        Out("--- GUI Timing ---")

        local function TimeFn(label, fn)
            local t0 = debugprofilestop()
            fn()
            local t1 = debugprofilestop()
            Out(string.format("  %s: %.3f ms", label, t1 - t0))
        end

        local SL = GRIPEMS.SequenceList
        if SL and SL.RefreshDataProvider then
            TimeFn("SequenceList:RefreshDataProvider", function()
                SL:RefreshDataProvider()
            end)
        end

        local SE = GRIPEMS.SequenceEditor
        if SE then
            if SE.UpdatePreview and SE.currentSequence then
                TimeFn("SequenceEditor:UpdatePreview", function()
                    SE:UpdatePreview()
                end)
            end
            if SE.UpdateSpellWarning then
                TimeFn("SequenceEditor:UpdateSpellWarning", function()
                    SE:UpdateSpellWarning()
                end)
            end
            if SE.RefreshDependencies then
                TimeFn("SequenceEditor:RefreshDependencies", function()
                    SE:RefreshDependencies()
                end)
            end
        end
    end)

    Out("=== End Performance Report ===")
    if DW then
        Out("|cFF888888Use the Copy button in the Debug Window to copy results.|r")
    end
end

--- Handle /gems monitor: 300-frame continuous profiler with function hooks.
local function HandleMonitor()
    if GRIPEMS._monitorActive then
        GRIPEMS:Print("Monitor already running.")
        return
    end
    GRIPEMS:Print("Starting 300-frame monitor (about 5 seconds)...")
    GRIPEMS._monitorActive = true

    local function Out(msg)
        GRIPEMS:Print("|cff00cc66Monitor:|r " .. msg)
    end

    -- Counters
    local counters = {}
    local function Track(name)
        counters[name] = { calls = 0, totalMs = 0 }
    end
    local function Hit(name, ms)
        local c = counters[name]
        if c then
            c.calls = c.calls + 1
            c.totalMs = c.totalMs + (ms or 0)
        end
    end

    Track("SH:Colorize")
    Track("SH:Strip")
    Track("RT:RefreshDisplay")
    Track("RT.editBox:OnTextChanged")
    Track("RT.scroll:OnSizeChanged")
    Track("SLV:RefreshAll")
    Track("SLV:RefreshTreeMode")
    Track("SE:UpdateTabContent")
    Track("SE:UpdatePreview")
    Track("SL:RefreshDataProvider")

    -- Save originals for unhooking
    local originals = {}
    local hooks = {}

    local function HookMethod(tbl, key, trackName)
        if not tbl or not tbl[key] then
            return
        end
        originals[trackName] = tbl[key]
        tbl[key] = function(...)
            local t0 = debugprofilestop()
            local r1, r2, r3, r4, r5 = originals[trackName](...)
            Hit(trackName, debugprofilestop() - t0)
            return r1, r2, r3, r4, r5
        end
        hooks[#hooks + 1] = { tbl = tbl, key = key, name = trackName }
    end

    local SH = GRIPEMS.SyntaxHighlight
    if SH then
        HookMethod(SH, "Colorize", "SH:Colorize")
        HookMethod(SH, "Strip", "SH:Strip")
    end

    local RT = GRIPEMS.RawTab
    if RT then
        HookMethod(RT, "RefreshDisplay", "RT:RefreshDisplay")
    end

    local SLV = GRIPEMS.StepListView
    if SLV then
        HookMethod(SLV, "RefreshAll", "SLV:RefreshAll")
        HookMethod(SLV, "RefreshTreeMode", "SLV:RefreshTreeMode")
    end

    local SE = GRIPEMS.SequenceEditor
    if SE then
        HookMethod(SE, "UpdateTabContent", "SE:UpdateTabContent")
        HookMethod(SE, "UpdatePreview", "SE:UpdatePreview")
    end

    local SL = GRIPEMS.SequenceList
    if SL then
        HookMethod(SL, "RefreshDataProvider", "SL:RefreshDataProvider")
    end

    -- Hook RawTab EditBox OnTextChanged (script hook)
    local rtEditBox = RT and RT.editBox
    local origRTOnTextChanged
    if rtEditBox and rtEditBox.GetScript then
        origRTOnTextChanged = rtEditBox:GetScript("OnTextChanged")
        if origRTOnTextChanged then
            rtEditBox:SetScript("OnTextChanged", function(self, ...)
                local t0 = debugprofilestop()
                origRTOnTextChanged(self, ...)
                Hit("RT.editBox:OnTextChanged", debugprofilestop() - t0)
            end)
        end
    end

    -- Hook RawTab scroll frame OnSizeChanged
    local rtScrollFrame = RT and RT.scrollFrame
    local origScrollSizeChanged
    if rtScrollFrame and rtScrollFrame.GetScript then
        origScrollSizeChanged = rtScrollFrame:GetScript("OnSizeChanged")
        if origScrollSizeChanged then
            rtScrollFrame:SetScript("OnSizeChanged", function(self, ...)
                local t0 = debugprofilestop()
                origScrollSizeChanged(self, ...)
                Hit("RT.scroll:OnSizeChanged", debugprofilestop() - t0)
            end)
        end
    end

    -- Per-frame timing
    local frameTimes = {}
    local frameCount = 0
    local lastTime = debugprofilestop()
    local monitorFrame = CreateFrame("Frame")

    monitorFrame:SetScript("OnUpdate", function(self)
        local now = debugprofilestop()
        frameCount = frameCount + 1
        frameTimes[frameCount] = now - lastTime
        lastTime = now

        if frameCount >= 300 then
            self:SetScript("OnUpdate", nil)
            GRIPEMS._monitorActive = false

            -- Restore method hooks
            for _, h in ipairs(hooks) do
                h.tbl[h.key] = originals[h.name]
            end

            -- Restore script hooks
            if rtEditBox and origRTOnTextChanged then
                rtEditBox:SetScript("OnTextChanged", origRTOnTextChanged)
            end
            if rtScrollFrame and origScrollSizeChanged then
                rtScrollFrame:SetScript("OnSizeChanged", origScrollSizeChanged)
            end

            -- Calculate stats
            local totalFrameTime = 0
            local maxFrameTime = 0
            for _, ft in ipairs(frameTimes) do
                totalFrameTime = totalFrameTime + ft
                if ft > maxFrameTime then
                    maxFrameTime = ft
                end
            end
            local avgFrameTime = totalFrameTime / frameCount
            local fps = 1000 / avgFrameTime

            -- Report
            Out("--- Monitor Report (300 frames) ---")
            Out(string.format("  Avg frame: %.2f ms (%.1f fps)", avgFrameTime, fps))
            Out(string.format("  Max frame: %.2f ms", maxFrameTime))
            Out(string.format("  Total wall: %.0f ms", totalFrameTime))
            Out("--- Function Call Counts ---")

            local sorted = {}
            for name, data in pairs(counters) do
                sorted[#sorted + 1] = { name = name, calls = data.calls, totalMs = data.totalMs }
            end
            table.sort(sorted, function(a, b)
                return a.calls > b.calls
            end)

            for _, entry in ipairs(sorted) do
                if entry.calls > 0 then
                    Out(
                        string.format(
                            "  %s: %d calls, %.3f ms total (%.3f ms avg)",
                            entry.name,
                            entry.calls,
                            entry.totalMs,
                            entry.calls > 0 and entry.totalMs / entry.calls or 0
                        )
                    )
                end
            end

            local zeroCount = 0
            for _, entry in ipairs(sorted) do
                if entry.calls == 0 then
                    zeroCount = zeroCount + 1
                end
            end
            if zeroCount > 0 then
                Out(string.format("  (%d tracked functions had 0 calls)", zeroCount))
            end

            Out("--- End Monitor Report ---")
        end
    end)
end

--- Handle /gems perftest: triple sub-mode profiler (events N / scan / reanalyze).
--- Sub-modes print via GRIPEMS:Print (visible regardless of /gems debug state).
local function HandlePerftest(arg)
    local sub, rest = (arg or ""):match("^(%S*)%s*(.*)$")
    sub = (sub or ""):lower()

    if sub == "" then
        -- No sub-mode: run the existing performance report (same as /gems perf).
        HandlePerf()
        return
    end

    if sub == "events" then
        if GRIPEMS._perftestEventsActive then
            GRIPEMS:Print("perftest events already running.")
            return
        end
        local seconds = tonumber(rest) or 30
        if seconds < 1 then
            seconds = 1
        end

        -- Target frames (top-5 hottest OnEvent handlers)
        local targets = {}
        local TA = GRIPEMS.TempoAdvisor
        if TA and TA.eventFrame then
            targets[#targets + 1] = { name = "TempoAdvisor", frame = TA.eventFrame }
        end
        local SC = GRIPEMS.SpellCache
        if SC and SC.eventFrame then
            targets[#targets + 1] = { name = "SpellCache", frame = SC.eventFrame }
        end
        local engFrame = _G["GRIPEMS_EngineEvent"]
        if engFrame then
            targets[#targets + 1] = { name = "Engine", frame = engFrame }
        end
        local SQW = GRIPEMS.SQWOptimizer
        if SQW and SQW.eventFrame then
            targets[#targets + 1] = { name = "SQWOptimizer", frame = SQW.eventFrame }
        end
        local txFrame = _G["GRIPEMS_TransmitEvent"]
        if txFrame then
            targets[#targets + 1] = { name = "Transmission", frame = txFrame }
        end

        if #targets == 0 then
            GRIPEMS:Print("perftest events: no target frames available.")
            return
        end

        -- Stats table and original-script map
        local stats = {}
        local originals = {}
        for _, t in ipairs(targets) do
            stats[t.name] = { totalMs = 0, peakMs = 0, fireCount = 0 }
            local orig = t.frame:GetScript("OnEvent")
            originals[t.name] = orig
            if orig then
                local name = t.name
                t.frame:SetScript("OnEvent", function(self, event, ...)
                    local t0 = debugprofilestop()
                    orig(self, event, ...)
                    local elapsed = debugprofilestop() - t0
                    local s = stats[name]
                    s.totalMs = s.totalMs + elapsed
                    s.fireCount = s.fireCount + 1
                    if elapsed > s.peakMs then
                        s.peakMs = elapsed
                    end
                end)
            end
        end

        GRIPEMS._perftestEventsActive = true
        GRIPEMS:Print(string.format("perftest events: instrumenting %d frames for %ds...", #targets, seconds))

        if C_Timer and C_Timer.After then
            C_Timer.After(seconds, function()
                -- Restore originals
                for _, t in ipairs(targets) do
                    t.frame:SetScript("OnEvent", originals[t.name])
                end
                GRIPEMS._perftestEventsActive = false

                GRIPEMS:Print(string.format("=== perftest events (%ds) ===", seconds))
                -- Sort by totalMs desc
                local sorted = {}
                for name, s in pairs(stats) do
                    sorted[#sorted + 1] =
                        { name = name, totalMs = s.totalMs, peakMs = s.peakMs, fireCount = s.fireCount }
                end
                table.sort(sorted, function(a, b)
                    return a.totalMs > b.totalMs
                end)
                for _, e in ipairs(sorted) do
                    GRIPEMS:Print(
                        string.format(
                            "  %-14s fires=%d  total=%.2f ms  peak=%.2f ms",
                            e.name,
                            e.fireCount,
                            e.totalMs,
                            e.peakMs
                        )
                    )
                end
                GRIPEMS:Print("=== end perftest events ===")
            end)
        end
        return
    end

    if sub == "scan" then
        local SC = GRIPEMS.SpellCache
        if not SC then
            GRIPEMS:Print("perftest scan: SpellCache not loaded.")
            return
        end
        GRIPEMS:Print("=== perftest scan ===")

        -- Force-dirty all collections so the scan actually runs every sub-builder.
        if SC.collectionsDirty then
            SC.collectionsDirty.spells = true
            SC.collectionsDirty.items = true
            SC.collectionsDirty.toys = true
            SC.collectionsDirty.mounts = true
            SC.collectionsDirty.companions = true
        end

        local subTotals = {}

        -- Wrap each sub-builder transiently to collect per-cache ms
        local origItem = SC.BuildItemCache
        local origToy = SC.BuildToyCache
        local origMount = SC.BuildMountCache
        local origComp = SC.BuildCompanionCache

        SC.BuildItemCache = function(self, ...)
            local t0 = debugprofilestop()
            local a, b, c = origItem(self, ...)
            subTotals.items = (subTotals.items or 0) + (debugprofilestop() - t0)
            return a, b, c
        end
        SC.BuildToyCache = function(self, ...)
            local t0 = debugprofilestop()
            local a, b, c = origToy(self, ...)
            subTotals.toys = (subTotals.toys or 0) + (debugprofilestop() - t0)
            return a, b, c
        end
        SC.BuildMountCache = function(self, ...)
            local t0 = debugprofilestop()
            local a, b, c = origMount(self, ...)
            subTotals.mounts = (subTotals.mounts or 0) + (debugprofilestop() - t0)
            return a, b, c
        end
        SC.BuildCompanionCache = function(self, ...)
            local t0 = debugprofilestop()
            local a, b, c = origComp(self, ...)
            subTotals.companions = (subTotals.companions or 0) + (debugprofilestop() - t0)
            return a, b, c
        end

        local spellsBefore = debugprofilestop()
        SC:Scan()
        local total = debugprofilestop() - spellsBefore

        -- Restore originals
        SC.BuildItemCache = origItem
        SC.BuildToyCache = origToy
        SC.BuildMountCache = origMount
        SC.BuildCompanionCache = origComp

        local subSum = (subTotals.items or 0)
            + (subTotals.toys or 0)
            + (subTotals.mounts or 0)
            + (subTotals.companions or 0)
        local spellsOnly = total - subSum
        GRIPEMS:Print(string.format("  spells      %.2f ms", spellsOnly))
        GRIPEMS:Print(string.format("  items       %.2f ms", subTotals.items or 0))
        GRIPEMS:Print(string.format("  toys        %.2f ms", subTotals.toys or 0))
        GRIPEMS:Print(string.format("  mounts      %.2f ms", subTotals.mounts or 0))
        GRIPEMS:Print(string.format("  companions  %.2f ms", subTotals.companions or 0))
        GRIPEMS:Print(string.format("  total       %.2f ms", total))
        GRIPEMS:Print("=== end perftest scan ===")
        return
    end

    if sub == "reanalyze" then
        local TA = GRIPEMS.TempoAdvisor
        local eng = GRIPEMS.Engine
        if not TA or not eng then
            GRIPEMS:Print("perftest reanalyze: TempoAdvisor or Engine not loaded.")
            return
        end
        local count = 0
        local t0 = debugprofilestop()
        if TA._lastAnalysisTime then
            wipe(TA._lastAnalysisTime)
        end
        if eng.sequences then
            for sn, entry in pairs(eng.sequences) do
                if entry.data and entry.button and TA.OnSequenceActivated then
                    TA:OnSequenceActivated(sn, entry.data)
                    count = count + 1
                end
            end
        end
        local elapsed = debugprofilestop() - t0
        GRIPEMS:Print("=== perftest reanalyze ===")
        GRIPEMS:Print(string.format("  sequences analysed: %d", count))
        GRIPEMS:Print(string.format("  total               %.2f ms", elapsed))
        GRIPEMS:Print("=== end perftest reanalyze ===")
        return
    end

    GRIPEMS:Print("Usage: /gems perftest [events N | scan | reanalyze]")
end

--- Handle /gems variants [<seqName> [add|remove MOD]]: Smart Keybind Group
--- inspection + per-variant SV management (IC-VAR-02 Phase 1).
--- No args: list every active sequence with at least one variant override.
--- seqName only: list overrides for that sequence (or print "none" if empty).
--- seqName + add MOD: append an override with steps={} placeholder; Phase 2 UI
--- (or direct SV edit) populates steps before /reload.
--- seqName + remove MOD: remove the override matching modifier MOD.
--- @param arg string Remainder after "/gems variants" (untrimmed case preserved)
local function HandleVariants(arg)
    local D = GRIPEMS.Defaults
    local E = GRIPEMS.Engine
    if not E or not E.sequences then
        return
    end

    local trimmed = (arg or ""):trim()
    if trimmed == "" then
        local listed = 0
        for seqName, entry in pairs(E.sequences) do
            local ver = entry.data and E:GetActiveVersion(entry.data)
            local overrides = ver and ver.variantOverrides
            local count = overrides and #overrides or 0
            if count > 0 then
                GRIPEMS:Print(string.format("  %s: %d variant override(s)", seqName, count))
                listed = listed + 1
            end
        end
        if listed == 0 then
            GRIPEMS:Print("No active sequences carry variant overrides.")
        end
        return
    end

    local tokens = {}
    for tok in trimmed:gmatch("%S+") do
        tokens[#tokens + 1] = tok
    end
    local seqName = tokens[1]
    local action = tokens[2] and tokens[2]:lower() or nil
    local mod = tokens[3] and tokens[3]:lower() or nil

    local entry = E.sequences[seqName]
    if not entry or not entry.data then
        GRIPEMS:Print(string.format(L["GEMS_NOT_FOUND"], seqName))
        return
    end
    local ver = E:GetActiveVersion(entry.data)
    if not ver then
        GRIPEMS:Print(string.format(L["GEMS_NOT_FOUND"], seqName))
        return
    end

    if not action then
        local overrides = ver.variantOverrides or {}
        if #overrides == 0 then
            GRIPEMS:Print(string.format(L["GEMS_VARIANT_LIST_NONE"], seqName))
            return
        end
        GRIPEMS:Print(string.format(L["GEMS_VARIANT_LIST_HEADER"], seqName))
        for ovIdx, override in ipairs(overrides) do
            GRIPEMS:Print(
                string.format(
                    L["GEMS_VARIANT_LIST_ROW"],
                    ovIdx + 1,
                    override.name or ("variant_" .. (override.modifier or "?")),
                    override.modifier or "?",
                    override.steps and #override.steps or 0
                )
            )
        end
        return
    end

    if action == "add" then
        if not mod or not D.VARIANT_MODIFIER_SET[mod] or mod == "plain" then
            GRIPEMS:Print(string.format(L["GEMS_VARIANT_BAD_MODIFIER"], tostring(mod)))
            return
        end
        ver.variantOverrides = ver.variantOverrides or {}
        if #ver.variantOverrides >= D.MAX_VARIANT_OVERRIDES then
            GRIPEMS:Print(string.format(L["GEMS_VARIANT_MAX_REACHED"], seqName, D.MAX_VARIANT_OVERRIDES))
            return
        end
        for _, override in ipairs(ver.variantOverrides) do
            if override.modifier == mod then
                GRIPEMS:Print(string.format(L["GEMS_VARIANT_DUP_MODIFIER"], mod, seqName))
                return
            end
        end
        local newOverride = {
            name = "variant_" .. mod,
            modifier = mod,
            steps = {},
            keyPress = nil,
            keyRelease = nil,
            icon = nil,
        }
        table.insert(ver.variantOverrides, newOverride)
        E:DeactivateSequence(seqName, true)
        E:ActivateSequence(seqName, entry.data)
        GRIPEMS:Print(string.format(L["GEMS_VARIANT_ADDED"], newOverride.name, seqName, mod))
        return
    end

    if action == "remove" then
        if not mod or not D.VARIANT_MODIFIER_SET[mod] or mod == "plain" then
            GRIPEMS:Print(string.format(L["GEMS_VARIANT_BAD_MODIFIER"], tostring(mod)))
            return
        end
        local overrides = ver.variantOverrides or {}
        for ovIdx, override in ipairs(overrides) do
            if override.modifier == mod then
                table.remove(overrides, ovIdx)
                E:DeactivateSequence(seqName, true)
                E:ActivateSequence(seqName, entry.data)
                GRIPEMS:Print(string.format(L["GEMS_VARIANT_REMOVED"], seqName, mod))
                return
            end
        end
        GRIPEMS:Print(string.format(L["GEMS_VARIANT_NOT_FOUND"], seqName, mod))
        return
    end

    GRIPEMS:Print("Usage: /gems variants [<seqName> [add|remove <shift|ctrl|alt>]]")
end

-- Built-in /gems subcommands the dispatcher below claims. This set MUST list EVERY
-- cmd literal the if/elseif chain matches, INCLUDING aliases (dw, config, options,
-- memory, tutorial, ...). It backs GRIPEMS.IsBuiltinSlashCommand so a plugin can never
-- register a /gems subcommand that shadows a built-in.
--
-- MAINTENANCE: adding a new built-in cmd to the dispatcher REQUIRES adding it here.
-- Test/test_slash_builtin_drift.lua fails the suite if any dispatcher cmd literal is
-- missing from this set.
GRIPEMS._builtinSlashCommands = {
    ["help"] = true,
    ["open"] = true,
    ["keys"] = true,
    ["create"] = true,
    ["delete"] = true,
    ["list"] = true,
    ["test"] = true,
    ["reset"] = true,
    ["debugwindow"] = true,
    ["dw"] = true,
    ["debug"] = true,
    ["bind"] = true,
    ["unbind"] = true,
    ["binds"] = true,
    ["swap"] = true,
    ["unpin"] = true,
    ["import"] = true,
    ["export"] = true,
    ["exportall"] = true,
    ["migrate"] = true,
    ["tour"] = true,
    ["guide"] = true,
    ["tutorial"] = true,
    ["tracker"] = true,
    ["send"] = true,
    ["accept"] = true,
    ["block"] = true,
    ["unblock"] = true,
    ["blocklist"] = true,
    ["browse"] = true,
    ["settings"] = true,
    ["config"] = true,
    ["options"] = true,
    ["theme"] = true,
    ["simplified"] = true,
    ["apply"] = true,
    ["variants"] = true,
    ["status"] = true,
    ["testlocale"] = true,
    ["testspellid"] = true,
    ["validate"] = true,
    ["menu"] = true,
    ["revalidate"] = true,
    ["compress"] = true,
    ["decompress"] = true,
    ["mapinfo"] = true,
    ["spellcache"] = true,
    ["diag"] = true,
    ["msadvisor"] = true,
    ["memcheck"] = true,
    ["memory"] = true,
    ["perf"] = true,
    ["perftest"] = true,
    ["monitor"] = true,
    ["loadclass"] = true,
    ["repair"] = true,
    ["repairall"] = true,
    ["cvar"] = true,
    ["sqw"] = true,
    ["fs"] = true,
    ["record"] = true,
    ["trace"] = true,
    ["overlay"] = true,
    ["resetui"] = true,
}

--- Whether a /gems subcommand name is a built-in (reserved) command. nil-safe and
--- case-insensitive: lowercases the input and tests the reserved set. The plugin
--- RegisterSlashCommand path uses it to reject a name that would shadow a built-in.
--- @param sub string Candidate subcommand name
--- @return boolean True when sub is a reserved built-in subcommand
function GRIPEMS.IsBuiltinSlashCommand(sub)
    return sub ~= nil and GRIPEMS._builtinSlashCommands[tostring(sub):lower()] == true
end

SlashCmdList["GRIPEMS"] = function(input)
    local cmd, arg = ParseSlashInput(input)

    if cmd == "" then
        -- Open main frame (lazy-created inside ToggleMainFrame)
        if GRIPEMS.UI then
            GRIPEMS.UI:ToggleMainFrame()
        else
            ShowHelp()
        end
    elseif cmd == "help" then
        ShowHelp()
    elseif cmd == "open" then
        if GRIPEMS.UI then
            GRIPEMS.UI:ToggleMainFrame()
        end
    elseif cmd == "create" then
        HandleCreate(arg)
    elseif cmd == "delete" then
        HandleDelete(arg)
    elseif cmd == "list" then
        HandleList()
    elseif cmd == "test" then
        if arg == "prep" then
            if GRIPEMS.TestSuite and GRIPEMS.TestSuite.PrintPrep then
                GRIPEMS.TestSuite:PrintPrep()
            else
                GRIPEMS:Print("|cFFFF4444TestSuite:PrintPrep not available.|r")
            end
        elseif GRIPEMS.TestSuite then
            GRIPEMS.TestSuite:Run(arg ~= "" and arg or nil)
        else
            GRIPEMS:Print("|cFFFF4444TestSuite module not loaded.|r")
        end
    elseif cmd == "reset" then
        HandleReset(arg)
    elseif cmd == "debugwindow" or cmd == "dw" then
        if GRIPEMS.DebugWindow then
            GRIPEMS.DebugWindow:Toggle()
        end
    elseif cmd == "debug" then
        HandleDebug(arg)
    elseif cmd == "bind" then
        HandleBind(arg)
    elseif cmd == "unbind" then
        HandleUnbind(arg)
    elseif cmd == "binds" then
        HandleBinds(arg)
    elseif cmd == "swap" then
        HandleSwap(arg)
    elseif cmd == "unpin" then
        HandleUnpin(arg)
    elseif cmd == "import" then
        HandleImport(arg)
    elseif cmd == "export" then
        HandleExport(arg)
    elseif cmd == "exportall" then
        GRIPEMS.ExportFrame:Show()
    elseif cmd == "migrate" then
        HandleMigrate()
    elseif cmd == "tour" then
        if arg == "reset" then
            if GRIPEMS.Tutorial then
                GRIPEMS.Tutorial:Reset()
            end
        else
            if GRIPEMS.Tutorial then
                GRIPEMS.Tutorial:Start()
            end
        end
    elseif cmd == "guide" or cmd == "tutorial" then
        GRIPEMS:Print(L["GEMS_GUIDE_CLICK"])
        GRIPEMS:Print("|cFF8899aa" .. L["GEMS_GUIDE_TIP"] .. "|r")
    elseif cmd == "tracker" then
        if GRIPEMS.TrackerHUD then
            if arg == "lock" then
                GRIPEMS.TrackerHUD:ToggleLock()
            else
                GRIPEMS.TrackerHUD:Toggle()
            end
        end
    elseif cmd == "send" then
        local seqName, target = arg:match("^(%S+)%s+(%S+)")
        if not seqName or not target then
            GRIPEMS:Print(L["GEMS_SEND_USAGE"])
        elseif GRIPEMS.Transmission then
            GRIPEMS.Transmission:SendSequence(seqName, target)
        end
    elseif cmd == "accept" then
        if GRIPEMS.Transmission then
            GRIPEMS.Transmission:AcceptPending()
        end
    elseif cmd == "block" then
        if not arg or arg == "" then
            GRIPEMS:Print("Usage: /gems block <player>")
        elseif GRIPEMS.Transmission then
            GRIPEMS.Transmission:BlockPlayer(arg)
        end
    elseif cmd == "unblock" then
        if not arg or arg == "" then
            GRIPEMS:Print("Usage: /gems unblock <player>")
        elseif GRIPEMS.Transmission then
            GRIPEMS.Transmission:UnblockPlayer(arg)
        end
    elseif cmd == "blocklist" then
        if GRIPEMS.Transmission then
            local list = GRIPEMS.Transmission:GetBlockedList()
            if #list == 0 then
                GRIPEMS:Print(L["GEMS_BLOCK_LIST_EMPTY"])
            else
                GRIPEMS:Print(L["GEMS_BLOCK_LIST_HEADER"])
                for _, name in ipairs(list) do
                    GRIPEMS:Print("  " .. Ambiguate(name, "none") .. " (" .. name .. ")")
                end
            end
        end
    elseif cmd == "browse" then
        local RBrowser = GRIPEMS.RemoteBrowser
        if RBrowser then
            RBrowser:Toggle()
        end
    elseif cmd == "settings" or cmd == "config" or cmd == "options" then
        if GRIPEMS.SettingsPanel then
            GRIPEMS.SettingsPanel:Open()
        end
    elseif cmd == "theme" then
        if arg == "inspect" then
            if InCombatLockdown() then
                GRIPEMS:Print(
                    "|cFFFFAA33"
                        .. (L["ACCESS_THEMING_MODAL_COMBAT_BLOCKED"] or "Theme editor is hidden during combat.")
                        .. "|r"
                )
            elseif GRIPEMS.UI and GRIPEMS.UI.InspectOverlay and GRIPEMS.UI.InspectOverlay.Enter then
                GRIPEMS.UI.InspectOverlay:Enter()
            end
        else
            if GRIPEMS.UI and GRIPEMS.UI.OpenThemeEditor then
                GRIPEMS.UI.OpenThemeEditor()
            end
        end
    elseif cmd == "simplified" then
        local a = GRIPEMS.Settings
            and GRIPEMS.Settings.db
            and GRIPEMS.Settings.db.profile
            and GRIPEMS.Settings.db.profile.accessibility
        if not a then
            return
        end
        if arg == "on" then
            a.simplifiedMode = true
        elseif arg == "off" then
            a.simplifiedMode = false
        else
            a.simplifiedMode = not a.simplifiedMode
        end
        if GRIPEMS.SequenceEditor and GRIPEMS.SequenceEditor.RelayoutSimplified then
            GRIPEMS.SequenceEditor:RelayoutSimplified()
        end
        GRIPEMS:Print("|cff33ff99EMS:|r Simplified Mode " .. (a.simplifiedMode and "ON" or "OFF"))
    elseif cmd == "apply" then
        local OQ = GRIPEMS.OOCQueue
        if OQ and OQ.Process then
            if OQ.IsRestricted and OQ:IsRestricted() then
                GRIPEMS:Print(L["GEMS_APPLY_IN_COMBAT"])
            else
                local before = OQ:GetCount()
                if before == 0 then
                    GRIPEMS:Print(L["GEMS_APPLY_NOTHING_QUEUED"])
                else
                    OQ:Process("manual")
                    local after = OQ:GetCount()
                    GRIPEMS:Print(string.format(L["GEMS_APPLY_DRAINED"], before - after))
                end
            end
        end
    elseif cmd == "variants" then
        HandleVariants(arg)
    elseif cmd == "status" then
        HandleStatus()
    elseif cmd == "testlocale" then
        HandleTestLocale()
    elseif cmd == "testspellid" then
        HandleTestSpellID()
    elseif cmd == "validate" then
        local SV = GRIPEMS.SpellValidator
        if not SV then
            GRIPEMS:Print("SpellValidator not loaded")
            return
        end
        local results = SV:ValidateAll()
        local total, clean, warn = 0, 0, 0
        for name, r in pairs(results.sequences) do
            total = total + 1
            if r.staleCount > 0 then
                warn = warn + 1
                GRIPEMS:Print(L["GEMS_SPELL_VALIDATE_SEQ"]:format(name, r.unknownCount, r.knownCount))
            else
                clean = clean + 1
            end
        end
        if warn == 0 then
            GRIPEMS:Print(L["GEMS_SPELL_VALIDATE_CLEAN"])
        else
            GRIPEMS:Print(L["GEMS_SPELL_VALIDATE_SUMMARY"]:format(total, clean, warn))
        end
    elseif cmd == "menu" then
        if GRIPEMS.FloatingMenu then
            GRIPEMS.FloatingMenu:Toggle()
        end
    elseif cmd == "revalidate" then
        HandleRevalidate()
    elseif cmd == "compress" then
        -- Encode a sequence by name for debugging
        if not arg or arg == "" then
            GRIPEMS:Print("Usage: /gems compress <sequenceName>")
            return
        end
        local E = GRIPEMS.Engine
        if not E or not E.sequences[arg] then
            GRIPEMS:Print("Sequence not found: " .. arg)
            return
        end
        local Ser = GRIPEMS.Serialization
        if not Ser then
            GRIPEMS:Print("Serialization module not loaded")
            return
        end
        local ok, result = Ser.Encode(E.sequences[arg].data)
        if ok then
            GRIPEMS:Print("Compressed (" .. #result .. " chars):")
            GRIPEMS:Print(result)
        else
            GRIPEMS:Print("Compress failed: " .. tostring(result))
        end
    elseif cmd == "decompress" then
        -- Decode a raw string for debugging
        if not arg or arg == "" then
            GRIPEMS:Print("Usage: /gems decompress <encodedString>")
            return
        end
        local Ser = GRIPEMS.Serialization
        if not Ser then
            GRIPEMS:Print("Serialization module not loaded")
            return
        end
        local ok, decoded, fmt = Ser.Decode(arg)
        if ok and decoded then
            local name = decoded.name or "unnamed"
            -- type(), not truthiness. `decoded` is whatever Ser.Decode made of a
            -- string the USER PASTED at this slash command, so this is the least
            -- trusted .versions read in the addon -- nothing upstream validates
            -- the payload shape before it reaches here. Measured: a number or
            -- boolean in .versions raised "attempt to get length of field
            -- 'versions'", and a string silently fabricated a version count from
            -- its character length. The step count below indexes the SAME
            -- untrusted field, so it is folded into one guard rather than
            -- repeating the head check.
            local verCount = 0
            local stepCount = 0
            if type(decoded.versions) == "table" then
                verCount = #decoded.versions
                local v1 = decoded.versions[1]
                if type(v1) == "table" and type(v1.steps) == "table" then
                    stepCount = #v1.steps
                end
            end
            GRIPEMS:Print(
                string.format("Decoded [%s]: %s, %d version(s), %d step(s)", fmt or "?", name, verCount, stepCount)
            )
        else
            GRIPEMS:Print("Decompress failed: " .. tostring(decoded))
        end
    elseif cmd == "mapinfo" then
        local name, instanceType, difficultyID, _, _, _, _, instanceMapID = GetInstanceInfo()
        local uiMapID = C_Map.GetBestMapForUnit("player")
        GRIPEMS:Print("Map Info:")
        GRIPEMS:Print("  Instance: " .. tostring(name))
        GRIPEMS:Print("  Type: " .. tostring(instanceType))
        GRIPEMS:Print("  DifficultyID: " .. tostring(difficultyID))
        GRIPEMS:Print("  InstanceMapID: " .. tostring(instanceMapID))
        GRIPEMS:Print("  UIMapID: " .. tostring(uiMapID))
        GRIPEMS:Print("  Context: " .. tostring(GRIPEMS.Engine.currentContext))
    elseif cmd == "spellcache" then
        if GRIPEMS.SpellCacheViewer then
            GRIPEMS.SpellCacheViewer:Show()
        else
            GRIPEMS:Print(L["GEMS_SPELLCACHE_NOT_AVAILABLE"])
        end
    elseif cmd == "diag" then
        HandleDiag(arg)
    elseif cmd == "msadvisor" then
        HandleMSAdvisor(arg)
    elseif cmd == "memcheck" or cmd == "memory" then
        HandleMemcheck()
    elseif cmd == "perf" then
        HandlePerf()
    elseif cmd == "perftest" then
        HandlePerftest(arg)
    elseif cmd == "monitor" then
        HandleMonitor()
    elseif cmd == "loadclass" then
        local classID = tonumber(arg)
        if not classID then
            GRIPEMS:Print(L["GEMS_LOADCLASS_USAGE"])
            return
        end
        if GRIPEMS.loadedClasses and GRIPEMS.loadedClasses[classID] then
            GRIPEMS:Print(string.format(L["GEMS_LOADCLASS_ALREADY"], classID))
            return
        end
        local activated = 0
        local engine = GRIPEMS.Engine
        if engine then
            for name, entry in pairs(engine.sequences) do
                if not entry.button and entry.data then
                    local seqClass = entry.data.classID or 0
                    if seqClass == classID then
                        engine:ActivateDormantSequence(name)
                        activated = activated + 1
                    end
                end
            end
        end
        GRIPEMS.loadedClasses = GRIPEMS.loadedClasses or {}
        GRIPEMS.loadedClasses[classID] = true
        GRIPEMS:Print(string.format(L["GEMS_LOADCLASS_DONE"], activated, classID))
    elseif cmd == "keys" then
        local KCP = GRIPEMS.KeybindConflictPanel
        if not KCP then
            GRIPEMS:Print(L["GEMS_KC_TITLE"])
            return
        end
        KCP:Show()
    elseif cmd == "repair" then
        local seqName = (arg and arg ~= "") and arg or nil
        if not seqName then
            seqName = GRIPEMS.UI and GRIPEMS.UI.selectedSequence or nil
        end
        if not seqName then
            GRIPEMS:Print(L["GEMS_REPAIR_USAGE"])
            return
        end
        local RA = GRIPEMS.RepairAnalyzer
        local RF = GRIPEMS.RepairFrame
        local E = GRIPEMS.Engine
        if not RA or not RF or not E then
            GRIPEMS:Print(L["GEMS_REPAIR_NOT_LOADED"])
            return
        end
        local entry = E.sequences[seqName]
        if not entry or not entry.data then
            GRIPEMS:Print(string.format(L["GEMS_REPAIR_SEQ_NOT_FOUND"], seqName))
            return
        end
        local issues = RA:Analyze(entry.data, seqName, { surface = "repair" })
        if #issues == 0 then
            local score = RA:ComputeHealthScore(issues)
            GRIPEMS:Print(string.format(L["GEMS_REPAIR_NONE"], score))
            return
        end
        RF:Show(entry.data, issues, seqName)
    elseif cmd == "repairall" then
        local RA = GRIPEMS.RepairAnalyzer
        local RF = GRIPEMS.RepairFrame
        if not RA or not RF then
            GRIPEMS:Print(L["GEMS_REPAIR_NOT_LOADED"])
            return
        end
        local allIssues = RA:AnalyzeAll()
        local totalCount = 0
        for _, issues in pairs(allIssues) do
            totalCount = totalCount + #issues
        end
        if totalCount == 0 then
            GRIPEMS:Print(L["GEMS_REPAIR_ALL_HEALTHY"])
            return
        end
        RF:ShowBatch(allIssues)
    elseif cmd == "cvar" then
        local CPM = GRIPEMS.CvarProfileManager
        if CPM then
            CPM:HandleSlashCommand(arg or "")
        end
    elseif cmd == "sqw" then
        local SQWO = GRIPEMS.SQWOptimizer
        if SQWO then
            SQWO:HandleSlashCommand(arg or "")
        end
    elseif cmd == "fs" then
        local TAM = GRIPEMS.TempoAdvisor
        if TAM then
            TAM:HandleSlashCommand(arg or "")
        end
    elseif cmd == "record" then
        local MR = GRIPEMS.MacroRecorder
        if not MR then
            GRIPEMS:Print(L["GEMS_RECORDER_UNAVAILABLE"])
        else
            MR:Toggle()
            if MR.isRecording then
                GRIPEMS:Print(L["GEMS_RECORDER_STARTED"])
            else
                GRIPEMS:Print(string.format(L["GEMS_RECORDER_STOPPED"], MR:GetCount()))
            end
        end
    elseif cmd == "trace" then
        local ET = GRIPEMS.ExecutionTracer
        if not ET then
            GRIPEMS:Print(L["GEMS_TRACE_UNAVAILABLE"])
        else
            local sub = (arg or ""):lower()
            if sub == "on" then
                ET:Start()
                GRIPEMS:Print(L["GEMS_TRACE_STARTED"])
            elseif sub == "off" then
                ET:Stop()
                GRIPEMS:Print(L["GEMS_TRACE_STOPPED"])
            elseif sub == "status" then
                local state = ET:IsActive() and L["GEMS_TRACE_STATE_ON"] or L["GEMS_TRACE_STATE_OFF"]
                GRIPEMS:Print(string.format(L["GEMS_TRACE_STATUS"], state, ET:GetClickRate()))
            elseif ET:IsActive() then
                ET:Stop()
                GRIPEMS:Print(L["GEMS_TRACE_STOPPED"])
            else
                ET:Start()
                GRIPEMS:Print(L["GEMS_TRACE_STARTED"])
            end
        end
    elseif cmd == "overlay" then
        local TOV = GRIPEMS.TempoOverlay
        if TOV then
            TOV:Toggle()
        end
    elseif cmd == "resetui" then
        local sv = GRIP_EMS_CHAR and GRIP_EMS_CHAR.ui
        if sv then
            sv.mainFrame = {}
        end
        local mf = _G["GRIPEMS_MainFrame"]
        if mf then
            local defaults = GRIPEMS.Defaults
            mf:ClearAllPoints()
            mf:SetPoint("CENTER")
            mf:SetSize(defaults.MAIN_FRAME_WIDTH, defaults.MAIN_FRAME_HEIGHT)
            if mf.minimized and mf.DoRestore then
                mf.DoRestore()
            end
        end
        GRIPEMS:Print(L["GEMS_RESETUI_DONE"])
    else
        if
            GRIPEMS.PluginAPI
            and GRIPEMS.PluginAPI.DispatchSlashCommand
            and GRIPEMS.PluginAPI:DispatchSlashCommand(cmd, arg)
        then
            return
        end
        GRIPEMS:Print(string.format(L["GEMS_UNKNOWN_CMD"], cmd))
    end
end

-- Coerce a sequence updatedAt value to a numeric epoch.
-- Native sequences store time() (a number). Legacy imports may carry a
-- 14-digit YYYYMMDDHHMMSS string from the source sequencer metadata.
-- Returns a number for any recognizable timestamp, or nil when the value
-- is missing or unparseable so callers can apply their own fallback via
-- GRIPEMS.NormalizeUpdatedAt(x) or <default>.
function GRIPEMS.NormalizeUpdatedAt(value)
    if type(value) == "number" then
        return value
    end
    if type(value) ~= "string" or value == "" then
        return nil
    end
    local y, mo, d, h, mi, s = value:match("^(%d%d%d%d)(%d%d)(%d%d)(%d%d)(%d%d)(%d%d)$")
    if y then
        return time({
            year = tonumber(y),
            month = tonumber(mo),
            day = tonumber(d),
            hour = tonumber(h),
            min = tonumber(mi),
            sec = tonumber(s),
        })
    end
    return tonumber(value)
end

--- Migrate existing sequences to include fields added in Phase 3A-2.
--- Called once at ADDON_LOADED after SavedVariables are initialized.
--- Fills in any missing schema fields with sensible defaults.
local function MigrateSequenceSchema()
    if not _G.GRIP_EMS_CHAR or not GRIP_EMS_CHAR.sequences then
        return
    end
    local playerClassID = select(3, UnitClass("player")) or 0
    for name, seqData in pairs(GRIP_EMS_CHAR.sequences) do
        if type(seqData) == "table" then
            -- Sequence-level metadata defaults
            seqData.name = seqData.name or name
            seqData.author = seqData.author or ""
            seqData.version = seqData.version or "1"
            seqData.description = seqData.description or ""
            seqData.help = seqData.help or ""
            seqData.helplink = seqData.helplink or ""
            seqData.classID = seqData.classID or playerClassID
            -- seqData.specID: leave nil if nil (means "all specs")
            seqData.createdAt = seqData.createdAt or time()
            seqData.updatedAt = GRIPEMS.NormalizeUpdatedAt(seqData.updatedAt) or time()
            -- Migrate flat format to versioned (T2-2a)
            GRIPEMS.Engine:MigrateSequenceFormat(seqData)
            -- Ensure contextOverrides exists (T2-1)
            seqData.contextOverrides = seqData.contextOverrides or {}
            GRIP_EMS_CHAR.sequences[name] = seqData
        end
    end

    -- Phase 2a: flag for lazy taggedSteps migration (runs after SpellCache loads)
    if _G.GRIP_EMS_DB and not GRIP_EMS_DB.taggedStepsMigrated then
        GRIP_EMS_DB.pendingTagMigration = true
    end
end

--- Mirror Blizzard accessibility CVars into EMS settings on first login.
--- Only runs once per account (gated by db.global.cvarFirstRunMirrorDone).
--- Never overwrites a field that is not at stock default.
--- @param forceReset boolean|nil If true, clears the first-run flag before running.
--- @return boolean ran, number applied
function GRIPEMS:MirrorAccessibilityCVars(forceReset)
    local db = self.Settings and self.Settings.db
    if not db then
        return false, 0
    end
    if forceReset then
        db.global.cvarFirstRunMirrorDone = false
    end
    if db.global.cvarFirstRunMirrorDone then
        return false, 0
    end

    local applied = 0
    local a = db.profile.accessibility

    local bobbing = nil
    if GetCVarBool then
        local ok, v = pcall(GetCVarBool, "cameraBobbing")
        if ok then
            bobbing = v
        end
    end
    if bobbing == false and a.reduceMotion == false then
        a.reduceMotion = true
        applied = applied + 1
    end

    local gp = false
    if C_GamePad and C_GamePad.IsEnabled then
        local ok, v = pcall(C_GamePad.IsEnabled)
        if ok and v == true then
            gp = true
        end
    end
    if gp and a.reduceMotion == false then
        a.reduceMotion = true
        applied = applied + 1
    end

    local edgeFlash = nil
    if GetCVarBool then
        local ok, v = pcall(GetCVarBool, "screenEdgeFlash")
        if ok then
            edgeFlash = v
        end
    end
    if edgeFlash == false and a.flickerSafe == false then
        a.flickerSafe = true
        applied = applied + 1
    end

    db.global.cvarFirstRunMirrorDone = true

    if applied > 0 and DEFAULT_CHAT_FRAME then
        local loc = self.L
            or setmetatable({}, {
                __index = function(_, k)
                    return k
                end,
            })
        DEFAULT_CHAT_FRAME:AddMessage(format(loc["ACCESS_CVAR_MIRROR_TOAST_APPLIED"], applied))
    end
    return true, applied
end

---------------------------------------------------------------------------
-- Guide URL popup (shown from /gems guide clickable link)
---------------------------------------------------------------------------
function GRIPEMS:ShowGuidePopup()
    if not self.guideFrame then
        local C = GRIPEMS.UI and GRIPEMS.UI.Colors
        local frame = CreateFrame("Frame", "GRIPEMSGuideFrame", UIParent, "BackdropTemplate")
        frame:SetSize(440, 150)
        frame:SetPoint("CENTER")
        frame:SetFrameStrata("DIALOG")
        frame:SetFrameLevel(200)

        -- Backdrop (match addon dark theme)
        if C then
            GRIPEMS.UI:ApplyBackdrop(frame, GRIPEMS.UI.Backdrops.panel, C.bgDeep, C.border)
        else
            frame:SetBackdrop({
                bgFile = "Interface/Tooltips/UI-Tooltip-Background",
                edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
                edgeSize = 16,
                insets = { left = 4, right = 4, top = 4, bottom = 4 },
            })
            frame:SetBackdropColor(0.08, 0.08, 0.16, 0.95)
            frame:SetBackdropBorderColor(0.3, 0.3, 0.5, 0.8)
        end

        -- Close button
        local closeBtn = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
        closeBtn:SetPoint("TOPRIGHT", -2, -2)

        -- Title
        local title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        title:SetPoint("TOP", 0, -14)
        title:SetTextColor(1, 0.96, 0.26)
        title:SetText(L["GEMS_GUIDE_TITLE"])

        -- Subtitle
        local subtitle = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        subtitle:SetPoint("TOP", title, "BOTTOM", 0, -6)
        subtitle:SetTextColor(0.53, 0.6, 0.67)
        subtitle:SetText(L["GEMS_GUIDE_PATH"])

        -- EditBox (read-only URL)
        local editBox = CreateFrame("EditBox", nil, frame, "InputBoxTemplate")
        editBox:SetSize(400, 22)
        editBox:SetPoint("TOP", subtitle, "BOTTOM", 0, -8)
        editBox:SetAutoFocus(false)
        editBox:SetText(L["GEMS_GUIDE_URL"])
        editBox:SetScript("OnEditFocusGained", function(self)
            self:HighlightText()
        end)
        editBox:SetScript("OnEscapePressed", function(self)
            self:ClearFocus()
        end)
        -- Keep read-only: reset text if user types
        local guideURL = L["GEMS_GUIDE_URL"]
        editBox:SetScript("OnTextChanged", function(self, userInput)
            if userInput then
                self:SetText(guideURL)
                self:HighlightText()
            end
        end)

        -- Track focus state globally so EMS keybinds suppress while typing
        if GRIPEMS.Focus and GRIPEMS.Focus.HookEditBox then
            GRIPEMS.Focus:HookEditBox(editBox)
        end

        -- Local path hint
        local hint = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        hint:SetPoint("TOP", editBox, "BOTTOM", 0, -6)
        hint:SetTextColor(0.53, 0.6, 0.67)
        hint:SetText(L["GEMS_GUIDE_TIP"])

        -- ESC-closeable
        tinsert(UISpecialFrames, "GRIPEMSGuideFrame")

        frame.editBox = editBox
        self.guideFrame = frame
    end

    self.guideFrame:Show()
    self.guideFrame.editBox:SetText(L["GEMS_GUIDE_URL"])
    self.guideFrame.editBox:HighlightText()
    self.guideFrame.editBox:SetFocus()
end

-- Event frame (named for /reload reuse -- prevents orphan C++ frame objects)
local eventFrame = _G["GRIPEMS_CoreEvent"] or CreateFrame("Frame", "GRIPEMS_CoreEvent")
eventFrame:UnregisterAllEvents()
eventFrame:RegisterEvent("ADDON_LOADED")
eventFrame:RegisterEvent("PLAYER_LOGIN")
eventFrame:RegisterEvent("CVAR_UPDATE")
-- SKYRIDE-WATCHDOG (Phase): drive KeybindManager:HealStuckSuspend so both keybind
-- layers reconcile when skyriding exit signals go missing. PLAYER_MOUNT_DISPLAY_CHANGED
-- is the reliable dismount signal the bar-swap events lack; UPDATE_SHAPESHIFT_FORM is
-- the druid form-cancel analog; PLAYER_REGEN_ENABLED re-runs the OOC-only watchdog after
-- a trigger that landed in combat; the UNIT vehicle pair is filtered to arg1 == "player".
-- The gliding-state change event (registered below, pcall-guarded) is the enter-side
-- trigger: it fires when isGliding flips, so the missed-enter heal runs at takeoff and
-- the force retires at landing instead of waiting for an incidental bar or mount event.
eventFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
eventFrame:RegisterEvent("UPDATE_BONUS_ACTIONBAR")
eventFrame:RegisterEvent("PLAYER_MOUNT_DISPLAY_CHANGED")
eventFrame:RegisterEvent("UPDATE_SHAPESHIFT_FORM")
-- PLAYER_IS_GLIDING_CHANGED fires on skyriding takeoff AND landing --
-- the only trigger that lands exactly when the enter-heal gate
-- (isGliding) flips. pcall-guarded so a future removal of the event
-- degrades to the incidental triggers instead of a load error.
pcall(eventFrame.RegisterEvent, eventFrame, "PLAYER_IS_GLIDING_CHANGED")
eventFrame:RegisterEvent("UNIT_ENTERED_VEHICLE")
eventFrame:RegisterEvent("UNIT_EXITED_VEHICLE")

-------------------------------------------------------------------------------
-- SavedVariables schema -- values that MUST NEVER be persisted
--
-- GetTime() returns seconds since UI load; it resets to 0 on every /reload
-- and login. Any GetTime() value written to GRIP_EMS_DB or GRIP_EMS_CHAR
-- survives the reload but the next session's GetTime() starts back near 0,
-- so any comparison  (now - savedTs) >= cooldown  reads as a huge negative
-- number and the cooldown blocks indefinitely (or appears permanently fresh).
--
-- Rule: debounce, freshness, last-fired, last-seen, and any timestamp that
-- only matters within a single session belong on a module-level Lua table
-- that is rebuilt fresh each session (e.g. TA._lastAnalysisTime,
-- TA._recFreshness, TA._adjustedNotifyAt, ET._clickTimes, SQW.history).
-- Use time() / GetServerTime() only when the timestamp must persist across
-- sessions -- and even then, prefer not to persist runtime-only state at all.
--
-- Affected fields that have been scrubbed or must stay scrubbed:
--   GRIP_EMS_CHAR.tempoAdvisor[specID][seqName].timestamp -- REMOVED;
--     freshness lives in TA._recFreshness (module table).
-------------------------------------------------------------------------------

eventFrame:SetScript("OnEvent", function(self, event, ...)
    if event == "ADDON_LOADED" and ... == ADDON_NAME then
        -- Initialize SavedVariables
        _G.GRIP_EMS_DB = _G.GRIP_EMS_DB or {}
        _G.GRIP_EMS_CHAR = _G.GRIP_EMS_CHAR or {}
        GRIP_EMS_CHAR.sequences = GRIP_EMS_CHAR.sequences or {}
        GRIP_EMS_CHAR.keybinds = GRIP_EMS_CHAR.keybinds or {}

        -- UI state SavedVariables
        GRIP_EMS_CHAR.ui = GRIP_EMS_CHAR.ui or {}
        GRIP_EMS_CHAR.ui.mainFrame = GRIP_EMS_CHAR.ui.mainFrame or {}

        -- Account-wide variables store
        GRIP_EMS_DB.variables = GRIP_EMS_DB.variables or {}

        -- Account-wide UI settings
        GRIP_EMS_DB.config = GRIP_EMS_DB.config or {}
        -- v2.1.8 cleanup: drop the dead tamperedImportSilenced flag left in
        -- saved data by the removed tampered-import confirm modal.
        GRIP_EMS_DB.config.tamperedImportSilenced = nil

        -- Account-wide blocked players list (T2-9 block list)
        GRIP_EMS_DB.blockedPlayers = GRIP_EMS_DB.blockedPlayers or {}

        -- Account-wide import statistics
        GRIP_EMS_DB.importStats = GRIP_EMS_DB.importStats or {}

        -- WhatsNew popup state
        GRIP_EMS_DB.whatsNew = GRIP_EMS_DB.whatsNew or {}

        -- Initialize CallbackHandler message bus (before Settings so
        -- GRIPEMS:Fire() is available during initialization)
        local cbRegistry = LibStub("CallbackHandler-1.0"):New(GRIPEMS)
        function GRIPEMS:Fire(event, ...) -- luacheck: no redefined
            cbRegistry:Fire(event, ...)
        end

        -- Register SpellCache migrations now that GRIPEMS.RegisterCallback exists.
        -- SpellCache.lua cannot self-register at file load -- RegisterCallback is nil then.
        if GRIPEMS.SpellCache and GRIPEMS.SpellCache.RegisterMigrations then
            GRIPEMS.SpellCache:RegisterMigrations()
        end

        -- Initialize settings (AceDB profile system)
        if GRIPEMS.Settings then
            GRIPEMS.Settings:Initialize()
        end

        -- v2.1.4 cvarHealthOnboardingShown profile->global migration (G.4d L376).
        -- The onboarding flag was per-profile and re-fired on every new EMS profile.
        -- Lift the prior "true" into the new account-wide slot, then nil the profile
        -- copy so future profile-scope reads default to global. Idempotent:
        -- profileValue is nil after the first run, so the block becomes a no-op.
        local S = GRIPEMS.Settings
        if S and S.db and S.db.profile and S.db.profile.cvarHealthOnboardingShown ~= nil then
            local profileValue = S.db.profile.cvarHealthOnboardingShown
            if profileValue == true and S.db.global and not S.db.global.cvarHealthOnboardingShown then
                S.db.global.cvarHealthOnboardingShown = true
            end
            S.db.profile.cvarHealthOnboardingShown = nil
        end

        -- Phase 4 item 21: rebuild theming state whenever AceDB swaps profiles.
        -- Defer one frame so widget teardown for the outgoing profile settles
        -- before the new profile's overrides fan out. See design 18.6.
        if GRIPEMS.Settings and GRIPEMS.Settings.db and GRIPEMS.Settings.db.RegisterCallback then
            local function queueThemeReapply()
                local function applyAll()
                    if GRIPEMS.UI and GRIPEMS.UI.ApplyAll then
                        GRIPEMS.UI:ApplyAll()
                    end
                    if GRIPEMS.SequenceEditor and GRIPEMS.SequenceEditor.RelayoutSimplified then
                        pcall(GRIPEMS.SequenceEditor.RelayoutSimplified, GRIPEMS.SequenceEditor)
                    end
                    if GRIPEMS.Focus and GRIPEMS.Focus.ClearActivationLockouts then
                        pcall(GRIPEMS.Focus.ClearActivationLockouts, GRIPEMS.Focus)
                    end
                end
                if C_Timer and C_Timer.After then
                    C_Timer.After(0, applyAll)
                else
                    applyAll()
                end
            end
            GRIPEMS.Settings.db.RegisterCallback(GRIPEMS, "OnProfileChanged", queueThemeReapply)
            GRIPEMS.Settings.db.RegisterCallback(GRIPEMS, "OnProfileReset", queueThemeReapply)
            GRIPEMS.Settings.db.RegisterCallback(GRIPEMS, "OnProfileCopied", queueThemeReapply)
        end

        -- Migrate sequence schema (add fields missing from older saves)
        MigrateSequenceSchema()

        -- Run v2 per-loadout keybind schema migration (idempotent; stamps
        -- GRIP_EMS_CHAR.keybindSchemaVersion = 2 on first v2 session)
        if GRIPEMS.KeybindManager and GRIPEMS.KeybindManager.Initialize then
            GRIPEMS.KeybindManager:Initialize()
        end

        GRIPEMS.state.initialized = true
        GRIPEMS:Debug("SavedVariables initialized.")

        -- Initialize minimap button (LibDBIcon)
        if GRIPEMS.UI and GRIPEMS.UI.InitMinimapButton then
            GRIPEMS.UI:InitMinimapButton()
        end

        -- Hook SetItemRef for clickable guide hyperlink + theme chat links.
        -- hooksecurefunc, never a raw global replacement: a raw replacement
        -- parks an addon-authored function in a global that secure code reads,
        -- tainting every hyperlink click in the session (same class as the
        -- CancelLogout popup-table taint, fixed 2026-05-03). The post-hook is
        -- behavior-identical here because the default handler no-ops both EMS
        -- link families: GRIPEMSguide is an unknown link type, and
        -- garrmission:emsTheme:* fails the digits-only garrmission match in
        -- ItemRefHandlersShared.lua.
        hooksecurefunc("SetItemRef", function(link, text, button, chatFrame)
            if link == "GRIPEMSguide" then
                GRIPEMS:ShowGuidePopup()
                return
            end
            if string.sub(link, 1, 21) == "garrmission:emsTheme:" then
                if GRIPEMS.ThemeTransport and GRIPEMS.ThemeTransport.HandleLinkClick then
                    GRIPEMS.ThemeTransport:HandleLinkClick(link, chatFrame)
                end
            end
        end)

        -- Register the theme chat-link AceComm prefix (Phase D transport B)
        if GRIPEMS.ThemeTransport and GRIPEMS.ThemeTransport.Init then
            GRIPEMS.ThemeTransport:Init()
        end

        if GRIPEMS.Sound and GRIPEMS.Sound.Init then
            GRIPEMS.Sound:Init()
        end

        -- Wago Analytics (optional, pcall-wrapped)
        pcall(function()
            GRIPEMS.wagoAnalytics = LibStub("WagoAnalytics"):Register(ADDON_NAME)
        end)
    elseif event == "PLAYER_LOGIN" then
        if GRIPEMS.MirrorAccessibilityCVars then
            GRIPEMS:MirrorAccessibilityCVars(false)
        end

        -- Populate the secure vehicle-keybind matrix once at login so the
        -- attribute driver has vkcount/vkkey/vkslot before the first bar swap.
        if GRIPEMS.VehicleKeybinds and GRIPEMS.VehicleKeybinds.Initialize then
            GRIPEMS.VehicleKeybinds:Initialize()
        end

        local S = GRIPEMS.Settings
        if not (S and S:Get("hideLoginMsg")) then
            GRIPEMS:Print(string.format(L["GEMS_VERSION"], GRIPEMS.version))
            local activeCount = GRIPEMS.Engine and GRIPEMS.Engine:GetActiveCount() or 0
            if activeCount > 0 then
                GRIPEMS:Print(string.format(L["GEMS_LOGIN_ACTIVE"], activeCount))
            end
        end

        -- Phase H1.9b: Cross-class spell catalog drift notice. The bundled
        -- Data/CrossClassSpellCatalog.lua is regenerated per WoW patch from
        -- SimC's class_spell dump; the stamp in Defaults.SPELL_CATALOG_BUILD
        -- records which client build the catalog was generated against. If
        -- the running client drifts ahead of the stamp, surface a single
        -- informational print so the user knows the All Classes browse data
        -- may lag the live client. Respect hideLoginMsg the same way as the
        -- version print above so users who silenced login output stay silent.
        -- GetBuildInfo() positions 1+2 are buildVersion ("12.0.5") and
        -- buildNumber ("67403"); position 4 is interfaceVersion (number,
        -- 120005). The catalog stamp is the composite "12.0.5.67403", so
        -- we extract positions 1+2 and concat to match its shape.
        local clientVersion, clientBuild = GetBuildInfo()
        local gameBuild = (clientVersion and clientBuild) and (clientVersion .. "." .. clientBuild) or nil
        local catalogBuild = (GRIPEMS.Defaults and GRIPEMS.Defaults.SPELL_CATALOG_BUILD) or ""
        if gameBuild and catalogBuild ~= "" and gameBuild ~= catalogBuild then
            if not (GRIPEMS.Settings and GRIPEMS.Settings:Get("hideLoginMsg")) then
                GRIPEMS:Print(string.format(L["GEMS_SPELL_CATALOG_DRIFT"], catalogBuild, gameBuild))
            end
        end

        -- v2.1.0 Authorship Integrity: stamp no-provenance defaults on any
        -- sequence whose originalAuthor is nil. One-shot + idempotent:
        -- subsequent /reloads find originalAuthor already set and short-circuit.
        local function _MigrateSequenceProvenance(seq)
            if seq.originalAuthor ~= nil then
                -- Phase C polish: pre-polish v2.1.0 forks have forkedFrom but
                -- not forkedFromChain. Stamp the empty list so the editor row
                -- + ImportFrame chain code can rely on the field. Subsequent
                -- forks of these sequences inherit from forkedFrom via the
                -- StampForked elseif branch.
                seq.forkedFromChain = seq.forkedFromChain or {}
                return false
            end
            seq.originalAuthor = seq.author or "Unknown"
            seq.originalAuthorIdentity = ""
            seq.originalAuthorRealm = ""
            seq.originalAuthorBattleTag = nil
            seq.originalCreatedAt = 0
            seq.originalSignature = ""
            seq.lastModifier = seq.author or ""
            seq.lastModifierIdentity = ""
            seq.lastModifierRealm = ""
            seq.lastModifiedAt = 0
            seq.modifierChain = {}
            seq.forkedFrom = nil
            seq.forkedFromChain = {}
            seq.provenanceSource = "no-provenance"
            seq.privacyMode = "public"
            seq.signatureAlgorithm = "ALG_V0_DJB2"
            return true
        end
        local _migrated = 0
        if _G.GRIP_EMS_DB and GRIP_EMS_DB.sequences then
            for _, seq in pairs(GRIP_EMS_DB.sequences) do
                if type(seq) == "table" and _MigrateSequenceProvenance(seq) then
                    _migrated = _migrated + 1
                end
            end
        end
        if _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.sequences then
            for _, seq in pairs(GRIP_EMS_CHAR.sequences) do
                if type(seq) == "table" and _MigrateSequenceProvenance(seq) then
                    _migrated = _migrated + 1
                end
            end
        end
        if _migrated > 0 then
            GRIPEMS:Debug("Provenance migration: stamped " .. _migrated .. " sequence(s) with no-provenance defaults.")
        end

        -- Phase 2 #9 / #8: apply contrast preset, init focus ring
        if GRIPEMS.UI and GRIPEMS.UI.SetPalette then
            local pref = (GRIPEMS.Settings and GRIPEMS.Settings:Get("contrastPreset")) or "auto"
            local name = pref
            if name == "auto" then
                name = GRIPEMS.UI:ResolveAutoPreset()
            end
            GRIPEMS.UI:SetPalette(name)
            if GRIPEMS.UI.FocusRing and GRIPEMS.UI.FocusRing.Init then
                GRIPEMS.UI.FocusRing:Init()
            end
            -- CursorOverlay registers its profile-change watch at login so a
            -- switch to an overlay-enabled profile shows it. The frame itself
            -- is built lazily inside Refresh -- off-by-default users never
            -- build it. See UI/CursorOverlay.lua.
            if GRIPEMS.UI.CursorOverlay and GRIPEMS.UI.CursorOverlay.Init then
                GRIPEMS.UI.CursorOverlay:Init()
            end
            if GRIPEMS.UI and GRIPEMS.UI.HookAceGUIDropdowns then
                pcall(GRIPEMS.UI.HookAceGUIDropdowns, GRIPEMS.UI)
            end
            if GRIPEMS.UI and GRIPEMS.UI.HookAceGUIFonts then
                pcall(GRIPEMS.UI.HookAceGUIFonts, GRIPEMS.UI)
            end
            if GRIPEMS.RegisterCallback then
                GRIPEMS.RegisterCallback("GRIPEMS_PaletteAutoReapply", "SETTING_CHANGED", function(_, key)
                    if key ~= "contrastPreset" then
                        return
                    end
                    local cbS = GRIPEMS.Settings
                    local cbPref = (cbS and cbS:Get("contrastPreset")) or "auto"
                    local cbName = (cbPref == "auto") and GRIPEMS.UI:ResolveAutoPreset() or cbPref
                    GRIPEMS.UI:SetPalette(cbName)
                end)
            end
        end

        -- Initialize VariableStore (after SavedVariables, before UI)
        if GRIPEMS.VariableStore then
            GRIPEMS.VariableStore:Initialize()
        end

        -- Register SpellValidator callbacks (after CallbackHandler created in ADDON_LOADED)
        if GRIPEMS.SpellValidator and GRIPEMS.SpellValidator.RegisterCallbacks then
            GRIPEMS.SpellValidator:RegisterCallbacks()
        end

        -- Register Engine callbacks (same reason as SpellValidator above, and
        -- as SpellCache at L3310). Engine used to do this itself in two
        -- column-0 "if GRIPEMS.RegisterCallback then" blocks at the bottom of
        -- Engine.lua, which tested nil and registered NOTHING, so five heals
        -- and the macroResetModifiers republish were dead on every client.
        -- This call must stay AHEAD of the first SpellCache scan: SC:Scan is
        -- driven by SPELLS_CHANGED / PLAYER_ENTERING_WORLD off the frame
        -- SC:RegisterEvents creates, and both fire after ADDON_LOADED, so the
        -- SPELL_CACHE_REFRESHED handler is in place before the event can fire.
        if GRIPEMS.Engine and GRIPEMS.Engine.RegisterCallbacks then
            GRIPEMS.Engine:RegisterCallbacks()
        end

        -- Initialize CVar Profile Manager (after CallbackHandler + Settings)
        if GRIPEMS.CvarProfileManager then
            GRIPEMS.CvarProfileManager:Initialize()
        end

        -- Initialize SQW Optimizer (after CPM, before SettingsPanel)
        if GRIPEMS.SQWOptimizer then
            GRIPEMS.SQWOptimizer:Initialize()
        end

        -- Initialize TempoAdvisor (after SQW, needs SpellCache + Engine)
        if GRIPEMS.TempoAdvisor then
            GRIPEMS.TempoAdvisor:Initialize()
        end

        -- Initialize TempoOverlay (after TempoAdvisor, needs Settings + UI)
        if GRIPEMS.TempoOverlay then
            GRIPEMS.TempoOverlay:Init()
        end

        -- Auto-start ExecutionTracer on first sequence creation
        local ET = GRIPEMS.ExecutionTracer
        if ET then
            GRIPEMS.RegisterCallback("ExecutionTracer", "SEQUENCE_CREATED", function()
                if not ET:IsActive() then
                    ET:Start()
                end
            end)
        end

        -- Initialize syntax highlighting (after Settings, before UI)
        if GRIPEMS.SyntaxHighlight then
            GRIPEMS.SyntaxHighlight:Initialize()
        end

        -- Initialize settings panel (Blizzard Settings registration)
        if GRIPEMS.SettingsPanel then
            GRIPEMS.SettingsPanel:Initialize()
        end

        -- Initialize P2P transmission (after all modules, needs AceComm)
        if GRIPEMS.Transmission then
            GRIPEMS.Transmission:Initialize()
        end

        -- Load plugin sequences (after user sequences are restored)
        if GRIPEMS.LoadPluginSequences then
            GRIPEMS.LoadPluginSequences()
        end

        -- Initialize Tracker HUD (after all modules and settings)
        if GRIPEMS.TrackerHUD then
            GRIPEMS.TrackerHUD:Init()
        end

        -- Initialize Floating Menu (after all modules and settings)
        if GRIPEMS.FloatingMenu then
            GRIPEMS.FloatingMenu:Init()
        end

        -- v2.3.14 hotfix: ActionButtonUseKeyDown must be "1" (cast on key
        -- down) or the macro engine never advances. The recurring "nothing
        -- happens" report is almost always this CVar sitting at "0". Force it
        -- on at every login, independent of the auto-fix opt-in below.
        if not InCombatLockdown() and GetCVar("ActionButtonUseKeyDown") ~= "1" then
            SetCVar("ActionButtonUseKeyDown", "1")
        end

        -- Auto-fix CVars on login if enabled
        if GRIPEMS.Settings:Get("autoFixCVars") then
            local D = GRIPEMS.Defaults
            local autoEntries = GRIPEMS.Settings:Get("cvarAutoFixEntries") or {}
            local fixCount = 0
            local autoFixDetails = {}
            for _, section in ipairs(D.CVAR_SECTIONS) do
                for _, rec in ipairs(section.cvars) do
                    if rec.recommended and autoEntries[rec.cvar] then
                        -- G17: skip pinned CVars (user-intentional override)
                        local CPM = GRIPEMS.CvarProfileManager
                        if not (CPM and CPM.IsPinned and CPM:IsPinned(rec.cvar)) then
                            -- G.5-POLISH-CVARMATCH-NIL-GUARD-SWEEP: wrap GetCVar to match
                            -- the sibling autoFix-classifier pattern at L497. Defensive guard
                            -- only; rec.cvar is sourced from D.CVAR_SECTIONS so GetCVar should
                            -- never return nil here, but `or "?"` is house style in this file.
                            local current = D.CvarReadState(rec)
                            if not D.CvarIsRecommended(rec) then
                                if not InCombatLockdown() then
                                    if CPM and CPM.MarkAutoFixed then
                                        CPM:MarkAutoFixed(rec.cvar)
                                    end
                                    -- G7: capture previous value BEFORE SetCVar so user can undo later.
                                    if CPM and CPM.CapturePrevious then
                                        CPM:CapturePrevious(rec.cvar)
                                    end
                                    D.CvarApply(rec, rec.recommended)
                                    fixCount = fixCount + 1
                                    table.insert(
                                        autoFixDetails,
                                        { cvar = rec.cvar, from = current, to = rec.recommended }
                                    )
                                    GRIPEMS:Debug("CVar auto-fix: " .. rec.cvar .. " = " .. rec.recommended)
                                end
                            end
                        end
                    end
                end
            end
            if fixCount > 0 then
                GRIPEMS:Print(string.format(L["GEMS_CVAR_AUTOFIX_COUNT"], fixCount))
                if GRIPEMS.ReloadGate and GRIPEMS.ReloadGate.Notify then
                    GRIPEMS.ReloadGate:Notify("AUTOFIX_LOGIN", fixCount, autoFixDetails)
                end
            end
        end

        -- Detect CVar changes since last session and take snapshot
        -- (runs always, not gated behind autoFixCVars, so What Changed works regardless)
        if GRIPEMS.CvarProfileManager then
            GRIPEMS.CvarProfileManager:DetectChanges()
        end

        -- Score-history capture: delayed 30s so auto-fix-on-login (above) and
        -- any OOC-queued profile writes settle before the reading. "login"
        -- always records, even when unchanged, so the trend has cadence.
        if C_Timer and C_Timer.After then
            C_Timer.After(30, function()
                local CPM = GRIPEMS.CvarProfileManager
                if CPM and CPM.RecordHealthScore then
                    CPM:RecordHealthScore("login")
                end
            end)
        end

        -- Show What's New popup (after all modules, 2s delayed)
        if GRIPEMS.WhatsNew then
            GRIPEMS.WhatsNew:Init()
        end

        -- Gamepad/ConsolePort detection
        local gamepadDetected = false
        if C_AddOns and C_AddOns.IsAddOnLoaded("ConsolePort") then
            gamepadDetected = true
            GRIPEMS:Debug("ConsolePort detected -- gamepad keybind capture active")
        end
        local gpEnabled = GetCVar("GamePadEnable")
        if gpEnabled == "1" then
            gamepadDetected = true
            GRIPEMS:Debug("Native gamepad enabled -- gamepad keybind capture active")
        end
        GRIPEMS.gamepadDetected = gamepadDetected

        -- WagoAnalytics event tracking
        local function InitAnalytics()
            local wa = GRIPEMS.wagoAnalytics
            if not wa then
                return
            end

            -- Track sequence lifecycle events
            GRIPEMS.RegisterCallback("WagoAnalytics", "SEQUENCE_CREATED", function()
                wa:IncrementCounter("seq_created")
            end)
            GRIPEMS.RegisterCallback("WagoAnalytics", "SEQUENCE_DELETED", function()
                wa:IncrementCounter("seq_deleted")
            end)
            GRIPEMS.RegisterCallback("WagoAnalytics", "SEQUENCE_IMPORTED", function()
                wa:IncrementCounter("seq_imported")
            end)
            if GRIPEMS.PluginAPI then
                GRIPEMS.RegisterCallback("WagoAnalytics", "PLUGIN_REGISTERED", function()
                    wa:IncrementCounter("plugin_registered")
                end)
            end

            -- Track feature usage (one-time switches)
            local E = GRIPEMS.Engine
            if E then
                local checked = false
                GRIPEMS.RegisterCallback("WagoAnalytics", "SEQUENCE_STEP_ADVANCED", function()
                    if checked then
                        return
                    end
                    checked = true
                    -- Check feature usage on first step advance
                    for _, entry in pairs(E.sequences) do
                        local d = entry.data
                        if d then
                            if d.variables and next(d.variables) then
                                wa:Switch("feature_variables", true)
                            end
                            local v1 = type(d.versions) == "table" and d.versions[1] or nil
                            if v1 and v1.contextKey then
                                wa:Switch("feature_context", true)
                            end
                        end
                    end
                    local KM = GRIPEMS.KeybindManager
                    if KM then
                        local binds = KM:GetAllKeybinds()
                        if binds and next(binds) then
                            wa:Switch("feature_keybinds", true)
                        end
                    end
                end)
            end
        end
        InitAnalytics()

        -- Periodic GC to prevent memory balloon (garbage outpaces incremental GC)
        local D = GRIPEMS.Defaults
        if C_Timer and C_Timer.NewTicker then
            C_Timer.NewTicker(D.GC_INTERVAL, function()
                collectgarbage("step", 200)
            end)
        end

        -- One-shot migration: legacy editorScale -> unified uiScale.
        do
            local a = GRIPEMS.Settings
                and GRIPEMS.Settings.db
                and GRIPEMS.Settings.db.profile
                and GRIPEMS.Settings.db.profile.accessibility
            if a and not a.migratedEditorScaleToUiScale then
                if a.editorScale and a.editorScale ~= 1.0 and (a.uiScale == nil or a.uiScale == 1.0) then
                    a.uiScale = a.editorScale
                end
                a.migratedEditorScaleToUiScale = true
            end
        end

        -- Phase 4 item 21 (B.3+ per-element theming): additive migration.
        -- Empty elements table preserves pixel-identical v1.9.9 rendering.
        do
            local p = GRIPEMS.Settings and GRIPEMS.Settings.db and GRIPEMS.Settings.db.profile
            if p and not p.theming then
                p.theming = {
                    preset = "default",
                    elements = {},
                    savedThemes = {},
                    migratedFromB3 = true,
                }
            end
        end

        if GRIPEMS.UI and GRIPEMS.UI.ApplyTheme then
            GRIPEMS.UI:ApplyTheme()
        end
        if GRIPEMS.Theme and GRIPEMS.Theme.ApplyTheme then
            GRIPEMS.Theme.ApplyTheme()
        end

        local a = GRIPEMS.Settings
            and GRIPEMS.Settings.db
            and GRIPEMS.Settings.db.profile
            and GRIPEMS.Settings.db.profile.accessibility
        if a and a.simplifiedMode then
            if GRIPEMS.SequenceEditor and GRIPEMS.SequenceEditor.RelayoutSimplified then
                GRIPEMS.SequenceEditor:RelayoutSimplified()
            end
        end

        self:UnregisterEvent("ADDON_LOADED")
    elseif event == "CVAR_UPDATE" then
        local cvar = ...
        if cvar == "COLORBLIND_MODE" or cvar == "colorblindMode" then
            local S = GRIPEMS.Settings
            local pref = (S and S:Get("contrastPreset")) or "auto"
            if pref == "auto" and GRIPEMS.UI and GRIPEMS.UI.SetPalette then
                GRIPEMS.UI:SetPalette(GRIPEMS.UI:ResolveAutoPreset())
            end
        end
        if
            (cvar == "autoDismountFlying" or cvar == "autoUnshift")
            and GRIPEMS.KeybindManager
            and GRIPEMS.KeybindManager.RefreshAutoDismountAttr
        then
            GRIPEMS.KeybindManager:RefreshAutoDismountAttr()
        end
    elseif
        event == "PLAYER_REGEN_ENABLED"
        or event == "UPDATE_BONUS_ACTIONBAR"
        or event == "PLAYER_MOUNT_DISPLAY_CHANGED"
        or event == "UPDATE_SHAPESHIFT_FORM"
        or event == "PLAYER_IS_GLIDING_CHANGED"
    then
        -- SKYRIDE-WATCHDOG: reconcile both keybind layers against an offset-free
        -- reality check when skyriding exit signals go missing. The watchdog is
        -- OOC-only; PLAYER_REGEN_ENABLED re-runs it after a trigger landed in combat.
        if GRIPEMS.KeybindManager and GRIPEMS.KeybindManager.HealStuckSuspend then
            GRIPEMS.KeybindManager:HealStuckSuspend()
        end
    elseif event == "UNIT_ENTERED_VEHICLE" or event == "UNIT_EXITED_VEHICLE" then
        -- Only the player's own vehicle enter/exit bears on the EMS keybind layers.
        local unit = ...
        if unit == "player" and GRIPEMS.KeybindManager and GRIPEMS.KeybindManager.HealStuckSuspend then
            GRIPEMS.KeybindManager:HealStuckSuspend()
        end
    end
end)
