-- GRIP-EMS: Headless test for interleave overflow / clamp / copy-budget
--
-- Created:    2026-07-14
-- Updated:    2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.
--
-- Standalone (Lua 5.1) regression guard for Engine/ActionCompiler.lua's
-- interleave handling: the overflow clamp (47d12b9), the InterleaveOverflows
-- warning helper, and the shared copy budget. Named test_*.lua so the alltest
-- SET A / SET B discovery picks it up automatically -- the previous fix shipped
-- with zero automated coverage. Loads the REAL Data/Defaults.lua,
-- Engine/MacroSyntax.lua, and Engine/ActionCompiler.lua via loadfile + setfenv
-- into a sandbox, mirroring test_actioncompiler_disabled_children.lua.
--
-- Run from the EMS root:  lua Test/test_interleave_overflow.lua
-- Exit code 0 = all passed, 1 = at least one failure.
--
-- Cases:
--   T1  root interval 8 over 6 base steps clamps: one copy after base step 6
--   T2  loop repeat 1: interval 8 over 6 child steps clamps to one copy
--   T3  loop repeat 2: interval 8 over 12 compiled steps does NOT clamp
--   T4  ValidateActions warns on the T2 tree; isValid stays true
--   T5  ValidateActions warns on the T1 tree; isValid stays true
--   T6  interval 3 over 6 base steps: copies after 3 and 6, len 8, no warnings
--   T7  interleave-only tree returns and does not hang (clamp guard)
--   T8  pleggster repro: 6 base, intervals 4/8/8, all three macros appear
--   T9  import call-site parity: ApplyInterleaving == editor recompile
--   T10 EMBED resolves: baseCount 12, interval 8 fits, ZERO overflow findings
--   T11 EMBED does not resolve: helper refuses to warn on an untrusted count
--   T12 copy budget: truncated node reported got < want, matches real emission
--   T13 PRIORITY loop triangle (6 -> 21): interval 8 fits, no false overflow
--   T14 REVERSE_PRIORITY triangle: same 21-step count, interval 8 fits
--   T15 PRIORITY triangle (3 -> 6): interval 10 overruns, baseCount 6 not 3
--   T16 repeat measured by compiling: baseCount 6, perIteration 2, not assumed
--   T17 depth threaded: deep-nested chain overflows at depth 1, collapses deep

local ADDON_NAME = "GRIP-EMS"

-- ---------------------------------------------------------------------------
-- Minimal assertion + runner harness.
-- ---------------------------------------------------------------------------

local tests = {}

local function test(name, fn)
    tests[#tests + 1] = { name = name, fn = fn }
end

local function assertEqual(expected, actual, label)
    if expected ~= actual then
        error((label or "value") .. ": expected " .. tostring(expected) .. ", got " .. tostring(actual), 2)
    end
end

local function assertTrue(cond, label)
    if not cond then
        error((label or "condition") .. " failed", 2)
    end
end

local function count(steps, macro)
    local c = 0
    for _, step in ipairs(steps) do
        if step == macro then
            c = c + 1
        end
    end
    return c
end

local function anyWarning(warnings, ...)
    local needles = { ... }
    for _, w in ipairs(warnings) do
        if type(w) == "string" then
            local all = true
            for _, needle in ipairs(needles) do
                if not w:find(needle, 1, true) then
                    all = false
                    break
                end
            end
            if all then
                return true
            end
        end
    end
    return false
end

-- ---------------------------------------------------------------------------
-- Sandbox: a self-referential no-op stub backs every unknown global, so the
-- modules load without a real WoW client. Real stdlib falls through to _G.
-- ---------------------------------------------------------------------------

local stub = {}
setmetatable(stub, {
    __index = function()
        return stub
    end,
    __call = function()
        return stub
    end,
})

local env = setmetatable({}, {
    __index = function(_, k)
        local v = rawget(_G, k)
        if v ~= nil then
            return v
        end
        return stub
    end,
})
env._G = env

-- The warning-formatting tests need the REAL interleave format strings so
-- string.format renders the numbers. Every other key resolves to its own name
-- (no % specifiers, so string.format returns it verbatim).
local LOCALE = setmetatable({
    GEMS_INTERLEAVE_OVERFLOW_LOOP_FMT = "Node %s: interval %s exceeds this loop's %s compiled steps. Clamped to %s so it still fires. Set the loop's Repeat to %s for an exact interval of %s.",
    GEMS_INTERLEAVE_OVERFLOW_ROOT_FMT = "Node %s: interval %s exceeds the sequence's %s base steps. Clamped to %s so it still fires; lower the interval to that or less for an exact interval.",
    GEMS_INTERLEAVE_BUDGET_FMT = "Node %s: the interleave copy budget (%s) is spent. This action emits %s of its %s copies. Lower an interval or remove an interleave.",
}, {
    __index = function(_, k)
        return k
    end,
})

env.LibStub = function()
    return {
        GetLocale = function()
            return LOCALE
        end,
    }
end
env.strlower = string.lower
env.GetTime = function()
    return 0
end

local GRIPEMS = {
    Debug = function() end,
}

-- ---------------------------------------------------------------------------
-- Load the REAL modules into the sandbox. Defaults first (ActionCompiler
-- captures local D = GRIPEMS.Defaults at load), then MacroSyntax (the IF
-- compile path routes through it), then the compiler.
-- ---------------------------------------------------------------------------

local function loadModule(candidates)
    for _, path in ipairs(candidates) do
        -- loadfile is dev-harness file I/O, intentionally outside the addon WoW std.
        -- selene: allow(undefined_variable)
        local chunk = loadfile(path)
        if chunk then
            setfenv(chunk, env)
            chunk(ADDON_NAME, GRIPEMS)
            return true
        end
    end
    return false
end

assertTrue(
    loadModule({
        "Data/Defaults.lua",
        "../Data/Defaults.lua",
        "GRIP/EMS/Data/Defaults.lua",
    }),
    "could not locate Data/Defaults.lua (run from the EMS root)"
)
assertTrue(
    loadModule({
        "Engine/MacroSyntax.lua",
        "../Engine/MacroSyntax.lua",
        "GRIP/EMS/Engine/MacroSyntax.lua",
    }),
    "could not locate Engine/MacroSyntax.lua (run from the EMS root)"
)
assertTrue(
    loadModule({
        "Engine/ActionCompiler.lua",
        "../Engine/ActionCompiler.lua",
        "GRIP/EMS/Engine/ActionCompiler.lua",
    }),
    "could not locate Engine/ActionCompiler.lua (run from the EMS root)"
)

local D = GRIPEMS.Defaults
local AC = GRIPEMS.ActionCompiler
assertTrue(D ~= nil, "Defaults loaded")
assertTrue(GRIPEMS.MacroSyntax ~= nil, "MacroSyntax loaded")
assertTrue(AC ~= nil, "ActionCompiler loaded")
assertTrue(type(AC.CompileActions) == "function", "CompileActions defined")
assertTrue(type(AC.InterleaveOverflows) == "function", "InterleaveOverflows defined")
assertTrue(AC.MAX_INTERLEAVE_INSERTED == 200, "copy budget constant is 200")

-- ---------------------------------------------------------------------------
-- Fixtures.
-- ---------------------------------------------------------------------------

local WEAVE = "/cast Weave"
local M1 = "/cast Weave1"
local M2 = "/cast Weave2"
local M3 = "/cast Weave3"

local function action(macro, extra)
    local node = { type = D.ACTION_TYPE_ACTION, macro = macro }
    for k, v in pairs(extra or {}) do
        node[k] = v
    end
    return node
end

-- N plain base actions, macros "/cast BaseN" (no interval -> real base steps).
local function baseActions(n)
    local t = {}
    for i = 1, n do
        t[i] = action("/cast Base" .. i)
    end
    return t
end

-- Base actions plus a trailing interleave action.
local function withInterleave(n, macro, interval)
    local t = baseActions(n)
    t[#t + 1] = action(macro, { interval = interval })
    return t
end

-- ---------------------------------------------------------------------------
-- Cases.
-- ---------------------------------------------------------------------------

test("T1: root interval 8 over 6 base steps clamps to one copy after step 6", function()
    local steps = AC.CompileActions(withInterleave(6, WEAVE, 8), nil)
    assertEqual(7, #steps, "step count (6 base + 1 clamped copy)")
    assertEqual("/cast Base6", steps[6], "base step 6 precedes the copy")
    assertEqual(WEAVE, steps[7], "clamped copy sits immediately after base step 6")
    assertEqual(1, count(steps, WEAVE), "exactly one interleave copy")
end)

test("T2: loop repeat 1 interval 8 over 6 child steps clamps to one copy", function()
    local loopNode = {
        type = D.ACTION_TYPE_LOOP,
        ["repeat"] = 1,
        stepFunction = D.STEP_SEQUENTIAL,
        children = withInterleave(6, WEAVE, 8),
    }
    local steps = AC.CompileActions({ loopNode }, nil)
    assertEqual(7, #steps, "step count")
    assertEqual(WEAVE, steps[7], "copy after the sixth compiled step")
    assertEqual(1, count(steps, WEAVE), "exactly one copy")
end)

test("T3: loop repeat 2 interval 8 over 12 compiled steps does NOT clamp", function()
    local loopNode = {
        type = D.ACTION_TYPE_LOOP,
        ["repeat"] = 2,
        stepFunction = D.STEP_SEQUENTIAL,
        children = withInterleave(6, WEAVE, 8),
    }
    local steps = AC.CompileActions({ loopNode }, nil)
    assertEqual(13, #steps, "12 compiled base + 1 copy")
    assertEqual(WEAVE, steps[9], "copy lands at compiled position 9, not the end")
    assertEqual("/cast Base6", steps[13], "last step is a base step, not the copy")
    assertEqual(1, count(steps, WEAVE), "exactly one copy")
end)

test("T4: ValidateActions warns on the loop tree; isValid stays true", function()
    local loopNode = {
        type = D.ACTION_TYPE_LOOP,
        ["repeat"] = 1,
        stepFunction = D.STEP_SEQUENTIAL,
        children = withInterleave(6, WEAVE, 8),
    }
    local ok, _, warnings = AC.ValidateActions({ loopNode })
    assertEqual(true, ok, "overflow is a warning, never an error")
    assertTrue(
        anyWarning(warnings, "interval 8", "this loop's 6 compiled steps", "Repeat to 2"),
        "warning names interval 8, count 6, suggested repeat 2"
    )
end)

test("T5: ValidateActions warns on the root tree; isValid stays true", function()
    local ok, _, warnings = AC.ValidateActions(withInterleave(6, WEAVE, 8))
    assertEqual(true, ok, "overflow is a warning, never an error")
    assertTrue(
        anyWarning(warnings, "interval 8", "sequence's 6 base steps"),
        "root warning names interval 8 and count 6"
    )
end)

test("T6: interval 3 over 6 base steps -- copies after 3 and 6, len 8, no warnings", function()
    local steps = AC.CompileActions(withInterleave(6, WEAVE, 3), nil)
    assertEqual(8, #steps, "6 base + 2 copies")
    assertEqual(WEAVE, steps[4], "copy after base step 3")
    assertEqual(WEAVE, steps[8], "copy after base step 6")
    assertEqual(2, count(steps, WEAVE), "exactly two copies")
    local ok, _, warnings = AC.ValidateActions(withInterleave(6, WEAVE, 3))
    assertEqual(true, ok, "valid")
    assertEqual(0, #warnings, "an in-range interval emits no warning")
end)

test("T7: interleave-only tree returns and does not hang (clamp guard)", function()
    -- Direct guard: clamping to 0 base steps must not spin _applyInterleaving.
    local es, el = {}, {}
    AC.ApplyInterleaving(es, el, { { macro = WEAVE, interval = 8 } })
    assertEqual(0, #es, "zero base steps stays zero copies (no infinite loop)")

    -- End to end: the interleave-only fallback compiles the interleave as a
    -- base step instead of silently doing nothing.
    local steps = AC.CompileActions({ action(WEAVE, { interval = 8 }) }, nil)
    assertEqual(1, #steps, "fallback compiled the interleave as a base step")
    assertEqual(WEAVE, steps[1], "single base step is the interleave macro")
end)

test("T8: pleggster repro -- 6 base, intervals 4/8/8, all three macros appear", function()
    local tree = baseActions(6)
    tree[#tree + 1] = action(M1, { interval = 4 })
    tree[#tree + 1] = action(M2, { interval = 8 })
    tree[#tree + 1] = action(M3, { interval = 8 })
    local steps = AC.CompileActions(tree, nil)
    assertTrue(count(steps, M1) >= 1, "interval 4 macro fires")
    assertTrue(count(steps, M2) >= 1, "first clamped interval 8 macro fires")
    assertTrue(count(steps, M3) >= 1, "second clamped interval 8 macro fires")
end)

test("T9: import call-site parity -- ApplyInterleaving == editor recompile", function()
    local base = { "/cast B1", "/cast B2", "/cast B3", "/cast B4", "/cast B5", "/cast B6" }

    -- Import weaving path: mutate a flat base array in place.
    local direct, labels = {}, {}
    for i = 1, #base do
        direct[i] = base[i]
    end
    AC.ApplyInterleaving(direct, labels, { { macro = WEAVE, interval = 8 } })

    -- Editor recompile of the equivalent tree.
    local tree = {}
    for i = 1, #base do
        tree[i] = action(base[i])
    end
    tree[#tree + 1] = action(WEAVE, { interval = 8 })
    local recompiled = AC.CompileActions(tree, nil)

    assertEqual(#recompiled, #direct, "same length")
    for i = 1, #direct do
        assertEqual(recompiled[i], direct[i], "byte-identical step " .. i)
    end
end)

test("T10: EMBED resolves -- baseCount 12, interval 8 fits, ZERO overflow", function()
    local embedSteps = {}
    for i = 1, 10 do
        embedSteps[i] = "/cast Embed" .. i
    end
    local engine = {
        sequences = { MySeq = { data = { marker = true } } },
        GetActiveVersion = function(_, _)
            return { steps = embedSteps }
        end,
    }
    local tree = {
        { type = D.ACTION_TYPE_EMBED, sequence = "MySeq" },
        action("/cast Act1"),
        action("/cast Act2"),
        action(WEAVE, { interval = 8 }),
    }
    -- Sanity: with the engine the embed really resolves to 10 base steps
    -- (base 12, interval 8 <= 12, one copy after step 8 -> length 13).
    local steps = AC.CompileActions(tree, engine)
    assertEqual(13, #steps, "embed resolved to 10 -> base 12, one copy")

    local overflows, capped = AC.InterleaveOverflows(tree, nil, engine)
    assertEqual(0, #overflows, "interval 8 fits inside a base count of 12")
    assertEqual(0, #capped, "no budget truncation")
end)

test("T11: EMBED does not resolve -- helper refuses to warn on an untrusted count", function()
    local tree = {
        { type = D.ACTION_TYPE_EMBED, sequence = "MySeq" },
        action("/cast Act1"),
        action("/cast Act2"),
        action(WEAVE, { interval = 8 }),
    }
    -- An engine with no matching sequence: base count is a guess, so bail.
    local emptyEngine = {
        sequences = {},
        GetActiveVersion = function(_, _)
            return nil
        end,
    }
    local o1, c1 = AC.InterleaveOverflows(tree, nil, emptyEngine)
    assertEqual(0, #o1, "unresolved embed -> no false overflow")
    assertEqual(0, #c1, "unresolved embed -> no budget finding")

    -- nil engine falls back to GRIPEMS.Engine (absent here) -- still bail.
    local o2, c2 = AC.InterleaveOverflows(tree, nil, nil)
    assertEqual(0, #o2, "nil engine -> no false overflow")
    assertEqual(0, #c2, "nil engine -> no budget finding")
end)

test("T12: copy budget -- truncated node reported got < want, matches real emission", function()
    local children = baseActions(10)
    children[#children + 1] = action(WEAVE, { interval = 1 })
    local loopNode = {
        type = D.ACTION_TYPE_LOOP,
        ["repeat"] = 30,
        stepFunction = D.STEP_SEQUENTIAL,
        children = children,
    }
    -- baseCount = 10 * 30 = 300; interval 1 wants 300 copies, budget caps at 200.
    local _, capped = AC.InterleaveOverflows(loopNode.children, loopNode)
    assertEqual(1, #capped, "one truncated interleave")
    assertTrue(capped[1].got < capped[1].want, "truncation: got < want")
    assertEqual(300, capped[1].want, "wanted floor(300 / 1) copies")
    assertEqual(200, capped[1].got, "got the shared budget of 200")

    -- The warning must describe the REAL truncation, not a predicted one.
    local steps = AC.CompileActions({ loopNode }, nil)
    assertEqual(500, #steps, "300 base + 200 inserted")
    assertEqual(capped[1].got, #steps - 300, "reported got equals copies actually emitted")
end)

test("T13: PRIORITY loop, interval fits the triangle -- no false overflow", function()
    -- A Priority loop over 6 base child steps expands to a TRIANGLE:
    -- 6*7/2 = 21 compiled base steps, NOT 6. Interval 8 fits (copies land at
    -- base indices 8 and 16; the compiler clamps nothing). Before the
    -- compile-derived count this warned "exceeds this loop's 6 compiled
    -- steps" while the compiler had clamped nothing -- regression guard for
    -- the triangle divergence.
    local children = baseActions(6)
    children[#children + 1] = action(WEAVE, { interval = 8 })
    local loopNode = {
        type = D.ACTION_TYPE_LOOP,
        ["repeat"] = 1,
        stepFunction = D.STEP_PRIORITY,
        children = children,
    }
    local steps = AC.CompileActions({ loopNode }, nil)
    assertEqual(23, #steps, "21 triangle base steps + 2 interleave copies")
    assertEqual(2, count(steps, WEAVE), "interleave macro lands twice (base indices 8 and 16)")

    local overflows, capped = AC.InterleaveOverflows(children, loopNode)
    assertEqual(0, #overflows, "interval 8 fits inside 21 compiled steps")
    assertEqual(0, #capped, "no budget truncation")
end)

test("T14: REVERSE_PRIORITY loop, interval fits the mirrored triangle -- no false overflow", function()
    -- The reverse-priority triangle has the same 21-step count, so interval 8
    -- fits there too.
    local children = baseActions(6)
    children[#children + 1] = action(WEAVE, { interval = 8 })
    local loopNode = {
        type = D.ACTION_TYPE_LOOP,
        ["repeat"] = 1,
        stepFunction = D.STEP_REVERSE_PRIORITY,
        children = children,
    }
    local steps = AC.CompileActions({ loopNode }, nil)
    assertEqual(23, #steps, "21 mirrored-triangle base steps + 2 interleave copies")
    assertEqual(2, count(steps, WEAVE), "interleave macro lands twice")

    local overflows, capped = AC.InterleaveOverflows(children, loopNode)
    assertEqual(0, #overflows, "interval 8 fits inside 21 compiled steps")
    assertEqual(0, #capped, "no budget truncation")
end)

test("T15: PRIORITY loop, interval genuinely overruns the triangle", function()
    -- 3 base child steps -> triangle of 6. Interval 10 overruns 6, so the
    -- compiler DOES clamp. baseCount must be 6 (the triangle), NOT 3, and the
    -- suggested repeat is ceil(10 / 6) = 2.
    local children = baseActions(3)
    children[#children + 1] = action(WEAVE, { interval = 10 })
    local loopNode = {
        type = D.ACTION_TYPE_LOOP,
        ["repeat"] = 1,
        stepFunction = D.STEP_PRIORITY,
        children = children,
    }
    local overflows = AC.InterleaveOverflows(children, loopNode)
    assertEqual(1, #overflows, "interval 10 exceeds the 6-step triangle")
    assertEqual(6, overflows[1].baseCount, "baseCount is the triangle count 6, not 3")
    assertEqual(2, overflows[1].suggestedRepeat, "ceil(10 / 6) = 2")

    -- The compiler clamps: the macro appears once, after the last base step.
    local steps = AC.CompileActions({ loopNode }, nil)
    assertEqual(7, #steps, "6 triangle base steps + 1 clamped copy")
    assertEqual(1, count(steps, WEAVE), "exactly one clamped copy")
    assertEqual(WEAVE, steps[7], "clamped copy sits after the last base step")
end)

test("T16: repeat is measured through the compiler, not assumed", function()
    -- Sequential loop, 2 base child steps, Repeat 3 -> 6 compiled base steps.
    -- Interval 8 overruns 6. perIteration must be MEASURED (2) via a
    -- one-iteration compile, not assumed, so a future refactor cannot quietly
    -- reintroduce the multiplication.
    local children = baseActions(2)
    children[#children + 1] = action(WEAVE, { interval = 8 })
    local loopNode = {
        type = D.ACTION_TYPE_LOOP,
        ["repeat"] = 3,
        stepFunction = D.STEP_SEQUENTIAL,
        children = children,
    }
    local overflows = AC.InterleaveOverflows(children, loopNode)
    assertEqual(1, #overflows, "interval 8 exceeds the 6 compiled base steps")
    assertEqual(6, overflows[1].baseCount, "baseCount is repeat 3 * 2 = 6, obtained by compiling")
    assertEqual(2, overflows[1].perIteration, "perIteration measured as 2 via a one-iteration compile")
    assertEqual(4, overflows[1].suggestedRepeat, "ceil(8 / 2) = 4")
end)

test("T17: overflow count is measured at the scope's real nesting depth", function()
    -- The live compiler caps output past D.ACTION_MAX_DEPTH, so a loop's base
    -- count depends on the depth it is compiled at. A chain of nested
    -- Sequential loops wrapping base actions survives a shallow compile but
    -- truncates to zero once the chain lands past the cap. Rooted at depth 1
    -- the outer loop has 3 base steps and interval 8 overruns them (one
    -- overflow); rooted at the cap the base count collapses to 0 and the
    -- helper bails. Before depth was threaded through, both calls compiled at
    -- depth 1 and the deep call wrongly matched the shallow result.
    local MAXD = D.ACTION_MAX_DEPTH

    -- Base child: outer -> chain -> deepLeaf -> {D1,D2,D3}. Rooted at depth 1
    -- the deepest action sits at depth 4 (well within the cap); rooted at the
    -- cap the chain's first nested level lands past it and truncates.
    local deepLeaf = {
        type = D.ACTION_TYPE_LOOP,
        ["repeat"] = 1,
        stepFunction = D.STEP_SEQUENTIAL,
        children = { action("/cast D1"), action("/cast D2"), action("/cast D3") },
    }
    local chain = {
        type = D.ACTION_TYPE_LOOP,
        ["repeat"] = 1,
        stepFunction = D.STEP_SEQUENTIAL,
        children = { deepLeaf },
    }
    local outer = {
        type = D.ACTION_TYPE_LOOP,
        ["repeat"] = 1,
        stepFunction = D.STEP_SEQUENTIAL,
        children = { chain, action(WEAVE, { interval = 8 }) },
    }

    -- Depth 1: the chain compiles to 3 base steps; interval 8 overruns them.
    local oShallow, cShallow = AC.InterleaveOverflows(outer.children, outer, nil, 1)
    assertTrue(#oShallow >= 1, "depth 1: interval 8 overruns the 3 compiled base steps")
    assertEqual(3, oShallow[1].baseCount, "depth 1 base count is the 3 compiled deep-chain steps")

    -- Rooted at the cap: the outer loop survives but its first nested level
    -- lands past D.ACTION_MAX_DEPTH and truncates, so the base count is 0 and
    -- the helper bails -- no overflow, no budget finding.
    local deepDepth = MAXD
    local oDeep, cDeep = AC.InterleaveOverflows(outer.children, outer, nil, deepDepth)
    assertEqual(0, #oDeep, "deep depth: base count collapses to 0, no overflow finding")
    assertEqual(0, #cDeep, "deep depth: no budget finding either")

    -- The whole point: the two depths must disagree. Pre-fix they matched.
    assertTrue(#oShallow ~= #oDeep, "depth must change the result; pre-fix both compiled at depth 1")
    assertEqual(0, #cShallow, "depth 1: one clamped copy fits the budget, nothing truncated")
end)

-- ---------------------------------------------------------------------------
-- Run.
-- ---------------------------------------------------------------------------

local passed = 0
local failed = 0
for _, t in ipairs(tests) do
    local ok, err = pcall(t.fn)
    if ok then
        passed = passed + 1
        print("PASS  " .. t.name)
    else
        failed = failed + 1
        print("FAIL  " .. t.name .. " -- " .. tostring(err))
    end
end
print(string.format("RESULT %d passed, %d failed", passed, failed))
os.exit(failed > 0 and 1 or 0)
