-- GRIP-EMS: Raw Macrotext Editor Tab
-- Read-only/editable view of full sequence data as a Lua table

local ADDON_NAME, GRIPEMS = ...
local UI = GRIPEMS.UI
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS")

-- Upvalue accessor for Defaults
local function D() return GRIPEMS.Defaults end

GRIPEMS.RawTab = {}
local RT = GRIPEMS.RawTab

-- Runtime state
RT.isEditing = false
RT.container = nil
RT.currentName = nil

---------------------------------------------------------------------------
-- Table serializer (human-readable Lua)
---------------------------------------------------------------------------

--- Check if a table is an array (consecutive integer keys 1..#tbl).
--- @param tbl table
--- @return boolean
local function isArray(tbl)
    local count = 0
    for _ in pairs(tbl) do
        count = count + 1
    end
    if count ~= #tbl then return false end
    for i = 1, count do
        if tbl[i] == nil then return false end
    end
    return true
end

--- Serialize a Lua table to human-readable Lua source.
--- Handles strings, numbers, booleans, and nested tables.
--- @param tbl table The table to serialize
--- @param indent string Current indentation (default "")
--- @return string
function RT:SerializeTable(tbl, indent)
    indent = indent or ""
    local nextIndent = indent .. "    "
    local lines = {}

    lines[#lines + 1] = "{"

    if isArray(tbl) then
        -- Array format: no explicit keys
        for i = 1, #tbl do
            local v = tbl[i]
            local vType = type(v)
            if vType == "string" then
                lines[#lines + 1] = nextIndent .. "\"" .. v:gsub("\\", "\\\\"):gsub("\"", "\\\""):gsub("\n", "\\n") .. "\","
            elseif vType == "number" then
                lines[#lines + 1] = nextIndent .. tostring(v) .. ","
            elseif vType == "boolean" then
                lines[#lines + 1] = nextIndent .. tostring(v) .. ","
            elseif vType == "table" then
                lines[#lines + 1] = nextIndent .. RT:SerializeTable(v, nextIndent) .. ","
            end
        end
    else
        -- Hash table format: sorted string keys
        local keys = {}
        for k in pairs(tbl) do
            if type(k) == "string" then
                keys[#keys + 1] = k
            end
        end
        sort(keys)

        for _, k in ipairs(keys) do
            local v = tbl[k]
            local vType = type(v)
            if vType == "string" then
                lines[#lines + 1] = nextIndent .. k .. " = \"" .. v:gsub("\\", "\\\\"):gsub("\"", "\\\""):gsub("\n", "\\n") .. "\","
            elseif vType == "number" then
                lines[#lines + 1] = nextIndent .. k .. " = " .. tostring(v) .. ","
            elseif vType == "boolean" then
                lines[#lines + 1] = nextIndent .. k .. " = " .. tostring(v) .. ","
            elseif vType == "table" then
                lines[#lines + 1] = nextIndent .. k .. " = " .. RT:SerializeTable(v, nextIndent) .. ","
            end
        end
    end

    lines[#lines + 1] = indent .. "}"
    return table.concat(lines, "\n")
end

---------------------------------------------------------------------------
-- Initialization
---------------------------------------------------------------------------

--- Build the Raw tab UI inside the content area.
--- @param contentArea Frame The shared content area from SequenceEditor
function RT:Init(contentArea)
    if not contentArea then return end
    RT.container = contentArea
    local C = UI.Colors

    -- Main frame (fills content area)
    local mainFrame = CreateFrame("Frame", nil, contentArea, "BackdropTemplate")
    mainFrame:SetAllPoints(contentArea)
    mainFrame:SetBackdrop(UI.Backdrops.panelNoBorder)
    mainFrame:SetBackdropColor(C.bgMain:GetRGBA())
    mainFrame:Hide()
    RT.mainFrame = mainFrame

    -- Header row (28px)
    local headerHeight = D().RAW_HEADER_HEIGHT

    local titleLabel = mainFrame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(titleLabel, 11)
    titleLabel:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", 8, -6)
    titleLabel:SetText(L["GEMS_RAW_TITLE"])
    titleLabel:SetTextColor(C.textPrimary:GetRGBA())

    -- Cancel button (right side, before Edit/Apply)
    local cancelBtn = UI:CreateButton(mainFrame, L["GEMS_RAW_CANCEL"], 60, 22)
    cancelBtn:SetPoint("TOPRIGHT", mainFrame, "TOPRIGHT", -8, -3)
    cancelBtn:SetScript("OnClick", function()
        RT:ExitEditMode()
    end)
    cancelBtn:Hide()
    RT.cancelBtn = cancelBtn

    -- Edit/Apply button (left of Cancel)
    local editBtn = UI:CreateButton(mainFrame, L["GEMS_RAW_EDIT"], 60, 22)
    editBtn:SetPoint("RIGHT", cancelBtn, "LEFT", -4, 0)
    editBtn:SetScript("OnClick", function()
        if RT.isEditing then
            RT:ApplyChanges()
        else
            RT:EnterEditMode()
        end
    end)
    RT.editBtn = editBtn

    -- Read-only hint (below title)
    local hintLabel = mainFrame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(hintLabel, 9)
    hintLabel:SetPoint("TOPLEFT", titleLabel, "BOTTOMLEFT", 0, -1)
    hintLabel:SetText(L["GEMS_RAW_READONLY_HINT"])
    hintLabel:SetTextColor(C.textMuted:GetRGBA())
    RT.hintLabel = hintLabel

    -- ScrollFrame (below header)
    local statusHeight = D().RAW_STATUS_HEIGHT
    local scrollFrame = CreateFrame("ScrollFrame", nil, mainFrame, "UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", 8, -headerHeight)
    scrollFrame:SetPoint("BOTTOMRIGHT", mainFrame, "BOTTOMRIGHT", -26, statusHeight + 4)

    -- Scroll child (EditBox container)
    local scrollChild = CreateFrame("Frame", nil, scrollFrame)
    scrollChild:SetWidth(scrollFrame:GetWidth() or 400)
    scrollFrame:SetScrollChild(scrollChild)
    RT.scrollFrame = scrollFrame
    RT.scrollChild = scrollChild

    -- Update scroll child width when scrollFrame resizes
    scrollFrame:SetScript("OnSizeChanged", function(self, w)
        scrollChild:SetWidth(w)
        if RT.editBox then
            RT.editBox:SetWidth(w)
        end
    end)

    -- EditBox inside scroll child
    local editBox = CreateFrame("EditBox", nil, scrollChild)
    editBox:SetMultiLine(true)
    editBox:SetAutoFocus(false)
    editBox:SetAllPoints(scrollChild)
    local fontPath = GameFontNormal:GetFont()
    editBox:SetFont(fontPath, 10, "")
    editBox:SetTextColor(C.textSecondary:GetRGBA())
    editBox:EnableKeyboard(false)
    editBox:EnableMouse(true)
    editBox:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
    end)
    -- Auto-resize scroll child to fit text
    editBox:SetScript("OnTextChanged", function(self)
        local height = self:GetHeight()
        if height and height > 0 then
            scrollChild:SetHeight(height)
        end
    end)
    RT.editBox = editBox

    -- Status line (bottom of main frame)
    local statusLine = mainFrame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(statusLine, 10)
    statusLine:SetPoint("BOTTOMLEFT", mainFrame, "BOTTOMLEFT", 8, 4)
    statusLine:SetPoint("BOTTOMRIGHT", mainFrame, "BOTTOMRIGHT", -8, 4)
    statusLine:SetJustifyH("LEFT")
    statusLine:SetTextColor(C.textSuccess:GetRGBA())
    statusLine:Hide()
    RT.statusLine = statusLine
end

---------------------------------------------------------------------------
-- Show / Hide
---------------------------------------------------------------------------

--- Show the Raw tab.
function RT:Show()
    if RT.mainFrame then
        RT.mainFrame:Show()
        RT:RefreshDisplay()
    end
end

--- Hide the Raw tab.
function RT:Hide()
    if RT.mainFrame then
        RT.mainFrame:Hide()
    end
    if RT.isEditing then
        RT:ExitEditMode()
    end
end

---------------------------------------------------------------------------
-- Sequence loading
---------------------------------------------------------------------------

--- Load a sequence into the Raw tab.
--- @param name string Sequence name
function RT:LoadSequence(name)
    RT.currentName = name
    RT:RefreshDisplay()
end

--- Clear the Raw tab state.
function RT:Clear()
    RT.currentName = nil
    if RT.editBox then
        RT.editBox:SetText("")
    end
    if RT.mainFrame then
        RT.mainFrame:Hide()
    end
    if RT.isEditing then
        RT:ExitEditMode()
    end
end

---------------------------------------------------------------------------
-- Display refresh
---------------------------------------------------------------------------

--- Refresh the EditBox with the current sequence data.
function RT:RefreshDisplay()
    if not RT.editBox then return end

    local C = UI.Colors
    local name = RT.currentName
    if not name then
        RT.editBox:SetText(L["GEMS_RAW_NO_SEQUENCE"])
        return
    end

    local engine = GRIPEMS.Engine
    local entry = engine and engine.sequences and engine.sequences[name]
    if not entry or not entry.data then
        RT.editBox:SetText(L["GEMS_RAW_NO_SEQUENCE"])
        return
    end

    local text = RT:SerializeTable(entry.data)
    RT.editBox:SetText(text)

    -- Ensure read-only appearance
    if not RT.isEditing then
        RT.editBox:EnableKeyboard(false)
        RT.editBox:SetTextColor(C.textSecondary:GetRGBA())
    end
end

---------------------------------------------------------------------------
-- Edit mode
---------------------------------------------------------------------------

--- Enter edit mode (editable, Apply/Cancel visible).
function RT:EnterEditMode()
    RT.isEditing = true
    local C = UI.Colors

    if RT.editBox then
        RT.editBox:EnableKeyboard(true)
        RT.editBox:SetTextColor(C.textPrimary:GetRGBA())
    end
    if RT.editBtn then
        RT.editBtn:SetText(L["GEMS_RAW_APPLY"])
    end
    if RT.cancelBtn then
        RT.cancelBtn:Show()
    end
    if RT.hintLabel then
        RT.hintLabel:Hide()
    end
    if RT.statusLine then
        RT.statusLine:SetText("")
        RT.statusLine:Show()
    end
end

--- Exit edit mode (read-only, revert to engine data).
function RT:ExitEditMode()
    RT.isEditing = false
    local C = UI.Colors

    if RT.editBox then
        RT.editBox:EnableKeyboard(false)
        RT.editBox:SetTextColor(C.textSecondary:GetRGBA())
        RT.editBox:ClearFocus()
    end
    if RT.editBtn then
        RT.editBtn:SetText(L["GEMS_RAW_EDIT"])
    end
    if RT.cancelBtn then
        RT.cancelBtn:Hide()
    end
    if RT.hintLabel then
        RT.hintLabel:Show()
    end
    if RT.statusLine then
        RT.statusLine:Hide()
    end

    RT:RefreshDisplay()
end

---------------------------------------------------------------------------
-- Apply changes
---------------------------------------------------------------------------

--- Validate and apply edited Lua table back to the engine.
function RT:ApplyChanges()
    if not RT.editBox then return end

    local C = UI.Colors
    local text = RT.editBox:GetText()

    -- Validate Lua syntax
    local fn, err = loadstring("return " .. text)
    if not fn then
        if RT.statusLine then
            RT.statusLine:SetText(string.format(L["GEMS_RAW_INVALID"], err or "unknown"))
            RT.statusLine:SetTextColor(C.textError:GetRGBA())
        end
        return
    end

    -- Execute to get the table
    local ok, result = pcall(fn)
    if not ok or type(result) ~= "table" then
        if RT.statusLine then
            RT.statusLine:SetText(string.format(L["GEMS_RAW_INVALID"],
                not ok and tostring(result) or "Result is not a table"))
            RT.statusLine:SetTextColor(C.textError:GetRGBA())
        end
        return
    end

    -- Validate required fields
    if type(result.name) ~= "string" or result.name == "" then
        if RT.statusLine then
            RT.statusLine:SetText(string.format(L["GEMS_RAW_MISSING_FIELD"], "name"))
            RT.statusLine:SetTextColor(C.textError:GetRGBA())
        end
        return
    end

    -- Handle name change: ignore, override back to current
    local currentName = RT.currentName
    local nameChanged = result.name ~= currentName

    -- Build clean seqData table (version-aware)
    local newSeqData = {
        name = currentName,
        icon = result.icon,
        autoIcon = result.autoIcon,
        author = result.author or "",
        version = result.version or "1",
        description = result.description or "",
        classID = result.classID or 0,
        specID = result.specID,
        createdAt = result.createdAt or time(),
        updatedAt = time(),
    }

    if result.versions and type(result.versions) == "table"
            and next(result.versions) then
        -- Versioned format: validate each version
        for i, ver in ipairs(result.versions) do
            if type(ver) ~= "table" or type(ver.steps) ~= "table" then
                if RT.statusLine then
                    RT.statusLine:SetText(string.format(
                        L["GEMS_RAW_MISSING_FIELD"], "versions[" .. i .. "].steps"))
                    RT.statusLine:SetTextColor(C.textError:GetRGBA())
                end
                return
            end
            local sf = ver.stepFunction
            if sf ~= "Sequential" and sf ~= "Random" and sf ~= "Priority" then
                if RT.statusLine then
                    RT.statusLine:SetText(string.format(
                        L["GEMS_RAW_MISSING_FIELD"],
                        "versions[" .. i .. "].stepFunction"))
                    RT.statusLine:SetTextColor(C.textError:GetRGBA())
                end
                return
            end
        end
        newSeqData.defaultVersion = result.defaultVersion or 1
        newSeqData.versions = {}
        for i, ver in ipairs(result.versions) do
            newSeqData.versions[i] = {
                stepFunction = ver.stepFunction or "Sequential",
                resetOnCombat = ver.resetOnCombat and true or false,
                resetOnTarget = ver.resetOnTarget and true or false,
                resetOnGear = ver.resetOnGear and true or false,
                resetOnSpec = ver.resetOnSpec and true or false,
                resetTimer = tonumber(ver.resetTimer) or 0,
                steps = {},
            }
            if ver.steps then
                for j = 1, #ver.steps do
                    newSeqData.versions[i].steps[j] = tostring(ver.steps[j])
                end
            end
        end
    elseif result.steps and type(result.steps) == "table" then
        -- Legacy flat format: validate then migrate
        if result.stepFunction ~= "Sequential" and result.stepFunction ~= "Random"
                and result.stepFunction ~= "Priority" then
            if RT.statusLine then
                RT.statusLine:SetText(string.format(
                    L["GEMS_RAW_MISSING_FIELD"], "stepFunction"))
                RT.statusLine:SetTextColor(C.textError:GetRGBA())
            end
            return
        end
        newSeqData.steps = {}
        for i = 1, #result.steps do
            newSeqData.steps[i] = tostring(result.steps[i])
        end
        newSeqData.stepFunction = result.stepFunction or "Sequential"
        newSeqData.resetOnCombat = result.resetOnCombat and true or false
        newSeqData.resetOnTarget = result.resetOnTarget and true or false
        newSeqData.resetOnGear = result.resetOnGear and true or false
        newSeqData.resetOnSpec = result.resetOnSpec and true or false
        newSeqData.resetTimer = tonumber(result.resetTimer) or 0
        GRIPEMS.Engine:MigrateSequenceFormat(newSeqData)
    else
        if RT.statusLine then
            RT.statusLine:SetText(string.format(
                L["GEMS_RAW_MISSING_FIELD"], "versions or steps"))
            RT.statusLine:SetTextColor(C.textError:GetRGBA())
        end
        return
    end

    -- Apply to engine
    local engine = GRIPEMS.Engine
    if engine and engine.UpdateSequenceData then
        engine:UpdateSequenceData(currentName, newSeqData)
    end

    -- Mark editor dirty so user can Save to persist
    local SE = GRIPEMS.SequenceEditor
    if SE then
        SE.isDirty = true
        if SE.UpdateSaveButtons then
            SE:UpdateSaveButtons()
        end
    end

    -- Exit edit mode
    RT:ExitEditMode()

    -- Show success message (with name warning if applicable)
    if RT.statusLine then
        if nameChanged then
            RT.statusLine:SetText(L["GEMS_RAW_NAME_IGNORED"])
            RT.statusLine:SetTextColor(C.textWarning:GetRGBA())
        else
            RT.statusLine:SetText(L["GEMS_RAW_APPLIED"])
            RT.statusLine:SetTextColor(C.textSuccess:GetRGBA())
        end
        RT.statusLine:Show()
        -- Hide after 2 seconds
        C_Timer.After(2, function()
            if RT.statusLine and not RT.isEditing then
                RT.statusLine:Hide()
            end
        end)
    end
end
