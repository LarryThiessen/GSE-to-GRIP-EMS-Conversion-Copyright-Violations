-- Created: 2026-04-19
-- Updated: 2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.
-- Blizzard TTS shim. All C_VoiceChat / C_TTSSettings calls are pcall-wrapped.
-- Silent no-op on any failure path except the one-shot first-enable toast.

local _, ns = ...
local GRIPEMS = ns
GRIPEMS.Speech = GRIPEMS.Speech or {}
local Speech = GRIPEMS.Speech
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

--- Resolve the current Blizzard TTS voice ID for the Alternate voice slot.
--- Returns nil if C_TTSSettings is unavailable or the lookup errors.
function Speech:GetVoiceID()
    if not C_TTSSettings or not C_TTSSettings.GetVoiceOptionID or not Enum or not Enum.TtsVoiceType then
        return nil
    end
    local ok, voiceID = pcall(C_TTSSettings.GetVoiceOptionID, Enum.TtsVoiceType.Alternate)
    if not ok then
        return nil
    end
    return voiceID
end

--- Speak a short string via Blizzard TTS. Silent no-op when disabled, missing
--- API, or no voice selected. First time a no-voice condition is hit after
--- speech is enabled, surface a one-shot UIErrorsFrame toast pointing at the
--- Social menu voice chat setting.
function Speech:Announce(text)
    local EMS = GRIPEMS.Settings
    if not EMS or not EMS.db or not EMS.db.profile or not EMS.db.profile.accessibility then
        return
    end
    if type(text) ~= "string" or #text == 0 then
        return
    end
    local a = EMS.db.profile.accessibility

    -- Tier A: TTS via C_VoiceChat.SpeakText (independent channel)
    if a.speechEnabled then
        local voiceID = self:GetVoiceID()
        if voiceID == nil then
            if not a.speechFirstEnableShown then
                if UIErrorsFrame and UIErrorsFrame.AddMessage then
                    pcall(UIErrorsFrame.AddMessage, UIErrorsFrame, L["ACCESS_SPEECH_NO_VOICE_TOAST"], 1.0, 0.5, 0.0)
                end
                a.speechFirstEnableShown = true
            end
        elseif C_VoiceChat and C_VoiceChat.SpeakText then
            local rate = a.speechRate or 0
            local volume = a.speechVolume or 100
            pcall(C_VoiceChat.SpeakText, voiceID, text, rate, volume, false)
        end
    end

    -- Tier B: ChatFrame emit via AddMessage (independent channel)
    if a.chatEmitterEnabled then
        local slot = a.chatEmitterFrame or 9
        local frame = _G["ChatFrame" .. tostring(slot)] or DEFAULT_CHAT_FRAME
        if frame and frame.AddMessage then
            pcall(frame.AddMessage, frame, L["ACCESS_CHAT_EMITTER_PREFIX"] .. text)
        end
    end
end
