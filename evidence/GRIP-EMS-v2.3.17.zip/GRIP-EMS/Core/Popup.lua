-- GRIP-EMS: Core/Popup.lua
-- Created: 2026-05-03
-- Updated: 2026-06-21
-- Patch: 12.0.7.68256 Midnight (Retail LIVE)
--
-- Custom modal popup framework. Replaces all 29 EMS uses of the
-- global _G.StaticPopupDialogs table. The bug fix this targets is
-- BUG-TAINT-CANCELLOGOUT: writing entries to _G.StaticPopupDialogs
-- at addon load taints the whole table, and every subsequent
-- Blizzard read of that table inherits the EMS taint. By keeping
-- definitions in a private table and rendering popups from a
-- frame we own, we avoid touching _G.StaticPopupDialogs entirely.
--
-- Public API (mirrors the StaticPopupDialogs surface EMS uses):
--   GRIPEMS.Popup:Define(name, def)
--   GRIPEMS.Popup:GetDef(name)
--   GRIPEMS.Popup:Show(name, text1, text2, data) -> frame|false
--   GRIPEMS.Popup:Hide(name)
--   GRIPEMS.Popup:IsShown(name) -> boolean
--
-- Definition table fields supported:
--   text          string with optional %s/%d sprintf placeholders
--   button1       string label for the primary button (left)
--   button2       string label for the secondary button (right)
--   button3       string label for the optional alt button (centered between b1/b2)
--   OnAccept      function(frame, data) -- fires on button1 click
--   OnCancel      function(frame, data) -- fires on button2 click OR ESC dismissal
--   OnAlt         function(frame, data) -- fires on button3 click
--   OnShow        function(frame)
--   OnHide        function(frame)
--   hasEditBox    boolean
--   editBoxWidth  number (pixels)
--   maxLetters    number (edit box character limit)
--   timeout       number; 0 = no auto-close (only value EMS uses)
--   hideOnEscape  boolean, default true
--
-- The frame argument passed to callbacks exposes:
--   frame.EditBox          the optional edit box widget
--   frame.data             the data argument from Show()
--   frame.currentName      the popup name currently displayed

local ADDON_NAME, GRIPEMS = ...
GRIPEMS.Popup = GRIPEMS.Popup or {}
local POP = GRIPEMS.Popup

-- Private definition store. NEVER mirrored to _G.StaticPopupDialogs.
local definitions = {}

-- Single shared modal frame (lazily created on first Show).
local sharedFrame = nil

----------------------------------------------------------------
-- Modal frame construction
----------------------------------------------------------------

----------------------------------------------------------------
-- Combat-safe wrapper for SetPropagateKeyboardInput
----------------------------------------------------------------

-- SetPropagateKeyboardInput is protected during combat. The frame
-- OnKeyDown handler calls it on every key press while a popup is
-- shown. Without this guard, any popup that lingers into combat
-- would fire ADDON_ACTION_BLOCKED on every WASD key. OOC behavior
-- is unchanged.
local function SafeSetPropagate(frame, value)
    if InCombatLockdown() then
        return
    end
    frame:SetPropagateKeyboardInput(value)
end

local function CreatePopupFrame()
    local UIm = GRIPEMS.UI
    local frame = CreateFrame("Frame", "GRIPEMS_PopupFrame", UIParent, "BackdropTemplate")
    frame:SetSize(420, 180)
    frame:SetPoint("CENTER")
    frame:SetFrameStrata("DIALOG")
    frame:SetFrameLevel(200)
    frame:EnableMouse(true)
    frame:Hide()

    frame:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true,
        tileSize = 32,
        edgeSize = 32,
        insets = { left = 11, right = 12, top = 12, bottom = 11 },
    })

    -- Body text (centered, wraps).
    local body = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    body:SetPoint("TOP", frame, "TOP", 0, -20)
    body:SetWidth(380)
    body:SetJustifyH("CENTER")
    body:SetJustifyV("TOP")
    body:SetSpacing(2)
    frame.Body = body
    if UIm and UIm.SetFont then
        UIm:SetFont(body, 11)
    end

    -- Edit box (hidden by default; shown when def.hasEditBox).
    local editBox = CreateFrame("EditBox", "$parentEditBox", frame, "InputBoxTemplate")
    editBox:SetSize(200, 20)
    editBox:SetPoint("BOTTOM", frame, "BOTTOM", 0, 60)
    editBox:SetAutoFocus(false)
    editBox:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
        local f = self:GetParent()
        if f.def and f.def.hideOnEscape ~= false then
            local def, name, data = f.def, f.currentName, f.data
            if def and def.OnCancel then
                local ok, err = pcall(def.OnCancel, f, data)
                if not ok and GRIPEMS.Debug then
                    GRIPEMS:Debug("Popup EditBox ESC OnCancel error:", name, err)
                end
            end
            POP:Hide(name)
        end
    end)
    editBox:SetScript("OnEnterPressed", function(self)
        self:ClearFocus()
        local f = self:GetParent()
        if f.button1 and f.button1:IsEnabled() then
            f.button1:Click()
        end
    end)
    editBox:Hide()
    frame.EditBox = editBox
    -- HookEditBox keeps popup typing from leaking to global keybinds
    -- (Belt/Braces for the v2.1.7 SpellPicker keyboard-steal fix).
    if GRIPEMS.Focus and GRIPEMS.Focus.HookEditBox then
        GRIPEMS.Focus:HookEditBox(editBox)
    end

    -- Buttons. button1 left, button2 right, button3 (optional) center.
    local function MakeButton(parent, name)
        local b = CreateFrame("Button", "$parent" .. name, parent, "UIPanelButtonTemplate")
        b:SetSize(120, 22)
        b:Hide()
        return b
    end

    frame.button1 = MakeButton(frame, "Button1")
    frame.button2 = MakeButton(frame, "Button2")
    frame.button3 = MakeButton(frame, "Button3")
    if UIm and UIm.RegisterLargeTarget then
        UIm:RegisterLargeTarget(frame.button1)
        UIm:RegisterLargeTarget(frame.button2)
        UIm:RegisterLargeTarget(frame.button3)
    end

    frame.button1:SetScript("OnClick", function()
        local def, name, data = frame.def, frame.currentName, frame.data
        if def and def.OnAccept then
            local ok, err = pcall(def.OnAccept, frame, data)
            if not ok and GRIPEMS.Debug then
                GRIPEMS:Debug("Popup OnAccept error:", name, err)
            end
        end
        POP:Hide(name)
    end)

    frame.button2:SetScript("OnClick", function()
        local def, name, data = frame.def, frame.currentName, frame.data
        if def and def.OnCancel then
            local ok, err = pcall(def.OnCancel, frame, data)
            if not ok and GRIPEMS.Debug then
                GRIPEMS:Debug("Popup OnCancel error:", name, err)
            end
        end
        POP:Hide(name)
    end)

    frame.button3:SetScript("OnClick", function()
        local def, name, data = frame.def, frame.currentName, frame.data
        if def and def.OnAlt then
            local ok, err = pcall(def.OnAlt, frame, data)
            if not ok and GRIPEMS.Debug then
                GRIPEMS:Debug("Popup OnAlt error:", name, err)
            end
        end
        POP:Hide(name)
    end)

    -- ESC handling on the frame itself when no edit box has focus.
    frame:EnableKeyboard(true)
    SafeSetPropagate(frame, true)
    frame:SetScript("OnKeyDown", function(self, key)
        if key == "ESCAPE" and self.def and self.def.hideOnEscape ~= false then
            SafeSetPropagate(self, false)
            local def, name, data = self.def, self.currentName, self.data
            if def and def.OnCancel then
                local ok, err = pcall(def.OnCancel, self, data)
                if not ok and GRIPEMS.Debug then
                    GRIPEMS:Debug("Popup ESC OnCancel error:", name, err)
                end
            end
            POP:Hide(name)
        elseif (key == "TAB" or key == "SPACE" or key == "ENTER") and not InCombatLockdown() and GRIPEMS.Focus then
            SafeSetPropagate(self, false)
            if key == "TAB" then
                GRIPEMS.Focus:Cycle(IsShiftKeyDown() and -1 or 1)
            else
                GRIPEMS.Focus:Activate()
            end
        else
            SafeSetPropagate(self, true)
        end
    end)

    return frame
end

----------------------------------------------------------------
-- Configuration helper -- applies a definition to the shared frame
----------------------------------------------------------------

local function ConfigureFrame(frame, name, def, text1, text2, data)
    frame.currentName = name
    frame.def = def
    frame.data = data

    -- Body text (sprintf if args provided)
    local displayText = def.text or ""
    if text1 ~= nil then
        local ok, formatted = pcall(string.format, displayText, text1, text2 or "")
        if ok then
            displayText = formatted
        end
    end
    frame.Body:SetText(displayText)

    -- Edit box visibility + width
    if def.hasEditBox then
        frame.EditBox:SetWidth(def.editBoxWidth or 200)
        if def.maxLetters then
            frame.EditBox:SetMaxLetters(def.maxLetters)
        else
            frame.EditBox:SetMaxLetters(0)
        end
        frame.EditBox:SetText("")
        frame.EditBox:Show()
    else
        frame.EditBox:Hide()
    end

    -- Buttons
    frame.button1:Hide()
    frame.button2:Hide()
    frame.button3:Hide()
    frame.button1:ClearAllPoints()
    frame.button2:ClearAllPoints()
    frame.button3:ClearAllPoints()

    local hasB1 = def.button1 and def.button1 ~= ""
    local hasB2 = def.button2 and def.button2 ~= ""
    local hasB3 = def.button3 and def.button3 ~= ""

    if hasB1 then
        frame.button1:SetText(def.button1)
        frame.button1:Show()
    end
    if hasB2 then
        frame.button2:SetText(def.button2)
        frame.button2:Show()
    end
    if hasB3 then
        frame.button3:SetText(def.button3)
        frame.button3:Show()
    end

    -- Layout buttons across the bottom.
    -- 2-button: button1 left, button2 right.
    -- 3-button: button1 left, button3 center, button2 right.
    -- 1-button: button1 centered.
    if hasB3 and hasB1 and hasB2 then
        frame.button1:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 20, 16)
        frame.button3:SetPoint("BOTTOM", frame, "BOTTOM", 0, 16)
        frame.button2:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -20, 16)
    elseif hasB1 and hasB2 then
        frame.button1:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 50, 16)
        frame.button2:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -50, 16)
    elseif hasB1 then
        frame.button1:SetPoint("BOTTOM", frame, "BOTTOM", 0, 16)
    end

    -- Dynamic frame height: body text + edit box (if any) + button strip.
    -- GetStringHeight returns 0 until the next frame draw if SetText was
    -- called this same tick, so fall back to a sensible minimum.
    local bodyHeight = frame.Body:GetStringHeight()
    if not bodyHeight or bodyHeight < 32 then
        bodyHeight = 32
    end
    local editBoxArea = def.hasEditBox and 36 or 0
    local buttonArea = 50
    local topPadding = 24
    local bottomPadding = 16
    local total = topPadding + bodyHeight + editBoxArea + buttonArea + bottomPadding
    if total < 160 then
        total = 160
    end
    frame:SetHeight(total)
end

----------------------------------------------------------------
-- Public API
----------------------------------------------------------------

function POP:Define(name, def)
    if type(name) ~= "string" or type(def) ~= "table" then
        return
    end
    definitions[name] = def
end

function POP:GetDef(name)
    return definitions[name]
end

function POP:Show(name, text1, text2, data)
    local def = definitions[name]
    if not def then
        if GRIPEMS.Debug then
            GRIPEMS:Debug("Popup:Show called for undefined popup:", tostring(name))
        end
        return false
    end
    if not sharedFrame then
        sharedFrame = CreatePopupFrame()
    end
    ConfigureFrame(sharedFrame, name, def, text1, text2, data)
    sharedFrame:Show()
    if def.hasEditBox then
        sharedFrame.EditBox:SetFocus()
    end
    if def.OnShow then
        local ok, err = pcall(def.OnShow, sharedFrame)
        if not ok and GRIPEMS.Debug then
            GRIPEMS:Debug("Popup OnShow error:", name, err)
        end
    end
    local Focus = GRIPEMS.Focus
    if Focus and Focus.PushContext then
        if sharedFrame._focusContextPushed and Focus.PopContext then
            pcall(Focus.PopContext, Focus, "GRIPEMSPopup")
        end
        local targets = {}
        if sharedFrame.EditBox:IsShown() then
            targets[#targets + 1] = sharedFrame.EditBox
        end
        if sharedFrame.button1:IsShown() then
            targets[#targets + 1] = sharedFrame.button1
        end
        if sharedFrame.button3:IsShown() then
            targets[#targets + 1] = sharedFrame.button3
        end
        if sharedFrame.button2:IsShown() then
            targets[#targets + 1] = sharedFrame.button2
        end
        sharedFrame._focusContextPushed = true
        Focus:PushContext("GRIPEMSPopup", targets, {
            onActivate = function(w)
                if w == sharedFrame.EditBox then
                    w:SetFocus()
                elseif w.Click then
                    w:Click()
                end
            end,
        })
    end
    return sharedFrame
end

function POP:Hide(name)
    if not sharedFrame then
        return
    end
    if name and sharedFrame.currentName ~= name then
        return
    end
    if not sharedFrame:IsShown() then
        return
    end
    local def, currentName = sharedFrame.def, sharedFrame.currentName
    sharedFrame:Hide()
    sharedFrame.EditBox:ClearFocus()
    sharedFrame.currentName = nil
    sharedFrame.def = nil
    sharedFrame.data = nil
    if sharedFrame._focusContextPushed then
        sharedFrame._focusContextPushed = nil
        local Focus = GRIPEMS.Focus
        if Focus and Focus.PopContext then
            pcall(Focus.PopContext, Focus, "GRIPEMSPopup")
        end
    end
    if def and def.OnHide then
        local ok, err = pcall(def.OnHide, sharedFrame)
        if not ok and GRIPEMS.Debug then
            GRIPEMS:Debug("Popup OnHide error:", currentName, err)
        end
    end
end

function POP:IsShown(name)
    if not sharedFrame or not sharedFrame:IsShown() then
        return false
    end
    if name == nil then
        return true
    end
    return sharedFrame.currentName == name
end
