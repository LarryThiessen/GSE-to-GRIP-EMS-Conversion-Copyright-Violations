-- GRIP-EMS: Test spec for the custom modal popup keyboard/focus contract
--
-- Created:    2026-06-28
-- Updated:    2026-08-17
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
--
-- Registers 3 tests under category "popup" for /gems test popup. Covers the
-- GRIPEMS.Popup (Core/Popup.lua) keyboard/focus contract the G8 accessibility
-- audit needs verified for the CVar Health onboarding popup (G8-AUDIT-15) and
-- the Reset-to-Defaults confirm popup (G8-AUDIT-21). Both popups migrated to
-- the shared GRIPEMS.Popup frame, so the keyboard pass is now EMS-owned and
-- assertable here instead of being Blizzard StaticPopup chrome.
--
-- Asserted (the mechanical keyboard pass):
--   - Show pushes the "GRIPEMSPopup" focus context with the visible buttons
--     as targets; Hide pops it.
--   - TAB cycles focus through the buttons (frame OnKeyDown -> Focus:Cycle).
--   - A bare ENTER with nothing focused does NOT accept (no accidental
--     destructive accept); ENTER activates only a deliberately-focused button.
--   - ESC dismisses through OnCancel.
--   - The two real popups carry the expected button shape.
--
-- Out of scope (cannot be asserted by a test): the subjective Simplified Mode
-- feel of the onboarding surprise-modal and the all-or-nothing reset accept,
-- and pixel-level focus-ring rendering. Those stay a human call on a live run.

local ADDON_NAME, GRIPEMS = ...
local TS = GRIPEMS.TestSuite
if not TS then
    return
end

local TEST_POPUP = "_TS_PopupFocus"

local function onKeyDown(frame, key)
    local handler = frame and frame.GetScript and frame:GetScript("OnKeyDown")
    if handler then
        handler(frame, key)
    end
end

TS:Register("Popup: keyboard/focus contract (context, TAB, accept, ESC)", "popup", function(self)
    if InCombatLockdown() then
        self:Skip("requires out of combat (popup key handler gates on combat lockdown)")
        return
    end
    local POP = GRIPEMS.Popup
    local Focus = GRIPEMS.Focus
    if not (POP and POP.Define and POP.Show and POP.Hide and POP.IsShown) then
        self:Fail("GRIPEMS.Popup API missing")
        return
    end
    if not (Focus and Focus.TopContext and Focus.GetCurrent) then
        self:Fail("GRIPEMS.Focus API missing")
        return
    end

    local accepted, cancelled = false, false
    POP:Define(TEST_POPUP, {
        text = "TestSuite popup focus contract",
        button1 = "Accept",
        button2 = "Cancel",
        timeout = 0,
        hideOnEscape = true,
        OnAccept = function()
            accepted = true
        end,
        OnCancel = function()
            cancelled = true
        end,
    })

    local shown = POP:Show(TEST_POPUP)
    local frame = _G.GRIPEMS_PopupFrame
    if not (shown and frame and frame.IsShown and frame:IsShown() and POP:IsShown(TEST_POPUP)) then
        self:Fail("popup did not show")
        POP:Hide(TEST_POPUP)
        return
    end

    -- Show pushed the focus context with both visible buttons as targets.
    local ctx = Focus:TopContext()
    if not (ctx and ctx.name == "GRIPEMSPopup") then
        self:Fail("Show did not push GRIPEMSPopup context; top=" .. tostring(ctx and ctx.name))
        POP:Hide(TEST_POPUP)
        return
    end
    if not (ctx.targets and #ctx.targets == 2) then
        self:Fail("expected 2 focus targets, got " .. tostring(ctx.targets and #ctx.targets))
        POP:Hide(TEST_POPUP)
        return
    end

    -- Bare ENTER with nothing focused must not accept and must not dismiss.
    onKeyDown(frame, "ENTER")
    if accepted then
        self:Fail("bare ENTER with no focused button fired OnAccept")
        POP:Hide(TEST_POPUP)
        return
    end
    if not frame:IsShown() then
        self:Fail("bare ENTER dismissed the popup")
        POP:Hide(TEST_POPUP)
        return
    end

    -- TAB focuses button1; ENTER then activates it deliberately.
    onKeyDown(frame, "TAB")
    if Focus:GetCurrent() ~= frame.button1 then
        self:Fail("first TAB did not focus button1")
        POP:Hide(TEST_POPUP)
        return
    end
    onKeyDown(frame, "ENTER")
    if not accepted then
        self:Fail("ENTER on a focused button did not fire OnAccept")
        POP:Hide(TEST_POPUP)
        return
    end
    if frame:IsShown() then
        self:Fail("accept did not hide the popup")
        POP:Hide(TEST_POPUP)
        return
    end

    -- ESC dismisses through OnCancel and pops the context.
    POP:Show(TEST_POPUP)
    onKeyDown(frame, "ESCAPE")
    if not cancelled then
        self:Fail("ESC did not fire OnCancel")
        POP:Hide(TEST_POPUP)
        return
    end
    if POP:IsShown(TEST_POPUP) then
        self:Fail("ESC did not hide the popup")
        POP:Hide(TEST_POPUP)
        return
    end
    local afterCtx = Focus:TopContext()
    if afterCtx and afterCtx.name == "GRIPEMSPopup" then
        self:Fail("Hide did not pop the GRIPEMSPopup context")
        return
    end

    self:Pass()
end)

TS:Register("Popup: CVar Health onboarding is single-button, ESC-dismissable", "popup", function(self)
    local POP = GRIPEMS.Popup
    if not (POP and POP.GetDef) then
        self:Fail("GRIPEMS.Popup API missing")
        return
    end
    local def = POP:GetDef("GRIPEMS_CVAR_HEALTH_ONBOARDING")
    if not def then
        self:Skip("open /gems options then CVar Health once to define it, then re-run /gems test popup")
        return
    end
    if not def.button1 then
        self:Fail("onboarding popup has no primary button")
        return
    end
    if def.button2 then
        self:Fail("onboarding popup should be single-button; found button2")
        return
    end
    if def.hideOnEscape == false then
        self:Fail("onboarding popup is not ESC-dismissable")
        return
    end
    if type(def.OnAccept) ~= "function" then
        self:Fail("onboarding popup has no OnAccept")
        return
    end
    self:Pass()
end)

TS:Register("Popup: reset-to-defaults confirm is two-button with deliberate accept", "popup", function(self)
    local POP = GRIPEMS.Popup
    if not (POP and POP.GetDef) then
        self:Fail("GRIPEMS.Popup API missing")
        return
    end
    local def = POP:GetDef("GRIPEMS_CVAR_RESET_DEFAULTS_CONFIRM")
    if not def then
        self:Skip("open /gems options then CVar Health once to define it, then re-run /gems test popup")
        return
    end
    if not (def.button1 and def.button2) then
        self:Fail("reset-confirm popup must have two buttons (YES/NO)")
        return
    end
    if def.hideOnEscape == false then
        self:Fail("reset-confirm popup is not ESC-cancelable")
        return
    end
    if type(def.OnAccept) ~= "function" then
        self:Fail("reset-confirm popup has no OnAccept")
        return
    end
    -- Deliberately never Shows or accepts this popup: OnAccept runs a
    -- destructive CVar reset. The shared no-bare-ENTER contract is proven by
    -- the first test against the same frame.
    self:Pass()
end)
