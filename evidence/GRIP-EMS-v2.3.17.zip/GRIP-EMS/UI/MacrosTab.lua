-- GRIP-EMS: MacrosTab
-- Created: 2026-03-19
-- Updated: 2026-06-24
-- Patch: 12.0.7.68275 Midnight (Retail LIVE)

-- GRIP-EMS: Macros Tab
-- Macro stub management panel with info, slot usage, and orphan cleanup

local ADDON_NAME, GRIPEMS = ...
local UI = GRIPEMS.UI
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

-- Upvalue accessor for Defaults
local function D()
    return GRIPEMS.Defaults
end

GRIPEMS.MacrosTab = {}
local MT = GRIPEMS.MacrosTab

-- Runtime state
MT.currentSeqName = nil

-- v2.2.0 L87 EMS-MACRO-DEPS-NATIVE-SEQUENCE-TAGGING: set of macro names the
-- author has tagged as dependencies of the current sequence. Keyed by macro
-- name. Populated from MetaData.Dependencies.Macros on LoadSequence; written
-- back to that field on SE:SaveSequence via MT:GetMacroDeps().
MT.checkedMacros = {}

---------------------------------------------------------------------------
-- Initialization
---------------------------------------------------------------------------

--- Build the macros tab UI inside the given parent frame (content area).
--- @param parentFrame Frame The content area that hosts tab content
function MT:Init(parentFrame)
    if not parentFrame then
        return
    end
    local C = UI.Colors

    MT.container = parentFrame

    local frame = CreateFrame("Frame", nil, parentFrame)
    frame:SetAllPoints(parentFrame)
    frame:Hide()
    MT.frame = frame
    -- Phase C: expose this tab root as the mountable "macros" panel.
    if GRIPEMS.RegisterMountablePanel then
        GRIPEMS:RegisterMountablePanel("macros", MT.frame)
    end

    local yOff = -8

    -----------------------------------------------------------------------
    -- A) Stub Info for Current Sequence
    -----------------------------------------------------------------------
    local stubLabel = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(stubLabel, 10)
    stubLabel:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, yOff)
    stubLabel:SetText(L["GEMS_UI_MACRO_STUB_SECTION"])
    stubLabel:SetTextColor(C.textSecondary:GetRGBA())

    -- Stub icon
    local stubIcon = frame:CreateTexture(nil, "ARTWORK")
    stubIcon:SetSize(20, 20)
    stubIcon:SetPoint("TOPLEFT", stubLabel, "BOTTOMLEFT", 0, -4)
    stubIcon:Hide()
    MT.stubIcon = stubIcon

    -- Stub info text
    local stubInfo = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(stubInfo, 11)
    stubInfo:SetPoint("LEFT", stubIcon, "RIGHT", 6, 0)
    stubInfo:SetText(L["GEMS_UI_STUB_NONE"])
    stubInfo:SetTextColor(C.textMuted:GetRGBA())
    MT.stubInfo = stubInfo

    yOff = yOff - 14 - 4 - 20 - 12

    -----------------------------------------------------------------------
    -- B) Slot Usage
    -----------------------------------------------------------------------
    local slotInfo = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(slotInfo, 11)
    slotInfo:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, yOff)
    slotInfo:SetText("")
    slotInfo:SetTextColor(C.textSecondary:GetRGBA())
    MT.slotInfo = slotInfo

    yOff = yOff - 18

    -----------------------------------------------------------------------
    -- C) Action Buttons
    -----------------------------------------------------------------------
    local btnRow = CreateFrame("Frame", nil, frame)
    btnRow:SetHeight(D().KEY_CAPTURE_BUTTON_HEIGHT + 4)
    btnRow:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, yOff)
    btnRow:SetPoint("RIGHT", frame, "RIGHT", -8, 0)

    -- Refresh button
    local refreshBtn = UI:CreateButton(btnRow, L["GEMS_UI_REFRESH_STUBS"], 80, D().KEY_CAPTURE_BUTTON_HEIGHT)
    refreshBtn:SetPoint("LEFT", btnRow, "LEFT", 0, 0)
    refreshBtn:SetScript("OnClick", function()
        local MM = GRIPEMS.MacroManager
        if MM then
            MM:ScanExisting()
            MT:RefreshDisplay()
        end
    end)
    refreshBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.bgRowHover:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
        UI:ShowTooltip(self, L["GEMS_UI_REFRESH_STUBS"], L["GEMS_UI_REFRESH_STUBS_DESC"])
    end)
    refreshBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
        UI:HideTooltip()
    end)

    -- Clean Orphans button
    local cleanBtn = UI:CreateButton(btnRow, L["GEMS_UI_CLEAN_ORPHANS"], 110, D().KEY_CAPTURE_BUTTON_HEIGHT)
    cleanBtn:SetPoint("LEFT", refreshBtn, "RIGHT", 4, 0)
    cleanBtn:SetScript("OnClick", function()
        MT:CleanOrphans()
    end)
    cleanBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.bgRowHover:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
        UI:ShowTooltip(self, L["GEMS_UI_CLEAN_ORPHANS"], L["GEMS_UI_CLEAN_ORPHANS_DESC"])
    end)
    cleanBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
        UI:HideTooltip()
    end)

    yOff = yOff - D().KEY_CAPTURE_BUTTON_HEIGHT - 12

    -----------------------------------------------------------------------
    -- D) Stub List
    -----------------------------------------------------------------------
    local listHeader = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(listHeader, 10)
    listHeader:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, yOff)
    listHeader:SetText("")
    listHeader:SetTextColor(C.textSecondary:GetRGBA())
    MT.listHeader = listHeader

    -- Container for stub rows
    local listContainer = CreateFrame("Frame", nil, frame)
    listContainer:SetPoint("TOPLEFT", listHeader, "BOTTOMLEFT", 0, -4)
    listContainer:SetPoint("RIGHT", frame, "RIGHT", -8, 0)
    listContainer:SetPoint("BOTTOM", frame, "BOTTOM", 0, 4)
    MT.listContainer = listContainer

    MT.stubRows = {}

    -----------------------------------------------------------------------
    -- D-bis) Macro Dependencies (v2.2.0 L87 EMS-MACRO-DEPS-NATIVE-SEQUENCE-TAGGING)
    -- Author-tagged set of macros this sequence uses. Tags persist in
    -- entry.data.MetaData.Dependencies.Macros and are read by the export-
    -- side auto-include path (GE.ResolveMacroDeps in ExportPreview.lua).
    -----------------------------------------------------------------------
    -- Fixed-height container at the bottom; listContainer is reanchored
    -- above to share remaining vertical space.
    local DEPS_PANEL_HEIGHT = 220 -- header + hint + ~8 visible rows + padding

    local depsContainer = CreateFrame("Frame", nil, frame)
    depsContainer:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 8, 4)
    depsContainer:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -8, 4)
    depsContainer:SetHeight(DEPS_PANEL_HEIGHT)
    MT.depsContainer = depsContainer

    local depsSectionHeader = depsContainer:CreateFontString(nil, "OVERLAY")
    UI:SetFont(depsSectionHeader, 10)
    depsSectionHeader:SetPoint("TOPLEFT", depsContainer, "TOPLEFT", 0, 0)
    depsSectionHeader:SetText(L["GEMS_UI_MACRO_DEPS_SECTION"])
    depsSectionHeader:SetTextColor(C.textSecondary:GetRGBA())
    MT.depsSectionHeader = depsSectionHeader

    local depsHint = depsContainer:CreateFontString(nil, "OVERLAY")
    UI:SetFont(depsHint, 9)
    depsHint:SetPoint("TOPLEFT", depsSectionHeader, "BOTTOMLEFT", 0, -2)
    depsHint:SetText(L["GEMS_UI_MACRO_DEPS_HINT"])
    depsHint:SetTextColor(C.textMuted:GetRGBA())
    MT.depsHint = depsHint

    local depsScrollBox = CreateFrame("Frame", nil, depsContainer, "WowScrollBoxList")
    depsScrollBox:SetPoint("TOPLEFT", depsHint, "BOTTOMLEFT", 0, -4)
    depsScrollBox:SetPoint("BOTTOMRIGHT", depsContainer, "BOTTOMRIGHT", -18, 0)
    MT.depsScrollBox = depsScrollBox

    local depsScrollBar = CreateFrame("EventFrame", nil, depsContainer, "MinimalScrollBar")
    depsScrollBar:SetPoint("TOPLEFT", depsScrollBox, "TOPRIGHT", 2, 0)
    depsScrollBar:SetPoint("BOTTOMLEFT", depsScrollBox, "BOTTOMRIGHT", 2, 0)
    MT.depsScrollBar = depsScrollBar

    local depsScrollView = CreateScrollBoxListLinearView()
    depsScrollView:SetElementExtent(D().STUB_ROW_HEIGHT + 2)

    depsScrollView:SetElementInitializer("Button", function(row, rowData)
        MT:InitDepRow(row, rowData)
    end)

    ScrollUtil.InitScrollBoxListWithScrollBar(depsScrollBox, depsScrollBar, depsScrollView)

    local depsDataProvider = CreateDataProvider()
    depsScrollBox:SetDataProvider(depsDataProvider)
    MT.depsDataProvider = depsDataProvider

    local depsEmptyLabel = depsContainer:CreateFontString(nil, "OVERLAY")
    UI:SetFont(depsEmptyLabel, 10)
    depsEmptyLabel:SetPoint("CENTER", depsScrollBox, "CENTER", 0, 0)
    depsEmptyLabel:SetText(L["GEMS_UI_MACRO_DEPS_EMPTY"])
    depsEmptyLabel:SetTextColor(C.textMuted:GetRGBA())
    depsEmptyLabel:Hide()
    MT.depsEmptyLabel = depsEmptyLabel

    -- Reanchor listContainer so its bottom sits above the deps section
    listContainer:ClearAllPoints()
    listContainer:SetPoint("TOPLEFT", listHeader, "BOTTOMLEFT", 0, -4)
    listContainer:SetPoint("RIGHT", frame, "RIGHT", -8, 0)
    listContainer:SetPoint("BOTTOM", depsContainer, "TOP", 0, 8)

    -- Register for sequence change callbacks so stub list auto-refreshes
    if GRIPEMS.RegisterCallback then
        GRIPEMS.RegisterCallback(MT, "SEQUENCE_CREATED", "OnSequenceChanged")
        GRIPEMS.RegisterCallback(MT, "SEQUENCE_DELETED", "OnSequenceChanged")
        GRIPEMS.RegisterCallback(MT, "SEQUENCE_UPDATED", "OnSequenceChanged")
    end

    -- v2.2.0 POLISH-2: refresh the dep picker when the player creates/
    -- edits/deletes a macro via /macro while the tab is visible. Guard
    -- on frame:IsShown so we do not rebuild the data provider when the
    -- tab is hidden -- LoadSequence/Show will refresh on next open.
    local macroEventFrame = _G["GRIPEMS_MacrosTabMacroEvent"] or CreateFrame("Frame", "GRIPEMS_MacrosTabMacroEvent")
    macroEventFrame:UnregisterAllEvents()
    macroEventFrame:RegisterEvent("UPDATE_MACROS")
    macroEventFrame:SetScript("OnEvent", function()
        if MT.frame and MT.frame:IsShown() then
            MT:RefreshMacroDepsList()
        end
    end)
    MT.macroEventFrame = macroEventFrame
end

--- Auto-refresh when sequences change (callback handler).
function MT:OnSequenceChanged(event, name, data)
    if MT.frame and MT.frame:IsShown() then
        MT:RefreshDisplay()
    end
end

---------------------------------------------------------------------------
-- Orphan cleanup
---------------------------------------------------------------------------

--- Find and delete orphan macro stubs (stubs for sequences that no longer exist).
function MT:CleanOrphans()
    local MM = GRIPEMS.MacroManager
    local engine = GRIPEMS.Engine
    if not MM or not engine then
        return
    end

    -- Find orphans
    local orphans = {}
    for seqName, _ in pairs(MM.stubs) do
        if not engine.sequences[seqName] then
            orphans[#orphans + 1] = seqName
        end
    end

    if #orphans == 0 then
        GRIPEMS:Print(L["GEMS_UI_NO_ORPHANS"])
        return
    end

    -- Show confirmation dialog
    GRIPEMS.Popup:Define("GRIPEMS_CLEAN_ORPHANS", {
        text = string.format(L["GEMS_UI_CLEAN_CONFIRM"], #orphans),
        button1 = ACCEPT,
        button2 = CANCEL,
        OnAccept = function()
            local count = 0
            for _, seqName in ipairs(orphans) do
                MM:DeleteStub(seqName)
                count = count + 1
            end
            -- Rescan to rebuild accurate slot indices after batch deletion
            MM:ScanExisting()
            GRIPEMS:Print(string.format(L["GEMS_UI_ORPHANS_CLEANED"], count))
            MT:RefreshDisplay()
        end,
        timeout = 0,
        hideOnEscape = true,
    })
    GRIPEMS.Popup:Show("GRIPEMS_CLEAN_ORPHANS")
end

---------------------------------------------------------------------------
-- Display refresh
---------------------------------------------------------------------------

--- Refresh the entire macros tab display.
function MT:RefreshDisplay()
    if not MT.frame then
        return
    end
    local C = UI.Colors
    local MM = GRIPEMS.MacroManager

    -- Stub info for current sequence
    if MT.currentSeqName and MM and MM.stubs[MT.currentSeqName] then
        local slotId = MM.stubs[MT.currentSeqName]
        local macroName, macroIcon = GetMacroInfo(slotId)
        if macroName then
            MT.stubInfo:SetText(string.format(L["GEMS_UI_STUB_INFO"], macroName, slotId))
            MT.stubInfo:SetTextColor(C.textPrimary:GetRGBA())
            if macroIcon then
                MT.stubIcon:SetTexture(macroIcon)
                MT.stubIcon:Show()
            end
        else
            MT.stubInfo:SetText(L["GEMS_UI_STUB_NONE"])
            MT.stubInfo:SetTextColor(C.textMuted:GetRGBA())
            MT.stubIcon:Hide()
        end
    else
        MT.stubInfo:SetText(L["GEMS_UI_STUB_NONE"])
        MT.stubInfo:SetTextColor(C.textMuted:GetRGBA())
        MT.stubIcon:Hide()
    end

    -- Slot usage
    if MT.slotInfo then
        local _, perChar = GetNumMacros()
        local maxSlots = D().MAX_PER_CHAR_MACROS
        MT.slotInfo:SetText(string.format(L["GEMS_UI_SLOTS_USED"], perChar, maxSlots))

        if perChar >= maxSlots then
            MT.slotInfo:SetTextColor(C.textError:GetRGBA())
        elseif perChar >= 14 then
            MT.slotInfo:SetTextColor(C.textWarning:GetRGBA())
        else
            MT.slotInfo:SetTextColor(C.textSuccess:GetRGBA())
        end
    end

    -- Stub list
    MT:RefreshStubList()

    -- v2.2.0 L87: macro dependency picker rows
    MT:RefreshMacroDepsList()
end

--- Refresh the stub list display.
function MT:RefreshStubList()
    if not MT.listContainer then
        return
    end
    local C = UI.Colors
    local MM = GRIPEMS.MacroManager
    local engine = GRIPEMS.Engine

    -- Hide existing rows
    for _, row in ipairs(MT.stubRows) do
        row:Hide()
    end

    if not MM or not next(MM.stubs) then
        if MT.listHeader then
            MT.listHeader:SetText(L["GEMS_UI_NO_STUBS"])
        end
        return
    end

    -- Build sorted list of stubs
    local stubList = {}
    for seqName, slotId in pairs(MM.stubs) do
        stubList[#stubList + 1] = {
            name = seqName,
            slotId = slotId,
            isActive = engine and engine.sequences[seqName] ~= nil,
        }
    end
    table.sort(stubList, function(a, b)
        return a.name < b.name
    end)

    if MT.listHeader then
        MT.listHeader:SetText(string.format(L["GEMS_UI_STUB_LIST_HEADER"], #stubList))
    end

    -- Create/update rows (capped at MACROS_TAB_MAX_STUBS)
    local maxRows = math.min(#stubList, D().MACROS_TAB_MAX_STUBS)
    for i = 1, maxRows do
        local entry = stubList[i]
        local row = MT.stubRows[i]

        if not row then
            row = CreateFrame("Frame", nil, MT.listContainer)
            row:SetHeight(D().STUB_ROW_HEIGHT)

            -- Status dot
            row.dot = row:CreateTexture(nil, "ARTWORK")
            row.dot:SetSize(8, 8)
            row.dot:SetPoint("LEFT", row, "LEFT", 2, 0)
            row.dot:SetColorTexture(0, 1, 0, 1)

            -- Name text
            row.nameText = row:CreateFontString(nil, "OVERLAY")
            UI:SetFont(row.nameText, 10)
            row.nameText:SetPoint("LEFT", row.dot, "RIGHT", 4, 0)
            row.nameText:SetJustifyH("LEFT")

            -- Slot text
            row.slotText = row:CreateFontString(nil, "OVERLAY")
            UI:SetFont(row.slotText, 10)
            row.slotText:SetPoint("RIGHT", row, "RIGHT", -4, 0)
            row.slotText:SetJustifyH("RIGHT")

            MT.stubRows[i] = row
        end

        -- Position
        row:SetPoint("TOPLEFT", MT.listContainer, "TOPLEFT", 0, -(i - 1) * D().STUB_ROW_HEIGHT)
        row:SetPoint("RIGHT", MT.listContainer, "RIGHT", 0, 0)

        -- Content
        row.nameText:SetText(entry.name)
        row.slotText:SetText("slot " .. entry.slotId)

        if entry.isActive then
            row.dot:SetColorTexture(0, 0.8, 0.4, 1) -- green
            row.nameText:SetTextColor(C.textPrimary:GetRGBA())
            row.slotText:SetTextColor(C.textSecondary:GetRGBA())
        else
            row.dot:SetColorTexture(1, 0.267, 0.267, 1) -- red
            row.nameText:SetTextColor(C.textError:GetRGBA())
            row.slotText:SetTextColor(C.textMuted:GetRGBA())
        end

        row:Show()
    end

    -- Overflow indicator if more stubs than max visible rows
    if #stubList > D().MACROS_TAB_MAX_STUBS then
        if not MT.overflowLabel then
            MT.overflowLabel = MT.listContainer:CreateFontString(nil, "OVERLAY")
            UI:SetFont(MT.overflowLabel, 9)
        end
        MT.overflowLabel:SetPoint("TOPLEFT", MT.listContainer, "TOPLEFT", 2, -(maxRows * D().STUB_ROW_HEIGHT) - 4)
        MT.overflowLabel:SetText(string.format(L["GEMS_UI_STUBS_MORE"], #stubList - D().MACROS_TAB_MAX_STUBS))
        MT.overflowLabel:SetTextColor(C.textMuted:GetRGBA())
        MT.overflowLabel:Show()
    elseif MT.overflowLabel then
        MT.overflowLabel:Hide()
    end
end

---------------------------------------------------------------------------
-- Macro dependency picker (v2.2.0 L87 EMS-MACRO-DEPS-NATIVE-SEQUENCE-TAGGING)
---------------------------------------------------------------------------

--- Initialize (or reuse) a ScrollBox dep-picker row. Widgets are lazy-created
--- on first call per row and reused across data-provider rebinds; rowData
--- carries the macro entry { name=string, icon=number, scope="account"|"character" }.
--- @param row Frame ScrollBox-recycled row frame
--- @param rowData table macro entry
function MT:InitDepRow(row, rowData)
    local C = UI.Colors
    if not row._checkBtn then
        row._checkBtn = CreateFrame("CheckButton", nil, row, "UICheckButtonTemplate")
        row._checkBtn:SetSize(14, 14)
        row._checkBtn:SetPoint("LEFT", row, "LEFT", 2, 0)

        row._icon = row:CreateTexture(nil, "ARTWORK")
        row._icon:SetSize(16, 16)
        row._icon:SetPoint("LEFT", row._checkBtn, "RIGHT", 4, 0)

        row._nameText = row:CreateFontString(nil, "OVERLAY")
        UI:SetFont(row._nameText, 10)
        row._nameText:SetPoint("LEFT", row._icon, "RIGHT", 6, 0)
        row._nameText:SetJustifyH("LEFT")

        row._scopeText = row:CreateFontString(nil, "OVERLAY")
        UI:SetFont(row._scopeText, 9)
        row._scopeText:SetPoint("RIGHT", row, "RIGHT", -4, 0)
        row._scopeText:SetJustifyH("RIGHT")

        row:SetHighlightTexture("Interface\\Buttons\\UI-Listbox-Highlight2", "ADD")
    end

    row._icon:SetTexture(rowData.icon)
    row._nameText:SetText(rowData.name)
    row._nameText:SetTextColor(C.textPrimary:GetRGBA())

    if rowData.scope == "account" then
        row._scopeText:SetText(L["GEMS_EXPORT_PICK_MACRO_SCOPE_ACCOUNT"])
    else
        row._scopeText:SetText(L["GEMS_EXPORT_PICK_MACRO_SCOPE_CHARACTER"])
    end
    row._scopeText:SetTextColor(C.textMuted:GetRGBA())

    row._checkBtn:SetChecked(MT.checkedMacros[rowData.name] and true or false)

    local macroName = rowData.name
    row._checkBtn:SetScript("OnClick", function(self)
        MT.checkedMacros[macroName] = self:GetChecked() and true or nil
        local SE = GRIPEMS.SequenceEditor
        if SE and SE.OnMetadataChanged then
            SE:OnMetadataChanged()
        end
    end)
end

--- Refresh the macro dependency row list using GetMacroInfo enumeration.
--- Renders one row per existing macro (account first, then character,
--- alphabetical within scope) with a checkbox bound to MT.checkedMacros.
--- Toggling a checkbox marks the editor dirty via SE:OnMetadataChanged.
function MT:RefreshMacroDepsList()
    if not MT.depsDataProvider then
        return
    end

    local accountBase = D().MAX_ACCOUNT_MACROS
    local perCharMax = D().MAX_PER_CHAR_MACROS

    local macList = {}
    for slot = 1, accountBase do
        local name, icon = GetMacroInfo(slot)
        if name and name ~= "" then
            macList[#macList + 1] = { name = name, icon = icon, slot = slot, scope = "account" }
        end
    end
    for slot = accountBase + 1, accountBase + perCharMax do
        local name, icon = GetMacroInfo(slot)
        if name and name ~= "" then
            macList[#macList + 1] = { name = name, icon = icon, slot = slot, scope = "character" }
        end
    end

    table.sort(macList, function(a, b)
        if a.scope ~= b.scope then
            return a.scope == "account"
        end
        return a.name:lower() < b.name:lower()
    end)

    if MT.depsEmptyLabel then
        if #macList == 0 then
            MT.depsEmptyLabel:Show()
        else
            MT.depsEmptyLabel:Hide()
        end
    end

    MT.depsDataProvider:Flush()
    for _, entry in ipairs(macList) do
        MT.depsDataProvider:Insert(entry)
    end
end

--- Return the author-tagged macro names as a sorted array.
--- Consumed by SE:SaveSequence to persist into MetaData.Dependencies.Macros.
--- @return table Array of macro name strings (sorted, may be empty)
function MT:GetMacroDeps()
    local result = {}
    for name in pairs(MT.checkedMacros) do
        result[#result + 1] = name
    end
    table.sort(result)
    return result
end

---------------------------------------------------------------------------
-- Data flow methods (called by SequenceEditor)
---------------------------------------------------------------------------

--- Load macro data for a sequence.
--- @param name string Sequence name
function MT:LoadSequence(name)
    MT.currentSeqName = name

    -- v2.2.0 L87: hydrate the macro picker check state from the sequence's
    -- existing MetaData.Dependencies.Macros so reopening a tagged sequence
    -- shows the prior selections without further author action.
    MT.checkedMacros = {}
    local engine = GRIPEMS.Engine
    local entry = engine and engine.sequences and engine.sequences[name]
    if entry and entry.data and entry.data.MetaData and entry.data.MetaData.Dependencies then
        local macs = entry.data.MetaData.Dependencies.Macros
        if type(macs) == "table" then
            for _, n in ipairs(macs) do
                MT.checkedMacros[n] = true
            end
        end
    end

    MT:RefreshDisplay()
end

--- Clear the macros tab.
function MT:Clear()
    MT.currentSeqName = nil
    MT.checkedMacros = {}
    for _, row in ipairs(MT.stubRows) do
        row:Hide()
    end
end

--- Show the macros tab.
function MT:Show()
    if MT.frame then
        MT.frame:Show()
    end
    MT:RefreshDisplay()
end

--- Hide the macros tab.
function MT:Hide()
    if MT.frame then
        MT.frame:Hide()
    end
end
