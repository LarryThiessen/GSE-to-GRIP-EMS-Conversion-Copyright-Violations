-- GRIP-EMS: Plugin/Addon Registration API
-- Public API for third-party addons to register sequences with EMS

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS")

GRIPEMS.PluginAPI = {}
local PA = GRIPEMS.PluginAPI

-- Internal storage for registered addons
-- Structure per entry:
-- { name=string, version=string, sequences={}, checksum=string,
--   loaded=false, loadedAt=nil }
PA.registeredAddons = {}

--- Register a third-party addon and its sequences with EMS.
--- Call this from your addon's initialization (after GRIPEMS is available).
--- @param name string Addon/plugin name (must be non-empty)
--- @param version string Version string
--- @param seqNames table Array of sequence name strings to register
--- @param seqTable table Table keyed by sequence names containing sequence data
--- @return boolean success True if registration succeeded
function GRIPEMS.RegisterAddon(name, version, seqNames, seqTable)
    -- Validate inputs
    if type(name) ~= "string" or name == "" then
        GRIPEMS:Print("RegisterAddon: name must be a non-empty string")
        return false
    end
    if type(version) ~= "string" then
        GRIPEMS:Print("RegisterAddon: version must be a string")
        return false
    end
    if type(seqNames) ~= "table" then
        GRIPEMS:Print("RegisterAddon: seqNames must be a table")
        return false
    end
    if type(seqTable) ~= "table" then
        GRIPEMS:Print("RegisterAddon: seqTable must be a table")
        return false
    end

    -- Reject duplicate registration
    if PA.registeredAddons[name] then
        GRIPEMS:Print("RegisterAddon: '" .. name .. "' is already registered")
        return false
    end

    -- Compute simple checksum: sorted seqNames concatenated, length as marker
    local sorted = {}
    for i = 1, #seqNames do
        sorted[i] = seqNames[i]
    end
    table.sort(sorted)
    local concat = table.concat(sorted, "")
    local checksum = tostring(string.len(concat))

    -- Store registration entry
    local entry = {
        name = name,
        version = version,
        sequences = {},
        checksum = checksum,
        loaded = false,
        loadedAt = nil,
    }

    -- Copy sequences from seqTable, stamp each with pluginSource
    for _, seqName in ipairs(seqNames) do
        if seqTable[seqName] then
            local seqData = seqTable[seqName]
            seqData.pluginSource = name
            entry.sequences[seqName] = seqData
        end
    end

    PA.registeredAddons[name] = entry

    -- Notify listeners
    if GRIPEMS.Fire then
        GRIPEMS:Fire("PLUGIN_REGISTERED", name, version)
    end

    GRIPEMS:Print(string.format(L["GEMS_PLUGIN_REGISTERED"], name, version, #seqNames))
    return true
end

--- Load all pending plugin sequences into the Engine.
--- User-created sequences take priority (skipped if name already exists).
--- Called automatically during PLAYER_LOGIN after user sequences are restored.
function GRIPEMS.LoadPluginSequences()
    local Engine = GRIPEMS.Engine
    if not Engine then
        return
    end

    for addonName, addon in pairs(PA.registeredAddons) do
        if not addon.loaded then
            for seqName, seqData in pairs(addon.sequences) do
                if Engine.sequences[seqName] then
                    -- User version takes priority
                    GRIPEMS:Print(string.format(L["GEMS_PLUGIN_SKIP_EXISTS"], addonName, seqName))
                else
                    local ok, err = pcall(Engine.ActivateSequence, Engine, seqName, seqData)
                    if not ok then
                        GRIPEMS:Debug("Plugin ActivateSequence failed for '" .. seqName .. "': " .. tostring(err))
                    end
                end
            end
            addon.loaded = true
            addon.loadedAt = time()
            GRIPEMS:Print(string.format(L["GEMS_PLUGIN_LOADED"], addonName))
        end
    end

    -- Notify listeners
    if GRIPEMS.Fire then
        GRIPEMS:Fire("PLUGIN_SEQUENCES_LOADED")
    end
end

--- Get status information for a registered plugin addon.
--- @param addonName string The addon name to query
--- @return table|nil status Status table or nil if not registered
function GRIPEMS.GetPluginSequenceStatus(addonName)
    local addon = PA.registeredAddons[addonName]
    if not addon then
        return nil
    end

    local Engine = GRIPEMS.Engine
    local sequenceCount = 0
    local activeCount = 0

    for seqName in pairs(addon.sequences) do
        sequenceCount = sequenceCount + 1
        if Engine and Engine.sequences[seqName] then
            activeCount = activeCount + 1
        end
    end

    return {
        name = addon.name,
        version = addon.version,
        checksum = addon.checksum,
        loaded = addon.loaded,
        loadedAt = addon.loadedAt,
        sequenceCount = sequenceCount,
        activeCount = activeCount,
    }
end

--- Get a list of all registered addons for UI display.
--- @return table list Array of { name, version, loaded, sequenceCount }
function GRIPEMS.GetRegisteredAddons()
    local list = {}
    for _, addon in pairs(PA.registeredAddons) do
        local count = 0
        for _ in pairs(addon.sequences) do
            count = count + 1
        end
        list[#list + 1] = {
            name = addon.name,
            version = addon.version,
            loaded = addon.loaded,
            sequenceCount = count,
        }
    end
    return list
end
