-- GRIP-EMS: English Locale (Default)
-- All user-facing strings. L["key"] = true means display text equals the key.

local L = LibStub("AceLocale-3.0"):NewLocale("GRIP-EMS", "enUS", true)
if not L then return end

-- General
L["GRIP - Enhanced Macro Sequencer"] = true

-- Slash command help
L["GEMS_HELP_HEADER"] = "Available commands:"
L["GEMS_HELP_NONE"] = "  /gems - Open main window (or show help if UI not loaded)"
L["GEMS_HELP_HELP"] = "  /gems help - This help message"
L["GEMS_HELP_CREATE"] = "  /gems create [name] - Create a test sequence (default: TestSeq)"
L["GEMS_HELP_DELETE"] = "  /gems delete <name> - Delete a sequence and its macro stub"
L["GEMS_HELP_LIST"] = "  /gems list - List all active sequences"
L["GEMS_HELP_TEST"] = "  /gems test <name> - Advance step manually (debug)"
L["GEMS_HELP_RESET"] = "  /gems reset <name> - Reset sequence to step 1"
L["GEMS_HELP_DEBUG"] = "  /gems debug - Toggle debug mode"
L["GEMS_HELP_STATUS"] = "  /gems status - Show engine status"
L["GEMS_HELP_TESTLOCALE"] = "  /gems testlocale - Run locale translation round-trip test"

-- Slash command responses
L["GEMS_VERSION"] = "|cFF00CC66GRIP|r - Enhanced Macro Sequencer |cFFAAAAAAv%s|r"
L["GEMS_DEBUG_ENABLED"] = "Debug mode |cFF00FF00enabled|r."
L["GEMS_DEBUG_DISABLED"] = "Debug mode |cFFFF4444disabled|r."
L["GEMS_UNKNOWN_CMD"] = "Unknown command '%s'. Type /gems help for available commands."

-- Sequence creation/deletion
L["GEMS_CREATED"] = "Sequence |cFF00FF00'%s'|r created with %d steps (%s)."
L["GEMS_DELETED"] = "Sequence |cFF00FF00'%s'|r deleted."
L["GEMS_ALREADY_EXISTS"] = "Sequence '%s' already exists. Delete it first with /gems delete %s"
L["GEMS_NOT_FOUND"] = "Sequence '%s' not found."
L["GEMS_DELETE_NEED_NAME"] = "Usage: /gems delete <name>"

-- Sequence list
L["GEMS_LIST_HEADER"] = "Active sequences (%d):"
L["GEMS_LIST_ENTRY"] = "  |cFF00FF00%s|r - %d steps, step %d/%d (%s)"
L["GEMS_LIST_EMPTY"] = "No active sequences. Use /gems create to make one."

-- Sequence test/reset
L["GEMS_TEST_NEED_NAME"] = "Usage: /gems test <name>"
L["GEMS_TEST_ADVANCED"] = "|cFF00FF00%s|r: advanced to step %d/%d."
L["GEMS_RESET_NEED_NAME"] = "Usage: /gems reset <name>"
L["GEMS_RESET_DONE"] = "|cFF00FF00%s|r: reset to step 1."

-- Status
L["GEMS_STATUS_HEADER"] = "--- GRIP-EMS Status ---"
L["GEMS_STATUS_SEQUENCES"] = "Active sequences: %d"
L["GEMS_STATUS_MACROS"] = "Macro slots: %d/%d per-character used"
L["GEMS_STATUS_KEYDOWN"] = "ActionButtonUseKeyDown: %s (buttons override: true)"
L["GEMS_STATUS_SQW"] = "SpellQueueWindow: %s ms"
L["GEMS_STATUS_OOC"] = "OOC queue: %d pending"

-- Step function descriptions
L["GEMS_STEPFUNC_SEQUENTIAL_DESC"] = "Cycles through steps in order: 1, 2, 3, ..., N, 1, ..."
L["GEMS_STEPFUNC_RANDOM_DESC"] = "Picks a random step each press"
L["GEMS_STEPFUNC_PRIORITY_DESC"] = "Pre-expanded priority: higher steps appear more often (weighted round-robin)"
L["GEMS_STEPFUNC_REVERSE_PRIORITY_DESC"] = "Reverse priority: lower steps appear more often (inverted frequency)"
L["GEMS_STEPFUNC_REVERSEPRIORITY_DESC"] = "Reverse priority: lower steps appear more often (inverted frequency)"

-- Validation errors
L["GEMS_STEP_TOO_LONG"] = "Step %d exceeds macrotext limit (%d chars, max %d)."
L["GEMS_STEP_NIL"] = "Step %d is nil."
L["GEMS_PRIORITY_TOO_LONG"] = "|cFFFF4444Warning:|r Priority macrotext exceeds limit (%d chars, max %d). This exceeds the practical threshold but has no hard WoW limit."
L["GEMS_ERR_NO_STEPS"] = "Sequence '%s' has no steps."
L["GEMS_ERR_NO_NAME"] = "Sequence name is required."

-- Macro manager
L["GEMS_ERR_NO_MACRO_SLOTS"] = "No available macro slots (%d/%d per-character macros used)."
L["GEMS_ERR_MACRO_CREATE_FAILED"] = "Failed to create macro stub for sequence '%s'."
L["GEMS_MACRO_CREATED"] = "Macro stub '%s' created (slot %d)."
L["GEMS_MACRO_DELETED"] = "Macro stub for '%s' deleted (was slot %d)."
L["GEMS_MACROS_SCANNED"] = "Reclaimed %d existing GRIP-EMS macro stubs."

-- OOC Queue
L["GEMS_OOC_QUEUED"] = "Operation queued for out-of-combat processing."
L["GEMS_OOC_PROCESSED"] = "Processed %d queued operations."

-- Keybind manager
L["GEMS_HELP_BIND"] = "  /gems bind <name> <key> - Bind a key to fire a sequence (e.g. CTRL-F12)"
L["GEMS_HELP_UNBIND"] = "  /gems unbind <name> - Remove keybinding from a sequence"
L["GEMS_HELP_BINDS"] = "  /gems binds - List all keybindings for current spec"
L["GEMS_BIND_SUCCESS"] = "Bound |cFF00FF00'%s'|r to |cFFFFFF00%s|r. Press the key to fire the sequence."
L["GEMS_BIND_NEED_ARGS"] = "Usage: /gems bind <name> <key> (e.g. /gems bind TestSeq CTRL-F12)"
L["GEMS_UNBIND_SUCCESS"] = "Unbound |cFF00FF00'%s'|r."
L["GEMS_UNBIND_NO_BIND"] = "Sequence '%s' has no keybinding."
L["GEMS_UNBIND_NEED_NAME"] = "Usage: /gems unbind <name>"
L["GEMS_BINDS_HEADER"] = "Keybindings (spec %d):"
L["GEMS_BINDS_ENTRY"] = "  |cFFFFFF00%s|r -> |cFF00FF00%s|r"
L["GEMS_BINDS_EMPTY"] = "No keybindings set. Use /gems bind <name> <key>."
L["GEMS_KEYBINDS_LOADED"] = "Loaded %d keybindings for spec %d."
L["GEMS_STATUS_KEYBINDS"] = "Keybindings: %d for current spec"

-- Import/Export
L["GEMS_HELP_IMPORT"] = "  /gems import - Open import window (paste export strings)"
L["GEMS_HELP_EXPORT"] = "  /gems export <name> - Export a sequence as GRIP string"
L["GEMS_IMPORT_SUCCESS"] = "Import successful: %d sequence(s) imported"
L["GEMS_IMPORT_ENTRY"] = "  - '%s' (%d steps)"
L["GEMS_IMPORT_FAILED"] = "Import failed: %s"
L["GEMS_IMPORT_WARNING"] = "Warning: %s"
L["GEMS_IMPORT_USAGE"] = "Usage: /gems import (opens paste window for export strings)"
L["GEMS_EXPORT_USAGE"] = "Usage: /gems export <name>"
L["GEMS_EXPORT_RESULT"] = "Export: %s"
L["GEMS_EXPORT_FAILED"] = "Export failed: %s"
L["GEMS_IMPORT_PASTE_INSTRUCTIONS"] = "Paste an export string below, then click Import."
L["GEMS_IMPORT_PASTE_LABEL"] = "Export String"
L["GEMS_IMPORT_BUTTON"] = "Import"
L["GEMS_IMPORT_CLEAR"] = "Clear"
L["GEMS_IMPORT_SHORT_STRING"] = "Hint: Use /gems import (no args) to open the paste window for long strings."
L["GEMS_IMPORT_USE_FRAME"] = "Tip: The string may have been truncated. Use |cFFFFFF00/gems import|r to open the paste window."
L["No sequence named '%s' found."] = true
L["Step %d exceeds 255-char limit (%d chars), truncated."] = true
L["Unknown import format"] = true
L["Skipped action: %s"] = true
L["Embedded sequence '%s' skipped (not available)"] = true
L["Pause action skipped (not supported)"] = true

-- UI strings (Phase 3)
L["GEMS_HELP_OPEN"] = "  /gems open - Open/close the main window"
L["GEMS_UI_TITLE"] = "GRIP-EMS"
L["GEMS_UI_SELECT_SEQUENCE"] = "Select a sequence to edit"
L["GEMS_UI_SEQUENCE_LIST_PLACEHOLDER"] = "Sequence list loading..."
L["GEMS_UI_NO_SEQUENCES"] = "No sequences found. Create one or import."
L["GEMS_UI_CLOSE"] = "Close"
L["GEMS_UI_CLOSE_DESC"] = "Close the GRIP-EMS window"
L["GEMS_UI_RESIZE"] = "Resize"
L["GEMS_UI_RESIZE_DESC"] = "Drag to resize the window"
L["GEMS_UI_MINIMAP_LEFT"] = "Left-click: Open/Close"
L["GEMS_UI_MINIMAP_RIGHT"] = "Right-click: Quick menu"
L["GEMS_UI_ACTIVE_SEQUENCES"] = "%d active sequence(s)"

-- UI strings (Phase 3A-2): Search
L["GEMS_UI_SEARCH"] = "Search..."
L["GEMS_UI_SEARCH_DESC"] = "Filter sequences by name"

-- UI strings (Phase 3A-2): Buttons
L["GEMS_UI_NEW"] = "New"
L["GEMS_UI_NEW_DESC"] = "Create a new sequence"
L["GEMS_UI_IMPORT_BTN"] = "Import"
L["GEMS_UI_IMPORT_BTN_DESC"] = "Import a sequence from an export string"

-- UI strings (Phase 3A-2): Context menu
L["GEMS_UI_DUPLICATE"] = "Duplicate"
L["GEMS_UI_DELETE"] = "Delete"
L["GEMS_UI_EXPORT_CTX"] = "Export"
L["GEMS_UI_RENAME"] = "Rename"

-- UI strings (Phase 3A-2): Editor header
L["GEMS_UI_SEQ_NAME"] = "Name"
L["GEMS_UI_SEQ_ICON"] = "Icon"
L["GEMS_UI_STEP_FUNCTION"] = "Step Function"
L["GEMS_UI_RESET_COMBAT"] = "Reset on Combat End"
L["GEMS_UI_RESET_COMBAT_DESC"] = "Reset step counter when combat ends"
L["GEMS_UI_RESET_TARGET"] = "Reset on Target Change"
L["GEMS_UI_RESET_TARGET_DESC"] = "Reset step counter when target changes (out of combat only)"
L["GEMS_UI_DESCRIPTION"] = "Description"
L["GEMS_UI_DESCRIPTION_DESC"] = "Optional notes about this sequence"

-- UI strings (Phase 3A-2): Tabs
L["GEMS_UI_TAB_STEPS"] = "Steps"
L["GEMS_UI_TAB_KEYBIND"] = "Keybind"
L["GEMS_UI_TAB_VARIABLES"] = "Variables"
L["GEMS_UI_TAB_RAW"] = "Raw"
L["GEMS_UI_TAB_COMING_SOON"] = "Coming soon"

-- UI strings (Phase 3A-2): Step list
L["GEMS_UI_STEP_NUM"] = "#%d"
L["GEMS_UI_CHAR_COUNT"] = "%d"
L["GEMS_UI_NO_STEPS"] = "No steps defined."
L["GEMS_UI_ADD_STEP_HINT"] = "No steps. Click '+ Add' to create one."

-- UI strings (Phase 3A-2): Dialogs
L["GEMS_UI_NEW_SEQ_TITLE"] = "New Sequence"
L["GEMS_UI_NEW_SEQ_DESC"] = "Enter a name for the new sequence:"
L["GEMS_UI_DELETE_CONFIRM"] = "Are you sure you want to delete '%s'? This cannot be undone."
L["GEMS_UI_DUP_TITLE"] = "Duplicate Sequence"
L["GEMS_UI_DUP_DESC"] = "Enter a name for the duplicate:"
L["GEMS_UI_RENAME_TITLE"] = "Rename Sequence"
L["GEMS_UI_RENAME_DESC"] = "Enter the new name:"
L["GEMS_UI_NAME_EXISTS"] = "A sequence named '%s' already exists."
L["GEMS_UI_NAME_EMPTY"] = "Sequence name cannot be empty."

-- UI strings (Phase 3A-2): Status text in rows
L["GEMS_UI_STEPS_COUNT"] = "%d steps"
L["GEMS_UI_ROW_SUBTITLE"] = "%s | %d steps"
L["GEMS_UI_ACTIVE"] = "Active"
L["GEMS_UI_KEYBIND_NONE"] = "No keybind"

-- UI strings (Phase 3A-2): Sort
L["GEMS_UI_SORT_ALPHA"] = "Sort: A-Z"
L["GEMS_UI_SORT_CLASS"] = "Sort: Class"
L["GEMS_UI_SORT_UPDATED"] = "Sort: Recent"

-- UI strings (Phase 3A-2): Editor misc
L["GEMS_UI_RENAME_HINT"] = "Right-click the sequence in the list to rename"
L["GEMS_UI_ICON_HINT"] = "Click to change icon"
L["GEMS_UI_DUPLICATE_FAILED"] = "Duplicate failed."
L["GEMS_UI_COPY_SUFFIX"] = "_copy"

-- UI strings (Phase 3A-2): Step function labels
L["GEMS_UI_SF_SEQUENTIAL"] = "Sequential"
L["GEMS_UI_SF_RANDOM"] = "Random"
L["GEMS_UI_SF_PRIORITY"] = "Priority"
L["GEMS_UI_SF_REVERSEPRIORITY"] = "Rev. Priority"

-- UI strings (Phase 3B-1): Step editor
L["GEMS_UI_ADD_STEP"] = "+ Add"
L["GEMS_UI_ADD_STEP_DESC"] = "Add a new empty step after the selected step"
L["GEMS_UI_DUP_STEP"] = "Dup"
L["GEMS_UI_DUP_STEP_DESC"] = "Duplicate the selected step"
L["GEMS_UI_MOVE_UP"] = "Up"
L["GEMS_UI_MOVE_UP_DESC"] = "Move the selected step up"
L["GEMS_UI_MOVE_DOWN"] = "Down"
L["GEMS_UI_MOVE_DOWN_DESC"] = "Move the selected step down"
L["GEMS_UI_DEL_STEP"] = "Del"
L["GEMS_UI_DEL_STEP_DESC"] = "Delete the selected step"
L["GEMS_UI_STEP_HEADER"] = "Step %d:"
L["GEMS_UI_SELECT_STEP"] = "Select a step to edit"
L["GEMS_UI_NO_STEPS_ADD"] = "No steps. Click '+ Add' to create one."
L["GEMS_UI_DELETE_STEP_CONFIRM"] = "Delete step %d? This cannot be undone."
L["GEMS_UI_CTX_DUP_STEP"] = "Duplicate Step"
L["GEMS_UI_CTX_MOVE_UP"] = "Move Up"
L["GEMS_UI_CTX_MOVE_DOWN"] = "Move Down"
L["GEMS_UI_CTX_DELETE_STEP"] = "Delete Step"
L["GEMS_UI_EXPORT_BTN_EDITOR"] = "Export"
L["GEMS_UI_EXPORT_BTN_EDITOR_DESC"] = "Export this sequence as a GRIP string"
L["GEMS_UI_NAME_TOOLTIP"] = "Sequence Name"
L["GEMS_UI_NAME_EDIT_HINT"] = "Click to rename. Press Enter to confirm, Escape to cancel."
L["GEMS_UI_SAVE_PROMPT"] = "Save changes to '%s'?"
L["GEMS_UI_SAVE"] = "Save"
L["GEMS_UI_SAVE_BTN_DESC"] = "Save changes to this sequence"
L["GEMS_UI_DISCARD"] = "Discard"
L["GEMS_UI_DISCARD_BTN_DESC"] = "Discard changes and revert to last saved state"

-- Phase 3B-2: Keybind tab
L["GEMS_UI_CURRENT_KEYBIND"] = "Current Keybind"
L["GEMS_UI_KEYBIND_DISPLAY_NONE"] = "None"
L["GEMS_UI_SET_KEYBIND"] = "Set Keybind"
L["GEMS_UI_CHANGE_KEYBIND"] = "Change"
L["GEMS_UI_CLEAR_KEYBIND"] = "Clear"
L["GEMS_UI_PRESS_KEY"] = "Press a key..."
L["GEMS_UI_KEYBIND_HINT"] = "Keybinds are per-spec override bindings. They are temporary and not saved to your WoW keybind settings."
L["GEMS_UI_CAPTURE_HINT"] = "Press any key combination. Escape to cancel."
L["GEMS_UI_CAPTURE_COMBAT"] = "Cannot capture keybinds during combat."
L["GEMS_UI_SPEC_KEYBINDS"] = "Keybinds by Spec"
L["GEMS_UI_CURRENT_SPEC"] = "(current)"
L["GEMS_UI_LOADOUT_COMING_SOON"] = "Per-talent-loadout keybinds: coming soon"

-- Phase 3B-2: Macros tab
L["GEMS_UI_TAB_MACROS"] = "Macros"
L["GEMS_UI_MACRO_STUB_SECTION"] = "Macro Stub"
L["GEMS_UI_STUB_INFO"] = "%s (slot %d)"
L["GEMS_UI_STUB_NONE"] = "No macro stub"
L["GEMS_UI_SLOTS_USED"] = "%d/%d per-character macro slots used"
L["GEMS_UI_REFRESH_STUBS"] = "Refresh"
L["GEMS_UI_REFRESH_STUBS_DESC"] = "Re-scan for existing GRIP-EMS macro stubs"
L["GEMS_UI_CLEAN_ORPHANS"] = "Clean Orphans"
L["GEMS_UI_CLEAN_ORPHANS_DESC"] = "Delete macro stubs for sequences that no longer exist"
L["GEMS_UI_CLEAN_CONFIRM"] = "Delete %d orphan macro stub(s)? This cannot be undone."
L["GEMS_UI_ORPHANS_CLEANED"] = "Cleaned %d orphan macro stub(s)."
L["GEMS_UI_NO_ORPHANS"] = "No orphan stubs found."
L["GEMS_UI_STUB_LIST_HEADER"] = "All Stubs (%d)"
L["GEMS_UI_STUB_ACTIVE"] = "active"
L["GEMS_UI_STUB_ORPHAN"] = "orphan"
L["GEMS_UI_NO_STUBS"] = "No macro stubs found."

-- Phase 3B-2: Priority preview
L["GEMS_UI_PRIORITY_PREVIEW"] = "Priority Preview"
L["GEMS_UI_COMPILED_CHARS"] = "Compiled: %d/%d chars"
L["GEMS_UI_PRIORITY_EMPTY"] = "(no steps to compile)"

-- Phase 3C-1: Spell autocomplete
L["GEMS_UI_AUTOCOMPLETE_HINT"] = "Tab: autocomplete spell name"
L["GEMS_UI_SPELL_CACHE_READY"] = "Spell cache: %d spells indexed."
L["GEMS_UI_NO_SPELL_MATCH"] = "No matching spells found."

-- Phase 3C-2: Icon picker
L["GEMS_UI_ICON_PICKER_TITLE"] = "Choose Icon"
L["GEMS_UI_AUTO_DETECT"] = "Auto-Detect"
L["GEMS_UI_AUTO_DETECT_DESC"] = "Automatically detect icon from the first /cast spell"
L["GEMS_UI_ICON_CURRENT"] = "Current: %s"

-- Context version selection (T2-1)
L["GEMS_CONTEXT_CHANGED"] = "Context changed: %s"
L["GEMS_CONTEXT_COLLAPSED"] = "[+] Context"
L["GEMS_CONTEXT_CURRENT"] = "Current: %s"
L["GEMS_CONTEXT_EXPANDED"] = "[-] Context"
L["GEMS_CONTEXT_NONE_LABEL"] = "None"
L["GEMS_CONTEXT_OVERRIDE_TIP"] = "Assign a version to this content type. None = use default version."
L["GEMS_CONTEXT_RELOAD"] = "Context switch reloaded %d sequence(s)"
L["GEMS_CONTEXT_SOLO"] = "Solo (World)"
L["GEMS_CONTEXT_WORLD"] = "World"

-- Context tab (T2-1b)
L["GEMS_UI_TAB_CONTEXT"] = "Context"
L["GEMS_CONTEXT_DEFAULT_LABEL"] = "Default Version: %d"
L["GEMS_CONTEXT_CURRENT_INFO"] = "Current Context: %s"
L["GEMS_CONTEXT_VIEWING"] = "Assignments for Version %d"
L["GEMS_CONTEXT_NO_VERSIONS"] = "Add a second version to configure context overrides."
L["GEMS_CONTEXT_HINT"] = "Check the content types where this version should be active. Unchecked contexts use the fallback chain, then the default version."
L["GEMS_CONTEXT_CONFLICT_TITLE"] = "Context Conflict"
L["GEMS_CONTEXT_CONFLICT_MSG"] = "%s is currently assigned to Version %d.\nReassign to Version %d?"
L["GEMS_CONTEXT_ASSIGNED_OTHER"] = "(Version %d)"
L["GEMS_CONTEXT_GROUP_RAIDS"] = "Raids"
L["GEMS_CONTEXT_GROUP_DUNGEONS"] = "Dungeons"
L["GEMS_CONTEXT_GROUP_PVP"] = "PvP"
L["GEMS_CONTEXT_GROUP_OTHER"] = "Other"

-- Context migration (T2-3)
L["GEMS_CONTEXT_MIGRATED"] = "%d context override(s) imported"

-- Phase 2B: Migration
L["GEMS_HELP_MIGRATE"] = "  /gems migrate - Migrate sequences from another sequencer"
L["GEMS_UI_MIGRATE_BTN"] = "Migrate"
L["GEMS_UI_MIGRATE_BTN_DESC"] = "Import all sequences from another sequencer"
L["GEMS_MIGRATE_NO_GSE"] = "No compatible sequencer found for migration."
L["GEMS_MIGRATE_GSE_DISABLED"] = "A compatible sequencer was found but is disabled. Enable it in the AddOns list and /reload to migrate."
L["GEMS_MIGRATE_SUCCESS"] = "Migration complete: %d sequences imported, %d skipped."
L["GEMS_MIGRATE_FAILED"] = "Migration failed: %s"
L["GEMS_MIGRATE_CONFIRM"] = "Migrate all sequences from your previous sequencer?\n\nFound %d sequences. Existing sequences with the same name will be skipped."
L["GEMS_DELETE_COMBAT"] = "Cannot delete sequences during combat."
L["GEMS_MIGRATE_COMBAT"] = "Cannot migrate during combat. Try again after combat."
L["GEMS_MIGRATE_EMPTY"] = "No sequences found in source library."
L["GEMS_MIGRATE_SKIPPED"] = "%s (already exists, skipped)"

-- Phase 2C: Export frame
L["GEMS_EXPORT_FRAME_TITLE"] = "GRIP-EMS: Export"
L["GEMS_EXPORT_FRAME_LABEL"] = "Exported: %s"
L["GEMS_EXPORT_FRAME_HINT"] = "Press Ctrl+C to copy, then paste into another player's import window."

-- Phase 3C-3: Variable system
L["GEMS_VAR_EVAL_ERROR"] = "Variable '%s' evaluation failed: %s"
L["GEMS_VAR_INVALID_NAME"] = "Variable name must be alphanumeric (a-z, 0-9, underscore)"
L["GEMS_VAR_NAME_TOO_LONG"] = "Variable name exceeds %d characters"
L["GEMS_VAR_FUNC_TOO_LONG"] = "Variable function exceeds %d characters"
L["GEMS_VAR_NAME_EMPTY"] = "Variable name cannot be empty"
L["GEMS_VAR_NAME_EXISTS"] = "Variable '%s' already exists"
L["GEMS_VAR_DELETED"] = "Variable '%s' deleted"
L["GEMS_VAR_SAVED"] = "Variable '%s' saved"
L["GEMS_VAR_REFS_FOUND"] = "Variable '%s' is referenced by: %s"
L["GEMS_VAR_IMPORT_PAUSE"] = "Pause with variable converted to comment"
L["GEMS_VAR_IMPORTED"] = "Imported %d variable(s)."
L["GEMS_VAR_IMPORT_SKIPPED"] = "Skipped %d variable(s) (already exist)."
L["GEMS_VAR_RECOMPILE"] = "Recompiling '%s' (variable changed)"

-- Phase 3C-3b: Variables Tab UI
L["GEMS_VAR_TAB_EMPTY"] = "No variables defined. Click New to create one."
L["GEMS_VAR_NEW"] = "New Variable"
L["GEMS_VAR_NAME_LABEL"] = "Name"
L["GEMS_VAR_FUNC_LABEL"] = "Function Body"
L["GEMS_VAR_FUNC_PLACEHOLDER"] = "return GetHaste() > 20"
L["GEMS_VAR_EVENTS_LABEL"] = "Events (comma-separated)"
L["GEMS_VAR_EVENTS_PLACEHOLDER"] = "SPELL_CAST_SUCCESS, UNIT_AURA"
L["GEMS_VAR_COMMENTS_LABEL"] = "Comments"
L["GEMS_VAR_DISABLED_LABEL"] = "Disabled"
L["GEMS_VAR_SAVE"] = "Save"
L["GEMS_VAR_TEST"] = "Test"
L["GEMS_VAR_TEST_RESULT"] = "Variable '%s' = %s"
L["GEMS_VAR_TEST_ERROR"] = "Variable '%s' error: %s"
L["GEMS_VAR_VALID"] = "Valid"
L["GEMS_VAR_INVALID"] = "Error: %s"
L["GEMS_VAR_USED_BY"] = "Used by: %s"
L["GEMS_VAR_NOT_USED"] = "Not referenced by any sequence"
L["GEMS_VAR_DELETE_CONFIRM"] = "Delete variable '%s'?"
L["GEMS_VAR_DELETE_REFS_WARN"] = "This variable is used by %d sequence(s). Delete anyway?"
L["GEMS_VAR_RENAME"] = "Rename Variable"
L["GEMS_VAR_AUTOCOMPLETE_HINT"] = "Type ~ then Tab for variable autocomplete"

-- Raw tab
L["GEMS_RAW_TITLE"] = "Raw Data"
L["GEMS_RAW_EDIT"] = "Edit"
L["GEMS_RAW_APPLY"] = "Apply"
L["GEMS_RAW_CANCEL"] = "Cancel"
L["GEMS_RAW_VALID"] = "Valid Lua table"
L["GEMS_RAW_INVALID"] = "Invalid: %s"
L["GEMS_RAW_MISSING_FIELD"] = "Missing required field: %s"
L["GEMS_RAW_APPLIED"] = "Changes applied"
L["GEMS_RAW_NAME_IGNORED"] = "Name change ignored. Use Rename from context menu."
L["GEMS_RAW_NO_SEQUENCE"] = "No sequence selected"
L["GEMS_RAW_READONLY_HINT"] = "Click Edit to modify. Changes are validated before applying."

-- Step action bar (Save + hint)
L["GEMS_STEP_SAVE"] = "Save"
L["GEMS_STEP_SAVE_DESC"] = "Save all step changes to the sequence"
L["GEMS_STEP_UNSAVED_HINT"] = "Unsaved changes"

-- Engine debug
L["GEMS_SEQ_ACTIVATED"] = "Sequence '%s' activated (%d steps)."
L["GEMS_SEQ_DEACTIVATED"] = "Sequence '%s' deactivated."
L["GEMS_STEP_RESET"] = "Sequence '%s' step reset to 1."
L["GEMS_STEP_ADVANCED"] = "Sequence '%s' step advanced to %d/%d."
L["GEMS_COMBAT_RESET"] = "Sequence '%s' reset (combat drop)."
L["GEMS_TARGET_RESET"] = "Sequence '%s' reset (target change)."
L["GEMS_GEAR_RESET"] = "%s: reset on gear change."
L["GEMS_SPEC_RESET"] = "%s: reset on spec change."
L["GEMS_TIMER_RESET"] = "%s: reset after %.1fs idle."
L["GEMS_RESTORED"] = "Restored %d saved sequence(s)."
L["GEMS_KEYBINDS_SUSPENDED"] = "Keybinds suspended: %s"
L["GEMS_KEYBINDS_RESTORED"] = "Keybinds restored: %s"

-- Settings panel (T1-1 + T1-7)
L["GEMS_HELP_SETTINGS"] = "  /gems settings - Open settings panel"
L["GEMS_SETTINGS_HEADER_DESC"] = "Configure GRIP - Enhanced Macro Sequencer behavior and display."
L["GEMS_SETTINGS_GENERAL"] = "General"
L["GEMS_SETTINGS_CLICK_RATE"] = "Click Rate (ms)"
L["GEMS_SETTINGS_CLICK_RATE_DESC"] = "Minimum milliseconds between step advances. Lower = faster rotation. Does not affect spell cast speed, only step cycling. Default: 250ms."
L["GEMS_SETTINGS_OOC_DELAY"] = "OOC Queue Delay (sec)"
L["GEMS_SETTINGS_OOC_DELAY_DESC"] = "Seconds between out-of-combat queue polls. Lower = faster processing of queued operations after combat. Changes take effect after /reload. Default: 7s."
L["GEMS_SETTINGS_RESET_OOC"] = "Reset on Combat End (default)"
L["GEMS_SETTINGS_RESET_OOC_DESC"] = "Default value for 'Reset on Combat End' when creating new sequences. Existing sequences are not affected."
L["GEMS_SETTINGS_UI"] = "Display"
L["GEMS_SETTINGS_HIDE_LOGIN"] = "Hide Login Message"
L["GEMS_SETTINGS_HIDE_LOGIN_DESC"] = "Suppress the 'GRIP-EMS vX.X' message on login."
L["GEMS_SETTINGS_DEBUG"] = "Debug Mode"
L["GEMS_SETTINGS_DEBUG_DESC"] = "Show debug messages in chat. Also toggleable via /gems debug."
L["GEMS_SETTINGS_INFO"] = "Info"
L["GEMS_SETTINGS_VERSION_INFO"] = "GRIP-EMS v%s | %d active sequence(s)"

-- About info (T1-5)
L["GEMS_ABOUT_AUTHOR"] = "Author: Sataana (MrSataana)"
L["GEMS_ABOUT_LINKS"] = "Guide: jesperlive.github.io/grip-ems-guide/\nCurseForge: curseforge.com/wow/addons/grip-enhanced-macro-sequencer\nWago: addons.wago.io/addons/qGZODqNd\nWoWInterface: wowinterface.com/downloads/info27081"
L["GEMS_ABOUT_KEYBINDS"] = "Active keybinds: %d"
L["GEMS_ABOUT_OOC_QUEUE"] = "OOC queue: %d pending"
L["GEMS_ABOUT_GSE_STATUS"] = "Migration source: %s"
L["GEMS_ABOUT_MACRO_SLOTS"] = "Macro slots: %d / %d per-character"
L["GEMS_UI_ACTIVE_SEQUENCES_LABEL"] = "Active sequences"
L["GEMS_UI_CONTEXT_LABEL"] = "Context"
L["GEMS_LOGIN_ACTIVE"] = "|cFF888888  %d active sequence(s)|r"
L["GEMS_UI_SETTINGS_BTN"] = "Settings"
L["GEMS_UI_SETTINGS_BTN_DESC"] = "Open GRIP-EMS settings panel"

-- Migration report (T1-9)
L["GEMS_REPORT_HEADER_MIGRATE"] = "--- GRIP-EMS Migration Report ---"
L["GEMS_REPORT_HEADER_IMPORT"] = "--- GRIP-EMS Import Report ---"
L["GEMS_REPORT_IMPORTED"] = "Imported: %d sequence(s), %d variable(s)"
L["GEMS_REPORT_SKIPPED"] = "Skipped: %d (already exist)"
L["GEMS_REPORT_SEQ_ENTRY"] = "  + %s (%d steps, %s)"
L["GEMS_REPORT_LIMITATIONS"] = "Known limitations:"
L["GEMS_REPORT_VERSIONS_DROPPED"] = "  - %d extra version(s) not imported (only default version supported)"
L["GEMS_REPORT_PAUSES_SKIPPED"] = "  - %d pause action(s) skipped (click rate handles timing)"
L["GEMS_REPORT_EMBEDS_SKIPPED"] = "  - %d embedded sequence ref(s) skipped (not yet supported)"
L["GEMS_REPORT_TRUNCATED"] = "  - %d step(s) exceeded 255 chars and were truncated"
L["GEMS_REPORT_TIP_VERIFY"] = "Tip: Open each migrated sequence and verify steps look correct."
L["GEMS_REPORT_TIP_VERSIONS"] = "Use /gems to open the editor and configure context version overrides."

-- Guide (T1-10)
L["GEMS_GUIDE_TITLE"] = "GRIP-EMS Interactive Guide"
L["GEMS_GUIDE_PATH"] = "Copy this URL and open it in your browser:"
L["GEMS_GUIDE_TIP"] = "Local file: Interface/AddOns/GRIP-EMS/Guide/GRIP-EMS_Guide.html"
L["GEMS_GUIDE_URL"] = "https://jesperlive.github.io/grip-ems-guide/"
L["GEMS_GUIDE_CLICK"] = "|cff4ecca3|HGRIPEMSguide|h[Click here to open GRIP-EMS Guide]|h|r"
L["GEMS_HELP_GUIDE"] = "  /gems guide - GRIP-EMS Interactive Guide"

-- Import preview (T2-4)
L["GEMS_IMPORT_PREVIEW_TITLE"] = "Import Preview"
L["GEMS_IMPORT_PREVIEW_SEQ_HEADER"] = "Sequences (%d)"
L["GEMS_IMPORT_PREVIEW_VAR_HEADER"] = "Variables (%d)"
L["GEMS_IMPORT_PREVIEW_NEW"] = "New"
L["GEMS_IMPORT_PREVIEW_EXISTS"] = "Exists"
L["GEMS_IMPORT_PREVIEW_IMPORT_SELECTED"] = "Import Selected (%d)"
L["GEMS_IMPORT_PREVIEW_CANCEL"] = "Cancel"
L["GEMS_IMPORT_PREVIEW_SELECT_ALL"] = "Select All"
L["GEMS_IMPORT_PREVIEW_DESELECT_ALL"] = "Deselect All"
L["GEMS_IMPORT_PREVIEW_EMPTY"] = "No sequences or variables found in this string."
L["GEMS_IMPORT_PREVIEW_SUMMARY"] = "Imported %d sequence(s), %d variable(s)"
L["GEMS_IMPORT_PREVIEW_BTN"] = "Preview"
L["GEMS_IMPORT_PREVIEW_HEADER"] = "%d sequences, %d variables"
L["GEMS_IMPORT_PREVIEW_NEW_COUNT"] = "%d new"
L["GEMS_IMPORT_PREVIEW_EXISTING_COUNT"] = "%d existing"
L["GEMS_IMPORT_PREVIEW_INFO"] = "%d versions, %d steps"
L["GEMS_IMPORT_PREVIEW_ACTION_SKIP"] = "Skip"
L["GEMS_IMPORT_PREVIEW_ACTION_REPLACE"] = "Replace"
L["GEMS_IMPORT_PREVIEW_ACTION_RENAME"] = "Rename"

-- Advanced Export (T2-12)
L["GEMS_EXPORT_PICK_TITLE"] = "Export Sequences"
L["GEMS_EXPORT_PICK_HEADER"] = "%d sequences, %d variables available"
L["GEMS_EXPORT_PICK_SEQ_HEADER"] = "Sequences (%d)"
L["GEMS_EXPORT_PICK_VAR_HEADER"] = "Variables (%d)"
L["GEMS_EXPORT_PICK_INFO"] = "%d versions, %d steps"
L["GEMS_EXPORT_PICK_VAR_DEPS"] = "(+%d vars)"
L["GEMS_EXPORT_PICK_USED_BY"] = "used by: %s"
L["GEMS_EXPORT_PICK_AUTO"] = "auto"
L["GEMS_EXPORT_PICK_SELECT_ALL"] = "Select All"
L["GEMS_EXPORT_PICK_DESELECT_ALL"] = "Deselect All"
L["GEMS_EXPORT_PICK_EXPORT_SELECTED"] = "Export Selected (%d)"
L["GEMS_EXPORT_PICK_BACK"] = "Back"
L["GEMS_EXPORT_PICK_DISPLAY_HEADER"] = "Exported %d sequences, %d variables"
L["GEMS_EXPORT_PICK_EMBEDDED_WARN"] = "%s uses %s (not selected)"
L["GEMS_EXPORT_PICK_EMPTY"] = "No sequences available to export."
L["GEMS_UI_EXPORT_MULTI"] = "Export Multiple..."
L["GEMS_EXPORTALL_USAGE"] = "Opens the multi-select export window."
L["GEMS_HELP_EXPORTALL"] = "  /gems exportall - Open multi-select export window"

-- Transmission (T2-9)
L["GEMS_HELP_SEND"] = "  /gems send <name> <player> - Send a sequence to another player"
L["GEMS_HELP_ACCEPT"] = "  /gems accept - Accept the most recent incoming sequence"
L["GEMS_SEND_USAGE"] = "Usage: /gems send <name> <player>"
L["GEMS_SEND_SUCCESS"] = "Sent '%s' to %s"
L["GEMS_SEND_FAILED"] = "Send failed: %s"
L["GEMS_SEND_DISABLED"] = "P2P sharing is disabled in settings."
L["GEMS_SEND_NO_SEQ"] = "No sequence named '%s' found."
L["GEMS_RECEIVE_ANNOUNCE"] = "Received sequence from %s. Opening import..."
L["GEMS_RECEIVE_AUTO"] = "Auto-imported '%s' from %s (friend)."
L["GEMS_REQUEST_SENT"] = "Requesting '%s' from %s..."
L["GEMS_REQUEST_FULFILLED"] = "Sent '%s' to %s (requested)."
L["GEMS_VERSION_ANNOUNCE"] = "GRIP-EMS user detected: %s (v%s)"
L["GEMS_ACCEPT_USAGE"] = "No pending sequences to accept."
L["GEMS_UI_SEND_PLAYER"] = "Send to Player"
L["GEMS_UI_SEND_BTN"] = "Send"
L["GEMS_UI_SEND_BTN_DESC"] = "Send this sequence to another player"
L["GEMS_SEND_DIALOG_TEXT"] = "Send '%s' to:"
L["GEMS_SEND_DIALOG_ACCEPT"] = "Send"
L["GEMS_P2P_ENABLED"] = "Enable P2P Sharing"
L["GEMS_P2P_ENABLED_DESC"] = "Allow sending and receiving sequences with other GRIP-EMS users."
L["GEMS_P2P_AUTO_FRIENDS"] = "Auto-Accept from Friends"
L["GEMS_P2P_AUTO_FRIENDS_DESC"] = "Automatically import sequences received from friends without prompting."
L["GEMS_P2P_ANNOUNCE"] = "Announce Received"
L["GEMS_P2P_ANNOUNCE_DESC"] = "Print a chat message when receiving a sequence from another player."
L["GEMS_IMPORT_FROM"] = "Import from %s"

-- Debug window (T1-6)
L["GEMS_HELP_DEBUGWINDOW"] = "  /gems debugwindow - Toggle debug message window"
L["GEMS_DEBUG_WINDOW_TITLE"] = "GRIP-EMS Debug"
L["GEMS_DEBUG_CLEAR"] = "Clear"
L["GEMS_DEBUG_COPY"] = "Copy"
L["GEMS_DEBUG_COPY_HINT"] = "Use /gems export or Ctrl+C from the export frame to copy debug output."
