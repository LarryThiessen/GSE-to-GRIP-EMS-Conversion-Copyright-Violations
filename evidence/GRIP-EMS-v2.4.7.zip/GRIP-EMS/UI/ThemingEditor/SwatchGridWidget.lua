-- GRIP-EMS: Per-Element Theming editor -- custom 8x8 swatch grid widget
--
-- Created:    2026-04-22
-- Updated:    2026-08-17
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
--
-- Registers AceGUI-3.0 widget type "GRIPEMS_SwatchGrid". Drop-in replacement
-- for an AceConfig "select" when referenced via dialogControl. Renders an
-- 8x8 grid of 20x20 color buttons sourced from UI.ThemingEditor.SWATCH_PALETTE.
-- OnValueChanged(idx) fires on click; AceConfigDialog's select set= handler
-- writes the theming override, so this widget never calls Theme.ApplyElement
-- or Theme.ApplyTheme (preserves the Phase B gate).
--
-- Selection highlight is a two-tone ring: outer 1 px black edge at
-- offset -2 from the button, inner 1 px white edge at offset -1.
-- The two edges do not overlap, so no frame-level trickery is needed.
--
-- Palette lookup is LAZY: this file loads before ClassEditor.lua in the
-- .toc, so TE.SWATCH_PALETTE is empty at module load. SetList/OnAcquire
-- read the palette fresh each time.

local Type = "GRIPEMS_SwatchGrid"
local Version = 1

local AceGUI = LibStub and LibStub("AceGUI-3.0", true)
if not AceGUI then
    return
end

local COLS, ROWS, CELL, GAP = 8, 8, 20, 2
local STRIDE = CELL + GAP
-- PAD reserves 2 pixels on every side so the 2-pixel selection
-- highlight on the edge cells stays fully inside the widget frame.
local PAD = 2
local FRAME_W = COLS * CELL + (COLS - 1) * GAP + 2 * PAD -- 178
local FRAME_H = ROWS * CELL + (ROWS - 1) * GAP + 2 * PAD -- 178

local function lookupPalette()
    local g = _G.GRIPEMS
    local u = g and g.UI
    local te = u and u.ThemingEditor
    return te and te.SWATCH_PALETTE or nil
end

local function positionHighlight(widget)
    local inner = widget.highlight
    local outer = widget.highlightOuter
    if not inner and not outer then
        return
    end
    local value = widget.value
    local btn = (type(value) == "number") and widget.buttons[value] or nil
    if not btn then
        if inner then
            inner:Hide()
        end
        if outer then
            outer:Hide()
        end
        return
    end
    if outer then
        outer:ClearAllPoints()
        outer:SetPoint("TOPLEFT", btn, "TOPLEFT", -2, 2)
        outer:SetPoint("BOTTOMRIGHT", btn, "BOTTOMRIGHT", 2, -2)
        outer:Show()
    end
    if inner then
        inner:ClearAllPoints()
        inner:SetPoint("TOPLEFT", btn, "TOPLEFT", -1, 1)
        inner:SetPoint("BOTTOMRIGHT", btn, "BOTTOMRIGHT", 1, -1)
        inner:Show()
    end
end

local methods = {}

function methods:OnAcquire()
    self.value = nil
    self.list = nil
    self.order = nil
    self.disabled = nil
    if self.highlight then
        self.highlight:Hide()
    end
    if self.highlightOuter then
        self.highlightOuter:Hide()
    end
    for i = 1, #self.buttons do
        local b = self.buttons[i]
        b:Enable()
        b.tex:SetColorTexture(0, 0, 0, 0)
        b.label = nil
    end
    if self.labelFS then
        self.labelFS:SetText("")
        self.labelFS:Hide()
    end
end

function methods:OnRelease()
    self.value = nil
    self.list = nil
    self.order = nil
    if self.highlight then
        self.highlight:Hide()
    end
    if self.highlightOuter then
        self.highlightOuter:Hide()
    end
end

function methods:SetValue(value)
    self.value = value
    positionHighlight(self)
end

function methods:SetList(list, order)
    self.list, self.order = list, order
    local palette = lookupPalette() or {}
    for i = 1, #self.buttons do
        local b = self.buttons[i]
        local entry = palette[i]
        if entry and entry.r then
            b.tex:SetColorTexture(entry.r, entry.g, entry.b, entry.a or 1)
        else
            b.tex:SetColorTexture(0, 0, 0, 0)
        end
        local txt
        if list and list[i] then
            txt = tostring(list[i])
        elseif entry and entry.hex then
            txt = entry.hex
        end
        b.label = txt
    end
end

function methods:SetDisabled(disabled)
    self.disabled = disabled
    for i = 1, #self.buttons do
        self.buttons[i]:SetEnabled(not disabled)
    end
end

function methods:SetLabel(text)
    if not self.labelFS then
        return
    end
    if text and text ~= "" then
        self.labelFS:SetText(text)
        self.labelFS:Show()
    else
        self.labelFS:SetText("")
        self.labelFS:Hide()
    end
end

local function Constructor()
    local frame = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
    frame:SetSize(FRAME_W, FRAME_H)

    local widget = {
        type = Type,
        frame = frame,
        buttons = {},
    }
    frame.obj = widget

    local labelFS = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    labelFS:SetPoint("BOTTOMLEFT", frame, "TOPLEFT", 0, 2)
    labelFS:SetText("")
    labelFS:Hide()
    widget.labelFS = labelFS

    local highlightOuter = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    highlightOuter:SetFrameLevel(frame:GetFrameLevel() + 2)
    highlightOuter:SetBackdrop({
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
    })
    highlightOuter:SetBackdropBorderColor(0, 0, 0, 1)
    highlightOuter:Hide()
    widget.highlightOuter = highlightOuter

    local highlight = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    highlight:SetFrameLevel(frame:GetFrameLevel() + 2)
    highlight:SetBackdrop({
        edgeFile = "Interface\\Buttons\\WHITE8X8",
        edgeSize = 1,
    })
    highlight:SetBackdropBorderColor(1, 1, 1, 1)
    highlight:Hide()
    widget.highlight = highlight

    for i = 1, COLS * ROWS do
        local idx = i
        local btn = CreateFrame("Button", nil, frame, "BackdropTemplate")
        btn:SetSize(CELL, CELL)
        local col = (idx - 1) % COLS
        local row = math.floor((idx - 1) / COLS)
        btn:SetPoint("TOPLEFT", frame, "TOPLEFT", PAD + col * STRIDE, -(PAD + row * STRIDE))
        local tex = btn:CreateTexture(nil, "BACKGROUND")
        tex:SetAllPoints(btn)
        tex:SetColorTexture(0, 0, 0, 0)
        btn.tex = tex
        btn:SetScript("OnClick", function()
            widget.value = idx
            positionHighlight(widget)
            widget:Fire("OnValueChanged", idx)
        end)
        btn:SetScript("OnEnter", function(button)
            GameTooltip:SetOwner(button, "ANCHOR_RIGHT")
            if button.label then
                GameTooltip:AddLine(button.label)
            end
            GameTooltip:Show()
        end)
        btn:SetScript("OnLeave", function()
            GameTooltip:Hide()
        end)
        widget.buttons[i] = btn
    end

    for name, fn in pairs(methods) do
        widget[name] = fn
    end

    return AceGUI:RegisterAsWidget(widget)
end

AceGUI:RegisterWidgetType(Type, Constructor, Version)

-- end of UI/ThemingEditor/SwatchGridWidget.lua
