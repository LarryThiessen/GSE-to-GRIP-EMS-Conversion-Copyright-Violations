-- GRIP-EMS: UI Utilities
-- Shared color constants, backdrop definitions, tooltip helpers, font helper, and button factory
--
-- Created:    2025 (pre-stamping; exact date unknown)
-- Updated:    2026-08-17
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)

local ADDON_NAME, GRIPEMS = ...

GRIPEMS.UI = GRIPEMS.UI or {}
local UI = GRIPEMS.UI
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

-- Register Atkinson Hyperlegible with LibSharedMedia-3.0 if present.
-- Atkinson is bundled for dyslexia-friendly readability (Latin scripts only).
do
    local LSM = LibStub and LibStub("LibSharedMedia-3.0", true)
    if LSM then
        local base = "Interface\\AddOns\\GRIP-EMS\\Media\\Fonts\\"
        LSM:Register(LSM.MediaType.FONT, "Atkinson Hyperlegible", base .. "AtkinsonHyperlegible-Regular.ttf")
        LSM:Register(LSM.MediaType.FONT, "Atkinson Hyperlegible Bold", base .. "AtkinsonHyperlegible-Bold.ttf")
        LSM:Register(LSM.MediaType.FONT, "Atkinson Hyperlegible Italic", base .. "AtkinsonHyperlegible-Italic.ttf")
        LSM:Register(
            LSM.MediaType.FONT,
            "Atkinson Hyperlegible BoldItalic",
            base .. "AtkinsonHyperlegible-BoldItalic.ttf"
        )
    end
end

-- Upvalue accessor for Defaults
local function D()
    return GRIPEMS.Defaults
end

---------------------------------------------------------------------------
-- Color palette (dark theme -- see Phase3_UI_Design.md section 8)
-- Phase 2 #9: preset-driven (Default / HighContrast / DeuteranopiaSafe).
-- Consumers cache UI.Colors as an upvalue ("local C = UI.Colors", 83 sites)
-- so SetPalette MUST mutate fields in place via ColorMixin:SetRGBA --
-- never reassign UI.Colors itself or all upvalues silently go stale.
---------------------------------------------------------------------------
UI.Presets = UI.Presets or {}

UI.Presets.Default = {
    bgDeep = { 0.051, 0.051, 0.102, 1 },
    bgMain = { 0.102, 0.102, 0.180, 1 },
    bgPanel = { 0.086, 0.129, 0.243, 1 },
    bgInput = { 0.059, 0.090, 0.161, 1 },
    bgRowHover = { 0.059, 0.204, 0.376, 1 },
    bgRowSelected = { 0.325, 0.204, 0.514, 1 },
    bgButton = { 0.118, 0.176, 0.290, 1 },
    accent = { 0.914, 0.271, 0.376, 1 },
    gripGreen = { 0.000, 0.800, 0.400, 1 },
    textPrimary = { 0.933, 0.933, 1.000, 1 },
    textSecondary = { 0.533, 0.533, 0.667, 1 },
    textMuted = { 0.333, 0.333, 0.467, 1 },
    textWarning = { 1.000, 0.800, 0.000, 1 },
    textError = { 1.000, 0.267, 0.267, 1 },
    textSuccess = { 0.000, 0.800, 0.400, 1 },
    textContextual = { 0.000, 0.700, 1.000, 1 },
    keybindGold = { 1.000, 0.843, 0.000, 1 },
    bgSave = { 0.100, 0.280, 0.150, 1 },
    bgSaveHover = { 0.150, 0.380, 0.200, 1 },
    border = { 0.200, 0.200, 0.333, 1 },
    borderFocus = { 0.333, 0.333, 0.667, 1 },
    focusRing = { 1.000, 0.850, 0.100, 1 },
    scoreGood = { 0.000, 1.000, 0.000, 1 },
    scoreWarn = { 1.000, 1.000, 0.000, 1 },
    scoreBad = { 1.000, 0.000, 0.000, 1 },
    cvarMatch = { 0.000, 1.000, 0.000, 1 },
    cvarMismatchCritical = { 1.000, 0.000, 0.000, 1 },
    cvarMismatchPolish = { 1.000, 1.000, 0.000, 1 },
    cvarUnrecommended = { 0.533, 0.533, 0.533, 1 },
    cvarSqwManaged = { 0.000, 0.800, 1.000, 1 },
    cvarAdvisoryGood = { 0.000, 1.000, 0.000, 1 },
    cvarAdvisoryWarn = { 1.000, 1.000, 0.000, 1 },
    cvarAdvisoryBad = { 1.000, 0.000, 0.000, 1 },
    reloadGateMinimap = { 1.000, 0.850, 0.000, 1 },
    reloadGateSidebar = { 1.000, 0.550, 0.000, 1 },
    cvarChangesDetected = { 1.000, 0.667, 0.000, 1 },
}

UI.Presets.HighContrast = {
    bgDeep = { 0.000, 0.000, 0.000, 1 },
    bgMain = { 0.000, 0.000, 0.000, 1 },
    bgPanel = { 0.050, 0.050, 0.050, 1 },
    bgInput = { 0.000, 0.000, 0.000, 1 },
    bgRowHover = { 0.150, 0.150, 0.150, 1 },
    bgRowSelected = { 0.250, 0.250, 0.250, 1 },
    bgButton = { 0.100, 0.100, 0.100, 1 },
    accent = { 1.000, 1.000, 0.000, 1 },
    gripGreen = { 0.000, 1.000, 0.000, 1 },
    textPrimary = { 1.000, 1.000, 1.000, 1 },
    textSecondary = { 0.850, 0.850, 0.850, 1 },
    textMuted = { 0.700, 0.700, 0.700, 1 },
    textWarning = { 1.000, 1.000, 0.000, 1 },
    textError = { 1.000, 0.300, 0.300, 1 },
    textSuccess = { 0.000, 1.000, 0.000, 1 },
    textContextual = { 0.000, 1.000, 1.000, 1 },
    keybindGold = { 1.000, 1.000, 0.000, 1 },
    bgSave = { 0.000, 0.400, 0.000, 1 },
    bgSaveHover = { 0.000, 0.600, 0.000, 1 },
    border = { 0.700, 0.700, 0.700, 1 },
    borderFocus = { 1.000, 1.000, 1.000, 1 },
    focusRing = { 1.000, 1.000, 1.000, 1 },
    scoreGood = { 0.000, 1.000, 0.000, 1 },
    scoreWarn = { 1.000, 1.000, 0.000, 1 },
    scoreBad = { 1.000, 0.300, 0.300, 1 },
    cvarMatch = { 0.000, 1.000, 0.000, 1 },
    cvarMismatchCritical = { 1.000, 0.300, 0.300, 1 },
    cvarMismatchPolish = { 1.000, 1.000, 0.000, 1 },
    cvarUnrecommended = { 0.700, 0.700, 0.700, 1 },
    cvarSqwManaged = { 0.000, 1.000, 1.000, 1 },
    cvarAdvisoryGood = { 0.000, 1.000, 0.000, 1 },
    cvarAdvisoryWarn = { 1.000, 1.000, 0.000, 1 },
    cvarAdvisoryBad = { 1.000, 0.300, 0.300, 1 },
    reloadGateMinimap = { 1.000, 1.000, 0.000, 1 },
    reloadGateSidebar = { 1.000, 0.700, 0.000, 1 },
    cvarChangesDetected = { 1.000, 0.700, 0.000, 1 },
}

UI.Presets.DeuteranopiaSafe = {
    bgDeep = { 0.051, 0.051, 0.102, 1 },
    bgMain = { 0.102, 0.102, 0.180, 1 },
    bgPanel = { 0.086, 0.129, 0.243, 1 },
    bgInput = { 0.059, 0.090, 0.161, 1 },
    bgRowHover = { 0.059, 0.204, 0.376, 1 },
    bgRowSelected = { 0.325, 0.204, 0.514, 1 },
    bgButton = { 0.118, 0.176, 0.290, 1 },
    accent = { 0.000, 0.447, 0.698, 1 },
    gripGreen = { 0.337, 0.706, 0.914, 1 },
    textPrimary = { 0.933, 0.933, 1.000, 1 },
    textSecondary = { 0.533, 0.533, 0.667, 1 },
    textMuted = { 0.333, 0.333, 0.467, 1 },
    textWarning = { 0.902, 0.624, 0.000, 1 },
    textError = { 0.835, 0.369, 0.000, 1 },
    textSuccess = { 0.337, 0.706, 0.914, 1 },
    textContextual = { 0.400, 0.800, 1.000, 1 },
    keybindGold = { 0.902, 0.624, 0.000, 1 },
    bgSave = { 0.000, 0.200, 0.400, 1 },
    bgSaveHover = { 0.000, 0.300, 0.550, 1 },
    border = { 0.200, 0.200, 0.333, 1 },
    borderFocus = { 0.337, 0.706, 0.914, 1 },
    focusRing = { 0.902, 0.624, 0.000, 1 },
    scoreGood = { 0.337, 0.706, 0.914, 1 },
    scoreWarn = { 0.902, 0.624, 0.000, 1 },
    scoreBad = { 0.835, 0.369, 0.000, 1 },
    cvarMatch = { 0.337, 0.706, 0.914, 1 },
    cvarMismatchCritical = { 0.835, 0.369, 0.000, 1 },
    cvarMismatchPolish = { 0.902, 0.624, 0.000, 1 },
    cvarUnrecommended = { 0.533, 0.533, 0.667, 1 },
    cvarSqwManaged = { 0.000, 0.620, 0.451, 1 },
    cvarAdvisoryGood = { 0.337, 0.706, 0.914, 1 },
    cvarAdvisoryWarn = { 0.902, 0.624, 0.000, 1 },
    cvarAdvisoryBad = { 0.835, 0.369, 0.000, 1 },
    reloadGateMinimap = { 0.902, 0.624, 0.000, 1 },
    reloadGateSidebar = { 0.835, 0.369, 0.000, 1 },
    cvarChangesDetected = { 0.902, 0.624, 0.000, 1 },
}

-- Machado 2009 severity-1.0 matrices for colorblind daltonization (row-major 3x3).
UI._CVD_MATRICES = {
    protan = {
        0.152286,
        1.052583,
        -0.204868,
        0.114503,
        0.786281,
        0.099216,
        -0.003882,
        -0.048116,
        1.051998,
    },
    deutan = {
        0.367322,
        0.860646,
        -0.227968,
        0.280085,
        0.672501,
        0.047413,
        -0.011820,
        0.042940,
        0.968881,
    },
    tritan = {
        1.255528,
        -0.076749,
        -0.178779,
        -0.078411,
        0.930809,
        0.147602,
        0.004733,
        0.691367,
        0.303900,
    },
    -- Achromat uses CCIR 601 luma projection onto (L, L, L) when strength = 1.
    -- Matrix form for consistency with the blending code below.
    achromat = {
        0.299,
        0.587,
        0.114,
        0.299,
        0.587,
        0.114,
        0.299,
        0.587,
        0.114,
    },
}

-- Anomaly variants use severity 0.6 (mid-range of the Machado 2009 partial-
-- deficiency band of 0.5-0.7). Opia variants use severity 1.0 (full
-- deficiency). The user-facing strength slider further scales the blend
-- from identity to the category matrix, so users can tune beyond these
-- anchor points if 0.6 feels too strong or too weak for their condition.
-- Type-to-(category, default_severity). Default severity is used to pre-blend
-- the category matrix toward identity for the "-anomaly" types. The strength
-- slider then further scales from identity to that pre-blended matrix.
UI._CVD_TYPE_MAP = {
    none = nil,
    protanomaly = { cat = "protan", severity = 0.6 },
    protanopia = { cat = "protan", severity = 1.0 },
    deuteranomaly = { cat = "deutan", severity = 0.6 },
    deuteranopia = { cat = "deutan", severity = 1.0 },
    tritanomaly = { cat = "tritan", severity = 0.6 },
    tritanopia = { cat = "tritan", severity = 1.0 },
    achromatomaly = { cat = "achromat", severity = 0.5 },
    achromatopsia = { cat = "achromat", severity = 1.0 },
}

local function clamp01(x)
    if x < 0 then
        return 0
    end
    if x > 1 then
        return 1
    end
    return x
end

-- Linearly blend matrix M toward identity I by (1 - severity).
-- severity == 1.0 returns M. severity == 0.0 returns identity.
local function blendMatrixTowardIdentity(m, severity)
    local s = clamp01(severity)
    local out = {
        s * m[1] + (1 - s) * 1,
        s * m[2] + (1 - s) * 0,
        s * m[3] + (1 - s) * 0,
        s * m[4] + (1 - s) * 0,
        s * m[5] + (1 - s) * 1,
        s * m[6] + (1 - s) * 0,
        s * m[7] + (1 - s) * 0,
        s * m[8] + (1 - s) * 0,
        s * m[9] + (1 - s) * 1,
    }
    return out
end

-- Apply matrix M to (r, g, b) and blend the result with the original
-- by strength. strength == 0 returns the original color. strength == 1
-- returns the fully shifted color. Returned a in [0,1].
local function applyCVDMatrix(r, g, b, m, strength)
    local t = clamp01(strength)
    local mr = m[1] * r + m[2] * g + m[3] * b
    local mg = m[4] * r + m[5] * g + m[6] * b
    local mb = m[7] * r + m[8] * g + m[9] * b
    return clamp01(r + t * (mr - r)), clamp01(g + t * (mg - g)), clamp01(b + t * (mb - b))
end

UI.Colors = {}
for k, rgba in pairs(UI.Presets.Default) do
    UI.Colors[k] = CreateColor(rgba[1], rgba[2], rgba[3], rgba[4])
end

UI._paletteListeners = UI._paletteListeners or {}
UI._themeListeners = UI._themeListeners or {}
UI._backdropBindings = UI._backdropBindings or {}
setmetatable(UI._backdropBindings, { __mode = "k" })
UI._panelRegistry = UI._panelRegistry or { panel = {}, overlay = {} }
UI._largeTargetRegistry = UI._largeTargetRegistry or {}

--- Register a callback fired after UI:SetPalette mutates UI.Colors.
--- @param fn function
function UI:OnPaletteChanged(fn)
    if type(fn) == "function" then
        self._paletteListeners[#self._paletteListeners + 1] = fn
    end
end

--- Return the WoW color escape ("|cAARRGGBB") for a UI.Colors key.
--- Routes through ColorMixin:GenerateHexColor() so palette mutations
--- via UI:SetPalette propagate without re-baking the escape string.
--- Falls back to white when the key is unknown -- safe default that
--- still renders, with the missing-token name visible in nearby
--- text since callers typically concat label data.
--- @param key string Token name in UI.Colors
--- @return string The "|cAARRGGBB" escape (use with "|r" terminator)
function UI:ColorCode(key)
    local c = self.Colors and self.Colors[key]
    if c and c.GenerateHexColor then
        return "|c" .. c:GenerateHexColor()
    end
    return "|cFFFFFFFF"
end

--- Compute the effective RGBA after applying colorblind shift on top of
--- the base preset rgba. Reads accessibility.colorblindType and
--- accessibility.colorblindStrength from the current profile.
--- Returns (r, g, b, a) as four scalars. Safe when settings not loaded --
--- falls back to passthrough.
function UI:ApplyColorblindShift(r, g, b, a)
    local S = GRIPEMS and GRIPEMS.Settings
    if not (S and S.db and S.db.profile and S.db.profile.accessibility) then
        return r, g, b, a
    end
    local A = S.db.profile.accessibility
    local typeKey = A.colorblindType or "none"
    local mapping = UI._CVD_TYPE_MAP[typeKey]
    if not mapping then
        return r, g, b, a
    end
    local strength = tonumber(A.colorblindStrength) or 1.0
    if strength <= 0 then
        return r, g, b, a
    end
    local base = UI._CVD_MATRICES[mapping.cat]
    if not base then
        return r, g, b, a
    end
    local m = blendMatrixTowardIdentity(base, mapping.severity)
    local nr, ng, nb = applyCVDMatrix(r, g, b, m, strength)
    return nr, ng, nb, a
end

--- Apply a named preset by mutating UI.Colors fields in place. Does NOT
--- reassign UI.Colors -- preserves the upvalue cached at all 83 call sites.
--- @param name string Preset key (Default, HighContrast, DeuteranopiaSafe)
function UI:SetPalette(name)
    local preset = UI.Presets[name] or UI.Presets.Default
    for k, rgba in pairs(preset) do
        local r, g, b, a = self:ApplyColorblindShift(rgba[1], rgba[2], rgba[3], rgba[4])
        local c = UI.Colors[k]
        if c then
            c:SetRGBA(r, g, b, a)
        else
            UI.Colors[k] = CreateColor(r, g, b, a)
        end
    end
    for i = 1, #self._paletteListeners do
        pcall(self._paletteListeners[i])
    end
    self:RebindBackdrops()
end

--- Register a callback fired after UI:ApplyTheme updates opacity, alpha, or scale.
--- @param fn function
function UI:OnThemeChanged(fn)
    if type(fn) == "function" then
        self._themeListeners[#self._themeListeners + 1] = fn
    end
end

--- Register a frame with a theming element class (Phase A foundation).
--- Validates the class against UI.ELEMENT_CLASS_SET, stores the class on the
--- frame as _emsElementClass, and appends to the class-to-widgets reverse
--- index so Theme.ApplyElement(class) can fan out.
--- Unknown classes are ignored (safe default -- widget stays unthemed).
--- Idempotent per frame: re-registering the same frame under the same class
--- is a no-op. Re-registering under a different class updates the index.
--- Self-heal: late-registered frames receive theme via Theme.RequestApply at end of function.
--- @param frame Frame The widget to classify
--- @param class string One of UI.ELEMENT_CLASSES
function UI:RegisterElement(frame, class)
    if not frame or type(class) ~= "string" then
        return
    end
    local whitelist = self.ELEMENT_CLASS_SET
    if not (whitelist and whitelist[class]) then
        return
    end
    self._elementClasses = self._elementClasses or {}
    self._classWidgets = self._classWidgets or {}
    local prior = self._elementClasses[frame]
    if prior == class then
        return
    end
    if prior and self._classWidgets[prior] then
        local bucket = self._classWidgets[prior]
        for i = #bucket, 1, -1 do
            if bucket[i] == frame then
                table.remove(bucket, i)
                break
            end
        end
    end
    self._elementClasses[frame] = class
    frame._emsElementClass = class
    -- Snapshot default backdrop for panel.* classes so Theme.applyPanel can
    -- revert a user-textured backdrop to the pre-theming default when
    -- overrides are cleared (Reset widget / ApplyPreset("default") / profile
    -- switch). Set-once; re-registration keeps the original snapshot.
    -- Second-chance snapshot lives in Data/Theme.lua applyPanel for frames
    -- whose backdrop is set after RegisterElement fires.
    if not frame._emsDefaultBackdrop and class:sub(1, 6) == "panel." and frame.GetBackdrop then
        local current = frame:GetBackdrop()
        if type(current) == "table" then
            frame._emsDefaultBackdrop = {
                bgFile = current.bgFile,
                edgeFile = current.edgeFile,
                tile = current.tile,
                tileSize = current.tileSize,
                edgeSize = current.edgeSize,
                insets = current.insets and {
                    left = current.insets.left,
                    right = current.insets.right,
                    top = current.insets.top,
                    bottom = current.insets.bottom,
                } or nil,
            }
        end
    end
    local bucket = self._classWidgets[class]
    if not bucket then
        bucket = {}
        self._classWidgets[class] = bucket
    end
    for i = 1, #bucket do
        if bucket[i] == frame then
            return
        end
    end
    bucket[#bucket + 1] = frame
    -- Immediate-apply: cover the lazy-init path. Modules that register
    -- frames after ADDON_LOADED ApplyTheme has run (e.g. on-demand UI
    -- construction, profile-switch reapply) get themed within one
    -- frame via the Theme.RequestApply dirty-flag cascade.
    if GRIPEMS.Theme and GRIPEMS.Theme.RequestApply then
        GRIPEMS.Theme.RequestApply(class)
    end
end

--- Register a frame for live alpha and scale updates. Idempotent: duplicate registrations are ignored.
--- Also registers the frame with UI.RegisterElement under `class` if given, else the category default
--- (panel -> "panel.main", overlay -> "overlay.tooltip"). Existing 2-arg callers keep working.
--- Self-heal: alpha + scale apply immediately; theme-element via chained RegisterElement call.
--- @param frame Frame The root frame to register
--- @param category string "panel" or "overlay"
--- @param class string Element class from UI.ELEMENT_CLASSES. Required (2026-04-22 Phase B prep).
---   If omitted, the frame is still registered for alpha/scale propagation but NOT for theme,
---   and a red-text warning is written to DEFAULT_CHAT_FRAME so the regression is visible.
function UI:RegisterPanelFrame(frame, category, class)
    if not frame then
        return
    end
    local bucket = self._panelRegistry[category]
    if not bucket then
        return
    end
    local alreadyRegistered = false
    for i = 1, #bucket do
        if bucket[i] == frame then
            alreadyRegistered = true
            break
        end
    end
    if not alreadyRegistered then
        bucket[#bucket + 1] = frame
        if category == "panel" then
            if frame.SetAlpha then
                pcall(frame.SetAlpha, frame, self:GetPanelAlpha())
            end
        elseif category == "overlay" then
            if frame.SetAlpha then
                pcall(frame.SetAlpha, frame, self:GetOverlayAlpha())
            end
        end
        if frame.SetScale then
            pcall(frame.SetScale, frame, self:GetUIScale())
        end
    end
    if class == nil then
        if DEFAULT_CHAT_FRAME and DEFAULT_CHAT_FRAME.AddMessage then
            DEFAULT_CHAT_FRAME:AddMessage(
                "|cffff6060[GRIP-EMS]|r RegisterPanelFrame called without class argument for frame "
                    .. tostring(frame and frame.GetName and frame:GetName() or frame)
                    .. "; skipping theme registration. Every call must pass an explicit class string from UI.ELEMENT_CLASSES."
            )
        end
        return
    end
    if self.RegisterElement then
        self:RegisterElement(frame, class)
    end
end

--- WCAG 2.5.5 AAA minimum hit-target size, in pixels.
local LARGE_TARGET_MIN_PX = 44

--- Apply hit-rect insets to f based on its size and axis stash.
--- "all" or nil: symmetric pad on all four sides.
--- "br": expand only toward top-left (keeps the bottom-right corner pinned,
--- which matters for resize grips anchored at BOTTOMRIGHT -- expanding
--- bottom or right would shove the hit rect off the frame).
local function applyInsetsForFrame(f)
    local axis = f._emsLargeTargetAxis or "all"
    local w = f:GetWidth() or 0
    local h = f:GetHeight() or 0
    local effW = LARGE_TARGET_MIN_PX - w
    if effW < 0 then
        effW = 0
    end
    local effH = LARGE_TARGET_MIN_PX - h
    if effH < 0 then
        effH = 0
    end
    if axis == "br" then
        pcall(f.SetHitRectInsets, f, -effW, 0, -effH, 0)
    else
        local padX = effW / 2
        local padY = effH / 2
        pcall(f.SetHitRectInsets, f, -padX, -padX, -padY, -padY)
    end
end

--- Read accessibility.density from AceDB. Returns "normal" or "large".
--- @return string
function UI:GetDensityMode()
    if GRIPEMS.Settings and GRIPEMS.Settings.db and GRIPEMS.Settings.db.profile then
        local a = GRIPEMS.Settings.db.profile.accessibility
        if a and a.density == "large" then
            return "large"
        end
    end
    return "normal"
end

--- Convenience predicate.
--- @return boolean
function UI:IsLargeTargets()
    return self:GetDensityMode() == "large"
end

--- Density-aware extra px in large density mode. Returns 0 in normal mode,
--- 4 in large mode. Consumers integrate this into per-axis offset/size
--- math to spread or grow content when density="large". Sign depends on
--- coordinate space at each call site: SequenceEditor row anchors
--- SUBTRACT it from a negative y-offset literal (e.g. "0, -6 - UI:GetRowGap()"
--- pushes a row 4 px further DOWN in large mode); Import/Export pickers
--- ADD it to per-row height; SpellPicker filter rail ADDS it to per-tab
--- vertical gap. The user-perceived effect everywhere is "more space".
--- /reload required for already-drawn surfaces when density toggles --
--- documented behavior, no live re-anchor.
--- @return number
function UI:GetRowGap()
    if self:IsLargeTargets() then
        return 4
    end
    return 0
end

--- Register a frame as a large-target candidate.
--- When density is "large", ApplyLargeTargets will set SetHitRectInsets so the
--- effective click rect is at least LARGE_TARGET_MIN_PX x LARGE_TARGET_MIN_PX.
--- When density is "normal", insets are cleared to (0,0,0,0).
--- The optional axis arg selects the inset distribution:
---   nil or "all" -> symmetric pad on all four sides (default)
---   "br"         -> bottom-right corner pinned, pad expands left + top only
---                   (use for resize grips anchored at BOTTOMRIGHT)
--- Self-heal: applyInsetsForFrame fires immediately when density mode is large.
--- @param frame Frame The clickable frame to register
--- @param axis string|nil "all" (default) or "br"
function UI:RegisterLargeTarget(frame, axis)
    if not frame or not frame.SetHitRectInsets then
        return
    end
    frame._emsLargeTargetAxis = axis or "all"
    for i = 1, #self._largeTargetRegistry do
        if self._largeTargetRegistry[i] == frame then
            return
        end
    end
    table.insert(self._largeTargetRegistry, frame)

    -- Immediate-apply: cover the lazy-init path (SE:Init registers
    -- frames after ADDON_LOADED ApplyTheme has run). Keeps insets
    -- in sync without forcing a full ApplyLargeTargets walk.
    if self:IsLargeTargets() then
        applyInsetsForFrame(frame)
    end
end

--- Walk the registry and apply hit-rect insets per current density mode.
--- Safe against destroyed frames via pcall.
function UI:ApplyLargeTargets()
    local large = self:IsLargeTargets()
    for i = 1, #self._largeTargetRegistry do
        local f = self._largeTargetRegistry[i]
        if f and f.SetHitRectInsets and f.GetWidth and f.GetHeight then
            if large then
                applyInsetsForFrame(f)
            else
                pcall(f.SetHitRectInsets, f, 0, 0, 0, 0)
            end
        end
    end
    self:ApplyTitleBarSpacing()
end

--- Re-anchor the MainFrame title-bar buttons (close / minimize / settings)
--- with a density-aware horizontal gap. Normal density keeps the buttons
--- visually tight (-4 px overlap on borders); large density spreads them
--- by -20 px so the 44px hit rects stop overlapping each other.
--- Each ClearAllPoints / SetPoint pair is pcall-guarded so a partial
--- frame teardown does not break the walk.
function UI:ApplyTitleBarSpacing()
    local mf = _G.GRIPEMS_MainFrame
    if not mf then
        return
    end
    local closeBtn = mf.closeBtn
    local minimizeBtn = mf.minimizeBtn
    local settingsBtn = mf.settingsBtn
    if not (closeBtn and minimizeBtn and settingsBtn) then
        return
    end
    local gap = self:IsLargeTargets() and -20 or -4
    pcall(minimizeBtn.ClearAllPoints, minimizeBtn)
    pcall(minimizeBtn.SetPoint, minimizeBtn, "RIGHT", closeBtn, "LEFT", gap, 0)
    pcall(settingsBtn.ClearAllPoints, settingsBtn)
    pcall(settingsBtn.SetPoint, settingsBtn, "RIGHT", minimizeBtn, "LEFT", gap, 0)
end

--- Post-hook AceGUI:Create so every interactive AceGUI leaf widget (Button,
--- CheckBox, Dropdown / Dropdown-Item-*, EditBox, MultiLineEditBox, Slider,
--- Keybinding, ColorPicker, LSM30_*) is registered as a large-target
--- candidate at construction time. Mirrors UI/AceConfigFocusShim.lua
--- isLeafType (L46-58): LEAF_TYPES literal set + LSM30_ prefix branch.
--- Same set the focus shim TAB-cycles through, so every TAB-reachable
--- widget gets a 44x44 hit-rect under accessibility.density.largeTarget = true.
--- The LSM30_ branch covers LibSharedMedia widget-provider addons that
--- register LSM30_Font / LSM30_Sound / LSM30_Background / LSM30_Border
--- as custom AceGUI widget types; without a provider AceConfigDialog
--- falls back to native Dropdown (caught by the Dropdown branch).
--- The wrapper's own Dropdown-Item-* branch is asymmetric vs the shim --
--- shim does not TAB through individual menu items, but largeTarget DOES
--- expand each item's hit-rect when the menu pops.
--- AceGUI pools widgets, so a "released" widget re-enters Create on the next
--- acquire -- the registration call is itself idempotent so double-wrapping
--- is harmless. Idempotent gate via self._aceGUIHooked prevents wrapping the
--- wrapper if HookAceGUIDropdowns is invoked twice.
--- Function name retained for backward compat with the one call site at
--- Core/Core.lua L3247; scope expansion via body change only.
function UI:HookAceGUIDropdowns()
    local AceGUI = LibStub and LibStub("AceGUI-3.0", true)
    if not AceGUI or self._aceGUIHooked then
        return
    end
    self._aceGUIHooked = true
    local origCreate = AceGUI.Create
    if type(origCreate) ~= "function" then
        return
    end
    AceGUI.Create = function(ag, widgetType)
        local w = origCreate(ag, widgetType)
        if w and w.frame and type(widgetType) == "string" then
            local isInteractive = widgetType == "Button"
                or widgetType == "CheckBox"
                or widgetType == "Dropdown"
                or widgetType:sub(1, 14) == "Dropdown-Item-"
                or widgetType == "EditBox"
                or widgetType == "MultiLineEditBox"
                or widgetType == "Slider"
                or widgetType == "Keybinding"
                or widgetType == "ColorPicker"
                or widgetType:sub(1, 6) == "LSM30_"
            if isInteractive then
                UI:RegisterLargeTarget(w.frame)
            end
        end
        return w
    end
end

--- Read accessibility.fontName from AceDB. Returns nil when unset or empty.
--- ApplyAceGUIFont uses nil to short-circuit before any LSM lookup, so an
--- unset fontName never triggers SetFont calls that would sever GameFont
--- FontObject inheritance.
--- @return string|nil
function UI:GetAccessibilityFontName()
    if GRIPEMS.Settings and GRIPEMS.Settings.db and GRIPEMS.Settings.db.profile then
        local a = GRIPEMS.Settings.db.profile.accessibility
        if a and a.fontName and a.fontName ~= "" then
            return a.fontName
        end
    end
    return nil
end

-- AceGUI widget FontString attribute names walked by UI:ApplyAceGUIFont.
-- Covers Button / CheckBox / Label / Heading / Dropdown / EditBox /
-- MultiLineEditBox / Slider / Keybinding / InteractiveLabel / ColorPicker /
-- Frame / Window / InlineGroup / BlizOptionsGroup. Nested FontStrings
-- (Keybinding widget.button text, widget.msgframe.msg, Slider editbox) are
-- intentionally NOT included -- short transient captions.
local FONT_ATTRS = { "label", "text", "desc", "titletext", "statustext", "lowtext", "hightext" }

--- Resolve the LSM-fetched font path for the configured accessibility
--- fontName. Returns nil when GetAccessibilityFontName returns nil (setting
--- unset/empty), when fontName == "Friz Quadrata TT" (default LSM key --
--- skip to preserve GameFont FontObject inheritance + SetTextColor
--- propagation), when LSM is absent, or when LSM:Fetch returns nil (font
--- registered but file missing). Centralizes the guard chain so
--- ApplyAceGUIFont and the dynamic widget hooks (BuildTabs / RefreshTree)
--- share one resolution path.
--- @return string|nil path
function UI:ResolveAccessibilityFontPath()
    local fontName = UI:GetAccessibilityFontName()
    if not fontName or fontName == "Friz Quadrata TT" then
        return nil
    end
    local LSM = LibStub and LibStub("LibSharedMedia-3.0", true)
    if not LSM then
        return nil
    end
    return LSM:Fetch("font", fontName, true)
end

--- Apply a resolved font path to a single FontString candidate. pcall-guards
--- GetObjectType so non-FontString fields named like attribute keys (e.g. a
--- Button widget.text that is the button frame itself) are skipped safely,
--- and pcall-guards SetFont preserving the existing height and flags.
--- Callers resolve the path once via ResolveAccessibilityFontPath and
--- dispatch multiple FontStrings through this helper.
--- @param fs table|nil FontString candidate
--- @param path string LSM-resolved font file path
function UI:ApplyFontToFontString(fs, path)
    if not fs then
        return
    end
    local ok, objType = pcall(fs.GetObjectType, fs)
    if ok and objType == "FontString" then
        local _, height, flags = fs:GetFont()
        pcall(fs.SetFont, fs, path, height or 10, flags or "")
    end
end

--- Apply the configured accessibility font to an AceGUI widget's FontString
--- attributes. Iterates the module-scope attribute list and dispatches each
--- candidate through UI:ApplyFontToFontString so the per-FontString pcall
--- guard is shared with the dynamic widget hooks below.
---
--- Plus dynamic TabGroup tab.Text + TreeGroup button.text via
--- hooksecurefunc on BuildTabs / RefreshTree (idempotent gate per-widget).
--- Closes the AceConfigDialog left-sidebar + nested-tab coverage gap
--- surfaced during G.8c.11 post-Code verification: AceConfig builds its
--- left navigation as a TreeGroup whose row FontStrings (button.text) are
--- constructed in RefreshTree, and tabbed sub-panels as TabGroups whose
--- tab FontStrings (tab.Text) are built in BuildTabs. Both paths bypass
--- the FONT_ATTRS attribute scan because their FontStrings live inside
--- child tables (self.tabs[i].Text, self.buttons[i].text), not on the
--- widget root.
---
--- SKIP entirely when ResolveAccessibilityFontPath returns nil. The path
--- resolver bails on the "Friz Quadrata TT" default to preserve GameFont
--- FontObject inheritance + SetTextColor propagation for users who never
--- changed the setting.
--- @param w table AceGUI widget table
function UI:ApplyAceGUIFont(w)
    if not w then
        return
    end
    local path = UI:ResolveAccessibilityFontPath()
    if not path then
        return
    end
    for _, attr in ipairs(FONT_ATTRS) do
        UI:ApplyFontToFontString(w[attr], path)
    end
    if type(w.BuildTabs) == "function" and not w._aceGUIFontTabsHooked then
        w._aceGUIFontTabsHooked = true
        hooksecurefunc(w, "BuildTabs", function(self)
            local p = UI:ResolveAccessibilityFontPath()
            if not p or not self.tabs then
                return
            end
            for _, tab in ipairs(self.tabs) do
                UI:ApplyFontToFontString(tab.Text, p)
            end
        end)
    end
    if type(w.RefreshTree) == "function" and not w._aceGUIFontTreeHooked then
        w._aceGUIFontTreeHooked = true
        hooksecurefunc(w, "RefreshTree", function(self)
            local p = UI:ResolveAccessibilityFontPath()
            if not p or not self.buttons then
                return
            end
            for _, btn in ipairs(self.buttons) do
                UI:ApplyFontToFontString(btn.text, p)
            end
        end)
    end
end

--- Post-hook AceGUI:Create so every constructed widget has its FontString
--- attributes re-routed through the accessibility.fontName setting.
--- Composes on top of UI:HookAceGUIDropdowns -- both wrappers run on every
--- Create call in install order (HookAceGUIDropdowns first, HookAceGUIFonts
--- second per Core.lua pcall site ordering). Composition is safe because
--- each wrapper captures the prior Create reference and forwards results
--- unchanged.
---
--- Closes G8-AUDIT-29 / -38 / -52: AceConfig labels/descs render in
--- GameFontHighlight regardless of the accessibility.fontName select at
--- SettingsPanel.lua L4027-4048. The select stores the preference; this
--- wrapper is the live-apply path on the next AceConfig dialog open. AceGUI
--- widgets pool but every panel open re-acquires via Create, so the hook
--- covers both fresh-acquire + post-release re-acquire paths.
---
--- Idempotent via self._aceGUIFontsHooked.
function UI:HookAceGUIFonts()
    local AceGUI = LibStub and LibStub("AceGUI-3.0", true)
    if not AceGUI or self._aceGUIFontsHooked then
        return
    end
    self._aceGUIFontsHooked = true
    local origCreate = AceGUI.Create
    if type(origCreate) ~= "function" then
        return
    end
    AceGUI.Create = function(ag, widgetType)
        local w = origCreate(ag, widgetType)
        if w then
            UI:ApplyAceGUIFont(w)
        end
        return w
    end
end

--- Read accessibility.bgOpacity from AceDB. Defaults to 1.0 if missing.
--- @return number
function UI:GetBgOpacity()
    if GRIPEMS.Settings and GRIPEMS.Settings.db and GRIPEMS.Settings.db.profile then
        local a = GRIPEMS.Settings.db.profile.accessibility
        if a and a.bgOpacity ~= nil then
            return a.bgOpacity
        end
    end
    return 1.0
end

--- Read accessibility.borderOpacity from AceDB. Defaults to 1.0 if missing.
--- @return number
function UI:GetBorderOpacity()
    if GRIPEMS.Settings and GRIPEMS.Settings.db and GRIPEMS.Settings.db.profile then
        local a = GRIPEMS.Settings.db.profile.accessibility
        if a and a.borderOpacity ~= nil then
            return a.borderOpacity
        end
    end
    return 1.0
end

--- Read accessibility.panelAlpha from AceDB. Defaults to 1.0 if missing.
--- @return number
function UI:GetPanelAlpha()
    if GRIPEMS.Settings and GRIPEMS.Settings.db and GRIPEMS.Settings.db.profile then
        local a = GRIPEMS.Settings.db.profile.accessibility
        if a and a.panelAlpha ~= nil then
            return a.panelAlpha
        end
    end
    return 1.0
end

--- Read accessibility.overlayAlpha from AceDB. Defaults to 1.0 if missing.
--- @return number
function UI:GetOverlayAlpha()
    if GRIPEMS.Settings and GRIPEMS.Settings.db and GRIPEMS.Settings.db.profile then
        local a = GRIPEMS.Settings.db.profile.accessibility
        if a and a.overlayAlpha ~= nil then
            return a.overlayAlpha
        end
    end
    return 1.0
end

--- Read accessibility.uiScale from AceDB, clamped to [0.8, 2.0]. Defaults to 1.0.
--- @return number
function UI:GetUIScale()
    local v = 1.0
    if GRIPEMS.Settings and GRIPEMS.Settings.db and GRIPEMS.Settings.db.profile then
        local a = GRIPEMS.Settings.db.profile.accessibility
        if a and a.uiScale ~= nil then
            v = a.uiScale
        end
    end
    if type(v) ~= "number" then
        return 1.0
    end
    if v < 0.8 then
        return 0.8
    elseif v > 2.0 then
        return 2.0
    end
    return v
end

--- Re-apply backdrop colors for every tracked binding using current opacity multipliers.
--- Nil-guards every field; pcalls both SetBackdrop* calls so a destroyed frame does not break the walk.
function UI:RebindBackdrops()
    local bgMul = self:GetBgOpacity()
    local borderMul = self:GetBorderOpacity()
    for frame, binding in pairs(self._backdropBindings) do
        if frame and binding.bg and frame.SetBackdropColor then
            local r, g, bl, a = binding.bg:GetRGBA()
            pcall(frame.SetBackdropColor, frame, r, g, bl, a * bgMul)
        end
        if frame and binding.border and frame.SetBackdropBorderColor then
            local r, g, bl, a = binding.border:GetRGBA()
            pcall(frame.SetBackdropBorderColor, frame, r, g, bl, a * borderMul)
        end
    end
end

--- Apply panelAlpha to every registered panel frame and overlayAlpha to every overlay frame.
function UI:ApplyLiveAlphas()
    local panelA = self:GetPanelAlpha()
    local overlayA = self:GetOverlayAlpha()
    local panel = self._panelRegistry.panel
    for i = 1, #panel do
        local f = panel[i]
        if f and f.SetAlpha then
            pcall(f.SetAlpha, f, panelA)
        end
    end
    local overlay = self._panelRegistry.overlay
    for i = 1, #overlay do
        local f = overlay[i]
        if f and f.SetAlpha then
            pcall(f.SetAlpha, f, overlayA)
        end
    end
end

--- Apply the global uiScale to every registered panel and overlay frame.
function UI:ApplyUIScale()
    local s = self:GetUIScale()
    local panel = self._panelRegistry.panel
    for i = 1, #panel do
        local f = panel[i]
        if f and f.SetScale then
            pcall(f.SetScale, f, s)
        end
    end
    local overlay = self._panelRegistry.overlay
    for i = 1, #overlay do
        local f = overlay[i]
        if f and f.SetScale then
            pcall(f.SetScale, f, s)
        end
    end
end

--- Apply every live theme update (backdrops, alphas, scale) and fire theme listeners.
function UI:ApplyTheme()
    self:RebindBackdrops()
    self:ApplyLiveAlphas()
    self:ApplyUIScale()
    self:ApplyLargeTargets()
    self:ApplyTitleBarSpacing()
    for i = 1, #self._themeListeners do
        pcall(self._themeListeners[i])
    end
end

--- One-call facade for the dual Theme + UI cascade. queueThemeReapply,
--- AccessibilityMode toggle, and any future "apply everything" caller
--- should invoke this rather than two sequential calls. Targeted callers
--- (palette swap, slot load, isolated theme-only events) keep using
--- GRIPEMS.Theme.ApplyTheme or UI:ApplyTheme directly.
--- See Backlog UI-APPLYALL-FACADE.
function UI:ApplyAll()
    if GRIPEMS.Theme and GRIPEMS.Theme.ApplyTheme then
        GRIPEMS.Theme.ApplyTheme()
    end
    self:ApplyTheme()
end

--- Resolve the "auto" preset selection from the colorblindMode CVar.
--- @return string Preset key
function UI:ResolveAutoPreset()
    local cb = GetCVar and GetCVar("colorblindMode")
    if cb == "1" then
        return "DeuteranopiaSafe"
    end
    return "Default"
end

---------------------------------------------------------------------------
-- Severity scale (shared)
---------------------------------------------------------------------------
-- ONE SCALE, TWO PANELS. These values lived only in UI/RepairFrame.lua and are
-- moved here verbatim so the keybind conflict panel renders on the same scale
-- rather than inventing a second one. A second scale is how two panels end up
-- showing the same severity in two colours, which teaches the user that the
-- colour means nothing.
--
-- This is a MOVE, not a redesign. RepairFrame must render byte-identically.
UI.SEVERITY_COLORS = {
    critical = { 1.0, 0.2, 0.2 },
    error = { 1.0, 0.3, 0.3 },
    warning = { 1.0, 0.8, 0.0 },
    info = { 0.6, 0.6, 0.7 },
}
-- The labels are localised. They are populated HERE rather than behind an
-- accessor because both consumers already capture this table as an upvalue and
-- index it -- UI/RepairFrame.lua and UI/KeybindConflictPanel.lua, nine call sites
-- between them -- so filling it in place localises every one of them without
-- touching a single call site. Locale loads long before UI in the .toc, so the
-- lookups here are safe at file-load time.
--
-- KEEP THE ENGLISH SHORT. These render inside 60-pixel chip buttons in both
-- panels, so a long translation clips rather than wraps.
UI.SEVERITY_LABELS = {
    critical = L["GEMS_SEV_CRIT"],
    error = L["GEMS_SEV_ERR"],
    warning = L["GEMS_SEV_WARN"],
    info = L["GEMS_SEV_INFO"],
}
UI.SEVERITY_ORDER = { "critical", "error", "warning", "info" }

---------------------------------------------------------------------------
-- Backdrop definitions (BackdropTemplate)
---------------------------------------------------------------------------
UI.Backdrops = {
    panel = {
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    },
    panelNoBorder = {
        bgFile = "Interface\\Buttons\\WHITE8x8",
    },
}

---------------------------------------------------------------------------
-- Tooltip helpers (GameTooltip wrappers)
---------------------------------------------------------------------------

--- Show a standard tooltip anchored to the given frame.
--- @param owner Frame The frame to anchor the tooltip to
--- @param title string Tooltip title (white text)
--- @param desc string|nil Optional description line (gray text)
--- @param hint string|nil Optional hint line (yellow text)
function UI:ShowTooltip(owner, title, desc, hint)
    if not owner or not title then
        return
    end
    GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")
    GameTooltip:SetText(title, 1, 1, 1)
    if desc then
        GameTooltip:AddLine(desc, 0.8, 0.8, 0.8, true)
    end
    if hint then
        GameTooltip:AddLine(hint, 1, 0.82, 0, true)
    end
    GameTooltip:Show()
    -- Screen-edge clamp: flip anchor if tooltip extends past right edge
    if GameTooltip:GetRight() and GameTooltip:GetRight() > UIParent:GetRight() then
        GameTooltip:ClearAllPoints()
        GameTooltip:SetPoint("TOPRIGHT", owner, "TOPLEFT", -2, 0)
    end
end

--- Hide the GameTooltip.
function UI:HideTooltip()
    GameTooltip:Hide()
end

---------------------------------------------------------------------------
-- Font helper
---------------------------------------------------------------------------

--- Resolve the currently-selected font path.
--- Reads accessibility.fontName from AceDB, resolves via LibSharedMedia-3.0.
--- Falls back to GameFontNormal path if LSM is absent or the font key is unknown.
--- @return string fontPath Absolute path to a font file
function UI:GetFontPath()
    local name
    if GRIPEMS.Settings and GRIPEMS.Settings.db and GRIPEMS.Settings.db.profile then
        local a = GRIPEMS.Settings.db.profile.accessibility
        if a and a.fontName then
            name = a.fontName
        end
    end
    if name and LibStub then
        local LSM = LibStub("LibSharedMedia-3.0", true)
        if LSM then
            local path = LSM:Fetch("font", name, true)
            if path then
                return path
            end
        end
    end
    return GameFontNormal:GetFont()
end

--- Set a FontString to the standard game font at the given size.
--- @param fontString FontString The FontString object to configure
--- @param size number Font size in points
--- @param flags string|nil Optional font flags ("OUTLINE", "THICKOUTLINE", etc.)
function UI:SetFont(fontString, size, flags)
    if not fontString then
        return
    end
    local fontPath = UI:GetFontPath()
    fontString:SetFont(fontPath, size, flags or "")
end

---------------------------------------------------------------------------
-- Button factory
---------------------------------------------------------------------------

--- Create a themed button with dark-theme styling and tooltip support.
--- @param parent Frame Parent frame
--- @param text string Button label text
--- @param width number Button width
--- @param height number Button height
--- @return Button The created button frame
function UI:CreateButton(parent, text, width, height)
    local btn = CreateFrame("Button", nil, parent, "BackdropTemplate")
    btn:SetSize(width, height)
    local C = UI.Colors
    UI:ApplyBackdrop(btn, UI.Backdrops.panel, C.bgButton, C.border)

    -- Label
    local label = btn:CreateFontString(nil, "OVERLAY")
    UI:SetFont(label, 12)
    label:SetPoint("CENTER")
    label:SetText(text)
    label:SetTextColor(C.textPrimary:GetRGBA())
    btn.label = label

    -- Hover highlight
    btn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.bgRowHover:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
    end)
    btn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
    end)

    -- Click flash
    btn:SetScript("OnMouseDown", function(self)
        self:SetBackdropColor(C.accent:GetRGBA())
    end)
    btn:SetScript("OnMouseUp", function(self)
        self:SetBackdropColor(C.bgRowHover:GetRGBA())
    end)

    return btn
end

---------------------------------------------------------------------------
-- Backdrop application
---------------------------------------------------------------------------

--- Apply a backdrop definition with background and optional border color.
--- Colors must be ColorMixin objects (from UI.Colors).
--- Self-heal: applies colors immediately and stores binding for later RebindBackdrops walks; no lazy-init gap.
--- @param frame Frame The frame to apply backdrop to
--- @param backdropDef table Backdrop definition (e.g. UI.Backdrops.panel)
--- @param bgColor table ColorMixin for SetBackdropColor
--- @param borderColor table|nil ColorMixin for SetBackdropBorderColor (omit for no-border backdrops)
function UI:ApplyBackdrop(frame, backdropDef, bgColor, borderColor)
    -- ScrollBox rows built by SetElementInitializer("Button"/"Frame", ...)
    -- are plain frames with no backdrop methods, so SetBackdrop below is
    -- nil on them and the nil-call aborts the caller's whole initializer
    -- via secureexecuterange -- rows then paint blank. Applying a backdrop
    -- is this function's contract, so ensuring the frame can take one
    -- belongs here rather than at each call site. The bgColor/borderColor
    -- guards below already anticipated method-less frames; this closes the
    -- gap two lines above them.
    if not frame.SetBackdrop then
        Mixin(frame, BackdropTemplateMixin)
    end
    frame:SetBackdrop(backdropDef)
    if bgColor and frame.SetBackdropColor then
        local r, g, b, a = bgColor:GetRGBA()
        frame:SetBackdropColor(r, g, b, a * self:GetBgOpacity())
    end
    if borderColor and frame.SetBackdropBorderColor then
        local r, g, b, a = borderColor:GetRGBA()
        frame:SetBackdropBorderColor(r, g, b, a * self:GetBorderOpacity())
    end
    self._backdropBindings[frame] = { bg = bgColor, border = borderColor }
end

---------------------------------------------------------------------------
-- Icon resolution
---------------------------------------------------------------------------

--- Resolve an icon value to a WoW texture path.
--- Handles numeric IDs (pass through), string paths (prefix if needed), and nil.
--- @param icon any Icon value (number, string, or nil)
--- @return any Resolved texture path or ID
function UI:ResolveIcon(icon)
    if type(icon) == "number" then
        return icon
    end
    if type(icon) == "string" then
        if icon:find("^Interface\\") then
            return icon
        end
        if icon ~= "" then
            return "Interface\\Icons\\" .. icon
        end
    end
    return "Interface\\Icons\\" .. D().QUESTION_MARK_ICON
end

---------------------------------------------------------------------------
-- Scroll panel factory
---------------------------------------------------------------------------

--- Create a standard scroll panel with UIPanelScrollFrameTemplate.
--- Returns the ScrollFrame and its scrollChild. Caller must set anchoring
--- on the scrollFrame (too context-specific to generalize).
--- @param parent Frame Parent frame
--- @param childWidth number|nil Initial scrollChild width (default 300)
--- @return ScrollFrame scrollFrame
--- @return Frame scrollChild
function UI:CreateScrollPanel(parent, childWidth)
    local scrollFrame = CreateFrame("ScrollFrame", nil, parent, "UIPanelScrollFrameTemplate")
    local scrollChild = CreateFrame("Frame", nil, scrollFrame)
    scrollChild:SetWidth(childWidth or 300)
    scrollFrame:SetScrollChild(scrollChild)
    UI:SkinLegacyScrollBar(scrollFrame)
    return scrollFrame, scrollChild
end

---------------------------------------------------------------------------
-- Legacy scrollbar skinning
---------------------------------------------------------------------------

--- Skin a UIPanelScrollFrameTemplate scrollbar to match the dark theme.
--- Hides arrow buttons, narrows the bar, recolors thumb/track.
--- Defensive: silently no-ops if elements are missing.
--- @param scrollFrame ScrollFrame A UIPanelScrollFrameTemplate instance
function UI:SkinLegacyScrollBar(scrollFrame)
    if not scrollFrame then
        return
    end

    -- Locate scrollbar: named convention or anonymous child
    local sfName = scrollFrame.GetName and scrollFrame:GetName()
    local scrollBar = scrollFrame.ScrollBar or (sfName and _G[sfName .. "ScrollBar"])
    if not scrollBar then
        return
    end

    -- Narrow the bar
    pcall(scrollBar.SetWidth, scrollBar, 12)

    -- Hide arrow buttons (try all known patterns)
    local upBtn = scrollBar.ScrollUpButton or scrollBar.Back or (sfName and _G[sfName .. "ScrollBarScrollUpButton"])
    local downBtn = scrollBar.ScrollDownButton
        or scrollBar.Forward
        or (sfName and _G[sfName .. "ScrollBarScrollDownButton"])
    if upBtn then
        pcall(upBtn.SetAlpha, upBtn, 0)
        pcall(upBtn.SetSize, upBtn, 1, 1)
    end
    if downBtn then
        pcall(downBtn.SetAlpha, downBtn, 0)
        pcall(downBtn.SetSize, downBtn, 1, 1)
    end

    -- Reskin thumb
    local thumb = scrollBar.ThumbTexture or (sfName and _G[sfName .. "ScrollBarThumbTexture"])
    if thumb then
        pcall(thumb.SetColorTexture, thumb, 0.4, 0.4, 0.4, 0.6)
        pcall(thumb.SetSize, thumb, 8, 32)
    end

    -- Track background
    pcall(function()
        local track = scrollBar:CreateTexture(nil, "BACKGROUND")
        track:SetAllPoints()
        track:SetColorTexture(0.08, 0.08, 0.1, 0.8)
    end)
end

---------------------------------------------------------------------------
-- Frame reclamation (for /reload reuse)
---------------------------------------------------------------------------

--- Reclaim a named frame that survived /reload, or create a new one.
--- On /reload, named C++ frames persist and are re-mapped to _G.
--- This function reuses the surviving frame (clearing stale scripts
--- and orphaning old children) instead of creating a new one.
--- @param name string Global frame name
--- @param frameType string|nil Frame type (default "Frame")
--- @param parent Frame|nil Parent frame (default UIParent)
--- @param template string|nil Template name
--- @return Frame The reclaimed or newly created frame
function UI:ReclaimFrame(name, frameType, parent, template)
    local frame = _G[name]
    if frame then
        frame:SetParent(parent or UIParent)
        frame:ClearAllPoints()
        frame:UnregisterAllEvents()
        frame:SetScript("OnEvent", nil)
        frame:SetScript("OnUpdate", nil)
        frame:SetScript("OnShow", nil)
        frame:SetScript("OnHide", nil)
        if frame:HasScript("OnDragStart") then
            frame:SetScript("OnDragStart", nil)
        end
        if frame:HasScript("OnDragStop") then
            frame:SetScript("OnDragStop", nil)
        end
        if frame:HasScript("OnMouseDown") then
            frame:SetScript("OnMouseDown", nil)
        end
        if frame:HasScript("OnSizeChanged") then
            frame:SetScript("OnSizeChanged", nil)
        end
        if frame:HasScript("OnEnter") then
            frame:SetScript("OnEnter", nil)
        end
        if frame:HasScript("OnLeave") then
            frame:SetScript("OnLeave", nil)
        end
        if frame:HasScript("OnClick") then
            frame:SetScript("OnClick", nil)
        end
        if frame:HasScript("OnTextChanged") then
            frame:SetScript("OnTextChanged", nil)
        end
        for _, child in pairs({ frame:GetChildren() }) do
            child:Hide()
            child:ClearAllPoints()
            child:SetParent(nil)
        end
        for _, region in pairs({ frame:GetRegions() }) do
            region:Hide()
        end
        return frame
    end
    return CreateFrame(frameType or "Frame", name, parent or UIParent, template)
end
