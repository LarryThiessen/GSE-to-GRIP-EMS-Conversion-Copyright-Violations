-- GRIP-EMS: Headless test for Source tab apply-strip + highlight size gate
--
-- Created:    2026-07-09
-- Updated:    2026-08-04
-- Patch: 12.0.7.68974 Midnight (Retail LIVE)
--
-- Standalone (Lua 5.1) test for UI/SyntaxHighlight.lua (Colorize/Strip and
-- the SH_MAX_COLORIZE_CHARS large-buffer gate) and UI/RawTab.lua's
-- ApplyChanges strip-before-parse path. The Apply click drops editbox focus
-- first, so the focus-loss highlight hook has already baked colour escape
-- codes into the buffer; ApplyChanges must strip them before loadstring.
-- Loads the REAL modules via loadfile + setfenv into a sandbox. No frames
-- are created (RT:Init is never called); a fake editBox and statusLine back
-- the apply path directly.
--
-- Run from the EMS root:  lua Test/test_syntaxhighlight_apply_strip.lua
-- Exit code 0 = all passed, 1 = at least one failure.
--
-- Cases:
--   T1  Strip(Colorize(src)) round-trips byte-exact for small Lua source
--   T2  gate on: buffer over SH_MAX_COLORIZE_CHARS comes back unchanged
--   T3  gate off below cap: small source gains cff escape prefixes
--   T4  ApplyChanges with a colour-coded buffer applies cleanly (field shape)
--   T5  ApplyChanges with a plain buffer still applies (strip is a no-op)
--   T6  ApplyChanges with a CHANGED name warns and schedules no auto-hide
--   T7  ApplyChanges with an UNCHANGED name applies and schedules one auto-hide

local ADDON_NAME = "GRIP-EMS"

-- ---------------------------------------------------------------------------
-- Minimal assertion + runner harness.
-- ---------------------------------------------------------------------------

local tests = {}

local function test(name, fn)
    tests[#tests + 1] = { name = name, fn = fn }
end

local function assertEqual(expected, actual, label)
    if expected ~= actual then
        error((label or "value") .. ": expected " .. tostring(expected) .. ", got " .. tostring(actual), 2)
    end
end

local function assertTrue(cond, label)
    if not cond then
        error((label or "condition") .. " failed", 2)
    end
end

-- ---------------------------------------------------------------------------
-- Sandbox: a self-referential no-op stub backs every unknown global, so the
-- modules load without a real WoW client. Real stdlib falls through to _G.
-- ---------------------------------------------------------------------------

local stub = {}
setmetatable(stub, {
    __index = function()
        return stub
    end,
    __call = function()
        return stub
    end,
})

local env = setmetatable({}, {
    __index = function(_, k)
        local v = rawget(_G, k)
        if v ~= nil then
            return v
        end
        return stub
    end,
})
env._G = env

-- Locale lookups resolve to the key name itself, so string.format on them
-- never errors and the statusLine capture can be asserted against key names.
local LOCALE = setmetatable({}, {
    __index = function(_, k)
        return k
    end,
})

env.LibStub = function()
    return {
        GetLocale = function()
            return LOCALE
        end,
    }
end
env.time = function()
    return 0
end

-- C_Timer recorder. ApplyChanges schedules the status-line auto-hide through
-- C_Timer.After; every scheduled call lands here so a case can assert both
-- legs -- the success message DOES schedule a hide, the name-ignored warning
-- does NOT (it must stay on screen until the next edit session clears it).
local timerCalls = {}
env.C_Timer = {
    After = function(delay, fn)
        timerCalls[#timerCalls + 1] = { delay = delay, fn = fn }
    end,
}

-- ---------------------------------------------------------------------------
-- GRIPEMS scaffold. UI.Colors must exist BEFORE RawTab.lua loads -- the
-- module captures local UI = GRIPEMS.UI at file scope. Every colour entry
-- exposes GetRGBA() returning plain white.
-- ---------------------------------------------------------------------------

local colourStub = {
    GetRGBA = function()
        return 1, 1, 1, 1
    end,
}

local GRIPEMS = {
    UI = {
        Colors = setmetatable({}, {
            __index = function()
                return colourStub
            end,
        }),
    },
    Defaults = {
        RAW_HEADER_HEIGHT = 28,
        RAW_STATUS_HEIGHT = 16,
        SH_MAX_COLORIZE_CHARS = 20000,
    },
}

-- ---------------------------------------------------------------------------
-- Load the REAL modules into the sandbox.
-- ---------------------------------------------------------------------------

local function loadModule(candidates)
    for _, path in ipairs(candidates) do
        -- loadfile is dev-harness file I/O, intentionally outside the addon WoW std.
        -- selene: allow(undefined_variable)
        local chunk = loadfile(path)
        if chunk then
            setfenv(chunk, env)
            chunk(ADDON_NAME, GRIPEMS)
            return true
        end
    end
    return false
end

assertTrue(
    loadModule({
        "UI/SyntaxHighlight.lua",
        "../UI/SyntaxHighlight.lua",
        "GRIP/EMS/UI/SyntaxHighlight.lua",
    }),
    "could not locate UI/SyntaxHighlight.lua (run from the EMS root)"
)
assertTrue(
    loadModule({
        "UI/RawTab.lua",
        "../UI/RawTab.lua",
        "GRIP/EMS/UI/RawTab.lua",
    }),
    "could not locate UI/RawTab.lua (run from the EMS root)"
)

local SH = GRIPEMS.SyntaxHighlight
local RT = GRIPEMS.RawTab
assertTrue(SH ~= nil, "SyntaxHighlight loaded")
assertTrue(RT ~= nil, "RawTab loaded")
assertTrue(type(SH.Colorize) == "function", "Colorize defined")
assertTrue(type(SH.Strip) == "function", "Strip defined")
assertTrue(type(RT.ApplyChanges) == "function", "ApplyChanges defined")

-- ---------------------------------------------------------------------------
-- Fake widgets. RT:Init is never called; the apply path only needs an
-- editBox (text buffer) and a statusLine (message capture). editBtn,
-- cancelBtn, modeLabel, hintLabel, and GRIPEMS.SequenceEditor stay unset --
-- those paths are nil-safe.
-- ---------------------------------------------------------------------------

local editBuffer = ""
local statusCaptured = nil
local updateCalls = 0

RT.editBox = {
    _shBusy = false,
    GetText = function()
        return editBuffer
    end,
    SetText = function(_, text)
        editBuffer = text
    end,
    EnableKeyboard = function() end,
    SetTextColor = function() end,
    ClearFocus = function() end,
}

RT.statusLine = {
    SetText = function(_, text)
        statusCaptured = text
    end,
    SetTextColor = function() end,
    Show = function() end,
    Hide = function() end,
}

-- ---------------------------------------------------------------------------
-- Fixtures.
-- ---------------------------------------------------------------------------

local SEQ_NAME = "RawApplySeq"

-- Minimal valid sequence for the apply path: name + flat steps + Sequential.
local function makeSeqTable()
    return {
        name = SEQ_NAME,
        stepFunction = "Sequential",
        steps = {
            "/say GRIP-EMS step 1",
            "/say GRIP-EMS step 2",
        },
    }
end

local SMALL_SRC = 'local total = 0\nfor i = 1, 10 do\n    total = total + i\nend\nreturn "done"\n'

local function deepCopy(tbl)
    if type(tbl) ~= "table" then
        return tbl
    end
    local copy = {}
    for k, v in pairs(tbl) do
        copy[k] = deepCopy(v)
    end
    return copy
end

-- Deterministic serialize: sorted keys, recursive, order-independent.
local function canonical(value)
    if type(value) ~= "table" then
        return tostring(value)
    end
    local keys = {}
    for k in pairs(value) do
        keys[#keys + 1] = k
    end
    table.sort(keys, function(a, b)
        return tostring(a) < tostring(b)
    end)
    local parts = {}
    for _, k in ipairs(keys) do
        parts[#parts + 1] = tostring(k) .. "=" .. canonical(value[k])
    end
    return "{" .. table.concat(parts, ",") .. "}"
end

--- Wire the Engine + Identity stubs and reset per-case apply state.
--- @param bufferText string The text the fake editBox hands to ApplyChanges
local function setupApplyCase(bufferText)
    updateCalls = 0
    statusCaptured = nil
    timerCalls = {}
    editBuffer = bufferText

    GRIPEMS.Engine = {
        sequences = { [SEQ_NAME] = { data = makeSeqTable() } },
        UpdateSequenceData = function()
            updateCalls = updateCalls + 1
        end,
        MigrateSequenceFormat = function() end,
        GetActiveVersion = function()
            return nil
        end,
    }
    GRIPEMS.Identity = {
        _DeepCopy = function(_, tbl)
            return deepCopy(tbl)
        end,
        CanonicalSerialize = function(_, tbl)
            return canonical(tbl)
        end,
        AppendModifierEntry = function() end,
    }

    RT.currentName = SEQ_NAME
    RT.isEditing = true
end

-- ---------------------------------------------------------------------------
-- Cases.
-- ---------------------------------------------------------------------------

test("T1: Strip(Colorize(src)) round-trips byte-exact for small Lua source", function()
    local coloured = SH:Colorize(SMALL_SRC, "lua")
    assertEqual(SMALL_SRC, SH:Strip(coloured), "round-trip")
end)

test("T2: gate on -- buffer over the cap comes back from Colorize unchanged", function()
    local big = string.rep('local n = 1 -- "padding"\n', 1000)
    assertTrue(#big > GRIPEMS.Defaults.SH_MAX_COLORIZE_CHARS, "fixture exceeds the cap")
    local out = SH:Colorize(big, "lua")
    assertEqual(big, out, "oversized buffer unchanged")
    assertEqual(nil, out:find("|cff", 1, true), "no colour codes added")
end)

test("T3: gate off below cap -- small source still gains cff escape prefixes", function()
    local out = SH:Colorize(SMALL_SRC, "lua")
    assertTrue(out:find("|cff", 1, true) ~= nil, "cff escape prefix present")
end)

test("T4: apply with a colour-coded buffer strips codes and applies cleanly", function()
    local serialization = RT:SerializeTable(makeSeqTable())
    local coloured = SH:Colorize(serialization, "lua")
    -- Sanity: the fixture reproduces the field failure shape -- codes are
    -- present and the raw buffer does NOT parse without the strip.
    assertTrue(coloured ~= serialization, "fixture buffer carries colour codes")
    assertEqual(nil, loadstring("return " .. coloured), "unstripped buffer fails loadstring")

    setupApplyCase(coloured)
    RT:ApplyChanges()
    assertEqual("GEMS_RAW_APPLIED", statusCaptured, "status message")
    assertEqual(1, updateCalls, "UpdateSequenceData call count")
end)

test("T5: apply with a plain buffer still applies -- strip is a no-op", function()
    setupApplyCase(RT:SerializeTable(makeSeqTable()))
    RT:ApplyChanges()
    assertEqual("GEMS_RAW_APPLIED", statusCaptured, "status message")
    assertEqual(1, updateCalls, "UpdateSequenceData call count")
end)

test("T6: apply with a CHANGED name warns and schedules NO auto-hide timer", function()
    local renamed = makeSeqTable()
    renamed.name = SEQ_NAME .. "Renamed"
    setupApplyCase(RT:SerializeTable(renamed))
    RT:ApplyChanges()
    assertEqual("GEMS_RAW_NAME_IGNORED", statusCaptured, "status message")
    assertEqual(1, updateCalls, "UpdateSequenceData call count")
    assertEqual(0, #timerCalls, "warning must not schedule an auto-hide")
end)

test("T7: apply with an UNCHANGED name applies and schedules exactly one auto-hide", function()
    setupApplyCase(RT:SerializeTable(makeSeqTable()))
    RT:ApplyChanges()
    assertEqual("GEMS_RAW_APPLIED", statusCaptured, "status message")
    assertEqual(1, updateCalls, "UpdateSequenceData call count")
    assertEqual(1, #timerCalls, "success must schedule exactly one auto-hide")
    assertEqual(2, timerCalls[1] and timerCalls[1].delay, "auto-hide delay")
end)

-- ---------------------------------------------------------------------------
-- Run.
-- ---------------------------------------------------------------------------

local passed = 0
local failed = 0
for _, t in ipairs(tests) do
    local ok, err = pcall(t.fn)
    if ok then
        passed = passed + 1
        print("PASS  " .. t.name)
    else
        failed = failed + 1
        print("FAIL  " .. t.name .. " -- " .. tostring(err))
    end
end
print(string.format("RESULT %d passed, %d failed", passed, failed))
os.exit(failed > 0 and 1 or 0)
