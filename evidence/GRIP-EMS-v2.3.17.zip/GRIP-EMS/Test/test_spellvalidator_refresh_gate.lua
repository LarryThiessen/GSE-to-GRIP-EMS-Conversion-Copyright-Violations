-- GRIP-EMS: Headless test for the spell-validation refresh combat gate
--
-- Created:    2026-07-10
-- Updated:    2026-07-10
-- Patch: 12.0.7 Midnight (Retail LIVE)
--
-- Standalone (Lua 5.1) test for Data/SpellValidator.lua's event-driven
-- revalidation path: the debounced SPELL_CACHE_REFRESHED handler fires a
-- SPELL_VALIDATION_UPDATED ping (no batch ValidateAll), and parks the ping
-- on a PLAYER_REGEN_ENABLED frame when the debounce lands in combat. Drives
-- the REAL SpellValidator module via loadfile + setfenv into a sandbox that
-- stubs C_Timer, CreateFrame, InCombatLockdown, and a fake GRIPEMS namespace.
-- Keeping the stubs as fields on a local env table (never global assignments)
-- keeps the file luacheck-clean under the read-only WoW std.
--
-- Run from the EMS root:  lua Test/test_spellvalidator_refresh_gate.lua
-- Exit code 0 = all passed, 1 = at least one failure.
--
-- Cases:
--   T1  OOC refresh          -> one ping, ValidateAll NOT called
--   T2  combat park          -> no ping until PLAYER_REGEN_ENABLED, then one;
--                               regen frame unregisters the event
--   T3  debounce coalescing  -> two back-to-back refreshes = one live timer,
--                               one ping
--   T4  direct path intact   -> SV:ValidateAll() returns { sequences = ... }
--   T5  regen frame reuse    -> second combat park re-registers the same
--                               frame; no new frame; second ping fires

local ADDON_NAME = "GRIP-EMS"

-- ---------------------------------------------------------------------------
-- Minimal assertion + runner harness (mirrors TestSuite Pass/Fail semantics).
-- ---------------------------------------------------------------------------

local tests = {}

local function test(name, fn)
    tests[#tests + 1] = { name = name, fn = fn }
end

local function assertEqual(expected, actual, label)
    if expected ~= actual then
        error((label or "value") .. ": expected " .. tostring(expected) .. ", got " .. tostring(actual), 2)
    end
end

local function assertTrue(cond, label)
    if not cond then
        error((label or "condition") .. " failed", 2)
    end
end

-- ---------------------------------------------------------------------------
-- C_Timer stub. Records every NewTimer; callbacks run only when the test
-- pumps them via runPendingTimers().
-- ---------------------------------------------------------------------------

local timers = {}

local function activeTimerCount()
    local n = 0
    for _, t in ipairs(timers) do
        if not t.cancelled and not t.executed then
            n = n + 1
        end
    end
    return n
end

local function runPendingTimers()
    for _, t in ipairs(timers) do
        if not t.cancelled and not t.executed then
            t.executed = true
            t.fn()
        end
    end
end

-- ---------------------------------------------------------------------------
-- Fake GRIPEMS namespace + sandbox environment.
-- ---------------------------------------------------------------------------

local D = {
    SPELL_VALIDATE_DEBOUNCE = 0.5,
    SPELL_STATUS_VALID = "valid",
    SPELL_STATUS_KNOWN = "known",
    SPELL_STATUS_UNKNOWN = "unknown",
    SPELL_STATUS_CONTEXTUAL = "contextual",
    SPELL_STATUS_ITEM = "item",
    SPELL_STATUS_VARIABLE = "variable",
    SPELL_STATUS_TOOLTIP_STALE = "tooltip_stale",
    VAR_PATTERN = "@%w+@",
    SKIP_SPELL_PREFIXES = {},
    QUESTION_MARK_ICON = 134400,
}

local fireCounts = {}

local function resetFireCounts()
    for k in pairs(fireCounts) do
        fireCounts[k] = nil
    end
end

local function pingCount()
    return fireCounts["SPELL_VALIDATION_UPDATED"] or 0
end

local registrations = {}

local spellCache = {
    byName = { ["fireball"] = 133 },
    GetIcon = function()
        return 135808
    end,
    GetSpellID = function()
        return nil
    end,
}

local engine = {
    sequences = {
        Seq = { data = { versions = { { steps = { "/cast Fireball" } } } } },
    },
    GetActiveVersion = function(_, data)
        return data.versions[1]
    end,
    SubstituteVariables = function(_, text)
        return text
    end,
}

local GRIPEMS = {
    Defaults = D,
    SpellCache = spellCache,
    Engine = engine,
    Debug = function() end,
    Fire = function(_, event)
        fireCounts[event] = (fireCounts[event] or 0) + 1
    end,
    RegisterCallback = function(target, event, method)
        registrations[event] = { target = target, method = method }
    end,
}

local function deliverCallback(event)
    local reg = registrations[event]
    assertTrue(reg ~= nil, "registration exists for " .. event)
    reg.target[reg.method](reg.target, event)
end

local inCombat = false
local createdFrames = {}

local env = setmetatable({}, { __index = _G })
env._G = env
env.strlower = string.lower
env.issecretvalue = function()
    return false
end
env.InCombatLockdown = function()
    return inCombat
end
env.CreateFrame = function()
    local frame = { registered = {}, scripts = {} }
    frame.RegisterEvent = function(self, event)
        self.registered[event] = true
    end
    frame.UnregisterEvent = function(self, event)
        self.registered[event] = nil
    end
    frame.SetScript = function(self, scriptType, handler)
        self.scripts[scriptType] = handler
    end
    createdFrames[#createdFrames + 1] = frame
    return frame
end
env.C_Timer = {
    NewTimer = function(_, fn)
        local t = { fn = fn, cancelled = false, executed = false }
        t.Cancel = function(self)
            self.cancelled = true
        end
        timers[#timers + 1] = t
        return t
    end,
}
env.C_Spell = {
    GetSpellName = function()
        return nil
    end,
    DoesSpellExist = function()
        return false
    end,
    GetSpellTexture = function()
        return nil
    end,
}
env.C_Item = {
    GetItemInfoInstant = function()
        return nil
    end,
}

-- ---------------------------------------------------------------------------
-- Load the REAL SpellValidator module into the sandbox.
-- ---------------------------------------------------------------------------

local function loadSpellValidator()
    local candidates = {
        "Data/SpellValidator.lua",
        "../Data/SpellValidator.lua",
        "GRIP/EMS/Data/SpellValidator.lua",
    }
    for _, path in ipairs(candidates) do
        -- loadfile is dev-harness file I/O, intentionally outside the addon WoW std.
        -- selene: allow(undefined_variable)
        local chunk = loadfile(path)
        if chunk then
            setfenv(chunk, env)
            return chunk
        end
    end
    error("could not locate Data/SpellValidator.lua (run from the EMS root)")
end

loadSpellValidator()(ADDON_NAME, GRIPEMS)

local SV = GRIPEMS.SpellValidator
assertTrue(SV ~= nil, "SpellValidator loaded")
assertTrue(type(SV.OnSpellCacheRefreshed) == "function", "OnSpellCacheRefreshed defined")

SV:RegisterCallbacks()

-- Counting spy around ValidateAll: delegates to the real function so T4 still
-- exercises the direct path, while T1 proves the refresh handler never calls it.
local validateAllCalls = 0
local realValidateAll = SV.ValidateAll
SV.ValidateAll = function(self, ...)
    validateAllCalls = validateAllCalls + 1
    return realValidateAll(self, ...)
end

-- ---------------------------------------------------------------------------
-- Cases.
-- ---------------------------------------------------------------------------

test("T1: OOC refresh fires one ping and never calls ValidateAll", function()
    resetFireCounts()
    inCombat = false
    local callsBefore = validateAllCalls
    deliverCallback("SPELL_CACHE_REFRESHED")
    assertEqual(1, activeTimerCount(), "one pending debounce timer")
    runPendingTimers()
    assertEqual(1, pingCount(), "SPELL_VALIDATION_UPDATED fired exactly once")
    assertEqual(callsBefore, validateAllCalls, "ValidateAll not called by the refresh path")
end)

test("T2: in-combat debounce parks the ping until PLAYER_REGEN_ENABLED", function()
    resetFireCounts()
    inCombat = true
    deliverCallback("SPELL_CACHE_REFRESHED")
    runPendingTimers()
    assertEqual(0, pingCount(), "no ping while in combat")
    local frame = createdFrames[#createdFrames]
    assertTrue(frame ~= nil, "regen frame created")
    assertTrue(frame.registered["PLAYER_REGEN_ENABLED"] == true, "PLAYER_REGEN_ENABLED registered")
    assertTrue(type(frame.scripts.OnEvent) == "function", "OnEvent handler set")
    inCombat = false
    frame.scripts.OnEvent(frame, "PLAYER_REGEN_ENABLED")
    assertEqual(1, pingCount(), "ping fired exactly once after regen")
    assertTrue(frame.registered["PLAYER_REGEN_ENABLED"] == nil, "PLAYER_REGEN_ENABLED unregistered")
end)

test("T3: two back-to-back OOC refreshes coalesce to one live timer and one ping", function()
    resetFireCounts()
    inCombat = false
    local timersBefore = #timers
    deliverCallback("SPELL_CACHE_REFRESHED")
    deliverCallback("SPELL_CACHE_REFRESHED")
    assertEqual(2, #timers - timersBefore, "second refresh replaced the first timer")
    assertTrue(timers[timersBefore + 1].cancelled, "first debounce timer cancelled")
    assertEqual(1, activeTimerCount(), "exactly one live debounce timer")
    runPendingTimers()
    assertEqual(1, pingCount(), "coalesced refreshes fire exactly one ping")
end)

test("T4: SV:ValidateAll still returns a result table with a sequences key", function()
    local result = SV:ValidateAll()
    assertTrue(type(result) == "table", "ValidateAll returns a table")
    assertTrue(type(result.sequences) == "table", "result has a sequences table")
    assertTrue(result.sequences.Seq ~= nil, "the Seq sequence was validated")
    assertEqual(0, result.sequences.Seq.staleCount, "known spell yields zero stale entries")
    assertEqual(1, #result.sequences.Seq.steps, "one step validated")
end)

test("T5: regen frame is reused across combat parks", function()
    resetFireCounts()
    inCombat = true
    deliverCallback("SPELL_CACHE_REFRESHED")
    runPendingTimers()
    local framesAfterFirst = #createdFrames
    local f1 = createdFrames[#createdFrames]
    inCombat = false
    f1.scripts.OnEvent(f1, "PLAYER_REGEN_ENABLED")
    assertEqual(1, pingCount(), "first park pings once")
    inCombat = true
    deliverCallback("SPELL_CACHE_REFRESHED")
    runPendingTimers()
    assertEqual(framesAfterFirst, #createdFrames, "no new frame on second park (reuse)")
    assertTrue(f1.registered["PLAYER_REGEN_ENABLED"] == true, "same frame re-registered")
    inCombat = false
    f1.scripts.OnEvent(f1, "PLAYER_REGEN_ENABLED")
    assertEqual(2, pingCount(), "second park pings once more")
end)

-- ---------------------------------------------------------------------------
-- Run.
-- ---------------------------------------------------------------------------

local passed = 0
local failed = 0
for _, t in ipairs(tests) do
    local ok, err = pcall(t.fn)
    if ok then
        passed = passed + 1
        print("PASS  " .. t.name)
    else
        failed = failed + 1
        print("FAIL  " .. t.name .. " -- " .. tostring(err))
    end
end
print(string.format("RESULT %d passed, %d failed", passed, failed))
os.exit(failed > 0 and 1 or 0)
