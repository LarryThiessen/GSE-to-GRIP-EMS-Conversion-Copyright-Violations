-- GRIP-EMS: Per-Element Theming editor -- 5-slot save/load (Phase B)
--
-- Created:    2026-04-22
-- Updated:    2026-06-21
-- Patch: 12.0.7.68256 Midnight (Retail LIVE)
--
-- BuildSlotArgs() returns the 5-slot save/load AceConfig subtree. Save
-- captures profile.theming.elements + preset into savedThemes[i]. Load
-- overwrites elements and calls Theme.ApplyTheme. Overwrite on a
-- non-empty slot routes through a StaticPopupDialog confirmation.

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

GRIPEMS.UI = GRIPEMS.UI or {}
local UI = GRIPEMS.UI
UI.ThemingEditor = UI.ThemingEditor or {}
local TE = UI.ThemingEditor

local SLOT_COUNT = 5

local function profileTheming()
    local S = GRIPEMS.Settings
    if not (S and S.db and S.db.profile) then
        return nil
    end
    S.db.profile.theming = S.db.profile.theming or { preset = "default", elements = {}, savedThemes = {} }
    S.db.profile.theming.elements = S.db.profile.theming.elements or {}
    S.db.profile.theming.savedThemes = S.db.profile.theming.savedThemes or {}
    return S.db.profile.theming
end

local function deepCopy(t)
    if type(t) ~= "table" then
        return t
    end
    local c = {}
    for k, v in pairs(t) do
        if type(v) == "table" then
            local inner = {}
            for kk, vv in pairs(v) do
                inner[kk] = vv
            end
            c[k] = inner
        else
            c[k] = v
        end
    end
    return c
end

local function slotAt(i)
    local t = profileTheming()
    return t and t.savedThemes[i] or nil
end
local function isEmpty(i)
    return slotAt(i) == nil
end
local function notify()
    LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
end

local function slotName(i)
    local s = slotAt(i)
    if s and type(s.name) == "string" and s.name ~= "" then
        return s.name
    end
    return L["ACCESS_THEMING_SLOT_EMPTY"] or "(empty)"
end

local function saveSlot(i, customName)
    local t = profileTheming()
    if not t then
        return
    end
    local existing = t.savedThemes[i]
    local name = customName
    if not name or name == "" then
        name = (existing and existing.name) or string.format(L["ACCESS_THEMING_SLOT_DEFAULT_NAME"] or "Theme %d", i)
    end
    t.savedThemes[i] = {
        name = name,
        preset = t.preset or "default",
        elements = deepCopy(t.elements or {}),
    }
    TE._activeSlot = i
    notify()
end

local function loadSlot(i)
    local t = profileTheming()
    local s = t and t.savedThemes[i]
    if not s then
        return
    end
    t.elements = deepCopy(s.elements or {})
    t.preset = s.preset or "default"
    TE._activeSlot = i
    if GRIPEMS.Theme and GRIPEMS.Theme.ApplyTheme then
        GRIPEMS.Theme.ApplyTheme()
    end
    notify()
end

local function renameSlot(i, newName)
    local s = slotAt(i)
    if s and type(newName) == "string" and newName ~= "" then
        s.name = newName
    end
    notify()
end

local function clearSlot(i)
    local t = profileTheming()
    if t then
        t.savedThemes[i] = nil
    end
    notify()
end

if not GRIPEMS.Popup:GetDef("GRIP_EMS_THEME_OVERWRITE_SLOT") then
    GRIPEMS.Popup:Define("GRIP_EMS_THEME_OVERWRITE_SLOT", {
        text = L["ACCESS_THEMING_SLOT_OVERWRITE_CONFIRM"] or "Overwrite slot %d (%s)?",
        button1 = YES or "Yes",
        button2 = NO or "No",
        OnAccept = function(self, data)
            if data and data.index then
                saveSlot(data.index, data.name)
            end
        end,
        timeout = 0,
        hideOnEscape = true,
    })
end

local function requestSave(i, currentName)
    if isEmpty(i) then
        saveSlot(i, currentName)
        return
    end
    GRIPEMS.Popup:Show("GRIP_EMS_THEME_OVERWRITE_SLOT", i, slotName(i), { index = i, name = currentName })
end

local function scratchAt(i)
    TE._slotNameScratch = TE._slotNameScratch or {}
    return TE._slotNameScratch[i]
end
local function setScratch(i, v)
    TE._slotNameScratch = TE._slotNameScratch or {}
    TE._slotNameScratch[i] = v
end

local function buildRow(i, order)
    return {
        type = "group",
        inline = true,
        name = "",
        order = order,
        args = {
            nameField = {
                type = "input",
                order = 1,
                name = L["ACCESS_THEMING_SLOT_NAME"] or "Name",
                get = function()
                    local s = scratchAt(i)
                    return s ~= nil and s or slotName(i)
                end,
                set = function(_, v)
                    setScratch(i, v)
                end,
            },
            save = {
                type = "execute",
                order = 2,
                name = L["ACCESS_THEMING_SLOT_SAVE"] or "Save",
                func = function()
                    requestSave(i, scratchAt(i))
                    setScratch(i, nil)
                end,
            },
            load = {
                type = "execute",
                order = 3,
                name = L["ACCESS_THEMING_SLOT_LOAD"] or "Load",
                disabled = function()
                    return isEmpty(i)
                end,
                func = function()
                    loadSlot(i)
                end,
            },
            rename = {
                type = "execute",
                order = 4,
                name = L["ACCESS_THEMING_SLOT_RENAME"] or "Rename",
                disabled = function()
                    return isEmpty(i)
                end,
                func = function()
                    renameSlot(i, scratchAt(i))
                    setScratch(i, nil)
                end,
            },
            clear = {
                type = "execute",
                order = 5,
                name = L["ACCESS_THEMING_SLOT_CLEAR"] or "Clear",
                disabled = function()
                    return isEmpty(i)
                end,
                confirm = true,
                confirmText = L["ACCESS_THEMING_SLOT_CLEAR_CONFIRM"] or "Clear this slot?",
                func = function()
                    clearSlot(i)
                    setScratch(i, nil)
                end,
            },
        },
    }
end

function TE.BuildSlotArgs()
    local args = {
        header = { type = "header", order = 1, name = L["ACCESS_THEMING_SLOTS_HEADER"] or "Saved Themes" },
        description = { type = "description", order = 2, name = L["ACCESS_THEMING_SLOTS_DESC"] or "" },
    }
    for i = 1, SLOT_COUNT do
        args["slot" .. i] = buildRow(i, 10 + i)
    end
    return args
end

--- Returns the slot index most recently loaded or saved into.
--- Falls back to 1 when no slot has been touched this session.
function TE.GetActiveSlot()
    local s = tonumber(TE._activeSlot)
    if s and s >= 1 and s <= 5 then
        return s
    end
    return 1
end

-- end of UI/ThemingEditor/SlotManager.lua
