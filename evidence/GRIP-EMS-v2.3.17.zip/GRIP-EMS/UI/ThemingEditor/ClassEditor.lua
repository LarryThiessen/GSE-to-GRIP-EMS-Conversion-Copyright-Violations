-- GRIP-EMS: Per-Element Theming editor -- per-class controls (Phase B)
--
-- Created:    2026-04-22
-- Updated:    2026-06-21
-- Patch: 12.0.7.68256 Midnight (Retail LIVE)
--
-- BuildClassArgs(class) returns the per-class AceConfig leaf: color pickers,
-- swatch quick-pick, alpha/size sliders, font dropdown (LSM-backed), and
-- reset. Controls are emitted conditionally based on fields in
-- UI.DEFAULT_THEME[class]. TE.SWATCH_PALETTE decodes once at module load.

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

GRIPEMS.UI = GRIPEMS.UI or {}
local UI = GRIPEMS.UI
UI.ThemingEditor = UI.ThemingEditor or {}
local TE = UI.ThemingEditor

-- 64-swatch palette: grayscale, dark panel, mid panel, warm text, cool text,
-- green text, semantic, accent. Decoded to RGBA once below.
local PALETTE_HEX = {
    "#000000",
    "#1a1a1a",
    "#333333",
    "#4d4d4d",
    "#666666",
    "#808080",
    "#b3b3b3",
    "#ffffff",
    "#0f1419",
    "#1e2a3a",
    "#2a1e3a",
    "#3a1e2a",
    "#1e3a2a",
    "#3a2a1e",
    "#2a3a1e",
    "#1e3a3a",
    "#2c3e50",
    "#34495e",
    "#4a3f5e",
    "#5e3f4a",
    "#3f5e4a",
    "#5e4a3f",
    "#4a5e3f",
    "#3f5e5e",
    "#fff8e7",
    "#ffe4b5",
    "#ffd700",
    "#ffb347",
    "#ff8c42",
    "#e67e22",
    "#d35400",
    "#a04000",
    "#e6f2ff",
    "#b3d9ff",
    "#66b2ff",
    "#4a9eff",
    "#3080d0",
    "#2060a0",
    "#104570",
    "#082040",
    "#d9fff2",
    "#7ae599",
    "#52c878",
    "#2ecc71",
    "#1e8449",
    "#145a32",
    "#0f3d22",
    "#082416",
    "#ff6b6b",
    "#ff4444",
    "#cc2222",
    "#ffa726",
    "#fff176",
    "#81c784",
    "#4fc3f7",
    "#ba68c8",
    "#f39c12",
    "#e74c3c",
    "#9b59b6",
    "#3498db",
    "#1abc9c",
    "#2ecc71",
    "#f1c40f",
    "#ecf0f1",
}

TE.SWATCH_PALETTE = {}
local SWATCH_LABELS = {}
for i = 1, #PALETTE_HEX do
    local hex = PALETTE_HEX[i]
    local r = tonumber(hex:sub(2, 3), 16) / 255
    local g = tonumber(hex:sub(4, 5), 16) / 255
    local b = tonumber(hex:sub(6, 7), 16) / 255
    TE.SWATCH_PALETTE[i] = { r = r, g = g, b = b, a = 1.0, hex = hex }
    SWATCH_LABELS[i] = hex
end

local function groupOfClass(class)
    local dot = class:find("%.")
    return dot and class:sub(1, dot - 1) or class
end

local function profileTheming()
    local S = GRIPEMS.Settings
    if not (S and S.db and S.db.profile) then
        return nil
    end
    S.db.profile.theming = S.db.profile.theming or { preset = "default", elements = {}, savedThemes = {} }
    S.db.profile.theming.elements = S.db.profile.theming.elements or {}
    S.db.profile.theming.savedThemes = S.db.profile.theming.savedThemes or {}
    return S.db.profile.theming
end

local function getField(class, field)
    local t = profileTheming()
    local o = t and t.elements[class]
    if o and o[field] ~= nil then
        return o[field]
    end
    local d = UI.DEFAULT_THEME and UI.DEFAULT_THEME[class]
    return d and d[field] or nil
end

local function setField(class, field, value)
    local t = profileTheming()
    if not t then
        return
    end
    t.elements[class] = t.elements[class] or {}
    t.elements[class][field] = value
    if GRIPEMS.Theme and GRIPEMS.Theme.ApplyElement then
        GRIPEMS.Theme.ApplyElement(class)
    end
end

local function makeColorArgs(class, field, nameKey, baseOrder)
    return {
        type = "color",
        name = L[nameKey] or nameKey,
        hasAlpha = true,
        order = baseOrder,
        get = function()
            local c = getField(class, field) or { 0, 0, 0, 1 }
            return c[1] or 0, c[2] or 0, c[3] or 0, (c[4] == nil) and 1 or c[4]
        end,
        set = function(_, r, g, b, a)
            setField(class, field, { r, g, b, a })
        end,
    }, {
        type = "select",
        dialogControl = "GRIPEMS_SwatchGrid",
        name = L["ACCESS_THEMING_SWATCH_ADVANCED"] or "Swatch",
        order = baseOrder + 1,
        width = "full",
        values = SWATCH_LABELS,
        get = function()
            return nil
        end,
        set = function(_, idx)
            local s = TE.SWATCH_PALETTE[idx]
            if s then
                setField(class, field, { s.r, s.g, s.b, s.a })
            end
        end,
    }
end

function TE.BuildClassArgs(class)
    local default = (UI.DEFAULT_THEME and UI.DEFAULT_THEME[class]) or {}
    local group = groupOfClass(class)
    local args = {}
    local o = 1

    if default.bg then
        args.bgColor, args.bgSwatch = makeColorArgs(class, "bg", "ACCESS_THEMING_FIELD_BG", o)
        o = o + 10
    end
    if default.border then
        args.borderColor, args.borderSwatch = makeColorArgs(class, "border", "ACCESS_THEMING_FIELD_BORDER", o)
        o = o + 10
    end

    local textField
    if group == "text" and default.color then
        textField = "color"
    elseif (group == "overlay" or group == "button" or group == "emphasis") and default.text then
        textField = "text"
    end
    if textField then
        args.textColor, args.textSwatch = makeColorArgs(class, textField, "ACCESS_THEMING_FIELD_TEXT", o)
        o = o + 10
    end

    if default.alpha ~= nil then
        args.alpha = {
            type = "range",
            name = L["ACCESS_THEMING_FIELD_ALPHA"] or "Alpha",
            order = o,
            min = 0.0,
            max = 1.0,
            step = 0.05,
            get = function()
                local v = getField(class, "alpha")
                return (v ~= nil) and v or 1.0
            end,
            set = function(_, v)
                setField(class, "alpha", v)
            end,
        }
        o = o + 10
    end

    if group == "panel" then
        args.bgTexture = {
            type = "select",
            name = L["ACCESS_THEMING_FIELD_BG_TEXTURE"] or "Background texture",
            desc = L["ACCESS_THEMING_FIELD_BG_TEXTURE_DESC"] or "",
            order = o,
            dialogControl = "LSM30_Background",
            values = function()
                local LSM = LibStub and LibStub("LibSharedMedia-3.0", true)
                return (LSM and LSM:HashTable("background")) or {}
            end,
            get = function()
                return getField(class, "bgTexture")
            end,
            set = function(_, v)
                setField(class, "bgTexture", v)
            end,
        }
        o = o + 10
        args.borderTexture = {
            type = "select",
            name = L["ACCESS_THEMING_FIELD_BORDER_TEXTURE"] or "Border texture",
            desc = L["ACCESS_THEMING_FIELD_BORDER_TEXTURE_DESC"] or "",
            order = o,
            dialogControl = "LSM30_Border",
            values = function()
                local LSM = LibStub and LibStub("LibSharedMedia-3.0", true)
                return (LSM and LSM:HashTable("border")) or {}
            end,
            get = function()
                return getField(class, "borderTexture")
            end,
            set = function(_, v)
                setField(class, "borderTexture", v)
            end,
        }
        o = o + 10
    end

    if group == "text" or group == "global" then
        args.font = {
            type = "select",
            name = L["ACCESS_THEMING_FIELD_FONT"] or "Font",
            desc = L["ACCESS_THEMING_FIELD_FONT_DESC"] or "",
            order = o,
            dialogControl = "LSM30_Font",
            values = function()
                local LSM = LibStub and LibStub("LibSharedMedia-3.0", true)
                return (LSM and LSM:HashTable("font")) or { ["Friz Quadrata TT"] = "Friz Quadrata TT" }
            end,
            get = function()
                return getField(class, "font") or "Friz Quadrata TT"
            end,
            set = function(_, v)
                setField(class, "font", v)
            end,
        }
        o = o + 10
    end

    if group == "text" then
        args.size = {
            type = "range",
            name = L["ACCESS_THEMING_FIELD_SIZE"] or "Size",
            order = o,
            min = 8,
            max = 32,
            step = 1,
            get = function()
                return getField(class, "fontSize") or 12
            end,
            set = function(_, v)
                setField(class, "fontSize", v)
            end,
        }
    end

    args.reset = {
        type = "execute",
        name = L["ACCESS_THEMING_RESET_CLASS"] or "Reset",
        desc = L["ACCESS_THEMING_RESET_CLASS_DESC"] or "",
        order = 999,
        func = function()
            local t = profileTheming()
            if not t then
                return
            end
            t.elements[class] = nil
            if GRIPEMS.Theme and GRIPEMS.Theme.ApplyTheme then
                GRIPEMS.Theme.ApplyTheme()
            end
            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
        end,
    }

    return {
        type = "group",
        name = function()
            local label = (TE.FormatClassLabel and TE.FormatClassLabel(class)) or class
            if not (GRIPEMS.Theme and GRIPEMS.Theme.CheckContrast) then
                return label
            end
            local ok = GRIPEMS.Theme.CheckContrast(class)
            local icon = ok and (L["ACCESS_THEMING_CONTRAST_BADGE_PASS"] or "")
                or (L["ACCESS_THEMING_CONTRAST_BADGE_FAIL"] or "")
            if icon ~= "" then
                return icon .. " " .. label
            end
            return label
        end,
        args = args,
    }
end

-- end of UI/ThemingEditor/ClassEditor.lua
