-- GRIP-EMS: Settings Panel
-- AceConfig options table + Blizzard Settings integration + AceDBOptions profiles

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS")

GRIPEMS.SettingsPanel = {}
local SP = GRIPEMS.SettingsPanel

--- Initialize the settings panel. Registers AceConfig options and adds
--- to the Blizzard Settings panel. Called from Core.lua PLAYER_LOGIN.
function SP:Initialize()
    local AceConfig = LibStub("AceConfig-3.0")
    local AceConfigDialog = LibStub("AceConfigDialog-3.0")
    local AceDBOptions = LibStub("AceDBOptions-3.0")
    local S = GRIPEMS.Settings

    GRIPEMS:Debug("SettingsPanel:Initialize() - db exists: "
        .. tostring(S:GetDB() ~= nil))

    local options = {
        type = "group",
        name = "GRIP-EMS",
        childGroups = "tab",
        args = {
            headerDesc = {
                type = "description",
                name = L["GEMS_SETTINGS_HEADER_DESC"],
                order = 1,
                fontSize = "medium",
            },
            general = {
                type = "group",
                name = L["GEMS_SETTINGS_GENERAL"],
                order = 10,
                args = {
                    clickRate = {
                        type = "range",
                        name = L["GEMS_SETTINGS_CLICK_RATE"],
                        desc = L["GEMS_SETTINGS_CLICK_RATE_DESC"],
                        order = 1,
                        min = 100, max = 1000, step = 10,
                        get = function() return S:Get("clickRate") end,
                        set = function(_, v) S:Set("clickRate", v) end,
                        width = "double",
                    },
                    oocDelay = {
                        type = "range",
                        name = L["GEMS_SETTINGS_OOC_DELAY"],
                        desc = L["GEMS_SETTINGS_OOC_DELAY_DESC"],
                        order = 2,
                        min = 1, max = 60, step = 1,
                        get = function() return S:Get("oocDelay") end,
                        set = function(_, v) S:Set("oocDelay", v) end,
                        width = "double",
                    },
                    resetOOC = {
                        type = "toggle",
                        name = L["GEMS_SETTINGS_RESET_OOC"],
                        desc = L["GEMS_SETTINGS_RESET_OOC_DESC"],
                        order = 3,
                        get = function() return S:Get("resetOOC") end,
                        set = function(_, v) S:Set("resetOOC", v) end,
                        width = "full",
                    },
                },
            },
            ui = {
                type = "group",
                name = L["GEMS_SETTINGS_UI"],
                order = 20,
                args = {
                    hideLoginMsg = {
                        type = "toggle",
                        name = L["GEMS_SETTINGS_HIDE_LOGIN"],
                        desc = L["GEMS_SETTINGS_HIDE_LOGIN_DESC"],
                        order = 1,
                        get = function() return S:Get("hideLoginMsg") end,
                        set = function(_, v) S:Set("hideLoginMsg", v) end,
                        width = "full",
                    },
                    debug = {
                        type = "toggle",
                        name = L["GEMS_SETTINGS_DEBUG"],
                        desc = L["GEMS_SETTINGS_DEBUG_DESC"],
                        order = 2,
                        get = function() return S:Get("debug") end,
                        set = function(_, v) S:Set("debug", v) end,
                        width = "full",
                    },
                },
            },
            sharing = {
                type = "group",
                name = L["GEMS_P2P_ENABLED"],
                order = 25,
                args = {
                    p2pEnabled = {
                        type = "toggle",
                        name = L["GEMS_P2P_ENABLED"],
                        desc = L["GEMS_P2P_ENABLED_DESC"],
                        order = 1,
                        get = function() return S:Get("p2pEnabled") end,
                        set = function(_, v) S:Set("p2pEnabled", v) end,
                        width = "full",
                    },
                    p2pAutoAcceptFriends = {
                        type = "toggle",
                        name = L["GEMS_P2P_AUTO_FRIENDS"],
                        desc = L["GEMS_P2P_AUTO_FRIENDS_DESC"],
                        order = 2,
                        get = function() return S:Get("p2pAutoAcceptFriends") end,
                        set = function(_, v) S:Set("p2pAutoAcceptFriends", v) end,
                        width = "full",
                    },
                    p2pAnnounceReceive = {
                        type = "toggle",
                        name = L["GEMS_P2P_ANNOUNCE"],
                        desc = L["GEMS_P2P_ANNOUNCE_DESC"],
                        order = 3,
                        get = function() return S:Get("p2pAnnounceReceive") end,
                        set = function(_, v) S:Set("p2pAnnounceReceive", v) end,
                        width = "full",
                    },
                },
            },
            info = {
                type = "group",
                name = L["GEMS_SETTINGS_INFO"],
                order = 30,
                args = {
                    version = {
                        type = "description",
                        name = function()
                            return string.format(
                                L["GEMS_SETTINGS_VERSION_INFO"],
                                GRIPEMS.version or "dev",
                                GRIPEMS.Engine
                                    and GRIPEMS.Engine:GetActiveCount()
                                    or 0)
                        end,
                        order = 1,
                        fontSize = "medium",
                    },
                    author = {
                        type = "description",
                        name = L["GEMS_ABOUT_AUTHOR"],
                        order = 2,
                    },
                    links = {
                        type = "description",
                        name = L["GEMS_ABOUT_LINKS"],
                        order = 3,
                    },
                    statusHeader = {
                        type = "header",
                        name = "",
                        order = 10,
                    },
                    status = {
                        type = "description",
                        name = function()
                            local lines = {}
                            -- Keybind count
                            local bindCount = 0
                            local KM = GRIPEMS.KeybindManager
                            if KM then
                                local binds = KM:GetAllKeybinds()
                                if binds then
                                    for _ in pairs(binds) do
                                        bindCount = bindCount + 1
                                    end
                                end
                            end
                            table.insert(lines, string.format(
                                L["GEMS_ABOUT_KEYBINDS"], bindCount))
                            -- OOC queue
                            local oocCount = 0
                            if GRIPEMS.OOCQueue then
                                oocCount = GRIPEMS.OOCQueue:GetCount()
                            end
                            table.insert(lines, string.format(
                                L["GEMS_ABOUT_OOC_QUEUE"], oocCount))
                            -- Migration source status
                            local gseStatus = "Not detected"
                            if GRIPEMS.GSEMigrate then
                                local gs = GRIPEMS.GSEMigrate.GetGSEStatus()
                                if gs == "active" then
                                    gseStatus = "Active (migration available)"
                                elseif gs == "disabled" then
                                    gseStatus = "Disabled"
                                end
                            end
                            table.insert(lines, string.format(
                                L["GEMS_ABOUT_GSE_STATUS"], gseStatus))
                            -- Macro slots
                            local D = GRIPEMS.Defaults
                            local _, perChar = GetNumMacros()
                            table.insert(lines, string.format(
                                L["GEMS_ABOUT_MACRO_SLOTS"], perChar, D.MAX_PER_CHAR_MACROS))
                            return table.concat(lines, "\n")
                        end,
                        order = 11,
                        fontSize = "medium",
                    },
                },
            },
        },
    }

    -- Add Profiles tab via AceDBOptions
    local db = S:GetDB()
    if db then
        options.args.profiles = AceDBOptions:GetOptionsTable(db)
        options.args.profiles.order = 40
    else
        GRIPEMS:Debug("SettingsPanel: AceDB not available for profiles tab")
    end

    -- Register with AceConfig
    AceConfig:RegisterOptionsTable("GRIP-EMS", options)

    -- Register with Blizzard Settings panel
    AceConfigDialog:AddToBlizOptions("GRIP-EMS", "|cFF00CC66GRIP|r-EMS")
end

--- Open the settings panel programmatically.
function SP:Open()
    LibStub("AceConfigDialog-3.0"):Open("GRIP-EMS")
end
