-- GRIP-EMS: Headless test for three SavedVariables writers that had no test
--
-- Created:    2026-08-17
-- Updated:    2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.
--
-- SE:OnKeyPressChanged and SE:OnKeyReleaseChanged are the ONLY route by which a
-- player's typed keyPress and keyRelease text reaches SavedVariables. That field
-- pairing produced two shipped defects in three releases: v2.4.2 wrote transient
-- override text into persisted steps, and v2.4.5 showed the keypress spell on
-- every tracker row. Neither writer was named by any test.
--
-- VS:Rename mutates _G.GRIP_EMS_CHAR.sequences IN PLACE across BOTH the
-- versioned layout and the legacy flat layout. The only suite that loaded
-- Data/VariableStore.lua headless seeded GRIP_EMS_DB but never GRIP_EMS_CHAR, so
-- the sequence rewrite loop had never executed in any test: the `if` at
-- Data/VariableStore.lua:316 passed on a TRUTHY catch-all stub, pairs() over that
-- stub yielded nothing, and the loop body was never entered. W4 and W5 exist
-- because of that specific trap, and the F2 falsification below is what proves
-- they are not still sitting in it.
--
-- Run from the EMS root:  lua Test/test_writeset_persisted_fields.lua
-- Exit code 0 = all passed, 1 = at least one failure.
--
-- Cases:
--   W1  SE:OnKeyPressChanged persists the typed text to the SavedVariables row
--   W2  every guard blocks the write, and blocking leaves the row untouched
--   W3  SE:OnKeyReleaseChanged persists the typed text to the SavedVariables row
--   W4  VS:Rename rewrites the VERSIONED layout in place
--   W5  VS:Rename rewrites the LEGACY FLAT layout in place
--   W6  the rewrite is targeted, not a blanket substitution
--
-- TWO ISOLATED SANDBOXES, each with its own env, its own catch-all stub and its
-- own holder table. Nothing is shared between them. UI/SequenceEditor.lua and
-- Data/VariableStore.lua both bind file-scope upvalues off the holder at load
-- time, so a holder shaped for one is actively wrong for the other.
--
-- STUB AUDIT -- SANDBOX 1 (SequenceEditor).
--   UI/SequenceEditor.lua  loaded FOR REAL through the LoadIsolated shape proved
--                         in Test/test_v0_upgrade_guard.lua:383. The three
--                         writers under test are the shipped implementations.
--   GRIPEMS.Engine        a HAND-BUILT recorder, rawset BEFORE the load. The real
--                         Engine/Engine.lua is deliberately NOT loaded:
--                         Engine:UpdateSequenceData handles engine rewrap,
--                         activation and locale normalisation, and NONE of that is
--                         the persistence mechanism under test. Persistence
--                         happens because entry.data ALIASES the SavedVariables
--                         row -- the comment at UI/SequenceEditor.lua:3882 states
--                         exactly this ("the data mutation persists at logout
--                         either way (entry.data aliases the SV row)"). W1(d) and
--                         W3(d) pin that alias BY IDENTITY, so a future refactor
--                         that copies instead of aliasing reddens this file.
--                         This is the vacuous-green trap the F1 falsification
--                         exists to catch: left to the holder's catch-all,
--                         GRIPEMS.Engine answers a truthy stub, engine.sequences
--                         answers a truthy stub, entry.data answers a truthy stub,
--                         and type(stub.versions) really IS "table" -- so
--                         SE:GetEditingVersion returns a STUB and `ver.keyPress =
--                         text` writes into it. Every guard is passed, the
--                         function runs to completion, and the SavedVariables row
--                         is never touched.
--   GRIPEMS.StepListView  a real recorder carrying RefreshAll. The writers assign
--                         SLV.keyPressLen / SLV.keyReleaseLen, which is the 255-cap
--                         accounting the status label reads. LIVE: the real step
--                         list, whose RefreshAll redraws every row.
--   GRIPEMS.UI            a real table carrying Colors, whose every key answers a
--                         table with GetRGBA. SequenceEditor binds `local UI =
--                         GRIPEMS.UI` at file scope (line 13), BEFORE
--                         GRIPEMS.SequenceEditor is assigned, so this must be
--                         rawset ahead of the load or the upvalue captures a stub.
--   env.C_Timer           an EXPLICIT table whose After RECORDS the callback and
--                         does NOT run it. The debounced re-sign flush is out of
--                         scope here. Left to the catch-all, After would be a
--                         truthy callable stub that swallows the arm silently, and
--                         nothing would distinguish armed from not-armed.
--   env.CreateFrame       returns a frame stub. UI/SequenceEditor.lua calls
--                         CreateFrame("Frame") at FILE scope (line 3884) for the
--                         PLAYER_LOGOUT quick-resign flusher, so the load itself
--                         needs it.
--   SE.kpStatusLabel      DELIBERATELY left nil, and this is an exclusion rather
--   SE.saveBtn            than an oversight. SE:UpdateKeyPressStatus returns at
--   SE.discardBtn         its first line when kpStatusLabel is nil (line 4219) and
--                         SE:UpdateSaveButtons returns at its first line when
--                         saveBtn or discardBtn is nil (line 4694), so both are
--                         inert. Note SE carries a metatable whose __index answers
--                         nil for every key except editBoxFocused (line 27), so
--                         these read nil rather than falling through to a stub.
--                         Neither function writes to SavedVariables; both are
--                         widget refresh, and no case here observes a widget.
--   GRIPEMS.OOCQueue      IsRestricted answers false. Only UpdateSaveButtons reads
--                         it, past a guard that already returned, so it exists for
--                         shape rather than for reach.
--
-- STUB AUDIT -- SANDBOX 2 (VariableStore).
--   Data/VariableStore.lua  loaded FOR REAL. VS:Rename is the shipped one.
--   GRIPEMS.Defaults      a REAL table carrying VAR_MAX_NAME = 32 and VAR_PATTERN
--                         = "~([%w_]+)~", both verbatim from Data/Defaults.lua
--                         lines 1057 and 1056. The module binds `local D =
--                         GRIPEMS.Defaults` at file scope (line 11) as an upvalue,
--                         and VS:ValidateName compares #name against D.VAR_MAX_NAME
--                         (line 719) -- against a stub table that comparison raises,
--                         so Rename would never reach its rewrite loop.
--   env.GRIP_EMS_DB       { variables = {}, config = {} }, the shape proved in
--                         Test/test_variable_sandbox_and_noredistribute.lua:430.
--   env.GRIP_EMS_CHAR     a REAL table carrying sequences. THIS IS THE WHOLE POINT
--                         OF W4 AND W5 -- see the F2 note in the header above.
--   env.time              os.time. Left to the catch-all, `varDef.updatedAt =
--                         time()` (line 297) assigns a stub TABLE where the field
--                         is documented as a number.
--   VS:Create             does not exist -- the module's CRUD surface is
--                         Set/Get/GetAll/Delete/Rename, verified by enumerating
--                         every `function VS:` in the file. The Old definition is
--                         therefore written straight into GRIP_EMS_DB.variables,
--                         carrying only the fields Rename and
--                         RebuildEventRegistration actually read: name, plus
--                         events = "" so the event-registration sweep skips it.
--   env.CreateFrame       catch-all. VS:RebuildEventRegistration (called by Rename
--                         at line 341) makes an event frame and calls
--                         UnregisterAllEvents / SetScript on it. With events = ""
--                         on the only definition, its register/unregister diff runs
--                         over an empty set. No case observes an event.

local ADDON_NAME = "GRIP-EMS"

-- ---------------------------------------------------------------------------
-- Minimal assertion + runner harness.
-- ---------------------------------------------------------------------------

local tests = {}

local function test(name, fn)
    tests[#tests + 1] = { name = name, fn = fn }
end

local function assertEqual(expected, actual, label)
    if expected ~= actual then
        error((label or "value") .. ": expected " .. tostring(expected) .. ", got " .. tostring(actual), 2)
    end
end

local function assertNotEqual(unexpected, actual, label)
    if unexpected == actual then
        error((label or "value") .. ": expected anything BUT " .. tostring(unexpected), 2)
    end
end

local function assertTrue(cond, label)
    if not cond then
        error((label or "condition") .. " failed", 2)
    end
end

-- ---------------------------------------------------------------------------
-- Sandbox construction. Each sandbox gets its OWN stub and its OWN env so a
-- write in one cannot be observed in the other.
-- ---------------------------------------------------------------------------

--- A self-referential no-op: indexing it returns itself, calling it returns
--- itself. Backs every global and every holder field not explicitly seeded.
local function NewStub()
    local s = {}
    setmetatable(s, {
        __index = function()
            return s
        end,
        __call = function()
            return s
        end,
    })
    return s
end

-- AceLocale stand-in: every key echoes back as a STRING, so L["KEY"]:format(...)
-- stays valid. A stub table here would raise on the :format call.
local LOCALE = setmetatable({}, {
    __index = function(_, k)
        return k
    end,
})

--- A sandbox global table. Real stdlib falls through to _G; everything else
--- answers the sandbox's own stub.
local function NewEnv(stub)
    local e = setmetatable({}, {
        __index = function(_, k)
            local v = rawget(_G, k)
            if v ~= nil then
                return v
            end
            return stub
        end,
    })
    e._G = e
    e.LibStub = function()
        return {
            GetLocale = function()
                return LOCALE
            end,
        }
    end
    return e
end

--- Load a shipped module into a PRE-BUILT env and holder. Same shape as
--- LoadIsolated in Test/test_v0_upgrade_guard.lua:383, split so the caller can
--- seed the env before the chunk runs -- which is mandatory here, because both
--- modules capture file-scope upvalues off the holder at load time.
local function LoadInto(paths, holder, ienv)
    for _, path in ipairs(paths) do
        -- loadfile is dev-harness file I/O, intentionally outside the addon WoW std.
        -- selene: allow(undefined_variable)
        local chunk = loadfile(path)
        if chunk then
            setfenv(chunk, ienv)
            chunk(ADDON_NAME, holder)
            return true
        end
    end
    return false
end

-- ===========================================================================
-- SANDBOX 1 -- UI/SequenceEditor.lua
-- ===========================================================================

local seStub = NewStub()
local seEnv = NewEnv(seStub)

-- EXPLICIT, never the catch-all. SE:_QueueQuickResign arms through
-- C_Timer.After (line 3859); recording without running keeps the debounced
-- re-sign flush out of scope while still leaving the arm observable.
local timerArmed = {}
seEnv.C_Timer = {
    After = function(delay, fn)
        timerArmed[#timerArmed + 1] = { delay = delay, fn = fn }
    end,
}

-- UI/SequenceEditor.lua builds the PLAYER_LOGOUT quick-resign flusher at FILE
-- scope, so the load itself needs a frame. Nothing here observes a widget.
local seFrameStub = NewStub()
seEnv.CreateFrame = function()
    return seFrameStub
end

-- The holder. Every unseeded field answers the catch-all; the tables the writers
-- actually consult are rawset below, BEFORE the load, so the module's file-scope
-- upvalues capture the real recorders instead of the stub.
local seHolder = setmetatable({}, {
    __index = function()
        return seStub
    end,
})

rawset(seHolder, "UI", {
    Colors = setmetatable({}, {
        __index = function()
            return {
                GetRGBA = function()
                    return 1, 1, 1, 1
                end,
            }
        end,
    }),
})

-- The Engine recorder. UpdateSequenceData appends and does nothing else: what
-- W1(d) and W3(d) read off this log is the ALIAS between the engine entry's data
-- field and the SavedVariables row, which is the persistence mechanism itself.
local engineLog = {}
local Engine = {
    sequences = {},
    UpdateSequenceData = function(_, name, seqData)
        engineLog[#engineLog + 1] = { name = name, data = seqData }
    end,
}
-- F1 DELETES EXACTLY THIS LINE. With it gone the holder's catch-all supplies a
-- truthy stub Engine, every guard is passed, and the write lands in the stub.
rawset(seHolder, "Engine", Engine)

local StepListView = {
    RefreshAll = function() end,
}
rawset(seHolder, "StepListView", StepListView)

rawset(seHolder, "OOCQueue", {
    IsRestricted = function()
        return false
    end,
})
rawset(seHolder, "Defaults", {
    MAX_MACROTEXT_LENGTH = 255,
    MAX_SAB_MACROTEXT_LENGTH = 255,
    STEP_SEQUENTIAL = "Sequential",
    VAR_PATTERN = "~([%w_]+)~",
})
rawset(seHolder, "Fire", function() end)
rawset(seHolder, "Debug", function() end)
rawset(seHolder, "Print", function() end)

assertTrue(
    LoadInto({
        "UI/SequenceEditor.lua",
        "../UI/SequenceEditor.lua",
        "GRIP/EMS/UI/SequenceEditor.lua",
    }, seHolder, seEnv),
    "could not locate UI/SequenceEditor.lua (run from the EMS root)"
)

local SE = rawget(seHolder, "SequenceEditor")
assertTrue(type(SE) == "table", "GRIPEMS.SequenceEditor attached")
assertTrue(type(SE.OnKeyPressChanged) == "function", "SE:OnKeyPressChanged defined")
assertTrue(type(SE.OnKeyReleaseChanged) == "function", "SE:OnKeyReleaseChanged defined")
assertTrue(type(SE.GetEditingVersion) == "function", "SE:GetEditingVersion defined")
assertTrue(type(SE._quickResignSerial) == "number", "SE._quickResignSerial is the module's own counter")

-- ---------------------------------------------------------------------------
-- Sandbox 1 fixture. The version INDEX is load bearing: two versions, both
-- carrying the sentinels, and the editor pointed at the SECOND one. A writer
-- that ignored activeVersionIndex and always took versions[1] would pass a
-- single-version fixture and fail here.
-- ---------------------------------------------------------------------------

local SEQ_NAME = "WriteSetSeq"
local SENTINEL_KP = "SENTINEL_KEYPRESS_NEVER_TYPED"
local SENTINEL_KR = "SENTINEL_KEYRELEASE_NEVER_TYPED"
local TYPED_KP = "/cast [mod:shift] Typed KeyPress Spell"
local TYPED_KR = "/cast Typed KeyRelease Spell"

local seqData = {
    name = SEQ_NAME,
    defaultVersion = 1,
    versions = {
        {
            stepFunction = "Sequential",
            steps = { "/cast Alpha" },
            keyPress = SENTINEL_KP,
            keyRelease = SENTINEL_KR,
        },
        {
            stepFunction = "Sequential",
            steps = { "/cast Beta" },
            keyPress = SENTINEL_KP,
            keyRelease = SENTINEL_KR,
        },
    },
}

-- THE SAME TABLE OBJECT reaches both the SavedVariables global and the engine
-- entry. Not a copy. The alias IS the persistence mechanism, and W1(d) asserts
-- it by identity rather than by value.
rawset(seEnv, "GRIP_EMS_CHAR", { sequences = { [SEQ_NAME] = seqData } })
Engine.sequences[SEQ_NAME] = { button = {}, data = seqData }

SE.currentSequence = SEQ_NAME
SE.activeVersionIndex = 2

--- The persisted row, resolved through the sandbox's OWN _G every time. Never a
--- local handle captured at fixture time: a handle would keep answering after a
--- refactor stopped writing to SavedVariables at all.
local function SavedRow()
    local char = rawget(seEnv, "GRIP_EMS_CHAR")
    local sequences = char and char.sequences
    return sequences and sequences[SEQ_NAME]
end

local function SavedVersion(idx)
    local row = SavedRow()
    local versions = row and row.versions
    if type(versions) ~= "table" then
        return nil
    end
    return versions[idx]
end

-- ---------------------------------------------------------------------------
-- Cases -- sandbox 1.
-- ---------------------------------------------------------------------------

test("W1: SE:OnKeyPressChanged persists the typed keyPress to the SavedVariables row", function()
    local serialBefore = SE._quickResignSerial
    local logBefore = #engineLog

    SE:OnKeyPressChanged(TYPED_KP)

    local logged = engineLog[#engineLog]

    -- (a) NON-VACUITY, first. A no-op writer cannot pass this file by accident:
    -- if the typed text equalled the sentinel, every assertion below would hold
    -- against a function that never ran.
    assertNotEqual(SENTINEL_KP, TYPED_KP, "W1(a): the typed text really differs from the seeded sentinel")

    -- (b) read through the SavedVariables global, never through a local handle.
    assertEqual(TYPED_KP, SavedVersion(2).keyPress, "W1(b): the typed text reached GRIP_EMS_CHAR")

    -- (c) the write went to the ACTIVE version and ONLY to it.
    assertEqual(SENTINEL_KP, SavedVersion(1).keyPress, "W1(c): versions[1] was left holding its sentinel")

    -- (d) the ALIAS, by identity. If a future refactor copies instead of
    -- aliasing, this is the assertion that goes red.
    assertEqual(logBefore + 1, #engineLog, "W1(d): UpdateSequenceData was called exactly once")
    assertEqual(SEQ_NAME, logged.name, "W1(d): it was called for the edited sequence")
    assertEqual(SavedRow(), logged.data, "W1(d): the data it was handed IS the SavedVariables row, not a copy")

    -- (e) the reached-the-end witness. The increment is produced by the LAST
    -- statement of the function, so it discriminates ran-to-completion from
    -- early-returned. Delta, never absolute: the counter is module state shared
    -- with W2 and W3.
    assertEqual(serialBefore + 1, SE._quickResignSerial, "W1(e): the function ran to its last statement")

    -- (f) the 255-cap accounting the status label reads.
    assertEqual(#TYPED_KP, StepListView.keyPressLen, "W1(f): StepListView.keyPressLen tracks the typed length")
end)

test("W2: every guard blocks the write, and blocking leaves the row untouched", function()
    --- One guard sub-check: mutate, call, RESTORE, then assert. Restoring before
    --- the reads matters for sub-check 4, where versions is a scalar during the
    --- call and cannot be indexed while it is.
    local function GuardCase(label, mutate, restore)
        local before = SavedVersion(2).keyPress
        local serialBefore = SE._quickResignSerial
        mutate()
        local ok, err = pcall(SE.OnKeyPressChanged, SE, "GUARD_MUST_NOT_PERSIST_" .. label)
        restore()
        assertTrue(ok, "W2/" .. label .. ": the guard absorbed the call instead of raising: " .. tostring(err))
        assertEqual(before, SavedVersion(2).keyPress, "W2/" .. label .. ": the SavedVariables row is untouched")
        -- A serial that moved means the function ran PAST its guard, which is the
        -- failure this sub-check exists to detect even when the row happens to
        -- look unchanged.
        assertEqual(
            serialBefore,
            SE._quickResignSerial,
            "W2/" .. label .. ": the resign serial did not move, so the guard really did return early"
        )
    end

    GuardCase("no-current-sequence", function()
        SE.currentSequence = nil
    end, function()
        SE.currentSequence = SEQ_NAME
    end)

    local savedSequences
    GuardCase("no-engine-sequences", function()
        savedSequences = Engine.sequences
        Engine.sequences = nil
    end, function()
        Engine.sequences = savedSequences
    end)

    GuardCase("no-entry-data", function()
        Engine.sequences[SEQ_NAME].data = nil
    end, function()
        Engine.sequences[SEQ_NAME].data = SavedRow()
    end)

    -- SE:GetEditingVersion type()-checks .versions rather than testing its
    -- truthiness, precisely so a SCALAR cannot be indexed. A scalar is what
    -- un-migrated and hand-edited SavedVariables actually carry.
    local savedVersions
    GuardCase("scalar-versions", function()
        local row = SavedRow()
        savedVersions = row.versions
        row.versions = 5
    end, function()
        SavedRow().versions = savedVersions
    end)
end)

test("W3: SE:OnKeyReleaseChanged persists the typed keyRelease to the SavedVariables row", function()
    local serialBefore = SE._quickResignSerial
    local logBefore = #engineLog
    -- Captured, not asserted against a constant. W1's write is NOT a precondition
    -- of W3: comparing before against after keeps this case pinned to line 4326
    -- alone, so breaking the keyPress writer reddens W1 and leaves W3 green.
    local keyPressBefore = SavedVersion(2).keyPress

    SE:OnKeyReleaseChanged(TYPED_KR)

    local logged = engineLog[#engineLog]

    assertNotEqual(SENTINEL_KR, TYPED_KR, "W3(a): the typed text really differs from the seeded sentinel")
    assertEqual(TYPED_KR, SavedVersion(2).keyRelease, "W3(b): the typed text reached GRIP_EMS_CHAR")
    assertEqual(SENTINEL_KR, SavedVersion(1).keyRelease, "W3(c): versions[1] was left holding its sentinel")
    assertEqual(logBefore + 1, #engineLog, "W3(d): UpdateSequenceData was called exactly once")
    assertEqual(SEQ_NAME, logged.name, "W3(d): it was called for the edited sequence")
    assertEqual(SavedRow(), logged.data, "W3(d): the data it was handed IS the SavedVariables row, not a copy")
    assertEqual(serialBefore + 1, SE._quickResignSerial, "W3(e): the function ran to its last statement")
    assertEqual(#TYPED_KR, StepListView.keyReleaseLen, "W3(f): StepListView.keyReleaseLen tracks the typed length")
    -- The sibling field is a DIFFERENT line. A writer that touched both would
    -- pass every assertion above and fail here.
    assertEqual(keyPressBefore, SavedVersion(2).keyPress, "W3: the keyRelease write did not disturb keyPress")
end)

-- ===========================================================================
-- SANDBOX 2 -- Data/VariableStore.lua. Its own env, its own stub, its own
-- holder. Nothing above is reachable from here.
-- ===========================================================================

local vsStub = NewStub()
local vsEnv = NewEnv(vsStub)

-- EXPLICIT. `varDef.updatedAt = time()` at Data/VariableStore.lua:297 would
-- otherwise be handed the catch-all and assign a TABLE where a number belongs.
vsEnv.time = os.time

rawset(vsEnv, "GRIP_EMS_DB", { variables = {}, config = {} })

-- THE POINT OF W4 AND W5. Left to the catch-all, _G.GRIP_EMS_CHAR answers a
-- truthy stub, the `if` at Data/VariableStore.lua:316 passes, pairs() over the
-- stub yields nothing, the loop body never runs, and both cases pass having
-- rewritten nothing at all. F2 deletes this line to prove they do not.
rawset(vsEnv, "GRIP_EMS_CHAR", {
    sequences = {
        VersionedSeq = { versions = { { steps = { "/cast ~Old~", "/cast Untouched" } } } },
        LegacySeq = { steps = { "/cast ~Old~ then more" } },
        OtherVarSeq = { versions = { { steps = { "/cast ~Other~" } } } },
    },
})

local vsHolder = setmetatable({}, {
    __index = function()
        return vsStub
    end,
})

-- REAL, and rawset BEFORE the load: the module binds `local D = GRIPEMS.Defaults`
-- at file scope (line 11), and VS:ValidateName compares #name against
-- D.VAR_MAX_NAME (line 719), which raises against a stub table. Both values are
-- verbatim from Data/Defaults.lua lines 1056 and 1057.
rawset(vsHolder, "Defaults", {
    VAR_MAX_NAME = 32,
    VAR_PATTERN = "~([%w_]+)~",
})
rawset(vsHolder, "Fire", function() end)
rawset(vsHolder, "Debug", function() end)
rawset(vsHolder, "Print", function() end)

assertTrue(
    LoadInto({
        "Data/VariableStore.lua",
        "../Data/VariableStore.lua",
        "GRIP/EMS/Data/VariableStore.lua",
    }, vsHolder, vsEnv),
    "could not locate Data/VariableStore.lua (run from the EMS root)"
)

local VS = rawget(vsHolder, "VariableStore")
assertTrue(type(VS) == "table", "GRIPEMS.VariableStore attached")
assertTrue(type(VS.Rename) == "function", "VS:Rename defined")

--- The variable store, resolved through the sandbox's own _G.
local function VarStore()
    local db = rawget(vsEnv, "GRIP_EMS_DB")
    return db and db.variables
end

--- One step, resolved through the sandbox's own _G and nil-safe at every hop.
--- Nil-safe on purpose: under F2 the whole GRIP_EMS_CHAR chain is absent, and a
--- raise here would abort the file before any RESULT line was printed. Returning
--- nil instead lets W4 and W5 report their own FAIL lines, which is what the
--- falsification needs to be readable.
local function CharStep(seqName, verIdx, stepIdx)
    local char = rawget(vsEnv, "GRIP_EMS_CHAR")
    local sequences = char and char.sequences
    local seq = sequences and sequences[seqName]
    if not seq then
        return nil
    end
    if verIdx then
        local versions = seq.versions
        local ver = type(versions) == "table" and versions[verIdx] or nil
        local steps = ver and ver.steps
        return steps and steps[stepIdx]
    end
    local steps = seq.steps
    return steps and steps[stepIdx]
end

-- VS:Create does not exist on this module -- the CRUD surface is
-- Set/Get/GetAll/Delete/Rename -- so the definition is written straight into the
-- store, carrying only the fields Rename and RebuildEventRegistration read.
VarStore().Old = {
    name = "Old",
    type = "value",
    value = "1",
    events = "",
    createdAt = 0,
    updatedAt = 0,
}

-- ONE rename, observed by three cases. Pre-state is captured first so each case
-- can assert its own non-vacuity, and the call is pcall'd so a raise reports as a
-- FAIL line rather than aborting the file.
local preVersioned = CharStep("VersionedSeq", 1, 1)
local preLegacy = CharStep("LegacySeq", nil, 1)
local preOther = CharStep("OtherVarSeq", 1, 1)
local renameRan, renameReturn = pcall(VS.Rename, VS, "Old", "New")

-- ---------------------------------------------------------------------------
-- Cases -- sandbox 2.
-- ---------------------------------------------------------------------------

test("W4: VS:Rename rewrites the VERSIONED layout in place", function()
    -- NON-VACUITY first: the pre-state really carried the token being renamed.
    assertTrue(preVersioned ~= nil, "W4 (witness): the versioned fixture was reachable through GRIP_EMS_CHAR")
    assertTrue(preVersioned:find("~Old~", 1, true) ~= nil, "W4 (witness): the pre-state really carried ~Old~")

    assertTrue(renameRan, "W4: VS:Rename raised instead of returning: " .. tostring(renameReturn))
    assertEqual(true, renameReturn, "W4: VS:Rename reported success")

    assertEqual("/cast ~New~", CharStep("VersionedSeq", 1, 1), "W4: the versioned step was rewritten in place")
    assertEqual("/cast Untouched", CharStep("VersionedSeq", 1, 2), "W4: the sibling step was left alone")

    -- The definition moved with the name.
    assertTrue(type(VarStore().New) == "table", "W4: the definition is stored under the new name")
    assertEqual(nil, VarStore().Old, "W4: the old name no longer holds a definition")
    assertEqual("New", VarStore().New.name, "W4: the definition's own name field was updated")
end)

test("W5: VS:Rename rewrites the LEGACY FLAT layout in place", function()
    -- Pre-T2-2 data that no current test loads. The fallback branch at
    -- Data/VariableStore.lua:331-337 is the only thing that reaches this layout.
    assertTrue(preLegacy ~= nil, "W5 (witness): the legacy fixture was reachable through GRIP_EMS_CHAR")
    assertTrue(preLegacy:find("~Old~", 1, true) ~= nil, "W5 (witness): the pre-state really carried ~Old~")

    assertEqual("/cast ~New~ then more", CharStep("LegacySeq", nil, 1), "W5: the flat step was rewritten in place")
end)

test("W6: the rewrite is targeted, not a blanket substitution", function()
    assertTrue(preOther ~= nil, "W6 (witness): the control fixture was reachable through GRIP_EMS_CHAR")
    assertEqual("/cast ~Other~", CharStep("OtherVarSeq", 1, 1), "W6: an unrelated variable reference is untouched")
end)

-- ---------------------------------------------------------------------------
-- Run.
-- ---------------------------------------------------------------------------

local passed = 0
local failed = 0
for _, t in ipairs(tests) do
    local ok, err = pcall(t.fn)
    if ok then
        passed = passed + 1
        print("PASS  " .. t.name)
    else
        failed = failed + 1
        print("FAIL  " .. t.name .. " -- " .. tostring(err))
    end
end
print(string.format("RESULT %d passed, %d failed", passed, failed))
os.exit(failed > 0 and 1 or 0)
