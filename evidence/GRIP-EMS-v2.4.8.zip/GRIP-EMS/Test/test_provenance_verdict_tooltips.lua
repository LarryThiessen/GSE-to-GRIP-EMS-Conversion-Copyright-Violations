-- GRIP-EMS: Provenance verdict tooltip locale-coupling guard
--
-- Created:    2026-07-30
-- Updated:    2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.
--
-- SCOPE WARNING -- READ BEFORE TRUSTING A GREEN RUN.
-- This file does NOT prove the verdict detail row appears on screen. Render
-- reachability is deliberately out of scope: Import/ImportFrame.lua is loaded
-- by no test suite in this repo (it builds native frames and AceGUI widgets at
-- module scope), so there is no harness in which _ShowProvTooltip can be
-- driven and its rows inspected. A green run here means the LOCALE COUPLING is
-- sound, not that the tooltip is visible. Visual confirmation stays a manual
-- in-game check.
--
-- What it does prove, all of it CI-enforced (SET A is glob-discovered from
-- EMS/Test/test_*.lua, no registration step):
--
--   P1  The verdict set is DERIVED from Engine/Identity.lua's VerifySequence
--       body rather than hardcoded here. A seventh return value -- or a
--       literal return replaced by a variable -- makes this the test that
--       notices.
--   P2  _ProvBadgeLabel in Import/ImportFrame.lua maps every derived verdict
--       to a locale key that resolves to a non-empty enUS string.
--   P3  _ProvBadgeDetail maps every derived verdict to a locale key that
--       resolves to a non-empty enUS string. Neither map may carry a state
--       that VerifySequence cannot return.
--   P4  GEMS_PROVENANCE_MODIFIED_TOOLTIP carries exactly one format specifier
--       and it is %d, so _ProvBadgeDetail's string.format call cannot drift
--       into an arity mismatch unnoticed.
--   P5  The other five tooltip strings carry zero format specifiers, so
--       handing them to AddRow unformatted cannot leak a literal specifier
--       into the user's tooltip.
--   P6  _ProvBadgeDetail contains exactly one string.format call, which is
--       what keeps P4 and P5 honest: the %d string cannot be routed around
--       the format call, and the five bare strings cannot be routed through
--       one.
--
-- Both maps are read as TEXT out of the shipped source. That is intentional:
-- ImportFrame.lua cannot be loaded headless, and a text scan still fails on
-- exactly the drift this guard exists to catch (a verdict added to one map but
-- not the other, or a key renamed on one side only).
--
-- Run from the EMS root:  lua Test/test_provenance_verdict_tooltips.lua
-- Exit code 0 = all passed, 1 = at least one failure.

-- ---------------------------------------------------------------------------
-- Minimal assertion + runner harness (mirrors test_v0_upgrade_guard.lua).
-- ---------------------------------------------------------------------------

local tests = {}

local function test(name, fn)
    tests[#tests + 1] = { name = name, fn = fn }
end

local function assertEqual(expected, actual, label)
    if expected ~= actual then
        error((label or "value") .. ": expected " .. tostring(expected) .. ", got " .. tostring(actual), 2)
    end
end

local function assertTrue(cond, label)
    if not cond then
        error((label or "condition") .. " failed", 2)
    end
end

-- ---------------------------------------------------------------------------
-- Source location. Candidate lists match the other SET A files so the run
-- works from the EMS root, from Test/, or from the Hub root.
-- ---------------------------------------------------------------------------

local function readSource(candidates, label)
    for _, path in ipairs(candidates) do
        local fh = io.open(path, "rb")
        if fh then
            local text = fh:read("*a")
            fh:close()
            -- Normalize line endings so the col-0 "end" anchors below hold on
            -- a CRLF checkout as well as the LF repo.
            return (text:gsub("\r\n", "\n"))
        end
    end
    error("could not locate " .. label .. " (run from the EMS root)", 0)
end

local identitySrc = readSource({
    "Engine/Identity.lua",
    "../Engine/Identity.lua",
    "GRIP/EMS/Engine/Identity.lua",
}, "Engine/Identity.lua")

local importSrc = readSource({
    "Import/ImportFrame.lua",
    "../Import/ImportFrame.lua",
    "GRIP/EMS/Import/ImportFrame.lua",
}, "Import/ImportFrame.lua")

-- ---------------------------------------------------------------------------
-- enUS locale values. Loaded as a real chunk (not text-scraped) so multi-line
-- assignments and escape sequences resolve to the exact runtime string.
-- ---------------------------------------------------------------------------

local function loadLocale()
    local captured = {}
    local env = setmetatable({}, { __index = _G })
    env.LibStub = function()
        return {
            NewLocale = function()
                return captured
            end,
        }
    end
    local candidates = {
        "Locale/enUS.lua",
        "../Locale/enUS.lua",
        "GRIP/EMS/Locale/enUS.lua",
    }
    for _, path in ipairs(candidates) do
        -- loadfile is dev-harness file I/O, intentionally outside the addon WoW std.
        -- selene: allow(undefined_variable)
        local chunk = loadfile(path)
        if chunk then
            setfenv(chunk, env)
            chunk()
            return captured
        end
    end
    error("could not locate Locale/enUS.lua (run from the EMS root)", 0)
end

local L = loadLocale()

-- ---------------------------------------------------------------------------
-- P1 source: the verdict set, derived from VerifySequence's own body.
-- Slice runs from the function header to the first column-0 "end", so the
-- doc comment above the function contributes nothing and the indented inner
-- "end" keywords do not terminate the slice early.
-- ---------------------------------------------------------------------------

local verifyBody = identitySrc:match("\nfunction I:VerifySequence%(seq%)(.-)\nend")

local verdicts = {}
local verdictOrder = {}
if verifyBody then
    for v in verifyBody:gmatch('return%s+"([%w_%-]+)"') do
        if not verdicts[v] then
            verdicts[v] = true
            verdictOrder[#verdictOrder + 1] = v
        end
    end
end
table.sort(verdictOrder)

-- ---------------------------------------------------------------------------
-- P2/P3 source: the two badge maps, read out of the shipped ImportFrame.
-- ---------------------------------------------------------------------------

local labelBody = importSrc:match("\nlocal function _ProvBadgeLabel%(state%)(.-)\nend")
local detailBody = importSrc:match("\nlocal function _ProvBadgeDetail%(state, prov%)(.-)\nend")

local function parseStateKeyMap(body)
    local map = {}
    if not body then
        return map
    end
    for state, key in body:gmatch('(%a[%w_]*)%s*=%s*L%["([%w_]+)"%]') do
        map[state] = key
    end
    return map
end

local labelKeys = parseStateKeyMap(labelBody)
local detailKeys = parseStateKeyMap(detailBody)

-- The modified verdict does not live in _ProvBadgeDetail's map table -- it is
-- the early-return branch that owns the only string.format call. Fold it in so
-- the coverage assertions see one map spanning all six verdicts.
local modifiedState, modifiedKey
if detailBody then
    modifiedState, modifiedKey = detailBody:match('state%s*==%s*"(%a[%w_]*)".-string%.format%(%s*L%["([%w_]+)"%]')
    if modifiedState and modifiedKey then
        detailKeys[modifiedState] = modifiedKey
    end
end

local detailFormatCalls = 0
if detailBody then
    for _ in detailBody:gmatch("string%.format") do
        detailFormatCalls = detailFormatCalls + 1
    end
end

-- ---------------------------------------------------------------------------
-- Format-specifier scanner. Returns every specifier in a string, so a count of
-- zero is a positive proof of "safe to pass to AddRow unformatted" rather than
-- the absence of one particular pattern. A bare "%" that is not an escaped
-- "%%" is reported too, which is the strict reading a guard wants.
-- ---------------------------------------------------------------------------

local function formatSpecs(s)
    local specs = {}
    local i = 1
    while i <= #s do
        if s:sub(i, i) == "%" then
            local nxt = s:sub(i + 1, i + 1)
            if nxt == "%" then
                i = i + 2
            else
                local flags, conv = s:sub(i + 1):match("^([-+#0]*%d*%.?%d*)(%a)")
                if conv then
                    specs[#specs + 1] = "%" .. flags .. conv
                    i = i + 2 + #flags
                else
                    specs[#specs + 1] = "%" .. nxt
                    i = i + 2
                end
            end
        else
            i = i + 1
        end
    end
    return specs
end

local function assertLocaleString(key, label)
    -- Presence guard first: without it a nil key dies on the label
    -- concatenation below, reporting a Lua type error instead of naming the
    -- verdict whose map entry is missing.
    assertTrue(key ~= nil, label .. " a locale key is mapped")
    local value = L[key]
    assertEqual("string", type(value), label .. " L[" .. key .. "] is a string")
    assertTrue(value ~= "", label .. " L[" .. key .. "] is non-empty")
    return value
end

-- ---------------------------------------------------------------------------
-- Cases.
-- ---------------------------------------------------------------------------

test("P1: the verdict set is derived from VerifySequence, and it is the known six", function()
    assertTrue(verifyBody ~= nil, "VerifySequence body located in Engine/Identity.lua")
    -- Hardcoded here ONLY as the expected value of a derived set. If
    -- VerifySequence gains a seventh verdict this comparison is what fails,
    -- and the fix is to wire the new verdict into both badge maps and add its
    -- tooltip key -- not to widen this list on its own.
    local expected = { "damaged", "forked", "modified", "tampered", "unknown", "verified" }
    assertEqual(#expected, #verdictOrder, "verdict count derived from VerifySequence")
    for idx, name in ipairs(expected) do
        assertEqual(name, verdictOrder[idx], "derived verdict " .. idx)
    end
end)

test("P2: _ProvBadgeLabel covers every verdict with a real enUS string", function()
    assertTrue(labelBody ~= nil, "_ProvBadgeLabel body located in Import/ImportFrame.lua")
    for _, state in ipairs(verdictOrder) do
        local key = labelKeys[state]
        assertTrue(key ~= nil, "_ProvBadgeLabel maps verdict " .. state)
        assertLocaleString(key, "label for " .. state .. ":")
    end
    for state in pairs(labelKeys) do
        assertTrue(verdicts[state], "_ProvBadgeLabel state " .. state .. " is a real VerifySequence verdict")
    end
end)

test("P3: _ProvBadgeDetail covers every verdict with a real enUS string", function()
    assertTrue(detailBody ~= nil, "_ProvBadgeDetail body located in Import/ImportFrame.lua")
    for _, state in ipairs(verdictOrder) do
        local key = detailKeys[state]
        assertTrue(key ~= nil, "_ProvBadgeDetail maps verdict " .. state)
        assertLocaleString(key, "detail for " .. state .. ":")
    end
    for state in pairs(detailKeys) do
        assertTrue(verdicts[state], "_ProvBadgeDetail state " .. state .. " is a real VerifySequence verdict")
    end
end)

test("P4: the modified tooltip carries exactly one specifier and it is %d", function()
    assertEqual("modified", modifiedState, "the string.format branch is the modified verdict")
    assertEqual("GEMS_PROVENANCE_MODIFIED_TOOLTIP", modifiedKey, "the formatted key")
    local specs = formatSpecs(assertLocaleString(modifiedKey, "modified detail:"))
    assertEqual(1, #specs, "specifier count in " .. modifiedKey)
    assertEqual("%d", specs[1], "the single specifier is the chain count")
end)

test("P5: the other five tooltips carry zero specifiers", function()
    local checked = 0
    for _, state in ipairs(verdictOrder) do
        if state ~= modifiedState then
            local key = detailKeys[state]
            local specs = formatSpecs(assertLocaleString(key, "detail for " .. state .. ":"))
            assertEqual(0, #specs, "specifier count in " .. key .. " (passed to AddRow unformatted)")
            checked = checked + 1
        end
    end
    assertEqual(5, checked, "unformatted tooltip strings checked")
end)

test("P6: _ProvBadgeDetail contains exactly one string.format call", function()
    assertEqual(1, detailFormatCalls, "string.format calls in _ProvBadgeDetail")
end)

-- ---------------------------------------------------------------------------
-- Run.
-- ---------------------------------------------------------------------------

local passed = 0
local failed = 0
for _, t in ipairs(tests) do
    local ok, err = pcall(t.fn)
    if ok then
        passed = passed + 1
        print("PASS  " .. t.name)
    else
        failed = failed + 1
        print("FAIL  " .. t.name .. " " .. tostring(err))
    end
end
print(string.format("RESULT %d passed, %d failed", passed, failed))
os.exit(failed > 0 and 1 or 0)
