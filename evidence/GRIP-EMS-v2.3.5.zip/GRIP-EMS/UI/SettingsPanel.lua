-- GRIP-EMS: Settings Panel
-- Created: 2025 (pre-stamping)
-- Updated: 2026-06-24
-- Patch: 12.0.7.68275 Midnight (Retail LIVE)
-- AceConfig options table + Blizzard Settings integration + AceDBOptions profiles

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)
local function D()
    return GRIPEMS.Defaults
end

GRIPEMS.SettingsPanel = {}
local SP = GRIPEMS.SettingsPanel
local UI = GRIPEMS.UI

-- G8-AUDIT-36: centralized cvarHealth row-action announcer.
-- Called by per-row Fix / Set / Undo / Redo / Pin / Auto-fix paths.
-- action: one of "FIX", "SET", "UNDO", "REDO", "PIN_ON", "PIN_OFF",
--                "AUTOFIX_ON", "AUTOFIX_OFF"
-- cvarName: raw CVar name string (used as %s arg 1)
-- toValue:  resulting value string (used as %s arg 2 for FIX/SET/UNDO/REDO; ignored otherwise)
local CVAR_ANNOUNCE_KEYS = {
    FIX = "ACCESS_ANNOUNCE_CVAR_FIX",
    SET = "ACCESS_ANNOUNCE_CVAR_SET",
    UNDO = "ACCESS_ANNOUNCE_CVAR_UNDO",
    REDO = "ACCESS_ANNOUNCE_CVAR_REDO",
    PIN_ON = "ACCESS_ANNOUNCE_CVAR_PIN_ON",
    PIN_OFF = "ACCESS_ANNOUNCE_CVAR_PIN_OFF",
    AUTOFIX_ON = "ACCESS_ANNOUNCE_CVAR_AUTOFIX_ON",
    AUTOFIX_OFF = "ACCESS_ANNOUNCE_CVAR_AUTOFIX_OFF",
}

local function cvarRowAnnounce(action, cvarName, _fromValue, toValue)
    if not (GRIPEMS.Speech and GRIPEMS.Speech.Announce) then
        return
    end
    local localeKey = CVAR_ANNOUNCE_KEYS[action]
    if not localeKey then
        return
    end
    local fmt = L[localeKey]
    if not fmt then
        return
    end
    if action == "FIX" or action == "SET" or action == "UNDO" or action == "REDO" then
        GRIPEMS.Speech:Announce(string.format(fmt, tostring(cvarName), tostring(toValue)))
    else
        GRIPEMS.Speech:Announce(string.format(fmt, tostring(cvarName)))
    end
end

-- G.9: shared cvarHealth row classifier. Returns one of:
--   "sqwManaged"      -- SpellQueueWindow while SQW Optimizer is active
--   "unrecommended"   -- r.recommended == nil (user-choice CVars)
--   "match"           -- effective recommendation is matched
--   "mismatchCritical"-- mismatch on a r.critical row
--   "mismatchPolish"  -- mismatch on a non-critical row
-- Used by per-row cvar_status_* color selection, the offender accumulator
-- in the score explainer, and the issue-anchor collector below. CPM is
-- looked up via GRIPEMS.CvarProfileManager so this is safe to call from
-- module scope before SP:Initialize has populated its locals.
function SP:_ClassifyCvarRow(r)
    if not r or not r.cvar then
        return "match"
    end
    local SQWO = GRIPEMS.SQWOptimizer
    if r.cvar == "SpellQueueWindow" and SQWO and SQWO:IsActive() then
        return "sqwManaged"
    end
    -- V2OX-G9-CPM-OVERRIDE-OFFENDER-DECISION (2026-05-22 reckoning
    -- Option c): consult CPM BEFORE the recommended==nil short-
    -- circuit. If a profile assigns a recommendation to a catalog-
    -- nil CVar, the profile value wins and the row participates
    -- in match/mismatch classification. Belt-and-braces: the
    -- catalog-fill pass (Defaults.lua enableMultiActionBars /
    -- enableMouseoverCast / maxFPS) removed all current nils;
    -- this reorder guards future additions of new CVars added
    -- without a recommended value.
    local CPM = GRIPEMS.CvarProfileManager
    local eff
    if CPM and CPM.GetEffectiveRecommendation then
        eff = CPM:GetEffectiveRecommendation(r.cvar)
    end
    if eff == nil then
        eff = r.recommended
    end
    if eff == nil then
        return "unrecommended"
    end
    local current = GetCVar(r.cvar) or ""
    local Defaults = D()
    if Defaults and Defaults.CvarMatch and Defaults.CvarMatch(current, eff) then
        return "match"
    end
    if r.critical then
        return "mismatchCritical"
    end
    return "mismatchPolish"
end

-- G.9: collect cvarHealth section + issue anchors and register them with
-- the AceConfig focus shim. Called once after the initial Shim:Enable and
-- again on every Shim:_RewalkActive via the onRewalk callback so anchors
-- track row-status changes (issues shrink as they get fixed).
function SP:_RegisterCvarHealthAnchors()
    local Shim = GRIPEMS.UI and GRIPEMS.UI.AceConfigFocusShim
    if not Shim then
        return
    end
    local sections = D() and D().CVAR_SECTIONS
    if type(sections) ~= "table" then
        return
    end

    -- V2OX-G9-PINNED-MISMATCH-DIVERGENCE: CPM upvalue for the pinned
    -- mismatch anchor swap inside the inner loop. CPM is not module
    -- scope in this file; mirrors the lookup pattern at lines 73,
    -- 1467, 4011, 4159, 4594.
    local CPM = GRIPEMS.CvarProfileManager

    local sectionAnchors = {}
    -- G.9 polish: issueAnchors targets only rows whose cvar_fix_
    -- button is visible and actionable. healthScoreExplain (type
    -- description) is not focusable. r.recommended == nil rows
    -- hide the Fix button (the user has free choice; profiles
    -- suggest but don't force). Aligns with the score-explainer
    -- offender list at args.healthScoreExplain.name.
    -- V2OX-G9-PINNED-MISMATCH-DIVERGENCE: pinned mismatch rows have
    -- a disabled cvar_fix_ button (ENTER on it is silent). Re-anchor
    -- those rows to cvar_pin_ so Alt+N lands on the actionable unpin
    -- toggle. Keeps blind-user navigability intact AND avoids the
    -- silent disabled-button-lands path.
    local issueAnchors = {}

    for i, section in ipairs(sections) do
        sectionAnchors[i] = {
            key = section.key,
            name = section.label or section.key,
            path = "cvarSection_" .. section.key .. ".fixAll",
        }
        for _, r in ipairs(section.cvars or {}) do
            local status = SP:_ClassifyCvarRow(r)
            if status == "mismatchCritical" or status == "mismatchPolish" then
                -- V2OX-G9-PINNED-MISMATCH-DIVERGENCE-COMBAT-SECURE-FOLLOWUP:
                -- skip secure-cvar mismatch rows during combat lockdown.
                -- The cvar_fix_ button is disabled for secure CVars while
                -- InCombatLockdown() returns true (disable gate around
                -- L2260 and four more sites in this file). ENTER on a
                -- disabled button is silent for blind / TTS users.
                -- Re-anchoring to cvar_pin_ is wrong semantically
                -- (pin means leave alone, not fix). Skipped rows reappear
                -- on combat exit via the PLAYER_REGEN handler at module
                -- scope at end of file, which calls AceConfigRegistry's
                -- NotifyChange("GRIP-EMS") and triggers the
                -- ConfigTableChange path that re-runs this registrar.
                local secureCombatSkip = CPM and CPM.IsCVarSecure and CPM.IsCVarSecure(r.cvar) and InCombatLockdown()
                if not secureCombatSkip then
                    -- V2OX-G9-FIX-SELECT-ANCHOR (Backlog L31): widget-path picker
                    -- mirrors the conditional render in cvarHealth so issueAnchors
                    -- target the widget actually rendered for each row.
                    --   pin   -> cvar_pin_<cvar>        (pinned, leave alone)
                    --   r.options ~= nil -> cvar_fix_select_<cvar>  (dropdown Fix)
                    --   r.recommended == nil -> cvar_set_<cvar>     (free-input Set)
                    --   default -> cvar_fix_<cvar>      (execute Fix button)
                    local widget
                    if CPM and CPM.IsPinned and CPM:IsPinned(r.cvar) then
                        widget = "cvar_pin_"
                    elseif r.options ~= nil then
                        widget = "cvar_fix_select_"
                    elseif r.recommended == nil then
                        widget = "cvar_set_"
                    else
                        widget = "cvar_fix_"
                    end
                    issueAnchors[#issueAnchors + 1] = "cvarSection_" .. section.key .. "." .. widget .. r.cvar
                end
            end
        end
    end

    Shim:RegisterSectionAnchors("cvarHealth", sectionAnchors)
    Shim:RegisterIssueAnchors("cvarHealth", issueAnchors)
end

-- G.9 V2OX-G9-ACCESSIBILITY-SECTION-ANCHORS: collect accessibility
-- inline-group section anchors and register them with the AceConfig
-- focus shim. 13 inline groups inside the general tab become anchors
-- per the 2026-05-22 reckoning. No issue anchors -- accessibility has
-- no mismatch / issue concept like cvarHealth.
--
-- Tab-transition handling: accessibility wraps its inline groups in
-- a "general" tab (childGroups = "tab" with general + themingEditor
-- children). Paths are prefixed "general." so resolveOptionPath
-- traverses the tab wrapper. When user is on the themingEditor tab,
-- the general inline groups are not in the rendered tree and the
-- "general" segment fails to resolve -- JumpToSection silently
-- no-ops. The 30s ticker at the bottom of SP:Initialize fires
-- NotifyChange which re-runs _RewalkActive then entry.onRewalk
-- after the user tabs back to general; the OnShow hook below is a
-- belt-and-braces safety net for subFrame re-show transitions.
--
-- Anchor order matches the AceConfig sort-by-order field for each
-- inline group (matches screen order). Pressing "1" lands on the
-- topmost section (guide, order=-2) and "9" on the 9th rendered
-- section. Sections 10-13 reachable via PageDown wrap only.
function SP:_RegisterAccessibilityAnchors()
    local Shim = GRIPEMS.UI and GRIPEMS.UI.AceConfigFocusShim
    if not Shim then
        return
    end

    local sectionAnchors = {
        { key = "guide", name = L["ACCESS_GUIDE_SECTION_NAME"], path = "general.guide.open" },
        { key = "accessibilityMode", name = L["ACCESS_MODE_SECTION_NAME"], path = "general.accessibilityMode.toggle" },
        { key = "preset", name = "Contrast preset", path = "general.preset.contrastPreset" },
        {
            key = "colorblind",
            name = L["ACCESS_COLORBLIND_SECTION_NAME"] or "Color vision",
            path = "general.colorblind.colorblindType",
        },
        {
            key = "soundCues",
            name = L["ACCESS_SOUND_SECTION_NAME"] or "Sound cues",
            path = "general.soundCues.enabled",
        },
        { key = "display", name = L["ACCESS_SECTION_DISPLAY"], path = "general.display.fontName" },
        { key = "motion", name = L["ACCESS_SECTION_MOTION"], path = "general.motion.reduceMotion" },
        { key = "cursorOverlay", name = L["ACCESS_CURSOR_SECTION_NAME"], path = "general.cursorOverlay.enabled" },
        { key = "audio", name = L["ACCESS_SECTION_AUDIO"], path = "general.audio.speechEnabled" },
        { key = "feedback", name = L["ACCESS_FEEDBACK_SECTION_NAME"], path = "general.feedback.apx" },
        { key = "theming", name = L["ACCESS_THEME_SECTION_NAME"], path = "general.theming.uiScale" },
        { key = "simplifiedMode", name = L["ACCESS_SIMPLIFIED_SECTION_NAME"], path = "general.simplifiedMode.toggle" },
        { key = "density", name = L["ACCESS_DENSITY_SECTION_NAME"], path = "general.density.largeTargets" },
    }

    Shim:RegisterSectionAnchors("accessibility", sectionAnchors)
end

---------------------------------------------------------------------------
-- Dark-theme restyle for AceConfigDialog frames
---------------------------------------------------------------------------
-- FRAGILE: This function depends on AceConfigDialog-3.0 internal frame
-- structure (children layout, title region, close button). If the library
-- updates its frame hierarchy, this restyle may break silently.
-- Tested against AceConfigDialog-3.0 r1286. Review on lib updates.
---------------------------------------------------------------------------
local function RestyleAceFrame(widget)
    if not widget then
        return
    end
    -- Idempotent guard on the widget table
    if widget._gripRestyled then
        return
    end
    widget._gripRestyled = true

    local ok, err = pcall(function()
        local frame = widget.frame
        if not frame then
            return
        end

        local C = UI.Colors

        -- Main frame backdrop (must mixin BackdropTemplateMixin first)
        if not frame.SetBackdrop then
            Mixin(frame, BackdropTemplateMixin)
        end
        UI:ApplyBackdrop(frame, UI.Backdrops.panel, C.bgMain, C.border)

        -- Content area backdrop
        local content = widget.content
        if content then
            if not content.SetBackdrop then
                Mixin(content, BackdropTemplateMixin)
            end
            UI:ApplyBackdrop(content, UI.Backdrops.panel, C.bgPanel, C.border)
        end

        -- Title text color
        local titleText = widget.titletext
        if titleText and titleText.SetTextColor then
            local text = titleText:GetText()
            if text and text:find(ADDON_NAME) then
                titleText:SetTextColor(C.gripGreen:GetRGBA())
            else
                titleText:SetTextColor(C.textPrimary:GetRGBA())
            end
        end

        -- Move title text down into the frame (was floating above due to
        -- hidden ornamental banner anchoring)
        if titleText then
            titleText:ClearAllPoints()
            titleText:SetPoint("TOP", frame, "TOP", 0, -8)
        end

        -- Hide ornamental title bar textures (texture ID 131080)
        if widget.titlebg then
            widget.titlebg:SetAlpha(0)
        end
        for _, region in pairs({ frame:GetRegions() }) do
            if region.GetTexture and region:GetTexture() == 131080 then
                region:SetAlpha(0)
            end
        end

        -- Hide the status bar (serves no purpose in settings)
        if widget.statustext then
            local statusBar = widget.statustext:GetParent()
            if statusBar then
                statusBar:Hide()
            end
            widget.statustext:Hide()
        end

        -- Expand content area into reclaimed status bar space
        if widget.content then
            widget.content:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -17, 17)
        end

        -- Walk actual Frame children for close button and tab buttons
        for _, child in pairs({ frame:GetChildren() }) do
            if child:GetObjectType() == "Button" and child.GetText then
                local btnText = child:GetText()
                if btnText == CLOSE then
                    -- Strip UIPanelButtonTemplate textures to prevent double borders
                    if child.SetNormalTexture then
                        child:SetNormalTexture("")
                    end
                    if child.SetHighlightTexture then
                        child:SetHighlightTexture("")
                    end
                    if child.SetPushedTexture then
                        child:SetPushedTexture("")
                    end
                    if child.SetDisabledTexture then
                        child:SetDisabledTexture("")
                    end
                    -- Apply dark theme backdrop
                    if not child.SetBackdrop then
                        Mixin(child, BackdropTemplateMixin)
                    end
                    UI:ApplyBackdrop(child, UI.Backdrops.panel, C.bgButton, C.border)
                    -- Raise above content area
                    child:SetFrameLevel(frame:GetFrameLevel() + 10)
                    -- Restyle text
                    local fs = child:GetFontString()
                    if fs then
                        fs:SetTextColor(C.textPrimary:GetRGBA())
                    end
                elseif btnText and btnText ~= "" then
                    -- Tab buttons
                    if not child.SetBackdrop then
                        Mixin(child, BackdropTemplateMixin)
                    end
                    UI:ApplyBackdrop(child, UI.Backdrops.panel, C.bgButton, C.border)
                    local fs = child:GetFontString()
                    if fs then
                        fs:SetTextColor(C.textPrimary:GetRGBA())
                    end
                end
            end
        end

        GRIPEMS:Debug("SettingsPanel: Applied dark theme to AceConfigDialog frame")
    end)
    if not ok then
        GRIPEMS:Debug("RestyleAceFrame failed: " .. tostring(err))
    end
end

local function SP_buildLSMSoundRow(cueKey, settingKey, orderNum, nameKey, descKey)
    local _ = cueKey
    return {
        type = "select",
        dialogControl = "LSM30_Sound",
        name = L[nameKey] or settingKey,
        desc = L[descKey] or "",
        order = orderNum,
        values = function()
            local LSM = LibStub("LibSharedMedia-3.0", true)
            if LSM then
                return LSM:HashTable("sound")
            end
            return {}
        end,
        get = function()
            return GRIPEMS.Settings.db.profile.accessibility[settingKey]
        end,
        set = function(_, val)
            GRIPEMS.Settings.db.profile.accessibility[settingKey] = val
        end,
        disabled = function()
            return not GRIPEMS.Settings.db.profile.accessibility.soundCuesEnabled
        end,
        width = 1.5,
    }
end

local function SP_buildPreviewButton(cueKey, orderNum)
    return {
        type = "execute",
        name = L["ACCESS_SOUND_PREVIEW_LABEL"] or "Play",
        order = orderNum,
        func = function()
            if GRIPEMS.Sound and GRIPEMS.Sound.Play then
                GRIPEMS.Sound:Play(cueKey, { forcePlay = true })
            end
        end,
        disabled = function()
            return not GRIPEMS.Settings.db.profile.accessibility.soundCuesEnabled
        end,
        width = 0.5,
    }
end

-- Phase 4 item 22 Phase 2: per-cue Blizzard channel select. The four cue
-- groups (error / success / info / stepComplete) each get their own channel
-- routing. Width is 0.5 so the row fits LSM (1.5) + channel (0.5) = 2.0
-- before the preview button wraps to the next row.
local function SP_buildChannelRow(cueKey, channelSettingKey, orderNum, nameKey)
    local _ = cueKey
    return {
        type = "select",
        name = L[nameKey] or channelSettingKey,
        desc = L["ACCESS_SOUND_CHANNEL_PER_CUE_DESC"] or "",
        order = orderNum,
        values = {
            Master = "Master",
            SFX = "SFX",
            Ambience = "Ambience",
            Dialog = "Dialog",
        },
        sorting = { "Master", "SFX", "Ambience", "Dialog" },
        get = function()
            return GRIPEMS.Settings.db.profile.accessibility[channelSettingKey] or "Master"
        end,
        set = function(_, val)
            GRIPEMS.Settings.db.profile.accessibility[channelSettingKey] = val
        end,
        disabled = function()
            return not GRIPEMS.Settings.db.profile.accessibility.soundCuesEnabled
        end,
        width = 0.5,
    }
end

local function SP_ensureURLPopup()
    if GRIPEMS.Popup:GetDef("GRIPEMS_URL_POPUP") then
        return
    end
    GRIPEMS.Popup:Define("GRIPEMS_URL_POPUP", {
        text = L["ACCESS_FEEDBACK_POPUP_TEXT"],
        button1 = OKAY,
        hasEditBox = true,
        editBoxWidth = 350,
        OnShow = function(self)
            local eb = self.EditBox
            local data = self.data
            if eb then
                eb:SetText(data or "")
                eb:HighlightText()
                eb:SetFocus()
            end
        end,
        timeout = 0,
        hideOnEscape = true,
    })
end

local function SP_showURL(url)
    SP_ensureURLPopup()
    GRIPEMS.Popup:Show("GRIPEMS_URL_POPUP", nil, nil, url)
end

--- Initialize the settings panel. Registers AceConfig options and adds
--- to the Blizzard Settings panel. Called from Core.lua PLAYER_LOGIN.
function SP:Initialize()
    local AceConfig = LibStub("AceConfig-3.0")
    local AceConfigDialog = LibStub("AceConfigDialog-3.0")
    local AceDBOptions = LibStub("AceDBOptions-3.0")
    local S = GRIPEMS.Settings

    GRIPEMS:Debug("SettingsPanel:Initialize() - db exists: " .. tostring(S:GetDB() ~= nil))

    local options = {
        type = "group",
        name = "GRIP-EMS",
        childGroups = "tree",
        args = {
            overview = {
                type = "group",
                name = L["GEMS_OVERVIEW_NAME"],
                order = 5,
                args = {
                    title = {
                        type = "description",
                        name = "|cFF00CC66GRIP|r - Enhanced Macro Sequencer",
                        order = 1,
                        fontSize = "large",
                    },
                    version = {
                        type = "description",
                        name = function()
                            local v = "?"
                            if C_AddOns and C_AddOns.GetAddOnMetadata then
                                v = C_AddOns.GetAddOnMetadata(ADDON_NAME, "Version") or "?"
                            end
                            return string.format(L["GEMS_OVERVIEW_VERSION_LABEL"], v)
                        end,
                        order = 2,
                        fontSize = "medium",
                    },
                    welcome = {
                        type = "description",
                        name = L["GEMS_SETTINGS_HEADER_DESC"],
                        order = 3,
                        fontSize = "medium",
                    },
                    navigateHint = {
                        type = "description",
                        name = L["GEMS_OVERVIEW_NAVIGATE_HINT"],
                        order = 4,
                        fontSize = "medium",
                    },
                    helpButton = {
                        type = "execute",
                        name = L["ACCESS_GUIDE_BUTTON_LABEL"],
                        order = 10,
                        func = function()
                            SP_showURL("https://jesperlive.github.io/grip-ems-guide/")
                        end,
                    },
                    discordButton = {
                        type = "execute",
                        name = L["GEMS_OVERVIEW_DISCORD_BUTTON"],
                        order = 11,
                        func = function()
                            SP_showURL("https://discord.gg/temptingus")
                        end,
                    },
                    spacer = {
                        type = "description",
                        name = " ",
                        order = 90,
                    },
                    footer = {
                        type = "description",
                        name = "|cFF888888" .. L["GEMS_OVERVIEW_AUTHOR_LINE"] .. "|r",
                        order = 99,
                        fontSize = "small",
                    },
                },
            },
            general = {
                type = "group",
                name = L["GEMS_SETTINGS_GENERAL"],
                order = 10,
                args = {
                    oocDelay = {
                        type = "range",
                        name = L["GEMS_SETTINGS_OOC_DELAY"],
                        desc = L["GEMS_SETTINGS_OOC_DELAY_DESC"],
                        order = 1,
                        min = 1,
                        max = 60,
                        step = 1,
                        get = function()
                            return S:Get("oocDelay")
                        end,
                        set = function(_, v)
                            S:Set("oocDelay", v)
                        end,
                        width = "double",
                    },
                    resetOOC = {
                        type = "toggle",
                        name = L["GEMS_SETTINGS_RESET_OOC"],
                        desc = L["GEMS_SETTINGS_RESET_OOC_DESC"],
                        order = 3,
                        get = function()
                            return S:Get("resetOOC")
                        end,
                        set = function(_, v)
                            S:Set("resetOOC", v)
                        end,
                        width = "full",
                    },
                    autoReloadAtCombatEnd = {
                        type = "toggle",
                        name = L["GEMS_SETTINGS_AUTO_RELOAD"],
                        desc = L["GEMS_SETTINGS_AUTO_RELOAD_DESC"],
                        order = 4,
                        get = function()
                            return S:Get("autoReloadAtCombatEnd")
                        end,
                        set = function(_, v)
                            S:Set("autoReloadAtCombatEnd", v)
                        end,
                        width = "full",
                    },
                    showVariantsTab = {
                        type = "toggle",
                        name = L["GEMS_SETTINGS_SHOW_VARIANTS_TAB"],
                        desc = L["GEMS_SETTINGS_SHOW_VARIANTS_TAB_DESC"],
                        order = 5,
                        get = function()
                            return S:Get("showVariantsTab")
                        end,
                        set = function(_, v)
                            S:Set("showVariantsTab", v)
                        end,
                        width = "full",
                    },
                    msClickRate = {
                        type = "range",
                        name = function()
                            if S:Get("tempoAutoSet") and GRIPEMS.TempoAdvisor then
                                local eng = GRIPEMS.Engine
                                local activeSeq = eng and eng._lastClickedSequence
                                if activeSeq then
                                    local rec = GRIPEMS.TempoAdvisor:GetRecommendation(activeSeq)
                                    local ms = rec and (rec.blendedMs or rec.recommendedMs)
                                    if ms then
                                        return string.format(L["FS_AUTO_LABEL"], ms, activeSeq)
                                    end
                                end
                            end
                            return L["GEMS_SETTINGS_CLICK_RATE"]
                        end,
                        desc = L["GEMS_SETTINGS_CLICK_RATE_DESC"],
                        order = 6,
                        min = D().MS_CLICK_RATE_MIN,
                        max = D().MS_CLICK_RATE_MAX,
                        step = D().MS_CLICK_RATE_STEP,
                        get = function()
                            return S:Get("msClickRate")
                        end,
                        set = function(_, v)
                            S:Set("msClickRate", v)
                        end,
                        width = "double",
                    },
                    charClickRateHeader = {
                        type = "header",
                        name = L["GEMS_SETTINGS_CHAR_OVERRIDES"],
                        order = 7,
                    },
                    charClickRate = {
                        type = "range",
                        name = L["GEMS_SETTINGS_CHAR_CLICK_RATE"],
                        desc = L["GEMS_SETTINGS_CHAR_CLICK_RATE_DESC"],
                        order = 8,
                        min = 0,
                        max = D().MS_CLICK_RATE_MAX,
                        step = D().MS_CLICK_RATE_STEP,
                        get = function()
                            if GRIP_EMS_CHAR and GRIP_EMS_CHAR.msClickRate then
                                return GRIP_EMS_CHAR.msClickRate
                            end
                            return 0
                        end,
                        set = function(_, v)
                            S:SetCharClickRate(v)
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                        end,
                        width = "double",
                    },
                    charClickRateWarning = {
                        type = "description",
                        order = 9,
                        fontSize = "medium",
                        name = function()
                            local v = (GRIP_EMS_CHAR and GRIP_EMS_CHAR.msClickRate) or 0
                            local floor = D().MS_CLICK_RATE_MIN
                            if v == 0 or v >= floor then
                                return ""
                            end
                            local delta = floor - v
                            return UI:ColorCode("cvarAdvisoryWarn")
                                .. string.format(
                                    L["GEMS_SETTINGS_CHAR_CLICK_RATE_WARN"]
                                        or "Your setting: %dms (%dms faster than the %dms human/hardware floor)",
                                    v,
                                    delta,
                                    floor
                                )
                                .. "|r"
                        end,
                        hidden = function()
                            local v = (GRIP_EMS_CHAR and GRIP_EMS_CHAR.msClickRate) or 0
                            local floor = D().MS_CLICK_RATE_MIN
                            return v == 0 or v >= floor
                        end,
                        width = "full",
                    },
                    barIntegration = {
                        type = "toggle",
                        name = L["GEMS_BAR_INTEGRATION_HEADER"],
                        desc = L["GEMS_BAR_INTEGRATION_DESC"],
                        order = 10,
                        get = function()
                            return S:Get("barIntegration")
                        end,
                        set = function(_, v)
                            S:Set("barIntegration", v)
                        end,
                        width = "full",
                    },
                    keybindsPerLoadout = {
                        type = "toggle",
                        name = L["GEMS_KEYBINDS_PER_LOADOUT_TOGGLE"],
                        desc = L["GEMS_KEYBINDS_PER_LOADOUT_TOGGLE_TOOLTIP"],
                        order = 11,
                        get = function()
                            return GRIP_EMS_CHAR and GRIP_EMS_CHAR.keybindsPerLoadout or false
                        end,
                        set = function(_, v)
                            if not GRIP_EMS_CHAR then
                                return
                            end
                            GRIP_EMS_CHAR.keybindsPerLoadout = v
                            if GRIPEMS.KeybindManager and GRIPEMS.KeybindManager.ScheduleLoadKeybinds then
                                GRIPEMS.KeybindManager:ScheduleLoadKeybinds()
                            end
                            if GRIPEMS.KeybindTab and GRIPEMS.KeybindTab.RefreshDisplay then
                                GRIPEMS.KeybindTab:RefreshDisplay()
                            end
                        end,
                        width = "double",
                    },
                    macroRefAutoRefresh = {
                        type = "toggle",
                        name = L["GEMS_MACROREF_AUTOREFRESH"],
                        desc = L["GEMS_MACROREF_AUTOREFRESH_DESC"],
                        order = 12,
                        get = function()
                            return S:Get("macroRefAutoRefresh")
                        end,
                        set = function(_, v)
                            S:Set("macroRefAutoRefresh", v)
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                        end,
                        width = "full",
                    },
                },
            },
            ui = {
                type = "group",
                name = L["GEMS_SETTINGS_UI"],
                order = 20,
                args = {
                    hideLoginMsg = {
                        type = "toggle",
                        name = L["GEMS_SETTINGS_HIDE_LOGIN"],
                        desc = L["GEMS_SETTINGS_HIDE_LOGIN_DESC"],
                        order = 1,
                        get = function()
                            return S:Get("hideLoginMsg")
                        end,
                        set = function(_, v)
                            S:Set("hideLoginMsg", v)
                        end,
                        width = "full",
                    },
                    debug = {
                        type = "toggle",
                        name = L["GEMS_SETTINGS_DEBUG"],
                        desc = L["GEMS_SETTINGS_DEBUG_DESC"],
                        order = 2,
                        get = function()
                            return S:Get("debug")
                        end,
                        set = function(_, v)
                            S:Set("debug", v)
                        end,
                        width = "full",
                    },
                    showUnresolvedSpellWarnings = {
                        type = "toggle",
                        name = L["GEMS_SETTING_UNRESOLVED_WARN_LABEL"],
                        desc = L["GEMS_SETTING_UNRESOLVED_WARN_DESC"],
                        width = "full",
                        order = 3,
                        get = function()
                            return GRIPEMS.Settings:Get("showUnresolvedSpellWarnings")
                        end,
                        set = function(_, val)
                            GRIPEMS.Settings:Set("showUnresolvedSpellWarnings", val and true or false)
                        end,
                    },
                },
            },
            recorder = {
                type = "group",
                name = L["GEMS_SETTINGS_RECORDER_HEADER"],
                order = 29,
                args = {
                    recorderDedup = {
                        type = "toggle",
                        name = L["GEMS_SETTINGS_RECORDER_DEDUP"],
                        desc = L["GEMS_SETTINGS_RECORDER_DEDUP_DESC"],
                        order = 1,
                        get = function()
                            return S:Get("recorderDedup")
                        end,
                        set = function(_, v)
                            S:Set("recorderDedup", v)
                        end,
                        width = "full",
                    },
                },
            },
            editorColours = {
                type = "group",
                name = L["GEMS_SETTINGS_EDITOR_COLOURS"],
                order = 30,
                args = {
                    syntaxCommandColor = {
                        type = "color",
                        name = L["GEMS_SETTINGS_SYNTAX_COMMAND"],
                        desc = L["GEMS_SETTINGS_SYNTAX_COMMAND_DESC"],
                        hasAlpha = false,
                        order = 1,
                        get = function()
                            local c = S:Get("syntaxCommandColor")
                            return c[1], c[2], c[3]
                        end,
                        set = function(_, r, g, b)
                            S:Set("syntaxCommandColor", { r, g, b })
                        end,
                    },
                    syntaxConditionalColor = {
                        type = "color",
                        name = L["GEMS_SETTINGS_SYNTAX_CONDITIONAL"],
                        desc = L["GEMS_SETTINGS_SYNTAX_CONDITIONAL_DESC"],
                        hasAlpha = false,
                        order = 2,
                        get = function()
                            local c = S:Get("syntaxConditionalColor")
                            return c[1], c[2], c[3]
                        end,
                        set = function(_, r, g, b)
                            S:Set("syntaxConditionalColor", { r, g, b })
                        end,
                    },
                    syntaxVariableColor = {
                        type = "color",
                        name = L["GEMS_SETTINGS_SYNTAX_VARIABLE"],
                        desc = L["GEMS_SETTINGS_SYNTAX_VARIABLE_DESC"],
                        hasAlpha = false,
                        order = 3,
                        get = function()
                            local c = S:Get("syntaxVariableColor")
                            return c[1], c[2], c[3]
                        end,
                        set = function(_, r, g, b)
                            S:Set("syntaxVariableColor", { r, g, b })
                        end,
                    },
                    syntaxCommentColor = {
                        type = "color",
                        name = L["GEMS_SETTINGS_SYNTAX_COMMENT"],
                        desc = L["GEMS_SETTINGS_SYNTAX_COMMENT_DESC"],
                        hasAlpha = false,
                        order = 4,
                        get = function()
                            local c = S:Get("syntaxCommentColor")
                            return c[1], c[2], c[3]
                        end,
                        set = function(_, r, g, b)
                            S:Set("syntaxCommentColor", { r, g, b })
                        end,
                    },
                    syntaxResetColor = {
                        type = "color",
                        name = L["GEMS_SETTINGS_SYNTAX_RESET"],
                        desc = L["GEMS_SETTINGS_SYNTAX_RESET_DESC"],
                        hasAlpha = false,
                        order = 5,
                        get = function()
                            local c = S:Get("syntaxResetColor")
                            return c[1], c[2], c[3]
                        end,
                        set = function(_, r, g, b)
                            S:Set("syntaxResetColor", { r, g, b })
                        end,
                    },
                    syntaxNumberColor = {
                        type = "color",
                        name = L["GEMS_SETTINGS_SYNTAX_NUMBER"],
                        desc = L["GEMS_SETTINGS_SYNTAX_NUMBER_DESC"],
                        hasAlpha = false,
                        order = 6,
                        get = function()
                            local c = S:Get("syntaxNumberColor")
                            return c[1], c[2], c[3]
                        end,
                        set = function(_, r, g, b)
                            S:Set("syntaxNumberColor", { r, g, b })
                        end,
                    },
                },
            },
            sharing = {
                type = "group",
                name = L["GEMS_P2P_ENABLED"],
                order = 25,
                args = {
                    p2pEnabled = {
                        type = "toggle",
                        name = L["GEMS_P2P_ENABLED"],
                        desc = L["GEMS_P2P_ENABLED_DESC"],
                        order = 1,
                        get = function()
                            return S:Get("p2pEnabled")
                        end,
                        set = function(_, v)
                            S:Set("p2pEnabled", v)
                        end,
                        width = "full",
                    },
                    p2pAutoAcceptFriends = {
                        type = "toggle",
                        name = L["GEMS_P2P_AUTO_FRIENDS"],
                        desc = L["GEMS_P2P_AUTO_FRIENDS_DESC"],
                        order = 2,
                        get = function()
                            return S:Get("p2pAutoAcceptFriends")
                        end,
                        set = function(_, v)
                            S:Set("p2pAutoAcceptFriends", v)
                        end,
                        width = "full",
                    },
                    p2pAnnounceReceive = {
                        type = "toggle",
                        name = L["GEMS_P2P_ANNOUNCE"],
                        desc = L["GEMS_P2P_ANNOUNCE_DESC"],
                        order = 3,
                        get = function()
                            return S:Get("p2pAnnounceReceive")
                        end,
                        set = function(_, v)
                            S:Set("p2pAnnounceReceive", v)
                        end,
                        width = "full",
                    },
                },
            },
            blockedPlayers = {
                type = "group",
                name = L["GEMS_SETTINGS_BLOCKED_PLAYERS"],
                order = 26,
                args = {
                    desc = {
                        type = "description",
                        name = L["GEMS_SETTINGS_BLOCKED_PLAYERS_DESC"],
                        order = 1,
                        fontSize = "medium",
                    },
                    addPlayer = {
                        type = "input",
                        name = L["GEMS_BLOCK_ADDED"]:gsub(" from P2P transmission%.", ""),
                        desc = L["GEMS_HELP_BLOCK"],
                        order = 2,
                        width = "full",
                        set = function(_, v)
                            if v and v ~= "" then
                                local T = GRIPEMS.Transmission
                                if T then
                                    T:BlockPlayer(v)
                                end
                            end
                        end,
                        get = function()
                            return ""
                        end,
                    },
                    list = {
                        type = "description",
                        name = function()
                            local T = GRIPEMS.Transmission
                            if not T then
                                return ""
                            end
                            local blocked = T:GetBlockedList()
                            if #blocked == 0 then
                                return "\n" .. L["GEMS_BLOCK_LIST_EMPTY"]
                            end
                            local lines = { "\n" .. L["GEMS_BLOCK_LIST_HEADER"] }
                            for _, n in ipairs(blocked) do
                                lines[#lines + 1] = "  " .. Ambiguate(n, "none")
                            end
                            return table.concat(lines, "\n")
                        end,
                        order = 3,
                        fontSize = "medium",
                    },
                    removePlayer = {
                        type = "input",
                        name = L["GEMS_BLOCK_REMOVED"]:gsub("%.", ""),
                        desc = L["GEMS_HELP_UNBLOCK"],
                        order = 4,
                        width = "full",
                        set = function(_, v)
                            if v and v ~= "" then
                                local T = GRIPEMS.Transmission
                                if T then
                                    T:UnblockPlayer(v)
                                end
                            end
                        end,
                        get = function()
                            return ""
                        end,
                    },
                },
            },
            authorshipPrivacy = {
                type = "group",
                name = L["GEMS_PRIVACY_GROUP_NAME"],
                order = 28,
                args = {
                    privacyDefault = {
                        type = "select",
                        name = L["GEMS_PRIVACY_DEFAULT_LABEL"],
                        desc = L["GEMS_PRIVACY_DEFAULT_DESC"],
                        order = 10,
                        values = {
                            public = L["GEMS_PRIVACY_MODE_PUBLIC"],
                            pseudonymous = L["GEMS_PRIVACY_MODE_PSEUDONYMOUS"],
                            private = L["GEMS_PRIVACY_MODE_PRIVATE"],
                        },
                        get = function()
                            local cfg = _G.GRIP_EMS_DB and _G.GRIP_EMS_DB.config
                            return (cfg and cfg.privacyDefault) or "public"
                        end,
                        set = function(_, v)
                            _G.GRIP_EMS_DB = _G.GRIP_EMS_DB or {}
                            _G.GRIP_EMS_DB.config = _G.GRIP_EMS_DB.config or {}
                            _G.GRIP_EMS_DB.config.privacyDefault = v
                        end,
                        width = "double",
                    },
                    pseudonym = {
                        type = "input",
                        name = L["GEMS_PRIVACY_PSEUDONYM_LABEL"],
                        desc = L["GEMS_PRIVACY_PSEUDONYM_DESC"],
                        order = 20,
                        get = function()
                            local cfg = _G.GRIP_EMS_DB and _G.GRIP_EMS_DB.config
                            return (cfg and cfg.pseudonym) or "Anonymous"
                        end,
                        set = function(_, v)
                            _G.GRIP_EMS_DB = _G.GRIP_EMS_DB or {}
                            _G.GRIP_EMS_DB.config = _G.GRIP_EMS_DB.config or {}
                            _G.GRIP_EMS_DB.config.pseudonym = v
                        end,
                        width = "double",
                    },
                    showProvenanceBadges = {
                        type = "toggle",
                        name = L["GEMS_PRIVACY_SHOW_BADGES_LABEL"],
                        desc = L["GEMS_PRIVACY_SHOW_BADGES_DESC"],
                        order = 30,
                        get = function()
                            local cfg = _G.GRIP_EMS_DB and _G.GRIP_EMS_DB.config
                            if cfg and cfg.showProvenanceBadges == false then
                                return false
                            end
                            return true
                        end,
                        set = function(_, v)
                            _G.GRIP_EMS_DB = _G.GRIP_EMS_DB or {}
                            _G.GRIP_EMS_DB.config = _G.GRIP_EMS_DB.config or {}
                            _G.GRIP_EMS_DB.config.showProvenanceBadges = v
                        end,
                        width = "full",
                    },
                },
            },
            macroReset = {
                type = "group",
                name = L["GEMS_SETTINGS_MACRO_RESET"],
                order = 15,
                args = (function()
                    local args = {}
                    -- Mouse buttons
                    args.mouseHeader = {
                        type = "header",
                        name = L["GEMS_RESET_MOD_MOUSE_HEADER"],
                        order = 1,
                    }
                    local mouseKeys = { "LeftButton", "RightButton", "MiddleButton", "Button4", "Button5" }
                    for i, mod in ipairs(mouseKeys) do
                        args["reset_" .. mod] = {
                            type = "toggle",
                            name = L["GEMS_RESET_MOD_" .. strupper(mod)],
                            desc = L["GEMS_RESET_MOD_DESC"],
                            order = 1 + i,
                            get = function()
                                local mods = S:GetResetModifiers()
                                return mods[mod]
                            end,
                            set = function(_, v)
                                S:SetResetModifier(mod, v)
                            end,
                            width = "normal",
                        }
                    end
                    -- Alt keys
                    args.altHeader = {
                        type = "header",
                        name = L["GEMS_RESET_MOD_ALT_HEADER"],
                        order = 7,
                    }
                    local altKeys = { "LeftAlt", "RightAlt", "Alt" }
                    for i, mod in ipairs(altKeys) do
                        args["reset_" .. mod] = {
                            type = "toggle",
                            name = L["GEMS_RESET_MOD_" .. strupper(mod)],
                            desc = L["GEMS_RESET_MOD_DESC"],
                            order = 7 + i,
                            get = function()
                                local mods = S:GetResetModifiers()
                                return mods[mod]
                            end,
                            set = function(_, v)
                                S:SetResetModifier(mod, v)
                            end,
                            width = "normal",
                        }
                    end
                    -- Control keys
                    args.controlHeader = {
                        type = "header",
                        name = L["GEMS_RESET_MOD_CONTROL_HEADER"],
                        order = 11,
                    }
                    local ctrlKeys = { "LeftControl", "RightControl", "Control" }
                    for i, mod in ipairs(ctrlKeys) do
                        args["reset_" .. mod] = {
                            type = "toggle",
                            name = L["GEMS_RESET_MOD_" .. strupper(mod)],
                            desc = L["GEMS_RESET_MOD_DESC"],
                            order = 11 + i,
                            get = function()
                                local mods = S:GetResetModifiers()
                                return mods[mod]
                            end,
                            set = function(_, v)
                                S:SetResetModifier(mod, v)
                            end,
                            width = "normal",
                        }
                    end
                    -- Shift keys
                    args.shiftHeader = {
                        type = "header",
                        name = L["GEMS_RESET_MOD_SHIFT_HEADER"],
                        order = 15,
                    }
                    local shiftKeys = { "LeftShift", "RightShift", "Shift" }
                    for i, mod in ipairs(shiftKeys) do
                        args["reset_" .. mod] = {
                            type = "toggle",
                            name = L["GEMS_RESET_MOD_" .. strupper(mod)],
                            desc = L["GEMS_RESET_MOD_DESC"],
                            order = 15 + i,
                            get = function()
                                local mods = S:GetResetModifiers()
                                return mods[mod]
                            end,
                            set = function(_, v)
                                S:SetResetModifier(mod, v)
                            end,
                            width = "normal",
                        }
                    end
                    -- Any modifier
                    args.anyHeader = {
                        type = "header",
                        name = L["GEMS_RESET_MOD_ANY_HEADER"],
                        order = 19,
                    }
                    args.reset_AnyMod = {
                        type = "toggle",
                        name = L["GEMS_RESET_MOD_ANYMOD"],
                        desc = L["GEMS_RESET_MOD_DESC"],
                        order = 20,
                        get = function()
                            local mods = S:GetResetModifiers()
                            return mods["AnyMod"]
                        end,
                        set = function(_, v)
                            S:SetResetModifier("AnyMod", v)
                        end,
                        width = "normal",
                    }
                    return args
                end)(),
            },
            holdToFreeze = {
                type = "group",
                name = L["GEMS_HOLD_FREEZE_HEADER"],
                order = 16,
                args = {
                    enable = {
                        type = "toggle",
                        name = L["GEMS_HOLD_FREEZE_ENABLE"],
                        desc = L["GEMS_HOLD_FREEZE_ENABLE_DESC"],
                        order = 1,
                        width = "full",
                        get = function()
                            return S:GetHoldToFreeze().enabled
                        end,
                        set = function(_, v)
                            S:SetHoldToFreeze(v, nil)
                            if v then
                                GRIPEMS.Settings:WarnFreezeConflicts()
                            end
                        end,
                    },
                    modifier = {
                        type = "select",
                        name = L["GEMS_HOLD_FREEZE_MODIFIER"],
                        desc = L["GEMS_HOLD_FREEZE_MODIFIER_DESC"],
                        order = 2,
                        width = "normal",
                        values = {
                            shift = L["GEMS_HOLD_FREEZE_MOD_SHIFT"],
                            ctrl = L["GEMS_HOLD_FREEZE_MOD_CTRL"],
                            alt = L["GEMS_HOLD_FREEZE_MOD_ALT"],
                        },
                        disabled = function()
                            return not S:GetHoldToFreeze().enabled
                        end,
                        get = function()
                            return S:GetHoldToFreeze().modifier
                        end,
                        set = function(_, v)
                            S:SetHoldToFreeze(nil, v)
                            GRIPEMS.Settings:WarnFreezeConflicts()
                        end,
                    },
                },
            },
            tracker = {
                type = "group",
                name = L["GEMS_TRACKER_HEADER"],
                order = 27,
                args = {
                    trackerShowMode = {
                        type = "select",
                        name = L["GEMS_TRACKER_HEADER"],
                        desc = L["GEMS_TRACKER_SHOWMODE_DESC"],
                        order = 1,
                        values = {
                            ALWAYS = L["GEMS_TRACKER_MODE_ALWAYS"],
                            COMBAT = L["GEMS_TRACKER_MODE_COMBAT"],
                            TARGET = L["GEMS_TRACKER_MODE_TARGET"],
                            NEVER = L["GEMS_TRACKER_MODE_NEVER"],
                        },
                        get = function()
                            return S:Get("trackerShowMode")
                        end,
                        set = function(_, v)
                            S:Set("trackerShowMode", v)
                        end,
                        width = "double",
                    },
                    trackerIconSize = {
                        type = "range",
                        name = L["GEMS_TRACKER_ICONSIZE_DESC"],
                        desc = L["GEMS_TRACKER_ICONSIZE_DESC"],
                        order = 2,
                        min = 20,
                        max = 80,
                        step = 2,
                        get = function()
                            return S:Get("trackerIconSize")
                        end,
                        set = function(_, v)
                            S:Set("trackerIconSize", v)
                        end,
                        width = "double",
                    },
                    trackerOrientation = {
                        type = "select",
                        name = L["GEMS_TRACKER_ORIENTATION_DESC"],
                        desc = L["GEMS_TRACKER_ORIENTATION_DESC"],
                        order = 3,
                        values = {
                            HORIZONTAL = "Horizontal",
                            VERTICAL = "Vertical",
                        },
                        get = function()
                            return S:Get("trackerOrientation")
                        end,
                        set = function(_, v)
                            S:Set("trackerOrientation", v)
                        end,
                        width = "normal",
                    },
                    trackerShowName = {
                        type = "toggle",
                        name = L["GEMS_TRACKER_SHOWNAME_DESC"],
                        desc = L["GEMS_TRACKER_SHOWNAME_DESC"],
                        order = 4,
                        get = function()
                            return S:Get("trackerShowName")
                        end,
                        set = function(_, v)
                            S:Set("trackerShowName", v)
                        end,
                        width = "full",
                    },
                    trackerShowModifiers = {
                        type = "toggle",
                        name = L["GEMS_TRACKER_SHOWMODS_DESC"],
                        desc = L["GEMS_TRACKER_SHOWMODS_DESC"],
                        order = 5,
                        get = function()
                            return S:Get("trackerShowModifiers")
                        end,
                        set = function(_, v)
                            S:Set("trackerShowModifiers", v)
                        end,
                        width = "full",
                    },
                    trackerLocked = {
                        type = "toggle",
                        name = L["GEMS_TRACKER_LOCK_DESC"],
                        desc = L["GEMS_TRACKER_LOCK_DESC"],
                        order = 6,
                        get = function()
                            return S:Get("trackerLocked")
                        end,
                        set = function(_, v)
                            S:Set("trackerLocked", v)
                        end,
                        width = "full",
                    },
                    trackerScale = {
                        type = "range",
                        name = L["GEMS_TRACKER_SCALE_DESC"],
                        desc = L["GEMS_TRACKER_SCALE_DESC"],
                        order = 7,
                        min = 0.5,
                        max = 2.0,
                        step = 0.05,
                        isPercent = true,
                        get = function()
                            return S:Get("trackerScale")
                        end,
                        set = function(_, v)
                            S:Set("trackerScale", v)
                        end,
                        width = "double",
                    },
                    trackerVariantIndicators = {
                        type = "toggle",
                        name = L["GEMS_SETTINGS_VARIANT_INDICATORS_TRACKER"],
                        desc = L["GEMS_SETTINGS_VARIANT_INDICATORS_TRACKER_DESC"],
                        order = 8,
                        get = function()
                            return S:Get("trackerVariantIndicators")
                        end,
                        set = function(_, v)
                            S:Set("trackerVariantIndicators", v)
                        end,
                        width = "full",
                    },
                    barVariantIndicators = {
                        type = "toggle",
                        name = L["GEMS_SETTINGS_VARIANT_INDICATORS_BAR"],
                        desc = L["GEMS_SETTINGS_VARIANT_INDICATORS_BAR_DESC"],
                        order = 9,
                        get = function()
                            return S:Get("barVariantIndicators")
                        end,
                        set = function(_, v)
                            S:Set("barVariantIndicators", v)
                        end,
                        width = "full",
                    },
                },
            },
            floatingMenu = {
                type = "group",
                name = L["GEMS_FLOATING_HEADER"],
                order = 28,
                args = {
                    floatingMenuShow = {
                        type = "toggle",
                        name = L["GEMS_FLOATING_HEADER"],
                        desc = L["GEMS_FLOATING_SHOW_DESC"],
                        order = 1,
                        get = function()
                            return S:Get("floatingMenuShow")
                        end,
                        set = function(_, v)
                            S:Set("floatingMenuShow", v)
                        end,
                        width = "full",
                    },
                    floatingMenuDirection = {
                        type = "select",
                        name = L["GEMS_FLOATING_DIRECTION_DESC"],
                        desc = L["GEMS_FLOATING_DIRECTION_DESC"],
                        order = 2,
                        values = {
                            UP = L["GEMS_FLOATING_DIR_UP"],
                            DOWN = L["GEMS_FLOATING_DIR_DOWN"],
                            LEFT = L["GEMS_FLOATING_DIR_LEFT"],
                            RIGHT = L["GEMS_FLOATING_DIR_RIGHT"],
                        },
                        get = function()
                            return S:Get("floatingMenuDirection")
                        end,
                        set = function(_, v)
                            S:Set("floatingMenuDirection", v)
                        end,
                        width = "normal",
                    },
                    floatingMenuLocked = {
                        type = "toggle",
                        name = L["GEMS_FLOATING_LOCK_DESC"],
                        desc = L["GEMS_FLOATING_LOCK_DESC"],
                        order = 3,
                        get = function()
                            return S:Get("floatingMenuLocked")
                        end,
                        set = function(_, v)
                            S:Set("floatingMenuLocked", v)
                        end,
                        width = "full",
                    },
                    floatingMenuScale = {
                        type = "range",
                        name = L["GEMS_FLOATING_SCALE_DESC"],
                        desc = L["GEMS_FLOATING_SCALE_DESC"],
                        order = 4,
                        min = 0.5,
                        max = 2.0,
                        step = 0.1,
                        isPercent = true,
                        get = function()
                            return S:Get("floatingMenuScale")
                        end,
                        set = function(_, v)
                            S:Set("floatingMenuScale", v)
                        end,
                        width = "double",
                    },
                },
            },
            fasterSlower = {
                type = "group",
                name = L["FS_STATUS_HEADER"],
                order = 34,
                args = {
                    tempoAutoSet = {
                        type = "toggle",
                        name = L["FS_AUTO_SET"],
                        desc = L["FS_AUTO_SET_DESC"],
                        order = 1,
                        get = function()
                            return S:Get("tempoAutoSet")
                        end,
                        set = function(_, v)
                            S:Set("tempoAutoSet", v)
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                        end,
                        width = "full",
                    },
                    tempoOverlayShown = {
                        type = "toggle",
                        name = L["FS_OVERLAY_SHOWN"],
                        order = 2,
                        get = function()
                            return S:Get("tempoOverlayShown")
                        end,
                        set = function(_, v)
                            S:Set("tempoOverlayShown", v)
                        end,
                        width = "full",
                    },
                    tempoSparkline = {
                        type = "toggle",
                        name = L["FS_SPARKLINE"],
                        order = 3,
                        get = function()
                            return S:Get("tempoSparkline")
                        end,
                        set = function(_, v)
                            S:Set("tempoSparkline", v)
                        end,
                        width = "full",
                    },
                    alertHeader = {
                        type = "header",
                        name = "",
                        order = 10,
                    },
                    tempoAlertEnabled = {
                        type = "toggle",
                        name = L["FS_ALERT_ENABLED"],
                        order = 11,
                        get = function()
                            return S:Get("tempoAlertEnabled")
                        end,
                        set = function(_, v)
                            S:Set("tempoAlertEnabled", v)
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                        end,
                        width = "full",
                    },
                    tempoAlertVisual = {
                        type = "toggle",
                        name = "  " .. L["FS_ALERT_VISUAL"],
                        order = 12,
                        get = function()
                            return S:Get("tempoAlertVisual")
                        end,
                        set = function(_, v)
                            S:Set("tempoAlertVisual", v)
                        end,
                        hidden = function()
                            return not S:Get("tempoAlertEnabled")
                        end,
                        width = "full",
                    },
                    tempoAlertAudio = {
                        type = "toggle",
                        name = "  " .. L["FS_ALERT_AUDIO"],
                        order = 13,
                        get = function()
                            return S:Get("tempoAlertAudio")
                        end,
                        set = function(_, v)
                            S:Set("tempoAlertAudio", v)
                        end,
                        hidden = function()
                            return not S:Get("tempoAlertEnabled")
                        end,
                        width = "full",
                    },
                    tempoAlertSoundSlow = {
                        type = "select",
                        name = "  " .. L["FS_ALERT_SOUND_SLOW"],
                        order = 14,
                        values = {
                            [43505] = "Raid Warning",
                            [37666] = "Toast Notification",
                            [8959] = "Ready Check",
                        },
                        get = function()
                            return S:Get("tempoAlertSoundSlow")
                        end,
                        set = function(_, v)
                            S:Set("tempoAlertSoundSlow", v)
                        end,
                        hidden = function()
                            return not S:Get("tempoAlertEnabled") or not S:Get("tempoAlertAudio")
                        end,
                        width = "normal",
                    },
                    tempoAlertTestSlow = {
                        type = "execute",
                        name = L["FS_ALERT_TEST"],
                        order = 14.1,
                        func = function()
                            local channel = S:Get("tempoAlertChannel") or "Master"
                            PlaySound(S:Get("tempoAlertSoundSlow") or 43505, channel)
                        end,
                        hidden = function()
                            return not S:Get("tempoAlertEnabled") or not S:Get("tempoAlertAudio")
                        end,
                        width = "half",
                    },
                    tempoAlertSoundFast = {
                        type = "select",
                        name = "  " .. L["FS_ALERT_SOUND_FAST"],
                        order = 15,
                        values = {
                            [43505] = "Raid Warning",
                            [37666] = "Toast Notification",
                            [8959] = "Ready Check",
                        },
                        get = function()
                            return S:Get("tempoAlertSoundFast")
                        end,
                        set = function(_, v)
                            S:Set("tempoAlertSoundFast", v)
                        end,
                        hidden = function()
                            return not S:Get("tempoAlertEnabled") or not S:Get("tempoAlertAudio")
                        end,
                        width = "normal",
                    },
                    tempoAlertTestFast = {
                        type = "execute",
                        name = L["FS_ALERT_TEST"],
                        order = 15.1,
                        func = function()
                            local channel = S:Get("tempoAlertChannel") or "Master"
                            PlaySound(S:Get("tempoAlertSoundFast") or 37666, channel)
                        end,
                        hidden = function()
                            return not S:Get("tempoAlertEnabled") or not S:Get("tempoAlertAudio")
                        end,
                        width = "half",
                    },
                    tempoAlertChannel = {
                        type = "select",
                        name = "  " .. L["FS_ALERT_CHANNEL"],
                        order = 16,
                        values = {
                            Master = "Master",
                            SFX = "Sound Effects",
                            Music = "Music",
                            Ambience = "Ambience",
                            Dialog = "Dialog",
                        },
                        get = function()
                            return S:Get("tempoAlertChannel")
                        end,
                        set = function(_, v)
                            S:Set("tempoAlertChannel", v)
                        end,
                        hidden = function()
                            return not S:Get("tempoAlertEnabled") or not S:Get("tempoAlertAudio")
                        end,
                        width = "normal",
                    },
                    tempoAlertSlowThreshold = {
                        type = "range",
                        name = L["FS_ALERT_SLOW"],
                        order = 20,
                        min = 0.3,
                        max = 0.9,
                        step = 0.1,
                        isPercent = true,
                        get = function()
                            return S:Get("tempoAlertSlowThreshold")
                        end,
                        set = function(_, v)
                            S:Set("tempoAlertSlowThreshold", v)
                        end,
                        hidden = function()
                            return not S:Get("tempoAlertEnabled")
                        end,
                        width = "double",
                    },
                    tempoAlertFastThreshold = {
                        type = "range",
                        name = L["FS_ALERT_FAST"],
                        order = 21,
                        min = 1.5,
                        max = 3.0,
                        step = 0.1,
                        get = function()
                            return S:Get("tempoAlertFastThreshold")
                        end,
                        set = function(_, v)
                            S:Set("tempoAlertFastThreshold", v)
                        end,
                        hidden = function()
                            return not S:Get("tempoAlertEnabled")
                        end,
                        width = "double",
                    },
                    holdHeader = {
                        type = "header",
                        name = "",
                        order = 30,
                        hidden = true,
                    },
                    holdModeEnabled = {
                        type = "toggle",
                        name = L["FS_HOLD_ENABLED"],
                        desc = L["FS_HOLD_ENABLED_DESC"],
                        order = 31,
                        hidden = true,
                        get = function()
                            return S:Get("holdModeEnabled")
                        end,
                        set = function(_, v)
                            S:Set("holdModeEnabled", v)
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                        end,
                        width = "full",
                    },
                    holdModeSlot = {
                        type = "input",
                        name = L["FS_HOLD_SLOT"],
                        desc = L["FS_HOLD_SLOT_DESC"],
                        order = 32,
                        get = function()
                            return S:Get("holdModeSlot")
                        end,
                        set = function(_, v)
                            S:Set("holdModeSlot", v)
                        end,
                        hidden = function()
                            return not S:Get("holdModeEnabled")
                        end,
                        width = "double",
                    },
                    holdModePollRateMin = {
                        type = "range",
                        name = L["FS_HOLD_POLL_MIN"],
                        desc = L["FS_HOLD_POLL_MIN_DESC"],
                        order = 33,
                        min = 25,
                        max = 200,
                        step = 5,
                        get = function()
                            return S:Get("holdModePollRateMin")
                        end,
                        set = function(_, v)
                            S:Set("holdModePollRateMin", v)
                        end,
                        hidden = function()
                            return not S:Get("holdModeEnabled")
                        end,
                        width = "double",
                    },
                    holdModeNote = {
                        type = "description",
                        name = L["FS_HOLD_NOTE"],
                        order = 34,
                        fontSize = "small",
                        hidden = function()
                            return not S:Get("holdModeEnabled")
                        end,
                    },
                },
            },
            cvarHealth = {
                type = "group",
                name = L["GEMS_SETTINGS_CVAR_HEALTH"],
                order = 35,
                args = (function()
                    local args = {}
                    local CPM = GRIPEMS.CvarProfileManager
                    -- G5: lock to prevent overlapping Fix All Critical throttled tickers from concurrent clicks.
                    -- Closure-scope so it persists for the panel's lifetime; reset to false when each ticker completes.
                    local fixAllInProgress = false
                    -- G12: lock for the Reset-to-Defaults throttled ticker, paired with the
                    -- closure-scope target cache populated by the args.resetDefaults handler
                    -- and consumed by the StaticPopup OnAccept body.
                    local resetInProgress = false
                    local pendingResetTargets = {}
                    -- G.4d (G22): one-shot first-run onboarding popup gate.
                    -- Closure-scope flag prevents repeat triggers within a session;
                    -- SV flag (cvarHealthOnboardingShown) prevents triggers across sessions.
                    local onboardingTriggered = false
                    if not GRIPEMS.Popup:GetDef("GRIPEMS_CVAR_HEALTH_ONBOARDING") then
                        GRIPEMS.Popup:Define("GRIPEMS_CVAR_HEALTH_ONBOARDING", {
                            text = L["GEMS_CVAR_ONBOARDING_BODY"],
                            button1 = OKAY,
                            OnAccept = function()
                                -- G.4d L376: account-wide gate, not profile-scoped.
                                if S and S.db and S.db.global then
                                    S.db.global.cvarHealthOnboardingShown = true
                                end
                            end,
                            OnCancel = function()
                                if S and S.db and S.db.global then
                                    S.db.global.cvarHealthOnboardingShown = true
                                end
                            end,
                            timeout = 0,
                            hideOnEscape = true,
                        })
                    end
                    -- G12: confirmation dialog for Reset-to-Defaults. The throttled apply
                    -- mirrors Fix All Critical (5 SetCVars per 0.05s tick, CapturePrevious
                    -- before each SetCVar so per-row Undo can revert any individual reset).
                    if not GRIPEMS.Popup:GetDef("GRIPEMS_CVAR_RESET_DEFAULTS_CONFIRM") then
                        GRIPEMS.Popup:Define("GRIPEMS_CVAR_RESET_DEFAULTS_CONFIRM", {
                            text = L["GEMS_CVAR_RESET_DEFAULTS_CONFIRM"],
                            button1 = YES,
                            button2 = NO,
                            OnAccept = function()
                                if InCombatLockdown() then
                                    GRIPEMS:Print(L["GEMS_CVAR_COMBAT_DISABLED"])
                                    return
                                end
                                -- G.5-POLISH-STATE-CHANGES-MID-POPUP (L377):
                                -- Re-collect the live targets list and intersect with the
                                -- click-time pendingResetTargets snapshot. Drops any CVar
                                -- that became pinned or SQW-managed between click and
                                -- Yes-confirm. The per-tick pin re-check below handles
                                -- gestures placed AFTER Yes-confirm, mid-throttle.
                                if CPM and CPM.GetResetToDefaultsTargets then
                                    local freshTargets = CPM:GetResetToDefaultsTargets()
                                    local freshSet = {}
                                    for _, t in ipairs(freshTargets) do
                                        freshSet[t.cvar] = t.default
                                    end
                                    local filtered = {}
                                    for _, t in ipairs(pendingResetTargets) do
                                        if freshSet[t.cvar] ~= nil then
                                            table.insert(filtered, t)
                                        end
                                    end
                                    pendingResetTargets = filtered
                                end
                                local total = #pendingResetTargets
                                if total == 0 then
                                    return
                                end
                                resetInProgress = true
                                GRIPEMS:Print(string.format(L["GEMS_CVAR_RESET_DEFAULTS_BUSY"], total))
                                local idx = 1
                                local ticker
                                local resetDetails = {}
                                if C_Timer and C_Timer.NewTicker then
                                    ticker = C_Timer.NewTicker(0.05, function()
                                        local stop = math.min(idx + 4, total)
                                        for i = idx, stop do
                                            local t = pendingResetTargets[i]
                                            -- G5-FOLLOWUP-RESET-PIN-RECHECK-AT-TICK: respect mid-throttle pin gestures.
                                            -- Pin is ironclad; a pin click placed between the Reset to Defaults OK
                                            -- click and this tick must win over the click-time pendingResetTargets
                                            -- snapshot. GetResetToDefaultsTargets filters out pre-pinned CVars at
                                            -- click time; this re-check catches pins added DURING the throttle.
                                            local pinned = CPM and CPM.IsPinned and CPM:IsPinned(t.cvar)
                                            if not pinned then
                                                local prev = GetCVar(t.cvar)
                                                -- G5-POLISH-COMBAT-MID-THROTTLE: SetCVar silently no-ops on secure CVars in
                                                -- combat lockdown. Gate CapturePrevious + details on success so
                                                -- cvarPreviousValues and ReloadGate Notify only reflect CVars that actually
                                                -- changed.
                                                -- G.4-CAUSE-ATTRIBUTION-PANEL-FIX-PATHS: stamp BEFORE SetCVar so the
                                                -- ticker classifies this Reset as AUTOFIX, not ADDON.
                                                if CPM and CPM.MarkAutoFixed then
                                                    CPM:MarkAutoFixed(t.cvar)
                                                end
                                                local success = SetCVar(t.cvar, t.default)
                                                if success then
                                                    if CPM and CPM.CapturePrevious then
                                                        CPM:CapturePrevious(t.cvar, prev)
                                                    end
                                                    table.insert(
                                                        resetDetails,
                                                        { cvar = t.cvar, from = prev, to = t.default }
                                                    )
                                                end
                                            end
                                        end
                                        idx = stop + 1
                                        if idx > total then
                                            if ticker and ticker.Cancel then
                                                ticker:Cancel()
                                            end
                                            if CPM and CPM.ClearAutoFixEntries then
                                                CPM:ClearAutoFixEntries()
                                            end
                                            if CPM and CPM.RebuildSnapshot then
                                                CPM:RebuildSnapshot()
                                            end
                                            pendingResetTargets = {}
                                            resetInProgress = false
                                            -- G5-FOLLOWUP-COUNT-INTENT-VS-OUTCOME-DRIFT: broadcast actual changes
                                            -- (#resetDetails) not click-time intent (total).
                                            local resetMsg
                                            if #resetDetails < total then
                                                resetMsg = string.format(
                                                    L["GEMS_CVAR_RESET_DEFAULTS_DONE_PARTIAL"],
                                                    #resetDetails,
                                                    total,
                                                    total - #resetDetails
                                                )
                                            else
                                                resetMsg =
                                                    string.format(L["GEMS_CVAR_RESET_DEFAULTS_DONE"], #resetDetails)
                                            end
                                            GRIPEMS:Print(resetMsg)
                                            -- G8-AUDIT-19b: announce completion to Tier A TTS users.
                                            if GRIPEMS.Speech and GRIPEMS.Speech.Announce then
                                                GRIPEMS.Speech:Announce(resetMsg)
                                            end
                                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                                            if GRIPEMS.ReloadGate and GRIPEMS.ReloadGate.Notify then
                                                GRIPEMS.ReloadGate:Notify("RESET_DEFAULTS", #resetDetails, resetDetails)
                                            end
                                        end
                                    end)
                                -- G5-POLISH-CTIMER-DEFENSIVE-GUARD: sync fallback when C_Timer is
                                -- missing. Mirrors scoreTicker pattern below. Should never trigger
                                -- on Retail 12.0+.
                                else
                                    for i = 1, total do
                                        local t = pendingResetTargets[i]
                                        local prev = GetCVar(t.cvar)
                                        -- G5-POLISH-COMBAT-MID-THROTTLE: SetCVar silently no-ops on secure CVars in
                                        -- combat lockdown. Gate CapturePrevious + details on success so
                                        -- cvarPreviousValues and ReloadGate Notify only reflect CVars that actually
                                        -- changed.
                                        -- G.4-CAUSE-ATTRIBUTION-PANEL-FIX-PATHS: stamp BEFORE SetCVar so the
                                        -- ticker classifies this Reset as AUTOFIX, not ADDON.
                                        if CPM and CPM.MarkAutoFixed then
                                            CPM:MarkAutoFixed(t.cvar)
                                        end
                                        local success = SetCVar(t.cvar, t.default)
                                        if success then
                                            if CPM and CPM.CapturePrevious then
                                                CPM:CapturePrevious(t.cvar, prev)
                                            end
                                            table.insert(resetDetails, { cvar = t.cvar, from = prev, to = t.default })
                                        end
                                    end
                                    if CPM and CPM.ClearAutoFixEntries then
                                        CPM:ClearAutoFixEntries()
                                    end
                                    if CPM and CPM.RebuildSnapshot then
                                        CPM:RebuildSnapshot()
                                    end
                                    pendingResetTargets = {}
                                    resetInProgress = false
                                    -- G5-FOLLOWUP-COUNT-INTENT-VS-OUTCOME-DRIFT: broadcast actual changes
                                    -- (#resetDetails) not click-time intent (total).
                                    local resetMsg
                                    if #resetDetails < total then
                                        resetMsg = string.format(
                                            L["GEMS_CVAR_RESET_DEFAULTS_DONE_PARTIAL"],
                                            #resetDetails,
                                            total,
                                            total - #resetDetails
                                        )
                                    else
                                        resetMsg = string.format(L["GEMS_CVAR_RESET_DEFAULTS_DONE"], #resetDetails)
                                    end
                                    GRIPEMS:Print(resetMsg)
                                    if GRIPEMS.Speech and GRIPEMS.Speech.Announce then
                                        GRIPEMS.Speech:Announce(resetMsg)
                                    end
                                    LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                                    if GRIPEMS.ReloadGate and GRIPEMS.ReloadGate.Notify then
                                        GRIPEMS.ReloadGate:Notify("RESET_DEFAULTS", #resetDetails, resetDetails)
                                    end
                                end
                            end,
                            timeout = 0,
                            hideOnEscape = true,
                        })
                    end
                    local function CleanNumber(val)
                        if val == nil then
                            return "?"
                        end
                        local num = tonumber(val)
                        if num then
                            local s = string.format("%.4f", num)
                            s = s:gsub("%.?0+$", "")
                            return s
                        end
                        return val
                    end
                    local function GetEffective(cvarName)
                        if CPM then
                            return CPM:GetEffectiveRecommendation(cvarName)
                        end
                        -- Fallback to General if CPM not loaded
                        for _, sec in ipairs(D().CVAR_SECTIONS) do
                            for _, rec in ipairs(sec.cvars) do
                                if rec.cvar == cvarName then
                                    return rec.recommended
                                end
                            end
                        end
                        return nil
                    end
                    local function ComputeSectionScore(section)
                        local total, matched = 0, 0
                        local SQWO = GRIPEMS.SQWOptimizer
                        local sqwManaged = SQWO and SQWO:IsActive()
                        for _, rec in ipairs(section.cvars) do
                            local eff = GetEffective(rec.cvar)
                            if eff ~= nil then
                                total = total + 1
                                if rec.cvar == "SpellQueueWindow" and sqwManaged then
                                    matched = matched + 1
                                elseif CPM and CPM.IsPinned and CPM:IsPinned(rec.cvar) then
                                    -- G17: pinned CVars credit as matched (user-intentional override)
                                    matched = matched + 1
                                elseif D().CvarMatch(GetCVar(rec.cvar) or "", eff) then
                                    matched = matched + 1
                                end
                            end
                        end
                        return matched, total
                    end
                    args.onboarding = {
                        type = "description",
                        order = 0.05,
                        fontSize = "small",
                        width = "full",
                        name = function()
                            -- G.4d: side-effect-driven first-run popup. Returns "" so the
                            -- description widget is invisible. Closure-scope flag prevents
                            -- repeat triggers within a session; SV flag prevents triggers
                            -- across sessions.
                            if onboardingTriggered then
                                return ""
                            end
                            onboardingTriggered = true
                            -- G.4d L376: account-wide gate, not profile-scoped.
                            local onboardingShown = S and S.db and S.db.global and S.db.global.cvarHealthOnboardingShown
                            if onboardingShown then
                                return ""
                            end
                            if C_Timer and C_Timer.After then
                                C_Timer.After(0.1, function()
                                    local stillUnshown = not (
                                        S
                                        and S.db
                                        and S.db.global
                                        and S.db.global.cvarHealthOnboardingShown
                                    )
                                    if stillUnshown then
                                        local cvarTotal = 0
                                        for _, section in ipairs(D().CVAR_SECTIONS) do
                                            cvarTotal = cvarTotal + #section.cvars
                                        end
                                        -- G8-AUDIT-14: announce body before showing the modal.
                                        if GRIPEMS.Speech and GRIPEMS.Speech.Announce then
                                            GRIPEMS.Speech:Announce(
                                                string.format(L["GEMS_CVAR_ONBOARDING_BODY"], cvarTotal)
                                            )
                                        end
                                        GRIPEMS.Popup:Show("GRIPEMS_CVAR_HEALTH_ONBOARDING", cvarTotal)
                                    end
                                end)
                            end
                            return ""
                        end,
                    }
                    args.profileHeader = {
                        type = "description",
                        order = 0.5,
                        fontSize = "medium",
                        width = "full",
                        name = function()
                            local activeKey = S:Get("cvarActiveProfile")
                            local profileLabel
                            if activeKey then
                                local p = CPM and CPM:GetProfile(activeKey)
                                profileLabel = (p and p.label and p.label ~= "" and p.label) or activeKey
                            else
                                profileLabel = L["GEMS_CVAR_PROFILE_GENERAL"]
                            end
                            local line = string.format(L["GEMS_CVAR_PROFILE_ACTIVE"], profileLabel)
                            local trigger = (CPM and CPM.GetActiveProfileCause and CPM:GetActiveProfileCause()) or ""
                            if trigger ~= "" then
                                line = line .. "  --  " .. string.format(L["GEMS_CVAR_PROFILE_TRIGGERED_BY"], trigger)
                            end
                            return line
                        end,
                    }
                    args.desc = {
                        type = "description",
                        name = L["GEMS_SETTINGS_CVAR_DESC"],
                        order = 1,
                        fontSize = "medium",
                    }
                    args.autoFix = {
                        type = "toggle",
                        name = L["GEMS_SETTINGS_CVAR_AUTOFIX"],
                        desc = L["GEMS_SETTINGS_CVAR_AUTOFIX_DESC"],
                        order = 2,
                        get = function()
                            return S:Get("autoFixCVars")
                        end,
                        set = function(_, v)
                            S:Set("autoFixCVars", v)
                        end,
                        width = "full",
                    }
                    args.fixAllCritical = {
                        type = "execute",
                        name = L["GEMS_CVAR_FIX_ALL_CRITICAL"],
                        order = 3,
                        func = function()
                            -- G5: collect targets synchronously, write opt-in entries synchronously,
                            -- then throttle SetCVar via C_Timer.NewTicker (5 CVars per 0.05s tick).
                            -- Filters at collect time: critical, eff present, pin, SQW guard, mismatch.
                            local entries = S:Get("cvarAutoFixEntries") or {}
                            local targets = {}
                            for _, section in ipairs(D().CVAR_SECTIONS) do
                                for _, rec in ipairs(section.cvars) do
                                    if rec.critical then
                                        local eff = GetEffective(rec.cvar)
                                        if eff then
                                            -- G17: skip pinned CVars
                                            if not (CPM and CPM.IsPinned and CPM:IsPinned(rec.cvar)) then
                                                if
                                                    not (
                                                        rec.cvar == "SpellQueueWindow"
                                                        and GRIPEMS.SQWOptimizer
                                                        and GRIPEMS.SQWOptimizer:IsActive()
                                                    )
                                                then
                                                    -- G.5-POLISH-CVARMATCH-NIL-GUARD-SWEEP: inline `or ""` wrap to
                                                    -- match the same-file sibling pattern at L1631, L1865, L2340.
                                                    -- rec.cvar is from D.CVAR_SECTIONS so GetCVar should never
                                                    -- return nil here; the wrap is house-style consistency only.
                                                    if not D().CvarMatch(GetCVar(rec.cvar) or "", eff) then
                                                        table.insert(targets, { cvar = rec.cvar, eff = eff })
                                                    end
                                                end
                                                entries[rec.cvar] = true
                                            end
                                        end
                                    end
                                end
                            end
                            S:Set("cvarAutoFixEntries", entries)
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")

                            local total = #targets
                            if total == 0 then
                                return
                            end

                            -- G5: throttle the SetCVar burst.
                            fixAllInProgress = true
                            GRIPEMS:Print(string.format(L["GEMS_CVAR_FIX_ALL_BUSY"], total))
                            -- G8-AUDIT-36: announce Fix-All Critical busy state.
                            if GRIPEMS.Speech and GRIPEMS.Speech.Announce then
                                GRIPEMS.Speech:Announce(string.format(L["ACCESS_ANNOUNCE_CVAR_FIXALL_BUSY"], total))
                            end
                            local idx = 1
                            local ticker
                            local fixCriticalDetails = {}
                            if C_Timer and C_Timer.NewTicker then
                                ticker = C_Timer.NewTicker(0.05, function()
                                    local stop = math.min(idx + 4, total)
                                    for i = idx, stop do
                                        local t = targets[i]
                                        -- G5-POLISH-PIN-RECHECK-AT-TICK: respect mid-throttle pin gestures.
                                        -- Pin is ironclad; a pin click placed between Fix All Critical click
                                        -- and this tick must win over the click-time targets snapshot. The
                                        -- targets list was filtered for pre-pinned CVars at click time;
                                        -- this re-check catches pins added DURING the throttle window.
                                        local pinned = CPM and CPM.IsPinned and CPM:IsPinned(t.cvar)
                                        if not pinned then
                                            local prev = GetCVar(t.cvar)
                                            -- G5-POLISH-COMBAT-MID-THROTTLE: SetCVar silently no-ops on secure CVars in
                                            -- combat lockdown. Gate CapturePrevious + details on success so
                                            -- cvarPreviousValues and ReloadGate Notify only reflect CVars that actually
                                            -- changed.
                                            -- G.4-CAUSE-ATTRIBUTION-PANEL-FIX-PATHS: stamp BEFORE SetCVar so the
                                            -- ticker classifies this Fix All Critical as AUTOFIX, not ADDON.
                                            if CPM and CPM.MarkAutoFixed then
                                                CPM:MarkAutoFixed(t.cvar)
                                            end
                                            local success = SetCVar(t.cvar, t.eff)
                                            if success then
                                                if CPM and CPM.CapturePrevious then
                                                    CPM:CapturePrevious(t.cvar, prev)
                                                end
                                                table.insert(
                                                    fixCriticalDetails,
                                                    { cvar = t.cvar, from = prev, to = t.eff }
                                                )
                                            end
                                        end
                                    end
                                    idx = stop + 1
                                    if idx > total then
                                        if ticker and ticker.Cancel then
                                            ticker:Cancel()
                                        end
                                        fixAllInProgress = false
                                        -- G5-FOLLOWUP-COUNT-INTENT-VS-OUTCOME-DRIFT: broadcast actual changes
                                        -- (#fixCriticalDetails) not click-time intent (total).
                                        if #fixCriticalDetails < total then
                                            GRIPEMS:Print(
                                                string.format(
                                                    L["GEMS_CVAR_FIX_ALL_DONE_PARTIAL"],
                                                    #fixCriticalDetails,
                                                    total,
                                                    total - #fixCriticalDetails
                                                )
                                            )
                                        else
                                            GRIPEMS:Print(
                                                string.format(L["GEMS_CVAR_FIX_ALL_DONE"], #fixCriticalDetails)
                                            )
                                        end
                                        -- G8-AUDIT-36: announce Fix-All Critical completion.
                                        if GRIPEMS.Speech and GRIPEMS.Speech.Announce then
                                            GRIPEMS.Speech:Announce(
                                                string.format(
                                                    L["ACCESS_ANNOUNCE_CVAR_FIXALL_DONE"],
                                                    #fixCriticalDetails
                                                )
                                            )
                                        end
                                        LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                                        if GRIPEMS.ReloadGate and GRIPEMS.ReloadGate.Notify then
                                            GRIPEMS.ReloadGate:Notify(
                                                "FIX_ALL_CRITICAL",
                                                #fixCriticalDetails,
                                                fixCriticalDetails
                                            )
                                        end
                                    end
                                end)
                            -- G5-POLISH-CTIMER-DEFENSIVE-GUARD: sync fallback when C_Timer is
                            -- missing. Mirrors scoreTicker pattern below. Should never trigger
                            -- on Retail 12.0+.
                            else
                                for i = 1, total do
                                    local t = targets[i]
                                    local prev = GetCVar(t.cvar)
                                    -- G5-POLISH-COMBAT-MID-THROTTLE: SetCVar silently no-ops on secure CVars in
                                    -- combat lockdown. Gate CapturePrevious + details on success so
                                    -- cvarPreviousValues and ReloadGate Notify only reflect CVars that actually
                                    -- changed.
                                    -- G.4-CAUSE-ATTRIBUTION-PANEL-FIX-PATHS: stamp BEFORE SetCVar so the
                                    -- ticker classifies this Fix All Critical as AUTOFIX, not ADDON.
                                    if CPM and CPM.MarkAutoFixed then
                                        CPM:MarkAutoFixed(t.cvar)
                                    end
                                    local success = SetCVar(t.cvar, t.eff)
                                    if success then
                                        if CPM and CPM.CapturePrevious then
                                            CPM:CapturePrevious(t.cvar, prev)
                                        end
                                        table.insert(fixCriticalDetails, { cvar = t.cvar, from = prev, to = t.eff })
                                    end
                                end
                                fixAllInProgress = false
                                -- G5-FOLLOWUP-COUNT-INTENT-VS-OUTCOME-DRIFT: broadcast actual changes
                                -- (#fixCriticalDetails) not click-time intent (total).
                                if #fixCriticalDetails < total then
                                    GRIPEMS:Print(
                                        string.format(
                                            L["GEMS_CVAR_FIX_ALL_DONE_PARTIAL"],
                                            #fixCriticalDetails,
                                            total,
                                            total - #fixCriticalDetails
                                        )
                                    )
                                else
                                    GRIPEMS:Print(string.format(L["GEMS_CVAR_FIX_ALL_DONE"], #fixCriticalDetails))
                                end
                                if GRIPEMS.Speech and GRIPEMS.Speech.Announce then
                                    GRIPEMS.Speech:Announce(
                                        string.format(L["ACCESS_ANNOUNCE_CVAR_FIXALL_DONE"], #fixCriticalDetails)
                                    )
                                end
                                LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                                if GRIPEMS.ReloadGate and GRIPEMS.ReloadGate.Notify then
                                    GRIPEMS.ReloadGate:Notify(
                                        "FIX_ALL_CRITICAL",
                                        #fixCriticalDetails,
                                        fixCriticalDetails
                                    )
                                end
                            end
                        end,
                        disabled = function()
                            -- G5: also disable while a throttled batch is running so re-clicks
                            -- do not start a second concurrent ticker.
                            -- G.5-POLISH-CROSS-LOCK-FIXALL-RESET: also block while Reset is
                            -- mid-throttle so a Fix-All click during Reset cannot start a
                            -- concurrent ticker. Both flags are declared in the same closure
                            -- scope (fixAllInProgress at L1500, resetInProgress at L1504).
                            if fixAllInProgress or resetInProgress then
                                return true
                            end
                            return InCombatLockdown()
                        end,
                        width = "double",
                    }
                    args.resetDefaults = {
                        type = "execute",
                        name = L["GEMS_CVAR_RESET_DEFAULTS"],
                        desc = L["GEMS_CVAR_RESET_DEFAULTS_DESC"],
                        order = 3.5,
                        func = function()
                            -- G12: collect targets via CPM, cache in closure-scope, then
                            -- show the confirmation popup. The throttled SetCVar burst lives
                            -- in the StaticPopup OnAccept body so the user has a chance to
                            -- cancel before any state mutates. CapturePrevious runs before
                            -- each SetCVar inside the ticker so per-row Undo can revert any
                            -- individual reset.
                            if not CPM or not CPM.GetResetToDefaultsTargets then
                                return
                            end
                            pendingResetTargets = CPM:GetResetToDefaultsTargets()
                            local total = #pendingResetTargets
                            if total == 0 then
                                -- Nothing to reset (already at Blizzard defaults / all pinned / SQW-managed).
                                return
                            end
                            -- G8-AUDIT-19a: announce confirm body before showing the modal.
                            if GRIPEMS.Speech and GRIPEMS.Speech.Announce then
                                GRIPEMS.Speech:Announce(string.format(L["GEMS_CVAR_RESET_DEFAULTS_CONFIRM"], total))
                            end
                            GRIPEMS.Popup:Show("GRIPEMS_CVAR_RESET_DEFAULTS_CONFIRM", total)
                        end,
                        disabled = function()
                            -- G.5-POLISH-CROSS-LOCK-FIXALL-RESET: mirror of the fixAllCritical
                            -- cross-lock above. Block Reset while Fix-All-Critical is mid-
                            -- throttle so concurrent tickers cannot run; CapturePrevious would
                            -- otherwise record stale intermediate values for overlapping cvars.
                            if resetInProgress or fixAllInProgress then
                                return true
                            end
                            return InCombatLockdown()
                        end,
                        width = "double",
                    }
                    args.healthScore = {
                        type = "description",
                        order = 4,
                        fontSize = "medium",
                        name = function()
                            local totalWeight, matchWeight = 0, 0
                            local SQWO = GRIPEMS.SQWOptimizer
                            local sqwManaged = SQWO and SQWO:IsActive()
                            for _, section in ipairs(D().CVAR_SECTIONS) do
                                for _, rec in ipairs(section.cvars) do
                                    local eff = GetEffective(rec.cvar)
                                    if eff ~= nil then
                                        local w = rec.critical and 3 or 1
                                        totalWeight = totalWeight + w
                                        if rec.cvar == "SpellQueueWindow" and sqwManaged then
                                            matchWeight = matchWeight + w
                                        elseif CPM and CPM.IsPinned and CPM:IsPinned(rec.cvar) then
                                            -- G17: pinned CVars credit at full weight
                                            matchWeight = matchWeight + w
                                        elseif D().CvarMatch(GetCVar(rec.cvar) or "", eff) then
                                            matchWeight = matchWeight + w
                                        end
                                    end
                                end
                            end
                            local score = totalWeight > 0 and math.floor(matchWeight / totalWeight * 100 + 0.5) or 100
                            local color =
                                UI:ColorCode(score >= 80 and "scoreGood" or (score >= 50 and "scoreWarn" or "scoreBad"))
                            return color .. string.format(L["GEMS_CVAR_HEALTH_SCORE"], score) .. "|r"
                        end,
                    }
                    args.healthScoreExplain = {
                        type = "description",
                        order = 4.5,
                        fontSize = "small",
                        width = "full",
                        name = function()
                            local SQWO = GRIPEMS.SQWOptimizer
                            local sqwManaged = SQWO and SQWO:IsActive()
                            local offenders = {}
                            for _, section in ipairs(D().CVAR_SECTIONS) do
                                for _, rec in ipairs(section.cvars) do
                                    -- G.9: delegate to the shared classifier. SQW-managed
                                    -- and match rows are filtered by status. r.recommended
                                    -- == nil cvars are excluded from offenders (status is
                                    -- "unrecommended"); pinned cvars are still filtered
                                    -- here because pin-state is orthogonal to status.
                                    local status = SP:_ClassifyCvarRow(rec)
                                    if status == "mismatchCritical" or status == "mismatchPolish" then
                                        if not (CPM and CPM.IsPinned and CPM:IsPinned(rec.cvar)) then
                                            local eff = GetEffective(rec.cvar)
                                            local w = rec.critical and 3 or 1
                                            table.insert(offenders, {
                                                label = rec.label,
                                                current = GetCVar(rec.cvar) or "?",
                                                recommended = eff,
                                                weight = w,
                                            })
                                        end
                                    end
                                end
                            end
                            if #offenders == 0 and not sqwManaged then
                                return L["GEMS_CVAR_HEALTH_EXPLAIN_PERFECT"]
                            end
                            table.sort(offenders, function(a, b)
                                if a.weight ~= b.weight then
                                    return a.weight > b.weight
                                end
                                return tostring(a.label) < tostring(b.label)
                            end)
                            local lines = { L["GEMS_CVAR_HEALTH_EXPLAIN_HEADER"] }
                            if sqwManaged then
                                table.insert(lines, L["GEMS_CVAR_HEALTH_EXPLAIN_SQW_CREDIT"])
                            end
                            local top = math.min(5, #offenders)
                            for i = 1, top do
                                local o = offenders[i]
                                table.insert(
                                    lines,
                                    string.format(
                                        L["GEMS_CVAR_HEALTH_EXPLAIN_OFFENDER"],
                                        tostring(o.label),
                                        tostring(o.current),
                                        tostring(o.recommended),
                                        o.weight
                                    )
                                )
                            end
                            if #offenders > top then
                                table.insert(lines, string.format(L["GEMS_CVAR_HEALTH_EXPLAIN_MORE"], #offenders - top))
                            end
                            return table.concat(lines, "\n")
                        end,
                    }
                    args.profileSelect = {
                        type = "select",
                        name = L["GEMS_CVAR_PROFILE_SELECT"],
                        order = 5,
                        values = function()
                            local v = {}
                            v["__general"] = L["GEMS_CVAR_PROFILE_GENERAL"]
                            v["__auto"] = L["GEMS_CVAR_PROFILE_AUTO"]
                            for _, p in ipairs(D().CVAR_PROFILES) do
                                v[p.key] = p.label
                            end
                            local custom = S:Get("cvarProfiles") or {}
                            for key, prof in pairs(custom) do
                                v[key] = prof.label or key
                            end
                            return v
                        end,
                        sorting = function()
                            local order = { "__auto", "__general" }
                            for _, p in ipairs(D().CVAR_PROFILES) do
                                table.insert(order, p.key)
                            end
                            local custom = S:Get("cvarProfiles") or {}
                            for key in pairs(custom) do
                                table.insert(order, key)
                            end
                            return order
                        end,
                        get = function()
                            if CPM and not S:Get("cvarManualOverride") and S:Get("cvarAutoSwitchEnabled") then
                                return "__auto"
                            end
                            return S:Get("cvarActiveProfile") or "__general"
                        end,
                        set = function(_, val)
                            if not CPM then
                                return
                            end
                            if val == "__auto" then
                                CPM:ClearManualOverride()
                                S:Set("cvarAutoSwitchEnabled", true)
                            elseif val == "__general" then
                                CPM:SetManualProfile(nil)
                            else
                                CPM:SetManualProfile(val)
                            end
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                        end,
                        disabled = function()
                            return InCombatLockdown()
                        end,
                        width = "normal",
                    }
                    args.autoSwitch = {
                        type = "toggle",
                        name = L["GEMS_CVAR_PROFILE_AUTOSWITCH"],
                        desc = L["GEMS_CVAR_PROFILE_AUTOSWITCH_DESC"],
                        order = 6,
                        get = function()
                            return S:Get("cvarAutoSwitchEnabled")
                        end,
                        set = function(_, v)
                            S:Set("cvarAutoSwitchEnabled", v)
                            if v and CPM then
                                CPM:ClearManualOverride()
                            end
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                        end,
                        disabled = function()
                            return InCombatLockdown()
                        end,
                        width = "full",
                    }
                    args.sessionNotice = {
                        type = "toggle",
                        name = L["GEMS_CVAR_SESSION_NOTICE"],
                        desc = L["GEMS_CVAR_SESSION_NOTICE_DESC"],
                        order = 6.5,
                        get = function()
                            return S:Get("cvarSessionChangeNotice")
                        end,
                        set = function(_, v)
                            S:Set("cvarSessionChangeNotice", v)
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                        end,
                        width = "full",
                    }
                    args.whatChanged = {
                        type = "execute",
                        name = function()
                            local changes = CPM and CPM.pendingChanges
                            if changes and #changes > 0 then
                                return UI:ColorCode("cvarChangesDetected")
                                    .. string.format(L["GEMS_CVAR_CHANGES_DETECTED"], #changes)
                                    .. "|r"
                            end
                            return ""
                        end,
                        order = 7,
                        func = function()
                            if not CPM or not CPM.pendingChanges then
                                return
                            end
                            local total = #CPM.pendingChanges
                            local byCause = {}
                            for _, c in ipairs(CPM.pendingChanges) do
                                local key = c.cause or "UNKNOWN"
                                byCause[key] = (byCause[key] or 0) + 1
                            end
                            local bulkThreshold = (D() and D().CVAR_BULK_SUMMARY_THRESHOLD) or 10
                            local bulkCause = false
                            for _, n in pairs(byCause) do
                                if n > bulkThreshold then
                                    bulkCause = true
                                    break
                                end
                            end
                            if bulkCause and total > bulkThreshold then
                                for cause, n in pairs(byCause) do
                                    local causeKey = "GEMS_CVAR_CHANGES_CAUSE_" .. cause
                                    local causeStr = L[causeKey] or L["GEMS_CVAR_CHANGES_CAUSE_UNKNOWN"]
                                    GRIPEMS:Print(string.format(L["GEMS_CVAR_CHANGES_BULK_SUMMARY"], n, causeStr))
                                end
                            else
                                for _, c in ipairs(CPM.pendingChanges) do
                                    local arrow = c.was .. " -> " .. (c.now or "?")
                                    local causeKey = c.cause and ("GEMS_CVAR_CHANGES_CAUSE_" .. c.cause)
                                    local causeStr = (causeKey and L[causeKey]) or L["GEMS_CVAR_CHANGES_CAUSE_UNKNOWN"]
                                    GRIPEMS:Print(tostring(c.label) .. ": " .. arrow .. " (" .. causeStr .. ")")
                                end
                            end
                            CPM.pendingChanges = nil
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                        end,
                        hidden = function()
                            return not CPM or not CPM.pendingChanges or #CPM.pendingChanges == 0
                        end,
                        width = "full",
                    }
                    args.sqwToggle = {
                        type = "toggle",
                        name = L["GEMS_SQW_OPTIMIZER"],
                        desc = L["GEMS_SQW_OPTIMIZER_DESC"],
                        order = 8,
                        get = function()
                            return S:Get("sqwOptimizerEnabled")
                        end,
                        set = function(_, v)
                            S:Set("sqwOptimizerEnabled", v)
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                        end,
                        width = "full",
                    }
                    args.sqwLink = {
                        type = "description",
                        name = L["GEMS_SQW_OPTIMIZER_LINK"],
                        order = 8.5,
                        fontSize = "small",
                        width = "full",
                    }
                    args.sqwBuffer = {
                        type = "range",
                        name = L["GEMS_SQW_BUFFER"],
                        desc = L["GEMS_SQW_BUFFER_DESC"],
                        order = 9,
                        min = 50,
                        max = 200,
                        step = 10,
                        bigStep = 10,
                        get = function()
                            return S:Get("sqwBuffer") or 100
                        end,
                        set = function(_, v)
                            S:Set("sqwBuffer", v)
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                        end,
                        hidden = function()
                            return not S:Get("sqwOptimizerEnabled")
                        end,
                        width = "double",
                        disabled = function()
                            return InCombatLockdown()
                        end,
                    }
                    args.sqwLive = {
                        type = "description",
                        order = 10,
                        fontSize = "medium",
                        name = function()
                            local SQWO = GRIPEMS.SQWOptimizer
                            if not SQWO or not SQWO:IsActive() then
                                return ""
                            end
                            local st = SQWO:GetState()
                            if not st.sqw then
                                return ""
                            end
                            return UI:ColorCode("cvarSqwManaged")
                                .. string.format(L["GEMS_SQW_LIVE"], st.sqw, math.floor(st.latency or 0), st.buffer)
                                .. "|r"
                        end,
                        hidden = function()
                            return not S:Get("sqwOptimizerEnabled")
                        end,
                        width = "full",
                    }
                    args.sqwAdvisory = {
                        type = "description",
                        order = 11,
                        fontSize = "medium",
                        name = function()
                            local SQWO = GRIPEMS.SQWOptimizer
                            if not SQWO or not SQWO:IsActive() then
                                return ""
                            end
                            local st = SQWO:GetState()
                            if not st.advisoryMs then
                                return ""
                            end
                            local line1 = string.format(L["GEMS_SQW_ADVISORY"], st.advisoryMs)
                            local line2 = string.format(
                                L["GEMS_SQW_ADVISORY_DETAIL"],
                                math.floor(st.gcd or 0),
                                st.sqw or 0,
                                math.floor(st.latency or 0)
                            )
                            local effectiveMS = S:GetEffectiveClickRate() or 250
                            local delta = effectiveMS - st.advisoryMs
                            local word = delta > 0 and L["GEMS_SQW_SLOWER"] or L["GEMS_SQW_FASTER"]
                            local absDelta = math.abs(delta)
                            local deltaColor
                            if absDelta <= 50 then
                                deltaColor = UI:ColorCode("cvarAdvisoryGood")
                            elseif absDelta <= 100 then
                                deltaColor = UI:ColorCode("cvarAdvisoryWarn")
                            else
                                deltaColor = UI:ColorCode("cvarAdvisoryBad")
                            end
                            local line3 = deltaColor
                                .. string.format(L["GEMS_SQW_ADVISORY_DELTA"], effectiveMS, absDelta, word)
                                .. "|r"
                            return line1 .. "\n" .. line2 .. "\n" .. line3
                        end,
                        hidden = function()
                            return not S:Get("sqwOptimizerEnabled")
                        end,
                        width = "full",
                    }
                    for _, section in ipairs(D().CVAR_SECTIONS) do
                        local sectionArgs = {}
                        sectionArgs.autoFixSectionGated = {
                            type = "description",
                            name = function()
                                return L["GEMS_CVAR_AUTOFIX_SECTION_GATED"]
                            end,
                            order = 0.5,
                            fontSize = "small",
                            width = "full",
                            hidden = function()
                                return S:Get("autoFixCVars") == true
                            end,
                        }
                        sectionArgs.fixAll = {
                            type = "execute",
                            name = L["GEMS_CVAR_FIX_ALL_SECTION"],
                            order = 1,
                            func = function()
                                -- G11: Fix All in Section also opts in to next-login auto-fix
                                -- (parallel to Fix All Critical) for consistency.
                                local entries = S:Get("cvarAutoFixEntries") or {}
                                local sectionDetails = {}
                                local sectionApplied = 0
                                for _, rec in ipairs(section.cvars) do
                                    local eff = GetEffective(rec.cvar)
                                    if eff then
                                        -- G17: skip pinned CVars
                                        if not (CPM and CPM.IsPinned and CPM:IsPinned(rec.cvar)) then
                                            if
                                                not (
                                                    rec.cvar == "SpellQueueWindow"
                                                    and GRIPEMS.SQWOptimizer
                                                    and GRIPEMS.SQWOptimizer:IsActive()
                                                )
                                            then
                                                local cur = GetCVar(rec.cvar) or ""
                                                if not D().CvarMatch(cur, eff) then
                                                    -- G5-FOLLOWUP-PER-ROW-SETCVAR-SUCCESS-GATE: SetCVar can silently
                                                    -- no-op (combat lockdown on secure CVars, unknown CVar, out-of-range
                                                    -- value). Gate CapturePrevious + details + counter on SetCVar success
                                                    -- so cvarPreviousValues and the section journal only reflect actual changes.
                                                    -- G.4-CAUSE-ATTRIBUTION-PANEL-FIX-PATHS: stamp BEFORE SetCVar so the
                                                    -- ticker classifies this Fix All in Section as AUTOFIX, not ADDON.
                                                    if CPM and CPM.MarkAutoFixed then
                                                        CPM:MarkAutoFixed(rec.cvar)
                                                    end
                                                    local success = SetCVar(rec.cvar, eff)
                                                    if success then
                                                        if CPM and CPM.CapturePrevious then
                                                            CPM:CapturePrevious(rec.cvar, cur)
                                                        end
                                                        table.insert(
                                                            sectionDetails,
                                                            { cvar = rec.cvar, from = cur, to = eff }
                                                        )
                                                        sectionApplied = sectionApplied + 1
                                                    end
                                                end
                                            end
                                            -- G11: opt in for next-login auto-fix
                                            entries[rec.cvar] = true
                                        end
                                    end
                                end
                                S:Set("cvarAutoFixEntries", entries)
                                LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                                if sectionApplied > 0 and GRIPEMS.ReloadGate and GRIPEMS.ReloadGate.Notify then
                                    GRIPEMS.ReloadGate:Notify("FIX_ALL_SECTION", sectionApplied, sectionDetails)
                                end
                            end,
                            disabled = function()
                                return InCombatLockdown()
                            end,
                            width = "full",
                        }
                        for idx, rec in ipairs(section.cvars) do
                            local r = rec
                            local baseOrder = 10 + (idx - 1) * 3
                            sectionArgs["cvar_status_" .. r.cvar] = {
                                type = "description",
                                order = baseOrder,
                                fontSize = "medium",
                                name = function()
                                    -- G.9: delegate row classification to the shared
                                    -- helper so the offender accumulator and the
                                    -- issue-anchor collector see identical status codes.
                                    local status = SP:_ClassifyCvarRow(r)
                                    if status == "sqwManaged" then
                                        local SQWO = GRIPEMS.SQWOptimizer
                                        local st = SQWO:GetState()
                                        local val = st.sqw or tonumber(GetCVar("SpellQueueWindow")) or 400
                                        return UI:ColorCode("cvarSqwManaged")
                                            .. r.label
                                            .. ": "
                                            .. val
                                            .. "ms  "
                                            .. L["GEMS_SQW_MANAGED"]
                                            .. "|r"
                                    end
                                    local current = GetCVar(r.cvar) or "?"
                                    local cleanCurrent = CleanNumber(current)
                                    local color
                                    if status == "unrecommended" then
                                        color = UI:ColorCode("cvarUnrecommended")
                                    elseif status == "match" then
                                        color = UI:ColorCode("cvarMatch")
                                    elseif status == "mismatchCritical" then
                                        color = UI:ColorCode("cvarMismatchCritical")
                                    else
                                        color = UI:ColorCode("cvarMismatchPolish")
                                    end
                                    if status == "unrecommended" then
                                        return color
                                            .. r.label
                                            .. "|r: "
                                            .. cleanCurrent
                                            .. "  "
                                            .. L["GEMS_CVAR_YOUR_CHOICE"]
                                    elseif status == "match" then
                                        return color .. r.label .. "|r: " .. cleanCurrent
                                    else
                                        local eff = GetEffective(r.cvar)
                                        return color
                                            .. r.label
                                            .. "|r: "
                                            .. cleanCurrent
                                            .. "  -->  "
                                            .. CleanNumber(eff)
                                    end
                                end,
                                width = "double",
                            }
                            sectionArgs["cvar_fix_" .. r.cvar] = {
                                type = "execute",
                                name = L["GEMS_SETTINGS_CVAR_FIX"],
                                order = baseOrder + 1,
                                desc = function()
                                    local current = GetCVar(r.cvar) or "?"
                                    local eff = GetEffective(r.cvar)
                                    local lines = r.desc
                                    if r.cvar == "SpellQueueWindow" then
                                        local SQWO = GRIPEMS.SQWOptimizer
                                        if SQWO and SQWO:IsActive() then
                                            -- G9: append longform doc if present, even in SQW-managed branch
                                            local body = r.desc .. "\n\n" .. L["GEMS_SQW_MANAGED"]
                                            if r.descLong then
                                                body = body .. "\n\n" .. r.descLong
                                            end
                                            return body
                                        end
                                    end
                                    if CPM.IsCVarSecure(r.cvar) and InCombatLockdown() then
                                        lines = lines .. "\n\n" .. L["GEMS_CVAR_COMBAT_DISABLED"]
                                    elseif eff and not D().CvarMatch(current, eff) then
                                        lines = lines
                                            .. "\n\n"
                                            .. string.format(
                                                L["GEMS_CVAR_WILL_CHANGE"],
                                                CleanNumber(current),
                                                CleanNumber(eff)
                                            )
                                    end
                                    -- G9: longform doc appended at end if present
                                    if r.descLong then
                                        lines = lines .. "\n\n" .. r.descLong
                                    end
                                    return lines
                                end,
                                func = function()
                                    -- G17: pinned CVars are not modified by Fix
                                    if CPM and CPM.IsPinned and CPM:IsPinned(r.cvar) then
                                        return
                                    end
                                    local eff = GetEffective(r.cvar)
                                    if eff then
                                        local prev = GetCVar(r.cvar)
                                        -- G5-FOLLOWUP-PER-ROW-SETCVAR-SUCCESS-GATE: SetCVar can silently
                                        -- no-op (combat lockdown on secure CVars, unknown CVar, out-of-range
                                        -- value). Gate CapturePrevious + announce + Notify + NotifyChange on
                                        -- SetCVar success so cvarPreviousValues and downstream surfaces only
                                        -- reflect actual changes.
                                        -- G.4-CAUSE-ATTRIBUTION-PANEL-FIX-PATHS: stamp BEFORE SetCVar so the
                                        -- ticker classifies this per-row Fix as AUTOFIX, not ADDON.
                                        if CPM and CPM.MarkAutoFixed then
                                            CPM:MarkAutoFixed(r.cvar)
                                        end
                                        local success = SetCVar(r.cvar, eff)
                                        if success then
                                            if CPM and CPM.CapturePrevious then
                                                CPM:CapturePrevious(r.cvar, prev)
                                            end
                                            -- G8-AUDIT-36: announce per-row Fix.
                                            cvarRowAnnounce("FIX", r.cvar, prev, eff)
                                            if GRIPEMS.ReloadGate and GRIPEMS.ReloadGate.Notify then
                                                GRIPEMS.ReloadGate:Notify(
                                                    "PER_ROW_FIX",
                                                    1,
                                                    { { cvar = r.cvar, from = prev, to = eff } }
                                                )
                                            end
                                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                                        end
                                    end
                                end,
                                disabled = function()
                                    -- G17: pinned CVars cannot be Fixed (use Pin toggle to release)
                                    if CPM and CPM.IsPinned and CPM:IsPinned(r.cvar) then
                                        return true
                                    end
                                    if r.cvar == "SpellQueueWindow" then
                                        local SQWO = GRIPEMS.SQWOptimizer
                                        if SQWO and SQWO:IsActive() then
                                            return true
                                        end
                                    end
                                    if r.recommended == nil then
                                        return true
                                    end
                                    local eff = GetEffective(r.cvar)
                                    if eff and D().CvarMatch(GetCVar(r.cvar) or "", eff) then
                                        return true
                                    end
                                    if CPM.IsCVarSecure(r.cvar) and InCombatLockdown() then
                                        return true
                                    end
                                    return false
                                end,
                                width = "half",
                                hidden = function()
                                    -- G8: hide Fix button when r.options is populated; the dropdown takes over
                                    return r.recommended == nil or r.options ~= nil
                                end,
                            }
                            sectionArgs["cvar_fix_select_" .. r.cvar] = {
                                type = "select",
                                name = L["GEMS_SETTINGS_CVAR_FIX"],
                                order = baseOrder + 1.1,
                                desc = function()
                                    local lines = r.desc or ""
                                    if r.descLong then
                                        if lines ~= "" then
                                            lines = lines .. "\n\n" .. r.descLong
                                        else
                                            lines = r.descLong
                                        end
                                    end
                                    return lines
                                end,
                                values = function()
                                    local v = {}
                                    if r.options then
                                        for _, opt in ipairs(r.options) do
                                            local label = opt.label or tostring(opt.value)
                                            if
                                                r.recommended ~= nil
                                                and tostring(opt.value) == tostring(r.recommended)
                                            then
                                                label = string.format(L["GEMS_CVAR_OPTION_RECOMMENDED"], label)
                                            end
                                            v[opt.value] = label
                                        end
                                    end
                                    return v
                                end,
                                sorting = function()
                                    local order = {}
                                    if r.options then
                                        for _, opt in ipairs(r.options) do
                                            table.insert(order, opt.value)
                                        end
                                    end
                                    return order
                                end,
                                get = function()
                                    return GetCVar(r.cvar)
                                end,
                                set = function(_, val)
                                    -- G17: pinned CVars are not modified by dropdown
                                    if CPM and CPM.IsPinned and CPM:IsPinned(r.cvar) then
                                        return
                                    end
                                    if val and val ~= "" then
                                        local prev = GetCVar(r.cvar)
                                        -- G5-FOLLOWUP-PER-ROW-SETCVAR-SUCCESS-GATE: SetCVar can silently
                                        -- no-op (combat lockdown on secure CVars, unknown CVar, out-of-range
                                        -- value). Gate CapturePrevious + announce + Notify + NotifyChange on
                                        -- SetCVar success so cvarPreviousValues and downstream surfaces
                                        -- only reflect actual changes.
                                        -- G.4-CAUSE-ATTRIBUTION-PANEL-FIX-PATHS: stamp BEFORE SetCVar so the
                                        -- ticker classifies this per-row Set Value as AUTOFIX, not ADDON.
                                        if CPM and CPM.MarkAutoFixed then
                                            CPM:MarkAutoFixed(r.cvar)
                                        end
                                        local success = SetCVar(r.cvar, val)
                                        if success then
                                            if CPM and CPM.CapturePrevious then
                                                CPM:CapturePrevious(r.cvar, prev)
                                            end
                                            -- G8-AUDIT-36: announce per-row Set Value.
                                            cvarRowAnnounce("SET", r.cvar, prev, val)
                                            if GRIPEMS.ReloadGate and GRIPEMS.ReloadGate.Notify then
                                                GRIPEMS.ReloadGate:Notify(
                                                    "PER_ROW_SET",
                                                    1,
                                                    { { cvar = r.cvar, from = prev, to = val } }
                                                )
                                            end
                                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                                        end
                                    end
                                end,
                                disabled = function()
                                    if CPM and CPM.IsPinned and CPM:IsPinned(r.cvar) then
                                        return true
                                    end
                                    if r.cvar == "SpellQueueWindow" then
                                        local SQWO = GRIPEMS.SQWOptimizer
                                        if SQWO and SQWO:IsActive() then
                                            return true
                                        end
                                    end
                                    if CPM.IsCVarSecure(r.cvar) and InCombatLockdown() then
                                        return true
                                    end
                                    return false
                                end,
                                width = "half",
                                hidden = function()
                                    return r.options == nil
                                end,
                            }
                            sectionArgs["cvar_undo_" .. r.cvar] = {
                                type = "execute",
                                name = function()
                                    local prev = CPM and CPM.GetPrevious and CPM:GetPrevious(r.cvar)
                                    if prev ~= nil then
                                        return string.format(L["GEMS_CVAR_UNDO_TO"], CleanNumber(prev))
                                    end
                                    return L["GEMS_CVAR_UNDO"]
                                end,
                                desc = L["GEMS_CVAR_UNDO_DESC"],
                                order = baseOrder + 1.5,
                                func = function()
                                    if CPM and CPM.UndoPrevious then
                                        CPM:UndoPrevious(r.cvar)
                                        -- G8-AUDIT-36: announce per-row Undo. CPM:UndoPrevious
                                        -- returns boolean success, so use GetCVar fallback for
                                        -- the announced value.
                                        cvarRowAnnounce("UNDO", r.cvar, nil, GetCVar(r.cvar))
                                        LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                                    end
                                end,
                                disabled = function()
                                    -- G.3b option-b: pin is ironclad; Undo button greys when pinned
                                    if CPM and CPM.IsPinned and CPM:IsPinned(r.cvar) then
                                        return true
                                    end
                                    if CPM.IsCVarSecure(r.cvar) and InCombatLockdown() then
                                        return true
                                    end
                                    return false
                                end,
                                hidden = function()
                                    if r.recommended == nil then
                                        return true
                                    end
                                    if not (CPM and CPM.HasPrevious and CPM:HasPrevious(r.cvar)) then
                                        return true
                                    end
                                    return false
                                end,
                                width = "half",
                            }
                            sectionArgs["cvar_redo_" .. r.cvar] = {
                                type = "execute",
                                name = function()
                                    local redo = CPM and CPM.GetRedo and CPM:GetRedo(r.cvar)
                                    if redo ~= nil then
                                        return string.format(L["GEMS_CVAR_REDO_TO"], CleanNumber(redo))
                                    end
                                    return L["GEMS_CVAR_REDO"]
                                end,
                                desc = L["GEMS_CVAR_REDO_DESC"],
                                order = baseOrder + 1.75,
                                func = function()
                                    if CPM and CPM.RedoPrevious then
                                        CPM:RedoPrevious(r.cvar)
                                        cvarRowAnnounce("REDO", r.cvar, nil, GetCVar(r.cvar))
                                        LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                                    end
                                end,
                                disabled = function()
                                    if CPM and CPM.IsPinned and CPM:IsPinned(r.cvar) then
                                        return true
                                    end
                                    if CPM.IsCVarSecure(r.cvar) and InCombatLockdown() then
                                        return true
                                    end
                                    return false
                                end,
                                hidden = function()
                                    if r.recommended == nil then
                                        return true
                                    end
                                    if not (CPM and CPM.HasRedo and CPM:HasRedo(r.cvar)) then
                                        return true
                                    end
                                    return false
                                end,
                                width = "half",
                            }
                            sectionArgs["cvar_auto_" .. r.cvar] = {
                                type = "toggle",
                                name = L["GEMS_CVAR_AUTOFIX_ENTRY"],
                                desc = function()
                                    if not S:Get("autoFixCVars") then
                                        return L["GEMS_CVAR_AUTOFIX_ENTRY_GATED"]
                                    end
                                    if CPM and CPM.IsPinned and CPM:IsPinned(r.cvar) then
                                        return L["GEMS_CVAR_AUTOFIX_PIN_OVERRIDE"]
                                    end
                                    return nil
                                end,
                                order = baseOrder + 2,
                                get = function()
                                    return (S:Get("cvarAutoFixEntries") or {})[r.cvar]
                                end,
                                set = function(_, v)
                                    local entries = S:Get("cvarAutoFixEntries") or {}
                                    entries[r.cvar] = v or nil
                                    S:Set("cvarAutoFixEntries", entries)
                                    -- G8-AUDIT-36: announce per-row Auto-fix toggle.
                                    cvarRowAnnounce(v and "AUTOFIX_ON" or "AUTOFIX_OFF", r.cvar, nil, nil)
                                end,
                                width = "half",
                                hidden = function()
                                    return r.recommended == nil or not S:Get("autoFixCVars")
                                end,
                                disabled = function()
                                    if not S:Get("autoFixCVars") then
                                        return true
                                    end
                                    if CPM and CPM.IsPinned and CPM:IsPinned(r.cvar) then
                                        return true
                                    end
                                    return false
                                end,
                            }
                            sectionArgs["cvar_pin_" .. r.cvar] = {
                                type = "toggle",
                                name = L["GEMS_CVAR_PIN"],
                                desc = function()
                                    if CPM and CPM.IsPinned and CPM:IsPinned(r.cvar) then
                                        return L["GEMS_CVAR_PIN_PINNED"]
                                    end
                                    return L["GEMS_CVAR_PIN_DESC"]
                                end,
                                order = baseOrder + 2.5,
                                get = function()
                                    if CPM and CPM.IsPinned then
                                        return CPM:IsPinned(r.cvar)
                                    end
                                    return false
                                end,
                                set = function(_, v)
                                    if CPM and CPM.SetPinned then
                                        CPM:SetPinned(r.cvar, v)
                                        -- G8-AUDIT-36: announce per-row Pin toggle.
                                        cvarRowAnnounce(v and "PIN_ON" or "PIN_OFF", r.cvar, nil, nil)
                                        LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                                    end
                                end,
                                width = "half",
                                hidden = function()
                                    return r.recommended == nil
                                end,
                            }
                            if r.recommended == nil then
                                sectionArgs["cvar_info_" .. r.cvar] = {
                                    type = "description",
                                    order = baseOrder + 1,
                                    fontSize = "small",
                                    name = UI:ColorCode("cvarUnrecommended") .. r.desc .. "|r",
                                    width = "full",
                                }
                                sectionArgs["cvar_set_" .. r.cvar] = {
                                    type = "input",
                                    name = L["GEMS_CVAR_SET_VALUE"],
                                    desc = r.desc,
                                    order = baseOrder + 2,
                                    get = function()
                                        return GetCVar(r.cvar) or ""
                                    end,
                                    set = function(_, val)
                                        if val and val ~= "" then
                                            local prev = GetCVar(r.cvar)
                                            -- G5-FOLLOWUP-PER-ROW-SETCVAR-SUCCESS-GATE: SetCVar can silently
                                            -- no-op (combat lockdown on secure CVars, unknown CVar, out-of-range
                                            -- value). Gate CapturePrevious + Notify + NotifyChange on SetCVar
                                            -- success so cvarPreviousValues and the ReloadGate journal only
                                            -- reflect actual changes.
                                            local success = SetCVar(r.cvar, val)
                                            if success then
                                                if CPM and CPM.CapturePrevious then
                                                    CPM:CapturePrevious(r.cvar, prev)
                                                end
                                                if GRIPEMS.ReloadGate and GRIPEMS.ReloadGate.Notify then
                                                    GRIPEMS.ReloadGate:Notify(
                                                        "PER_ROW_SET",
                                                        1,
                                                        { { cvar = r.cvar, from = prev, to = val } }
                                                    )
                                                end
                                                LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                                            end
                                        end
                                    end,
                                    disabled = function()
                                        return CPM.IsCVarSecure(r.cvar) and InCombatLockdown()
                                    end,
                                    width = "half",
                                }
                            end
                            sectionArgs["cvar_spacer_" .. r.cvar] = {
                                type = "description",
                                name = " ",
                                order = baseOrder + 2.9,
                                fontSize = "small",
                                width = "full",
                            }
                        end
                        args["cvarSection_" .. section.key] = {
                            type = "group",
                            name = function()
                                local matched, total = ComputeSectionScore(section)
                                return string.format(L["GEMS_CVAR_SECTION_HEALTH"], section.label, matched, total)
                            end,
                            order = 10 + section.order,
                            inline = false,
                            args = sectionArgs,
                        }
                    end
                    if GRIPEMS.RegisterCallback then
                        GRIPEMS.RegisterCallback("SettingsPanel_CVar", "CVAR_PROFILE_CHANGED", function()
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                        end)
                        GRIPEMS.RegisterCallback("SettingsPanel_SQW", "SQW_UPDATED", function()
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                        end)
                        GRIPEMS.RegisterCallback("SettingsPanel_SQWState", "SQW_OPTIMIZER_STATE", function()
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                        end)
                        -- G.3b: refresh the panel when G7 Undo fires or G17 Pin flips
                        GRIPEMS.RegisterCallback("SettingsPanel_CVarUndo", "CVAR_UNDO_APPLIED", function()
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                        end)
                        GRIPEMS.RegisterCallback("SettingsPanel_CVarRedo", "CVAR_REDO_APPLIED", function()
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                        end)
                        GRIPEMS.RegisterCallback("SettingsPanel_CVarPin", "CVAR_PINNED_CHANGED", function()
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                        end)
                        -- G.4c (G18): refresh header trigger label when context changes inside AUTO mode
                        -- (covers the case where new context resolves to the same profile, so no
                        -- CVAR_PROFILE_CHANGED fires but the trigger string still needs updating).
                        GRIPEMS.RegisterCallback("SettingsPanel_CVarContext", "CONTEXT_CHANGED", function()
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                        end)
                    end
                    return args
                end)(),
            },
            contextDetection = {
                type = "group",
                name = L["GEMS_SETTINGS_CONTEXT_HEADER"],
                order = 36,
                args = {
                    desc = {
                        type = "description",
                        name = L["GEMS_SETTINGS_CONTEXT_DESC"],
                        order = 1,
                        fontSize = "medium",
                    },
                    mythicPlusMid = {
                        type = "range",
                        name = L["GEMS_SETTINGS_MPLUS_MID"],
                        desc = L["GEMS_SETTINGS_MPLUS_MID_DESC"],
                        order = 2,
                        min = 2,
                        max = 20,
                        step = 1,
                        get = function()
                            return S:Get("mythicPlusTierMid")
                        end,
                        set = function(_, v)
                            local high = S:Get("mythicPlusTierHigh")
                            if v >= high then
                                v = high - 1
                            end
                            S:Set("mythicPlusTierMid", v)
                            local Engine = GRIPEMS.Engine
                            if Engine and Engine.UpdateContext then
                                Engine:UpdateContext()
                            end
                        end,
                        width = "double",
                    },
                    mythicPlusHigh = {
                        type = "range",
                        name = L["GEMS_SETTINGS_MPLUS_HIGH"],
                        desc = L["GEMS_SETTINGS_MPLUS_HIGH_DESC"],
                        order = 3,
                        min = 3,
                        max = 30,
                        step = 1,
                        get = function()
                            return S:Get("mythicPlusTierHigh")
                        end,
                        set = function(_, v)
                            local mid = S:Get("mythicPlusTierMid")
                            if v <= mid then
                                v = mid + 1
                            end
                            S:Set("mythicPlusTierHigh", v)
                            local Engine = GRIPEMS.Engine
                            if Engine and Engine.UpdateContext then
                                Engine:UpdateContext()
                            end
                        end,
                        width = "double",
                    },
                    delvesTierHigh = {
                        type = "range",
                        name = L["GEMS_SETTINGS_DELVES_HIGH"],
                        desc = L["GEMS_SETTINGS_DELVES_HIGH_DESC"],
                        order = 4,
                        min = 2,
                        max = 11,
                        step = 1,
                        get = function()
                            return S:Get("delvesTierHigh")
                        end,
                        set = function(_, v)
                            S:Set("delvesTierHigh", v)
                            local Engine = GRIPEMS.Engine
                            if Engine and Engine.UpdateContext then
                                Engine:UpdateContext()
                            end
                        end,
                        width = "double",
                    },
                },
            },
            accessibility = {
                type = "group",
                name = L["ACCESS_PANEL_NAME"],
                order = 31,
                childGroups = "tab",
                args = {
                    general = {
                        type = "group",
                        name = L["ACCESS_GENERAL_TAB"] or "General",
                        order = 1,
                        args = {
                            guide = {
                                type = "group",
                                name = L["ACCESS_GUIDE_SECTION_NAME"],
                                order = -2,
                                inline = true,
                                args = {
                                    desc = {
                                        type = "description",
                                        name = L["ACCESS_GUIDE_SECTION_DESC"],
                                        order = 1,
                                        fontSize = "medium",
                                    },
                                    open = {
                                        type = "execute",
                                        name = L["ACCESS_GUIDE_BUTTON_LABEL"],
                                        desc = L["ACCESS_GUIDE_BUTTON_DESC"],
                                        order = 2,
                                        func = function()
                                            SP_showURL("https://jesperlive.github.io/grip-ems-guide/")
                                        end,
                                    },
                                },
                            },
                            accessibilityMode = {
                                type = "group",
                                name = L["ACCESS_MODE_SECTION_NAME"],
                                inline = true,
                                order = -1,
                                args = {
                                    desc = {
                                        type = "description",
                                        name = L["ACCESS_MODE_SECTION_DESC"],
                                        order = 1,
                                        fontSize = "medium",
                                    },
                                    toggle = {
                                        type = "toggle",
                                        name = L["ACCESS_MODE_TOGGLE_LABEL"],
                                        desc = L["ACCESS_MODE_TOGGLE_DESC"],
                                        order = 2,
                                        get = function()
                                            return GRIPEMS.Settings.db.profile.accessibility.accessibilityPresetOn
                                        end,
                                        set = function(_, val)
                                            local a = GRIPEMS.Settings.db.profile.accessibility
                                            a.accessibilityPresetOn = val and true or false
                                            if val then
                                                a._accessibilityPresetSimplifiedSnapshot = {
                                                    simplified = a.simplifiedMode,
                                                    density = a.density,
                                                    scale = a.uiScale,
                                                }
                                                a._accessibilityPresetOverlaySnapshot = {
                                                    mode = a.cursorOverlayMode,
                                                    size = a.cursorOverlaySize,
                                                }
                                                a._accessibilityPresetVisionSnapshot = {
                                                    speechEnabled = a.speechEnabled,
                                                    reduceMotion = a.reduceMotion,
                                                    soundCuesEnabled = a.soundCuesEnabled,
                                                    cursorOverlayEnabled = a.cursorOverlayEnabled,
                                                    contrastPreset = GRIPEMS.Settings.db.profile.contrastPreset,
                                                }
                                                a.simplifiedMode = true
                                                a.speechEnabled = true
                                                a.reduceMotion = true
                                                a.soundCuesEnabled = true
                                                a.uiScale = 1.5 -- per design doc sec 4.1 step 2 (severe-motor users)
                                                a.cursorOverlayEnabled = true
                                                a.cursorOverlayMode = "ring"
                                                a.cursorOverlaySize = 1.5
                                                a.density = "large"
                                                GRIPEMS.Settings.db.profile.contrastPreset = "HighContrast"
                                                _G.GRIP_EMS_Settings = _G.GRIP_EMS_Settings or {}
                                                _G.GRIP_EMS_Settings.contrastPreset = "HighContrast"
                                                if GRIPEMS.UI and GRIPEMS.UI.SetPalette then
                                                    GRIPEMS.UI:SetPalette("HighContrast")
                                                end
                                                if GRIPEMS.UI and GRIPEMS.UI.ApplyUIScale then
                                                    GRIPEMS.UI:ApplyUIScale()
                                                end
                                                -- Phase 4-polish #7: small-display warning. At uiScale=1.5 (forced by AccessibilityMode),
                                                -- MainFrame's logical MIN_HEIGHT px needs at least that many logical screen px to render fully.
                                                -- Users on small displays at uiScale=1.5 may see effective screen px below MIN_HEIGHT,
                                                -- which leaves no room for chrome/header/drag-resize. Phase F bumped the floor 480 -> MIN_HEIGHT (640).
                                                -- Fire a one-time toast informing the user; not a blocker, just transparency.
                                                local screenH = (UIParent and UIParent:GetHeight()) or 0
                                                if
                                                    screenH > 0
                                                    and screenH < (D and D() and D().MAIN_FRAME_MIN_HEIGHT or 640)
                                                then
                                                    GRIPEMS:Print(
                                                        "|cFFFFAA00"
                                                            .. (L["ACCESS_MODE_SMALL_DISPLAY_WARNING"] or "EMS: Accessibility Mode requires more screen height than your display has at this UI scale. MainFrame may be cramped.")
                                                            .. "|r"
                                                    )
                                                end
                                                if GRIPEMS.UI and GRIPEMS.UI.ApplyLargeTargets then
                                                    GRIPEMS.UI:ApplyLargeTargets()
                                                end
                                                if GRIPEMS.Theme and GRIPEMS.Theme.ApplyTheme then
                                                    GRIPEMS.Theme.ApplyTheme()
                                                end
                                                if
                                                    GRIPEMS.UI
                                                    and GRIPEMS.UI.CursorOverlay
                                                    and GRIPEMS.UI.CursorOverlay.Refresh
                                                then
                                                    GRIPEMS.UI.CursorOverlay:Refresh()
                                                end
                                                GRIPEMS:Print(L["ACCESS_MODE_TOAST_APPLIED"])
                                            else
                                                a.speechEnabled = false
                                                a.reduceMotion = false
                                                a.soundCuesEnabled = false
                                                a.uiScale = 1.0
                                                a.cursorOverlayEnabled = false
                                                a.density = "normal"
                                                GRIPEMS.Settings.db.profile.contrastPreset = "auto"
                                                _G.GRIP_EMS_Settings = _G.GRIP_EMS_Settings or {}
                                                _G.GRIP_EMS_Settings.contrastPreset = "auto"
                                                local name = "auto"
                                                if GRIPEMS.UI and GRIPEMS.UI.ResolveAutoPreset then
                                                    name = GRIPEMS.UI:ResolveAutoPreset()
                                                end
                                                if GRIPEMS.UI and GRIPEMS.UI.SetPalette then
                                                    GRIPEMS.UI:SetPalette(name)
                                                end
                                                if GRIPEMS.UI and GRIPEMS.UI.ApplyUIScale then
                                                    GRIPEMS.UI:ApplyUIScale()
                                                end
                                                if GRIPEMS.UI and GRIPEMS.UI.ApplyLargeTargets then
                                                    GRIPEMS.UI:ApplyLargeTargets()
                                                end
                                                if GRIPEMS.Theme and GRIPEMS.Theme.ApplyTheme then
                                                    GRIPEMS.Theme.ApplyTheme()
                                                end
                                                if
                                                    GRIPEMS.UI
                                                    and GRIPEMS.UI.CursorOverlay
                                                    and GRIPEMS.UI.CursorOverlay.Refresh
                                                then
                                                    GRIPEMS.UI.CursorOverlay:Refresh()
                                                end
                                                local snap = a._accessibilityPresetSimplifiedSnapshot
                                                if snap then
                                                    a.simplifiedMode = snap.simplified
                                                    a.density = snap.density
                                                    a.uiScale = snap.scale
                                                    a._accessibilityPresetSimplifiedSnapshot = nil
                                                end
                                                local osnap = a._accessibilityPresetOverlaySnapshot
                                                if osnap then
                                                    a.cursorOverlayMode = osnap.mode
                                                    a.cursorOverlaySize = osnap.size
                                                    a._accessibilityPresetOverlaySnapshot = nil
                                                    if
                                                        GRIPEMS.UI
                                                        and GRIPEMS.UI.CursorOverlay
                                                        and GRIPEMS.UI.CursorOverlay.Refresh
                                                    then
                                                        GRIPEMS.UI.CursorOverlay:Refresh()
                                                    end
                                                end
                                                if
                                                    GRIPEMS.SequenceEditor and GRIPEMS.SequenceEditor.RelayoutSimplified
                                                then
                                                    GRIPEMS.SequenceEditor:RelayoutSimplified()
                                                end
                                                local vsnap = a._accessibilityPresetVisionSnapshot
                                                if vsnap then
                                                    a.speechEnabled = vsnap.speechEnabled
                                                    a.reduceMotion = vsnap.reduceMotion
                                                    a.soundCuesEnabled = vsnap.soundCuesEnabled
                                                    a.cursorOverlayEnabled = vsnap.cursorOverlayEnabled
                                                    GRIPEMS.Settings.db.profile.contrastPreset = vsnap.contrastPreset
                                                    _G.GRIP_EMS_Settings = _G.GRIP_EMS_Settings or {}
                                                    _G.GRIP_EMS_Settings.contrastPreset = vsnap.contrastPreset
                                                    if GRIPEMS.UI and GRIPEMS.UI.SetPalette then
                                                        local paletteName = vsnap.contrastPreset
                                                        if paletteName == "auto" and GRIPEMS.UI.ResolveAutoPreset then
                                                            paletteName = GRIPEMS.UI:ResolveAutoPreset()
                                                        end
                                                        GRIPEMS.UI:SetPalette(paletteName)
                                                    end
                                                    if
                                                        GRIPEMS.UI
                                                        and GRIPEMS.UI.CursorOverlay
                                                        and GRIPEMS.UI.CursorOverlay.Refresh
                                                    then
                                                        GRIPEMS.UI.CursorOverlay:Refresh()
                                                    end
                                                    a._accessibilityPresetVisionSnapshot = nil
                                                end
                                                GRIPEMS:Print(L["ACCESS_MODE_TOAST_REVERTED"])
                                            end
                                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                                        end,
                                        width = "full",
                                    },
                                    reDetectCVars = {
                                        type = "execute",
                                        order = 2,
                                        name = L["ACCESS_CVAR_MIRROR_REDETECT_LABEL"],
                                        desc = L["ACCESS_CVAR_MIRROR_REDETECT_DESC"],
                                        func = function()
                                            if GRIPEMS.MirrorAccessibilityCVars then
                                                local ran, applied = GRIPEMS:MirrorAccessibilityCVars(true)
                                                if ran and applied == 0 and DEFAULT_CHAT_FRAME then
                                                    DEFAULT_CHAT_FRAME:AddMessage(L["ACCESS_CVAR_MIRROR_TOAST_NOOP"])
                                                end
                                            end
                                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                                        end,
                                    },
                                },
                            },
                            preset = {
                                type = "group",
                                name = "Contrast preset",
                                inline = true,
                                order = 0,
                                args = {
                                    desc = {
                                        type = "description",
                                        name = "Switch the addon color palette. Reload UI for full effect.",
                                        order = 1,
                                        fontSize = "medium",
                                    },
                                    contrastPreset = {
                                        type = "select",
                                        name = "Contrast preset",
                                        desc = "Auto follows the WoW colorblindMode CVar.",
                                        order = 2,
                                        values = {
                                            auto = "Auto (follow colorblindMode CVar)",
                                            Default = "Default",
                                            HighContrast = "High contrast",
                                            DeuteranopiaSafe = "Deuteranopia-safe",
                                        },
                                        get = function()
                                            if _G.GRIP_EMS_Settings and _G.GRIP_EMS_Settings.contrastPreset ~= nil then
                                                return _G.GRIP_EMS_Settings.contrastPreset
                                            end
                                            return GRIPEMS.Settings.db.profile.contrastPreset or "auto"
                                        end,
                                        set = function(_, val)
                                            _G.GRIP_EMS_Settings = _G.GRIP_EMS_Settings or {}
                                            _G.GRIP_EMS_Settings.contrastPreset = val
                                            if GRIPEMS.Settings and GRIPEMS.Settings.db then
                                                GRIPEMS.Settings.db.profile.contrastPreset = val
                                            end
                                            local name = val
                                            if name == "auto" and GRIPEMS.UI and GRIPEMS.UI.ResolveAutoPreset then
                                                name = GRIPEMS.UI:ResolveAutoPreset()
                                            end
                                            if GRIPEMS.UI and GRIPEMS.UI.SetPalette then
                                                GRIPEMS.UI:SetPalette(name)
                                            end
                                            GRIPEMS:Print("Reload UI for full effect.")
                                        end,
                                        width = "double",
                                    },
                                },
                            },
                            colorblind = {
                                type = "group",
                                name = L["ACCESS_COLORBLIND_SECTION_NAME"] or "Color vision",
                                inline = true,
                                order = 1,
                                args = {
                                    desc = {
                                        type = "description",
                                        name = L["ACCESS_COLORBLIND_SECTION_DESC"] or "",
                                        order = 1,
                                        fontSize = "medium",
                                    },
                                    colorblindType = {
                                        type = "select",
                                        name = L["ACCESS_COLORBLIND_TYPE_LABEL"] or "Color vision deficiency",
                                        desc = function()
                                            local base = L["ACCESS_COLORBLIND_TYPE_DESC"] or ""
                                            local a = GRIPEMS.Settings
                                                and GRIPEMS.Settings.db
                                                and GRIPEMS.Settings.db.profile
                                                and GRIPEMS.Settings.db.profile.accessibility
                                            if not a then
                                                return base
                                            end
                                            local preset = GRIPEMS.Settings.db.profile.contrastPreset or "auto"
                                            if preset == "auto" and GRIPEMS.UI and GRIPEMS.UI.ResolveAutoPreset then
                                                preset = GRIPEMS.UI:ResolveAutoPreset()
                                            end
                                            local t = a.colorblindType or "none"
                                            local warnings = {}
                                            if
                                                preset == "DeuteranopiaSafe"
                                                and (t == "deuteranomaly" or t == "deuteranopia")
                                            then
                                                warnings[#warnings + 1] = L["ACCESS_COLORBLIND_STACK_WARN"] or ""
                                            end
                                            if t == "achromatomaly" or t == "achromatopsia" then
                                                warnings[#warnings + 1] = L["ACCESS_COLORBLIND_ACHROMAT_HINT"] or ""
                                            end
                                            if #warnings > 0 then
                                                return base
                                                    .. "\n\n|cffffaa33"
                                                    .. table.concat(warnings, "\n\n")
                                                    .. "|r"
                                            end
                                            return base
                                        end,
                                        order = 2,
                                        values = {
                                            none = L["ACCESS_COLORBLIND_TYPE_NONE"] or "None",
                                            protanomaly = L["ACCESS_COLORBLIND_TYPE_PROTANOMALY"]
                                                or "Protanomaly (reduced red response)",
                                            protanopia = L["ACCESS_COLORBLIND_TYPE_PROTANOPIA"]
                                                or "Protanopia (no red response)",
                                            deuteranomaly = L["ACCESS_COLORBLIND_TYPE_DEUTERANOMALY"]
                                                or "Deuteranomaly (reduced green response)",
                                            deuteranopia = L["ACCESS_COLORBLIND_TYPE_DEUTERANOPIA"]
                                                or "Deuteranopia (no green response)",
                                            tritanomaly = L["ACCESS_COLORBLIND_TYPE_TRITANOMALY"]
                                                or "Tritanomaly (reduced blue response)",
                                            tritanopia = L["ACCESS_COLORBLIND_TYPE_TRITANOPIA"]
                                                or "Tritanopia (no blue response)",
                                            achromatomaly = L["ACCESS_COLORBLIND_TYPE_ACHROMATOMALY"]
                                                or "Achromatomaly (partial color loss)",
                                            achromatopsia = L["ACCESS_COLORBLIND_TYPE_ACHROMATOPSIA"]
                                                or "Achromatopsia (full color loss)",
                                        },
                                        sorting = {
                                            "none",
                                            "protanomaly",
                                            "protanopia",
                                            "deuteranomaly",
                                            "deuteranopia",
                                            "tritanomaly",
                                            "tritanopia",
                                            "achromatomaly",
                                            "achromatopsia",
                                        },
                                        get = function()
                                            return GRIPEMS.Settings.db.profile.accessibility.colorblindType or "none"
                                        end,
                                        set = function(_, val)
                                            local a = GRIPEMS.Settings.db.profile.accessibility
                                            a.colorblindType = val
                                            -- Re-apply the current preset so the daltonization layer flushes through.
                                            local name = GRIPEMS.Settings.db.profile.contrastPreset or "auto"
                                            if name == "auto" and GRIPEMS.UI and GRIPEMS.UI.ResolveAutoPreset then
                                                name = GRIPEMS.UI:ResolveAutoPreset()
                                            end
                                            if GRIPEMS.UI and GRIPEMS.UI.SetPalette then
                                                GRIPEMS.UI:SetPalette(name)
                                            end
                                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                                        end,
                                        width = "double",
                                    },
                                    colorblindStrength = {
                                        type = "range",
                                        name = L["ACCESS_COLORBLIND_STRENGTH_LABEL"] or "Correction strength",
                                        desc = L["ACCESS_COLORBLIND_STRENGTH_DESC"] or "",
                                        order = 3,
                                        min = 0,
                                        max = 100,
                                        step = 1,
                                        bigStep = 5,
                                        get = function()
                                            local s = tonumber(
                                                GRIPEMS.Settings.db.profile.accessibility.colorblindStrength
                                            ) or 1.0
                                            return math.floor(s * 100 + 0.5)
                                        end,
                                        set = function(_, val)
                                            local a = GRIPEMS.Settings.db.profile.accessibility
                                            a.colorblindStrength = (tonumber(val) or 0) / 100
                                            local name = GRIPEMS.Settings.db.profile.contrastPreset or "auto"
                                            if name == "auto" and GRIPEMS.UI and GRIPEMS.UI.ResolveAutoPreset then
                                                name = GRIPEMS.UI:ResolveAutoPreset()
                                            end
                                            if GRIPEMS.UI and GRIPEMS.UI.SetPalette then
                                                GRIPEMS.UI:SetPalette(name)
                                            end
                                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                                        end,
                                        disabled = function()
                                            return (GRIPEMS.Settings.db.profile.accessibility.colorblindType or "none")
                                                == "none"
                                        end,
                                        width = "double",
                                    },
                                    preview = {
                                        type = "description",
                                        order = 4,
                                        fontSize = "medium",
                                        name = function()
                                            local C = GRIPEMS.UI and GRIPEMS.UI.Colors
                                            if not C then
                                                return ""
                                            end
                                            local function hex(color)
                                                if not color or not color.GetRGB then
                                                    return "ffffff"
                                                end
                                                local r, g, b = color:GetRGB()
                                                return string.format(
                                                    "%02x%02x%02x",
                                                    math.floor((r or 0) * 255 + 0.5),
                                                    math.floor((g or 0) * 255 + 0.5),
                                                    math.floor((b or 0) * 255 + 0.5)
                                                )
                                            end
                                            local label = L["ACCESS_COLORBLIND_PREVIEW_LABEL"] or "Preview:"
                                            return string.format(
                                                "%s  |cff%s[error]|r  |cff%s[success]|r  |cff%s[warning]|r  |cff%s[accent]|r  |cff%s[keybind]|r",
                                                label,
                                                hex(C.textError),
                                                hex(C.textSuccess),
                                                hex(C.textWarning),
                                                hex(C.accent),
                                                hex(C.keybindGold)
                                            )
                                        end,
                                    },
                                },
                            },
                            soundCues = {
                                type = "group",
                                name = L["ACCESS_SOUND_SECTION_NAME"] or "Sound cues",
                                inline = true,
                                order = 2,
                                args = {
                                    desc = {
                                        type = "description",
                                        name = L["ACCESS_SOUND_SECTION_DESC"] or "",
                                        order = 1,
                                        fontSize = "medium",
                                    },
                                    enabled = {
                                        type = "toggle",
                                        name = L["ACCESS_SOUND_ENABLED_LABEL"] or "Enable sound cues",
                                        desc = L["ACCESS_SOUND_ENABLED_DESC"] or "",
                                        order = 2,
                                        width = "full",
                                        get = function()
                                            return GRIPEMS.Settings.db.profile.accessibility.soundCuesEnabled
                                        end,
                                        set = function(_, val)
                                            GRIPEMS.Settings.db.profile.accessibility.soundCuesEnabled = val and true
                                                or false
                                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                                        end,
                                    },
                                    visualComplement = {
                                        type = "toggle",
                                        name = L["ACCESS_SOUND_VISUAL_LABEL"],
                                        desc = L["ACCESS_SOUND_VISUAL_DESC"],
                                        order = 2.5,
                                        get = function()
                                            return GRIPEMS.Settings.db.profile.accessibility.soundCuesVisualComplement
                                        end,
                                        set = function(_, val)
                                            GRIPEMS.Settings.db.profile.accessibility.soundCuesVisualComplement = val
                                                    and true
                                                or false
                                        end,
                                        width = "full",
                                    },
                                    errorCue = SP_buildLSMSoundRow(
                                        "error",
                                        "soundCueError",
                                        10,
                                        "ACCESS_SOUND_CUE_ERROR_LABEL",
                                        "ACCESS_SOUND_CUE_ERROR_DESC"
                                    ),
                                    errorChannel = SP_buildChannelRow(
                                        "error",
                                        "soundCueErrorChannel",
                                        10.5,
                                        "ACCESS_SOUND_CHANNEL_ERROR_LABEL"
                                    ),
                                    errorPreview = SP_buildPreviewButton("error", 11),
                                    successCue = SP_buildLSMSoundRow(
                                        "success",
                                        "soundCueSuccess",
                                        20,
                                        "ACCESS_SOUND_CUE_SUCCESS_LABEL",
                                        "ACCESS_SOUND_CUE_SUCCESS_DESC"
                                    ),
                                    successChannel = SP_buildChannelRow(
                                        "success",
                                        "soundCueSuccessChannel",
                                        20.5,
                                        "ACCESS_SOUND_CHANNEL_SUCCESS_LABEL"
                                    ),
                                    successPreview = SP_buildPreviewButton("success", 21),
                                    infoCue = SP_buildLSMSoundRow(
                                        "info",
                                        "soundCueInfo",
                                        30,
                                        "ACCESS_SOUND_CUE_INFO_LABEL",
                                        "ACCESS_SOUND_CUE_INFO_DESC"
                                    ),
                                    infoChannel = SP_buildChannelRow(
                                        "info",
                                        "soundCueInfoChannel",
                                        30.5,
                                        "ACCESS_SOUND_CHANNEL_INFO_LABEL"
                                    ),
                                    infoPreview = SP_buildPreviewButton("info", 31),
                                    stepCue = SP_buildLSMSoundRow(
                                        "stepComplete",
                                        "soundCueStepComplete",
                                        40,
                                        "ACCESS_SOUND_CUE_STEP_LABEL",
                                        "ACCESS_SOUND_CUE_STEP_DESC"
                                    ),
                                    stepChannel = SP_buildChannelRow(
                                        "stepComplete",
                                        "soundCueStepCompleteChannel",
                                        40.5,
                                        "ACCESS_SOUND_CHANNEL_STEP_LABEL"
                                    ),
                                    stepPreview = SP_buildPreviewButton("stepComplete", 41),
                                },
                            },
                            cursorOverlay = {
                                type = "group",
                                name = L["ACCESS_CURSOR_SECTION_NAME"],
                                inline = true,
                                order = 4,
                                args = {
                                    desc = {
                                        type = "description",
                                        name = L["ACCESS_CURSOR_SECTION_DESC"],
                                        order = 1,
                                        fontSize = "medium",
                                    },
                                    enabled = {
                                        type = "toggle",
                                        name = L["ACCESS_CURSOR_ENABLED_LABEL"],
                                        desc = L["ACCESS_CURSOR_ENABLED_DESC"],
                                        order = 2,
                                        width = "full",
                                        get = function()
                                            return GRIPEMS.Settings.db.profile.accessibility.cursorOverlayEnabled
                                        end,
                                        set = function(_, val)
                                            GRIPEMS.Settings.db.profile.accessibility.cursorOverlayEnabled = val
                                                    and true
                                                or false
                                            if
                                                GRIPEMS.UI
                                                and GRIPEMS.UI.CursorOverlay
                                                and GRIPEMS.UI.CursorOverlay.Refresh
                                            then
                                                GRIPEMS.UI.CursorOverlay:Refresh()
                                            end
                                        end,
                                    },
                                    mode = {
                                        type = "select",
                                        name = L["ACCESS_CURSOR_MODE_LABEL"],
                                        desc = L["ACCESS_CURSOR_MODE_DESC"],
                                        order = 3,
                                        values = function()
                                            return {
                                                ring = L["ACCESS_CURSOR_MODE_RING"],
                                                crosshair = L["ACCESS_CURSOR_MODE_CROSSHAIR"],
                                            }
                                        end,
                                        sorting = { "ring", "crosshair" },
                                        get = function()
                                            return GRIPEMS.Settings.db.profile.accessibility.cursorOverlayMode or "ring"
                                        end,
                                        set = function(_, val)
                                            GRIPEMS.Settings.db.profile.accessibility.cursorOverlayMode = val
                                            if
                                                GRIPEMS.UI
                                                and GRIPEMS.UI.CursorOverlay
                                                and GRIPEMS.UI.CursorOverlay.Refresh
                                            then
                                                GRIPEMS.UI.CursorOverlay:Refresh()
                                            end
                                        end,
                                        disabled = function()
                                            return not GRIPEMS.Settings.db.profile.accessibility.cursorOverlayEnabled
                                        end,
                                    },
                                    size = {
                                        type = "select",
                                        name = L["ACCESS_CURSOR_SIZE_LABEL"],
                                        desc = L["ACCESS_CURSOR_SIZE_DESC"],
                                        order = 4,
                                        values = function()
                                            return {
                                                [1.0] = L["ACCESS_CURSOR_SIZE_1X"],
                                                [1.5] = L["ACCESS_CURSOR_SIZE_15X"],
                                                [2.0] = L["ACCESS_CURSOR_SIZE_2X"],
                                            }
                                        end,
                                        sorting = { 1.0, 1.5, 2.0 },
                                        get = function()
                                            return GRIPEMS.Settings.db.profile.accessibility.cursorOverlaySize or 1.5
                                        end,
                                        set = function(_, val)
                                            GRIPEMS.Settings.db.profile.accessibility.cursorOverlaySize = tonumber(val)
                                                or 1.5
                                            if
                                                GRIPEMS.UI
                                                and GRIPEMS.UI.CursorOverlay
                                                and GRIPEMS.UI.CursorOverlay.Refresh
                                            then
                                                GRIPEMS.UI.CursorOverlay:Refresh()
                                            end
                                        end,
                                        disabled = function()
                                            return not GRIPEMS.Settings.db.profile.accessibility.cursorOverlayEnabled
                                        end,
                                    },
                                    colorInfo = {
                                        type = "description",
                                        name = L["ACCESS_CURSOR_COLOR_INFO"],
                                        order = 5,
                                        fontSize = "medium",
                                    },
                                },
                            },
                            feedback = {
                                type = "group",
                                name = L["ACCESS_FEEDBACK_SECTION_NAME"],
                                order = 5,
                                inline = true,
                                args = {
                                    desc = {
                                        type = "description",
                                        name = L["ACCESS_FEEDBACK_SECTION_DESC"],
                                        order = 1,
                                        fontSize = "medium",
                                    },
                                    apx = {
                                        type = "execute",
                                        name = L["ACCESS_FEEDBACK_APX_LABEL"],
                                        desc = L["ACCESS_FEEDBACK_APX_DESC"],
                                        order = 2,
                                        func = function()
                                            SP_showURL("https://accessible.games/accessible-player-experiences/")
                                        end,
                                    },
                                    gag = {
                                        type = "execute",
                                        name = L["ACCESS_FEEDBACK_GAG_LABEL"],
                                        desc = L["ACCESS_FEEDBACK_GAG_DESC"],
                                        order = 3,
                                        func = function()
                                            SP_showURL("https://gameaccessibilityguidelines.com/")
                                        end,
                                    },
                                    ibelin = {
                                        type = "execute",
                                        name = L["ACCESS_FEEDBACK_IBELIN_LABEL"],
                                        desc = L["ACCESS_FEEDBACK_IBELIN_DESC"],
                                        order = 4,
                                        func = function()
                                            SP_showURL(
                                                "https://www.netflix.com/tudum/articles/ibelin-release-date-trailer-news"
                                            )
                                        end,
                                    },
                                    discord = {
                                        type = "execute",
                                        name = L["ACCESS_FEEDBACK_DISCORD_LABEL"],
                                        desc = L["ACCESS_FEEDBACK_DISCORD_DESC"],
                                        order = 5,
                                        func = function()
                                            SP_showURL("https://discord.gg/temptingus")
                                        end,
                                    },
                                },
                            },
                            density = {
                                type = "group",
                                name = L["ACCESS_DENSITY_SECTION_NAME"],
                                inline = true,
                                order = 10,
                                args = {
                                    desc = {
                                        type = "description",
                                        name = L["ACCESS_DENSITY_SECTION_DESC"],
                                        order = 1,
                                        fontSize = "medium",
                                    },
                                    largeTargets = {
                                        type = "toggle",
                                        name = L["ACCESS_DENSITY_TOGGLE_LABEL"],
                                        desc = L["ACCESS_DENSITY_TOGGLE_DESC"],
                                        order = 2,
                                        width = "full",
                                        get = function()
                                            return GRIPEMS.Settings.db.profile.accessibility.density == "large"
                                        end,
                                        set = function(_, val)
                                            -- Simplified Mode (Phase S2) requires Large targets; refuse to
                                            -- disable the toggle while Simplified Mode is on.
                                            local acc = GRIPEMS.Settings.db.profile.accessibility
                                            if acc.simplifiedMode and not val then
                                                GRIPEMS:Print(L["ACCESS_SIMPLIFIED_DENSITY_REJECT"])
                                                return
                                            end
                                            GRIPEMS.Settings.db.profile.accessibility.density = val and "large"
                                                or "normal"
                                            if GRIPEMS.UI and GRIPEMS.UI.ApplyLargeTargets then
                                                GRIPEMS.UI:ApplyLargeTargets()
                                            end
                                        end,
                                    },
                                    reloadHint = {
                                        type = "description",
                                        name = L["ACCESS_DENSITY_RELOAD_HINT"],
                                        order = 3,
                                        fontSize = "medium",
                                    },
                                },
                            },
                            simplifiedMode = {
                                type = "group",
                                name = L["ACCESS_SIMPLIFIED_SECTION_NAME"],
                                inline = true,
                                order = 7,
                                args = {
                                    desc = {
                                        type = "description",
                                        name = L["ACCESS_SIMPLIFIED_SECTION_DESC"],
                                        order = 1,
                                        fontSize = "medium",
                                    },
                                    toggle = {
                                        type = "toggle",
                                        name = L["ACCESS_SIMPLIFIED_TOGGLE_LABEL"],
                                        desc = L["ACCESS_SIMPLIFIED_TOGGLE_DESC"],
                                        order = 2,
                                        width = "full",
                                        get = function()
                                            return GRIPEMS.Settings.db.profile.accessibility.simplifiedMode
                                        end,
                                        set = function(_, val)
                                            GRIPEMS.Settings.db.profile.accessibility.simplifiedMode = val and true
                                                or false
                                            if GRIPEMS.SequenceEditor and GRIPEMS.SequenceEditor.RelayoutSimplified then
                                                GRIPEMS.SequenceEditor:RelayoutSimplified()
                                            end
                                        end,
                                    },
                                    delay = {
                                        type = "range",
                                        name = L["ACCESS_SIMPLIFIED_DELAY_LABEL"],
                                        desc = L["ACCESS_SIMPLIFIED_DELAY_DESC"],
                                        order = 3,
                                        min = 250,
                                        max = 1500,
                                        step = 50,
                                        get = function()
                                            return GRIPEMS.Settings.db.profile.accessibility.simplifiedDelay
                                        end,
                                        set = function(_, val)
                                            GRIPEMS.Settings.db.profile.accessibility.simplifiedDelay = val
                                        end,
                                        width = "full",
                                    },
                                },
                            },
                            display = {
                                type = "group",
                                name = L["ACCESS_SECTION_DISPLAY"],
                                inline = true,
                                order = 3,
                                args = {
                                    desc = {
                                        type = "description",
                                        name = L["ACCESS_SECTION_DISPLAY_DESC"],
                                        order = 1,
                                        fontSize = "medium",
                                    },
                                    fontName = {
                                        type = "select",
                                        name = L["ACCESS_FONT_LABEL"],
                                        desc = L["ACCESS_FONT_DESC"],
                                        order = 3,
                                        dialogControl = "LSM30_Font",
                                        values = function()
                                            local LSM = LibStub and LibStub("LibSharedMedia-3.0", true)
                                            if LSM then
                                                return LSM:HashTable("font")
                                            end
                                            return { ["Friz Quadrata TT"] = "Friz Quadrata TT" }
                                        end,
                                        get = function()
                                            return GRIPEMS.Settings.db.profile.accessibility.fontName
                                        end,
                                        set = function(_, val)
                                            GRIPEMS.Settings.db.profile.accessibility.fontName = val
                                            GRIPEMS:Print(L["ACCESS_FONT_RELOAD_NOTICE"])
                                        end,
                                        width = "full",
                                    },
                                },
                            },
                            theming = {
                                type = "group",
                                name = L["ACCESS_THEME_SECTION_NAME"],
                                inline = true,
                                order = 6,
                                args = {
                                    desc = {
                                        type = "description",
                                        name = L["ACCESS_THEME_SECTION_DESC"],
                                        order = 1,
                                        fontSize = "medium",
                                    },
                                    uiScale = {
                                        type = "range",
                                        name = L["ACCESS_THEME_UI_SCALE_LABEL"],
                                        desc = L["ACCESS_THEME_UI_SCALE_DESC"],
                                        order = 2,
                                        min = 0.8,
                                        max = 2.0,
                                        step = 0.05,
                                        get = function()
                                            return GRIPEMS.Settings.db.profile.accessibility.uiScale
                                        end,
                                        set = function(_, val)
                                            -- Simplified Mode (Phase S2) enforces a 1.25 minimum UI scale
                                            -- per design 4.3. Sub-minimum values are rejected with a toast;
                                            -- users may still pick any value in the [1.25, 2.0] range.
                                            local acc = GRIPEMS.Settings.db.profile.accessibility
                                            if acc.simplifiedMode and (val or 0) < 1.25 then
                                                GRIPEMS:Print(L["ACCESS_SIMPLIFIED_SCALE_REJECT"])
                                                return
                                            end
                                            GRIPEMS.Settings.db.profile.accessibility.uiScale = val
                                            if GRIPEMS.UI and GRIPEMS.UI.ApplyUIScale then
                                                GRIPEMS.UI:ApplyUIScale()
                                            end
                                            if GRIPEMS.Theme and GRIPEMS.Theme.ApplyTheme then
                                                GRIPEMS.Theme.ApplyTheme()
                                            end
                                        end,
                                        width = "full",
                                    },
                                    bgOpacity = {
                                        type = "range",
                                        name = L["ACCESS_THEME_BG_OPACITY_LABEL"],
                                        desc = L["ACCESS_THEME_BG_OPACITY_DESC"],
                                        order = 3,
                                        min = 0.4,
                                        max = 1.0,
                                        step = 0.05,
                                        get = function()
                                            return GRIPEMS.Settings.db.profile.accessibility.bgOpacity
                                        end,
                                        set = function(_, val)
                                            GRIPEMS.Settings.db.profile.accessibility.bgOpacity = val
                                            if GRIPEMS.UI and GRIPEMS.UI.RebindBackdrops then
                                                GRIPEMS.UI:RebindBackdrops()
                                            end
                                            if GRIPEMS.Theme and GRIPEMS.Theme.ApplyTheme then
                                                GRIPEMS.Theme.ApplyTheme()
                                            end
                                        end,
                                        width = "full",
                                    },
                                    borderOpacity = {
                                        type = "range",
                                        name = L["ACCESS_THEME_BORDER_OPACITY_LABEL"],
                                        desc = L["ACCESS_THEME_BORDER_OPACITY_DESC"],
                                        order = 4,
                                        min = 0.4,
                                        max = 1.0,
                                        step = 0.05,
                                        get = function()
                                            return GRIPEMS.Settings.db.profile.accessibility.borderOpacity
                                        end,
                                        set = function(_, val)
                                            GRIPEMS.Settings.db.profile.accessibility.borderOpacity = val
                                            if GRIPEMS.UI and GRIPEMS.UI.RebindBackdrops then
                                                GRIPEMS.UI:RebindBackdrops()
                                            end
                                            if GRIPEMS.Theme and GRIPEMS.Theme.ApplyTheme then
                                                GRIPEMS.Theme.ApplyTheme()
                                            end
                                        end,
                                        width = "full",
                                    },
                                    panelAlpha = {
                                        type = "range",
                                        name = L["ACCESS_THEME_PANEL_ALPHA_LABEL"],
                                        desc = L["ACCESS_THEME_PANEL_ALPHA_DESC"],
                                        order = 5,
                                        min = 0.4,
                                        max = 1.0,
                                        step = 0.05,
                                        get = function()
                                            return GRIPEMS.Settings.db.profile.accessibility.panelAlpha
                                        end,
                                        set = function(_, val)
                                            GRIPEMS.Settings.db.profile.accessibility.panelAlpha = val
                                            if GRIPEMS.UI and GRIPEMS.UI.ApplyLiveAlphas then
                                                GRIPEMS.UI:ApplyLiveAlphas()
                                            end
                                            if GRIPEMS.Theme and GRIPEMS.Theme.ApplyTheme then
                                                GRIPEMS.Theme.ApplyTheme()
                                            end
                                        end,
                                        width = "full",
                                    },
                                    overlayAlpha = {
                                        type = "range",
                                        name = L["ACCESS_THEME_OVERLAY_ALPHA_LABEL"],
                                        desc = L["ACCESS_THEME_OVERLAY_ALPHA_DESC"],
                                        order = 6,
                                        min = 0.4,
                                        max = 1.0,
                                        step = 0.05,
                                        get = function()
                                            return GRIPEMS.Settings.db.profile.accessibility.overlayAlpha
                                        end,
                                        set = function(_, val)
                                            GRIPEMS.Settings.db.profile.accessibility.overlayAlpha = val
                                            if GRIPEMS.UI and GRIPEMS.UI.ApplyLiveAlphas then
                                                GRIPEMS.UI:ApplyLiveAlphas()
                                            end
                                            if GRIPEMS.Theme and GRIPEMS.Theme.ApplyTheme then
                                                GRIPEMS.Theme.ApplyTheme()
                                            end
                                        end,
                                        width = "full",
                                    },
                                    reset = {
                                        type = "execute",
                                        name = L["ACCESS_THEME_RESET_LABEL"],
                                        desc = L["ACCESS_THEME_RESET_DESC"],
                                        order = 7,
                                        func = function()
                                            local a = GRIPEMS.Settings.db.profile.accessibility
                                            a.bgOpacity = 1.0
                                            a.borderOpacity = 1.0
                                            a.panelAlpha = 1.0
                                            a.overlayAlpha = 1.0
                                            a.uiScale = 1.0
                                            if GRIPEMS.UI and GRIPEMS.UI.ApplyTheme then
                                                GRIPEMS.UI:ApplyTheme()
                                            end
                                            if GRIPEMS.Theme and GRIPEMS.Theme.ApplyTheme then
                                                GRIPEMS.Theme.ApplyTheme()
                                            end
                                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                                        end,
                                    },
                                },
                            },
                            motion = {
                                type = "group",
                                name = L["ACCESS_SECTION_MOTION"],
                                inline = true,
                                order = 3.1,
                                args = {
                                    desc = {
                                        type = "description",
                                        name = L["ACCESS_SECTION_MOTION_DESC"],
                                        order = 1,
                                        fontSize = "medium",
                                    },
                                    reduceMotion = {
                                        type = "toggle",
                                        name = L["ACCESS_REDUCE_MOTION_LABEL"],
                                        desc = L["ACCESS_REDUCE_MOTION_DESC"],
                                        order = 2,
                                        get = function()
                                            return GRIPEMS.Settings.db.profile.accessibility.reduceMotion
                                        end,
                                        set = function(_, val)
                                            GRIPEMS.Settings.db.profile.accessibility.reduceMotion = val
                                            -- G8-AUDIT-50: announce toggle state.
                                            if GRIPEMS.Speech and GRIPEMS.Speech.Announce then
                                                GRIPEMS.Speech:Announce(
                                                    L[val and "ACCESS_ANNOUNCE_TOGGLE_REDUCE_MOTION_ON" or "ACCESS_ANNOUNCE_TOGGLE_REDUCE_MOTION_OFF"]
                                                )
                                            end
                                        end,
                                        width = "full",
                                    },
                                    flickerSafe = {
                                        type = "toggle",
                                        name = L["ACCESS_FLICKER_SAFE_LABEL"],
                                        desc = L["ACCESS_FLICKER_SAFE_DESC"],
                                        order = 3,
                                        get = function()
                                            return GRIPEMS.Settings.db.profile.accessibility.flickerSafe
                                        end,
                                        set = function(_, val)
                                            GRIPEMS.Settings.db.profile.accessibility.flickerSafe = val and true
                                                or false
                                            -- G8-AUDIT-50: announce toggle state.
                                            if GRIPEMS.Speech and GRIPEMS.Speech.Announce then
                                                GRIPEMS.Speech:Announce(
                                                    L[val and "ACCESS_ANNOUNCE_TOGGLE_FLICKER_SAFE_ON" or "ACCESS_ANNOUNCE_TOGGLE_FLICKER_SAFE_OFF"]
                                                )
                                            end
                                        end,
                                        width = "full",
                                    },
                                },
                            },
                            audio = {
                                type = "group",
                                name = L["ACCESS_SECTION_AUDIO"],
                                inline = true,
                                order = 4.1,
                                args = {
                                    desc = {
                                        type = "description",
                                        name = L["ACCESS_SECTION_AUDIO_DESC"],
                                        order = 1,
                                        fontSize = "medium",
                                    },
                                    speechEnabled = {
                                        type = "toggle",
                                        name = L["ACCESS_SPEECH_ENABLED_LABEL"],
                                        desc = L["ACCESS_SPEECH_ENABLED_DESC"],
                                        order = 2,
                                        get = function()
                                            return GRIPEMS.Settings.db.profile.accessibility.speechEnabled
                                        end,
                                        set = function(_, val)
                                            -- G8-AUDIT-50: channel-toggle special-case. When turning OFF,
                                            -- announce BEFORE the write so Tier A is still active. When
                                            -- turning ON, announce AFTER the write so the new ON state
                                            -- lets Tier A fire.
                                            local prev = GRIPEMS.Settings.db.profile.accessibility.speechEnabled
                                            if prev and not val and GRIPEMS.Speech and GRIPEMS.Speech.Announce then
                                                GRIPEMS.Speech:Announce(L["ACCESS_ANNOUNCE_TOGGLE_SPEECH_ENABLED_OFF"])
                                            end
                                            GRIPEMS.Settings.db.profile.accessibility.speechEnabled = val
                                            if not prev and val and GRIPEMS.Speech and GRIPEMS.Speech.Announce then
                                                GRIPEMS.Speech:Announce(L["ACCESS_ANNOUNCE_TOGGLE_SPEECH_ENABLED_ON"])
                                            end
                                        end,
                                        width = "full",
                                    },
                                    speechRate = {
                                        type = "range",
                                        name = L["ACCESS_SPEECH_RATE_LABEL"],
                                        desc = L["ACCESS_SPEECH_RATE_DESC"],
                                        order = 3,
                                        min = -10,
                                        max = 10,
                                        step = 1,
                                        get = function()
                                            return GRIPEMS.Settings.db.profile.accessibility.speechRate
                                        end,
                                        set = function(_, val)
                                            GRIPEMS.Settings.db.profile.accessibility.speechRate = val
                                        end,
                                        width = "full",
                                    },
                                    speechVolume = {
                                        type = "range",
                                        name = L["ACCESS_SPEECH_VOLUME_LABEL"],
                                        desc = L["ACCESS_SPEECH_VOLUME_DESC"],
                                        order = 4,
                                        min = 0,
                                        max = 100,
                                        step = 5,
                                        get = function()
                                            return GRIPEMS.Settings.db.profile.accessibility.speechVolume
                                        end,
                                        set = function(_, val)
                                            GRIPEMS.Settings.db.profile.accessibility.speechVolume = val
                                        end,
                                        width = "full",
                                    },
                                    chatEmitterEnabled = {
                                        type = "toggle",
                                        name = L["ACCESS_CHAT_EMITTER_ENABLED_LABEL"],
                                        desc = L["ACCESS_CHAT_EMITTER_ENABLED_DESC"],
                                        order = 5,
                                        get = function()
                                            return GRIPEMS.Settings.db.profile.accessibility.chatEmitterEnabled
                                        end,
                                        set = function(_, val)
                                            -- G8-AUDIT-50: channel-toggle special-case. Same rationale as speechEnabled.
                                            local prev = GRIPEMS.Settings.db.profile.accessibility.chatEmitterEnabled
                                            if prev and not val and GRIPEMS.Speech and GRIPEMS.Speech.Announce then
                                                GRIPEMS.Speech:Announce(L["ACCESS_ANNOUNCE_TOGGLE_CHAT_EMITTER_OFF"])
                                            end
                                            GRIPEMS.Settings.db.profile.accessibility.chatEmitterEnabled = val
                                            if not prev and val and GRIPEMS.Speech and GRIPEMS.Speech.Announce then
                                                GRIPEMS.Speech:Announce(L["ACCESS_ANNOUNCE_TOGGLE_CHAT_EMITTER_ON"])
                                            end
                                        end,
                                        width = "full",
                                    },
                                    chatEmitterFrame = {
                                        type = "select",
                                        name = L["ACCESS_CHAT_EMITTER_FRAME_LABEL"],
                                        desc = L["ACCESS_CHAT_EMITTER_FRAME_DESC"],
                                        order = 6,
                                        values = {
                                            [1] = "Chat Window 1",
                                            [2] = "Chat Window 2 (Combat Log -- not recommended)",
                                            [3] = "Chat Window 3",
                                            [4] = "Chat Window 4",
                                            [5] = "Chat Window 5",
                                            [6] = "Chat Window 6",
                                            [7] = "Chat Window 7",
                                            [8] = "Chat Window 8",
                                            [9] = "Chat Window 9 (recommended -- typically hidden)",
                                            [10] = "Chat Window 10",
                                        },
                                        get = function()
                                            return GRIPEMS.Settings.db.profile.accessibility.chatEmitterFrame
                                        end,
                                        set = function(_, val)
                                            GRIPEMS.Settings.db.profile.accessibility.chatEmitterFrame = val
                                        end,
                                        width = "full",
                                        disabled = function()
                                            return not GRIPEMS.Settings.db.profile.accessibility.chatEmitterEnabled
                                        end,
                                    },
                                },
                            },
                        },
                    },
                    themingEditor = {
                        type = "group",
                        name = L["ACCESS_THEMING_EDITOR_NAME"] or "Per-Element Theming",
                        inline = false,
                        order = 2,
                        childGroups = "tab",
                        args = (function()
                            local TE = GRIPEMS.UI and GRIPEMS.UI.ThemingEditor
                            local a = {}

                            -- Overview tab: desc + 5 inline sections (preset, contrast silence, slots, import/export, footer)
                            local overviewArgs = {}
                            overviewArgs.desc = {
                                type = "description",
                                name = L["ACCESS_THEMING_EDITOR_DESC"] or "",
                                order = 0.5,
                                fontSize = "medium",
                            }
                            if TE then
                                if TE.BuildPresetArgs then
                                    overviewArgs.presetSection = {
                                        type = "group",
                                        inline = true,
                                        order = 1,
                                        name = L["ACCESS_THEMING_PRESET_HEADER"] or "Preset",
                                        args = TE.BuildPresetArgs(),
                                    }
                                end
                                if TE.BuildContrastSilenceArgs then
                                    overviewArgs.contrastSilenceSection = {
                                        type = "group",
                                        inline = true,
                                        order = 15,
                                        name = function()
                                            local n = (TE.GetSilencedCount and TE.GetSilencedCount()) or 0
                                            if n > 0 then
                                                return (
                                                    L["ACCESS_THEMING_CONTRAST_SILENCE_HEADER_BADGE"]
                                                    or "Silenced contrasts (%d)"
                                                ):format(n)
                                            end
                                            return L["ACCESS_THEMING_CONTRAST_SILENCE_HEADER"] or "Silenced contrasts"
                                        end,
                                        args = TE.BuildContrastSilenceArgs(),
                                    }
                                end
                                if TE.BuildSlotArgs then
                                    overviewArgs.slotSection = {
                                        type = "group",
                                        inline = true,
                                        order = 20,
                                        name = L["ACCESS_THEMING_SLOTS_HEADER"] or "Saved Themes",
                                        args = TE.BuildSlotArgs(),
                                    }
                                end
                                if TE.BuildImportExportArgs then
                                    overviewArgs.importExportSection = {
                                        type = "group",
                                        inline = true,
                                        order = 30,
                                        name = L["ACCESS_THEMING_IMPORTEXPORT_HEADER"] or "Import / Export",
                                        args = TE.BuildImportExportArgs(),
                                    }
                                end
                                if TE.BuildFooterArgs then
                                    overviewArgs.footerSection = {
                                        type = "group",
                                        inline = true,
                                        order = 40,
                                        name = L["ACCESS_THEMING_FOOTER_HEADER"] or "",
                                        args = TE.BuildFooterArgs(),
                                    }
                                end
                            end
                            a.overview = {
                                type = "group",
                                name = L["ACCESS_THEMING_OVERVIEW_TAB"] or "Overview",
                                order = 1,
                                args = overviewArgs,
                            }

                            -- Customize tab: 7 BuildOptionsTree groups (panel, overlay, row, button, text, emphasis, global)
                            local customizeArgs = {}
                            if TE and TE.BuildOptionsTree then
                                for k, v in pairs(TE.BuildOptionsTree()) do
                                    customizeArgs[k] = v
                                end
                            end
                            a.customize = {
                                type = "group",
                                name = L["ACCESS_THEMING_CUSTOMIZE_TAB"] or "Customize",
                                order = 2,
                                args = customizeArgs,
                            }

                            return a
                        end)(),
                    },
                },
            },
            info = {
                type = "group",
                name = L["GEMS_SETTINGS_SUPPORT"],
                order = 32,
                args = {
                    version = {
                        type = "description",
                        name = function()
                            return string.format(
                                L["GEMS_SETTINGS_VERSION_INFO"],
                                GRIPEMS.version or "dev",
                                GRIPEMS.Engine and GRIPEMS.Engine:GetActiveCount() or 0
                            )
                        end,
                        order = 1,
                        fontSize = "medium",
                    },
                    author = {
                        type = "description",
                        name = L["GEMS_ABOUT_AUTHOR"],
                        order = 2,
                    },
                    links = {
                        type = "description",
                        name = L["GEMS_ABOUT_LINKS"],
                        order = 3,
                    },
                    creditsHeader = {
                        type = "header",
                        name = L["GEMS_SUPPORT_CREDITS_HEADER"],
                        order = 5,
                    },
                    credits = {
                        type = "description",
                        name = L["GEMS_SUPPORT_CREDITS"],
                        order = 6,
                    },
                    systemHeader = {
                        type = "header",
                        name = L["GEMS_SUPPORT_SYSTEM_HEADER"],
                        order = 10,
                    },
                    systemInfo = {
                        type = "description",
                        name = function()
                            local ver, _, _, iface = GetBuildInfo()
                            local locale = GetLocale()
                            UpdateAddOnMemoryUsage()
                            local mem = GetAddOnMemoryUsage("GRIP-EMS")
                            return string.format(
                                "WoW: %s | Interface: %s | Locale: %s | Memory: %.1f KB",
                                ver or "?",
                                tostring(iface or "?"),
                                locale or "?",
                                mem or 0
                            )
                        end,
                        order = 11,
                        fontSize = "medium",
                    },
                    discordHeader = {
                        type = "header",
                        name = L["GEMS_SUPPORT_DISCORD_HEADER"],
                        order = 15,
                    },
                    discordLink = {
                        type = "description",
                        name = L["GEMS_SUPPORT_DISCORD"],
                        order = 16,
                    },
                    statusHeader = {
                        type = "header",
                        name = "",
                        order = 20,
                    },
                    status = {
                        type = "description",
                        name = function()
                            local lines = {}
                            -- Keybind count
                            local bindCount = 0
                            local KM = GRIPEMS.KeybindManager
                            if KM then
                                local binds = KM:GetAllKeybinds()
                                if binds then
                                    for _ in pairs(binds) do
                                        bindCount = bindCount + 1
                                    end
                                end
                            end
                            table.insert(lines, string.format(L["GEMS_ABOUT_KEYBINDS"], bindCount))
                            -- OOC queue
                            local oocCount = 0
                            if GRIPEMS.OOCQueue then
                                oocCount = GRIPEMS.OOCQueue:GetCount()
                            end
                            table.insert(lines, string.format(L["GEMS_ABOUT_OOC_QUEUE"], oocCount))
                            -- Migration source status
                            local sourceStatus = "Not detected"
                            if GRIPEMS.LegacyMigrate then
                                local gs = GRIPEMS.LegacyMigrate.GetSourceStatus()
                                if gs == "active" then
                                    sourceStatus = "Active (migration available)"
                                elseif gs == "disabled" then
                                    sourceStatus = "Disabled"
                                end
                            end
                            table.insert(lines, string.format(L["GEMS_ABOUT_SOURCE_STATUS"], sourceStatus))
                            -- Macro slots
                            local _, perChar = GetNumMacros()
                            table.insert(
                                lines,
                                string.format(L["GEMS_ABOUT_MACRO_SLOTS"], perChar, D().MAX_PER_CHAR_MACROS)
                            )
                            return table.concat(lines, "\n")
                        end,
                        order = 21,
                        fontSize = "medium",
                    },
                },
            },
            profileDiff = {
                type = "group",
                name = L["GEMS_CVAR_DIFF_TAB"],
                order = 37.5,
                args = (function()
                    local CPM = GRIPEMS.CvarProfileManager
                    local diffArgs = {}
                    local leftKey = "__general"
                    local rightKey = "__general"
                    local showDiffsOnly = true

                    local function GetProfileOverrides(key)
                        if key == "__general" then
                            return {}, L["GEMS_CVAR_PROFILE_GENERAL"]
                        end
                        local p = CPM and CPM:GetProfile(key)
                        if not p then
                            return {}, key
                        end
                        return p.overrides or {}, p.label or key
                    end

                    local function ProfileSelectValues()
                        local v = {}
                        v["__general"] = L["GEMS_CVAR_PROFILE_GENERAL"]
                        for _, p in ipairs(D().CVAR_PROFILES) do
                            v[p.key] = p.label
                        end
                        local custom = S:Get("cvarProfiles") or {}
                        for key, prof in pairs(custom) do
                            v[key] = prof.label or key
                        end
                        return v
                    end

                    diffArgs.desc = {
                        type = "description",
                        name = L["GEMS_CVAR_DIFF_DESC"],
                        order = 1,
                        fontSize = "medium",
                    }
                    diffArgs.leftProfile = {
                        type = "select",
                        name = L["GEMS_CVAR_DIFF_LEFT"],
                        order = 2,
                        values = ProfileSelectValues,
                        get = function()
                            return leftKey
                        end,
                        set = function(_, val)
                            leftKey = val
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                        end,
                        width = "normal",
                    }
                    diffArgs.rightProfile = {
                        type = "select",
                        name = L["GEMS_CVAR_DIFF_RIGHT"],
                        order = 3,
                        values = ProfileSelectValues,
                        get = function()
                            return rightKey
                        end,
                        set = function(_, val)
                            rightKey = val
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                        end,
                        width = "normal",
                    }
                    diffArgs.showDiffsOnly = {
                        type = "toggle",
                        name = L["GEMS_CVAR_DIFF_SHOW_DIFFS_ONLY"],
                        order = 4,
                        get = function()
                            return showDiffsOnly
                        end,
                        set = function(_, v)
                            showDiffsOnly = v
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                        end,
                        width = "full",
                    }
                    diffArgs.diffDisplay = {
                        type = "description",
                        order = 10,
                        fontSize = "medium",
                        width = "full",
                        name = function()
                            local leftOv, leftLbl = GetProfileOverrides(leftKey)
                            local rightOv, rightLbl = GetProfileOverrides(rightKey)
                            local seen = {}
                            local bothDiffer, leftOnly, rightOnly, bothSame = {}, {}, {}, {}
                            for cvar, val in pairs(leftOv) do
                                seen[cvar] = true
                                local rval = rightOv[cvar]
                                if rval == nil then
                                    table.insert(leftOnly, { cvar = cvar, l = val })
                                elseif tostring(val) ~= tostring(rval) then
                                    table.insert(bothDiffer, { cvar = cvar, l = val, r = rval })
                                else
                                    table.insert(bothSame, { cvar = cvar, l = val })
                                end
                            end
                            for cvar, val in pairs(rightOv) do
                                if not seen[cvar] then
                                    table.insert(rightOnly, { cvar = cvar, r = val })
                                end
                            end
                            local function sortByCvar(a, b)
                                return tostring(a.cvar) < tostring(b.cvar)
                            end
                            table.sort(bothDiffer, sortByCvar)
                            table.sort(leftOnly, sortByCvar)
                            table.sort(rightOnly, sortByCvar)
                            table.sort(bothSame, sortByCvar)
                            local total = #bothDiffer + #leftOnly + #rightOnly
                            if total == 0 and (showDiffsOnly or #bothSame == 0) then
                                return L["GEMS_CVAR_DIFF_NO_DIFFERENCES"]
                            end
                            local lines = {
                                string.format(L["GEMS_CVAR_DIFF_HEADER"], leftLbl, rightLbl),
                            }
                            for _, e in ipairs(bothDiffer) do
                                local body =
                                    string.format(L["GEMS_CVAR_DIFF_BOTH_DIFFER"], e.cvar, tostring(e.l), tostring(e.r))
                                table.insert(lines, "|cFFFF0000" .. body .. "|r")
                            end
                            for _, e in ipairs(leftOnly) do
                                local body = string.format(L["GEMS_CVAR_DIFF_LEFT_ONLY"], e.cvar, tostring(e.l))
                                table.insert(lines, "|cFFFFFF00" .. body .. "|r")
                            end
                            for _, e in ipairs(rightOnly) do
                                local body = string.format(L["GEMS_CVAR_DIFF_RIGHT_ONLY"], e.cvar, tostring(e.r))
                                table.insert(lines, "|cFFFFFF00" .. body .. "|r")
                            end
                            if not showDiffsOnly then
                                for _, e in ipairs(bothSame) do
                                    local body = string.format(L["GEMS_CVAR_DIFF_BOTH_SAME"], e.cvar, tostring(e.l))
                                    table.insert(lines, "|cFF00FF00" .. body .. "|r")
                                end
                            end
                            return table.concat(lines, "\n")
                        end,
                    }

                    return diffArgs
                end)(),
            },
            manageProfiles = {
                type = "group",
                name = L["GEMS_CVAR_PROFILE_MANAGE"],
                order = 38,
                args = (function()
                    local CPM = GRIPEMS.CvarProfileManager
                    local manageArgs = {}
                    local cloneFromVal = "__none"

                    -- Delete-profile confirmation
                    if not GRIPEMS.Popup:GetDef("GRIPEMS_DELETE_CVAR_PROFILE") then
                        GRIPEMS.Popup:Define("GRIPEMS_DELETE_CVAR_PROFILE", {
                            text = L["GEMS_CVAR_PROFILE_DELETE_CONFIRM"],
                            button1 = YES,
                            button2 = NO,
                            OnAccept = function(self)
                                local key = self.data
                                if key and GRIPEMS.CvarProfileManager then
                                    GRIPEMS.CvarProfileManager:DeleteProfile(key)
                                    LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                                end
                            end,
                            timeout = 0,
                            hideOnEscape = true,
                        })
                    end

                    if not GRIPEMS.Popup:GetDef("GRIPEMS_CVAR_PROFILE_EXPORT") then
                        GRIPEMS.Popup:Define("GRIPEMS_CVAR_PROFILE_EXPORT", {
                            text = L["GEMS_CVAR_PROFILE_EXPORT_RESULT"],
                            button1 = OKAY,
                            hasEditBox = true,
                            editBoxWidth = 350,
                            OnShow = function(self)
                                local data = self.data
                                if self.EditBox and data then
                                    self.EditBox:SetText(data)
                                    self.EditBox:HighlightText()
                                    self.EditBox:SetFocus()
                                end
                            end,
                            timeout = 0,
                            hideOnEscape = true,
                        })
                    end

                    local importString = ""
                    local importLabel = ""

                    manageArgs.importHeader = {
                        type = "header",
                        name = L["GEMS_CVAR_PROFILE_IMPORT"],
                        order = 0.1,
                    }
                    manageArgs.importDesc = {
                        type = "description",
                        name = L["GEMS_CVAR_PROFILE_IMPORT_DESC"],
                        order = 0.2,
                        fontSize = "medium",
                    }
                    manageArgs.importString = {
                        type = "input",
                        name = L["GEMS_CVAR_PROFILE_IMPORT_INPUT"],
                        order = 0.3,
                        multiline = 4,
                        get = function()
                            return importString
                        end,
                        set = function(_, val)
                            importString = val
                        end,
                        width = "full",
                    }
                    manageArgs.importLabel = {
                        type = "input",
                        name = L["GEMS_CVAR_PROFILE_IMPORT_LABEL"],
                        desc = L["GEMS_CVAR_PROFILE_IMPORT_LABEL_DESC"],
                        order = 0.4,
                        get = function()
                            return importLabel
                        end,
                        set = function(_, val)
                            importLabel = val
                        end,
                        width = "double",
                    }
                    manageArgs.importButton = {
                        type = "execute",
                        name = L["GEMS_CVAR_PROFILE_IMPORT_BUTTON"],
                        order = 0.5,
                        func = function()
                            if not CPM or not CPM.ImportProfile then
                                return
                            end
                            if not importString or importString == "" then
                                return
                            end
                            local key, countOrErr = CPM:ImportProfile(importString, importLabel)
                            if key then
                                local imported = CPM:GetProfile(key)
                                local lbl = imported and imported.label or key
                                GRIPEMS:Print(
                                    string.format(L["GEMS_CVAR_PROFILE_IMPORT_SUCCESS"], tostring(lbl), countOrErr or 0)
                                )
                                -- G8-AUDIT-27a: announce import success on Tier A TTS.
                                if GRIPEMS.Speech and GRIPEMS.Speech.Announce then
                                    GRIPEMS.Speech:Announce(
                                        string.format(
                                            L["ACCESS_ANNOUNCE_S18_IMPORT_OK"],
                                            tostring(lbl),
                                            countOrErr or 0
                                        )
                                    )
                                end
                                importString = ""
                                importLabel = ""
                                LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                            else
                                GRIPEMS:Print(
                                    string.format(L["GEMS_CVAR_PROFILE_IMPORT_ERROR"], tostring(countOrErr or "?"))
                                )
                                -- G8-AUDIT-27b: announce import error on Tier A TTS.
                                if GRIPEMS.Speech and GRIPEMS.Speech.Announce then
                                    GRIPEMS.Speech:Announce(
                                        string.format(
                                            L["ACCESS_ANNOUNCE_S18_IMPORT_ERROR"],
                                            tostring(countOrErr or "?")
                                        )
                                    )
                                end
                            end
                        end,
                        disabled = function()
                            return not importString or importString == ""
                        end,
                        width = "normal",
                    }

                    manageArgs.desc = {
                        type = "description",
                        name = L["GEMS_CVAR_PROFILE_MANAGE_DESC"],
                        order = 1,
                        fontSize = "medium",
                    }
                    manageArgs.createName = {
                        type = "input",
                        name = L["GEMS_CVAR_PROFILE_CREATE_NAME"],
                        order = 2,
                        set = function(_, val)
                            if not val or val == "" or not CPM then
                                return
                            end
                            local src = cloneFromVal ~= "__none" and cloneFromVal or nil
                            CPM:CreateProfile(val, src)
                            cloneFromVal = "__none"
                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                        end,
                        get = function()
                            return ""
                        end,
                        width = "double",
                    }
                    manageArgs.cloneFrom = {
                        type = "select",
                        name = L["GEMS_CVAR_PROFILE_CLONE_FROM"],
                        order = 3,
                        values = function()
                            local v = { ["__none"] = L["GEMS_CVAR_PROFILE_GENERAL"] }
                            for _, p in ipairs(D().CVAR_PROFILES) do
                                v[p.key] = p.label
                            end
                            local custom = S:Get("cvarProfiles") or {}
                            for key, prof in pairs(custom) do
                                v[key] = prof.label or key
                            end
                            return v
                        end,
                        get = function()
                            return cloneFromVal
                        end,
                        set = function(_, val)
                            cloneFromVal = val
                        end,
                        width = "normal",
                    }

                    -- Rebuild dynamic entries (custom + built-in profile subgroups)
                    local function RebuildDynamic()
                        for k in pairs(manageArgs) do
                            if k:find("^cp_") or k:find("^bp_") then
                                manageArgs[k] = nil
                            end
                        end

                        -- Custom profiles (editable)
                        local custom = S:Get("cvarProfiles") or {}
                        local cpOrder = 10
                        for key, prof in pairs(custom) do
                            cpOrder = cpOrder + 1
                            local subArgs = {}
                            subArgs.rename = {
                                type = "input",
                                name = L["GEMS_CVAR_PROFILE_RENAME"],
                                order = 1,
                                get = function()
                                    local c = S:Get("cvarProfiles") or {}
                                    return c[key] and c[key].label or ""
                                end,
                                set = function(_, val)
                                    if CPM then
                                        CPM:RenameProfile(key, val)
                                        LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                                    end
                                end,
                                width = "double",
                            }
                            subArgs.delete = {
                                type = "execute",
                                name = L["GEMS_CVAR_PROFILE_DELETE"],
                                order = 2,
                                func = function()
                                    local lbl = prof.label or key
                                    -- G8-AUDIT-27c: announce delete-confirm body before showing the modal.
                                    if GRIPEMS.Speech and GRIPEMS.Speech.Announce then
                                        GRIPEMS.Speech:Announce(
                                            string.format(L["ACCESS_ANNOUNCE_S18_DELETE_CONFIRM"], tostring(lbl))
                                        )
                                    end
                                    GRIPEMS.Popup:Show("GRIPEMS_DELETE_CVAR_PROFILE", lbl, nil, key)
                                end,
                                width = "half",
                                confirm = false,
                            }
                            subArgs.export = {
                                type = "execute",
                                name = L["GEMS_CVAR_PROFILE_EXPORT"],
                                desc = L["GEMS_CVAR_PROFILE_EXPORT_DESC"],
                                order = 2.5,
                                func = function()
                                    if not CPM or not CPM.ExportProfile then
                                        return
                                    end
                                    local encoded, err = CPM:ExportProfile(key)
                                    if encoded then
                                        local lbl = prof.label or key
                                        -- G8-AUDIT-27d: announce export-ready body before showing the modal.
                                        if GRIPEMS.Speech and GRIPEMS.Speech.Announce then
                                            GRIPEMS.Speech:Announce(
                                                string.format(L["ACCESS_ANNOUNCE_S18_EXPORT_READY"], tostring(lbl))
                                            )
                                        end
                                        GRIPEMS.Popup:Show("GRIPEMS_CVAR_PROFILE_EXPORT", lbl, nil, encoded)
                                    else
                                        GRIPEMS:Print(
                                            string.format(L["GEMS_CVAR_PROFILE_IMPORT_ERROR"], tostring(err or "?"))
                                        )
                                    end
                                end,
                                width = "half",
                            }

                            -- Override count header
                            local overrides = prof.overrides or {}
                            local ovCount = 0
                            for _ in pairs(overrides) do
                                ovCount = ovCount + 1
                            end
                            subArgs.overridesHeader = {
                                type = "header",
                                name = ovCount > 0 and string.format(L["GEMS_CVAR_PROFILE_OVERRIDES"], ovCount)
                                    or L["GEMS_CVAR_PROFILE_NO_OVERRIDES"],
                                order = 3,
                            }

                            -- Per-override rows
                            local oOrder = 10
                            for cvarName, val in pairs(overrides) do
                                oOrder = oOrder + 1
                                local genVal = CPM and CPM:GetGeneralRecommendation(cvarName) or "?"
                                subArgs["ov_" .. cvarName] = {
                                    type = "input",
                                    name = cvarName,
                                    desc = "General: " .. tostring(genVal),
                                    order = oOrder,
                                    get = function()
                                        local c = S:Get("cvarProfiles") or {}
                                        if c[key] and c[key].overrides then
                                            return c[key].overrides[cvarName] or ""
                                        end
                                        return ""
                                    end,
                                    set = function(_, v)
                                        if CPM then
                                            CPM:SetProfileOverride(key, cvarName, v ~= "" and v or nil)
                                            RebuildDynamic()
                                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                                        end
                                    end,
                                    width = "double",
                                }
                                subArgs["rm_" .. cvarName] = {
                                    type = "execute",
                                    name = "X",
                                    desc = L["GEMS_CVAR_PROFILE_OVERRIDE_NONE"],
                                    order = oOrder + 0.5,
                                    func = function()
                                        if CPM then
                                            CPM:SetProfileOverride(key, cvarName, nil)
                                            RebuildDynamic()
                                            LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                                        end
                                    end,
                                    width = "half",
                                }
                            end

                            -- Add Override dropdown
                            subArgs.addOverride = {
                                type = "select",
                                name = L["GEMS_CVAR_PROFILE_ADD_OVERRIDE"],
                                order = 100,
                                values = function()
                                    local v = { ["__none"] = "" }
                                    local c = S:Get("cvarProfiles") or {}
                                    local existing = c[key] and c[key].overrides or {}
                                    for _, section in ipairs(D().CVAR_SECTIONS) do
                                        for _, rec in ipairs(section.cvars) do
                                            if not existing[rec.cvar] then
                                                v[rec.cvar] = rec.label or rec.cvar
                                            end
                                        end
                                    end
                                    return v
                                end,
                                get = function()
                                    return "__none"
                                end,
                                set = function(_, val)
                                    if val == "__none" or not CPM then
                                        return
                                    end
                                    local genVal = CPM:GetGeneralRecommendation(val) or "1"
                                    CPM:SetProfileOverride(key, val, genVal)
                                    RebuildDynamic()
                                    LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                                end,
                                width = "double",
                            }

                            manageArgs["cp_" .. key] = {
                                type = "group",
                                name = prof.label or key,
                                order = cpOrder,
                                inline = false,
                                args = subArgs,
                            }
                        end

                        -- Built-in profiles (read-only)
                        for i, p in ipairs(D().CVAR_PROFILES) do
                            local bArgs = {}
                            local bOverrides = p.overrides or {}
                            local bCount = 0
                            for _ in pairs(bOverrides) do
                                bCount = bCount + 1
                            end
                            bArgs.export = {
                                type = "execute",
                                name = L["GEMS_CVAR_PROFILE_EXPORT"],
                                desc = L["GEMS_CVAR_PROFILE_EXPORT_DESC"],
                                order = 0.5,
                                func = function()
                                    if not CPM or not CPM.ExportProfile then
                                        return
                                    end
                                    local encoded, err = CPM:ExportProfile(p.key)
                                    if encoded then
                                        -- G8-AUDIT-27e: announce export-ready body before showing the modal.
                                        if GRIPEMS.Speech and GRIPEMS.Speech.Announce then
                                            GRIPEMS.Speech:Announce(
                                                string.format(L["ACCESS_ANNOUNCE_S18_EXPORT_READY"], tostring(p.label))
                                            )
                                        end
                                        GRIPEMS.Popup:Show("GRIPEMS_CVAR_PROFILE_EXPORT", p.label, nil, encoded)
                                    else
                                        GRIPEMS:Print(
                                            string.format(L["GEMS_CVAR_PROFILE_IMPORT_ERROR"], tostring(err or "?"))
                                        )
                                    end
                                end,
                                width = "half",
                            }
                            bArgs.overridesHeader = {
                                type = "header",
                                name = bCount > 0 and string.format(L["GEMS_CVAR_PROFILE_OVERRIDES"], bCount)
                                    or L["GEMS_CVAR_PROFILE_NO_OVERRIDES"],
                                order = 1,
                            }
                            local bOrder = 2
                            for cvarName, val in pairs(bOverrides) do
                                bOrder = bOrder + 1
                                local genVal = CPM and CPM:GetGeneralRecommendation(cvarName) or "?"
                                bArgs["ov_" .. cvarName] = {
                                    type = "description",
                                    name = cvarName
                                        .. ": "
                                        .. tostring(val)
                                        .. "  (General: "
                                        .. tostring(genVal)
                                        .. ")",
                                    order = bOrder,
                                    fontSize = "medium",
                                }
                            end
                            manageArgs["bp_" .. p.key] = {
                                type = "group",
                                name = p.label .. " (built-in)",
                                order = 50 + i,
                                inline = false,
                                args = bArgs,
                            }
                        end
                    end

                    RebuildDynamic()

                    if GRIPEMS.RegisterCallback then
                        GRIPEMS.RegisterCallback("SettingsPanel_Manage", "CVAR_PROFILE_CHANGED", function()
                            RebuildDynamic()
                        end)
                    end

                    return manageArgs
                end)(),
            },
            profileMap = {
                type = "group",
                name = L["GEMS_CVAR_MAP_HEADER"],
                order = 39,
                args = (function()
                    local CPM = GRIPEMS.CvarProfileManager
                    local mapArgs = {}
                    mapArgs.desc = {
                        type = "description",
                        name = L["GEMS_CVAR_MAP_DESC"],
                        order = 1,
                        fontSize = "medium",
                    }
                    local gOrder = 2
                    for gi, group in ipairs(D().CONTEXT_GROUPS) do
                        gOrder = gOrder + 1
                        mapArgs["grpHeader_" .. gi] = {
                            type = "header",
                            name = group.name,
                            order = gOrder,
                        }
                        for _, ctxKey in ipairs(group.keys) do
                            gOrder = gOrder + 1
                            -- Resolve built-in default for desc label
                            local biKey = D().CVAR_PROFILE_MAP[ctxKey]
                            if not biKey then
                                local chain = D().CONTEXT_FALLBACKS and D().CONTEXT_FALLBACKS[ctxKey]
                                if chain then
                                    for _, fb in ipairs(chain) do
                                        if D().CVAR_PROFILE_MAP[fb] then
                                            biKey = D().CVAR_PROFILE_MAP[fb]
                                            break
                                        end
                                    end
                                end
                            end
                            local biLabel
                            if biKey then
                                for _, p in ipairs(D().CVAR_PROFILES) do
                                    if p.key == biKey then
                                        biLabel = p.label
                                        break
                                    end
                                end
                            end
                            mapArgs["ctx_" .. ctxKey] = {
                                type = "select",
                                name = ctxKey,
                                desc = biLabel and string.format(L["GEMS_CVAR_MAP_DEFAULT"], biLabel) or nil,
                                order = gOrder,
                                values = function()
                                    local v = { ["__none"] = L["GEMS_CVAR_MAP_NONE"] }
                                    for _, p in ipairs(D().CVAR_PROFILES) do
                                        v[p.key] = p.label
                                    end
                                    local custom = S:Get("cvarProfiles") or {}
                                    for key, prof in pairs(custom) do
                                        v[key] = prof.label or key
                                    end
                                    return v
                                end,
                                get = function()
                                    local userMap = S:Get("cvarProfileMap") or {}
                                    if userMap[ctxKey] then
                                        return userMap[ctxKey]
                                    end
                                    if CPM then
                                        local resolved = CPM:ResolveProfile(ctxKey)
                                        if resolved then
                                            return resolved
                                        end
                                    end
                                    return "__none"
                                end,
                                set = function(_, val)
                                    if not CPM then
                                        return
                                    end
                                    if val == "__none" then
                                        CPM:SetContextMapping(ctxKey, nil)
                                    else
                                        CPM:SetContextMapping(ctxKey, val)
                                    end
                                    LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
                                end,
                                width = "double",
                            }
                        end
                    end
                    return mapArgs
                end)(),
            },
        },
    }

    -- Add Profiles tab via AceDBOptions
    local db = S:GetDB()
    if db then
        options.args.profiles = AceDBOptions:GetOptionsTable(db)
        options.args.profiles.order = 40
    else
        GRIPEMS:Debug("SettingsPanel: AceDB not available for profiles tab")
    end

    -- Plugin settings group (Plugin API v2 Phase F). One AceConfig group aggregating every
    -- setting plugins registered via handle:RegisterSetting. The WHOLE group is hidden until
    -- at least one plugin setting exists, and it is EXCLUDED from the Blizzard subcategory
    -- loop below, so a no-plugin install renders exactly as before. Its args are (re)built on
    -- demand by SP:_RefreshPluginSettings, which SP:Open calls just before the dialog shows.
    options.args.pluginSettings = {
        type = "group",
        name = L["GEMS_SETTINGS_PLUGINS"],
        order = 45,
        hidden = function()
            local PA = GRIPEMS.PluginAPI
            return not (PA and PA.settingsDefs and next(PA.settingsDefs))
        end,
        args = {},
    }
    SP._options = options

    -- Register with AceConfig
    AceConfig:RegisterOptionsTable("GRIP-EMS", options)

    -- Register with Blizzard Settings panel: parent canvas + per-group subcategories.
    -- Parent shows the overview group (welcome / version / links).
    -- Each top-level group becomes a subcategory under the parent in Blizzard's left tree.
    -- The standalone AceConfigDialog (opened via SP:Open) uses the same left-tree layout via childGroups = tree.
    local parentName = "|cFF00CC66GRIP|r-EMS"
    SP._blizFrames = {}

    local parentFrame, parentCategoryID = AceConfigDialog:AddToBlizOptions("GRIP-EMS", parentName, nil, "overview")
    SP._blizParentCategoryID = parentCategoryID
    if parentFrame then
        SP._blizFrames[#SP._blizFrames + 1] = parentFrame
        if GRIPEMS.UI and GRIPEMS.UI.RegisterPanelFrame then
            GRIPEMS.UI:RegisterPanelFrame(parentFrame, "panel", "panel.settings")
        end
        parentFrame:HookScript("OnShow", function()
            if C_Timer and C_Timer.After then
                C_Timer.After(0, function()
                    SP:RestyleBlizPanel()
                end)
            end
        end)
    end

    -- Build sorted list of subcategory entries from the options table.
    local subEntries = {}
    for groupKey, groupTbl in pairs(options.args) do
        if
            groupKey ~= "overview"
            and groupKey ~= "pluginSettings"
            and type(groupTbl) == "table"
            and groupTbl.type == "group"
        then
            local resolvedName = groupTbl.name
            if type(resolvedName) == "function" then
                local ok, val = pcall(resolvedName)
                resolvedName = ok and val or groupKey
            end
            subEntries[#subEntries + 1] = {
                key = groupKey,
                order = tonumber(groupTbl.order) or 100,
                name = resolvedName or groupKey,
            }
        end
    end
    table.sort(subEntries, function(a, b)
        return a.order < b.order
    end)

    for _, entry in ipairs(subEntries) do
        local subFrame = AceConfigDialog:AddToBlizOptions("GRIP-EMS", entry.name, parentName, entry.key)
        if subFrame then
            SP._blizFrames[#SP._blizFrames + 1] = subFrame
            if GRIPEMS.UI and GRIPEMS.UI.RegisterPanelFrame then
                GRIPEMS.UI:RegisterPanelFrame(subFrame, "panel", "panel.settings")
            end
            subFrame:HookScript("OnShow", function()
                if C_Timer and C_Timer.After then
                    C_Timer.After(0, function()
                        SP:RestyleBlizPanel()
                    end)
                end
            end)
            -- G.8c.4: opt-in AceConfig -> Focus shim for v2.0.0 surfaces.
            -- G.9: cvarHealth additionally registers section + issue anchors
            -- and re-registers them on every shim rewalk via onRewalk.
            if entry.key == "accessibility" then
                local Shim = GRIPEMS.UI and GRIPEMS.UI.AceConfigFocusShim
                if Shim and Shim.Enable then
                    Shim:Enable(entry.key, subFrame, {
                        onRewalk = function()
                            SP:_RegisterAccessibilityAnchors()
                        end,
                    })
                    SP:_RegisterAccessibilityAnchors()
                    -- Mirror cvarHealth's OnShow re-registration safety net:
                    -- ensures anchors land against the freshly-walked tree on
                    -- every subFrame show (covers tab-switch scenarios where
                    -- the general tab returns to focus).
                    subFrame:HookScript("OnShow", function()
                        SP:_RegisterAccessibilityAnchors()
                    end)
                end
            elseif entry.key == "cvarHealth" then
                local Shim = GRIPEMS.UI and GRIPEMS.UI.AceConfigFocusShim
                if Shim and Shim.Enable then
                    Shim:Enable(entry.key, subFrame, {
                        onRewalk = function()
                            SP:_RegisterCvarHealthAnchors()
                            -- G8-AUDIT-01 (Bundle D): re-pin reload-gate pip
                            -- into the freshly-walked targets so it survives
                            -- AceConfigRegistry NotifyChange rewalks.
                            local RG = GRIPEMS.ReloadGate
                            if RG and RG._PinIntoFocusContext then
                                RG:_PinIntoFocusContext()
                            end
                        end,
                    })
                    SP:_RegisterCvarHealthAnchors()
                    -- V2OX-G9-COMBAT-FILTER-CROSS-SUBFRAME-WINDOW: refresh
                    -- anchors whenever the cvarHealth panel becomes visible.
                    -- Without this, if the user is on another subFrame
                    -- (e.g. accessibility) during a combat transition, the
                    -- SP._combatExitFrame OnEvent handler's NotifyChange
                    -- triggers _RewalkActive for the ACTIVE subFrame, not
                    -- cvarHealth. Accessibility's Shim:Enable above passes its own
                    -- onRewalk callback for accessibility anchors only,
                    -- so cvarHealth's anchors stay
                    -- stale until either the 30-second ticker fires while
                    -- Shim._activeKey == "cvarHealth" or the user returns
                    -- to cvarHealth and triggers another ConfigTableChange.
                    -- HookScript stacks with the existing RestyleBlizPanel
                    -- OnShow hook above; both fire on show.
                    subFrame:HookScript("OnShow", function()
                        SP:_RegisterCvarHealthAnchors()
                    end)
                end
            else
                local Shim = GRIPEMS.UI and GRIPEMS.UI.AceConfigFocusShim
                if Shim and Shim.Enable then
                    Shim:Enable(entry.key, subFrame, {})
                end
            end
        end
    end

    -- G.2a (G1): periodic in-session re-render so CVar Health scores stay
    -- fresh when CVars change outside the EMS panel (other addons, /script,
    -- in-game settings). AceConfigRegistry NotifyChange is cheap when no
    -- panel is visible -- it marks registered listeners; visible widgets
    -- re-render on the next frame, hidden widgets re-render when shown.
    if SP._scoreTicker then
        SP._scoreTicker:Cancel()
    end
    if C_Timer and C_Timer.NewTicker then
        SP._scoreTicker = C_Timer.NewTicker(30, function()
            local reg = LibStub and LibStub("AceConfigRegistry-3.0", true)
            if reg then
                reg:NotifyChange("GRIP-EMS")
            end
        end)
    end
end

--- Rebuild the Plugins group args from the live PA.settingsDefs registry. Each registered key
--- becomes one AceConfig option whose get reads the live Settings value and whose set routes
--- through the owning plugin handle's OverrideSetting -- so the override stack + single
--- SETTING_CHANGED fire path is the one write site. No-op when the group or the registry is
--- absent. Called by SP:Open just before the dialog shows so the panel reflects whatever
--- plugins have registered.
function SP:_RefreshPluginSettings()
    if not (SP._options and SP._options.args and SP._options.args.pluginSettings) then
        return
    end
    local PA = GRIPEMS.PluginAPI
    local rebuilt = {}
    if PA and PA.settingsDefs then
        local n = 0
        for key, entry in pairs(PA.settingsDefs) do
            n = n + 1
            local def = entry.def or {}
            local owner = entry.owner
            local item = {
                type = def.type or "toggle",
                name = def.name or key,
                desc = def.desc,
                order = n,
                get = function()
                    return GRIPEMS.Settings:Get(key)
                end,
                set = function(_, v)
                    local p = PA.plugins and PA.plugins[owner]
                    if p and p.handle then
                        p.handle:OverrideSetting(key, v)
                    end
                end,
            }
            if item.type == "range" then
                item.min = def.min
                item.max = def.max
                item.step = def.step
            end
            rebuilt[key] = item
        end
    end
    SP._options.args.pluginSettings.args = rebuilt
end

--- Open the settings panel programmatically.
function SP:Open()
    local AceConfigDialog = LibStub("AceConfigDialog-3.0")
    SP:_RefreshPluginSettings()
    AceConfigDialog:Open("GRIP-EMS")

    -- Apply dark theme after AceConfigDialog creates/shows the widget
    local widget = AceConfigDialog.OpenFrames and AceConfigDialog.OpenFrames["GRIP-EMS"]
    RestyleAceFrame(widget)
end

--- Public alias: apply the dark-theme restyle to any AceConfigDialog
--- widget. Used by UI/ThemingEditor/ModalFrame.lua so the standalone
--- per-element editor gets identical chrome to SP:Open without
--- duplicating the ~125-line restyle body.
function SP:RestyleAceFrameExternal(widget)
    RestyleAceFrame(widget)
end

--- Restyle every Blizzard Settings (ESC -> Options -> Addons) embedded subcategory frame.
--- Called from each subcategory's OnShow hook after AddToBlizOptions creates the embedded panel.
--- After Phase 4 v2.0.0 conversion, BlizOptions["GRIP-EMS"] holds one entry per subcategory plus the parent.
function SP:RestyleBlizPanel()
    local AceConfigDialog = LibStub("AceConfigDialog-3.0")
    local entries = AceConfigDialog.BlizOptions and AceConfigDialog.BlizOptions["GRIP-EMS"]
    if not entries then
        return
    end
    for _, widget in pairs(entries) do
        if widget then
            if widget.frame then
                RestyleAceFrame(widget)
            elseif widget.GetObjectType then
                RestyleAceFrame({ frame = widget, _gripRestyled = false })
            end
        end
    end
end

-- V2OX-G9-PINNED-MISMATCH-DIVERGENCE-COMBAT-SECURE-FOLLOWUP: PLAYER_REGEN
-- listener that re-runs SP:_RegisterCvarHealthAnchors when combat state
-- transitions. Secure-cvar mismatch rows are filtered out of issueAnchors
-- by _RegisterCvarHealthAnchors during combat (their cvar_fix_ button is
-- disabled by the InCombatLockdown gate). Calling AceConfigRegistry's
-- NotifyChange here fires the ConfigTableChange callback in
-- UI/AceConfigFocusShim.lua (Shim:_OnConfigChange), which schedules
-- _RewalkActive, which calls entry.onRewalk (wired at SettingsPanel.lua
-- L4775), which re-runs _RegisterCvarHealthAnchors. The filter then
-- reflects the new combat state on the next Alt+N press.
--
-- Idempotent: if this file is reloaded (defensive), the existing frame
-- is reused via SP._combatExitFrame, and UnregisterAllEvents wipes any
-- previous registrations before re-adding.
SP._combatExitFrame = SP._combatExitFrame or CreateFrame("Frame")
SP._combatExitFrame:UnregisterAllEvents()
SP._combatExitFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
SP._combatExitFrame:RegisterEvent("PLAYER_REGEN_DISABLED")
SP._combatExitFrame:SetScript("OnEvent", function()
    local reg = LibStub and LibStub("AceConfigRegistry-3.0", true)
    if reg and reg.NotifyChange then
        reg:NotifyChange("GRIP-EMS")
    end
end)
