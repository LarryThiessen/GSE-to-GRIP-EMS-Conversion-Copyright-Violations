-- GRIP-EMS: SpellValidator
-- Created: 2026-03-27
-- Updated: 2026-07-10
-- Patch: 12.0.7.68256 Midnight (Retail LIVE)

-- GRIP-EMS: SpellValidator
-- Spell validation for import, editor, and batch contexts.
-- Detects stale, talent-gated, renamed, or removed spells in sequences.

local ADDON_NAME, GRIPEMS = ...
local function D()
    return GRIPEMS.Defaults
end
local function SC()
    return GRIPEMS.SpellCache
end
local function Engine()
    return GRIPEMS.Engine
end

GRIPEMS.SpellValidator = {}
local SV = GRIPEMS.SpellValidator

-- Known macro placeholders (no-op in /castsequence, always valid)
local MACRO_PLACEHOLDERS = { ["null"] = true }

---------------------------------------------------------------------------
-- Spell Extraction
---------------------------------------------------------------------------

-- Casting command patterns (case-insensitive via :lower())
local castPatterns = {
    { pattern = "^%s*/castsequence%s", cmd = "castsequence" },
    { pattern = "^%s*/castrandom%s", cmd = "castrandom" },
    { pattern = "^%s*/cast%s", cmd = "cast" },
    { pattern = "^%s*/use%s", cmd = "use" },
}

--- Clean a raw spell token: strip (Rank N), semicolons, whitespace.
--- @param token string Raw spell name token
--- @return string|nil Cleaned spell name or nil if empty
local function CleanSpellToken(token)
    if not token then
        return nil
    end
    token = token:gsub("%s*%(Rank%s+%d+%)%s*$", "")
    token = token:gsub(";+%s*$", "")
    token = token:gsub("^!", "")
    token = token:match("^%s*(.-)%s*$")
    if token == "" then
        return nil
    end
    return token
end

--- Extract ALL spell/item references from a macrotext string.
--- Unlike SC:ParseSpellFromMacrotext, this processes every line and every
--- spell in /castsequence comma lists.
--- @param macrotext string The macro text to parse
--- @return table Array of { name=string, command=string }
function SV:ExtractAllSpells(macrotext)
    local results = {}
    if type(macrotext) ~= "string" or macrotext == "" then
        return results
    end

    for line in macrotext:gmatch("[^\r\n]+") do
        local lineLower = line:lower()

        -- Tooltip extraction: #showtooltip / #show with spell args
        local skip = false
        local tooltipRest = nil
        local ttMatch = lineLower:match("^%s*#showtooltip%s+(.*)")
        if ttMatch then
            tooltipRest = line:match("^%s*#showtooltip%s+(.*)")
        else
            ttMatch = lineLower:match("^%s*#show%s+(.*)")
            if ttMatch then
                tooltipRest = line:match("^%s*#show%s+(.*)")
            end
        end
        if tooltipRest then
            tooltipRest = tooltipRest:gsub("%[.-%]", "")
            tooltipRest = tooltipRest:match("^%s*(.-)%s*$")
            if tooltipRest and tooltipRest ~= "" then
                for token in tooltipRest:gmatch("[^;]+") do
                    local spell = CleanSpellToken(token)
                    if spell then
                        -- BUG-052 sibling: a bare number after #showtooltip is
                        -- an inventory slot (e.g. 13 = top trinket), not a spell
                        local num = tonumber(spell)
                        if num and tostring(num) == spell then
                            spell = nil
                        end
                        if spell and spell ~= "" then
                            results[#results + 1] = {
                                name = spell,
                                command = "showtooltip",
                            }
                        end
                    end
                end
            end
            skip = true
        end

        -- Check skip prefixes (lazy via D() to avoid load-time dependency)
        for _, pat in ipairs(D().SKIP_SPELL_PREFIXES) do
            if lineLower:match(pat) then
                skip = true
                break
            end
        end

        if not skip then
            -- Try each casting command pattern
            local matchedCmd = nil
            for _, entry in ipairs(castPatterns) do
                if lineLower:match(entry.pattern) then
                    matchedCmd = entry.cmd
                    break
                end
            end

            if matchedCmd then
                -- Strip the command prefix (use original case line)
                local rest = line:match("^%s*/[%a]+%s+(.*)")
                if rest then
                    -- Strip [conditionals] blocks
                    rest = rest:gsub("%[.-%]", "")
                    -- Strip reset=... clause (for /castsequence)
                    rest = rest:gsub("reset=%S+%s*", "")
                    -- Trim
                    rest = rest:match("^%s*(.-)%s*$")

                    if rest and rest ~= "" then
                        if matchedCmd == "castsequence" or matchedCmd == "castrandom" then
                            -- Extract ALL spells in comma-separated list
                            for token in rest:gmatch("[^,]+") do
                                local spell = CleanSpellToken(token)
                                if spell then
                                    results[#results + 1] = { name = spell, command = matchedCmd }
                                end
                            end
                        else
                            -- /cast, /use: split on semicolons (conditional fallthrough branches).
                            -- The comma is part of the spell name here (e.g. "Invoke Niuzao, the
                            -- Black Ox"), so do NOT split the branch on commas.
                            for branch in rest:gmatch("[^;]+") do
                                local spell = CleanSpellToken(branch)
                                if spell then
                                    -- BUG-052: /use <number> is inventory slot, not spell
                                    if matchedCmd == "use" then
                                        local num = tonumber(spell)
                                        if num and tostring(num) == spell then
                                            spell = nil
                                        end
                                    end
                                    if spell then
                                        results[#results + 1] = { name = spell, command = matchedCmd }
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end

    return results
end

---------------------------------------------------------------------------
-- Single Spell Validation
---------------------------------------------------------------------------

--- Return true if the player has this spell in their kit, including a spell
--- granted as an override by an aura, talent, form, or proc. Modern
--- replacement for the deprecated IsSpellKnownOrOverridesKnown
--- (C_SpellBook.IsSpellInSpellBook with includeOverrides = true). Checks the
--- player bank, then the pet bank.
--- @param spellID number Resolved numeric spell ID
--- @return boolean hasIt
function SV:_PlayerHasSpell(spellID)
    if type(spellID) ~= "number" then
        return false
    end
    if not (C_SpellBook and C_SpellBook.IsSpellInSpellBook and Enum and Enum.SpellBookSpellBank) then
        return false
    end
    local okPlayer, inPlayer = pcall(C_SpellBook.IsSpellInSpellBook, spellID, Enum.SpellBookSpellBank.Player, true)
    if okPlayer and inPlayer then
        return true
    end
    local okPet, inPet = pcall(C_SpellBook.IsSpellInSpellBook, spellID, Enum.SpellBookSpellBank.Pet, true)
    return (okPet and inPet) and true or false
end

--- Validate a single spell or item reference.
--- @param spellName string The spell/item name to validate
--- @param command string The macro command that referenced it (cast, use, etc.)
--- @return table { name=string, status=string, icon=number|nil }
function SV:ValidateSpell(spellName, command)
    local result = { name = spellName, status = D().SPELL_STATUS_UNKNOWN, icon = nil }

    -- Macro placeholders (e.g. "null" in /castsequence) are always valid
    if MACRO_PLACEHOLDERS[strlower(spellName)] then
        result.status = D().SPELL_STATUS_VALID
        return result
    end

    -- Fast path: in spellbook cache
    if SC().byName[strlower(spellName)] then
        result.status = D().SPELL_STATUS_VALID
        result.icon = SC():GetIcon(spellName)
        return result
    end

    -- Numeric spell ID: resolve to localized name
    local numericID = tonumber(spellName)
    local resolvedName
    if numericID then
        resolvedName = C_Spell.GetSpellName(numericID)
        if resolvedName then
            result.name = resolvedName
            if SC().byName[strlower(resolvedName)] then
                result.status = D().SPELL_STATUS_VALID
                result.icon = SC():GetIcon(resolvedName)
                return result
            end
        end
    end

    -- Override / form / proc-replacement spells (Voidform's Void Bolt,
    -- shapeshift-form abilities, evolve spells, proc-replacements) are not in
    -- the live spellbook snapshot (SC.byName) but ARE in the player's kit.
    -- Resolve the name to an ID and ask the spellbook with includeOverrides.
    local kitID = numericID or SC():GetSpellID(spellName)
    if kitID and self:_PlayerHasSpell(kitID) then
        result.status = D().SPELL_STATUS_CONTEXTUAL
        result.icon = (C_Spell.GetSpellTexture and C_Spell.GetSpellTexture(kitID))
            or SC():GetIcon(spellName)
            or D().QUESTION_MARK_ICON
        return result
    end

    -- API check: spell exists but not in spellbook (talent-gated, wrong spec)
    local exists = C_Spell.DoesSpellExist(spellName)
    if exists and not issecretvalue(exists) then
        result.status = D().SPELL_STATUS_KNOWN
        result.icon = SC():GetIcon(spellName)
        return result
    end

    -- /use can target items
    if command == "use" then
        local itemID, _, _, _, itemIcon = C_Item.GetItemInfoInstant(spellName)
        if itemID then
            result.status = D().SPELL_STATUS_ITEM
            result.icon = itemIcon or D().QUESTION_MARK_ICON
            return result
        end
        -- Some abilities use /use syntax -- already checked via DoesSpellExist above
    end

    -- Unknown: not a spell, not an item
    result.icon = D().QUESTION_MARK_ICON
    return result
end

---------------------------------------------------------------------------
-- Step Validation
---------------------------------------------------------------------------

--- Validate all spells in a single macro step.
--- @param macrotext string The step macro text
--- @return table { spells=array, hasVariable=bool }
function SV:ValidateStep(macrotext)
    local result = { spells = {}, tooltipSpells = {}, hasVariable = false }
    if type(macrotext) ~= "string" or macrotext == "" then
        return result
    end

    -- Check for variable references
    if macrotext:match(D().VAR_PATTERN) then
        result.hasVariable = true
        result.spells[#result.spells + 1] = {
            name = "(variable)",
            status = D().SPELL_STATUS_VARIABLE,
            icon = nil,
        }
    end

    local extracted = self:ExtractAllSpells(macrotext)
    for _, entry in ipairs(extracted) do
        local validated = self:ValidateSpell(entry.name, entry.command)
        if entry.command == "showtooltip" then
            if validated.status == D().SPELL_STATUS_UNKNOWN or validated.status == D().SPELL_STATUS_KNOWN then
                validated.status = D().SPELL_STATUS_TOOLTIP_STALE
            end
            result.tooltipSpells[#result.tooltipSpells + 1] = validated
        else
            result.spells[#result.spells + 1] = validated
        end
    end

    return result
end

---------------------------------------------------------------------------
-- Sequence Validation
---------------------------------------------------------------------------

local function AccumulateCounts(stepResult, result)
    for _, spell in ipairs(stepResult.spells) do
        if spell.status == D().SPELL_STATUS_UNKNOWN then
            result.unknownCount = result.unknownCount + 1
        elseif spell.status == D().SPELL_STATUS_KNOWN then
            result.knownCount = result.knownCount + 1
        elseif spell.status == D().SPELL_STATUS_CONTEXTUAL then
            result.contextualCount = result.contextualCount + 1
        end
    end
    for _, spell in ipairs(stepResult.tooltipSpells) do
        if spell.status == D().SPELL_STATUS_TOOLTIP_STALE then
            result.tooltipStaleCount = result.tooltipStaleCount + 1
        end
    end
end

--- Validate an entire sequence (active version).
--- @param seqData table Sequence data (versioned format)
--- @return table { steps=array, staleCount=number, unknownCount=number, knownCount=number, contextualCount=number, tooltipStaleCount=number }
function SV:ValidateSequence(seqData)
    local result = {
        steps = {},
        staleCount = 0,
        unknownCount = 0,
        knownCount = 0,
        contextualCount = 0,
        tooltipStaleCount = 0,
    }

    local ver = Engine():GetActiveVersion(seqData)
    if not ver then
        GRIPEMS:Debug("SpellValidator: no active version for sequence -- skipping validation")
        return result
    end

    -- Validate main steps
    local steps = ver.steps or {}
    local spellCache = GRIPEMS.SpellCache
    for i = 1, #steps do
        local stepText = (spellCache and spellCache.StepToString) and spellCache:StepToString(steps[i])
            or (type(steps[i]) == "string" and steps[i] or "")
        local resolved = Engine():SubstituteVariables(stepText)
        local stepResult = self:ValidateStep(resolved)
        result.steps[#result.steps + 1] = stepResult
        AccumulateCounts(stepResult, result)
    end

    -- Validate keyPress if present
    local kp = ver.keyPress
    if type(kp) == "string" and kp ~= "" then
        local resolved = Engine():SubstituteVariables(kp)
        local stepResult = self:ValidateStep(resolved)
        AccumulateCounts(stepResult, result)
    end

    -- Validate keyRelease if present
    local kr = ver.keyRelease
    if type(kr) == "string" and kr ~= "" then
        local resolved = Engine():SubstituteVariables(kr)
        local stepResult = self:ValidateStep(resolved)
        AccumulateCounts(stepResult, result)
    end

    -- KNOWN spells exist (DoesSpellExist == true) but are not in the active
    -- spellbook -- typically talent-gated or wrong-spec abilities the player
    -- still has access to via macros. Counting them as stale fires the warning
    -- banner over legitimate sequences; keep knownCount populated for the
    -- tooltip detail but only treat UNKNOWN entries as stale.
    result.staleCount = result.unknownCount
    return result
end

---------------------------------------------------------------------------
-- Node Recursive Validation
---------------------------------------------------------------------------

--- Walk a node's descendants and classify worst-case spell validity.
--- ACTION nodes evaluate node.macro via ValidateStep. Loop/Embed structural
--- nodes recurse into .children (flat array). If nodes have
--- children = { trueBranchArray, falseBranchArray } where each branch is
--- itself a flat array of nodes; both branches are walked.
--- @param node table An action tree node
--- @param visited table|nil Recursion guard for EMBED cycle detection
--- @param collectAll boolean|nil If true, walk the entire subtree and collect every
---        invalid spell; if false/nil, short-circuit on the first UNKNOWN (badge path).
--- @return string|nil "error" on any unknown spell, "warn" on any known-not-in-spellbook, nil otherwise
--- @return table invalids List of { name, status } entries. Complete only when collectAll is true;
---         otherwise truncated at the first UNKNOWN.
function SV:NodeHasInvalidSpells(node, visited, collectAll)
    if not node or type(node) ~= "table" then
        return nil
    end
    local defs = GRIPEMS.Defaults
    local cache = GRIPEMS.SpellCache
    if not defs or not cache then
        return nil
    end
    visited = visited or {}

    local worst, invalids = nil, {}
    local seen = {}
    local function addInvalid(spellName, status)
        local k = status .. ":" .. spellName
        if not seen[k] then
            seen[k] = true
            invalids[#invalids + 1] = { name = spellName, status = status }
        end
    end

    local function walk(n)
        if not collectAll and worst == "error" then
            return
        end
        if not n or type(n) ~= "table" then
            return
        end
        if n.type == defs.ACTION_TYPE_ACTION then
            local macro = n.macro or ""
            if macro ~= "" then
                local resolved = macro
                local eng = GRIPEMS.Engine
                if eng and eng.SubstituteVariables then
                    local ok, out = pcall(eng.SubstituteVariables, eng, macro)
                    if ok and type(out) == "string" then
                        resolved = out
                    end
                end
                local stepResult = SV:ValidateStep(resolved)
                for _, spell in ipairs(stepResult.spells) do
                    if spell.status == defs.SPELL_STATUS_UNKNOWN then
                        addInvalid(spell.name, spell.status)
                        worst = "error"
                        if not collectAll then
                            return
                        end
                    elseif spell.status == defs.SPELL_STATUS_KNOWN then
                        addInvalid(spell.name, spell.status)
                        worst = worst or "warn"
                    end
                end
            end
            return
        end

        if n.type == defs.ACTION_TYPE_EMBED then
            local seqName = n.sequence
            if not seqName or seqName == "" then
                return
            end
            if visited[seqName] then
                return
            end
            if (visited._depth or 0) >= 10 then
                return
            end
            visited[seqName] = true
            visited._depth = (visited._depth or 0) + 1
            local eng = GRIPEMS.Engine
            local entry = eng and eng.sequences and eng.sequences[seqName]
            if entry and entry.data and eng.GetActiveVersion then
                local ver = eng:GetActiveVersion(entry.data)
                if ver and ver.actions then
                    for _, child in ipairs(ver.actions) do
                        walk(child)
                        if not collectAll and worst == "error" then
                            visited._depth = visited._depth - 1
                            return
                        end
                    end
                elseif ver and ver.steps then
                    -- fallback: synthesize ACTION nodes for each flat step
                    for _, macroText in ipairs(ver.steps) do
                        walk({ type = defs.ACTION_TYPE_ACTION, macro = macroText })
                        if not collectAll and worst == "error" then
                            visited._depth = visited._depth - 1
                            return
                        end
                    end
                end
            end
            visited._depth = visited._depth - 1
            return
        end

        if n.children and type(n.children) == "table" then
            if n.type == defs.ACTION_TYPE_IF then
                -- If node: children = { trueBranchArray, falseBranchArray }
                -- Each branch is itself a flat array of nodes.
                local trueBranch = n.children[1]
                if type(trueBranch) == "table" then
                    for _, child in ipairs(trueBranch) do
                        walk(child)
                        if not collectAll and worst == "error" then
                            return
                        end
                    end
                end
                local falseBranch = n.children[2]
                if type(falseBranch) == "table" then
                    for _, child in ipairs(falseBranch) do
                        walk(child)
                        if not collectAll and worst == "error" then
                            return
                        end
                    end
                end
            else
                -- Loop, Embed, or any other structural node: children is a
                -- flat array of nodes.
                for _, child in ipairs(n.children) do
                    walk(child)
                    if not collectAll and worst == "error" then
                        return
                    end
                end
            end
        end
    end

    walk(node)
    return worst, invalids
end

---------------------------------------------------------------------------
-- Batch Validation
---------------------------------------------------------------------------

--- Validate every sequence in Engine().sequences.
--- @return table { sequences = { [name] = ValidateSequence result } }
function SV:ValidateAll()
    local result = { sequences = {} }
    for name, entry in pairs(Engine().sequences) do
        if entry.data then
            result.sequences[name] = self:ValidateSequence(entry.data)
        end
    end
    return result
end

---------------------------------------------------------------------------
-- Event-Driven Revalidation
---------------------------------------------------------------------------

local revalTimer = nil
local regenFrame = nil

local function FireValidationPing()
    if GRIPEMS.Fire then
        GRIPEMS:Fire("SPELL_VALIDATION_UPDATED")
    end
end

--- Debounced handler for spell cache refresh.
--- Waits SPELL_VALIDATE_DEBOUNCE seconds, then fires SPELL_VALIDATION_UPDATED
--- so visible UI panels recompute their own validation state. Does not run a
--- batch validation: no consumer reads the result, and a full pass ran inside
--- the combat execution budget on large collections. If the debounce lands in
--- combat, the ping parks until PLAYER_REGEN_ENABLED.
function SV:OnSpellCacheRefreshed()
    if revalTimer then
        revalTimer:Cancel()
        revalTimer = nil
    end
    if C_Timer and C_Timer.NewTimer then
        revalTimer = C_Timer.NewTimer(D().SPELL_VALIDATE_DEBOUNCE, function()
            revalTimer = nil
            if InCombatLockdown() then
                if not regenFrame then
                    regenFrame = CreateFrame("Frame")
                    regenFrame:SetScript("OnEvent", function(frame)
                        frame:UnregisterEvent("PLAYER_REGEN_ENABLED")
                        FireValidationPing()
                    end)
                end
                regenFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
            else
                FireValidationPing()
            end
        end)
    end
end

--- Register for SPELL_CACHE_REFRESHED callback.
--- Must be called AFTER Core.lua ADDON_LOADED creates the CallbackHandler.
function SV:RegisterCallbacks()
    if GRIPEMS.RegisterCallback then
        GRIPEMS.RegisterCallback(SV, "SPELL_CACHE_REFRESHED", "OnSpellCacheRefreshed")
    end
end
