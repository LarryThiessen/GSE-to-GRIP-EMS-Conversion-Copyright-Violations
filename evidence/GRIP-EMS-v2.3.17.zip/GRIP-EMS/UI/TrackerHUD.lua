-- GRIP-EMS: Tracker HUD
-- Movable overlay showing active sequence icons with step advancement feedback
--
-- Created: 2026-03-31 (estimated, pre-stamping)
-- Updated: 2026-07-27
-- Patch: 12.0.7.68275 Midnight (Retail LIVE)
-- WCAG 2.3.1 audit (2026-04-19): 1 animation site in this file
-- (animGroup in step-advance highlight). fadeIn + fadeOut Alpha
-- pair, under 3 Hz, overlay region well under 25 percent of
-- viewport. Compliant without rate cap. reduceMotion guard at
-- the Play site.

local ADDON_NAME, GRIPEMS = ...

GRIPEMS.TrackerHUD = {}
local TH = GRIPEMS.TrackerHUD
local UI = GRIPEMS.UI
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)
local D = GRIPEMS.Defaults

-- Upvalue accessors (modules load before UI/)
local function S()
    return GRIPEMS.Settings
end
local function Engine()
    return GRIPEMS.Engine
end
local function SC()
    return GRIPEMS.SpellCache
end

---------------------------------------------------------------------------
-- Constants
---------------------------------------------------------------------------
local QUESTION_MARK_ICON = 134400 -- Interface\Icons\INV_Misc_QuestionMark
local ICON_PADDING = 4
local NAME_HEIGHT = 12
local STEP_FONT_SIZE = 10
local NAME_FONT_SIZE = 9
local FRAME_PADDING = 6
local DEFAULT_POS = { "BOTTOMRIGHT", nil, "BOTTOMRIGHT", -200, 200 }

---------------------------------------------------------------------------
-- Restriction state label
---------------------------------------------------------------------------
local function GetRestrictionLabel()
    local r = GRIPEMS.restrictions
    if not r then
        return nil
    end
    if r[2] == 2 then
        return "M+"
    end
    if r[1] == 2 then
        return "Encounter"
    end
    if r[3] == 2 then
        return "PvP"
    end
    return nil
end

---------------------------------------------------------------------------
-- Variant label resolver (IC-VAR-08-polish)
-- Resolves the four GEMS_VARIANT_INDICATOR_LABEL_* locale keys via AceLocale
-- with a defensive fallback to D.VARIANT_LABEL_SHORT when the key is missing.
-- Declared above CreateIconEntry so the local upvalue is bound before any
-- CreateIconEntry call captures it.
---------------------------------------------------------------------------
local function GetVariantLabelText(modifier)
    local key
    if modifier == "shift" then
        key = "GEMS_VARIANT_INDICATOR_LABEL_SHIFT"
    elseif modifier == "ctrl" then
        key = "GEMS_VARIANT_INDICATOR_LABEL_CTRL"
    elseif modifier == "alt" then
        key = "GEMS_VARIANT_INDICATOR_LABEL_ALT"
    else
        key = "GEMS_VARIANT_INDICATOR_LABEL_PLAIN"
    end
    local resolved = L[key]
    if resolved and resolved ~= key then
        return resolved
    end
    return D.VARIANT_LABEL_SHORT[modifier or "plain"]
end

---------------------------------------------------------------------------
-- Visibility evaluator
---------------------------------------------------------------------------
local function ShouldBeVisible()
    local mode = S():Get("trackerShowMode") or "NEVER"
    if mode == "ALWAYS" then
        return true
    end
    if mode == "NEVER" then
        return false
    end
    if mode == "COMBAT" then
        return InCombatLockdown()
    end
    if mode == "TARGET" then
        return UnitExists("target")
    end
    return false
end

---------------------------------------------------------------------------
-- Frame creation (lazy, called once from Init)
---------------------------------------------------------------------------
local function CreateHUDFrame()
    local C = UI.Colors

    local frame = UI:ReclaimFrame("GRIPEMS_TrackerHUD", "Frame", UIParent, "BackdropTemplate")
    frame:SetSize(60, 60)
    frame:SetFrameStrata("MEDIUM")
    frame:SetFrameLevel(100)
    frame:SetBackdrop(UI.Backdrops.panel)
    frame:SetBackdropColor(0.12, 0.12, 0.14, 0.85)
    frame:SetBackdropBorderColor(0.3, 0.3, 0.35, 1)
    if GRIPEMS.UI and GRIPEMS.UI.RegisterPanelFrame then
        GRIPEMS.UI:RegisterPanelFrame(frame, "overlay", "overlay.hud")
    end
    frame:SetClampedToScreen(true)
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", function(self)
        if not S():Get("trackerLocked") then
            self:StartMoving()
        end
    end)
    frame:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        TH:SavePosition()
    end)
    frame:Hide()

    -- Modifier key overlay text (top-left corner)
    local modText = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(modText, 9, "OUTLINE")
    modText:SetPoint("BOTTOMLEFT", frame, "TOPLEFT", 4, 12)
    modText:SetTextColor(C.keybindGold:GetRGBA())
    modText:SetText("")
    frame.modText = modText

    -- Restriction state overlay text (top-right corner)
    local restrictText = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(restrictText, 9, "OUTLINE")
    restrictText:SetPoint("BOTTOMRIGHT", frame, "TOPRIGHT", -4, 12)
    restrictText:SetTextColor(0.95, 0.65, 0.15, 1) -- amber/orange
    restrictText:SetText("")
    restrictText:Hide()
    frame.restrictText = restrictText

    return frame
end

---------------------------------------------------------------------------
-- Position save / restore
---------------------------------------------------------------------------
function TH:SavePosition()
    if not TH.frame then
        return
    end
    local point, _, relPoint, x, y = TH.frame:GetPoint(1)
    if not _G.GRIP_EMS_CHAR then
        return
    end
    GRIP_EMS_CHAR.trackerPos = { point, "UIParent", relPoint, x, y }
end

function TH:RestorePosition()
    if not TH.frame then
        return
    end
    local pos = _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.trackerPos
    if pos and pos[1] then
        TH.frame:ClearAllPoints()
        TH.frame:SetPoint(pos[1], UIParent, pos[3], pos[4], pos[5])
    else
        TH.frame:ClearAllPoints()
        TH.frame:SetPoint(DEFAULT_POS[1], UIParent, DEFAULT_POS[3], DEFAULT_POS[4], DEFAULT_POS[5])
    end
end

---------------------------------------------------------------------------
-- Icon entry creation
---------------------------------------------------------------------------
local function CreateIconEntry(parent, index)
    local C = UI.Colors
    local iconSize = S():Get("trackerIconSize") or 40

    local iconFrame = CreateFrame("Frame", nil, parent, "BackdropTemplate")
    iconFrame:SetSize(iconSize, iconSize)
    iconFrame:SetBackdrop(UI.Backdrops.panel)
    iconFrame:SetBackdropColor(0.08, 0.08, 0.10, 0.9)
    iconFrame:SetBackdropBorderColor(0.3, 0.3, 0.35, 1)

    -- Spell icon texture
    local tex = iconFrame:CreateTexture(nil, "ARTWORK")
    tex:SetPoint("TOPLEFT", 1, -1)
    tex:SetPoint("BOTTOMRIGHT", -1, 1)
    tex:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    tex:SetTexture(QUESTION_MARK_ICON)

    -- Step counter (bottom-right corner overlay)
    local stepText = iconFrame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(stepText, STEP_FONT_SIZE, "OUTLINE")
    stepText:SetPoint("BOTTOMRIGHT", iconFrame, "BOTTOMRIGHT", -2, 2)
    stepText:SetTextColor(C.textPrimary:GetRGBA())
    stepText:SetText("")

    -- Read-only LIVE version badge (top-left corner overlay). Shows which
    -- version the keybind fires; populated by TH:Rebuild only when the
    -- sequence has more than one version. Display-only -- reads the existing
    -- Engine:GetActiveVersionIndex accessor, no engine or secure-path change.
    local versionBadge = iconFrame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(versionBadge, STEP_FONT_SIZE, "OUTLINE")
    versionBadge:SetPoint("TOPLEFT", iconFrame, "TOPLEFT", 2, -2)
    versionBadge:SetTextColor(C.textSecondary:GetRGBA())
    versionBadge:SetText("")

    -- Name label (below icon, optional)
    local nameText = iconFrame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(nameText, NAME_FONT_SIZE)
    nameText:SetPoint("TOP", iconFrame, "BOTTOM", 0, -1)
    nameText:SetTextColor(C.textSecondary:GetRGBA())
    nameText:SetText("")
    nameText:SetWordWrap(false)
    nameText:SetMaxLines(1)

    -- IC-VAR-08: per-variant indicator strip (below icon, above nameText).
    -- Up to 4 small frames sized D.VARIANT_INDICATOR_SIZE square, laid out
    -- horizontally with D.VARIANT_INDICATOR_SPACING between slots. Hidden by
    -- default and only shown when the sequence has variantOverrides AND the
    -- trackerVariantIndicators setting is enabled. Slot 1 = base/plain;
    -- slots 2..4 = variantOverrides[1..3].
    local stripFrame = CreateFrame("Frame", nil, iconFrame)
    local stripSize = D.VARIANT_INDICATOR_SIZE
    local stripSpacing = D.VARIANT_INDICATOR_SPACING
    stripFrame:SetSize(stripSize * 4 + stripSpacing * 3, stripSize)
    stripFrame:SetPoint("TOP", iconFrame, "BOTTOM", 0, -1)
    stripFrame:Hide()

    local variantFrames = {}
    for i = 1, 4 do
        local vf = CreateFrame("Frame", nil, stripFrame, "BackdropTemplate")
        vf:SetSize(stripSize, stripSize)
        if i == 1 then
            vf:SetPoint("LEFT", stripFrame, "LEFT", 0, 0)
        else
            vf:SetPoint("LEFT", variantFrames[i - 1].frame, "RIGHT", stripSpacing, 0)
        end
        vf:SetBackdrop(UI.Backdrops.panel)
        vf:SetBackdropColor(0.08, 0.08, 0.10, 0.9)
        vf:SetBackdropBorderColor(0.3, 0.3, 0.35, 1)
        vf:Hide()

        local statusIcon = vf:CreateTexture(nil, "ARTWORK")
        statusIcon:SetPoint("TOPLEFT", 1, -1)
        statusIcon:SetPoint("BOTTOMRIGHT", -1, 1)
        statusIcon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
        statusIcon:SetTexture(QUESTION_MARK_ICON)

        local cooldownRing = CreateFrame("Cooldown", nil, vf, "CooldownFrameTemplate")
        cooldownRing:SetAllPoints(vf)
        if cooldownRing.SetHideCountdownNumbers then
            cooldownRing:SetHideCountdownNumbers(true)
        end
        if cooldownRing.SetReverse then
            cooldownRing:SetReverse(true)
        end
        if cooldownRing.SetDrawEdge then
            cooldownRing:SetDrawEdge(false)
        end
        cooldownRing:SetFrameLevel(vf:GetFrameLevel() + 1)

        local borderPulse = vf:CreateTexture(nil, "OVERLAY")
        borderPulse:SetColorTexture(1, 0.85, 0.25, 1)
        borderPulse:SetPoint("TOPLEFT", vf, "TOPLEFT", 1, -1)
        borderPulse:SetPoint("BOTTOMRIGHT", vf, "BOTTOMRIGHT", -1, 1)
        borderPulse:Hide()

        local label = vf:CreateFontString(nil, "OVERLAY")
        UI:SetFont(label, 8, "OUTLINE")
        label:SetPoint("TOPLEFT", vf, "TOPLEFT", 1, -1)
        label:SetTextColor(1, 0.84, 0, 1)
        label:SetText("")

        -- IC-VAR-08-polish: per-variant tooltip via GEMS_VARIANT_INDICATOR_TOOLTIP.
        -- Slot ordinal is captured per-iteration; modifier and keybind are
        -- resolved at hover time so SavedVariables / binding edits are picked
        -- up without a Rebuild. Modifier resolution is inlined to avoid the
        -- GetSlotModifier upvalue-ordering issue (it is declared further down
        -- in this file).
        local slotOrdinal = i
        vf:SetScript("OnEnter", function(self)
            local entry
            for _, e in ipairs(TH.icons) do
                if e.frame == iconFrame then
                    entry = e
                    break
                end
            end
            if not entry or not entry.seqName then
                return
            end
            local eng = Engine()
            local seqEntry = eng and eng.sequences and eng.sequences[entry.seqName]
            local ver = seqEntry and eng:GetActiveVersion(seqEntry.data)

            local mod
            if slotOrdinal == 1 then
                mod = D.VARIANT_MOD_PLAIN
            else
                local override = ver and ver.variantOverrides and ver.variantOverrides[slotOrdinal - 1]
                mod = (override and override.modifier) or D.VARIANT_MOD_PLAIN
            end

            local sanitized = entry.seqName
            if eng and eng.SanitizeName then
                sanitized = eng:SanitizeName(entry.seqName) or entry.seqName
            end
            local buttonName
            if slotOrdinal == 1 then
                buttonName = D.BUTTON_PREFIX .. sanitized
            else
                buttonName = D.BUTTON_PREFIX .. sanitized .. D.VARIANT_BUTTON_SUFFIX .. slotOrdinal
            end
            local bind
            if _G.GetBindingKey then
                bind = _G.GetBindingKey("CLICK " .. buttonName .. ":LeftButton")
                if not bind or bind == "" then
                    bind = _G.GetBindingKey(buttonName)
                end
            end
            if not bind or bind == "" then
                bind = ""
            end

            GameTooltip:SetOwner(self, "ANCHOR_TOP")
            local fmt = L["GEMS_VARIANT_INDICATOR_TOOLTIP"]
            if fmt then
                GameTooltip:AddLine(string.format(fmt, tostring(slotOrdinal), mod, bind))
            else
                GameTooltip:AddLine(tostring(slotOrdinal) .. " " .. mod .. " " .. bind)
            end
            GameTooltip:Show()
        end)
        vf:SetScript("OnLeave", function()
            GameTooltip:Hide()
        end)

        variantFrames[i] = {
            frame = vf,
            statusIcon = statusIcon,
            cooldownRing = cooldownRing,
            borderPulse = borderPulse,
            label = label,
        }
    end

    -- Highlight animation group (alpha pulse on step advance)
    local highlightTex = iconFrame:CreateTexture(nil, "OVERLAY")
    highlightTex:SetAllPoints(iconFrame)
    highlightTex:SetColorTexture(1, 0.84, 0, 0.3)
    highlightTex:SetAlpha(0)

    local animGroup = highlightTex:CreateAnimationGroup()
    local fadeIn = animGroup:CreateAnimation("Alpha")
    fadeIn:SetFromAlpha(0)
    fadeIn:SetToAlpha(0.5)
    fadeIn:SetDuration(0.15)
    fadeIn:SetOrder(1)
    local fadeOut = animGroup:CreateAnimation("Alpha")
    fadeOut:SetFromAlpha(0.5)
    fadeOut:SetToAlpha(0)
    fadeOut:SetDuration(0.15)
    fadeOut:SetOrder(2)
    animGroup:SetScript("OnFinished", function()
        highlightTex:SetAlpha(0)
    end)

    iconFrame:SetScript("OnEnter", function(self)
        local entry
        for _, e in ipairs(TH.icons) do
            if e.frame == self then
                entry = e
                break
            end
        end
        if entry and entry.seqName then
            GameTooltip:SetOwner(self, "ANCHOR_TOP")
            GameTooltip:AddLine(entry.seqName, 0, 0.8, 0.4)
            GameTooltip:AddLine(entry.stepText:GetText() or "", 0.8, 0.8, 0.8)
            GameTooltip:AddLine(L["GEMS_TRACKER_PREVIEW_HINT"], 0.5, 0.5, 0.5, true)
            GameTooltip:Show()
        end
    end)
    iconFrame:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)

    return {
        frame = iconFrame,
        texture = tex,
        stepText = stepText,
        versionBadge = versionBadge,
        nameText = nameText,
        highlightTex = highlightTex,
        animGroup = animGroup,
        seqName = nil,
        variantStrip = {
            frame = stripFrame,
            frames = variantFrames,
        },
    }
end

-- IC-VAR-08 render-path helpers shared with BarIntegration (Path D5).
-- Duplicated module-locals here because TrackerHUD is in UI/ and cannot
-- reach into the BarIntegration overlay module. Both implementations are
-- kept in sync at the same constants in D.VARIANT_*. The tint helper below
-- uses the secret-value-safe curve-launder pattern (mirrors BarIntegration);
-- the prior in-Lua resource-fraction math threw on Patch 12.0+ because the
-- player health read is always secret-tagged, even out of combat. See
-- Research/Variable_Taint_Solution_2026-05-04.md.
local function TH_ApplyColorCurveTint(textureRef)
    if not textureRef then
        return
    end
    if not (C_CurveUtil and C_CurveUtil.CreateColorCurve and UnitHealthPercent) then
        return
    end
    local low = D.VARIANT_COLOR_CURVE_RGBA_LOW
    local high = D.VARIANT_COLOR_CURVE_RGBA_HIGH
    local okCurve, curve = pcall(C_CurveUtil.CreateColorCurve)
    if not okCurve or not curve or not curve.AddPoint then
        return
    end
    -- Table-form stops REQUIRED: positional components silently build an EMPTY curve (alpha-0 tint; proven in-game 2026-06-10).
    pcall(curve.AddPoint, curve, 0, { r = low[1], g = low[2], b = low[3], a = low[4] })
    pcall(curve.AddPoint, curve, 1, { r = high[1], g = high[2], b = high[3], a = high[4] })
    local okEval, result = pcall(UnitHealthPercent, "player", true, curve)
    if not okEval or not result or not result.GetRGBA then
        return
    end
    local okRGBA, r, g, b, a = pcall(result.GetRGBA, result)
    if not okRGBA or not r then
        return
    end
    textureRef:SetVertexColor(r, g, b, a or 1)
end

local function TH_ApplyCooldownRing(cooldownRef, spellID)
    if not cooldownRef or not spellID then
        return
    end
    if not (C_Spell and C_Spell.GetSpellCooldown) then
        return
    end
    local ok, info = pcall(C_Spell.GetSpellCooldown, spellID)
    if not ok or type(info) ~= "table" then
        return
    end
    local startTime = info.startTime
    local duration = info.duration
    if not startTime or not duration then
        return
    end
    pcall(cooldownRef.SetCooldown, cooldownRef, startTime, duration)
end

local function PulseBorder(textureRef, periodSec, minA, maxA)
    if not textureRef then
        return
    end
    local parent = textureRef:GetParent()
    if not parent then
        return
    end
    parent._pulsePhase = parent._pulsePhase or 0
    parent._pulseEnabled = true
    parent:SetScript("OnUpdate", function(self, elapsed)
        if not self._pulseEnabled then
            textureRef:SetAlpha(maxA)
            -- IC-VAR-08-polish: detach the OnUpdate once we have both stopped
            -- pulsing and gone offscreen, so the no-op handler does not keep
            -- firing every frame for the entire session lifetime.
            if not self:IsShown() then
                self:SetScript("OnUpdate", nil)
            end
            return
        end
        self._pulsePhase = (self._pulsePhase or 0) + (elapsed or 0)
        local p = periodSec > 0 and periodSec or 1
        local theta = (self._pulsePhase / p) * math.pi * 2
        local sinNorm = (math.sin(theta) + 1) * 0.5
        local alpha = minA + (maxA - minA) * sinNorm
        textureRef:SetAlpha(alpha)
    end)
end

---------------------------------------------------------------------------
-- Icon management
---------------------------------------------------------------------------
TH.icons = {}
TH.activeSeqName = nil

function TH:Rebuild()
    if not TH.frame then
        return
    end

    local eng = Engine()
    if not eng or not eng.sequences then
        TH.frame:Hide()
        return
    end

    -- Collect only sequences with an active keybind, sorted for stable ordering
    local KM = GRIPEMS.KeybindManager
    local sorted = {}
    for name, entry in pairs(eng.sequences) do
        if KM and KM:GetKeybind(name) and not (entry.data and entry.data.disabled) then
            sorted[#sorted + 1] = name
        end
    end
    table.sort(sorted)

    -- Skip rebuild if sequence list unchanged
    if TH._lastSorted then
        local same = (#sorted == #TH._lastSorted)
        if same then
            for i = 1, #sorted do
                if sorted[i] ~= TH._lastSorted[i] then
                    same = false
                    break
                end
            end
        end
        if same then
            -- Still update step counters and icons without full rebuild
            for _, entry in ipairs(TH.icons) do
                if entry.seqName and entry.frame:IsShown() then
                    local seqEntry = eng.sequences[entry.seqName]
                    if seqEntry then
                        local ver = eng:GetActiveVersion(seqEntry.data)
                        local hudBtn = seqEntry.button
                        TH:UpdateIcon(
                            entry.seqName,
                            tonumber(hudBtn and hudBtn:GetAttribute("step")) or 1,
                            eng:GetExecStepCount(hudBtn, ver)
                        )
                    end
                end
            end
            TH:UpdateVisibility()
            return
        end
    end
    TH._lastSorted = sorted

    -- Hide all existing icons
    for _, entry in ipairs(TH.icons) do
        entry.frame:Hide()
        entry.seqName = nil
    end

    local iconSize = S():Get("trackerIconSize") or 40
    local showName = S():Get("trackerShowName")
    local orientation = S():Get("trackerOrientation") or "HORIZONTAL"

    GRIPEMS:Debug(string.format("TrackerHUD: Rebuild (%d bound sequences)", #sorted))

    if #sorted == 0 then
        TH.frame:Hide()
        return
    end

    -- Create or reuse icon entries
    for i, seqName in ipairs(sorted) do
        local entry = TH.icons[i]
        if not entry then
            entry = CreateIconEntry(TH.frame, i)
            TH.icons[i] = entry
        end

        entry.seqName = seqName
        entry.frame:SetSize(iconSize, iconSize)
        entry.frame:Show()

        -- Name label
        if showName then
            local displayName = seqName
            if #displayName > 8 then
                displayName = displayName:sub(1, 6) .. ".."
            end
            entry.nameText:SetText(displayName)
            entry.nameText:SetWidth(iconSize + 4)
            entry.nameText:Show()
        else
            entry.nameText:Hide()
        end

        -- Resolve sequence icon and step info
        local seqEntry = eng.sequences[seqName]
        local seqData = seqEntry and seqEntry.data
        local btn = seqEntry and seqEntry.button

        -- Dynamic icon: resolve current step's spell via SpellCache
        local iconID = nil
        local sc = SC()
        if btn then
            local curStep = tonumber(btn:GetAttribute("step")) or 1
            local ver = eng:GetActiveVersion(seqData)
            local stepText = eng:GetExecStepText(btn, curStep, ver)
            if stepText and sc then
                local spellName = sc:ParseSpellFromMacrotext(stepText)
                if spellName then
                    iconID = sc:GetIcon(spellName)
                end
            end
        end
        -- Fallback: sequence icon, then question mark
        if not iconID then
            iconID = seqData and seqData.icon
        end
        if type(iconID) == "string" then
            iconID = tonumber(iconID) or QUESTION_MARK_ICON
        end
        if not iconID or iconID == "" or iconID == "INV_Misc_QuestionMark" then
            iconID = QUESTION_MARK_ICON
        end
        entry.texture:SetTexture(iconID)

        -- Step counter. Both numbers must live in the SAME domain: "step" is an index
        -- into the expanded execution array, so the denominator must be the expanded
        -- count, not #ver.steps (which rendered "7/4" for a 4-step Priority sequence).
        local step = 1
        if btn then
            step = tonumber(btn:GetAttribute("step")) or 1
        end
        local ver = eng:GetActiveVersion(seqData)
        local numSteps = eng:GetExecStepCount(btn, ver)
        entry.stepText:SetText(step .. "/" .. numSteps)

        -- Read-only LIVE version badge: which version the keybind fires now,
        -- via the existing accessor. Only shown when the sequence has more
        -- than one version (single-version entries leave the corner clear).
        if entry.versionBadge then
            -- type(), not truthiness. This has no gate above it at all, and the
            -- parenthesised spelling is why the pass-15c sweep never surfaced
            -- it: the closing paren sits between the field name and the length
            -- operator, so the two-operator pattern missed the line entirely. A
            -- scalar .versions passes the truthiness test and then raises
            -- "attempt to get length of field 'versions'".
            local versionCount = (type(seqData) == "table" and type(seqData.versions) == "table" and #seqData.versions)
                or 0
            local liveIdx = (versionCount > 1) and eng:GetActiveVersionIndex(seqData, ver) or nil
            if liveIdx then
                entry.versionBadge:SetText("V" .. liveIdx)
                entry.versionBadge:Show()
            else
                entry.versionBadge:SetText("")
                entry.versionBadge:Hide()
            end
        end

        -- Layout position
        entry.frame:ClearAllPoints()
        if i == 1 then
            entry.frame:SetPoint("TOPLEFT", TH.frame, "TOPLEFT", FRAME_PADDING, -FRAME_PADDING)
        else
            local prev = TH.icons[i - 1].frame
            if orientation == "VERTICAL" then
                local offset = showName and (NAME_HEIGHT + ICON_PADDING) or ICON_PADDING
                entry.frame:SetPoint("TOPLEFT", prev, "BOTTOMLEFT", 0, -offset)
            else
                entry.frame:SetPoint("TOPLEFT", prev, "TOPRIGHT", ICON_PADDING, 0)
            end
        end

        -- IC-VAR-08: per-variant indicator strip refresh.
        TH:UpdateVariantIndicators(seqName)
    end

    -- Resize parent frame to fit all icons
    local count = #sorted
    local nameExtra = showName and (NAME_HEIGHT + 2) or 0
    local totalW, totalH

    if orientation == "VERTICAL" then
        totalW = iconSize + (FRAME_PADDING * 2)
        totalH = (count * iconSize) + ((count - 1) * (ICON_PADDING + nameExtra)) + (FRAME_PADDING * 2) + nameExtra
    else
        totalW = (count * iconSize) + ((count - 1) * ICON_PADDING) + (FRAME_PADDING * 2)
        totalH = iconSize + (FRAME_PADDING * 2) + nameExtra
    end

    TH.frame:SetSize(math.max(totalW, 30), math.max(totalH, 30))

    -- Restore active highlight
    if TH.activeSeqName then
        for _, entry in ipairs(TH.icons) do
            if entry.seqName == TH.activeSeqName then
                entry.frame:SetBackdropBorderColor(1, 0.84, 0, 1)
                break
            end
        end
    end

    -- Apply scale
    local scale = S():Get("trackerScale") or 1.0
    TH.frame:SetScale(scale)

    TH:UpdateRestrictionLabel()
    TH:UpdateVisibility()
end

function TH:UpdateIcon(seqName, step, numSteps)
    for _, entry in ipairs(TH.icons) do
        if entry.seqName == seqName then
            entry.stepText:SetText(step .. "/" .. numSteps)

            -- Keep the read-only LIVE version badge fresh here too. TH:Rebuild's
            -- "sequence list unchanged" fast path and step advances route through
            -- UpdateIcon without re-running the full-rebuild badge block, so an
            -- in-place context switch (active version changes, bound names do not)
            -- would otherwise leave the corner showing a stale index. Only shown
            -- when the sequence has more than one version. Display-only.
            if entry.versionBadge then
                local liveEng = Engine()
                local liveEntry = liveEng and liveEng.sequences and liveEng.sequences[seqName]
                local liveData = liveEntry and liveEntry.data
                -- type(), not truthiness -- the live-data sibling of the badge
                -- block in the full rebuild above. Same parenthesised spelling,
                -- same scalar raise on the length operator.
                local versionCount = (
                    type(liveData) == "table"
                    and type(liveData.versions) == "table"
                    and #liveData.versions
                ) or 0
                local liveIdx = (versionCount > 1) and liveEng:GetActiveVersionIndex(liveData) or nil
                if liveIdx then
                    entry.versionBadge:SetText("V" .. liveIdx)
                    entry.versionBadge:Show()
                else
                    entry.versionBadge:SetText("")
                    entry.versionBadge:Hide()
                end
            end

            -- Dynamic icon: resolve current step's spell via SpellCache
            local iconID = nil
            local eng = Engine()
            local sc = SC()
            if eng and sc and eng.sequences[seqName] then
                local seqEntry = eng.sequences[seqName]
                local btn = seqEntry.button
                if btn then
                    local ver = eng:GetActiveVersion(seqEntry.data)
                    local stepText = eng:GetExecStepText(btn, step, ver)
                    if stepText then
                        local spellName = sc:ParseSpellFromMacrotext(stepText)
                        if spellName then
                            iconID = sc:GetIcon(spellName)
                        end
                    end
                end
                -- Fallback: sequence icon, then question mark
                if not iconID then
                    iconID = seqEntry.data and seqEntry.data.icon
                end
                if type(iconID) == "string" then
                    iconID = tonumber(iconID) or QUESTION_MARK_ICON
                end
                if not iconID or iconID == "" or iconID == "INV_Misc_QuestionMark" then
                    iconID = QUESTION_MARK_ICON
                end
                entry.texture:SetTexture(iconID)
            end

            -- Flash highlight
            entry.animGroup:Stop()
            entry.highlightTex:SetAlpha(0)
            local a = GRIPEMS.Settings.db.profile.accessibility
            -- flickerSafe and reduceMotion both intentionally lose the
            -- highlight pulse; flickerSafe shows a muted sustained
            -- 0.3 alpha for ALERT_FLASH_DURATION-equivalent before
            -- clearing, reduceMotion shows nothing (existing behavior).
            if a.flickerSafe then
                entry.highlightTex:SetAlpha(0.3)
                if C_Timer and C_Timer.After then
                    C_Timer.After(0.30, function()
                        if entry and entry.highlightTex then
                            entry.highlightTex:SetAlpha(0)
                        end
                    end)
                end
            elseif not a.reduceMotion then
                entry.animGroup:Play()
            end
            -- reduceMotion-only path: skip animation entirely (existing,
            -- highlight stays at neutral)

            -- Persistent gold border on active sequence
            if TH.activeSeqName and TH.activeSeqName ~= seqName then
                for _, other in ipairs(TH.icons) do
                    if other.seqName == TH.activeSeqName then
                        other.frame:SetBackdropBorderColor(0.3, 0.3, 0.35, 1)
                        break
                    end
                end
            end
            TH.activeSeqName = seqName
            entry.frame:SetBackdropBorderColor(1, 0.84, 0, 1)
            return
        end
    end
end

---------------------------------------------------------------------------
-- Restriction label management
---------------------------------------------------------------------------
function TH:UpdateRestrictionLabel()
    if not TH.frame or not TH.frame.restrictText then
        return
    end
    local label = GetRestrictionLabel()
    if label then
        TH.frame.restrictText:SetText(label)
        TH.frame.restrictText:Show()
    else
        TH.frame.restrictText:SetText("")
        TH.frame.restrictText:Hide()
    end
end

---------------------------------------------------------------------------
-- Visibility management
---------------------------------------------------------------------------
function TH:UpdateVisibility()
    if not TH.frame then
        return
    end
    if ShouldBeVisible() then
        TH.frame:Show()
    else
        TH.frame:Hide()
    end
end

---------------------------------------------------------------------------
-- Modifier key display
---------------------------------------------------------------------------
local function UpdateModifierDisplay()
    if not TH.frame or not TH.frame:IsShown() then
        return
    end
    if not S():Get("trackerShowModifiers") then
        TH.frame.modText:SetText("")
        return
    end

    local parts = {}
    if IsShiftKeyDown() then
        parts[#parts + 1] = "[S]"
    end
    if IsAltKeyDown() then
        parts[#parts + 1] = "[A]"
    end
    if IsControlKeyDown() then
        parts[#parts + 1] = "[C]"
    end

    TH.frame.modText:SetText(table.concat(parts, " "))
end

---------------------------------------------------------------------------
-- Callback handlers
---------------------------------------------------------------------------
function TH:OnStepAdvanced(_, seqName, step, numSteps)
    TH:UpdateIcon(seqName, step, numSteps)
end

function TH:OnSequenceChanged()
    TH:Rebuild()
end

---------------------------------------------------------------------------
-- IC-VAR-08: per-variant indicator strip
---------------------------------------------------------------------------
-- Returns the spellID for the first step of the given variant slot. slotIdx
-- 1 = base steps; 2..4 = variantOverrides[1..3]. Returns nil when the slot
-- is empty or the macrotext does not parse to a known spell.
local function ResolveVariantFirstSpellID(seqName, slotIdx)
    local eng = Engine()
    if not eng or not eng.sequences then
        return nil
    end
    local seqEntry = eng.sequences[seqName]
    if not seqEntry or not seqEntry.data then
        return nil
    end
    local ver = eng:GetActiveVersion(seqEntry.data)
    if not ver then
        return nil
    end
    local steps
    if slotIdx and slotIdx >= 2 then
        local override = ver.variantOverrides and ver.variantOverrides[slotIdx - 1]
        steps = override and override.steps
    else
        steps = ver.steps
    end
    if not steps or #steps == 0 then
        return nil
    end
    local sc = SC()
    if not sc or not sc.ParseSpellFromMacrotext then
        return nil
    end
    local spellName = sc:ParseSpellFromMacrotext(steps[1])
    if not spellName then
        return nil
    end
    if sc.GetSpellID then
        return sc:GetSpellID(spellName, seqEntry.data.classID)
    end
    return nil
end

local function GetSlotModifier(ver, slotIdx)
    if not slotIdx or slotIdx == 1 then
        return D.VARIANT_MOD_PLAIN
    end
    local override = ver and ver.variantOverrides and ver.variantOverrides[slotIdx - 1]
    return override and override.modifier or nil
end

-- Refresh the per-variant indicator strip for one sequence. Hidden when the
-- sequence has no variantOverrides OR the trackerVariantIndicators setting
-- is disabled. Slot 1 always exists (base/plain); slots 2..4 follow the
-- ordered variantOverrides array.
function TH:UpdateVariantIndicators(seqName)
    local entry
    for _, e in ipairs(TH.icons) do
        if e.seqName == seqName then
            entry = e
            break
        end
    end
    if not entry or not entry.variantStrip then
        return
    end
    local strip = entry.variantStrip
    local showStrip = S():Get("trackerVariantIndicators")
    local eng = Engine()
    local seqEntry = eng and eng.sequences and eng.sequences[seqName]
    local ver = seqEntry and eng:GetActiveVersion(seqEntry.data)
    local overrides = ver and ver.variantOverrides
    local disabled = seqEntry and seqEntry.data and seqEntry.data.disabled
    if disabled or not showStrip or not overrides or #overrides == 0 then
        strip.frame:Hide()
        return
    end
    strip.frame:Show()

    local cached
    if GRIPEMS.RecommendationEvaluator and GRIPEMS.RecommendationEvaluator.GetCachedRecommendation then
        cached = GRIPEMS.RecommendationEvaluator:GetCachedRecommendation(seqName)
    end

    local sc = SC()

    local slotCount = math.min(#overrides + 1, 4)
    for i, vf in ipairs(strip.frames) do
        if i <= slotCount then
            local mod = GetSlotModifier(ver, i)
            local labelText = GetVariantLabelText(mod) or tostring(i)
            vf.label:SetText(labelText)

            local iconID = QUESTION_MARK_ICON
            local spellID = ResolveVariantFirstSpellID(seqName, i)
            if spellID and sc and sc.GetIcon then
                local steps
                if i >= 2 then
                    local override = overrides[i - 1]
                    steps = override and override.steps
                else
                    steps = ver.steps
                end
                if steps and steps[1] then
                    local spellName = sc:ParseSpellFromMacrotext(steps[1])
                    if spellName then
                        local resolved = sc:GetIcon(spellName)
                        if resolved then
                            iconID = resolved
                        end
                    end
                end
            end
            if type(iconID) == "string" then
                iconID = tonumber(iconID) or QUESTION_MARK_ICON
            end
            vf.statusIcon:SetTexture(iconID)
            if not InCombatLockdown() then
                TH_ApplyColorCurveTint(vf.statusIcon)
            end

            if spellID then
                TH_ApplyCooldownRing(vf.cooldownRing, spellID)
                vf.cooldownRing:Show()
            else
                vf.cooldownRing:Hide()
            end

            if cached and mod == cached then
                PulseBorder(
                    vf.borderPulse,
                    D.VARIANT_PULSE_PERIOD,
                    D.VARIANT_PULSE_MIN_ALPHA,
                    D.VARIANT_PULSE_MAX_ALPHA
                )
                vf.borderPulse:Show()
                vf.frame:SetAlpha(D.VARIANT_INDICATOR_ARMED_ALPHA)
            else
                vf.frame._pulseEnabled = false
                vf.borderPulse:SetAlpha(D.VARIANT_PULSE_MAX_ALPHA)
                vf.borderPulse:Hide()
                vf.frame:SetAlpha(D.VARIANT_INDICATOR_DIM_ALPHA)
            end
            vf.frame:Show()
        else
            vf.frame:Hide()
        end
    end
end

-- VARIANT_RECOMMENDATION_UPDATED callback. Drives borderPulse + alpha on
-- the matching variant frame in the strip. Mirror of BI:OnRecommendationUpdated.
function TH:OnRecommendationUpdated(_, seqName, _oldMod, newMod)
    local entry
    for _, e in ipairs(TH.icons) do
        if e.seqName == seqName then
            entry = e
            break
        end
    end
    if not entry or not entry.variantStrip or not entry.variantStrip.frame:IsShown() then
        return
    end
    local eng = Engine()
    local seqEntry = eng and eng.sequences and eng.sequences[seqName]
    local ver = seqEntry and eng:GetActiveVersion(seqEntry.data)
    for i, vf in ipairs(entry.variantStrip.frames) do
        if vf.frame:IsShown() then
            local slotMod = GetSlotModifier(ver, i)
            if slotMod and slotMod == newMod then
                PulseBorder(
                    vf.borderPulse,
                    D.VARIANT_PULSE_PERIOD,
                    D.VARIANT_PULSE_MIN_ALPHA,
                    D.VARIANT_PULSE_MAX_ALPHA
                )
                vf.borderPulse:Show()
                vf.frame:SetAlpha(D.VARIANT_INDICATOR_ARMED_ALPHA)
            else
                vf.frame._pulseEnabled = false
                vf.borderPulse:SetAlpha(D.VARIANT_PULSE_MAX_ALPHA)
                vf.borderPulse:Hide()
                vf.frame:SetAlpha(D.VARIANT_INDICATOR_DIM_ALPHA)
            end
        end
    end
end

function TH:RefreshVariantTints()
    if not S():Get("trackerVariantIndicators") then
        return
    end
    if InCombatLockdown() then
        return
    end
    for _, entry in ipairs(TH.icons) do
        if entry.seqName and entry.variantStrip and entry.variantStrip.frame:IsShown() then
            TH:UpdateVariantIndicators(entry.seqName)
        end
    end
end

function TH:OnSettingChanged(_, key, value)
    if not key or not tostring(key):match("^tracker") then
        return
    end
    GRIPEMS:Debug(string.format("TrackerHUD: setting %s = %s", tostring(key), tostring(value)))
    if key == "trackerShowMode" then
        if value == "NEVER" then
            if TH.frame then
                TH.frame:Hide()
            end
        else
            if not TH.frame then
                TH.frame = CreateHUDFrame()
                TH:RestorePosition()
            end
            TH:Rebuild()
        end
    elseif key == "trackerScale" then
        if TH.frame then
            TH.frame:SetScale(value or 1.0)
        end
    elseif key == "trackerIconSize" then
        TH:Rebuild()
    elseif key == "trackerOrientation" then
        TH:Rebuild()
    elseif key == "trackerShowName" then
        TH:Rebuild()
    elseif key == "trackerVariantIndicators" then
        TH:Rebuild()
    elseif key == "trackerLocked" then
        -- no-op: lock state checked dynamically in OnDragStart
        return
    elseif key == "trackerShowModifiers" then
        if value then
            if not TH.modFrame then
                local modFrame = _G["GRIPEMS_TrackerMod"] or CreateFrame("Frame", "GRIPEMS_TrackerMod", UIParent)
                modFrame:UnregisterAllEvents()
                modFrame:RegisterEvent("MODIFIER_STATE_CHANGED")
                modFrame:SetScript("OnEvent", UpdateModifierDisplay)
                TH.modFrame = modFrame
            end
            UpdateModifierDisplay()
        else
            if TH.modFrame then
                TH.modFrame:UnregisterAllEvents()
                TH.modFrame:SetScript("OnEvent", nil)
                TH.modFrame:Hide()
                TH.modFrame = nil
            end
            if TH.frame and TH.frame.modText then
                TH.frame.modText:SetText("")
            end
        end
    end
end

---------------------------------------------------------------------------
-- Public API
---------------------------------------------------------------------------
function TH:Toggle()
    local current = S():Get("trackerShowMode") or "NEVER"
    local order = { "NEVER", "ALWAYS", "COMBAT", "TARGET" }
    local modeNames = {
        NEVER = L["GEMS_TRACKER_MODE_NEVER"],
        ALWAYS = L["GEMS_TRACKER_MODE_ALWAYS"],
        COMBAT = L["GEMS_TRACKER_MODE_COMBAT"],
        TARGET = L["GEMS_TRACKER_MODE_TARGET"],
    }
    local nextIdx = 1
    for i, mode in ipairs(order) do
        if mode == current then
            nextIdx = (i % #order) + 1
            break
        end
    end
    local newMode = order[nextIdx]
    S():Set("trackerShowMode", newMode)
    GRIPEMS:Print(string.format(L["GEMS_TRACKER_TOGGLE"], modeNames[newMode] or newMode))
end

function TH:ToggleLock()
    local current = S():Get("trackerLocked")
    S():Set("trackerLocked", not current)
    if not current then
        GRIPEMS:Print(L["GEMS_TRACKER_LOCKED"])
    else
        GRIPEMS:Print(L["GEMS_TRACKER_UNLOCKED"])
    end
end

---------------------------------------------------------------------------
-- Initialization
---------------------------------------------------------------------------
function TH:Init()
    -- Create the frame
    TH.frame = CreateHUDFrame()
    TH:RestorePosition()
    GRIPEMS:Debug("TrackerHUD: Init complete")

    -- Register callbacks
    if GRIPEMS.RegisterCallback then
        GRIPEMS.RegisterCallback(TH, "SEQUENCE_STEP_ADVANCED", "OnStepAdvanced")
        GRIPEMS.RegisterCallback(TH, "SEQUENCE_CREATED", "OnSequenceChanged")
        GRIPEMS.RegisterCallback(TH, "SEQUENCE_DELETED", "OnSequenceChanged")
        GRIPEMS.RegisterCallback(TH, "SEQUENCE_UPDATED", "OnSequenceChanged")
        GRIPEMS.RegisterCallback(TH, "SETTING_CHANGED", "OnSettingChanged")
        GRIPEMS.RegisterCallback(TH, "KEYBIND_CHANGED", "OnSequenceChanged")
        -- IC-VAR-08: VARIANT_RECOMMENDATION_UPDATED -> per-variant strip pulse + alpha
        GRIPEMS.RegisterCallback(TH, "VARIANT_RECOMMENDATION_UPDATED", "OnRecommendationUpdated")
    end

    -- Restriction state event frame
    local restrictFrame = _G["GRIPEMS_TrackerRestrict"] or CreateFrame("Frame", "GRIPEMS_TrackerRestrict", UIParent)
    restrictFrame:UnregisterAllEvents()
    if C_RestrictedActions and C_RestrictedActions.IsAddOnRestrictionActive then
        restrictFrame:RegisterEvent("ADDON_RESTRICTION_STATE_CHANGED")
    end
    restrictFrame:SetScript("OnEvent", function()
        TH:UpdateRestrictionLabel()
    end)
    TH.restrictFrame = restrictFrame

    -- Visibility event frame (combat/target state changes).
    -- IC-VAR-08 also routes UNIT_HEALTH + UNIT_POWER_UPDATE through this
    -- frame so the ColorCurve tint refreshes on resource change. The OOC
    -- gate inside RefreshVariantTints matches Path D5 discipline -- HP/power
    -- are read only when InCombatLockdown() is false.
    local visFrame = _G["GRIPEMS_TrackerVis"] or CreateFrame("Frame", "GRIPEMS_TrackerVis", UIParent)
    visFrame:UnregisterAllEvents()
    visFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
    visFrame:RegisterEvent("PLAYER_REGEN_DISABLED")
    visFrame:RegisterEvent("PLAYER_TARGET_CHANGED")
    visFrame:RegisterEvent("UNIT_HEALTH")
    visFrame:RegisterEvent("UNIT_POWER_UPDATE")
    visFrame:SetScript("OnEvent", function(_, event, unit)
        if event == "UNIT_HEALTH" or event == "UNIT_POWER_UPDATE" then
            if unit ~= "player" then
                return
            end
            TH:RefreshVariantTints()
            return
        end
        if ShouldBeVisible() and TH.frame and not TH.frame:IsShown() then
            TH:Rebuild()
        else
            TH:UpdateVisibility()
        end
    end)
    TH.visFrame = visFrame

    -- Modifier key event frame
    if S():Get("trackerShowModifiers") then
        local modFrame = _G["GRIPEMS_TrackerMod"] or CreateFrame("Frame", "GRIPEMS_TrackerMod", UIParent)
        modFrame:UnregisterAllEvents()
        modFrame:RegisterEvent("MODIFIER_STATE_CHANGED")
        modFrame:SetScript("OnEvent", UpdateModifierDisplay)
        TH.modFrame = modFrame
    end

    -- Initial build + visibility check
    TH:Rebuild()
    TH:UpdateVisibility()
end
