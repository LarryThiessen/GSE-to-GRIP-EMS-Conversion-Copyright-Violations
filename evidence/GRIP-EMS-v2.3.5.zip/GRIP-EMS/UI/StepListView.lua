-- GRIP-EMS: Step List View
-- Editable step list with ScrollBox, action buttons, and per-step EditBox
-- Created: 2026-03-15 (estimated, pre-stamping)
-- Updated: 2026-07-03
-- Patch: 12.0.7.68275 Midnight (Retail LIVE)

local ADDON_NAME, GRIPEMS = ...
local UI = GRIPEMS.UI
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

-- Upvalue accessor for Defaults
local function D()
    return GRIPEMS.Defaults
end

GRIPEMS.StepListView = {}
local SLV = GRIPEMS.StepListView

-- Runtime state
SLV.workingSteps = {}
SLV.originalSteps = {}
SLV.workingStepLabels = {}
SLV.originalStepLabels = {}
SLV.selectedIndex = nil
SLV._lastLineCount = 0
SLV._refreshRowTimer = nil
SLV.keyPressLen = 0
SLV.keyReleaseLen = 0

-- Tree mode state (v1.2.0 S14-B)
SLV.treeMode = false
SLV.workingActions = nil
SLV._originalActionsSerialized = nil
SLV.hasActions = false

-- Multi-select state (flat step lists only). selectedSet is nil in
-- single/no-selection mode, or a set (idx -> true) with >= 2 entries in
-- multi-select mode. selectedIndex remains the primary/last-clicked row.
SLV.selectedSet = nil
SLV.selectionAnchor = nil

-- True while a flat multi-selection is active. Gated to flat mode so an
-- outline/actions sequence always reports single-select.
function SLV:IsMultiSelect()
    if SLV.hasActions or SLV.selectedSet == nil then
        return false
    end
    -- Self-heal the multi-select invariant. A legitimate multi-selection
    -- always keeps selectedIndex as a member of selectedSet; only a foreign
    -- write (a single-step undo/redo restoring selectedIndex without owning
    -- the selection) can break that. When the primary is no longer a member
    -- the set is stale, so collapse to single-select on the primary. Every
    -- consumer (row highlight, button state, edit area, bulk delegation)
    -- funnels through here, so the collapse is seen consistently.
    if SLV.selectedIndex == nil or not SLV.selectedSet[SLV.selectedIndex] then
        SLV.selectedSet = nil
        SLV.selectionAnchor = SLV.selectedIndex
        return false
    end
    return true
end

-- Selection test used by row rendering. Flat multi-select highlights from
-- the set; every other case falls back to the single primary index.
function SLV:IsRowSelected(index)
    if SLV:IsMultiSelect() then
        return SLV.selectedSet[index] == true
    end
    return index == SLV.selectedIndex
end

-- Ascending list of selected flat-step indices. Single-select returns the
-- primary index alone; no selection returns an empty list.
function SLV:GetSelectionList()
    local list = {}
    if SLV:IsMultiSelect() then
        for k in pairs(SLV.selectedSet) do
            list[#list + 1] = k
        end
        table.sort(list)
    elseif SLV.selectedIndex then
        list[1] = SLV.selectedIndex
    end
    return list
end

-- Modifier-aware click handler for flat step rows.
function SLV:_HandleFlatSelectionClick(index)
    local ctrl = IsControlKeyDown()
    local shift = IsShiftKeyDown()
    if shift and (SLV.selectionAnchor or SLV.selectedIndex) then
        local anchor = SLV.selectionAnchor or SLV.selectedIndex
        local lo = math.min(anchor, index)
        local hi = math.max(anchor, index)
        if hi > lo then
            local set = {}
            for i = lo, hi do
                set[i] = true
            end
            SLV.selectedSet = set
        else
            SLV.selectedSet = nil
        end
        SLV.selectedIndex = index
    elseif ctrl then
        if SLV.selectedSet then
            if SLV.selectedSet[index] then
                SLV.selectedSet[index] = nil
                local remaining = {}
                for k in pairs(SLV.selectedSet) do
                    remaining[#remaining + 1] = k
                end
                if #remaining <= 1 then
                    SLV.selectedSet = nil
                    SLV.selectedIndex = remaining[1]
                elseif SLV.selectedIndex == index then
                    table.sort(remaining)
                    SLV.selectedIndex = remaining[#remaining]
                end
            else
                SLV.selectedSet[index] = true
                SLV.selectedIndex = index
            end
        elseif SLV.selectedIndex and SLV.selectedIndex ~= index then
            SLV.selectedSet = { [SLV.selectedIndex] = true, [index] = true }
            SLV.selectedIndex = index
        elseif SLV.selectedIndex == index then
            SLV.selectedIndex = nil
        else
            SLV.selectedIndex = index
        end
        -- Anchor tracks the surviving primary, not the clicked row: a ctrl-click
        -- that deselects a row must not leave the anchor on a now-unselected row,
        -- or the next shift-click would range from a ghost anchor.
        SLV.selectionAnchor = SLV.selectedIndex
    else
        SLV.selectedSet = nil
        SLV.selectedIndex = index
        SLV.selectionAnchor = index
    end
end

-- Debug: when true, RefreshCurrentRow is skipped (flicker diagnostic)
local debugSkipRowRefresh = false

---------------------------------------------------------------------------
-- Tooltip anchoring helper (edge-clamp)
---------------------------------------------------------------------------

--- Anchor GameTooltip to an owner row with screen-right overflow protection.
--- Flips from ANCHOR_RIGHT to ANCHOR_LEFT when the row sits far enough right
--- that a right-anchored tooltip would extend past UIParent's right edge.
--- Always re-asserts SetClampedToScreen(true) as a belt-and-braces guard.
--- @param owner Frame The owner frame (typically the row the user is hovering)
local function anchorTooltipSmart(owner)
    if not owner or not GameTooltip then
        return
    end
    local anchor = "ANCHOR_RIGHT"
    local ok, rowRight = pcall(owner.GetRight, owner)
    if ok and rowRight then
        local okP, parentRight = pcall(UIParent.GetRight, UIParent)
        if okP and parentRight then
            local estTooltipWidth = 320
            if rowRight + estTooltipWidth > parentRight then
                anchor = "ANCHOR_LEFT"
            end
        end
    end
    GameTooltip:SetOwner(owner, anchor)
    if GameTooltip.SetClampedToScreen then
        pcall(GameTooltip.SetClampedToScreen, GameTooltip, true)
    end
end

---------------------------------------------------------------------------
-- Tab-press autocomplete helpers
---------------------------------------------------------------------------

--- Extract the word under the cursor from an EditBox.
--- Walks back from cursor to the nearest word boundary (space, newline, or
--- start of string). "/" and "#" are NOT boundaries (macro command prefixes).
--- @param editBox EditBox The EditBox to read
--- @return string word The extracted word
--- @return number wordStart Start position of the word (1-based)
--- @return number cursorPos Cursor position
local function extractWordUnderCursor(editBox)
    local text = editBox:GetText() or ""
    local cursorPos = editBox:GetCursorPosition()
    local wordStart = cursorPos
    while wordStart > 0 do
        local ch = text:sub(wordStart, wordStart)
        if ch == " " or ch == "\n" then
            wordStart = wordStart + 1
            break
        end
        wordStart = wordStart - 1
    end
    if wordStart <= 0 then
        wordStart = 1
    end
    local word = text:sub(wordStart, cursorPos)
    return word, wordStart, cursorPos
end

--- Handle Tab keypress in a step EditBox: attempt spell autocomplete.
--- Falls back to ClearFocus if no matches or spell cache unavailable.
--- @param editBox EditBox The EditBox that received the Tab press
local function handleTabAutocomplete(editBox)
    -- If dropdown is already shown, dismiss it and defocus
    if SLV.autocompleteDropdown and SLV.autocompleteDropdown:IsShown() then
        SLV.autocompleteDropdown:Hide()
        editBox:ClearFocus()
        return
    end

    local SC = GRIPEMS.SpellCache
    if not SC or not SC.ready then
        editBox:ClearFocus()
        return
    end

    local word, wordStart, cursorPos = extractWordUnderCursor(editBox)

    -- Variable autocomplete: check if character before wordStart is "~"
    local text = editBox:GetText() or ""
    local charBefore = (wordStart > 1) and text:sub(wordStart - 1, wordStart - 1) or ""
    local isVarComplete = (charBefore == "~")
    -- Also trigger if word itself starts with ~ (cursor right after ~)
    if not isVarComplete and word:sub(1, 1) == "~" then
        isVarComplete = true
        -- Strip the leading ~ from the word; adjust wordStart to include it
        word = word:sub(2)
        -- wordStart already includes the ~ position
    end

    if isVarComplete then
        local VS = GRIPEMS.VariableStore
        if not VS then
            editBox:ClearFocus()
            return
        end
        local store = VS:GetAll()
        local varMatches = {}
        local prefix = word:lower()
        for varName in pairs(store) do
            if prefix == "" or varName:lower():sub(1, #prefix) == prefix then
                varMatches[#varMatches + 1] = { name = varName }
            end
        end
        table.sort(varMatches, function(a, b)
            return a.name < b.name
        end)
        if #varMatches > D().AUTOCOMPLETE_MAX_RESULTS then
            local trimmed = {}
            for i = 1, D().AUTOCOMPLETE_MAX_RESULTS do
                trimmed[i] = varMatches[i]
            end
            varMatches = trimmed
        end
        if #varMatches == 0 then
            editBox:ClearFocus()
            return
        end
        -- For variable autocomplete, the replacement range starts at the ~
        local tildeStart = charBefore == "~" and (wordStart - 1) or wordStart
        SLV:ShowVarAutocompleteMenu(editBox, varMatches, tildeStart, cursorPos)
        return
    end

    local firstChar = word:sub(1, 1)
    local isCommand = (firstChar == "/" or firstChar == "#")
    local minChars = isCommand and D().AUTOCOMPLETE_MIN_CHARS or D().AUTOCOMPLETE_MIN_SPELL_CHARS
    if #word < minChars then
        editBox:ClearFocus()
        return
    end

    -- Dual-path: macro commands (starts with / or #) or spell names
    local matches
    if isCommand then
        matches = SC:MacroCommandSearch(word, D().AUTOCOMPLETE_MAX_RESULTS)
    else
        matches = SC:PrefixSearch(word, D().AUTOCOMPLETE_MAX_RESULTS)
    end
    if #matches == 0 then
        -- Fallback: sequence name autocomplete
        if #word >= D().AUTOCOMPLETE_MIN_SEQ_CHARS then
            local seqMatches = SLV:SearchSequenceNames(word)
            if #seqMatches > 0 then
                SLV:ShowSeqAutocompleteMenu(editBox, seqMatches, wordStart, cursorPos)
                return
            end
        end
        editBox:ClearFocus()
        return
    end

    -- Show autocomplete popup
    SLV:ShowAutocompleteMenu(editBox, matches, wordStart, cursorPos)
end

---------------------------------------------------------------------------
-- Initialization
---------------------------------------------------------------------------

--- Build the editable step list inside the given parent frame (tab content area).
--- @param parentFrame Frame The content area that hosts the step list
function SLV:Init(parentFrame)
    if not parentFrame then
        return
    end
    local C = UI.Colors

    SLV.container = parentFrame

    ---------------------------------------------------------------------------
    -- Edit area (bottom section: header line + EditBox)
    ---------------------------------------------------------------------------
    local editArea = CreateFrame("Frame", nil, parentFrame)
    editArea:SetPoint("BOTTOMLEFT", parentFrame, "BOTTOMLEFT", 4, 4)
    editArea:SetPoint("BOTTOMRIGHT", parentFrame, "BOTTOMRIGHT", -4, 4)
    editArea:Hide()
    SLV.editArea = editArea

    -- Phase 4-polish editBox-overflow: dynamic editArea height
    -- Scales with parentFrame height up to a ratio + absolute cap.
    local function _resizeEditArea()
        local ph = parentFrame:GetHeight() or 0
        if ph <= 0 then
            return
        end
        local d = D()
        local target = math.max(
            d.STEP_EDIT_AREA_MIN_HEIGHT,
            math.min(d.STEP_EDIT_AREA_MAX_RATIO * ph, d.STEP_EDIT_AREA_MAX_HEIGHT)
        )
        editArea:SetHeight(target)
    end
    parentFrame:HookScript("OnSizeChanged", function()
        _resizeEditArea()
    end)
    _resizeEditArea() -- initial pass before parentFrame OnSizeChanged fires

    -- Step header: "Step N:" left-aligned, char count right-aligned
    local editHeader = editArea:CreateFontString(nil, "OVERLAY")
    UI:SetFont(editHeader, 11)
    editHeader:SetPoint("TOPLEFT", editArea, "TOPLEFT", 2, 0)
    editHeader:SetText("")
    editHeader:SetTextColor(C.textSecondary:GetRGBA())
    SLV.editHeader = editHeader

    local editCharCount = editArea:CreateFontString(nil, "OVERLAY")
    UI:SetFont(editCharCount, 10)
    editCharCount:SetPoint("TOPRIGHT", editArea, "TOPRIGHT", -2, 0)
    editCharCount:SetText("")
    editCharCount:SetTextColor(C.textSuccess:GetRGBA())
    SLV.editCharCount = editCharCount

    -- Interleave controls row (shown only for ACTION nodes in outline mode)
    local ilRow = CreateFrame("Frame", nil, editArea)
    ilRow:SetHeight(22)
    ilRow:SetPoint("TOPLEFT", editHeader, "BOTTOMLEFT", 0, -2)
    ilRow:SetPoint("RIGHT", editArea, "RIGHT", -2, 0)
    ilRow:Hide()
    SLV.ilRow = ilRow

    local ilLbl = ilRow:CreateFontString(nil, "OVERLAY")
    UI:SetFont(ilLbl, 10)
    ilLbl:SetPoint("LEFT", ilRow, "LEFT", 0, 0)
    ilLbl:SetText(L["GEMS_ACTION_INTERLEAVE_EVERY"])
    ilLbl:SetTextColor(C.textSecondary:GetRGBA())
    SLV.ilLabel = ilLbl

    local ilCheck = CreateFrame("CheckButton", nil, ilRow, "UICheckButtonTemplate")
    ilCheck:SetSize(20, 20)
    ilCheck:SetPoint("LEFT", ilLbl, "RIGHT", 4, 0)
    ilCheck:SetScript("OnEnter", function(self)
        anchorTooltipSmart(self)
        GameTooltip:SetText(L["GEMS_INTERLEAVE_TOOLTIP_TITLE"], 1, 1, 1)
        GameTooltip:AddLine(L["GEMS_INTERLEAVE_TOOLTIP_DESC"], 0.8, 0.8, 0.8, true)
        GameTooltip:Show()
    end)
    ilCheck:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)
    SLV.ilCheck = ilCheck

    local fontPath = GRIPEMS.UI:GetFontPath()
    local ivBox = CreateFrame("EditBox", nil, ilRow, "BackdropTemplate")
    ivBox:SetSize(36, 20)
    ivBox:SetPoint("LEFT", ilCheck, "RIGHT", 4, 0)
    ivBox:SetAutoFocus(false)
    ivBox:SetNumeric(true)
    ivBox:SetMaxLetters(2)
    UI:ApplyBackdrop(ivBox, UI.Backdrops.panel, C.bgInput, C.border)
    ivBox:SetTextInsets(4, 4, 2, 2)
    ivBox:SetFont(fontPath, 10, "")
    ivBox:SetTextColor(C.textPrimary:GetRGBA())
    ivBox:Hide()
    SLV.ilSpinner = ivBox
    GRIPEMS.Focus:HookEditBox(ivBox)

    local stepsLbl = ilRow:CreateFontString(nil, "OVERLAY")
    UI:SetFont(stepsLbl, 10)
    stepsLbl:SetPoint("LEFT", ivBox, "RIGHT", 4, 0)
    stepsLbl:SetText(L["GEMS_ACTION_INTERLEAVE_STEPS"])
    stepsLbl:SetTextColor(C.textSecondary:GetRGBA())
    SLV.ilStepsLabel = stepsLbl

    -- Phase 4-polish editBox-overflow: ScrollFrame wrap (mirrors kpScroll pattern at SE.lua L656-708)
    -- editBox lives inside editScrollFrame; ScrollFrame clips on overflow + provides scroll via mousewheel + scrollbar.
    local editScrollFrame = CreateFrame("ScrollFrame", nil, editArea)
    editScrollFrame:SetPoint("TOPLEFT", editHeader, "BOTTOMLEFT", 0, -4)
    editScrollFrame:SetPoint("BOTTOMLEFT", editArea, "BOTTOMLEFT", 0, 4)
    editScrollFrame:SetPoint("RIGHT", editArea, "RIGHT", -34, 0)
    SLV.editScrollFrame = editScrollFrame

    -- editBox: SetScrollChild target. Auto-grows on user input; ScrollFrame clips overflow.
    local editBox = CreateFrame("EditBox", nil, editScrollFrame, "BackdropTemplate")
    editBox:SetMultiLine(true)
    editBox:SetAutoFocus(false)
    UI:ApplyBackdrop(editBox, UI.Backdrops.panel, C.bgInput, C.border)
    editBox:SetTextInsets(6, 6, 4, 4)
    editBox:SetFont(fontPath, 11, "")
    editBox:SetTextColor(C.textPrimary:GetRGBA())
    editBox:SetHeight(D().STEP_EDIT_HEIGHT_MIN)
    editBox:SetWidth(editScrollFrame:GetWidth())

    editScrollFrame:SetScrollChild(editBox)
    editScrollFrame:SetScript("OnSizeChanged", function(self, w, _h)
        if w and w > 0 then
            editBox:SetWidth(w)
        end
    end)
    editScrollFrame:EnableMouseWheel(true)
    editScrollFrame:SetScript("OnMouseWheel", function(self, delta)
        local current = self:GetVerticalScroll() or 0
        local maxScroll = self:GetVerticalScrollRange() or 0
        local step = 20
        local newScroll = current - (delta * step)
        newScroll = math.max(0, math.min(newScroll, maxScroll))
        self:SetVerticalScroll(newScroll)
    end)

    -- MinimalScrollBar widget (mirrors UI/StepListView.lua scrollBox precedent above).
    -- Always-visible per Cowork spec; manually wired to editScrollFrame.
    local editScrollBar = CreateFrame("EventFrame", nil, editArea, "MinimalScrollBar")
    editScrollBar:SetPoint("TOPLEFT", editScrollFrame, "TOPRIGHT", 2, 0)
    editScrollBar:SetPoint("BOTTOMLEFT", editScrollFrame, "BOTTOMRIGHT", 2, 0)
    SLV.editScrollBar = editScrollBar

    -- Wire scrollbar value <-> ScrollFrame vertical scroll
    editScrollBar:RegisterCallback("OnScroll", function(_self, scrollPercentage)
        local maxScroll = editScrollFrame:GetVerticalScrollRange() or 0
        editScrollFrame:SetVerticalScroll(scrollPercentage * maxScroll)
    end, editScrollBar)
    editScrollFrame:SetScript("OnVerticalScroll", function(self, offset)
        local maxScroll = self:GetVerticalScrollRange() or 0
        if maxScroll > 0 then
            editScrollBar:SetScrollPercentage(offset / maxScroll)
        end
    end)
    editScrollFrame:SetScript("OnScrollRangeChanged", function(self, _xRange, yRange)
        local visibleExtent = self:GetHeight() or 0
        local fullExtent = (yRange or 0) + visibleExtent
        if visibleExtent > 0 and fullExtent > 0 then
            editScrollBar:SetVisibleExtentPercentage(visibleExtent / fullExtent)
        end
    end)

    -- Force always-visible (Cowork spec). MinimalScrollBar auto-hides via ScrollUtil
    -- when registered with WowScrollBoxList; manual wiring usually leaves it visible,
    -- but belt-and-braces hook OnHide to re-Show.
    editScrollBar:Show()
    editScrollBar:HookScript("OnHide", function(self)
        self:Show()
    end)

    -- spellPickerBtn: parent to editScrollFrame so visibility follows the ScrollFrame's Show/Hide
    local spellPickerBtn = CreateFrame("Button", nil, editScrollFrame)
    spellPickerBtn:SetSize(16, 16)
    spellPickerBtn:SetPoint("LEFT", editScrollBar, "RIGHT", 4, 0)
    spellPickerBtn:SetPoint("TOP", editScrollFrame, "TOP", 0, 0)
    spellPickerBtn:SetNormalTexture("Interface\\Icons\\INV_Misc_Book_09")
    spellPickerBtn:SetScript("OnClick", function(self)
        local SPicker = GRIPEMS.SpellPicker
        if SPicker then
            SPicker:Toggle(editBox, self)
        end
    end)
    spellPickerBtn:SetScript("OnEnter", function(self)
        UI:ShowTooltip(self, L["GEMS_SPELLPICKER_TITLE"], L["GEMS_SPELLPICKER_INSERT"])
    end)
    spellPickerBtn:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)
    SLV.spellPickerBtn = spellPickerBtn

    editBox:SetScript("OnTextChanged", function(self, userInput)
        if not userInput then
            return
        end
        if not SLV.selectedIndex then
            return
        end
        local text = self:GetText() or ""
        local idx = SLV.selectedIndex
        SLV.workingSteps[idx] = text

        -- Undo snapshot: capture original text on first change
        if SLV._undoTextSnapshot == nil and not SLV._suppressUndo then
            SLV._undoTextSnapshot = SLV._preEditText or ""
            SLV._undoTextSnapshotIdx = idx
        end

        -- Update char count display
        SLV:UpdateEditCharCount(#text)

        -- Set dirty flag on editor
        local SE = GRIPEMS.SequenceEditor
        if SE then
            SE.isDirty = true
            SE:UpdateSaveButtons()
        end

        -- Auto-height: editBox grows to natural content height; ScrollFrame clips overflow
        -- and the scrollbar engages. The MIN clamp keeps short-content boxes from collapsing.
        local numLines = select(2, text:gsub("\n", "")) + 1
        if numLines ~= SLV._lastLineCount then
            SLV._lastLineCount = numLines
            local lineHeight = 14
            local contentH = math.max(D().STEP_EDIT_HEIGHT_MIN, numLines * lineHeight + 8)
            self:SetHeight(contentH)
        end

        -- Refresh scroll row (lightweight, no DataProvider rebuild)
        SLV:DebouncedRefreshCurrentRow()

        -- Live-filter autocomplete if dropdown is visible
        SLV:RefreshAutocomplete(self)
    end)
    editBox:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
    end)
    editBox:SetScript("OnTabPressed", function(self)
        handleTabAutocomplete(self)
    end)
    editBox:SetScript("OnEditFocusGained", function(self)
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
        -- Capture pre-edit text for undo snapshot
        if SLV.selectedIndex and SLV.workingSteps then
            SLV._preEditText = SLV.workingSteps[SLV.selectedIndex]
        end
    end)
    editBox:SetScript("OnEditFocusLost", function(self)
        self:SetBackdropBorderColor(C.border:GetRGBA())
        -- Flush debounced undo entry for text editing
        SLV:FlushTextUndoSnapshot()
    end)
    SLV.editBox = editBox
    GRIPEMS.Focus:HookEditBox(editBox)
    GRIPEMS.Focus:HookSelectionCapture(editBox)

    -- Syntax highlighting hook
    local SH = GRIPEMS.SyntaxHighlight
    if SH then
        SH:HookEditBox(SLV.editBox, "macro")
    end

    -- Unsaved changes hint (below editBox, subtle yellow)
    local unsavedHint = editArea:CreateFontString(nil, "OVERLAY")
    UI:SetFont(unsavedHint, 9)
    unsavedHint:SetPoint("BOTTOMLEFT", editArea, "BOTTOMLEFT", 4, 0)
    unsavedHint:SetText(L["GEMS_STEP_UNSAVED_HINT"])
    unsavedHint:SetTextColor(C.textWarning:GetRGBA())
    unsavedHint:SetAlpha(0.8)
    unsavedHint:Hide()
    SLV.unsavedHint = unsavedHint

    ---------------------------------------------------------------------------
    -- Action button bar (above edit area)
    ---------------------------------------------------------------------------
    local actionBar = CreateFrame("Frame", nil, parentFrame)
    actionBar:SetHeight(D().STEP_ACTION_BAR_HEIGHT)
    actionBar:SetPoint("BOTTOMLEFT", editArea, "TOPLEFT", 0, 4)
    actionBar:SetPoint("BOTTOMRIGHT", editArea, "TOPRIGHT", 0, 4)
    SLV.actionBar = actionBar

    -- Build action buttons
    local btnDefs = {
        {
            key = "add",
            label = L["GEMS_UI_ADD_STEP"],
            desc = L["GEMS_UI_ADD_STEP_DESC"],
            fn = function(self)
                SLV:_showAddMenu(self or SLV.actionButtons["add"], false)
            end,
        },
        {
            key = "dup",
            label = L["GEMS_UI_DUP_STEP"],
            desc = L["GEMS_UI_DUP_STEP_DESC"],
            fn = function()
                if SLV.hasActions and SLV.workingActions then
                    local ni = (SLV._editingContext and SLV._editingContext.nodeIndex)
                        or (SLV._detailOpen and SLV._detailNodeIndex)
                    if ni and SLV.workingActions[ni] then
                        local DD = GRIPEMS.Defaults
                        local copy = DD.DeepCopyActions({ SLV.workingActions[ni] })[1]
                        table.insert(SLV.workingActions, ni + 1, copy)
                        SLV:_markDirty()
                        SLV:RefreshAll()
                        return
                    end
                end
                SLV:DuplicateStep()
            end,
        },
        {
            key = "up",
            label = L["GEMS_UI_MOVE_UP"],
            desc = L["GEMS_UI_MOVE_UP_DESC"],
            fn = function()
                if SLV.hasActions and SLV.workingActions then
                    local ni = (SLV._editingContext and SLV._editingContext.nodeIndex)
                        or (SLV._detailOpen and SLV._detailNodeIndex)
                    if ni and ni > 1 then
                        SLV.workingActions[ni], SLV.workingActions[ni - 1] =
                            SLV.workingActions[ni - 1], SLV.workingActions[ni]
                        if SLV._editingContext then
                            SLV._editingContext.nodeIndex = ni - 1
                        end
                        if SLV._detailOpen and SLV._detailNodeIndex == ni then
                            SLV._detailNodeIndex = ni - 1
                        end
                        SLV:_markDirty()
                        SLV:RefreshAll()
                        return
                    end
                end
                SLV:MoveStepUp()
            end,
        },
        {
            key = "down",
            label = L["GEMS_UI_MOVE_DOWN"],
            desc = L["GEMS_UI_MOVE_DOWN_DESC"],
            fn = function()
                if SLV.hasActions and SLV.workingActions then
                    local ni = (SLV._editingContext and SLV._editingContext.nodeIndex)
                        or (SLV._detailOpen and SLV._detailNodeIndex)
                    if ni and ni < #SLV.workingActions then
                        SLV.workingActions[ni], SLV.workingActions[ni + 1] =
                            SLV.workingActions[ni + 1], SLV.workingActions[ni]
                        if SLV._editingContext then
                            SLV._editingContext.nodeIndex = ni + 1
                        end
                        if SLV._detailOpen and SLV._detailNodeIndex == ni then
                            SLV._detailNodeIndex = ni + 1
                        end
                        SLV:_markDirty()
                        SLV:RefreshAll()
                        return
                    end
                end
                SLV:MoveStepDown()
            end,
        },
        {
            key = "del",
            label = L["GEMS_UI_DEL_STEP"],
            desc = L["GEMS_UI_DEL_STEP_DESC"],
            fn = function()
                if SLV.hasActions and SLV.workingActions then
                    local ni = (SLV._editingContext and SLV._editingContext.nodeIndex)
                        or (SLV._detailOpen and SLV._detailNodeIndex)
                    if ni and SLV.workingActions[ni] then
                        table.remove(SLV.workingActions, ni)
                        if SLV._detailOpen and SLV._detailNodeIndex then
                            if SLV._detailNodeIndex == ni then
                                SLV:CloseDetailPane()
                            elseif SLV._detailNodeIndex > ni then
                                SLV._detailNodeIndex = SLV._detailNodeIndex - 1
                            end
                        end
                        SLV._editingContext = nil
                        SLV.selectedIndex = nil
                        SLV:_markDirty()
                        SLV:RefreshAll()
                        return
                    end
                end
                SLV:DeleteStep()
            end,
        },
    }
    SLV.actionButtons = {}
    local prevBtn
    for _, def in ipairs(btnDefs) do
        local btn = UI:CreateButton(actionBar, def.label, D().STEP_BUTTON_WIDTH, D().STEP_BUTTON_HEIGHT)
        if prevBtn then
            btn:SetPoint("LEFT", prevBtn, "RIGHT", 4, 0)
        else
            btn:SetPoint("LEFT", actionBar, "LEFT", 0, 0)
        end

        btn:SetScript("OnClick", def.fn)
        btn:SetScript("OnEnter", function(self)
            self:SetBackdropColor(C.bgRowHover:GetRGBA())
            self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
            UI:ShowTooltip(self, def.label, def.desc)
        end)
        btn:SetScript("OnLeave", function(self)
            SLV:UpdateButtonStates()
            UI:HideTooltip()
        end)

        SLV.actionButtons[def.key] = btn
        prevBtn = btn
    end

    -- Save button (right-aligned, shown only when dirty)
    local saveBtn = UI:CreateButton(actionBar, L["GEMS_STEP_SAVE"], 60, D().STEP_BUTTON_HEIGHT)
    saveBtn:SetPoint("RIGHT", actionBar, "RIGHT", 0, 0)
    saveBtn:SetBackdropColor(C.bgSave:GetRGBA())
    saveBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.bgSaveHover:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
        UI:ShowTooltip(self, L["GEMS_STEP_SAVE"], L["GEMS_STEP_SAVE_DESC"])
    end)
    saveBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgSave:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
        UI:HideTooltip()
    end)
    saveBtn:SetScript("OnClick", function()
        local SE = GRIPEMS.SequenceEditor
        if SE then
            SE:SaveSequence()
        end
    end)
    saveBtn:Hide()
    SLV.saveBtn = saveBtn

    ---------------------------------------------------------------------------
    -- ScrollBox (top section, above action bar)
    ---------------------------------------------------------------------------
    local scrollBox = CreateFrame("Frame", nil, parentFrame, "WowScrollBoxList")
    scrollBox:SetPoint("TOPLEFT", parentFrame, "TOPLEFT", 4, -4)
    scrollBox:SetPoint("RIGHT", parentFrame, "RIGHT", -18, 0)
    scrollBox:SetPoint("BOTTOM", actionBar, "TOP", 0, 4)
    SLV.scrollBox = scrollBox
    if GRIPEMS.UI and GRIPEMS.UI.RegisterElement then
        GRIPEMS.UI:RegisterElement(scrollBox, "panel.stepList")
    end

    local scrollBar = CreateFrame("EventFrame", nil, parentFrame, "MinimalScrollBar")
    scrollBar:SetPoint("TOPLEFT", scrollBox, "TOPRIGHT", 2, 0)
    scrollBar:SetPoint("BOTTOMLEFT", scrollBox, "BOTTOMRIGHT", 2, 0)
    SLV.scrollBar = scrollBar

    local scrollView = CreateScrollBoxListLinearView()
    -- Variable row heights: step rows use STEP_ROW_HEIGHT, but Loop / If and
    -- other structural node badges render at NODE_BADGE_HEIGHT (see InitRow).
    -- A single fixed extent sizes the scroll range from one height, so once a
    -- taller node row is present the range falls short and rows overlap: a long
    -- Loop list could not scroll to the last rows until the window was resized.
    -- The per-element calculator returns each row's real height so the range
    -- and layout stay correct. The calculator is invoked as
    -- elementExtentCalculator(dataIndex, elementData) by the linear view.
    scrollView:SetElementExtentCalculator(function(_dataIndex, elementData)
        if elementData and elementData.rowType == "node" then
            return D().NODE_BADGE_HEIGHT
        end
        return D().STEP_ROW_HEIGHT
    end)
    SLV.scrollView = scrollView

    scrollView:SetElementInitializer("Button", function(button, data)
        SLV:InitRow(button, data)
    end)

    ScrollUtil.InitScrollBoxListWithScrollBar(scrollBox, scrollBar, scrollView)

    local dp = CreateDataProvider()
    scrollBox:SetDataProvider(dp)
    SLV.dataProvider = dp

    ---------------------------------------------------------------------------
    -- Drag-to-reorder infrastructure (ghost frame, indicator, state)
    ---------------------------------------------------------------------------
    local dragGhost = CreateFrame("Frame", "GRIPEMS_DragGhost", UIParent, "BackdropTemplate")
    dragGhost:SetFrameStrata("TOOLTIP")
    UI:ApplyBackdrop(dragGhost, UI.Backdrops.panel, C.bgRowSelected, C.borderFocus)
    dragGhost:SetSize(scrollBox:GetWidth(), D().STEP_ROW_HEIGHT)

    dragGhost.ghostNum = dragGhost:CreateFontString(nil, "OVERLAY")
    UI:SetFont(dragGhost.ghostNum, 10)
    dragGhost.ghostNum:SetPoint("LEFT", dragGhost, "LEFT", 4, 0)
    dragGhost.ghostNum:SetWidth(30)
    dragGhost.ghostNum:SetJustifyH("LEFT")
    dragGhost.ghostNum:SetTextColor(C.textSecondary:GetRGBA())

    dragGhost.ghostText = dragGhost:CreateFontString(nil, "OVERLAY")
    UI:SetFont(dragGhost.ghostText, 11)
    dragGhost.ghostText:SetPoint("LEFT", dragGhost.ghostNum, "RIGHT", 4, 0)
    dragGhost.ghostText:SetPoint("RIGHT", dragGhost, "RIGHT", -4, 0)
    dragGhost.ghostText:SetJustifyH("LEFT")
    dragGhost.ghostText:SetWordWrap(false)
    dragGhost.ghostText:SetTextColor(C.textPrimary:GetRGBA())

    dragGhost:Hide()
    SLV.dragGhost = dragGhost

    local dragIndicator = CreateFrame("Frame", nil, parentFrame)
    dragIndicator:SetHeight(2)
    dragIndicator:SetFrameLevel(scrollBox:GetFrameLevel() + 10)
    local indicatorTex = dragIndicator:CreateTexture(nil, "OVERLAY")
    indicatorTex:SetAllPoints()
    indicatorTex:SetColorTexture(C.borderFocus:GetRGBA())
    dragIndicator:Hide()
    SLV.dragIndicator = dragIndicator

    -- Reparent highlight: tints a Loop row when a dragged top-level node hovers
    -- its middle band (drop INTO the loop). Created alongside the drag overlays.
    SLV.dragReparentHighlight = CreateFrame("Frame", nil, parentFrame, "BackdropTemplate")
    SLV.dragReparentHighlight:SetFrameStrata("DIALOG")
    local reparentTex = SLV.dragReparentHighlight:CreateTexture(nil, "OVERLAY")
    reparentTex:SetAllPoints(SLV.dragReparentHighlight)
    reparentTex:SetColorTexture(C.borderFocus:GetRGB())
    reparentTex:SetAlpha(0.22)
    SLV.dragReparentHighlight._tex = reparentTex
    SLV.dragReparentHighlight:Hide()

    SLV._dragSourceIndex = nil
    SLV._isDragging = false

    ---------------------------------------------------------------------------
    -- Empty / placeholder labels
    ---------------------------------------------------------------------------
    local emptyIcon = parentFrame:CreateTexture(nil, "OVERLAY")
    emptyIcon:SetSize(32, 32)
    emptyIcon:SetPoint("CENTER", scrollBox, "CENTER", 0, 24)
    emptyIcon:SetTexture(134400)
    emptyIcon:SetAlpha(0.3)
    SLV.emptyIcon = emptyIcon

    local emptyLabel = parentFrame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(emptyLabel, 11)
    emptyLabel:SetPoint("CENTER", scrollBox, "CENTER", 0, -4)
    emptyLabel:SetText(L["GEMS_UI_NO_STEPS"])
    emptyLabel:SetTextColor(C.textMuted:GetRGBA())
    SLV.emptyLabel = emptyLabel

    local hintLabel = parentFrame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(hintLabel, 9)
    hintLabel:SetPoint("TOP", emptyLabel, "BOTTOM", 0, -4)
    hintLabel:SetText(L["GEMS_UI_ADD_STEP_HINT"])
    hintLabel:SetTextColor(C.textMuted:GetRGBA())
    hintLabel:SetWidth(220)
    hintLabel:SetJustifyH("CENTER")
    SLV.hintLabel = hintLabel

    -- Placeholder for when no step is selected
    local selectLabel = parentFrame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(selectLabel, 10)
    selectLabel:SetPoint("CENTER", editArea, "CENTER", 0, 0)
    selectLabel:SetText(L["GEMS_UI_SELECT_STEP"])
    selectLabel:SetTextColor(C.textMuted:GetRGBA())
    selectLabel:Hide()
    SLV.selectLabel = selectLabel

    local multiSelectLabel = parentFrame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(multiSelectLabel, 10)
    multiSelectLabel:SetPoint("CENTER", editArea, "CENTER", 0, 0)
    multiSelectLabel:SetTextColor(C.textMuted:GetRGBA())
    multiSelectLabel:Hide()
    SLV.multiSelectLabel = multiSelectLabel

    -- Re-render outline + detail rows when SpellValidator finishes revalidating
    if GRIPEMS.RegisterCallback then
        GRIPEMS.RegisterCallback(SLV, "SPELL_VALIDATION_UPDATED", "OnSpellValidationUpdated")
    end
end

---------------------------------------------------------------------------
-- Row initializer
---------------------------------------------------------------------------

--- Initialize or refresh a step row. ScrollBox reuses frames.
--- Handles both "step" rows (flat steps) and "node" rows (badge rows).
--- @param button Button The reusable row frame
--- @param data table { rowType, index, text, charCount } or { rowType, nodeType, ... }
function SLV:InitRow(button, data)
    local C = UI.Colors
    local defaults = D()

    -- Simplified Mode (Phase S2): propagate read-only flag to recycled rows.
    button._readOnly = SLV._allRowsReadOnly and true or false
    if button.dragHandle and button.dragHandle.SetShown then
        button.dragHandle:SetShown(not button._readOnly)
    end

    -- Node badge rows
    if data.rowType == "node" then
        button:SetHeight(defaults.NODE_BADGE_HEIGHT)

        -- One-time init for BackdropTemplate
        if not button.SetBackdrop then
            Mixin(button, BackdropTemplateMixin)
        end
        button:SetBackdrop(UI.Backdrops.panelNoBorder)
        button:EnableMouse(true)
        button:RegisterForClicks("LeftButtonUp", "RightButtonUp")

        -- Hide step-specific elements if they exist
        if button.stepNum then
            button.stepNum:Hide()
        end
        if button.stepText then
            button.stepText:Hide()
        end
        if button.charCount then
            button.charCount:Hide()
        end
        if button.modBadge then
            button.modBadge:Hide()
        end
        if button.stepLabel then
            button.stepLabel:Hide()
        end

        -- Lazy-create drag handle (shared with step rows)
        if not button.dragHandle then
            button.dragHandle = CreateFrame("Frame", nil, button)
            button.dragHandle:SetSize(defaults.STEP_DRAG_HANDLE_WIDTH, defaults.NODE_BADGE_HEIGHT)
            button.dragHandle:SetPoint("LEFT", button, "LEFT", 2, 0)
            for lineIdx = 1, 3 do
                local line = button.dragHandle:CreateTexture(nil, "ARTWORK")
                line:SetSize(8, 1)
                line:SetColorTexture(C.textMuted:GetRGBA())
                line:SetPoint("CENTER", button.dragHandle, "CENTER", 0, (lineIdx - 2) * 3)
            end
            button.dragHandle:EnableMouse(true)
            button.dragHandle:RegisterForDrag("LeftButton")
        end
        button.dragHandle:SetHeight(defaults.NODE_BADGE_HEIGHT)
        button.dragHandle:Show()

        -- Lazy-create node badge elements
        if not button._nodeIcon then
            local iconFrame = CreateFrame("Frame", nil, button, "BackdropTemplate")
            iconFrame:SetSize(18, 18)
            iconFrame:SetPoint("LEFT", button, "LEFT", 6 + defaults.STEP_DRAG_HANDLE_WIDTH, 0)
            local iconLabel = iconFrame:CreateFontString(nil, "OVERLAY")
            UI:SetFont(iconLabel, 11, "OUTLINE")
            iconLabel:SetPoint("CENTER")
            button._nodeIcon = iconFrame
            button._nodeIconLabel = iconLabel
        end
        -- Re-anchor icon after drag handle
        button._nodeIcon:ClearAllPoints()
        button._nodeIcon:SetPoint("LEFT", button.dragHandle, "RIGHT", 2, 0)

        if not button._nodeNameLabel then
            local nameFs = button:CreateFontString(nil, "OVERLAY")
            UI:SetFont(nameFs, 12)
            nameFs:SetPoint("LEFT", button._nodeIcon, "RIGHT", 6, 0)
            nameFs:SetJustifyH("LEFT")
            nameFs:SetWordWrap(false)
            button._nodeNameLabel = nameFs
        end
        if not button._nodeSummaryLabel then
            local sumFs = button:CreateFontString(nil, "OVERLAY")
            UI:SetFont(sumFs, 11)
            sumFs:SetPoint("LEFT", button._nodeNameLabel, "RIGHT", 8, 0)
            sumFs:SetPoint("RIGHT", button, "RIGHT", -24, 0)
            sumFs:SetJustifyH("LEFT")
            sumFs:SetWordWrap(false)
            button._nodeSummaryLabel = sumFs
        end
        if not button._nodeChevron then
            local chev = button:CreateFontString(nil, "OVERLAY")
            UI:SetFont(chev, 12)
            chev:SetPoint("RIGHT", button, "RIGHT", -6, 0)
            chev:SetText(">")
            button._nodeChevron = chev
        end
        if not button._nodeWarnBadge then
            local warn = button:CreateFontString(nil, "OVERLAY")
            UI:SetFont(warn, 13, "OUTLINE")
            warn:SetPoint("RIGHT", button._nodeChevron, "LEFT", -6, 0)
            button._nodeWarnBadge = warn
        end

        -- Show node elements
        button._nodeIcon:Show()
        button._nodeIconLabel:Show()
        button._nodeNameLabel:Show()
        button._nodeSummaryLabel:Show()
        button._nodeChevron:Show()

        -- Populate node badge
        local iconInfo = defaults.NODE_ICONS[data.nodeType] or defaults.NODE_ICONS["loop"]
        local iconColor = iconInfo.color
        UI:ApplyBackdrop(
            button._nodeIcon,
            UI.Backdrops.panel,
            CreateColor(iconColor[1], iconColor[2], iconColor[3], 0.3),
            CreateColor(iconColor[1], iconColor[2], iconColor[3], 0.6)
        )
        button._nodeIconLabel:SetText(iconInfo.symbol)
        button._nodeIconLabel:SetTextColor(iconColor[1], iconColor[2], iconColor[3], 1)

        local displayName = data.nodeName or ""
        if displayName == "" then
            displayName = iconInfo.label
        end
        if data.label and data.label ~= "" then
            displayName = "[" .. data.label .. "] " .. displayName
        end
        button._nodeNameLabel:SetText(displayName)
        if data.disabled then
            button._nodeNameLabel:SetTextColor(C.textMuted:GetRGBA())
        else
            button._nodeNameLabel:SetTextColor(C.textPrimary:GetRGBA())
        end

        button._nodeSummaryLabel:SetText(data.nodeSummary or "")
        if data.disabled then
            button._nodeSummaryLabel:SetTextColor(C.textMuted:GetRGBA())
        else
            button._nodeSummaryLabel:SetTextColor(C.textSecondary:GetRGBA())
        end

        button._nodeChevron:SetTextColor(C.textMuted:GetRGBA())

        -- Node-level spell validation badge
        local nodeSV = GRIPEMS.SpellValidator
        local nodeSC = GRIPEMS.SpellCache
        local warnLevel = nil
        if nodeSC and nodeSC.ready and nodeSV and data.node then
            warnLevel = nodeSV:NodeHasInvalidSpells(data.node)
        end
        if warnLevel == "error" then
            button._nodeWarnBadge:SetText("!!")
            button._nodeWarnBadge:SetTextColor(C.textError:GetRGBA())
            button._nodeWarnBadge:Show()
        elseif warnLevel == "warn" then
            button._nodeWarnBadge:SetText("!")
            button._nodeWarnBadge:SetTextColor(C.textWarning:GetRGBA())
            button._nodeWarnBadge:Show()
        else
            button._nodeWarnBadge:Hide()
        end
        -- Re-anchor summary label based on badge visibility
        button._nodeSummaryLabel:ClearAllPoints()
        button._nodeSummaryLabel:SetPoint("LEFT", button._nodeNameLabel, "RIGHT", 8, 0)
        if button._nodeWarnBadge:IsShown() then
            button._nodeSummaryLabel:SetPoint("RIGHT", button._nodeWarnBadge, "LEFT", -4, 0)
        else
            button._nodeSummaryLabel:SetPoint("RIGHT", button, "RIGHT", -24, 0)
        end

        -- Selection state for node badges
        local isSelected = (SLV._detailOpen and SLV._detailNodeIndex == data.nodeIndex)
        if isSelected then
            button:SetBackdropColor(C.bgRowSelected:GetRGBA())
        else
            button:SetBackdropColor(C.bgPanel:GetRGBA())
        end

        button._stepData = data

        -- Hover
        button:SetScript("OnEnter", function(self)
            if not isSelected then
                self:SetBackdropColor(C.bgRowHover:GetRGBA())
            end
            local sv = GRIPEMS.SpellValidator
            local sc = GRIPEMS.SpellCache
            if sc and sc.ready and sv and data.node then
                local _, invalids = sv:NodeHasInvalidSpells(data.node, nil, true)
                if invalids and #invalids > 0 then
                    anchorTooltipSmart(self)
                    local title = (data.nodeName ~= "" and data.nodeName) or iconInfo.label
                    GameTooltip:SetText(title, 1, 1, 1)
                    GameTooltip:AddLine(data.nodeSummary or "", 0.7, 0.7, 0.7, true)
                    GameTooltip:AddLine(" ")
                    for _, spell in ipairs(invalids) do
                        local fmt = (spell.status == D().SPELL_STATUS_UNKNOWN) and L["GEMS_SPELL_TOOLTIP_UNKNOWN"]
                            or L["GEMS_SPELL_TOOLTIP_KNOWN"]
                        GameTooltip:AddLine(string.format(fmt, spell.name), 1, 0.27, 0.27, true)
                    end
                    GameTooltip:Show()
                end
            end
        end)
        button:SetScript("OnLeave", function(self)
            if not isSelected then
                self:SetBackdropColor(C.bgPanel:GetRGBA())
            end
            GameTooltip:Hide()
        end)

        -- Click: left = open detail pane, right = context menu
        button:SetScript("OnClick", function(self, mouseButton)
            if mouseButton == "RightButton" then
                -- Simplified Mode (Phase S2): suppress context menu on read-only rows.
                if self._readOnly then
                    return
                end
                SLV:ShowNodeContextMenu(self, data)
            else
                SLV:OpenDetailPane(data.nodeIndex)
            end
        end)

        -- Drag scripts for outline reorder
        button.dragHandle:SetScript("OnEnter", function()
            if button:GetScript("OnEnter") then
                button:GetScript("OnEnter")(button)
            end
        end)
        button.dragHandle:SetScript("OnLeave", function()
            if button:GetScript("OnLeave") then
                button:GetScript("OnLeave")(button)
            end
        end)
        button.dragHandle:SetScript("OnDragStart", function()
            SLV:_beginOutlineDrag(button, data)
        end)
        button.dragHandle:SetScript("OnDragStop", function()
            SLV:_endOutlineDrag(button)
        end)
        button.dragHandle:SetScript("OnMouseUp", function(_, mouseButton)
            if not SLV._isDragging then
                button:GetScript("OnClick")(button, mouseButton)
            end
        end)

        return
    end

    -- Step rows (rowType == "step" or nil for backward compat)
    button:SetHeight(defaults.STEP_ROW_HEIGHT)

    -- Create child elements once
    if not button._gripInit then
        if not button.SetBackdrop then
            Mixin(button, BackdropTemplateMixin)
        end

        button:SetBackdrop(UI.Backdrops.panelNoBorder)
        button:EnableMouse(true)
        button:RegisterForClicks("LeftButtonUp", "RightButtonUp")

        -- Drag handle (grip icon: three horizontal lines)
        button.dragHandle = CreateFrame("Frame", nil, button)
        button.dragHandle:SetSize(D().STEP_DRAG_HANDLE_WIDTH, D().STEP_ROW_HEIGHT)
        button.dragHandle:SetPoint("LEFT", button, "LEFT", 2, 0)
        for lineIdx = 1, 3 do
            local line = button.dragHandle:CreateTexture(nil, "ARTWORK")
            line:SetSize(8, 1)
            line:SetColorTexture(C.textMuted:GetRGBA())
            line:SetPoint("CENTER", button.dragHandle, "CENTER", 0, (lineIdx - 2) * 3)
        end

        -- Step number (anchored to drag handle)
        button.stepNum = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(button.stepNum, 10)
        button.stepNum:SetPoint("LEFT", button.dragHandle, "RIGHT", 2, 0)
        button.stepNum:SetWidth(30)
        button.stepNum:SetJustifyH("LEFT")

        -- Optional step label (Phase 1C-bis, flat mode only, lazy-hidden)
        button.stepLabel = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(button.stepLabel, 10)
        button.stepLabel:SetJustifyH("LEFT")
        button.stepLabel:SetWordWrap(false)
        button.stepLabel:SetWidth(90)
        button.stepLabel:Hide()

        -- Step text
        button.stepText = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(button.stepText, 11)
        button.stepText:SetPoint("LEFT", button.stepNum, "RIGHT", 4, 0)
        button.stepText:SetPoint("RIGHT", button, "RIGHT", -55, 0)
        button.stepText:SetJustifyH("LEFT")
        button.stepText:SetWordWrap(false)

        -- Mod badge (between step text and char count)
        button.modBadge = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(button.modBadge, 9)
        button.modBadge:SetPoint("RIGHT", button, "RIGHT", -55, 0)
        button.modBadge:SetJustifyH("RIGHT")
        button.modBadge:SetTextColor(C.keybindGold:GetRGBA())
        button.modBadge:Hide()

        -- Char count
        button.charCount = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(button.charCount, 10)
        button.charCount:SetPoint("RIGHT", button, "RIGHT", -4, 0)
        button.charCount:SetJustifyH("RIGHT")

        -- Drag handle: mouse and drag registration (one-time setup)
        button.dragHandle:EnableMouse(true)
        button.dragHandle:RegisterForDrag("LeftButton")

        button._gripInit = true
    end

    -- Hide node badge elements if this frame was previously used for a node row
    if button._nodeIcon then
        button._nodeIcon:Hide()
    end
    if button._nodeIconLabel then
        button._nodeIconLabel:Hide()
    end
    if button._nodeNameLabel then
        button._nodeNameLabel:Hide()
    end
    if button._nodeSummaryLabel then
        button._nodeSummaryLabel:Hide()
    end
    if button._nodeChevron then
        button._nodeChevron:Hide()
    end

    -- Show step-specific elements
    if button.dragHandle then
        button.dragHandle:Show()
    end
    if button.stepNum then
        button.stepNum:Show()
    end
    if button.stepText then
        button.stepText:Show()
    end
    if button.charCount then
        button.charCount:Show()
    end

    -- Drag handle: data-dependent scripts (re-bound each InitRow call)
    button.dragHandle:SetScript("OnEnter", function()
        button:GetScript("OnEnter")(button)
    end)
    button.dragHandle:SetScript("OnLeave", function()
        button:GetScript("OnLeave")(button)
    end)
    button.dragHandle:SetScript("OnDragStart", function()
        SLV:_beginOutlineDrag(button, data)
    end)
    button.dragHandle:SetScript("OnDragStop", function()
        SLV:_endOutlineDrag(button)
    end)

    -- Click-through: non-drag clicks on handle pass to row for selection
    button.dragHandle:SetScript("OnMouseUp", function(_, mouseButton)
        if not SLV._isDragging then
            button:GetScript("OnClick")(button, mouseButton)
        end
    end)

    -- Populate
    button.stepNum:SetText(string.format(L["GEMS_UI_STEP_NUM"], data.index or 0))
    button.stepNum:SetTextColor(C.textSecondary:GetRGBA())

    -- Spell validation: color step number by validity.
    -- Defensive: data.text can be non-string under legacy SV
    -- corruption (see L1142 pattern). Coerce locally so the
    -- subsequent SV:ValidateStep call always receives a string.
    local SV = GRIPEMS.SpellValidator
    local SC = GRIPEMS.SpellCache
    local svText = type(data.text) == "string" and data.text or ""
    if SC and SC.ready and SV and svText ~= "" then
        local stepResult = SV:ValidateStep(svText)
        local hasUnknown, hasKnown, hasContextual = false, false, false
        for _, spell in ipairs(stepResult.spells) do
            if spell.status == D().SPELL_STATUS_UNKNOWN then
                hasUnknown = true
            elseif spell.status == D().SPELL_STATUS_KNOWN then
                hasKnown = true
            elseif spell.status == D().SPELL_STATUS_CONTEXTUAL then
                hasContextual = true
            end
        end
        if hasUnknown then
            button.stepNum:SetTextColor(C.textError:GetRGBA())
        elseif hasKnown then
            button.stepNum:SetTextColor(C.textWarning:GetRGBA())
        elseif hasContextual then
            button.stepNum:SetTextColor(C.textContextual:GetRGBA())
        end
    end

    local SC2 = GRIPEMS.SpellCache
    local displayText = (SC2 and SC2.StepToString) and SC2:StepToString(data.text)
        or (type(data.text) == "string" and data.text or "")
    local firstLine = displayText:match("^([^\n]*)") or displayText
    if SC2 and SC2.ready and SC2.ResolveSpellIDsInText then
        firstLine = SC2:ResolveSpellIDsInText(firstLine)
    end
    local SH = GRIPEMS.SyntaxHighlight
    if SH then
        firstLine = SH:ColorizeString(firstLine)
    end
    button.stepText:SetText(firstLine)
    if data.disabled then
        -- Disabled steps stay in the editor at their original position but are
        -- greyed and marked so it is obvious at a glance they are skipped.
        button.stepText:SetTextColor(C.textMuted:GetRGBA())
        button.stepText:SetText(L["GEMS_UI_STEP_DISABLED_PREFIX"] .. firstLine)
    else
        button.stepText:SetTextColor(C.textPrimary:GetRGBA())
    end

    -- Phase 1C-bis: optional step label badge + stepText LEFT re-anchor
    if button.stepLabel then
        if data.label and data.label ~= "" then
            button.stepLabel:ClearAllPoints()
            button.stepLabel:SetPoint("LEFT", button.stepNum, "RIGHT", 4, 0)
            button.stepLabel:SetText("[" .. data.label .. "]")
            button.stepLabel:SetTextColor(UI.Colors.textMuted:GetRGBA())
            button.stepLabel:Show()
            button.stepText:ClearAllPoints()
            button.stepText:SetPoint("LEFT", button.stepLabel, "RIGHT", 4, 0)
        else
            button.stepLabel:Hide()
            button.stepText:ClearAllPoints()
            button.stepText:SetPoint("LEFT", button.stepNum, "RIGHT", 4, 0)
        end
    end

    -- Mod pattern badge
    if button.modBadge then
        -- Defensive coercion: data.text can be a non-string from
        -- legacy SV corruption (table-shaped step bug class, closed
        -- v2.0.3 hotfix arc). The fallback `or ""` only catches nil/
        -- false; truthy non-strings (e.g. tables) pass through and
        -- crash :gmatch on the next line. Mirror the L1142-1143
        -- displayText defensive pattern.
        local rawText = type(data.text) == "string" and data.text or ""
        local mods = {}
        for mod in rawText:gmatch("%[mod:(%w+)") do
            mods[#mods + 1] = strupper(mod)
        end
        if #mods > 0 then
            local badgeText
            if #mods == 1 then
                badgeText = mods[1]
            elseif #mods == 2 then
                badgeText = mods[1] .. "+" .. mods[2]
            else
                badgeText = mods[1] .. "+" .. mods[2] .. "..."
            end
            button.modBadge:SetText(badgeText)
            button.modBadge:Show()
            -- Shrink step text right anchor to make room for badge
            button.stepText:SetPoint("RIGHT", button.modBadge, "LEFT", -4, 0)
        else
            button.modBadge:Hide()
            button.stepText:SetPoint("RIGHT", button, "RIGHT", -55, 0)
        end
    end

    local count = data.charCount or 0
    local kpCost = (SLV.keyPressLen or 0) > 0 and (SLV.keyPressLen + 1) or 0
    local krCost = (SLV.keyReleaseLen or 0) > 0 and (SLV.keyReleaseLen + 1) or 0
    local displayCount = count
    if kpCost > 0 or krCost > 0 then
        displayCount = count + kpCost + krCost
    end
    button.charCount:SetText(string.format("%d/%d", displayCount, defaults.CHAR_COUNT_DANGER))

    -- Color the char count based on thresholds (using effective cost)
    if displayCount >= defaults.CHAR_COUNT_DANGER then
        button.charCount:SetTextColor(C.textError:GetRGBA())
    elseif displayCount > defaults.CHAR_COUNT_WARNING then
        button.charCount:SetTextColor(C.textWarning:GetRGBA())
    else
        button.charCount:SetTextColor(C.textSuccess:GetRGBA())
    end

    -- Selection state
    local isSelected = SLV:IsRowSelected(data.index)
    if isSelected then
        button:SetBackdropColor(C.bgRowSelected:GetRGBA())
    elseif data.index and data.index % 2 == 0 then
        button:SetBackdropColor(C.bgPanel:GetRGBA())
    else
        button:SetBackdropColor(C.bgMain:GetRGBA())
    end

    -- Store data ref
    button._stepData = data

    -- Tooltip: native spell tooltip when possible, otherwise text fallback
    button:SetScript("OnEnter", function(self)
        if not isSelected then
            self:SetBackdropColor(C.bgRowHover:GetRGBA())
        end
        -- Defensive coercion: data.text can be non-string from legacy
        -- SV corruption (table-shaped step bug class). All downstream
        -- consumers in this handler (SV:ExtractAllSpells, SV:ValidateStep,
        -- tooltip body concat, UI:ShowTooltip) require a string.
        -- Mirror the L1184 mod-badge defensive pattern.
        local stepText = type(data.text) == "string" and data.text or ""
        if stepText == "" then
            return
        end

        -- Try to find a primary spell for native tooltip
        local nativeShown = false
        if SC and SC.ready and SV then
            local extracted = SV:ExtractAllSpells(stepText)
            if extracted and #extracted > 0 then
                local primaryName = extracted[1].name
                if primaryName and primaryName ~= "" then
                    -- Check if it is an item (starts with item: or recognized by cache)
                    local itemID = primaryName:match("^item:(%d+)")
                    if itemID then
                        if C_TooltipInfo and C_TooltipInfo.GetItemByID then
                            local info = C_TooltipInfo.GetItemByID(tonumber(itemID))
                            if info then
                                anchorTooltipSmart(self)
                                GameTooltip:ProcessInfo(info)
                                nativeShown = true
                            end
                        else
                            -- Fallback for pre-11.0 (safety)
                            anchorTooltipSmart(self)
                            GameTooltip:SetItemByID(tonumber(itemID))
                            nativeShown = true
                        end
                    else
                        local spellID = SC:GetSpellID(primaryName)
                        if spellID then
                            if C_TooltipInfo and C_TooltipInfo.GetSpellByID then
                                local info = C_TooltipInfo.GetSpellByID(spellID)
                                if info then
                                    anchorTooltipSmart(self)
                                    GameTooltip:ProcessInfo(info)
                                    nativeShown = true
                                end
                            else
                                -- Fallback for pre-11.0 (safety)
                                anchorTooltipSmart(self)
                                GameTooltip:SetSpellByID(spellID)
                                nativeShown = true
                            end
                        end
                    end
                end
            end

            -- Add keybind hint if native tooltip shown
            if nativeShown then
                local SE = GRIPEMS.SequenceEditor
                local KM = GRIPEMS.KeybindManager
                if SE and SE.currentSequence and KM then
                    local keyText = KM:GetKeybind(SE.currentSequence)
                    if keyText then
                        GameTooltip:AddLine(" ")
                        GameTooltip:AddLine(string.format(L["GEMS_UI_KEYBIND_TOOLTIP"], keyText), 1, 0.82, 0, true)
                    end
                end
            end

            -- Add validation warning lines
            local stepResult = SV:ValidateStep(stepText)
            local issues = {}
            local contextual = {}
            for _, spell in ipairs(stepResult.spells) do
                if spell.status == D().SPELL_STATUS_UNKNOWN then
                    issues[#issues + 1] = string.format(L["GEMS_SPELL_TOOLTIP_UNKNOWN"], spell.name)
                elseif spell.status == D().SPELL_STATUS_KNOWN then
                    issues[#issues + 1] = string.format(L["GEMS_SPELL_TOOLTIP_KNOWN"], spell.name)
                elseif spell.status == D().SPELL_STATUS_CONTEXTUAL then
                    contextual[#contextual + 1] = string.format(L["GEMS_SPELL_TOOLTIP_CONTEXTUAL"], spell.name)
                end
            end
            if nativeShown and (#issues > 0 or #contextual > 0) then
                GameTooltip:AddLine(" ")
                for _, issue in ipairs(issues) do
                    GameTooltip:AddLine(issue, 1, 0.27, 0.27, true)
                end
                if #contextual > 0 then
                    local ctxR, ctxG, ctxB = C.textContextual:GetRGBA()
                    for _, line in ipairs(contextual) do
                        GameTooltip:AddLine(line, ctxR, ctxG, ctxB, true)
                    end
                end
                GameTooltip:Show()
            elseif not nativeShown then
                local tooltipBody = stepText
                local extra = {}
                for _, issue in ipairs(issues) do
                    extra[#extra + 1] = issue
                end
                for _, line in ipairs(contextual) do
                    extra[#extra + 1] = line
                end
                if #extra > 0 then
                    tooltipBody = stepText .. "\n\n" .. table.concat(extra, "\n")
                end
                UI:ShowTooltip(self, string.format(L["GEMS_UI_STEP_NUM"], data.index or 0), tooltipBody)
            else
                GameTooltip:Show()
            end
        else
            UI:ShowTooltip(self, string.format(L["GEMS_UI_STEP_NUM"], data.index or 0), stepText)
        end
    end)
    button:SetScript("OnLeave", function(self)
        if not isSelected then
            if data.index and data.index % 2 == 0 then
                self:SetBackdropColor(C.bgPanel:GetRGBA())
            else
                self:SetBackdropColor(C.bgMain:GetRGBA())
            end
        end
        UI:HideTooltip()
    end)

    -- Click: select step or show context menu
    button:SetScript("OnClick", function(self, mouseButton)
        if mouseButton == "RightButton" then
            -- Simplified Mode (Phase S2): suppress context menu on read-only rows.
            if self._readOnly then
                return
            end
            SLV:ShowContextMenu(self, data)
        else
            if SLV.hasActions then
                SLV.selectedIndex = data.index
            else
                SLV:_HandleFlatSelectionClick(data.index)
            end
            SLV._lastLineCount = 0
            -- Macro-ref nodes have a read-only body -- inline editing is not
            -- a useful gesture, so a left-click on the row opens the detail
            -- pane instead. The detail pane is the only surface where the
            -- name (Change button) and drift indicator are reachable.
            if SLV.hasActions and data.nodeIndex and SLV.workingActions then
                local DD = GRIPEMS.Defaults
                local clickedNode = SLV.workingActions[data.nodeIndex]
                if
                    clickedNode
                    and clickedNode.type == DD.ACTION_TYPE_ACTION
                    and clickedNode.subtype == DD.ACTION_SUBTYPE_MACROREF
                then
                    SLV._editingContext = nil
                    if SLV.OpenDetailPane then
                        SLV:OpenDetailPane(data.nodeIndex)
                    end
                    return
                end
            end
            -- In outline mode, set editing context for action nodes
            if SLV.hasActions and data.nodeIndex then
                SLV._editingContext = {
                    source = "outline",
                    nodeIndex = data.nodeIndex,
                    label = string.format(L["GEMS_UI_STEP_HEADER"], data.index),
                }
            else
                SLV._editingContext = nil
            end
            if SLV.hasActions and SLV._detailOpen then
                SLV._detailOpen = false
                SLV._detailNavStack = nil
                SLV._detailNode = nil
                SLV._detailNodeIndex = nil
                SLV._detailSelectedChild = nil
                if SLV._detailContainer then
                    SLV._detailContainer:Hide()
                end
            end
            SLV:RefreshAll()
        end
    end)
end

---------------------------------------------------------------------------
-- Context menu for step rows
---------------------------------------------------------------------------

--- Show a right-click context menu for a step row.
--- @param button Button The row frame (menu anchor)
--- @param data table Row data { index, text, charCount }
function SLV:ShowContextMenu(button, data)
    if not data or not data.index then
        return
    end

    MenuUtil.CreateContextMenu(button, function(ownerRegion, rootDescription)
        -- Multi-select: when the right-clicked row is part of the selection,
        -- show bulk actions instead of the single-step menu.
        if SLV:IsMultiSelect() and SLV.selectedSet[data.index] then
            local selCount = #SLV:GetSelectionList()
            rootDescription:CreateButton(string.format(L["GEMS_UI_CTX_DUP_SELECTED"], selCount), function()
                SLV:DuplicateSelectedSteps()
            end)
            rootDescription:CreateDivider()
            rootDescription:CreateButton(
                "|cFFFF4444" .. string.format(L["GEMS_UI_CTX_DELETE_SELECTED"], selCount) .. "|r",
                function()
                    SLV:DeleteSelectedSteps()
                end
            )
            return
        end
        -- Right-clicking outside a multi-selection collapses it to that row.
        if SLV:IsMultiSelect() then
            SLV.selectedSet = nil
            SLV.selectedIndex = data.index
        end
        rootDescription:CreateButton(L["GEMS_UI_CTX_DUP_STEP"], function()
            if SLV.hasActions and SLV.workingActions and data.nodeIndex then
                local DD = GRIPEMS.Defaults
                local src = SLV.workingActions[data.nodeIndex]
                if src then
                    local copy = DD.DeepCopyActions({ src })[1]
                    table.insert(SLV.workingActions, data.nodeIndex + 1, copy)
                    SLV:_markDirty()
                    SLV:RefreshAll()
                end
            else
                SLV.selectedIndex = data.index
                SLV:DuplicateStep()
            end
        end)

        local moveUpBtn = rootDescription:CreateButton(L["GEMS_UI_CTX_MOVE_UP"], function()
            if SLV.hasActions and SLV.workingActions and data.nodeIndex then
                local ni = data.nodeIndex
                if ni > 1 then
                    SLV.workingActions[ni], SLV.workingActions[ni - 1] =
                        SLV.workingActions[ni - 1], SLV.workingActions[ni]
                    SLV:_markDirty()
                    SLV:RefreshAll()
                end
            else
                SLV.selectedIndex = data.index
                SLV:MoveStepUp()
            end
        end)
        moveUpBtn:SetEnabled(data.nodeIndex and data.nodeIndex > 1 or data.index > 1)

        local moveDownBtn = rootDescription:CreateButton(L["GEMS_UI_CTX_MOVE_DOWN"], function()
            if SLV.hasActions and SLV.workingActions and data.nodeIndex then
                local ni = data.nodeIndex
                if ni < #SLV.workingActions then
                    SLV.workingActions[ni], SLV.workingActions[ni + 1] =
                        SLV.workingActions[ni + 1], SLV.workingActions[ni]
                    SLV:_markDirty()
                    SLV:RefreshAll()
                end
            else
                SLV.selectedIndex = data.index
                SLV:MoveStepDown()
            end
        end)
        moveDownBtn:SetEnabled(
            (SLV.hasActions and SLV.workingActions and data.nodeIndex and data.nodeIndex < #SLV.workingActions)
                or (not SLV.hasActions and data.index < #SLV.workingSteps)
        )

        -- Per-step enable/disable toggle. On an action-model sequence this flips the
        -- node's disabled flag directly. On a flat (legacy) sequence it first converts
        -- to an action tree via _migrateToActions (undoable -- the same path the first
        -- IF/LOOP insertion uses), shows a one-time conversion note, then disables the
        -- new node. So the feature works on every sequence. Flipping true->nil keeps
        -- enabled nodes free of a disabled key.
        local rowIdx = (SLV.hasActions and data.nodeIndex) or data.index
        if rowIdx then
            local curNode = SLV.hasActions and SLV.workingActions and SLV.workingActions[data.nodeIndex]
            local lbl = (curNode and curNode.disabled) and L["GEMS_UI_CTX_ENABLE_STEP"] or L["GEMS_UI_CTX_DISABLE_STEP"]
            rootDescription:CreateButton(lbl, function()
                if not SLV.hasActions then
                    SLV:_migrateToActions()
                    if not SLV._stepDisableConvertNoticeShown then
                        SLV._stepDisableConvertNoticeShown = true
                        if GRIPEMS.Print then
                            GRIPEMS:Print(L["GEMS_UI_STEP_DISABLE_CONVERTED"])
                        end
                    end
                end
                local node = SLV.workingActions and SLV.workingActions[rowIdx]
                if node then
                    node.disabled = (not node.disabled) or nil
                    SLV:_markDirty()
                    SLV:RefreshAll()
                end
            end)
        end

        rootDescription:CreateDivider()

        rootDescription:CreateButton("|cFFFF4444" .. L["GEMS_UI_CTX_DELETE_STEP"] .. "|r", function()
            if SLV.hasActions and SLV.workingActions and data.nodeIndex then
                local ni = data.nodeIndex
                table.remove(SLV.workingActions, ni)
                if SLV._detailOpen and SLV._detailNodeIndex then
                    if SLV._detailNodeIndex == ni then
                        SLV:CloseDetailPane()
                    elseif SLV._detailNodeIndex > ni then
                        SLV._detailNodeIndex = SLV._detailNodeIndex - 1
                    end
                end
                SLV:_markDirty()
                SLV:RefreshAll()
            else
                SLV.selectedIndex = data.index
                SLV:DeleteStep()
            end
        end)
    end)
end

--- Right-click context menu for node badge rows in the outline view.
--- Provides duplicate, move up/down, and delete operations on action nodes.
--- @param button Button The row frame that was right-clicked
--- @param data table Row data with nodeIndex field
function SLV:ShowNodeContextMenu(button, data)
    if not data or not data.nodeIndex then
        return
    end
    local idx = data.nodeIndex
    MenuUtil.CreateContextMenu(button, function(ownerRegion, rootDescription)
        rootDescription:CreateButton(L["GEMS_UI_CTX_DUP_STEP"], function()
            if SLV.workingActions and SLV.workingActions[idx] then
                local DD = GRIPEMS.Defaults
                local copy = DD.DeepCopyActions({ SLV.workingActions[idx] })
                table.insert(SLV.workingActions, idx + 1, copy[1])
                SLV:_markDirty()
                SLV:RefreshAll()
            end
        end)

        local moveUpBtn = rootDescription:CreateButton(L["GEMS_UI_CTX_MOVE_UP"], function()
            if SLV.workingActions and idx > 1 then
                SLV.workingActions[idx], SLV.workingActions[idx - 1] =
                    SLV.workingActions[idx - 1], SLV.workingActions[idx]
                SLV:_markDirty()
                SLV:RefreshAll()
            end
        end)
        moveUpBtn:SetEnabled(idx > 1)

        local moveDownBtn = rootDescription:CreateButton(L["GEMS_UI_CTX_MOVE_DOWN"], function()
            if SLV.workingActions and idx < #SLV.workingActions then
                SLV.workingActions[idx], SLV.workingActions[idx + 1] =
                    SLV.workingActions[idx + 1], SLV.workingActions[idx]
                SLV:_markDirty()
                SLV:RefreshAll()
            end
        end)
        moveDownBtn:SetEnabled(SLV.workingActions and idx < #SLV.workingActions)

        rootDescription:CreateDivider()

        rootDescription:CreateButton("|cFFFF4444" .. L["GEMS_UI_CTX_DELETE_STEP"] .. "|r", function()
            if SLV.workingActions and SLV.workingActions[idx] then
                table.remove(SLV.workingActions, idx)
                if SLV._detailOpen and SLV._detailNodeIndex == idx then
                    SLV:CloseDetailPane()
                elseif SLV._detailOpen and SLV._detailNodeIndex > idx then
                    SLV._detailNodeIndex = SLV._detailNodeIndex - 1
                end
                SLV:_markDirty()
                SLV:RefreshAll()
            end
        end)
    end)
end

--- Right-click context menu for step rows nested inside a Loop / IF detail pane.
--- Mirrors ShowContextMenu but operates on the active detail node's children
--- array, wiring the existing _detailDupChild / _detailMoveChild /
--- _detailDeleteChild helpers plus an inline enable/disable toggle.
--- @param anchor Button The child row frame that was right-clicked
function SLV:ShowDetailChildContextMenu(anchor)
    if not SLV._detailNode or not SLV._detailSelectedChild then
        return
    end
    local defaults = D()
    local node = SLV._detailNode
    local idx = SLV._detailSelectedChild
    local children
    if node.type == defaults.ACTION_TYPE_IF then
        local branch = SLV._detailSelectedBranch or 1
        children = node.children and node.children[branch]
    else
        children = node.children
    end
    if not children or not children[idx] then
        return
    end
    MenuUtil.CreateContextMenu(anchor, function(_, rootDescription)
        rootDescription:CreateButton(L["GEMS_UI_CTX_DUP_STEP"], function()
            SLV:_detailDupChild()
        end)
        local upBtn = rootDescription:CreateButton(L["GEMS_UI_CTX_MOVE_UP"], function()
            SLV:_detailMoveChild(-1)
        end)
        upBtn:SetEnabled(idx > 1)
        local downBtn = rootDescription:CreateButton(L["GEMS_UI_CTX_MOVE_DOWN"], function()
            SLV:_detailMoveChild(1)
        end)
        downBtn:SetEnabled(idx < #children)
        local curChild = children[idx]
        local toggleLabel = (curChild and curChild.disabled) and L["GEMS_UI_CTX_ENABLE_STEP"]
            or L["GEMS_UI_CTX_DISABLE_STEP"]
        rootDescription:CreateButton(toggleLabel, function()
            local c = children[idx]
            if c then
                c.disabled = (not c.disabled) or nil
                SLV:_markDirty()
                SLV:_renderDetailPane()
                SLV:RefreshAll()
            end
        end)
        rootDescription:CreateDivider()
        rootDescription:CreateButton("|cFFFF4444" .. L["GEMS_UI_CTX_DELETE_STEP"] .. "|r", function()
            SLV:_detailDeleteChild()
        end)
    end)
end

---------------------------------------------------------------------------
-- Autocomplete menu
---------------------------------------------------------------------------

--- Show an autocomplete dropdown anchored below the EditBox.
--- Uses a create-once reusable frame with pooled button rows.
--- @param editBox EditBox The EditBox to anchor the dropdown to
--- @param matches table Array of { name, spellID, iconID } entries
--- @param wordStart number Start position of the word being completed
--- @param cursorPos number Cursor position when Tab was pressed
function SLV:ShowAutocompleteMenu(editBox, matches, wordStart, cursorPos)
    if not editBox or not matches or #matches == 0 then
        return
    end

    local C = UI.Colors
    local ROW_HEIGHT = 22

    -- Lazy-init: create the dropdown frame once
    local dropdown = SLV.autocompleteDropdown
    if not dropdown then
        dropdown = CreateFrame("Frame", "GRIPEMS_AutocompleteDropdown", UIParent, "BackdropTemplate")
        dropdown:SetFrameStrata("DIALOG")
        UI:ApplyBackdrop(dropdown, UI.Backdrops.panel, C.bgPanel, C.border)
        dropdown:SetClampedToScreen(true)
        dropdown:EnableKeyboard(true)
        dropdown:SetScript("OnKeyDown", function(self, key)
            if key == "ESCAPE" then
                self:Hide()
                pcall(self.SetPropagateKeyboardInput, self, false)
            else
                pcall(self.SetPropagateKeyboardInput, self, true)
            end
        end)
        dropdown._rows = {}
        SLV.autocompleteDropdown = dropdown
    end

    -- Hide all existing rows first
    for _, row in ipairs(dropdown._rows) do
        row:Hide()
    end

    -- Size the dropdown
    local ddWidth = math.max(editBox:GetWidth(), 200)
    dropdown:SetSize(ddWidth, #matches * ROW_HEIGHT)
    dropdown:ClearAllPoints()
    dropdown:SetPoint("TOPLEFT", SLV.editScrollFrame, "BOTTOMLEFT", 0, -2)

    -- Create or reuse button rows
    for i, match in ipairs(matches) do
        local row = dropdown._rows[i]
        if not row then
            row = CreateFrame("Button", nil, dropdown, "BackdropTemplate")
            row:SetBackdrop(UI.Backdrops.panelNoBorder)
            row:SetBackdropColor(0, 0, 0, 0)

            -- Icon texture
            row.icon = row:CreateTexture(nil, "ARTWORK")
            row.icon:SetSize(16, 16)
            row.icon:SetPoint("LEFT", row, "LEFT", 4, 0)

            -- Label
            row.label = row:CreateFontString(nil, "OVERLAY")
            UI:SetFont(row.label, 12)
            row.label:SetTextColor(C.textPrimary:GetRGBA())

            -- Hover highlight
            row:SetScript("OnEnter", function(self)
                self:SetBackdropColor(C.bgRowHover:GetRGBA())
            end)
            row:SetScript("OnLeave", function(self)
                self:SetBackdropColor(0, 0, 0, 0)
            end)

            dropdown._rows[i] = row
        end

        row:SetSize(ddWidth, ROW_HEIGHT)
        row:ClearAllPoints()
        row:SetPoint("TOPLEFT", dropdown, "TOPLEFT", 0, -((i - 1) * ROW_HEIGHT))

        -- Icon: show if match has iconID, hide otherwise
        if match.iconID then
            row.icon:SetTexture(match.iconID)
            row.icon:Show()
            row.label:SetPoint("LEFT", row.icon, "RIGHT", 4, 0)
        else
            row.icon:Hide()
            row.label:ClearAllPoints()
            row.label:SetPoint("LEFT", row, "LEFT", 4, 0)
        end
        row.label:SetText(match.name)

        -- OnClick: do text replacement, hide dropdown
        row:SetScript("OnClick", function()
            local text = editBox:GetText() or ""
            local SH = GRIPEMS.SyntaxHighlight
            if SH then
                text = SH:Strip(text)
            end
            local before = text:sub(1, wordStart - 1)
            local after = text:sub(cursorPos + 1)
            local insertion = match.name
            -- Macro commands get trailing space for convenience
            local firstCh = insertion:sub(1, 1)
            if (firstCh == "/" or firstCh == "#") and after == "" then
                insertion = insertion .. " "
            end
            local newText = before .. insertion .. after
            editBox._shBusy = true
            editBox:SetText(newText)
            editBox:SetCursorPosition(wordStart - 1 + #insertion)
            editBox._shBusy = false

            -- Update working copy and dirty state
            local idx = SLV.selectedIndex
            if idx then
                SLV.workingSteps[idx] = newText
                SLV:UpdateEditCharCount(#newText)
                local SE = GRIPEMS.SequenceEditor
                if SE then
                    SE.isDirty = true
                    SE:UpdateSaveButtons()
                end
                SLV:RefreshCurrentRow()
            end

            dropdown:Hide()
        end)

        row:Show()
    end

    dropdown:Show()
end

---------------------------------------------------------------------------
-- Variable autocomplete menu
---------------------------------------------------------------------------

--- Show a variable autocomplete dropdown (no icons, inserts ~name~).
--- Reuses the same dropdown frame as spell autocomplete.
--- @param editBox EditBox The EditBox to anchor the dropdown to
--- @param matches table Array of { name = string } entries
--- @param tildeStart number Position of the leading ~ (1-based)
--- @param cursorPos number Cursor position when Tab was pressed
function SLV:ShowVarAutocompleteMenu(editBox, matches, tildeStart, cursorPos)
    if not editBox or not matches or #matches == 0 then
        return
    end

    local C = UI.Colors
    local ROW_HEIGHT = 22

    -- Lazy-init: reuse the same dropdown frame
    local dropdown = SLV.autocompleteDropdown
    if not dropdown then
        dropdown = CreateFrame("Frame", "GRIPEMS_AutocompleteDropdown", UIParent, "BackdropTemplate")
        dropdown:SetFrameStrata("DIALOG")
        UI:ApplyBackdrop(dropdown, UI.Backdrops.panel, C.bgPanel, C.border)
        dropdown:SetClampedToScreen(true)
        dropdown:EnableKeyboard(true)
        dropdown:SetScript("OnKeyDown", function(self, key)
            if key == "ESCAPE" then
                self:Hide()
                pcall(self.SetPropagateKeyboardInput, self, false)
            else
                pcall(self.SetPropagateKeyboardInput, self, true)
            end
        end)
        dropdown._rows = {}
        SLV.autocompleteDropdown = dropdown
    end

    -- Hide all existing rows
    for _, row in ipairs(dropdown._rows) do
        row:Hide()
    end

    -- Size the dropdown
    local ddWidth = math.max(editBox:GetWidth(), 200)
    dropdown:SetSize(ddWidth, #matches * ROW_HEIGHT)
    dropdown:ClearAllPoints()
    dropdown:SetPoint("TOPLEFT", SLV.editScrollFrame, "BOTTOMLEFT", 0, -2)

    for i, match in ipairs(matches) do
        local row = dropdown._rows[i]
        if not row then
            row = CreateFrame("Button", nil, dropdown, "BackdropTemplate")
            row:SetBackdrop(UI.Backdrops.panelNoBorder)
            row:SetBackdropColor(0, 0, 0, 0)

            row.icon = row:CreateTexture(nil, "ARTWORK")
            row.icon:SetSize(16, 16)
            row.icon:SetPoint("LEFT", row, "LEFT", 4, 0)

            row.label = row:CreateFontString(nil, "OVERLAY")
            UI:SetFont(row.label, 12)
            row.label:SetTextColor(C.textPrimary:GetRGBA())

            row:SetScript("OnEnter", function(self)
                self:SetBackdropColor(C.bgRowHover:GetRGBA())
            end)
            row:SetScript("OnLeave", function(self)
                self:SetBackdropColor(0, 0, 0, 0)
            end)

            dropdown._rows[i] = row
        end

        row:SetSize(ddWidth, ROW_HEIGHT)
        row:ClearAllPoints()
        row:SetPoint("TOPLEFT", dropdown, "TOPLEFT", 0, -((i - 1) * ROW_HEIGHT))

        -- No icon for variable autocomplete
        row.icon:Hide()
        row.label:ClearAllPoints()
        row.label:SetPoint("LEFT", row, "LEFT", 4, 0)
        row.label:SetText("~" .. match.name .. "~")

        -- OnClick: replace from tildeStart to cursorPos with ~name~
        row:SetScript("OnClick", function()
            local text = editBox:GetText() or ""
            local SH = GRIPEMS.SyntaxHighlight
            if SH then
                text = SH:Strip(text)
            end
            local before = text:sub(1, tildeStart - 1)
            local after = text:sub(cursorPos + 1)
            local insertion = "~" .. match.name .. "~"
            local newText = before .. insertion .. after
            editBox._shBusy = true
            editBox:SetText(newText)
            editBox:SetCursorPosition(tildeStart - 1 + #insertion)
            editBox._shBusy = false

            -- Update working copy and dirty state
            local idx = SLV.selectedIndex
            if idx then
                SLV.workingSteps[idx] = newText
                SLV:UpdateEditCharCount(#newText)
                local SE = GRIPEMS.SequenceEditor
                if SE then
                    SE.isDirty = true
                    SE:UpdateSaveButtons()
                end
                SLV:RefreshCurrentRow()
            end

            dropdown:Hide()
        end)

        row:Show()
    end

    dropdown:Show()
end

---------------------------------------------------------------------------
-- Sequence name autocomplete (fallback when spell/command has 0 matches)
---------------------------------------------------------------------------

--- Search Engine.sequences for names starting with prefix (case-insensitive).
--- @param prefix string The prefix to match against sequence names
--- @return table Array of { name = string } sorted alphabetically
function SLV:SearchSequenceNames(prefix)
    local Engine = GRIPEMS.Engine
    if not Engine or not Engine.sequences then
        return {}
    end
    local results = {}
    local lowerPrefix = prefix:lower()
    for seqName in pairs(Engine.sequences) do
        if seqName:lower():sub(1, #lowerPrefix) == lowerPrefix then
            results[#results + 1] = { name = seqName }
        end
    end
    table.sort(results, function(a, b)
        return a.name < b.name
    end)
    if #results > D().AUTOCOMPLETE_MAX_RESULTS then
        local trimmed = {}
        for i = 1, D().AUTOCOMPLETE_MAX_RESULTS do
            trimmed[i] = results[i]
        end
        results = trimmed
    end
    return results
end

--- Show a sequence name autocomplete dropdown with section header.
--- Inserts "/click GRIPEMS_<name>" replacing the typed word.
--- @param editBox EditBox The EditBox to anchor the dropdown to
--- @param matches table Array of { name = string } entries
--- @param wordStart number Start position of the word being replaced (1-based)
--- @param cursorPos number Cursor position when Tab was pressed
function SLV:ShowSeqAutocompleteMenu(editBox, matches, wordStart, cursorPos)
    if not editBox or not matches or #matches == 0 then
        return
    end

    local C = UI.Colors
    local ROW_HEIGHT = 22

    -- Lazy-init: reuse the same dropdown frame
    local dropdown = SLV.autocompleteDropdown
    if not dropdown then
        dropdown = CreateFrame("Frame", "GRIPEMS_AutocompleteDropdown", UIParent, "BackdropTemplate")
        dropdown:SetFrameStrata("DIALOG")
        UI:ApplyBackdrop(dropdown, UI.Backdrops.panel, C.bgPanel, C.border)
        dropdown:SetClampedToScreen(true)
        dropdown:EnableKeyboard(true)
        dropdown:SetScript("OnKeyDown", function(self, key)
            if key == "ESCAPE" then
                self:Hide()
                pcall(self.SetPropagateKeyboardInput, self, false)
            else
                pcall(self.SetPropagateKeyboardInput, self, true)
            end
        end)
        dropdown._rows = {}
        SLV.autocompleteDropdown = dropdown
    end

    -- Hide all existing rows
    for _, row in ipairs(dropdown._rows) do
        row:Hide()
    end

    -- Total rows = 1 header + N matches
    local totalRows = 1 + #matches
    local ddWidth = math.max(editBox:GetWidth(), 200)
    dropdown:SetSize(ddWidth, totalRows * ROW_HEIGHT)
    dropdown:ClearAllPoints()
    dropdown:SetPoint("TOPLEFT", SLV.editScrollFrame, "BOTTOMLEFT", 0, -2)

    -- Row 1: non-clickable section header
    local headerRow = dropdown._rows[1]
    if not headerRow then
        headerRow = CreateFrame("Button", nil, dropdown, "BackdropTemplate")
        headerRow:SetBackdrop(UI.Backdrops.panelNoBorder)
        headerRow:SetBackdropColor(0, 0, 0, 0)

        headerRow.icon = headerRow:CreateTexture(nil, "ARTWORK")
        headerRow.icon:SetSize(16, 16)
        headerRow.icon:SetPoint("LEFT", headerRow, "LEFT", 4, 0)

        headerRow.label = headerRow:CreateFontString(nil, "OVERLAY")
        UI:SetFont(headerRow.label, 12)
        headerRow.label:SetTextColor(C.textPrimary:GetRGBA())

        headerRow:SetScript("OnEnter", function(self)
            self:SetBackdropColor(0, 0, 0, 0)
        end)
        headerRow:SetScript("OnLeave", function(self)
            self:SetBackdropColor(0, 0, 0, 0)
        end)

        dropdown._rows[1] = headerRow
    end
    headerRow:SetSize(ddWidth, ROW_HEIGHT)
    headerRow:ClearAllPoints()
    headerRow:SetPoint("TOPLEFT", dropdown, "TOPLEFT", 0, 0)
    headerRow.icon:Hide()
    headerRow.label:ClearAllPoints()
    headerRow.label:SetPoint("LEFT", headerRow, "LEFT", 4, 0)
    headerRow.label:SetText(L["GEMS_AUTOCOMPLETE_SEQUENCES"])
    headerRow.label:SetTextColor(C.textSecondary:GetRGBA())
    headerRow:SetScript("OnClick", nil)
    headerRow:EnableMouse(false)
    headerRow:Show()

    -- Rows 2..N+1: clickable sequence entries
    for i, match in ipairs(matches) do
        local rowIdx = i + 1
        local row = dropdown._rows[rowIdx]
        if not row then
            row = CreateFrame("Button", nil, dropdown, "BackdropTemplate")
            row:SetBackdrop(UI.Backdrops.panelNoBorder)
            row:SetBackdropColor(0, 0, 0, 0)

            row.icon = row:CreateTexture(nil, "ARTWORK")
            row.icon:SetSize(16, 16)
            row.icon:SetPoint("LEFT", row, "LEFT", 4, 0)

            row.label = row:CreateFontString(nil, "OVERLAY")
            UI:SetFont(row.label, 12)
            row.label:SetTextColor(C.textPrimary:GetRGBA())

            row:SetScript("OnEnter", function(self)
                self:SetBackdropColor(C.bgRowHover:GetRGBA())
            end)
            row:SetScript("OnLeave", function(self)
                self:SetBackdropColor(0, 0, 0, 0)
            end)

            dropdown._rows[rowIdx] = row
        end

        row:EnableMouse(true)
        row:SetSize(ddWidth, ROW_HEIGHT)
        row:ClearAllPoints()
        row:SetPoint("TOPLEFT", dropdown, "TOPLEFT", 0, -((rowIdx - 1) * ROW_HEIGHT))

        -- Macro scroll icon
        row.icon:SetTexture(D().AUTOCOMPLETE_SEQ_ICON)
        row.icon:Show()
        row.label:ClearAllPoints()
        row.label:SetPoint("LEFT", row.icon, "RIGHT", 4, 0)
        row.label:SetTextColor(C.textPrimary:GetRGBA())
        row.label:SetText(match.name)

        -- OnClick: replace word with /click GRIPEMS_<name>
        row:SetScript("OnClick", function()
            local text = editBox:GetText() or ""
            local SH = GRIPEMS.SyntaxHighlight
            if SH then
                text = SH:Strip(text)
            end
            local before = text:sub(1, wordStart - 1)
            local after = text:sub(cursorPos + 1)
            local insertion = format(L["GEMS_AUTOCOMPLETE_CLICK_INSERT"], match.name)
            local newText = before .. insertion .. after
            editBox._shBusy = true
            editBox:SetText(newText)
            editBox:SetCursorPosition(wordStart - 1 + #insertion)
            editBox._shBusy = false

            -- Update working copy and dirty state
            local idx = SLV.selectedIndex
            if idx then
                SLV.workingSteps[idx] = newText
                SLV:UpdateEditCharCount(#newText)
                local SE = GRIPEMS.SequenceEditor
                if SE then
                    SE.isDirty = true
                    SE:UpdateSaveButtons()
                end
                SLV:RefreshCurrentRow()
            end

            dropdown:Hide()
        end)

        row:Show()
    end

    dropdown:Show()
end

---------------------------------------------------------------------------
-- Live-filter autocomplete (called from OnTextChanged)
---------------------------------------------------------------------------

--- Re-filter the autocomplete dropdown while the user types.
--- Called from OnTextChanged when the dropdown is already visible.
--- Hides the dropdown if the word shrinks below min chars or no matches.
--- @param editBox EditBox The EditBox being edited
function SLV:RefreshAutocomplete(editBox)
    if not SLV.autocompleteDropdown or not SLV.autocompleteDropdown:IsShown() then
        return
    end

    local SC = GRIPEMS.SpellCache
    if not SC or not SC.ready then
        SLV.autocompleteDropdown:Hide()
        return
    end

    local word, wordStart, cursorPos = extractWordUnderCursor(editBox)
    local firstChar = word:sub(1, 1)
    local isCommand = (firstChar == "/" or firstChar == "#")
    local minChars = isCommand and D().AUTOCOMPLETE_MIN_CHARS or D().AUTOCOMPLETE_MIN_SPELL_CHARS

    if #word < minChars then
        SLV.autocompleteDropdown:Hide()
        return
    end

    local matches
    if isCommand then
        matches = SC:MacroCommandSearch(word, D().AUTOCOMPLETE_MAX_RESULTS)
    else
        matches = SC:PrefixSearch(word, D().AUTOCOMPLETE_MAX_RESULTS)
    end

    if #matches == 0 then
        SLV.autocompleteDropdown:Hide()
        return
    end

    -- Re-populate the dropdown with updated matches
    SLV:ShowAutocompleteMenu(editBox, matches, wordStart, cursorPos)
end

---------------------------------------------------------------------------
-- Data flow methods
---------------------------------------------------------------------------

--- Load an array of step strings into the step list.
--- Deep-copies into workingSteps and originalSteps.
--- Optional second parameter enables tree mode when actions are present.
--- @param steps table|nil Array of macro text strings
--- @param actions table|nil Array of action tree nodes (v1.2.0 S14-B)
function SLV:LoadSteps(steps, actions, stepLabels)
    if not SLV.scrollView then
        return
    end

    local US = GRIPEMS.UndoStack
    if US then
        US:Clear()
    end

    SLV.workingSteps = {}
    SLV.originalSteps = {}
    SLV.workingStepLabels = {}
    SLV.originalStepLabels = {}
    SLV.selectedIndex = nil
    SLV.selectedSet = nil
    SLV.selectionAnchor = nil
    SLV._lastLineCount = 0
    SLV._undoTextSnapshot = nil
    SLV._undoTextSnapshotIdx = nil
    SLV._preEditText = nil

    -- Reset detail pane state before loading
    SLV._detailOpen = false
    SLV._detailNavStack = nil
    SLV._detailNode = nil
    SLV._detailNodeIndex = nil
    SLV._detailSelectedChild = nil
    SLV._detailSelectedBranch = nil
    SLV._editingContext = nil
    if SLV._detailContainer then
        SLV._detailContainer:Hide()
    end

    if steps then
        for i, step in ipairs(steps) do
            SLV.workingSteps[i] = step
            SLV.originalSteps[i] = step
        end
        if stepLabels then
            for i = 1, #steps do
                SLV.workingStepLabels[i] = stepLabels[i]
                SLV.originalStepLabels[i] = stepLabels[i]
            end
        end
    end

    -- Actions render in outline + detail pane mode.
    SLV.treeMode = false
    if actions and #actions > 0 then
        SLV.hasActions = true
        SLV.workingActions = D().DeepCopyActions(actions)
        SLV._originalActionsSerialized = SLV:_serializeActions(actions)
    else
        SLV.hasActions = false
        SLV.workingActions = nil
        SLV._originalActionsSerialized = nil
    end

    SLV:RefreshAll()
end

--- Return the current edited steps array (always flat).
--- @return table workingSteps
function SLV:GetWorkingSteps()
    return SLV.workingSteps
end

--- Return the current working actions array (nil if flat mode).
--- @return table|nil workingActions
function SLV:GetWorkingActions()
    return SLV.workingActions
end

--- Return the current working step labels array (Phase 1C-bis, flat mode).
--- @return table workingStepLabels
function SLV:GetWorkingStepLabels()
    return SLV.workingStepLabels
end

--- Compare working steps/actions against original to detect changes.
--- @return boolean hasChanges
function SLV:HasChanges()
    -- Migration detection: if original was flat but working copy is now actions
    if SLV.hasActions and not SLV._originalActionsSerialized then
        return true
    end
    if #SLV.workingSteps ~= #SLV.originalSteps then
        return true
    end
    for i = 1, #SLV.workingSteps do
        if SLV.workingSteps[i] ~= SLV.originalSteps[i] then
            return true
        end
    end
    if SLV.hasActions and SLV.workingActions then
        local cur = SLV:_serializeActions(SLV.workingActions)
        if cur ~= SLV._originalActionsSerialized then
            return true
        end
    end
    for i = 1, math.max(#SLV.workingStepLabels, #SLV.originalStepLabels) do
        if (SLV.workingStepLabels[i] or "") ~= (SLV.originalStepLabels[i] or "") then
            return true
        end
    end
    return false
end

--- Serialize an actions array to a string for comparison.
--- Simple recursive key-sorted serialization.
--- @param actions table Action node array
--- @return string Serialized string
function SLV:_serializeActions(actions)
    if not actions then
        return ""
    end
    local parts = {}
    for _, node in ipairs(actions) do
        parts[#parts + 1] = SLV:_serializeNode(node)
    end
    return table.concat(parts, "|")
end

--- Serialize a single action node to a string.
--- @param node table Action node
--- @return string Serialized string
function SLV:_serializeNode(node)
    if not node or not node.type then
        return ""
    end
    local parts = { node.type }
    if node.name and node.name ~= "" then
        parts[#parts + 1] = "n=" .. node.name
    end
    if node.label and node.label ~= "" then
        parts[#parts + 1] = "lbl=" .. node.label
    end
    if node.macro then
        parts[#parts + 1] = node.macro
    end
    if node["repeat"] then
        parts[#parts + 1] = "r=" .. tostring(node["repeat"])
    end
    if node.stepFunction then
        parts[#parts + 1] = "sf=" .. node.stepFunction
    end
    if node.variable then
        parts[#parts + 1] = "v=" .. node.variable
    end
    if node.sequence then
        parts[#parts + 1] = "s=" .. node.sequence
    end
    if node.clicks then
        parts[#parts + 1] = "c=" .. tostring(node.clicks)
    end
    if node.ms then
        parts[#parts + 1] = "ms=" .. tostring(node.ms)
    end
    if node.gcd then
        parts[#parts + 1] = "gcd=" .. tostring(node.gcd)
    end
    if node.children then
        if node.type == D().ACTION_TYPE_IF then
            parts[#parts + 1] = "t{" .. SLV:_serializeActions(node.children[1] or {}) .. "}"
            parts[#parts + 1] = "f{" .. SLV:_serializeActions(node.children[2] or {}) .. "}"
        else
            parts[#parts + 1] = "ch{" .. SLV:_serializeActions(node.children) .. "}"
        end
    end
    return table.concat(parts, ";")
end

--- Rebuild DataProvider, update button states, update edit area.
function SLV:RefreshAll()
    if SLV.autocompleteDropdown then
        SLV.autocompleteDropdown:Hide()
    end
    if not SLV.scrollView then
        return
    end

    -- Overlap guard (Discord 1522268637098938622): RefreshAll runs from
    -- sequence load, editor save, and version switches, which can fire while
    -- another editor tab is active. Rebuild data and anchors as usual, but
    -- only assert widget VISIBILITY when the Steps tab owns the content
    -- area. SE:UpdateTabContent re-asserts visibility on Steps-tab return.
    local SEd = GRIPEMS.SequenceEditor
    local onStepsTab = not SEd or SEd.activeTab == "Steps"

    -- Outline + Detail pane mode (replaces S30-BUG-03 split-pane)
    local defaults = D()
    if SLV.hasActions and SLV.workingActions then
        -- Build outline from top-level actions
        local dp = CreateDataProvider()
        local stepCounter = 0
        for i, node in ipairs(SLV.workingActions) do
            if node.type == defaults.ACTION_TYPE_ACTION then
                stepCounter = stepCounter + 1
                local rowText
                if node.subtype == defaults.ACTION_SUBTYPE_MACROREF then
                    rowText = "[M] " .. (node.macroName or "")
                else
                    rowText = node.macro or ""
                end
                dp:Insert({
                    rowType = "step",
                    index = stepCounter,
                    text = rowText,
                    charCount = #(node.macro or ""),
                    nodeIndex = i,
                    label = node.label,
                    disabled = node.disabled,
                })
            else
                dp:Insert({
                    rowType = "node",
                    nodeType = node.type,
                    nodeName = node.name or "",
                    nodeSummary = defaults.NodeSummary(node),
                    nodeIndex = i,
                    node = node,
                    label = node.label,
                    disabled = node.disabled,
                })
            end
        end
        SLV.scrollBox:SetDataProvider(dp, ScrollBoxConstants.RetainScrollPosition)
        SLV.dataProvider = dp

        if stepCounter > 0 or #SLV.workingActions > 0 then
            if SLV.emptyIcon then
                SLV.emptyIcon:Hide()
            end
            if SLV.emptyLabel then
                SLV.emptyLabel:Hide()
            end
            if SLV.hintLabel then
                SLV.hintLabel:Hide()
            end
        elseif onStepsTab then
            if SLV.emptyIcon then
                SLV.emptyIcon:Show()
            end
            if SLV.emptyLabel then
                SLV.emptyLabel:Show()
            end
            if SLV.hintLabel then
                SLV.hintLabel:Show()
            end
        end

        -- Full-width scrollBox (no split pane) unless detail pane is open
        if SLV._detailOpen then
            SLV.scrollBox:ClearAllPoints()
            SLV.scrollBox:SetPoint("TOPLEFT", SLV.container, "TOPLEFT", 4, -4)
            SLV.scrollBox:SetPoint("BOTTOM", SLV.actionBar, "TOP", 0, 4)
            SLV.scrollBox:SetPoint("RIGHT", SLV.container, "CENTER", -8, 0)
            SLV.scrollBar:ClearAllPoints()
            SLV.scrollBar:SetPoint("TOPLEFT", SLV.scrollBox, "TOPRIGHT", 2, 0)
            SLV.scrollBar:SetPoint("BOTTOMLEFT", SLV.scrollBox, "BOTTOMRIGHT", 2, 0)
        else
            SLV.scrollBox:ClearAllPoints()
            SLV.scrollBox:SetPoint("TOPLEFT", SLV.container, "TOPLEFT", 4, -4)
            SLV.scrollBox:SetPoint("RIGHT", SLV.container, "RIGHT", -18, 0)
            SLV.scrollBox:SetPoint("BOTTOM", SLV.actionBar, "TOP", 0, 4)
            SLV.scrollBar:ClearAllPoints()
            SLV.scrollBar:SetPoint("TOPLEFT", SLV.scrollBox, "TOPRIGHT", 2, 0)
            SLV.scrollBar:SetPoint("BOTTOMLEFT", SLV.scrollBox, "BOTTOMRIGHT", 2, 0)
        end

        -- If detail pane is open, re-render it
        if SLV._detailOpen and SLV._detailNodeIndex then
            SLV:_renderDetailPane()
        end
    else
        -- Flat mode (no actions): UNCHANGED behavior
        local dp = CreateDataProvider()
        if #SLV.workingSteps > 0 then
            for i, step in ipairs(SLV.workingSteps) do
                dp:Insert({
                    rowType = "step",
                    index = i,
                    text = step,
                    charCount = #step,
                    label = SLV.workingStepLabels[i],
                })
            end
            if SLV.emptyIcon then
                SLV.emptyIcon:Hide()
            end
            if SLV.emptyLabel then
                SLV.emptyLabel:Hide()
            end
            if SLV.hintLabel then
                SLV.hintLabel:Hide()
            end
        elseif onStepsTab then
            if SLV.emptyIcon then
                SLV.emptyIcon:Show()
            end
            if SLV.emptyLabel then
                SLV.emptyLabel:Show()
            end
            if SLV.hintLabel then
                SLV.hintLabel:Show()
            end
        end
        SLV.scrollBox:SetDataProvider(dp, ScrollBoxConstants.RetainScrollPosition)
        SLV.dataProvider = dp

        -- Full width flat mode (original anchors)
        SLV.scrollBox:ClearAllPoints()
        SLV.scrollBox:SetPoint("TOPLEFT", SLV.container, "TOPLEFT", 4, -4)
        SLV.scrollBox:SetPoint("RIGHT", SLV.container, "RIGHT", -18, 0)
        SLV.scrollBox:SetPoint("BOTTOM", SLV.actionBar, "TOP", 0, 4)
        SLV.scrollBar:ClearAllPoints()
        SLV.scrollBar:SetPoint("TOPLEFT", SLV.scrollBox, "TOPRIGHT", 2, 0)
        SLV.scrollBar:SetPoint("BOTTOMLEFT", SLV.scrollBox, "BOTTOMRIGHT", 2, 0)
    end

    -- Show flat mode UI elements (only while the Steps tab is active)
    if onStepsTab and SLV.scrollBox then
        SLV.scrollBox:Show()
    end
    if onStepsTab and SLV.scrollBar then
        SLV.scrollBar:Show()
    end

    -- Update action button states
    SLV:UpdateButtonStates()

    -- Update edit area
    SLV:UpdateEditArea()
end

--- Re-evaluate outline row validation badges and detail pane after
--- SpellValidator fires SPELL_VALIDATION_UPDATED. Does not rebuild the
--- data provider (avoids re-triggering validation); uses ForEachFrame to
--- re-run InitRow on visible rows only.
function SLV:OnSpellValidationUpdated()
    if not SLV.scrollView then
        return
    end
    if SLV.scrollBox and SLV.dataProvider and SLV.scrollBox.ForEachFrame then
        SLV.scrollBox:ForEachFrame(function(frame, elementData)
            if frame and elementData then
                SLV:InitRow(frame, elementData)
            end
        end)
    end
    if SLV._detailOpen and SLV._detailNodeIndex then
        SLV:_renderDetailPane()
    end
end

---------------------------------------------------------------------------
-- Detail Pane (Outline + Detail pattern)
---------------------------------------------------------------------------

--- Lazy-create the detail pane container and its sub-frames.
--- Idempotent: creates once, reuses on subsequent calls.
function SLV:_ensureDetailPane()
    if SLV._detailContainer then
        return
    end

    local C = UI.Colors

    -- Main container (anchored to right half of SLV.container)
    local container = CreateFrame("Frame", nil, SLV.container, "BackdropTemplate")
    UI:ApplyBackdrop(container, UI.Backdrops.panel, C.bgMain, C.border)
    container:Hide()
    SLV._detailContainer = container

    -- Header: breadcrumb + close button
    local header = CreateFrame("Frame", nil, container)
    header:SetHeight(24)
    header:SetPoint("TOPLEFT", container, "TOPLEFT", 0, 0)
    header:SetPoint("TOPRIGHT", container, "TOPRIGHT", 0, 0)
    SLV._detailHeader = header

    local closeBtn = UI:CreateButton(header, "X", 22, 20)
    closeBtn:SetPoint("TOPRIGHT", header, "TOPRIGHT", -2, -2)
    closeBtn:SetScript("OnClick", function()
        SLV:CloseDetailPane()
    end)
    SLV._detailCloseBtn = closeBtn

    -- Breadcrumb container
    local breadcrumb = CreateFrame("Frame", nil, header)
    breadcrumb:SetPoint("TOPLEFT", header, "TOPLEFT", 4, -2)
    breadcrumb:SetPoint("RIGHT", closeBtn, "LEFT", -4, 0)
    breadcrumb:SetHeight(20)
    SLV._detailBreadcrumb = breadcrumb

    -- Settings bar (below header)
    local settings = CreateFrame("Frame", nil, container)
    settings:SetHeight(30)
    settings:SetPoint("TOPLEFT", header, "BOTTOMLEFT", 0, 0)
    settings:SetPoint("TOPRIGHT", header, "BOTTOMRIGHT", 0, 0)
    SLV._detailSettings = settings

    -- ScrollPanel for children list
    local scrollFrame, scrollChild = UI:CreateScrollPanel(container, 400)
    scrollFrame:SetPoint("TOPLEFT", settings, "BOTTOMLEFT", 2, -2)
    scrollFrame:SetPoint("BOTTOMRIGHT", container, "BOTTOMRIGHT", -4, 32)
    scrollFrame:SetScript("OnSizeChanged", function(self)
        local w = self:GetWidth() - 20
        if w > 0 then
            scrollChild:SetWidth(w)
        end
    end)
    SLV._detailScrollFrame = scrollFrame
    SLV._detailScrollChild = scrollChild

    -- Bottom toolbar
    local toolbar = CreateFrame("Frame", nil, container)
    toolbar:SetHeight(28)
    toolbar:SetPoint("BOTTOMLEFT", container, "BOTTOMLEFT", 0, 2)
    toolbar:SetPoint("BOTTOMRIGHT", container, "BOTTOMRIGHT", 0, 2)
    SLV._detailToolbar = toolbar

    local addBtn = UI:CreateButton(toolbar, "+ Add", 50, 22)
    addBtn:SetPoint("LEFT", toolbar, "LEFT", 4, 0)
    addBtn:SetScript("OnClick", function(self)
        SLV:_showAddMenu(self, true)
    end)

    local dupBtn = UI:CreateButton(toolbar, "Dup", 40, 22)
    dupBtn:SetPoint("LEFT", addBtn, "RIGHT", 2, 0)
    dupBtn:SetScript("OnClick", function()
        SLV:_detailDupChild()
    end)

    local upBtn = UI:CreateButton(toolbar, "Up", 32, 22)
    upBtn:SetPoint("LEFT", dupBtn, "RIGHT", 2, 0)
    upBtn:SetScript("OnClick", function()
        SLV:_detailMoveChild(-1)
    end)

    local downBtn = UI:CreateButton(toolbar, "Down", 42, 22)
    downBtn:SetPoint("LEFT", upBtn, "RIGHT", 2, 0)
    downBtn:SetScript("OnClick", function()
        SLV:_detailMoveChild(1)
    end)

    local delBtn = UI:CreateButton(toolbar, "Del", 36, 22)
    delBtn:SetPoint("LEFT", downBtn, "RIGHT", 2, 0)
    delBtn:SetScript("OnClick", function()
        SLV:_detailDeleteChild()
    end)

    SLV._detailToolbarButtons = {
        add = addBtn,
        dup = dupBtn,
        up = upBtn,
        down = downBtn,
        del = delBtn,
    }
end

--- Open the detail pane for a node at the given index in workingActions.
--- @param nodeIndex number Index in SLV.workingActions
function SLV:OpenDetailPane(nodeIndex)
    if not SLV.workingActions or not SLV.workingActions[nodeIndex] then
        return
    end

    SLV._detailOpen = true
    SLV._detailNavStack = {}
    SLV._detailNodeIndex = nodeIndex
    SLV._detailNode = SLV.workingActions[nodeIndex]
    SLV._detailSelectedChild = nil
    SLV._editingContext = nil
    SLV.selectedIndex = nil

    SLV:_ensureDetailPane()

    -- Shrink outline scrollBox to left half via live anchor (right edge at container CENTER)
    SLV.scrollBox:ClearAllPoints()
    SLV.scrollBox:SetPoint("TOPLEFT", SLV.container, "TOPLEFT", 4, -4)
    SLV.scrollBox:SetPoint("BOTTOM", SLV.actionBar, "TOP", 0, 4)
    SLV.scrollBox:SetPoint("RIGHT", SLV.container, "CENTER", -8, 0)
    SLV.scrollBar:ClearAllPoints()
    SLV.scrollBar:SetPoint("TOPLEFT", SLV.scrollBox, "TOPRIGHT", 2, 0)
    SLV.scrollBar:SetPoint("BOTTOMLEFT", SLV.scrollBox, "BOTTOMRIGHT", 2, 0)

    -- Show and anchor detail pane to track scrollBar's right edge
    SLV._detailContainer:ClearAllPoints()
    SLV._detailContainer:SetPoint("TOPLEFT", SLV.scrollBar, "TOPRIGHT", 4, 0)
    SLV._detailContainer:SetPoint("BOTTOMRIGHT", SLV.actionBar, "TOPRIGHT", -4, 4)
    SLV._detailContainer:Show()

    -- Refresh outline to highlight selected badge
    SLV:RefreshAll()
    SLV:UpdateButtonStates()
end

--- Close the detail pane and restore full-width outline.
function SLV:CloseDetailPane()
    SLV._detailOpen = false
    SLV._detailNavStack = nil
    SLV._detailNode = nil
    SLV._detailNodeIndex = nil
    SLV._detailSelectedChild = nil
    SLV._editingContext = nil

    if SLV._detailContainer then
        SLV._detailContainer:Hide()
    end

    -- Restore full-width outline
    SLV:RefreshAll()
end

--- Drill into a child node within the detail pane.
--- Pushes current node onto the nav stack and renders the child.
--- @param childIndex number Index in current detail node children
--- @param branchIndex number|nil For If nodes: 1=true, 2=false
function SLV:DrillIntoNode(childIndex, branchIndex)
    if not SLV._detailNode then
        return
    end

    -- Push current state
    SLV._detailNavStack = SLV._detailNavStack or {}
    SLV._detailNavStack[#SLV._detailNavStack + 1] = {
        node = SLV._detailNode,
        selectedChild = SLV._detailSelectedChild,
    }

    -- Navigate to child
    local children
    if branchIndex then
        children = SLV._detailNode.children and SLV._detailNode.children[branchIndex]
    else
        children = SLV._detailNode.children
    end
    if children and children[childIndex] then
        SLV._detailNode = children[childIndex]
    end
    SLV._detailSelectedChild = nil
    SLV._editingContext = nil

    SLV:_renderDetailPane()
end

--- Navigate to a breadcrumb level in the detail pane.
--- @param stackIndex number Index in the nav stack (0 = root detail node)
function SLV:NavigateBreadcrumb(stackIndex)
    if not SLV._detailNavStack then
        return
    end

    if stackIndex == 0 then
        -- Go back to root detail node
        if #SLV._detailNavStack > 0 then
            SLV._detailNode = SLV._detailNavStack[1].node
        end
        SLV._detailNavStack = {}
    else
        -- Pop to the given level
        local target = SLV._detailNavStack[stackIndex]
        if target then
            SLV._detailNode = target.node
            -- Trim stack
            local newStack = {}
            for i = 1, stackIndex - 1 do
                newStack[i] = SLV._detailNavStack[i]
            end
            SLV._detailNavStack = newStack
        end
    end
    SLV._detailSelectedChild = nil
    SLV._editingContext = nil

    SLV:_renderDetailPane()
end

--- Render (or re-render) the current detail pane contents.
--- Called on open, drill-down, breadcrumb nav, and child mutations.
function SLV:_renderDetailPane()
    if not SLV._detailContainer or not SLV._detailNode then
        return
    end

    local C = UI.Colors
    local defaults = D()
    local node = SLV._detailNode

    -- HEADER: breadcrumb
    local bc = SLV._detailBreadcrumb
    -- Clear old breadcrumb children
    for _, child in ipairs({ bc:GetChildren() }) do
        child:Hide()
        child:SetParent(nil)
    end
    for _, region in ipairs({ bc:GetRegions() }) do
        region:Hide()
    end

    -- Build breadcrumb segments
    local segments = {}
    local navStack = SLV._detailNavStack or {}
    -- Root node label
    local rootNode = navStack[1] and navStack[1].node or node
    local rootInfo = defaults.NODE_ICONS[rootNode.type] or { label = "Node" }
    local rootName = rootNode.name and rootNode.name ~= "" and rootNode.name or rootInfo.label
    segments[1] = rootName

    for i = 2, #navStack do
        local stackNode = navStack[i].node
        local info = defaults.NODE_ICONS[stackNode.type] or { label = "Node" }
        local name = stackNode.name and stackNode.name ~= "" and stackNode.name or info.label
        segments[#segments + 1] = name
    end
    -- Current node (if we have drilled deeper)
    if #navStack > 0 then
        local curInfo = defaults.NODE_ICONS[node.type] or { label = "Node" }
        local curName = node.name and node.name ~= "" and node.name or curInfo.label
        segments[#segments + 1] = curName
    end

    -- Build the list of segment indices to display, with truncation at depth 5+
    local totalSegs = #segments
    local displayIndices = {}
    if totalSegs <= 4 then
        -- Show all segments
        for si = 1, totalSegs do
            displayIndices[#displayIndices + 1] = si
        end
    else
        -- Truncate: [Root] > ... > [Parent] > [Current]
        displayIndices[1] = 1 -- root
        displayIndices[2] = 0 -- 0 = ellipsis placeholder
        displayIndices[3] = totalSegs - 1 -- parent
        displayIndices[4] = totalSegs -- current
    end

    -- Helper: render a ">" separator
    local prevAnchor = bc
    local prevPoint = "LEFT"
    local function addSep()
        local sep = bc:CreateFontString(nil, "OVERLAY")
        UI:SetFont(sep, 10)
        sep:SetPoint("LEFT", prevAnchor, prevPoint == "LEFT" and "LEFT" or "RIGHT", 2, 0)
        sep:SetText(">")
        sep:SetTextColor(C.textMuted:GetRGBA())
        prevAnchor = sep
        prevPoint = "RIGHT"
    end

    -- Helper: render a clickable breadcrumb segment
    local function addNavSegment(text, stackIdx)
        local navBtn = CreateFrame("Button", nil, bc)
        navBtn:SetHeight(18)
        local navLbl = navBtn:CreateFontString(nil, "OVERLAY")
        UI:SetFont(navLbl, 10)
        navLbl:SetPoint("LEFT")
        navLbl:SetText(text)
        navLbl:SetTextColor(C.gripGreen:GetRGBA())
        navBtn:SetWidth(navLbl:GetStringWidth() + 4)
        navBtn:SetPoint("LEFT", prevAnchor, prevPoint == "LEFT" and "LEFT" or "RIGHT", 4, 0)
        navBtn:SetScript("OnClick", function()
            SLV:NavigateBreadcrumb(stackIdx)
        end)
        navBtn:SetScript("OnEnter", function()
            navLbl:SetTextColor(1, 1, 1, 1)
        end)
        navBtn:SetScript("OnLeave", function()
            navLbl:SetTextColor(C.gripGreen:GetRGBA())
        end)
        prevAnchor = navBtn
        prevPoint = "RIGHT"
    end

    for di, si in ipairs(displayIndices) do
        if di > 1 then
            addSep()
        end

        if si == 0 then
            -- Ellipsis: click navigates to the first hidden level (navStack index 2)
            addNavSegment("...", 2)
        elseif si == totalSegs then
            -- Current node (last segment): non-clickable, white text
            local lbl = bc:CreateFontString(nil, "OVERLAY")
            UI:SetFont(lbl, 10)
            lbl:SetPoint("LEFT", prevAnchor, prevPoint == "LEFT" and "LEFT" or "RIGHT", 4, 0)
            lbl:SetText(segments[si])
            lbl:SetTextColor(C.textPrimary:GetRGBA())
            prevAnchor = lbl
            prevPoint = "RIGHT"
        else
            -- Clickable intermediate segment
            addNavSegment(segments[si], si - 1)
        end
    end

    -- SETTINGS BAR: node-type-specific controls
    local settings = SLV._detailSettings
    -- Clear old settings children
    for _, child in ipairs({ settings:GetChildren() }) do
        child:Hide()
        child:SetParent(nil)
    end
    for _, region in ipairs({ settings:GetRegions() }) do
        region:Hide()
    end

    SLV:_renderDetailSettings(settings, node)

    -- CHILDREN LIST: render in scroll panel
    local scrollChild = SLV._detailScrollChild
    -- Clear old children
    for _, child in ipairs({ scrollChild:GetChildren() }) do
        child:Hide()
        child:SetParent(nil)
    end
    for _, region in ipairs({ scrollChild:GetRegions() }) do
        region:Hide()
    end

    local yOffset = 0
    local nodeType = node.type

    if nodeType == defaults.ACTION_TYPE_IF then
        -- If node: two branches + compile preview block (spec section 10.4)
        yOffset = SLV:_renderDetailBranch(scrollChild, "True:", node.children and node.children[1] or {}, 1, yOffset)
        yOffset = SLV:_renderDetailBranch(scrollChild, "False:", node.children and node.children[2] or {}, 2, yOffset)
        yOffset = SLV:_renderDetailIfPreview(scrollChild, node, yOffset)
    elseif nodeType == defaults.ACTION_TYPE_ACTION and node.subtype == defaults.ACTION_SUBTYPE_MACROREF then
        -- Macro-ref: read-only body preview + drift indicator + Refresh button
        yOffset = SLV:_renderDetailMacroRefPreview(scrollChild, node, yOffset)
    else
        -- Loop, Embed, Pause: single children array
        local children = node.children or {}
        for i, child in ipairs(children) do
            yOffset = SLV:_renderDetailChildRow(scrollChild, child, i, nil, yOffset)
        end
    end

    scrollChild:SetHeight(math.abs(yOffset) + 10)

    -- Recompute the classic ScrollFrame's scroll range now that the child
    -- height changed, so the scrollbar engages immediately when children are
    -- added or removed (otherwise the range stays stale until the next manual
    -- window resize). Clamp current scroll into the new range so shrinking
    -- content does not leave the pane scrolled past its end.
    local detailSF = SLV._detailScrollFrame
    if detailSF then
        if detailSF.UpdateScrollChildRect then
            detailSF:UpdateScrollChildRect()
        end
        local maxScroll = (detailSF.GetVerticalScrollRange and detailSF:GetVerticalScrollRange()) or 0
        if (detailSF:GetVerticalScroll() or 0) > maxScroll then
            detailSF:SetVerticalScroll(maxScroll)
        end
    end
end

--- Render settings controls for a specific node type.
--- @param parent Frame The settings bar frame
--- @param node table The current detail node
function SLV:_renderDetailSettings(parent, node)
    local C = UI.Colors
    local defaults = D()
    local xOff = 4

    -- Name EditBox (all structural types)
    local nameLbl = parent:CreateFontString(nil, "OVERLAY")
    UI:SetFont(nameLbl, 10)
    nameLbl:SetPoint("LEFT", parent, "LEFT", xOff, 0)
    nameLbl:SetText("Name:")
    nameLbl:SetTextColor(C.textSecondary:GetRGBA())

    local nameBox = CreateFrame("EditBox", nil, parent, "BackdropTemplate")
    nameBox:SetSize(80, 20)
    nameBox:SetPoint("LEFT", nameLbl, "RIGHT", 4, 0)
    nameBox:SetAutoFocus(false)
    nameBox:SetMaxBytes(32)
    UI:ApplyBackdrop(nameBox, UI.Backdrops.panel, C.bgInput, C.border)
    nameBox:SetTextInsets(4, 4, 2, 2)
    local fontPath = GRIPEMS.UI:GetFontPath()
    nameBox:SetFont(fontPath, 10, "")
    nameBox:SetTextColor(C.textPrimary:GetRGBA())
    nameBox:SetText(node.name or "")
    nameBox:SetScript("OnTextChanged", function(self, userInput)
        if not userInput then
            return
        end
        node.name = self:GetText() or ""
        SLV:_markDirty()
        SLV:DebouncedRefreshRowByNodeIndex(SLV._detailNodeIndex)
    end)
    nameBox:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
    end)
    SLV._detailNameEditBox = nameBox
    GRIPEMS.Focus:HookEditBox(nameBox)

    -- Label EditBox (Phase 1C-bis-outline: per-action optional label, TTS-aware)
    local lblLbl = parent:CreateFontString(nil, "OVERLAY")
    UI:SetFont(lblLbl, 10)
    lblLbl:SetPoint("LEFT", nameBox, "RIGHT", 8, 0)
    lblLbl:SetText(L["ACCESS_STEP_LABEL_LABEL"])
    lblLbl:SetTextColor(C.textSecondary:GetRGBA())

    local lblBox = CreateFrame("EditBox", nil, parent, "BackdropTemplate")
    lblBox:SetSize(140, 20)
    lblBox:SetPoint("LEFT", lblLbl, "RIGHT", 4, 0)
    lblBox:SetAutoFocus(false)
    lblBox:SetMaxBytes(80)
    UI:ApplyBackdrop(lblBox, UI.Backdrops.panel, C.bgInput, C.border)
    lblBox:SetTextInsets(4, 4, 2, 2)
    lblBox:SetFont(fontPath, 10, "")
    lblBox:SetTextColor(C.textPrimary:GetRGBA())
    lblBox:SetText(node.label or "")
    lblBox:SetScript("OnTextChanged", function(self, userInput)
        if not userInput then
            return
        end
        local newText = self:GetText() or ""
        if #newText > 40 then
            newText = newText:sub(1, 40)
            self:SetText(newText)
        end
        if newText == "" then
            node.label = nil
        else
            node.label = newText
        end
        SLV:_markDirty()
        SLV:DebouncedRefreshRowByNodeIndex(SLV._detailNodeIndex)
    end)
    lblBox:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
    end)
    lblBox:SetScript("OnEnter", function(self)
        anchorTooltipSmart(self)
        GameTooltip:SetText(L["ACCESS_STEP_LABEL_LABEL"], 1, 1, 1)
        GameTooltip:AddLine(L["ACCESS_STEP_LABEL_DESC"], 0.8, 0.8, 0.8, true)
        GameTooltip:Show()
    end)
    lblBox:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)
    SLV._detailLabelEditBox = lblBox
    GRIPEMS.Focus:HookEditBox(lblBox)

    local nodeType = node.type

    if nodeType == defaults.ACTION_TYPE_LOOP then
        -- Repeat
        local rLbl = parent:CreateFontString(nil, "OVERLAY")
        UI:SetFont(rLbl, 10)
        rLbl:SetText("Repeat:")
        rLbl:SetTextColor(C.textSecondary:GetRGBA())

        local rBox = CreateFrame("EditBox", nil, parent, "BackdropTemplate")
        rBox:SetSize(36, 20)
        rBox:SetAutoFocus(false)
        rBox:SetNumeric(true)
        rBox:SetMaxLetters(3)
        UI:ApplyBackdrop(rBox, UI.Backdrops.panel, C.bgInput, C.border)
        rBox:SetTextInsets(4, 4, 2, 2)
        rBox:SetFont(fontPath, 10, "")
        rBox:SetTextColor(C.textPrimary:GetRGBA())
        rBox:SetText(tostring(node["repeat"] or defaults.ACTION_LOOP_DEFAULT_REPEAT))
        rBox:SetScript("OnTextChanged", function(self, userInput)
            if not userInput then
                return
            end
            local val = tonumber(self:GetText()) or defaults.ACTION_LOOP_DEFAULT_REPEAT
            if val < 1 then
                val = 1
            end
            if val > defaults.ACTION_LOOP_MAX_REPEAT then
                val = defaults.ACTION_LOOP_MAX_REPEAT
            end
            node["repeat"] = val
            SLV:_markDirty()
            SLV:DebouncedRefreshRowByNodeIndex(SLV._detailNodeIndex)
        end)
        rBox:SetScript("OnEscapePressed", function(self)
            self:ClearFocus()
        end)
        GRIPEMS.Focus:HookEditBox(rBox)

        -- Step function dropdown
        local sfLbl = parent:CreateFontString(nil, "OVERLAY")
        UI:SetFont(sfLbl, 10)
        sfLbl:SetText("SF:")
        sfLbl:SetTextColor(C.textSecondary:GetRGBA())

        local sfNames = {
            defaults.STEP_SEQUENTIAL,
            defaults.STEP_PRIORITY,
            defaults.STEP_REVERSE_PRIORITY,
            defaults.STEP_RANDOM,
        }
        local sfBtn = UI:CreateButton(parent, node.stepFunction or defaults.STEP_SEQUENTIAL, 80, 20)
        sfBtn:SetScript("OnClick", function(self)
            MenuUtil.CreateContextMenu(self, function(_, rootDescription)
                for _, sfName in ipairs(sfNames) do
                    rootDescription:CreateButton(sfName, function()
                        node.stepFunction = sfName
                        self.label:SetText(sfName)
                        SLV:_markDirty()
                        SLV:RefreshRowByNodeIndex(SLV._detailNodeIndex)
                    end)
                end
            end)
        end)

        -- Right-anchor chain (right-to-left): sfBtn -> sfLbl -> rBox -> rLbl
        -- Tracks parent width at narrow MainFrame so widgets stay inside detail pane
        sfBtn:SetPoint("RIGHT", parent, "RIGHT", -8, 0)
        sfLbl:SetPoint("RIGHT", sfBtn, "LEFT", -4, 0)
        rBox:SetPoint("RIGHT", sfLbl, "LEFT", -8, 0)
        rLbl:SetPoint("RIGHT", rBox, "LEFT", -4, 0)
        lblBox:SetPoint("RIGHT", rLbl, "LEFT", -4, 0)
    elseif nodeType == defaults.ACTION_TYPE_PAUSE then
        -- Mode dropdown
        local modes = { "clicks", "ms", "gcd" }
        local modeLabels = { clicks = "Clicks", ms = "MS", gcd = "GCD" }
        local currentMode = "clicks"
        if node.ms then
            currentMode = "ms"
        elseif node.gcd then
            currentMode = "gcd"
        end

        local modeBtn = UI:CreateButton(parent, modeLabels[currentMode], 50, 20)
        modeBtn:SetScript("OnClick", function(self)
            MenuUtil.CreateContextMenu(self, function(_, rootDescription)
                for _, mode in ipairs(modes) do
                    rootDescription:CreateButton(modeLabels[mode], function()
                        node.clicks = nil
                        node.ms = nil
                        node.gcd = nil
                        if mode == "clicks" then
                            node.clicks = 1
                        elseif mode == "ms" then
                            node.ms = 250
                        elseif mode == "gcd" then
                            node.gcd = 1
                        end
                        self.label:SetText(modeLabels[mode])
                        SLV:_markDirty()
                        SLV:_renderDetailPane()
                        SLV:RefreshRowByNodeIndex(SLV._detailNodeIndex)
                    end)
                end
            end)
        end)

        -- Value box
        local val = node.clicks or node.ms or node.gcd or 1
        local valBox = CreateFrame("EditBox", nil, parent, "BackdropTemplate")
        valBox:SetSize(50, 20)
        valBox:SetAutoFocus(false)
        valBox:SetNumeric(true)
        valBox:SetMaxLetters(5)
        UI:ApplyBackdrop(valBox, UI.Backdrops.panel, C.bgInput, C.border)
        valBox:SetTextInsets(4, 4, 2, 2)
        valBox:SetFont(fontPath, 10, "")
        valBox:SetTextColor(C.textPrimary:GetRGBA())
        valBox:SetText(tostring(val))
        valBox:SetScript("OnTextChanged", function(self, userInput)
            if not userInput then
                return
            end
            local v = tonumber(self:GetText()) or 1
            if v < 1 then
                v = 1
            end
            if node.clicks then
                node.clicks = v
            elseif node.ms then
                node.ms = v
            elseif node.gcd then
                node.gcd = v
            end
            SLV:_markDirty()
            SLV:DebouncedRefreshRowByNodeIndex(SLV._detailNodeIndex)
        end)
        valBox:SetScript("OnEscapePressed", function(self)
            self:ClearFocus()
        end)
        GRIPEMS.Focus:HookEditBox(valBox)

        -- Right-anchor chain (right-to-left): valBox -> modeBtn
        valBox:SetPoint("RIGHT", parent, "RIGHT", -8, 0)
        modeBtn:SetPoint("RIGHT", valBox, "LEFT", -4, 0)
        lblBox:SetPoint("RIGHT", modeBtn, "LEFT", -4, 0)
    elseif nodeType == defaults.ACTION_TYPE_IF then
        local MS = GRIPEMS.MacroSyntax
        local AC = GRIPEMS.ActionCompiler

        -- "Cond:" label
        local condLbl = parent:CreateFontString(nil, "OVERLAY")
        UI:SetFont(condLbl, 10)
        condLbl:SetText("Cond:")
        condLbl:SetTextColor(C.textSecondary:GetRGBA())

        -- Compile-path indicator badge: sits between condLbl and condBox.
        -- Mirrors the path categories from IF_Node_Complete_Spec.md section 7
        -- ("Single line", "Two-line split", "Per-step", "Fall-through"). Empty
        -- string when the cond is empty or fails to parse.
        local pathBadge = parent:CreateFontString(nil, "OVERLAY")
        UI:SetFont(pathBadge, 9)
        pathBadge:SetTextColor(C.textSecondary:GetRGBA())
        pathBadge:SetAlpha(0.75)

        local condBox = CreateFrame("EditBox", nil, parent, "BackdropTemplate")
        condBox:SetSize(120, 20)
        condBox:SetAutoFocus(false)
        condBox:SetMaxBytes(255)
        UI:ApplyBackdrop(condBox, UI.Backdrops.panel, C.bgInput, C.border)
        condBox:SetTextInsets(4, 4, 2, 2)
        condBox:SetFont(fontPath, 10, "")
        condBox:SetTextColor(C.textPrimary:GetRGBA())
        condBox:SetText(node.variable or "")

        -- Hint overlay shown when the condBox is empty (after trim). Matches
        -- the placeholder pattern from spec section 10.1.
        local condHint = condBox:CreateFontString(nil, "OVERLAY")
        UI:SetFont(condHint, 10)
        condHint:SetPoint("LEFT", condBox, "LEFT", 6, 0)
        condHint:SetText(L["GEMS_IF_COND_HINT"])
        condHint:SetTextColor(C.textSecondary:GetRGBA())
        condHint:SetAlpha(0.55)

        local function _trim(s)
            local r = (s or ""):gsub("^%s+", "")
            r = r:gsub("%s+$", "")
            return r
        end

        local function _refreshHint()
            if _trim(condBox:GetText()) == "" then
                condHint:Show()
            else
                condHint:Hide()
            end
        end

        local function _refreshValidation()
            local txt = _trim(condBox:GetText())
            if txt == "" then
                condBox._validationError = nil
                condBox:SetBackdropBorderColor(C.border:GetRGBA())
                return
            end
            local result = MS.ParseCondBoxInput(txt)
            if #result.errors > 0 then
                condBox._validationError = result.errors[1]
                condBox:SetBackdropBorderColor(C.textError:GetRGBA())
            else
                condBox._validationError = nil
                condBox:SetBackdropBorderColor(C.border:GetRGBA())
            end
        end

        local function _refreshPathBadge()
            local txt = _trim(condBox:GetText())
            if txt == "" then
                pathBadge:SetText("")
                return
            end
            local parsed = MS.ParseCondBoxInput(txt)
            if #parsed.errors > 0 then
                pathBadge:SetText("")
                return
            end
            local steps = AC.CompileActions({ node }, GRIPEMS.Engine)
            local stepCount = #steps
            local N = (node.children and node.children[1]) and #node.children[1] or 0
            local M = (node.children and node.children[2]) and #node.children[2] or 0
            if N == 0 and M == 0 then
                pathBadge:SetText("")
            elseif (N == 1 and M == 0) or (N == 0 and M == 1) then
                pathBadge:SetText(L["GEMS_IF_PATH_SINGLE"])
            elseif N == 1 and M == 1 and stepCount == 1 then
                pathBadge:SetText(L["GEMS_IF_PATH_FALL_THROUGH"])
            elseif N == 1 and M == 1 then
                pathBadge:SetText(L["GEMS_IF_PATH_TWO_LINE"])
            else
                pathBadge:SetText(L["GEMS_IF_PATH_PER_STEP"])
            end
        end

        condBox:SetScript("OnTextChanged", function(self, userInput)
            if not userInput then
                return
            end
            node.variable = self:GetText() or ""
            _refreshHint()
            _refreshValidation()
            _refreshPathBadge()
            if SLV._detailIfPreviewRefresh then
                SLV._detailIfPreviewRefresh()
            end
            SLV:_markDirty()
            SLV:DebouncedRefreshRowByNodeIndex(SLV._detailNodeIndex)
        end)
        condBox:SetScript("OnEscapePressed", function(self)
            self:ClearFocus()
        end)
        condBox:SetScript("OnEnter", function(self)
            anchorTooltipSmart(self)
            GameTooltip:SetText(L["GEMS_IF_COND_TOOLTIP_TITLE"], 1, 1, 1)
            GameTooltip:AddLine(L["GEMS_IF_COND_TOOLTIP_BODY"], 0.9, 0.9, 0.9, true)
            if self._validationError then
                GameTooltip:AddLine(" ")
                GameTooltip:AddLine(
                    (L["GEMS_IF_COND_INVALID"] or "Invalid condition") .. ": " .. self._validationError,
                    1.0,
                    0.3,
                    0.3,
                    true
                )
            end
            GameTooltip:Show()
        end)
        condBox:SetScript("OnLeave", function()
            GameTooltip:Hide()
        end)
        GRIPEMS.Focus:HookEditBox(condBox)

        -- Initial paint
        _refreshHint()
        _refreshValidation()
        _refreshPathBadge()

        -- Phase H1: conditional picker trigger button. Click opens the
        -- popup defined in UI/ConditionalPicker.lua; on Apply the popup
        -- inserts comma-joined tokens at the cursor of condBox and
        -- re-fires the OnTextChanged hook (which refreshes the path
        -- badge + live validation). Anchored to the right edge of the
        -- parent so condBox sits to its left.
        local pickerTrigger = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
        pickerTrigger:SetSize(20, 20)
        pickerTrigger:SetText("v")
        pickerTrigger:SetScript("OnClick", function()
            local function fireOnApply()
                if SLV._detailIfPreviewRefresh then
                    SLV._detailIfPreviewRefresh()
                end
            end
            -- H4b routing: parse the existing Cond box content; if it
            -- contains multiple OR brackets, route to ConditionalBuilder
            -- (modal). Otherwise the ConditionalPicker (popup) handles
            -- single-clause + empty input. Fixes the H1.2 detection bug
            -- (#clauses > 1 was dead; correct signal is
            -- #clauses[1].conditions > 1).
            local existing = (condBox:GetText() or ""):gsub("^%s+", ""):gsub("%s+$", "")
            local CB = GRIPEMS.ConditionalBuilder
            if existing ~= "" and MS and MS.ParseCondBoxInput and CB and CB.Open then
                local parsed = MS.ParseCondBoxInput(existing)
                if
                    parsed
                    and parsed.ast
                    and parsed.ast.clauses
                    and parsed.ast.clauses[1]
                    and #parsed.ast.clauses[1].conditions > 1
                then
                    CB:Open(condBox, parsed, fireOnApply, pickerTrigger)
                    return
                end
            end
            local CP = GRIPEMS.ConditionalPicker
            if CP and CP.Open then
                CP:Open(condBox, pickerTrigger, fireOnApply)
            end
        end)

        -- Right-anchor chain (right-to-left): pickerTrigger -> condBox -> pathBadge -> condLbl
        pickerTrigger:SetPoint("RIGHT", parent, "RIGHT", -8, 0)
        condBox:SetPoint("RIGHT", pickerTrigger, "LEFT", -4, 0)
        pathBadge:SetPoint("RIGHT", condBox, "LEFT", -4, 0)
        condLbl:SetPoint("RIGHT", pathBadge, "LEFT", -4, 0)
        lblBox:SetPoint("RIGHT", condLbl, "LEFT", -4, 0)
    elseif nodeType == defaults.ACTION_TYPE_EMBED then
        -- Sequence dropdown
        local seqLbl = parent:CreateFontString(nil, "OVERLAY")
        UI:SetFont(seqLbl, 10)
        seqLbl:SetText("Seq:")
        seqLbl:SetTextColor(C.textSecondary:GetRGBA())

        local seqBtn = UI:CreateButton(parent, node.sequence or "(select)", 120, 20)
        seqBtn:SetScript("OnClick", function(self)
            local Engine = GRIPEMS.Engine
            if not Engine or not Engine.sequences then
                return
            end
            MenuUtil.CreateContextMenu(self, function(_, rootDescription)
                local names = {}
                for seqName in pairs(Engine.sequences) do
                    names[#names + 1] = seqName
                end
                table.sort(names)
                for _, seqName in ipairs(names) do
                    rootDescription:CreateButton(seqName, function()
                        node.sequence = seqName
                        self.label:SetText(seqName)
                        SLV:_markDirty()
                        SLV:RefreshRowByNodeIndex(SLV._detailNodeIndex)
                    end)
                end
            end)
        end)

        -- Right-anchor chain (right-to-left): seqBtn -> seqLbl
        seqBtn:SetPoint("RIGHT", parent, "RIGHT", -8, 0)
        seqLbl:SetPoint("RIGHT", seqBtn, "LEFT", -4, 0)
        lblBox:SetPoint("RIGHT", seqLbl, "LEFT", -4, 0)
    elseif nodeType == defaults.ACTION_TYPE_ACTION and node.subtype == defaults.ACTION_SUBTYPE_MACROREF then
        -- Macro reference: bare name with a Change button that re-opens picker.
        local nameLbl2 = parent:CreateFontString(nil, "OVERLAY")
        UI:SetFont(nameLbl2, 10)
        nameLbl2:SetText(L["GEMS_MACROREF_NAME"] or "Macro:")
        nameLbl2:SetTextColor(C.textSecondary:GetRGBA())

        local nameBtn = UI:CreateButton(parent, node.macroName or "(pick)", 140, 20)
        nameBtn:SetScript("OnClick", function()
            GRIPEMS.MacroPicker:Show(function(sel)
                if not sel then
                    return
                end
                node.macroName = sel.name
                node.macro = sel.body or ""
                node.macroRefSynced = node.macro
                SLV:_markDirty()
                SLV:_renderDetailPane()
                SLV:RefreshRowByNodeIndex(SLV._detailNodeIndex)
            end)
        end)

        -- Right-anchor chain (right-to-left): nameBtn -> nameLbl2 -> lblBox
        nameBtn:SetPoint("RIGHT", parent, "RIGHT", -8, 0)
        nameLbl2:SetPoint("RIGHT", nameBtn, "LEFT", -4, 0)
        lblBox:SetPoint("RIGHT", nameLbl2, "LEFT", -4, 0)
    else
        -- ACTION (and any future type with no right-side widgets): lblBox flexes
        -- to parent.RIGHT so the chain compresses cleanly at narrow MainFrame.
        lblBox:SetPoint("RIGHT", parent, "RIGHT", -4, 0)
    end
end

--- Render the macro-ref body preview + drift indicator + Refresh button.
--- Body preview is a multi-line read-only EditBox showing node.macro. Drift
--- is computed at render time via MM:DetectDrift -- never persisted in
--- SavedVariables. Three visual states:
---   * sourceState == "missing": yellow hint, Refresh disabled
---   * isDrift == true:          yellow indicator, Refresh enabled
---   * neither:                  no indicator, Refresh hidden
--- @param scrollChild Frame Parent scroll child
--- @param node table Macro-ref node (subtype = ACTION_SUBTYPE_MACROREF)
--- @param yOffset number Current Y offset
--- @return number yOffset Updated Y offset
function SLV:_renderDetailMacroRefPreview(scrollChild, node, yOffset)
    local C = UI.Colors
    local fontPath = GRIPEMS.UI:GetFontPath()
    local drift = GRIPEMS.MacroManager:DetectDrift(node)

    -- Status row: drift indicator (yellow) or source-missing hint
    local statusFrame = CreateFrame("Frame", nil, scrollChild)
    statusFrame:SetHeight(20)
    statusFrame:SetPoint("TOPLEFT", scrollChild, "TOPLEFT", 4, yOffset)
    statusFrame:SetPoint("RIGHT", scrollChild, "RIGHT", -4, 0)

    local statusFS = statusFrame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(statusFS, 11)
    statusFS:SetPoint("LEFT", statusFrame, "LEFT", 0, 0)

    if drift.sourceState == "missing" then
        statusFS:SetText(L["GEMS_MACROREF_SOURCE_MISSING"] or "source macro missing -- re-pick from picker")
        statusFS:SetTextColor(0.95, 0.80, 0.20, 1.0)
    elseif drift.isDrift then
        statusFS:SetText(L["GEMS_MACROREF_DRIFT_INDICATOR"] or "stored body differs from /macro")
        statusFS:SetTextColor(0.95, 0.80, 0.20, 1.0)
    else
        statusFS:SetText("")
    end

    -- Refresh button: only when source exists and there is drift; disabled when source missing
    local refreshBtn = UI:CreateButton(statusFrame, L["GEMS_MACROREF_REFRESH"] or "Refresh from /macro", 140, 18)
    refreshBtn:SetPoint("RIGHT", statusFrame, "RIGHT", 0, 0)
    if drift.sourceState == "missing" then
        refreshBtn:Show()
        if refreshBtn.SetEnabled then
            refreshBtn:SetEnabled(false)
        else
            refreshBtn:Disable()
        end
    elseif drift.isDrift then
        refreshBtn:Show()
        if refreshBtn.SetEnabled then
            refreshBtn:SetEnabled(true)
        else
            refreshBtn:Enable()
        end
        refreshBtn:SetScript("OnClick", function()
            GRIPEMS.MacroManager:RefreshFromSource(node)
            SLV:_markDirty()
            SLV:_renderDetailPane()
            SLV:RefreshRowByNodeIndex(SLV._detailNodeIndex)
        end)
    else
        refreshBtn:Hide()
    end

    yOffset = yOffset - 22

    -- Body preview: multi-line read-only EditBox
    local bodyFrame = CreateFrame("Frame", nil, scrollChild, "BackdropTemplate")
    bodyFrame:SetHeight(120)
    bodyFrame:SetPoint("TOPLEFT", scrollChild, "TOPLEFT", 4, yOffset)
    bodyFrame:SetPoint("RIGHT", scrollChild, "RIGHT", -4, 0)
    UI:ApplyBackdrop(bodyFrame, UI.Backdrops.panel, C.bgInput, C.border)

    local bodyBox = CreateFrame("EditBox", nil, bodyFrame, "BackdropTemplate")
    bodyBox:SetMultiLine(true)
    bodyBox:SetAutoFocus(false)
    bodyBox:SetFont(fontPath, 11, "")
    bodyBox:SetTextColor(C.textPrimary:GetRGBA())
    bodyBox:SetTextInsets(6, 6, 4, 4)
    bodyBox:SetPoint("TOPLEFT", bodyFrame, "TOPLEFT", 2, -2)
    bodyBox:SetPoint("BOTTOMRIGHT", bodyFrame, "BOTTOMRIGHT", -2, 2)
    bodyBox:SetText(node.macro or "")
    bodyBox:EnableMouse(true)
    bodyBox:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
    end)
    -- Read-only: any user input is reverted to the stored body. Direct edits
    -- go through Refresh-from-source (or picker re-selection) -- there is no
    -- path to mutate the inlined body here.
    bodyBox:SetScript("OnTextChanged", function(self, userInput)
        if userInput then
            self:SetText(node.macro or "")
        end
    end)

    yOffset = yOffset - 124
    return yOffset
end

--- Render a branch section label + its children in the detail pane.
--- Used for If node true/false branches.
--- @param scrollChild Frame The scroll child to render into
--- @param label string Section label ("True:" or "False:")
--- @param children table Array of child nodes
--- @param branchIndex number 1=true, 2=false
--- @param yOffset number Current Y offset
--- @return number yOffset Updated Y offset
function SLV:_renderDetailBranch(scrollChild, label, children, branchIndex, yOffset)
    local C = UI.Colors

    -- Section label (clickable to set the active branch for + Add).
    -- Treat _detailSelectedBranch == nil as branch 1 (matches _detailAddChild default).
    local lbl = CreateFrame("Button", nil, scrollChild)
    lbl:SetHeight(18)
    lbl:SetPoint("TOPLEFT", scrollChild, "TOPLEFT", 0, yOffset)
    lbl:SetPoint("RIGHT", scrollChild, "RIGHT", 0, 0)
    local fs = lbl:CreateFontString(nil, "OVERLAY")
    UI:SetFont(fs, 10)
    fs:SetPoint("LEFT", lbl, "LEFT", 4, 0)
    local activeBranch = SLV._detailSelectedBranch or 1
    if branchIndex == activeBranch then
        fs:SetText("> " .. label)
    else
        fs:SetText("  " .. label)
    end
    if branchIndex == 1 then
        fs:SetTextColor(C.textSuccess:GetRGBA())
    else
        fs:SetTextColor(C.textError:GetRGBA())
    end
    lbl:RegisterForClicks("LeftButtonUp")
    lbl:SetScript("OnClick", function()
        SLV._detailSelectedBranch = branchIndex
        SLV._detailSelectedChild = nil
        SLV:_renderDetailPane()
    end)
    yOffset = yOffset - 18

    for i, child in ipairs(children) do
        yOffset = SLV:_renderDetailChildRow(scrollChild, child, i, branchIndex, yOffset)
    end

    return yOffset
end

--- Render the IF action node compile preview block (spec section 10.4).
--- Shows the byte-exact output of AC.CompileActions for the current node,
--- with per-line char-count markers (warn at 200<len<=255, error at len>255)
--- and a DeMorgan annotation when the false branch is non-empty.
--- The refresh function is stored on SLV._detailIfPreviewRefresh so the
--- condBox OnTextChanged hook (in _renderDetailSettings) can update the
--- preview as the user types without re-rendering the whole detail pane.
--- @param scrollChild Frame Parent scroll child
--- @param node table The IF node
--- @param yOffset number Current Y offset
--- @return number yOffset Updated Y offset
function SLV:_renderDetailIfPreview(scrollChild, node, yOffset)
    local C = UI.Colors
    local MS = GRIPEMS.MacroSyntax
    local AC = GRIPEMS.ActionCompiler

    -- Spacer above preview header
    yOffset = yOffset - 8

    local previewFrame = CreateFrame("Frame", nil, scrollChild)
    previewFrame:SetPoint("TOPLEFT", scrollChild, "TOPLEFT", 4, yOffset)
    previewFrame:SetPoint("RIGHT", scrollChild, "RIGHT", -4, 0)
    previewFrame:SetHeight(20)

    local previewHeader = previewFrame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(previewHeader, 10)
    previewHeader:SetPoint("TOPLEFT", previewFrame, "TOPLEFT", 0, 0)
    previewHeader:SetText(L["GEMS_IF_PREVIEW_HEADER"])
    previewHeader:SetTextColor(C.textSecondary:GetRGBA())

    local previewBody = previewFrame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(previewBody, 9)
    previewBody:SetPoint("TOPLEFT", previewHeader, "BOTTOMLEFT", 0, -2)
    previewBody:SetPoint("RIGHT", previewFrame, "RIGHT", -4, 0)
    previewBody:SetJustifyH("LEFT")
    previewBody:SetSpacing(2)
    previewBody:SetWordWrap(true)

    local function _refreshPreview()
        local steps = AC.CompileActions({ node }, GRIPEMS.Engine)
        if #steps == 0 then
            previewBody:SetText(L["GEMS_IF_PREVIEW_EMPTY"])
            previewBody:SetTextColor(C.textSecondary:GetRGBA())
            return
        end
        local lines = {}
        local hasWarn, hasError = false, false
        for _, step in ipairs(steps) do
            local len = MS.PreviewLength(step)
            local marker = ""
            if len > 255 then
                marker = " (" .. string.format(L["GEMS_IF_LEN_ERROR"], len) .. ")"
                hasError = true
            elseif len > 200 then
                marker = " (" .. string.format(L["GEMS_IF_LEN_WARN"], len) .. ")"
                hasWarn = true
            end
            -- Combat-blocked command annotation (spec section 10.8, Phase H2).
            if GRIPEMS.MacroLint then
                local mlSev, mlFindings = GRIPEMS.MacroLint.LintMacro(step)
                if mlSev == "warn" and mlFindings and mlFindings[1] then
                    marker = marker
                        .. " ("
                        .. string.format(L["GEMS_IF_LINT_COMBAT_BLOCKED_MARKER"], mlFindings[1].cmd)
                        .. ")"
                    hasWarn = true
                end
            end
            lines[#lines + 1] = step .. marker
        end

        -- DeMorgan annotation: when the false branch has at least one entry,
        -- show the negated condition string so the user can verify the
        -- DeMorgan pass produced what they expected (spec section 10.5).
        local fCount = (node.children and node.children[2]) and #node.children[2] or 0
        if fCount > 0 and node.variable then
            local trimmed = (node.variable):gsub("^%s+", ""):gsub("%s+$", "")
            if trimmed ~= "" then
                local parsed = MS.ParseCondBoxInput(trimmed)
                if #parsed.errors == 0 and parsed.ast.clauses[1] then
                    local condList = parsed.ast.clauses[1].conditions
                    local negList = MS.Negate(condList)
                    local synthetic = { clauses = { { conditions = negList, value = "" } } }
                    local negStr = MS.Serialize(synthetic)
                    if negStr ~= "" then
                        lines[#lines + 1] = (L["GEMS_IF_PREVIEW_NEG_LABEL"] or "neg") .. ": " .. negStr
                    end
                end
            end
        end

        previewBody:SetText(table.concat(lines, "\n"))
        if hasError then
            previewBody:SetTextColor(C.textError:GetRGBA())
        elseif hasWarn then
            previewBody:SetTextColor(C.textWarning:GetRGBA())
        else
            previewBody:SetTextColor(C.textPrimary:GetRGBA())
        end
    end

    SLV._detailIfPreviewRefresh = _refreshPreview
    _refreshPreview()

    -- Estimate frame height: header (12) + spacer (2) + body (9 px per line,
    -- count newlines + 1). Line-count fallback when GetText is empty.
    local bodyText = previewBody:GetText() or ""
    local lineCount = 1
    for _ in bodyText:gmatch("\n") do
        lineCount = lineCount + 1
    end
    local bodyHeight = math.max(12, lineCount * 12)
    previewFrame:SetHeight(14 + bodyHeight)
    yOffset = yOffset - (14 + bodyHeight) - 4

    return yOffset
end

--- Render a single child row in the detail pane.
--- Action children = step row (text + charcount, clickable for EditBox).
--- Structural children = badge row (icon, name, summary, chevron, clickable for drill-down).
--- @param scrollChild Frame Parent scroll child
--- @param child table Child node
--- @param childIndex number Index in children array
--- @param branchIndex number|nil For If nodes: 1=true, 2=false
--- @param yOffset number Current Y offset
--- @return number yOffset Updated Y offset
function SLV:_renderDetailChildRow(scrollChild, child, childIndex, branchIndex, yOffset)
    local C = UI.Colors
    local defaults = D()

    local row = CreateFrame("Button", nil, scrollChild, "BackdropTemplate")
    row:SetHeight(defaults.NODE_BADGE_HEIGHT)
    row:SetPoint("TOPLEFT", scrollChild, "TOPLEFT", 0, yOffset)
    row:SetPoint("RIGHT", scrollChild, "RIGHT", 0, 0)
    if not row.SetBackdrop then
        Mixin(row, BackdropTemplateMixin)
    end
    row:EnableMouse(true)
    row:RegisterForClicks("LeftButtonUp", "RightButtonUp")

    -- Drag handle for detail pane reorder
    local dh = CreateFrame("Frame", nil, row)
    dh:SetSize(defaults.STEP_DRAG_HANDLE_WIDTH, defaults.NODE_BADGE_HEIGHT)
    dh:SetPoint("LEFT", row, "LEFT", 2, 0)
    for li = 1, 3 do
        local line = dh:CreateTexture(nil, "ARTWORK")
        line:SetSize(8, 1)
        line:SetColorTexture(C.textMuted:GetRGBA())
        line:SetPoint("CENTER", dh, "CENTER", 0, (li - 2) * 3)
    end
    dh:EnableMouse(true)
    dh:RegisterForDrag("LeftButton")
    dh:SetScript("OnDragStart", function()
        SLV:_beginDetailDrag(row, childIndex, branchIndex)
    end)
    dh:SetScript("OnDragStop", function()
        SLV:_endDetailDrag(row)
    end)
    dh:SetScript("OnMouseUp", function(_, mouseButton)
        if not SLV._isDragging and row:GetScript("OnClick") then
            row:GetScript("OnClick")(row, mouseButton)
        end
    end)

    -- Stash index + branch on the row frame so the detail-pane drag can find
    -- which row the cursor is over by geometry (height-agnostic, If-safe).
    row._childIndex = childIndex
    row._branchIndex = branchIndex

    local leftAnchorOffset = 4 + defaults.STEP_DRAG_HANDLE_WIDTH

    if child.type == defaults.ACTION_TYPE_ACTION then
        -- Step row in detail pane
        row:SetBackdrop(UI.Backdrops.panelNoBorder)
        local isSelected = (
            SLV._detailSelectedChild == childIndex
            and (not branchIndex or SLV._detailSelectedBranch == branchIndex)
        )
        if isSelected then
            row:SetBackdropColor(C.bgRowSelected:GetRGBA())
        else
            row:SetBackdropColor(C.bgMain:GetRGBA())
        end

        local macro = child.macro or ""

        -- Per-step validation for the warning badge
        local detailSV = GRIPEMS.SpellValidator
        local detailSC = GRIPEMS.SpellCache
        local warnLevel = nil
        if detailSC and detailSC.ready and detailSV and macro ~= "" then
            local stepResult = detailSV:ValidateStep(macro)
            local hasUnknown, hasKnown = false, false
            for _, spell in ipairs(stepResult.spells) do
                if spell.status == defaults.SPELL_STATUS_UNKNOWN then
                    hasUnknown = true
                elseif spell.status == defaults.SPELL_STATUS_KNOWN then
                    hasKnown = true
                end
            end
            if hasUnknown then
                warnLevel = "error"
            elseif hasKnown then
                warnLevel = "warn"
            end
        end

        -- Combat-blocked command lint (spec section 10.8, Phase H2).
        -- Promotes nil warnLevel to "warn"; never overrides existing "error".
        local ML = GRIPEMS.MacroLint
        local lintFindings = nil
        if ML and macro ~= "" then
            local lintSev, found = ML.LintMacro(macro)
            if lintSev == "warn" then
                lintFindings = found
                if warnLevel == nil then
                    warnLevel = "warn"
                end
            end
        end

        local stepText = row:CreateFontString(nil, "OVERLAY")
        UI:SetFont(stepText, 11)
        stepText:SetPoint("LEFT", row, "LEFT", leftAnchorOffset, 0)
        stepText:SetJustifyH("LEFT")
        stepText:SetWordWrap(false)

        -- Phase 1C-bis: optional [label] prefix matching the canonical
        -- container-row stepLabel from createStepRow. Created only when set
        -- so labelless children render with zero visual delta.
        if child.label and child.label ~= "" then
            local stepLabel = row:CreateFontString(nil, "OVERLAY")
            UI:SetFont(stepLabel, 10)
            stepLabel:SetJustifyH("LEFT")
            stepLabel:SetWordWrap(false)
            stepLabel:SetWidth(90)
            stepLabel:SetPoint("LEFT", row, "LEFT", leftAnchorOffset, 0)
            stepLabel:SetText("[" .. child.label .. "]")
            stepLabel:SetTextColor(C.textMuted:GetRGBA())
            stepText:ClearAllPoints()
            stepText:SetPoint("LEFT", stepLabel, "RIGHT", 4, 0)
        end

        local macroStr = (type(macro) == "string") and macro or ""
        local firstLine = macroStr:match("^([^\n]*)") or macroStr
        -- Display-only spell ID resolution; stored macro is untouched
        if detailSC and detailSC.ready and detailSC.ResolveSpellIDsInText then
            firstLine = detailSC:ResolveSpellIDsInText(firstLine)
        end
        if child.disabled then
            stepText:SetText(L["GEMS_UI_STEP_DISABLED_PREFIX"] .. firstLine)
            stepText:SetTextColor(C.textMuted:GetRGBA())
        else
            stepText:SetText(firstLine)
            stepText:SetTextColor(C.textPrimary:GetRGBA())
        end

        local charFs = row:CreateFontString(nil, "OVERLAY")
        UI:SetFont(charFs, 9)
        charFs:SetPoint("RIGHT", row, "RIGHT", -4, 0)
        local cc = #macroStr
        charFs:SetText(string.format("%d/%d", cc, defaults.CHAR_COUNT_DANGER))
        if cc >= defaults.CHAR_COUNT_DANGER then
            charFs:SetTextColor(C.textError:GetRGBA())
        elseif cc > defaults.CHAR_COUNT_WARNING then
            charFs:SetTextColor(C.textWarning:GetRGBA())
        else
            charFs:SetTextColor(C.textSuccess:GetRGBA())
        end

        -- Validation badge anchored between stepText and charFs
        local warnFs = nil
        if warnLevel then
            warnFs = row:CreateFontString(nil, "OVERLAY")
            UI:SetFont(warnFs, 11, "OUTLINE")
            warnFs:SetPoint("RIGHT", charFs, "LEFT", -6, 0)
            if warnLevel == "error" then
                warnFs:SetText("!!")
                warnFs:SetTextColor(C.textError:GetRGBA())
            else
                warnFs:SetText("!")
                warnFs:SetTextColor(C.textWarning:GetRGBA())
            end
        end

        -- Inline interleave controls: [checkbox] [editbox] steps
        local ilEnabled = (child.interval ~= nil and child.interval >= defaults.ACTION_INTERLEAVE_MIN)

        local ilCheck = CreateFrame("CheckButton", nil, row, "UICheckButtonTemplate")
        ilCheck:SetSize(18, 18)
        ilCheck:SetHitRectInsets(0, 0, 0, 0)
        ilCheck:SetChecked(ilEnabled)

        local ilEdit = CreateFrame("EditBox", nil, row, "InputBoxTemplate")
        ilEdit:SetSize(24, 16)
        ilEdit:SetAutoFocus(false)
        ilEdit:SetMaxLetters(2)
        ilEdit:SetNumeric(true)
        ilEdit:SetFontObject("ChatFontSmall")
        ilEdit:SetJustifyH("CENTER")

        local stepsLbl = row:CreateFontString(nil, "OVERLAY")
        UI:SetFont(stepsLbl, 10)
        stepsLbl:SetText(L["GEMS_ACTION_INTERLEAVE_STEPS"] or "steps")
        stepsLbl:SetTextColor(C.textMuted:GetRGBA())

        local ilAnchor, ilAnchorX
        if warnFs then
            ilAnchor = warnFs
            ilAnchorX = -6
        else
            ilAnchor = charFs
            ilAnchorX = -6
        end
        stepsLbl:SetPoint("RIGHT", ilAnchor, "LEFT", ilAnchorX, 0)
        ilEdit:SetPoint("RIGHT", stepsLbl, "LEFT", -4, 0)
        ilCheck:SetPoint("RIGHT", ilEdit, "LEFT", -2, 0)

        if ilEnabled then
            ilEdit:SetText(tostring(child.interval))
            ilEdit:Show()
            stepsLbl:Show()
        else
            ilEdit:Hide()
            stepsLbl:Hide()
        end

        stepText:SetPoint("RIGHT", ilCheck, "LEFT", -4, 0)

        ilCheck:SetScript("OnEnter", function(self)
            anchorTooltipSmart(self)
            GameTooltip:SetText(L["GEMS_INTERLEAVE_TOOLTIP_TITLE"], 1, 1, 1)
            GameTooltip:AddLine(L["GEMS_INTERLEAVE_TOOLTIP_DESC"], 0.8, 0.8, 0.8, true)
            GameTooltip:Show()
        end)
        ilCheck:SetScript("OnLeave", function()
            GameTooltip:Hide()
        end)

        ilCheck:SetScript("OnClick", function(self)
            if self:GetChecked() then
                child.interval = defaults.ACTION_INTERLEAVE_DEFAULT
            else
                child.interval = nil
            end
            SLV:_markDirty()
            SLV:_renderDetailPane()
        end)

        ilEdit:SetScript("OnEnterPressed", function(self)
            local n = tonumber(self:GetText())
            if n then
                if n < defaults.ACTION_INTERLEAVE_MIN then
                    n = defaults.ACTION_INTERLEAVE_MIN
                end
                if n > defaults.ACTION_INTERLEAVE_MAX then
                    n = defaults.ACTION_INTERLEAVE_MAX
                end
                child.interval = n
                self:SetText(tostring(n))
            end
            self:ClearFocus()
            SLV:_markDirty()
            SLV:_renderDetailPane()
        end)
        ilEdit:SetScript("OnEscapePressed", function(self)
            self:SetText(tostring(child.interval or defaults.ACTION_INTERLEAVE_DEFAULT))
            self:ClearFocus()
        end)
        GRIPEMS.Focus:HookEditBox(ilEdit)

        row:SetScript("OnEnter", function(self)
            if not isSelected then
                self:SetBackdropColor(C.bgRowHover:GetRGBA())
            end
            if not macro or macro == "" then
                return
            end
            local SC_local = GRIPEMS.SpellCache
            local SV_local = GRIPEMS.SpellValidator
            if not (SC_local and SC_local.ready and SV_local) then
                return
            end

            local nativeShown = false
            local extracted = SV_local:ExtractAllSpells(macro)
            if extracted and #extracted > 0 then
                local primaryName = extracted[1].name
                if primaryName and primaryName ~= "" then
                    local itemID = primaryName:match("^item:(%d+)")
                    if itemID then
                        if C_TooltipInfo and C_TooltipInfo.GetItemByID then
                            local info = C_TooltipInfo.GetItemByID(tonumber(itemID))
                            if info then
                                anchorTooltipSmart(self)
                                GameTooltip:ProcessInfo(info)
                                nativeShown = true
                            end
                        else
                            -- Fallback for pre-11.0 (safety)
                            anchorTooltipSmart(self)
                            GameTooltip:SetItemByID(tonumber(itemID))
                            nativeShown = true
                        end
                    else
                        local spellID = SC_local:GetSpellID(primaryName)
                        if spellID then
                            if C_TooltipInfo and C_TooltipInfo.GetSpellByID then
                                local info = C_TooltipInfo.GetSpellByID(spellID)
                                if info then
                                    anchorTooltipSmart(self)
                                    GameTooltip:ProcessInfo(info)
                                    nativeShown = true
                                end
                            else
                                -- Fallback for pre-11.0 (safety)
                                anchorTooltipSmart(self)
                                GameTooltip:SetSpellByID(spellID)
                                nativeShown = true
                            end
                        end
                    end
                end
            end

            local stepResult = SV_local:ValidateStep(macro)
            local issues = {}
            local contextual = {}
            for _, spell in ipairs(stepResult.spells) do
                if spell.status == defaults.SPELL_STATUS_UNKNOWN then
                    issues[#issues + 1] = string.format(L["GEMS_SPELL_TOOLTIP_UNKNOWN"], spell.name)
                elseif spell.status == defaults.SPELL_STATUS_KNOWN then
                    issues[#issues + 1] = string.format(L["GEMS_SPELL_TOOLTIP_KNOWN"], spell.name)
                elseif spell.status == defaults.SPELL_STATUS_CONTEXTUAL then
                    contextual[#contextual + 1] = string.format(L["GEMS_SPELL_TOOLTIP_CONTEXTUAL"], spell.name)
                end
            end

            local blockedLines = {}
            if lintFindings then
                for _, f in ipairs(lintFindings) do
                    local fmt = L[f.localeKey]
                    if fmt then
                        blockedLines[#blockedLines + 1] = string.format(fmt, f.cmd)
                    end
                end
            end

            if nativeShown and (#issues > 0 or #contextual > 0) then
                GameTooltip:AddLine(" ")
                for _, issue in ipairs(issues) do
                    GameTooltip:AddLine(issue, 1, 0.27, 0.27, true)
                end
                if #contextual > 0 then
                    local ctxR, ctxG, ctxB = C.textContextual:GetRGBA()
                    for _, line in ipairs(contextual) do
                        GameTooltip:AddLine(line, ctxR, ctxG, ctxB, true)
                    end
                end
                GameTooltip:Show()
            elseif not nativeShown then
                if #issues > 0 or #blockedLines > 0 or #contextual > 0 then
                    anchorTooltipSmart(self)
                    local ttMacroStr = (type(macro) == "string") and macro or ""
                    GameTooltip:SetText(ttMacroStr:match("^([^\n]*)") or ttMacroStr, 1, 1, 1)
                    if #issues > 0 then
                        GameTooltip:AddLine(" ")
                        for _, issue in ipairs(issues) do
                            GameTooltip:AddLine(issue, 1, 0.27, 0.27, true)
                        end
                    end
                    if #contextual > 0 then
                        GameTooltip:AddLine(" ")
                        local ctxR, ctxG, ctxB = C.textContextual:GetRGBA()
                        for _, line in ipairs(contextual) do
                            GameTooltip:AddLine(line, ctxR, ctxG, ctxB, true)
                        end
                    end
                    GameTooltip:Show()
                end
            else
                GameTooltip:Show()
            end

            -- Combat-blocked command tooltip block (spec section 10.8, Phase H2).
            -- Appends after any spell-validation issues; anchored above.
            if #blockedLines > 0 then
                GameTooltip:AddLine(" ")
                GameTooltip:AddLine(L["GEMS_IF_LINT_COMBAT_BLOCKED_TOOLTIP_HEADER"], 1, 0.84, 0, true)
                for _, line in ipairs(blockedLines) do
                    GameTooltip:AddLine(line, 1, 0.84, 0, true)
                end
                GameTooltip:AddLine(L["GEMS_IF_LINT_COMBAT_BLOCKED_TOOLTIP_HINT"], 0.8, 0.8, 0.8, true)
                GameTooltip:Show()
            end
        end)
        row:SetScript("OnLeave", function(self)
            if not isSelected then
                self:SetBackdropColor(C.bgMain:GetRGBA())
            end
            GameTooltip:Hide()
        end)

        row:SetScript("OnClick", function(_, mouseButton)
            if mouseButton == "RightButton" then
                SLV._detailSelectedChild = childIndex
                SLV._detailSelectedBranch = branchIndex
                SLV:ShowDetailChildContextMenu(row)
                return
            end
            SLV._detailSelectedChild = childIndex
            SLV._detailSelectedBranch = branchIndex
            -- Build breadcrumb path label for EditBox
            local navStack = SLV._detailNavStack or {}
            local pathParts = {}
            for _, entry in ipairs(navStack) do
                local info = defaults.NODE_ICONS[entry.node.type] or { label = "Node" }
                local n = entry.node.name and entry.node.name ~= "" and entry.node.name or info.label
                pathParts[#pathParts + 1] = n
            end
            local curInfo = defaults.NODE_ICONS[SLV._detailNode.type] or { label = "Node" }
            local curName = SLV._detailNode.name and SLV._detailNode.name ~= "" and SLV._detailNode.name
                or curInfo.label
            pathParts[#pathParts + 1] = curName
            local pathStr = table.concat(pathParts, " > ")
            local label = pathStr .. " > Action " .. childIndex .. ":"

            SLV._editingContext = {
                source = "detail",
                childIndex = childIndex,
                branchIndex = branchIndex,
                label = label,
            }
            SLV:UpdateEditArea()
            SLV:_renderDetailPane()
        end)
    else
        -- Badge row for structural child (drill-down)
        row:SetBackdrop(UI.Backdrops.panelNoBorder)
        local isSelected = (
            SLV._detailSelectedChild == childIndex
            and (not branchIndex or SLV._detailSelectedBranch == branchIndex)
        )
        if isSelected then
            row:SetBackdropColor(C.bgRowSelected:GetRGBA())
        else
            row:SetBackdropColor(C.bgPanel:GetRGBA())
        end

        local iconInfo = defaults.NODE_ICONS[child.type] or defaults.NODE_ICONS["loop"]
        local iconColor = iconInfo.color

        local iconFrame = CreateFrame("Frame", nil, row, "BackdropTemplate")
        iconFrame:SetSize(18, 18)
        iconFrame:SetPoint("LEFT", row, "LEFT", leftAnchorOffset, 0)
        UI:ApplyBackdrop(
            iconFrame,
            UI.Backdrops.panel,
            CreateColor(iconColor[1], iconColor[2], iconColor[3], 0.3),
            CreateColor(iconColor[1], iconColor[2], iconColor[3], 0.6)
        )
        local iconLabel = iconFrame:CreateFontString(nil, "OVERLAY")
        UI:SetFont(iconLabel, 11, "OUTLINE")
        iconLabel:SetPoint("CENTER")
        iconLabel:SetText(iconInfo.symbol)
        iconLabel:SetTextColor(iconColor[1], iconColor[2], iconColor[3], 1)

        local nameFs = row:CreateFontString(nil, "OVERLAY")
        UI:SetFont(nameFs, 12)
        nameFs:SetPoint("LEFT", iconFrame, "RIGHT", 6, 0)
        nameFs:SetJustifyH("LEFT")
        local dispName = child.name and child.name ~= "" and child.name or iconInfo.label
        nameFs:SetText(dispName)
        if child.disabled then
            nameFs:SetTextColor(C.textMuted:GetRGBA())
        else
            nameFs:SetTextColor(C.textPrimary:GetRGBA())
        end

        local sumFs = row:CreateFontString(nil, "OVERLAY")
        UI:SetFont(sumFs, 11)
        sumFs:SetPoint("LEFT", nameFs, "RIGHT", 8, 0)
        sumFs:SetPoint("RIGHT", row, "RIGHT", -24, 0)
        sumFs:SetJustifyH("LEFT")
        sumFs:SetWordWrap(false)
        sumFs:SetText(defaults.NodeSummary(child))
        sumFs:SetTextColor(C.textSecondary:GetRGBA())

        -- Structural-child recursive spell validation badge
        local warnBadge = row:CreateFontString(nil, "OVERLAY")
        UI:SetFont(warnBadge, 13, "OUTLINE")
        warnBadge:SetPoint("RIGHT", row, "RIGHT", -24, 0)

        local structSV = GRIPEMS.SpellValidator
        local structSC = GRIPEMS.SpellCache
        local structWarn = nil
        if structSC and structSC.ready and structSV and child then
            structWarn = structSV:NodeHasInvalidSpells(child)
        end

        -- Combat-blocked command lint, recursive walk (spec section 10.8, Phase H2).
        -- Promotes nil structWarn to "warn"; never overrides existing "error".
        local structML = GRIPEMS.MacroLint
        local structLintFindings = nil
        if structML and child then
            local lintSev, found = structML:NodeHasBlockedCommands(child, nil, true)
            if lintSev == "warn" then
                structLintFindings = found
                if structWarn == nil then
                    structWarn = "warn"
                end
            end
        end

        if structWarn == "error" then
            warnBadge:SetText("!!")
            warnBadge:SetTextColor(C.textError:GetRGBA())
            sumFs:ClearAllPoints()
            sumFs:SetPoint("LEFT", nameFs, "RIGHT", 8, 0)
            sumFs:SetPoint("RIGHT", warnBadge, "LEFT", -4, 0)
        elseif structWarn == "warn" then
            warnBadge:SetText("!")
            warnBadge:SetTextColor(C.textWarning:GetRGBA())
            sumFs:ClearAllPoints()
            sumFs:SetPoint("LEFT", nameFs, "RIGHT", 8, 0)
            sumFs:SetPoint("RIGHT", warnBadge, "LEFT", -4, 0)
        else
            warnBadge:Hide()
        end

        local chev = row:CreateFontString(nil, "OVERLAY")
        UI:SetFont(chev, 12)
        chev:SetPoint("RIGHT", row, "RIGHT", -6, 0)
        chev:SetText(">")
        chev:SetTextColor(C.textMuted:GetRGBA())

        row:SetScript("OnEnter", function(self)
            if not isSelected then
                self:SetBackdropColor(C.bgRowHover:GetRGBA())
            end
            local sv = GRIPEMS.SpellValidator
            local sc = GRIPEMS.SpellCache
            local invalids = nil
            if sc and sc.ready and sv and child then
                invalids = select(2, sv:NodeHasInvalidSpells(child, nil, true))
            end

            -- Combat-blocked command tooltip block (spec section 10.8, Phase H2).
            local structBlockedLines = {}
            if structLintFindings then
                for _, f in ipairs(structLintFindings) do
                    local fmt = L[f.localeKey]
                    if fmt then
                        structBlockedLines[#structBlockedLines + 1] = string.format(fmt, f.cmd)
                    end
                end
            end

            local hasInvalids = invalids and #invalids > 0
            local hasBlocked = #structBlockedLines > 0
            if hasInvalids or hasBlocked then
                anchorTooltipSmart(self)
                local title = (child.name and child.name ~= "") and child.name or iconInfo.label
                GameTooltip:SetText(title, 1, 1, 1)
                GameTooltip:AddLine(defaults.NodeSummary(child), 0.7, 0.7, 0.7, true)
                if hasInvalids then
                    GameTooltip:AddLine(" ")
                    for _, spell in ipairs(invalids) do
                        local fmt = (spell.status == defaults.SPELL_STATUS_UNKNOWN) and L["GEMS_SPELL_TOOLTIP_UNKNOWN"]
                            or L["GEMS_SPELL_TOOLTIP_KNOWN"]
                        GameTooltip:AddLine(string.format(fmt, spell.name), 1, 0.27, 0.27, true)
                    end
                end
                if hasBlocked then
                    GameTooltip:AddLine(" ")
                    GameTooltip:AddLine(L["GEMS_IF_LINT_COMBAT_BLOCKED_TOOLTIP_HEADER"], 1, 0.84, 0, true)
                    for _, line in ipairs(structBlockedLines) do
                        GameTooltip:AddLine(line, 1, 0.84, 0, true)
                    end
                    GameTooltip:AddLine(L["GEMS_IF_LINT_COMBAT_BLOCKED_TOOLTIP_HINT"], 0.8, 0.8, 0.8, true)
                end
                GameTooltip:Show()
            end
        end)
        row:SetScript("OnLeave", function(self)
            if not isSelected then
                self:SetBackdropColor(C.bgPanel:GetRGBA())
            end
            GameTooltip:Hide()
        end)

        row:RegisterForClicks("LeftButtonUp", "RightButtonUp")
        row:SetScript("OnClick", function(_, mouseButton)
            if mouseButton == "RightButton" then
                SLV._detailSelectedChild = childIndex
                SLV._detailSelectedBranch = branchIndex
                SLV:ShowDetailChildContextMenu(row)
                return
            end
            local wasSelected = (
                SLV._detailSelectedChild == childIndex
                and (not branchIndex or SLV._detailSelectedBranch == branchIndex)
            )
            if wasSelected then
                SLV:DrillIntoNode(childIndex, branchIndex)
            else
                SLV._detailSelectedChild = childIndex
                SLV._detailSelectedBranch = branchIndex
                SLV._editingContext = nil
                SLV:_renderDetailPane()
            end
        end)
    end

    return yOffset - defaults.NODE_BADGE_HEIGHT
end

--- Mark the sequence as dirty (detail pane edits).
function SLV:_markDirty()
    local SE = GRIPEMS.SequenceEditor
    if SE then
        SE.isDirty = true
        SE:UpdateSaveButtons()
    end
    SLV:DebouncedUpdatePreview()
end

---------------------------------------------------------------------------
-- Outline drag-to-reorder (shared by step rows and node badge rows)
---------------------------------------------------------------------------

-- Height of a node's deepest descendant relative to the node itself.
-- Leaf (no children) = 0; a loop holding leaves = 1. Discriminates the If
-- shape (children = { trueArray, falseArray }) from the Loop shape (flat
-- node array) by node.type -- NOT by whether children[1] is populated. An
-- else-only If (empty true branch, populated false branch) must still be
-- measured through its false branch, or the depth gate under-counts and
-- admits a drop the compiler would later silently truncate.
local function reparentSubtreeHeight(node)
    if type(node) ~= "table" or type(node.children) ~= "table" then
        return 0
    end
    local ch = node.children
    local maxH = 0
    if node.type == D().ACTION_TYPE_IF then
        for _, branch in ipairs(ch) do
            if type(branch) == "table" then
                for _, c in ipairs(branch) do
                    local h = 1 + reparentSubtreeHeight(c)
                    if h > maxH then
                        maxH = h
                    end
                end
            end
        end
    else
        for _, c in ipairs(ch) do
            local h = 1 + reparentSubtreeHeight(c)
            if h > maxH then
                maxH = h
            end
        end
    end
    return maxH
end

-- True when the mouse cursor is over frame, converted with the FRAME'S own
-- effective scale so the hit test is correct even under a non-default UI
-- scale. Coarse rectangle test -- reliable where a narrow per-row band is not.
local function cursorOverFrame(frame)
    if not frame or not frame.IsVisible or not frame:IsVisible() then
        return false
    end
    local scale = frame:GetEffectiveScale()
    if not scale or scale == 0 then
        return false
    end
    local cx, cy = GetCursorPosition()
    cx, cy = cx / scale, cy / scale
    local l, r, t, b = frame:GetLeft(), frame:GetRight(), frame:GetTop(), frame:GetBottom()
    if not (l and r and t and b) then
        return false
    end
    return cx >= l and cx <= r and cy >= b and cy <= t
end

-- True when needle is node itself or anywhere inside node's subtree.
-- Discriminates the If shape from the Loop shape by node.type (the same
-- canonical rule the rest of the file now uses). Cycle guard for reparent.
local function subtreeContains(node, needle)
    if node == needle then
        return true
    end
    if type(node) ~= "table" or type(node.children) ~= "table" then
        return false
    end
    local ch = node.children
    local function arrHas(arr)
        if type(arr) ~= "table" then
            return false
        end
        for _, c in ipairs(arr) do
            if subtreeContains(c, needle) then
                return true
            end
        end
        return false
    end
    if node.type == D().ACTION_TYPE_IF then
        return arrHas(ch[1]) or arrHas(ch[2])
    end
    return arrHas(ch)
end

--- Begin a drag operation in the outline scrollBox.
--- Works for both flat mode (workingSteps) and outline mode (workingActions).
--- @param button Frame The row frame being dragged
--- @param data table The DataProvider item data for this row
function SLV:_beginOutlineDrag(button, data)
    if not data then
        return
    end

    -- Determine item count and source index based on mode
    local itemCount, srcIdx
    if SLV.hasActions and SLV.workingActions then
        itemCount = #SLV.workingActions
        srcIdx = data.nodeIndex
    else
        itemCount = #SLV.workingSteps
        srcIdx = data.index
    end

    if not srcIdx or itemCount <= 1 then
        return
    end

    SLV._dragSourceIndex = srcIdx
    SLV._isDragging = true
    SLV._dragMode = SLV.hasActions and "outline" or "flat"
    SLV._dragReparentIndex = nil
    SLV._dragIntoDetail = nil
    if SLV.dragReparentHighlight then
        SLV.dragReparentHighlight:Hide()
    end

    -- Hide autocomplete if open
    if SLV.autocompleteDropdown and SLV.autocompleteDropdown:IsShown() then
        SLV.autocompleteDropdown:Hide()
    end

    -- Configure ghost frame
    local ghost = SLV.dragGhost
    ghost:SetWidth(SLV.scrollBox:GetWidth())
    if data.rowType == "node" then
        local defaults = D()
        local iconInfo = defaults.NODE_ICONS[data.nodeType] or { label = "Node", symbol = "?" }
        ghost.ghostNum:SetText("[" .. iconInfo.symbol .. "]")
        ghost.ghostText:SetText(data.nodeName ~= "" and data.nodeName or iconInfo.label)
    else
        ghost.ghostNum:SetText(button.stepNum and button.stepNum:GetText() or "")
        ghost.ghostText:SetText(button.stepText and button.stepText:GetText() or "")
    end
    ghost:ClearAllPoints()
    ghost:SetAlpha(0.7)
    ghost:Show()

    -- Dim source row
    button:SetAlpha(0.3)

    -- Show drag indicator with fade-in
    SLV.dragIndicator:SetAlpha(0)
    SLV.dragIndicator:Show()
    local fadeElapsed = 0
    SLV.dragIndicator:SetScript("OnUpdate", function(self, dt)
        fadeElapsed = fadeElapsed + dt
        local alpha = math.min(fadeElapsed / 0.1, 1)
        self:SetAlpha(alpha)
        if alpha >= 1 then
            self:SetScript("OnUpdate", nil)
        end
    end)

    -- OnUpdate: track cursor, position ghost and indicator
    ghost:SetScript("OnUpdate", function()
        if not SLV._isDragging then
            ghost:SetScript("OnUpdate", nil)
            return
        end
        local scale = UIParent:GetEffectiveScale()
        local cursorX, cursorY = GetCursorPosition()
        cursorX = cursorX / scale
        cursorY = cursorY / scale
        ghost:ClearAllPoints()
        ghost:SetPoint("CENTER", UIParent, "BOTTOMLEFT", cursorX, cursorY)

        -- Auto-scroll when cursor is near ScrollBox edges
        local sbTopEdge = SLV.scrollBox:GetTop()
        local sbBottomEdge = SLV.scrollBox:GetBottom()
        if sbTopEdge and sbBottomEdge then
            local edgeZone = D().DRAG_SCROLL_EDGE_ZONE
            if cursorY > (sbTopEdge - edgeZone) then
                local pct = SLV.scrollBox:GetScrollPercentage()
                if pct and pct > 0 then
                    SLV.scrollBox:SetScrollPercentage(math.max(0, pct - D().DRAG_SCROLL_INCREMENT))
                end
            elseif cursorY < (sbBottomEdge + edgeZone) then
                local pct = SLV.scrollBox:GetScrollPercentage()
                if pct and pct < 1 then
                    SLV.scrollBox:SetScrollPercentage(math.min(1, pct + D().DRAG_SCROLL_INCREMENT))
                end
            end
        end

        -- Geometry-based drop target: walk the rendered rows, find the one the
        -- cursor is over, and choose insert-before (upper half) or insert-after
        -- (lower half). Reading each row's real top / bottom makes this
        -- height-agnostic (step rows 24, node rows 28) and scroll-safe (each
        -- row carries its absolute data index in _stepData). The old
        -- floor(distance / fixed-height) math drifted once a taller node row or
        -- any scroll offset was present. Default to the previous target so a
        -- tick where the cursor is over a gap keeps the last good value and the
        -- downstream indicator loop never sees a nil index.
        local dropKey = SLV._dragMode == "outline" and "nodeIndex" or "index"
        local targetIdx = SLV._dragTargetIndex or 1
        for _, frame in ipairs(SLV.scrollBox:GetFrames() or {}) do
            if frame._stepData and frame.IsShown and frame:IsShown() then
                local fIdx = frame._stepData[dropKey]
                local top = frame:GetTop()
                local bottom = frame:GetBottom()
                if fIdx and top and bottom and cursorY <= top and cursorY >= bottom then
                    local mid = (top + bottom) / 2
                    if cursorY >= mid then
                        targetIdx = fIdx
                    else
                        targetIdx = fIdx + 1
                    end
                    break
                end
            end
        end
        targetIdx = math.max(1, math.min(itemCount + 1, targetIdx))
        SLV._dragTargetIndex = targetIdx

        -- Reparent detection: a top-level node over the MIDDLE band of a Loop row
        -- reparents INTO that loop; the top/bottom edge bands keep the existing
        -- reorder-insertion behaviour. Loop rows only, outline mode only, and
        -- never the dragged node itself. Read each row's real top/bottom so the
        -- band is height-agnostic (rows are 24/28px) and scroll-safe.
        local reparentIdx = nil
        if SLV._dragMode == "outline" then
            for _, frame in ipairs(SLV.scrollBox:GetFrames() or {}) do
                local sd = frame._stepData
                if
                    sd
                    and sd.rowType == "node"
                    and sd.nodeType == D().ACTION_TYPE_LOOP
                    and sd.nodeIndex
                    and sd.nodeIndex ~= SLV._dragSourceIndex
                    and frame.IsShown
                    and frame:IsShown()
                then
                    local top = frame:GetTop()
                    local bottom = frame:GetBottom()
                    if top and bottom then
                        local band = (top - bottom) * 0.25
                        if cursorY <= (top - band) and cursorY >= (bottom + band) then
                            reparentIdx = sd.nodeIndex
                            break
                        end
                    end
                end
            end
        end
        local intoDetail = false
        if
            SLV._dragMode == "outline"
            and SLV._detailOpen
            and SLV._detailContainer
            and SLV._detailContainer:IsShown()
            and type(SLV._detailNode) == "table"
            and (SLV._detailNode.type == D().ACTION_TYPE_LOOP or SLV._detailNode.type == D().ACTION_TYPE_IF)
            and SLV._detailNode ~= SLV.workingActions[SLV._dragSourceIndex]
            and cursorOverFrame(SLV._detailContainer)
        then
            intoDetail = true
            reparentIdx = nil
        end
        SLV._dragIntoDetail = intoDetail
        SLV._dragReparentIndex = reparentIdx

        -- The detail-pane tint, the loop-row highlight and the insertion line
        -- are mutually exclusive.
        if SLV._dragIntoDetail then
            SLV.dragIndicator:Hide()
            local hl = SLV.dragReparentHighlight
            if hl then
                hl:ClearAllPoints()
                hl:SetAllPoints(SLV._detailContainer)
                hl:Show()
            end
        elseif reparentIdx then
            SLV.dragIndicator:Hide()
            local hl = SLV.dragReparentHighlight
            if hl then
                local targetFrame
                for _, frame in ipairs(SLV.scrollBox:GetFrames() or {}) do
                    if frame._stepData and frame._stepData.nodeIndex == reparentIdx then
                        targetFrame = frame
                        break
                    end
                end
                if targetFrame then
                    hl:ClearAllPoints()
                    hl:SetAllPoints(targetFrame)
                    hl:Show()
                else
                    hl:Hide()
                end
            end
        else
            if SLV.dragReparentHighlight then
                SLV.dragReparentHighlight:Hide()
            end

            -- Position insertion indicator between rows
            local indicator = SLV.dragIndicator
            local anchorFrame, anchorPoint
            -- In outline mode, match by nodeIndex; in flat mode, match by index
            local matchKey = SLV._dragMode == "outline" and "nodeIndex" or "index"
            for _, frame in ipairs(SLV.scrollBox:GetFrames() or {}) do
                if frame._stepData then
                    local frameIdx = frame._stepData[matchKey]
                    if targetIdx <= itemCount and frameIdx == targetIdx then
                        anchorFrame = frame
                        anchorPoint = "TOPLEFT"
                        break
                    elseif targetIdx > itemCount and frameIdx == itemCount then
                        anchorFrame = frame
                        anchorPoint = "BOTTOMLEFT"
                        break
                    end
                end
            end
            if anchorFrame then
                indicator:ClearAllPoints()
                if anchorPoint == "TOPLEFT" then
                    indicator:SetPoint("BOTTOMLEFT", anchorFrame, "TOPLEFT", 0, 0)
                    indicator:SetPoint("BOTTOMRIGHT", anchorFrame, "TOPRIGHT", 0, 0)
                else
                    indicator:SetPoint("TOPLEFT", anchorFrame, "BOTTOMLEFT", 0, 0)
                    indicator:SetPoint("TOPRIGHT", anchorFrame, "BOTTOMRIGHT", 0, 0)
                end
                indicator:Show()
            else
                indicator:Hide()
            end
        end
    end)
end

--- End a drag operation in the outline scrollBox. Performs the reorder.
--- @param button Frame The row frame that initiated the drag
function SLV:_endOutlineDrag(button)
    SLV._isDragging = false
    SLV.dragIndicator:Hide()

    local ghost = SLV.dragGhost
    ghost:SetScript("OnUpdate", nil)

    local src = SLV._dragSourceIndex
    local dst = SLV._dragTargetIndex
    local mode = SLV._dragMode or "flat"
    SLV._dragSourceIndex = nil
    SLV._dragTargetIndex = nil
    SLV._dragMode = nil

    local reparentIdx = SLV._dragReparentIndex
    local intoDetail = SLV._dragIntoDetail
    SLV._dragReparentIndex = nil
    SLV._dragIntoDetail = nil
    if SLV.dragReparentHighlight then
        SLV.dragReparentHighlight:Hide()
    end

    -- Detail-pane drop (drag into the open container) takes priority over the
    -- loop-row reparent and the reorder path below.
    if mode == "outline" and intoDetail and src and type(SLV._detailNode) == "table" then
        SLV.dragIndicator:Hide()
        ghost:SetScript("OnUpdate", nil)
        ghost:Hide()
        button:SetAlpha(1.0)
        local ok, reason = SLV:_reparentNodeIntoContainer(src, SLV._detailNode, SLV._detailSelectedBranch)
        if not ok and reason == "depth" then
            GRIPEMS:Print(string.format(L["GEMS_REPARENT_DEPTH_REJECT"], D().ACTION_MAX_DEPTH))
        end
        return
    end

    -- Reparent drop (drag into a Loop) short-circuits the reorder path.
    if mode == "outline" and reparentIdx and src then
        SLV.dragIndicator:Hide()
        ghost:SetScript("OnUpdate", nil)
        ghost:Hide()
        button:SetAlpha(1.0)
        local ok, reason = SLV:_reparentNodeIntoLoop(src, reparentIdx)
        if not ok and reason == "depth" then
            GRIPEMS:Print(string.format(L["GEMS_REPARENT_DEPTH_REJECT"], D().ACTION_MAX_DEPTH))
        end
        return
    end

    local itemArray = mode == "outline" and SLV.workingActions or SLV.workingSteps
    local itemCount = itemArray and #itemArray or 0

    -- Clamp dst for cancel detection
    local clampedDst = dst
    if dst and src then
        clampedDst = math.max(1, math.min(itemCount, dst))
    end
    local isCancel = (not src or not dst or src == clampedDst)

    if isCancel then
        -- Snap-back animation
        if src then
            local startX, startY = ghost:GetCenter()
            local targetFrame
            local matchKey = mode == "outline" and "nodeIndex" or "index"
            for _, frame in ipairs(SLV.scrollBox:GetFrames() or {}) do
                if frame._stepData and frame._stepData[matchKey] == src then
                    targetFrame = frame
                    break
                end
            end
            if targetFrame and startX and startY then
                local targetX, targetY = targetFrame:GetCenter()
                if targetX and targetY then
                    local elapsed = 0
                    local duration = 0.15
                    ghost:SetScript("OnUpdate", function(_, dt)
                        elapsed = elapsed + dt
                        local t = math.min(elapsed / duration, 1)
                        t = 1 - (1 - t) * (1 - t)
                        local cx = startX + (targetX - startX) * t
                        local cy = startY + (targetY - startY) * t
                        ghost:ClearAllPoints()
                        ghost:SetPoint("CENTER", UIParent, "BOTTOMLEFT", cx, cy)
                        ghost:SetAlpha(0.7 * (1 - t))
                        if elapsed >= duration then
                            ghost:SetScript("OnUpdate", nil)
                            ghost:Hide()
                            ghost:SetAlpha(0.7)
                        end
                    end)
                    button:SetAlpha(1.0)
                    return
                end
            end
        end
        ghost:Hide()
        button:SetAlpha(1.0)
        return
    end

    -- Success path: perform reorder
    ghost:Hide()
    button:SetAlpha(1.0)

    dst = clampedDst
    local item = table.remove(itemArray, src)
    local insertAt = dst
    if dst > src then
        insertAt = dst - 1
    end
    table.insert(itemArray, insertAt, item)

    if mode == "flat" then
        local lbl = table.remove(SLV.workingStepLabels, src)
        table.insert(SLV.workingStepLabels, insertAt, lbl)
    end

    if mode == "flat" then
        SLV.selectedIndex = insertAt
        -- A flat drag-reorder shifts indices, so an active multi-selection
        -- would point at the wrong rows (and a follow-up bulk Delete/Duplicate
        -- would act on them). Collapse to a single selection on the dropped
        -- row, mirroring the Up/Down arrow-nav collapse.
        if SLV:IsMultiSelect() then
            SLV.selectedSet = nil
            SLV.selectionAnchor = insertAt
        end
    end

    -- Undo
    if not SLV._suppressUndo then
        local US = GRIPEMS.UndoStack
        if US then
            local fromSrc = src
            local toAt = insertAt
            local undoMode = mode
            US:Push(function()
                local arr = undoMode == "outline" and SLV.workingActions or SLV.workingSteps
                if arr then
                    local s = table.remove(arr, toAt)
                    local restoreAt = fromSrc
                    if fromSrc > toAt then
                        restoreAt = fromSrc
                    end
                    table.insert(arr, restoreAt, s)
                    if undoMode == "flat" then
                        SLV.selectedIndex = restoreAt
                    end
                end
                if undoMode == "flat" then
                    local lbl = table.remove(SLV.workingStepLabels, toAt)
                    local restoreAtLbl = fromSrc
                    if fromSrc > toAt then
                        restoreAtLbl = fromSrc
                    end
                    table.insert(SLV.workingStepLabels, restoreAtLbl, lbl)
                end
                SLV:_markDirty()
                SLV:RefreshAll()
            end, function()
                local arr = undoMode == "outline" and SLV.workingActions or SLV.workingSteps
                if arr then
                    local s = table.remove(arr, fromSrc)
                    local redoAt = toAt
                    if toAt > fromSrc then
                        redoAt = toAt
                    end
                    table.insert(arr, redoAt, s)
                    if undoMode == "flat" then
                        SLV.selectedIndex = redoAt
                    end
                end
                if undoMode == "flat" then
                    local lbl = table.remove(SLV.workingStepLabels, fromSrc)
                    local redoAtLbl = toAt
                    if toAt > fromSrc then
                        redoAtLbl = toAt
                    end
                    table.insert(SLV.workingStepLabels, redoAtLbl, lbl)
                end
                SLV:_markDirty()
                SLV:RefreshAll()
            end, "Reorder " .. (undoMode == "outline" and "action" or "step"))
        end
    end

    SLV:_markDirty()
    SLV:RefreshAll()
end

--- Move the top-level workingActions node at srcIdx INTO the Loop node at
--- loopIdx (append to its children). Returns true on success, or
--- false, "<reason>" on rejection. Pushes an undo entry on success.
--- @param srcIdx number Index of the dragged node in SLV.workingActions
--- @param loopIdx number Index of the target Loop in SLV.workingActions
--- @return boolean ok
--- @return string|nil reason "self" | "type" | "range" | "depth"
function SLV:_reparentNodeIntoLoop(srcIdx, loopIdx)
    local defaults = D()
    if not SLV.hasActions or type(SLV.workingActions) ~= "table" then
        return false, "type"
    end
    if not srcIdx or not loopIdx or srcIdx == loopIdx then
        return false, "self"
    end
    local moved = SLV.workingActions[srcIdx]
    local loopNode = SLV.workingActions[loopIdx]
    if not moved or not loopNode then
        return false, "range"
    end
    if loopNode.type ~= defaults.ACTION_TYPE_LOOP then
        return false, "type"
    end
    local loopDepth = SLV:_computeNodeDepth(loopNode) or 1
    if (loopDepth + 1 + reparentSubtreeHeight(moved)) > defaults.ACTION_MAX_DEPTH then
        return false, "depth"
    end

    table.remove(SLV.workingActions, srcIdx)
    loopNode.children = loopNode.children or {}
    loopNode.children[#loopNode.children + 1] = moved

    if not SLV._suppressUndo then
        local US = GRIPEMS.UndoStack
        if US then
            local restoreAt = srcIdx
            local theNode = moved
            local theLoop = loopNode
            US:Push(function()
                for i = #theLoop.children, 1, -1 do
                    if theLoop.children[i] == theNode then
                        table.remove(theLoop.children, i)
                        break
                    end
                end
                table.insert(SLV.workingActions, math.min(restoreAt, #SLV.workingActions + 1), theNode)
                SLV:_markDirty()
                SLV:RefreshAll()
            end, function()
                for i = #SLV.workingActions, 1, -1 do
                    if SLV.workingActions[i] == theNode then
                        table.remove(SLV.workingActions, i)
                        break
                    end
                end
                theLoop.children = theLoop.children or {}
                theLoop.children[#theLoop.children + 1] = theNode
                SLV:_markDirty()
                SLV:RefreshAll()
            end, "Reparent step into loop")
        end
    end

    SLV:_markDirty()
    if SLV._detailOpen then
        SLV:_renderDetailPane()
    end
    SLV:RefreshAll()
    return true
end

--- Move the top-level workingActions node at srcIdx INTO containerNode
--- (a Loop -> its children; an If -> branchIndex, default the active
--- branch). containerNode is passed BY REFERENCE so a nested open
--- container works. Returns true, or false + reason.
--- @param srcIdx number Index in SLV.workingActions of the dragged node
--- @param containerNode table The open Loop/If node to drop into
--- @param branchIndex number|nil If-branch (1=true,2=false); default active
--- @return boolean ok
--- @return string|nil reason "type" | "range" | "self" | "cycle" | "depth"
function SLV:_reparentNodeIntoContainer(srcIdx, containerNode, branchIndex)
    local defaults = D()
    if not SLV.hasActions or type(SLV.workingActions) ~= "table" then
        return false, "type"
    end
    if not srcIdx or type(containerNode) ~= "table" then
        return false, "range"
    end
    local moved = SLV.workingActions[srcIdx]
    if not moved or moved == containerNode then
        return false, "self"
    end
    local isIf = containerNode.type == defaults.ACTION_TYPE_IF
    if containerNode.type ~= defaults.ACTION_TYPE_LOOP and not isIf then
        return false, "type"
    end
    if subtreeContains(moved, containerNode) then
        return false, "cycle"
    end
    local cDepth = SLV:_computeNodeDepth(containerNode) or 1
    if (cDepth + 1 + reparentSubtreeHeight(moved)) > defaults.ACTION_MAX_DEPTH then
        return false, "depth"
    end

    local destArray
    if isIf then
        local branch = branchIndex or SLV._detailSelectedBranch or 1
        containerNode.children = containerNode.children or { {}, {} }
        containerNode.children[branch] = containerNode.children[branch] or {}
        destArray = containerNode.children[branch]
    else
        containerNode.children = containerNode.children or {}
        destArray = containerNode.children
    end

    table.remove(SLV.workingActions, srcIdx)
    destArray[#destArray + 1] = moved

    if not SLV._suppressUndo then
        local US = GRIPEMS.UndoStack
        if US then
            local restoreAt = srcIdx
            local theNode = moved
            local theArray = destArray
            US:Push(function()
                for i = #theArray, 1, -1 do
                    if theArray[i] == theNode then
                        table.remove(theArray, i)
                        break
                    end
                end
                table.insert(SLV.workingActions, math.min(restoreAt, #SLV.workingActions + 1), theNode)
                SLV:_markDirty()
                SLV:RefreshAll()
            end, function()
                for i = #SLV.workingActions, 1, -1 do
                    if SLV.workingActions[i] == theNode then
                        table.remove(SLV.workingActions, i)
                        break
                    end
                end
                theArray[#theArray + 1] = theNode
                SLV:_markDirty()
                SLV:RefreshAll()
            end, "Reparent step into container")
        end
    end

    SLV:_markDirty()
    if SLV._detailOpen then
        SLV:_renderDetailPane()
    end
    SLV:RefreshAll()
    return true
end

---------------------------------------------------------------------------
-- Detail pane drag-to-reorder
---------------------------------------------------------------------------

--- Begin a drag in the detail pane children list.
--- @param row Frame The child row frame
--- @param childIndex number Index of the child in the children array
--- @param branchIndex number|nil For If nodes: 1=true, 2=false
function SLV:_beginDetailDrag(row, childIndex, branchIndex)
    if not SLV._detailNode then
        return
    end
    local defaults = D()
    local node = SLV._detailNode
    local children
    if node.type == defaults.ACTION_TYPE_IF and branchIndex then
        children = node.children and node.children[branchIndex]
    else
        children = node.children
    end
    if not children or #children <= 1 then
        return
    end

    SLV._detailDragSrc = childIndex
    SLV._detailDragBranch = branchIndex
    SLV._detailDragChildren = children
    SLV._isDragging = true

    -- Ghost
    local ghost = SLV.dragGhost
    ghost:SetWidth(SLV._detailScrollFrame and SLV._detailScrollFrame:GetWidth() or 200)
    local child = children[childIndex]
    if child and child.type == defaults.ACTION_TYPE_ACTION then
        ghost.ghostNum:SetText(tostring(childIndex))
        local cm = (type(child.macro) == "string") and child.macro or ""
        ghost.ghostText:SetText(cm:match("^([^\n]*)") or "")
    else
        local iconInfo = defaults.NODE_ICONS[child and child.type or "loop"] or { symbol = "?", label = "Node" }
        ghost.ghostNum:SetText("[" .. iconInfo.symbol .. "]")
        ghost.ghostText:SetText(child and child.name ~= "" and child.name or iconInfo.label)
    end
    ghost:ClearAllPoints()
    ghost:SetAlpha(0.7)
    ghost:Show()
    row:SetAlpha(0.3)

    ghost:SetScript("OnUpdate", function()
        if not SLV._isDragging then
            ghost:SetScript("OnUpdate", nil)
            return
        end
        local scale = UIParent:GetEffectiveScale()
        local cursorX, cursorY = GetCursorPosition()
        cursorX = cursorX / scale
        cursorY = cursorY / scale
        ghost:ClearAllPoints()
        ghost:SetPoint("CENTER", UIParent, "BOTTOMLEFT", cursorX, cursorY)

        -- Geometry-based target over the rendered child rows of the dragged
        -- branch. Height-agnostic and correct for If nodes: the pane mixes 18px
        -- branch labels with 28px rows, and each branch is its own index space,
        -- so the old floor((paneTop - cursorY) / 28) math (measured from the
        -- whole pane, indexed into one branch) sent every False-branch drag to
        -- the end. Branch labels and preview frames carry no _childIndex, so the
        -- walk skips them; _branchIndex is nil for non-If nodes and matches the
        -- nil drag branch, so Loop / Embed / Pause keep working unchanged.
        if SLV._detailScrollChild then
            local dragBranch = SLV._detailDragBranch
            local target = SLV._detailDragTarget or 1
            for _, frame in pairs({ SLV._detailScrollChild:GetChildren() }) do
                if frame._childIndex and frame._branchIndex == dragBranch and frame.IsShown and frame:IsShown() then
                    local top = frame:GetTop()
                    local bottom = frame:GetBottom()
                    if top and bottom and cursorY <= top and cursorY >= bottom then
                        local mid = (top + bottom) / 2
                        if cursorY >= mid then
                            target = frame._childIndex
                        else
                            target = frame._childIndex + 1
                        end
                        break
                    end
                end
            end
            SLV._detailDragTarget = math.max(1, math.min(#children + 1, target))
        end
    end)
end

--- End a drag in the detail pane. Performs the reorder.
--- @param row Frame The child row that was dragged
function SLV:_endDetailDrag(row)
    SLV._isDragging = false
    local ghost = SLV.dragGhost
    ghost:SetScript("OnUpdate", nil)
    ghost:Hide()
    row:SetAlpha(1.0)

    local src = SLV._detailDragSrc
    local dst = SLV._detailDragTarget
    local children = SLV._detailDragChildren
    SLV._detailDragSrc = nil
    SLV._detailDragTarget = nil
    SLV._detailDragBranch = nil
    SLV._detailDragChildren = nil

    if not src or not dst or not children then
        return
    end
    local clampedDst = math.max(1, math.min(#children, dst))
    if src == clampedDst then
        return
    end

    local item = table.remove(children, src)
    local insertAt = clampedDst
    if clampedDst > src then
        insertAt = clampedDst - 1
    end
    table.insert(children, insertAt, item)

    SLV:_markDirty()
    SLV:_renderDetailPane()
    SLV:RefreshAll()
end

--- Migrate a flat sequence (workingSteps) to action tree format.
--- Each existing step string becomes an ACTION_TYPE_ACTION node.
--- Called when the first structural node is inserted into a flat sequence.
--- One-way within the editing session; discard restores original flat steps.
--- @return table workingActions The newly created actions array
function SLV:_migrateToActions()
    local defaults = D()
    local actions = {}
    for _, step in ipairs(SLV.workingSteps) do
        actions[#actions + 1] = {
            type = defaults.ACTION_TYPE_ACTION,
            macro = step,
        }
    end

    -- Snapshot for undo
    local savedSteps = {}
    for i, s in ipairs(SLV.workingSteps) do
        savedSteps[i] = s
    end
    local savedHasActions = SLV.hasActions
    local savedTreeMode = SLV.treeMode

    SLV.workingActions = actions
    SLV.hasActions = true
    SLV.treeMode = true
    SLV.workingSteps = {}
    SLV.selectedIndex = nil
    SLV._editingContext = nil

    -- Push undo for the migration
    local US = GRIPEMS.UndoStack
    if US and not SLV._suppressUndo then
        US:Push(function()
            -- Undo: restore flat steps
            SLV.workingActions = nil
            SLV.hasActions = savedHasActions
            SLV.treeMode = savedTreeMode
            SLV.workingSteps = savedSteps
            SLV.selectedIndex = nil
            SLV._editingContext = nil
            SLV:_markDirty()
            SLV:RefreshAll()
        end, function()
            -- Redo: re-migrate
            SLV:_migrateToActions()
            SLV:_markDirty()
            SLV:RefreshAll()
        end, "Migrate to actions")
    end

    SLV:_markDirty()
    return SLV.workingActions
end

--- Compute the compile-depth of a target node within SLV.workingActions.
--- Returns the depth (1 for root children, 2 for grandchildren, etc.)
--- or nil if targetNode is not in the tree.
--- @param targetNode table|nil The node to locate.
--- @return number|nil depth The compile-depth of targetNode, or nil.
function SLV:_computeNodeDepth(targetNode)
    if not targetNode or not SLV.workingActions then
        return nil
    end
    local function walk(nodes, currentDepth)
        if type(nodes) ~= "table" then
            return nil
        end
        for _, n in ipairs(nodes) do
            if n == targetNode then
                return currentDepth
            end
            if type(n.children) == "table" then
                -- Discriminate the If shape (children = { trueArray, falseArray })
                -- from the Loop / other container shape (flat node array) by
                -- node.type -- NOT by whether children[1] is populated. An
                -- else-only If (empty true branch, populated false branch) must
                -- still be descended through BOTH branch arrays; the old
                -- children[1][1] heuristic treated it as a flat array, never
                -- found a node in the false branch, and returned nil -- which
                -- skips the + Add depth gate (see reparentSubtreeHeight).
                if n.type == D().ACTION_TYPE_IF then
                    for _, branch in ipairs(n.children) do
                        local d = walk(branch, currentDepth + 1)
                        if d then
                            return d
                        end
                    end
                else
                    local d = walk(n.children, currentDepth + 1)
                    if d then
                        return d
                    end
                end
            end
        end
        return nil
    end
    return walk(SLV.workingActions, 1)
end

--- Show the + Add dropdown menu for creating new nodes.
--- Used by both the detail pane toolbar and outline actionBar.
--- @param anchor Frame The button to anchor the menu to
--- @param isDetailPane boolean True if called from detail pane, false if from outline
function SLV:_showAddMenu(anchor, isDetailPane)
    local defaults = D()
    MenuUtil.CreateContextMenu(anchor, function(_, rootDescription)
        -- Depth gate: at compile time, ActionCompiler.lua:106 drops ANY
        -- node (leaf or container) whose depth exceeds D.ACTION_MAX_DEPTH.
        -- If isDetailPane and _detailNode sits at compile-depth D where
        -- D+1 > MAX, every add child would be dropped -- so disable all
        -- add options and show a hint. Pause's leaf-ness is irrelevant;
        -- it drops the same way as Loop at depth MAX+1.
        local addDisabled = false
        if isDetailPane and SLV._detailNode then
            local currentDepth = SLV:_computeNodeDepth(SLV._detailNode)
            if currentDepth and (currentDepth + 1) > defaults.ACTION_MAX_DEPTH then
                addDisabled = true
            end
        end

        if addDisabled then
            rootDescription:CreateTitle(
                string.format(
                    L["GEMS_ADD_MENU_DEPTH_CAP_HINT"] or "Max nesting depth (%d) reached",
                    defaults.ACTION_MAX_DEPTH
                )
            )
        end

        local stepBtn = rootDescription:CreateButton("Step", function()
            if isDetailPane then
                SLV:_detailAddChild(defaults.ACTION_TYPE_ACTION)
            else
                -- Outline: flat vs actions
                if SLV.hasActions then
                    SLV:AddAction(defaults.ACTION_TYPE_ACTION)
                else
                    SLV:AddStep()
                end
            end
        end)
        if addDisabled then
            stepBtn:SetEnabled(false)
        end

        local interleaveBtn = rootDescription:CreateButton(
            L["GEMS_ADD_ACTION_INTERLEAVE"] or "Action (Interleave)",
            function()
                if isDetailPane then
                    if not SLV._detailNode then
                        return
                    end
                    local node = SLV._detailNode
                    local newChild = defaults.NewActionNode(defaults.ACTION_TYPE_ACTION)
                    newChild.interval = defaults.ACTION_INTERLEAVE_DEFAULT
                    if node.type == defaults.ACTION_TYPE_IF then
                        local branch = SLV._detailSelectedBranch or 1
                        if not node.children then
                            node.children = { {}, {} }
                        end
                        if not node.children[branch] then
                            node.children[branch] = {}
                        end
                        node.children[branch][#node.children[branch] + 1] = newChild
                    else
                        if not node.children then
                            node.children = {}
                        end
                        node.children[#node.children + 1] = newChild
                    end
                    SLV:_markDirty()
                    SLV:_renderDetailPane()
                    SLV:RefreshAll()
                else
                    if not SLV.hasActions then
                        SLV:_migrateToActions()
                    end
                    SLV:AddAction(defaults.ACTION_TYPE_ACTION)
                    if SLV.workingActions and #SLV.workingActions > 0 then
                        local newAction = SLV.workingActions[#SLV.workingActions]
                        newAction.interval = defaults.ACTION_INTERLEAVE_DEFAULT
                        SLV:_markDirty()
                        SLV:RefreshAll()
                    end
                end
            end
        )
        if addDisabled then
            interleaveBtn:SetEnabled(false)
        end

        local macroBtn = rootDescription:CreateButton(L["GEMS_ADD_ACTION_MACRO"] or "Macro", function()
            GRIPEMS.MacroPicker:Show(function(sel)
                if not sel then
                    return
                end
                local newNode = {
                    type = defaults.ACTION_TYPE_ACTION,
                    subtype = defaults.ACTION_SUBTYPE_MACROREF,
                    macroName = sel.name,
                    macro = sel.body or "",
                    macroRefSynced = sel.body or "",
                }
                if isDetailPane then
                    if not SLV._detailNode then
                        return
                    end
                    local node = SLV._detailNode
                    if node.type == defaults.ACTION_TYPE_IF then
                        local branch = SLV._detailSelectedBranch or 1
                        if not node.children then
                            node.children = { {}, {} }
                        end
                        if not node.children[branch] then
                            node.children[branch] = {}
                        end
                        node.children[branch][#node.children[branch] + 1] = newNode
                    else
                        if not node.children then
                            node.children = {}
                        end
                        node.children[#node.children + 1] = newNode
                    end
                    SLV:_markDirty()
                    SLV:_renderDetailPane()
                    SLV:RefreshAll()
                else
                    if not SLV.hasActions then
                        SLV:_migrateToActions()
                    end
                    SLV.workingActions[#SLV.workingActions + 1] = newNode
                    SLV:_markDirty()
                    SLV:RefreshAll()
                    local newIdx = #SLV.workingActions
                    if newIdx > 0 then
                        SLV:OpenDetailPane(newIdx)
                    end
                end
            end)
        end)
        if addDisabled then
            macroBtn:SetEnabled(false)
        end

        rootDescription:CreateDivider()

        local structTypes = {
            { key = defaults.ACTION_TYPE_LOOP, icon = "L", label = "Loop" },
            { key = defaults.ACTION_TYPE_PAUSE, icon = "P", label = "Pause" },
            { key = defaults.ACTION_TYPE_IF, icon = "?", label = "If" },
            { key = defaults.ACTION_TYPE_EMBED, icon = "E", label = "Embed" },
        }

        for _, def in ipairs(structTypes) do
            local entry = rootDescription:CreateButton("[" .. def.icon .. "] " .. def.label, function()
                if isDetailPane then
                    SLV:_detailAddChild(def.key)
                else
                    -- Outline: migrate if flat, then insert
                    if not SLV.hasActions then
                        SLV:_migrateToActions()
                    end
                    SLV:AddAction(def.key)
                    -- Auto-open detail pane for the new node and focus name
                    local newIdx = SLV.workingActions and #SLV.workingActions or 0
                    if newIdx > 0 then
                        SLV:OpenDetailPane(newIdx)
                        if C_Timer and C_Timer.After then
                            C_Timer.After(0, function()
                                if SLV._detailNameEditBox then
                                    SLV._detailNameEditBox:SetFocus()
                                end
                            end)
                        end
                    end
                end
            end)
            if addDisabled then
                entry:SetEnabled(false)
            end
        end
    end)
end

--- Detail pane toolbar: add a new child of the given type to the current node.
--- @param nodeType string|nil One of D.ACTION_TYPE_* (defaults to ACTION_TYPE_ACTION)
function SLV:_detailAddChild(nodeType)
    if not SLV._detailNode then
        return
    end
    local defaults = D()
    local node = SLV._detailNode
    local newChild = defaults.NewActionNode(nodeType or defaults.ACTION_TYPE_ACTION)

    if node.type == defaults.ACTION_TYPE_IF then
        -- Add to the branch that has the selected child, or true by default
        local branch = SLV._detailSelectedBranch or 1
        if not node.children then
            node.children = { {}, {} }
        end
        if not node.children[branch] then
            node.children[branch] = {}
        end
        node.children[branch][#node.children[branch] + 1] = newChild
    else
        if not node.children then
            node.children = {}
        end
        node.children[#node.children + 1] = newChild
    end

    SLV:_markDirty()
    SLV:_renderDetailPane()
    SLV:RefreshAll()
end

--- Detail pane toolbar: duplicate the selected child.
function SLV:_detailDupChild()
    if not SLV._detailNode or not SLV._detailSelectedChild then
        return
    end
    local defaults = D()
    local node = SLV._detailNode
    local idx = SLV._detailSelectedChild
    local children

    if node.type == defaults.ACTION_TYPE_IF then
        local branch = SLV._detailSelectedBranch or 1
        children = node.children and node.children[branch]
    else
        children = node.children
    end

    if not children or not children[idx] then
        return
    end
    local copy = defaults.DeepCopyActions({ children[idx] })[1]
    table.insert(children, idx + 1, copy)

    SLV:_markDirty()
    SLV:_renderDetailPane()
    SLV:RefreshAll()
end

--- Detail pane toolbar: move selected child up or down.
--- @param direction number -1 for up, +1 for down
function SLV:_detailMoveChild(direction)
    if not SLV._detailNode or not SLV._detailSelectedChild then
        return
    end
    local defaults = D()
    local node = SLV._detailNode
    local idx = SLV._detailSelectedChild
    local children

    if node.type == defaults.ACTION_TYPE_IF then
        local branch = SLV._detailSelectedBranch or 1
        children = node.children and node.children[branch]
    else
        children = node.children
    end

    if not children then
        return
    end
    local target = idx + direction
    if target < 1 or target > #children then
        return
    end
    children[idx], children[target] = children[target], children[idx]
    SLV._detailSelectedChild = target

    SLV:_markDirty()
    SLV:_renderDetailPane()
    SLV:RefreshAll()
end

--- Detail pane toolbar: delete the selected child of a container, OR the
--- active node itself when it is a leaf (Action / Pause / Embed). Leaf
--- fall-through option (a): mirrors the outline Del path so leaf macro-refs,
--- pauses, and embeds can be removed from the detail pane without bouncing
--- back to the outline first.
function SLV:_detailDeleteChild()
    if not SLV._detailNode then
        return
    end
    local defaults = D()
    local node = SLV._detailNode

    -- Leaf detection: ACTION (covers macro-ref subtype), Pause, Embed --
    -- nodes that have no children container.
    local isLeaf = (node.type == defaults.ACTION_TYPE_ACTION)
        or (node.type == defaults.ACTION_TYPE_PAUSE)
        or (node.type == defaults.ACTION_TYPE_EMBED)
    if isLeaf then
        local ni = SLV._detailNodeIndex
        if ni and SLV.workingActions and SLV.workingActions[ni] then
            table.remove(SLV.workingActions, ni)
            SLV:CloseDetailPane()
            SLV._editingContext = nil
            SLV.selectedIndex = nil
            SLV:_markDirty()
            SLV:RefreshAll()
        end
        return
    end

    -- Container path (Loop / If): delete the selected child.
    if not SLV._detailSelectedChild then
        return
    end
    local idx = SLV._detailSelectedChild
    local children

    if node.type == defaults.ACTION_TYPE_IF then
        local branch = SLV._detailSelectedBranch or 1
        children = node.children and node.children[branch]
    else
        children = node.children
    end

    if not children or not children[idx] then
        return
    end
    table.remove(children, idx)
    SLV._detailSelectedChild = nil
    SLV._detailSelectedBranch = nil
    SLV._editingContext = nil

    SLV:_markDirty()
    SLV:_renderDetailPane()
    SLV:RefreshAll()
end

--- Clear the step list to empty state.
function SLV:Clear()
    SLV.workingSteps = {}
    SLV.originalSteps = {}
    SLV.workingStepLabels = {}
    SLV.originalStepLabels = {}
    SLV.selectedIndex = nil
    SLV.selectedSet = nil
    SLV.selectionAnchor = nil
    SLV._lastLineCount = 0
    SLV.treeMode = false
    SLV.hasActions = false
    SLV.workingActions = nil
    SLV._originalActionsSerialized = nil

    -- Reset detail pane state
    SLV._detailOpen = false
    SLV._detailNavStack = nil
    SLV._detailNode = nil
    SLV._detailNodeIndex = nil
    SLV._detailSelectedChild = nil
    SLV._detailSelectedBranch = nil
    SLV._editingContext = nil
    if SLV._detailContainer then
        SLV._detailContainer:Hide()
    end

    if SLV.scrollView then
        local dp = CreateDataProvider()
        SLV.scrollBox:SetDataProvider(dp)
        SLV.dataProvider = dp
    end

    -- Overlap guard: Clear runs when a sequence is deselected, which can
    -- happen from any editor tab. Reset state always; Show only on Steps.
    local SEd = GRIPEMS.SequenceEditor
    local onStepsTab = not SEd or SEd.activeTab == "Steps"
    if onStepsTab and SLV.emptyIcon then
        SLV.emptyIcon:Show()
    end
    if onStepsTab and SLV.emptyLabel then
        SLV.emptyLabel:Show()
    end
    if onStepsTab and SLV.hintLabel then
        SLV.hintLabel:Show()
    end
    if SLV.editArea then
        SLV.editArea:Hide()
    end
    if SLV.selectLabel then
        SLV.selectLabel:Hide()
    end

    -- Reset scrollBox to full-width layout
    if SLV.scrollBox then
        SLV.scrollBox:ClearAllPoints()
        SLV.scrollBox:SetPoint("TOPLEFT", SLV.container, "TOPLEFT", 4, -4)
        SLV.scrollBox:SetPoint("RIGHT", SLV.container, "RIGHT", -18, 0)
        SLV.scrollBox:SetPoint("BOTTOM", SLV.actionBar, "TOP", 0, 4)
        if onStepsTab then
            SLV.scrollBox:Show()
        end
    end
    if SLV.scrollBar then
        SLV.scrollBar:ClearAllPoints()
        SLV.scrollBar:SetPoint("TOPLEFT", SLV.scrollBox, "TOPRIGHT", 2, 0)
        SLV.scrollBar:SetPoint("BOTTOMLEFT", SLV.scrollBox, "BOTTOMRIGHT", 2, 0)
        if onStepsTab then
            SLV.scrollBar:Show()
        end
    end
end

---------------------------------------------------------------------------
-- Button state management
---------------------------------------------------------------------------

--- Update enabled/disabled state of action buttons.
function SLV:UpdateButtonStates()
    if SLV._updatingButtons then
        return
    end
    SLV._updatingButtons = true

    local C = UI.Colors
    local sel = SLV.selectedIndex
    local count = #SLV.workingSteps
    local multi = SLV:IsMultiSelect()

    local treeNi, treeCount
    if SLV.hasActions and SLV.workingActions then
        treeNi = (SLV._editingContext and SLV._editingContext.nodeIndex) or (SLV._detailOpen and SLV._detailNodeIndex)
        treeCount = #SLV.workingActions
    end

    local function setEnabled(btn, enabled)
        if not btn then
            return
        end
        if enabled then
            btn:Enable()
            btn.label:SetTextColor(C.textPrimary:GetRGBA())
            btn:SetBackdropColor(C.bgButton:GetRGBA())
            btn:SetBackdropBorderColor(C.border:GetRGBA())
        else
            btn:Disable()
            btn.label:SetTextColor(C.textMuted:GetRGBA())
            btn:SetBackdropColor(C.bgDeep:GetRGBA())
            btn:SetBackdropBorderColor(C.border:GetRGBA())
        end
    end

    -- Add is always enabled
    setEnabled(SLV.actionButtons["add"], true)
    -- Dup/Del need selection (tree nodeIndex or flat selectedIndex)
    setEnabled(SLV.actionButtons["dup"], sel ~= nil or treeNi ~= nil)
    setEnabled(SLV.actionButtons["del"], sel ~= nil or treeNi ~= nil)
    -- Up needs selection and not first
    setEnabled(SLV.actionButtons["up"], (treeNi and treeNi > 1) or (not multi and sel ~= nil and sel > 1))
    -- Down needs selection and not last
    setEnabled(SLV.actionButtons["down"], (treeNi and treeNi < treeCount) or (not multi and sel ~= nil and sel < count))

    SLV._updatingButtons = false
end

---------------------------------------------------------------------------
-- Edit area management
---------------------------------------------------------------------------

--- Update the edit area based on current selection.
function SLV:UpdateEditArea()
    if SLV.autocompleteDropdown then
        SLV.autocompleteDropdown:Hide()
    end
    if not SLV.editArea then
        return
    end

    -- Overlap guard: never assert edit-area visibility while another editor
    -- tab owns the content area (see the RefreshAll guard). hideStepListView
    -- already hid these widgets; Steps-tab return re-runs this function.
    do
        local SEd = GRIPEMS.SequenceEditor
        if SEd and SEd.activeTab ~= "Steps" then
            return
        end
    end

    if SLV.multiSelectLabel then
        SLV.multiSelectLabel:Hide()
    end
    if SLV:IsMultiSelect() then
        SLV.editArea:Show()
        if SLV.editLabelBox then
            SLV.editLabelBox:Hide()
        end
        if SLV.editLabelHint then
            SLV.editLabelHint:Hide()
        end
        if SLV.editBox then
            SLV.editScrollFrame:Hide()
            SLV.editScrollBar:Hide()
        end
        if SLV.selectLabel then
            SLV.selectLabel:Hide()
        end
        if SLV.multiSelectLabel then
            SLV.multiSelectLabel:SetText(string.format(L["GEMS_UI_STEPS_SELECTED"], #SLV:GetSelectionList()))
            SLV.multiSelectLabel:Show()
        end
        return
    end

    local defaults = D()
    local ctx = SLV._editingContext

    -- Lazy-create the label EditBox + placeholder hint (shared across flat/outline/detail).
    local function _ensureLabelBox()
        if not SLV.editLabelBox then
            local labelBox = CreateFrame("EditBox", nil, SLV.editArea, "BackdropTemplate")
            labelBox:SetHeight(20)
            labelBox:SetMultiLine(false)
            labelBox:SetAutoFocus(false)
            labelBox:SetMaxLetters(40)
            UI:ApplyBackdrop(labelBox, UI.Backdrops.panel, UI.Colors.bgInput, UI.Colors.border)
            labelBox:SetTextInsets(6, 6, 2, 2)
            local fp = GameFontNormal:GetFont()
            labelBox:SetFont(fp, 11, "")
            labelBox:SetTextColor(UI.Colors.textPrimary:GetRGBA())
            labelBox:SetPoint("TOPLEFT", SLV.editHeader, "BOTTOMLEFT", 0, -4)
            labelBox:SetPoint("RIGHT", SLV.editArea, "RIGHT", -4, 0)
            labelBox:SetScript("OnEscapePressed", function(self)
                self:ClearFocus()
            end)
            labelBox:SetScript("OnEnterPressed", function(self)
                self:ClearFocus()
            end)
            SLV.editLabelBox = labelBox
            GRIPEMS.Focus:HookEditBox(labelBox)

            local labelHint = SLV.editArea:CreateFontString(nil, "OVERLAY")
            UI:SetFont(labelHint, 10)
            labelHint:SetPoint("LEFT", labelBox, "LEFT", 8, 0)
            labelHint:SetText(L["ACCESS_STEP_LABEL_PLACEHOLDER"])
            labelHint:SetTextColor(UI.Colors.textMuted:GetRGBA())
            SLV.editLabelHint = labelHint
        end
    end

    -- Detail pane editing context
    if ctx and ctx.source == "detail" then
        if SLV.ilRow then
            SLV.ilRow:Hide()
        end
        local childNode = SLV:_resolveDetailChild(ctx.childIndex, ctx.branchIndex)
        if not childNode then
            if SLV.editLabelBox then
                SLV.editLabelBox:Hide()
            end
            if SLV.editLabelHint then
                SLV.editLabelHint:Hide()
            end
            if SLV.editBox then
                SLV.editScrollFrame:SetPoint("TOPLEFT", SLV.editHeader, "BOTTOMLEFT", 0, -4)
            end
            SLV._editingContext = nil
            SLV.editArea:Show()
            if SLV.editBox then
                SLV.editScrollFrame:Hide()
                SLV.editScrollBar:Hide()
            end
            if SLV.selectLabel then
                SLV.selectLabel:Show()
            end
            return
        end

        SLV.editArea:Show()
        if SLV.selectLabel then
            SLV.selectLabel:Hide()
        end
        if SLV.editBox then
            SLV.editScrollFrame:Show()
            SLV.editScrollBar:Show()
        end

        -- Label editor (ACTION children only)
        if childNode.type == defaults.ACTION_TYPE_ACTION then
            _ensureLabelBox()
            SLV.editLabelBox:Show()
            local labelText = childNode.label or ""
            SLV.editLabelBox._shBusy = true
            SLV.editLabelBox:SetScript("OnTextChanged", nil)
            SLV.editLabelBox:SetText(labelText)
            if SLV.editLabelHint then
                if labelText == "" then
                    SLV.editLabelHint:Show()
                else
                    SLV.editLabelHint:Hide()
                end
            end
            SLV.editLabelBox:SetScript("OnTextChanged", function(self, userInput)
                if self._shBusy then
                    return
                end
                if not userInput then
                    return
                end
                local curCtx = SLV._editingContext
                if not curCtx or curCtx.source ~= "detail" then
                    return
                end
                local curChild = SLV:_resolveDetailChild(curCtx.childIndex, curCtx.branchIndex)
                if not curChild then
                    return
                end
                local newText = self:GetText() or ""
                if #newText > 40 then
                    newText = newText:sub(1, 40)
                    self:SetText(newText)
                end
                if newText == "" then
                    curChild.label = nil
                    if SLV.editLabelHint then
                        SLV.editLabelHint:Show()
                    end
                else
                    curChild.label = newText
                    if SLV.editLabelHint then
                        SLV.editLabelHint:Hide()
                    end
                end
                SLV:_markDirty()
                SLV:_renderDetailPane()
            end)
            SLV.editLabelBox._shBusy = false
            if SLV.editBox then
                SLV.editScrollFrame:SetPoint("TOPLEFT", SLV.editLabelBox, "BOTTOMLEFT", 0, -4)
            end
        else
            if SLV.editLabelBox then
                SLV.editLabelBox:Hide()
            end
            if SLV.editLabelHint then
                SLV.editLabelHint:Hide()
            end
            if SLV.editBox then
                SLV.editScrollFrame:SetPoint("TOPLEFT", SLV.editHeader, "BOTTOMLEFT", 0, -4)
            end
        end

        local text = childNode.macro or ""
        if SLV.editHeader then
            SLV.editHeader:SetText(ctx.label or "Action:")
        end
        SLV:UpdateEditCharCount(#text)

        if SLV.editBox then
            SLV.editBox._shBusy = true
            SLV.editBox:SetScript("OnTextChanged", nil)
            SLV.editBox:SetText(text)
            SLV._lastLineCount = select(2, text:gsub("\n", "")) + 1

            SLV.editBox:SetScript("OnTextChanged", function(self, userInput)
                if not userInput then
                    return
                end
                local curCtx = SLV._editingContext
                if not curCtx or curCtx.source ~= "detail" then
                    return
                end
                local curChild = SLV:_resolveDetailChild(curCtx.childIndex, curCtx.branchIndex)
                if not curChild then
                    return
                end
                local newText = self:GetText() or ""
                curChild.macro = newText
                SLV:UpdateEditCharCount(#newText)
                SLV:_markDirty()

                local numLines = select(2, newText:gsub("\n", "")) + 1
                if numLines ~= SLV._lastLineCount then
                    SLV._lastLineCount = numLines
                    local lineHeight = 14
                    local desiredH = math.max(
                        defaults.STEP_EDIT_HEIGHT_MIN,
                        math.min(defaults.STEP_EDIT_HEIGHT_MAX, numLines * lineHeight + 8)
                    )
                    self:SetHeight(desiredH)
                end
                SLV:RefreshAutocomplete(self)
            end)
            SLV.editBox._shBusy = false
        end
        return
    end

    -- Outline mode: step row clicked (hasActions = true)
    if ctx and ctx.source == "outline" and SLV.hasActions and SLV.workingActions then
        local nodeIdx = ctx.nodeIndex
        local actionNode = SLV.workingActions[nodeIdx]
        if not actionNode or actionNode.type ~= defaults.ACTION_TYPE_ACTION then
            if SLV.editLabelBox then
                SLV.editLabelBox:Hide()
            end
            if SLV.editLabelHint then
                SLV.editLabelHint:Hide()
            end
            if SLV.ilRow then
                SLV.ilRow:Hide()
            end
            if SLV.editBox then
                SLV.editScrollFrame:SetPoint("TOPLEFT", SLV.editHeader, "BOTTOMLEFT", 0, -4)
            end
            SLV._editingContext = nil
            SLV.editArea:Show()
            if SLV.editBox then
                SLV.editScrollFrame:Hide()
                SLV.editScrollBar:Hide()
            end
            if SLV.selectLabel then
                SLV.selectLabel:Show()
            end
            return
        end

        SLV.editArea:Show()
        if SLV.selectLabel then
            SLV.selectLabel:Hide()
        end
        if SLV.editBox then
            SLV.editScrollFrame:Show()
            SLV.editScrollBar:Show()
        end

        -- Label editor (ACTION nodes only)
        _ensureLabelBox()
        SLV.editLabelBox:Show()
        do
            local labelText = actionNode.label or ""
            SLV.editLabelBox._shBusy = true
            SLV.editLabelBox:SetScript("OnTextChanged", nil)
            SLV.editLabelBox:SetText(labelText)
            if SLV.editLabelHint then
                if labelText == "" then
                    SLV.editLabelHint:Show()
                else
                    SLV.editLabelHint:Hide()
                end
            end
            SLV.editLabelBox:SetScript("OnTextChanged", function(self, userInput)
                if self._shBusy then
                    return
                end
                if not userInput then
                    return
                end
                local curCtx = SLV._editingContext
                if not curCtx or curCtx.source ~= "outline" then
                    return
                end
                local curNode = SLV.workingActions[curCtx.nodeIndex]
                if not curNode then
                    return
                end
                local newText = self:GetText() or ""
                if #newText > 40 then
                    newText = newText:sub(1, 40)
                    self:SetText(newText)
                end
                if newText == "" then
                    curNode.label = nil
                    if SLV.editLabelHint then
                        SLV.editLabelHint:Show()
                    end
                else
                    curNode.label = newText
                    if SLV.editLabelHint then
                        SLV.editLabelHint:Hide()
                    end
                end
                SLV:_markDirty()
                SLV:DebouncedRefreshCurrentRow()
            end)
            SLV.editLabelBox._shBusy = false
        end

        local text = actionNode.macro or ""
        if SLV.editHeader then
            SLV.editHeader:SetText(ctx.label or "Step:")
        end
        SLV:UpdateEditCharCount(#text)

        -- Anchor editBox below labelBox by default; ilRow block overrides when shown.
        if SLV.editBox then
            SLV.editScrollFrame:SetPoint("TOPLEFT", SLV.editLabelBox, "BOTTOMLEFT", 0, -4)
        end

        -- Interleave controls
        if SLV.ilRow then
            -- Re-anchor ilRow below labelBox (labelBox occupies editHeader BOTTOMLEFT slot)
            SLV.ilRow:ClearAllPoints()
            SLV.ilRow:SetPoint("TOPLEFT", SLV.editLabelBox, "BOTTOMLEFT", 0, -2)
            SLV.ilRow:SetPoint("RIGHT", SLV.editArea, "RIGHT", -2, 0)
            local hasIL = actionNode.interval and actionNode.interval >= defaults.ACTION_INTERLEAVE_MIN
            SLV.ilRow:Show()
            SLV.ilCheck:SetChecked(hasIL)
            if hasIL then
                SLV.ilSpinner:SetText(tostring(actionNode.interval))
                SLV.ilSpinner:Show()
                SLV.ilStepsLabel:Show()
            else
                SLV.ilSpinner:Hide()
                SLV.ilStepsLabel:Hide()
            end
            SLV.ilCheck:SetScript("OnClick", function(self)
                if self:GetChecked() then
                    actionNode.interval = defaults.ACTION_INTERLEAVE_DEFAULT
                else
                    actionNode.interval = nil
                end
                SLV:_markDirty()
                SLV:UpdateEditArea()
                SLV:DebouncedRefreshCurrentRow()
            end)
            SLV.ilSpinner:SetScript("OnTextChanged", function(self, userInput)
                if not userInput then
                    return
                end
                local val = tonumber(self:GetText()) or defaults.ACTION_INTERLEAVE_DEFAULT
                if val < defaults.ACTION_INTERLEAVE_MIN then
                    val = defaults.ACTION_INTERLEAVE_MIN
                end
                if val > defaults.ACTION_INTERLEAVE_MAX then
                    val = defaults.ACTION_INTERLEAVE_MAX
                end
                actionNode.interval = val
                SLV:_markDirty()
                SLV:DebouncedRefreshCurrentRow()
            end)
            SLV.ilSpinner:SetScript("OnEscapePressed", function(self)
                self:ClearFocus()
            end)
            -- Re-anchor editBox below ilRow
            SLV.editScrollFrame:SetPoint("TOPLEFT", SLV.ilRow, "BOTTOMLEFT", 0, -4)
        end

        if SLV.editBox then
            SLV.editBox._shBusy = true
            SLV.editBox:SetScript("OnTextChanged", nil)
            SLV.editBox:SetText(text)
            SLV._lastLineCount = select(2, text:gsub("\n", "")) + 1

            SLV.editBox:SetScript("OnTextChanged", function(self, userInput)
                if not userInput then
                    return
                end
                local curCtx = SLV._editingContext
                if not curCtx or curCtx.source ~= "outline" then
                    return
                end
                local curNode = SLV.workingActions[curCtx.nodeIndex]
                if not curNode then
                    return
                end
                local newText = self:GetText() or ""
                curNode.macro = newText
                SLV:UpdateEditCharCount(#newText)
                SLV:_markDirty()

                local numLines = select(2, newText:gsub("\n", "")) + 1
                if numLines ~= SLV._lastLineCount then
                    SLV._lastLineCount = numLines
                    local lineHeight = 14
                    local desiredH = math.max(
                        defaults.STEP_EDIT_HEIGHT_MIN,
                        math.min(defaults.STEP_EDIT_HEIGHT_MAX, numLines * lineHeight + 8)
                    )
                    self:SetHeight(desiredH)
                end
                SLV:DebouncedRefreshCurrentRow()
                SLV:RefreshAutocomplete(self)
            end)
            SLV.editBox._shBusy = false
        end
        return
    end

    -- Flat mode (no actions): original behavior
    if #SLV.workingSteps == 0 and not (SLV.hasActions and SLV.workingActions) then
        if SLV.editLabelBox then
            SLV.editLabelBox:Hide()
        end
        if SLV.editLabelHint then
            SLV.editLabelHint:Hide()
        end
        if SLV.ilRow then
            SLV.ilRow:Hide()
        end
        if SLV.editBox then
            SLV.editScrollFrame:SetPoint("TOPLEFT", SLV.editHeader, "BOTTOMLEFT", 0, -4)
        end
        SLV.editArea:Hide()
        if SLV.selectLabel then
            SLV.selectLabel:Hide()
        end
        return
    end

    if not SLV.selectedIndex then
        if SLV.editLabelBox then
            SLV.editLabelBox:Hide()
        end
        if SLV.editLabelHint then
            SLV.editLabelHint:Hide()
        end
        if SLV.ilRow then
            SLV.ilRow:Hide()
        end
        if SLV.editBox then
            SLV.editScrollFrame:SetPoint("TOPLEFT", SLV.editHeader, "BOTTOMLEFT", 0, -4)
        end
        SLV.editArea:Show()
        if SLV.editBox then
            SLV.editScrollFrame:Hide()
            SLV.editScrollBar:Hide()
        end
        if SLV.editHeader then
            SLV.editHeader:SetText("")
        end
        if SLV.editCharCount then
            SLV.editCharCount:SetText("")
        end
        if SLV.selectLabel then
            SLV.selectLabel:Show()
        end
        return
    end

    -- Flat step is selected
    if SLV.ilRow then
        SLV.ilRow:Hide()
    end

    _ensureLabelBox()
    -- Flat mode: ensure labelBox anchor matches spec (outline mode may have re-anchored ilRow
    -- below the labelBox and does not touch the labelBox anchor, so this is usually redundant).
    SLV.editLabelBox:ClearAllPoints()
    SLV.editLabelBox:SetPoint("TOPLEFT", SLV.editHeader, "BOTTOMLEFT", 0, -4)
    SLV.editLabelBox:SetPoint("RIGHT", SLV.editArea, "RIGHT", -4, 0)

    if SLV.editBox then
        SLV.editScrollFrame:SetPoint("TOPLEFT", SLV.editLabelBox, "BOTTOMLEFT", 0, -4)
    end
    SLV.editArea:Show()
    if SLV.selectLabel then
        SLV.selectLabel:Hide()
    end
    if SLV.editBox then
        SLV.editScrollFrame:Show()
        SLV.editScrollBar:Show()
    end
    if SLV.editLabelBox then
        SLV.editLabelBox:Show()
    end

    local idx = SLV.selectedIndex
    local text = SLV.workingSteps[idx] or ""
    local labelText = SLV.workingStepLabels[idx] or ""

    if SLV.editHeader then
        SLV.editHeader:SetText(string.format(L["GEMS_UI_STEP_HEADER"], idx))
    end

    if SLV.editLabelBox then
        SLV.editLabelBox._shBusy = true
        SLV.editLabelBox:SetScript("OnTextChanged", nil)
        SLV.editLabelBox:SetText(labelText)
        if SLV.editLabelHint then
            if labelText == "" then
                SLV.editLabelHint:Show()
            else
                SLV.editLabelHint:Hide()
            end
        end
        SLV.editLabelBox:SetScript("OnTextChanged", function(self, userInput)
            if not userInput then
                return
            end
            if not SLV.selectedIndex then
                return
            end
            local newText = self:GetText() or ""
            if #newText > 40 then
                newText = newText:sub(1, 40)
                self:SetText(newText)
            end
            if newText == "" then
                SLV.workingStepLabels[SLV.selectedIndex] = nil
                if SLV.editLabelHint then
                    SLV.editLabelHint:Show()
                end
            else
                SLV.workingStepLabels[SLV.selectedIndex] = newText
                if SLV.editLabelHint then
                    SLV.editLabelHint:Hide()
                end
            end
            local SE = GRIPEMS.SequenceEditor
            if SE then
                SE.isDirty = true
                SE:UpdateSaveButtons()
            end
            SLV:DebouncedRefreshCurrentRow()
        end)
        SLV.editLabelBox._shBusy = false
    end

    SLV:UpdateEditCharCount(#text)

    if SLV.editBox then
        SLV.editBox._shBusy = true
        SLV.editBox:SetScript("OnTextChanged", nil)
        SLV.editBox:SetText(text)
        SLV._lastLineCount = select(2, text:gsub("\n", "")) + 1

        SLV.editBox:SetScript("OnTextChanged", function(self, userInput)
            if not userInput then
                return
            end
            if not SLV.selectedIndex then
                return
            end
            local newText = self:GetText() or ""
            SLV.workingSteps[SLV.selectedIndex] = newText
            SLV:UpdateEditCharCount(#newText)
            local SE = GRIPEMS.SequenceEditor
            if SE then
                SE.isDirty = true
                SE:UpdateSaveButtons()
            end

            local numLines = select(2, newText:gsub("\n", "")) + 1
            if numLines ~= SLV._lastLineCount then
                SLV._lastLineCount = numLines
                local lineHeight = 14
                local desiredH = math.max(
                    defaults.STEP_EDIT_HEIGHT_MIN,
                    math.min(defaults.STEP_EDIT_HEIGHT_MAX, numLines * lineHeight + 8)
                )
                self:SetHeight(desiredH)
            end

            SLV:DebouncedRefreshCurrentRow()
            SLV:RefreshAutocomplete(self)
        end)
        SLV.editBox._shBusy = false
    end
end

--- Resolve a child node from the detail pane context.
--- @param childIndex number Index in children array
--- @param branchIndex number|nil For If nodes: 1=true, 2=false
--- @return table|nil child The child node or nil
function SLV:_resolveDetailChild(childIndex, branchIndex)
    if not SLV._detailNode then
        return nil
    end
    local defaults = D()
    local node = SLV._detailNode
    local children
    if node.type == defaults.ACTION_TYPE_IF and branchIndex then
        children = node.children and node.children[branchIndex]
    else
        children = node.children
    end
    if not children then
        return nil
    end
    return children[childIndex]
end

--- Update the char count display in the edit area.
--- @param count number Character count
function SLV:UpdateEditCharCount(count)
    if not SLV.editCharCount then
        return
    end
    local C = UI.Colors
    local defaults = D()
    local kpCost = (SLV.keyPressLen or 0) > 0 and (SLV.keyPressLen + 1) or 0
    local krCost = (SLV.keyReleaseLen or 0) > 0 and (SLV.keyReleaseLen + 1) or 0
    local displayCount = count
    if kpCost > 0 or krCost > 0 then
        displayCount = count + kpCost + krCost
    end

    SLV.editCharCount:SetText(string.format("%d/%d", displayCount, defaults.CHAR_COUNT_DANGER))

    if displayCount >= defaults.CHAR_COUNT_DANGER then
        SLV.editCharCount:SetTextColor(C.textError:GetRGBA())
    elseif displayCount > defaults.CHAR_COUNT_WARNING then
        SLV.editCharCount:SetTextColor(C.textWarning:GetRGBA())
    else
        SLV.editCharCount:SetTextColor(C.textSuccess:GetRGBA())
    end
end

---------------------------------------------------------------------------
-- Debounced row refresh (coalesces rapid OnTextChanged calls)
---------------------------------------------------------------------------

---------------------------------------------------------------------------
-- nodeIndex-keyed row refresh (Finding H)
---------------------------------------------------------------------------

--- Repaint the scroll-box row whose _stepData.nodeIndex matches ni, using
--- the current SLV.workingActions[ni] node state. Unlike RefreshCurrentRow
--- this does NOT depend on SLV.selectedIndex, so it works while the detail
--- pane is open (OpenDetailPane clears selectedIndex). Handles both ACTION
--- rows (rowType == "step") and container rows (rowType == "node").
function SLV:RefreshRowByNodeIndex(ni)
    if not ni or not SLV.scrollBox or not SLV.workingActions then
        return
    end
    local node = SLV.workingActions[ni]
    if not node then
        return
    end
    local defaults = D()
    for _, frame in ipairs(SLV.scrollBox:GetFrames() or {}) do
        if frame._stepData and frame._stepData.nodeIndex == ni then
            if frame._stepData.rowType == "step" then
                frame._stepData.text = node.macro or ""
                frame._stepData.charCount = #(node.macro or "")
                frame._stepData.label = node.label
            else
                frame._stepData.nodeType = node.type
                frame._stepData.nodeName = node.name or ""
                frame._stepData.nodeSummary = defaults.NodeSummary(node)
                frame._stepData.label = node.label
                frame._stepData.node = node
            end
            SLV:InitRow(frame, frame._stepData)
            break
        end
    end
end

--- Debounce wrapper for RefreshRowByNodeIndex. Coalesces rapid keystroke
--- updates into a single refresh after 0.1s idle. Used by detail-pane
--- settings editors that write to node.X while the detail pane is open.
function SLV:DebouncedRefreshRowByNodeIndex(ni)
    if self._refreshRowNITimer then
        self._refreshRowNITimer:Cancel()
    end
    self._pendingRefreshNI = ni
    if C_Timer and C_Timer.NewTimer then
        self._refreshRowNITimer = C_Timer.NewTimer(0.1, function()
            local pending = self._pendingRefreshNI
            self._refreshRowNITimer = nil
            self._pendingRefreshNI = nil
            self:RefreshRowByNodeIndex(pending)
        end)
    end
end

-- Debounce wrapper that refreshes the Sequence Editor preview strip after
-- 0.15s idle. Called from _markDirty so every edit (step text, loop Repeat /
-- SF, pause, if, embed, add / delete / move child) keeps the strip live.
function SLV:DebouncedUpdatePreview()
    if self._previewTimer then
        self._previewTimer:Cancel()
    end
    if C_Timer and C_Timer.NewTimer then
        self._previewTimer = C_Timer.NewTimer(0.15, function()
            self._previewTimer = nil
            local SE = GRIPEMS.SequenceEditor
            if SE and SE.UpdatePreview then
                SE:UpdatePreview()
            end
        end)
    end
end

--- Debounce wrapper for RefreshCurrentRow. Coalesces rapid keystroke
--- updates into a single refresh after 0.1s idle. Used by OnTextChanged
--- handlers; autocomplete click handlers call RefreshCurrentRow directly.
function SLV:DebouncedRefreshCurrentRow()
    if self._refreshRowTimer then
        self._refreshRowTimer:Cancel()
    end
    if C_Timer and C_Timer.NewTimer then
        self._refreshRowTimer = C_Timer.NewTimer(0.1, function()
            self._refreshRowTimer = nil
            self:RefreshCurrentRow()
        end)
    end
end

---------------------------------------------------------------------------
-- Lightweight row refresh (flicker-free keystroke updates)
---------------------------------------------------------------------------

--- Lightweight refresh: update only the scroll row matching the
--- selected step. Does NOT rebuild the DataProvider or touch the
--- EditBox. Use this from OnTextChanged to avoid flicker.
function SLV:RefreshCurrentRow()
    if debugSkipRowRefresh then
        return
    end
    if not SLV.selectedIndex or not SLV.scrollBox then
        return
    end
    local idx = SLV.selectedIndex

    -- GetFrames returns the data-provider's pooled row frames (the ones
    -- that carry _stepData). GetChildren does NOT -- on a WowScrollBoxList
    -- it returns only the scroll box's structural children.
    for _, frame in ipairs(SLV.scrollBox:GetFrames() or {}) do
        if frame._stepData and frame._stepData.index == idx then
            -- Finding G: outline mode mutates workingActions live but
            -- workingSteps / workingStepLabels are only rebuilt at save
            -- time (CompileActions). Prefer the action-tree source when
            -- the row carries a nodeIndex. Label can always come from
            -- the node. Text only overrides for ACTION nodes (.macro
            -- exists); LOOP/IF containers keep their computed header
            -- string from the flat array.
            local text = SLV.workingSteps[idx] or ""
            local label = SLV.workingStepLabels[idx]
            if SLV.hasActions and SLV.workingActions and frame._stepData.nodeIndex then
                local node = SLV.workingActions[frame._stepData.nodeIndex]
                if node then
                    if type(node.macro) == "string" then
                        text = node.macro
                    end
                    label = node.label
                end
            end
            -- Update displayed text and char count
            if frame.stepText then
                frame.stepText:SetText(text)
            end
            local count = #text
            if frame.charCount then
                local C = UI.Colors
                local defaults = D()
                local kpCost = (SLV.keyPressLen or 0) > 0 and (SLV.keyPressLen + 1) or 0
                local krCost = (SLV.keyReleaseLen or 0) > 0 and (SLV.keyReleaseLen + 1) or 0
                local displayCount = count
                if kpCost > 0 or krCost > 0 then
                    displayCount = count + kpCost + krCost
                end
                frame.charCount:SetText(string.format("%d/%d", displayCount, defaults.CHAR_COUNT_DANGER))
                if displayCount >= defaults.CHAR_COUNT_DANGER then
                    frame.charCount:SetTextColor(C.textError:GetRGBA())
                elseif displayCount > defaults.CHAR_COUNT_WARNING then
                    frame.charCount:SetTextColor(C.textWarning:GetRGBA())
                else
                    frame.charCount:SetTextColor(C.textSuccess:GetRGBA())
                end
            end
            -- Phase 1C-bis: keep the [label] prefix in sync with the
            -- working store so live label edits repaint without RefreshAll.
            -- Mirrors the createStepRow paint path (build site).
            if frame.stepLabel and frame.stepNum and frame.stepText then
                if label and label ~= "" then
                    frame.stepLabel:ClearAllPoints()
                    frame.stepLabel:SetPoint("LEFT", frame.stepNum, "RIGHT", 4, 0)
                    frame.stepLabel:SetText("[" .. label .. "]")
                    frame.stepLabel:SetTextColor(UI.Colors.textMuted:GetRGBA())
                    frame.stepLabel:Show()
                    frame.stepText:ClearAllPoints()
                    frame.stepText:SetPoint("LEFT", frame.stepLabel, "RIGHT", 4, 0)
                    if frame.modBadge and frame.modBadge:IsShown() then
                        frame.stepText:SetPoint("RIGHT", frame.modBadge, "LEFT", -4, 0)
                    else
                        frame.stepText:SetPoint("RIGHT", frame, "RIGHT", -55, 0)
                    end
                else
                    frame.stepLabel:Hide()
                    frame.stepText:ClearAllPoints()
                    frame.stepText:SetPoint("LEFT", frame.stepNum, "RIGHT", 4, 0)
                    if frame.modBadge and frame.modBadge:IsShown() then
                        frame.stepText:SetPoint("RIGHT", frame.modBadge, "LEFT", -4, 0)
                    else
                        frame.stepText:SetPoint("RIGHT", frame, "RIGHT", -55, 0)
                    end
                end
            end
            -- Update stored data reference
            frame._stepData.text = text
            frame._stepData.charCount = count
            frame._stepData.label = label
            break -- found our frame, stop iterating
        end
    end
end

--- Toggle the debugSkipRowRefresh flag (flicker diagnostic).
--- @return boolean New state (true = RefreshCurrentRow is DISABLED)
function SLV:ToggleDebugRowRefresh()
    debugSkipRowRefresh = not debugSkipRowRefresh
    return debugSkipRowRefresh
end

---------------------------------------------------------------------------
-- Undo text snapshot flush
---------------------------------------------------------------------------

--- Flush a pending text-edit undo snapshot (called on focus lost or step change).
function SLV:FlushTextUndoSnapshot()
    if SLV._undoTextSnapshot ~= nil and not SLV._suppressUndo then
        local oldText = SLV._undoTextSnapshot
        local snapIdx = SLV._undoTextSnapshotIdx
        local newText = SLV.workingSteps and SLV.workingSteps[snapIdx]
        if newText and oldText ~= newText then
            local US = GRIPEMS.UndoStack
            if US then
                US:Push(function()
                    SLV.workingSteps[snapIdx] = oldText
                    SLV.selectedIndex = snapIdx
                    SLV:RefreshAll()
                    local SE = GRIPEMS.SequenceEditor
                    if SE then
                        SE.isDirty = true
                        SE:UpdateSaveButtons()
                    end
                end, function()
                    SLV.workingSteps[snapIdx] = newText
                    SLV.selectedIndex = snapIdx
                    SLV:RefreshAll()
                    local SE = GRIPEMS.SequenceEditor
                    if SE then
                        SE.isDirty = true
                        SE:UpdateSaveButtons()
                    end
                end, "Edit step text")
            end
        end
    end
    SLV._undoTextSnapshot = nil
    SLV._undoTextSnapshotIdx = nil
    SLV._preEditText = nil
end

---------------------------------------------------------------------------
-- Step operations
---------------------------------------------------------------------------

--- Add a new empty step after the selected step (or at end).
function SLV:AddStep()
    local pos = (SLV.selectedIndex or #SLV.workingSteps) + 1
    table.insert(SLV.workingSteps, pos, "")
    for i = #SLV.workingSteps, pos + 1, -1 do
        SLV.workingStepLabels[i] = SLV.workingStepLabels[i - 1]
    end
    SLV.workingStepLabels[pos] = nil
    SLV.selectedIndex = pos
    SLV.selectedSet = nil

    if not SLV._suppressUndo then
        local US = GRIPEMS.UndoStack
        if US then
            local addedIdx = pos
            US:Push(function()
                table.remove(SLV.workingSteps, addedIdx)
                table.remove(SLV.workingStepLabels, addedIdx)
                if SLV.selectedIndex and SLV.selectedIndex >= addedIdx then
                    SLV.selectedIndex = math.max(1, addedIdx - 1)
                end
                if #SLV.workingSteps == 0 then
                    SLV.selectedIndex = nil
                end
                local SE = GRIPEMS.SequenceEditor
                if SE then
                    SE.isDirty = true
                    SE:UpdateSaveButtons()
                end
                SLV:RefreshAll()
            end, function()
                table.insert(SLV.workingSteps, addedIdx, "")
                for i = #SLV.workingSteps, addedIdx + 1, -1 do
                    SLV.workingStepLabels[i] = SLV.workingStepLabels[i - 1]
                end
                SLV.workingStepLabels[addedIdx] = nil
                SLV.selectedIndex = addedIdx
                local SE = GRIPEMS.SequenceEditor
                if SE then
                    SE.isDirty = true
                    SE:UpdateSaveButtons()
                end
                SLV:RefreshAll()
            end, "Add step")
        end
    end

    local SE = GRIPEMS.SequenceEditor
    if SE then
        SE.isDirty = true
        SE:UpdateSaveButtons()
    end

    SLV:RefreshAll()

    -- Focus the EditBox after a frame delay
    if C_Timer and C_Timer.After then
        C_Timer.After(0, function()
            if SLV.editBox then
                SLV.editBox:SetFocus()
            end
        end)
    end
end

--- Duplicate the selected step.
function SLV:DuplicateStep()
    if SLV:IsMultiSelect() then
        return SLV:DuplicateSelectedSteps()
    end
    if not SLV.selectedIndex then
        return
    end
    local copy = SLV.workingSteps[SLV.selectedIndex]
    local dupIdx = SLV.selectedIndex + 1
    table.insert(SLV.workingSteps, dupIdx, copy)
    table.insert(SLV.workingStepLabels, dupIdx, SLV.workingStepLabels[SLV.selectedIndex])
    SLV.selectedIndex = dupIdx

    if not SLV._suppressUndo then
        local US = GRIPEMS.UndoStack
        if US then
            local di = dupIdx
            local dupText = copy
            local dupLabel = SLV.workingStepLabels[SLV.selectedIndex]
            US:Push(function()
                table.remove(SLV.workingSteps, di)
                table.remove(SLV.workingStepLabels, di)
                if SLV.selectedIndex and SLV.selectedIndex >= di then
                    SLV.selectedIndex = math.max(1, di - 1)
                end
                if #SLV.workingSteps == 0 then
                    SLV.selectedIndex = nil
                end
                local SE = GRIPEMS.SequenceEditor
                if SE then
                    SE.isDirty = true
                    SE:UpdateSaveButtons()
                end
                SLV:RefreshAll()
            end, function()
                table.insert(SLV.workingSteps, di, dupText)
                table.insert(SLV.workingStepLabels, di, dupLabel)
                SLV.selectedIndex = di
                local SE = GRIPEMS.SequenceEditor
                if SE then
                    SE.isDirty = true
                    SE:UpdateSaveButtons()
                end
                SLV:RefreshAll()
            end, "Duplicate step")
        end
    end

    local SE = GRIPEMS.SequenceEditor
    if SE then
        SE.isDirty = true
        SE:UpdateSaveButtons()
    end

    SLV:RefreshAll()
end

--- Move the selected step up.
function SLV:MoveStepUp()
    -- Single-step move: inert during a flat multi-select. Mirrors the greyed-out
    -- toolbar button and also blocks the Alt+Up keybind, which reaches here directly.
    if SLV:IsMultiSelect() then
        return
    end
    if not SLV.selectedIndex or SLV.selectedIndex <= 1 then
        return
    end
    if not SLV.workingSteps then
        return
    end
    local fromIdx = SLV.selectedIndex
    local i = SLV.selectedIndex
    SLV.workingSteps[i], SLV.workingSteps[i - 1] = SLV.workingSteps[i - 1], SLV.workingSteps[i]
    SLV.workingStepLabels[i], SLV.workingStepLabels[i - 1] = SLV.workingStepLabels[i - 1], SLV.workingStepLabels[i]
    SLV.selectedIndex = i - 1

    if not SLV._suppressUndo then
        local US = GRIPEMS.UndoStack
        if US then
            local fi = fromIdx
            US:Push(function()
                local a = fi - 1
                SLV.workingSteps[a], SLV.workingSteps[fi] = SLV.workingSteps[fi], SLV.workingSteps[a]
                SLV.workingStepLabels[a], SLV.workingStepLabels[fi] =
                    SLV.workingStepLabels[fi], SLV.workingStepLabels[a]
                SLV.selectedIndex = fi
                local SE = GRIPEMS.SequenceEditor
                if SE then
                    SE.isDirty = true
                    SE:UpdateSaveButtons()
                end
                SLV:RefreshAll()
            end, function()
                SLV.workingSteps[fi], SLV.workingSteps[fi - 1] = SLV.workingSteps[fi - 1], SLV.workingSteps[fi]
                SLV.workingStepLabels[fi], SLV.workingStepLabels[fi - 1] =
                    SLV.workingStepLabels[fi - 1], SLV.workingStepLabels[fi]
                SLV.selectedIndex = fi - 1
                local SE = GRIPEMS.SequenceEditor
                if SE then
                    SE.isDirty = true
                    SE:UpdateSaveButtons()
                end
                SLV:RefreshAll()
            end, "Move step up")
        end
    end

    local SE = GRIPEMS.SequenceEditor
    if SE then
        SE.isDirty = true
        SE:UpdateSaveButtons()
    end

    SLV:RefreshAll()
end

--- Move the selected step down.
function SLV:MoveStepDown()
    -- Single-step move: inert during a flat multi-select. Mirrors the greyed-out
    -- toolbar button and also blocks the Alt+Down keybind, which reaches here directly.
    if SLV:IsMultiSelect() then
        return
    end
    if not SLV.workingSteps then
        return
    end
    if not SLV.selectedIndex or SLV.selectedIndex >= #SLV.workingSteps then
        return
    end
    local fromIdx = SLV.selectedIndex
    local i = SLV.selectedIndex
    SLV.workingSteps[i], SLV.workingSteps[i + 1] = SLV.workingSteps[i + 1], SLV.workingSteps[i]
    SLV.workingStepLabels[i], SLV.workingStepLabels[i + 1] = SLV.workingStepLabels[i + 1], SLV.workingStepLabels[i]
    SLV.selectedIndex = i + 1

    if not SLV._suppressUndo then
        local US = GRIPEMS.UndoStack
        if US then
            local fi = fromIdx
            US:Push(function()
                local a = fi + 1
                SLV.workingSteps[fi], SLV.workingSteps[a] = SLV.workingSteps[a], SLV.workingSteps[fi]
                SLV.workingStepLabels[fi], SLV.workingStepLabels[a] =
                    SLV.workingStepLabels[a], SLV.workingStepLabels[fi]
                SLV.selectedIndex = fi
                local SE = GRIPEMS.SequenceEditor
                if SE then
                    SE.isDirty = true
                    SE:UpdateSaveButtons()
                end
                SLV:RefreshAll()
            end, function()
                SLV.workingSteps[fi], SLV.workingSteps[fi + 1] = SLV.workingSteps[fi + 1], SLV.workingSteps[fi]
                SLV.workingStepLabels[fi], SLV.workingStepLabels[fi + 1] =
                    SLV.workingStepLabels[fi + 1], SLV.workingStepLabels[fi]
                SLV.selectedIndex = fi + 1
                local SE = GRIPEMS.SequenceEditor
                if SE then
                    SE.isDirty = true
                    SE:UpdateSaveButtons()
                end
                SLV:RefreshAll()
            end, "Move step down")
        end
    end

    local SE = GRIPEMS.SequenceEditor
    if SE then
        SE.isDirty = true
        SE:UpdateSaveButtons()
    end

    SLV:RefreshAll()
end

--- Delete the selected step (with confirmation).
function SLV:DeleteStep()
    if SLV:IsMultiSelect() then
        return SLV:DeleteSelectedSteps()
    end
    if not SLV.selectedIndex then
        return
    end
    local idx = SLV.selectedIndex
    local removedText = SLV.workingSteps[idx]
    local removedLabel = SLV.workingStepLabels[idx]

    GRIPEMS.Popup:Define("GRIPEMS_DELETE_STEP", {
        text = string.format(L["GEMS_UI_DELETE_STEP_CONFIRM"], idx),
        button1 = ACCEPT,
        button2 = CANCEL,
        OnAccept = function()
            table.remove(SLV.workingSteps, idx)
            table.remove(SLV.workingStepLabels, idx)
            if idx > #SLV.workingSteps then
                SLV.selectedIndex = #SLV.workingSteps > 0 and #SLV.workingSteps or nil
            end

            if not SLV._suppressUndo then
                local US = GRIPEMS.UndoStack
                if US then
                    local di = idx
                    local dt = removedText
                    local dl = removedLabel
                    US:Push(function()
                        table.insert(SLV.workingSteps, di, dt)
                        table.insert(SLV.workingStepLabels, di, dl)
                        SLV.selectedIndex = di
                        local SE = GRIPEMS.SequenceEditor
                        if SE then
                            SE.isDirty = true
                            SE:UpdateSaveButtons()
                        end
                        SLV:RefreshAll()
                    end, function()
                        table.remove(SLV.workingSteps, di)
                        table.remove(SLV.workingStepLabels, di)
                        if di > #SLV.workingSteps then
                            SLV.selectedIndex = #SLV.workingSteps > 0 and #SLV.workingSteps or nil
                        else
                            SLV.selectedIndex = di
                        end
                        local SE = GRIPEMS.SequenceEditor
                        if SE then
                            SE.isDirty = true
                            SE:UpdateSaveButtons()
                        end
                        SLV:RefreshAll()
                    end, "Delete step")
                end
            end

            local SE = GRIPEMS.SequenceEditor
            if SE then
                SE.isDirty = true
                SE:UpdateSaveButtons()
            end

            SLV:RefreshAll()
        end,
        timeout = 0,
        hideOnEscape = true,
    })
    GRIPEMS.Popup:Show("GRIPEMS_DELETE_STEP")
end

--- Duplicate every selected flat step as one contiguous block inserted after
--- the last selected row. One undo snapshot. Flat multi-select only.
function SLV:DuplicateSelectedSteps()
    local list = SLV:GetSelectionList()
    local n = #list
    if n == 0 then
        return
    end
    if n == 1 then
        SLV.selectedSet = nil
        SLV.selectedIndex = list[1]
        return SLV:DuplicateStep()
    end
    local base = list[n]
    local copies = {}
    for i = 1, n do
        copies[i] = { text = SLV.workingSteps[list[i]], label = SLV.workingStepLabels[list[i]] }
    end
    for i = 1, n do
        table.insert(SLV.workingSteps, base + i, copies[i].text)
        table.insert(SLV.workingStepLabels, base + i, copies[i].label)
    end
    local newSet = {}
    for i = 1, n do
        newSet[base + i] = true
    end
    SLV.selectedSet = newSet
    SLV.selectedIndex = base + 1
    SLV.selectionAnchor = base + 1

    if not SLV._suppressUndo then
        local US = GRIPEMS.UndoStack
        if US then
            local cnt = n
            US:Push(function()
                for i = cnt, 1, -1 do
                    table.remove(SLV.workingSteps, base + i)
                    table.remove(SLV.workingStepLabels, base + i)
                end
                SLV.selectedSet = nil
                SLV.selectedIndex = base > 0 and math.min(base, #SLV.workingSteps) or nil
                if #SLV.workingSteps == 0 then
                    SLV.selectedIndex = nil
                end
                SLV.selectionAnchor = SLV.selectedIndex
                local SE = GRIPEMS.SequenceEditor
                if SE then
                    SE.isDirty = true
                    SE:UpdateSaveButtons()
                end
                SLV:RefreshAll()
            end, function()
                for i = 1, cnt do
                    table.insert(SLV.workingSteps, base + i, copies[i].text)
                    table.insert(SLV.workingStepLabels, base + i, copies[i].label)
                end
                local rset = {}
                for i = 1, cnt do
                    rset[base + i] = true
                end
                SLV.selectedSet = rset
                SLV.selectedIndex = base + 1
                SLV.selectionAnchor = base + 1
                local SE = GRIPEMS.SequenceEditor
                if SE then
                    SE.isDirty = true
                    SE:UpdateSaveButtons()
                end
                SLV:RefreshAll()
            end, "Duplicate steps")
        end
    end

    local SE = GRIPEMS.SequenceEditor
    if SE then
        SE.isDirty = true
        SE:UpdateSaveButtons()
    end
    SLV:RefreshAll()
end

--- Delete every selected flat step (confirm shows the count). Removes in
--- descending order so indices stay valid; one undo snapshot restores them.
function SLV:DeleteSelectedSteps()
    local list = SLV:GetSelectionList()
    local n = #list
    if n == 0 then
        return
    end
    if n == 1 then
        SLV.selectedSet = nil
        SLV.selectedIndex = list[1]
        return SLV:DeleteStep()
    end
    GRIPEMS.Popup:Define("GRIPEMS_DELETE_STEPS", {
        text = string.format(L["GEMS_UI_DELETE_STEPS_CONFIRM"], n),
        button1 = ACCEPT,
        button2 = CANCEL,
        OnAccept = function()
            local removed = {}
            for i = 1, n do
                local idx = list[i]
                removed[i] = { idx = idx, text = SLV.workingSteps[idx], label = SLV.workingStepLabels[idx] }
            end
            for i = n, 1, -1 do
                table.remove(SLV.workingSteps, list[i])
                table.remove(SLV.workingStepLabels, list[i])
            end
            SLV.selectedSet = nil
            SLV.selectedIndex = #SLV.workingSteps > 0 and math.min(list[1], #SLV.workingSteps) or nil
            SLV.selectionAnchor = SLV.selectedIndex

            if not SLV._suppressUndo then
                local US = GRIPEMS.UndoStack
                if US then
                    US:Push(function()
                        for i = 1, n do
                            table.insert(SLV.workingSteps, removed[i].idx, removed[i].text)
                            table.insert(SLV.workingStepLabels, removed[i].idx, removed[i].label)
                        end
                        SLV.selectedSet = nil
                        SLV.selectedIndex = removed[1].idx
                        SLV.selectionAnchor = SLV.selectedIndex
                        local SE = GRIPEMS.SequenceEditor
                        if SE then
                            SE.isDirty = true
                            SE:UpdateSaveButtons()
                        end
                        SLV:RefreshAll()
                    end, function()
                        for i = n, 1, -1 do
                            table.remove(SLV.workingSteps, removed[i].idx)
                            table.remove(SLV.workingStepLabels, removed[i].idx)
                        end
                        SLV.selectedSet = nil
                        SLV.selectedIndex = #SLV.workingSteps > 0 and math.min(removed[1].idx, #SLV.workingSteps) or nil
                        SLV.selectionAnchor = SLV.selectedIndex
                        local SE = GRIPEMS.SequenceEditor
                        if SE then
                            SE.isDirty = true
                            SE:UpdateSaveButtons()
                        end
                        SLV:RefreshAll()
                    end, "Delete steps")
                end
            end

            local SE = GRIPEMS.SequenceEditor
            if SE then
                SE.isDirty = true
                SE:UpdateSaveButtons()
            end
            SLV:RefreshAll()
        end,
        timeout = 0,
        hideOnEscape = true,
    })
    GRIPEMS.Popup:Show("GRIPEMS_DELETE_STEPS")
end

---------------------------------------------------------------------------
-- Tree mode operations (v1.2.0 S14-B)
---------------------------------------------------------------------------

--- Resolve a tree path (array of indices) to the parent array and target index.
--- Path examples: {2} = actions[2], {2,1} = actions[2].children[1]
--- @param path table Array of 1-based indices into the tree
--- @return table|nil parentArray The array containing the target node
--- @return number|nil targetIndex Index within parentArray
function SLV:_resolveTreePath(path)
    if not path or #path == 0 or not SLV.workingActions then
        return nil, nil
    end
    local current = SLV.workingActions
    for i = 1, #path - 1 do
        local idx = path[i]
        local node = current[idx]
        if not node then
            return nil, nil
        end
        if node.type == D().ACTION_TYPE_IF then
            -- Next index selects branch (1 = true, 2 = false)
            i = i + 1
            if i > #path - 1 then
                -- The branch itself is the parent
                local branchIdx = path[i] or 1
                current = node.children and node.children[branchIdx] or {}
                return current, path[#path]
            end
            local branchIdx = path[i]
            current = node.children and node.children[branchIdx] or {}
        else
            current = node.children or {}
        end
    end
    return current, path[#path]
end

--- Add an action node of the given type at the specified tree path.
--- If parentPath is nil, appends to the root actions array.
--- @param nodeType string One of D().ACTION_TYPE_* constants
--- @param parentPath table|nil Array of indices into the tree
function SLV:AddAction(nodeType, parentPath)
    if not SLV.workingActions then
        return
    end
    local newNode = D().NewActionNode(nodeType)
    if not parentPath or #parentPath == 0 then
        SLV.workingActions[#SLV.workingActions + 1] = newNode
    else
        local parentArray = SLV:_resolveTreePath(parentPath)
        if parentArray then
            parentArray[#parentArray + 1] = newNode
        end
    end

    local SE = GRIPEMS.SequenceEditor
    if SE then
        SE.isDirty = true
        SE:UpdateSaveButtons()
    end
    SLV:RefreshAll()
end

--- Delete the action node at the given tree path.
--- @param path table Array of indices into the tree
function SLV:DeleteAction(path)
    if not path or #path == 0 or not SLV.workingActions then
        return
    end
    local parentArray, targetIndex = SLV:_resolveTreePath(path)
    if parentArray and targetIndex and parentArray[targetIndex] then
        table.remove(parentArray, targetIndex)
        local SE = GRIPEMS.SequenceEditor
        if SE then
            SE.isDirty = true
            SE:UpdateSaveButtons()
        end
        SLV:RefreshAll()
    end
end

--- Move the action node at the given path up or down within its parent.
--- @param path table Array of indices into the tree
--- @param direction number -1 for up, 1 for down
function SLV:MoveAction(path, direction)
    if not path or #path == 0 or not SLV.workingActions then
        return
    end
    local parentArray, targetIndex = SLV:_resolveTreePath(path)
    if not parentArray or not targetIndex then
        return
    end
    local newIndex = targetIndex + direction
    if newIndex < 1 or newIndex > #parentArray then
        return
    end
    parentArray[targetIndex], parentArray[newIndex] = parentArray[newIndex], parentArray[targetIndex]
    local SE = GRIPEMS.SequenceEditor
    if SE then
        SE.isDirty = true
        SE:UpdateSaveButtons()
    end
    SLV:RefreshAll()
end

---------------------------------------------------------------------------
-- Simplified Mode: per-row read-only toggle (Phase S2)
---------------------------------------------------------------------------

--- Toggle read-only on a single pooled row. Hides the drag handle and
--- stores a flag consulted by the OnClick handler to suppress right-click
--- context menus. Safe to call on rows whose lazy widgets haven't been
--- created yet.
--- @param row Button A pooled step or node row frame.
--- @param flag boolean True = read-only, false = interactive.
function SLV:SetRowReadOnly(row, flag)
    if not row then
        return
    end
    row._readOnly = flag and true or false
    if row.dragHandle and row.dragHandle.SetShown then
        row.dragHandle:SetShown(not row._readOnly)
    end
end

--- Global read-only toggle for every currently rendered row. InitRow
--- consults SLV._allRowsReadOnly so recycled frames keep the flag after
--- a data-provider rebuild.
--- @param flag boolean True = read-only, false = interactive.
function SLV:SetAllRowsReadOnly(flag)
    SLV._allRowsReadOnly = flag and true or false
    if SLV.scrollBox and SLV.scrollBox.ForEachFrame then
        SLV.scrollBox:ForEachFrame(function(row)
            SLV:SetRowReadOnly(row, SLV._allRowsReadOnly)
        end)
    end
end
