-- GRIP-EMS: MacroManager
-- Created: 2026-03-18
-- Updated: 2026-08-17
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)

-- GRIP-EMS: Macro Manager
-- CRUD operations for WoW macro stubs that /click the sequencer buttons

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)
local D = GRIPEMS.Defaults

-- MacroManager module: creates, updates, and deletes the WoW macros that act
-- as stubs for GRIP-EMS sequences. Each active sequence gets one per-character
-- macro whose body is:
--   #showtooltip
--   /click [button:1] GRIPEMS_SeqName LeftButton t; GRIPEMS_SeqName
-- The [button:1] conditional targets left-click events; the trailing bare name
-- is a fallback for virtual button and keyboard-only usage. The macro stub
-- is what the player drags to their action bar; clicking it triggers the
-- SecureActionButton which executes the current step's attributes.
-- All write operations go through OOCQueue to handle combat lockdown.
GRIPEMS.MacroManager = {
    stubs = {}, -- seqName -> macroId mapping
}
local MM = GRIPEMS.MacroManager

--- Truncate a sequence name to fit within the macro name limit.
--- Format: "GEMS:<name>" must fit in MAX_MACRO_NAME (16) chars.
--- If a collision exists in the stubs table, appends a numeric suffix.
--- @param seqName string The sequence name to truncate
--- @return string The truncated macro name
function MM:TruncateName(seqName)
    if not seqName then
        return D.MACRO_PREFIX
    end
    local prefixLen = #D.MACRO_PREFIX
    local maxNameLen = D.MAX_MACRO_NAME - prefixLen
    local truncated = D.MACRO_PREFIX .. seqName:sub(1, maxNameLen)

    -- Check for collisions with existing stubs
    local suffix = 1
    local maxSuffix = 99
    while suffix <= maxSuffix do
        local collision = false
        for existingSeq, _ in pairs(self.stubs) do
            if existingSeq ~= seqName then
                local existingMacroName = self:GetMacroName(existingSeq)
                if existingMacroName == truncated then
                    collision = true
                    break
                end
            end
        end
        if not collision then
            break
        end
        -- Append numeric suffix, shrinking the name portion to fit
        local suffixStr = tostring(suffix)
        local shrunkLen = D.MAX_MACRO_NAME - prefixLen - #suffixStr
        if shrunkLen < 1 then
            shrunkLen = 1
        end
        truncated = D.MACRO_PREFIX .. seqName:sub(1, shrunkLen) .. suffixStr
        suffix = suffix + 1
    end
    return truncated
end

--- Get the macro display name for a sequence (without collision resolution).
--- Used internally for collision detection.
--- @param seqName string The sequence name
--- @return string The basic macro name (may collide)
function MM:GetMacroName(seqName)
    if not seqName then
        return D.MACRO_PREFIX
    end
    local prefixLen = #D.MACRO_PREFIX
    local maxNameLen = D.MAX_MACRO_NAME - prefixLen
    return D.MACRO_PREFIX .. seqName:sub(1, maxNameLen)
end

--- Build the macro stub body, fitting keyPress/keyRelease lines greedily
--- within the 255-char macro body limit. Lines are added top-down; once a
--- line does not fit, all remaining lines for that block are skipped.
--- Always includes #showtooltip and the /click line.
--- @param buttonName string The SecureActionButton global name
--- @param keyPress string|nil KeyPress block (multi-line)
--- @param keyRelease string|nil KeyRelease block (multi-line)
--- @param steps table|nil Active step array; when every step already bakes
---        keyPress/keyRelease the stub omits them (see Engine:AllStepsBakeKpKr)
--- @return string The macro body text
function MM:BuildStubBody(buttonName, keyPress, keyRelease, steps)
    local kp = (type(keyPress) == "string") and keyPress or ""
    local kr = (type(keyRelease) == "string") and keyRelease or ""
    -- Option 1: when every step already bakes keyPress/keyRelease into its
    -- per-step button macrotext, the stub does not need to embed them. The
    -- button (triggered by both keybind and the stub's /click) already
    -- carries them, so omit the redundant copy that would overflow the stub.
    if (kp ~= "" or kr ~= "") and steps and GRIPEMS.Engine and GRIPEMS.Engine.AllStepsBakeKpKr then
        if GRIPEMS.Engine:AllStepsBakeKpKr(steps, kp, kr) then
            kp = ""
            kr = ""
        end
    end
    -- No keyPress/keyRelease: use default template
    if kp == "" and kr == "" then
        return string.format(D.MACRO_BODY_TEMPLATE, buttonName, buttonName)
    end
    local showtooltip = "#showtooltip"
    local clickLine = string.format("/click [button:1] %s LeftButton t; %s", buttonName, buttonName)
    -- Fixed cost: #showtooltip\n.../click line
    local fixedLen = #showtooltip + 1 + #clickLine
    if fixedLen > D.MAX_MACRO_BODY then
        -- Safety: use short /click form
        clickLine = "/click " .. buttonName
        fixedLen = #showtooltip + 1 + #clickLine
    end
    local remaining = D.MAX_MACRO_BODY - fixedLen
    -- Split keyPress into individual lines
    local kpLines = {}
    if kp ~= "" then
        for line in kp:gmatch("[^\n]+") do
            kpLines[#kpLines + 1] = line
        end
    end
    -- Fit keyPress lines top-down (inserted between #showtooltip and /click)
    local fittedKP = {}
    for _, line in ipairs(kpLines) do
        local cost = 1 + #line -- \n separator + line content
        if cost <= remaining then
            fittedKP[#fittedKP + 1] = line
            remaining = remaining - cost
        else
            break -- top-down order matters, stop on first miss
        end
    end
    -- Split keyRelease into individual lines
    local krLines = {}
    if kr ~= "" then
        for line in kr:gmatch("[^\n]+") do
            krLines[#krLines + 1] = line
        end
    end
    -- Fit keyRelease lines top-down (appended after /click)
    local fittedKR = {}
    for _, line in ipairs(krLines) do
        local cost = 1 + #line -- \n separator + line content
        if cost <= remaining then
            fittedKR[#fittedKR + 1] = line
            remaining = remaining - cost
        else
            break
        end
    end
    -- Assemble: #showtooltip, [kp lines...], /click, [kr lines...]
    local parts = { showtooltip }
    for _, line in ipairs(fittedKP) do
        parts[#parts + 1] = line
    end
    parts[#parts + 1] = clickLine
    for _, line in ipairs(fittedKR) do
        parts[#parts + 1] = line
    end
    return table.concat(parts, "\n")
end

--- Update an existing macro stub body (e.g., after keyPress changes).
--- @param seqName string The sequence name
--- @param keyPress string|nil KeyPress block
--- @param keyRelease string|nil KeyRelease block
--- @param steps table|nil Active step array (forwarded to BuildStubBody)
function MM:UpdateStubBody(seqName, keyPress, keyRelease, steps)
    if not seqName or not self.stubs[seqName] then
        return
    end
    local macroId = self.stubs[seqName]
    local buttonName = D.BUTTON_PREFIX .. GRIPEMS.Engine:SanitizeName(seqName)
    local body = self:BuildStubBody(buttonName, keyPress, keyRelease, steps)
    local function doUpdate()
        EditMacro(macroId, nil, nil, body)
    end
    GRIPEMS.OOCQueue:Add(doUpdate, D.OOC_OP_GENERIC, seqName)
end

--- Create a macro stub for a sequence. Queues via OOCQueue if in combat.
--- @param seqName string The sequence name
--- @param keyPress string|nil KeyPress block for macro stub body
--- @param keyRelease string|nil KeyRelease block for macro stub body
--- @param steps table|nil Active step array (forwarded to BuildStubBody)
--- @return number|nil The macro ID if created immediately, nil if queued or failed
--- @return string|nil Error message if creation failed
function MM:CreateStub(seqName, keyPress, keyRelease, steps)
    if not seqName or seqName == "" then
        return nil, L["GEMS_ERR_NO_NAME"]
    end

    -- Check if stub already exists
    if self.stubs[seqName] then
        -- Refresh body with current keyPress/keyRelease (stub may have been
        -- reclaimed by ScanExisting with stale body from a previous session)
        if keyPress or keyRelease then
            self:UpdateStubBody(seqName, keyPress, keyRelease, steps)
        end
        return self.stubs[seqName], nil
    end

    local function doCreate()
        -- Check available slots
        local available = self:GetAvailableSlots()
        if available <= 0 then
            local _, perChar = GetNumMacros()
            GRIPEMS:Print(string.format(L["GEMS_ERR_NO_MACRO_SLOTS"], perChar, D.MAX_PER_CHAR_MACROS))
            return
        end

        local macroName = self:TruncateName(seqName)
        local buttonName = D.BUTTON_PREFIX .. GRIPEMS.Engine:SanitizeName(seqName)
        local body = self:BuildStubBody(buttonName, keyPress, keyRelease, steps)

        local ok, result = pcall(CreateMacro, macroName, D.QUESTION_MARK_ICON, body, true)
        if ok and result then
            self.stubs[seqName] = result
            -- Auto-convert stub icon from question mark to the sequence's resolved icon.
            -- Fixes imported / migrated stubs showing the red ? until first user click.
            local engine = GRIPEMS.Engine
            local entry = engine and engine.sequences and engine.sequences[seqName]
            local seqData = entry and entry.data
            if seqData and type(seqData.icon) == "number" and seqData.icon ~= D.QUESTION_MARK_ICON then
                EditMacro(result, nil, seqData.icon, nil)
            end
            -- Refresh keybind to route through macro stub (enables keyPress via keybind)
            if GRIPEMS.KeybindManager and not GRIPEMS.OOCQueue.IsRestricted() then
                GRIPEMS.KeybindManager:BindIfConfigured(seqName)
            end
            GRIPEMS:Debug(string.format(L["GEMS_MACRO_CREATED"], macroName, result))
        else
            local errMsg = not ok and tostring(result) or "unknown error"
            GRIPEMS:Print(string.format(L["GEMS_ERR_MACRO_CREATE_FAILED"], seqName) .. " (" .. errMsg .. ")")
        end
    end

    GRIPEMS.OOCQueue:Add(doCreate, D.OOC_OP_GENERIC, seqName)
    return nil, nil
end

--- Delete the macro stub for a sequence. Queues via OOCQueue if in combat.
--- @param seqName string The sequence name
function MM:DeleteStub(seqName)
    if not seqName or not self.stubs[seqName] then
        return
    end

    local function doDelete()
        -- Scan for our macro by body content (immune to index shifts)
        local _, perChar = GetNumMacros()
        local accountSlots = D.MAX_ACCOUNT_MACROS
        local targetBtn = D.BUTTON_PREFIX .. GRIPEMS.Engine:SanitizeName(seqName)
        for i = accountSlots + 1, accountSlots + perChar do
            local _, _, body = GetMacroInfo(i)
            local pos = body and body:find(targetBtn, 1, true)
            if pos then
                local afterChar = body:sub(pos + #targetBtn, pos + #targetBtn)
                if afterChar == "" or not afterChar:match("[%w_]") then
                    DeleteMacro(i)
                    break
                end
            end
        end
        self.stubs[seqName] = nil
    end

    GRIPEMS.OOCQueue:Add(doDelete, D.OOC_OP_GENERIC, seqName)
end

--- Update the icon of a macro stub. Queues via OOCQueue if in combat.
--- @param seqName string The sequence name
--- @param iconFileID number The icon texture fileID
function MM:UpdateIcon(seqName, iconFileID)
    if not seqName or not self.stubs[seqName] then
        return
    end
    if not iconFileID then
        return
    end
    local macroId = self.stubs[seqName]

    local function doUpdate()
        EditMacro(macroId, nil, iconFileID, nil)
    end

    GRIPEMS.OOCQueue:Add(doUpdate, D.OOC_OP_ICON, seqName)
end

--- Scan all per-character macros on login and reclaim any GRIP-EMS stubs.
--- Rebuilds the stubs table from found macros whose body starts with
--- "/click GRIPEMS_". Called on PLAYER_ENTERING_WORLD.
function MM:ScanExisting()
    -- Clear stale entries before rescanning
    wipe(self.stubs)

    -- Build reverse lookup: sanitized -> original sequence name
    local sanitizedToOriginal = {}
    if _G.GRIP_EMS_CHAR and _G.GRIP_EMS_CHAR.sequences then
        for origName, _ in pairs(_G.GRIP_EMS_CHAR.sequences) do
            local sanitized = GRIPEMS.Engine:SanitizeName(origName)
            sanitizedToOriginal[sanitized] = origName
        end
    end

    local _, perChar = GetNumMacros()
    local accountSlots = D.MAX_ACCOUNT_MACROS
    local found = 0

    for i = accountSlots + 1, accountSlots + perChar do
        local name, _, body = GetMacroInfo(i)
        if name and body then
            local buttonMatch = body:match("; " .. D.BUTTON_PREFIX .. "(%S+)")
            if not buttonMatch then
                buttonMatch = body:match("/click " .. D.BUTTON_PREFIX .. "(%S+)")
            end
            if buttonMatch then
                local sanitizedName = buttonMatch:gsub("%s+LeftButton.*$", "")
                -- Map back to original sequence name (spaces, not underscores)
                local seqName = sanitizedToOriginal[sanitizedName] or sanitizedName
                self.stubs[seqName] = i
                found = found + 1
            end
        end
    end

    if found > 0 then
        GRIPEMS:Debug(string.format(L["GEMS_MACROS_SCANNED"], found))
    end
end

--- Return the number of available per-character macro slots.
--- @return number Available slots
function MM:GetAvailableSlots()
    local _, perChar = GetNumMacros()
    return D.MAX_PER_CHAR_MACROS - perChar
end

---------------------------------------------------------------------------
-- Imported-macro CRUD (auxiliary macros referenced by imported sequences)
--
-- These functions cover the second class of macros EMS manages: ordinary
-- WoW macros (the ones that show up in /macro) referenced by name from
-- inside a sequence step. When an imported sequence has a step like
-- `{Type="Action", type="macro", macro="MOONSPAM"}` and the export bundle
-- carries the macro body, EMS recreates that macro slot so the bare-name
-- reference resolves at fire time instead of typing into chat.
--
-- Storage:
--   GRIP_EMS_DB.macros[name]   -- account scope
--   GRIP_EMS_CHAR.macros[name] -- per-character scope
--
-- Each stored node mirrors the imported wire format:
--   { name, icon, text, value (slot), manageMacro, [Managed] }
--
-- The category field on the import node ("a" or "p") drives scope routing
-- and is stripped before storage.
---------------------------------------------------------------------------

-- UPDATE_MACROS guard counter: incremented while we are about to write a
-- macro and decremented after, so an external listener that filters on this
-- counter can suppress its own re-scan during our own writes. Keeping the
-- counter at the module level means nested writes still increment cleanly.
MM._suppressUpdateMacros = 0

--- Wrap a function so UPDATE_MACROS does not re-fire our own listeners.
--- The CreateMacro / EditMacro / DeleteMacro APIs trigger UPDATE_MACROS;
--- bumping the suppression counter lets MM:ScanExisting (and any future
--- UPDATE_MACROS hook) skip the re-entrant scan.
--- @param fn function The function to call under suppression
--- @return any... The return values of fn
local function withMacroWriteGuard(fn)
    MM._suppressUpdateMacros = MM._suppressUpdateMacros + 1
    local ok, err = pcall(fn)
    MM._suppressUpdateMacros = MM._suppressUpdateMacros - 1
    if MM._suppressUpdateMacros < 0 then
        MM._suppressUpdateMacros = 0
    end
    if not ok then
        return nil, err
    end
    return true
end

--- Choose the SavedVariables bucket for an imported macro node.
--- @param isCharacterScope boolean True for per-character, false for account
--- @return table The macros table (lazily initialized) or nil if the SavedVariable global is not yet set up
local function getStorageBucket(isCharacterScope)
    if isCharacterScope then
        if not _G.GRIP_EMS_CHAR then
            return nil
        end
        GRIP_EMS_CHAR.macros = GRIP_EMS_CHAR.macros or {}
        return GRIP_EMS_CHAR.macros
    end
    if not _G.GRIP_EMS_DB then
        return nil
    end
    GRIP_EMS_DB.macros = GRIP_EMS_DB.macros or {}
    return GRIP_EMS_DB.macros
end

--- Does EMS own the macro currently occupying this name and slot?
---
--- An import that finds a name already taken must know whether it is looking
--- at its own earlier work or at a macro the player wrote by hand. Answering
--- "yes" wrongly costs the player a macro body; answering "no" wrongly costs
--- them one skipped update they can retry. The two are not symmetric, so every
--- uncertain case answers no.
---
--- Ownership is granted on any of three signals:
---   1. the name is a key in GRIP_EMS_DB.macros   (account scope)
---   2. the name is a key in GRIP_EMS_CHAR.macros (per-character scope)
---   3. the body at the slot carries the button prefix, i.e. it is a stub EMS
---      wrote -- the same structural match ScanExisting uses to reclaim stubs
---      on login, so there is ONE convention for "this body is ours"
---
--- BOTH buckets are consulted regardless of the import's own scope. The
--- buckets are split by scope but GetMacroIndexByName searches the account and
--- character tabs together, so a lookup that consulted only the matching
--- bucket would let an account-scope import silently eat a character-scope
--- macro, and the reverse. That cross-scope hole is the reason this takes no
--- isCharacterScope argument.
---
--- Every global read is guarded: GRIP_EMS_DB and GRIP_EMS_CHAR can both be nil
--- before SavedVariables load, and a nil-index error here would break import
--- entirely rather than merely mis-answer. With neither global readable the
--- bucket arms cannot answer at all, so ownership is UNKNOWN and the result is
--- false, which routes to the refusal. Signal 3 still stands on its own there
--- because it reads the live macro body rather than any saved state: a body
--- carrying the button prefix is ours by construction, whatever the
--- SavedVariables happen to hold.
---
--- @param name string Macro name as it appears in /macro
--- @param slot number|nil Slot index the name currently resolves to
--- @return boolean True when EMS may overwrite the macro at this slot
local function emsOwnsMacro(name, slot)
    if not name or name == "" then
        return false
    end

    local db = _G.GRIP_EMS_DB
    if db and type(db.macros) == "table" and db.macros[name] ~= nil then
        return true
    end

    local charDb = _G.GRIP_EMS_CHAR
    if charDb and type(charDb.macros) == "table" and charDb.macros[name] ~= nil then
        return true
    end

    if slot and slot > 0 then
        local _, _, body = GetMacroInfo(slot)
        if type(body) == "string" then
            if body:match("; " .. D.BUTTON_PREFIX .. "(%S+)") then
                return true
            end
            if body:match("/click " .. D.BUTTON_PREFIX .. "(%S+)") then
                return true
            end
        end
    end

    return false
end

--- Strip wire-format-only fields before storing the node in SavedVariables.
--- @param node table Node to clean (mutated in place)
local function cleanNode(node)
    node.category = nil
    node.objectType = nil
end

--- Create or update an in-game macro from an imported macro node.
---
--- If the name is free, a new macro is created via CreateMacro and the
--- resulting slot index is written back into node.value. The node is then
--- mirrored into the matching SavedVariables bucket (account or per-character).
---
--- If the name is already taken, the existing slot is updated via EditMacro
--- ONLY WHEN EMS OWNS IT (see emsOwnsMacro). A name held by a macro the player
--- wrote is REFUSED: a localized warning names the macro, nothing is written,
--- and nil is returned.
---
--- This function used to overwrite unconditionally, and its docstring
--- presented that as the contract, which is why the behaviour survived review.
--- An import string carrying a Macros payload -- or Layer 3 legacy migration --
--- would replace the body of any macro whose name collided, then record the
--- adopted slot as EMS's own. Sequence-name collisions were already handled by
--- a rename; macro-name collisions had no equivalent.
---
--- The refusal deliberately writes NOTHING: not node.value, not the bucket.
--- Recording either would make the next import see the foreign macro as
--- EMS-owned, so a refusal that still wrote the bucket would delay the
--- overwrite by exactly one import rather than prevent it.
---
--- The macro is NOT renamed to dodge the collision: sequence steps reference
--- macros by bare name, so a rename leaves the step pointing at a name that no
--- longer exists and breaks the sequence quietly.
---
--- @param node table { name, icon, text, value, manageMacro }
--- @param isCharacterScope boolean True to create/store as per-character
--- @return table|nil The mutated node on success, nil if combat-restricted,
---                   invalid, slots are full, or the name belongs to a macro
---                   EMS does not own
function MM:UpdateMacro(node, isCharacterScope)
    if type(node) ~= "table" then
        return nil
    end
    if not node.name or node.name == "" then
        return nil
    end
    if not node.text and not node.manageMacro then
        return nil
    end

    -- Combat guard: write via OOCQueue if restricted, otherwise inline
    if InCombatLockdown() then
        return nil
    end

    local icon = node.icon or D.QUESTION_MARK_ICON
    local body = node.text or node.manageMacro or ""

    local existingSlot = GetMacroIndexByName(node.name)

    -- Overflow guard: when about to call CreateMacro for a brand-new slot,
    -- check against the per-scope cap and surface a localized warning if
    -- the slot pool is full. This is the ONLY place EMS calls CreateMacro
    -- for imports (LegacyMigrate routes here too via OOCQueue), so the
    -- check covers COLLECTION import and Layer 3 migration uniformly.
    if not existingSlot or existingSlot == 0 then
        local global, perChar = GetNumMacros()
        if isCharacterScope then
            if perChar >= D.MAX_PER_CHAR_MACROS then
                GRIPEMS:Print(
                    string.format(
                        L["GEMS_IMPORT_MACROS_OVERFLOW"]
                            or "Macro '%s' could not be created -- macro slots full (%d/%d). Delete unused /macro entries and re-import.",
                        node.name,
                        perChar,
                        D.MAX_PER_CHAR_MACROS
                    )
                )
                return nil
            end
        else
            if global >= D.MAX_ACCOUNT_MACROS then
                GRIPEMS:Print(
                    string.format(
                        L["GEMS_IMPORT_MACROS_OVERFLOW"]
                            or "Macro '%s' could not be created -- macro slots full (%d/%d). Delete unused /macro entries and re-import.",
                        node.name,
                        global,
                        D.MAX_ACCOUNT_MACROS
                    )
                )
                return nil
            end
        end
    end

    if existingSlot and existingSlot > 0 then
        -- Ownership gate. Overwriting a macro EMS never created destroys the
        -- player's own body, so an unowned name is refused outright and
        -- NOTHING is recorded -- see the note on writes in the docstring.
        if not emsOwnsMacro(node.name, existingSlot) then
            GRIPEMS:Print(
                string.format(
                    L["GEMS_IMPORT_MACRO_NOT_OURS"]
                        or "Macro '%s' already exists and was not created by EMS, so it was left alone. "
                            .. "Rename your macro or the one in the import, then import again.",
                    node.name
                )
            )
            return nil
        end
        withMacroWriteGuard(function()
            EditMacro(existingSlot, node.name, icon, body)
        end)
        node.value = existingSlot
    else
        local newSlot
        withMacroWriteGuard(function()
            newSlot = CreateMacro(node.name, icon, body, isCharacterScope and true or false)
        end)
        if not newSlot then
            return nil
        end
        node.value = newSlot
    end

    -- Mirror into SavedVariables (drop wire-only fields first)
    cleanNode(node)
    local bucket = getStorageBucket(isCharacterScope)
    if bucket then
        bucket[node.name] = node
    end

    return node
end

--- Import a macro node from a sequence payload. Resolves account/character
--- scope from node.category ("p" for per-character, anything else for
--- account), forwards to MM:UpdateMacro, and prints a user-facing line.
---
--- The combat / restriction defer is handled by the caller -- LegacyImport
--- enqueues this through GRIPEMS.OOCQueue so by the time we fire, lockdown
--- is clear. If lockdown re-asserts mid-tick (unlikely but possible),
--- UpdateMacro returns nil and the entry is dropped this pass; the next
--- import attempt will re-enqueue.
---
--- THE RETURN VALUE IS LOAD-BEARING. It already decided whether to print the
--- confirmation line and was then thrown away, which is how a refused macro
--- came to be counted as imported: out of combat OOCQueue:Add runs this
--- synchronously, so LI.ImportMacro reaches its counter line with the outcome
--- ALREADY known and no way to read it. Returning UpdateMacro's own result
--- rather than a fresh vocabulary keeps one meaning for "the node on success,
--- nil otherwise" across this whole path.
---
--- @param node table { name, icon, text, value, manageMacro, category }
--- @return table|nil The mutated node on success, nil when the node is invalid
---                   or UpdateMacro refused it (unowned name, slots full,
---                   combat re-asserted)
function MM:ImportMacro(node)
    if type(node) ~= "table" then
        return nil
    end
    local name = node.name
    if not name or name == "" then
        return nil
    end

    local isCharacterScope = (node.category == "p")
    local result = self:UpdateMacro(node, isCharacterScope)
    if result then
        GRIPEMS:Print(string.format(L["GEMS_IMPORT_MACRO_LINE"] or "Macro %s was imported.", name))
    end
    return result
end

--- Snapshot a macro from the live WoW macro list into a node table.
--- Used by export production (snapshot dependent macros into the bundle)
--- and by Layer 2 inline fallback (look up a macro body that is in /macro
--- but was not bundled in the import payload).
---
--- @param name string Macro name to look up
--- @return table|nil Node { name, icon, text, value, manageMacro } or nil if not found
function MM:SnapshotByName(name)
    if not name or name == "" then
        return nil
    end
    local slot = GetMacroIndexByName(name)
    if not slot or slot <= 0 then
        return nil
    end
    local macroName, iconTexture, body = GetMacroInfo(slot)
    if not macroName then
        return nil
    end
    return {
        name = macroName,
        icon = iconTexture,
        text = body or "",
        value = slot,
        manageMacro = body or "",
    }
end

--- Look up a stored imported-macro node by name.
--- Checks account-scope first, then per-character scope. Used by the
--- Layer 2 inline-fallback path and by future typeahead pickers in the
--- editor.
---
--- @param name string Macro name to look up
--- @return table|nil Stored node or nil
function MM:GetStored(name)
    if not name or name == "" then
        return nil
    end
    if _G.GRIP_EMS_DB and GRIP_EMS_DB.macros and GRIP_EMS_DB.macros[name] then
        return GRIP_EMS_DB.macros[name]
    end
    if _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.macros and GRIP_EMS_CHAR.macros[name] then
        return GRIP_EMS_CHAR.macros[name]
    end
    return nil
end

---------------------------------------------------------------------------
-- Layer 4 macro-ref drift detection + refresh -- editor-side helpers for
-- the Macro action type. See Backlog row EMS-EDITOR-MACRO-ACTION-TYPE.
--
-- Storage shape: macro-ref nodes are regular Action nodes with two extra
-- fields:
--     node.subtype   = "macroref"               -- discriminator
--     node.macroName = "MOONSPAM"               -- bare name (picker, drift)
--     node.macro     = "/castsequence ..."      -- inlined body (runtime)
-- The compiler reads node.macro -- no compiler change needed.
--
-- Drift behavior: NO auto-sync. UPDATE_MACROS is NOT hooked. Drift is
-- detected on editor open and on every detail-pane render by comparing
-- stored node.macro against the live /macro body for node.macroName.
-- Refresh button is the only way the stored body changes after authoring.
---------------------------------------------------------------------------

--- Enumerate every macro the picker should show: WoW account/character
--- macros plus EMS-stored macros (account + per-character buckets).
--- De-duplicates by name; "both" sources prefer the live WoW body.
--- @return table Array of { name, icon, body, source } sorted by name.
---         source ::= "wow" | "ems_account" | "ems_char" | "both"
function MM:EnumerateAllMacros()
    local byName = {}

    -- WoW macros (account + per-character)
    local global, perChar = GetNumMacros()
    local accountSlots = D.MAX_ACCOUNT_MACROS
    -- Account scope: slots 1..MAX_ACCOUNT_MACROS (only first `global` populated)
    for i = 1, global do
        local name, icon, body = GetMacroInfo(i)
        if name and name ~= "" then
            byName[name] = {
                name = name,
                icon = icon,
                body = body or "",
                source = "wow",
            }
        end
    end
    -- Per-character scope: slots MAX_ACCOUNT_MACROS+1 .. +perChar
    for i = accountSlots + 1, accountSlots + perChar do
        local name, icon, body = GetMacroInfo(i)
        if name and name ~= "" and not byName[name] then
            byName[name] = {
                name = name,
                icon = icon,
                body = body or "",
                source = "wow",
            }
        end
    end

    -- EMS-stored macros (account scope)
    if _G.GRIP_EMS_DB and GRIP_EMS_DB.macros then
        for name, node in pairs(GRIP_EMS_DB.macros) do
            if name and name ~= "" then
                local existing = byName[name]
                if existing then
                    -- Already present from WoW: mark as "both", keep WoW body
                    existing.source = "both"
                else
                    byName[name] = {
                        name = name,
                        icon = node.icon or D.QUESTION_MARK_ICON,
                        body = node.text or node.manageMacro or "",
                        source = "ems_account",
                    }
                end
            end
        end
    end

    -- EMS-stored macros (per-character scope)
    if _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.macros then
        for name, node in pairs(GRIP_EMS_CHAR.macros) do
            if name and name ~= "" then
                local existing = byName[name]
                if existing then
                    if existing.source == "wow" then
                        existing.source = "both"
                    end
                    -- ems_account or both: leave as-is
                else
                    byName[name] = {
                        name = name,
                        icon = node.icon or D.QUESTION_MARK_ICON,
                        body = node.text or node.manageMacro or "",
                        source = "ems_char",
                    }
                end
            end
        end
    end

    -- Flatten + alphabetize
    local list = {}
    for _, entry in pairs(byName) do
        list[#list + 1] = entry
    end
    table.sort(list, function(a, b)
        return strlower(a.name) < strlower(b.name)
    end)
    return list
end

--- Detect whether a macro-ref node's stored body differs from the live
--- /macro body for its macroName. Pure read -- never mutates.
--- @param node table Action node with subtype = ACTION_SUBTYPE_MACROREF
--- @return table { isDrift, liveBody, sourceState }
---         sourceState ::= "ok" | "missing"
function MM:DetectDrift(node)
    if type(node) ~= "table" or node.subtype ~= D.ACTION_SUBTYPE_MACROREF then
        return { isDrift = false, liveBody = nil, sourceState = "ok" }
    end
    local name = node.macroName
    if not name or name == "" then
        return { isDrift = false, liveBody = nil, sourceState = "missing" }
    end
    local slot = GetMacroIndexByName(name)
    if not slot or slot <= 0 then
        return { isDrift = false, liveBody = nil, sourceState = "missing" }
    end
    local _, _, liveBody = GetMacroInfo(slot)
    liveBody = liveBody or ""
    local stored = (type(node.macro) == "string") and node.macro or ""
    return {
        isDrift = (liveBody ~= stored),
        liveBody = liveBody,
        sourceState = "ok",
    }
end

--- Re-pull the live /macro body into a macro-ref node's inlined macro
--- field. Used by the detail-pane Refresh button. Returns true on success.
--- @param node table Action node with subtype = ACTION_SUBTYPE_MACROREF
--- @return boolean true if refreshed, false if source is missing or wrong type
function MM:RefreshFromSource(node)
    if type(node) ~= "table" or node.subtype ~= D.ACTION_SUBTYPE_MACROREF then
        return false
    end
    local name = node.macroName
    if not name or name == "" then
        return false
    end
    local slot = GetMacroIndexByName(name)
    if not slot or slot <= 0 then
        return false
    end
    local _, _, body = GetMacroInfo(slot)
    node.macro = body or ""
    node.macroRefSynced = node.macro
    return true
end

---------------------------------------------------------------------------
-- Opt-in auto-refresh -- pull macro-ref bodies when the source /macro
-- changes, without the player opening the step. Gated by the profile
-- setting macroRefAutoRefresh (default off). Provenance/modification
-- guarded by node.macroRefSynced so imported or in-editor-edited bodies
-- are never silently overwritten.
---------------------------------------------------------------------------

--- Recurse an action array, calling fn(node) for every macro-ref node.
--- Discriminates container children the way the rest of the codebase does --
--- on node.type, not on child-array shape. An If node's children is
--- { trueArray, falseArray }; a Loop (and any other container) carries a flat
--- node array. Branching on type stays correct when either If branch is empty
--- (for example an else-only If with an empty true branch); a structural
--- "is children[1][1] truthy" heuristic would misread that as a flat Loop
--- array and skip every macro-ref in the populated false branch.
--- @param actions table Action node array
--- @param fn function Callback receiving each macro-ref node
local function forEachMacroRef(actions, fn)
    if type(actions) ~= "table" then
        return
    end
    for _, node in ipairs(actions) do
        if type(node) == "table" then
            if node.subtype == D.ACTION_SUBTYPE_MACROREF then
                fn(node)
            end
            local ch = node.children
            if type(ch) == "table" then
                if node.type == D.ACTION_TYPE_IF then
                    -- children = { trueArray, falseArray }; recurse each branch
                    -- explicitly so an empty branch in either slot does not hide
                    -- the other. forEachMacroRef no-ops on a nil/non-table arg.
                    forEachMacroRef(ch[1], fn)
                    forEachMacroRef(ch[2], fn)
                else
                    forEachMacroRef(ch, fn)
                end
            end
        end
    end
end

--- True when a macro-ref node may be auto-refreshed: source exists, the
--- live body differs from the stored body, and the stored body is exactly
--- what we last synced from this client (so it was not imported and not
--- edited in the editor).
--- @param node table Action node
--- @return boolean
function MM:_isAutoRefreshEligible(node)
    if type(node) ~= "table" or node.subtype ~= D.ACTION_SUBTYPE_MACROREF then
        return false
    end
    if node.macroRefSynced == nil or node.macro ~= node.macroRefSynced then
        return false
    end
    local drift = self:DetectDrift(node)
    return drift.sourceState == "ok" and drift.isDrift == true
end

--- Walk every stored sequence's every version, auto-refresh eligible
--- macro-ref nodes, and recompile each changed sequence so the live
--- button reflects the new body. The _suppressUpdateMacros bracket stops
--- RecompileSequence's own stub write from re-triggering the hook.
function MM:AutoRefreshAll()
    local engine = GRIPEMS.Engine
    if not engine or not engine.sequences then
        return
    end
    self._suppressUpdateMacros = (self._suppressUpdateMacros or 0) + 1
    local changedNames = {}
    for name, entry in pairs(engine.sequences) do
        local seqData = entry and entry.data
        if seqData and type(seqData.versions) == "table" then
            local seqChanged = false
            for _, ver in pairs(seqData.versions) do
                if ver and type(ver.actions) == "table" then
                    forEachMacroRef(ver.actions, function(node)
                        if self:_isAutoRefreshEligible(node) then
                            if self:RefreshFromSource(node) then
                                seqChanged = true
                            end
                        end
                    end)
                end
            end
            if seqChanged then
                changedNames[#changedNames + 1] = name
            end
        end
    end
    for _, name in ipairs(changedNames) do
        if engine.RecompileSequence then
            engine:RecompileSequence(name)
        end
    end
    self._suppressUpdateMacros = self._suppressUpdateMacros - 1
    if self._suppressUpdateMacros < 0 then
        self._suppressUpdateMacros = 0
    end
    if #changedNames > 0 then
        GRIPEMS:Debug(string.format(L["GEMS_MACROREF_AUTOREFRESH_DEBUG"], #changedNames))
    end
end

-- UPDATE_MACROS hook (idempotent frame). Debounced; gated on the setting;
-- skipped while our own macro writes are in flight.
local autoRefreshFrame = _G["GRIPEMS_MacroAutoRefreshEvent"] or CreateFrame("Frame", "GRIPEMS_MacroAutoRefreshEvent")
autoRefreshFrame:UnregisterAllEvents()
autoRefreshFrame:RegisterEvent("UPDATE_MACROS")
MM._autoRefreshPending = false
autoRefreshFrame:SetScript("OnEvent", function()
    if (MM._suppressUpdateMacros or 0) > 0 then
        return
    end
    local S = GRIPEMS.Settings
    if not S or not S:Get("macroRefAutoRefresh") then
        return
    end
    if MM._autoRefreshPending then
        return
    end
    MM._autoRefreshPending = true
    C_Timer.After(0.3, function()
        MM._autoRefreshPending = false
        MM:AutoRefreshAll()
    end)
end)
MM.autoRefreshFrame = autoRefreshFrame
