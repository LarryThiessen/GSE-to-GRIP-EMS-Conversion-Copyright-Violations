-- GRIP-EMS: Test spec for the KeybindTab focus contract + numbered-key tab jump
--
-- Created:    2026-06-28
-- Updated:    2026-08-17
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
--
-- Registers 3 tests under category "keybind" for /gems test keybind. Locks in
-- the G8 accessibility arc for the Keybind tab:
--   a56cb80 -- KT:Show pushes a "KeybindTab" focus context so Set Keybind is
--              Tab-reachable; KT:Hide / KT:Clear pop it.
--   94e8d12 -- the SequenceEditor numbered-key tab jump (1-6) whitelists the
--              "KeybindTab" base context, so digits switch tabs on the Keybind
--              tab again (and the digit is consumed, not leaked to the action
--              bar), while real modal contexts still block the jump.
--
-- Asserted (the mechanical keyboard pass, simulating the editor OnKeyDown call
-- the same way popup_focus_spec simulates the popup handler):
--   1  SwitchTab("Keybind") pushes the "KeybindTab" context whose first two
--      focus targets are setBtn then clearBtn; switching away pops it.
--   2  A "1" keypress on the editor panel while on the Keybind tab switches
--      tabs (the gate allows the jump) -- the 94e8d12 regression fix.
--   3  A modal context on top still blocks the "1" jump (the
--      A11Y-SE-OVERLAY-GATE modal protection is intact).
--
-- Self-setup: each test builds/shows the editor if needed and selects a temp
-- sequence, then tears all of it down (prior shown/hidden state, tab, selection,
-- and the temp sequence are restored). No manual prep -- /gems test keybind runs
-- the 3 tests directly. Keyboard focus is cleared right before the digit press
-- so the digit reaches the tab-jump gate instead of a focused EditBox tripping
-- the editor OnKeyDown guard.
--
-- Out of scope: WoW routing a physical keypress to the frame (the input system,
-- not EMS logic).

local ADDON_NAME, GRIPEMS = ...
local TS = GRIPEMS.TestSuite
if not TS then
    return
end

local CATEGORY = "keybind"
local SKIP_REASON = "editor right panel unavailable (rightPanel missing after open)"
local MODAL_CTX = "_TS_KeybindFocusModal"
local TEMP_SEQ = "_TS_KeybindFocus"

local function onKeyDown(frame, key)
    local handler = frame and frame.GetScript and frame:GetScript("OnKeyDown")
    if handler then
        handler(frame, key)
    end
end

-- Clear keyboard focus so the simulated digit reaches the tab-jump gate. When
-- the editor is open a frame usually holds keyboard focus (e.g. the StepListView
-- macro EditBox), which trips the OnKeyDown EditBox guard and leaks the digit to
-- the EditBox instead of the gate.
local function clearKeyboardFocus()
    local kf = GetCurrentKeyBoardFocus and GetCurrentKeyBoardFocus()
    if kf and kf.ClearFocus then
        kf:ClearFocus()
    end
    if GRIPEMS.Focus and GRIPEMS.Focus.editBoxFocused ~= nil then
        -- belt: clear the cached flag the editor guard also reads
        GRIPEMS.Focus.editBoxFocused = false
    end
end

-- Shared setup. Skips (never Fails) when the live state needed to exercise the
-- contract is unreachable. On success returns a teardown() closure that restores
-- everything it touched, so every exit path stays hermetic.
local function setup(self)
    if InCombatLockdown() then
        self:Skip("requires out of combat (the tab-jump gate and KeybindTab handlers gate on combat lockdown)")
        return nil, false
    end
    local Engine = GRIPEMS.Engine
    local SE = GRIPEMS.SequenceEditor
    local Focus = GRIPEMS.Focus
    local KT = GRIPEMS.KeybindTab
    local UI = GRIPEMS.UI
    local D = GRIPEMS.Defaults
    if not (Engine and Engine.ActivateSequence and Engine.DeactivateSequence) then
        self:Skip("GRIPEMS.Engine API missing")
        return nil, false
    end
    if not (SE and SE.SwitchTab and SE.LoadSequence and SE.Clear) then
        self:Skip("GRIPEMS.SequenceEditor API missing")
        return nil, false
    end
    if not (Focus and Focus.TopContext and Focus.PushContext and Focus.PopContext) then
        self:Skip("GRIPEMS.Focus API missing")
        return nil, false
    end
    if not (KT and KT.GetFocusTargets) then
        self:Skip("GRIPEMS.KeybindTab API missing")
        return nil, false
    end
    if not (UI and UI.ToggleMainFrame) then
        self:Skip("GRIPEMS.UI API missing")
        return nil, false
    end
    if not (D and D.NewSequenceFromTemplate and D.TestSequence) then
        self:Skip("GRIPEMS.Defaults API missing")
        return nil, false
    end

    -- Do not clobber an unsaved working copy: SE:LoadSequence (used to
    -- select the temp sequence and to restore on teardown) bypasses the
    -- SL:SelectSequence dirty prompt, so a dirty editor would lose its edits.
    if SE.isDirty then
        self:Skip("editor has unsaved changes; save or discard, then /gems test keybind")
        return nil, false
    end

    -- Save originals before mutating anything.
    local mf = _G.GRIPEMS_MainFrame
    local wasShown = mf and mf.IsShown and mf:IsShown()
    local origTab = SE.activeTab
    local origSeq = SE.currentSequence

    -- Ensure the editor is built + shown.
    local openedByTest = false
    if not wasShown then
        UI:ToggleMainFrame()
        openedByTest = true
    end

    -- Create a temp sequence with the same shape TestSuite.lua uses, then select
    -- it into the editor so SE.currentSequence == the temp name.
    if Engine.sequences and Engine.sequences[TEMP_SEQ] then
        Engine:DeactivateSequence(TEMP_SEQ)
    end
    local seqData = D.NewSequenceFromTemplate(TEMP_SEQ, D.TestSequence)
    Engine:ActivateSequence(TEMP_SEQ, seqData)
    SE:LoadSequence(TEMP_SEQ)

    local function teardown()
        if origTab then
            SE:SwitchTab(origTab)
        end
        if origSeq then
            SE:LoadSequence(origSeq)
        else
            SE:Clear()
        end
        Engine:DeactivateSequence(TEMP_SEQ)
        if openedByTest then
            local f = _G.GRIPEMS_MainFrame
            if f and f.Hide then
                f:Hide()
            end
        end
    end

    return teardown, true
end

TS:Register("Keybind tab pushes the KeybindTab focus context with capture targets", CATEGORY, function(self)
    local teardown, ok = setup(self)
    if not ok then
        return
    end
    local SE = GRIPEMS.SequenceEditor
    local Focus = GRIPEMS.Focus
    local KT = GRIPEMS.KeybindTab

    -- Mutate + measure first, then tear down, then assert -- so a failed
    -- assertion never leaves the editor on the wrong tab or the stack unbalanced.
    SE:SwitchTab("Keybind")
    local ctx = Focus:TopContext()
    local pushedName = ctx and ctx.name
    local t = KT:GetFocusTargets()
    local targetsOk = type(t) == "table" and #t >= 2 and t[1] == KT.setBtn and t[2] == KT.clearBtn

    -- Switch away to prove the context is popped on leave.
    SE:SwitchTab("Steps")
    local awayCtx = Focus:TopContext()
    local poppedOnLeave = not (awayCtx and awayCtx.name == "KeybindTab")

    teardown()

    if pushedName ~= "KeybindTab" then
        self:Fail("SwitchTab(Keybind) did not push the KeybindTab context; top=" .. tostring(pushedName))
        return
    end
    if not targetsOk then
        self:Fail("GetFocusTargets must return a table whose first two entries are setBtn then clearBtn")
        return
    end
    if not poppedOnLeave then
        self:Fail("switching away from the Keybind tab did not pop the KeybindTab context")
        return
    end
    self:Pass()
end)

TS:Register("Numbered-key tab jump works on the Keybind tab (94e8d12 regression fix)", CATEGORY, function(self)
    local teardown, ok = setup(self)
    if not ok then
        return
    end
    local SE = GRIPEMS.SequenceEditor
    local Focus = GRIPEMS.Focus
    local mf = _G.GRIPEMS_MainFrame
    local panel = mf and mf.rightPanel
    if not (panel and panel.GetScript) then
        teardown()
        self:Skip(SKIP_REASON)
        return
    end

    SE:SwitchTab("Keybind")
    local onKeybind = Focus:TopContext()
    local ctxOk = onKeybind and onKeybind.name == "KeybindTab"
    -- Clear keyboard focus so the digit reaches the gate. Digit "1" on the editor
    -- panel then switches to tab 1 ("Steps") instead of leaking to the action
    -- bar. tabOrder[1] is "Steps", never "Keybind".
    clearKeyboardFocus()
    onKeyDown(panel, "1")
    local jumped = SE.activeTab ~= "Keybind"

    teardown()

    if not ctxOk then
        self:Fail("precondition: SwitchTab(Keybind) did not push the KeybindTab context")
        return
    end
    if not jumped then
        self:Fail("digit 1 did not switch tabs on the Keybind tab (the gate blocked the jump)")
        return
    end
    self:Pass()
end)

TS:Register("A modal context still blocks the numbered-key tab jump (gate intact)", CATEGORY, function(self)
    local teardown, ok = setup(self)
    if not ok then
        return
    end
    local SE = GRIPEMS.SequenceEditor
    local Focus = GRIPEMS.Focus
    local mf = _G.GRIPEMS_MainFrame
    local panel = mf and mf.rightPanel
    if not (panel and panel.GetScript) then
        teardown()
        self:Skip(SKIP_REASON)
        return
    end

    SE:SwitchTab("Keybind")
    local ctx = Focus:TopContext()
    local ctxOk = ctx and ctx.name == "KeybindTab"

    -- Push a stand-in modal context on top of KeybindTab. The gate must treat any
    -- non-base context as modal and block the digit jump even with keyboard focus
    -- cleared, proving the block is the modal gate -- not a focused EditBox. Pop
    -- it BEFORE tearing down so the focus stack stays balanced on failure.
    Focus:PushContext(MODAL_CTX, {})
    local before = SE.activeTab
    clearKeyboardFocus()
    onKeyDown(panel, "1")
    local blocked = SE.activeTab == before
    Focus:PopContext(MODAL_CTX)

    teardown()

    if not ctxOk then
        self:Fail("precondition: SwitchTab(Keybind) did not push the KeybindTab context")
        return
    end
    if not blocked then
        self:Fail("digit 1 switched tabs with a modal context on top (the gate was weakened)")
        return
    end
    self:Pass()
end)
