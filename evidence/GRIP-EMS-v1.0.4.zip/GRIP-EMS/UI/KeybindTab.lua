-- GRIP-EMS: Keybind Tab
-- Keybind editor panel with display, key capture, and per-spec overview

local ADDON_NAME, GRIPEMS = ...
local UI = GRIPEMS.UI
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS")

-- Upvalue accessor for Defaults
local function D() return GRIPEMS.Defaults end

GRIPEMS.KeybindTab = {}
local KT = GRIPEMS.KeybindTab

-- Runtime state
KT.currentSeqName = nil
KT.isCapturing = false

-- Modifier-only keys to ignore during capture
local MODIFIER_KEYS = {
    LSHIFT = true, RSHIFT = true,
    LCTRL = true, RCTRL = true,
    LALT = true, RALT = true,
    LMETA = true, RMETA = true,
}

---------------------------------------------------------------------------
-- Initialization
---------------------------------------------------------------------------

--- Build the keybind tab UI inside the given parent frame (content area).
--- @param parentFrame Frame The content area that hosts tab content
function KT:Init(parentFrame)
    if not parentFrame then return end
    local C = UI.Colors

    KT.container = parentFrame

    -- Main scroll frame for the keybind tab content
    local frame = CreateFrame("Frame", nil, parentFrame)
    frame:SetAllPoints(parentFrame)
    frame:Hide()
    KT.frame = frame

    local yOff = -8

    -----------------------------------------------------------------------
    -- A) Current Keybind Display
    -----------------------------------------------------------------------
    local kbLabel = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(kbLabel, 10)
    kbLabel:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, yOff)
    kbLabel:SetText(L["GEMS_UI_CURRENT_KEYBIND"])
    kbLabel:SetTextColor(C.textSecondary:GetRGBA())
    KT.kbLabel = kbLabel

    local kbDisplay = frame:CreateFontString(nil, "OVERLAY")
    local fontPath = GameFontNormal:GetFont()
    kbDisplay:SetFont(fontPath, D().KEYBIND_DISPLAY_FONT_SIZE, "OUTLINE")
    kbDisplay:SetPoint("TOPLEFT", kbLabel, "BOTTOMLEFT", 0, -4)
    kbDisplay:SetText(L["GEMS_UI_KEYBIND_DISPLAY_NONE"])
    kbDisplay:SetTextColor(C.textMuted:GetRGBA())
    KT.kbDisplay = kbDisplay

    yOff = -8 - 14 - 4 - D().KEYBIND_DISPLAY_FONT_SIZE - 8

    -----------------------------------------------------------------------
    -- B) Key Capture Row
    -----------------------------------------------------------------------
    local captureRow = CreateFrame("Frame", nil, frame)
    captureRow:SetHeight(D().KEY_CAPTURE_BUTTON_HEIGHT + 4)
    captureRow:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, yOff)
    captureRow:SetPoint("RIGHT", frame, "RIGHT", -8, 0)
    KT.captureRow = captureRow

    -- Set/Change button
    local setBtn = UI:CreateButton(captureRow, L["GEMS_UI_SET_KEYBIND"],
        D().KEY_CAPTURE_BUTTON_WIDTH, D().KEY_CAPTURE_BUTTON_HEIGHT)
    setBtn:SetPoint("LEFT", captureRow, "LEFT", 0, 0)
    setBtn:SetScript("OnClick", function()
        KT:StartCapture()
    end)
    setBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.bgRowHover:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
        UI:ShowTooltip(self, L["GEMS_UI_SET_KEYBIND"],
            L["GEMS_UI_KEYBIND_HINT"])
    end)
    setBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
        UI:HideTooltip()
    end)
    KT.setBtn = setBtn

    -- Clear button
    local clearBtn = UI:CreateButton(captureRow, L["GEMS_UI_CLEAR_KEYBIND"],
        70, D().KEY_CAPTURE_BUTTON_HEIGHT)
    clearBtn:SetPoint("LEFT", setBtn, "RIGHT", 4, 0)
    clearBtn:SetScript("OnClick", function()
        if not KT.currentSeqName then return end
        local KM = GRIPEMS.KeybindManager
        if KM then
            KM:ClearKeybind(KT.currentSeqName)
            KT:RefreshDisplay()
        end
    end)
    clearBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.bgRowHover:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
        UI:ShowTooltip(self, L["GEMS_UI_CLEAR_KEYBIND"])
    end)
    clearBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
        UI:HideTooltip()
    end)
    KT.clearBtn = clearBtn

    yOff = yOff - D().KEY_CAPTURE_BUTTON_HEIGHT - 16

    -----------------------------------------------------------------------
    -- C) Spec Overview
    -----------------------------------------------------------------------
    local specLabel = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(specLabel, 10)
    specLabel:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, yOff)
    specLabel:SetText(L["GEMS_UI_SPEC_KEYBINDS"])
    specLabel:SetTextColor(C.textSecondary:GetRGBA())
    KT.specLabel = specLabel

    -- Spec rows container
    local specContainer = CreateFrame("Frame", nil, frame)
    specContainer:SetPoint("TOPLEFT", specLabel, "BOTTOMLEFT", 0, -4)
    specContainer:SetPoint("RIGHT", frame, "RIGHT", -8, 0)
    specContainer:SetHeight(4 * D().SPEC_ROW_HEIGHT)
    KT.specContainer = specContainer

    -- Loadout hint text
    local loadoutHint = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(loadoutHint, 9)
    loadoutHint:SetPoint("TOPLEFT", specContainer, "BOTTOMLEFT", 0, -6)
    loadoutHint:SetText(L["GEMS_UI_LOADOUT_COMING_SOON"])
    loadoutHint:SetTextColor(C.textMuted:GetRGBA())
    KT.loadoutHint = loadoutHint

    -----------------------------------------------------------------------
    -- D) Hint text (bottom)
    -----------------------------------------------------------------------
    local hintText = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(hintText, 9)
    hintText:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 8, 8)
    hintText:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -8, 8)
    hintText:SetText(L["GEMS_UI_KEYBIND_HINT"])
    hintText:SetTextColor(C.textMuted:GetRGBA())
    hintText:SetJustifyH("LEFT")
    hintText:SetWordWrap(true)
    KT.hintText = hintText

    -----------------------------------------------------------------------
    -- Key capture frame (invisible, fullscreen, eats all keypresses)
    -----------------------------------------------------------------------
    local captureFrame = CreateFrame("Frame", "GRIPEMS_KeyCapture", UIParent)
    captureFrame:SetFrameStrata("FULLSCREEN_DIALOG")
    captureFrame:SetAllPoints(UIParent)
    captureFrame:EnableKeyboard(true)
    captureFrame:Hide()

    captureFrame:SetScript("OnKeyDown", function(self, key)
        KT:OnCaptureKeyDown(key)
    end)
    captureFrame:SetScript("OnShow", function(self)
        self:SetPropagateKeyboardInput(false)
    end)
    captureFrame:SetScript("OnHide", function(self)
        self:SetPropagateKeyboardInput(true)
    end)
    KT.captureFrame = captureFrame

    -- Register KEYBIND_CHANGED callback
    if GRIPEMS.RegisterCallback then
        GRIPEMS.RegisterCallback(KT, "KEYBIND_CHANGED", "OnKeybindChanged")
    end
end

---------------------------------------------------------------------------
-- Key capture logic
---------------------------------------------------------------------------

--- Start key capture mode. Checks combat lockdown first.
function KT:StartCapture()
    if not KT.currentSeqName then return end

    if InCombatLockdown() then
        GRIPEMS:Print(L["GEMS_UI_CAPTURE_COMBAT"])
        return
    end

    KT.isCapturing = true
    local C = UI.Colors

    -- Update button text
    if KT.setBtn and KT.setBtn.label then
        KT.setBtn.label:SetText(L["GEMS_UI_PRESS_KEY"])
        KT.setBtn:SetBackdropBorderColor(C.accent:GetRGBA())
    end

    -- Show capture frame (with pcall safety)
    local ok, err = pcall(function()
        if KT.captureFrame then
            KT.captureFrame:Show()
        end
    end)
    if not ok then
        KT:StopCapture()
        GRIPEMS:Print("Capture error: " .. tostring(err))
    end
end

--- Stop key capture mode. Always hides the capture frame safely.
function KT:StopCapture()
    KT.isCapturing = false

    -- CRITICAL: Always hide the capture frame
    if KT.captureFrame then
        KT.captureFrame:Hide()
    end

    -- Restore button text
    KT:UpdateSetButtonLabel()
end

--- Handle a key press during capture mode.
--- @param key string The WoW key name
function KT:OnCaptureKeyDown(key)
    -- Ignore lone modifier keys
    if MODIFIER_KEYS[key] then return end

    -- Escape cancels capture (deferred so ESCAPE isn't propagated to MainFrame)
    if key == "ESCAPE" then
        C_Timer.After(0, function() KT:StopCapture() end)
        return
    end

    -- Build combo string: ALT-CTRL-SHIFT-KEY (alphabetical order)
    local parts = {}
    if IsAltKeyDown() then parts[#parts + 1] = "ALT" end
    if IsControlKeyDown() then parts[#parts + 1] = "CTRL" end
    if IsShiftKeyDown() then parts[#parts + 1] = "SHIFT" end
    parts[#parts + 1] = key
    local combo = table.concat(parts, "-")

    -- Apply keybind (pcall for safety -- MUST hide capture frame on error)
    local ok, err = pcall(function()
        local KM = GRIPEMS.KeybindManager
        if KM and KT.currentSeqName then
            KM:SetKeybind(KT.currentSeqName, combo)
        end
    end)

    -- Always stop capture (hides frame)
    KT:StopCapture()
    KT:RefreshDisplay()

    if not ok then
        GRIPEMS:Print("Keybind error: " .. tostring(err))
    end
end

---------------------------------------------------------------------------
-- Display refresh
---------------------------------------------------------------------------

--- Update the Set/Change button label based on current keybind state.
function KT:UpdateSetButtonLabel()
    if not KT.setBtn or not KT.setBtn.label then return end
    local KM = GRIPEMS.KeybindManager
    local currentKey = KM and KT.currentSeqName and KM:GetKeybind(KT.currentSeqName)

    if currentKey then
        KT.setBtn.label:SetText(L["GEMS_UI_CHANGE_KEYBIND"])
    else
        KT.setBtn.label:SetText(L["GEMS_UI_SET_KEYBIND"])
    end

    local C = UI.Colors
    KT.setBtn:SetBackdropBorderColor(C.border:GetRGBA())
end

--- Refresh the entire keybind tab display.
function KT:RefreshDisplay()
    if not KT.frame then return end
    local C = UI.Colors
    local KM = GRIPEMS.KeybindManager

    -- Current keybind display
    local currentKey = KM and KT.currentSeqName and KM:GetKeybind(KT.currentSeqName)
    if KT.kbDisplay then
        if currentKey then
            KT.kbDisplay:SetText(currentKey)
            KT.kbDisplay:SetTextColor(C.keybindGold:GetRGBA())
        else
            KT.kbDisplay:SetText(L["GEMS_UI_KEYBIND_DISPLAY_NONE"])
            KT.kbDisplay:SetTextColor(C.textMuted:GetRGBA())
        end
    end

    -- Button states
    KT:UpdateSetButtonLabel()

    -- Clear button: disabled if no keybind
    if KT.clearBtn then
        if currentKey then
            KT.clearBtn:Enable()
            KT.clearBtn.label:SetTextColor(C.textPrimary:GetRGBA())
            KT.clearBtn:SetBackdropColor(C.bgButton:GetRGBA())
        else
            KT.clearBtn:Disable()
            KT.clearBtn.label:SetTextColor(C.textMuted:GetRGBA())
            KT.clearBtn:SetBackdropColor(C.bgDeep:GetRGBA())
        end
    end

    -- Combat lockdown check for buttons
    if InCombatLockdown() then
        if KT.setBtn then
            KT.setBtn:Disable()
            KT.setBtn.label:SetTextColor(C.textMuted:GetRGBA())
            KT.setBtn:SetBackdropColor(C.bgDeep:GetRGBA())
        end
        if KT.clearBtn then
            KT.clearBtn:Disable()
            KT.clearBtn.label:SetTextColor(C.textMuted:GetRGBA())
            KT.clearBtn:SetBackdropColor(C.bgDeep:GetRGBA())
        end
    else
        if KT.setBtn and KT.currentSeqName then
            KT.setBtn:Enable()
            KT.setBtn.label:SetTextColor(C.textPrimary:GetRGBA())
            KT.setBtn:SetBackdropColor(C.bgButton:GetRGBA())
        end
    end

    -- Spec overview
    KT:RefreshSpecOverview()
end

--- Refresh the spec overview section.
function KT:RefreshSpecOverview()
    if not KT.specContainer then return end
    local C = UI.Colors
    local KM = GRIPEMS.KeybindManager

    -- Clear existing spec rows
    if KT.specRows then
        for _, row in ipairs(KT.specRows) do
            row:Hide()
        end
    end
    KT.specRows = KT.specRows or {}

    local numSpecs = GetNumSpecializations() or 0
    local currentSpec = KM and KM:GetCurrentSpec() or 0

    for i = 1, numSpecs do
        local _, specName, _, specIcon = C_SpecializationInfo.GetSpecializationInfo(i)
        if not specName then specName = "Spec " .. i end

        -- Create row frame if needed
        local row = KT.specRows[i]
        if not row then
            row = CreateFrame("Frame", nil, KT.specContainer, "BackdropTemplate")
            row:SetHeight(D().SPEC_ROW_HEIGHT)

            if not row.SetBackdrop then
                Mixin(row, BackdropTemplateMixin)
            end
            row:SetBackdrop(UI.Backdrops.panelNoBorder)

            -- Spec icon
            row.icon = row:CreateTexture(nil, "ARTWORK")
            row.icon:SetSize(20, 20)
            row.icon:SetPoint("LEFT", row, "LEFT", 4, 0)

            -- Spec name
            row.nameText = row:CreateFontString(nil, "OVERLAY")
            UI:SetFont(row.nameText, 11)
            row.nameText:SetPoint("LEFT", row.icon, "RIGHT", 6, 0)

            -- Key display
            row.keyText = row:CreateFontString(nil, "OVERLAY")
            UI:SetFont(row.keyText, 11)
            row.keyText:SetPoint("RIGHT", row, "RIGHT", -4, 0)

            KT.specRows[i] = row
        end

        -- Position
        row:SetPoint("TOPLEFT", KT.specContainer, "TOPLEFT", 0,
            -(i - 1) * D().SPEC_ROW_HEIGHT)
        row:SetPoint("RIGHT", KT.specContainer, "RIGHT", 0, 0)

        -- Icon
        if specIcon then
            row.icon:SetTexture(specIcon)
        end

        -- Name with (current) suffix
        local isCurrent = (i == currentSpec)
        if isCurrent then
            row.nameText:SetText(specName .. " " .. L["GEMS_UI_CURRENT_SPEC"])
            row.nameText:SetTextColor(C.textPrimary:GetRGBA())
            row:SetBackdropColor(C.bgRowSelected:GetRGBA())
        else
            row.nameText:SetText(specName)
            row.nameText:SetTextColor(C.textSecondary:GetRGBA())
            row:SetBackdropColor(0, 0, 0, 0)
        end

        -- Find keybind for this spec and current sequence
        local specKey = nil
        if KT.currentSeqName and _G.GRIP_EMS_CHAR
                and GRIP_EMS_CHAR.keybinds and GRIP_EMS_CHAR.keybinds[i] then
            for key, seqName in pairs(GRIP_EMS_CHAR.keybinds[i]) do
                if seqName == KT.currentSeqName then
                    specKey = key
                    break
                end
            end
        end

        if specKey then
            row.keyText:SetText(specKey)
            row.keyText:SetTextColor(C.keybindGold:GetRGBA())
        else
            row.keyText:SetText(L["GEMS_UI_KEYBIND_DISPLAY_NONE"])
            row.keyText:SetTextColor(C.textMuted:GetRGBA())
        end

        row:Show()
    end

    -- Adjust container height
    KT.specContainer:SetHeight(numSpecs * D().SPEC_ROW_HEIGHT)
end

---------------------------------------------------------------------------
-- Data flow methods (called by SequenceEditor)
---------------------------------------------------------------------------

--- Load keybind data for a sequence.
--- @param name string Sequence name
function KT:LoadSequence(name)
    KT.currentSeqName = name
    KT:RefreshDisplay()
end

--- Clear the keybind tab.
function KT:Clear()
    KT.currentSeqName = nil
    KT:StopCapture()

    local C = UI.Colors
    if KT.kbDisplay then
        KT.kbDisplay:SetText(L["GEMS_UI_KEYBIND_DISPLAY_NONE"])
        KT.kbDisplay:SetTextColor(C.textMuted:GetRGBA())
    end

    if KT.specRows then
        for _, row in ipairs(KT.specRows) do
            row:Hide()
        end
    end
end

--- Show the keybind tab.
function KT:Show()
    if KT.frame then KT.frame:Show() end
    KT:RefreshDisplay()
end

--- Hide the keybind tab.
function KT:Hide()
    if KT.frame then KT.frame:Hide() end
    KT:StopCapture()
end

---------------------------------------------------------------------------
-- Callback handler
---------------------------------------------------------------------------

--- Respond to KEYBIND_CHANGED events.
function KT:OnKeybindChanged(event, seqName, key)
    if KT.frame and KT.frame:IsShown() then
        KT:RefreshDisplay()
    end
end
