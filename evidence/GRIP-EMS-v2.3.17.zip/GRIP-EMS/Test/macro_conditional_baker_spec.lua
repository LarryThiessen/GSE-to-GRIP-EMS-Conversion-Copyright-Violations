-- GRIP-EMS: Test spec for the Macro-Conditional Baker (IC-VAR-04, v2.1.8)
--
-- Created:    2026-05-28
-- Updated:    2026-06-21
-- Patch: 12.0.7.68256 Midnight (Retail LIVE)
--
-- Registers tests in TestSuite under category "macro_conditional_baker"
-- covering Engine/MacroConditionalBaker.lua. Groups:
--   1  per-helper positive (23) -- one bake per registered helper
--   2  per-shape positive (5)   -- T1 / T2 / I1 / I2 / L1
--   3  compound positive (16)   -- 6 AND-merge + 6 OR-chain + 4 mixed
--   4  negation (6)             -- 4 simple not + 2 DeMorgan compound
--   5  rejection (12)           -- shapes that must NOT bake (assert nil)
--   6  integration (3)          -- full CompileSteps bake + runtime + reject mix
--   7  performance smoke (1)    -- 50-step x100 compile under a permissive bound
-- Bake fixtures call MCB:Bake directly (no cache, no game state). Integration
-- and performance fixtures touch VariableStore + Engine and clean up after.

local ADDON_NAME, GRIPEMS = ...

local TS = GRIPEMS.TestSuite
if not TS then
    return
end

local CATEGORY = "macro_conditional_baker"

-- ---------------------------------------------------------------------------
-- Bake assertion helpers
-- ---------------------------------------------------------------------------

local function expectBake(self, funct, expected)
    local MCB = GRIPEMS.MacroConditionalBaker
    if not MCB then
        self:Skip("MacroConditionalBaker not loaded")
        return
    end
    local actual = MCB:Bake({ funct = funct })
    if actual == expected then
        self:Pass()
    else
        self:Fail("expected '" .. tostring(expected) .. "', got '" .. tostring(actual) .. "'")
    end
end

local function expectReject(self, funct)
    local MCB = GRIPEMS.MacroConditionalBaker
    if not MCB then
        self:Skip("MacroConditionalBaker not loaded")
        return
    end
    local actual = MCB:Bake({ funct = funct })
    if actual == nil then
        self:Pass()
    else
        self:Fail("expected reject (nil), got '" .. tostring(actual) .. "'")
    end
end

local function expectRejectVarDef(self, varDef)
    local MCB = GRIPEMS.MacroConditionalBaker
    if not MCB then
        self:Skip("MacroConditionalBaker not loaded")
        return
    end
    local actual = MCB:Bake(varDef)
    if actual == nil then
        self:Pass()
    else
        self:Fail("expected reject (nil), got '" .. tostring(actual) .. "'")
    end
end

-- ===========================================================================
-- GROUP 1 -- Per-helper positive (23 fixtures)
-- ===========================================================================

TS:Register("MCB.helper: InCombat -> [combat]", CATEGORY, function(self)
    expectBake(self, 'GRIPEMS.InCombat() and "Fireball" or "Frostbolt"', "[combat] Fireball; Frostbolt")
end)

TS:Register("MCB.helper: HasMod -> [mod:shift]", CATEGORY, function(self)
    expectBake(self, 'GRIPEMS.HasMod("shift") and "A" or "B"', "[mod:shift] A; B")
end)

TS:Register("MCB.helper: InStance -> [stance:1]", CATEGORY, function(self)
    expectBake(self, 'GRIPEMS.InStance(1) and "A" or "B"', "[stance:1] A; B")
end)

TS:Register("MCB.helper: InForm -> [form:2]", CATEGORY, function(self)
    expectBake(self, 'GRIPEMS.InForm(2) and "A" or "B"', "[form:2] A; B")
end)

TS:Register("MCB.helper: InSpec -> [spec:1]", CATEGORY, function(self)
    expectBake(self, 'GRIPEMS.InSpec(1) and "A" or "B"', "[spec:1] A; B")
end)

TS:Register("MCB.helper: InBonusBar -> [bonusbar:5]", CATEGORY, function(self)
    expectBake(self, 'GRIPEMS.InBonusBar(5) and "A" or "B"', "[bonusbar:5] A; B")
end)

TS:Register("MCB.helper: IsStealthed -> [stealth]", CATEGORY, function(self)
    expectBake(self, 'GRIPEMS.IsStealthed() and "A" or "B"', "[stealth] A; B")
end)

TS:Register("MCB.helper: IsDead -> [dead]", CATEGORY, function(self)
    expectBake(self, 'GRIPEMS.IsDead() and "A" or "B"', "[dead] A; B")
end)

TS:Register("MCB.helper: IsHelp -> [help]", CATEGORY, function(self)
    expectBake(self, 'GRIPEMS.IsHelp() and "A" or "B"', "[help] A; B")
end)

TS:Register("MCB.helper: IsHarm -> [harm]", CATEGORY, function(self)
    expectBake(self, 'GRIPEMS.IsHarm() and "A" or "B"', "[harm] A; B")
end)

TS:Register("MCB.helper: UnitExists -> [exists]", CATEGORY, function(self)
    expectBake(self, 'GRIPEMS.UnitExists() and "A" or "B"', "[exists] A; B")
end)

TS:Register("MCB.helper: InParty -> [party]", CATEGORY, function(self)
    expectBake(self, 'GRIPEMS.InParty() and "A" or "B"', "[party] A; B")
end)

TS:Register("MCB.helper: InRaid -> [raid]", CATEGORY, function(self)
    expectBake(self, 'GRIPEMS.InRaid() and "A" or "B"', "[raid] A; B")
end)

TS:Register("MCB.helper: InGroup -> [group]", CATEGORY, function(self)
    expectBake(self, 'GRIPEMS.InGroup() and "A" or "B"', "[group] A; B")
end)

TS:Register("MCB.helper: IsChanneling -> [channeling]", CATEGORY, function(self)
    expectBake(self, 'GRIPEMS.IsChanneling() and "A" or "B"', "[channeling] A; B")
end)

TS:Register("MCB.helper: KnowsSpell -> [known:Fireball]", CATEGORY, function(self)
    expectBake(self, 'GRIPEMS.KnowsSpell("Fireball") and "A" or "B"', "[known:Fireball] A; B")
end)

TS:Register("MCB.helper: IsMounted -> [mounted]", CATEGORY, function(self)
    expectBake(self, 'GRIPEMS.IsMounted() and "A" or "B"', "[mounted] A; B")
end)

TS:Register("MCB.helper: IsIndoors -> [indoors]", CATEGORY, function(self)
    expectBake(self, 'GRIPEMS.IsIndoors() and "A" or "B"', "[indoors] A; B")
end)

TS:Register("MCB.helper: IsOutdoors -> [outdoors]", CATEGORY, function(self)
    expectBake(self, 'GRIPEMS.IsOutdoors() and "A" or "B"', "[outdoors] A; B")
end)

TS:Register("MCB.helper: IsSwimming -> [swimming]", CATEGORY, function(self)
    expectBake(self, 'GRIPEMS.IsSwimming() and "A" or "B"', "[swimming] A; B")
end)

TS:Register("MCB.helper: UnitHasVehicleUI -> [unithasvehicleui]", CATEGORY, function(self)
    expectBake(self, 'GRIPEMS.UnitHasVehicleUI() and "A" or "B"', "[unithasvehicleui] A; B")
end)

TS:Register("MCB.helper: InPossessBar -> [possessbar]", CATEGORY, function(self)
    expectBake(self, 'GRIPEMS.InPossessBar() and "A" or "B"', "[possessbar] A; B")
end)

TS:Register("MCB.helper: InOverrideBar -> [overridebar]", CATEGORY, function(self)
    expectBake(self, 'GRIPEMS.InOverrideBar() and "A" or "B"', "[overridebar] A; B")
end)

-- ===========================================================================
-- GROUP 2 -- Per-shape positive (5 fixtures)
-- ===========================================================================

TS:Register("MCB.shape T1: simple ternary", CATEGORY, function(self)
    expectBake(self, 'GRIPEMS.InCombat() and "X" or "Y"', "[combat] X; Y")
end)

TS:Register("MCB.shape T2: nested ternary", CATEGORY, function(self)
    expectBake(self, 'GRIPEMS.InCombat() and "X" or GRIPEMS.InParty() and "Y" or "Z"', "[combat] X; [party] Y; Z")
end)

TS:Register("MCB.shape I1: if-elseif-else", CATEGORY, function(self)
    expectBake(
        self,
        "if GRIPEMS.InCombat() then return " .. '"X" elseif GRIPEMS.InParty() then return "Y" else return "Z" end',
        "[combat] X; [party] Y; Z"
    )
end)

TS:Register("MCB.shape I2: negated helper", CATEGORY, function(self)
    expectBake(self, 'not GRIPEMS.InCombat() and "X" or "Y"', "[nocombat] X; Y")
end)

TS:Register("MCB.shape L1: local-then-return", CATEGORY, function(self)
    expectBake(self, 'function() local r = GRIPEMS.InCombat() and "X" or "Y"; return r end', "[combat] X; Y")
end)

-- ===========================================================================
-- GROUP 3 -- Compound positive (16 fixtures: 6 AND-merge, 6 OR-chain, 4 mixed)
-- ===========================================================================

-- 6 AND-merge (single bracket, comma-separated)
TS:Register("MCB.and-merge: combat + mod:shift", CATEGORY, function(self)
    expectBake(self, 'GRIPEMS.InCombat() and GRIPEMS.HasMod("shift") and "X" or "Y"', "[combat,mod:shift] X; Y")
end)

TS:Register("MCB.and-merge: party + raid", CATEGORY, function(self)
    expectBake(self, 'GRIPEMS.InParty() and GRIPEMS.InRaid() and "X" or "Y"', "[party,raid] X; Y")
end)

TS:Register("MCB.and-merge: combat + stealth", CATEGORY, function(self)
    expectBake(self, 'GRIPEMS.InCombat() and GRIPEMS.IsStealthed() and "X" or "Y"', "[combat,stealth] X; Y")
end)

TS:Register("MCB.and-merge: mod:ctrl + mod:shift", CATEGORY, function(self)
    expectBake(self, 'GRIPEMS.HasMod("ctrl") and GRIPEMS.HasMod("shift") and "X" or "Y"', "[mod:ctrl,mod:shift] X; Y")
end)

TS:Register("MCB.and-merge: three helpers", CATEGORY, function(self)
    expectBake(
        self,
        'GRIPEMS.InCombat() and GRIPEMS.HasMod("alt") and GRIPEMS.IsMounted() and "X" or "Y"',
        "[combat,mod:alt,mounted] X; Y"
    )
end)

TS:Register("MCB.and-merge: spec:1 + combat", CATEGORY, function(self)
    expectBake(self, 'GRIPEMS.InSpec(1) and GRIPEMS.InCombat() and "X" or "Y"', "[spec:1,combat] X; Y")
end)

-- 6 OR-chain (multiple brackets, separated by "; ")
TS:Register("MCB.or-chain: combat / party", CATEGORY, function(self)
    expectBake(self, 'GRIPEMS.InCombat() and "A" or GRIPEMS.InParty() and "B" or "C"', "[combat] A; [party] B; C")
end)

TS:Register("MCB.or-chain: mounted / swimming", CATEGORY, function(self)
    expectBake(
        self,
        'GRIPEMS.IsMounted() and "A" or GRIPEMS.IsSwimming() and "B" or "C"',
        "[mounted] A; [swimming] B; C"
    )
end)

TS:Register("MCB.or-chain: mod:shift / mod:ctrl", CATEGORY, function(self)
    expectBake(
        self,
        'GRIPEMS.HasMod("shift") and "A" or GRIPEMS.HasMod("ctrl") and "B" or "C"',
        "[mod:shift] A; [mod:ctrl] B; C"
    )
end)

TS:Register("MCB.or-chain: stance:1 / stance:2", CATEGORY, function(self)
    expectBake(
        self,
        'GRIPEMS.InStance(1) and "A" or GRIPEMS.InStance(2) and "B" or "C"',
        "[stance:1] A; [stance:2] B; C"
    )
end)

TS:Register("MCB.or-chain: combat / stealth", CATEGORY, function(self)
    expectBake(self, 'GRIPEMS.InCombat() and "A" or GRIPEMS.IsStealthed() and "B" or "C"', "[combat] A; [stealth] B; C")
end)

TS:Register("MCB.or-chain: help / harm", CATEGORY, function(self)
    expectBake(self, 'GRIPEMS.IsHelp() and "A" or GRIPEMS.IsHarm() and "B" or "C"', "[help] A; [harm] B; C")
end)

-- 4 mixed AND+OR (nested compound)
TS:Register("MCB.mixed: (combat,mod:shift) / party", CATEGORY, function(self)
    expectBake(
        self,
        'GRIPEMS.InCombat() and GRIPEMS.HasMod("shift") and "A" or GRIPEMS.InParty() and "B" or "C"',
        "[combat,mod:shift] A; [party] B; C"
    )
end)

TS:Register("MCB.mixed: combat / (party,raid)", CATEGORY, function(self)
    expectBake(
        self,
        'GRIPEMS.InCombat() and "A" or GRIPEMS.InParty() and GRIPEMS.InRaid() and "B" or "C"',
        "[combat] A; [party,raid] B; C"
    )
end)

TS:Register("MCB.mixed: (mounted,outdoors) / swimming", CATEGORY, function(self)
    expectBake(
        self,
        'GRIPEMS.IsMounted() and GRIPEMS.IsOutdoors() and "A" or GRIPEMS.IsSwimming() and "B" or "C"',
        "[mounted,outdoors] A; [swimming] B; C"
    )
end)

TS:Register("MCB.mixed: (spec:1,combat) / spec:2", CATEGORY, function(self)
    expectBake(
        self,
        'GRIPEMS.InSpec(1) and GRIPEMS.InCombat() and "A" or GRIPEMS.InSpec(2) and "B" or "C"',
        "[spec:1,combat] A; [spec:2] B; C"
    )
end)

-- ===========================================================================
-- GROUP 4 -- Negation (6 fixtures: 4 simple not, 2 DeMorgan compound)
-- ===========================================================================

TS:Register("MCB.neg: not InCombat (0-arg)", CATEGORY, function(self)
    expectBake(self, 'not GRIPEMS.InCombat() and "X" or "Y"', "[nocombat] X; Y")
end)

TS:Register("MCB.neg: not InStance(1) (integer)", CATEGORY, function(self)
    expectBake(self, 'not GRIPEMS.InStance(1) and "X" or "Y"', "[nostance:1] X; Y")
end)

TS:Register("MCB.neg: not IsDead(target) (unit)", CATEGORY, function(self)
    expectBake(self, 'not GRIPEMS.IsDead("target") and "X" or "Y"', "[nodead,@target] X; Y")
end)

TS:Register("MCB.neg: not HasMod(shift) (modkey)", CATEGORY, function(self)
    expectBake(self, 'not GRIPEMS.HasMod("shift") and "X" or "Y"', "[nomod:shift] X; Y")
end)

TS:Register("MCB.neg: DeMorgan not (combat and mod:shift)", CATEGORY, function(self)
    expectBake(
        self,
        'not (GRIPEMS.InCombat() and GRIPEMS.HasMod("shift")) and "X" or "Y"',
        "[nocombat] X; [nomod:shift] X; Y"
    )
end)

TS:Register("MCB.neg: DeMorgan not (party and raid)", CATEGORY, function(self)
    expectBake(self, 'not (GRIPEMS.InParty() and GRIPEMS.InRaid()) and "X" or "Y"', "[noparty] X; [noraid] X; Y")
end)

-- ===========================================================================
-- GROUP 5 -- Rejection (12 fixtures, each asserts MCB:Bake returns nil)
-- ===========================================================================

TS:Register("MCB.reject: loop construct", CATEGORY, function(self)
    expectReject(self, 'for i = 1, 3 do return "X" end')
end)

TS:Register("MCB.reject: table literal", CATEGORY, function(self)
    expectReject(self, '{ "X" }')
end)

TS:Register("MCB.reject: method call", CATEGORY, function(self)
    expectReject(self, 'foo:bar() and "X" or "Y"')
end)

TS:Register("MCB.reject: unknown helper", CATEGORY, function(self)
    expectReject(self, 'GRIPEMS.NotARealHelper() and "X" or "Y"')
end)

TS:Register("MCB.reject: non-literal helper arg", CATEGORY, function(self)
    expectReject(self, 'GRIPEMS.HasMod(SOME_GLOBAL) and "X" or "Y"')
end)

TS:Register("MCB.reject: mixed bakeable + non-bakeable", CATEGORY, function(self)
    expectReject(self, 'GRIPEMS.InCombat() and GRIPEMS.HasBuff(12345) and "X" or "Y"')
end)

TS:Register("MCB.reject: nested ~varname~ in value", CATEGORY, function(self)
    expectReject(self, 'GRIPEMS.InCombat() and "~innerVar~" or "Y"')
end)

TS:Register("MCB.reject: depth-cap exceeded (4 OR branches)", CATEGORY, function(self)
    expectReject(
        self,
        'GRIPEMS.InCombat() and "1" or GRIPEMS.InParty() and "2" '
            .. 'or GRIPEMS.InRaid() and "3" or GRIPEMS.InGroup() and "4" or "5"'
    )
end)

TS:Register("MCB.reject: DeMorgan combinatorial cap exceeded", CATEGORY, function(self)
    expectReject(
        self,
        "not (GRIPEMS.InParty() and GRIPEMS.InRaid() and GRIPEMS.InGroup() "
            .. "and GRIPEMS.IsMounted() and GRIPEMS.IsStealthed() and GRIPEMS.IsIndoors() "
            .. 'and GRIPEMS.IsOutdoors() and GRIPEMS.IsSwimming() and GRIPEMS.InCombat()) and "X" or "Y"'
    )
end)

TS:Register("MCB.reject: empty .funct", CATEGORY, function(self)
    expectReject(self, "")
end)

TS:Register("MCB.reject: disabled variable", CATEGORY, function(self)
    expectRejectVarDef(self, { funct = 'GRIPEMS.InCombat() and "X" or "Y"', disabled = true })
end)

TS:Register("MCB.reject: deleted variable (nil varDef)", CATEGORY, function(self)
    expectRejectVarDef(self, nil)
end)

-- ===========================================================================
-- GROUP 6 -- Integration (3 fixtures, full CompileSteps bake/runtime/reject mix)
-- ===========================================================================

-- Build temp variables, compile a step list, clean up, THEN assert (so the
-- store is always restored even if an assertion fails).
local function runIntegration(self, varDefs, steps, expectations)
    local Engine = GRIPEMS.Engine
    local VS = GRIPEMS.VariableStore
    local MCB = GRIPEMS.MacroConditionalBaker
    if not (Engine and VS and MCB) then
        self:Skip("Engine / VariableStore / MCB not loaded")
        return
    end
    for name, def in pairs(varDefs) do
        VS:Set(name, def)
    end
    local compiled = Engine:CompileSteps(steps, "", "")
    for name in pairs(varDefs) do
        VS:Delete(name)
    end
    for i, expected in ipairs(expectations) do
        local entry = compiled[i]
        local actual = entry and entry.macrotext or nil
        if actual ~= expected then
            self:Fail("step " .. i .. ": expected '" .. tostring(expected) .. "', got '" .. tostring(actual) .. "'")
            return
        end
    end
    self:Pass()
end

TS:Register("MCB.integration: bake + runtime + reject mix", CATEGORY, function(self)
    runIntegration(self, {
        MCBSpecBake = { funct = 'GRIPEMS.InCombat() and "Fireball" or "Frostbolt"' },
        MCBSpecRun = { funct = 'GRIPEMS.HasBuff(999999) and "Buffed" or "Unbuffed"' },
        MCBSpecRej = { funct = '"Fire" .. "ball"' },
    }, {
        "~MCBSpecBake~",
        "~MCBSpecRun~",
        "~MCBSpecRej~",
    }, {
        "[combat] Fireball; Frostbolt",
        "Unbuffed",
        "Fireball",
    })
end)

TS:Register("MCB.integration: negated bake + bare-string runtime", CATEGORY, function(self)
    runIntegration(self, {
        MCBSpecNeg = { funct = 'not GRIPEMS.IsMounted() and "Sprint" or "Mount"' },
        MCBSpecPlain = { funct = '"Healing Potion"' },
        MCBSpecBuff = { funct = 'GRIPEMS.HasBuff(999999) and "X" or "Steady Shot"' },
    }, {
        "~MCBSpecNeg~",
        "~MCBSpecPlain~",
        "~MCBSpecBuff~",
    }, {
        "[nomounted] Sprint; Mount",
        "Healing Potion",
        "Steady Shot",
    })
end)

TS:Register("MCB.integration: compound bake + two runtime", CATEGORY, function(self)
    runIntegration(self, {
        MCBSpecCmp = { funct = 'GRIPEMS.InCombat() and "A" or GRIPEMS.InParty() and "B" or "C"' },
        MCBSpecStr = { funct = '"Arcane Intellect"' },
        MCBSpecHb = { funct = 'GRIPEMS.HasBuff(999999) and "Yes" or "No"' },
    }, {
        "~MCBSpecCmp~",
        "~MCBSpecStr~",
        "~MCBSpecHb~",
    }, {
        "[combat] A; [party] B; C",
        "Arcane Intellect",
        "No",
    })
end)

-- ===========================================================================
-- GROUP 7 -- Performance smoke (1 fixture)
-- ===========================================================================

-- 50 unique bakeable variables, 100 compiles of a 50-step list. Uses
-- debugprofilestop (millisecond high-res) because GetTime() is frame-locked
-- and cannot measure sub-frame durations. Threshold is permissive: a cold
-- bake fills the cache on the first compile, the remaining 99 are O(1) hits.
TS:Register("MCB.perf: 50-step x100 compile under 100ms", CATEGORY, function(self)
    local Engine = GRIPEMS.Engine
    local VS = GRIPEMS.VariableStore
    local MCB = GRIPEMS.MacroConditionalBaker
    if not (Engine and VS and MCB) then
        self:Skip("Engine / VariableStore / MCB not loaded")
        return
    end
    local names = {}
    local steps = {}
    for i = 1, 50 do
        local nm = "MCBSpecPerf" .. i
        names[i] = nm
        VS:Set(nm, { funct = 'GRIPEMS.InCombat() and "Fireball" or "Frostbolt"' })
        steps[i] = "~" .. nm .. "~"
    end
    local t0 = debugprofilestop()
    for _ = 1, 100 do
        Engine:CompileSteps(steps, "", "")
    end
    local elapsed = debugprofilestop() - t0
    for _, nm in ipairs(names) do
        VS:Delete(nm)
    end
    if elapsed < 100 then
        self:Pass()
    else
        self:Fail(string.format("compile took %.1fms (>= 100ms)", elapsed))
    end
end)

-- end of Test/macro_conditional_baker_spec.lua
