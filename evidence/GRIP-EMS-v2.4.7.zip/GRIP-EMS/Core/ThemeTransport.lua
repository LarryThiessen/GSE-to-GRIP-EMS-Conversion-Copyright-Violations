-- GRIP-EMS: Theming chat-link transport (Phase D)
--
-- Created:    2026-04-23
-- Updated:    2026-08-17
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
--
-- Transport B for the Per-Element Theming editor. Inserts a clickable
-- "garrmission:emsTheme:..." hyperlink into the active chat edit box.
-- Receivers with EMS installed click the link and are offered a preview
-- modal that routes Apply back to TE.ImportString. Payload travels over
-- an AceComm channel ("EMS_THEME_1") via chunked WHISPER messages.
--
-- Design reference: Research/Access/ThemingEditor_Design_2026-04-22.md
-- sections 7.2 through 7.5 and 18.2 (forgery mitigation).

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

GRIPEMS.ThemeTransport = GRIPEMS.ThemeTransport or {}
local TT = GRIPEMS.ThemeTransport

-- AceComm prefix length limit is 16 chars. "EMS_THEME_1" = 11 chars.
-- Future schema bumps increment the suffix ("EMS_THEME_2" etc.) so
-- older receivers reject unknown versions.
local COMM_PREFIX = "EMS_THEME_1"
local LINK_HEAD = "garrmission:emsTheme:"
local EXPORT_PREFIX = "GEMSTHEME1"
local EXPORT_VERSION = 1
local CHUNK_BYTES = 4000
local MAX_PAYLOAD = 16 * 1024
local MAX_CHUNK_COUNT = math.ceil(MAX_PAYLOAD / CHUNK_BYTES) + 2
local SEND_TTL = 120
local REQUEST_TIMEOUT = 3

-- uuid -> { slot, payload, expires }
local pendingSends = {}
-- uuid -> { sender, total, received, chunks, expires }
local pendingReceives = {}
-- uuid -> { sender, expires }  (we clicked a link, waiting on chunks)
local pendingRequests = {}

-- Sliding-window rate limit on outgoing REQUEST whispers.
-- Keyed on canonical sender name. Each entry is a list of
-- timestamps within REQUEST_RATE_WINDOW seconds.
-- See Backlog THEME-LINK-HANDSHAKE.
local REQUEST_RATE_LIMIT = 3
local REQUEST_RATE_WINDOW = 60
local requestRateLimit = {}

-- Separate AceComm embed target keeps our OnCommReceived independent of
-- Engine/Transmission.lua (which already embeds AceComm into GRIPEMS and
-- owns the "GRIPEMS" sequence-share prefix). Registering on its own table
-- avoids overwriting that handler.
local commHost = {}

---------------------------------------------------------------------------
-- Small utilities
---------------------------------------------------------------------------
local function nowSeconds()
    return GetTime and GetTime() or (time and time()) or 0
end

local function randomUUID()
    local chars = "0123456789abcdef"
    local out = {}
    for i = 1, 8 do
        local n = math.random(1, 16)
        out[i] = chars:sub(n, n)
    end
    return table.concat(out)
end

local function profileTheming()
    local S = GRIPEMS.Settings
    if not (S and S.db and S.db.profile) then
        return nil
    end
    S.db.profile.theming = S.db.profile.theming or { preset = "default", elements = {}, savedThemes = {} }
    S.db.profile.theming.elements = S.db.profile.theming.elements or {}
    S.db.profile.theming.savedThemes = S.db.profile.theming.savedThemes or {}
    return S.db.profile.theming
end

local function slotLabel(i)
    local t = profileTheming()
    local snap = t and t.savedThemes and t.savedThemes[i]
    if snap and type(snap.name) == "string" and snap.name ~= "" then
        return snap.name
    end
    return string.format(L["ACCESS_THEMING_SLOT_DEFAULT_NAME"] or "Theme %d", i)
end

local function libs()
    local ser = LibStub and LibStub("AceSerializer-3.0", true)
    local defl = LibStub and LibStub("LibDeflate", true)
    return ser, defl
end

local function playerFullName()
    if GetUnitName then
        local name = GetUnitName("player", true)
        if type(name) == "string" and name ~= "" then
            return name
        end
    end
    local n = UnitName and UnitName("player")
    local r = GetRealmName and GetRealmName() or ""
    if type(r) == "string" then
        r = r:gsub("[%s'-]", "")
    end
    if n and r ~= "" then
        return n .. "-" .. r
    end
    return n or "Unknown"
end

-- Returns true if a REQUEST whisper to senderName is allowed
-- under the sliding-window cap. Prunes expired timestamps and
-- appends "now" on success. Silent on rate-limit hit; caller
-- decides whether to toast.
local function tryRequestRate(senderName)
    if type(senderName) ~= "string" or senderName == "" then
        return false
    end
    local now = nowSeconds()
    local cutoff = now - REQUEST_RATE_WINDOW
    local stamps = requestRateLimit[senderName]
    if not stamps then
        stamps = {}
        requestRateLimit[senderName] = stamps
    end
    local kept = {}
    for i = 1, #stamps do
        if stamps[i] >= cutoff then
            kept[#kept + 1] = stamps[i]
        end
    end
    if #kept >= REQUEST_RATE_LIMIT then
        requestRateLimit[senderName] = kept
        return false
    end
    kept[#kept + 1] = now
    requestRateLimit[senderName] = kept
    return true
end

-- Realm allowlist for incoming theme-link clicks. The sender field in a
-- garrmission:emsTheme: link is fully attacker-controllable, so we must
-- reject any sender that does not resolve to our own realm or one of the
-- connected realms reported by C_AutoComplete.GetAutoCompleteRealms. A forged
-- cross-realm sender would otherwise cause our client to whisper an
-- arbitrary character on an unrelated realm.
local function isSenderRealmAllowed(senderName)
    if type(senderName) ~= "string" or senderName == "" then
        return false
    end
    local _, senderRealm = senderName:match("^(.-)-(.+)$")
    if not senderRealm or senderRealm == "" then
        -- No realm in sender = same realm by convention.
        return true
    end
    local myRealm = GetRealmName and GetRealmName() or ""
    if type(myRealm) == "string" then
        myRealm = myRealm:gsub("[%s'-]", "")
    end
    if senderRealm == myRealm then
        return true
    end
    -- 12.1 moved this global into the C_AutoComplete namespace. The namespaced
    -- form also exists on 12.0.x, so prefer it and keep the bare global as a
    -- fallback for anyone still on an older client.
    local getRealms = (C_AutoComplete and C_AutoComplete.GetAutoCompleteRealms) or GetAutoCompleteRealms
    if getRealms then
        local connected = getRealms()
        if type(connected) == "table" then
            for i = 1, #connected do
                if connected[i] == senderRealm then
                    return true
                end
            end
        end
    end
    return false
end

local function printToast(msg)
    if GRIPEMS and GRIPEMS.Print then
        GRIPEMS:Print("|cFFFFAA33" .. tostring(msg) .. "|r")
    end
end

---------------------------------------------------------------------------
-- Pending-table housekeeping: cheap expiry sweep run at every send and
-- receive tick. Prevents unbounded growth if a link is never clicked.
---------------------------------------------------------------------------
local function pruneExpired()
    local now = nowSeconds()
    for uuid, rec in pairs(pendingSends) do
        if rec.expires and rec.expires < now then
            pendingSends[uuid] = nil
        end
    end
    for uuid, rec in pairs(pendingReceives) do
        if rec.expires and rec.expires < now then
            pendingReceives[uuid] = nil
        end
    end
    for uuid, rec in pairs(pendingRequests) do
        if rec.expires and rec.expires < now then
            pendingRequests[uuid] = nil
        end
    end
end

---------------------------------------------------------------------------
-- Export a slot snapshot (or the current profile's elements if the slot
-- is empty) into the GEMSTHEME1-prefixed print-safe string used by
-- TE.ImportString. Reused by BuildLink and by the REQUEST reply path.
---------------------------------------------------------------------------
local function exportSlotPayload(slot)
    local ser, defl = libs()
    if not (ser and defl) then
        return nil, "missing libs"
    end
    local t = profileTheming()
    if not t then
        return nil, "no profile"
    end
    local snap = t.savedThemes and t.savedThemes[slot]
    local elements, preset
    if snap and snap.elements then
        elements = snap.elements
        preset = snap.preset or t.preset or "default"
    else
        elements = t.elements or {}
        preset = t.preset or "default"
    end
    local GE = GRIPEMS.GRIPExport
    local exportedBy = GE and GE.BuildExportedBy and GE.BuildExportedBy(nil) or nil
    local spec = {
        version = EXPORT_VERSION,
        preset = preset,
        elements = elements,
        -- v2.3.3 Phase 1: parser metadata. Theme.ValidateSpec ignores unknown
        -- top-level keys, so older clients import these strings unchanged.
        name = slotLabel(slot),
        addonVersion = GRIPEMS.version,
        exportedAt = time(),
        wowInterface = GetBuildInfo and select(4, GetBuildInfo()) or nil,
        author = exportedBy and exportedBy.name or nil,
    }
    local ok, raw = pcall(function()
        return ser:Serialize(spec)
    end)
    if not ok or type(raw) ~= "string" then
        return nil, "serialize failed"
    end
    local encoded = defl:EncodeForPrint(defl:CompressDeflate(raw, { level = 9 }))
    if type(encoded) ~= "string" then
        return nil, "encode failed"
    end
    return EXPORT_PREFIX .. ":" .. encoded, nil
end

---------------------------------------------------------------------------
-- Pre-validate an incoming GEMSTHEME1 string against the 16 KB
-- post-decompress hard cap and Theme.ValidateSpec. Returns (ok, spec|err).
---------------------------------------------------------------------------
local function decodeAndValidate(fullText)
    if type(fullText) ~= "string" or fullText == "" then
        return false, "empty"
    end
    local ser, defl = libs()
    if not (ser and defl) then
        return false, "missing libs"
    end
    local body = fullText
    local colon = fullText:find(":")
    if colon and fullText:sub(1, colon - 1) == EXPORT_PREFIX then
        body = fullText:sub(colon + 1)
    end
    local decoded = defl:DecodeForPrint(body)
    if not decoded then
        return false, "decode failed"
    end
    local raw = defl:DecompressDeflate(decoded)
    if not raw then
        return false, "inflate failed"
    end
    if #raw > MAX_PAYLOAD then
        return false, "payload too large"
    end
    local ok, spec = ser:Deserialize(raw)
    if not ok or type(spec) ~= "table" then
        return false, "deserialize failed"
    end
    if GRIPEMS.Theme and GRIPEMS.Theme.ValidateSpec then
        local valid, err = GRIPEMS.Theme.ValidateSpec(spec)
        if not valid then
            return false, err or "invalid spec"
        end
    end
    return true, spec
end

---------------------------------------------------------------------------
-- Confirmation dialog: registered once on Init. Pops on payload receive.
---------------------------------------------------------------------------
local function registerAcceptDialog()
    if GRIPEMS.Popup:GetDef("GRIP_EMS_THEME_ACCEPT") then
        return
    end
    GRIPEMS.Popup:Define("GRIP_EMS_THEME_ACCEPT", {
        text = L["ACCESS_THEMING_CHATLINK_RECEIVE_PROMPT"] or "Accept theme from %s?",
        button1 = YES or "Yes",
        button2 = NO or "No",
        OnAccept = function(self, data)
            if not data or type(data.payload) ~= "string" then
                return
            end
            local TE = GRIPEMS.UI and GRIPEMS.UI.ThemingEditor
            if TE and TE.ImportString then
                local ok, err = TE.ImportString(data.payload)
                if not ok then
                    printToast((L["ACCESS_THEMING_IMPORT_FAIL"] or "Import failed") .. ": " .. tostring(err or ""))
                end
            end
        end,
        timeout = 0,
        hideOnEscape = true,
    })
end

---------------------------------------------------------------------------
-- Wire-format helpers. Each envelope is AceSerializer-encoded; AceComm
-- handles transport framing (which itself auto-chunks above ~250 bytes).
-- We still chunk at application level so no single envelope exceeds the
-- ChatThrottleLib soft limit (~4000 bytes).
---------------------------------------------------------------------------
local function encodeEnvelope(env)
    local ser = libs()
    if not ser then
        return nil
    end
    local ok, out = pcall(function()
        return ser:Serialize(env)
    end)
    if ok and type(out) == "string" then
        return out
    end
    return nil
end

local function decodeEnvelope(msg)
    local ser = libs()
    if not ser then
        return nil
    end
    local ok, env = ser:Deserialize(msg)
    if ok and type(env) == "table" then
        return env
    end
    return nil
end

local function sendEnvelope(env, target)
    local msg = encodeEnvelope(env)
    if not msg then
        return false
    end
    if not (commHost and commHost.SendCommMessage) then
        return false
    end
    commHost:SendCommMessage(COMM_PREFIX, msg, "WHISPER", target, "NORMAL")
    return true
end

---------------------------------------------------------------------------
-- Split a fully-encoded payload string into CHUNK envelopes keyed by
-- uuid, then send a closing END envelope. Receiver assembles on END.
---------------------------------------------------------------------------
local function dispatchPayload(uuid, target, fullText)
    local length = #fullText
    local total = math.max(1, math.ceil(length / CHUNK_BYTES))
    for seq = 1, total do
        local lo = (seq - 1) * CHUNK_BYTES + 1
        local hi = math.min(seq * CHUNK_BYTES, length)
        local data = fullText:sub(lo, hi)
        local okSend = sendEnvelope({
            kind = "CHUNK",
            uuid = uuid,
            seq = seq,
            total = total,
            data = data,
        }, target)
        if not okSend then
            return false
        end
    end
    sendEnvelope({ kind = "END", uuid = uuid, total = total }, target)
    return true
end

---------------------------------------------------------------------------
-- Public API
---------------------------------------------------------------------------

--- Build a chat-link string for a saved slot. Stores the outgoing payload
--- keyed by a fresh UUID so the click roundtrip resolves back to the
--- correct slot on this character. Returns the formatted link or nil+err.
function TT:BuildLink(slot)
    pruneExpired()
    slot = tonumber(slot) or 1
    local payload, err = exportSlotPayload(slot)
    if not payload then
        return nil, err
    end
    local uuid = randomUUID()
    pendingSends[uuid] = {
        slot = slot,
        payload = payload,
        expires = nowSeconds() + SEND_TTL,
    }
    local sender = playerFullName()
    local label = slotLabel(slot)
    -- Format: garrmission:emsTheme:<sender>:<uuid>
    -- Sender is embedded so the receiver's click knows which character to
    -- whisper for the payload. string.sub(link, 1, 21) == "garrmission:emsTheme:"
    -- still matches the head in the SetItemRef hook.
    local link = string.format("|cff00aaff|H%s%s:%s|h[%s: %s]|h|r", LINK_HEAD, sender, uuid, "EMS Theme", label)
    return link, nil
end

--- Insert a built link into the active chat edit box. Returns true on
--- successful insert, false otherwise so the caller can toast a hint.
--- Refuses (with toast) while in combat lockdown.
function TT:InsertLink(slot)
    if InCombatLockdown and InCombatLockdown() then
        printToast(L["ACCESS_THEMING_MODAL_COMBAT_BLOCKED"] or "Theme editor is hidden during combat.")
        return false
    end
    local link, err = self:BuildLink(slot)
    if not link then
        printToast((L["ACCESS_THEMING_IMPORT_FAIL"] or "Export failed") .. ": " .. tostring(err or ""))
        return false
    end
    local edit = ChatEdit_GetActiveWindow and ChatEdit_GetActiveWindow() or nil
    if not edit then
        return false
    end
    if ChatEdit_InsertLink then
        local ok = ChatEdit_InsertLink(link)
        if ok == nil then
            -- Older returns are boolean; treat any non-false as success.
            return true
        end
        return ok and true or false
    end
    -- Fallback: raw append to the edit box text.
    local cur = edit:GetText() or ""
    edit:SetText(cur .. link)
    return true
end

--- SetItemRef callback. Parses "garrmission:emsTheme:<sender>:<uuid>" and
--- routes the click to either a local-sender preview or a REQUEST to the
--- remote sender. chatFrame is unused today but kept on the signature to
--- match the design doc's public surface.
function TT:HandleLinkClick(linkArg, chatFrame)
    if type(linkArg) ~= "string" then
        return
    end
    local _ = chatFrame
    local tail = linkArg:match("^garrmission:emsTheme:(.+)$")
    if not tail then
        return
    end
    local sender, uuid = tail:match("^([^:]+):(.+)$")
    if not sender or not uuid then
        -- Older links (no embedded sender) still land here but cannot
        -- be routed. Treat as malformed.
        return
    end
    -- Realm allowlist gate: reject before any state mutation. The sender
    -- field is attacker-controllable, so a forged cross-realm sender
    -- would otherwise cause our client to whisper an arbitrary player
    -- on an unconnected realm.
    if not isSenderRealmAllowed(sender) then
        printToast(
            L["ACCESS_THEMING_CHATLINK_REALM_BLOCK"] or "EMS: theme link from an unconnected realm. Click ignored."
        )
        return
    end
    pruneExpired()

    -- Case 1: we sent this link; resolve locally (no-op preview today).
    if pendingSends[uuid] then
        printToast(
            L["ACCESS_THEMING_CHATLINK_OWN_LINK"]
                or "That is your own theme link. Share it with another player to send."
        )
        return
    end

    -- Case 2: we clicked a remote link; ask the sender for the payload.
    local me = playerFullName()
    if sender == me then
        -- Own link but the pending record expired -- surface nothing.
        return
    end
    pendingRequests[uuid] = {
        sender = sender,
        expires = nowSeconds() + REQUEST_TIMEOUT + 1,
    }
    if not tryRequestRate(sender) then
        printToast(
            L["ACCESS_THEMING_CHATLINK_RATE_LIMIT"]
                or "EMS: too many recent theme requests to that player. Try again in a moment."
        )
        pendingRequests[uuid] = nil
        return
    end
    local okSend = sendEnvelope({ kind = "REQUEST", uuid = uuid }, sender)
    if not okSend then
        printToast(string.format(L["ACCESS_THEMING_CHATLINK_NO_RECEIVER"] or "%s does not have EMS installed.", sender))
        pendingRequests[uuid] = nil
        return
    end
    -- Arm a timeout: if no chunks arrive, assume the sender does not have
    -- EMS installed (or dropped the request) and surface a friendly toast.
    if C_Timer and C_Timer.After then
        C_Timer.After(REQUEST_TIMEOUT, function()
            local rec = pendingRequests[uuid]
            if rec and not pendingReceives[uuid] then
                pendingRequests[uuid] = nil
                printToast(
                    string.format(L["ACCESS_THEMING_CHATLINK_NO_RECEIVER"] or "%s does not have EMS installed.", sender)
                )
            end
        end)
    end
end

---------------------------------------------------------------------------
-- AceComm receive dispatch. prefix is already pre-filtered to COMM_PREFIX
-- by AceComm; message is one of our AceSerializer envelopes.
---------------------------------------------------------------------------
function TT:OnCommReceived(prefix, message, distribution, sender)
    if prefix ~= COMM_PREFIX then
        -- Unknown version -> user-facing notice (only once per sender).
        if type(prefix) == "string" and prefix:sub(1, 10) == "EMS_THEME_" then
            printToast(
                L["ACCESS_THEMING_CHATLINK_VERSION_MISMATCH"]
                    or "This theme is from a newer EMS version. Update EMS and try again."
            )
        end
        return
    end
    local env = decodeEnvelope(message)
    if not env or type(env.kind) ~= "string" or type(env.uuid) ~= "string" then
        return
    end
    pruneExpired()

    if env.kind == "REQUEST" then
        local rec = pendingSends[env.uuid]
        if not rec or type(rec.payload) ~= "string" then
            return
        end
        dispatchPayload(env.uuid, sender, rec.payload)
        return
    end

    if env.kind == "CHUNK" then
        local expectedSender = pendingRequests[env.uuid] and pendingRequests[env.uuid].sender or nil
        if expectedSender and expectedSender ~= sender then
            -- Someone else is trying to inject chunks under the same UUID.
            return
        end
        -- DoS guard: cap the claimed chunk count. Legitimate transfers
        -- fit under MAX_PAYLOAD bytes which is ~5 chunks at CHUNK_BYTES.
        -- A claim above MAX_CHUNK_COUNT is either a bug or an attempted
        -- memory-exhaustion attack. Drop the receive and notify once.
        local claimedTotal = tonumber(env.total) or 0
        if claimedTotal > MAX_CHUNK_COUNT then
            pendingReceives[env.uuid] = nil
            pendingRequests[env.uuid] = nil
            printToast(
                L["ACCESS_THEMING_CHATLINK_DOS_BLOCK"] or "EMS: theme transfer rejected (chunk count exceeds limit)."
            )
            return
        end
        local state = pendingReceives[env.uuid]
        if not state then
            state = {
                sender = sender,
                total = tonumber(env.total) or 0,
                received = 0,
                chunks = {},
                expires = nowSeconds() + 30,
            }
            pendingReceives[env.uuid] = state
        end
        local seq = tonumber(env.seq)
        if seq and not state.chunks[seq] and type(env.data) == "string" then
            state.chunks[seq] = env.data
            state.received = state.received + 1
        end
        return
    end

    if env.kind == "END" then
        local expectedSender = pendingRequests[env.uuid] and pendingRequests[env.uuid].sender or nil
        if expectedSender and expectedSender ~= sender then
            return
        end
        local state = pendingReceives[env.uuid]
        if not state then
            return
        end
        pendingReceives[env.uuid] = nil
        pendingRequests[env.uuid] = nil
        local total = tonumber(env.total) or state.total or 0
        if total > MAX_CHUNK_COUNT then
            pendingReceives[env.uuid] = nil
            pendingRequests[env.uuid] = nil
            printToast(
                L["ACCESS_THEMING_CHATLINK_DOS_BLOCK"] or "EMS: theme transfer rejected (chunk count exceeds limit)."
            )
            return
        end
        local parts = {}
        for i = 1, total do
            if type(state.chunks[i]) ~= "string" then
                printToast(L["ACCESS_THEMING_CHATLINK_TIMEOUT"] or "Theme transfer timed out.")
                return
            end
            parts[i] = state.chunks[i]
        end
        local full = table.concat(parts)
        local ok, err = decodeAndValidate(full)
        if not ok then
            if GRIPEMS.Sound then
                GRIPEMS.Sound:Play("error")
            end
            printToast((L["ACCESS_THEMING_IMPORT_FAIL"] or "Import failed") .. ": " .. tostring(err or ""))
            return
        end
        registerAcceptDialog()
        local def = GRIPEMS.Popup:GetDef("GRIP_EMS_THEME_ACCEPT")
        if def then
            def.text = string.format(L["ACCESS_THEMING_CHATLINK_RECEIVE_PROMPT"] or "Accept theme from %s?", sender)
        end
        GRIPEMS.Popup:Show("GRIP_EMS_THEME_ACCEPT", sender, nil, { payload = full, sender = sender })
        if GRIPEMS.Sound then
            GRIPEMS.Sound:Play("info")
        end
        return
    end
end

---------------------------------------------------------------------------
-- Init: embed AceComm on our dedicated host table, register the prefix,
-- and pre-create the accept dialog so the first received payload has a
-- dialog waiting.
---------------------------------------------------------------------------
function TT:Init()
    if self._initialized then
        return
    end
    self._initialized = true

    local AceComm = LibStub and LibStub("AceComm-3.0", true)
    if AceComm then
        AceComm:Embed(commHost)
        function commHost:OnCommReceived(prefix, message, distribution, senderName)
            TT:OnCommReceived(prefix, message, distribution, senderName)
        end
        commHost:RegisterComm(COMM_PREFIX)
    end

    registerAcceptDialog()
end

-- end of Core/ThemeTransport.lua
