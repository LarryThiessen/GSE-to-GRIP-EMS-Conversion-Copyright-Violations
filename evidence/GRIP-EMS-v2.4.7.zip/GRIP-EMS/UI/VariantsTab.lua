-- GRIP-EMS: VariantsTab
-- Created: 2026-05-26
-- Updated: 2026-08-17
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
--
-- Per-sequence Variants subtab. Edits the recommend function (sequence-level
-- fallback + per-version override) and the per-modifier variant macrotext.
-- Gated by Settings:Get("showVariantsTab") -- the tab button is hidden when
-- the setting is off, but the content frame is always created so toggling
-- the setting back on does not require recreating UI surface.

local _, GRIPEMS = ...
local UI = GRIPEMS.UI
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

GRIPEMS.VariantsTab = {}
local VT = GRIPEMS.VariantsTab

local function D()
    return GRIPEMS.Defaults
end

-- Banned API patterns: presence in recommend source text triggers the risk
-- banner. The recommend function runs every VARIABLE_UPDATED so any of these
-- would either taint protected frames (SetAttribute on a secure frame) or
-- compete with the engine's own event registration.
local BANNED_PATTERNS = {
    "SetAttribute",
    "UseAction",
    "C_Macro",
    "RegisterStateDriver",
    "RegisterEvent",
}

local function HasBannedAPI(text)
    if type(text) ~= "string" or text == "" then
        return false
    end
    for _, pat in ipairs(BANNED_PATTERNS) do
        if text:find(pat, 1, true) then
            return true
        end
    end
    return false
end

-- Local edit-box factory. Multiline source editors use a ScrollFrame +
-- inner EditBox so long bodies scroll inside the bound height. Matches the
-- shape VariablesTab uses for its funcEdit (L470-530 of that module).
local function CreateMultiline(parent, height)
    local C = UI.Colors
    local container = CreateFrame("Frame", nil, parent, "BackdropTemplate")
    container:SetHeight(height)
    UI:ApplyBackdrop(container, UI.Backdrops.panel, C.bgInput, C.border)
    local scroll = CreateFrame("ScrollFrame", nil, container, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", container, "TOPLEFT", 4, -4)
    scroll:SetPoint("BOTTOMRIGHT", container, "BOTTOMRIGHT", -22, 4)
    UI:SkinLegacyScrollBar(scroll)
    local edit = CreateFrame("EditBox", nil, scroll)
    edit:SetMultiLine(true)
    edit:SetAutoFocus(false)
    edit:SetFont(GRIPEMS.UI:GetFontPath(), 11, "")
    edit:SetTextColor(C.textPrimary:GetRGBA())
    edit:SetWidth(180)
    edit:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
    end)
    edit:SetScript("OnEditFocusGained", function()
        container:SetBackdropBorderColor(C.borderFocus:GetRGBA())
    end)
    edit:SetScript("OnEditFocusLost", function()
        container:SetBackdropBorderColor(C.border:GetRGBA())
    end)
    scroll:SetScrollChild(edit)
    scroll:SetScript("OnSizeChanged", function(self)
        local w = self:GetWidth()
        if w > 0 then
            edit:SetWidth(w)
        end
    end)
    if GRIPEMS.Focus then
        GRIPEMS.Focus:HookEditBox(edit)
    end
    return container, edit
end

function VT:Init(parentFrame)
    if not parentFrame then
        return
    end
    VT.container = parentFrame
    local C = UI.Colors
    local frame = CreateFrame("Frame", nil, parentFrame)
    frame:SetAllPoints(parentFrame)
    frame:Hide()
    VT.frame = frame

    -- Risk-warning banner (top). Icon + text shape like the editor banners,
    -- scoped to recommend-source banned API checks. ANCHOR RULE (bug fix
    -- 2026-06-09): a hidden zero-height frame anchored TOPLEFT+TOPRIGHT has
    -- no resolvable rect, so NOTHING may anchor to this banner while it is
    -- hidden -- the whole tab rendered blank because the content chain
    -- rooted here. The chain roots on the frame at rest; UpdateRiskBanner
    -- swaps seqLabel onto/off the banner exactly like SE:UpdateSpellWarning
    -- does with versionBar in UI/SequenceEditor.lua.
    local banner = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    banner:SetHeight(0)
    banner:SetPoint("TOPLEFT", frame, "TOPLEFT", 4, -4)
    banner:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -4, -4)
    UI:ApplyBackdrop(banner, UI.Backdrops.panelNoBorder, C.bgInput)
    banner:Hide()
    local bIcon = banner:CreateTexture(nil, "ARTWORK")
    bIcon:SetSize(16, 16)
    bIcon:SetPoint("LEFT", banner, "LEFT", 4, 0)
    bIcon:SetTexture("Interface\\DialogFrame\\UI-Dialog-Icon-AlertNew")
    local bText = banner:CreateFontString(nil, "OVERLAY")
    UI:SetFont(bText, 11)
    bText:SetPoint("LEFT", bIcon, "RIGHT", 4, 0)
    bText:SetPoint("RIGHT", banner, "RIGHT", -4, 0)
    bText:SetJustifyH("LEFT")
    bText:SetTextColor(C.textWarning:GetRGBA())
    VT.riskBanner = banner
    VT.riskBannerText = bText

    -- Section 1: sequence-level recommend editor (multiline).
    local seqLabel = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(seqLabel, 10)
    seqLabel:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, -8)
    seqLabel:SetText(L["GEMS_VARIANTS_SEQ_RECOMMEND"])
    seqLabel:SetTextColor(C.textSecondary:GetRGBA())
    seqLabel:EnableMouse(true)
    seqLabel:SetScript("OnEnter", function(self)
        UI:ShowTooltip(self, L["GEMS_VARIANTS_SEQ_RECOMMEND"], L["GEMS_VARIANTS_SEQ_RECOMMEND_TT"])
    end)
    seqLabel:SetScript("OnLeave", function()
        UI:HideTooltip()
    end)
    local seqBox, seqEdit = CreateMultiline(frame, 50)
    seqBox:SetPoint("TOPLEFT", seqLabel, "BOTTOMLEFT", 0, -2)
    seqBox:SetPoint("RIGHT", frame, "RIGHT", -4, 0)
    seqEdit:SetScript("OnEditFocusLost", function(self)
        seqBox:SetBackdropBorderColor(C.border:GetRGBA())
        VT:SaveSeqRecommend(self:GetText() or "")
    end)
    VT.seqLabel = seqLabel
    VT.seqEdit = seqEdit
    VT.seqBox = seqBox

    -- Section 2: variant row container. Four rows -- plain (read-only),
    -- shift/ctrl/alt (Add/Remove + macrotext).
    local rowsHost = CreateFrame("Frame", nil, frame)
    rowsHost:SetPoint("TOPLEFT", seqBox, "BOTTOMLEFT", 0, -4)
    rowsHost:SetPoint("RIGHT", frame, "RIGHT", -4, 0)
    rowsHost:SetHeight(56)
    VT.rowsHost = rowsHost
    VT.variantRows = {}
    local rowDefs = {
        { mod = "plain", labelKey = "GEMS_VARIANTS_MOD_PLAIN_ROW", readOnly = true },
        { mod = "shift", labelKey = "GEMS_VARIANTS_MOD_SHIFT_ROW" },
        { mod = "ctrl", labelKey = "GEMS_VARIANTS_MOD_CTRL_ROW" },
        { mod = "alt", labelKey = "GEMS_VARIANTS_MOD_ALT_ROW" },
    }
    local prevRow
    for _, def in ipairs(rowDefs) do
        local row = CreateFrame("Frame", nil, rowsHost)
        row:SetHeight(14)
        row:SetPoint("LEFT", rowsHost, "LEFT", 0, 0)
        row:SetPoint("RIGHT", rowsHost, "RIGHT", 0, 0)
        if prevRow then
            row:SetPoint("TOP", prevRow, "BOTTOM", 0, 0)
        else
            row:SetPoint("TOP", rowsHost, "TOP", 0, 0)
        end
        local lbl = row:CreateFontString(nil, "OVERLAY")
        UI:SetFont(lbl, 10)
        lbl:SetPoint("LEFT", row, "LEFT", 0, 0)
        lbl:SetText(L[def.labelKey])
        lbl:SetTextColor(C.textSecondary:GetRGBA())
        row._mod = def.mod
        row._readOnly = def.readOnly
        row._label = lbl
        if not def.readOnly then
            local btn = UI:CreateButton(row, L["GEMS_VARIANTS_ADD"], 56, 14)
            btn:SetPoint("RIGHT", row, "RIGHT", 0, 0)
            btn:SetScript("OnClick", function()
                VT:ToggleVariant(def.mod)
            end)
            row._actionBtn = btn
        end
        VT.variantRows[def.mod] = row
        prevRow = row
    end

    -- Version-targeting status: names the version the rows above edit and
    -- whether it is the live one the engine runs. The /gems variants slash
    -- command and the indicator strip both target the live version; these
    -- rows target the editor-displayed version -- this label is the
    -- disambiguation (2026-06-09 smoke confusion).
    local verTarget = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(verTarget, 9)
    verTarget:SetPoint("RIGHT", VT.variantRows["plain"], "RIGHT", 0, 0)
    verTarget:SetText("")
    VT.verTargetLabel = verTarget

    -- Section 3: per-version recommend editor (multiline).
    local verLabel = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(verLabel, 10)
    verLabel:SetPoint("TOPLEFT", rowsHost, "BOTTOMLEFT", 0, -6)
    verLabel:SetText(L["GEMS_VARIANTS_VER_RECOMMEND"])
    verLabel:SetTextColor(C.textSecondary:GetRGBA())
    local verBox, verEdit = CreateMultiline(frame, 50)
    verBox:SetPoint("TOPLEFT", verLabel, "BOTTOMLEFT", 0, -2)
    verBox:SetPoint("RIGHT", frame, "RIGHT", -4, 0)
    verEdit:SetScript("OnEditFocusLost", function(self)
        verBox:SetBackdropBorderColor(C.border:GetRGBA())
        VT:SaveVerRecommend(self:GetText() or "")
    end)
    VT.verEdit = verEdit
    VT.verBox = verBox

    local verEmptyLabel = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(verEmptyLabel, 9)
    verEmptyLabel:SetPoint("LEFT", verLabel, "RIGHT", 6, 0)
    verEmptyLabel:SetText(L["GEMS_VARIANTS_VER_RECOMMEND_EMPTY"])
    verEmptyLabel:SetTextColor(C.textMuted:GetRGBA())
    verEmptyLabel:Hide()
    VT.verEmptyLabel = verEmptyLabel
end

-- Resolve the (seqData, verData, verIdx) tuple from the SequenceEditor's
-- current selection. Returns nil on any miss so callers can early-exit
-- cleanly without nil-deref churn.
local function GetSelection()
    local SE = GRIPEMS.SequenceEditor
    local Engine = GRIPEMS.Engine
    if not SE or not SE.currentSequence or not Engine then
        return nil
    end
    local entry = Engine.sequences and Engine.sequences[SE.currentSequence]
    local seqData = entry and entry.data
    if not seqData or type(seqData.versions) ~= "table" then
        return nil
    end
    local idx = SE.activeVersionIndex or seqData.defaultVersion or 1
    local verData = seqData.versions[idx]
    if not verData then
        return nil
    end
    return SE.currentSequence, seqData, verData, idx
end

function VT:Show()
    if not VT.frame then
        return
    end
    VT.frame:Show()
    VT:RefreshFromSelection()
end

function VT:Hide()
    if VT.frame then
        VT.frame:Hide()
    end
end

local function UpdateRiskBanner(text1, text2)
    if not VT.riskBanner then
        return
    end
    if HasBannedAPI(text1) or HasBannedAPI(text2) then
        VT.riskBannerText:SetText(L["GEMS_VARIANTS_UNSAFE_API_WARN"])
        VT.riskBanner:SetHeight(20)
        VT.riskBanner:Show()
        -- Banner joins the anchor chain only while shown with a real height
        -- (SE:UpdateSpellWarning / versionBar pattern).
        if VT.seqLabel then
            VT.seqLabel:ClearAllPoints()
            VT.seqLabel:SetPoint("TOPLEFT", VT.riskBanner, "BOTTOMLEFT", 4, -4)
        end
    else
        VT.riskBanner:SetHeight(0)
        VT.riskBanner:Hide()
        -- Rest state: root the chain on the frame. A hidden zero-height
        -- banner has no resolvable rect (2026-06-09 blank-tab root cause).
        if VT.seqLabel then
            VT.seqLabel:ClearAllPoints()
            VT.seqLabel:SetPoint("TOPLEFT", VT.frame, "TOPLEFT", 8, -8)
        end
    end
end

local function UpdateVariantRows(verData)
    local overrides = verData.variantOverrides or {}
    local hasMod = { plain = true } -- base is implicit
    for _, ov in ipairs(overrides) do
        if type(ov) == "table" and ov.modifier then
            hasMod[ov.modifier] = true
        end
    end
    for mod, row in pairs(VT.variantRows) do
        if row._actionBtn then
            local exists = hasMod[mod] or false
            row._actionBtn:SetText(exists and L["GEMS_VARIANTS_REMOVE"] or L["GEMS_VARIANTS_ADD"])
        end
    end
end

function VT:RefreshFromSelection()
    if not VT.frame or not VT.frame:IsShown() then
        return
    end
    local _, seqData, verData, verIdx = GetSelection()
    if not seqData or not verData then
        if VT.seqEdit then
            VT.seqEdit:SetText("")
        end
        if VT.verEdit then
            VT.verEdit:SetText("")
        end
        return
    end
    if VT.seqEdit then
        VT.seqEdit:SetText(seqData.recommendSource or "")
    end
    local verSrc = verData.recommendSource or ""
    if VT.verEdit then
        VT.verEdit:SetText(verSrc)
    end
    if VT.verEmptyLabel then
        if verSrc == "" then
            VT.verEmptyLabel:Show()
        else
            VT.verEmptyLabel:Hide()
        end
    end
    UpdateVariantRows(verData)
    if VT.verTargetLabel then
        local E = GRIPEMS.Engine
        local C = UI.Colors
        local isLive = false
        if E and E.GetActiveVersion then
            isLive = (E:GetActiveVersion(seqData) == verData)
        end
        if isLive then
            VT.verTargetLabel:SetText(string.format(L["GEMS_VARIANTS_VER_TARGET_LIVE"], verIdx))
            VT.verTargetLabel:SetTextColor(C.textSecondary:GetRGBA())
        else
            VT.verTargetLabel:SetText(string.format(L["GEMS_VARIANTS_VER_TARGET_NOT_LIVE"], verIdx))
            VT.verTargetLabel:SetTextColor(C.textWarning:GetRGBA())
        end
    end
    UpdateRiskBanner(seqData.recommendSource, verSrc)
end

-- Called by SequenceEditor:LoadSequence when the active sequence selection
-- changes. Caches the active sequence name (for diagnostics) and triggers
-- a refresh if the tab is currently visible -- RefreshFromSelection reads
-- SE.currentSequence directly so no further plumbing is needed.
function VT:LoadSequence(seqName)
    VT.activeSequence = seqName
    if VT.frame and VT.frame:IsShown() then
        VT:RefreshFromSelection()
    end
end

-- Called by SequenceEditor:Clear when the editor closes (no active
-- selection). Clears the edit boxes, hides the risk banner, and resets
-- variant rows to their Add state via an empty overrides table.
function VT:Clear()
    VT.activeSequence = nil
    if VT.seqEdit then
        VT.seqEdit:SetText("")
    end
    if VT.verEdit then
        VT.verEdit:SetText("")
    end
    UpdateRiskBanner(nil, nil)
    if VT.verTargetLabel then
        VT.verTargetLabel:SetText("")
    end
    UpdateVariantRows({})
end

-- Compile-check + persist seq-level recommend source. Empty text clears the
-- field. Non-empty text is compiled via the evaluator's CompileForVersion
-- (which calls loadstring) -- on failure the field is still saved but the
-- evaluator logs a debug warning; the UI shows the same warning via the
-- risk banner.
function VT:SaveSeqRecommend(text)
    local _, seqData, verData, verIdx = GetSelection()
    if not seqData then
        return
    end
    if text == "" then
        seqData.recommendSource = nil
    else
        seqData.recommendSource = text
    end
    if GRIPEMS.RecommendationEvaluator and verData then
        GRIPEMS.RecommendationEvaluator:CompileForVersion(
            GRIPEMS.SequenceEditor.currentSequence,
            verIdx,
            seqData,
            verData
        )
    end
    UpdateRiskBanner(seqData.recommendSource, verData and verData.recommendSource)
end

function VT:SaveVerRecommend(text)
    local _, seqData, verData, verIdx = GetSelection()
    if not seqData or not verData then
        return
    end
    if text == "" then
        verData.recommendSource = nil
    else
        verData.recommendSource = text
    end
    if VT.verEmptyLabel then
        if (verData.recommendSource or "") == "" then
            VT.verEmptyLabel:Show()
        else
            VT.verEmptyLabel:Hide()
        end
    end
    if GRIPEMS.RecommendationEvaluator then
        GRIPEMS.RecommendationEvaluator:CompileForVersion(
            GRIPEMS.SequenceEditor.currentSequence,
            verIdx,
            seqData,
            verData
        )
    end
    UpdateRiskBanner(seqData.recommendSource, verData.recommendSource)
end

-- Adds an empty-steps override for the modifier if missing, or removes the
-- existing override. Mirrors the /gems variants add MOD slash-command shape:
-- the empty-steps row is tolerated by the activation validator (steps {}) so
-- the user can populate macrotext via Steps-tab editing afterwards.
function VT:ToggleVariant(mod)
    local seqName, seqData, verData = GetSelection()
    if not verData or mod == "plain" then
        return
    end
    verData.variantOverrides = verData.variantOverrides or {}
    local foundIdx
    for i, ov in ipairs(verData.variantOverrides) do
        if type(ov) == "table" and ov.modifier == mod then
            foundIdx = i
            break
        end
    end
    if foundIdx then
        table.remove(verData.variantOverrides, foundIdx)
    else
        if #verData.variantOverrides >= (D() and D().MAX_VARIANT_OVERRIDES or 3) then
            GRIPEMS:Print(string.format(L["GEMS_VARIANT_MAX_REACHED"], seqName or "", D().MAX_VARIANT_OVERRIDES))
            return
        end
        table.insert(verData.variantOverrides, { name = "variant_" .. mod, modifier = mod, steps = {} })
    end
    -- Live-version parity with the /gems variants slash path: when the row
    -- just edited IS the version the engine runs, rebuild the activation so
    -- the indicator strip and macro stub reflect the change immediately.
    -- Non-live versions need no rebuild (the engine does not run them).
    local E = GRIPEMS.Engine
    if E and E.GetActiveVersion and seqName and E:GetActiveVersion(seqData) == verData then
        E:DeactivateSequence(seqName, true)
        E:ActivateSequence(seqName, seqData)
    end
    UpdateVariantRows(verData)
end
