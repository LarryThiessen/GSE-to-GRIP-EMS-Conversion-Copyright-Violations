-- GRIP-EMS: Remote Macro Browser
-- P2P sequence browsing: discover group members running EMS,
-- browse their sequence lists, and import remotely.
--
-- Created:    2025 (pre-stamping; exact date unknown)
-- Updated:    2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

GRIPEMS.RemoteBrowser = {}
local RB = GRIPEMS.RemoteBrowser

local frame = nil -- lazy-created, reused
local leftScrollBox, rightScrollBox
local selectedPlayer = nil
local rightHeader = nil
local statusText = nil
local waitingText = nil
local noPlayersText = nil

-- Forward declarations
local ClearSequenceRows
local RefreshSequenceList
local RefreshPlayerList

---------------------------------------------------------------------------
-- Player row initializer (left panel, ScrollBox)
---------------------------------------------------------------------------

local function InitPlayerRow(button, data)
    local UI = GRIPEMS.UI
    local C = UI.Colors

    if not button._initialized then
        UI:ApplyBackdrop(button, UI.Backdrops.panel, C.bgPanel, C.border)

        local nameLabel = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(nameLabel, 11)
        nameLabel:SetPoint("LEFT", button, "LEFT", 8, 2)
        nameLabel:SetJustifyH("LEFT")
        nameLabel:SetWordWrap(false)
        button._nameLabel = nameLabel

        local verLabel = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(verLabel, 9)
        verLabel:SetPoint("LEFT", button, "LEFT", 8, -8)
        verLabel:SetJustifyH("LEFT")
        button._verLabel = verLabel

        button._initialized = true
    end

    button._nameLabel:SetText(Ambiguate(data.name, "short"))
    button._nameLabel:SetTextColor(C.textPrimary:GetRGBA())
    button._verLabel:SetText("v" .. (data.version or "?"))
    button._verLabel:SetTextColor(C.textMuted:GetRGBA())

    if data.isSelected then
        UI:ApplyBackdrop(button, UI.Backdrops.panel, C.bgRowSelected, C.borderFocus)
    else
        UI:ApplyBackdrop(button, UI.Backdrops.panel, C.bgPanel, C.border)
    end

    local playerName = data.name
    button:SetScript("OnEnter", function(self)
        if playerName ~= selectedPlayer then
            self:SetBackdropColor(C.bgRowHover:GetRGBA())
            self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
        end
    end)
    button:SetScript("OnLeave", function(self)
        if playerName ~= selectedPlayer then
            self:SetBackdropColor(C.bgPanel:GetRGBA())
            self:SetBackdropBorderColor(C.border:GetRGBA())
        end
    end)

    button:SetScript("OnClick", function()
        selectedPlayer = playerName
        RefreshPlayerList()
        ClearSequenceRows()
        if rightHeader then
            rightHeader:SetText(string.format(L["GEMS_UI_REMOTE_SEQUENCES_FROM"], Ambiguate(playerName, "short")))
        end
        if waitingText then
            waitingText:SetText(L["GEMS_UI_REMOTE_WAITING"])
            waitingText:Show()
        end
        local T2 = GRIPEMS.Transmission
        local cached = T2 and T2:GetRemoteList(playerName)
        if cached then
            RefreshSequenceList(playerName)
        end
        if T2 then
            T2:SendListRequest(playerName)
        end
    end)
end

RefreshPlayerList = function()
    if not frame or not frame:IsShown() then
        return
    end

    local T = GRIPEMS.Transmission
    if not T then
        return
    end

    local sorted = T:GetKnownUserNames()
    local users = T:GetKnownUsers()

    if #sorted == 0 then
        if noPlayersText then
            noPlayersText:Show()
        end
        if leftScrollBox then
            leftScrollBox:SetDataProvider(CreateDataProvider())
        end
        return
    end

    if noPlayersText then
        noPlayersText:Hide()
    end

    local dp = CreateDataProvider()
    for _, name in ipairs(sorted) do
        local info = users[name]
        dp:Insert({
            name = name,
            version = info and info.version,
            isSelected = (name == selectedPlayer),
        })
    end
    if leftScrollBox then
        leftScrollBox:SetDataProvider(dp)
    end
end

---------------------------------------------------------------------------
-- Sequence row initializer (right panel, ScrollBox)
---------------------------------------------------------------------------

local function InitSequenceRow(row, data)
    local UI = GRIPEMS.UI
    local C = UI.Colors

    if not row._initialized then
        UI:ApplyBackdrop(row, UI.Backdrops.panel, C.bgPanel, C.border)

        local icon = row:CreateTexture(nil, "ARTWORK")
        icon:SetSize(32, 32)
        icon:SetPoint("LEFT", row, "LEFT", 4, 0)
        row._icon = icon

        local nameLabel = row:CreateFontString(nil, "OVERLAY")
        UI:SetFont(nameLabel, 12)
        nameLabel:SetPoint("TOPLEFT", icon, "TOPRIGHT", 8, -2)
        nameLabel:SetJustifyH("LEFT")
        nameLabel:SetWordWrap(false)
        row._nameLabel = nameLabel

        local helpLabel = row:CreateFontString(nil, "OVERLAY")
        UI:SetFont(helpLabel, 10)
        helpLabel:SetPoint("BOTTOMLEFT", icon, "BOTTOMRIGHT", 8, 2)
        helpLabel:SetJustifyH("LEFT")
        helpLabel:SetWordWrap(false)
        row._helpLabel = helpLabel

        local importBtn = UI:CreateButton(row, L["GEMS_UI_REMOTE_IMPORT"], 60, 24)
        importBtn:SetPoint("RIGHT", row, "RIGHT", -4, 0)
        row._importBtn = importBtn

        row._initialized = true
    end

    row._icon:SetTexture(UI:ResolveIcon(data.icon))
    row._icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

    row._nameLabel:SetText(data.name or "")
    row._nameLabel:SetTextColor(C.textPrimary:GetRGBA())
    row._nameLabel:SetWidth(280)

    local helpText = data.help or ""
    if helpText == "" then
        helpText = data.class or ""
    end
    row._helpLabel:SetText(helpText)
    row._helpLabel:SetTextColor(C.textSecondary:GetRGBA())
    row._helpLabel:SetWidth(280)

    local sender = data.sender
    local seqName = data.name
    row._importBtn:SetScript("OnEnter", function(self)
        UI:ShowTooltip(self, L["GEMS_UI_REMOTE_IMPORT"], L["GEMS_BROWSE_IMPORT_DESC"])
    end)
    row._importBtn:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)
    row._importBtn:SetScript("OnClick", function()
        if GRIPEMS.Transmission and sender then
            GRIPEMS.Transmission:SendRequest(seqName, sender)
            if statusText then
                statusText:SetText(string.format(L["GEMS_UI_REMOTE_REQUEST_SENT"], seqName, Ambiguate(sender, "short")))
            end
        end
    end)
end

ClearSequenceRows = function()
    if rightScrollBox then
        rightScrollBox:SetDataProvider(CreateDataProvider())
    end
    if waitingText then
        waitingText:Hide()
    end
end

RefreshSequenceList = function(sender)
    ClearSequenceRows()
    if not sender then
        return
    end

    local T = GRIPEMS.Transmission
    if not T then
        return
    end

    local listData = T:GetRemoteList(sender)
    if not listData or not listData.sequences then
        if waitingText then
            waitingText:SetText(L["GEMS_UI_REMOTE_NO_SEQUENCES"])
            waitingText:Show()
        end
        return
    end

    local seqs = listData.sequences
    if #seqs == 0 then
        if waitingText then
            waitingText:SetText(L["GEMS_UI_REMOTE_NO_SEQUENCES"])
            waitingText:Show()
        end
        return
    end

    if waitingText then
        waitingText:Hide()
    end

    local dp = CreateDataProvider()
    for _, info in ipairs(seqs) do
        dp:Insert({
            name = info.name,
            icon = info.icon,
            help = info.help,
            class = info.class,
            sender = sender,
        })
    end
    if rightScrollBox then
        rightScrollBox:SetDataProvider(dp)
    end

    if statusText then
        statusText:SetText(string.format(L["GEMS_UI_REMOTE_LIST_RECEIVED"], Ambiguate(sender, "short"), #seqs))
    end
end

---------------------------------------------------------------------------
-- Frame creation
---------------------------------------------------------------------------

local function CreateBrowserFrame()
    local C = GRIPEMS.UI.Colors
    local UI = GRIPEMS.UI

    frame = CreateFrame("Frame", "GRIPEMS_RemoteBrowser", UIParent, "BackdropTemplate")
    frame:SetSize(700, 450)
    frame:SetPoint("CENTER")
    frame:SetFrameStrata("HIGH")
    frame:SetClampedToScreen(true)
    UI:ApplyBackdrop(frame, UI.Backdrops.panel, C.bgMain, C.border)
    if GRIPEMS.UI and GRIPEMS.UI.RegisterPanelFrame then
        GRIPEMS.UI:RegisterPanelFrame(frame, "panel", "panel.utility")
    end
    frame:SetMovable(true)
    frame:Hide()

    -- ESC to close
    if not tContains(UISpecialFrames, "GRIPEMS_RemoteBrowser") then
        tinsert(UISpecialFrames, "GRIPEMS_RemoteBrowser")
    end

    ---------------------------------------------------------------------------
    -- Title bar
    ---------------------------------------------------------------------------
    local titleBar = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    titleBar:SetHeight(30)
    titleBar:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, 0)
    titleBar:SetPoint("TOPRIGHT", frame, "TOPRIGHT", 0, 0)
    UI:ApplyBackdrop(titleBar, UI.Backdrops.panelNoBorder, C.bgDeep)

    titleBar:EnableMouse(true)
    titleBar:RegisterForDrag("LeftButton")
    titleBar:SetScript("OnDragStart", function()
        frame:StartMoving()
    end)
    titleBar:SetScript("OnDragStop", function()
        frame:StopMovingOrSizing()
    end)

    local titleText = titleBar:CreateFontString(nil, "OVERLAY")
    UI:SetFont(titleText, 13, "OUTLINE")
    titleText:SetPoint("LEFT", titleBar, "LEFT", 12, 0)
    titleText:SetText("GRIP-EMS: " .. L["GEMS_UI_REMOTE_BROWSER_TITLE"])
    titleText:SetTextColor(C.gripGreen:GetRGBA())

    -- Close button
    local closeBtn = CreateFrame("Button", nil, titleBar, "BackdropTemplate")
    closeBtn:SetSize(24, 24)
    UI:RegisterLargeTarget(closeBtn)
    closeBtn:SetPoint("TOPRIGHT", titleBar, "TOPRIGHT", -6, -3)
    UI:ApplyBackdrop(closeBtn, UI.Backdrops.panel, C.bgButton, C.border)
    local closeLbl = closeBtn:CreateFontString(nil, "OVERLAY")
    UI:SetFont(closeLbl, 14)
    closeLbl:SetPoint("CENTER", 0, 1)
    closeLbl:SetText("X")
    closeLbl:SetTextColor(C.textSecondary:GetRGBA())
    closeBtn:SetScript("OnClick", function()
        frame:Hide()
    end)
    closeBtn:SetScript("OnEnter", function(self)
        UI:ShowTooltip(self, CLOSE or "Close", L["GEMS_BROWSE_CLOSE_DESC"])
        self:SetBackdropColor(C.accent:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
        closeLbl:SetTextColor(C.textPrimary:GetRGBA())
    end)
    closeBtn:SetScript("OnLeave", function(self)
        GameTooltip:Hide()
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
        closeLbl:SetTextColor(C.textSecondary:GetRGBA())
    end)

    ---------------------------------------------------------------------------
    -- Left panel (200px): Known Users
    ---------------------------------------------------------------------------
    local leftPanel = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    leftPanel:SetWidth(200)
    leftPanel:SetPoint("TOPLEFT", frame, "TOPLEFT", 1, -30)
    leftPanel:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 1, 26)
    UI:ApplyBackdrop(leftPanel, UI.Backdrops.panel, C.bgPanel, C.border)

    -- Left header
    local leftHeader = leftPanel:CreateFontString(nil, "OVERLAY")
    UI:SetFont(leftHeader, 11, "OUTLINE")
    leftHeader:SetPoint("TOPLEFT", leftPanel, "TOPLEFT", 8, -8)
    leftHeader:SetText(L["GEMS_UI_REMOTE_PLAYERS_HEADER"])
    leftHeader:SetTextColor(C.textSecondary:GetRGBA())

    -- Refresh button
    local refreshBtn = UI:CreateButton(leftPanel, L["GEMS_UI_REMOTE_REFRESH"], 70, 22)
    refreshBtn:SetPoint("TOPRIGHT", leftPanel, "TOPRIGHT", -4, -4)
    refreshBtn:SetScript("OnEnter", function(self)
        UI:ShowTooltip(self, L["GEMS_UI_REMOTE_REFRESH"], L["GEMS_BROWSE_REFRESH_DESC"])
    end)
    refreshBtn:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)
    refreshBtn:SetScript("OnClick", function()
        local T = GRIPEMS.Transmission
        if T then
            T:SendVersionCheck()
        end
        if C_Timer and C_Timer.After then
            C_Timer.After(2, function()
                RefreshPlayerList()
            end)
        end
    end)

    -- ScrollBox for player list
    leftScrollBox = CreateFrame("Frame", nil, leftPanel, "WowScrollBoxList")
    leftScrollBox:SetPoint("TOPLEFT", leftPanel, "TOPLEFT", 4, -32)
    leftScrollBox:SetPoint("BOTTOMRIGHT", leftPanel, "BOTTOMRIGHT", -18, 4)

    local leftScrollBar = CreateFrame("EventFrame", nil, leftPanel, "MinimalScrollBar")
    leftScrollBar:SetPoint("TOPLEFT", leftScrollBox, "TOPRIGHT", 2, 0)
    leftScrollBar:SetPoint("BOTTOMLEFT", leftScrollBox, "BOTTOMRIGHT", 2, 0)

    local leftScrollView = CreateScrollBoxListLinearView()
    leftScrollView:SetElementExtent(30)
    leftScrollView:SetElementInitializer("Button", function(button, data)
        InitPlayerRow(button, data)
    end)
    ScrollUtil.InitScrollBoxListWithScrollBar(leftScrollBox, leftScrollBar, leftScrollView)
    leftScrollBox:SetDataProvider(CreateDataProvider())

    -- No players text
    noPlayersText = leftPanel:CreateFontString(nil, "OVERLAY")
    UI:SetFont(noPlayersText, 10)
    noPlayersText:SetPoint("TOPLEFT", leftPanel, "TOPLEFT", 8, -40)
    noPlayersText:SetWidth(170)
    noPlayersText:SetText(L["GEMS_UI_REMOTE_NO_PLAYERS"])
    noPlayersText:SetTextColor(C.textMuted:GetRGBA())
    noPlayersText:SetJustifyH("LEFT")
    noPlayersText:SetWordWrap(true)

    ---------------------------------------------------------------------------
    -- Right panel: Sequence list
    ---------------------------------------------------------------------------
    local rightPanel = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    rightPanel:SetPoint("TOPLEFT", leftPanel, "TOPRIGHT", 1, 0)
    rightPanel:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -1, 26)
    UI:ApplyBackdrop(rightPanel, UI.Backdrops.panelNoBorder, C.bgMain)

    -- Right header
    rightHeader = rightPanel:CreateFontString(nil, "OVERLAY")
    UI:SetFont(rightHeader, 12, "OUTLINE")
    rightHeader:SetPoint("TOPLEFT", rightPanel, "TOPLEFT", 8, -8)
    rightHeader:SetText(L["GEMS_UI_REMOTE_BROWSER_TITLE"])
    rightHeader:SetTextColor(C.textPrimary:GetRGBA())

    -- Waiting text
    waitingText = rightPanel:CreateFontString(nil, "OVERLAY")
    UI:SetFont(waitingText, 11)
    waitingText:SetPoint("CENTER", rightPanel, "CENTER", 0, 0)
    waitingText:SetText(L["GEMS_UI_REMOTE_NO_PLAYERS"])
    waitingText:SetTextColor(C.textMuted:GetRGBA())

    -- ScrollBox for sequence list
    rightScrollBox = CreateFrame("Frame", nil, rightPanel, "WowScrollBoxList")
    rightScrollBox:SetPoint("TOPLEFT", rightPanel, "TOPLEFT", 4, -28)
    rightScrollBox:SetPoint("BOTTOMRIGHT", rightPanel, "BOTTOMRIGHT", -18, 4)

    local rightScrollBar = CreateFrame("EventFrame", nil, rightPanel, "MinimalScrollBar")
    rightScrollBar:SetPoint("TOPLEFT", rightScrollBox, "TOPRIGHT", 2, 0)
    rightScrollBar:SetPoint("BOTTOMLEFT", rightScrollBox, "BOTTOMRIGHT", 2, 0)

    local rightScrollView = CreateScrollBoxListLinearView()
    rightScrollView:SetElementExtent(42)
    rightScrollView:SetElementInitializer("Frame", function(row, data)
        InitSequenceRow(row, data)
    end)
    ScrollUtil.InitScrollBoxListWithScrollBar(rightScrollBox, rightScrollBar, rightScrollView)
    rightScrollBox:SetDataProvider(CreateDataProvider())

    ---------------------------------------------------------------------------
    -- Bottom status bar
    ---------------------------------------------------------------------------
    local statusBar = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    statusBar:SetHeight(24)
    statusBar:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 1, 1)
    statusBar:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -1, 1)
    UI:ApplyBackdrop(statusBar, UI.Backdrops.panelNoBorder, C.bgDeep)

    statusText = statusBar:CreateFontString(nil, "OVERLAY")
    UI:SetFont(statusText, 10)
    statusText:SetPoint("LEFT", statusBar, "LEFT", 8, 0)
    statusText:SetText("")
    statusText:SetTextColor(C.textMuted:GetRGBA())

    ---------------------------------------------------------------------------
    -- Register callback for incoming list responses
    ---------------------------------------------------------------------------
    GRIPEMS.RegisterCallback(GRIPEMS, "REMOTE_LIST_RECEIVED", function(_, sender)
        if frame and frame:IsShown() and sender == selectedPlayer then
            RefreshSequenceList(sender)
        end
        -- Also refresh player list in case of new users
        RefreshPlayerList()
    end)

    return frame
end

---------------------------------------------------------------------------
-- Public API
---------------------------------------------------------------------------

--- Toggle the Remote Browser frame.
function RB:Toggle()
    if not frame then
        CreateBrowserFrame()
    end
    if frame:IsShown() then
        frame:Hide()
    else
        selectedPlayer = nil
        frame:Show()
        RefreshPlayerList()
    end
end

--- Show the Remote Browser frame.
function RB:Show()
    if not frame then
        CreateBrowserFrame()
    end
    selectedPlayer = nil
    frame:Show()
    RefreshPlayerList()
end

--- Hide the Remote Browser frame.
function RB:Hide()
    if frame then
        frame:Hide()
    end
end

--- Check if the Remote Browser is currently shown.
--- @return boolean
function RB:IsShown()
    return frame and frame:IsShown()
end
