-- GRIP-EMS: Headless test for the DISPLAY-domain step text (stepOwnText)
--
-- Created:    2026-08-17
-- Updated:    2026-08-17
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
--
-- Engine:CompileSteps prepends the keyPress block to EVERY step whenever the two
-- fit the 255-char cap, and stores that COMBINED string as compiled[i].macrotext.
-- That string is correct for firing and wrong for display: SC:ParseSpellFromMacrotext
-- returns the LAST unconditional or [combat] cast it finds, else the FIRST
-- conditional cast. When no line anywhere is unconditional and none carries
-- [combat], the answer is keypress line one -- for every step.
--
-- Reported on a Brewmaster Monk whose keypress box opens with a [mod:shift] cast
-- and whose every step carries [nochanneling]: every tracker row showed Leg Sweep.
-- The casts were correct throughout, because only the display path is affected.
--
-- The same rule already existed one loop below the bake, on empowerRelease, which
-- is computed from the step's own resolved text rather than from combined, for
-- exactly this reason. The fix publishes that same resolved text as
-- compiled[i].stepOwnText and gives the display consumers their own accessor,
-- Engine:GetExecStepDisplayText. Nothing about casting reads it -- A2 pins that.
--
-- Run from the EMS root:  lua Test/test_display_step_own_text.lua
-- Exit code 0 = all passed, 1 = at least one failure.
--
-- Cases:
--   A1  the reporter's shape -- conditional keypress, [nochanneling] step. The
--       accessor AND the real TrackerHUD row both resolve the STEP's spell.
--   A2  control: casting is untouched -- macrotext still carries the keypress line
--   A3  overflow branch: nothing is baked, stepOwnText is published anyway
--   A4  legacy array (macrotext, no stepOwnText) falls back without raising
--   A5  an UNCONDITIONAL keypress line does not win the display either
--   A6  the BarIntegration WIRING, through the real BI:OnStepAdvanced
--   A7  the Engine:UpdateButtonIcon WIRING, through the real method
--   A8  the TrackerHUD REBUILD wiring, through the real TH:Rebuild
--
-- A6 and A7 exist because A1 and A5 pin the ACCESSOR and the TrackerHUD pair
-- only. Measured 2026-08-17 by mutation, not by reading: reverting BOTH
-- BarIntegration's ResolveSequenceIcon and Engine:UpdateButtonIcon to the old
-- accessor at the same time left SET A at 32 discovered, 32 passed, 0 failed.
-- Two of the four repointed call sites were carrying no test at all, which is
-- the same shape as the defect Phase 1 fixed: a rule that reached some call
-- sites and not others.
--
-- A8 closes the last one, and it is the subtlest of the four. TrackerHUD has TWO
-- call sites, in DIFFERENT functions: TH:UpdateIcon (pinned by A1 and A5) and
-- TH:Rebuild. Measured the same way: reverting the Rebuild site alone left all
-- four suites green. Rebuild also carries a FAST PATH that calls TH:UpdateIcon
-- for each entry and returns before its own call site is ever reached, so a case
-- that lands on that path sees the RIGHT spell reach SC:GetIcon from the WRONG
-- line and passes having tested nothing. A lookup count cannot catch that -- a
-- lookup really did happen. A8 defends it twice: TH._lastSorted is seeded with a
-- SENTINEL table that does not match the sorted list, so the unchanged-list test
-- fails and the fast path cannot be taken, and the case then asserts the latch is
-- no longer THAT OBJECT -- the full path assigns a new table past the fast-path
-- branch, while the fast path returns above that assignment and leaves the
-- sentinel exactly where the case put it.
--
-- The witness used to be EXISTENCE, and existence cannot discriminate here: a
-- non-nil latch is the PRECONDITION for taking the fast path, so the check was
-- satisfied in precisely the case it existed to detect. Measured 2026-08-17 --
-- seeding a MATCHING latch left A8 green, and seeding a matching latch WHILE the
-- Rebuild call site was reverted ALSO left A8 green: the line was broken, never
-- ran, and the case took its Tiger Palm from TH:UpdateIcon. Identity discriminates
-- where existence does not. This paragraph names the trap so it is not re-derived.
--
-- STUB AUDIT.
--   Data/SpellCache.lua   loaded FOR REAL, so StepToString, ScrubInvalidSpellTags
--                         and above all ParseSpellFromMacrotext are the shipped
--                         implementations. The whole defect is a ranking that
--                         function performs on its input, so stubbing it would
--                         test nothing. Its D() accessor reads the Defaults table
--                         below, whose SKIP_SPELL_PREFIXES is copied verbatim from
--                         Data/Defaults.lua.
--   SC:GetIcon            REPLACED after load with a name -> fixed-id map. LIVE:
--                         C_Spell.GetSpellTexture, a client lookup with no headless
--                         answer. No case asserts an icon ID is CORRECT; the
--                         observable is WHICH SPELL NAME the draw path handed it.
--   GRIPEMS.SpellValidator  absent, so Engine:EmpowerReleaseFor returns "" for
--                         every step. Empower is pinned in
--                         Test/test_stepadv_numsteps_domain.lua, not here; what
--                         matters is that stepOwnText sits beside that field and
--                         is computed from the same input.
--   GRIPEMS.VariableStore / MacroConditionalBaker  absent, so SubstituteVariables
--                         and the compile-time bake are identity. The fixtures
--                         carry no ~var~ and no bakeable conditional, so the
--                         resolved text equals the authored text.
--   TrackerHUD row widgets  a recording texture plus a self-referential catch-all
--                         backing every other child. LIVE: real Textures and
--                         FontStrings. The observable is the spell name that
--                         reached the icon lookup, which is what the user sees.
--   env.CreateFrame       returns a frame stub whose NUMERIC getters really answer
--                         numbers. The plain catch-all is not enough for A6:
--                         BarIntegration's CreateOverlay does
--                         cooldownRing:SetFrameLevel(frame:GetFrameLevel() + 1),
--                         and arithmetic on a stub table raises. LIVE: real Frames.
--                         No case asserts anything about frame geometry.
--   env.InCombatLockdown  false throughout, set EXPLICITLY rather than left to the
--                         catch-all. This is the vacuous-green trap in A6: the
--                         catch-all returns a TRUTHY stub table, BI:OnStepAdvanced
--                         takes its combat early-return, no icon is ever resolved,
--                         and the case passes having tested nothing.
--   OOCQueue.IsRestricted  false, the same trap on the A7 side: Engine:UpdateButtonIcon
--                         runs its icon block only when this is FALSY.
--   KeybindManager:GetKeybind  returns a fixed binding string. LIVE: the real
--                         KeybindManager, which answers what the player actually
--                         bound. TH:Rebuild collects a sequence into its sorted
--                         list ONLY when this is truthy, so without it A8's
--                         sequence never enters the list and #sorted == 0 hides
--                         the frame and returns. The harness previously carried
--                         KeybindManager as an empty table, which is TRUTHY and so
--                         passes the "KM and" half, then RAISES on the call --
--                         a missing field, not a nil answer. No case asserts
--                         anything about which key is bound.
--   Settings:Get          returns nil so every TrackerHUD layout read falls to its
--                         own "or <default>". LIVE: the real settings store. Size,
--                         orientation and name-label choices are not what these
--                         cases observe.
--   TH.frame              frameStub. TH:Rebuild returns immediately when this is
--                         nil, which is the A8 equivalent of the guard traps above.
--                         LIVE: the real HUD frame built by CreateHUDFrame.

local ADDON_NAME = "GRIP-EMS"

-- ---------------------------------------------------------------------------
-- Minimal assertion + runner harness.
-- ---------------------------------------------------------------------------

local tests = {}

local function test(name, fn)
    tests[#tests + 1] = { name = name, fn = fn }
end

local function assertEqual(expected, actual, label)
    if expected ~= actual then
        error((label or "value") .. ": expected " .. tostring(expected) .. ", got " .. tostring(actual), 2)
    end
end

local function assertNotEqual(unexpected, actual, label)
    if unexpected == actual then
        error((label or "value") .. ": expected anything BUT " .. tostring(unexpected), 2)
    end
end

local function assertTrue(cond, label)
    if not cond then
        error((label or "condition") .. " failed", 2)
    end
end

-- ---------------------------------------------------------------------------
-- Sandbox: a self-referential no-op stub backs every unknown global so the real
-- modules load without a WoW client. Real stdlib falls through to _G.
-- ---------------------------------------------------------------------------

local stub = {}
setmetatable(stub, {
    __index = function()
        return stub
    end,
    __call = function()
        return stub
    end,
})

local env = setmetatable({}, {
    __index = function(_, k)
        local v = rawget(_G, k)
        if v ~= nil then
            return v
        end
        return stub
    end,
})
env._G = env

-- AceLocale stand-in: every key echoes back so any L["KEY"] format is inert.
local LOCALE = setmetatable({}, {
    __index = function(_, k)
        return k
    end,
})
env.LibStub = function()
    return {
        GetLocale = function()
            return LOCALE
        end,
    }
end

-- EXPLICIT, never the catch-all: a truthy answer here sends BI:OnStepAdvanced
-- straight out of its combat early-return and A6 goes vacuously green.
env.InCombatLockdown = function()
    return false
end

-- A frame stub with real numbers behind the numeric getters. BarIntegration's
-- CreateOverlay adds 1 to frame:GetFrameLevel(), and Lua raises on arithmetic
-- against the catch-all table. Everything non-numeric still falls through to the
-- self-referential stub, so unknown widget methods stay no-ops.
local frameStub = {
    GetFrameLevel = function()
        return 1
    end,
    GetWidth = function()
        return 36
    end,
    GetHeight = function()
        return 36
    end,
    GetFrameStrata = function()
        return "MEDIUM"
    end,
}
setmetatable(frameStub, {
    __index = function()
        return stub
    end,
    __call = function()
        return stub
    end,
})
env.CreateFrame = function()
    return frameStub
end

env.strlower = string.lower
env.wipe = function(t)
    for k in pairs(t) do
        t[k] = nil
    end
    return t
end

-- ---------------------------------------------------------------------------
-- GRIPEMS control table.
-- ---------------------------------------------------------------------------

local GRIPEMS = {
    version = "headless",
    Print = function() end,
    Debug = function() end,
    Fire = function() end,
    Defaults = {
        STEP_SEQUENTIAL = "Sequential",
        STEP_RANDOM = "Random",
        STEP_PRIORITY = "Priority",
        STEP_REVERSE_PRIORITY = "ReversePriority",
        ATTR_TYPE_MACRO = "macro",
        MAX_MACROTEXT_LENGTH = 255,
        MAX_SAB_MACROTEXT_LENGTH = 255,
        CONTEXT_NONE = "none",
        VAR_PATTERN = "~([%w_]+)~",
        -- Verbatim from Data/Defaults.lua. ParseSpellFromMacrotext reads this
        -- through its D() accessor and a short list would silently change the
        -- ranking these cases are written against.
        SKIP_SPELL_PREFIXES = {
            "^%s*#show",
            "^%s*/stopcasting",
            "^%s*/stopattack",
            "^%s*/stopmacro",
            "^%s*/cancelaura",
            "^%s*/cancelform",
            "^%s*/startattack",
            "^%s*/target",
            "^%s*/focus",
            "^%s*/clearfocus",
            "^%s*/cleartarget",
        },
    },
    -- TrackerHUD's step-advance flash reads this table directly, with no guard.
    -- reduceMotion keeps the headless run out of the animation branch entirely.
    Settings = {
        db = { profile = { accessibility = { flickerSafe = false, reduceMotion = true } } },
        GetResetModifiers = function()
            return {}
        end,
        -- nil for every key, so TrackerHUD's layout reads take their own defaults.
        -- Only A8 reaches these; the earlier cases never call Settings:Get, because
        -- BarIntegration's one read sits behind an entry.variantIdx that stays nil.
        Get = function()
            return nil
        end,
    },
    OOCQueue = {
        -- EXPLICITLY false. Engine:UpdateButtonIcon runs its icon block only when
        -- this is FALSY, so a truthy answer would let A7 pass without ever
        -- reaching the accessor it exists to pin.
        IsRestricted = function()
            return false
        end,
        Add = function(_, fn)
            fn()
        end,
    },
    MacroManager = {
        UpdateIcon = function() end,
        UpdateStubBody = function() end,
    },
    KeybindManager = {
        -- TH:Rebuild admits a sequence to its sorted list only when this answers
        -- truthy. An empty table here is truthy enough to pass the "KM and" half
        -- and then raises on the call, which is why the field exists rather than
        -- the table alone. Nothing outside A8 calls it.
        GetKeybind = function()
            return "SHIFT-T"
        end,
    },
    Popup = {
        Define = function() end,
        Show = function() end,
    },
    UI = {
        Colors = setmetatable({}, {
            __index = function()
                return {
                    GetRGBA = function()
                        return 1, 1, 1, 1
                    end,
                }
            end,
        }),
    },
}

-- ---------------------------------------------------------------------------
-- Load the REAL modules into the sandbox, in TOC order.
-- ---------------------------------------------------------------------------

local function loadModule(candidates)
    for _, path in ipairs(candidates) do
        -- loadfile is dev-harness file I/O, intentionally outside the addon WoW std.
        -- selene: allow(undefined_variable)
        local chunk = loadfile(path)
        if chunk then
            setfenv(chunk, env)
            chunk(ADDON_NAME, GRIPEMS)
            return true
        end
    end
    return false
end

assert(
    loadModule({
        "Data/SpellCache.lua",
        "../Data/SpellCache.lua",
        "GRIP/EMS/Data/SpellCache.lua",
    }),
    "could not locate Data/SpellCache.lua (run from the EMS root)"
)
assert(
    loadModule({
        "Engine/StepFunctions.lua",
        "../Engine/StepFunctions.lua",
        "GRIP/EMS/Engine/StepFunctions.lua",
    }),
    "could not locate Engine/StepFunctions.lua (run from the EMS root)"
)
assert(
    loadModule({
        "Engine/Engine.lua",
        "../Engine/Engine.lua",
        "GRIP/EMS/Engine/Engine.lua",
    }),
    "could not locate Engine/Engine.lua (run from the EMS root)"
)
assert(
    loadModule({
        "Engine/BarIntegration.lua",
        "../Engine/BarIntegration.lua",
        "GRIP/EMS/Engine/BarIntegration.lua",
    }),
    "could not locate Engine/BarIntegration.lua (run from the EMS root)"
)
assert(
    loadModule({
        "UI/TrackerHUD.lua",
        "../UI/TrackerHUD.lua",
        "GRIP/EMS/UI/TrackerHUD.lua",
    }),
    "could not locate UI/TrackerHUD.lua (run from the EMS root)"
)

local Engine = GRIPEMS.Engine
local SC = GRIPEMS.SpellCache
local TH = GRIPEMS.TrackerHUD
local BI = GRIPEMS.BarIntegration

-- Only PRE-EXISTING symbols are asserted at load time. GetExecStepDisplayText is
-- deliberately NOT asserted here: against the pre-fix Engine every case below must
-- report its own FAIL line, and a load-time assert would abort the file instead.
assert(type(Engine) == "table", "Engine loaded")
assert(type(SC) == "table", "SpellCache loaded")
assert(type(TH) == "table", "TrackerHUD loaded")
assert(type(Engine.CompileSteps) == "function", "CompileSteps defined")
assert(type(Engine.GetExecStepText) == "function", "GetExecStepText defined")
assert(type(SC.ParseSpellFromMacrotext) == "function", "ParseSpellFromMacrotext defined")
assert(type(TH.UpdateIcon) == "function", "TH:UpdateIcon defined")
assert(type(BI) == "table", "BarIntegration loaded")
-- The only PUBLIC way into ResolveSequenceIcon, which is file-local. A6 drives
-- this rather than the helper, which is the point: the WIRING is what is untested.
assert(type(BI.OnStepAdvanced) == "function", "BI:OnStepAdvanced defined")
assert(type(Engine.UpdateButtonIcon) == "function", "Engine:UpdateButtonIcon defined")
Engine.sequences = {}

-- ---------------------------------------------------------------------------
-- Fixtures.
-- ---------------------------------------------------------------------------

-- The reporter's shape: a keypress box that opens with a modifier-gated cast, and
-- steps that all carry [nochanneling]. NOTHING here is unconditional and nothing
-- carries [combat], which is the exact input on which ParseSpellFromMacrotext
-- falls back to the FIRST conditional cast it saw.
local KEYPRESS = "/cast [mod:shift] Leg Sweep\n/cast [mod:alt] Spinning Crane Kick"
local STEP_1 = "/cast [nochanneling] Tiger Palm"
local STEP_2 = "/cast [nochanneling] Blackout Kick"

-- Same keypress spell, no conditional at all. This one lands in the PREFERRED
-- branch of the parser rather than the fallback, so it is a different code path
-- to the same wrong answer.
local KEYPRESS_UNCOND = "/cast Leg Sweep"

-- Long enough that keypress + step blows the 255-char cap, so CompileSteps takes
-- the overflow branch and bakes nothing. The #show line is in SKIP_SPELL_PREFIXES,
-- so the padding never reaches the spell ranking.
local KEYPRESS_LONG = "/cast [mod:shift] Leg Sweep\n#showtooltip " .. string.rep("A", 220)

-- Fixed icon IDs. No case asserts one is the spell's REAL icon -- they exist only
-- so the recorded lookup can be traced back to a name.
local ICON_IDS = {
    ["Tiger Palm"] = 606551,
    ["Leg Sweep"] = 608940,
    ["Blackout Kick"] = 574575,
    ["Spinning Crane Kick"] = 606543,
}

local iconLookups = {}
SC.GetIcon = function(_, spellName)
    iconLookups[#iconLookups + 1] = spellName
    return ICON_IDS[spellName] or 134400
end

--- The spell a DISPLAY consumer would show for a compiled entry's text.
local function parsed(text)
    return SC:ParseSpellFromMacrotext(text)
end

--- A button carrying a compiled execution array, the shape every display consumer
--- reads. GetAttribute answers "step" because TrackerHUD's full rebuild asks the
--- button for it; UpdateIcon is handed the index directly.
local function makeButton(execSteps, step)
    return {
        seqName = "Fixture",
        _execSteps = execSteps,
        _numExecSteps = execSteps and #execSteps or nil,
        GetAttribute = function(_, key)
            if key == "step" then
                return step or 1
            end
            return nil
        end,
    }
end

--- Register a sequence the real TrackerHUD can find, and hand back the version
--- table so a case can pass it to the accessor.
local function installSequence(seqName, steps, execSteps, step)
    local ver = { stepFunction = "Sequential", steps = steps, keyPress = "", keyRelease = "" }
    local seqData = { name = seqName, defaultVersion = 1, versions = { ver } }
    local btn = makeButton(execSteps, step)
    btn.seqData = seqData
    Engine.sequences[seqName] = { button = btn, data = seqData }
    return ver, btn
end

--- A TrackerHUD row of the shape TH:UpdateIcon drives. Every child is a
--- self-referential catch-all except texture, whose SetTexture is recorded.
local function installTrackerRow(seqName)
    local drawn = {}
    local rowStub = {}
    setmetatable(rowStub, {
        __index = function()
            return rowStub
        end,
        __call = function()
            return rowStub
        end,
    })
    local texture = setmetatable({}, {
        __index = function()
            return rowStub
        end,
    })
    texture.SetTexture = function(_, id)
        drawn[#drawn + 1] = id
    end
    TH.icons = {
        {
            seqName = seqName,
            stepText = rowStub,
            -- Only the full TH:Rebuild path (A8) touches this one; TH:UpdateIcon
            -- never reads it, so A1 and A5 are unaffected by its presence.
            nameText = rowStub,
            versionBadge = nil,
            texture = texture,
            animGroup = rowStub,
            highlightTex = rowStub,
            frame = rowStub,
        },
    }
    TH.activeSeqName = nil
    return drawn
end

--- Register a bar button BI:OnStepAdvanced will actually act on. The method
--- resolves an icon and then applies it only to trackedButtons whose seqName
--- matches, so without this the loop body never runs. variantIdx stays nil: that
--- is the single-variant path, which leaves the IC-VAR-08 indicator layers hidden
--- and keeps this case about the icon and nothing else.
local function installTrackedButton(globalName, seqName)
    -- Backed by frameStub, not the plain catch-all: CreateOverlay reads
    -- (button:GetFrameLevel() or 0) + 5 off the BUTTON as well as off the frame
    -- it just made, and a stub table there raises on the addition.
    local button = setmetatable({
        GetName = function()
            return globalName
        end,
    }, { __index = frameStub })
    BI.trackedButtons[globalName] = { button = button, seqName = seqName, variantIdx = nil }
    return button
end

local function clearFixtures()
    Engine.sequences = {}
    TH.icons = {}
    TH.activeSeqName = nil
    -- Both belong to TH:Rebuild. _lastSorted is the fast-path latch, and leaving a
    -- stale one behind would let a later case take the fast path by accident.
    TH._lastSorted = nil
    TH.frame = nil
    iconLookups = {}
    for k in pairs(BI.trackedButtons) do
        BI.trackedButtons[k] = nil
    end
end

-- ---------------------------------------------------------------------------
-- Cases.
-- ---------------------------------------------------------------------------

test("A1 (reporter's shape): the display resolves the STEP's spell, not the keypress line", function()
    -- Compiled through the REAL CompileSteps, so the bake decision, the 255-char
    -- test and the field publication are all the shipped ones.
    local compiled = Engine:CompileSteps({ STEP_1, STEP_2 }, KEYPRESS, "")
    local ver, btn = installSequence("A1_Seq", { STEP_1, STEP_2 }, compiled, 1)
    local drawn = installTrackerRow("A1_Seq")

    -- WITNESS: the combined text really does mis-rank. Without this the case
    -- could pass on a build where the fixture never reproduced the defect.
    local combinedSpell = parsed(compiled[1].macrotext)

    local displayText = Engine:GetExecStepDisplayText(btn, 1, ver)
    local displaySpell = parsed(displayText)

    -- And the CONSUMER the reporter actually reads: the real TrackerHUD row.
    TH:UpdateIcon("A1_Seq", 1, 2)
    local rowSpell = iconLookups[#iconLookups]
    local rowIcon = drawn[#drawn]
    clearFixtures()

    assertTrue(compiled[1] ~= nil, "A1: CompileSteps produced an entry for step 1")
    assertEqual("Leg Sweep", combinedSpell, "A1 (witness): the combined text ranks the keypress cast first")
    assertEqual("Tiger Palm", displaySpell, "A1: the display accessor resolves the step's own spell")
    assertNotEqual("Leg Sweep", displaySpell, "A1: the keypress spell must not win the display")
    assertEqual("Tiger Palm", rowSpell, "A1: the real TrackerHUD row looked up the step's own spell")
    assertEqual(ICON_IDS["Tiger Palm"], rowIcon, "A1: the row was given that spell's icon")
end)

test("A2 (control): casting is untouched -- macrotext still carries the keypress block", function()
    local compiled = Engine:CompileSteps({ STEP_1, STEP_2 }, KEYPRESS, "")
    local macrotext = compiled[1] and compiled[1].macrotext
    clearFixtures()

    -- A build that "fixed" the display by dropping keyPress out of the macro
    -- would pass A1 and fail HERE. The combined text is what fires and it is
    -- correct; only what the player is SHOWN was wrong.
    assertEqual(KEYPRESS .. "\n" .. STEP_1, macrotext, "A2: step 1 still fires keypress + step, byte for byte")
    assertTrue(macrotext:find("Leg Sweep", 1, true) ~= nil, "A2: the keypress cast is still in the fired macro")
    assertTrue(macrotext:find("Tiger Palm", 1, true) ~= nil, "A2: the step's own cast is still in the fired macro")
    assertEqual(STEP_1, compiled[1].stepOwnText, "A2: stepOwnText is the step's own text, not the combined text")
end)

test("A3 (overflow branch): nothing is baked, stepOwnText is published anyway", function()
    local combinedLen = #(KEYPRESS_LONG .. "\n" .. STEP_1)
    local compiled = Engine:CompileSteps({ STEP_1, STEP_2 }, KEYPRESS_LONG, "")
    local _, btn = installSequence("A3_Seq", { STEP_1, STEP_2 }, compiled, 1)
    local ownText = compiled[1] and compiled[1].stepOwnText
    local displaySpell = parsed(Engine:GetExecStepDisplayText(btn, 1, nil))
    clearFixtures()

    assertTrue(combinedLen > 255, "A3 (witness): the fixture really does exceed the 255-char cap")
    assertEqual(STEP_1, compiled[1].macrotext, "A3: the overflow branch bakes no keypress into the macro")
    assertEqual(STEP_1, ownText, "A3: stepOwnText is published on the overflow branch too")
    assertEqual("Tiger Palm", displaySpell, "A3: the display still resolves the step's own spell")
end)

test("A4 (legacy array): an entry with no stepOwnText falls back to the old answer", function()
    -- An execution array compiled before the field existed -- a button cached
    -- across an upgrade, or a hand-built array. The fallback must return exactly
    -- what GetExecStepText returns, and must not raise on the missing field.
    local legacy = { { type = "macro", macrotext = KEYPRESS .. "\n" .. STEP_1 } }
    local btn = makeButton(legacy, 1)

    local ok, display = pcall(Engine.GetExecStepDisplayText, Engine, btn, 1, nil)
    local plain = Engine:GetExecStepText(btn, 1, nil)
    clearFixtures()

    assertTrue(ok, "A4: the accessor absorbed the missing field instead of raising: " .. tostring(display))
    assertEqual(nil, legacy[1].stepOwnText, "A4 (witness): the fixture really carries no stepOwnText")
    assertEqual(plain, display, "A4: the fallback returns exactly the plain accessor's answer")
    assertEqual(KEYPRESS .. "\n" .. STEP_1, display, "A4: that answer is the stored macrotext")
    assertEqual("Leg Sweep", parsed(display), "A4: which is the OLD display answer, unchanged and not raised on")
end)

test("A5 (unconditional keypress): a keypress with no conditional does not win either", function()
    -- This one reaches the parser's PREFERRED branch rather than its fallback:
    -- an unconditional cast outranks every conditional line no matter where it
    -- sits. The fix does not depend on which branch answered, because the
    -- keypress block is no longer part of the input at all.
    local compiled = Engine:CompileSteps({ STEP_1, STEP_2 }, KEYPRESS_UNCOND, "")
    local ver, btn = installSequence("A5_Seq", { STEP_1, STEP_2 }, compiled, 2)
    local drawn = installTrackerRow("A5_Seq")

    local combinedSpell = parsed(compiled[2].macrotext)
    local displaySpell = parsed(Engine:GetExecStepDisplayText(btn, 2, ver))

    TH:UpdateIcon("A5_Seq", 2, 2)
    local rowSpell = iconLookups[#iconLookups]
    local rowIcon = drawn[#drawn]
    clearFixtures()

    assertEqual("Leg Sweep", combinedSpell, "A5 (witness): the unconditional keypress cast ranks first in combined")
    assertEqual("Blackout Kick", displaySpell, "A5: the display resolves step 2's own spell")
    assertNotEqual("Leg Sweep", displaySpell, "A5: an unconditional keypress must not win the display")
    assertEqual("Blackout Kick", rowSpell, "A5: the real TrackerHUD row looked up step 2's own spell")
    assertEqual(ICON_IDS["Blackout Kick"], rowIcon, "A5: the row was given that spell's icon")
end)

test("A6 (BarIntegration wiring): the real BI:OnStepAdvanced resolves the step's own spell", function()
    -- ResolveSequenceIcon is file-local, so the helper cannot be called directly
    -- and stubbing a caller would prove nothing about the wiring. BI:OnStepAdvanced
    -- is the public entry point that reaches it, so that is what runs here.
    local compiled = Engine:CompileSteps({ STEP_1, STEP_2 }, KEYPRESS, "")
    installSequence("A6_Seq", { STEP_1, STEP_2 }, compiled, 1)
    installTrackedButton("A6_BarButton1", "A6_Seq")

    -- WITNESS: the combined text this entry fires still mis-ranks, so a green A6
    -- means the call site changed domain, not that the fixture stopped biting.
    local combinedSpell = parsed(compiled[1].macrotext)

    local ok, err = pcall(BI.OnStepAdvanced, BI, nil, "A6_Seq")
    local barSpell = iconLookups[#iconLookups]
    local lookupCount = #iconLookups
    clearFixtures()

    assertTrue(ok, "A6: BI:OnStepAdvanced raised: " .. tostring(err))
    assertEqual("Leg Sweep", combinedSpell, "A6 (witness): the combined text still ranks the keypress cast first")
    assertTrue(lookupCount > 0, "A6: the overlay path reached the icon lookup at all (guards did not swallow it)")
    assertEqual("Tiger Palm", barSpell, "A6: the bar overlay looked up the step's own spell")
    assertNotEqual("Leg Sweep", barSpell, "A6: the keypress spell must not win the bar overlay")
end)

test("A7 (UpdateButtonIcon wiring): the real Engine:UpdateButtonIcon resolves the step's own spell", function()
    -- The macro stub's own icon, the third of the four repointed consumers. Driven
    -- as the restricted environment drives it, through the public method.
    local compiled = Engine:CompileSteps({ STEP_1, STEP_2 }, KEYPRESS, "")
    local _, btn = installSequence("A7_Seq", { STEP_1, STEP_2 }, compiled, 2)

    local combinedSpell = parsed(compiled[2].macrotext)

    local ok, err = pcall(Engine.UpdateButtonIcon, Engine, btn, true)
    local stubSpell = iconLookups[#iconLookups]
    local lookupCount = #iconLookups
    clearFixtures()

    assertTrue(ok, "A7: Engine:UpdateButtonIcon raised: " .. tostring(err))
    assertEqual("Leg Sweep", combinedSpell, "A7 (witness): the combined text still ranks the keypress cast first")
    assertTrue(lookupCount > 0, "A7: the icon block ran at all (the OOCQueue guard did not swallow it)")
    assertEqual("Blackout Kick", stubSpell, "A7: the macro stub icon looked up step 2's own spell")
    assertNotEqual("Leg Sweep", stubSpell, "A7: the keypress spell must not win the stub icon")
end)

test("A8 (TrackerHUD Rebuild wiring): the real TH:Rebuild resolves the step's own spell", function()
    local compiled = Engine:CompileSteps({ STEP_1, STEP_2 }, KEYPRESS, "")
    installSequence("A8_Seq", { STEP_1, STEP_2 }, compiled, 1)
    -- Pre-seeding TH.icons makes Rebuild REUSE this row rather than build one, so
    -- the recording texture is the one the full rebuild writes to.
    local drawn = installTrackerRow("A8_Seq")
    TH.frame = frameStub
    -- Fast-path defence one of two: a latch that deliberately does NOT match the
    -- sorted list, so the unchanged-list test fails and Rebuild cannot return
    -- early. It is a table this case OWNS, which is what defence two reads.
    local sentinelLatch = { "A8_NoSuchSequence" }
    TH._lastSorted = sentinelLatch

    local combinedSpell = parsed(compiled[1].macrotext)

    local ok, err = pcall(TH.Rebuild, TH)
    -- The FIRST lookup of this run is the one the rebuild's own call site makes;
    -- it happens before the variant-indicator refresh at the foot of the loop, so
    -- reading the last entry would let a later consumer answer in its place.
    local hudSpell = iconLookups[1]
    local lookupCount = #iconLookups
    -- Fast-path defence two of two. IDENTITY, not existence: the full path assigns
    -- a NEW sorted table past the fast-path branch, so TH._lastSorted stops being
    -- the sentinel; the fast path returns above that assignment and leaves the
    -- sentinel exactly where this case put it. An existence check cannot tell the
    -- two apart, because a non-nil latch is the PRECONDITION for taking the fast
    -- path -- it would be satisfied in precisely the case it exists to detect.
    local rebuiltLatch = TH._lastSorted
    local rowIcon = drawn[#drawn]
    clearFixtures()

    assertTrue(ok, "A8: TH:Rebuild raised: " .. tostring(err))
    assertEqual("Leg Sweep", combinedSpell, "A8 (witness): the combined text still ranks the keypress cast first")
    assertNotEqual(
        sentinelLatch,
        rebuiltLatch,
        "A8: the FULL rebuild ran -- _lastSorted must be a NEW table assigned past the fast-path "
            .. "branch, so still being the sentinel means the case took the UpdateIcon fast path and "
            .. "never reached Rebuild's own call site"
    )
    assertTrue(lookupCount > 0, "A8: the rebuild reached the icon lookup at all (no guard swallowed the body)")
    assertEqual("Tiger Palm", hudSpell, "A8: the rebuilt tracker row looked up the step's own spell")
    assertNotEqual("Leg Sweep", hudSpell, "A8: the keypress spell must not win the rebuilt row")
    assertEqual(ICON_IDS["Tiger Palm"], rowIcon, "A8: the row was given that spell's icon")
end)

-- ---------------------------------------------------------------------------
-- Run.
-- ---------------------------------------------------------------------------

local passed = 0
local failed = 0
for _, t in ipairs(tests) do
    local ok, err = pcall(t.fn)
    if ok then
        passed = passed + 1
        print("PASS  " .. t.name)
    else
        failed = failed + 1
        print("FAIL  " .. t.name .. " -- " .. tostring(err))
    end
end
print(string.format("RESULT %d passed, %d failed", passed, failed))
os.exit(failed > 0 and 1 or 0)
