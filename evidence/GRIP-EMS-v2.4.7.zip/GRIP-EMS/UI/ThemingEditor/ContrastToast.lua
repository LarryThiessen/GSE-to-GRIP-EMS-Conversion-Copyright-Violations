-- GRIP-EMS: Per-Element Theming editor -- contrast-warning toast (Phase C)
--
-- Created:    2026-04-22
-- Updated:    2026-08-17
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
--
-- Single reused toast frame parented to UIParent, shown when
-- Theme.CheckAndWarn detects a class failing the WCAG 2.2 contrast
-- threshold. Snap-in (no slide animation, accessible-by-default).
--
-- Per-class 30-minute silence: Dismiss records GetServerTime()+1800 for
-- that class into profile.contrastSilence so the record survives /reload
-- and /logout. The user is not re-warned during a session or the
-- initial minutes of the next session. Auto-fix writes the proposed
-- color via Settings.db.profile.theming at the target slot returned by
-- Theme.CheckContrast, then clears the silence record (no-op if none
-- existed).
--
-- Warnings that arrive while another toast is on screen are queued by
-- class. One toast shows at a time; a "+N more" counter on the active
-- toast reports the pending depth. Dismiss and auto-fix both advance
-- to the next queued class; later warnings for the same class
-- overwrite the queued entry (always latest params).

local ADDON_NAME, GRIPEMS = ...

GRIPEMS.UI = GRIPEMS.UI or {}
local UI = GRIPEMS.UI
UI.ThemingEditor = UI.ThemingEditor or {}
local TE = UI.ThemingEditor

local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

local SILENCE_SECONDS = 30 * 60

local toast -- lazy-created frame
local pendingByClass = {} -- [class] = {messageText, autofixColor, fixTarget}
local queueOrder = {} -- FIFO list of classes awaiting render
local currentClass = nil -- class currently rendered on the live toast

---------------------------------------------------------------------------
-- Silence persistence helpers (SavedVariables-backed via
-- profile.contrastSilence). GetServerTime() is used for epoch values so
-- silence windows remain meaningful across /reload and /logout.
---------------------------------------------------------------------------
local function silenceGet(class)
    local S = GRIPEMS.Settings
    if not (S and S.db and S.db.profile and S.db.profile.contrastSilence) then
        return nil
    end
    return S.db.profile.contrastSilence[class]
end

local function silenceSet(class, epoch)
    local S = GRIPEMS.Settings
    if not (S and S.db and S.db.profile) then
        return
    end
    S.db.profile.contrastSilence = S.db.profile.contrastSilence or {}
    S.db.profile.contrastSilence[class] = epoch
end

local function silenceClear(class)
    local S = GRIPEMS.Settings
    if not (S and S.db and S.db.profile and S.db.profile.contrastSilence) then
        return
    end
    S.db.profile.contrastSilence[class] = nil
end

---------------------------------------------------------------------------
-- Per-render silence accessors used by the function-form leaves of
-- TE.BuildContrastSilenceArgs. AceConfigDialog re-evaluates leaf
-- properties (name/desc/hidden) on every refresh via NotifyChange, so
-- each helper does its own read of profile.contrastSilence and prunes
-- expired records on the fly. CLASS_SORT_ORDER is the deterministic
-- iteration order for the 13 retail classes used to pre-allocate slots
-- in the static args table; per-class hidden() callbacks gate visibility.
---------------------------------------------------------------------------
local CLASS_SORT_ORDER = {
    "DEATHKNIGHT",
    "DEMONHUNTER",
    "DRUID",
    "EVOKER",
    "HUNTER",
    "MAGE",
    "MONK",
    "PALADIN",
    "PRIEST",
    "ROGUE",
    "SHAMAN",
    "WARLOCK",
    "WARRIOR",
}

local function profileSilence()
    local S = GRIPEMS.Settings
    local s = S and S.db and S.db.profile and S.db.profile.contrastSilence
    if type(s) ~= "table" then
        return nil
    end
    return s
end

local function pruneSilence(s)
    if type(s) ~= "table" then
        return
    end
    local now = GetServerTime()
    for class, expiry in pairs(s) do
        if type(expiry) ~= "number" or expiry <= now then
            s[class] = nil
        end
    end
end

local function isClassSilenced(class)
    local s = profileSilence()
    if not s then
        return false
    end
    pruneSilence(s)
    return type(s[class]) == "number"
end

local function silenceMinutesRemaining(class)
    local s = profileSilence()
    if not s then
        return 0
    end
    pruneSilence(s)
    local expiry = s[class]
    if type(expiry) ~= "number" then
        return 0
    end
    local now = GetServerTime()
    local remaining = math.ceil((expiry - now) / 60)
    if remaining < 1 then
        return 1
    end
    return remaining
end

local function silenceCount()
    local s = profileSilence()
    if not s then
        return 0
    end
    pruneSilence(s)
    local n = 0
    for _ in pairs(s) do
        n = n + 1
    end
    return n
end

---------------------------------------------------------------------------
-- Bulk-clear helpers. runBulkClear is the single execute path used both
-- by the small-set immediate path (silenceCount() <= 3) and the
-- popup-confirmed large-set path. registerUnsilenceAllDialog lazy-
-- registers a StaticPopupDialogs template the first time the user
-- triggers a count > 3 unsilence-all -- mirrors the registerAcceptDialog
-- pattern in Core/ThemeTransport.lua.
---------------------------------------------------------------------------
local function runBulkClear()
    local s = profileSilence()
    if s then
        local toClear = {}
        for class in pairs(s) do
            toClear[#toClear + 1] = class
        end
        for _, class in ipairs(toClear) do
            TE.ClearContrastSilence(class)
        end
    end
    local reg = LibStub and LibStub("AceConfigRegistry-3.0", true)
    if reg and reg.NotifyChange then
        reg:NotifyChange("GRIP-EMS")
        reg:NotifyChange("GRIP-EMS-Theme")
    end
end

local function registerUnsilenceAllDialog()
    if GRIPEMS.Popup:GetDef("GRIPEMS_THEMING_CONFIRM_UNSILENCE_ALL") then
        return
    end
    GRIPEMS.Popup:Define("GRIPEMS_THEMING_CONFIRM_UNSILENCE_ALL", {
        text = L["ACCESS_THEMING_CONTRAST_SILENCE_UNSILENCE_ALL_CONFIRM"]
            or "Clear silence for all %d silenced classes? They will warn again on the next theme apply or /reload.",
        button1 = YES or "Yes",
        button2 = NO or "No",
        OnAccept = function(self, data)
            if data and type(data.run) == "function" then
                data.run()
            end
        end,
        timeout = 0,
        hideOnEscape = true,
    })
end

---------------------------------------------------------------------------
-- buildToast creates the reusable frame on first show. Uses UI.Backdrops
-- + UI:ApplyBackdrop so it picks up every future theme change via the
-- Theme.ApplyElement dispatch (registered as overlay.toast.warn).
---------------------------------------------------------------------------
local function buildToast()
    if toast then
        return toast
    end
    local f = CreateFrame("Frame", "GRIPEMS_ContrastToast", UIParent, "BackdropTemplate")
    f:SetSize(340, 120)
    f:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", -20, -120)
    f:SetFrameStrata("HIGH")
    f:SetFrameLevel((UIParent:GetFrameLevel() or 0) + 50)
    f:Hide()

    local C = UI.Colors or {}
    if UI.ApplyBackdrop and UI.Backdrops and UI.Backdrops.panel then
        UI:ApplyBackdrop(f, UI.Backdrops.panel, C.bgMain, C.border)
    end

    -- Pending-queue counter, top-center. Empty string when queue is empty.
    local counter = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    counter:SetPoint("TOP", f, "TOP", 0, -2)
    counter:SetJustifyH("CENTER")
    counter:SetText("")
    f.counter = counter

    -- Title
    local title = f:CreateFontString(nil, "OVERLAY", "ChatFontNormal")
    title:SetPoint("TOPLEFT", f, "TOPLEFT", 12, -10)
    title:SetPoint("TOPRIGHT", f, "TOPRIGHT", -12, -10)
    title:SetJustifyH("LEFT")
    if C.textPrimary and C.textPrimary.GetRGBA then
        title:SetTextColor(C.textPrimary:GetRGBA())
    end
    f.title = title

    -- Message body
    local msg = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    msg:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -6)
    msg:SetPoint("TOPRIGHT", title, "BOTTOMRIGHT", 0, -6)
    msg:SetJustifyH("LEFT")
    msg:SetWordWrap(true)
    f.msg = msg

    -- Dismiss button (left)
    local dismissBtn = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
    dismissBtn:SetSize(150, 22)
    dismissBtn:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 12, 10)
    dismissBtn:SetText(L["ACCESS_THEMING_CONTRAST_DISMISS"] or "Dismiss (30 min)")
    if dismissBtn.SetNormalTexture then
        dismissBtn:SetNormalTexture("")
    end
    if dismissBtn.SetHighlightTexture then
        dismissBtn:SetHighlightTexture("")
    end
    if dismissBtn.SetPushedTexture then
        dismissBtn:SetPushedTexture("")
    end
    if not dismissBtn.SetBackdrop then
        Mixin(dismissBtn, BackdropTemplateMixin)
    end
    if UI.ApplyBackdrop and UI.Backdrops and UI.Backdrops.panel then
        UI:ApplyBackdrop(dismissBtn, UI.Backdrops.panel, C.bgButton, C.border)
    end
    local dfs = dismissBtn:GetFontString()
    if dfs and C.textPrimary and C.textPrimary.GetRGBA then
        dfs:SetTextColor(C.textPrimary:GetRGBA())
    end
    f.dismissBtn = dismissBtn

    -- Auto-fix button (right)
    local autofixBtn = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
    autofixBtn:SetSize(150, 22)
    autofixBtn:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -12, 10)
    autofixBtn:SetText(L["ACCESS_THEMING_CONTRAST_AUTOFIX"] or "Auto-fix background")
    if autofixBtn.SetNormalTexture then
        autofixBtn:SetNormalTexture("")
    end
    if autofixBtn.SetHighlightTexture then
        autofixBtn:SetHighlightTexture("")
    end
    if autofixBtn.SetPushedTexture then
        autofixBtn:SetPushedTexture("")
    end
    if not autofixBtn.SetBackdrop then
        Mixin(autofixBtn, BackdropTemplateMixin)
    end
    if UI.ApplyBackdrop and UI.Backdrops and UI.Backdrops.panel then
        UI:ApplyBackdrop(autofixBtn, UI.Backdrops.panel, C.bgButton, C.border)
    end
    local afs = autofixBtn:GetFontString()
    if afs and C.textPrimary and C.textPrimary.GetRGBA then
        afs:SetTextColor(C.textPrimary:GetRGBA())
    end
    f.autofixBtn = autofixBtn

    if UI.RegisterElement then
        UI:RegisterElement(f, "overlay.toast.warn")
    end

    toast = f
    return f
end

---------------------------------------------------------------------------
-- updateCounter refreshes the "+N more" text on the toast based on the
-- current pending-queue depth. Empty string when the queue is empty so
-- the single active toast looks uncluttered.
---------------------------------------------------------------------------
local function updateCounter()
    if not (toast and toast.counter) then
        return
    end
    local n = #queueOrder
    if n >= 1 then
        local fmt = L["ACCESS_THEMING_CONTRAST_QUEUE_MORE"] or "+%d more"
        toast.counter:SetText(string.format(fmt, n))
    else
        toast.counter:SetText("")
    end
end

---------------------------------------------------------------------------
-- renderOne paints the toast for a single class. Extracted from
-- ShowContrastWarning so advance() and ShowContrastWarning share one
-- render path. autofixColor may be nil (low-alpha cases have no numeric
-- fix). fixTarget may be nil (ApplyAutoFix falls back to own class.bg).
---------------------------------------------------------------------------
local advance -- forward declaration; defined below.

local function renderOne(class, messageText, autofixColor, fixTarget)
    local f = buildToast()

    local label = (TE.FormatClassLabel and TE.FormatClassLabel(class)) or class
    local header = L["ACCESS_THEMING_CONTRAST_WARN_TITLE"] or "Contrast warning"
    f.title:SetText(header .. " -- " .. label)

    f.msg:SetText(messageText or "")

    f.dismissBtn:SetScript("OnClick", function()
        silenceSet(class, GetServerTime() + SILENCE_SECONDS)
        local reg = LibStub and LibStub("AceConfigRegistry-3.0", true)
        if reg and reg.NotifyChange then
            reg:NotifyChange("GRIP-EMS")
            reg:NotifyChange("GRIP-EMS-Theme")
        end
        f:Hide()
        advance()
    end)

    if autofixColor then
        f.autofixBtn:Enable()
        f.autofixBtn:SetScript("OnClick", function()
            local target = fixTarget or { class = class, field = "bg" }
            TE.ApplyAutoFix(target, autofixColor)
            f:Hide()
            advance()
        end)
    else
        f.autofixBtn:Disable()
        f.autofixBtn:SetScript("OnClick", nil)
    end

    updateCounter()
    f:Show()
end

---------------------------------------------------------------------------
-- advance pops the next queued class (if any) and renders it, or hides
-- the toast and clears currentClass when the queue is empty. Called from
-- dismiss/auto-fix OnClick handlers so a user who works through a burst
-- of warnings sees them one at a time in arrival order.
---------------------------------------------------------------------------
advance = function()
    if #queueOrder == 0 then
        currentClass = nil
        if toast then
            toast:Hide()
        end
        updateCounter()
        return
    end
    local nextClass = table.remove(queueOrder, 1)
    local entry = pendingByClass[nextClass]
    pendingByClass[nextClass] = nil
    currentClass = nextClass
    if entry then
        renderOne(nextClass, entry[1], entry[2], entry[3])
    else
        -- Defensive: queueOrder drifted from pendingByClass. Recurse to
        -- drain until we either find a valid entry or the queue empties.
        advance()
    end
end

---------------------------------------------------------------------------
-- ShowContrastWarning is the single public entry point called from
-- Theme.CheckAndWarn. Early-returns if the user has dismissed this class
-- within the SavedVariables-persisted silence window. Queues subsequent
-- warnings if a toast is already showing: the active toast is not
-- clobbered; the user dismisses or auto-fixes through the queue in
-- arrival order. autofixColor is a {r,g,b,a} proposed by Theme.proposeFix
-- or nil (low-alpha cases). fixTarget is a {class, field} table from
-- Theme.CheckContrast indicating which AceDB slot to write the auto-fix
-- color into; nil falls back to the reporting class's own bg.
---------------------------------------------------------------------------
function TE.ShowContrastWarning(class, messageText, autofixColor, fixTarget)
    if type(class) ~= "string" or class == "" then
        return
    end
    local until_ = silenceGet(class)
    if until_ and GetServerTime() < until_ then
        return
    end

    if currentClass ~= nil and toast and toast:IsShown() then
        if pendingByClass[class] == nil then
            tinsert(queueOrder, class)
        end
        pendingByClass[class] = { messageText, autofixColor, fixTarget }
        updateCounter()
        return
    end

    currentClass = class
    renderOne(class, messageText, autofixColor, fixTarget)
end

---------------------------------------------------------------------------
-- HideContrastToast hides the frame without recording a silence entry.
-- Clears the pending queue and the active class pointer so an explicit
-- close from outside the OnClick handlers does not leave stale state.
---------------------------------------------------------------------------
function TE.HideContrastToast()
    wipe(pendingByClass)
    for i = #queueOrder, 1, -1 do
        queueOrder[i] = nil
    end
    currentClass = nil
    if toast then
        toast:Hide()
        updateCounter()
    end
end

---------------------------------------------------------------------------
-- ClearContrastSilence drops a recorded silence for this class so a later
-- FAIL after the class was already fixed/unsilenced shows again.
---------------------------------------------------------------------------
function TE.ClearContrastSilence(class)
    if type(class) == "string" then
        silenceClear(class)
        local reg = LibStub and LibStub("AceConfigRegistry-3.0", true)
        if reg and reg.NotifyChange then
            reg:NotifyChange("GRIP-EMS")
            reg:NotifyChange("GRIP-EMS-Theme")
        end
    end
end

---------------------------------------------------------------------------
-- BuildContrastSilenceArgs returns a structurally STATIC AceConfig args
-- table for the silence-visibility inline group rendered inside the
-- Theming Editor settings tree. AceConfigDialog requires args to be a
-- table (the library source iterates `for k,v in pairs(group.args) do`),
-- so the structure is built once -- but every leaf property the user
-- sees (name, desc, hidden) is a closure that AceConfigDialog re-
-- evaluates on every NotifyChange via GetOptionsMemberValue. Net effect:
-- dismissing a toast or unsilencing a class updates the panel live with
-- no /reload required.
--
-- The 13 retail classes are pre-allocated in CLASS_SORT_ORDER so the
-- args structure never mutates after first build; per-slot hidden()
-- callbacks gate visibility against profile.contrastSilence at render
-- time. Expired records are pruned inside the helper accessors
-- (silenceCount / isClassSilenced / silenceMinutesRemaining) so the
-- table cannot grow unbounded across sessions where the user lets
-- entries time out instead of explicitly unsilencing.
--
-- Output shape:
--   desc           order=1     hidden when silenceCount() > 0.
--   class_<CLASS>  order=1..13 hidden when isClassSilenced(class) false;
--                              one slot per CLASS_SORT_ORDER entry.
--   unsilenceAll   order=100   hidden when silenceCount() == 0; sits
--                              past every class slot regardless of count.
---------------------------------------------------------------------------
function TE.BuildContrastSilenceArgs()
    local args = {}

    args.desc = {
        type = "description",
        name = function()
            return L["ACCESS_THEMING_CONTRAST_SILENCE_EMPTY"] or "No contrast warnings are currently silenced."
        end,
        order = 1,
        fontSize = "medium",
        hidden = function()
            return silenceCount() > 0
        end,
    }

    local unsilenceLabel = function()
        return L["ACCESS_THEMING_CONTRAST_SILENCE_UNSILENCE"] or "Unsilence"
    end
    local remainingFmt = function()
        return L["ACCESS_THEMING_CONTRAST_SILENCE_REMAINING"] or "%s -- %d minutes remaining"
    end

    for i, class in ipairs(CLASS_SORT_ORDER) do
        local capturedClass = class
        args["class_" .. class] = {
            type = "execute",
            name = unsilenceLabel,
            desc = function()
                local className = (LOCALIZED_CLASS_NAMES_MALE and LOCALIZED_CLASS_NAMES_MALE[capturedClass])
                    or capturedClass
                return string.format(remainingFmt(), className, silenceMinutesRemaining(capturedClass))
            end,
            order = i,
            hidden = function()
                return not isClassSilenced(capturedClass)
            end,
            func = function()
                TE.ClearContrastSilence(capturedClass)
            end,
        }
    end

    args.unsilenceAll = {
        type = "execute",
        name = function()
            return L["ACCESS_THEMING_CONTRAST_SILENCE_UNSILENCE_ALL"] or "Unsilence all"
        end,
        order = 100,
        hidden = function()
            return silenceCount() == 0
        end,
        func = function()
            local n = silenceCount()
            if n <= 3 then
                runBulkClear()
                return
            end
            registerUnsilenceAllDialog()
            local popup = GRIPEMS.Popup:Show("GRIPEMS_THEMING_CONFIRM_UNSILENCE_ALL", n, nil, { run = runBulkClear })
            if not popup then
                runBulkClear()
            end
        end,
    }

    return args
end

function TE.GetSilencedCount()
    return silenceCount()
end

---------------------------------------------------------------------------
-- ApplyAutoFix validates the proposed color, writes it to the profile
-- override at the target slot ({class, field} from Theme.CheckContrast),
-- fires Theme.RequestApply, and notifies both AceConfig apps (the
-- settings-tree editor and the modal) to redraw.
---------------------------------------------------------------------------
function TE.ApplyAutoFix(target, newColor)
    if
        type(target) ~= "table"
        or type(target.class) ~= "string"
        or type(target.field) ~= "string"
        or type(newColor) ~= "table"
    then
        return
    end
    local targetClass = target.class
    local targetField = target.field

    local Theme = GRIPEMS.Theme
    if Theme and Theme.ValidateSpec then
        local okV = Theme.ValidateSpec({
            version = 1,
            elements = { [targetClass] = { [targetField] = newColor } },
        })
        if not okV then
            return
        end
    end

    local S = GRIPEMS.Settings
    if not (S and S.db and S.db.profile) then
        return
    end
    S.db.profile.theming = S.db.profile.theming or { preset = "default", elements = {}, savedThemes = {} }
    S.db.profile.theming.elements = S.db.profile.theming.elements or {}
    S.db.profile.theming.elements[targetClass] = S.db.profile.theming.elements[targetClass] or {}
    S.db.profile.theming.elements[targetClass][targetField] = {
        newColor[1] or 0,
        newColor[2] or 0,
        newColor[3] or 0,
        (newColor[4] == nil) and 1 or newColor[4],
    }

    if Theme and Theme.RequestApply then
        Theme.RequestApply(targetClass)
    end

    local reg = LibStub and LibStub("AceConfigRegistry-3.0", true)
    if reg and reg.NotifyChange then
        reg:NotifyChange("GRIP-EMS")
        reg:NotifyChange("GRIP-EMS-Theme")
    end
end

-- end of UI/ThemingEditor/ContrastToast.lua
