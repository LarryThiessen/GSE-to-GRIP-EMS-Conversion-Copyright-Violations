-- GRIP-EMS: Main Window Frame
-- Created: 2025 (pre-stamping)
-- Updated: 2026-08-17
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
--
-- Split-panel main window with title bar, movable/resizable, position
-- persistence. Phase 2 #7: EnableKeyboard + OnKeyDown installed on the frame,
-- routing TAB / ENTER / SPACE / ESC / UP / DOWN / DELETE through GRIPEMS.Focus.
-- A MainFrame root context is pushed at Build time carrying the title-bar
-- buttons (closeBtn, minimizeBtn, settingsBtn). List-row UP/DOWN + DELETE are
-- dispatched through the list sub-region owned by GRIPEMS.Focus.

local ADDON_NAME, GRIPEMS = ...
local UI = GRIPEMS.UI
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

-- Upvalues for Defaults (available after Defaults.lua loads, which is before UI/)
local function D()
    return GRIPEMS.Defaults
end

-- ---------------------------------------------------------------------------
-- Tier 3 layout provider: "classic" (Plugin API Phase 1b)
--
-- The in-core layout provider that reproduces today's two-panel UI exactly.
-- Registered with GRIPEMS.API.UI at file load (bottom of this file). Its
-- callbacks delegate to the existing build/init/minimize behaviour so the
-- provider indirection is byte-for-byte identical to the pre-Phase-1b UI.
-- A modern provider (Phase 3) positions the host frames instead; classic
-- ignores them and drives leftPanel / rightPanel directly.
-- ---------------------------------------------------------------------------
local classicProvider = {
    id = "classic",
    name = "Classic",
    -- Panels are already built inside CreateMainFrame; nothing host-specific
    -- to do for classic at main-frame init.
    OnInitMainFrame = function(mainFrame, hosts) end,
    -- Classic panel init: list + editor + initial data load + Focus context.
    -- This is the original UI:InitPanels body, moved here verbatim so the
    -- dispatcher (UI:InitPanels below) can route to it.
    OnInitPanels = function(mainFrame, hosts)
        if GRIPEMS.SequenceList then
            GRIPEMS.SequenceList:Init(GRIPEMS_MainFrame.leftPanel)
        end
        if GRIPEMS.SequenceEditor then
            GRIPEMS.SequenceEditor:Init(GRIPEMS_MainFrame.rightPanel)
        end
        -- Initial data load
        if GRIPEMS.SequenceList then
            GRIPEMS.SequenceList:RefreshDataProvider()
        end
        -- Phase 3 follow-up: push the MainFrame Focus context here
        -- rather than in CreateMainFrame so SE.helpBtn is reachable
        -- (SequenceEditor:Init constructs helpBtn above, see
        -- UI/SequenceEditor.lua tabBar helpBtn block).
        local Focus = GRIPEMS.Focus
        if Focus and Focus.PushContext then
            local targets = {
                GRIPEMS_MainFrame.closeBtn,
                GRIPEMS_MainFrame.minimizeBtn,
                GRIPEMS_MainFrame.settingsBtn,
            }
            if GRIPEMS.SequenceEditor and GRIPEMS.SequenceEditor.helpBtn then
                targets[#targets + 1] = GRIPEMS.SequenceEditor.helpBtn
            end
            Focus:PushContext("MainFrame", targets)
        end
    end,
    -- Classic layout is static (frame anchors set at build time); nothing to
    -- re-apply on a layout pass.
    OnApplyLayout = function(context) end,
    OnMinimize = function(mainFrame)
        mainFrame.DoMinimize()
    end,
    OnRestore = function(mainFrame)
        mainFrame.DoRestore()
    end,
}

local VALID_ANCHORS = {
    TOPLEFT = true,
    TOP = true,
    TOPRIGHT = true,
    LEFT = true,
    CENTER = true,
    RIGHT = true,
    BOTTOMLEFT = true,
    BOTTOM = true,
    BOTTOMRIGHT = true,
}

---------------------------------------------------------------------------
-- Frame creation
---------------------------------------------------------------------------

--- Build the main GRIPEMS window. Called once at file load time.
local function CreateMainFrame()
    local C = UI.Colors
    local defaults = D()

    local frame = UI:ReclaimFrame("GRIPEMS_MainFrame", "Frame", UIParent, "BackdropTemplate")
    frame:SetSize(defaults.MAIN_FRAME_WIDTH, defaults.MAIN_FRAME_HEIGHT)
    frame:SetPoint("CENTER")
    frame:SetFrameStrata("HIGH")
    UI:ApplyBackdrop(frame, UI.Backdrops.panel, C.bgMain, C.border)
    if GRIPEMS.UI and GRIPEMS.UI.RegisterPanelFrame then
        GRIPEMS.UI:RegisterPanelFrame(frame, "panel", "panel.main")
    end
    frame:SetClampedToScreen(true)
    frame:Hide()

    -- ESC to close
    if not tContains(UISpecialFrames, "GRIPEMS_MainFrame") then
        tinsert(UISpecialFrames, "GRIPEMS_MainFrame")
    end

    -- Movable via title bar (set up below)
    frame:SetMovable(true)

    local function ComputeMaxBounds()
        local maxW = math.floor(UIParent:GetWidth() - 100)
        local maxH = math.floor(UIParent:GetHeight() - 100)
        if maxW < D().MAIN_FRAME_MIN_WIDTH then
            maxW = D().MAIN_FRAME_MIN_WIDTH
        end
        if maxH < D().MAIN_FRAME_MIN_HEIGHT then
            maxH = D().MAIN_FRAME_MIN_HEIGHT
        end
        return maxW, maxH
    end

    -- Resizable: min 720x640 keeps the rightPanel chrome chain renderable at the floor (Phase F).
    -- Max is UIParent dimensions minus 50 px on each side, recomputed on
    -- OnShow and on UI_SCALE_CHANGED / DISPLAY_SIZE_CHANGED so resolution
    -- and UI-scale changes pick up live without /reload.
    frame:SetResizable(true)
    do
        local maxW, maxH = ComputeMaxBounds()
        frame:SetResizeBounds(D().MAIN_FRAME_MIN_WIDTH, D().MAIN_FRAME_MIN_HEIGHT, maxW, maxH)
        -- Phase F: enforce new minimum on saved layouts. SetResizeBounds clamps future
        -- user-resizes but doesn't immediately resize the frame; saved sizes from before
        -- the MIN_HEIGHT bump (460) would render below the new floor (640) until user
        -- interacts. Force a SetSize bump-up to clear the saved-size legacy.
        local curW, curH = frame:GetWidth() or 720, frame:GetHeight() or D().MAIN_FRAME_MIN_HEIGHT
        frame:SetSize(math.max(curW, D().MAIN_FRAME_MIN_WIDTH), math.max(curH, D().MAIN_FRAME_MIN_HEIGHT))
    end

    ---------------------------------------------------------------------------
    -- Title bar (40px)
    ---------------------------------------------------------------------------
    local titleBar = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    titleBar:SetHeight(D().TITLE_BAR_HEIGHT)
    titleBar:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, 0)
    titleBar:SetPoint("TOPRIGHT", frame, "TOPRIGHT", 0, 0)
    UI:ApplyBackdrop(titleBar, UI.Backdrops.panelNoBorder, C.bgDeep)
    frame.titleBar = titleBar

    -- Make title bar the drag region
    titleBar:EnableMouse(true)
    titleBar:RegisterForDrag("LeftButton")
    titleBar:SetScript("OnDragStart", function()
        frame:StartMoving()
    end)
    titleBar:SetScript("OnDragStop", function()
        frame:StopMovingOrSizing()
    end)

    -- Title text
    local titleText = titleBar:CreateFontString(nil, "OVERLAY")
    UI:SetFont(titleText, 14, "OUTLINE")
    titleText:SetPoint("LEFT", titleBar, "LEFT", 12, 0)
    titleText:SetText(L["GEMS_UI_TITLE"])
    titleText:SetTextColor(C.gripGreen:GetRGBA())
    frame.titleText = titleText

    -- Version text
    local versionText = titleBar:CreateFontString(nil, "OVERLAY")
    UI:SetFont(versionText, 10)
    versionText:SetPoint("LEFT", titleText, "RIGHT", 8, 0)
    versionText:SetText("v" .. (GRIPEMS.version or "dev"))
    versionText:SetTextColor(C.textMuted:GetRGBA())
    frame.versionText = versionText

    -- Close button (themed dark-UI X)
    local closeBtn = CreateFrame("Button", nil, titleBar, "BackdropTemplate")
    closeBtn:SetSize(24, 24)
    UI:RegisterLargeTarget(closeBtn)
    closeBtn:SetPoint("TOPRIGHT", titleBar, "TOPRIGHT", -6, -8)
    UI:ApplyBackdrop(closeBtn, UI.Backdrops.panel, C.bgButton, C.border)
    local closeLbl = closeBtn:CreateFontString(nil, "OVERLAY")
    UI:SetFont(closeLbl, 14)
    closeLbl:SetPoint("CENTER", 0, 1)
    closeLbl:SetText("X")
    closeLbl:SetTextColor(C.textSecondary:GetRGBA())
    closeBtn:SetScript("OnClick", function()
        frame:Hide()
    end)
    closeBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.accent:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
        closeLbl:SetTextColor(C.textPrimary:GetRGBA())
    end)
    closeBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
        closeLbl:SetTextColor(C.textSecondary:GetRGBA())
    end)
    frame.closeBtn = closeBtn

    -- Minimize button (left of close button)
    local minimizeBtn = CreateFrame("Button", nil, titleBar, "BackdropTemplate")
    minimizeBtn:SetSize(24, 24)
    UI:RegisterLargeTarget(minimizeBtn)
    minimizeBtn:SetPoint("RIGHT", closeBtn, "LEFT", -4, 0)
    UI:ApplyBackdrop(minimizeBtn, UI.Backdrops.panel, C.bgButton, C.border)
    local minLbl = minimizeBtn:CreateFontString(nil, "OVERLAY")
    UI:SetFont(minLbl, 14)
    minLbl:SetPoint("CENTER", 0, 1)
    minLbl:SetText("_")
    minLbl:SetTextColor(C.textSecondary:GetRGBA())
    minimizeBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.accent:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
        minLbl:SetTextColor(C.textPrimary:GetRGBA())
    end)
    minimizeBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
        minLbl:SetTextColor(C.textSecondary:GetRGBA())
    end)
    frame.minimizeBtn = minimizeBtn
    frame.minimizeLbl = minLbl

    -- Settings button (left of minimize button)
    local settingsBtn = CreateFrame("Button", nil, titleBar, "BackdropTemplate")
    settingsBtn:SetSize(24, 24)
    UI:RegisterLargeTarget(settingsBtn)
    settingsBtn:SetPoint("RIGHT", minimizeBtn, "LEFT", -4, 0)
    UI:ApplyBackdrop(settingsBtn, UI.Backdrops.panel, C.bgButton, C.border)
    local settingsIcon = settingsBtn:CreateTexture(nil, "ARTWORK")
    settingsIcon:SetSize(16, 16)
    settingsIcon:SetPoint("CENTER")
    settingsIcon:SetTexture("Interface\\Icons\\INV_Misc_Gear_01")
    settingsIcon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    settingsBtn:SetScript("OnClick", function()
        if GRIPEMS.SettingsPanel then
            GRIPEMS.SettingsPanel:Open()
        end
    end)
    settingsBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.accent:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
        UI:ShowTooltip(self, L["GEMS_UI_SETTINGS_BTN"], L["GEMS_UI_SETTINGS_BTN_DESC"])
    end)
    settingsBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
        UI:HideTooltip()
    end)
    frame.settingsBtn = settingsBtn

    ---------------------------------------------------------------------------
    -- Resize grip (bottom-right corner)
    ---------------------------------------------------------------------------
    local resizeGrip = CreateFrame("Button", nil, frame)
    resizeGrip:SetSize(16, 16)
    resizeGrip:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -2, 2)
    resizeGrip:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    resizeGrip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    resizeGrip:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
    UI:RegisterLargeTarget(resizeGrip, "br")
    resizeGrip:SetScript("OnMouseDown", function()
        frame:StartSizing("BOTTOMRIGHT")
    end)
    resizeGrip:SetScript("OnMouseUp", function()
        frame:StopMovingOrSizing()
        UI:SaveMainFrameSize()
    end)
    resizeGrip:SetScript("OnEnter", function(self)
        UI:ShowTooltip(self, L["GEMS_UI_RESIZE"], L["GEMS_UI_RESIZE_DESC"])
    end)
    resizeGrip:SetScript("OnLeave", function()
        UI:HideTooltip()
    end)
    frame.resizeGrip = resizeGrip

    ---------------------------------------------------------------------------
    -- Left panel (fixed 280px default, bgPanel color)
    ---------------------------------------------------------------------------
    local leftPanel = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    leftPanel:SetWidth(D().LEFT_PANEL_WIDTH)
    leftPanel:SetPoint("TOPLEFT", frame, "TOPLEFT", 1, -D().TITLE_BAR_HEIGHT)
    leftPanel:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 1, 1)
    UI:ApplyBackdrop(leftPanel, UI.Backdrops.panel, C.bgPanel, C.border)
    frame.leftPanel = leftPanel

    -- Placeholder text for left panel
    local leftPlaceholder = leftPanel:CreateFontString(nil, "OVERLAY")
    UI:SetFont(leftPlaceholder, 11)
    leftPlaceholder:SetPoint("CENTER")
    leftPlaceholder:SetText(L["GEMS_UI_SEQUENCE_LIST_PLACEHOLDER"])
    leftPlaceholder:SetTextColor(C.textMuted:GetRGBA())
    frame.leftPlaceholder = leftPlaceholder

    ---------------------------------------------------------------------------
    -- Divider (4px wide, between panels)
    ---------------------------------------------------------------------------
    local divider = CreateFrame("Frame", nil, frame)
    divider:SetWidth(4)
    divider:SetPoint("TOPLEFT", leftPanel, "TOPRIGHT", 0, 0)
    divider:SetPoint("BOTTOMLEFT", leftPanel, "BOTTOMRIGHT", 0, 0)
    frame.divider = divider

    ---------------------------------------------------------------------------
    -- Right panel (fills remaining space)
    ---------------------------------------------------------------------------
    local rightPanel = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    rightPanel:SetPoint("TOPLEFT", divider, "TOPRIGHT", 0, 0)
    rightPanel:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -1, 1)
    UI:ApplyBackdrop(rightPanel, UI.Backdrops.panelNoBorder, C.bgMain)
    frame.rightPanel = rightPanel

    -- Placeholder text for right panel
    local rightPlaceholder = rightPanel:CreateFontString(nil, "OVERLAY")
    UI:SetFont(rightPlaceholder, 12)
    rightPlaceholder:SetPoint("CENTER")
    rightPlaceholder:SetText(L["GEMS_UI_SELECT_SEQUENCE"])
    rightPlaceholder:SetTextColor(C.textMuted:GetRGBA())
    frame.rightPlaceholder = rightPlaceholder

    ---------------------------------------------------------------------------
    -- Tier 3 layout host frames (Plugin API Phase 1b)
    ---------------------------------------------------------------------------
    -- Seven plain (non-secure) Frame hosts a layout provider can mount panels
    -- into. Created empty + hidden with no layout role in classic: the classic
    -- provider positions leftPanel/rightPanel directly and never touches these.
    -- A modern provider positions and shows only the hosts it needs.
    --
    -- SAFETY GATE (design risk #1): hosts are plain "Frame" objects and a
    -- provider may reparent them, so NO secure template and NO secure-button
    -- descendant may ever live under a host. Secure buttons stay on the
    -- GRIPEMS_MainFrame root (or outside the MainFrame subtree entirely).
    frame.hosts = {}
    for _, hostName in ipairs({
        "navHost",
        "listHost",
        "metadataHost",
        "editorHost",
        "configHost",
        "globalViewHost",
        "iconFooterHost",
    }) do
        local h = CreateFrame("Frame", nil, frame)
        h:SetSize(1, 1)
        h:Hide()
        frame.hosts[hostName] = h
    end

    ---------------------------------------------------------------------------
    -- Minimize / Restore
    ---------------------------------------------------------------------------
    frame.minimized = false
    frame.restoreHeight = nil

    local function DoMinimize()
        frame.restoreHeight = frame:GetHeight()
        frame:SetResizable(false)
        frame:SetHeight(defaults.MINIMIZED_HEIGHT)
        leftPanel:Hide()
        rightPanel:Hide()
        divider:Hide()
        resizeGrip:Hide()
        minLbl:SetText("[ ]")
        frame.minimized = true
    end

    local function DoRestore()
        frame:SetHeight(frame.restoreHeight or defaults.MAIN_FRAME_HEIGHT)
        frame:SetResizable(true)
        do
            local maxW, maxH = ComputeMaxBounds()
            frame:SetResizeBounds(D().MAIN_FRAME_MIN_WIDTH, D().MAIN_FRAME_MIN_HEIGHT, maxW, maxH)
        end
        leftPanel:Show()
        rightPanel:Show()
        divider:Show()
        resizeGrip:Show()
        minLbl:SetText("_")
        frame.minimized = false
    end

    minimizeBtn:SetScript("OnClick", function()
        -- Route minimize/restore through the active layout provider (Plugin API
        -- Phase 1b). The classic provider delegates to DoMinimize/DoRestore, so
        -- the classic UI is unchanged; the direct calls remain as a fallback.
        local provider = GRIPEMS.ResolveActiveLayoutProvider and GRIPEMS:ResolveActiveLayoutProvider()
        if frame.minimized then
            if provider and provider.OnRestore then
                provider.OnRestore(frame)
            else
                DoRestore()
            end
        else
            if provider and provider.OnMinimize then
                provider.OnMinimize(frame)
            else
                DoMinimize()
            end
        end
        -- Persist state
        local sv = GRIP_EMS_CHAR and GRIP_EMS_CHAR.ui and GRIP_EMS_CHAR.ui.mainFrame
        if sv then
            sv.minimized = frame.minimized
        end
    end)

    frame.DoMinimize = DoMinimize
    frame.DoRestore = DoRestore

    ---------------------------------------------------------------------------
    -- Layout update on resize
    ---------------------------------------------------------------------------
    frame:SetScript("OnSizeChanged", function(self, width, height)
        -- Left panel stays fixed width, right panel adjusts automatically via anchors
    end)

    ---------------------------------------------------------------------------
    -- Position/size persistence
    ---------------------------------------------------------------------------
    frame:SetScript("OnHide", function(self)
        local sv = GRIP_EMS_CHAR and GRIP_EMS_CHAR.ui and GRIP_EMS_CHAR.ui.mainFrame
        if not sv then
            return
        end
        local point, _, _, x, y = self:GetPoint(1)
        sv.point = point
        sv.x = x
        sv.y = y
        if not self.minimized then
            sv.width = self:GetWidth()
            sv.height = self:GetHeight()
        end
        sv.minimized = self.minimized
    end)

    ---------------------------------------------------------------------------
    -- Phase 2 #7: keyboard-first navigation
    ---------------------------------------------------------------------------
    -- EnableKeyboard + OnKeyDown routes TAB / ENTER / SPACE / ESC / UP / DOWN /
    -- DELETE through GRIPEMS.Focus. Combat-lockdown guard at the top prevents
    -- protected-call taint; editBox-focus short-circuit lets typing pass
    -- through. Propagation toggles via pcall so a combat taint cannot throw
    -- out of the handler. Mirrors the SequenceEditor parentPanel OnKeyDown handler.
    frame:EnableKeyboard(true)
    frame:SetScript("OnKeyDown", function(self, key)
        if InCombatLockdown() then
            return
        end
        -- Suspenders layer: independent of the Focus flag, query WoW
        -- directly for any focused EditBox. If found, propagate the key
        -- and let the EditBox handle it.
        if GetCurrentKeyBoardFocus and GetCurrentKeyBoardFocus() then
            pcall(self.SetPropagateKeyboardInput, self, true)
            return
        end
        local Focus = GRIPEMS.Focus
        if Focus:IsEditBoxFocused() then
            pcall(self.SetPropagateKeyboardInput, self, true)
            return
        end
        if key == "TAB" then
            Focus:Cycle(IsShiftKeyDown() and -1 or 1)
            pcall(self.SetPropagateKeyboardInput, self, false)
            return
        elseif key == "UP" or key == "DOWN" then
            Focus:CycleListRow((key == "DOWN") and 1 or -1)
            pcall(self.SetPropagateKeyboardInput, self, false)
            return
        elseif key == "SPACE" then
            -- Dead-key fix: only consume SPACE when the focus cursor actually
            -- activated something. With no cursor (mouse-only use), SPACE must
            -- reach the game so jump works, even with the window up.
            if Focus:Activate() then
                pcall(self.SetPropagateKeyboardInput, self, false)
            else
                pcall(self.SetPropagateKeyboardInput, self, true)
            end
            return
        elseif key == "ENTER" then
            -- ENTER always reaches the game so chat opens. A focused EditBox
            -- is handled by the EditBox guards above. Keyboard activation of a
            -- focused widget is on SPACE.
            pcall(self.SetPropagateKeyboardInput, self, true)
            return
        elseif key == "DELETE" then
            Focus:Delete()
            pcall(self.SetPropagateKeyboardInput, self, false)
            return
        elseif key == "ESCAPE" then
            Focus:Clear()
            pcall(self.SetPropagateKeyboardInput, self, true)
            return
        end
        pcall(self.SetPropagateKeyboardInput, self, true)
    end)

    -- Re-enable key propagation when leaving combat. Mirrors the
    -- SequenceEditor PLAYER_REGEN_ENABLED propagation reset.
    frame:RegisterEvent("PLAYER_REGEN_ENABLED")
    frame:RegisterEvent("UI_SCALE_CHANGED")
    frame:RegisterEvent("DISPLAY_SIZE_CHANGED")
    frame:HookScript("OnEvent", function(self, event)
        if event == "PLAYER_REGEN_ENABLED" then
            pcall(self.SetPropagateKeyboardInput, self, true)
        elseif event == "UI_SCALE_CHANGED" or event == "DISPLAY_SIZE_CHANGED" then
            if not self.minimized then
                local maxW, maxH = ComputeMaxBounds()
                self:SetResizeBounds(D().MAIN_FRAME_MIN_WIDTH, D().MAIN_FRAME_MIN_HEIGHT, maxW, maxH)
            end
        end
    end)

    -- Reset propagation on Show. Mirrors the SequenceEditor OnShow propagation reset.
    -- Also recompute max-resize bounds against the current viewport so
    -- between-session resolution / UI-scale changes pick up at next open.
    frame:HookScript("OnShow", function(self)
        if not self.minimized then
            local maxW, maxH = ComputeMaxBounds()
            self:SetResizeBounds(D().MAIN_FRAME_MIN_WIDTH, D().MAIN_FRAME_MIN_HEIGHT, maxW, maxH)
        end
        -- v2.1.5 (Error 3 fix): SetPropagateKeyboardInput is protected during combat AND
        -- during ChallengeMode/Encounter/PvPMatch addon-restriction lockdowns. The pcall
        -- catches the throw but ADDON_ACTION_BLOCKED still fires. Gate matches the v2.1.1
        -- SequenceEditor fix shape; extends to AddOnRestrictionType lockdowns via OOCQueue.
        if not InCombatLockdown() and not GRIPEMS.OOCQueue:IsRestricted() then
            pcall(self.SetPropagateKeyboardInput, self, true)
        end
        if GRIPEMS.Tutorial and GRIPEMS.Tutorial.MaybeStart then
            pcall(function()
                GRIPEMS.Tutorial:MaybeStart()
            end)
        end
    end)

    -- Clear the Focus cursor on hide (MainFrame context itself stays pushed
    -- for the addon lifetime so subsequent Shows keep TAB nav).
    frame:HookScript("OnHide", function()
        GRIPEMS.Focus:Clear()
    end)

    -- Simplified Mode (Phase S2): drop per-widget activation lockouts on
    -- hide so a re-open or profile swap starts with a fresh activation
    -- map. HookScript keeps the existing Focus:Clear hook intact.
    frame:HookScript("OnHide", function()
        if GRIPEMS.Focus and GRIPEMS.Focus.ClearActivationLockouts then
            pcall(GRIPEMS.Focus.ClearActivationLockouts, GRIPEMS.Focus)
        end
    end)

    -- MainFrame Focus context push moved to UI:InitPanels so SE.helpBtn
    -- (constructed inside SequenceEditor:Init) is reachable via TAB.

    return frame
end

---------------------------------------------------------------------------
-- Initialize: create the frame
---------------------------------------------------------------------------
local mainFrame

---------------------------------------------------------------------------
-- Size persistence (AceDB profile-scoped)
---------------------------------------------------------------------------

--- Persist the current main frame size to EMS.db.profile.mainFrame.size.
--- Called from the bottom-right resize grip OnMouseUp.
function UI:SaveMainFrameSize()
    if not mainFrame then
        return
    end
    local S = GRIPEMS.Settings
    if not (S and S.db and S.db.profile and S.db.profile.mainFrame and S.db.profile.mainFrame.size) then
        return
    end
    S.db.profile.mainFrame.size.width = mainFrame:GetWidth()
    S.db.profile.mainFrame.size.height = mainFrame:GetHeight()
end

--- Restore main frame size from EMS.db.profile.mainFrame.size. Called at
--- frame init AFTER RestoreMainFramePosition so profile-scoped size wins.
function UI:RestoreMainFrameSize()
    if not mainFrame then
        return
    end
    local S = GRIPEMS.Settings
    if not (S and S.db and S.db.profile and S.db.profile.mainFrame and S.db.profile.mainFrame.size) then
        return
    end
    local w = S.db.profile.mainFrame.size.width
    local h = S.db.profile.mainFrame.size.height
    if w and h then
        mainFrame:SetSize(w, h)
    end
end

---------------------------------------------------------------------------
-- Position restore (called from Core.lua on PLAYER_LOGIN)
---------------------------------------------------------------------------

--- Restore saved window position and size from SavedVariables.
function UI:RestoreMainFramePosition()
    local sv = GRIP_EMS_CHAR and GRIP_EMS_CHAR.ui and GRIP_EMS_CHAR.ui.mainFrame
    if not sv then
        return
    end

    local defaults = D()
    local width = sv.width or defaults.MAIN_FRAME_WIDTH
    local height = sv.height or defaults.MAIN_FRAME_HEIGHT

    -- Clamp to minimum size
    if width < defaults.MAIN_FRAME_MIN_WIDTH then
        width = defaults.MAIN_FRAME_MIN_WIDTH
    end
    if height < defaults.MAIN_FRAME_MIN_HEIGHT then
        height = defaults.MAIN_FRAME_MIN_HEIGHT
    end

    mainFrame:SetSize(width, height)

    if sv.point and sv.x and sv.y and VALID_ANCHORS[sv.point] then
        mainFrame:ClearAllPoints()
        mainFrame:SetPoint(sv.point, UIParent, sv.point, sv.x, sv.y)
    end

    -- Restore minimized state
    if sv.minimized and mainFrame.DoMinimize then
        mainFrame.restoreHeight = height
        mainFrame.DoMinimize()
    end
end

---------------------------------------------------------------------------
-- Toggle function
---------------------------------------------------------------------------

--- Initialize panel content for the active layout provider (Plugin API Phase
--- 1b dispatcher). Resolves the active provider (default "classic"), runs
--- OnInitMainFrame then OnInitPanels -- falling back to the classic provider on
--- any OnInitPanels error -- then fires GEMS_UI_READY. Called from
--- UI:ToggleMainFrame() on first open (lazy-create). The classic body lives on
--- classicProvider.OnInitPanels (defined at the top of this file).
function UI:InitPanels()
    local provider = GRIPEMS:ResolveActiveLayoutProvider() or classicProvider
    if provider.OnInitMainFrame then
        pcall(provider.OnInitMainFrame, GRIPEMS_MainFrame, GRIPEMS_MainFrame.hosts)
    end
    if provider == classicProvider then
        -- Classic runs directly (no pcall): a failure must propagate exactly as
        -- the pre-Phase-1b UI:InitPanels did. Routing it through the pcall +
        -- classic fallback below would re-run the same body on a mid-init error
        -- and double-init the panels (duplicate :Init + a second
        -- Focus:PushContext("MainFrame")).
        provider.OnInitPanels(GRIPEMS_MainFrame, GRIPEMS_MainFrame.hosts)
    else
        local ok = pcall(provider.OnInitPanels, GRIPEMS_MainFrame, GRIPEMS_MainFrame.hosts)
        if not ok then
            GRIPEMS:Debug("layout provider OnInitPanels failed; falling back to classic")
            classicProvider.OnInitPanels(GRIPEMS_MainFrame, GRIPEMS_MainFrame.hosts)
        end
    end
    GRIPEMS:Fire("GEMS_UI_READY")
    if GRIPEMS.ReconcileOrphanSettingBases then
        GRIPEMS.ReconcileOrphanSettingBases()
    end
end

--- Apply the active layout provider's positioning pass. Builds a read-only
--- context snapshot (scalars + shown booleans only -- no live frame handles
--- beyond the IsShown reads) and hands it to provider.OnApplyLayout in pcall,
--- then fires GEMS_UI_LAYOUT_APPLY. Classic's OnApplyLayout is a no-op (its
--- layout is static frame anchors), so this is inert for the classic UI.
function UI:ApplyLayout()
    local provider = GRIPEMS:ResolveActiveLayoutProvider() or classicProvider
    local mf = _G.GRIPEMS_MainFrame
    local SE = GRIPEMS.SequenceEditor
    local context = {
        navId = nil, -- classic has no nav region; a modern provider supplies this
        editorTab = SE and SE.activeTab or nil,
        selectedSequence = SE and SE.currentSequence or nil,
        panelVisibility = {
            left = (mf and mf.leftPanel and mf.leftPanel:IsShown()) or false,
            right = (mf and mf.rightPanel and mf.rightPanel:IsShown()) or false,
        },
        previewMode = (GRIPEMS.Settings and GRIPEMS.Settings:Get("previewMode")) or nil,
        frameWidth = (mf and mf:GetWidth()) or nil,
        frameHeight = (mf and mf:GetHeight()) or nil,
    }
    if provider.OnApplyLayout then
        pcall(provider.OnApplyLayout, context)
    end
    GRIPEMS:Fire("GEMS_UI_LAYOUT_APPLY")
end

--- Toggle the main window open/closed (lazy-creates on first open).
function UI:ToggleMainFrame()
    if not mainFrame then
        mainFrame = CreateMainFrame()
        UI:RestoreMainFramePosition()
        UI:RestoreMainFrameSize()
        UI:InitPanels()
        UI:ApplyLayout()
        -- Register with ConsolePort cursor navigation (nil-safe)
        if ConsolePort and ConsolePort.AddInterfaceCursorFrame then
            ConsolePort:AddInterfaceCursorFrame(mainFrame)
        end
    end
    if GRIPEMS_MainFrame:IsShown() then
        GRIPEMS_MainFrame:Hide()
    else
        GRIPEMS_MainFrame:Show()
    end
end

---------------------------------------------------------------------------
-- Addon Compartment functions (declared in TOC, implemented here)
---------------------------------------------------------------------------

--- Called when the addon compartment button is clicked.
function GRIPEMS_OnCompartmentClick(addonName, buttonName)
    if buttonName == "RightButton" then
        MenuUtil.CreateContextMenu(nil, function(_, rootDescription)
            rootDescription:CreateTitle(L["GEMS_UI_TITLE"])
            rootDescription:CreateButton(L["GEMS_UI_REMOTE_BROWSER_TITLE"], function()
                if GRIPEMS.RemoteBrowser then
                    GRIPEMS.RemoteBrowser:Toggle()
                end
            end)
        end)
        return
    end
    UI:ToggleMainFrame()
end

--- Called when the mouse enters the addon compartment button.
function GRIPEMS_OnCompartmentEnter(addonName, menuButtonFrame)
    GameTooltip:SetOwner(menuButtonFrame, "ANCHOR_LEFT")
    GameTooltip:AddDoubleLine(
        "|cFF00CC66GRIP|r - Enhanced Macro Sequencer",
        "v" .. (GRIPEMS.version or "dev"),
        1,
        1,
        1,
        0.6,
        0.6,
        0.6
    )
    GameTooltip:AddLine(" ")
    local count = 0
    if GRIPEMS.Engine and GRIPEMS.Engine.GetActiveCount then
        count = GRIPEMS.Engine:GetActiveCount()
    end
    GameTooltip:AddDoubleLine(L["GEMS_UI_ACTIVE_SEQUENCES_LABEL"], tostring(count), 0.8, 0.8, 0.8, 0, 0.8, 0.4)
    if GRIPEMS.Engine and GRIPEMS.Engine.currentContext then
        GameTooltip:AddDoubleLine(
            L["GEMS_UI_CONTEXT_LABEL"],
            GRIPEMS.Engine.currentContext or "none",
            0.8,
            0.8,
            0.8,
            0,
            0.8,
            0.4
        )
    end
    GameTooltip:AddLine(" ")
    GameTooltip:AddLine(L["GEMS_UI_MINIMAP_LEFT"], 0.5, 0.5, 0.5)
    GameTooltip:Show()
end

--- Called when the mouse leaves the addon compartment button.
function GRIPEMS_OnCompartmentLeave(addonName, menuButtonFrame)
    GameTooltip:Hide()
end

---------------------------------------------------------------------------
-- Simplified Mode title-bar collapse (Phase S2)
---------------------------------------------------------------------------

--- Apply or revert the Simplified Mode title-bar collapse. When flag=true,
--- hide the minimize and settings buttons and enlarge the close button to
--- a 56x56 switch-user target. When flag=false, restore the default
--- 24x24 close button alongside minimize and settings.
--- Idempotent: safe to call repeatedly.
--- @param flag boolean True = collapse to a single close target.
function UI:ApplySimplifiedTitleBar(flag)
    local frame = _G.GRIPEMS_MainFrame
    if not frame then
        return
    end
    local size = flag and 56 or 24
    if frame.closeBtn and frame.closeBtn.SetSize then
        frame.closeBtn:SetSize(size, size)
    end
    if frame.minimizeBtn and frame.minimizeBtn.SetShown then
        frame.minimizeBtn:SetShown(not flag)
    end
    if frame.settingsBtn and frame.settingsBtn.SetShown then
        frame.settingsBtn:SetShown(not flag)
    end
end

---------------------------------------------------------------------------
-- Register the in-core "classic" layout provider (Plugin API Phase 1b).
-- PublicAPI.lua loads before this file per the TOC, so GRIPEMS.API.UI exists
-- here. SetActiveLayoutProvider is never called at load -- the resolver falls
-- back to the "classic" default, so the classic UI is the boot state.
---------------------------------------------------------------------------
if GRIPEMS.API and GRIPEMS.API.UI then
    GRIPEMS.API.UI:RegisterLayoutProvider("classic", classicProvider)
end
