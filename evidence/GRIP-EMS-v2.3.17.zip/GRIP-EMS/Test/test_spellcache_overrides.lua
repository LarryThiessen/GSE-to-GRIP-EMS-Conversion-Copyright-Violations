-- GRIP-EMS: Headless test for SC:ApplySpellOverrides
--
-- Created:    2026-07-16
-- Updated:    2026-07-16
-- Patch: 12.0.7 Midnight (Retail LIVE)
--
-- Standalone (Lua 5.1) test for Data/SpellCache.lua's shared spell-name
-- override apply/revert path, the single path behind the cache build and both
-- SpellCacheViewer edit paths. Drives the REAL SpellCache module via loadfile
-- + setfenv into a sandbox that stubs CreateFrame, C_Timer, LibStub, strlower
-- and a fake GRIPEMS namespace, the same technique as
-- test_spellvalidator_refresh_gate.lua. Keeping the stubs as fields on a local env
-- table (never global assignments) keeps the file luacheck-clean under the
-- read-only WoW std.
--
-- Run from the EMS root:  lua Test/test_spellcache_overrides.lua
-- Exit code 0 = all passed, 1 = at least one failure.
--
-- Cases:
--   T1  no overrides       -> nothing touched, changed=false
--   T2  one override       -> originalName captured, name rewritten, byName
--                             re-keyed, list re-sorted
--   T3  repeat call        -> idempotent, changed=false, originalName intact
--   T4  override removed   -> name reverts to base, originalName cleared,
--                             byName restored
--   T5  collision + revert -> a spell renamed onto another spell's name must
--                             not leave that spell orphaned out of byName once
--                             the override is cleared

local ADDON_NAME = "GRIP-EMS"

-- ---------------------------------------------------------------------------
-- Minimal assertion + runner harness (mirrors TestSuite Pass/Fail semantics).
-- ---------------------------------------------------------------------------

local tests = {}

local function test(name, fn)
    tests[#tests + 1] = { name = name, fn = fn }
end

local function assertEqual(expected, actual, label)
    if expected ~= actual then
        error((label or "value") .. ": expected " .. tostring(expected) .. ", got " .. tostring(actual), 2)
    end
end

local function assertTrue(cond, label)
    if not cond then
        error((label or "condition") .. ": expected true", 2)
    end
end

-- ---------------------------------------------------------------------------
-- Sandbox: load the real Data/SpellCache.lua.
-- ---------------------------------------------------------------------------

local env = setmetatable({}, { __index = _G })
env.strlower = string.lower
env.wipe = function(t)
    for k in pairs(t) do
        t[k] = nil
    end
end
env.CreateFrame = function()
    return {
        SetScript = function() end,
        RegisterEvent = function() end,
        UnregisterEvent = function() end,
        UnregisterAllEvents = function() end,
        Show = function() end,
        Hide = function() end,
    }
end
env.C_Timer = {
    After = function(_, f)
        if f then
            f()
        end
    end,
}
env.LibStub = function()
    return {
        GetLocale = function()
            return setmetatable({}, {
                __index = function(_, k)
                    return k
                end,
            })
        end,
        NewLibrary = function()
            return nil
        end,
        GetLibrary = function()
            return nil
        end,
    }
end

local GRIPEMS = {
    Debug = function() end,
    Print = function() end,
    Fire = function() end,
}

-- loadfile is dev-harness file I/O, intentionally outside the addon WoW std.
-- selene: allow(undefined_variable)
local chunk = assert(loadfile("Data/SpellCache.lua"))
setfenv(chunk, env)
chunk(ADDON_NAME, GRIPEMS)

local SC = GRIPEMS.SpellCache
assert(SC and SC.ApplySpellOverrides, "SC:ApplySpellOverrides missing")

local overrides = {}
GRIPEMS.Settings = { db = { profile = { spellOverrides = overrides } } }

-- Arcane Shot(1), Barbed Shot(2), Cobra Shot(3) -- already alphabetical.
local function reset()
    SC.spells = {
        { name = "Arcane Shot", spellID = 1 },
        { name = "Barbed Shot", spellID = 2 },
        { name = "Cobra Shot", spellID = 3 },
    }
    SC.byName = {}
    for _, e in ipairs(SC.spells) do
        SC.byName[string.lower(e.name)] = e
    end
    for k in pairs(overrides) do
        overrides[k] = nil
    end
end

local function names()
    local out = {}
    for _, e in ipairs(SC.spells) do
        out[#out + 1] = e.name
    end
    return table.concat(out, " | ")
end

local function entryFor(spellID)
    for _, e in ipairs(SC.spells) do
        if e.spellID == spellID then
            return e
        end
    end
    return nil
end

-- ---------------------------------------------------------------------------
-- Cases.
-- ---------------------------------------------------------------------------

test("T1 no overrides -- nothing touched", function()
    reset()
    local changed = SC:ApplySpellOverrides()
    assertEqual(false, changed, "changed")
    assertEqual("Arcane Shot | Barbed Shot | Cobra Shot", names(), "names")
end)

test("T2 one override -- capture, rewrite, re-key, re-sort", function()
    reset()
    overrides[2] = "Zulu Shot"
    local changed = SC:ApplySpellOverrides()
    local e = entryFor(2)
    assertEqual(true, changed, "changed")
    assertEqual("Zulu Shot", e.name, "name")
    assertEqual("Barbed Shot", e.originalName, "originalName")
    assertTrue(SC.byName["zulu shot"] == e, "byName re-keyed to custom name")
    assertEqual(nil, SC.byName["barbed shot"], "old byName key dropped")
    assertEqual("Arcane Shot | Cobra Shot | Zulu Shot", names(), "re-sorted")
end)

test("T3 repeat call -- idempotent", function()
    reset()
    overrides[2] = "Zulu Shot"
    SC:ApplySpellOverrides()
    local changed = SC:ApplySpellOverrides()
    local e = entryFor(2)
    assertEqual(false, changed, "changed on second call")
    assertEqual("Barbed Shot", e.originalName, "originalName not re-captured")
    assertEqual("Arcane Shot | Cobra Shot | Zulu Shot", names(), "names stable")
end)

test("T4 override removed -- reverts to base name", function()
    reset()
    overrides[2] = "Zulu Shot"
    SC:ApplySpellOverrides()
    overrides[2] = nil
    local changed = SC:ApplySpellOverrides()
    local e = entryFor(2)
    assertEqual(true, changed, "changed")
    assertEqual("Barbed Shot", e.name, "name reverted")
    assertEqual(nil, e.originalName, "originalName cleared")
    assertTrue(SC.byName["barbed shot"] == e, "byName restored")
    assertEqual(nil, SC.byName["zulu shot"], "custom byName key dropped")
    assertEqual("Arcane Shot | Barbed Shot | Cobra Shot", names(), "re-sorted back")
end)

test("T5 collision then revert -- real owner is not orphaned", function()
    reset()
    local cobra = entryFor(3)
    -- Rename Arcane Shot onto Cobra Shot's exact name. The clobber is expected:
    -- a rebuild produces the same state, so live and post-reload agree.
    overrides[1] = "Cobra Shot"
    SC:ApplySpellOverrides()
    assertTrue(SC.byName["cobra shot"] == entryFor(1), "renamed entry owns the key while the override is live")
    -- Clearing the override must hand the key back, not drop it.
    overrides[1] = nil
    SC:ApplySpellOverrides()
    assertEqual("Arcane Shot", entryFor(1).name, "renamed entry reverted")
    assertTrue(SC.byName["cobra shot"] == cobra, "real Cobra Shot resolvable again (not orphaned)")
    assertTrue(SC.byName["arcane shot"] == entryFor(1), "reverted entry re-keyed")
end)

-- ---------------------------------------------------------------------------
-- Run.
-- ---------------------------------------------------------------------------

local passed = 0
local failed = 0
for _, t in ipairs(tests) do
    local ok, err = pcall(t.fn)
    if ok then
        passed = passed + 1
        print("PASS  " .. t.name)
    else
        failed = failed + 1
        print("FAIL  " .. t.name .. " -- " .. tostring(err))
    end
end
print(string.format("RESULT %d passed, %d failed", passed, failed))
os.exit(failed > 0 and 1 or 0)
