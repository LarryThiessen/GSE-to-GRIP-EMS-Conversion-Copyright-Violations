-- GRIP-EMS: VehicleKeybinds
-- Created: 2026-04-03
-- Updated: 2026-06-21
-- Patch: 12.0.7.68256 Midnight (Retail LIVE)

-- GRIP-EMS: Vehicle Keybinds
-- Custom keybinds for vehicle/override/skyriding bar buttons 1-12.
-- A secure attribute driver (emsvk) maps each key to the active bar's action
-- slot whenever a vehicle / override / possess / skyriding / pet battle bar is
-- up, and clears the bindings at rest -- combat-legal and symmetric by
-- construction (no Lua event, no OOC queue on the bar-swap path).
-- Data model: GRIP_EMS_CHAR.vehicleKeybinds = { [key] = slotIndex }
-- Character-wide, NOT per-spec (vehicles are universal context).

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)
local D = GRIPEMS.Defaults

GRIPEMS.VehicleKeybinds = {}
local VK = GRIPEMS.VehicleKeybinds

-- Runtime state
VK.active = false

-- Latched true while the watchdog's missed-enter heal has force-applied the
-- bindings. vkstate is exactly what went stale in that scenario (it still
-- reads "none"/nil and never dispatches on the exit), so IsActive ORs this
-- latch in to keep the force-applied layer visible to the watchdog's
-- deactivate rule. Consumed by Deactivate (the rule's off-switch).
VK._forceApplied = false

-- Secure owner frame. emsvk states: any non-"none" value means a vehicle /
-- override / possess / skyriding / pet battle bar is active, so the user's
-- vehicle-slot bindings apply; "none" == at rest, bindings cleared.
-- vksuppress == "1" forces a clear regardless of state -- the OOC skyride
-- watchdog sets it for the offset-stale ElvUI dismount the [bonusbar:5]
-- macro condition cannot see, and clears it when a real bar returns. A
-- vksuppress change re-dispatches the current vkstate so the flip takes
-- effect without waiting for a bar swap. The _onattributechanged name MUST
-- carry the leading underscore; the non-underscore form is a silent no-op.
local vehicleKeybindOwner = _G["GRIPEMS_VehicleKeybindOwner"]
    or CreateFrame("Frame", "GRIPEMS_VehicleKeybindOwner", UIParent, "SecureHandlerAttributeTemplate")
vehicleKeybindOwner:UnregisterAllEvents()
vehicleKeybindOwner:Hide()

vehicleKeybindOwner:SetAttribute(
    "_onattributechanged",
    [=[
    if name == "autodismount" then
        name = "emsvk"
        value = self:GetAttribute("vkstate")
    end
    if name == "vksuppress" then
        name = "emsvk"
        value = self:GetAttribute("vkstate")
    end
    if name == "emsvk" then
        self:SetAttribute("vkstate", value)
        self:ClearBindings()
        local apply = (value ~= nil and value ~= "none")
            and (self:GetAttribute("vksuppress") ~= "1")
        if apply then
            local sky = (value == "skyride")
            local autoDis = (self:GetAttribute("autodismount") == "1")
            local n = self:GetAttribute("vkcount") or 0
            for i = 1, n do
                local key = self:GetAttribute("vkkey"..i)
                local slot = self:GetAttribute("vkslot"..i)
                if key and slot then
                    if not (sky and autoDis and self:GetAttribute("vkseq"..i) == "1") then
                        if sky then
                            local cb = self:GetFrameRef("vkcast"..i)
                            if cb then
                                self:SetBindingClick(true, key, cb, "LeftButton")
                            end
                        else
                            self:SetBinding(true, key, "ACTIONBUTTON"..slot)
                        end
                    end
                end
            end
        end
    end
]=]
)

-- Same condition set as the legacy _vehicleSuspendConditionActive Lua test
-- (HasVehicleActionBar / HasOverrideActionBar / UnitHasVehicleUI /
-- IsInBattle / skyriding bonus bar). UPDATE_BONUS_ACTIONBAR is in the
-- driver's event eval set, so [bonusbar:5] flips on skyriding enter AND
-- exit -- the combat-legal symmetry the OOC path lacked.
RegisterAttributeDriver(
    vehicleKeybindOwner,
    "emsvk",
    "[bonusbar:5] skyride; [vehicleui][possessbar][overridebar][petbattle] active; none"
)

-- Per-entry cast SecureActionButtons (Phase 2). During skyride a VK key that is NOT
-- yielding to the sequence layer binds to a CLICK on one of these instead of
-- ACTIONBUTTON<slot>: under ElvUI the paged ACTIONBUTTON never reaches the skyride
-- ability, but a "/cast <ability>" macro is bar-agnostic. Shown + RegisterForClicks
-- ("AnyDown") exactly like the sequence buttons (Engine.lua): a keybind CLICK only fires
-- a SecureActionButton's protected action when the button is shown and registered for
-- that click. Zero-size and unanchored so they stay invisible; wired as frame refs
-- vkcast<i> on the secure owner so the bind snippets can target them. Macrotext is
-- resolved live by VK:RefreshSkyrideCastAttrs (offset == 5 only) and cleared off-bar.
local vkCastButtons = {}
for i = 1, D.VEHICLE_KEYBIND_SLOTS do
    local b = _G["GRIPEMS_VKSkyCast" .. i]
        or CreateFrame("Button", "GRIPEMS_VKSkyCast" .. i, UIParent, "SecureActionButtonTemplate")
    b:SetAttribute("type", "macro")
    b:Show()
    b:RegisterForClicks("AnyDown")
    vkCastButtons[i] = b
    SecureHandlerSetFrameRef(vehicleKeybindOwner, "vkcast" .. i, b)
end

--- Build the flat { key, slot } list from the saved vehicle keybinds.
local function buildVKList()
    local list = {}
    if _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.vehicleKeybinds then
        for key, slotIndex in pairs(GRIP_EMS_CHAR.vehicleKeybinds) do
            list[#list + 1] = { key = key, slot = slotIndex }
        end
    end
    return list
end

--- Translate the { key, slot } list onto the secure owner: a vkcount
--- attribute plus a vkkey<i> / vkslot<i> pair per entry. Exposed as
--- VK._WriteVKMatrix so the translation can be asserted against a mock
--- (the restricted env cannot run headless).
local function writeVKMatrix(driver, list)
    local seqKeys = {}
    local km = GRIPEMS.KeybindManager
    if km and km._lastMatrixList then
        for _, e in ipairs(km._lastMatrixList) do
            if e.key then
                seqKeys[e.key] = true
            end
        end
    end
    driver:SetAttribute("vkcount", #list)
    for i, entry in ipairs(list) do
        driver:SetAttribute("vkkey" .. i, entry.key)
        driver:SetAttribute("vkslot" .. i, entry.slot)
        driver:SetAttribute("vkseq" .. i, seqKeys[entry.key] and "1" or nil)
    end
end
VK._WriteVKMatrix = writeVKMatrix

--- Push the current vehicle-keybind matrix to the secure owner, then
--- re-evaluate at rest. Every attribute write + SecureHandlerExecute is
--- protected and OOC-only, so when restricted this queues and returns; the
--- driver itself keeps re-evaluating IN combat (the point of the fix).
function VK:_PushMatrix()
    if GRIPEMS.OOCQueue.IsRestricted() then
        GRIPEMS.OOCQueue:Add(function()
            VK:_PushMatrix()
        end, D.OOC_OP_GENERIC)
        return
    end
    local list = buildVKList()
    writeVKMatrix(vehicleKeybindOwner, list)
    VK:RefreshAutoDismountAttr()
    SecureHandlerExecute(
        vehicleKeybindOwner,
        [=[
        local st = self:GetAttribute("vkstate")
        self:ClearBindings()
        local apply = (st ~= nil and st ~= "none")
            and (self:GetAttribute("vksuppress") ~= "1")
        if apply then
            local sky = (st == "skyride")
            local autoDis = (self:GetAttribute("autodismount") == "1")
            local n = self:GetAttribute("vkcount") or 0
            for i = 1, n do
                local key = self:GetAttribute("vkkey"..i)
                local slot = self:GetAttribute("vkslot"..i)
                if key and slot then
                    if not (sky and autoDis and self:GetAttribute("vkseq"..i) == "1") then
                        if sky then
                            local cb = self:GetFrameRef("vkcast"..i)
                            if cb then
                                self:SetBindingClick(true, key, cb, "LeftButton")
                            end
                        else
                            self:SetBinding(true, key, "ACTIONBUTTON"..slot)
                        end
                    end
                end
            end
        end
    ]=]
    )
    GRIPEMS:Debug(string.format(L["GEMS_VEHICLE_KEYBINDS_APPLIED"], #list))
end

--- Mirror the autoDismountFlying CVar onto the VK owner as the "autodismount"
--- attribute. The _onattributechanged autodismount branch re-dispatches the current
--- vkstate so a CVar toggle re-evaluates the skyride yield decision immediately.
--- OOC-only (protected attribute write).
function VK:RefreshAutoDismountAttr()
    if GRIPEMS.OOCQueue.IsRestricted() then
        GRIPEMS.OOCQueue:Add(function()
            VK:RefreshAutoDismountAttr()
        end, D.OOC_OP_GENERIC)
        return
    end
    local on = GetCVar and GetCVar("autoDismountFlying") == "1"
    vehicleKeybindOwner:SetAttribute("autodismount", on and "1" or nil)
end

--- Resolve, per VK entry, the "/cast <skyride ability>" macrotext for the cast button the
--- skyride bind snippet clicks, and store it as that button's macrotext attribute. The
--- offset is supplied by KM:RefreshSkyridePassAttrs (5 while the skyriding bar is up OR
--- while the watchdog skyrideforce flag bridges a stale offset; anything else is off-bar
--- and clears every cast button). Slot math is the Surge Forward bonus-bar formula
--- (NUM_ACTIONBAR_PAGES + offset - 1) * NUM_ACTIONBAR_BUTTONS + slot, reading vkslot<i>
--- from the owner so cast button i always matches the slot the snippet binds for entry i.
--- C_Spell.GetSpellName returns the client-locale name. Caller holds the OOC gate
--- (KM:RefreshSkyridePassAttrs); do not call this in combat directly.
function VK:RefreshSkyrideCastAttrs(offset)
    local n = vehicleKeybindOwner:GetAttribute("vkcount") or 0
    local base = (NUM_ACTIONBAR_PAGES + (offset or 0) - 1) * NUM_ACTIONBAR_BUTTONS
    for i = 1, D.VEHICLE_KEYBIND_SLOTS do
        local castBtn = vkCastButtons[i]
        if castBtn then
            local passText = nil
            if offset == 5 and i <= n then
                local slot = tonumber(vehicleKeybindOwner:GetAttribute("vkslot" .. i))
                if slot then
                    local aType, aID = GetActionInfo(base + slot)
                    if aType == "spell" and aID then
                        local spellName = C_Spell.GetSpellName(aID)
                        if spellName and spellName ~= "" then
                            passText = "/cast " .. spellName
                        end
                    end
                end
            end
            castBtn:SetAttribute("macrotext", passText)
        end
    end
end

--- Activate vehicle keybinds. Lifts any watchdog force-clear, then pushes the
--- current matrix to the secure owner. The attribute driver owns the live
--- apply/clear on bar swap; this remains for the one-shot load push and the OOC
--- skyride watchdog re-enable.
function VK:Activate()
    if GRIPEMS.OOCQueue.IsRestricted() then
        GRIPEMS.OOCQueue:Add(function()
            VK:Activate()
        end, D.OOC_OP_GENERIC)
        return
    end
    vehicleKeybindOwner:SetAttribute("vksuppress", nil)
    VK.active = true
    VK:_PushMatrix()
end

--- ForceApply: unconditional apply for the watchdog's missed-enter heal --
--- binds regardless of vkstate because the state attribute is exactly what
--- went stale; undone by the watchdog deactivate rule on real exit.
function VK:ForceApply()
    if GRIPEMS.OOCQueue.IsRestricted() then
        GRIPEMS.OOCQueue:Add(function()
            VK:ForceApply()
        end, D.OOC_OP_GENERIC)
        return
    end
    vehicleKeybindOwner:SetAttribute("vksuppress", nil)
    local list = buildVKList()
    writeVKMatrix(vehicleKeybindOwner, list)
    VK:RefreshAutoDismountAttr()
    SecureHandlerExecute(
        vehicleKeybindOwner,
        [=[
        self:ClearBindings()
        local autoDis = (self:GetAttribute("autodismount") == "1")
        local n = self:GetAttribute("vkcount") or 0
        for i = 1, n do
            local key = self:GetAttribute("vkkey"..i)
            local slot = self:GetAttribute("vkslot"..i)
            if key and slot then
                if not (autoDis and self:GetAttribute("vkseq"..i) == "1") then
                    local cb = self:GetFrameRef("vkcast"..i)
                    if cb then
                        self:SetBindingClick(true, key, cb, "LeftButton")
                    end
                end
            end
        end
    ]=]
    )
    VK.active = true
    VK._forceApplied = true
    GRIPEMS:Debug("skyride watchdog: vehicle keybinds force-applied (missed enter)")
end

--- Force-clear the secure layer and keep it cleared until a real bar returns.
function VK:Deactivate()
    if GRIPEMS.OOCQueue.IsRestricted() then
        GRIPEMS.OOCQueue:Add(function()
            VK:Deactivate()
        end, D.OOC_OP_GENERIC)
        return
    end
    -- Force the secure layer to clear and STAY clear until a real bar
    -- returns. The OOC skyride watchdog calls this for the offset-stale
    -- ElvUI dismount the [bonusbar:5] condition cannot see; a plain clear
    -- would be re-applied by the driver on its next 0.2s evaluation, so a
    -- persistent vksuppress flag is required.
    vehicleKeybindOwner:SetAttribute("vksuppress", "1")
    SecureHandlerExecute(vehicleKeybindOwner, [=[ self:ClearBindings() ]=])
    VK.active = false
    VK._forceApplied = false
    GRIPEMS:Debug(L["GEMS_VEHICLE_KEYBINDS_CLEARED"])
end

--- True when the secure layer is currently force-cleared by the watchdog.
function VK:IsSuppressed()
    return vehicleKeybindOwner:GetAttribute("vksuppress") == "1"
end

--- Lift the watchdog force-clear. The vksuppress change re-dispatches the
--- current vkstate, so the driver re-applies immediately when a real bar
--- is up. OOC-only (protected attribute write).
function VK:ClearSuppress()
    if GRIPEMS.OOCQueue.IsRestricted() then
        GRIPEMS.OOCQueue:Add(function()
            VK:ClearSuppress()
        end, D.OOC_OP_GENERIC)
        return
    end
    vehicleKeybindOwner:SetAttribute("vksuppress", nil)
end

--- Set a keybind for a vehicle slot.
--- @param slotIndex number Slot index 1..12
--- @param key string WoW key string
function VK:SetKeybind(slotIndex, key)
    if type(slotIndex) ~= "number" or slotIndex < 1 or slotIndex > D.VEHICLE_KEYBIND_SLOTS then
        return
    end
    if type(key) ~= "string" or key == "" then
        return
    end
    if not _G.GRIP_EMS_CHAR then
        return
    end

    GRIP_EMS_CHAR.vehicleKeybinds = GRIP_EMS_CHAR.vehicleKeybinds or {}
    local binds = GRIP_EMS_CHAR.vehicleKeybinds

    -- Clear any existing key for this slot
    for existingKey, existingSlot in pairs(binds) do
        if existingSlot == slotIndex then
            binds[existingKey] = nil
            break
        end
    end

    -- Clear any existing slot for this key
    if binds[key] then
        binds[key] = nil
    end

    -- Store the new binding
    binds[key] = slotIndex

    -- The secure driver owns the live bindings; one matrix push covers it.
    VK:_PushMatrix()

    if GRIPEMS.Fire then
        GRIPEMS:Fire("VEHICLE_KEYBIND_CHANGED", slotIndex, key)
    end
    if GRIPEMS.KeybindManager and GRIPEMS.KeybindManager.RefreshSkyridePassAttrs then
        GRIPEMS.KeybindManager:RefreshSkyridePassAttrs()
    end
end

--- Clear the keybind for a vehicle slot.
--- @param slotIndex number Slot index 1..12
function VK:ClearKeybind(slotIndex)
    if type(slotIndex) ~= "number" or slotIndex < 1 or slotIndex > D.VEHICLE_KEYBIND_SLOTS then
        return
    end
    if not _G.GRIP_EMS_CHAR or not GRIP_EMS_CHAR.vehicleKeybinds then
        return
    end

    local binds = GRIP_EMS_CHAR.vehicleKeybinds
    local foundKey = nil
    for key, slot in pairs(binds) do
        if slot == slotIndex then
            foundKey = key
            break
        end
    end

    if not foundKey then
        return
    end

    binds[foundKey] = nil

    -- Rebuild the secure matrix without the removed slot.
    VK:_PushMatrix()

    if GRIPEMS.Fire then
        GRIPEMS:Fire("VEHICLE_KEYBIND_CHANGED", slotIndex, nil)
    end
    if GRIPEMS.KeybindManager and GRIPEMS.KeybindManager.RefreshSkyridePassAttrs then
        GRIPEMS.KeybindManager:RefreshSkyridePassAttrs()
    end
end

--- Get the key string bound to a vehicle slot.
--- @param slotIndex number Slot index 1..12
--- @return string|nil The key string, or nil if no binding exists
function VK:GetKeybind(slotIndex)
    if not _G.GRIP_EMS_CHAR or not GRIP_EMS_CHAR.vehicleKeybinds then
        return nil
    end
    for key, slot in pairs(GRIP_EMS_CHAR.vehicleKeybinds) do
        if slot == slotIndex then
            return key
        end
    end
    return nil
end

--- Return a shallow copy of the vehicle keybinds table.
--- @return table copy { [key] = slotIndex }
function VK:GetAllKeybinds()
    if not _G.GRIP_EMS_CHAR or not GRIP_EMS_CHAR.vehicleKeybinds then
        return {}
    end
    local copy = {}
    for key, slot in pairs(GRIP_EMS_CHAR.vehicleKeybinds) do
        copy[key] = slot
    end
    return copy
end

-- Modifier ranking for normalizing external key combos to the canonical
-- ALT-CTRL-SHIFT-KEY order our own capture writes. The external module
-- builds its combo by prepending each held modifier, which yields
-- SHIFT-ALT-CTRL-KEY ordering for multi-modifier keys; an order-sensitive
-- lookup would false-negative on those.
local MOD_RANK = { ALT = 1, CTRL = 2, SHIFT = 3 }

--- Normalize a key-combo string to canonical ALT-CTRL-SHIFT-KEY order.
--- @param combo any Raw value from the external binds table
--- @return string|nil Canonical combo string, or nil for non-string input
local function NormalizeKeyCombo(combo)
    if type(combo) ~= "string" or combo == "" then
        return nil
    end
    local mods = {}
    local rest = combo
    while true do
        local mod, tail = string.match(rest, "^(ALT)%-(.+)$")
        if not mod then
            mod, tail = string.match(rest, "^(CTRL)%-(.+)$")
        end
        if not mod then
            mod, tail = string.match(rest, "^(SHIFT)%-(.+)$")
        end
        if not mod then
            break
        end
        mods[#mods + 1] = mod
        rest = tail
    end
    if rest == "" then
        return nil
    end
    table.sort(mods, function(a, b)
        return MOD_RANK[a] < MOD_RANK[b]
    end)
    mods[#mods + 1] = rest
    return table.concat(mods, "-")
end

--- Read the external sky-riding binds table. Shared by both collision
--- detectors. Read-only: never writes the external table.
--- @return table|nil The external { [slotString] = comboString } table, or nil
local function ReadExternalSkyrideBinds()
    if not (C_AddOns and C_AddOns.IsAddOnLoaded and C_AddOns.IsAddOnLoaded("GSE_QoL")) then
        return nil
    end
    local opts = _G.GSEOptions
    local srb = type(opts) == "table" and type(opts.SkyRidingBinds) == "table" and opts.SkyRidingBinds or nil
    return srb
end

--- Intersect the external sky-riding binds with one of our keybind maps.
--- @param mine table Our { [combo] = slotIndex } map
--- @param maxSlot number|nil Only consider external slots up to this index
--- @return table|nil Sorted, deduplicated array of contended combos, or nil
local function CollectExternalCollisions(mine, maxSlot)
    local srb = ReadExternalSkyrideBinds()
    if not srb then
        return nil
    end
    local hits = {}
    local seen = {}
    for slotKey, extCombo in pairs(srb) do
        local slotNum = tonumber(slotKey)
        if not maxSlot or (slotNum and slotNum <= maxSlot) then
            local canon = NormalizeKeyCombo(extCombo)
            if canon and mine[canon] and not seen[canon] then
                seen[canon] = true
                hits[#hits + 1] = canon
            end
        end
    end
    if #hits == 0 then
        return nil
    end
    table.sort(hits)
    return hits
end

--- List physical keys claimed by both our vehicle keybinds and the
--- sky-riding bind feature of the external sequencer's QoL module.
--- Read-only: reads the external saved-variables table, never writes
--- it. Returns nil when the module is absent, the feature is
--- unconfigured, or there is no overlap.
--- @return table|nil Sorted array of contended key strings, or nil
function VK:GetExternalSkyrideBindCollisions()
    return CollectExternalCollisions(VK:GetAllKeybinds(), nil)
end

--- List physical keys claimed by both our pet battle keybinds and the
--- sky-riding bind feature of the external sequencer's QoL module. That
--- feature override-binds its configured slots 1-6 during pet battles,
--- so only those slots are considered.
--- @return table|nil Sorted array of contended key strings, or nil
function VK:GetExternalPetBattleBindCollisions()
    local PB = GRIPEMS.PetBattleButtons
    if not (PB and PB.GetAllKeybinds) then
        return nil
    end
    return CollectExternalCollisions(PB:GetAllKeybinds(), D.PET_BATTLE_SLOTS)
end

--- Return true if vehicle keybinds are currently applied. Reads the secure
--- layer so the watchdog sees the true live state (a vksuppress force-clear
--- reads inactive even while a vkstate is set). The force-applied latch is
--- ORed in because the missed-enter heal binds while vkstate is stuck at
--- "none" -- without the latch the watchdog's deactivate rule could never
--- see (and so never retire) that layer after the dismount.
--- @return boolean
function VK:IsActive()
    if VK._forceApplied then
        return true
    end
    local st = vehicleKeybindOwner:GetAttribute("vkstate")
    if st == nil or st == "none" then
        return false
    end
    return vehicleKeybindOwner:GetAttribute("vksuppress") ~= "1"
end

--- One-shot push at login. Called from Core bootstrap so the secure attributes
--- are populated before the first bar swap.
function VK:Initialize()
    VK:_PushMatrix()
end
