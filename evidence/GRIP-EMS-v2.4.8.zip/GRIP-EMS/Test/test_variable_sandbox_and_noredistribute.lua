-- GRIP-EMS: Headless test for the variable sandbox and the do-not-share flag
--
-- Created:    2026-08-01
-- Updated:    2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.
--
-- Standalone (Lua 5.1) test covering two shipped changes:
--
--   PART A -- every variable function body compiled by VS:Evaluate runs under
--   an explicit whitelist environment. Unlisted globals resolve to nil, are
--   counted on VS._sandboxBlocked and are logged once per name per session.
--
--   PART B -- an inbound sequence marked do-not-share by its author lands with
--   seqData.noRedistribute set, and every export / transmit rail refuses it.
--
-- Run from the EMS root:  lua Test/test_variable_sandbox_and_noredistribute.lua
-- Exit code 0 = all passed, 1 = at least one failure.
--
-- WHY THE SENTINEL GLOBALS LIVE ON THE REAL _G. In Lua 5.1 loadstring hands the
-- returned chunk the GLOBAL environment of the state, NOT the fenv of whoever
-- called it. That is the entire shape of the defect: a variable body reached
-- the live WoW global table regardless of what environment VariableStore itself
-- ran in. So the leak targets below are rawset onto the true _G, which is what
-- an UNSANDBOXED body would see -- a sentinel parked only on the module sandbox
-- would read nil either way and every case would pass vacuously.
--
-- Cases:
--   S1  a body containing _G returns nil, and VS:GetSandboxBlocked reports _G
--   S2  a body reading another addon's global resolves nil and logs ONCE
--   S3  a body RETURNING a function is auto-called and the INNER function is
--       sandboxed too, not just the outer chunk
--   S4  the cache-hit path serves a SANDBOXED function: the second evaluation
--       of the same variable still resolves the leak target to nil
--   S5  a whitelisted Insert Helper picker helper still resolves and returns
--       its real value, namespaced exactly as the picker inserts it. A
--       NO-REGRESSION case: it passes before and after the sandbox by design
--   S6  the GRIPEMS the sandbox exposes is the picker facade and NOT the
--       published addon namespace -- Engine / Settings / VariableStore resolve
--       to nil while all six picker helpers stay reachable
--   C1  call site VariableStore.lua VS:Set -> Evaluate is sandboxed
--   C2  call site VariableStore.lua VS:EvaluateAll -> Evaluate is sandboxed
--   C3  call site VariableStore.lua VS:ProcessPendingReeval -> Evaluate is
--       sandboxed
--   C4  call site RepairAnalyzer.lua RA:CheckVariables -> Evaluate is sandboxed
--   C5  call site Engine.lua Engine:SubstituteVariables -> Evaluate is
--       sandboxed (the function is spliced out of the real Engine.lua source)
--   N1  an imported sequence carrying MetaData.noExport lands with
--       seqData.noRedistribute set
--   N2  the same via the lowercase converted-payload noExport field
--   N3  GE.Export refuses a flagged sequence, and the unflagged control still
--       exports
--   N4  transmit refuses a flagged sequence on the SEND path and on the
--       respond-to-request path, and the unflagged control still sends on both
--   N5  T:SendSequenceMeta emits NO comm message for a marked sequence, and the
--       unmarked control still emits a payload carrying Help
--   N6  T:SendListResponse omits a marked sequence from the list entirely
--   N7  T:SendListResponse does not spend a list slot on the omitted sequence:
--       51 stored sequences, one marked, response carries 50
--   P1  strict mode: a stored sequence sourced from another sequencer and
--       carrying NO author flag is UNPROVEN but NOT refused -- GE.Export
--       succeeds and GE.NeedsAuthorConfirm answers true instead
--   P2  strict mode: the same sequence is no longer refused on the send path
--       or on the respond-to-request path; both now run the confirmation and
--       both deliver for a player who confirms
--   P3  strict mode: a natively-authored sequence is NOT gated. The control
--       without which P1 proves nothing
--   P4  strict mode: an unattributed sequence is NOT gated, and neither is
--       one carrying no provenance field at all. Both exclusions are
--       deliberate and both are pinned here
--   P5  attested mode: the mode selects HOW GE.IsProvenanceGated answers, not
--       whether the content may move. The legacy-sourced sequence stays
--       unproven until it is attested by the CURRENT identity; in every one of
--       those states GE.Export succeeds. The mode is set through the saved
--       variable, the way a user would set it
--   P6  attested mode: the attestation is ABSENT from the DECODED payload, and
--       re-importing that payload lands a copy that is unproven again -- the
--       release does not survive a hop
--   P7  attested mode: an attestation naming another identity releases nothing
--   P8  ONE refusal message remains: the author's flag emits the do-not-share
--       string, the gate emits nothing because it refuses nothing, and a
--       sequence that is both still reports the flag
--   P9  call-site coverage for the rest of the call graph, restated for the
--       new contract -- the text rail, the collection send and the plugin
--       rail no longer refuse the gated shape, while the two automatic
--       DISCLOSURE sites still withhold it, now on the authorship axis
--  P10  the two PREVIEW warning sites, which warn rather than refuse: the
--       author's flag still produces the author's message, and a legacy-sourced
--       payload produces no warning at all
--   W1  IsSpellKnown(120679) -- the one real variable body measured on disk --
--       resolves rather than returning nil
--   W2  the C_ facades expose ONLY the listed functions: C_Spell.PickupSpell is
--       nil inside a variable body while C_Spell.GetSpellCooldown works
--   W3  C_Timer is unreachable from a variable body in every form
--   W4  every name in the deliberately-ABSENT comment block is unreachable. The
--       list is PARSED OUT OF THE SOURCE, not hardcoded, so the case cannot
--       drift away from the comment it enforces
--   W5  the three shape-drifting flat aliases resolve nil from a variable body
--       AND are RECORDED on VS:GetSandboxBlocked. The recording is the point:
--       a nil is visible telemetry, a wrong-shaped value is silent
--   W6  the same three functions are still reachable DOTTED, returning their
--       real modern tables
--   W7  every flat alias that was KEPT still resolves and still returns the old
--       shape. Asserts the TYPE, not merely non-nil -- a table where a tuple
--       belongs is exactly the failure W5 exists to prevent

-- ---------------------------------------------------------------------------
-- Minimal assertion + runner harness.
-- ---------------------------------------------------------------------------

local tests = {}

local function test(name, fn)
    tests[#tests + 1] = { name = name, fn = fn }
end

local function assertEqual(expected, actual, label)
    if expected ~= actual then
        error((label or "value") .. ": expected " .. tostring(expected) .. ", got " .. tostring(actual), 2)
    end
end

local function assertTrue(cond, label)
    if not cond then
        error((label or "condition") .. " failed", 2)
    end
end

local function assertNil(actual, label)
    if actual ~= nil then
        error((label or "value") .. ": expected nil, got " .. tostring(actual), 2)
    end
end

-- ---------------------------------------------------------------------------
-- Leak targets on the REAL global table. See the header note.
-- ---------------------------------------------------------------------------

_G.GRIPEMS_TEST_FOREIGN_DB = { secret = "leaked-account-wide-data" }
_G.GRIPEMS_TEST_INNER_LEAK = "leaked-from-inner-closure"
_G.GRIPEMS_TEST_CACHE_LEAK = "leaked-through-the-cache"

-- The C_ namespaces, on the REAL _G for the same reason as the sentinels above:
-- W2 only means something if PickupSpell is genuinely reachable outside the
-- sandbox. Each carries the functions the whitelist lifts PLUS the action verb
-- the facade is designed to leave behind.
_G.C_Spell = {
    GetSpellCooldown = function(spellID)
        return { startTime = 0, duration = 0, isEnabled = true, spellID = spellID }
    end,
    GetSpellCharges = function()
        return { currentCharges = 2, maxCharges = 2 }
    end,
    IsSpellUsable = function()
        return true, false
    end,
    GetSpellInfo = function(spellID)
        return { name = "TestSpell", spellID = spellID }
    end,
    IsCurrentSpell = function()
        return false
    end,
    -- The reason the facade exists. An ACTION primitive sitting on the same
    -- table as the queries above.
    PickupSpell = function()
        error("PickupSpell must never be reachable from a variable body")
    end,
}
_G.C_UnitAuras = {
    -- Return a real AuraData-shaped table rather than nil: W7 asserts the TYPE
    -- each kept alias yields, and a stub that always returns nil would make that
    -- assertion unfalsifiable.
    GetAuraDataBySpellName = function(_, spellName)
        return { name = spellName, applications = 1 }
    end,
    GetPlayerAuraBySpellID = function(spellID)
        return { spellId = spellID, applications = 1 }
    end,
    -- Present so the facade's exclusion of it is observable, and so
    -- VariableStore's own CheckPrivateAuraRisk read stays on its real branch.
    AuraIsPrivate = function()
        return false
    end,
}
_G.C_Item = {
    GetItemCount = function()
        return 5
    end,
    GetItemCooldown = function()
        return 0, 0, 1
    end,
    PickupItem = function()
        error("PickupItem must never be reachable from a variable body")
    end,
}
-- C_Timer carries After but NOT NewTimer, deliberately. W3 needs the global to
-- exist or the case is vacuous; VS:OnVariableEvent arms its consolidation timer
-- only behind a NewTimer test, and C3 drains the queue by hand, so omitting
-- NewTimer keeps that case driving the real code path.
_G.C_Timer = {
    After = function() end,
}

-- The one real variable body measured across the SavedVariables on this
-- machine. Returns a distinctive value so W1 can assert it RESOLVED rather than
-- merely stopped erroring.
_G.IsSpellKnown = function(spellID)
    return spellID == 120679
end

-- ---------------------------------------------------------------------------
-- Sandbox for the LOADED MODULES (not the variable sandbox under test).
-- ---------------------------------------------------------------------------

local frameStub = {}
frameStub.RegisterEvent = function() end
frameStub.UnregisterEvent = function() end
frameStub.UnregisterAllEvents = function() end
frameStub.SetScript = function() end
frameStub.Hide = function() end
frameStub.Show = function() end

local WOW_GLOBALS = {
    CreateFrame = function()
        return frameStub
    end,
    GetLocale = function()
        return "enUS"
    end,
    UnitName = function()
        return "Sataana"
    end,
    UnitClass = function()
        return "Mage", "MAGE", 8
    end,
    UnitExists = function()
        return true
    end,
    UnitHealth = function()
        return 50
    end,
    UnitHealthMax = function()
        return 100
    end,
    UnitPower = function()
        return 10
    end,
    UnitPowerMax = function()
        return 100
    end,
    GetBuildInfo = function()
        return "12.0.7", "68453", nil, 120007
    end,
    GetMacroIndexByName = function()
        return 0
    end,
    GetMacroInfo = function()
        return nil
    end,
    GetNumMacros = function()
        return 0, 0
    end,
    InCombatLockdown = function()
        return false
    end,
    Ambiguate = function(name)
        return (tostring(name):gsub("%-.*$", ""))
    end,
    GetNormalizedRealmName = function()
        return "TestRealm"
    end,
    IsInGroup = function()
        return false
    end,
    IsInRaid = function()
        return false
    end,
    -- T:PrintChatLink writes the received-sequence link here UNGUARDED
    -- (Transmission.lua T:PrintChatLink), so the N4 control send needs it.
    DEFAULT_CHAT_FRAME = {
        AddMessage = function() end,
    },
}

local env = setmetatable({}, {
    __index = function(_, k)
        local v = rawget(_G, k)
        if v ~= nil then
            return v
        end
        return WOW_GLOBALS[k]
    end,
})
env._G = env
env.strlower = string.lower
env.strtrim = function(s)
    return (tostring(s):gsub("^%s+", ""):gsub("%s+$", ""))
end
env.GetTime = function()
    return 0
end
-- Called UNGUARDED by RepairAnalyzer's ResetIDs, which RA:Analyze runs first.
env.wipe = function(t)
    for k in pairs(t) do
        t[k] = nil
    end
    return t
end
env.time = function()
    return 1000
end

-- Real enUS values, loaded the same way the addon loads them, with an echo
-- fallback so a key absent from enUS.lua returns the key rather than nil.
local LOADED_LOCALE = {}
local LOCALE = setmetatable({}, {
    __index = function(_, k)
        return LOADED_LOCALE[k] or k
    end,
})

env.LibStub = function()
    return {
        GetLocale = function()
            return LOCALE
        end,
        NewLocale = function()
            return LOADED_LOCALE
        end,
    }
end

-- ---------------------------------------------------------------------------
-- The addon namespace stub. Debug and Print are CAPTURED, not discarded: S2
-- asserts on the exact blocked-global line and on it appearing exactly once.
-- ---------------------------------------------------------------------------

local debugLog = {}
local printLog = {}
local sentMessages = {}

local GRIPEMS = {
    version = "test",
    Debug = function(_, msg, ...)
        if select("#", ...) > 0 then
            debugLog[#debugLog + 1] = tostring(msg)
        else
            debugLog[#debugLog + 1] = tostring(msg)
        end
    end,
    Print = function(_, msg)
        printLog[#printLog + 1] = tostring(msg)
    end,
    Fire = function() end,
    SendCommMessage = function(_, _, encoded, channel, target)
        sentMessages[#sentMessages + 1] = { encoded = encoded, channel = channel, target = target }
    end,
    NormalizeUpdatedAt = function(v)
        return tonumber(v) or 0
    end,
    -- The six helpers the VariablesTab Insert Helper picker offers. S5 drives
    -- SpellReady through the namespaced form the picker actually inserts.
    HasBuff = function()
        return false
    end,
    HasDebuff = function()
        return false
    end,
    SpellReady = function(spellID)
        return spellID == 12345 and "READY-12345" or false
    end,
    SpellOnCooldown = function()
        return false
    end,
    SpellEnabled = function()
        return true
    end,
    IsRestricted = function()
        return false
    end,
    Engine = {
        sequences = {},
        ActivateSequence = function(self, name, seqData)
            self.sequences[name] = { data = seqData }
        end,
        RegisterSequenceOnly = function(self, name, seqData)
            self.sequences[name] = { data = seqData }
        end,
        GetActiveVersion = function(_, seqData)
            if not seqData or type(seqData.versions) ~= "table" then
                return nil
            end
            return seqData.versions[seqData.defaultVersion or 1] or seqData.versions[1]
        end,
    },
    SpellCache = {
        ready = true,
        GetSpellID = function()
            return nil
        end,
        RecoverHandleTokensInText = function(_, text)
            return text
        end,
        TranslateMacrotext = function(_, text)
            return text
        end,
        NormalizeVersionLocale = function() end,
    },
    -- Get returns true so the P2P gate in Transmission opens. The rest are the
    -- accessors RA:Analyze calls UNGUARDED on its readiness / config checks.
    Settings = {
        Get = function()
            return true
        end,
        Set = function() end,
        GetEffectiveClickRate = function()
            return 250
        end,
        SetCharClickRate = function() end,
    },
    SpellValidator = {
        ValidateStep = function()
            return { spells = {}, tooltipSpells = {}, hasVariable = false }
        end,
        ExtractAllSpells = function()
            return {}
        end,
        ValidateSpell = function(_, spellName)
            return { name = spellName }
        end,
    },
    MacroManager = {
        stubs = {},
        TruncateName = function(_, name)
            return name
        end,
    },
    -- The pre-send repair warning auto-ACCEPTS here. T:SendSequence raises this
    -- dialog when RA:Analyze reports critical/error issues, and its OnAccept
    -- re-enters the send with the repair check skipped. Auto-accepting keeps the
    -- N4 control send meaningful (a user who clicks through still sends) while
    -- leaving the do-not-share gate -- which sits ABOVE the repair check -- as
    -- the only thing that can stop it.
    Popup = {
        _defs = {},
        GetDef = function(self, key)
            self._defs[key] = self._defs[key] or {}
            return self._defs[key]
        end,
        Show = function(self, key)
            local def = self._defs[key]
            if def and def.OnAccept then
                def.OnAccept()
            end
        end,
    },
    Serialization = {},
}

env.GRIPEMS = GRIPEMS
env.GRIP_EMS_DB = { variables = {}, config = {} }

-- Mirrors Core.lua:10 (_G.GRIPEMS = GRIPEMS). This matters for S5: the Insert
-- Helper picker inserts NAMESPACED snippets, and the only reason they worked
-- before the sandbox is that the whole addon namespace -- Engine, Settings,
-- every SavedVariables accessor -- was a live global. Without this line the
-- harness would understate what an unsandboxed body could reach.
_G.GRIPEMS = GRIPEMS

-- ---------------------------------------------------------------------------
-- The local player's identity.
--
-- ADDED for the author-confirmation phase. Before it, no fixture in this file
-- carried an identity at all, and nothing read one outside the P5 to P7 block
-- that stubs its own. That is no longer neutral: GE.IsLocallyAuthored compares
-- seqData.originalAuthorIdentity against this hash, and a harness with no
-- identity would answer "someone else wrote it" for EVERY fixture -- including
-- the N-series controls, whose whole job is to be the ordinary sequence the
-- author's flag is measured against.
--
-- So the harness now has one, and makeStoredSequence stamps it. An N-series
-- fixture is a sequence THIS PLAYER WROTE, which is what it always meant.
-- storeProvenanceSequence still blanks the stamp, so P-series fixtures stay
-- foreign-authored, which is what THEY always meant.
--
-- GetCurrent and AppendModifierEntry only, deliberately: no BuildExportPayload
-- (so GE.Export keeps the exact path the N series measured it on) and no
-- VerifySequence (so the preview provenance block stays "unknown"). Both are
-- guarded at their call sites; adding either here would move a different test.
local LOCAL_IDENTITY_HASH = "HASH-THIS-ACCOUNT"

GRIPEMS.Identity = {
    GetCurrent = function()
        return {
            displayName = "Sataana",
            identityHash = LOCAL_IDENTITY_HASH,
            realm = "TestRealm",
            source = "battletag",
        }
    end,
    AppendModifierEntry = function() end,
}

-- Registry-backed Serialization stub: Encode parks the table and returns
-- "<prefix>#<index>"; Decode resolves the index back. Enough for the
-- Transmission command envelopes N4 drives.
local REGISTRY = {}
local PREFIX_ORDER = { "GEMSCP1_PREFIX", "GRIP1_PREFIX", "GSE3_ENCRYPTED_PREFIX", "FRG1_PREFIX", "EMS1_PREFIX" }
local FORMAT_OF = {
    GEMSCP1_PREFIX = "GEMSCP1",
    GRIP1_PREFIX = "GRIP1",
    GSE3_ENCRYPTED_PREFIX = "GSE3ENC",
    FRG1_PREFIX = "FRG1",
    EMS1_PREFIX = "EMS1",
}

local function matchPrefix(str)
    local DD = GRIPEMS.Defaults
    for _, key in ipairs(PREFIX_ORDER) do
        local prefix = DD and DD[key]
        if prefix and str:sub(1, #prefix) == prefix then
            return key, prefix
        end
    end
    return nil
end

GRIPEMS.Serialization = {
    Encode = function(tbl, prefix)
        REGISTRY[#REGISTRY + 1] = tbl
        return true, prefix .. "#" .. tostring(#REGISTRY)
    end,
    Decode = function(str)
        local key, prefix = matchPrefix(str)
        if not key then
            return false, "Unknown format"
        end
        local idx = tonumber(str:sub(#prefix + 2))
        local tbl = idx and REGISTRY[idx]
        if not tbl then
            return false, "Decode failed"
        end
        return true, tbl, FORMAT_OF[key]
    end,
    DetectFormat = function(str)
        local key = matchPrefix(str)
        return key and FORMAT_OF[key] or nil
    end,
}

-- ---------------------------------------------------------------------------
-- Load the REAL modules into the sandbox.
-- ---------------------------------------------------------------------------

local function loadModule(candidates)
    for _, path in ipairs(candidates) do
        -- loadfile is dev-harness file I/O, intentionally outside the addon WoW std.
        -- selene: allow(undefined_variable)
        local chunk = loadfile(path)
        if chunk then
            setfenv(chunk, env)
            chunk("GRIP-EMS", GRIPEMS)
            return true
        end
    end
    return false
end

local MODULES = {
    { "Locale/enUS.lua", "../Locale/enUS.lua" },
    { "Data/Defaults.lua", "../Data/Defaults.lua" },
    { "Data/VariableStore.lua", "../Data/VariableStore.lua" },
    { "Engine/MacroSyntax.lua", "../Engine/MacroSyntax.lua" },
    { "Engine/ActionCompiler.lua", "../Engine/ActionCompiler.lua" },
    { "Data/RepairAnalyzer.lua", "../Data/RepairAnalyzer.lua" },
    { "Import/GRIPExport.lua", "../Import/GRIPExport.lua" },
    { "Import/ExportPreview.lua", "../Import/ExportPreview.lua" },
    { "Import/LegacyImport.lua", "../Import/LegacyImport.lua" },
    { "Import/ImportPreview.lua", "../Import/ImportPreview.lua" },
    { "Engine/Transmission.lua", "../Engine/Transmission.lua" },
}
for _, candidates in ipairs(MODULES) do
    assertTrue(loadModule(candidates), "could not locate " .. candidates[1] .. " (run from the EMS root)")
end

local VS = GRIPEMS.VariableStore
local GE = GRIPEMS.GRIPExport
local LI = GRIPEMS.LegacyImport
local RA = GRIPEMS.RepairAnalyzer
local T = GRIPEMS.Transmission
local D = GRIPEMS.Defaults

-- ---------------------------------------------------------------------------
-- C5 splice: Engine:SubstituteVariables lifted out of the REAL Engine.lua.
--
-- Engine.lua as a whole needs the Popup / OOCQueue / secure-frame surface this
-- harness deliberately does not stand up, so the ONE function that holds the
-- VS:Evaluate call site is spliced out and run isolated. It is real shipped
-- source, read from disk at run time -- if the function is renamed or its body
-- reordered past the terminator anchor below, this splice fails loudly rather
-- than silently covering nothing.
-- ---------------------------------------------------------------------------

local function readFile(candidates)
    for _, path in ipairs(candidates) do
        -- io is dev-harness file I/O, intentionally outside the addon WoW std.
        -- selene: allow(undefined_variable)
        local fh = io.open(path, "r")
        if fh then
            local text = fh:read("*a")
            fh:close()
            return text
        end
    end
    return nil
end

local spliceEnv = setmetatable({}, { __index = env })
spliceEnv.Engine = {}
spliceEnv.D = D
spliceEnv.L = LOCALE
spliceEnv.GRIPEMS = GRIPEMS

local function spliceSubstituteVariables()
    local src = readFile({ "Engine/Engine.lua", "../Engine/Engine.lua" })
    assertTrue(src ~= nil, "could not read Engine/Engine.lua for the C5 splice")
    local startPos = src:find("function Engine:SubstituteVariables", 1, true)
    assertTrue(startPos ~= nil, "C5 anchor gone: Engine:SubstituteVariables not found in Engine.lua")
    local endPos = src:find("\nend\n", startPos, true)
    assertTrue(endPos ~= nil, "C5 anchor gone: no column-0 terminator after Engine:SubstituteVariables")
    local body = src:sub(startPos, endPos + 4)
    local chunk, err = loadstring(body, "SubstituteVariables-splice")
    assertTrue(chunk ~= nil, "C5 splice failed to compile: " .. tostring(err))
    setfenv(chunk, spliceEnv)
    chunk()
    assertTrue(type(spliceEnv.Engine.SubstituteVariables) == "function", "C5 splice defined no function")
    return spliceEnv.Engine
end

-- Installed on the Engine stub as well, because RA:CheckPostSub calls
-- E:SubstituteVariables UNGUARDED on the C4 path. Wiring the REAL spliced
-- function there rather than a hand-written lookalike keeps that call honest:
-- the body has no self reference, so it works identically on either table.
GRIPEMS.Engine.SubstituteVariables = spliceSubstituteVariables().SubstituteVariables

-- ---------------------------------------------------------------------------
-- Shared fixture helpers.
-- ---------------------------------------------------------------------------

--- Define a variable through the REAL VS:Set (which itself evaluates once).
local function defineVar(name, funct, events)
    VS:Set(name, { funct = funct, events = events or "", eventsEnabled = true })
end

--- Hit count recorded for one blocked global, via the public accessor only.
local function blockedCount(globalName)
    return VS:GetSandboxBlocked()[globalName] or 0
end

local function countDebugLines(needle)
    local n = 0
    for _, line in ipairs(debugLog) do
        if line:find(needle, 1, true) then
            n = n + 1
        end
    end
    return n
end

--- Minimal legacy payload sequence carrying one castable step. Same shape the
--- sibling forge-provenance harness uses (lowercase action Type, MacroVersions
--- rather than Macros); anything else compiles to zero steps and ProcessSequence
--- refuses the import before the field under test is ever read.
local function legacySequence(metaData, extra)
    local seq = {
        MacroVersions = {
            {
                Actions = { { Type = "spell", Spell = "Fireball" } },
            },
        },
        MetaData = metaData,
    }
    for k, v in pairs(extra or {}) do
        seq[k] = v
    end
    return seq
end

local function newResults()
    return { warnings = {}, names = {}, count = 0, stepCounts = {}, stepFunctions = {} }
end

--- Build a fully-formed stored sequence. help is populated on every fixture:
--- it is the authored prose the two metadata paths were leaking, so a fixture
--- with an empty help would let N5 and N6 pass without proving anything.
---
--- originalAuthorIdentity is stamped with the LOCAL identity: this is a sequence
--- the player WROTE. Without the stamp GE.NeedsAuthorConfirm answers true for it
--- and the two automatic-answer paths withhold it, so the N5 and N6 CONTROLS --
--- "an unmarked sequence must still send its metadata / still be listed" --
--- would fail for a reason that has nothing to do with the author's flag they
--- exist to measure.
local function makeStoredSequence(name, noRedistribute)
    return {
        data = {
            name = name,
            originalAuthorIdentity = LOCAL_IDENTITY_HASH,
            icon = D.QUESTION_MARK_ICON,
            defaultVersion = 1,
            versions = {
                {
                    stepFunction = D.STEP_SEQUENTIAL,
                    steps = { "/cast Fireball" },
                    keyPress = "",
                    keyRelease = "",
                },
            },
            author = "Sataana",
            help = "AUTHORED-HELP-" .. name,
            classID = 8,
            createdAt = 1000,
            updatedAt = 1000,
            noRedistribute = noRedistribute or nil,
        },
    }
end

--- Register a fully-formed stored sequence straight on the engine stub.
local function storeSequence(name, noRedistribute)
    GRIPEMS.Engine.sequences[name] = makeStoredSequence(name, noRedistribute)
end

--- Drive a command through the REAL T:HandleReceive dispatch, as a remote
--- player would. Both T:SendSequenceMeta and T:SendListResponse have exactly
--- one shipped caller each and both are inside HandleReceive, so calling those
--- functions directly would leave the only live entry point uncovered.
---
--- sender is optional and defaults to the original single name. It exists
--- because the CMD_REQUEST author prompt carries a PER-SENDER cooldown, and
--- env.time() is frozen at a constant here -- so two prompted requests from one
--- name in the same run are one prompt and one silent drop, which is correct
--- behaviour and useless as a fixture. A case that wants two prompts uses two
--- names.
local function receiveCommand(payload, sender)
    local okEnc, encoded = GRIPEMS.Serialization.Encode(payload, D.GRIP1_PREFIX)
    assertTrue(okEnc, "test payload must encode")
    T:HandleReceive(D.COMM_PREFIX, encoded, "WHISPER", sender or "Requester")
end

--- Decode the payload of the most recent comm message the stub captured.
--- Goes through the REAL Serialization surface the module used to encode it.
local function lastSentPayload()
    local last = sentMessages[#sentMessages]
    if not last then
        return nil
    end
    local ok, payload = GRIPEMS.Serialization.Decode(last.encoded)
    return ok and payload or nil
end

-- ---------------------------------------------------------------------------
-- PART A -- the variable sandbox.
-- ---------------------------------------------------------------------------

test("S1 a body containing _G returns nil and _G is reported blocked", function()
    defineVar("sbGlobalTable", "_G")
    local before = blockedCount("_G")
    local value = VS:Evaluate("sbGlobalTable")
    assertNil(value, "a body of _G must not hand back the global table")
    assertTrue(blockedCount("_G") > before, "VS:GetSandboxBlocked must report _G with a hit count")
end)

test("S2 another addon's global resolves nil and logs exactly once", function()
    -- Control first: the leak target really is reachable on the real _G, so a
    -- nil below is containment and not an absent fixture.
    assertTrue(_G.GRIPEMS_TEST_FOREIGN_DB ~= nil, "leak target must exist on the real _G")

    defineVar("sbForeign", "GRIPEMS_TEST_FOREIGN_DB")
    local value = VS:Evaluate("sbForeign")
    assertNil(value, "another addon's global must resolve to nil inside a variable body")
    assertTrue(blockedCount("GRIPEMS_TEST_FOREIGN_DB") > 0, "the blocked read must be counted")

    local expected = string.format(LOCALE["GEMS_VAR_SANDBOX_BLOCKED"], "sbForeign", "GRIPEMS_TEST_FOREIGN_DB")
    assertEqual(1, countDebugLines(expected), "the blocked global must be logged with the variable name")

    -- Evaluate it many more times: the counter keeps climbing, the log does not.
    local before = blockedCount("GRIPEMS_TEST_FOREIGN_DB")
    for _ = 1, 20 do
        VS:Evaluate("sbForeign")
    end
    assertTrue(blockedCount("GRIPEMS_TEST_FOREIGN_DB") > before, "every hit must be counted")
    assertEqual(1, countDebugLines(expected), "the log line must stay at one per name per session")
end)

test("S3 a function-returning body has its INNER function sandboxed too", function()
    assertTrue(_G.GRIPEMS_TEST_INNER_LEAK ~= nil, "inner leak target must exist on the real _G")

    -- VS:Evaluate compiles "return function() ... end", sees a function result
    -- and auto-calls it. The auto-called closure is created INSIDE the chunk, so
    -- it inherits the chunk's environment -- this case is what proves it.
    defineVar("sbInner", "function() return GRIPEMS_TEST_INNER_LEAK end")
    local value = VS:Evaluate("sbInner")
    assertNil(value, "the auto-called inner function must not reach the global table")
    assertTrue(blockedCount("GRIPEMS_TEST_INNER_LEAK") > 0, "the inner read must be counted as blocked")
end)

test("S4 the cache-hit path serves a sandboxed function", function()
    assertTrue(_G.GRIPEMS_TEST_CACHE_LEAK ~= nil, "cache leak target must exist on the real _G")

    local funct = "GRIPEMS_TEST_CACHE_LEAK"
    defineVar("sbCache", funct)

    local first = VS:Evaluate("sbCache")
    assertNil(first, "first evaluation must be sandboxed")
    -- The compiled function is now cached; the second call takes the cache-hit
    -- branch at the top of VS:Evaluate rather than recompiling.
    assertEqual(funct, VS._cachedFunctSrc["sbCache"], "the compiled function must be cached after the first call")

    local before = blockedCount("GRIPEMS_TEST_CACHE_LEAK")
    local second = VS:Evaluate("sbCache")
    assertNil(second, "the cached function must still be sandboxed")
    assertTrue(blockedCount("GRIPEMS_TEST_CACHE_LEAK") > before, "the cache-hit evaluation must go through the env")
end)

test("S5 a whitelisted Insert Helper picker helper still returns its real value", function()
    -- A NO-REGRESSION case, not a fix-pinning one: this passes before and after
    -- the sandbox by design. It exists so the containment cannot be "achieved"
    -- by breaking the picker snippets the product tells users to insert.
    -- Exactly the shape the picker inserts: namespaced through GRIPEMS.
    defineVar("sbHelper", "GRIPEMS.SpellReady(12345)")
    local value = VS:Evaluate("sbHelper")
    assertEqual("READY-12345", value, "a whitelisted helper must keep working under the sandbox")
    assertEqual(0, blockedCount("GRIPEMS"), "GRIPEMS must be on the whitelist, not falling through __index")

    -- The bare-name form the RecommendationEvaluator whitelist also carries.
    defineVar("sbHelperBare", "SpellReady(12345)")
    assertEqual("READY-12345", VS:Evaluate("sbHelperBare"), "the bare helper name must resolve too")
end)

test("S6 the GRIPEMS the sandbox exposes is the picker facade, not the namespace", function()
    -- Core.lua publishes the whole addon namespace as a global, so before the
    -- sandbox a variable body reached Engine, Settings and every SavedVariables
    -- accessor through it. The env carries a facade of exactly the picker
    -- helpers instead; this is the case that pins the difference.
    assertTrue(_G.GRIPEMS.Engine ~= nil, "the real namespace must expose Engine, or this case proves nothing")

    defineVar("sbFacadeEngine", "GRIPEMS.Engine")
    assertNil(VS:Evaluate("sbFacadeEngine"), "the sandbox facade must not expose Engine")

    defineVar("sbFacadeSettings", "GRIPEMS.Settings")
    assertNil(VS:Evaluate("sbFacadeSettings"), "the sandbox facade must not expose Settings")

    defineVar("sbFacadeStore", "GRIPEMS.VariableStore")
    assertNil(VS:Evaluate("sbFacadeStore"), "the sandbox facade must not expose the variable store itself")

    -- ... while the six picker helpers stay reachable through the same name.
    for _, helper in ipairs({ "HasBuff", "HasDebuff", "SpellReady", "SpellOnCooldown", "SpellEnabled", "IsRestricted" }) do
        defineVar("sbFacade" .. helper, "type(GRIPEMS." .. helper .. ")")
        assertEqual("function", VS:Evaluate("sbFacade" .. helper), helper .. " must stay reachable on the facade")
    end
end)

-- ---------------------------------------------------------------------------
-- Call-site coverage. VS:Evaluate has five shipped callers; each gets a case
-- that drives it with a leaking body and asserts the sandbox held.
-- ---------------------------------------------------------------------------

test("C1 call site VariableStore VS:Set", function()
    local before = blockedCount("GRIPEMS_TEST_FOREIGN_DB")
    -- VS:Set evaluates the new definition itself before firing VARIABLE_UPDATED.
    defineVar("csSet", "GRIPEMS_TEST_FOREIGN_DB")
    assertTrue(blockedCount("GRIPEMS_TEST_FOREIGN_DB") > before, "VS:Set's own evaluation must be sandboxed")
    assertNil(VS:GetCachedValue("csSet"), "VS:Set must cache the sandboxed nil, not the global")
end)

test("C2 call site VariableStore VS:EvaluateAll", function()
    defineVar("csAll", "GRIPEMS_TEST_FOREIGN_DB")
    local before = blockedCount("GRIPEMS_TEST_FOREIGN_DB")
    local results = VS:EvaluateAll()
    assertTrue(blockedCount("GRIPEMS_TEST_FOREIGN_DB") > before, "VS:EvaluateAll must evaluate through the sandbox")
    assertNil(results["csAll"], "the leaking variable must evaluate to nil in the bulk pass")
end)

test("C3 call site VariableStore VS:ProcessPendingReeval", function()
    defineVar("csReeval", "GRIPEMS_TEST_FOREIGN_DB", "PLAYER_REGEN_DISABLED")
    -- Queue it the way a real event would, then drain the queue directly (no
    -- C_Timer in this harness, so the consolidation timer never arms).
    VS:OnVariableEvent("PLAYER_REGEN_DISABLED")
    local before = blockedCount("GRIPEMS_TEST_FOREIGN_DB")
    VS:ProcessPendingReeval()
    assertTrue(blockedCount("GRIPEMS_TEST_FOREIGN_DB") > before, "the re-eval pass must evaluate through the sandbox")
    assertNil(VS:GetCachedValue("csReeval"), "the re-evaluated value must stay nil")
end)

test("C4 call site RepairAnalyzer RA:CheckVariables", function()
    defineVar("csRepair", "GRIPEMS_TEST_FOREIGN_DB")
    local seqData = {
        versions = {
            {
                steps = { "/cast ~csRepair~" },
                keyPress = "",
                keyRelease = "",
            },
        },
        defaultVersion = 1,
    }
    local before = blockedCount("GRIPEMS_TEST_FOREIGN_DB")
    -- Driven through RA:Analyze rather than RA:CheckVariables directly: the
    -- module's VS upvalue is bound by the ResolveDeps call at the top of
    -- Analyze, so a direct CheckVariables call indexes a nil VS.
    RA:Analyze(seqData, "csRepairSeq")
    assertTrue(blockedCount("GRIPEMS_TEST_FOREIGN_DB") > before, "RA:CheckVariables must evaluate through the sandbox")
end)

test("C5 call site Engine Engine:SubstituteVariables", function()
    local Engine = spliceSubstituteVariables()
    defineVar("csSubst", "GRIPEMS_TEST_FOREIGN_DB")
    local before = blockedCount("GRIPEMS_TEST_FOREIGN_DB")
    local out = Engine:SubstituteVariables("/cast ~csSubst~")
    assertTrue(
        blockedCount("GRIPEMS_TEST_FOREIGN_DB") > before,
        "SubstituteVariables must evaluate through the sandbox"
    )
    -- A nil evaluation substitutes the empty string, so nothing from the global
    -- table can reach compiled macrotext.
    assertEqual("/cast ", out, "a blocked variable must substitute to empty, never to the leaked value")
end)

-- ---------------------------------------------------------------------------
-- PART B -- the inbound do-not-share flag.
-- ---------------------------------------------------------------------------

test("N1 MetaData.noExport lands as seqData.noRedistribute", function()
    local results = newResults()
    local ok, err = LI.ProcessSequence("nrMetaSeq", legacySequence({ noExport = true }), results)
    assertTrue(ok, "the import must succeed: " .. tostring(err))
    local stored = GRIPEMS.Engine.sequences["nrMetaSeq"]
    assertTrue(stored ~= nil, "the sequence must have been activated")
    assertEqual(true, stored.data.noRedistribute, "MetaData.noExport must set noRedistribute")

    -- Control: an unmarked payload must NOT gain the field.
    local ctlResults = newResults()
    assertTrue(LI.ProcessSequence("nrPlainSeq", legacySequence({}), ctlResults), "control import must succeed")
    assertNil(GRIPEMS.Engine.sequences["nrPlainSeq"].data.noRedistribute, "an unmarked payload must stay unmarked")
end)

test("N2 the lowercase converted-payload noExport lands too", function()
    local results = newResults()
    local seq = legacySequence({}, { noExport = true, gseVersion = 3 })
    local ok, err = LI.ProcessSequence("nrLowerSeq", seq, results)
    assertTrue(ok, "the import must succeed: " .. tostring(err))
    assertEqual(
        true,
        GRIPEMS.Engine.sequences["nrLowerSeq"].data.noRedistribute,
        "lowercase noExport must set noRedistribute on the converted-payload path"
    )

    -- An explicit inbound noRedistribute outranks both shapes, matching how
    -- provenanceSource believes a producer that states its own answer.
    local expResults = newResults()
    local expSeq = legacySequence({ noExport = true }, { noRedistribute = false })
    assertTrue(LI.ProcessSequence("nrExplicitSeq", expSeq, expResults), "explicit-value import must succeed")
    assertNil(
        GRIPEMS.Engine.sequences["nrExplicitSeq"].data.noRedistribute,
        "an explicit inbound noRedistribute must win over MetaData.noExport"
    )
end)

test("N3 export refuses a flagged sequence", function()
    storeSequence("nrExportBlocked", true)
    storeSequence("nrExportAllowed", false)

    local ok, msg = GE.Export("nrExportBlocked")
    assertEqual(false, ok, "GE.Export must refuse a do-not-share sequence")
    assertEqual(
        string.format(LOCALE["GEMS_EXPORT_NO_REDISTRIBUTE"], "nrExportBlocked"),
        msg,
        "the refusal must carry the do-not-share message"
    )

    local ctlOk = GE.Export("nrExportAllowed")
    assertEqual(true, ctlOk, "an unflagged sequence must still export")

    -- The collection rail and the plugin-provider rail refuse the same
    -- selection; a gate on the single-sequence encoder alone is not enough.
    local colOk, colMsg = GE.ExportCollection({ "nrExportAllowed", "nrExportBlocked" }, {}, {})
    assertEqual(false, colOk, "GE.ExportCollection must refuse a selection containing a flagged sequence")
    assertEqual(
        string.format(LOCALE["GEMS_EXPORT_NO_REDISTRIBUTE"], "nrExportBlocked"),
        colMsg,
        "the collection refusal must name the flagged sequence"
    )

    -- The human-readable rail withholds the body and says why in its place.
    local text = GE.ExportAsText({ "nrExportBlocked" }, {}, {})
    assertTrue(
        text:find(string.format(LOCALE["GEMS_EXPORT_NO_REDISTRIBUTE"], "nrExportBlocked"), 1, true) ~= nil,
        "the text rail must emit the refusal"
    )
    assertNil(text:find("/cast Fireball", 1, true), "the text rail must not emit the withheld step text")
end)

test("N4 transmit refuses on the send path and on the respond-to-request path", function()
    storeSequence("nrSendBlocked", true)
    storeSequence("nrSendAllowed", false)

    -- SEND path.
    local sentBefore = #sentMessages
    T:SendSequence("nrSendBlocked", "Someone", "WHISPER", true)
    assertEqual(sentBefore, #sentMessages, "no message may leave for a do-not-share sequence")
    assertEqual(
        string.format(LOCALE["GEMS_EXPORT_NO_REDISTRIBUTE"], "nrSendBlocked"),
        printLog[#printLog],
        "the send refusal must tell the user why"
    )

    T:SendSequence("nrSendAllowed", "Someone", "WHISPER", true)
    assertEqual(sentBefore + 1, #sentMessages, "an unflagged sequence must still send")

    -- RESPOND-TO-REQUEST path. Nothing here is user-initiated, so a send-only
    -- gate would leave this open.
    local function requestFrom(seqName)
        local okEnc, encoded = GRIPEMS.Serialization.Encode({
            Command = D.CMD_REQUEST,
            SeqName = seqName,
        }, D.GRIP1_PREFIX)
        assertTrue(okEnc, "test payload must encode")
        T:HandleReceive(D.COMM_PREFIX, encoded, "WHISPER", "Requester")
    end

    local beforeReq = #sentMessages
    requestFrom("nrSendBlocked")
    assertEqual(beforeReq, #sentMessages, "a remote request must not pull a do-not-share sequence")

    requestFrom("nrSendAllowed")
    assertEqual(beforeReq + 1, #sentMessages, "a remote request for an unflagged sequence must still be fulfilled")
end)

test("N5 SendSequenceMeta emits nothing for a marked sequence", function()
    storeSequence("nrMetaBlocked", true)
    storeSequence("nrMetaAllowed", false)

    -- The CMD_META payload carries Help, which is authored prose. This path was
    -- left open on the basis that it is "metadata only".
    local before = #sentMessages
    T:SendSequenceMeta("nrMetaBlocked", "WHISPER", "Someone")
    assertEqual(before, #sentMessages, "no meta message may leave for a do-not-share sequence")

    -- Silent, matching the pull path: a printed refusal would disclose the same
    -- possession fact the refusal exists to withhold.
    local printsBefore = #printLog
    T:SendSequenceMeta("nrMetaBlocked", "WHISPER", "Someone")
    assertEqual(printsBefore, #printLog, "the meta refusal must be silent, not printed")
    assertEqual(before, #sentMessages, "the second attempt must stay silent too")

    -- Control: the unmarked sequence still emits, and the payload still carries
    -- Help -- so the gate withheld the leak rather than breaking the feature.
    T:SendSequenceMeta("nrMetaAllowed", "WHISPER", "Someone")
    assertEqual(before + 1, #sentMessages, "an unmarked sequence must still send its metadata")
    local payload = lastSentPayload()
    assertTrue(payload ~= nil, "the control payload must decode")
    assertEqual(D.CMD_META, payload.Command, "the control payload must be a CMD_META")
    assertEqual("nrMetaAllowed", payload.SeqName, "the control payload must name the sequence")
    assertEqual("AUTHORED-HELP-nrMetaAllowed", payload.Help, "the control payload must still carry Help")

    -- CALL SITE. The only shipped caller is the CMD_META_REQUEST branch of
    -- T:HandleReceive; drive the gate through that real dispatch too.
    local viaDispatch = #sentMessages
    receiveCommand({ Command = D.CMD_META_REQUEST, SeqName = "nrMetaBlocked" })
    assertEqual(viaDispatch, #sentMessages, "a remote meta request must not pull a marked sequence's help")

    receiveCommand({ Command = D.CMD_META_REQUEST, SeqName = "nrMetaAllowed" })
    assertEqual(viaDispatch + 1, #sentMessages, "a remote meta request for an unmarked sequence still answers")
    assertEqual("AUTHORED-HELP-nrMetaAllowed", lastSentPayload().Help, "the dispatched control still carries Help")
end)

test("N6 SendListResponse omits a marked sequence entirely", function()
    storeSequence("nrListBlocked", true)
    storeSequence("nrListAllowed", false)

    T:SendListResponse("Someone")
    local payload = lastSentPayload()
    assertTrue(payload ~= nil, "the list payload must decode")
    assertEqual(D.CMD_LIST_RESPONSE, payload.Command, "the payload must be a CMD_LIST_RESPONSE")

    local sawBlocked, sawAllowed = false, false
    for _, row in ipairs(payload.Sequences) do
        if row.name == "nrListBlocked" then
            sawBlocked = true
        end
        if row.name == "nrListAllowed" then
            sawAllowed = true
        end
        -- Whatever else is in the list, no row may carry the marked sequence's
        -- authored prose under any key.
        assertTrue(row.help ~= "AUTHORED-HELP-nrListBlocked", "no row may carry the marked sequence's help")
    end
    assertEqual(false, sawBlocked, "a marked sequence must be omitted from the browse list entirely")
    assertEqual(true, sawAllowed, "an unmarked sequence must still be listed")

    -- CALL SITE. The only shipped caller is the CMD_LIST_REQUEST branch of
    -- T:HandleReceive; the filter must hold on that real dispatch as well.
    receiveCommand({ Command = D.CMD_LIST_REQUEST })
    local dispatched = lastSentPayload()
    assertTrue(dispatched ~= nil, "the dispatched list payload must decode")
    for _, row in ipairs(dispatched.Sequences) do
        assertTrue(row.name ~= "nrListBlocked", "the dispatched list must omit the marked sequence")
    end
end)

test("N7 SendListResponse does not spend a list slot on the omitted sequence", function()
    -- The list caps at 50. With 51 stored and one of them marked, a filter that
    -- ran AFTER the count increment would return 49: the marked sequence would
    -- consume a slot and then be dropped. Only a filter that runs BEFORE the
    -- increment yields 50.
    local savedSequences = GRIPEMS.Engine.sequences
    GRIPEMS.Engine.sequences = {}
    for i = 1, 50 do
        GRIPEMS.Engine.sequences["slotSeq" .. i] = makeStoredSequence("slotSeq" .. i, false)
    end
    GRIPEMS.Engine.sequences["slotSeqMarked"] = makeStoredSequence("slotSeqMarked", true)

    local okRun, err = pcall(function()
        T:SendListResponse("Someone")
        local payload = lastSentPayload()
        assertTrue(payload ~= nil, "the list payload must decode")
        assertEqual(50, #payload.Sequences, "51 stored with 1 marked must yield 50 listed")
        for _, row in ipairs(payload.Sequences) do
            assertTrue(row.name ~= "slotSeqMarked", "the marked sequence must not appear")
        end
    end)

    GRIPEMS.Engine.sequences = savedSequences
    assertTrue(okRun, tostring(err))
end)

-- ---------------------------------------------------------------------------
-- PART B2 -- the provenance gate.
--
-- Content converted from another sequencer carries provenanceSource
-- "gse-legacy" and nothing signed: that format states its author as free text
-- and offers no identity hash, so this client cannot establish that the local
-- user wrote it. strict -- the shipped default -- makes such a copy import
-- only. attested releases it for the ONE account that vouched for it locally,
-- and only while that account is the current one.
-- ---------------------------------------------------------------------------

local GATE_KEY_MARKED = "GEMS_EXPORT_NO_REDISTRIBUTE"
local GATE_KEY_PROVENANCE = "GEMS_EXPORT_PROVENANCE_GATED"
local THIS_IDENTITY_HASH = LOCAL_IDENTITY_HASH
local OTHER_IDENTITY_HASH = "HASH-SOME-OTHER-ACCOUNT"

--- Set the account-scoped gate mode the way a user would: through the saved
--- variable the shipped resolver reads, never by handing the predicate a mode
--- argument it does not have.
local function setGateMode(mode)
    env.GRIP_EMS_DB.config.provenanceGate = mode
end

--- A stored sequence from the SAME builder the N series uses, with the two
--- provenance fields laid on top.
---
--- originalAuthor is populated deliberately: the import arm that carries
--- provenanceSource across a round trip is gated on it, so without it P6's
--- re-imported copy would land with no provenance at all and would be refused
--- for the wrong reason -- or rather, would not be refused at all.
local function storeProvenanceSequence(name, provenanceSource, attestedBy)
    local entry = makeStoredSequence(name, false)
    entry.data.originalAuthor = "Legacy Author"
    entry.data.originalAuthorIdentity = ""
    entry.data.provenanceSource = provenanceSource
    entry.data.provenanceAttestedBy = attestedBy
    GRIPEMS.Engine.sequences[name] = entry
    return entry
end

--- Run fn with a stubbed local identity, restoring the identity AND the gate
--- mode afterwards even when fn raises -- the N7 save / pcall / restore shape.
--- The stub carries GetCurrent (what the gate reads) and AppendModifierEntry
--- (what the import arms call unguarded the moment Identity exists), and
--- deliberately NOT BuildExportPayload, so GE.Export keeps the exact path the
--- N series measured it on.
local function withIdentity(identityHash, fn)
    local savedIdentity = GRIPEMS.Identity
    local savedMode = env.GRIP_EMS_DB.config.provenanceGate
    GRIPEMS.Identity = {
        GetCurrent = function()
            return {
                displayName = "Tester",
                identityHash = identityHash,
                realm = "TestRealm",
                source = "battletag",
            }
        end,
        AppendModifierEntry = function() end,
    }
    local ok, err = pcall(fn)
    GRIPEMS.Identity = savedIdentity
    env.GRIP_EMS_DB.config.provenanceGate = savedMode
    assertTrue(ok, tostring(err))
end

test("P1 strict mode leaves legacy-sourced content unproven but not refused", function()
    -- RESTATED for the author-confirmation phase. It used to assert
    --   assertEqual("provenance", GE.RefusalReason(entry.data))
    --   assertEqual(false, GE.Export("pvStrictLegacy"))
    -- Both asserted the gate as a REFUSAL. The gate stopped refusing and
    -- started asking, so those two lines now pin a contract the product no
    -- longer has. What survives unchanged is the FACT the gate reports -- this
    -- client cannot prove the local player wrote it -- and what replaces the
    -- refusal is the confirmation the fact now feeds.
    setGateMode(nil)
    local entry = storeProvenanceSequence("pvStrictLegacy", "gse-legacy")

    -- Non-vacuity: the author's own flag is ABSENT, so whatever happens below
    -- is the gate and not the pre-existing do-not-share rail.
    assertNil(entry.data.noRedistribute, "the fixture must carry no author flag")
    assertEqual(true, GE.IsProvenanceGated(entry.data), "legacy-sourced content is still unproven in strict mode")

    assertEqual(false, GE.IsNoRedistribute(entry.data), "legacy-sourced content must no longer be refused")
    assertNil(GE.RefusalReason(entry.data), "a sequence that is not refused has no refusal reason")
    assertEqual(true, GE.NeedsAuthorConfirm(entry.data), "it must need the player's confirmation instead")

    local ok, msg = GE.Export("pvStrictLegacy")
    assertEqual(true, ok, "GE.Export must no longer refuse legacy-sourced content: " .. tostring(msg))
end)

test("P2 strict mode no longer refuses on the send path or the request path", function()
    -- RESTATED. It used to assert that NO message leaves on either path and
    -- that the send prints the import-only refusal. Both paths now run the
    -- author confirmation instead, and a player who confirms gets the send --
    -- which is the whole change: the content moves, the player is asked first.
    --
    -- WHAT THIS CASE CANNOT SEE, and says so rather than implying otherwise:
    -- the Popup stub at the top of this harness auto-ACCEPTS on Show, so it
    -- cannot distinguish "asked, and the player said yes" from "not asked at
    -- all". The prompt itself -- nothing on the wire before confirmation, the
    -- send only after it, and nothing ever after a cancel -- is pinned in
    -- Test/test_author_confirm.lua A5 and A6, which drives the same handler
    -- through a stub that does NOT auto-accept. What P2 pins here is the half
    -- that suite cannot: that the REFUSAL is gone.
    setGateMode(nil)
    storeProvenanceSequence("pvSendLegacy", "gse-legacy")
    storeProvenanceSequence("pvSendNative", "native")

    -- SEND path.
    local sentBefore = #sentMessages
    local printsBefore = #printLog
    T:SendSequence("pvSendLegacy", "Someone", "WHISPER", true)
    assertEqual(sentBefore + 1, #sentMessages, "legacy-sourced content must send once the player confirms")
    for i = printsBefore + 1, #printLog do
        assertTrue(
            printLog[i] ~= string.format(LOCALE[GATE_KEY_PROVENANCE], "pvSendLegacy"),
            "no import-only refusal may be printed any more"
        )
    end

    T:SendSequence("pvSendNative", "Someone", "WHISPER", true)
    assertEqual(sentBefore + 2, #sentMessages, "a natively-sourced sequence must still send")

    -- RESPOND-TO-REQUEST path. Nothing here is user-initiated, which is why it
    -- gets its own confirmation rather than inheriting the send path's.
    --
    -- TWO SENDERS, deliberately. The prompt carries a per-sender cooldown and
    -- env.time() is frozen here, so a second prompted request from one name in
    -- the same run is correctly dropped. Two names, two prompts.
    local beforeReq = #sentMessages
    receiveCommand({ Command = D.CMD_REQUEST, SeqName = "pvSendLegacy" }, "RequesterP2a")
    assertEqual(beforeReq + 1, #sentMessages, "a confirmed request must now pull legacy-sourced content")

    receiveCommand({ Command = D.CMD_REQUEST, SeqName = "pvSendNative" }, "RequesterP2b")
    assertEqual(beforeReq + 2, #sentMessages, "a request for a natively-sourced sequence is still fulfilled")
end)

test("P3 strict mode does not refuse a natively-authored sequence", function()
    setGateMode(nil)
    local entry = storeProvenanceSequence("pvStrictNative", "native")
    assertEqual(false, GE.IsProvenanceGated(entry.data), "native content must never be gated")
    assertEqual(false, GE.IsNoRedistribute(entry.data), "native content must not be refused")
    assertNil(GE.RefusalReason(entry.data), "an unrefused sequence has no reason")

    local ok = GE.Export("pvStrictNative")
    assertEqual(true, ok, "a natively-authored sequence must still export in strict mode")
end)

test("P4 strict mode does not refuse unattributed content or a missing provenance field", function()
    setGateMode(nil)

    -- Explicitly unattributed. Deliberately NOT gated: the gate answers for
    -- content whose origin IS known and is another sequencer, not for every
    -- payload whose origin is unknown.
    local noProv = storeProvenanceSequence("pvStrictNoProv", "no-provenance")
    assertEqual(false, GE.IsProvenanceGated(noProv.data), "no-provenance must not be gated")
    local noProvOk = GE.Export("pvStrictNoProv")
    assertEqual(true, noProvOk, "an unattributed sequence must still export")

    -- No provenanceSource field at all -- every sequence stored before the
    -- provenance family existed. Built by the plain N-series fixture, which
    -- sets no provenance fields whatsoever.
    storeSequence("pvStrictNoField", false)
    local bare = GRIPEMS.Engine.sequences["pvStrictNoField"].data
    assertNil(bare.provenanceSource, "the bare fixture must carry no provenance field")
    assertEqual(false, GE.IsProvenanceGated(bare), "a missing provenance field must not be gated")
    local bareOk = GE.Export("pvStrictNoField")
    assertEqual(true, bareOk, "a sequence with no provenance field must still export")
end)

test("P5 attested mode selects how the gate ANSWERS, not whether content may move", function()
    -- RESTATED. Every assertion in this case used to be a GE.Export refusal:
    -- unattested refused, empty attestation refused, attested released, strict
    -- and an unknown mode refused again. The mode no longer decides whether the
    -- content may move -- it decides how GE.IsProvenanceGated ANSWERS -- so the
    -- subject moves from GE.Export's return to the predicate's, and GE.Export
    -- is asserted to succeed THROUGHOUT. That is not the assertion going soft:
    -- an export that now succeeds in every mode is precisely the behaviour
    -- change, and a case that still demanded a refusal would be pinning the
    -- product that was replaced.
    withIdentity(THIS_IDENTITY_HASH, function()
        setGateMode("attested")
        local entry = storeProvenanceSequence("pvAttest", "gse-legacy")

        assertEqual(true, GE.IsProvenanceGated(entry.data), "an unattested sequence stays unproven in attested mode")
        local unattestedOk = GE.Export("pvAttest")
        assertEqual(true, unattestedOk, "an unattested sequence is no longer refused by the export rail")
        assertEqual(true, GE.NeedsAuthorConfirm(entry.data), "it needs the player's confirmation instead")

        -- An empty attestation is not an attestation.
        entry.data.provenanceAttestedBy = ""
        assertEqual(true, GE.IsProvenanceGated(entry.data), "an empty attestation must prove nothing")

        entry.data.provenanceAttestedBy = THIS_IDENTITY_HASH
        assertEqual(false, GE.IsProvenanceGated(entry.data), "the current identity's attestation must release it")
        assertNil(GE.RefusalReason(entry.data), "a released sequence has no refusal reason")
        local releasedOk = GE.Export("pvAttest")
        assertEqual(true, releasedOk, "an attested sequence must export in attested mode")

        -- The release is scoped to the MODE. strict ignores the attestation
        -- entirely, and so does any mode string this client does not know --
        -- an unreadable setting is not proof of authorship, and it must not
        -- raise either.
        setGateMode("strict")
        assertEqual(true, GE.IsProvenanceGated(entry.data), "strict mode must ignore an attestation")
        assertEqual(true, GE.Export("pvAttest"), "and must still not refuse the export")

        setGateMode("no-such-mode")
        assertEqual(true, GE.IsProvenanceGated(entry.data), "an unrecognised mode must behave as strict")
        assertEqual(true, GE.Export("pvAttest"), "and must still not refuse the export")
    end)
end)

test("P6 attested mode: the attestation never reaches the wire and never survives a hop", function()
    withIdentity(THIS_IDENTITY_HASH, function()
        setGateMode("attested")
        local entry = storeProvenanceSequence("pvHop", "gse-legacy", THIS_IDENTITY_HASH)

        local ok, encoded = GE.Export("pvHop")
        assertTrue(ok, "the attested sequence must export: " .. tostring(encoded))

        -- Through the REAL Serialization surface the module encoded it with,
        -- the same way N5 and N6 read their payloads. Checking the encoder's
        -- own table would not prove the field never reaches a receiver.
        local okDec, decoded = GRIPEMS.Serialization.Decode(encoded)
        assertTrue(okDec, "the exported payload must decode")
        assertTrue(type(decoded.sequence) == "table", "the decoded payload must carry a sequence block")
        assertEqual("gse-legacy", decoded.sequence.provenanceSource, "the SOURCE must keep travelling")
        assertNil(decoded.sequence.provenanceAttestedBy, "the attestation must be absent from the decoded payload")

        -- Non-vacuity: the stored copy really was attested, so the absence
        -- above is the strip and not an unset fixture.
        assertEqual(THIS_IDENTITY_HASH, entry.data.provenanceAttestedBy, "the stored copy must still be attested")

        -- Receiving side: the same payload back through the real import path.
        local okImp, impName, impData = GE.ImportNative(encoded)
        assertTrue(okImp, "the payload must re-import: " .. tostring(impName))
        assertEqual("pvHop", impName, "the re-import must name the sequence")
        assertNil(impData.provenanceAttestedBy, "the received copy must land unattested")
        assertEqual("gse-legacy", impData.provenanceSource, "the received copy must keep its source")

        -- RESTATED TAIL. It used to assert that the received copy is refused
        -- again and cannot be re-exported. The refusal is gone, but the thing
        -- this case exists to prove is not: the attestation did not survive the
        -- hop, so the receiving client is back to "cannot prove authorship" and
        -- its player is asked before the copy moves on. The subject moves from
        -- "refused again" to "unproven again, and confirmed again".
        GRIPEMS.Engine.sequences["pvHopReceived"] = { data = impData }
        assertEqual(true, GE.IsProvenanceGated(impData), "the received copy must be unproven again")
        assertEqual(false, GE.IsNoRedistribute(impData), "and must not be refused -- the gate no longer refuses")
        assertEqual(true, GE.NeedsAuthorConfirm(impData), "the receiver must be asked before it moves on")
        local reOk, reMsg = GE.Export("pvHopReceived")
        assertEqual(true, reOk, "the export rail itself no longer refuses it: " .. tostring(reMsg))
    end)
end)

test("P7 attested mode ignores an attestation naming another identity", function()
    -- The first assertion is UNCHANGED and is the one this case was always
    -- about. Only the tail is restated: the export is no longer refused, so
    -- what an ignored attestation costs is a confirmation rather than a wall.
    withIdentity(THIS_IDENTITY_HASH, function()
        setGateMode("attested")
        local entry = storeProvenanceSequence("pvOtherAccount", "gse-legacy", OTHER_IDENTITY_HASH)
        assertEqual(true, GE.IsProvenanceGated(entry.data), "another account's attestation must release nothing")
        assertEqual(true, GE.NeedsAuthorConfirm(entry.data), "so the player is still asked before it moves")

        local ok, msg = GE.Export("pvOtherAccount")
        assertEqual(true, ok, "the export rail no longer refuses it either: " .. tostring(msg))
    end)
end)

test("P8 exactly one refusal message remains, and it is the author's flag", function()
    -- RESTATED. It used to assert that the two refusal strings DIFFER and that
    -- each is emitted by its own axis. There is only one refusing axis now, so
    -- "the messages differ" is no longer the question -- "only one of them can
    -- still be emitted" is. The author's half is asserted UNCHANGED; the gate's
    -- half becomes an assertion that the gated sequence exports.
    setGateMode(nil)

    -- Non-vacuity, and it matters here more than anywhere: this harness echoes
    -- an ABSENT locale key back as the key itself, and the shipped code reads
    -- the same table, so a missing key would make both sides of every
    -- comparison below equal and the case would pass on nothing.
    assertTrue(LOCALE[GATE_KEY_MARKED] ~= GATE_KEY_MARKED, "the do-not-share key must exist in Locale/enUS.lua")

    storeProvenanceSequence("pvMsgGated", "gse-legacy")
    storeSequence("pvMsgMarked", true)

    local gateOk = GE.Export("pvMsgGated")
    assertEqual(true, gateOk, "the gated sequence must no longer be refused at all")

    local markOk, markMsg = GE.Export("pvMsgMarked")
    assertEqual(false, markOk, "the marked sequence must still be refused")
    assertEqual(
        string.format(LOCALE[GATE_KEY_MARKED], "pvMsgMarked"),
        markMsg,
        "the author's flag must still emit the do-not-share string"
    )

    -- A sequence that is BOTH reports the author's own flag: it is the stronger
    -- statement, and no local attestation and no local confirmation can lift it.
    local both = storeProvenanceSequence("pvMsgBoth", "gse-legacy")
    both.data.noRedistribute = true
    assertEqual("marked", GE.RefusalReason(both.data), "the author's flag must win when both hold")
    assertEqual(false, GE.NeedsAuthorConfirm(both.data), "and a refused sequence must never reach a prompt")
    local bothOk, bothMsg = GE.Export("pvMsgBoth")
    assertEqual(false, bothOk, "a sequence that is both must be refused")
    assertEqual(
        string.format(LOCALE[GATE_KEY_MARKED], "pvMsgBoth"),
        bothMsg,
        "a sequence that is both must report the author's flag"
    )

    -- The collection rail selects its message from FindNoRedistribute's second
    -- return, so the reason has to survive that hand-off too. Two names, so the
    -- single-sequence delegation inside ExportCollection does not short-circuit.
    -- The rail now skips past the gated member and names the MARKED one, which
    -- is the only member left that refuses anything.
    local colOk, colMsg = GE.ExportCollection({ "pvMsgGated", "pvMsgMarked" }, {}, {})
    assertEqual(false, colOk, "the collection rail must still refuse a selection carrying a marked sequence")
    assertEqual(
        string.format(LOCALE[GATE_KEY_MARKED], "pvMsgMarked"),
        colMsg,
        "the collection refusal must name the marked member, not the merely-gated one"
    )
end)

test("P9 the rest of the call graph, split by whether it transfers or discloses", function()
    -- CALL-SITE COVERAGE, RESTATED. Every site below used to REFUSE the gated
    -- shape and this case asserted that five times. The gate stopped refusing,
    -- so the five sites no longer answer the same way as each other, and the
    -- split between them is the thing worth pinning:
    --
    --   TRANSFER sites -- the text rail, the collection send, the plugin rail.
    --   These move content on a player's own action, so they no longer refuse
    --   the gated shape. WAS: each asserted a refusal naming the gate.
    --
    --   DISCLOSURE sites -- T:SendSequenceMeta and T:SendListResponse. These
    --   answer AUTOMATICALLY, with no player at the keyboard to ask, so they
    --   still withhold -- but on the AUTHORSHIP axis now, not the gate. Their
    --   assertions read the same and mean something different, which is exactly
    --   the shape a real regression could hide in, so each one below states
    --   which axis it is measuring and the controls are chosen to prove it.
    --
    -- THE CONTROLS MOVED, and that is load-bearing. "pvSiteNative" is natively
    -- SOURCED but carries a blank originalAuthorIdentity, so it is not natively
    -- AUTHORED and is now withheld by the disclosure sites too. A case that kept
    -- it as the control would fail for the right reason and read as a bug. The
    -- control is now "pvSiteMine", built by the N-series fixture, which stamps
    -- the local identity.
    setGateMode(nil)
    storeProvenanceSequence("pvSiteLegacy", "gse-legacy")
    storeProvenanceSequence("pvSiteNative", "native")
    storeSequence("pvSiteMine", false)

    -- SITE: GE.ExportAsText, a TRANSFER site. Renders the body now.
    local text = GE.ExportAsText({ "pvSiteLegacy" }, {}, {})
    assertNil(
        text:find(string.format(LOCALE[GATE_KEY_PROVENANCE], "pvSiteLegacy"), 1, true),
        "the text rail must no longer emit the gate's refusal"
    )
    assertTrue(text:find("/cast Fireball", 1, true) ~= nil, "the text rail must render the step text")

    -- SITE: T:SendSequenceMeta, a DISCLOSURE site. Still emits nothing, and
    -- still silently -- a printed refusal would disclose the possession fact
    -- the refusal exists to withhold.
    local metaSent, metaPrints = #sentMessages, #printLog
    T:SendSequenceMeta("pvSiteLegacy", "WHISPER", "Someone")
    assertEqual(metaSent, #sentMessages, "no meta message may leave for a sequence the player did not author")
    assertEqual(metaPrints, #printLog, "and withholding it must stay silent")
    T:SendSequenceMeta("pvSiteNative", "WHISPER", "Someone")
    assertEqual(metaSent, #sentMessages, "natively SOURCED is not natively AUTHORED -- it is withheld too")
    T:SendSequenceMeta("pvSiteMine", "WHISPER", "Someone")
    assertEqual(metaSent + 1, #sentMessages, "a sequence the player wrote must still send its metadata")

    -- SITE: T:SendListResponse, a DISCLOSURE site. Omitted from the browse list.
    T:SendListResponse("Someone")
    local listPayload = lastSentPayload()
    assertTrue(listPayload ~= nil, "the list payload must decode")
    local sawGated, sawNative, sawMine = false, false, false
    for _, row in ipairs(listPayload.Sequences) do
        if row.name == "pvSiteLegacy" then
            sawGated = true
        end
        if row.name == "pvSiteNative" then
            sawNative = true
        end
        if row.name == "pvSiteMine" then
            sawMine = true
        end
    end
    assertEqual(false, sawGated, "a sequence the player did not author must be omitted from the browse list")
    assertEqual(false, sawNative, "including a natively-sourced one with no local authorship stamp")
    assertEqual(true, sawMine, "a sequence the player wrote must still be listed")

    -- SITE: T:SendCollection, a TRANSFER site. The FindNoRedistribute gate
    -- ahead of the macro-dependency walk no longer stops the gated shape; the
    -- author confirmation runs instead, and this harness's popup confirms.
    local colSent = #sentMessages
    T:SendCollection({ "pvSiteNative", "pvSiteLegacy" }, {}, "Someone", "WHISPER")
    assertEqual(colSent + 1, #sentMessages, "a collection carrying a gated sequence must now send on confirm")

    -- SITE: GE.SerializeWithProvider, a TRANSFER site. It builds the collection
    -- payload itself and hands it to third-party code; the refusal it kept was
    -- the gate's, and that refusal is gone.
    local savedProviders = GRIPEMS._exportProviders
    GRIPEMS._exportProviders = {
        {
            id = "pvTestProvider",
            Serialize = function()
                return "PROVIDER-SERIALIZED-STRING"
            end,
        },
    }
    local okRun, err = pcall(function()
        local provOk, provResult = GE.SerializeWithProvider("pvTestProvider", { "pvSiteLegacy" }, {}, {})
        assertEqual(true, provOk, "the plugin rail must no longer refuse a gated sequence")
        assertEqual("PROVIDER-SERIALIZED-STRING", provResult, "the gated selection must reach the provider")

        -- The author's flag is still refused on this rail. Without this half the
        -- case would prove only that a refusal was deleted, not that the right
        -- one was.
        storeSequence("pvSiteMarked", true)
        local markOk, markMsg = GE.SerializeWithProvider("pvTestProvider", { "pvSiteMarked" }, {}, {})
        assertEqual(false, markOk, "the plugin rail must still refuse a do-not-share sequence")
        assertEqual(
            string.format(LOCALE[GATE_KEY_MARKED], "pvSiteMarked"),
            markMsg,
            "and must still name it with the author's own message"
        )
    end)
    GRIPEMS._exportProviders = savedProviders
    assertTrue(okRun, tostring(err))
end)

test("P10 the two preview warning sites keep the author's message and stay silent for the gate", function()
    -- CALL-SITE COVERAGE, the last two. These sites are the only ones in the
    -- refusal-message family that are NOT refusals: they warn, before commit,
    -- that a payload the user is about to approve carries the author's flag.
    -- Their key selection now runs through the shared reason, so both halves
    -- get pinned: the flagged payload must still warn with the author's string,
    -- and a legacy-sourced payload must produce NO warning at all -- the gate is
    -- an export-time rule about the stored copy, not a property of the inbound
    -- payload, and widening it here would nag on every legacy import.
    setGateMode(nil)

    -- SITE: LI._PreviewAddSequence -- the legacy preview row.
    local flagged = newResults()
    flagged.sequences = {}
    LI._PreviewAddSequence(flagged, "pvPreviewMarked", legacySequence({ noExport = true }))
    assertEqual(1, #flagged.sequences, "the flagged payload must still produce a preview row")
    assertEqual(true, flagged.sequences[1].noRedistribute, "the preview row must carry the author's flag")
    assertEqual(
        string.format(LOCALE[GATE_KEY_MARKED], "pvPreviewMarked"),
        flagged.warnings[1],
        "the preview warning must still be the author's do-not-share string"
    )

    local sourced = newResults()
    sourced.sequences = {}
    LI._PreviewAddSequence(sourced, "pvPreviewLegacy", legacySequence({}, { gseVersion = 3 }))
    assertEqual(1, #sourced.sequences, "the legacy-sourced payload must still produce a preview row")
    assertNil(sourced.sequences[1].noRedistribute, "an unflagged payload must not gain the flag")
    assertEqual(0, #sourced.warnings, "a legacy-sourced payload must raise no do-not-share warning at preview time")

    -- SITE: LI._PreviewNativePayload -- the collection preview row, same rule.
    local colPayload = {
        format = "GRIP-EMS",
        version = D.GRIP_FORMAT_VERSION,
        type = "COLLECTION",
        sequences = {
            pvPreviewColMarked = {
                icon = D.QUESTION_MARK_ICON,
                defaultVersion = 1,
                noExport = true,
                versions = { { steps = { "/cast Fireball" }, keyPress = "", keyRelease = "" } },
            },
            pvPreviewColLegacy = {
                icon = D.QUESTION_MARK_ICON,
                defaultVersion = 1,
                gseVersion = 3,
                versions = { { steps = { "/cast Fireball" }, keyPress = "", keyRelease = "" } },
            },
        },
    }
    local colResult = LI._PreviewNativePayload(colPayload)
    assertEqual(true, colResult.ok, "the collection payload must preview")
    assertEqual(2, #colResult.sequences, "both collection members must produce rows")
    assertEqual(1, #colResult.warnings, "exactly one member -- the flagged one -- may warn")
    assertEqual(
        string.format(LOCALE[GATE_KEY_MARKED], "pvPreviewColMarked"),
        colResult.warnings[1],
        "the collection preview warning must still be the author's do-not-share string"
    )
end)

-- ---------------------------------------------------------------------------
-- PART C -- the widened whitelist.
-- ---------------------------------------------------------------------------

test("W1 IsSpellKnown resolves -- the real body measured on disk", function()
    -- Exactly the one variable body found across the SavedVariables on this
    -- machine. Before the widening it evaluated to nil.
    defineVar("wIsSpellKnown", "IsSpellKnown(120679)")
    assertEqual(true, VS:Evaluate("wIsSpellKnown"), "IsSpellKnown must resolve inside a variable body")
    assertEqual(0, blockedCount("IsSpellKnown"), "IsSpellKnown must be whitelisted, not blocked")
end)

test("W2 the C_ facades expose only the listed functions", function()
    -- Non-vacuity: the action verb really is on the namespace outside the box.
    assertTrue(_G.C_Spell.PickupSpell ~= nil, "PickupSpell must exist on the real C_Spell")
    assertTrue(_G.C_Item.PickupItem ~= nil, "PickupItem must exist on the real C_Item")
    assertTrue(_G.C_UnitAuras.AuraIsPrivate ~= nil, "AuraIsPrivate must exist on the real C_UnitAuras")

    defineVar("wPickupSpell", "C_Spell.PickupSpell")
    assertNil(VS:Evaluate("wPickupSpell"), "C_Spell.PickupSpell must be nil inside a variable body")
    defineVar("wPickupItem", "C_Item.PickupItem")
    assertNil(VS:Evaluate("wPickupItem"), "C_Item.PickupItem must be nil inside a variable body")
    defineVar("wAuraIsPrivate", "C_UnitAuras.AuraIsPrivate")
    assertNil(VS:Evaluate("wAuraIsPrivate"), "C_UnitAuras.AuraIsPrivate must be nil inside a variable body")

    -- ... while the listed queries work, through the facade and flat.
    defineVar("wCdFacade", "C_Spell.GetSpellCooldown(12345).spellID")
    assertEqual(12345, VS:Evaluate("wCdFacade"), "C_Spell.GetSpellCooldown must work through the facade")
    -- The flat GetSpellCooldown alias this case once asserted was DROPPED: the
    -- C_ function returns one table where the retired global returned a tuple.
    -- W5 owns that assertion now; the facade form above is what remains.
    defineVar("wItemCount", "C_Item.GetItemCount(6948)")
    assertEqual(5, VS:Evaluate("wItemCount"), "C_Item.GetItemCount must work through the facade")
    defineVar("wItemCountFlat", "GetItemCount(6948)")
    assertEqual(5, VS:Evaluate("wItemCountFlat"), "GetItemCount must work as a flat alias")

    -- A body cannot poison the facade for the next evaluation: each env is fresh.
    defineVar("wFacadePoison", "function() C_Spell.GetSpellCooldown = nil return 1 end")
    assertEqual(1, VS:Evaluate("wFacadePoison"), "the poisoning body must run")
    assertEqual(12345, VS:Evaluate("wCdFacade"), "a later evaluation must get an unpoisoned facade")
end)

test("W3 C_Timer is unreachable from a variable body", function()
    assertTrue(_G.C_Timer ~= nil, "C_Timer must exist outside the sandbox or this case is vacuous")

    defineVar("wTimer", "C_Timer")
    assertNil(VS:Evaluate("wTimer"), "C_Timer must not be reachable from a variable body")
    assertTrue(blockedCount("C_Timer") > 0, "the C_Timer read must be recorded as blocked")

    defineVar("wTimerAfter", "C_Timer.After")
    assertNil(VS:Evaluate("wTimerAfter"), "indexing C_Timer must not reach After")
end)

test("W4 every name in the deliberately-ABSENT comment block is unreachable", function()
    -- The list is PARSED OUT OF THE SHIPPED SOURCE rather than hardcoded here,
    -- so this case tracks the comment instead of drifting away from it. If the
    -- comment gains a name, that name is tested from the next run onward.
    local src = readFile({ "Data/VariableStore.lua", "../Data/VariableStore.lua" })
    assertTrue(src ~= nil, "could not read Data/VariableStore.lua")

    local startPos = src:find("Deliberately ABSENT, and not to be added:", 1, true)
    assertTrue(startPos ~= nil, "W4 anchor gone: the deliberately-ABSENT comment block was renamed or removed")
    local endPos = src:find("A whitelist excludes", startPos, true)
    assertTrue(endPos ~= nil, "W4 anchor gone: no terminator after the deliberately-ABSENT list")

    local block = src:sub(startPos + #"Deliberately ABSENT, and not to be added:", endPos - 1)
    block = block:gsub("%-%-%-", " "):gsub("%s+", " ")

    local names = {}
    for token in block:gmatch("[^,]+") do
        local trimmed = token:gsub("^%s+", ""):gsub("%s+$", "")
        -- Bare identifiers only. The list ends in a prose clause ("and every
        -- Set-prefixed CVar or config API") which is not a single name; the
        -- pattern anchors reject it rather than a hand-maintained skip list.
        if trimmed:match("^[%a_][%w_]*$") then
            names[#names + 1] = trimmed
        end
    end
    assertTrue(#names >= 17, "expected the full absent list, parsed " .. #names)

    for _, globalName in ipairs(names) do
        -- Non-vacuity: the name must be reachable OUTSIDE the sandbox, or its
        -- being nil inside proves nothing. Plain Lua supplies most of them;
        -- the WoW-only ones are seeded here.
        if rawget(_G, globalName) == nil then
            rawset(_G, globalName, { __absentListSentinel = globalName })
        end
        assertTrue(rawget(_G, globalName) ~= nil, globalName .. " must exist outside the sandbox")

        local varName = "wAbsent_" .. globalName
        defineVar(varName, globalName)
        assertNil(VS:Evaluate(varName), globalName .. " is on the absent list but reachable from a variable body")
    end
end)

-- The three flat aliases dropped because the C_ function returns ONE TABLE
-- where the retired global of the same bare name returned a tuple. Derived from
-- the API surface, not from a hunch: C_Spell.GetSpellCooldown ->
-- SpellCooldownInfo, C_Spell.GetSpellCharges -> SpellChargeInfo,
-- C_Spell.GetSpellInfo -> SpellInfo.
local SHAPE_DRIFT_ALIASES = { "GetSpellCooldown", "GetSpellCharges", "GetSpellInfo" }

test("W5 shape-drifting flat aliases resolve nil AND are recorded as blocked", function()
    for _, aliasName in ipairs(SHAPE_DRIFT_ALIASES) do
        -- Non-vacuity: the function really is reachable on the namespace, so a
        -- nil from the bare name is the alias being gone, not the stub missing.
        assertTrue(_G.C_Spell[aliasName] ~= nil, aliasName .. " must exist on the real C_Spell")

        local varName = "wDrift_" .. aliasName
        defineVar(varName, aliasName .. "(12345)")
        -- Calling a nil raises inside the body; pcall in VS:Evaluate turns that
        -- into a nil return. Either way the body yields no value.
        assertNil(VS:Evaluate(varName), aliasName .. " must not resolve as a flat alias")

        -- THE POINT OF THE CHANGE. A dropped alias is VISIBLE: __index records
        -- it. Had the alias stayed, the body would have received a table where
        -- the old tuple belonged, raised nothing, and recorded nothing -- the
        -- telemetry cannot see a wrong-shaped value, only an absent one.
        assertTrue(
            blockedCount(aliasName) > 0,
            aliasName .. " must appear in GetSandboxBlocked with a hit count of at least 1"
        )
    end
end)

test("W6 the shape-drifting functions are still reachable dotted", function()
    defineVar("wDotCooldown", "C_Spell.GetSpellCooldown(12345).spellID")
    assertEqual(12345, VS:Evaluate("wDotCooldown"), "C_Spell.GetSpellCooldown must still return its table")

    defineVar("wDotCharges", "C_Spell.GetSpellCharges(12345).maxCharges")
    assertEqual(2, VS:Evaluate("wDotCharges"), "C_Spell.GetSpellCharges must still return its table")

    defineVar("wDotInfo", "C_Spell.GetSpellInfo(12345).name")
    assertEqual("TestSpell", VS:Evaluate("wDotInfo"), "C_Spell.GetSpellInfo must still return its table")
end)

test("W7 every kept flat alias still resolves and still returns the old shape", function()
    -- TYPE assertions, not merely non-nil. A kept alias whose C_ function had
    -- silently changed shape would still be non-nil while being exactly the
    -- defect this pass removed.
    local KEPT = {
        { name = "IsSpellUsable", body = "type(IsSpellUsable(12345))", want = "boolean" },
        { name = "IsCurrentSpell", body = "type(IsCurrentSpell(12345))", want = "boolean" },
        {
            name = "GetAuraDataBySpellName",
            body = 'type(GetAuraDataBySpellName("player", "Ice Block"))',
            want = "table",
        },
        { name = "GetPlayerAuraBySpellID", body = "type(GetPlayerAuraBySpellID(12345))", want = "table" },
        { name = "GetItemCount", body = "type(GetItemCount(6948))", want = "number" },
        { name = "GetItemCooldown", body = "type(GetItemCooldown(6948))", want = "number" },
    }
    for _, entry in ipairs(KEPT) do
        defineVar("wKept_" .. entry.name, entry.body)
        assertEqual(entry.want, VS:Evaluate("wKept_" .. entry.name), entry.name .. " must return a " .. entry.want)
        assertEqual(0, blockedCount(entry.name), entry.name .. " must stay whitelisted, not fall through __index")
    end

    -- GetItemCooldown is the one kept alias returning a MULTI-value tuple; the
    -- type check above only sees its first value, so pin the arity too. This is
    -- precisely the property the dropped three no longer have.
    defineVar("wKeptCooldownArity", "select('#', GetItemCooldown(6948))")
    assertEqual(3, VS:Evaluate("wKeptCooldownArity"), "GetItemCooldown must still return a 3-value tuple")

    -- And IsSpellUsable's second return, for the same reason.
    defineVar("wKeptUsableArity", "select('#', IsSpellUsable(12345))")
    assertEqual(2, VS:Evaluate("wKeptUsableArity"), "IsSpellUsable must still return a 2-value tuple")
end)

-- ---------------------------------------------------------------------------
-- Runner.
-- ---------------------------------------------------------------------------

local failures = 0
for _, t in ipairs(tests) do
    local ok, err = pcall(t.fn)
    if ok then
        print("PASS  " .. t.name)
    else
        failures = failures + 1
        print("FAIL  " .. t.name)
        print("      " .. tostring(err))
    end
end

print("")
print(string.format("%d/%d passed", #tests - failures, #tests))
if failures > 0 then
    -- os is dev-harness process control, intentionally outside the addon WoW std.
    -- selene: allow(undefined_variable)
    os.exit(1)
end
