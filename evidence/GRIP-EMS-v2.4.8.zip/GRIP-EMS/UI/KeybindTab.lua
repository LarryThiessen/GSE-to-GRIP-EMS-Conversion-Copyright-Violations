-- GRIP-EMS: Keybind Tab
-- Keybind editor panel with display, key capture, and per-spec overview
-- Created: 2025 (pre-stamping)
-- Updated: 2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.

local ADDON_NAME, GRIPEMS = ...
local UI = GRIPEMS.UI
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

-- Upvalue accessor for Defaults
local function D()
    return GRIPEMS.Defaults
end

GRIPEMS.KeybindTab = {}
local KT = GRIPEMS.KeybindTab

--- Check if a key combo conflicts with a ConsolePort binding.
--- @param key string The WoW key combo string (e.g. "ALT-F1")
--- @return string|nil action The bound action name, or nil if no conflict
function KT.CheckConsolePortConflict(key)
    if not ConsolePort or not ConsolePort.GetCurrentBindings then
        return nil
    end
    local bindings = ConsolePort:GetCurrentBindings()
    if bindings and bindings[key] then
        return bindings[key]
    end
    return nil
end

-- Runtime state
KT.currentSeqName = nil
KT.isCapturing = false
-- captureTarget routes key capture to the correct manager:
--   { type = "sequence" }  -> KeybindManager (default)
--   { type = "vehicle", slot = N }  -> VehicleKeybinds
--   { type = "petbattle", slot = N }  -> PetBattleButtons
KT.captureTarget = { type = "sequence" }

-- Human-readable display names for gamepad buttons
local GAMEPAD_DISPLAY_NAMES = {
    PAD1 = "A / Cross",
    PAD2 = "B / Circle",
    PAD3 = "X / Square",
    PAD4 = "Y / Triangle",
    PAD5 = "LB Extra",
    PAD6 = "RB Extra",
    PADDUP = "D-Pad Up",
    PADDDOWN = "D-Pad Down",
    PADDLEFT = "D-Pad Left",
    PADDRIGHT = "D-Pad Right",
    PADLSHOULDER = "Left Bumper",
    PADRSHOULDER = "Right Bumper",
    PADLTRIGGER = "Left Trigger",
    PADRTRIGGER = "Right Trigger",
    PADLSTICK = "Left Stick Click",
    PADRSTICK = "Right Stick Click",
    PADLSTICKUP = "Left Stick Up",
    PADLSTICKDOWN = "Left Stick Down",
    PADLSTICKLEFT = "Left Stick Left",
    PADLSTICKRIGHT = "Left Stick Right",
    PADRSTICKUP = "Right Stick Up",
    PADRSTICKDOWN = "Right Stick Down",
    PADRSTICKLEFT = "Right Stick Left",
    PADRSTICKRIGHT = "Right Stick Right",
    PADPADDLE1 = "Paddle 1",
    PADPADDLE2 = "Paddle 2",
    PADPADDLE3 = "Paddle 3",
    PADPADDLE4 = "Paddle 4",
    PADFORWARD = "Start / Options",
    PADBACK = "Back / Share",
    PADSYSTEM = "System",
    PADSOCIAL = "Social / Share",
}

-- WoW OnMouseDown button names to binding tokens.
-- WoW supports up to Button31 on extended mice.
local MOUSE_BUTTON_MAP = {
    LeftButton = "BUTTON1",
    RightButton = "BUTTON2",
    MiddleButton = "BUTTON3",
    Button4 = "BUTTON4",
    Button5 = "BUTTON5",
}

-- Fallback for Button6..Button31 is computed at use-site.

-- Human-readable display names for mouse buttons in overview rows.
local MOUSE_DISPLAY_NAMES = {
    BUTTON1 = "Mouse Left",
    BUTTON2 = "Mouse Right",
    BUTTON3 = "Mouse Middle",
    BUTTON4 = "Mouse 4",
    BUTTON5 = "Mouse 5",
    MOUSEWHEELUP = "Wheel Up",
    MOUSEWHEELDOWN = "Wheel Down",
}

--- Format a key string with friendly gamepad name if applicable.
--- @param keyStr string|nil The key combo string (e.g. "SHIFT-PAD1")
--- @return string|nil Formatted display string
local function FormatKeyDisplay(keyStr)
    if not keyStr then
        return nil
    end
    local parts = { strsplit("-", keyStr) }
    local baseKey = parts[#parts]
    local friendly = GAMEPAD_DISPLAY_NAMES[baseKey] or MOUSE_DISPLAY_NAMES[baseKey]
    if not friendly and baseKey and baseKey:match("^BUTTON(%d+)$") then
        local n = tonumber(baseKey:match("^BUTTON(%d+)$"))
        if n and n >= 6 and n <= 31 then
            friendly = "Mouse " .. n
        end
    end
    if friendly then
        return keyStr .. " (" .. friendly .. ")"
    end
    return keyStr
end

-- Modifier-only keys to ignore during capture
local MODIFIER_KEYS = {
    LSHIFT = true,
    RSHIFT = true,
    LCTRL = true,
    RCTRL = true,
    LALT = true,
    RALT = true,
}

---------------------------------------------------------------------------
-- Initialization
---------------------------------------------------------------------------

--- Build the keybind tab UI inside the given parent frame (content area).
--- @param parentFrame Frame The content area that hosts tab content
function KT:Init(parentFrame)
    if not parentFrame then
        return
    end
    local C = UI.Colors

    KT.container = parentFrame

    -- Main scroll frame for the keybind tab content
    local frame = CreateFrame("Frame", nil, parentFrame)
    frame:SetAllPoints(parentFrame)
    frame:Hide()
    KT.frame = frame
    if GRIPEMS.UI and GRIPEMS.UI.RegisterElement then
        GRIPEMS.UI:RegisterElement(frame, "panel.keybind")
    end

    -----------------------------------------------------------------------
    -- 0) Per-loadout status hint (active-loadout label + Settings jump)
    -----------------------------------------------------------------------
    local statusHintFrame = CreateFrame("Frame", nil, frame)
    statusHintFrame:SetHeight(22)
    statusHintFrame:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, -4)
    statusHintFrame:SetPoint("RIGHT", frame, "RIGHT", -8, 0)
    statusHintFrame:Hide()
    KT.statusHintFrame = statusHintFrame

    local statusHintText = statusHintFrame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(statusHintText, 10)
    statusHintText:SetPoint("LEFT", statusHintFrame, "LEFT", 0, 0)
    statusHintText:SetTextColor(C.textPrimary:GetRGBA())
    statusHintText:SetText(L["GEMS_KEYBINDS_NO_ACTIVE_LOADOUT"])
    KT.statusHintText = statusHintText

    local settingsJumpBtn = UI:CreateButton(statusHintFrame, "(Settings)", 78, 18)
    settingsJumpBtn:SetPoint("LEFT", statusHintText, "RIGHT", 8, 0)
    settingsJumpBtn:SetScript("OnClick", function()
        if GRIPEMS.SettingsPanel and GRIPEMS.SettingsPanel.Open then
            GRIPEMS.SettingsPanel:Open()
        elseif _G.Settings and _G.Settings.OpenToCategory then
            _G.Settings.OpenToCategory(ADDON_NAME)
        end
    end)
    KT.settingsJumpBtn = settingsJumpBtn

    local yOff = -8 - 26

    -----------------------------------------------------------------------
    -- A) Current Keybind Display
    -----------------------------------------------------------------------
    local kbLabel = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(kbLabel, 10)
    kbLabel:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, yOff)
    kbLabel:SetText(L["GEMS_UI_CURRENT_KEYBIND"])
    kbLabel:SetTextColor(C.textSecondary:GetRGBA())
    KT.kbLabel = kbLabel

    local kbDisplay = frame:CreateFontString(nil, "OVERLAY")
    local fontPath = GRIPEMS.UI:GetFontPath()
    kbDisplay:SetFont(fontPath, D().KEYBIND_DISPLAY_FONT_SIZE, "OUTLINE")
    kbDisplay:SetPoint("TOPLEFT", kbLabel, "BOTTOMLEFT", 0, -4)
    kbDisplay:SetText(L["GEMS_UI_KEYBIND_DISPLAY_NONE"])
    kbDisplay:SetTextColor(C.textMuted:GetRGBA())
    KT.kbDisplay = kbDisplay

    yOff = -8 - 26 - 14 - 4 - D().KEYBIND_DISPLAY_FONT_SIZE - 8

    -----------------------------------------------------------------------
    -- B) Key Capture Row
    -----------------------------------------------------------------------
    local captureRow = CreateFrame("Frame", nil, frame)
    captureRow:SetHeight(D().KEY_CAPTURE_BUTTON_HEIGHT + 4)
    captureRow:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, yOff)
    captureRow:SetPoint("RIGHT", frame, "RIGHT", -8, 0)
    KT.captureRow = captureRow

    -- Set/Change button
    local setBtn = UI:CreateButton(
        captureRow,
        L["GEMS_UI_SET_KEYBIND"],
        D().KEY_CAPTURE_BUTTON_WIDTH,
        D().KEY_CAPTURE_BUTTON_HEIGHT
    )
    setBtn:SetPoint("LEFT", captureRow, "LEFT", 0, 0)
    setBtn:SetScript("OnClick", function()
        KT:StartCapture()
    end)
    setBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.bgRowHover:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
        UI:ShowTooltip(self, L["GEMS_UI_SET_KEYBIND"], L["GEMS_UI_KEYBIND_HINT"])
    end)
    setBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
        UI:HideTooltip()
    end)
    KT.setBtn = setBtn

    -- Clear button
    local clearBtn = UI:CreateButton(captureRow, L["GEMS_UI_CLEAR_KEYBIND"], 70, D().KEY_CAPTURE_BUTTON_HEIGHT)
    clearBtn:SetPoint("LEFT", setBtn, "RIGHT", 4, 0)
    clearBtn:SetScript("OnClick", function()
        if not KT.currentSeqName then
            return
        end
        local KM = GRIPEMS.KeybindManager
        if KM then
            KM:ClearKeybind(KT.currentSeqName)
            KT:RefreshDisplay()
        end
    end)
    clearBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.bgRowHover:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
        UI:ShowTooltip(self, L["GEMS_UI_CLEAR_KEYBIND"])
    end)
    clearBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
        UI:HideTooltip()
    end)
    KT.clearBtn = clearBtn

    -- Open the keybind conflict panel. It reports across all five layers a key
    -- can be taken on; nothing in it changes any binding.
    local conflictBtn = UI:CreateButton(captureRow, L["GEMS_KC_OPEN_BUTTON"], 120, 22)
    conflictBtn:SetPoint("LEFT", clearBtn, "RIGHT", 4, 0)
    conflictBtn:SetScript("OnClick", function()
        local KCP = GRIPEMS.KeybindConflictPanel
        if KCP then
            KCP:Show()
        end
    end)
    conflictBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.bgRowHover:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
        UI:ShowTooltip(self, L["GEMS_KC_OPEN_BUTTON"], L["GEMS_KC_TITLE"])
    end)
    conflictBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
        UI:HideTooltip()
    end)
    KT.conflictBtn = conflictBtn

    -- Capture hint label (ESC to cancel)
    local captureHint = captureRow:CreateFontString(nil, "OVERLAY")
    UI:SetFont(captureHint, 9)
    captureHint:SetPoint("LEFT", clearBtn, "RIGHT", 8, 0)
    captureHint:SetText(L["GEMS_UI_CAPTURE_ESC_HINT"])
    captureHint:SetTextColor(C.textMuted:GetRGBA())
    captureHint:Hide()
    KT.captureHint = captureHint

    -- Suppress-in-this-loadout toggle (per-loadout mode only; populated by RefreshDisplay)
    local suppressBtn = CreateFrame("CheckButton", nil, captureRow, "UICheckButtonTemplate")
    suppressBtn:SetSize(20, 20)
    suppressBtn:SetPoint("LEFT", clearBtn, "RIGHT", 8, 0)
    if suppressBtn.text then
        suppressBtn.text:SetText(L["GEMS_KEYBINDS_SUPPRESS_IN_LOADOUT"])
    else
        local txt = suppressBtn:CreateFontString(nil, "OVERLAY")
        UI:SetFont(txt, 9)
        txt:SetPoint("LEFT", suppressBtn, "RIGHT", 4, 0)
        txt:SetText(L["GEMS_KEYBINDS_SUPPRESS_IN_LOADOUT"])
        txt:SetTextColor(C.textPrimary:GetRGBA())
        suppressBtn.text = txt
    end
    suppressBtn:Hide()
    suppressBtn:SetScript("OnClick", function(self)
        local KM = GRIPEMS.KeybindManager
        if not KM or not KT.currentSeqName then
            return
        end
        local perSpecKey = self._perSpecKey
        local activeLoadoutID = KM:_GetActiveLoadoutID()
        if not perSpecKey or not activeLoadoutID then
            return
        end
        if self:GetChecked() then
            KM:_SuppressKeybindForLoadout(perSpecKey, activeLoadoutID)
        else
            KM:_UnsuppressKeybindForLoadout(perSpecKey, activeLoadoutID)
        end
        KT:RefreshDisplay()
    end)
    suppressBtn:SetScript("OnEnter", function(self)
        UI:ShowTooltip(self, L["GEMS_KEYBINDS_SUPPRESS_IN_LOADOUT"], L["GEMS_KEYBINDS_SUPPRESS_IN_LOADOUT_TOOLTIP"])
    end)
    suppressBtn:SetScript("OnLeave", function()
        UI:HideTooltip()
    end)
    KT.suppressBtn = suppressBtn

    yOff = yOff - D().KEY_CAPTURE_BUTTON_HEIGHT - 16

    -- Copy bindings from another loadout (per-loadout mode only)
    local copyBtn = UI:CreateButton(frame, L["GEMS_KEYBINDS_COPY_BUTTON"], 220, D().KEY_CAPTURE_BUTTON_HEIGHT)
    copyBtn:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, yOff)
    copyBtn:Hide()
    copyBtn:SetScript("OnClick", function()
        KT:_ShowCopyLoadoutPicker()
    end)
    copyBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.bgRowHover:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
        UI:ShowTooltip(self, L["GEMS_KEYBINDS_COPY_BUTTON"])
    end)
    copyBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
        UI:HideTooltip()
    end)
    KT.copyBtn = copyBtn

    -- Manage all loadouts (per-loadout mode only): opens a popup with per-loadout
    -- entries and X buttons for pruning.
    local manageBtn = UI:CreateButton(frame, L["GEMS_KEYBINDS_MANAGE_ALL"], 160, D().KEY_CAPTURE_BUTTON_HEIGHT)
    manageBtn:SetPoint("LEFT", copyBtn, "RIGHT", 8, 0)
    manageBtn:Hide()
    manageBtn:SetScript("OnClick", function()
        KT:_ShowManageLoadoutsPopup()
    end)
    manageBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.bgRowHover:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
        UI:ShowTooltip(self, L["GEMS_KEYBINDS_MANAGE_ALL"])
    end)
    manageBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgButton:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
        UI:HideTooltip()
    end)
    KT.manageBtn = manageBtn

    yOff = yOff - D().KEY_CAPTURE_BUTTON_HEIGHT - 8

    -----------------------------------------------------------------------
    -- C) Spec Overview
    -----------------------------------------------------------------------
    local specLabel = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(specLabel, 10)
    specLabel:SetPoint("TOPLEFT", frame, "TOPLEFT", 8, yOff)
    specLabel:SetText(L["GEMS_UI_SPEC_KEYBINDS"])
    specLabel:SetTextColor(C.textSecondary:GetRGBA())
    KT.specLabel = specLabel

    -- Spec rows scroll panel (future-proofs for >4 specs)
    local specScroll, specChild = UI:CreateScrollPanel(frame)
    specScroll:SetPoint("TOPLEFT", specLabel, "BOTTOMLEFT", 0, -4)
    specScroll:SetPoint("RIGHT", frame, "RIGHT", -8, 0)
    specScroll:SetHeight(4 * D().SPEC_ROW_HEIGHT)
    local initSpecs = GetNumSpecializations and GetNumSpecializations() or 4
    specChild:SetHeight(math.max(initSpecs, 1) * D().SPEC_ROW_HEIGHT)
    KT.specScroll = specScroll
    KT.specContainer = specChild

    -- Loadout hint text
    local loadoutHint = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(loadoutHint, 9)
    loadoutHint:SetPoint("TOPLEFT", specScroll, "BOTTOMLEFT", 0, -6)
    loadoutHint:SetText(L["GEMS_UI_LOADOUT_COMING_SOON"])
    loadoutHint:SetTextColor(C.textMuted:GetRGBA())
    KT.loadoutHint = loadoutHint

    -----------------------------------------------------------------------
    -- D) Vehicle Keybinds Section (collapsible)
    -----------------------------------------------------------------------
    KT:CreateVehicleSection(frame, specScroll)

    -----------------------------------------------------------------------
    -- E) Pet Battle Keybinds Section (collapsible)
    -----------------------------------------------------------------------
    KT:CreatePetBattleSection(frame)

    -----------------------------------------------------------------------
    -- F) Hint text (bottom)
    -----------------------------------------------------------------------
    local hintText = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(hintText, 9)
    hintText:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 8, 8)
    hintText:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -8, 8)
    hintText:SetText(L["GEMS_UI_KEYBIND_HINT"])
    hintText:SetTextColor(C.textMuted:GetRGBA())
    hintText:SetJustifyH("LEFT")
    hintText:SetWordWrap(true)
    KT.hintText = hintText

    -- Gamepad hint (shown when controller detected)
    local gpHint = frame:CreateFontString(nil, "OVERLAY")
    UI:SetFont(gpHint, 9)
    gpHint:SetPoint("BOTTOMLEFT", hintText, "TOPLEFT", 0, 4)
    gpHint:SetText(L["GEMS_UI_GAMEPAD_HINT"])
    gpHint:SetTextColor(C.accent:GetRGBA())
    gpHint:Hide()
    KT.gpHint = gpHint

    -----------------------------------------------------------------------
    -- Key capture frame (invisible, fullscreen, eats all keypresses)
    -----------------------------------------------------------------------
    local captureFrame = CreateFrame("Frame", "GRIPEMS_KeyCapture", UIParent)
    captureFrame:SetFrameStrata("FULLSCREEN_DIALOG")
    captureFrame:SetAllPoints(UIParent)
    captureFrame:EnableKeyboard(true)
    captureFrame:EnableGamePadButton(true)
    captureFrame:EnableMouse(true)
    captureFrame:EnableMouseWheel(true)
    captureFrame:Hide()

    captureFrame:SetScript("OnKeyDown", function(self, key)
        KT:OnCaptureKeyDown(key)
    end)
    captureFrame:SetScript("OnGamePadButtonDown", function(self, button)
        KT:OnCaptureKeyDown(button)
    end)
    captureFrame:SetScript("OnMouseDown", function(self, button)
        local token = MOUSE_BUTTON_MAP[button]
        if not token then
            -- Button6..Button31 pass-through for extended mice
            local n = button and button:match("^Button(%d+)$")
            if n then
                token = "BUTTON" .. n
            end
        end
        if token then
            KT:OnCaptureKeyDown(token)
        end
    end)
    captureFrame:SetScript("OnMouseWheel", function(self, delta)
        if delta and delta > 0 then
            KT:OnCaptureKeyDown("MOUSEWHEELUP")
        elseif delta and delta < 0 then
            KT:OnCaptureKeyDown("MOUSEWHEELDOWN")
        end
    end)
    captureFrame:SetScript("OnShow", function(self)
        pcall(self.SetPropagateKeyboardInput, self, false)
    end)
    captureFrame:SetScript("OnHide", function(self)
        pcall(self.SetPropagateKeyboardInput, self, true)
    end)
    KT.captureFrame = captureFrame

    -- Register KEYBIND_CHANGED callback
    if GRIPEMS.RegisterCallback then
        GRIPEMS.RegisterCallback(KT, "KEYBIND_CHANGED", "OnKeybindChanged")
    end

    -- Combat transitions re-drive the capture-row button state live while the
    -- tab is on screen. Without this, the restricted Disable persisted until
    -- the next external refresh (tab switch or keybind change).
    local regenWatcher = CreateFrame("Frame")
    regenWatcher:RegisterEvent("PLAYER_REGEN_DISABLED")
    regenWatcher:RegisterEvent("PLAYER_REGEN_ENABLED")
    regenWatcher:SetScript("OnEvent", function()
        if KT.frame and KT.frame:IsShown() then
            KT:RefreshDisplay()
        end
    end)
    KT.regenWatcher = regenWatcher
end

---------------------------------------------------------------------------
-- Key capture logic
---------------------------------------------------------------------------

--- Start key capture mode. Checks combat lockdown first.
--- @param target table|nil Optional capture target { type, slot }
function KT:StartCapture(target)
    KT.captureTarget = target or { type = "sequence" }

    -- Sequence capture requires a selected sequence
    if KT.captureTarget.type == "sequence" and not KT.currentSeqName then
        return
    end

    if GRIPEMS.OOCQueue.IsRestricted() then
        GRIPEMS:Print(L["GEMS_UI_CAPTURE_COMBAT"])
        return
    end

    KT.isCapturing = true
    local C = UI.Colors

    -- Update button text
    if KT.setBtn and KT.setBtn.label then
        KT.setBtn.label:SetText(L["GEMS_UI_PRESS_KEY"])
        KT.setBtn:SetBackdropBorderColor(C.accent:GetRGBA())
    end

    -- Show capture hint
    if KT.captureHint then
        KT.captureHint:Show()
    end

    -- Show capture frame (with pcall safety)
    local ok, err = pcall(function()
        if KT.captureFrame then
            KT.captureFrame:Show()
        end
    end)
    if not ok then
        KT:StopCapture()
        GRIPEMS:Print("Capture error: " .. tostring(err))
    end
end

--- Stop key capture mode. Always hides the capture frame safely.
function KT:StopCapture()
    KT.isCapturing = false

    -- CRITICAL: Always hide the capture frame
    if KT.captureFrame then
        KT.captureFrame:Hide()
    end

    -- Hide capture hint
    if KT.captureHint then
        KT.captureHint:Hide()
    end

    -- Restore button text
    KT:UpdateSetButtonLabel()
end

--- Handle a key press during capture mode.
--- @param key string The WoW key name
function KT:OnCaptureKeyDown(key)
    -- Ignore lone modifier keys
    if MODIFIER_KEYS[key] then
        return
    end

    -- Escape cancels capture (deferred so ESCAPE isn't propagated to MainFrame)
    if key == "ESCAPE" then
        if C_Timer and C_Timer.After then
            C_Timer.After(0, function()
                KT:StopCapture()
            end)
        end
        return
    end

    -- BUTTON1 and BUTTON2 bare are unusable as keybinds
    -- (fire on normal clicks). Require at least one modifier.
    if
        (key == "BUTTON1" or key == "BUTTON2")
        and not IsAltKeyDown()
        and not IsControlKeyDown()
        and not IsShiftKeyDown()
    then
        if UIErrorsFrame and UIErrorsFrame.AddMessage then
            UIErrorsFrame:AddMessage(L["GEMS_KEYBIND_MOUSE_NEEDS_MODIFIER"], 1.0, 0.5, 0.0)
        end
        return
    end

    -- Build combo string: ALT-CTRL-SHIFT-KEY (alphabetical order)
    local parts = {}
    if IsAltKeyDown() then
        parts[#parts + 1] = "ALT"
    end
    if IsControlKeyDown() then
        parts[#parts + 1] = "CTRL"
    end
    if IsShiftKeyDown() then
        parts[#parts + 1] = "SHIFT"
    end
    parts[#parts + 1] = key
    local combo = table.concat(parts, "-")

    local target = KT.captureTarget or { type = "sequence" }

    -- Apply keybind based on capture target type (pcall for safety)
    local ok, err = pcall(function()
        if target.type == "vehicle" then
            local VK = GRIPEMS.VehicleKeybinds
            if VK and target.slot then
                VK:SetKeybind(target.slot, combo)
            end
        elseif target.type == "petbattle" then
            local PBM = GRIPEMS.PetBattleButtons
            if PBM and target.slot then
                PBM:SetKeybind(target.slot, combo)
            end
        else
            -- Default: sequence keybind
            local KM = GRIPEMS.KeybindManager
            -- Detect keybind conflict
            if KM and KM.GetCurrentSpec then
                local specIdx = KM:GetCurrentSpec()
                local specBinds = _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.keybinds and GRIP_EMS_CHAR.keybinds[specIdx]
                -- Resolve the same merged view GetKeybind renders, rather than the raw
                -- per-spec table. The raw read was wrong twice over: it never saw a
                -- conflict against an active-loadout overlay bind, and it warned about
                -- a per-spec key the active loadout had "__suppress__"ed -- a key that
                -- is not live and therefore cannot conflict.
                local conflictSeq = nil
                if specBinds and KM._ResolveFinalKeybinds then
                    local final = KM:_ResolveFinalKeybinds(specBinds, KM:_GetActiveLoadoutID())
                    conflictSeq = final and final[combo]
                elseif specBinds then
                    conflictSeq = specBinds[combo]
                end
                if conflictSeq and conflictSeq ~= KT.currentSeqName then
                    UIErrorsFrame:AddMessage(
                        string.format(L["GEMS_UI_KEYBIND_CONFLICT"], combo, conflictSeq),
                        1.0,
                        0.5,
                        0.0
                    )
                end
            end
            -- ConsolePort conflict warning
            local cpAction = KT.CheckConsolePortConflict(combo)
            if cpAction then
                UIErrorsFrame:AddMessage(
                    string.format(L["GEMS_UI_KEYBIND_CP_CONFLICT"], combo, tostring(cpAction)),
                    1.0,
                    0.7,
                    0.0
                )
            end
            if KM and KT.currentSeqName then
                KM:SetKeybind(KT.currentSeqName, combo)
            end
        end
    end)

    -- Always stop capture (hides the capture frame). Deferred to the next
    -- frame so the key that was just captured is NOT propagated to the editor.
    -- A synchronous StopCapture hides the frame mid-keypress, and the frame's
    -- OnHide flips SetPropagateKeyboardInput back to true, which leaks the digit
    -- to the SequenceEditor tab-jump handler (reported bug "Setting Keybind
    -- switches Tabs"). The ESCAPE branch above already defers for this reason.
    local function finishCapture()
        KT:StopCapture()
        KT:RefreshDisplay()
        KT:RefreshVehicleSection()
        KT:RefreshPetBattleSection()
    end
    if C_Timer and C_Timer.After then
        C_Timer.After(0, finishCapture)
    else
        finishCapture()
    end

    if not ok then
        GRIPEMS:Print("Keybind error: " .. tostring(err))
    end
end

---------------------------------------------------------------------------
-- Display refresh
---------------------------------------------------------------------------

--- Update the Set/Change button label based on current keybind state.
function KT:UpdateSetButtonLabel()
    if not KT.setBtn or not KT.setBtn.label then
        return
    end
    local KM = GRIPEMS.KeybindManager
    local currentKey = KM and KT.currentSeqName and KM:GetKeybind(KT.currentSeqName)

    if currentKey then
        KT.setBtn.label:SetText(L["GEMS_UI_CHANGE_KEYBIND"])
    else
        KT.setBtn.label:SetText(L["GEMS_UI_SET_KEYBIND"])
    end

    local C = UI.Colors
    KT.setBtn:SetBackdropBorderColor(C.border:GetRGBA())
end

--- Refresh the entire keybind tab display.
function KT:RefreshDisplay()
    if not KT.frame then
        return
    end
    local C = UI.Colors
    local KM = GRIPEMS.KeybindManager

    -- Current keybind display
    local currentKey = KM and KT.currentSeqName and KM:GetKeybind(KT.currentSeqName)
    if KT.kbDisplay then
        if currentKey then
            KT.kbDisplay:SetText(FormatKeyDisplay(currentKey))
            KT.kbDisplay:SetTextColor(C.keybindGold:GetRGBA())
        else
            KT.kbDisplay:SetText(L["GEMS_UI_KEYBIND_DISPLAY_NONE"])
            KT.kbDisplay:SetTextColor(C.textMuted:GetRGBA())
        end
    end

    -- Button states
    KT:UpdateSetButtonLabel()

    -- Clear button: disabled if no keybind
    if KT.clearBtn then
        if currentKey then
            KT.clearBtn:Enable()
            KT.clearBtn.label:SetTextColor(C.textPrimary:GetRGBA())
            KT.clearBtn:SetBackdropColor(C.bgButton:GetRGBA())
        else
            KT.clearBtn:Disable()
            KT.clearBtn.label:SetTextColor(C.textMuted:GetRGBA())
            KT.clearBtn:SetBackdropColor(C.bgDeep:GetRGBA())
        end
    end

    -- Set button: requires a loaded sequence; recomputed BOTH ways on every
    -- refresh, mirroring the Clear button recompute above. The old shape only
    -- enabled inside the non-restricted branch when currentSeqName was set,
    -- with no else -- a combat-time Disable stuck forever once currentSeqName
    -- went nil (in-combat New Sequence flow; community report 2026-07-15).
    if KT.setBtn then
        if KT.currentSeqName then
            KT.setBtn:Enable()
            KT.setBtn.label:SetTextColor(C.textPrimary:GetRGBA())
            KT.setBtn:SetBackdropColor(C.bgButton:GetRGBA())
        else
            KT.setBtn:Disable()
            KT.setBtn.label:SetTextColor(C.textMuted:GetRGBA())
            KT.setBtn:SetBackdropColor(C.bgDeep:GetRGBA())
        end
    end

    -- Combat/restriction lockdown overrides both buttons to disabled while it
    -- holds; the recomputes above re-drive them on the next refresh (the regen
    -- watcher in Init fires one when combat ends).
    if GRIPEMS.OOCQueue.IsRestricted() then
        if KT.setBtn then
            KT.setBtn:Disable()
            KT.setBtn.label:SetTextColor(C.textMuted:GetRGBA())
            KT.setBtn:SetBackdropColor(C.bgDeep:GetRGBA())
        end
        if KT.clearBtn then
            KT.clearBtn:Disable()
            KT.clearBtn.label:SetTextColor(C.textMuted:GetRGBA())
            KT.clearBtn:SetBackdropColor(C.bgDeep:GetRGBA())
        end
    end

    -- Simplified Mode keeps the capture row visible. The Keybind tab is one of
    -- the two whitelisted simplified tabs and binding is its core task; the
    -- old conditional hide left "Current Keybind: None" with no Set/Clear
    -- affordance and no explanation (community report 2026-07-10).
    if KT.captureRow and KT.captureRow.Show then
        KT.captureRow:Show()
    end

    -- Per-loadout state surfaces: status hint, suppress checkbox, copy/manage buttons
    KT:_RefreshPerLoadoutWidgets(KM)

    -- Spec overview
    KT:RefreshSpecOverview()
end

--- Update visibility and text of every per-loadout UI widget based on the
--- GRIP_EMS_CHAR.keybindsPerLoadout flag and active-loadout resolvability.
--- @param KM table The KeybindManager module
function KT:_RefreshPerLoadoutWidgets(KM)
    local perLoadoutOn = _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.keybindsPerLoadout
    local activeLoadoutID = KM and KM._GetActiveLoadoutID and KM:_GetActiveLoadoutID() or nil
    local activeLoadoutName = nil
    if KM and KM._GetActiveLoadoutName and activeLoadoutID then
        activeLoadoutName = KM:_GetActiveLoadoutName(activeLoadoutID)
    end

    -- Status hint
    if KT.statusHintFrame then
        if not perLoadoutOn then
            KT.statusHintFrame:Hide()
        else
            KT.statusHintFrame:Show()
            if KT.statusHintText then
                if activeLoadoutID and activeLoadoutName then
                    KT.statusHintText:SetText(string.format(L["GEMS_KEYBINDS_ACTIVE_LOADOUT_LABEL"], activeLoadoutName))
                else
                    KT.statusHintText:SetText(L["GEMS_KEYBINDS_NO_ACTIVE_LOADOUT"])
                end
            end
        end
    end

    -- Suppress checkbox: shown only when per-loadout mode is on, active loadout
    -- resolvable, and the current sequence has a per-spec binding (not just a
    -- per-loadout binding).
    if KT.suppressBtn then
        local show = perLoadoutOn and activeLoadoutID and KT.currentSeqName
        local perSpecKey = nil
        if show and KM then
            local perSpec = KM.GetPerSpecKeybinds and KM:GetPerSpecKeybinds() or nil
            if perSpec then
                for key, seqName in pairs(perSpec) do
                    if seqName == KT.currentSeqName then
                        perSpecKey = key
                        break
                    end
                end
            end
        end
        if show and perSpecKey then
            KT.suppressBtn._perSpecKey = perSpecKey
            local overlay = KM.GetPerLoadoutKeybinds and KM:GetPerLoadoutKeybinds(activeLoadoutID) or nil
            local isSuppressed = overlay and overlay[perSpecKey] == "__suppress__"
            KT.suppressBtn:SetChecked(isSuppressed and true or false)
            KT.suppressBtn:Show()
        else
            KT.suppressBtn._perSpecKey = nil
            KT.suppressBtn:Hide()
        end
    end

    -- Copy + manage buttons: shown only when per-loadout mode is on and
    -- active loadout resolvable.
    local copyManageShow = perLoadoutOn and activeLoadoutID
    if KT.copyBtn then
        KT.copyBtn:SetShown(copyManageShow and true or false)
    end
    if KT.manageBtn then
        KT.manageBtn:SetShown(copyManageShow and true or false)
    end
end

--- Refresh the spec overview section.
function KT:RefreshSpecOverview()
    if not KT.specContainer then
        return
    end
    local C = UI.Colors
    local KM = GRIPEMS.KeybindManager

    -- Clear existing spec rows
    if KT.specRows then
        for _, row in ipairs(KT.specRows) do
            row:Hide()
        end
    end
    KT.specRows = KT.specRows or {}

    local numSpecs = GetNumSpecializations() or 0
    local currentSpec = KM and KM:GetCurrentSpec() or 0

    for i = 1, numSpecs do
        local _, specName, _, specIcon = C_SpecializationInfo.GetSpecializationInfo(i)
        if not specName then
            specName = "Spec " .. i
        end

        -- Create row frame if needed
        local row = KT.specRows[i]
        if not row then
            row = CreateFrame("Frame", nil, KT.specContainer, "BackdropTemplate")
            row:SetHeight(D().SPEC_ROW_HEIGHT)

            if not row.SetBackdrop then
                Mixin(row, BackdropTemplateMixin)
            end
            row:SetBackdrop(UI.Backdrops.panelNoBorder)

            -- Spec icon
            row.icon = row:CreateTexture(nil, "ARTWORK")
            row.icon:SetSize(20, 20)
            row.icon:SetPoint("LEFT", row, "LEFT", 4, 0)

            -- Spec name
            row.nameText = row:CreateFontString(nil, "OVERLAY")
            UI:SetFont(row.nameText, 11)
            row.nameText:SetPoint("LEFT", row.icon, "RIGHT", 6, 0)

            -- Key display
            row.keyText = row:CreateFontString(nil, "OVERLAY")
            UI:SetFont(row.keyText, 11)
            row.keyText:SetPoint("RIGHT", row, "RIGHT", -4, 0)

            -- Per-loadout overrides hint (small, below the key display)
            row.overrideHint = row:CreateFontString(nil, "OVERLAY")
            UI:SetFont(row.overrideHint, 9)
            row.overrideHint:SetPoint("RIGHT", row, "RIGHT", -4, -10)
            row.overrideHint:SetTextColor(C.textMuted:GetRGBA())
            row.overrideHint:Hide()

            KT.specRows[i] = row
        end

        -- Position
        row:SetPoint("TOPLEFT", KT.specContainer, "TOPLEFT", 0, -(i - 1) * D().SPEC_ROW_HEIGHT)
        row:SetPoint("RIGHT", KT.specContainer, "RIGHT", 0, 0)

        -- Icon
        if specIcon then
            row.icon:SetTexture(specIcon)
        end

        -- Name with (current) suffix
        local isCurrent = (i == currentSpec)
        if isCurrent then
            row.nameText:SetText(specName .. " " .. L["GEMS_UI_CURRENT_SPEC"])
            row.nameText:SetTextColor(C.textPrimary:GetRGBA())
            row:SetBackdropColor(C.bgRowSelected:GetRGBA())
        else
            row.nameText:SetText(specName)
            row.nameText:SetTextColor(C.textSecondary:GetRGBA())
            row:SetBackdropColor(0, 0, 0, 0)
        end

        -- Find keybind for this spec and current sequence (skip _byLoadout subtable)
        local specKey = nil
        if KT.currentSeqName and _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.keybinds and GRIP_EMS_CHAR.keybinds[i] then
            for key, seqName in pairs(GRIP_EMS_CHAR.keybinds[i]) do
                if key ~= "_byLoadout" and seqName == KT.currentSeqName then
                    specKey = key
                    break
                end
            end
        end

        if specKey then
            row.keyText:SetText(FormatKeyDisplay(specKey))
            row.keyText:SetTextColor(C.keybindGold:GetRGBA())
        else
            row.keyText:SetText(L["GEMS_UI_KEYBIND_DISPLAY_NONE"])
            row.keyText:SetTextColor(C.textMuted:GetRGBA())
        end

        -- Per-loadout overrides hint: count of distinct loadouts under this spec
        -- that have at least one entry in their _byLoadout overlay.
        if row.overrideHint then
            local loadoutCount = 0
            if _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.keybinds and GRIP_EMS_CHAR.keybinds[i] then
                local specBinds = GRIP_EMS_CHAR.keybinds[i]
                if specBinds._byLoadout then
                    for _, loadoutBinds in pairs(specBinds._byLoadout) do
                        if type(loadoutBinds) == "table" and next(loadoutBinds) ~= nil then
                            loadoutCount = loadoutCount + 1
                        end
                    end
                end
            end
            if loadoutCount > 0 then
                row.overrideHint:SetText(string.format(L["GEMS_KEYBINDS_LOADOUT_OVERRIDES_HINT"], loadoutCount))
                row.overrideHint:Show()
            else
                row.overrideHint:Hide()
            end
        end

        row:Show()
    end

    -- Adjust scroll child height for content
    KT.specContainer:SetHeight(math.max(numSpecs, 1) * D().SPEC_ROW_HEIGHT)
end

---------------------------------------------------------------------------
-- Per-loadout popups
---------------------------------------------------------------------------

--- Lazy-create the copy-from-loadout picker popup. Lists loadouts with
--- bindings; clicking a row calls KM:CopyKeybindsFromLoadout into the
--- currently-active loadout.
function KT:_ShowCopyLoadoutPicker()
    local KM = GRIPEMS.KeybindManager
    if not KM then
        return
    end
    local activeLoadoutID = KM:_GetActiveLoadoutID()
    if not activeLoadoutID then
        return
    end
    local entries = KM:GetAllLoadoutsWithBindings()
    KT:_PopulateLoadoutPickerPopup("copy", entries, activeLoadoutID)
end

--- Lazy-create the manage-all-loadouts popup. Lists every loadout with
--- bindings; clicking the X clears that loadout's overlay via KM:PruneKeybindsForLoadout.
function KT:_ShowManageLoadoutsPopup()
    local KM = GRIPEMS.KeybindManager
    if not KM then
        return
    end
    local entries = KM:GetAllLoadoutsWithBindings()
    KT:_PopulateLoadoutPickerPopup("manage", entries, nil)
end

--- Lazy-create and populate the shared popup frame for both modes.
--- @param mode string "copy" or "manage"
--- @param entries table Array of { id, name, bindingCount } from KM:GetAllLoadoutsWithBindings
--- @param activeLoadoutID number? Target loadout for copy mode; ignored for manage mode
function KT:_PopulateLoadoutPickerPopup(mode, entries, activeLoadoutID)
    local C = UI.Colors
    if not KT.loadoutPickerPopup then
        local popup = CreateFrame("Frame", "GRIPEMS_LoadoutPickerPopup", UIParent, "BackdropTemplate")
        popup:SetSize(340, 220)
        popup:SetPoint("CENTER")
        popup:SetFrameStrata("DIALOG")
        if not popup.SetBackdrop then
            Mixin(popup, BackdropTemplateMixin)
        end
        popup:SetBackdrop(UI.Backdrops.panel)
        popup:SetBackdropColor(C.bgDeep:GetRGBA())
        popup:SetBackdropBorderColor(C.border:GetRGBA())
        popup:EnableMouse(true)
        popup:SetMovable(true)
        popup:RegisterForDrag("LeftButton")
        popup:SetScript("OnDragStart", popup.StartMoving)
        popup:SetScript("OnDragStop", popup.StopMovingOrSizing)

        local header = popup:CreateFontString(nil, "OVERLAY")
        UI:SetFont(header, 12)
        header:SetPoint("TOP", popup, "TOP", 0, -8)
        header:SetTextColor(C.textPrimary:GetRGBA())
        popup.header = header

        local closeBtn = UI:CreateButton(popup, "X", 22, 22)
        closeBtn:SetPoint("TOPRIGHT", popup, "TOPRIGHT", -6, -6)
        closeBtn:SetScript("OnClick", function()
            popup:Hide()
        end)
        popup.closeBtn = closeBtn

        local scroll, scrollChild = UI:CreateScrollPanel(popup)
        scroll:SetPoint("TOPLEFT", popup, "TOPLEFT", 8, -32)
        scroll:SetPoint("BOTTOMRIGHT", popup, "BOTTOMRIGHT", -8, 8)
        popup.scroll = scroll
        popup.scrollChild = scrollChild
        popup.rows = {}

        KT.loadoutPickerPopup = popup
    end

    local popup = KT.loadoutPickerPopup
    if mode == "copy" then
        popup.header:SetText(L["GEMS_KEYBINDS_COPY_BUTTON"])
    else
        popup.header:SetText(L["GEMS_KEYBINDS_MANAGE_ALL"])
    end

    -- Hide all existing rows
    for _, row in ipairs(popup.rows) do
        row:Hide()
    end

    local rowHeight = 22
    local y = 0
    for i, entry in ipairs(entries) do
        if mode ~= "copy" or entry.id ~= activeLoadoutID then
            local row = popup.rows[i]
            if not row then
                row = CreateFrame("Frame", nil, popup.scrollChild)
                row:SetHeight(rowHeight)
                row.label = row:CreateFontString(nil, "OVERLAY")
                UI:SetFont(row.label, 10)
                row.label:SetPoint("LEFT", row, "LEFT", 4, 0)
                row.label:SetTextColor(UI.Colors.textPrimary:GetRGBA())
                row.actionBtn = UI:CreateButton(row, "", 60, 18)
                row.actionBtn:SetPoint("RIGHT", row, "RIGHT", -4, 0)
                popup.rows[i] = row
            end
            row:ClearAllPoints()
            row:SetPoint("TOPLEFT", popup.scrollChild, "TOPLEFT", 0, -y)
            row:SetPoint("RIGHT", popup.scrollChild, "RIGHT", 0, 0)
            row.label:SetText(string.format(L["GEMS_KEYBINDS_LOADOUT_BINDING_COUNT"], entry.name, entry.bindingCount))
            local targetID = entry.id
            if mode == "copy" then
                row.actionBtn.label:SetText("Copy")
                row.actionBtn:SetScript("OnClick", function()
                    local KM = GRIPEMS.KeybindManager
                    if KM and activeLoadoutID then
                        KM:CopyKeybindsFromLoadout(targetID, activeLoadoutID)
                    end
                    popup:Hide()
                    KT:RefreshDisplay()
                end)
            else
                row.actionBtn.label:SetText("X")
                row.actionBtn:SetScript("OnClick", function()
                    local KM = GRIPEMS.KeybindManager
                    if KM then
                        -- isDeletion=false: the loadout still exists, this just
                        -- clears its overlay -- neutral wording, leave the LKG
                        -- snapshot untouched.
                        KM:PruneKeybindsForLoadout(targetID, false)
                        KM:ScheduleLoadKeybinds()
                    end
                    KT:RefreshDisplay()
                    KT:_PopulateLoadoutPickerPopup(mode, KM and KM:GetAllLoadoutsWithBindings() or {}, activeLoadoutID)
                end)
            end
            row:Show()
            y = y + rowHeight
        end
    end
    popup.scrollChild:SetHeight(math.max(y, rowHeight))
    popup:Show()
end

---------------------------------------------------------------------------
-- Data flow methods (called by SequenceEditor)
---------------------------------------------------------------------------

--- Load keybind data for a sequence.
--- @param name string Sequence name
function KT:LoadSequence(name)
    KT.currentSeqName = name
    KT:RefreshDisplay()
end

--- Clear the keybind tab.
function KT:Clear()
    KT.currentSeqName = nil
    -- Pop the focus context if KT:Show pushed it. The editor teardown path can
    -- reach Clear without Hide; the _focusPushed guard keeps this balanced.
    -- Top-guarded: PopContext is a no-op + warning when another context is on
    -- top (e.g. the delete-confirm popup), and clearing the flag on a refused
    -- pop leaks the KeybindTab context mid-stack while KT:Show re-pushes a
    -- duplicate later. Only pop + clear when the pop can actually happen.
    if GRIPEMS.Focus and GRIPEMS.Focus.PopContext and KT._focusPushed then
        local top = GRIPEMS.Focus.TopContext and GRIPEMS.Focus:TopContext()
        if top and top.name == "KeybindTab" then
            GRIPEMS.Focus:PopContext("KeybindTab")
            KT._focusPushed = false
        end
    end
    KT:StopCapture()

    local C = UI.Colors
    if KT.kbDisplay then
        KT.kbDisplay:SetText(L["GEMS_UI_KEYBIND_DISPLAY_NONE"])
        KT.kbDisplay:SetTextColor(C.textMuted:GetRGBA())
    end

    -- Keep the Set button honest on editor-clear paths: Clear nils the
    -- loaded name without running RefreshDisplay, which used to leave a
    -- stale-enabled no-op button until the next refresh.
    if KT.setBtn then
        KT.setBtn:Disable()
        KT.setBtn.label:SetTextColor(C.textMuted:GetRGBA())
        KT.setBtn:SetBackdropColor(C.bgDeep:GetRGBA())
    end

    if KT.specRows then
        for _, row in ipairs(KT.specRows) do
            row:Hide()
        end
    end
end

--- Build the ordered array of focusable controls currently shown on the tab.
--- Visual order: Set, Clear, then the per-loadout suppress / copy / manage
--- buttons, each appended only when it exists and is shown. Fed to
--- Focus:PushContext so keyboard users can Tab to the capture row and the
--- per-loadout buttons.
--- @return table Ordered array of focusable button frames
function KT:GetFocusTargets()
    local targets = {}
    local function add(frame)
        if frame and frame.IsShown and frame:IsShown() then
            targets[#targets + 1] = frame
        end
    end
    add(KT.setBtn)
    add(KT.clearBtn)
    add(KT.conflictBtn)
    add(KT.suppressBtn)
    add(KT.copyBtn)
    add(KT.manageBtn)
    return targets
end

--- Show the keybind tab.
function KT:Show()
    if KT.frame then
        KT.frame:Show()
    end
    if GRIPEMS.gamepadDetected and KT.gpHint then
        KT.gpHint:Show()
    elseif KT.gpHint then
        KT.gpHint:Hide()
    end
    KT:RefreshDisplay()
    KT:RefreshVehicleSection()
    KT:RefreshPetBattleSection()

    -- Register the capture controls and per-loadout buttons with the keyboard
    -- focus stack so they are Tab-reachable while this tab is shown. Pushed
    -- after the refresh calls above so per-loadout shown-state is current, and
    -- guarded so a repeated Show does not stack duplicate contexts.
    if GRIPEMS.Focus and GRIPEMS.Focus.PushContext and not KT._focusPushed then
        GRIPEMS.Focus:PushContext("KeybindTab", KT:GetFocusTargets())
        KT._focusPushed = true
    end
end

--- Hide the keybind tab.
function KT:Hide()
    if KT.frame then
        KT.frame:Hide()
    end
    -- Pop the focus context pushed by KT:Show so the stack stays balanced.
    -- Top-guarded like KT:Clear: never clear the flag on a refused pop.
    if GRIPEMS.Focus and GRIPEMS.Focus.PopContext and KT._focusPushed then
        local top = GRIPEMS.Focus.TopContext and GRIPEMS.Focus:TopContext()
        if top and top.name == "KeybindTab" then
            GRIPEMS.Focus:PopContext("KeybindTab")
            KT._focusPushed = false
        end
    end
    KT:StopCapture()
end

---------------------------------------------------------------------------
-- Callback handler
---------------------------------------------------------------------------

--- Respond to KEYBIND_CHANGED events.
function KT:OnKeybindChanged(event, seqName, key)
    if KT.frame and KT.frame:IsShown() then
        KT:RefreshDisplay()
    end
end

--- Respond to VEHICLE_KEYBIND_CHANGED events.
function KT:OnVehicleKeybindChanged()
    if KT.frame and KT.frame:IsShown() then
        KT:RefreshVehicleSection()
    end
end

--- Respond to PET_BATTLE_KEYBIND_CHANGED events.
function KT:OnPetBattleKeybindChanged()
    if KT.frame and KT.frame:IsShown() then
        KT:RefreshPetBattleSection()
    end
end

---------------------------------------------------------------------------
-- Vehicle Keybinds Section
---------------------------------------------------------------------------

--- Create the collapsible vehicle keybinds section (12 slots).
--- @param parent Frame Parent frame
--- @param anchor Frame Frame to anchor below
function KT:CreateVehicleSection(parent, anchor)
    local C = UI.Colors

    -- Container for entire vehicle section
    local section = CreateFrame("Frame", nil, parent)
    section:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", 0, -12)
    section:SetPoint("RIGHT", parent, "RIGHT", -8, 0)
    KT.vehicleSection = section

    -- Collapse header
    local header = CreateFrame("Button", nil, section)
    header:SetHeight(20)
    header:SetPoint("TOPLEFT", section, "TOPLEFT", 0, 0)
    header:SetPoint("RIGHT", section, "RIGHT", 0, 0)

    local headerText = header:CreateFontString(nil, "OVERLAY")
    UI:SetFont(headerText, 10)
    headerText:SetPoint("LEFT", header, "LEFT", 0, 0)
    headerText:SetText(L["GEMS_VEHICLE_KEYBINDS_HEADER"])
    headerText:SetTextColor(C.textSecondary:GetRGBA())
    KT.vehicleHeaderText = headerText

    local collapseIndicator = header:CreateFontString(nil, "OVERLAY")
    UI:SetFont(collapseIndicator, 10)
    collapseIndicator:SetPoint("RIGHT", header, "RIGHT", 0, 0)
    collapseIndicator:SetTextColor(C.textMuted:GetRGBA())
    KT.vehicleCollapseIndicator = collapseIndicator

    -- Content frame (hidden when collapsed)
    local content = CreateFrame("Frame", nil, section)
    content:SetPoint("TOPLEFT", header, "BOTTOMLEFT", 0, -4)
    content:SetPoint("RIGHT", section, "RIGHT", 0, 0)
    KT.vehicleContent = content

    -- Vehicle slot rows
    KT.vehicleRows = {}
    for slot = 1, D().VEHICLE_KEYBIND_SLOTS do
        local row = CreateFrame("Frame", nil, content)
        row:SetHeight(D().SPEC_ROW_HEIGHT)
        row:SetPoint("TOPLEFT", content, "TOPLEFT", 0, -(slot - 1) * D().SPEC_ROW_HEIGHT)
        row:SetPoint("RIGHT", content, "RIGHT", 0, 0)

        -- Slot label
        row.slotLabel = row:CreateFontString(nil, "OVERLAY")
        UI:SetFont(row.slotLabel, 10)
        row.slotLabel:SetPoint("LEFT", row, "LEFT", 4, 0)
        row.slotLabel:SetText(string.format(L["GEMS_VEHICLE_SLOT"], slot))
        row.slotLabel:SetTextColor(C.textSecondary:GetRGBA())

        -- Key display
        row.keyText = row:CreateFontString(nil, "OVERLAY")
        UI:SetFont(row.keyText, 10)
        row.keyText:SetPoint("CENTER", row, "CENTER", 0, 0)
        row.keyText:SetText(L["GEMS_UI_NOT_BOUND"])
        row.keyText:SetTextColor(C.textMuted:GetRGBA())

        -- Clear button
        local clearBtn = UI:CreateButton(row, L["GEMS_UI_CLEAR_KEYBIND"], 50, 20)
        clearBtn:SetPoint("RIGHT", row, "RIGHT", 0, 0)
        clearBtn.slot = slot
        clearBtn:SetScript("OnClick", function()
            local VK = GRIPEMS.VehicleKeybinds
            if VK then
                VK:ClearKeybind(slot)
                KT:RefreshVehicleSection()
            end
        end)

        -- Set button
        local setBtn = UI:CreateButton(row, L["GEMS_UI_SET_KEYBIND"], 60, 20)
        setBtn:SetPoint("RIGHT", clearBtn, "LEFT", -4, 0)
        setBtn.slot = slot
        setBtn:SetScript("OnClick", function()
            KT:StartCapture({ type = "vehicle", slot = slot })
        end)

        row.setBtn = setBtn
        row.clearBtn = clearBtn
        KT.vehicleRows[slot] = row
    end

    content:SetHeight(D().VEHICLE_KEYBIND_SLOTS * D().SPEC_ROW_HEIGHT)

    -- Default collapsed state from saved data
    local expanded = _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.vehicleKeybindsExpanded
    if expanded then
        content:Show()
        collapseIndicator:SetText("[-]")
    else
        content:Hide()
        collapseIndicator:SetText("[+]")
    end

    -- Update section height
    KT:UpdateVehicleSectionHeight()

    header:SetScript("OnClick", function()
        if not _G.GRIP_EMS_CHAR then
            return
        end
        GRIP_EMS_CHAR.vehicleKeybindsExpanded = not GRIP_EMS_CHAR.vehicleKeybindsExpanded
        if GRIP_EMS_CHAR.vehicleKeybindsExpanded then
            content:Show()
            collapseIndicator:SetText("[-]")
        else
            content:Hide()
            collapseIndicator:SetText("[+]")
        end
        KT:UpdateVehicleSectionHeight()
        KT:UpdatePetBattleSectionAnchor()
    end)

    -- Contention notice: shown in the header when the external
    -- sequencer's sky-riding binds claim the same physical keys as our
    -- vehicle slots.
    local warn = header:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    warn:SetPoint("RIGHT", header, "RIGHT", -4, 0)
    warn:SetJustifyH("RIGHT")
    warn:SetWordWrap(false)
    warn:SetTextColor(1, 0.6, 0.2)
    KT.vehicleExtWarn = warn
    KT:UpdateVehicleExternalBindWarning()

    -- Register callback
    if GRIPEMS.RegisterCallback then
        GRIPEMS.RegisterCallback(KT, "VEHICLE_KEYBIND_CHANGED", "OnVehicleKeybindChanged")
    end
end

--- Update the height of the vehicle section based on collapse state.
function KT:UpdateVehicleSectionHeight()
    if not KT.vehicleSection then
        return
    end
    local headerHeight = 20
    if KT.vehicleContent and KT.vehicleContent:IsShown() then
        KT.vehicleSection:SetHeight(headerHeight + 4 + D().VEHICLE_KEYBIND_SLOTS * D().SPEC_ROW_HEIGHT)
    else
        KT.vehicleSection:SetHeight(headerHeight)
    end
end

--- Refresh the vehicle keybinds section display.
function KT:RefreshVehicleSection()
    if not KT.vehicleRows then
        return
    end
    local C = UI.Colors
    local VK = GRIPEMS.VehicleKeybinds

    for slot = 1, D().VEHICLE_KEYBIND_SLOTS do
        local row = KT.vehicleRows[slot]
        if row then
            local key = VK and VK:GetKeybind(slot)
            if key then
                row.keyText:SetText(FormatKeyDisplay(key))
                row.keyText:SetTextColor(C.keybindGold:GetRGBA())
            else
                row.keyText:SetText(L["GEMS_UI_NOT_BOUND"])
                row.keyText:SetTextColor(C.textMuted:GetRGBA())
            end
        end
    end
    KT:UpdateVehicleExternalBindWarning()
end

--- Update the vehicle-section header notice that flags physical keys
--- also claimed by the external sequencer's sky-riding bind feature.
function KT:UpdateVehicleExternalBindWarning()
    if not KT.vehicleExtWarn then
        return
    end
    local VK = GRIPEMS.VehicleKeybinds
    local hits = VK and VK.GetExternalSkyrideBindCollisions and VK:GetExternalSkyrideBindCollisions()
    if hits then
        KT.vehicleExtWarn:SetText(string.format(L["GEMS_VEHICLE_EXT_COLLISION"], "GSE_QoL", table.concat(hits, ", ")))
        KT.vehicleExtWarn:Show()
    else
        KT.vehicleExtWarn:Hide()
    end
end

---------------------------------------------------------------------------
-- Pet Battle Keybinds Section
---------------------------------------------------------------------------

--- Create the collapsible pet battle keybinds section (6 slots).
--- @param parent Frame Parent frame
function KT:CreatePetBattleSection(parent)
    local C = UI.Colors

    -- Container for entire pet battle section
    local section = CreateFrame("Frame", nil, parent)
    section:SetPoint("TOPLEFT", KT.vehicleSection, "BOTTOMLEFT", 0, -8)
    section:SetPoint("RIGHT", parent, "RIGHT", -8, 0)
    KT.petBattleSection = section

    -- Collapse header
    local header = CreateFrame("Button", nil, section)
    header:SetHeight(20)
    header:SetPoint("TOPLEFT", section, "TOPLEFT", 0, 0)
    header:SetPoint("RIGHT", section, "RIGHT", 0, 0)

    local headerText = header:CreateFontString(nil, "OVERLAY")
    UI:SetFont(headerText, 10)
    headerText:SetPoint("LEFT", header, "LEFT", 0, 0)
    headerText:SetText(L["GEMS_PET_BATTLE_KEYBINDS_HEADER"])
    headerText:SetTextColor(C.textSecondary:GetRGBA())
    KT.petBattleHeaderText = headerText

    local collapseIndicator = header:CreateFontString(nil, "OVERLAY")
    UI:SetFont(collapseIndicator, 10)
    collapseIndicator:SetPoint("RIGHT", header, "RIGHT", 0, 0)
    collapseIndicator:SetTextColor(C.textMuted:GetRGBA())
    KT.petBattleCollapseIndicator = collapseIndicator

    -- Content frame (hidden when collapsed)
    local content = CreateFrame("Frame", nil, section)
    content:SetPoint("TOPLEFT", header, "BOTTOMLEFT", 0, -4)
    content:SetPoint("RIGHT", section, "RIGHT", 0, 0)
    KT.petBattleContent = content

    -- Slot labels for pet battle
    local slotLabels = D().PET_BATTLE_SLOT_NAMES

    -- Pet battle slot rows
    KT.petBattleRows = {}
    for slot = 1, D().PET_BATTLE_SLOTS do
        local row = CreateFrame("Frame", nil, content)
        row:SetHeight(D().SPEC_ROW_HEIGHT)
        row:SetPoint("TOPLEFT", content, "TOPLEFT", 0, -(slot - 1) * D().SPEC_ROW_HEIGHT)
        row:SetPoint("RIGHT", content, "RIGHT", 0, 0)

        -- Slot label
        row.slotLabel = row:CreateFontString(nil, "OVERLAY")
        UI:SetFont(row.slotLabel, 10)
        row.slotLabel:SetPoint("LEFT", row, "LEFT", 4, 0)
        row.slotLabel:SetText(slotLabels[slot] or ("Slot " .. slot))
        row.slotLabel:SetTextColor(C.textSecondary:GetRGBA())

        -- Key display
        row.keyText = row:CreateFontString(nil, "OVERLAY")
        UI:SetFont(row.keyText, 10)
        row.keyText:SetPoint("CENTER", row, "CENTER", 0, 0)
        row.keyText:SetText(L["GEMS_UI_NOT_BOUND"])
        row.keyText:SetTextColor(C.textMuted:GetRGBA())

        -- Clear button
        local clearBtn = UI:CreateButton(row, L["GEMS_UI_CLEAR_KEYBIND"], 50, 20)
        clearBtn:SetPoint("RIGHT", row, "RIGHT", 0, 0)
        clearBtn.slot = slot
        clearBtn:SetScript("OnClick", function()
            local PBM = GRIPEMS.PetBattleButtons
            if PBM then
                PBM:ClearKeybind(slot)
                KT:RefreshPetBattleSection()
            end
        end)

        -- Set button
        local setBtn = UI:CreateButton(row, L["GEMS_UI_SET_KEYBIND"], 60, 20)
        setBtn:SetPoint("RIGHT", clearBtn, "LEFT", -4, 0)
        setBtn.slot = slot
        setBtn:SetScript("OnClick", function()
            KT:StartCapture({ type = "petbattle", slot = slot })
        end)

        row.setBtn = setBtn
        row.clearBtn = clearBtn
        KT.petBattleRows[slot] = row
    end

    content:SetHeight(D().PET_BATTLE_SLOTS * D().SPEC_ROW_HEIGHT)

    -- Default collapsed state from saved data
    local expanded = _G.GRIP_EMS_CHAR and GRIP_EMS_CHAR.petBattleKeybindsExpanded
    if expanded then
        content:Show()
        collapseIndicator:SetText("[-]")
    else
        content:Hide()
        collapseIndicator:SetText("[+]")
    end

    -- Update section height
    KT:UpdatePetBattleSectionHeight()

    header:SetScript("OnClick", function()
        if not _G.GRIP_EMS_CHAR then
            return
        end
        GRIP_EMS_CHAR.petBattleKeybindsExpanded = not GRIP_EMS_CHAR.petBattleKeybindsExpanded
        if GRIP_EMS_CHAR.petBattleKeybindsExpanded then
            content:Show()
            collapseIndicator:SetText("[-]")
        else
            content:Hide()
            collapseIndicator:SetText("[+]")
        end
        KT:UpdatePetBattleSectionHeight()
    end)

    -- Contention notice: shown in the header when the external
    -- sequencer's sky-riding binds claim the same physical keys as our
    -- pet battle slots (that feature also fires during pet battles).
    local warn = header:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    warn:SetPoint("RIGHT", collapseIndicator, "LEFT", -6, 0)
    warn:SetJustifyH("RIGHT")
    warn:SetWordWrap(false)
    warn:SetTextColor(1, 0.6, 0.2)
    KT.petBattleExtWarn = warn
    KT:UpdatePetBattleExternalBindWarning()

    -- Register callback
    if GRIPEMS.RegisterCallback then
        GRIPEMS.RegisterCallback(KT, "PET_BATTLE_KEYBIND_CHANGED", "OnPetBattleKeybindChanged")
    end
end

--- Update the height of the pet battle section based on collapse state.
function KT:UpdatePetBattleSectionHeight()
    if not KT.petBattleSection then
        return
    end
    local headerHeight = 20
    if KT.petBattleContent and KT.petBattleContent:IsShown() then
        KT.petBattleSection:SetHeight(headerHeight + 4 + D().PET_BATTLE_SLOTS * D().SPEC_ROW_HEIGHT)
    else
        KT.petBattleSection:SetHeight(headerHeight)
    end
end

--- Update the pet battle section anchor after vehicle section collapse toggle.
function KT:UpdatePetBattleSectionAnchor()
    if not KT.petBattleSection or not KT.vehicleSection then
        return
    end
    KT.petBattleSection:SetPoint("TOPLEFT", KT.vehicleSection, "BOTTOMLEFT", 0, -8)
end

--- Refresh the pet battle keybinds section display.
function KT:RefreshPetBattleSection()
    if not KT.petBattleRows then
        return
    end
    local C = UI.Colors
    local PBM = GRIPEMS.PetBattleButtons

    for slot = 1, D().PET_BATTLE_SLOTS do
        local row = KT.petBattleRows[slot]
        if row then
            local key = PBM and PBM:GetKeybind(slot)
            if key then
                row.keyText:SetText(FormatKeyDisplay(key))
                row.keyText:SetTextColor(C.keybindGold:GetRGBA())
            else
                row.keyText:SetText(L["GEMS_UI_NOT_BOUND"])
                row.keyText:SetTextColor(C.textMuted:GetRGBA())
            end
        end
    end
    KT:UpdatePetBattleExternalBindWarning()
end

--- Update the pet-battle-section header notice that flags physical keys
--- also claimed by the external sequencer's sky-riding bind feature.
function KT:UpdatePetBattleExternalBindWarning()
    if not KT.petBattleExtWarn then
        return
    end
    local VK = GRIPEMS.VehicleKeybinds
    local hits = VK and VK.GetExternalPetBattleBindCollisions and VK:GetExternalPetBattleBindCollisions()
    if hits then
        local msg = string.format(L["GEMS_VEHICLE_EXT_COLLISION"], "GSE_QoL", table.concat(hits, ", "))
        KT.petBattleExtWarn:SetText(msg)
        KT.petBattleExtWarn:Show()
    else
        KT.petBattleExtWarn:Hide()
    end
end
