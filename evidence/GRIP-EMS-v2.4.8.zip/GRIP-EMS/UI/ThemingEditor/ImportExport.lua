-- GRIP-EMS: Per-Element Theming editor -- import/export, presets, footer
--
-- Created:    2026-04-22
-- Updated:    2026-08-25
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
-- (c) 2026 Sataana. All Rights Reserved. See LICENSE.
-- Not licensed for AI or ML training. See LICENSE section 3.
--
-- Exports three AceConfig arg builders used by the Paradigm B settings-tree
-- editor: BuildImportExportArgs (AceSerializer + LibDeflate pipeline with
-- the GEMSTHEME1 prefix), BuildPresetArgs (default/highContrast/custom),
-- and BuildFooterArgs (Reset All + Copy to All Profiles).

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

GRIPEMS.UI = GRIPEMS.UI or {}
local UI = GRIPEMS.UI
UI.ThemingEditor = UI.ThemingEditor or {}
local TE = UI.ThemingEditor

local EXPORT_PREFIX = "GEMSTHEME1"
local EXPORT_VERSION = 1

local function profileTheming()
    local S = GRIPEMS.Settings
    if not (S and S.db and S.db.profile) then
        return nil
    end
    S.db.profile.theming = S.db.profile.theming or { preset = "default", elements = {}, savedThemes = {} }
    S.db.profile.theming.elements = S.db.profile.theming.elements or {}
    S.db.profile.theming.savedThemes = S.db.profile.theming.savedThemes or {}
    return S.db.profile.theming
end

local function libs()
    local ser = LibStub and LibStub("AceSerializer-3.0", true)
    local defl = LibStub and LibStub("LibDeflate", true)
    return ser, defl
end

local function notify()
    LibStub("AceConfigRegistry-3.0"):NotifyChange("GRIP-EMS")
end

local function copyTable(t)
    local c = {}
    for k, v in pairs(t or {}) do
        if type(v) == "table" then
            local inner = {}
            for kk, vv in pairs(v) do
                inner[kk] = vv
            end
            c[k] = inner
        else
            c[k] = v
        end
    end
    return c
end

function TE.ExportCurrent()
    local t = profileTheming()
    if not t then
        return nil, "no profile"
    end
    local ser, defl = libs()
    if not (ser and defl) then
        return nil, "missing libs"
    end
    local GE = GRIPEMS.GRIPExport
    local exportedBy = GE and GE.BuildExportedBy and GE.BuildExportedBy(nil) or nil
    local spec = {
        version = EXPORT_VERSION,
        preset = t.preset or "default",
        elements = t.elements or {},
        -- v2.3.3 Phase 1: parser metadata. Theme.ValidateSpec ignores unknown
        -- top-level keys, so older clients import these strings unchanged.
        name = "Current",
        addonVersion = GRIPEMS.version,
        exportedAt = time(),
        wowInterface = GetBuildInfo and select(4, GetBuildInfo()) or nil,
        author = exportedBy and exportedBy.name or nil,
    }
    local ok, payload = pcall(function()
        return ser:Serialize(spec)
    end)
    if not ok or type(payload) ~= "string" then
        return nil, "serialize failed"
    end
    return EXPORT_PREFIX .. ":" .. defl:EncodeForPrint(defl:CompressDeflate(payload, { level = 9 })), nil
end

function TE.ImportString(raw)
    if type(raw) ~= "string" or raw == "" then
        return false, "empty"
    end
    local body = raw
    local colon = raw:find(":")
    if colon and raw:sub(1, colon - 1) == EXPORT_PREFIX then
        body = raw:sub(colon + 1)
    elseif not raw:find(EXPORT_PREFIX, 1, true) then
        return false, "unknown prefix"
    end
    local ser, defl = libs()
    if not (ser and defl) then
        return false, "missing libs"
    end
    local decoded = defl:DecodeForPrint(body)
    if not decoded then
        return false, "decode failed"
    end
    local raw2 = defl:DecompressDeflate(decoded)
    if not raw2 then
        return false, "inflate failed"
    end
    local ok, spec = ser:Deserialize(raw2)
    if not ok or type(spec) ~= "table" then
        return false, "deserialize failed"
    end
    if GRIPEMS.Theme and GRIPEMS.Theme.ValidateSpec then
        local valid, err = GRIPEMS.Theme.ValidateSpec(spec)
        if not valid then
            return false, err or "invalid spec"
        end
    end
    local t = profileTheming()
    if not t then
        return false, "no profile"
    end
    t.elements = copyTable(spec.elements or {})
    t.preset = spec.preset or t.preset or "default"
    if GRIPEMS.Theme and GRIPEMS.Theme.ApplyTheme then
        GRIPEMS.Theme.ApplyTheme()
    end
    notify()
    return true, nil
end

function TE.BuildImportExportArgs()
    TE._importScratch = TE._importScratch or ""
    TE._importStatus = TE._importStatus or ""
    return {
        header = { type = "header", order = 1, name = L["ACCESS_THEMING_IMPORTEXPORT_HEADER"] or "Import / Export" },
        exportBox = {
            type = "input",
            order = 2,
            multiline = 6,
            width = "full",
            name = L["ACCESS_THEMING_EXPORT_LABEL"] or "Export",
            get = function()
                local s = TE.ExportCurrent()
                return s or ""
            end,
            set = function() end,
        },
        exportChatLinkBtn = {
            type = "execute",
            order = 3,
            name = L["ACCESS_THEMING_CHATLINK_INSERT"] or "Insert chat link",
            desc = L["ACCESS_THEMING_CHATLINK_INSERT_DESC"] or "",
            func = function()
                local TT = GRIPEMS.ThemeTransport
                if not TT or not TT.InsertLink then
                    return
                end
                local currentSlot = (TE.GetActiveSlot and TE.GetActiveSlot()) or 1
                local ok = TT:InsertLink(currentSlot)
                if not ok then
                    GRIPEMS:Print(
                        "|cFFFFAA33"
                            .. (L["ACCESS_THEMING_CHATLINK_NO_EDITBOX"] or "Open a chat edit box first, then click Insert chat link.")
                            .. "|r"
                    )
                end
            end,
            disabled = function()
                return InCombatLockdown()
            end,
        },
        importBox = {
            type = "input",
            order = 4,
            multiline = 6,
            width = "full",
            name = L["ACCESS_THEMING_IMPORT_LABEL"] or "Import",
            get = function()
                return TE._importScratch or ""
            end,
            set = function(_, v)
                TE._importScratch = v
            end,
        },
        importApply = {
            type = "execute",
            order = 5,
            name = L["ACCESS_THEMING_IMPORT_APPLY"] or "Apply Import",
            func = function()
                local ok, err = TE.ImportString(TE._importScratch or "")
                if ok then
                    TE._importStatus = L["ACCESS_THEMING_IMPORT_OK"] or "Imported."
                    TE._importScratch = ""
                else
                    TE._importStatus = (L["ACCESS_THEMING_IMPORT_FAIL"] or "Import failed")
                        .. ": "
                        .. tostring(err or "")
                end
            end,
        },
        importStatus = {
            type = "description",
            order = 6,
            name = function()
                return TE._importStatus or ""
            end,
        },
    }
end

function TE.BuildPresetArgs()
    return {
        header = { type = "header", order = 1, name = L["ACCESS_THEMING_PRESET_HEADER"] or "Preset" },
        preset = {
            type = "select",
            order = 2,
            name = L["ACCESS_THEMING_PRESET_LABEL"] or "Preset",
            values = function()
                return {
                    default = L["ACCESS_THEMING_PRESET_DEFAULT"] or "Default",
                    highContrast = L["ACCESS_THEMING_PRESET_HIGH_CONTRAST"] or "High Contrast",
                    custom = L["ACCESS_THEMING_PRESET_CUSTOM"] or "Custom",
                }
            end,
            get = function()
                local t = profileTheming()
                return (t and t.preset) or "default"
            end,
            set = function(_, v)
                if GRIPEMS.Theme and GRIPEMS.Theme.ApplyPreset then
                    GRIPEMS.Theme.ApplyPreset(v)
                end
            end,
        },
    }
end

if not GRIPEMS.Popup:GetDef("GRIP_EMS_THEME_RESET_ALL") then
    GRIPEMS.Popup:Define("GRIP_EMS_THEME_RESET_ALL", {
        text = L["ACCESS_THEMING_RESET_ALL_CONFIRM"] or "Reset every theming override to defaults?",
        button1 = YES or "Yes",
        button2 = NO or "No",
        OnAccept = function()
            if GRIPEMS.Theme and GRIPEMS.Theme.ApplyPreset then
                GRIPEMS.Theme.ApplyPreset("default")
            end
            notify()
        end,
        timeout = 0,
        hideOnEscape = true,
    })
end

if not GRIPEMS.Popup:GetDef("GRIP_EMS_THEME_COPY_ALL_PROFILES") then
    GRIPEMS.Popup:Define("GRIP_EMS_THEME_COPY_ALL_PROFILES", {
        text = L["ACCESS_THEMING_COPY_ALL_CONFIRM"] or "Copy current theme to every profile?",
        button1 = YES or "Yes",
        button2 = NO or "No",
        OnAccept = function()
            local S = GRIPEMS.Settings
            if not (S and S.db and S.db.profiles and S.db.profile and S.db.profile.theming) then
                return
            end
            local src = S.db.profile.theming
            local elements = copyTable(src.elements or {})
            local saved = src.savedThemes or {}
            for name, prof in pairs(S.db.profiles) do
                prof.theming = { preset = src.preset or "default", elements = elements, savedThemes = saved }
            end
            notify()
        end,
        timeout = 0,
        hideOnEscape = true,
    })
end

function TE.BuildFooterArgs()
    return {
        resetAll = {
            type = "execute",
            order = 1,
            name = L["ACCESS_THEMING_RESET_ALL"] or "Reset All",
            desc = L["ACCESS_THEMING_RESET_ALL_DESC"] or "",
            func = function()
                GRIPEMS.Popup:Show("GRIP_EMS_THEME_RESET_ALL")
            end,
        },
        copyAll = {
            type = "execute",
            order = 2,
            name = L["ACCESS_THEMING_COPY_ALL_PROFILES"] or "Copy to All Profiles",
            desc = L["ACCESS_THEMING_COPY_ALL_PROFILES_DESC"] or "",
            func = function()
                GRIPEMS.Popup:Show("GRIP_EMS_THEME_COPY_ALL_PROFILES")
            end,
        },
    }
end

-- end of UI/ThemingEditor/ImportExport.lua
