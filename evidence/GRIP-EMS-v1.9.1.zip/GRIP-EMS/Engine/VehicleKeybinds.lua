-- GRIP-EMS: Vehicle Keybinds
-- Custom keybinds for vehicle/override/skyriding bar buttons 1-12.
-- When player enters a vehicle state, apply override bindings that click
-- the vehicle bar buttons directly. When player exits, deactivate.
-- Data model: GRIP_EMS_CHAR.vehicleKeybinds = { [key] = slotIndex }
-- Character-wide, NOT per-spec (vehicles are universal context).

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS")
local D = GRIPEMS.Defaults

GRIPEMS.VehicleKeybinds = {}
local VK = GRIPEMS.VehicleKeybinds

-- Runtime state
VK.active = false

-- Owner frame for vehicle override bindings
local vehicleKeybindOwner = _G["GRIPEMS_VehicleKeybindOwner"]
    or CreateFrame("Frame", "GRIPEMS_VehicleKeybindOwner", UIParent)
vehicleKeybindOwner:UnregisterAllEvents()
vehicleKeybindOwner:Hide()

--- Determine the target button name for a vehicle slot.
--- @param slotIndex number Slot index 1..12
--- @return string buttonName The button global name
local function GetVehicleButtonName(slotIndex)
    if HasOverrideActionBar() then
        return "OverrideActionBarButton" .. slotIndex
    end
    return "ActionButton" .. slotIndex
end

--- Activate vehicle keybinds. Called when entering vehicle/override bar state.
--- Applies override bindings that click vehicle bar buttons directly.
function VK:Activate()
    if GRIPEMS.OOCQueue.IsRestricted() then
        GRIPEMS.OOCQueue:Add(function()
            VK:Activate()
        end, D.OOC_OP_GENERIC)
        return
    end

    if not _G.GRIP_EMS_CHAR or not GRIP_EMS_CHAR.vehicleKeybinds then
        return
    end

    -- Clear any existing vehicle bindings first
    ClearOverrideBindings(vehicleKeybindOwner)

    local count = 0
    for key, slotIndex in pairs(GRIP_EMS_CHAR.vehicleKeybinds) do
        local targetButton = GetVehicleButtonName(slotIndex)
        if _G[targetButton] then
            SetOverrideBindingClick(vehicleKeybindOwner, false, key, targetButton, "LeftButton")
            count = count + 1
        end
    end

    VK.active = true
    GRIPEMS:Debug(string.format(L["GEMS_VEHICLE_KEYBINDS_APPLIED"], count))
end

--- Deactivate vehicle keybinds. Called when exiting vehicle/override bar state.
function VK:Deactivate()
    if GRIPEMS.OOCQueue.IsRestricted() then
        GRIPEMS.OOCQueue:Add(function()
            VK:Deactivate()
        end, D.OOC_OP_GENERIC)
        return
    end

    ClearOverrideBindings(vehicleKeybindOwner)
    VK.active = false
    GRIPEMS:Debug(L["GEMS_VEHICLE_KEYBINDS_CLEARED"])
end

--- Set a keybind for a vehicle slot.
--- @param slotIndex number Slot index 1..12
--- @param key string WoW key string
function VK:SetKeybind(slotIndex, key)
    if type(slotIndex) ~= "number" or slotIndex < 1 or slotIndex > D.VEHICLE_KEYBIND_SLOTS then
        return
    end
    if type(key) ~= "string" or key == "" then
        return
    end
    if not _G.GRIP_EMS_CHAR then
        return
    end

    GRIP_EMS_CHAR.vehicleKeybinds = GRIP_EMS_CHAR.vehicleKeybinds or {}
    local binds = GRIP_EMS_CHAR.vehicleKeybinds

    -- Clear any existing key for this slot
    for existingKey, existingSlot in pairs(binds) do
        if existingSlot == slotIndex then
            binds[existingKey] = nil
            break
        end
    end

    -- Clear any existing slot for this key
    if binds[key] then
        binds[key] = nil
    end

    -- Store the new binding
    binds[key] = slotIndex

    -- If currently in vehicle state, reapply
    if VK.active and not GRIPEMS.OOCQueue.IsRestricted() then
        VK:Activate()
    end

    if GRIPEMS.Fire then
        GRIPEMS:Fire("VEHICLE_KEYBIND_CHANGED", slotIndex, key)
    end
end

--- Clear the keybind for a vehicle slot.
--- @param slotIndex number Slot index 1..12
function VK:ClearKeybind(slotIndex)
    if type(slotIndex) ~= "number" or slotIndex < 1 or slotIndex > D.VEHICLE_KEYBIND_SLOTS then
        return
    end
    if not _G.GRIP_EMS_CHAR or not GRIP_EMS_CHAR.vehicleKeybinds then
        return
    end

    local binds = GRIP_EMS_CHAR.vehicleKeybinds
    local foundKey = nil
    for key, slot in pairs(binds) do
        if slot == slotIndex then
            foundKey = key
            break
        end
    end

    if not foundKey then
        return
    end

    binds[foundKey] = nil

    -- If in vehicle state, clear that specific override binding
    if VK.active and not GRIPEMS.OOCQueue.IsRestricted() then
        SetOverrideBinding(vehicleKeybindOwner, false, foundKey)
    end

    if GRIPEMS.Fire then
        GRIPEMS:Fire("VEHICLE_KEYBIND_CHANGED", slotIndex, nil)
    end
end

--- Get the key string bound to a vehicle slot.
--- @param slotIndex number Slot index 1..12
--- @return string|nil The key string, or nil if no binding exists
function VK:GetKeybind(slotIndex)
    if not _G.GRIP_EMS_CHAR or not GRIP_EMS_CHAR.vehicleKeybinds then
        return nil
    end
    for key, slot in pairs(GRIP_EMS_CHAR.vehicleKeybinds) do
        if slot == slotIndex then
            return key
        end
    end
    return nil
end

--- Return a shallow copy of the vehicle keybinds table.
--- @return table copy { [key] = slotIndex }
function VK:GetAllKeybinds()
    if not _G.GRIP_EMS_CHAR or not GRIP_EMS_CHAR.vehicleKeybinds then
        return {}
    end
    local copy = {}
    for key, slot in pairs(GRIP_EMS_CHAR.vehicleKeybinds) do
        copy[key] = slot
    end
    return copy
end

--- Return true if vehicle keybinds are currently applied.
--- @return boolean
function VK:IsActive()
    return VK.active
end
