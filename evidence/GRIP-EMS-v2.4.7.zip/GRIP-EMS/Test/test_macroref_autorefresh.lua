-- GRIP-EMS: Headless test for opt-in macro-reference auto-refresh
--
-- Created:    2026-06-21
-- Updated:    2026-08-17
-- Patch: 12.1.0.69299 Midnight (Retail LIVE)
--
-- Standalone (Lua 5.1) test for Engine/MacroManager.lua's AutoRefreshAll /
-- _isAutoRefreshEligible / forEachMacroRef. EMS ships its in-game tests as
-- *_spec.lua files registered with GRIPEMS.TestSuite and run via /gems test;
-- there is no in-client-independent suite runner, so this drives the REAL
-- MacroManager module via loadfile + setfenv into a sandbox that stubs the
-- WoW macro API (GetMacroIndexByName, GetMacroInfo), CreateFrame, C_Timer,
-- LibStub, and a fake GRIPEMS.Engine. Keeping the stubs as fields on a local
-- env table (never global assignments) keeps the file luacheck-clean under the
-- read-only WoW std.
--
-- Run from the EMS root:  lua Test/test_macroref_autorefresh.lua
-- Exit code 0 = all passed, 1 = at least one failure.
--
-- Cases:
--   a  eligible node             -> body pulled, macroRefSynced updated, 1 recompile
--   b  imported node (synced=nil)-> left alone
--   c  in-editor-edited node     -> left alone (macro ~= macroRefSynced)
--   d  source macro missing      -> left alone
--   e  no drift (live == stored) -> left alone
--   f  macro-ref nested in a Loop AND in an If branch -> both reached
--   g  UPDATE_MACROS hook honors the macroRefAutoRefresh setting
--   h  else-only If (empty true branch) -> reached
--   i  If false branch nested inside a Loop -> reached
--
-- Import ownership (MM:UpdateMacro must not overwrite a foreign macro):
--   j  player-written macro of the same name -> REFUSED, nothing written
--   k  EMS-owned macro -> still updated
--   l  account bucket grants ownership to a character-scope import
--   m  character bucket grants ownership to an account-scope import
--   n  brand-new name -> still created normally
--   o  stub slot owned via the body match alone, both buckets empty
--   p  neither SavedVariables global present -> refuses without erroring
--   q  manageMacro-only node (no .text) -> refused the same way
--   r  MM:ImportMacro scope routing; refusal prints no "was imported" line
--
-- Import COUNTING (a refusal must not be summarised as an import):
--   s  out-of-combat refusal -> macrosImported 0, macrosSkipped 1
--   t  successful import     -> macrosImported 1, macrosSkipped 0
--   u  early-validation fail -> macrosSkipped bumped exactly once
--   v  in-combat import      -> deferred, counted optimistically, refusal
--                               printed when the queue drains
--   w  mixed batch           -> all three counters correct simultaneously
--   x  scope-override shape  -> the migrate caller counts identically

local ADDON_NAME = "GRIP-EMS"

-- ---------------------------------------------------------------------------
-- Minimal assertion + runner harness (mirrors TestSuite Pass/Fail semantics).
-- ---------------------------------------------------------------------------

local tests = {}

local function test(name, fn)
    tests[#tests + 1] = { name = name, fn = fn }
end

local function assertEqual(expected, actual, label)
    if expected ~= actual then
        error((label or "value") .. ": expected " .. tostring(expected) .. ", got " .. tostring(actual), 2)
    end
end

local function assertTrue(cond, label)
    if not cond then
        error((label or "condition") .. " failed", 2)
    end
end

-- ---------------------------------------------------------------------------
-- Live /macro stub. name -> slot, slot -> { name, body }.
-- ---------------------------------------------------------------------------

local liveByName = {}
local liveBySlot = {}
local nextSlot = 0

local function clearLive()
    for k in pairs(liveByName) do
        liveByName[k] = nil
    end
    for k in pairs(liveBySlot) do
        liveBySlot[k] = nil
    end
    nextSlot = 0
end

local function setLiveMacro(name, body)
    nextSlot = nextSlot + 1
    liveByName[name] = nextSlot
    liveBySlot[nextSlot] = { name = name, body = body }
end

-- ---------------------------------------------------------------------------
-- Fake GRIPEMS namespace + sandbox environment.
-- ---------------------------------------------------------------------------

-- Stub constants. The exact ACTION_TYPE_IF string is irrelevant to the addon;
-- what matters is that the fixtures below use the SAME value the discriminator
-- compares against (node.type == D.ACTION_TYPE_IF).
-- BUTTON_PREFIX, QUESTION_MARK_ICON and the two macro caps are mirrored from
-- Data/Defaults.lua at their real values, because the import path exercised by
-- the ownership cases reads all four: the prefix drives the stub body match,
-- and the caps drive the overflow guard that sits above the write branch.
-- The OOC_* entries are mirrored from Data/Defaults.lua at their real values
-- because the counting cases load the REAL OOCQueue, which reads the op type
-- for dedup, the priority table when it sorts a drain, and the ticker interval
-- at module load. Only OOC_OP_IMPORTMACRO and OOC_OP_GENERIC are referenced by
-- the path under test; the rest of the priority table is carried so the sort
-- key lookup behaves as it does in the addon rather than falling to the default.
local D = {
    ACTION_SUBTYPE_MACROREF = "macroref",
    ACTION_TYPE_IF = "If",
    BUTTON_PREFIX = "GRIPEMS_",
    QUESTION_MARK_ICON = "INV_Misc_QuestionMark",
    MAX_PER_CHAR_MACROS = 30,
    MAX_ACCOUNT_MACROS = 120,
    OOC_OP_IMPORTMACRO = "importmacro",
    OOC_OP_GENERIC = "generic",
    OOC_TICKER_INTERVAL = 1,
}
D.OOC_PRIORITY = {
    [D.OOC_OP_IMPORTMACRO] = 75,
    [D.OOC_OP_GENERIC] = 80,
}

local locale = setmetatable({
    GEMS_MACROREF_AUTOREFRESH_DEBUG = "Auto-refreshed macro-reference bodies in %d sequence(s)",
}, {
    __index = function(_, key)
        return key
    end,
})

local settingValue = false

-- User-facing lines the addon prints, captured so the refusal case can assert
-- the player was actually told rather than silently skipped.
local printed = {}

local GRIPEMS = {
    Defaults = D,
    Debug = function() end,
    Print = function(_, msg)
        printed[#printed + 1] = msg
    end,
    Settings = {
        Get = function(_, _)
            return settingValue
        end,
    },
}

local capturedOnEvent

local env = setmetatable({}, { __index = _G })
env._G = env
env.LibStub = function()
    return {
        GetLocale = function()
            return locale
        end,
    }
end
env.CreateFrame = function()
    local frame = {}
    frame.RegisterEvent = function() end
    frame.UnregisterAllEvents = function() end
    frame.SetScript = function(_, _, handler)
        capturedOnEvent = handler
    end
    return frame
end
env.C_Timer = {
    After = function(_, fn)
        fn()
    end,
}
env.GetMacroIndexByName = function(name)
    return liveByName[name] or 0
end
env.GetMacroInfo = function(slot)
    local entry = liveBySlot[slot]
    if not entry then
        return nil
    end
    return entry.name, 0, entry.body
end

-- ---------------------------------------------------------------------------
-- Write-path stubs, added for the import-ownership cases.
--
-- MM:UpdateMacro writes through EditMacro / CreateMacro under
-- withMacroWriteGuard, which wraps the call in pcall -- so a MISSING stub here
-- would be swallowed silently and a "body unchanged" assertion would pass for
-- the wrong reason. Both are stubbed to mutate the live table exactly as the
-- game would, and both record their calls, so the refusal cases can assert
-- that no write was even attempted rather than only that nothing changed.
-- ---------------------------------------------------------------------------

local editCalls = {}
local createCalls = {}

env.EditMacro = function(slot, name, icon, body)
    editCalls[#editCalls + 1] = { slot = slot, name = name, icon = icon, body = body }
    local entry = liveBySlot[slot]
    if entry then
        entry.name = name
        entry.body = body
    end
    return slot
end

env.CreateMacro = function(name, icon, body, _perChar)
    createCalls[#createCalls + 1] = { name = name, icon = icon, body = body }
    nextSlot = nextSlot + 1
    liveByName[name] = nextSlot
    liveBySlot[nextSlot] = { name = name, body = body }
    return nextSlot
end

-- Held far below both caps so the overflow guard above the write branch never
-- fires; overflow has its own coverage and is not what these cases measure.
env.GetNumMacros = function()
    return 0, 0
end

-- Combat toggle. Defaults to false so every case written before the deferred
-- counting coverage sees exactly what it saw before. Case v flips it to reach
-- OOCQueue's queueing arm, then flips it back to drain. The modules resolve
-- InCombatLockdown through env on every call, so replacing the value here
-- reaches MacroManager even though it was loaded earlier.
local inCombat = false

env.InCombatLockdown = function()
    return inCombat
end

-- WoW supplies wipe(); Lua 5.1 does not, and OOCQueue:Process calls it when the
-- queue drains. Without this the deferred case fails on a nil call inside
-- Process rather than on the contract it is actually measuring.
env.wipe = function(t)
    for k in pairs(t) do
        t[k] = nil
    end
    return t
end

-- SavedVariables control. env._G is env, and MacroManager reads the buckets
-- both as _G.GRIP_EMS_DB and as a bare global, so both resolve here.
local function useBuckets(accountMacros, charMacros)
    env.GRIP_EMS_DB = { macros = accountMacros or {} }
    env.GRIP_EMS_CHAR = { macros = charMacros or {} }
end

--- Remove both SavedVariables globals, the pre-load state.
local function clearBuckets()
    env.GRIP_EMS_DB = nil
    env.GRIP_EMS_CHAR = nil
end

local function resetWriteSpies()
    for i = #editCalls, 1, -1 do
        editCalls[i] = nil
    end
    for i = #createCalls, 1, -1 do
        createCalls[i] = nil
    end
    for i = #printed, 1, -1 do
        printed[i] = nil
    end
end

--- Body of the macro currently registered under `name`, or nil.
local function liveBody(name)
    local slot = liveByName[name]
    if not slot then
        return nil
    end
    return liveBySlot[slot] and liveBySlot[slot].body
end

-- ---------------------------------------------------------------------------
-- Load the REAL MacroManager module into the sandbox.
-- ---------------------------------------------------------------------------

local function loadMacroManager()
    local candidates = {
        "Engine/MacroManager.lua",
        "../Engine/MacroManager.lua",
        "GRIP/EMS/Engine/MacroManager.lua",
    }
    for _, path in ipairs(candidates) do
        -- loadfile is dev-harness file I/O, intentionally outside the addon WoW std.
        -- selene: allow(undefined_variable)
        local chunk = loadfile(path)
        if chunk then
            setfenv(chunk, env)
            return chunk
        end
    end
    error("could not locate Engine/MacroManager.lua (run from the EMS root)")
end

loadMacroManager()(ADDON_NAME, GRIPEMS)

local MM = GRIPEMS.MacroManager
assertTrue(MM ~= nil, "MacroManager loaded")
assertTrue(type(MM.AutoRefreshAll) == "function", "AutoRefreshAll defined")

-- ---------------------------------------------------------------------------
-- Fixtures.
-- ---------------------------------------------------------------------------

local function macroNode(macroName, macro, synced)
    return {
        type = "Action",
        subtype = D.ACTION_SUBTYPE_MACROREF,
        macroName = macroName,
        macro = macro,
        macroRefSynced = synced,
    }
end

-- Build a fake engine holding one sequence "Seq" with the given list of
-- per-version action arrays. Returns the engine plus a recompile-spy array.
local function engineWith(actionsByVersion)
    local recompiled = {}
    local versions = {}
    for i = 1, #actionsByVersion do
        versions[i] = { actions = actionsByVersion[i] }
    end
    local engine = {
        sequences = {
            Seq = { data = { versions = versions } },
        },
        RecompileSequence = function(_, name)
            recompiled[#recompiled + 1] = name
        end,
    }
    return engine, recompiled
end

-- ---------------------------------------------------------------------------
-- Cases.
-- ---------------------------------------------------------------------------

test("a: eligible node is refreshed and recompiled once", function()
    clearLive()
    setLiveMacro("MOONSPAM", "NEW BODY")
    local node = macroNode("MOONSPAM", "OLD BODY", "OLD BODY")
    local engine, recompiled = engineWith({ { node } })
    GRIPEMS.Engine = engine
    MM:AutoRefreshAll()
    assertEqual("NEW BODY", node.macro, "node.macro pulled to live body")
    assertEqual("NEW BODY", node.macroRefSynced, "macroRefSynced updated to new body")
    assertEqual(1, #recompiled, "exactly one recompile")
    assertEqual("Seq", recompiled[1], "recompiled the owning sequence")
end)

test("b: imported node (no macroRefSynced) is left alone", function()
    clearLive()
    setLiveMacro("MOONSPAM", "NEW BODY")
    local node = macroNode("MOONSPAM", "OLD BODY", nil)
    local engine, recompiled = engineWith({ { node } })
    GRIPEMS.Engine = engine
    MM:AutoRefreshAll()
    assertEqual("OLD BODY", node.macro, "imported macro body unchanged")
    assertTrue(node.macroRefSynced == nil, "macroRefSynced still nil")
    assertEqual(0, #recompiled, "no recompile")
end)

test("c: in-editor-edited node (macro ~= macroRefSynced) is left alone", function()
    clearLive()
    setLiveMacro("MOONSPAM", "NEW BODY")
    local node = macroNode("MOONSPAM", "EDITED BODY", "SYNCED BODY")
    local engine, recompiled = engineWith({ { node } })
    GRIPEMS.Engine = engine
    MM:AutoRefreshAll()
    assertEqual("EDITED BODY", node.macro, "edited macro body unchanged")
    assertEqual(0, #recompiled, "no recompile")
end)

test("d: missing source macro is left alone", function()
    clearLive()
    -- MOONSPAM intentionally not registered -> GetMacroIndexByName returns 0.
    local node = macroNode("MOONSPAM", "OLD BODY", "OLD BODY")
    local engine, recompiled = engineWith({ { node } })
    GRIPEMS.Engine = engine
    MM:AutoRefreshAll()
    assertEqual("OLD BODY", node.macro, "macro unchanged when source missing")
    assertEqual(0, #recompiled, "no recompile")
end)

test("e: no drift (live == stored) does nothing", function()
    clearLive()
    setLiveMacro("MOONSPAM", "SAME BODY")
    local node = macroNode("MOONSPAM", "SAME BODY", "SAME BODY")
    local engine, recompiled = engineWith({ { node } })
    GRIPEMS.Engine = engine
    MM:AutoRefreshAll()
    assertEqual("SAME BODY", node.macro, "macro unchanged with no drift")
    assertEqual(0, #recompiled, "no recompile")
end)

test("f: macro-ref nested in a Loop and in an If branch are both reached", function()
    clearLive()
    setLiveMacro("LOOPMAC", "LOOP NEW")
    setLiveMacro("IFMAC", "IF NEW")
    local loopNode = macroNode("LOOPMAC", "LOOP OLD", "LOOP OLD")
    local ifNode = macroNode("IFMAC", "IF OLD", "IF OLD")
    -- Loop children is a flat node array (children[1].type set); If children is
    -- { trueArray, falseArray } (children[1][1] truthy). forEachMacroRef must
    -- recurse into both shapes.
    local actions = {
        { type = "Loop", children = { loopNode } },
        { type = D.ACTION_TYPE_IF, children = { { ifNode }, {} } },
    }
    local engine, recompiled = engineWith({ actions })
    GRIPEMS.Engine = engine
    MM:AutoRefreshAll()
    assertEqual("LOOP NEW", loopNode.macro, "loop-nested macro-ref refreshed")
    assertEqual("IF NEW", ifNode.macro, "if-branch-nested macro-ref refreshed")
    assertEqual(1, #recompiled, "one recompile for the sequence")
end)

test("g: UPDATE_MACROS hook honors the macroRefAutoRefresh setting", function()
    assertTrue(type(capturedOnEvent) == "function", "OnEvent handler captured")

    -- Setting OFF: the hook returns before doing any work.
    clearLive()
    setLiveMacro("MOONSPAM", "NEW BODY")
    local nodeOff = macroNode("MOONSPAM", "OLD BODY", "OLD BODY")
    local engineOff, recompiledOff = engineWith({ { nodeOff } })
    GRIPEMS.Engine = engineOff
    settingValue = false
    MM._autoRefreshPending = false
    capturedOnEvent()
    assertEqual("OLD BODY", nodeOff.macro, "off: node untouched")
    assertEqual(0, #recompiledOff, "off: no recompile")

    -- Setting ON: the debounced refresh fires (the C_Timer stub runs inline).
    clearLive()
    setLiveMacro("MOONSPAM", "NEW BODY")
    local nodeOn = macroNode("MOONSPAM", "OLD BODY", "OLD BODY")
    local engineOn, recompiledOn = engineWith({ { nodeOn } })
    GRIPEMS.Engine = engineOn
    settingValue = true
    MM._autoRefreshPending = false
    capturedOnEvent()
    assertEqual("NEW BODY", nodeOn.macro, "on: node refreshed")
    assertEqual(1, #recompiledOn, "on: one recompile")
end)

test("h: else-only If (empty true, populated false branch) is reached", function()
    clearLive()
    setLiveMacro("ELSEMAC", "ELSE NEW")
    local elseNode = macroNode("ELSEMAC", "ELSE OLD", "ELSE OLD")
    -- Empty true branch, populated false branch. A structural children[1][1]
    -- heuristic misreads this as a flat Loop array and skips the false branch.
    local actions = {
        { type = D.ACTION_TYPE_IF, children = { {}, { elseNode } } },
    }
    local engine, recompiled = engineWith({ actions })
    GRIPEMS.Engine = engine
    MM:AutoRefreshAll()
    assertEqual("ELSE NEW", elseNode.macro, "false-branch macro-ref refreshed")
    assertEqual(1, #recompiled, "one recompile")
end)

test("i: macro-ref in an If false branch nested inside a Loop is reached", function()
    clearLive()
    setLiveMacro("DEEPMAC", "DEEP NEW")
    local deepNode = macroNode("DEEPMAC", "DEEP OLD", "DEEP OLD")
    local ifNode = { type = D.ACTION_TYPE_IF, children = { {}, { deepNode } } }
    local actions = {
        { type = "Loop", children = { ifNode } },
    }
    local engine, recompiled = engineWith({ actions })
    GRIPEMS.Engine = engine
    MM:AutoRefreshAll()
    assertEqual("DEEP NEW", deepNode.macro, "deeply-nested false-branch macro-ref refreshed")
    assertEqual(1, #recompiled, "one recompile")
end)

-- ---------------------------------------------------------------------------
-- Import ownership: MM:UpdateMacro must not overwrite a macro EMS never made.
--
-- MM:UpdateMacro resolved GetMacroIndexByName and, on a hit, ran EditMacro
-- unconditionally -- replacing the body of whatever macro happened to hold that
-- name -- then recorded the adopted slot as EMS's own. Reached by pasting an
-- import string carrying a Macros payload, or by legacy migration, whenever the
-- player already held a macro whose name matched an imported node.
--
-- These cases pin the discriminator (both SavedVariables buckets, plus the
-- structural stub-body match) rather than the message text, so re-wording the
-- warning does not require re-stamping them.
-- ---------------------------------------------------------------------------

test("j: REFUSES to overwrite a macro the player wrote (motivating instance)", function()
    clearLive()
    resetWriteSpies()
    useBuckets({}, {}) -- both buckets present, NEITHER carries the name
    setLiveMacro("MOONSPAM", "PLAYER BODY")

    local node = { name = "MOONSPAM", text = "IMPORTED BODY", category = "a" }
    local result = MM:UpdateMacro(node, false)

    assertTrue(result == nil, "UpdateMacro returns nil on refusal")
    assertEqual("PLAYER BODY", liveBody("MOONSPAM"), "player's macro body is untouched")
    assertEqual(0, #editCalls, "EditMacro was never called")
    assertEqual(0, #createCalls, "CreateMacro was never called")
    -- Writing either of these would make the NEXT import see the foreign macro
    -- as EMS-owned, delaying the overwrite by one import instead of stopping it.
    assertTrue(node.value == nil, "node.value not written")
    assertTrue(env.GRIP_EMS_DB.macros["MOONSPAM"] == nil, "account bucket not written")
    assertTrue(env.GRIP_EMS_CHAR.macros["MOONSPAM"] == nil, "character bucket not written")
    assertEqual(1, #printed, "the player is told exactly once")
end)

test("k: re-import of an EMS-owned macro still updates it", function()
    clearLive()
    resetWriteSpies()
    useBuckets({ MOONSPAM = { name = "MOONSPAM", text = "OLD EMS BODY" } }, {})
    setLiveMacro("MOONSPAM", "OLD EMS BODY")

    local node = { name = "MOONSPAM", text = "NEW EMS BODY", category = "a" }
    local result = MM:UpdateMacro(node, false)

    assertTrue(result ~= nil, "UpdateMacro returns the node")
    assertEqual("NEW EMS BODY", liveBody("MOONSPAM"), "EMS-owned body was updated")
    assertEqual(1, #editCalls, "EditMacro called once")
    assertTrue(env.GRIP_EMS_DB.macros["MOONSPAM"] ~= nil, "account bucket still holds the node")
end)

test("l: account-scope bucket grants ownership to a CHARACTER-scope import", function()
    -- Cross-scope, direction 1. GetMacroIndexByName searches both tabs while
    -- the buckets are split by scope, so a predicate that consulted only the
    -- bucket matching isCharacterScope would answer "not ours" here and refuse
    -- to update a macro EMS itself created.
    clearLive()
    resetWriteSpies()
    useBuckets({ SHARED = { name = "SHARED" } }, {}) -- ACCOUNT bucket only
    setLiveMacro("SHARED", "OLD BODY")

    local node = { name = "SHARED", text = "NEW BODY", category = "p" }
    local result = MM:UpdateMacro(node, true) -- CHARACTER-scope import

    assertTrue(result ~= nil, "cross-scope ownership recognised")
    assertEqual("NEW BODY", liveBody("SHARED"), "body updated")
    assertEqual(1, #editCalls, "EditMacro called once")
end)

test("m: character-scope bucket grants ownership to an ACCOUNT-scope import", function()
    -- Cross-scope, direction 2. Both directions are asserted because a
    -- single-bucket predicate is wrong in one direction only, and a test of one
    -- direction would pass against it.
    clearLive()
    resetWriteSpies()
    useBuckets({}, { SHARED = { name = "SHARED" } }) -- CHARACTER bucket only
    setLiveMacro("SHARED", "OLD BODY")

    local node = { name = "SHARED", text = "NEW BODY", category = "a" }
    local result = MM:UpdateMacro(node, false) -- ACCOUNT-scope import

    assertTrue(result ~= nil, "cross-scope ownership recognised")
    assertEqual("NEW BODY", liveBody("SHARED"), "body updated")
    assertEqual(1, #editCalls, "EditMacro called once")
end)

test("n: a brand-new name with no collision is still created normally", function()
    clearLive()
    resetWriteSpies()
    useBuckets({}, {})

    local node = { name = "FRESHMAC", text = "FRESH BODY", category = "a" }
    local result = MM:UpdateMacro(node, false)

    assertTrue(result ~= nil, "UpdateMacro returns the node")
    assertEqual(1, #createCalls, "CreateMacro called once")
    assertEqual(0, #editCalls, "EditMacro not called")
    assertEqual("FRESH BODY", liveBody("FRESHMAC"), "new macro carries the imported body")
    assertTrue(node.value ~= nil, "node.value holds the new slot")
    assertTrue(env.GRIP_EMS_DB.macros["FRESHMAC"] ~= nil, "node mirrored into the bucket")
end)

test("o: a stub slot is owned via the body match, with both buckets empty", function()
    -- Ownership signal 3, standing alone: neither bucket knows the name, but
    -- the body carries the button prefix, so it is ours by construction. Same
    -- match ScanExisting uses to reclaim stubs on login.
    clearLive()
    resetWriteSpies()
    useBuckets({}, {})
    setLiveMacro("MySeq", "/click " .. D.BUTTON_PREFIX .. "MySeq LeftButton")

    local node = { name = "MySeq", text = "REBUILT STUB BODY", category = "a" }
    local result = MM:UpdateMacro(node, false)

    assertTrue(result ~= nil, "stub recognised as EMS-owned")
    assertEqual("REBUILT STUB BODY", liveBody("MySeq"), "stub body was rewritten")
    assertEqual(1, #editCalls, "EditMacro called once")
end)

test("p: with NEITHER SavedVariables global present the import refuses, not errors", function()
    clearLive()
    resetWriteSpies()
    clearBuckets() -- pre-SavedVariables-load state
    setLiveMacro("MOONSPAM", "PLAYER BODY")

    local node = { name = "MOONSPAM", text = "IMPORTED BODY", category = "a" }
    -- pcall so a nil-index regression reports as "raised" rather than as a
    -- generic case failure: the whole point is that it must not error.
    local ok, result = pcall(function()
        return MM:UpdateMacro(node, false)
    end)

    assertTrue(ok, "UpdateMacro must not raise when the globals are absent")
    assertTrue(result == nil, "ownership is UNKNOWN, so the import refuses")
    assertEqual("PLAYER BODY", liveBody("MOONSPAM"), "player's macro body is untouched")
    assertEqual(0, #editCalls, "EditMacro was never called")
    assertTrue(node.value == nil, "node.value not written")
    assertTrue(env.GRIP_EMS_DB == nil, "no bucket was conjured into existence")
    assertTrue(env.GRIP_EMS_CHAR == nil, "no bucket was conjured into existence")
end)

test("q: a manageMacro-only node (no .text) is refused the same way", function()
    -- Caller-shape coverage. LegacyMigrate reaches LI.ImportMacro on the test
    -- `macData.text or macData.manageMacro`, so a node carrying manageMacro and
    -- NO text is a real input shape. UpdateMacro's own validity guard admits it,
    -- and the ownership gate reads only name and slot -- but asserting that is
    -- cheaper than arguing it.
    clearLive()
    resetWriteSpies()
    useBuckets({}, {})
    setLiveMacro("MANAGED", "PLAYER BODY")

    local node = { name = "MANAGED", manageMacro = "MANAGED IMPORT BODY", category = "a" }
    local result = MM:UpdateMacro(node, false)

    assertTrue(result == nil, "manageMacro-only node is refused too")
    assertEqual("PLAYER BODY", liveBody("MANAGED"), "player's macro body is untouched")
    assertEqual(0, #editCalls, "EditMacro was never called")
end)

test("r: MM:ImportMacro routes scope from category and stays silent on refusal", function()
    -- One level up the real call path: every caller reaches the gate through
    -- MM:ImportMacro, which maps category "p" to the character scope and prints
    -- the success line. A refusal must not print that line -- it would tell the
    -- player a macro was imported while their own body sat untouched.
    clearLive()
    resetWriteSpies()
    useBuckets({}, {})
    setLiveMacro("PERCHAR", "PLAYER BODY")

    MM:ImportMacro({ name = "PERCHAR", text = "IMPORTED BODY", category = "p" })

    assertEqual("PLAYER BODY", liveBody("PERCHAR"), "player's macro body is untouched")
    assertEqual(0, #editCalls, "EditMacro was never called")
    assertTrue(env.GRIP_EMS_CHAR.macros["PERCHAR"] == nil, "character bucket not written")
    -- Exactly one line: the refusal. The "was imported" line must not appear.
    assertEqual(1, #printed, "only the refusal is printed, not an import confirmation")
end)

-- ---------------------------------------------------------------------------
-- Import COUNTING.
--
-- These load the REAL OOCQueue and LegacyImport into the same sandbox so the
-- whole path runs end to end:
--   LI.ImportMacro -> OOCQueue:Enqueue -> OOCQueue:Add -> MM:ImportMacro
--                  -> MM:UpdateMacro
-- A re-implementation of the counter logic here would prove nothing about the
-- numbers ImportFrame's summary actually reads.
--
-- The whole reason this is cheap: OOCQueue:Add runs func() INLINE when out of
-- combat, so the refusal has already happened by the time LI.ImportMacro
-- reaches its counter. Only the in-combat arm is genuinely deferred, and case v
-- covers that separately rather than pretending it resolves early.
-- ---------------------------------------------------------------------------

local function loadRelativeModule(relPath)
    local candidates = { relPath, "../" .. relPath, "GRIP/EMS/" .. relPath }
    for _, path in ipairs(candidates) do
        -- loadfile is dev-harness file I/O, intentionally outside the addon WoW std.
        -- selene: allow(undefined_variable)
        local chunk = loadfile(path)
        if chunk then
            setfenv(chunk, env)
            return chunk
        end
    end
    error("could not locate " .. relPath .. " (run from the EMS root)")
end

-- capturedOnEvent is a SINGLE slot shared by every CreateFrame in this sandbox,
-- and OOCQueue registers its own combat-end frame at module load. Loading it
-- here therefore overwrites the UPDATE_MACROS handler that case g invokes,
-- which made g fail with "expected NEW BODY, got OLD BODY" -- g was calling
-- OOCQueue's OnEvent. Snapshot MacroManager's handler and put it back, so the
-- modules these cases need can be loaded without reaching into case g.
local macroManagerOnEvent = capturedOnEvent

loadRelativeModule("Engine/OOCQueue.lua")(ADDON_NAME, GRIPEMS)
loadRelativeModule("Import/LegacyImport.lua")(ADDON_NAME, GRIPEMS)

capturedOnEvent = macroManagerOnEvent

local LI = GRIPEMS.LegacyImport
assertTrue(GRIPEMS.OOCQueue ~= nil, "OOCQueue loaded")
assertTrue(LI ~= nil, "LegacyImport loaded")
assertTrue(type(LI.ImportMacro) == "function", "LI.ImportMacro defined")

--- Fresh accumulator shaped like the one LegacyImport builds for a real import.
local function newResults()
    return { macrosImported = 0, macrosSkipped = 0 }
end

--- Reset every piece of shared state these cases touch, including the queue,
--- so an entry left pending by one case cannot drain inside the next one.
local function resetImportState()
    clearLive()
    resetWriteSpies()
    useBuckets({}, {})
    inCombat = false
    GRIPEMS.OOCQueue.queue = {}
    GRIPEMS.OOCQueue.insertOrder = 0
end

test("s: an out-of-combat refusal counts as skipped, not imported", function()
    -- THE MOTIVATING INSTANCE. Against the pre-change code this fails with
    -- "a refused macro is NOT counted as imported: expected 0, got 1" -- the
    -- summary telling the player a macro landed while their own body sat
    -- untouched, which is the miscount 2acd5d1 introduced and left open.
    resetImportState()
    setLiveMacro("MOONSPAM", "PLAYER BODY")

    local results = newResults()
    LI.ImportMacro("MOONSPAM", { name = "MOONSPAM", text = "IMPORTED BODY", category = "a" }, results)

    assertEqual("PLAYER BODY", liveBody("MOONSPAM"), "player's macro body is untouched")
    assertEqual(0, #editCalls, "EditMacro was never called")
    assertEqual(0, results.macrosImported, "a refused macro is NOT counted as imported")
    assertEqual(1, results.macrosSkipped, "it is counted as skipped instead")
end)

test("t: a successful import still counts as imported and not as skipped", function()
    -- The other half of case s. A counter change that only ever increments
    -- macrosSkipped would pass s and be worthless.
    resetImportState()

    local results = newResults()
    LI.ImportMacro("BRANDNEW", { name = "BRANDNEW", text = "IMPORTED BODY", category = "a" }, results)

    assertEqual(1, #createCalls, "the macro really was created")
    assertEqual("IMPORTED BODY", liveBody("BRANDNEW"), "the imported body landed")
    assertEqual(1, results.macrosImported, "counted as imported")
    assertEqual(0, results.macrosSkipped, "not counted as skipped")
end)

test("u: the early-validation failure still counts as skipped exactly once", function()
    -- A second skip site now exists further down the function. A non-text name
    -- must still return at the FIRST one and bump the counter a single time;
    -- falling through to the new site as well would double-count it.
    resetImportState()

    local results = newResults()
    LI.ImportMacro(5, { text = "/cast Fireball" }, results)

    assertEqual(0, results.macrosImported, "an invalid node is not counted as imported")
    assertEqual(1, results.macrosSkipped, "skipped exactly once, not twice")
    assertEqual(0, #createCalls, "nothing was created")
end)

test("v: an in-combat import is deferred, counted optimistically, corrected at drain", function()
    -- The deferred contract, stated explicitly so it cannot drift silently.
    -- In combat the outcome is genuinely unknowable, so it is counted as
    -- imported -- what the player is told today -- and the truth arrives at
    -- drain time as the refusal line naming the macro that was left alone.
    resetImportState()
    setLiveMacro("MOONSPAM", "PLAYER BODY")

    inCombat = true
    local results = newResults()
    LI.ImportMacro("MOONSPAM", { name = "MOONSPAM", text = "IMPORTED BODY", category = "a" }, results)

    assertEqual(1, results.macrosImported, "deferred work is counted optimistically")
    assertEqual(0, results.macrosSkipped, "nothing is skipped while the outcome is unknown")
    assertEqual(1, GRIPEMS.OOCQueue:GetCount(), "the entry really was queued rather than run")
    assertEqual(0, #printed, "nothing is printed to the player while still in combat")
    assertEqual(0, #editCalls, "no write was attempted during combat")

    -- Combat ends and the queue drains. "manual" bypasses the
    -- autoReloadAtCombatEnd gate, which the stub Settings answers false.
    inCombat = false
    GRIPEMS.OOCQueue:Process("manual")

    assertEqual("PLAYER BODY", liveBody("MOONSPAM"), "player's macro body is still untouched")
    assertEqual(0, #editCalls, "EditMacro was never called")
    assertEqual(1, #printed, "the drain-time refusal names the macro that did not land")
    assertEqual(0, GRIPEMS.OOCQueue:GetCount(), "the queue drained")
end)

test("w: a mixed batch counts import, refusal and invalid separately", function()
    -- Totals, not just per-case behaviour. Each of the three routes can be
    -- individually right while the accumulator they share ends up wrong, and
    -- the summary reads the accumulator.
    resetImportState()
    setLiveMacro("PLAYERMACRO", "PLAYER BODY")

    local results = newResults()
    LI.ImportMacro("FRESHONE", { name = "FRESHONE", text = "IMPORTED BODY", category = "a" }, results)
    LI.ImportMacro("PLAYERMACRO", { name = "PLAYERMACRO", text = "IMPORTED BODY", category = "a" }, results)
    LI.ImportMacro(5, { text = "/cast Fireball" }, results)

    assertEqual(1, results.macrosImported, "only the genuine import is counted as imported")
    assertEqual(2, results.macrosSkipped, "the refusal and the invalid node are both skipped")
    assertEqual("PLAYER BODY", liveBody("PLAYERMACRO"), "the player's macro survived the batch")
    assertEqual("IMPORTED BODY", liveBody("FRESHONE"), "the genuine import still landed")
end)

test("x: the scope-override caller shape counts the same as the plain one", function()
    -- Caller-shape coverage. LegacyMigrate.lua:295 and :304 reach
    -- LI.ImportMacro with an explicit "a"/"p" scope argument, which the other
    -- counting cases never pass. The override sets node.category and must not
    -- touch the counting, so a refusal under a forced scope is still a skip.
    resetImportState()
    setLiveMacro("PLAYERMACRO", "PLAYER BODY")

    local results = newResults()
    LI.ImportMacro("FRESHCHAR", { name = "FRESHCHAR", text = "IMPORTED BODY" }, results, "p")
    LI.ImportMacro("PLAYERMACRO", { name = "PLAYERMACRO", text = "IMPORTED BODY" }, results, "a")

    assertEqual(1, results.macrosImported, "the forced-scope import is counted once")
    assertEqual(1, results.macrosSkipped, "the forced-scope refusal is counted as skipped")
    assertEqual("PLAYER BODY", liveBody("PLAYERMACRO"), "player's macro survived the forced-scope import")
    assertEqual("IMPORTED BODY", liveBody("FRESHCHAR"), "the forced-scope import landed")
end)

-- ---------------------------------------------------------------------------
-- Run.
-- ---------------------------------------------------------------------------

local passed = 0
local failed = 0
for _, t in ipairs(tests) do
    local ok, err = pcall(t.fn)
    if ok then
        passed = passed + 1
        print("PASS  " .. t.name)
    else
        failed = failed + 1
        print("FAIL  " .. t.name .. " -- " .. tostring(err))
    end
end
print(string.format("RESULT %d passed, %d failed", passed, failed))
os.exit(failed > 0 and 1 or 0)
