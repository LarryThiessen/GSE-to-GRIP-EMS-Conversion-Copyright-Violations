-- GRIP-EMS: Out-of-Combat Queue
-- Defers protected API calls (CreateMacro, SetAttribute, etc.) until combat ends.
-- Priority-ordered with deduplication: newer requests replace older ones for
-- the same (opType, seqName) pair. Lower priority number = processed first.

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS")
local D = GRIPEMS.Defaults

GRIPEMS.OOCQueue = {
    queue = {},
    insertOrder = 0,
}
local OOCQueue = GRIPEMS.OOCQueue

-- Cache C_RestrictedActions API existence at file load (not per-call)
local hasRestrictedAPI = (C_RestrictedActions and C_RestrictedActions.IsAddOnRestrictionActive) and true or false

local RESTRICTION_NAMES = {
    [0] = "Combat",
    [1] = "Encounter",
    [2] = "ChallengeMode",
    [3] = "PvPMatch",
    [4] = "Map",
}
local STATE_NAMES = { [0] = "Inactive", [1] = "Activating", [2] = "Active" }

--- Check if protected actions are currently restricted.
--- Returns true if InCombatLockdown() or if any relevant AddOnRestrictionType
--- is active (Encounter=1, ChallengeMode=2, PvPMatch=3). Uses pcall for
--- backward compat with pre-12.0 clients.
--- @return boolean restricted
local function IsRestricted()
    if InCombatLockdown() then
        return true
    end
    if not hasRestrictedAPI then
        return false
    end
    -- Check Encounter (1), ChallengeMode (2), PvPMatch (3)
    -- Skip Combat (0, redundant) and Map (4, zone UI lockdown only)
    for _, rType in ipairs({ 1, 2, 3 }) do
        local ok, active = pcall(C_RestrictedActions.IsAddOnRestrictionActive, rType)
        if ok and active then
            return true
        end
    end
    return false
end
--- Check if protected actions are currently restricted (method form).
--- Wraps the local IsRestricted() so external callers can use OOCQueue:IsRestricted().
--- @return boolean restricted
function OOCQueue:IsRestricted()
    return IsRestricted()
end

GRIPEMS.restrictions = {
    [1] = 0, -- Encounter: Inactive
    [2] = 0, -- ChallengeMode: Inactive
    [3] = 0, -- PvPMatch: Inactive
}

--- Add an operation to the queue, or execute immediately if out of combat.
--- @param func function The function to call
--- @param opType string|nil Operation type from D.OOC_OP_* (default D.OOC_OP_GENERIC)
--- @param seqName string|nil Sequence name for dedup (nil for non-sequence ops)
function OOCQueue:Add(func, opType, seqName)
    if not func then
        return
    end

    if not IsRestricted() then
        func()
        return
    end

    opType = opType or D.OOC_OP_GENERIC
    self.insertOrder = self.insertOrder + 1

    -- Dedup: replace existing entry with same opType+seqName (generic always appends)
    if opType ~= D.OOC_OP_GENERIC then
        for i, item in ipairs(self.queue) do
            if item.opType == opType and item.seqName == seqName then
                GRIPEMS:Debug(string.format(L["GEMS_OOC_REPLACED"], opType, tostring(seqName) or "nil"))
                item.func = func
                return
            end
        end
    end

    table.insert(self.queue, {
        func = func,
        opType = opType,
        seqName = seqName,
        order = self.insertOrder,
    })
    GRIPEMS:Debug(L["GEMS_OOC_QUEUED"])
end

--- Process all queued operations in priority order. Skips if still in combat.
function OOCQueue:Process()
    if IsRestricted() then
        return
    end
    local count = #self.queue
    if count == 0 then
        return
    end

    -- Stable sort by priority (equal priority preserves insertion order)
    local priorities = D.OOC_PRIORITY
    local defaultPri = priorities[D.OOC_OP_GENERIC] or 80
    table.sort(self.queue, function(a, b)
        local pa = priorities[a.opType] or defaultPri
        local pb = priorities[b.opType] or defaultPri
        if pa ~= pb then
            return pa < pb
        end
        return a.order < b.order
    end)

    -- Process all entries, pcall each to prevent one failure from aborting the rest
    for _, item in ipairs(self.queue) do
        local ok, err = pcall(item.func)
        if not ok then
            GRIPEMS:Debug("OOC Queue error (" .. tostring(item.opType) .. "): " .. tostring(err))
        end
    end

    wipe(self.queue)
    self.insertOrder = 0
    GRIPEMS:Debug(string.format(L["GEMS_OOC_PRIORITY_PROCESSED"], count))
end

--- Return the number of pending operations in the queue.
--- @return number
function OOCQueue:GetCount()
    return #self.queue
end

-- Event frame for PLAYER_REGEN_ENABLED (combat end) and PLAYER_REGEN_DISABLED
-- Named for /reload reuse -- prevents orphan C++ frame objects
local oocFrame = _G["GRIPEMS_OOCEvent"] or CreateFrame("Frame", "GRIPEMS_OOCEvent")
oocFrame:UnregisterAllEvents()
oocFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
oocFrame:RegisterEvent("PLAYER_REGEN_DISABLED")
if hasRestrictedAPI then
    oocFrame:RegisterEvent("ADDON_RESTRICTION_STATE_CHANGED")
end
oocFrame:SetScript("OnEvent", function(_, event, ...)
    if event == "PLAYER_REGEN_ENABLED" then
        OOCQueue:Process()
    elseif event == "ADDON_RESTRICTION_STATE_CHANGED" then
        -- State payload: Enum.AddOnRestrictionState (Inactive=0, Activating=1, Active=2)
        -- NOTE: C_RestrictedActions.IsAddOnRestrictionActive returns false DURING
        -- dispatch of this event, so use the payload directly.
        local restrictionType, state = ...
        if GRIPEMS.restrictions then
            GRIPEMS.restrictions[restrictionType] = state
        end
        if GRIPEMS.DebugWindow then
            GRIPEMS.DebugWindow:AddMessage(
                "Restriction: "
                    .. (RESTRICTION_NAMES[restrictionType] or tostring(restrictionType))
                    .. " -> "
                    .. (STATE_NAMES[state] or tostring(state))
            )
        end
        if state == 0 then
            -- Restrictions lifted (Inactive) -- process queue like combat ending
            OOCQueue:Process()
        end
    end
    -- PLAYER_REGEN_DISABLED: queue persists across combat sessions (no wipe)
end)

-- Periodic fallback ticker: catches edge cases where PLAYER_REGEN_ENABLED
-- might not fire (e.g., forced combat drop, death, disconnect recovery).
local oocInterval = D.OOC_TICKER_INTERVAL
local S = GRIPEMS.Settings
if S and S.db then
    oocInterval = S:Get("oocDelay") or oocInterval
end
OOCQueue.ticker = C_Timer.NewTicker(oocInterval, function()
    if not IsRestricted() and #OOCQueue.queue > 0 then
        OOCQueue:Process()
    end
end)

-- Dynamic ticker update: recreate ticker when oocDelay setting changes.
-- Deferred to next frame in case GRIPEMS.RegisterCallback is not yet
-- available at file-load time (load order).
C_Timer.After(0, function()
    if GRIPEMS.RegisterCallback then
        GRIPEMS.RegisterCallback(OOCQueue, "SETTING_CHANGED", function(_, _, key, value)
            if key == "oocDelay" then
                if OOCQueue.ticker then
                    OOCQueue.ticker:Cancel()
                end
                local newInterval = tonumber(value) or D.OOC_TICKER_INTERVAL
                OOCQueue.ticker = C_Timer.NewTicker(newInterval, function()
                    if not IsRestricted() and #OOCQueue.queue > 0 then
                        OOCQueue:Process()
                    end
                end)
            end
        end)
    end
end)
