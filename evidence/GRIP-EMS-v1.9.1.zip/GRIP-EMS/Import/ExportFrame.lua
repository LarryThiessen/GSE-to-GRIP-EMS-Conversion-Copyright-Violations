-- GRIP-EMS: Export Frame (Two-Stage)
-- Stage 1: Multi-select picker with ScrollBox for choosing sequences/variables
-- Stage 2: Read-only display of encoded export string with Ctrl+C auto-close

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS")
local AceGUI = LibStub("AceGUI-3.0")

-- Upvalue accessor for Defaults
local function D()
    return GRIPEMS.Defaults
end

GRIPEMS.ExportFrame = {}
local EF = GRIPEMS.ExportFrame

local frame = nil -- lazy-created native Frame, reused
local pickStage = nil -- native Frame for stage 1 (multi-select picker)
local metaStage = nil -- native Frame for stage 1.5 (metadata editor)
local displayStage = nil -- native Frame for stage 2 (export string display)
local exportListData = nil -- result from GE.BuildExportList()
local metaSelectedSeqNames = nil -- sequence names carried from pick to meta stage
local metaSelectedVarNames = nil -- variable names carried from pick to meta stage

-- Pick stage sub-references
local pickScrollBox, pickScrollBar, pickScrollView, pickDataProvider
local pickHeaderLabel, pickSummaryLine, pickExportBtn, pickWarningLabel

-- Pre-export repair warning dialog (text set dynamically before each show)
StaticPopupDialogs["GRIPEMS_EXPORT_REPAIR_WARN"] = {
    text = "",
    button1 = "",
    button2 = CANCEL,
    OnAccept = function() end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
}

---------------------------------------------------------------------------
-- UpdateExportCount: refresh the Export Selected button label + state
---------------------------------------------------------------------------

local function UpdateExportCount()
    if not pickDataProvider or not pickExportBtn then
        return
    end

    local seqCount = 0
    local varCount = 0
    for _, entry in pickDataProvider:EnumerateEntireRange() do
        if entry.type == "sequence" and entry.entry and entry.entry.selected then
            seqCount = seqCount + 1
        elseif entry.type == "variable" and entry.entry and entry.entry.selected then
            varCount = varCount + 1
        end
    end

    local total = seqCount + varCount
    pickExportBtn.label:SetText(string.format(L["GEMS_EXPORT_PICK_EXPORT_SELECTED"], total))
    if seqCount == 0 then
        pickExportBtn:Disable()
        pickExportBtn:SetAlpha(0.7)
    else
        pickExportBtn:Enable()
        pickExportBtn:SetAlpha(1.0)
    end
end

---------------------------------------------------------------------------
-- Variable auto-selection: resolve deps for currently selected sequences
---------------------------------------------------------------------------

local function ResolveAndAutoSelectVars()
    if not exportListData then
        return
    end

    local GE = GRIPEMS.GRIPExport

    -- Collect selected sequence names
    local selectedNames = {}
    for _, seq in ipairs(exportListData.sequences) do
        if seq.selected then
            selectedNames[#selectedNames + 1] = seq.name
        end
    end

    -- Resolve needed variable names
    local neededVars = GE.ResolveVariableDeps(selectedNames)

    -- Update variable entries
    for _, varEntry in ipairs(exportListData.variables) do
        local needed = neededVars[varEntry.name] or false
        if needed then
            -- Auto-select if not manually deselected
            if not varEntry.manualDeselect then
                varEntry.autoSelected = true
                varEntry.selected = true
            end
        else
            -- Remove auto-selection (keep manual selection)
            varEntry.autoSelected = false
            if not varEntry.manualSelect then
                varEntry.selected = false
            end
        end
    end

    -- Update embedded dep warnings
    local warnings = GE.DetectMissingEmbeddedDeps(selectedNames)
    if pickWarningLabel then
        if #warnings > 0 then
            -- Show first warning, truncated
            local warnText = warnings[1]
            if #warnings > 1 then
                warnText = warnText .. " (+" .. (#warnings - 1) .. " more)"
            end
            pickWarningLabel:SetText(warnText)
            pickWarningLabel:SetTextColor(GRIPEMS.UI.Colors.textWarning:GetRGBA())
        else
            -- Check for locale risk in selected variables
            local hasLocaleRisk = false
            local vsRef = GRIPEMS.VariableStore
            if exportListData and exportListData.variables and vsRef then
                for _, varEntry in ipairs(exportListData.variables) do
                    if varEntry.selected then
                        local risk = vsRef:GetLocaleRisk(varEntry.name)
                        if risk then
                            hasLocaleRisk = true
                            break
                        end
                    end
                end
            end
            if hasLocaleRisk then
                pickWarningLabel:SetText(L["GEMS_EXPORT_PICK_LOCALE_WARN"])
                pickWarningLabel:SetTextColor(GRIPEMS.UI.Colors.textWarning:GetRGBA())
            else
                pickWarningLabel:SetText("")
            end
        end
    end

    -- Refresh ScrollBox display
    if pickScrollBox then
        pickScrollBox:ForEachFrame(function(btn)
            if btn._exportRefresh then
                btn._exportRefresh()
            end
        end)
        -- Force layout pass to visually sync all frames
        if pickScrollBox.FullUpdate then
            pickScrollBox:FullUpdate()
        end
    end

    UpdateExportCount()
end

---------------------------------------------------------------------------
-- Row initializer for pick stage ScrollBox
---------------------------------------------------------------------------

--- Initialize or refresh a pick-stage row.
--- @param button Button The reusable row frame
--- @param data table Row data with type, entry fields
local function InitExportRow(button, data)
    local UI = GRIPEMS.UI
    local C = UI.Colors
    local rowHeight = D().EXPORT_PICKER_ROW_HEIGHT

    button:SetHeight(rowHeight)

    -- Ensure sub-elements created once
    if not button._pickInit then
        button._pickInit = true

        -- Background
        local bg = button:CreateTexture(nil, "BACKGROUND")
        bg:SetAllPoints()
        bg:SetColorTexture(0, 0, 0, 0)
        button._bg = bg

        -- CheckButton
        local cb = CreateFrame("CheckButton", nil, button, "UICheckButtonTemplate")
        cb:SetSize(18, 18)
        cb:SetPoint("LEFT", button, "LEFT", 4, 0)
        cb:SetHitRectInsets(0, 0, 0, 0)
        button._checkBtn = cb

        -- Icon texture
        local icon = button:CreateTexture(nil, "ARTWORK")
        icon:SetSize(20, 20)
        icon:SetPoint("LEFT", cb, "RIGHT", 4, 0)
        button._icon = icon

        -- Name label
        local nameLabel = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(nameLabel, 11)
        nameLabel:SetPoint("LEFT", icon, "RIGHT", 6, 0)
        nameLabel:SetJustifyH("LEFT")
        nameLabel:SetWordWrap(false)
        button._nameLabel = nameLabel

        -- Info label (versions/steps)
        local infoLabel = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(infoLabel, 10)
        infoLabel:SetJustifyH("LEFT")
        infoLabel:SetWordWrap(false)
        button._infoLabel = infoLabel

        -- VarDep indicator
        local varDepLabel = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(varDepLabel, 10)
        varDepLabel:SetJustifyH("LEFT")
        varDepLabel:SetWordWrap(false)
        button._varDepLabel = varDepLabel

        -- Auto badge (for variables)
        local autoBadge = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(autoBadge, 10)
        autoBadge:SetJustifyH("RIGHT")
        button._autoBadge = autoBadge

        -- Section header label (for header rows)
        local headerText = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(headerText, 11, "OUTLINE")
        headerText:SetPoint("LEFT", button, "LEFT", 8, 0)
        headerText:SetJustifyH("LEFT")
        button._headerText = headerText
    end

    -- Reset visibility
    button._checkBtn:Hide()
    button._icon:Hide()
    button._nameLabel:Hide()
    button._infoLabel:Hide()
    button._varDepLabel:Hide()
    button._autoBadge:Hide()
    button._headerText:Hide()
    button._bg:SetColorTexture(0, 0, 0, 0)
    button._exportRefresh = nil

    -----------------------------------------------------------------------
    -- Section header rows
    -----------------------------------------------------------------------
    if data.type == "seqHeader" or data.type == "varHeader" then
        button._headerText:Show()
        button._headerText:SetTextColor(C.textSecondary:GetRGBA())
        button._bg:SetColorTexture(C.bgPanel:GetRGB())
        button._bg:SetAlpha(0.3)
        if data.type == "seqHeader" then
            button._headerText:SetText(string.format(L["GEMS_EXPORT_PICK_SEQ_HEADER"], data.count or 0))
        else
            button._headerText:SetText(string.format(L["GEMS_EXPORT_PICK_VAR_HEADER"], data.count or 0))
        end
        button:SetScript("OnClick", nil)
        return
    end

    -----------------------------------------------------------------------
    -- Sequence rows
    -----------------------------------------------------------------------
    if data.type == "sequence" then
        local entry = data.entry

        -- CheckButton
        button._checkBtn:Show()
        button._checkBtn:SetChecked(entry.selected)
        button._checkBtn:SetScript("OnClick", function(self)
            entry.selected = self:GetChecked()
            ResolveAndAutoSelectVars()
        end)

        -- Icon
        button._icon:Show()
        button._icon:SetTexture(UI:ResolveIcon(entry.icon))

        -- Name
        button._nameLabel:Show()
        button._nameLabel:SetText(entry.name or "")
        button._nameLabel:SetTextColor(C.textPrimary:GetRGBA())
        button._nameLabel:SetWidth(200)

        -- Info: "N versions, N steps"
        button._infoLabel:Show()
        button._infoLabel:SetPoint("LEFT", button._nameLabel, "RIGHT", 8, 0)
        button._infoLabel:SetText(
            string.format(L["GEMS_EXPORT_PICK_INFO"], entry.versionCount or 1, entry.stepCount or 0)
        )
        button._infoLabel:SetTextColor(C.textSecondary:GetRGBA())

        -- VarDep indicator
        if entry.varDeps and #entry.varDeps > 0 then
            button._varDepLabel:Show()
            button._varDepLabel:SetPoint("LEFT", button._infoLabel, "RIGHT", 8, 0)
            button._varDepLabel:SetText(string.format(L["GEMS_EXPORT_PICK_VAR_DEPS"], #entry.varDeps))
            button._varDepLabel:SetTextColor(C.keybindGold:GetRGBA())
        end

        button:SetScript("OnClick", nil)

        -- Refresh callback for auto-select updates
        button._exportRefresh = function()
            button._checkBtn:SetChecked(entry.selected)
        end
        return
    end

    -----------------------------------------------------------------------
    -- Variable rows
    -----------------------------------------------------------------------
    if data.type == "variable" then
        local entry = data.entry

        -- CheckButton (indented 24px more)
        button._checkBtn:Show()
        button._checkBtn:SetPoint("LEFT", button, "LEFT", 28, 0)
        button._checkBtn:SetChecked(entry.selected)
        button._checkBtn:SetScript("OnClick", function(self)
            local checked = self:GetChecked()
            entry.selected = checked
            if checked then
                entry.manualSelect = true
                entry.manualDeselect = nil
            else
                entry.manualDeselect = true
                entry.manualSelect = nil
                entry.autoSelected = false
            end
            UpdateExportCount()
        end)

        -- Name
        button._nameLabel:Show()
        button._nameLabel:SetPoint("LEFT", button._checkBtn, "RIGHT", 6, 0)
        button._nameLabel:SetText(entry.name or "")
        button._nameLabel:SetTextColor(C.textPrimary:GetRGBA())

        -- "used by" info
        if entry.referencedBy and #entry.referencedBy > 0 then
            button._infoLabel:Show()
            button._infoLabel:SetPoint("LEFT", button._nameLabel, "RIGHT", 8, 0)
            local refText = table.concat(entry.referencedBy, ", ")
            button._infoLabel:SetText(string.format(L["GEMS_EXPORT_PICK_USED_BY"], refText))
            button._infoLabel:SetTextColor(C.textSecondary:GetRGBA())
        end

        -- "auto" badge if autoSelected
        if entry.autoSelected then
            button._autoBadge:Show()
            button._autoBadge:SetPoint("RIGHT", button, "RIGHT", -8, 0)
            button._autoBadge:SetText(L["GEMS_EXPORT_PICK_AUTO"])
            button._autoBadge:SetTextColor(C.keybindGold:GetRGBA())
        end

        button:SetScript("OnClick", nil)

        -- Refresh callback for auto-select updates
        button._exportRefresh = function()
            button._checkBtn:SetChecked(entry.selected)
            if entry.autoSelected then
                button._autoBadge:Show()
                button._autoBadge:SetPoint("RIGHT", button, "RIGHT", -8, 0)
                button._autoBadge:SetText(L["GEMS_EXPORT_PICK_AUTO"])
                button._autoBadge:SetTextColor(C.keybindGold:GetRGBA())
            else
                button._autoBadge:Hide()
            end
        end
        return
    end
end

---------------------------------------------------------------------------
-- ShowPickStage: populate and show the picker
---------------------------------------------------------------------------

local function ShowPickStage(preSelectName)
    local GE = GRIPEMS.GRIPExport
    if not pickStage or not displayStage then
        return
    end

    pickStage:Show()
    displayStage:Hide()
    if metaStage then
        metaStage:Hide()
    end

    -- Build export list
    exportListData = GE.BuildExportList()

    -- Header
    pickHeaderLabel:SetText(L["GEMS_EXPORT_PICK_TITLE"])

    -- Summary
    pickSummaryLine:SetText(
        string.format(L["GEMS_EXPORT_PICK_HEADER"], #exportListData.sequences, #exportListData.variables)
    )

    -- Build flat data array for ScrollBox
    local flatData = {}

    if #exportListData.sequences > 0 then
        flatData[#flatData + 1] = {
            type = "seqHeader",
            count = #exportListData.sequences,
        }
        for _, entry in ipairs(exportListData.sequences) do
            flatData[#flatData + 1] = {
                type = "sequence",
                entry = entry,
            }
        end
    end

    if #exportListData.variables > 0 then
        flatData[#flatData + 1] = {
            type = "varHeader",
            count = #exportListData.variables,
        }
        for _, entry in ipairs(exportListData.variables) do
            flatData[#flatData + 1] = {
                type = "variable",
                entry = entry,
            }
        end
    end

    -- Pre-select mode: check the named sequence, deselect others
    if preSelectName then
        for _, entry in ipairs(exportListData.sequences) do
            if entry.name == preSelectName then
                entry.selected = true
            else
                entry.selected = false
            end
        end
    end

    -- Populate DataProvider
    pickDataProvider = CreateDataProvider()
    for _, rowData in ipairs(flatData) do
        pickDataProvider:Insert(rowData)
    end
    pickScrollBox:SetDataProvider(pickDataProvider)

    -- Clear warnings
    if pickWarningLabel then
        pickWarningLabel:SetText("")
    end

    UpdateExportCount()

    -- Auto-resolve variable deps for pre-selected sequence
    if preSelectName then
        ResolveAndAutoSelectVars()
    end
end

---------------------------------------------------------------------------
-- ShowDisplayStage: show the export string display
---------------------------------------------------------------------------

local function ShowDisplayStage(headerText, exportString, showBack)
    if not pickStage or not displayStage then
        return
    end
    pickStage:Hide()
    if metaStage then
        metaStage:Hide()
    end
    displayStage:Show()

    displayStage._headerLabel:SetText(headerText)
    displayStage._editbox:SetText(exportString)

    if showBack then
        displayStage._backBtn:Show()
    else
        displayStage._backBtn:Hide()
    end

    -- Auto-focus + highlight
    C_Timer.After(0.05, function()
        if displayStage and displayStage:IsShown() and displayStage._editbox then
            displayStage._editbox.editBox:SetFocus()
            displayStage._editbox.editBox:HighlightText()
        end
    end)
end

---------------------------------------------------------------------------
-- ShowMetaStage: populate and show the metadata editor
---------------------------------------------------------------------------

local function ShowMetaStage(seqNames)
    if not metaStage then
        return
    end
    if pickStage then
        pickStage:Hide()
    end
    if displayStage then
        displayStage:Hide()
    end
    metaStage:Show()

    -- Update subtitle with sequence count
    if metaStage._subtitleLabel then
        metaStage._subtitleLabel:SetText(string.format(L["GEMS_EXPORT_META_SUBTITLE"], #seqNames))
    end

    -- Default collection name: first selected sequence name, or generic
    local defaultName = "GRIP-EMS Collection"
    if #seqNames == 1 then
        defaultName = seqNames[1]
    end
    if metaStage._nameBox then
        metaStage._nameBox:SetText(defaultName)
    end

    -- Default author
    local playerName = UnitName("player") or ""
    if metaStage._authorBox then
        metaStage._authorBox:SetText(playerName)
    end

    -- Clear description and URL
    if metaStage._descBox then
        metaStage._descBox:SetText("")
    end
    if metaStage._urlBox then
        metaStage._urlBox:SetText("")
    end

    -- Talent string auto-populate
    local talentStr = ""
    local configID = C_ClassTalents and C_ClassTalents.GetActiveConfigID and C_ClassTalents.GetActiveConfigID()
    if configID and C_Traits and C_Traits.GenerateImportString then
        local talentOk, talentResult = pcall(C_Traits.GenerateImportString, configID)
        if talentOk and talentResult then
            talentStr = talentResult
        end
    end
    if metaStage._talentBox then
        metaStage._talentBox:SetText(talentStr)
    end

    -- Reset toggles to checked
    if metaStage._cbAuthor then
        metaStage._cbAuthor:SetChecked(true)
    end
    if metaStage._cbDesc then
        metaStage._cbDesc:SetChecked(true)
    end
    if metaStage._cbTalent then
        metaStage._cbTalent:SetChecked(true)
    end
    if metaStage._cbUrl then
        metaStage._cbUrl:SetChecked(true)
    end
end

---------------------------------------------------------------------------
-- CreateMetaStage: builds the metadata editor UI (once)
---------------------------------------------------------------------------

local function CreateMetaStage(rawFrame)
    local UI = GRIPEMS.UI
    local C = UI.Colors
    local Dd = D()

    metaStage = CreateFrame("Frame", nil, rawFrame)
    metaStage:SetPoint("TOPLEFT", rawFrame, "TOPLEFT", 10, -32)
    metaStage:SetPoint("BOTTOMRIGHT", rawFrame, "BOTTOMRIGHT", -10, 4)
    metaStage:Hide()

    -- Scrollable content area to handle overflow
    local scrollFrame = CreateFrame("ScrollFrame", nil, metaStage, "UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT", metaStage, "TOPLEFT", 0, 0)
    scrollFrame:SetPoint("BOTTOMRIGHT", metaStage, "BOTTOMRIGHT", -18, 36)

    local content = CreateFrame("Frame", nil, scrollFrame)
    content:SetWidth(Dd.EXPORT_PICKER_WIDTH - 56)
    scrollFrame:SetScrollChild(content)
    UI:SkinLegacyScrollBar(scrollFrame)

    -- Dark backdrop behind scroll area
    local scrollBg = CreateFrame("Frame", nil, metaStage, "BackdropTemplate")
    scrollBg:SetPoint("TOPLEFT", scrollFrame, "TOPLEFT", 0, 0)
    scrollBg:SetPoint("BOTTOMRIGHT", scrollFrame, "BOTTOMRIGHT", 18, 0)
    scrollBg:SetFrameLevel(metaStage:GetFrameLevel())
    UI:ApplyBackdrop(scrollBg, UI.Backdrops.panel, C.bgInput, C.border)

    local yOff = -8

    -- Header
    local titleLabel = content:CreateFontString(nil, "OVERLAY")
    UI:SetFont(titleLabel, 13)
    titleLabel:SetPoint("TOPLEFT", content, "TOPLEFT", 4, yOff)
    titleLabel:SetTextColor(C.textPrimary:GetRGBA())
    titleLabel:SetText(L["GEMS_EXPORT_META_TITLE"])

    yOff = yOff - 18

    -- Subtitle
    local subtitleLabel = content:CreateFontString(nil, "OVERLAY")
    UI:SetFont(subtitleLabel, 10)
    subtitleLabel:SetPoint("TOPLEFT", content, "TOPLEFT", 4, yOff)
    subtitleLabel:SetTextColor(C.textSecondary:GetRGBA())
    metaStage._subtitleLabel = subtitleLabel

    yOff = yOff - 24

    -- Helper: create a labeled single-line EditBox
    local function MakeEditBox(parent, labelText, maxChars, yPos)
        local lbl = parent:CreateFontString(nil, "OVERLAY")
        UI:SetFont(lbl, 11)
        lbl:SetPoint("TOPLEFT", parent, "TOPLEFT", 4, yPos)
        lbl:SetTextColor(C.textSecondary:GetRGBA())
        lbl:SetText(labelText)

        local box = CreateFrame("EditBox", nil, parent, "BackdropTemplate")
        box:SetPoint("TOPLEFT", parent, "TOPLEFT", 4, yPos - 16)
        box:SetPoint("RIGHT", parent, "RIGHT", -4, 0)
        box:SetHeight(22)
        box:SetAutoFocus(false)
        box:SetMaxLetters(maxChars or 256)
        UI:ApplyBackdrop(box, UI.Backdrops.panel, C.bgInput, C.border)
        UI:SetFont(box, 11)
        box:SetTextColor(C.textPrimary:GetRGBA())
        box:SetTextInsets(6, 6, 2, 2)
        box:SetScript("OnEscapePressed", function(self)
            self:ClearFocus()
        end)
        box:SetScript("OnEnterPressed", function(self)
            self:ClearFocus()
        end)
        return box, yPos - 44
    end

    -- Helper: create a labeled CheckButton
    local function MakeCheckButton(parent, labelText, yPos)
        local cb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
        cb:SetSize(18, 18)
        cb:SetPoint("TOPLEFT", parent, "TOPLEFT", 4, yPos)
        cb:SetChecked(true)
        local cbLabel = cb:CreateFontString(nil, "OVERLAY")
        UI:SetFont(cbLabel, 11)
        cbLabel:SetPoint("LEFT", cb, "RIGHT", 4, 0)
        cbLabel:SetTextColor(C.textSecondary:GetRGBA())
        cbLabel:SetText(labelText)
        return cb, yPos - 24
    end

    -- 1) Collection Name
    local nameBox
    nameBox, yOff = MakeEditBox(content, L["GEMS_EXPORT_META_NAME"], Dd.EXPORT_META_NAME_MAX, yOff)
    metaStage._nameBox = nameBox

    -- 2) Author
    local authorBox
    authorBox, yOff = MakeEditBox(content, L["GEMS_EXPORT_META_AUTHOR"], Dd.EXPORT_META_NAME_MAX, yOff)
    metaStage._authorBox = authorBox

    -- 3) Description (multi-line)
    local descLbl = content:CreateFontString(nil, "OVERLAY")
    UI:SetFont(descLbl, 11)
    descLbl:SetPoint("TOPLEFT", content, "TOPLEFT", 4, yOff)
    descLbl:SetTextColor(C.textSecondary:GetRGBA())
    descLbl:SetText(L["GEMS_EXPORT_META_DESC"])

    local descBox = CreateFrame("EditBox", nil, content, "BackdropTemplate")
    descBox:SetPoint("TOPLEFT", content, "TOPLEFT", 4, yOff - 16)
    descBox:SetPoint("RIGHT", content, "RIGHT", -4, 0)
    descBox:SetHeight(52)
    descBox:SetAutoFocus(false)
    descBox:SetMultiLine(true)
    descBox:SetMaxLetters(Dd.EXPORT_META_DESC_MAX)
    UI:ApplyBackdrop(descBox, UI.Backdrops.panel, C.bgInput, C.border)
    UI:SetFont(descBox, 11)
    descBox:SetTextColor(C.textPrimary:GetRGBA())
    descBox:SetTextInsets(6, 6, 4, 4)
    descBox:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
    end)
    metaStage._descBox = descBox
    yOff = yOff - 74

    -- 4) URL / Link
    local urlBox
    urlBox, yOff = MakeEditBox(content, L["GEMS_EXPORT_META_URL"], Dd.EXPORT_META_URL_MAX, yOff)
    metaStage._urlBox = urlBox

    -- 5) Talent Loadout
    local talentBox
    talentBox, yOff = MakeEditBox(content, L["GEMS_EXPORT_META_TALENT"], 512, yOff)
    metaStage._talentBox = talentBox

    yOff = yOff - 4

    -- Toggles section
    local cbAuthor
    cbAuthor, yOff = MakeCheckButton(content, L["GEMS_EXPORT_META_INCLUDE_AUTHOR"], yOff)
    metaStage._cbAuthor = cbAuthor

    local cbDesc
    cbDesc, yOff = MakeCheckButton(content, L["GEMS_EXPORT_META_INCLUDE_DESC"], yOff)
    metaStage._cbDesc = cbDesc

    local cbTalent
    cbTalent, yOff = MakeCheckButton(content, L["GEMS_EXPORT_META_INCLUDE_TALENT"], yOff)
    metaStage._cbTalent = cbTalent

    local cbUrl
    cbUrl, yOff = MakeCheckButton(content, L["GEMS_EXPORT_META_INCLUDE_URL"], yOff)
    metaStage._cbUrl = cbUrl

    -- Set content height for scrolling
    content:SetHeight(math.abs(yOff) + 16)

    -------------------------------------------------------------------
    -- Bottom bar (36px)
    -------------------------------------------------------------------
    local bottomBar = CreateFrame("Frame", nil, metaStage)
    bottomBar:SetHeight(Dd.BUTTON_BAR_HEIGHT)
    bottomBar:SetPoint("BOTTOMLEFT", metaStage, "BOTTOMLEFT", 0, 0)
    bottomBar:SetPoint("BOTTOMRIGHT", metaStage, "BOTTOMRIGHT", 0, 0)

    -- Back button
    local backBtn = UI:CreateButton(bottomBar, L["GEMS_EXPORT_META_BACK"], 120, 26)
    backBtn:SetPoint("LEFT", bottomBar, "LEFT", 0, 0)
    backBtn:SetScript("OnEnter", function(self)
        UI:ShowTooltip(self, L["GEMS_EXPORT_META_BACK"], L["GEMS_EXPORT_BACK_DESC"])
    end)
    backBtn:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)
    backBtn:SetScript("OnClick", function()
        metaStage:Hide()
        ShowPickStage()
    end)

    -- Generate Export String button (green, right side)
    local generateBtn = UI:CreateButton(bottomBar, L["GEMS_EXPORT_META_GENERATE"], 180, 26)
    generateBtn:SetPoint("RIGHT", bottomBar, "RIGHT", 0, 0)
    generateBtn:SetBackdropColor(C.bgSave:GetRGBA())
    generateBtn:SetScript("OnEnter", function(self)
        UI:ShowTooltip(self, L["GEMS_EXPORT_META_GENERATE"], L["GEMS_EXPORT_GENERATE_DESC"])
        self:SetBackdropColor(C.bgSaveHover:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
    end)
    generateBtn:SetScript("OnLeave", function(self)
        GameTooltip:Hide()
        self:SetBackdropColor(C.bgSave:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
    end)
    generateBtn:SetScript("OnClick", function()
        if not metaSelectedSeqNames or #metaSelectedSeqNames == 0 then
            return
        end

        -- Build exportMeta from editor fields
        local exportMeta = {
            collectionName = metaStage._nameBox and metaStage._nameBox:GetText() or "",
            author = metaStage._authorBox and metaStage._authorBox:GetText() or "",
            description = metaStage._descBox and metaStage._descBox:GetText() or "",
            url = metaStage._urlBox and metaStage._urlBox:GetText() or "",
            talentString = metaStage._talentBox and metaStage._talentBox:GetText() or "",
            includeAuthor = metaStage._cbAuthor and metaStage._cbAuthor:GetChecked() or false,
            includeDescription = metaStage._cbDesc and metaStage._cbDesc:GetChecked() or false,
            includeTalent = metaStage._cbTalent and metaStage._cbTalent:GetChecked() or false,
            includeUrl = metaStage._cbUrl and metaStage._cbUrl:GetChecked() or false,
        }

        local GE = GRIPEMS.GRIPExport
        local ok, result = GE.ExportCollection(metaSelectedSeqNames, metaSelectedVarNames, exportMeta)
        if ok then
            if GRIPEMS.wagoAnalytics then
                GRIPEMS.wagoAnalytics:IncrementCounter("seq_exported")
            end
            local header = string.format(
                L["GEMS_EXPORT_PICK_DISPLAY_HEADER"],
                #metaSelectedSeqNames,
                metaSelectedVarNames and #metaSelectedVarNames or 0
            )
            metaStage:Hide()
            ShowDisplayStage(header, result, true)
        else
            GRIPEMS:Print(string.format(L["GEMS_EXPORT_FAILED"], tostring(result)))
        end
    end)
end

---------------------------------------------------------------------------
-- CreatePickStage: builds the picker UI (once)
---------------------------------------------------------------------------

local function CreatePickStage(rawFrame)
    local UI = GRIPEMS.UI
    local C = UI.Colors

    pickStage = CreateFrame("Frame", nil, rawFrame)
    pickStage:SetPoint("TOPLEFT", rawFrame, "TOPLEFT", 10, -32)
    pickStage:SetPoint("BOTTOMRIGHT", rawFrame, "BOTTOMRIGHT", -10, 4)
    pickStage:Hide()

    -- Header label
    pickHeaderLabel = pickStage:CreateFontString(nil, "OVERLAY")
    UI:SetFont(pickHeaderLabel, 13)
    pickHeaderLabel:SetPoint("TOPLEFT", pickStage, "TOPLEFT", 4, -4)
    pickHeaderLabel:SetTextColor(C.textPrimary:GetRGBA())

    -- Summary line
    pickSummaryLine = pickStage:CreateFontString(nil, "OVERLAY")
    UI:SetFont(pickSummaryLine, 10)
    pickSummaryLine:SetPoint("TOPLEFT", pickHeaderLabel, "BOTTOMLEFT", 0, -4)
    pickSummaryLine:SetTextColor(C.textSecondary:GetRGBA())

    -------------------------------------------------------------------
    -- Bottom bar (36px)
    -------------------------------------------------------------------
    local bottomBar = CreateFrame("Frame", nil, pickStage)
    bottomBar:SetHeight(D().BUTTON_BAR_HEIGHT)
    bottomBar:SetPoint("BOTTOMLEFT", pickStage, "BOTTOMLEFT", 0, 0)
    bottomBar:SetPoint("BOTTOMRIGHT", pickStage, "BOTTOMRIGHT", 0, 0)

    -- Select All
    local selectAllBtn = UI:CreateButton(bottomBar, L["GEMS_EXPORT_PICK_SELECT_ALL"], 90, 26)
    selectAllBtn:SetPoint("BOTTOMLEFT", pickStage, "BOTTOMLEFT", 0, 0)
    selectAllBtn:SetScript("OnEnter", function(self)
        UI:ShowTooltip(self, L["GEMS_EXPORT_PICK_SELECT_ALL"], L["GEMS_EXPORT_SELECT_ALL_DESC"])
    end)
    selectAllBtn:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)
    selectAllBtn:SetScript("OnClick", function()
        if not exportListData then
            return
        end
        for _, entry in ipairs(exportListData.sequences) do
            entry.selected = true
        end
        ResolveAndAutoSelectVars()
    end)

    -- Deselect All
    local deselectAllBtn = UI:CreateButton(bottomBar, L["GEMS_EXPORT_PICK_DESELECT_ALL"], 100, 26)
    deselectAllBtn:SetPoint("LEFT", selectAllBtn, "RIGHT", 4, 0)
    deselectAllBtn:SetScript("OnEnter", function(self)
        UI:ShowTooltip(self, L["GEMS_EXPORT_PICK_DESELECT_ALL"], L["GEMS_EXPORT_DESELECT_ALL_DESC"])
    end)
    deselectAllBtn:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)
    deselectAllBtn:SetScript("OnClick", function()
        if not exportListData then
            return
        end
        for _, entry in ipairs(exportListData.sequences) do
            entry.selected = false
        end
        for _, entry in ipairs(exportListData.variables) do
            entry.selected = false
            entry.autoSelected = false
            entry.manualSelect = nil
            entry.manualDeselect = nil
        end
        if pickScrollBox then
            pickScrollBox:ForEachFrame(function(btn)
                if btn._exportRefresh then
                    btn._exportRefresh()
                end
            end)
        end
        if pickWarningLabel then
            pickWarningLabel:SetText("")
        end
        UpdateExportCount()
    end)

    -- Close button (right-most)
    local closeBtn = UI:CreateButton(pickStage, "Close", 70, 26)
    closeBtn:SetPoint("BOTTOMRIGHT", pickStage, "BOTTOMRIGHT", 0, 0)
    closeBtn:SetScript("OnEnter", function(self)
        UI:ShowTooltip(self, CLOSE or "Close", L["GEMS_EXPORT_CLOSE_DESC"])
    end)
    closeBtn:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)
    closeBtn:SetScript("OnClick", function()
        if frame then
            frame:Hide()
        end
    end)

    -- Copy as Text (left of Export, neutral)
    local copyTextBtn = UI:CreateButton(bottomBar, L["GEMS_EXPORT_COPY_TEXT"], 120, 26)
    copyTextBtn:SetPoint("RIGHT", closeBtn, "LEFT", -4, 0)
    copyTextBtn:SetScript("OnEnter", function(self)
        UI:ShowTooltip(self, L["GEMS_EXPORT_COPY_TEXT"], L["GEMS_EXPORT_COPY_DESC"])
    end)
    copyTextBtn:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)
    copyTextBtn:SetScript("OnClick", function()
        if not exportListData then
            return
        end
        local seqNames = {}
        for _, entry in ipairs(exportListData.sequences) do
            if entry.selected then
                seqNames[#seqNames + 1] = entry.name
            end
        end
        local varNames = {}
        for _, entry in ipairs(exportListData.variables) do
            if entry.selected then
                varNames[#varNames + 1] = entry.name
            end
        end
        if #seqNames == 0 then
            return
        end
        local GE = GRIPEMS.GRIPExport
        local text = GE.ExportAsText(seqNames, varNames)
        local header = string.format(L["GEMS_EXPORT_PICK_DISPLAY_HEADER"], #seqNames, #varNames)
        ShowDisplayStage(header, text, true)
    end)

    -- Export Selected (left of CopyText, green-tinted)
    pickExportBtn = UI:CreateButton(bottomBar, "", 160, 26)
    pickExportBtn:SetPoint("RIGHT", copyTextBtn, "LEFT", -4, 0)
    pickExportBtn:SetBackdropColor(C.bgSave:GetRGBA())
    pickExportBtn:SetScript("OnEnter", function(self)
        UI:ShowTooltip(self, L["GEMS_EXPORT_PICK_EXPORT_SELECTED"]:format(0), L["GEMS_EXPORT_GENERATE_DESC"])
        self:SetBackdropColor(C.bgSaveHover:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
    end)
    pickExportBtn:SetScript("OnLeave", function(self)
        GameTooltip:Hide()
        self:SetBackdropColor(C.bgSave:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
    end)
    pickExportBtn:SetScript("OnClick", function()
        if not exportListData then
            return
        end

        -- Collect selected names
        local seqNames = {}
        for _, entry in ipairs(exportListData.sequences) do
            if entry.selected then
                seqNames[#seqNames + 1] = entry.name
            end
        end
        local varNames = {}
        for _, entry in ipairs(exportListData.variables) do
            if entry.selected then
                varNames[#varNames + 1] = entry.name
            end
        end

        if #seqNames == 0 then
            return
        end

        -- Pre-export repair check (iterate ALL selected sequences)
        local RA = GRIPEMS.RepairAnalyzer
        if RA then
            local issueCount = 0
            for _, sName in ipairs(seqNames) do
                local seqEntry = GRIPEMS.Engine and GRIPEMS.Engine.sequences and GRIPEMS.Engine.sequences[sName]
                if seqEntry and seqEntry.data then
                    local issues = RA:Analyze(seqEntry.data, sName)
                    for _, issue in ipairs(issues) do
                        if issue.severity == "critical" or issue.severity == "error" then
                            issueCount = issueCount + 1
                        end
                    end
                end
            end
            if issueCount > 0 then
                local dialog = StaticPopupDialogs["GRIPEMS_EXPORT_REPAIR_WARN"]
                dialog.text = string.format(L["GEMS_REPAIR_EXPORT_WARN"], issueCount)
                dialog.button1 = L["GEMS_REPAIR_EXPORT_ACCEPT"]
                dialog.OnAccept = function()
                    metaSelectedSeqNames = seqNames
                    metaSelectedVarNames = varNames
                    ShowMetaStage(seqNames)
                end
                StaticPopup_Show("GRIPEMS_EXPORT_REPAIR_WARN")
                return
            end
        end

        -- Store selections for meta stage
        metaSelectedSeqNames = seqNames
        metaSelectedVarNames = varNames

        -- Show metadata editor instead of encoding directly
        ShowMetaStage(seqNames)
    end)

    -- Warning label (center, between deselect and export)
    pickWarningLabel = bottomBar:CreateFontString(nil, "OVERLAY")
    UI:SetFont(pickWarningLabel, 10)
    pickWarningLabel:SetPoint("LEFT", deselectAllBtn, "RIGHT", 8, 0)
    pickWarningLabel:SetPoint("RIGHT", pickExportBtn, "LEFT", -4, 0)
    pickWarningLabel:SetJustifyH("CENTER")
    pickWarningLabel:SetWordWrap(false)
    pickWarningLabel:SetText("")

    -------------------------------------------------------------------
    -- ScrollBox (between summary and bottom bar)
    -------------------------------------------------------------------
    pickScrollBox = CreateFrame("Frame", nil, pickStage, "WowScrollBoxList")
    pickScrollBox:SetPoint("TOPLEFT", pickSummaryLine, "BOTTOMLEFT", 0, -8)
    pickScrollBox:SetPoint("BOTTOMRIGHT", bottomBar, "TOPRIGHT", -18, 4)

    pickScrollBar = CreateFrame("EventFrame", nil, pickStage, "MinimalScrollBar")
    pickScrollBar:SetPoint("TOPLEFT", pickScrollBox, "TOPRIGHT", 2, 0)
    pickScrollBar:SetPoint("BOTTOMLEFT", pickScrollBox, "BOTTOMRIGHT", 2, 0)

    pickScrollView = CreateScrollBoxListLinearView()
    pickScrollView:SetElementExtent(D().EXPORT_PICKER_ROW_HEIGHT)

    pickScrollView:SetElementInitializer("Button", function(button, rowData)
        InitExportRow(button, rowData)
    end)

    ScrollUtil.InitScrollBoxListWithScrollBar(pickScrollBox, pickScrollBar, pickScrollView)

    -- Dark backdrop behind scroll area
    local scrollBg = CreateFrame("Frame", nil, pickStage, "BackdropTemplate")
    scrollBg:SetPoint("TOPLEFT", pickScrollBox, "TOPLEFT", 0, 0)
    scrollBg:SetPoint("BOTTOMRIGHT", pickScrollBar, "BOTTOMRIGHT", 0, 0)
    scrollBg:SetFrameLevel(pickStage:GetFrameLevel())
    UI:ApplyBackdrop(scrollBg, UI.Backdrops.panel, C.bgInput, C.border)

    pickDataProvider = CreateDataProvider()
    pickScrollBox:SetDataProvider(pickDataProvider)
end

---------------------------------------------------------------------------
-- CreateDisplayStage: builds the export string display UI (once)
---------------------------------------------------------------------------

local function CreateDisplayStage(rawFrame)
    local UI = GRIPEMS.UI
    local C = UI.Colors

    displayStage = CreateFrame("Frame", nil, rawFrame)
    displayStage:SetPoint("TOPLEFT", rawFrame, "TOPLEFT", 10, -32)
    displayStage:SetPoint("BOTTOMRIGHT", rawFrame, "BOTTOMRIGHT", -10, 4)
    displayStage:Hide()

    -- Header label
    local headerLabel = displayStage:CreateFontString(nil, "OVERLAY")
    UI:SetFont(headerLabel, 13)
    headerLabel:SetPoint("TOPLEFT", displayStage, "TOPLEFT", 4, -4)
    headerLabel:SetTextColor(C.textPrimary:GetRGBA())
    displayStage._headerLabel = headerLabel

    -- Hint label
    local hint = displayStage:CreateFontString(nil, "OVERLAY")
    UI:SetFont(hint, 10)
    hint:SetPoint("TOPLEFT", headerLabel, "BOTTOMLEFT", 0, -4)
    hint:SetText(L["GEMS_EXPORT_FRAME_HINT"])
    hint:SetTextColor(C.textSecondary:GetRGBA())

    -- Bottom bar
    local bottomBar = CreateFrame("Frame", nil, displayStage)
    bottomBar:SetHeight(D().BUTTON_BAR_HEIGHT)
    bottomBar:SetPoint("BOTTOMLEFT", displayStage, "BOTTOMLEFT", 0, 0)
    bottomBar:SetPoint("BOTTOMRIGHT", displayStage, "BOTTOMRIGHT", 0, 0)

    -- Back button (bottom-left)
    local backBtn = UI:CreateButton(bottomBar, L["GEMS_EXPORT_PICK_BACK"], 80, 26)
    backBtn:SetPoint("LEFT", bottomBar, "LEFT", 4, 0)
    backBtn:SetScript("OnEnter", function(self)
        UI:ShowTooltip(self, L["GEMS_EXPORT_PICK_BACK"], L["GEMS_EXPORT_BACK_DESC"])
    end)
    backBtn:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)
    backBtn:SetScript("OnClick", function()
        ShowPickStage()
    end)
    displayStage._backBtn = backBtn

    -- MultiLineEditBox (read-only display) via AceGUI
    local editbox = AceGUI:Create("MultiLineEditBox")
    editbox:SetLabel("")
    editbox:SetNumLines(15)
    editbox:DisableButton(true)
    editbox.frame:SetParent(displayStage)
    editbox.frame:SetPoint("TOPLEFT", hint, "BOTTOMLEFT", -2, -6)
    editbox.frame:SetPoint("BOTTOMRIGHT", bottomBar, "TOPRIGHT", -4, 4)
    editbox.frame:Show()
    displayStage._editbox = editbox

    -- Dark-theme the editbox
    editbox.scrollBG:SetBackdrop(UI.Backdrops.panel)
    editbox.scrollBG:SetBackdropColor(C.bgInput:GetRGBA())
    editbox.scrollBG:SetBackdropBorderColor(C.border:GetRGBA())
    editbox.editBox:SetTextColor(C.textPrimary:GetRGBA())
    if editbox.label then
        editbox.label:SetTextColor(C.textSecondary:GetRGBA())
    end

    -- On re-focus, re-highlight all text for easy Ctrl+C
    editbox.editBox:SetScript("OnEditFocusGained", function(self)
        self:HighlightText()
    end)

    -- Auto-close on Ctrl+C
    editbox.editBox:SetScript("OnKeyDown", function(_, key)
        if key == "C" and IsControlKeyDown() then
            C_Timer.After(0.1, function()
                if frame and frame:IsShown() then
                    frame:Hide()
                end
            end)
        end
    end)
end

---------------------------------------------------------------------------
-- EF:Show() -- main entry point
-- EF:Show()               -> open pick stage (multi-select, all deselected)
-- EF:Show(name)           -> open pick stage with name pre-selected + var auto-resolve
-- EF:Show(name, string)   -> go directly to display stage (backward compat)
---------------------------------------------------------------------------

--- Show the export frame.
--- With no args: opens multi-select picker (all deselected).
--- With (name): opens picker with that sequence pre-selected and variable
--- dependencies auto-resolved via ResolveAndAutoSelectVars.
--- With (name, string): shows export display directly (backward compat).
--- @param sequenceName string|nil Sequence name for pre-select or display mode
--- @param exportString string|nil Pre-encoded export string (display mode only)
function EF:Show(sequenceName, exportString)
    if not frame then
        local C = GRIPEMS.UI.Colors

        frame = CreateFrame("Frame", "GRIPEMS_ExportFrame", UIParent, "BackdropTemplate")
        frame:SetSize(D().EXPORT_PICKER_WIDTH, D().EXPORT_PICKER_HEIGHT)
        frame:SetPoint("CENTER")
        frame:SetFrameStrata("DIALOG")
        frame:SetClampedToScreen(true)
        GRIPEMS.UI:ApplyBackdrop(frame, GRIPEMS.UI.Backdrops.panel, C.bgMain, C.border)
        frame:SetMovable(true)
        frame:Hide()

        -- ESC to close (intercept before MainFrame sees it)
        frame:EnableKeyboard(true)
        frame:SetPropagateKeyboardInput(true)
        frame:SetScript("OnKeyDown", function(self, key)
            if key == "ESCAPE" then
                self:SetPropagateKeyboardInput(false)
                self:Hide()
            else
                self:SetPropagateKeyboardInput(true)
            end
        end)

        -- Title bar (30px)
        local titleBar = CreateFrame("Frame", nil, frame, "BackdropTemplate")
        titleBar:SetHeight(30)
        titleBar:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, 0)
        titleBar:SetPoint("TOPRIGHT", frame, "TOPRIGHT", 0, 0)
        GRIPEMS.UI:ApplyBackdrop(titleBar, GRIPEMS.UI.Backdrops.panelNoBorder, C.bgDeep)

        titleBar:EnableMouse(true)
        titleBar:RegisterForDrag("LeftButton")
        titleBar:SetScript("OnDragStart", function()
            frame:StartMoving()
        end)
        titleBar:SetScript("OnDragStop", function()
            frame:StopMovingOrSizing()
        end)

        -- Title text
        local titleText = titleBar:CreateFontString(nil, "OVERLAY")
        GRIPEMS.UI:SetFont(titleText, 13, "OUTLINE")
        titleText:SetPoint("LEFT", titleBar, "LEFT", 12, 0)
        titleText:SetText("GRIP-EMS: Export")
        titleText:SetTextColor(C.gripGreen:GetRGBA())
        frame.titleText = titleText

        -- Close button (themed dark-UI X)
        local titleCloseBtn = CreateFrame("Button", nil, titleBar, "BackdropTemplate")
        titleCloseBtn:SetSize(24, 24)
        titleCloseBtn:SetPoint("TOPRIGHT", titleBar, "TOPRIGHT", -6, -3)
        GRIPEMS.UI:ApplyBackdrop(titleCloseBtn, GRIPEMS.UI.Backdrops.panel, C.bgButton, C.border)
        local closeLbl = titleCloseBtn:CreateFontString(nil, "OVERLAY")
        GRIPEMS.UI:SetFont(closeLbl, 14)
        closeLbl:SetPoint("CENTER", 0, 1)
        closeLbl:SetText("X")
        closeLbl:SetTextColor(C.textSecondary:GetRGBA())
        titleCloseBtn:SetScript("OnClick", function()
            frame:Hide()
        end)
        titleCloseBtn:SetScript("OnEnter", function(self)
            self:SetBackdropColor(C.accent:GetRGBA())
            self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
            closeLbl:SetTextColor(C.textPrimary:GetRGBA())
        end)
        titleCloseBtn:SetScript("OnLeave", function(self)
            self:SetBackdropColor(C.bgButton:GetRGBA())
            self:SetBackdropBorderColor(C.border:GetRGBA())
            closeLbl:SetTextColor(C.textSecondary:GetRGBA())
        end)

        local rawFrame = frame

        -- Create all stages
        CreatePickStage(rawFrame)
        CreateMetaStage(rawFrame)
        CreateDisplayStage(rawFrame)
    end

    if not pickStage or not displayStage or not metaStage then
        return
    end
    -- Detect call signature
    if sequenceName and exportString then
        -- Single-export backward compat: skip pick, show display directly
        pickStage:Hide()
        metaStage:Hide()
        local header = string.format(L["GEMS_EXPORT_FRAME_LABEL"], sequenceName)
        frame.titleText:SetText("GRIP-EMS: Export")
        frame:Show()
        ShowDisplayStage(header, exportString, false)
    elseif sequenceName then
        -- Pre-select mode: open picker with this sequence checked + var auto-resolve
        displayStage:Hide()
        metaStage:Hide()
        exportListData = nil
        frame.titleText:SetText("GRIP-EMS: Export")
        frame:Show()
        ShowPickStage(sequenceName)
    else
        -- Multi-select mode: show pick stage (all deselected)
        displayStage:Hide()
        metaStage:Hide()
        exportListData = nil
        frame.titleText:SetText("GRIP-EMS: Export")
        frame:Show()
        ShowPickStage()
    end
end

--- Hide the export frame if shown.
function EF:Hide()
    if frame then
        frame:Hide()
    end
end

--- Check if the export frame is currently shown.
--- @return boolean
function EF:IsShown()
    return frame and frame:IsShown()
end
