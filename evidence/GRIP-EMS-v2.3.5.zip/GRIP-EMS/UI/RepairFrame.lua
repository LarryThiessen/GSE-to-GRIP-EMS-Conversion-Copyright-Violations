-- GRIP-EMS: Repair Frame
-- Created: 2026-04-07
-- Updated: 2026-06-21
-- Patch: 12.0.7.68256 Midnight (Retail LIVE)
--
-- Popup UI for reviewing and fixing repair issues per-sequence.
--
-- Phase 2 #7: the title close, Undo, Fix All, and Done buttons are
-- registered as GRIPEMS.Focus targets on Show; context is popped on Hide.
-- OnKeyDown routes bare TAB/ENTER/SPACE/ESC through Focus above the
-- existing Ctrl+Z / Ctrl+Y undo/redo hotkeys.

local _, GRIPEMS = ...
GRIPEMS.RepairFrame = {}
local RF = GRIPEMS.RepairFrame
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS", true)

local RA, UI, DW, E, US
local function ResolveDeps()
    if RA then
        return
    end
    RA, UI = GRIPEMS.RepairAnalyzer, GRIPEMS.UI
    DW, E = GRIPEMS.DebugWindow, GRIPEMS.Engine
    US = GRIPEMS.UndoStack
end

local ROW_HEIGHT, HEADER_HEIGHT = 28, 24
local SEV_COLORS = {
    critical = { 1.0, 0.2, 0.2 },
    error = { 1.0, 0.3, 0.3 },
    warning = { 1.0, 0.8, 0.0 },
    info = { 0.6, 0.6, 0.7 },
}
local SEV_LABELS = { critical = "CRIT", error = "ERR", warning = "WARN", info = "INFO" }
local SEV_ORDER = { "critical", "error", "warning", "info" }
local CAT_DISPLAY = {
    SPELLS = "Spells",
    STRUCTURE = "Structure",
    LIMITS = "Limits",
    VARIABLES = "Variables",
    ACTIONS = "Actions",
    STUBS = "Stubs",
    CONFIG = "Config",
    LOCALE = "Locale",
    READINESS = "Readiness",
    POST_SUB = "Post-Sub",
    STATE_SYNC = "State Sync",
    CROSS_SEQ = "Cross-Seq",
    CONCURRENT = "Concurrent",
}

local ISSUE_HELP = {
    -- SPELLS
    ["Unknown spell"] = {
        desc = "This spell was not found in your spellbook or the game database. The macro step will fail silently at runtime.",
        manual = "Open the editor, select the step shown in the detail, and replace the spell name with a valid one. Check the suggestions in parentheses if available.",
    },
    ["Spell not learned"] = {
        desc = "This spell exists in the game but is not currently in your spellbook. It may belong to a different spec or level range.",
        manual = "Switch to the spec that has this spell, or replace it with one available to your current spec.",
    },
    ["Stale tooltip"] = {
        desc = "The tooltip cache for this spell may be outdated. This is usually harmless and updates automatically.",
    },
    ["Item in non-/use command"] = {
        desc = "An item name was found in a /cast command. Items require /use to activate.",
        manual = "Change /cast to /use for this item in the step editor.",
    },
    -- STRUCTURE
    ["Missing versions"] = {
        desc = "The sequence has no version data. This is critical corruption.",
        fixDesc = "Creates a new default version with Sequential step function and empty steps.",
    },
    ["Empty steps array"] = {
        desc = "This version has no macro steps. The sequence will do nothing when activated.",
        manual = "Open the editor and add spell steps to this version using the + Add button.",
    },
    ["Missing stepFunction"] = {
        desc = "The step function (Sequential, Priority, etc.) is nil. Steps will not advance.",
        fixDesc = "Sets the step function to Sequential (default).",
    },
    ["Nil keyPress"] = {
        desc = "The keyPress field is nil instead of empty. May cause errors in macro generation.",
        fixDesc = "Sets keyPress to an empty string.",
    },
    ["Nil keyRelease"] = {
        desc = "The keyRelease field is nil instead of empty. May cause errors in macro generation.",
        fixDesc = "Sets keyRelease to an empty string.",
    },
    ["Orphaned taggedSteps"] = {
        desc = "The locale tag cache has a different count than actual steps. Locale healing may produce wrong results.",
        manual = "Save the sequence to regenerate tags, or run /gems revalidate.",
    },
    ["Missing name"] = {
        desc = "The sequence name is nil or empty. It cannot be identified in the UI.",
        fixDesc = "Sets the name to the internal sequence key.",
    },
    ["Missing icon"] = {
        desc = "No icon is set for this sequence.",
        fixDesc = "Sets the icon to the default question mark.",
    },
    ["defaultVersion out of range"] = {
        desc = "The active version number points beyond the available versions.",
        fixDesc = "Clamps the version number to the valid range.",
    },
    ["Stale context override"] = {
        desc = "A context override references a version number that no longer exists.",
        fixDesc = "Removes the stale context override entry.",
    },
    ["Unknown context key"] = {
        desc = "A context override uses a key that is not a recognized context type.",
        manual = "Open the Context tab and remove the unrecognized entry.",
    },
    ["Invalid classID"] = {
        desc = "The stored class ID does not match any known WoW class.",
        manual = "Re-import the sequence on the correct character, or recreate it.",
    },
    -- LIMITS
    ["Step exceeds 255 chars"] = {
        desc = "This step exceeds WoW's 255-character macro limit. It will be silently truncated at runtime.",
        fixDesc = "Splits the step at semicolons into multiple shorter steps. If there are no semicolons, the fix cannot help.",
        manual = "Open the editor and manually break this step into shorter lines.",
    },
    ["kp/kr overflow"] = {
        desc = "The combined keyPress/keyRelease plus step content exceeds 255 characters.",
        manual = "Reduce the keyPress/keyRelease content or shorten the affected step.",
    },
    ["kp lines trimmed"] = {
        desc = "Not all Key Press lines fit the action-bar macro stub (255-char limit), so the extra lines are left off the bar icon. Your keybind still runs the full sequence -- this only affects clicking the macro directly on the action bar.",
        fixDesc = "Removes trailing keyPress lines until the remaining ones fit within the stub body limit.",
    },
    -- VARIABLES
    ["Non-existent variable"] = {
        desc = "A ~variable~ in this step references a variable name that does not exist.",
        manual = "Create the missing variable in the Variables tab, or remove the ~varname~ reference from the step.",
    },
    ["Parse error"] = {
        desc = "The variable expression has a Lua syntax error and cannot evaluate.",
        manual = "Open the Variables tab, find this variable, and fix the Lua expression.",
    },
    ["Locale risk"] = {
        desc = "This variable contains a spell name that may break when the game client runs in a different language.",
        manual = "Consider using spell IDs instead of localized spell names in the variable expression.",
    },
    ["Evaluates to empty"] = {
        desc = "This variable evaluates to an empty string, which means it contributes nothing to the macro.",
        manual = "Check the expression in the Variables tab. It may need a return value.",
    },
    ["Circular reference"] = {
        desc = "This variable references itself through a chain of other variables, causing an infinite loop.",
        manual = "Open the Variables tab and break the circular dependency. A references B references A is not allowed.",
    },
    -- ACTIONS
    ["Nesting exceeds max depth"] = {
        desc = "The action tree is nested deeper than the compiler allows.",
        manual = "Flatten the action hierarchy by removing deeply nested IF or LOOP nodes.",
    },
    ["EMBED target missing"] = {
        desc = "An EMBED action references a sequence name that does not exist.",
        manual = "Create the target sequence, or fix the EMBED node to reference an existing sequence name.",
    },
    ["Invalid PAUSE clicks"] = {
        desc = "A PAUSE action has an invalid click count.",
        manual = "Edit the PAUSE node and set the click count to 1 or higher.",
    },
    ["Invalid LOOP count"] = {
        desc = "A LOOP action has an invalid repeat count.",
        manual = "Edit the LOOP node and set the repeat count to 1 or higher.",
    },
    ["Empty action macro"] = {
        desc = "An action node has empty macro text. It will do nothing when reached.",
        manual = "Add spell content to the action node, or delete it.",
    },
    ["IF missing variable"] = {
        desc = "An IF action references a condition variable that does not exist.",
        manual = "Create the variable, or change the IF condition to use an existing one.",
    },
    ["Complex IF false discarded"] = {
        desc = "The IF false branch was discarded. Runtime branching is not yet supported.",
        manual = "Restructure using separate sequences. This is a known engine limitation.",
    },
    ["Action tree error"] = {
        desc = "The action compiler encountered an error processing the action tree.",
        manual = "Check the action tree structure. See the detail for the specific error.",
    },
    -- STUBS
    ["Stub body out of sync"] = {
        desc = "The macro on your action bar does not match the sequence's current keyPress/keyRelease content.",
        fixDesc = "Deletes and recreates the macro stub with the correct, up-to-date content.",
    },
    ["No macro stub"] = {
        desc = "No macro stub exists for this sequence. It cannot be placed on an action bar without one.",
        manual = "Assign a keybind in the Keybind tab. The stub is created automatically when a keybind is set.",
    },
    -- CONFIG
    ["resetTimer out of range"] = {
        desc = "The reset timer is outside the valid range (0 to 3600 seconds).",
        fixDesc = "Clamps the value to the valid 0-3600 range.",
    },
    ["Invalid reset modifier"] = {
        desc = "A per-sequence reset modifier has an unrecognized key name.",
        manual = "Open the sequence settings and remove the invalid modifier.",
    },
    ["resetOnSpec on spec-locked"] = {
        desc = "Reset on Spec Change is enabled but the sequence is locked to one spec. It will never trigger.",
    },
    -- LOCALE
    ["Locale mismatch"] = {
        desc = "This version was saved in a different game language. Spell names may be wrong for your current locale.",
        manual = "Run /gems revalidate to re-tag all spells for your current locale.",
    },
    ["taggedSteps count mismatch"] = {
        desc = "The locale tag cache has a different number of entries than the actual step count.",
        manual = "Save the sequence to regenerate locale tags.",
    },
    ["Missing taggedSteps"] = {
        desc = "No locale tags exist for this version. Locale healing cannot protect these spells.",
        manual = "Save the sequence to generate initial locale tags.",
    },
    -- READINESS
    ["No keybind and no stub"] = {
        desc = "This sequence has no keybind and no macro stub. It cannot fire when you press a key.",
        fixDesc = "Creates a macro stub so the sequence can be dragged to an action bar.",
    },
    ["Keybind on different spec"] = {
        desc = "The keybind for this sequence is assigned to a different specialization.",
        manual = "Switch specs, or reassign the keybind in the Keybind tab for your current spec.",
    },
    ["All steps empty"] = {
        desc = "Every step in this version is blank. The sequence will fire but do nothing.",
        manual = "Open the editor and add spell content to the steps.",
    },
    ["Unedited template"] = {
        desc = "This sequence was just created and has never been edited. It contains only the default empty version.",
        manual = "Open the editor and add your rotation steps.",
    },
    ["Click rate is 0"] = {
        desc = "The global click rate is set to 0ms. No sequences will fire at all.",
        fixDesc = "Resets the click rate to the default 250ms.",
    },
    ["Class mismatch"] = {
        desc = "This sequence was created for a different class than your current character.",
        manual = "Import it on the correct class character, or accept that some spells may not work.",
    },
    ["Content in field not steps"] = {
        desc = "There are /cast commands in keyPress or keyRelease but the steps array is empty. The sequence structure may be inverted.",
        fixDesc = "Moves the content from the keyPress/keyRelease field into step 1.",
    },
    -- POST-SUB
    ["Post-sub overflow"] = {
        desc = "After replacing ~variables~ with their values, this step exceeds 255 characters.",
        manual = "Shorten the variable values, or split the step so each part stays under 255 chars after substitution.",
    },
    ["Post-sub locale risk"] = {
        desc = "A variable in this step resolves to a localized spell name that may break on non-English clients.",
        manual = "Use spell IDs in the variable expression instead of localized spell names.",
    },
    -- STATE_SYNC (suppressed from RepairFrame via opts, but included for completeness)
    ["Open in editor"] = {
        desc = "This sequence is currently open in the main editor.",
    },
    ["Popup editor open"] = {
        desc = "This sequence is open in a popup editor window.",
    },
    ["Active in TrackerHUD"] = {
        desc = "The TrackerHUD is currently tracking this sequence.",
    },
    ["UndoStack may be stale"] = {
        desc = "Editor undo history may be invalidated by destructive repairs.",
    },
    ["VS cache active"] = {
        desc = "The variable cache is active. Variable-related fixes may require a cache refresh.",
    },
    -- CONCURRENT (suppressed from RepairFrame via opts, but included for completeness)
    ["In combat lockdown"] = {
        desc = "You are in combat. Stub and keybind fixes will be queued until combat ends.",
    },
    ["RepairFrame already open"] = {
        desc = "Another repair session is already active.",
    },
    ["Queued OOC repairs pending"] = {
        desc = "Previous repair fixes are queued and waiting for combat to end.",
    },
}

-- State
RF.frame = nil
RF._seqData = nil
RF._seqName = nil
RF._issues = nil
RF._undoStack = nil
RF._collapsed = {}
RF._fixStatus = {}
RF._sevFilter = { critical = true, error = true, warning = true, info = true }
RF._batchMode = false
RF._batchIssues = nil

local scrollBox, dataProvider
local summaryLabel, sevBreakdownLabel, combatBanner, sevFilterBtns

local function DeepCopy(t)
    if type(t) ~= "table" then
        return t
    end
    local c = {}
    for k, v in pairs(t) do
        c[DeepCopy(k)] = DeepCopy(v)
    end
    return setmetatable(c, getmetatable(t))
end

local function SevColor(sev)
    return unpack(SEV_COLORS[sev] or SEV_COLORS.info)
end

local function UpdateSummary(issues)
    local C = UI.Colors
    local fixable = 0
    local counts = { critical = 0, error = 0, warning = 0, info = 0 }
    for _, iss in ipairs(issues) do
        counts[iss.severity] = (counts[iss.severity] or 0) + 1
        if iss.fixable then
            fixable = fixable + 1
        end
    end
    summaryLabel:SetText(string.format("Found %d issues (%d auto-fixable)", #issues, fixable))
    summaryLabel:SetTextColor(C.textPrimary:GetRGBA())
    local parts = {}
    for _, sev in ipairs(SEV_ORDER) do
        if counts[sev] > 0 then
            local r, g, b = SevColor(sev)
            parts[#parts + 1] = string.format("|cFF%02x%02x%02x%d %s|r", r * 255, g * 255, b * 255, counts[sev], sev)
        end
    end
    sevBreakdownLabel:SetText(table.concat(parts, ", "))
end

local function BuildFlatData(issues)
    local catOrder, catGroups = {}, {}
    for _, iss in ipairs(issues) do
        if RF._sevFilter[iss.severity] then
            if not catGroups[iss.category] then
                catGroups[iss.category] = {}
                catOrder[#catOrder + 1] = iss.category
            end
            catGroups[iss.category][#catGroups[iss.category] + 1] = iss
        end
    end
    local flat = {}
    for _, cat in ipairs(catOrder) do
        local grp = catGroups[cat]
        flat[#flat + 1] = { type = "header", category = cat, count = #grp }
        if not RF._collapsed[cat] then
            for _, iss in ipairs(grp) do
                flat[#flat + 1] = { type = "issue", issue = iss }
            end
        end
    end
    return flat
end

local function UpdateFixAllState()
    local btn = RF.frame and RF.frame._fixAllBtn
    if not btn then
        return
    end
    if RF._batchMode then
        btn:Hide()
        return
    end
    btn:Show()
    local count = 0
    for _, issue in ipairs(RF._issues or {}) do
        if issue.fixable and issue.fixFn and not RF._fixStatus[issue.id] then
            count = count + 1
        end
    end
    if count > 0 then
        btn:Enable()
        btn:SetAlpha(1.0)
        btn.label:SetText(string.format("%s (%d)", L["GEMS_UI_REPAIR_ALL"], count))
    else
        btn:Disable()
        btn:SetAlpha(0.35)
        btn.label:SetText(L["GEMS_UI_REPAIR_ALL"])
    end
end

local function RefreshDataProvider()
    if not scrollBox then
        return
    end
    local flat
    if RF._batchMode and RF._batchIssues then
        flat = {}
        local combined = {}
        for seqName, issues in pairs(RF._batchIssues) do
            if #issues > 0 then
                flat[#flat + 1] = { type = "seqHeader", seqName = seqName, count = #issues }
                for _, row in ipairs(BuildFlatData(issues)) do
                    flat[#flat + 1] = row
                end
                for _, iss in ipairs(issues) do
                    combined[#combined + 1] = iss
                end
            end
        end
        UpdateSummary(combined)
    elseif RF._issues then
        flat = BuildFlatData(RF._issues)
        UpdateSummary(RF._issues)
    else
        flat = {}
    end
    local dp = CreateDataProvider()
    for _, row in ipairs(flat) do
        dp:Insert(row)
    end
    scrollBox:SetDataProvider(dp, ScrollBoxConstants.RetainScrollPosition)
    dataProvider = dp
    UpdateFixAllState()
end

local function OnFixClick(issue)
    ResolveDeps()
    if not issue or not issue.fixable or not issue.fixFn or not RF._seqData then
        return
    end
    if RF._undoStack then
        local snap = DeepCopy(RF._seqData)
        local sd = RF._seqData
        RF._undoStack:Push(function()
            for k in pairs(sd) do
                sd[k] = nil
            end
            for k, v in pairs(snap) do
                sd[k] = v
            end
        end, function()
            issue.fixFn(sd)
        end, "Repair: " .. (issue.title or issue.id))
    end
    local ok, err = pcall(issue.fixFn, RF._seqData)
    if ok then
        RF._fixStatus[issue.id] = "fixed"
        if DW then
            DW:AddMessage("[Repair] " .. (RF._seqName or "?") .. ": Fixed - " .. (issue.title or issue.id))
        end
    else
        RF._fixStatus[issue.id] = "failed"
        if DW then
            DW:AddMessage("[Repair] FAILED - " .. tostring(err))
        end
    end
    if RA and RF._seqData and RF._seqName then
        RF._issues = RA:Analyze(RF._seqData, RF._seqName, { surface = "repair" })
    end
    RefreshDataProvider()
end

local function OnFixAllClick()
    ResolveDeps()
    if RF._batchMode then
        return
    end
    if not RF._seqData then
        return
    end
    if RF._undoStack then
        local snap = DeepCopy(RF._seqData)
        local sd = RF._seqData
        RF._undoStack:Push(function()
            for k in pairs(sd) do
                sd[k] = nil
            end
            for k, v in pairs(snap) do
                sd[k] = v
            end
        end, nil, "Repair: Fix All")
    end
    for _, issue in ipairs(RF._issues or {}) do
        if issue.fixable and issue.fixFn and not RF._fixStatus[issue.id] then
            local ok, err = pcall(issue.fixFn, RF._seqData)
            if ok then
                RF._fixStatus[issue.id] = "fixed"
                if DW then
                    DW:AddMessage("[Repair] " .. (RF._seqName or "?") .. ": Fixed - " .. (issue.title or issue.id))
                end
            else
                RF._fixStatus[issue.id] = "failed"
                if DW then
                    DW:AddMessage("[Repair] FAILED - " .. tostring(err))
                end
            end
        end
    end
    if RA and RF._seqData and RF._seqName then
        RF._issues = RA:Analyze(RF._seqData, RF._seqName, { surface = "repair" })
    end
    RefreshDataProvider()
end

-- Row initializer (ScrollBox reuses frames)
local function InitRow(button, data)
    local C = UI.Colors
    if not button._rfInit then
        button._rfInit = true
        local bg = button:CreateTexture(nil, "BACKGROUND")
        bg:SetAllPoints()
        bg:SetColorTexture(0, 0, 0, 0)
        button._bg = bg
        button._sevLabel = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(button._sevLabel, 10, "OUTLINE")
        button._sevLabel:SetPoint("LEFT", 8, 0)
        button._sevLabel:SetWidth(36)
        button._descText = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(button._descText, 11)
        button._descText:SetPoint("LEFT", button._sevLabel, "RIGHT", 6, 0)
        button._descText:SetPoint("RIGHT", button, "RIGHT", -120, 0)
        button._descText:SetWordWrap(false)
        button._statusText = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(button._statusText, 10)
        button._statusText:SetPoint("RIGHT", button, "RIGHT", -60, 0)
        button._statusText:SetWidth(60)
        button._statusText:SetJustifyH("CENTER")
        button._fixBtn = UI:CreateButton(button, "Fix", 48, 20)
        button._fixBtn:SetPoint("RIGHT", button, "RIGHT", -6, 0)
        button._headerText = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(button._headerText, 11, "OUTLINE")
        button._headerText:SetPoint("LEFT", 8, 0)
        button._countBadge = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(button._countBadge, 10)
        button._countBadge:SetPoint("RIGHT", -8, 0)
        button._seqHeaderText = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(button._seqHeaderText, 12, "OUTLINE")
        button._seqHeaderText:SetPoint("LEFT", 4, 0)
    end

    -- Reset
    for _, k in ipairs({
        "_sevLabel",
        "_descText",
        "_statusText",
        "_fixBtn",
        "_headerText",
        "_countBadge",
        "_seqHeaderText",
    }) do
        button[k]:Hide()
    end
    button._bg:SetColorTexture(0, 0, 0, 0)
    button:SetScript("OnClick", nil)
    button:SetScript("OnEnter", nil)
    button:SetScript("OnLeave", nil)

    if data.type == "seqHeader" then
        button:SetHeight(HEADER_HEIGHT + 4)
        button._seqHeaderText:Show()
        button._seqHeaderText:SetText(data.seqName .. " (" .. data.count .. " issues)")
        button._seqHeaderText:SetTextColor(C.gripGreen:GetRGBA())
        button._bg:SetColorTexture(C.bgDeep:GetRGBA())
        return
    end

    if data.type == "header" then
        button:SetHeight(HEADER_HEIGHT)
        button._headerText:Show()
        local arrow = RF._collapsed[data.category] and "> " or "v "
        button._headerText:SetText(arrow .. (CAT_DISPLAY[data.category] or data.category))
        button._headerText:SetTextColor(C.textPrimary:GetRGBA())
        button._countBadge:Show()
        button._countBadge:SetText(tostring(data.count))
        button._countBadge:SetTextColor(C.textSecondary:GetRGBA())
        button._bg:SetColorTexture(C.bgDeep:GetRGBA())
        button:SetScript("OnClick", function()
            RF._collapsed[data.category] = not RF._collapsed[data.category]
            RefreshDataProvider()
        end)
        button:SetScript("OnEnter", function()
            button._bg:SetColorTexture(C.bgRowHover:GetRGBA())
        end)
        button:SetScript("OnLeave", function()
            button._bg:SetColorTexture(C.bgDeep:GetRGBA())
        end)
        return
    end

    if data.type ~= "issue" then
        return
    end
    local issue = data.issue
    button:SetHeight(ROW_HEIGHT)
    button._sevLabel:Show()
    button._sevLabel:SetText(SEV_LABELS[issue.severity] or "?")
    button._sevLabel:SetTextColor(SevColor(issue.severity))
    button._descText:Show()
    local desc = issue.title or ""
    if issue.detail and issue.detail ~= "" then
        desc = desc .. " - " .. issue.detail
    end
    button._descText:SetText(desc)
    button._descText:SetTextColor(C.textPrimary:GetRGBA())

    local status = RF._fixStatus[issue.id]
    if status == "fixed" then
        button._statusText:Show()
        button._statusText:SetText("[Fixed]")
        button._statusText:SetTextColor(C.textSuccess:GetRGBA())
    elseif status == "failed" then
        button._statusText:Show()
        button._statusText:SetText("[Failed]")
        button._statusText:SetTextColor(C.textError:GetRGBA())
    elseif status == "queued" then
        button._statusText:Show()
        button._statusText:SetText("[Queued]")
        button._statusText:SetTextColor(C.textWarning:GetRGBA())
    end

    if issue.fixable and issue.fixFn and not status then
        button._fixBtn:Show()
        button._fixBtn:Enable()
        button._fixBtn:SetAlpha(1.0)
        button._fixBtn.label:SetText("Fix")
        UI:ApplyBackdrop(button._fixBtn, UI.Backdrops.panel, C.bgSave, C.border)
        button._fixBtn:SetScript("OnClick", function()
            OnFixClick(issue)
        end)
        button._fixBtn:SetScript("OnEnter", function(self)
            self:SetBackdropColor(C.bgSaveHover:GetRGBA())
            self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
            local help = ISSUE_HELP[issue.title]
            if not help and issue.title and issue.title:find("^Content in ") then
                help = ISSUE_HELP["Content in field not steps"]
            end
            local fd = help and help.fixDesc
            if fd then
                UI:ShowTooltip(self, "Fix: " .. (issue.title or ""), fd)
            end
        end)
        button._fixBtn:SetScript("OnLeave", function(self)
            self:SetBackdropColor(C.bgSave:GetRGBA())
            self:SetBackdropBorderColor(C.border:GetRGBA())
            UI:HideTooltip()
        end)
    elseif not status then
        button._fixBtn:Show()
        button._fixBtn:Disable()
        button._fixBtn:SetAlpha(0.35)
        button._fixBtn.label:SetText("Fix")
        button._fixBtn:SetScript("OnEnter", function(self)
            local help = ISSUE_HELP[issue.title]
            if not help and issue.title and issue.title:find("^Content in ") then
                help = ISSUE_HELP["Content in field not steps"]
            end
            local m = help and help.manual
            if m then
                UI:ShowTooltip(self, issue.title or "", m, "Manual fix required")
            end
        end)
        button._fixBtn:SetScript("OnLeave", function()
            UI:HideTooltip()
        end)
    end

    button:SetScript("OnEnter", function()
        button._bg:SetColorTexture(C.bgRowHover:GetRGBA())
        local help = ISSUE_HELP[issue.title]
        if not help and issue.title and issue.title:find("^Content in ") then
            help = ISSUE_HELP["Content in field not steps"]
        end
        local tipText = help and help.desc or ""
        if issue.detail and issue.detail ~= "" then
            tipText = tipText ~= "" and (tipText .. "\n\n" .. issue.detail) or issue.detail
        end
        if tipText ~= "" then
            UI:ShowTooltip(button, issue.title or issue.id, tipText)
        end
    end)
    button:SetScript("OnLeave", function()
        button._bg:SetColorTexture(0, 0, 0, 0)
        UI:HideTooltip()
    end)
end

-- Frame creation (lazy, reused)
local function CreateRepairFrame()
    if RF.frame then
        return
    end
    ResolveDeps()
    local C = UI.Colors

    local f = UI:ReclaimFrame("GRIPEMSRepairFrame", "Frame", UIParent, "BackdropTemplate")
    f:SetSize(650, 500)
    f:SetPoint("CENTER")
    f:SetFrameStrata("DIALOG")
    f:SetClampedToScreen(true)
    UI:ApplyBackdrop(f, UI.Backdrops.panel, C.bgMain, C.border)
    if GRIPEMS.UI and GRIPEMS.UI.RegisterPanelFrame then
        GRIPEMS.UI:RegisterPanelFrame(f, "panel", "panel.repair")
    end
    f:SetMovable(true)
    f:Hide()
    RF.frame = f
    tinsert(UISpecialFrames, "GRIPEMSRepairFrame")

    f:EnableKeyboard(true)
    pcall(f.SetPropagateKeyboardInput, f, true)
    f:SetScript("OnKeyDown", function(self, key)
        if InCombatLockdown() then
            return
        end
        -- Suspenders layer: independent of the Focus flag, query WoW
        -- directly for any focused EditBox. If found, propagate the key
        -- and let the EditBox handle it.
        if GetCurrentKeyBoardFocus and GetCurrentKeyBoardFocus() then
            pcall(self.SetPropagateKeyboardInput, self, true)
            return
        end
        local Focus = GRIPEMS.Focus
        if Focus and Focus:IsEditBoxFocused() then
            pcall(self.SetPropagateKeyboardInput, self, true)
            return
        end
        if key == "Z" and IsControlKeyDown() and not IsShiftKeyDown() then
            if RF._undoStack and RF._undoStack:CanUndo() then
                RF._undoStack:Undo()
                if RA and RF._seqData and RF._seqName then
                    RF._issues = RA:Analyze(RF._seqData, RF._seqName, { surface = "repair" })
                end
                RefreshDataProvider()
            end
            pcall(self.SetPropagateKeyboardInput, self, false)
            return
        end
        if (key == "Y" and IsControlKeyDown()) or (key == "Z" and IsControlKeyDown() and IsShiftKeyDown()) then
            if RF._undoStack and RF._undoStack:CanRedo() then
                RF._undoStack:Redo()
                if RA and RF._seqData and RF._seqName then
                    RF._issues = RA:Analyze(RF._seqData, RF._seqName, { surface = "repair" })
                end
                RefreshDataProvider()
            end
            pcall(self.SetPropagateKeyboardInput, self, false)
            return
        end
        if Focus and not IsControlKeyDown() and not IsAltKeyDown() then
            if key == "TAB" then
                Focus:Cycle(IsShiftKeyDown() and -1 or 1)
                pcall(self.SetPropagateKeyboardInput, self, false)
                return
            elseif key == "ENTER" or key == "SPACE" then
                Focus:Activate()
                pcall(self.SetPropagateKeyboardInput, self, false)
                return
            elseif key == "ESCAPE" then
                RF:Hide()
                pcall(self.SetPropagateKeyboardInput, self, false)
                return
            end
        end
        pcall(self.SetPropagateKeyboardInput, self, true)
    end)

    -- Title bar
    local tb = CreateFrame("Frame", nil, f, "BackdropTemplate")
    tb:SetHeight(30)
    tb:SetPoint("TOPLEFT")
    tb:SetPoint("TOPRIGHT")
    UI:ApplyBackdrop(tb, UI.Backdrops.panelNoBorder, C.bgDeep)
    tb:EnableMouse(true)
    tb:RegisterForDrag("LeftButton")
    tb:SetScript("OnDragStart", function()
        f:StartMoving()
    end)
    tb:SetScript("OnDragStop", function()
        f:StopMovingOrSizing()
    end)

    local tt = tb:CreateFontString(nil, "OVERLAY")
    UI:SetFont(tt, 13, "OUTLINE")
    tt:SetPoint("LEFT", 12, 0)
    tt:SetText("Repair")
    tt:SetTextColor(C.gripGreen:GetRGBA())
    f._titleText = tt

    local xb = CreateFrame("Button", nil, tb, "BackdropTemplate")
    xb:SetSize(24, 24)
    UI:RegisterLargeTarget(xb)
    xb:SetPoint("TOPRIGHT", -6, -3)
    UI:ApplyBackdrop(xb, UI.Backdrops.panel, C.bgButton, C.border)
    local xl = xb:CreateFontString(nil, "OVERLAY")
    UI:SetFont(xl, 14)
    xl:SetPoint("CENTER", 0, 1)
    xl:SetText("X")
    xl:SetTextColor(C.textSecondary:GetRGBA())
    xb:SetScript("OnClick", function()
        RF:Hide()
    end)
    xb:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.accent:GetRGBA())
        xl:SetTextColor(C.textPrimary:GetRGBA())
    end)
    xb:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgButton:GetRGBA())
        xl:SetTextColor(C.textSecondary:GetRGBA())
    end)
    f._titleCloseBtn = xb

    summaryLabel = f:CreateFontString(nil, "OVERLAY")
    UI:SetFont(summaryLabel, 12)
    summaryLabel:SetPoint("TOPLEFT", 12, -36)
    sevBreakdownLabel = f:CreateFontString(nil, "OVERLAY")
    UI:SetFont(sevBreakdownLabel, 10)
    sevBreakdownLabel:SetPoint("TOPLEFT", summaryLabel, "BOTTOMLEFT", 0, -2)

    combatBanner = f:CreateFontString(nil, "OVERLAY")
    UI:SetFont(combatBanner, 10)
    combatBanner:SetPoint("TOPRIGHT", f, "TOPRIGHT", -12, -36)
    combatBanner:SetText("In combat - some repairs queued")
    combatBanner:SetTextColor(C.textWarning:GetRGBA())
    combatBanner:Hide()

    -- Severity filter buttons
    sevFilterBtns = {}
    local x = 8
    for _, sev in ipairs(SEV_ORDER) do
        local btn = UI:CreateButton(f, SEV_LABELS[sev], 60, 20)
        btn:SetPoint("TOPLEFT", f, "TOPLEFT", x, -66)
        local function Refresh()
            if RF._sevFilter[sev] then
                btn.label:SetTextColor(SevColor(sev))
                UI:ApplyBackdrop(btn, UI.Backdrops.panel, C.bgButton, C.border)
            else
                btn.label:SetTextColor(C.textMuted:GetRGBA())
                UI:ApplyBackdrop(btn, UI.Backdrops.panel, C.bgDeep, C.border)
            end
        end
        btn:SetScript("OnClick", function()
            RF._sevFilter[sev] = not RF._sevFilter[sev]
            Refresh()
            RefreshDataProvider()
        end)
        btn:SetScript("OnEnter", function(self)
            self:SetBackdropColor(C.bgRowHover:GetRGBA())
        end)
        btn:SetScript("OnLeave", function()
            Refresh()
        end)
        Refresh()
        sevFilterBtns[sev] = btn
        x = x + 66
    end

    local cancelBtn = UI:CreateButton(f, "Done", 80, 26)
    cancelBtn:SetPoint("BOTTOMRIGHT", -10, 10)
    cancelBtn:SetScript("OnClick", function()
        RF:Hide()
    end)
    f._cancelBtn = cancelBtn

    local undoBtn = UI:CreateButton(f, "Undo", 80, 26)
    undoBtn:SetPoint("RIGHT", cancelBtn, "LEFT", -8, 0)
    undoBtn:SetScript("OnClick", function()
        if RF._undoStack and RF._undoStack:CanUndo() then
            RF._undoStack:Undo()
            if RA and RF._seqData and RF._seqName then
                RF._issues = RA:Analyze(RF._seqData, RF._seqName, { surface = "repair" })
            end
            RefreshDataProvider()
        end
    end)
    f._undoBtn = undoBtn

    local fixAllBtn = UI:CreateButton(f, L["GEMS_UI_REPAIR_ALL"], 90, 26)
    fixAllBtn:SetPoint("RIGHT", undoBtn, "LEFT", -8, 0)
    UI:ApplyBackdrop(fixAllBtn, UI.Backdrops.panel, C.bgSave, C.border)
    fixAllBtn:SetScript("OnClick", function()
        OnFixAllClick()
    end)
    fixAllBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.bgSaveHover:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
    end)
    fixAllBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgSave:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
    end)
    f._fixAllBtn = fixAllBtn

    scrollBox = CreateFrame("Frame", nil, f, "WowScrollBoxList")
    scrollBox:SetPoint("TOPLEFT", 8, -92)
    scrollBox:SetPoint("BOTTOMRIGHT", cancelBtn, "TOPRIGHT", -18, 6)
    local sb = CreateFrame("EventFrame", nil, f, "MinimalScrollBar")
    sb:SetPoint("TOPLEFT", scrollBox, "TOPRIGHT", 2, 0)
    sb:SetPoint("BOTTOMLEFT", scrollBox, "BOTTOMRIGHT", 2, 0)
    local sv = CreateScrollBoxListLinearView()
    sv:SetElementExtent(ROW_HEIGHT)
    sv:SetElementInitializer("Button", function(btn, d)
        InitRow(btn, d)
    end)
    ScrollUtil.InitScrollBoxListWithScrollBar(scrollBox, sb, sv)
    dataProvider = CreateDataProvider()
    scrollBox:SetDataProvider(dataProvider)

    -- Phase 2 #7: Focus context lifecycle for keyboard nav.
    f:HookScript("OnShow", function(self)
        local Focus = GRIPEMS.Focus
        if not Focus then
            return
        end
        Focus:PushContext("RepairFrame", {
            self._fixAllBtn,
            self._undoBtn,
            self._cancelBtn,
            self._titleCloseBtn,
        })
    end)
    f:HookScript("OnHide", function()
        local Focus = GRIPEMS.Focus
        if not Focus then
            return
        end
        Focus:PopContext("RepairFrame")
    end)
end

local function ResetFilters()
    RF._fixStatus = {}
    RF._collapsed = {}
    RF._sevFilter = { critical = true, error = true, warning = true, info = true }
    if sevFilterBtns then
        for _, sev in ipairs(SEV_ORDER) do
            local btn = sevFilterBtns[sev]
            if btn then
                btn.label:SetTextColor(SevColor(sev))
                UI:ApplyBackdrop(btn, UI.Backdrops.panel, UI.Colors.bgButton, UI.Colors.border)
            end
        end
    end
    if InCombatLockdown() then
        combatBanner:Show()
    else
        combatBanner:Hide()
    end
end

-- Public API
function RF:Show(seqData, issues, seqName)
    ResolveDeps()
    if RF:IsShown() then
        return
    end
    CreateRepairFrame()
    ResetFilters()
    RF._seqData = seqData
    RF._seqName = seqName or ""
    RF._issues = issues or {}
    RF._batchMode = false
    RF._batchIssues = nil
    RF._undoStack = US and US:New() or nil
    RF.frame._titleText:SetText("Repair: " .. (seqName or ""))
    RefreshDataProvider()
    RF.frame:Show()
end

function RF:ShowBatch(allIssues)
    ResolveDeps()
    if RF:IsShown() then
        return
    end
    CreateRepairFrame()
    ResetFilters()
    RF._seqData = nil
    RF._seqName = nil
    RF._issues = nil
    RF._batchMode = true
    RF._batchIssues = allIssues or {}
    -- Batch mode: no undo (no single seqData to snapshot)
    RF._undoStack = nil
    RF.frame._titleText:SetText("Repair All Sequences")
    RefreshDataProvider()
    RF.frame:Show()
end

function RF:IsShown()
    return RF.frame and RF.frame:IsShown() or false
end

function RF:Hide()
    if not RF.frame then
        return
    end
    if not RF._batchMode and RF._seqData and RF._seqName then
        local fixCount, manualCount = 0, 0
        for _, s in pairs(RF._fixStatus) do
            if s == "fixed" then
                fixCount = fixCount + 1
            end
        end
        if RF._issues then
            for _, iss in ipairs(RF._issues) do
                if not RF._fixStatus[iss.id] and iss.fixable then
                    manualCount = manualCount + 1
                end
            end
        end
        if fixCount > 0 and E and E.UpdateSequenceData then
            E:UpdateSequenceData(RF._seqName, RF._seqData)
            local msg = string.format("[Repair] Fixed %d issues.", fixCount)
            if manualCount > 0 then
                msg = msg .. string.format(" %d require manual attention.", manualCount)
            end
            print(msg)
            if DW then
                DW:AddMessage(msg)
            end
        end
    end
    RF.frame:Hide()
    RF._seqData = nil
    RF._seqName = nil
    RF._issues = nil
    RF._batchMode = false
    RF._batchIssues = nil
    RF._fixStatus = {}
    RF._undoStack = nil
end
