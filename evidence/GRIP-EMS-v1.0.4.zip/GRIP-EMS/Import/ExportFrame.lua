-- GRIP-EMS: Export Frame (Two-Stage)
-- Stage 1: Multi-select picker with ScrollBox for choosing sequences/variables
-- Stage 2: Read-only display of encoded export string with Ctrl+C auto-close

local ADDON_NAME, GRIPEMS = ...
local L = LibStub("AceLocale-3.0"):GetLocale("GRIP-EMS")
local AceGUI = LibStub("AceGUI-3.0")

-- Upvalue accessor for Defaults
local function D() return GRIPEMS.Defaults end

GRIPEMS.ExportFrame = {}
local EF = GRIPEMS.ExportFrame

local frame = nil           -- lazy-created AceGUI Frame, reused
local pickStage = nil        -- native Frame for stage 1 (multi-select picker)
local displayStage = nil     -- native Frame for stage 2 (export string display)
local exportListData = nil   -- result from GE.BuildExportList()

-- Pick stage sub-references
local pickScrollBox, pickScrollBar, pickScrollView, pickDataProvider
local pickHeaderLabel, pickSummaryLine, pickExportBtn, pickWarningLabel

---------------------------------------------------------------------------
-- Icon resolution helper (same as ImportFrame)
---------------------------------------------------------------------------

--- Resolve an icon value to a usable texture path or ID.
--- @param icon any Icon from export entry (number, string, or nil)
--- @return any Resolved texture (number ID or string path)
local function ResolveIcon(icon)
    if type(icon) == "number" then
        return icon
    end
    if type(icon) == "string" then
        if icon:find("^Interface\\") then
            return icon
        end
        if icon ~= "" then
            return "Interface\\Icons\\" .. icon
        end
    end
    return "Interface\\Icons\\" .. D().QUESTION_MARK_ICON
end

---------------------------------------------------------------------------
-- UpdateExportCount: refresh the Export Selected button label + state
---------------------------------------------------------------------------

local function UpdateExportCount()
    if not pickDataProvider or not pickExportBtn then return end

    local seqCount = 0
    local varCount = 0
    for _, entry in pickDataProvider:EnumerateEntireRange() do
        if entry.type == "sequence" and entry.entry and entry.entry.selected then
            seqCount = seqCount + 1
        elseif entry.type == "variable" and entry.entry
            and entry.entry.selected then
            varCount = varCount + 1
        end
    end

    local total = seqCount + varCount
    pickExportBtn.label:SetText(string.format(
        L["GEMS_EXPORT_PICK_EXPORT_SELECTED"], total))
    if seqCount == 0 then
        pickExportBtn:Disable()
        pickExportBtn:SetAlpha(0.5)
    else
        pickExportBtn:Enable()
        pickExportBtn:SetAlpha(1.0)
    end
end

---------------------------------------------------------------------------
-- Variable auto-selection: resolve deps for currently selected sequences
---------------------------------------------------------------------------

local function ResolveAndAutoSelectVars()
    if not exportListData then return end

    local GE = GRIPEMS.GRIPExport

    -- Collect selected sequence names
    local selectedNames = {}
    for _, seq in ipairs(exportListData.sequences) do
        if seq.selected then
            selectedNames[#selectedNames + 1] = seq.name
        end
    end

    -- Resolve needed variable names
    local neededVars = GE.ResolveVariableDeps(selectedNames)

    -- Update variable entries
    for _, varEntry in ipairs(exportListData.variables) do
        local needed = neededVars[varEntry.name] or false
        if needed then
            -- Auto-select if not manually deselected
            if not varEntry.manualDeselect then
                varEntry.autoSelected = true
                varEntry.selected = true
            end
        else
            -- Remove auto-selection (keep manual selection)
            varEntry.autoSelected = false
            if not varEntry.manualSelect then
                varEntry.selected = false
            end
        end
    end

    -- Update embedded dep warnings
    local warnings = GE.DetectMissingEmbeddedDeps(selectedNames)
    if pickWarningLabel then
        if #warnings > 0 then
            -- Show first warning, truncated
            local warnText = warnings[1]
            if #warnings > 1 then
                warnText = warnText .. " (+" .. (#warnings - 1) .. " more)"
            end
            pickWarningLabel:SetText(warnText)
            pickWarningLabel:SetTextColor(
                GRIPEMS.UI.Colors.textWarning:GetRGBA())
        else
            pickWarningLabel:SetText("")
        end
    end

    -- Refresh ScrollBox display
    if pickScrollBox then
        pickScrollBox:ForEachFrame(function(btn)
            if btn._exportRefresh then
                btn._exportRefresh()
            end
        end)
    end

    UpdateExportCount()
end

---------------------------------------------------------------------------
-- Row initializer for pick stage ScrollBox
---------------------------------------------------------------------------

--- Initialize or refresh a pick-stage row.
--- @param button Button The reusable row frame
--- @param data table Row data with type, entry fields
local function InitExportRow(button, data)
    local UI = GRIPEMS.UI
    local C = UI.Colors
    local rowHeight = D().EXPORT_PICKER_ROW_HEIGHT

    button:SetHeight(rowHeight)

    -- Ensure sub-elements created once
    if not button._pickInit then
        button._pickInit = true

        -- Background
        local bg = button:CreateTexture(nil, "BACKGROUND")
        bg:SetAllPoints()
        bg:SetColorTexture(0, 0, 0, 0)
        button._bg = bg

        -- CheckButton
        local cb = CreateFrame("CheckButton", nil, button, "UICheckButtonTemplate")
        cb:SetSize(18, 18)
        cb:SetPoint("LEFT", button, "LEFT", 4, 0)
        cb:SetHitRectInsets(0, 0, 0, 0)
        button._checkBtn = cb

        -- Icon texture
        local icon = button:CreateTexture(nil, "ARTWORK")
        icon:SetSize(20, 20)
        icon:SetPoint("LEFT", cb, "RIGHT", 4, 0)
        button._icon = icon

        -- Name label
        local nameLabel = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(nameLabel, 11)
        nameLabel:SetPoint("LEFT", icon, "RIGHT", 6, 0)
        nameLabel:SetJustifyH("LEFT")
        nameLabel:SetWordWrap(false)
        button._nameLabel = nameLabel

        -- Info label (versions/steps)
        local infoLabel = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(infoLabel, 10)
        infoLabel:SetJustifyH("LEFT")
        infoLabel:SetWordWrap(false)
        button._infoLabel = infoLabel

        -- VarDep indicator
        local varDepLabel = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(varDepLabel, 10)
        varDepLabel:SetJustifyH("LEFT")
        varDepLabel:SetWordWrap(false)
        button._varDepLabel = varDepLabel

        -- Auto badge (for variables)
        local autoBadge = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(autoBadge, 10)
        autoBadge:SetJustifyH("RIGHT")
        button._autoBadge = autoBadge

        -- Section header label (for header rows)
        local headerText = button:CreateFontString(nil, "OVERLAY")
        UI:SetFont(headerText, 11, "OUTLINE")
        headerText:SetPoint("LEFT", button, "LEFT", 8, 0)
        headerText:SetJustifyH("LEFT")
        button._headerText = headerText
    end

    -- Reset visibility
    button._checkBtn:Hide()
    button._icon:Hide()
    button._nameLabel:Hide()
    button._infoLabel:Hide()
    button._varDepLabel:Hide()
    button._autoBadge:Hide()
    button._headerText:Hide()
    button._bg:SetColorTexture(0, 0, 0, 0)
    button._exportRefresh = nil

    -----------------------------------------------------------------------
    -- Section header rows
    -----------------------------------------------------------------------
    if data.type == "seqHeader" or data.type == "varHeader" then
        button._headerText:Show()
        button._headerText:SetTextColor(C.textSecondary:GetRGBA())
        button._bg:SetColorTexture(C.bgPanel:GetRGB())
        button._bg:SetAlpha(0.3)
        if data.type == "seqHeader" then
            button._headerText:SetText(string.format(
                L["GEMS_EXPORT_PICK_SEQ_HEADER"], data.count or 0))
        else
            button._headerText:SetText(string.format(
                L["GEMS_EXPORT_PICK_VAR_HEADER"], data.count or 0))
        end
        button:SetScript("OnClick", nil)
        return
    end

    -----------------------------------------------------------------------
    -- Sequence rows
    -----------------------------------------------------------------------
    if data.type == "sequence" then
        local entry = data.entry

        -- CheckButton
        button._checkBtn:Show()
        button._checkBtn:SetChecked(entry.selected)
        button._checkBtn:SetScript("OnClick", function(self)
            entry.selected = self:GetChecked()
            ResolveAndAutoSelectVars()
        end)

        -- Icon
        button._icon:Show()
        button._icon:SetTexture(ResolveIcon(entry.icon))

        -- Name
        button._nameLabel:Show()
        button._nameLabel:SetText(entry.name or "")
        button._nameLabel:SetTextColor(C.textPrimary:GetRGBA())
        button._nameLabel:SetWidth(200)

        -- Info: "N versions, N steps"
        button._infoLabel:Show()
        button._infoLabel:SetPoint("LEFT", button._nameLabel, "RIGHT", 8, 0)
        button._infoLabel:SetText(string.format(
            L["GEMS_EXPORT_PICK_INFO"],
            entry.versionCount or 1, entry.stepCount or 0))
        button._infoLabel:SetTextColor(C.textSecondary:GetRGBA())

        -- VarDep indicator
        if entry.varDeps and #entry.varDeps > 0 then
            button._varDepLabel:Show()
            button._varDepLabel:SetPoint("LEFT", button._infoLabel,
                "RIGHT", 8, 0)
            button._varDepLabel:SetText(string.format(
                L["GEMS_EXPORT_PICK_VAR_DEPS"], #entry.varDeps))
            button._varDepLabel:SetTextColor(C.textAccent:GetRGBA())
        end

        button:SetScript("OnClick", nil)

        -- Refresh callback for auto-select updates
        button._exportRefresh = function()
            button._checkBtn:SetChecked(entry.selected)
        end
        return
    end

    -----------------------------------------------------------------------
    -- Variable rows
    -----------------------------------------------------------------------
    if data.type == "variable" then
        local entry = data.entry

        -- CheckButton (indented 24px more)
        button._checkBtn:Show()
        button._checkBtn:SetPoint("LEFT", button, "LEFT", 28, 0)
        button._checkBtn:SetChecked(entry.selected)
        button._checkBtn:SetScript("OnClick", function(self)
            local checked = self:GetChecked()
            entry.selected = checked
            if checked then
                entry.manualSelect = true
                entry.manualDeselect = nil
            else
                entry.manualDeselect = true
                entry.manualSelect = nil
                entry.autoSelected = false
            end
            UpdateExportCount()
        end)

        -- Name
        button._nameLabel:Show()
        button._nameLabel:SetPoint("LEFT", button._checkBtn, "RIGHT", 6, 0)
        button._nameLabel:SetText(entry.name or "")
        button._nameLabel:SetTextColor(C.textPrimary:GetRGBA())

        -- "used by" info
        if entry.referencedBy and #entry.referencedBy > 0 then
            button._infoLabel:Show()
            button._infoLabel:SetPoint("LEFT", button._nameLabel,
                "RIGHT", 8, 0)
            local refText = table.concat(entry.referencedBy, ", ")
            button._infoLabel:SetText(string.format(
                L["GEMS_EXPORT_PICK_USED_BY"], refText))
            button._infoLabel:SetTextColor(C.textSecondary:GetRGBA())
        end

        -- "auto" badge if autoSelected
        if entry.autoSelected then
            button._autoBadge:Show()
            button._autoBadge:SetPoint("RIGHT", button, "RIGHT", -8, 0)
            button._autoBadge:SetText(L["GEMS_EXPORT_PICK_AUTO"])
            button._autoBadge:SetTextColor(C.textAccent:GetRGBA())
        end

        button:SetScript("OnClick", nil)

        -- Refresh callback for auto-select updates
        button._exportRefresh = function()
            button._checkBtn:SetChecked(entry.selected)
            if entry.autoSelected then
                button._autoBadge:Show()
                button._autoBadge:SetPoint("RIGHT", button, "RIGHT", -8, 0)
                button._autoBadge:SetText(L["GEMS_EXPORT_PICK_AUTO"])
                button._autoBadge:SetTextColor(C.textAccent:GetRGBA())
            else
                button._autoBadge:Hide()
            end
        end
        return
    end
end

---------------------------------------------------------------------------
-- ShowPickStage: populate and show the picker
---------------------------------------------------------------------------

local function ShowPickStage()
    local GE = GRIPEMS.GRIPExport

    pickStage:Show()
    displayStage:Hide()

    -- Build export list
    exportListData = GE.BuildExportList()

    -- Header
    pickHeaderLabel:SetText(L["GEMS_EXPORT_PICK_TITLE"])

    -- Summary
    pickSummaryLine:SetText(string.format(L["GEMS_EXPORT_PICK_HEADER"],
        #exportListData.sequences, #exportListData.variables))

    -- Build flat data array for ScrollBox
    local flatData = {}

    if #exportListData.sequences > 0 then
        flatData[#flatData + 1] = {
            type = "seqHeader", count = #exportListData.sequences,
        }
        for _, entry in ipairs(exportListData.sequences) do
            flatData[#flatData + 1] = {
                type = "sequence", entry = entry,
            }
        end
    end

    if #exportListData.variables > 0 then
        flatData[#flatData + 1] = {
            type = "varHeader", count = #exportListData.variables,
        }
        for _, entry in ipairs(exportListData.variables) do
            flatData[#flatData + 1] = {
                type = "variable", entry = entry,
            }
        end
    end

    -- Populate DataProvider
    pickDataProvider = CreateDataProvider()
    for _, rowData in ipairs(flatData) do
        pickDataProvider:Insert(rowData)
    end
    pickScrollBox:SetDataProvider(pickDataProvider)

    -- Clear warnings
    if pickWarningLabel then
        pickWarningLabel:SetText("")
    end

    UpdateExportCount()
end

---------------------------------------------------------------------------
-- ShowDisplayStage: show the export string display
---------------------------------------------------------------------------

local function ShowDisplayStage(headerText, exportString, showBack)
    pickStage:Hide()
    displayStage:Show()

    displayStage._headerLabel:SetText(headerText)
    displayStage._editbox:SetText(exportString)

    if showBack then
        displayStage._backBtn:Show()
    else
        displayStage._backBtn:Hide()
    end

    -- Auto-focus + highlight
    C_Timer.After(0.05, function()
        if displayStage and displayStage:IsShown() and displayStage._editbox then
            displayStage._editbox.editBox:SetFocus()
            displayStage._editbox.editBox:HighlightText()
        end
    end)
end

---------------------------------------------------------------------------
-- CreatePickStage: builds the picker UI (once)
---------------------------------------------------------------------------

local function CreatePickStage(rawFrame)
    local UI = GRIPEMS.UI
    local C = UI.Colors

    pickStage = CreateFrame("Frame", nil, rawFrame)
    pickStage:SetPoint("TOPLEFT", rawFrame, "TOPLEFT", 10, -26)
    pickStage:SetPoint("BOTTOMRIGHT", rawFrame, "BOTTOMRIGHT", -10, 8)
    pickStage:Hide()

    -- Header label
    pickHeaderLabel = pickStage:CreateFontString(nil, "OVERLAY")
    UI:SetFont(pickHeaderLabel, 13)
    pickHeaderLabel:SetPoint("TOPLEFT", pickStage, "TOPLEFT", 4, -4)
    pickHeaderLabel:SetTextColor(C.textPrimary:GetRGBA())

    -- Summary line
    pickSummaryLine = pickStage:CreateFontString(nil, "OVERLAY")
    UI:SetFont(pickSummaryLine, 10)
    pickSummaryLine:SetPoint("TOPLEFT", pickHeaderLabel, "BOTTOMLEFT", 0, -4)
    pickSummaryLine:SetTextColor(C.textSecondary:GetRGBA())

    -------------------------------------------------------------------
    -- Bottom bar (36px)
    -------------------------------------------------------------------
    local bottomBar = CreateFrame("Frame", nil, pickStage)
    bottomBar:SetHeight(D().BUTTON_BAR_HEIGHT)
    bottomBar:SetPoint("BOTTOMLEFT", pickStage, "BOTTOMLEFT", 0, 0)
    bottomBar:SetPoint("BOTTOMRIGHT", pickStage, "BOTTOMRIGHT", 0, 0)

    -- Select All
    local selectAllBtn = UI:CreateButton(bottomBar,
        L["GEMS_EXPORT_PICK_SELECT_ALL"], 90, 26)
    selectAllBtn:SetPoint("LEFT", bottomBar, "LEFT", 4, 0)
    selectAllBtn:SetScript("OnClick", function()
        if not exportListData then return end
        for _, entry in ipairs(exportListData.sequences) do
            entry.selected = true
        end
        ResolveAndAutoSelectVars()
    end)

    -- Deselect All
    local deselectAllBtn = UI:CreateButton(bottomBar,
        L["GEMS_EXPORT_PICK_DESELECT_ALL"], 100, 26)
    deselectAllBtn:SetPoint("LEFT", selectAllBtn, "RIGHT", 6, 0)
    deselectAllBtn:SetScript("OnClick", function()
        if not exportListData then return end
        for _, entry in ipairs(exportListData.sequences) do
            entry.selected = false
        end
        for _, entry in ipairs(exportListData.variables) do
            entry.selected = false
            entry.autoSelected = false
            entry.manualSelect = nil
            entry.manualDeselect = nil
        end
        if pickScrollBox then
            pickScrollBox:ForEachFrame(function(btn)
                if btn._exportRefresh then
                    btn._exportRefresh()
                end
            end)
        end
        if pickWarningLabel then
            pickWarningLabel:SetText("")
        end
        UpdateExportCount()
    end)

    -- Export Selected (right-aligned, green-tinted)
    pickExportBtn = UI:CreateButton(bottomBar, "", 160, 26)
    pickExportBtn:SetPoint("RIGHT", bottomBar, "RIGHT", -4, 0)
    pickExportBtn:SetBackdropColor(C.bgSave:GetRGBA())
    pickExportBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(C.bgSaveHover:GetRGBA())
        self:SetBackdropBorderColor(C.borderFocus:GetRGBA())
    end)
    pickExportBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(C.bgSave:GetRGBA())
        self:SetBackdropBorderColor(C.border:GetRGBA())
    end)
    pickExportBtn:SetScript("OnClick", function()
        if not exportListData then return end

        local GE = GRIPEMS.GRIPExport

        -- Collect selected names
        local seqNames = {}
        for _, entry in ipairs(exportListData.sequences) do
            if entry.selected then
                seqNames[#seqNames + 1] = entry.name
            end
        end
        local varNames = {}
        for _, entry in ipairs(exportListData.variables) do
            if entry.selected then
                varNames[#varNames + 1] = entry.name
            end
        end

        if #seqNames == 0 then return end

        local ok, result = GE.ExportCollection(seqNames, varNames)
        if ok then
            local header = string.format(
                L["GEMS_EXPORT_PICK_DISPLAY_HEADER"],
                #seqNames, #varNames)
            ShowDisplayStage(header, result, true)
        else
            GRIPEMS:Print(string.format(L["GEMS_EXPORT_FAILED"],
                tostring(result)))
        end
    end)

    -- Warning label (center, between deselect and export)
    pickWarningLabel = bottomBar:CreateFontString(nil, "OVERLAY")
    UI:SetFont(pickWarningLabel, 10)
    pickWarningLabel:SetPoint("LEFT", deselectAllBtn, "RIGHT", 8, 0)
    pickWarningLabel:SetPoint("RIGHT", pickExportBtn, "LEFT", -8, 0)
    pickWarningLabel:SetJustifyH("CENTER")
    pickWarningLabel:SetWordWrap(false)
    pickWarningLabel:SetText("")

    -------------------------------------------------------------------
    -- ScrollBox (between summary and bottom bar)
    -------------------------------------------------------------------
    pickScrollBox = CreateFrame("Frame", nil, pickStage, "WowScrollBoxList")
    pickScrollBox:SetPoint("TOPLEFT", pickSummaryLine, "BOTTOMLEFT", 0, -8)
    pickScrollBox:SetPoint("BOTTOMRIGHT", bottomBar, "TOPRIGHT", -18, 4)

    pickScrollBar = CreateFrame("EventFrame", nil, pickStage,
        "MinimalScrollBar")
    pickScrollBar:SetPoint("TOPLEFT", pickScrollBox, "TOPRIGHT", 2, 0)
    pickScrollBar:SetPoint("BOTTOMLEFT", pickScrollBox, "BOTTOMRIGHT", 2, 0)

    pickScrollView = CreateScrollBoxListLinearView()
    pickScrollView:SetElementExtent(D().EXPORT_PICKER_ROW_HEIGHT)

    pickScrollView:SetElementInitializer("Button", function(button, rowData)
        InitExportRow(button, rowData)
    end)

    ScrollUtil.InitScrollBoxListWithScrollBar(
        pickScrollBox, pickScrollBar, pickScrollView)

    pickDataProvider = CreateDataProvider()
    pickScrollBox:SetDataProvider(pickDataProvider)
end

---------------------------------------------------------------------------
-- CreateDisplayStage: builds the export string display UI (once)
---------------------------------------------------------------------------

local function CreateDisplayStage(rawFrame)
    local UI = GRIPEMS.UI
    local C = UI.Colors

    displayStage = CreateFrame("Frame", nil, rawFrame)
    displayStage:SetPoint("TOPLEFT", rawFrame, "TOPLEFT", 10, -26)
    displayStage:SetPoint("BOTTOMRIGHT", rawFrame, "BOTTOMRIGHT", -10, 8)
    displayStage:Hide()

    -- Header label
    local headerLabel = displayStage:CreateFontString(nil, "OVERLAY")
    UI:SetFont(headerLabel, 13)
    headerLabel:SetPoint("TOPLEFT", displayStage, "TOPLEFT", 4, -4)
    headerLabel:SetTextColor(C.textPrimary:GetRGBA())
    displayStage._headerLabel = headerLabel

    -- Hint label
    local hint = displayStage:CreateFontString(nil, "OVERLAY")
    UI:SetFont(hint, 10)
    hint:SetPoint("TOPLEFT", headerLabel, "BOTTOMLEFT", 0, -4)
    hint:SetText(L["GEMS_EXPORT_FRAME_HINT"])
    hint:SetTextColor(C.textSecondary:GetRGBA())

    -- Bottom bar
    local bottomBar = CreateFrame("Frame", nil, displayStage)
    bottomBar:SetHeight(D().BUTTON_BAR_HEIGHT)
    bottomBar:SetPoint("BOTTOMLEFT", displayStage, "BOTTOMLEFT", 0, 0)
    bottomBar:SetPoint("BOTTOMRIGHT", displayStage, "BOTTOMRIGHT", 0, 0)

    -- Back button (bottom-left)
    local backBtn = UI:CreateButton(bottomBar,
        L["GEMS_EXPORT_PICK_BACK"], 80, 26)
    backBtn:SetPoint("LEFT", bottomBar, "LEFT", 4, 0)
    backBtn:SetScript("OnClick", function()
        ShowPickStage()
    end)
    displayStage._backBtn = backBtn

    -- MultiLineEditBox (read-only display) via AceGUI
    local editbox = AceGUI:Create("MultiLineEditBox")
    editbox:SetLabel("")
    editbox:SetNumLines(15)
    editbox:DisableButton(true)
    editbox.frame:SetParent(displayStage)
    editbox.frame:SetPoint("TOPLEFT", hint, "BOTTOMLEFT", -2, -6)
    editbox.frame:SetPoint("BOTTOMRIGHT", bottomBar, "TOPRIGHT", -4, 4)
    editbox.frame:Show()
    displayStage._editbox = editbox

    -- On re-focus, re-highlight all text for easy Ctrl+C
    editbox.editBox:SetScript("OnEditFocusGained", function(self)
        self:HighlightText()
    end)

    -- Auto-close on Ctrl+C
    editbox.editBox:SetScript("OnKeyDown", function(_, key)
        if key == "C" and IsControlKeyDown() then
            C_Timer.After(0.1, function()
                if frame and frame:IsShown() then
                    frame:Hide()
                end
            end)
        end
    end)
end

---------------------------------------------------------------------------
-- EF:Show() -- main entry point
-- EF:Show()               -> open pick stage (multi-select)
-- EF:Show(name, string)   -> go directly to display stage (backward compat)
---------------------------------------------------------------------------

--- Show the export frame.
--- With no args: opens multi-select picker.
--- With (name, string): shows export display directly (backward compat).
--- @param sequenceName string|nil Sequence name for single-export mode
--- @param exportString string|nil Pre-encoded export string
function EF:Show(sequenceName, exportString)
    if not frame then
        frame = AceGUI:Create("Frame")
        frame:SetTitle("GRIP-EMS: Export")
        frame:SetWidth(D().EXPORT_PICKER_WIDTH)
        frame:SetHeight(D().EXPORT_PICKER_HEIGHT)
        frame:SetLayout(nil)  -- manual layout
        frame.frame:SetFrameStrata("DIALOG")
        frame.frame:SetClampedToScreen(true)
        frame:SetCallback("OnClose", function(widget)
            widget:Hide()
        end)

        local rawFrame = frame.frame

        -- Create both stages
        CreatePickStage(rawFrame)
        CreateDisplayStage(rawFrame)
    end

    -- Detect call signature
    if sequenceName and exportString then
        -- Single-export backward compat: skip pick, show display directly
        pickStage:Hide()
        local header = string.format(L["GEMS_EXPORT_FRAME_LABEL"],
            sequenceName)
        frame:SetTitle("GRIP-EMS: Export")
        frame:Show()
        ShowDisplayStage(header, exportString, false)
    else
        -- Multi-select mode: show pick stage
        displayStage:Hide()
        exportListData = nil
        frame:SetTitle("GRIP-EMS: Export")
        frame:Show()
        ShowPickStage()
    end
end

--- Hide the export frame if shown.
function EF:Hide()
    if frame then
        frame:Hide()
    end
end

--- Check if the export frame is currently shown.
--- @return boolean
function EF:IsShown()
    return frame and frame:IsShown()
end
