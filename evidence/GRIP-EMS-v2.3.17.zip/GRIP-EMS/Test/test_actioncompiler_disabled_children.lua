-- GRIP-EMS: Headless test for disabled nodes inside Loop / IF subtrees
--
-- Created:    2026-07-09
-- Updated:    2026-07-10
-- Patch: 12.0.7.68453 Midnight (Retail LIVE)
--
-- Standalone (Lua 5.1) test for Engine/ActionCompiler.lua's disabled-node
-- handling below the top level. The top-level skip in compileTree dates from
-- the original step-disable work; the detail-pane menu later exposed the same
-- toggle on Loop / IF children, where _compileNode had no guard and the Loop
-- interleave collection ignored the flag -- a disabled child still baked into
-- steps. Loads the REAL Data/Defaults.lua, Engine/MacroSyntax.lua, and
-- Engine/ActionCompiler.lua via loadfile + setfenv into a sandbox (MacroSyntax
-- backs the IF compile path).
--
-- Run from the EMS root:  lua Test/test_actioncompiler_disabled_children.lua
-- Exit code 0 = all passed, 1 = at least one failure.
--
-- Cases:
--   T1  Sequential loop skips a disabled child (A, C, A, C -- no B)
--   T2  Priority loop expands the triangle over ENABLED children only
--   T3  disabled interval-bearing loop child is NOT interleaved
--   T4  IF true branch skips a disabled child
--   T5  top-level disabled ACTION node still skipped (regression control)
--   T6  all-children-disabled loop compiles to zero steps without erroring
--   T7  malformed non-table Loop children are skipped without erroring
--   T8  malformed non-table IF branch child compiles table children only
--   T9  malformed non-table top-level entries are skipped without erroring
--   T10 ValidateActions reports a malformed IF branch child, never throws

local ADDON_NAME = "GRIP-EMS"

-- ---------------------------------------------------------------------------
-- Minimal assertion + runner harness.
-- ---------------------------------------------------------------------------

local tests = {}

local function test(name, fn)
    tests[#tests + 1] = { name = name, fn = fn }
end

local function assertEqual(expected, actual, label)
    if expected ~= actual then
        error((label or "value") .. ": expected " .. tostring(expected) .. ", got " .. tostring(actual), 2)
    end
end

local function assertTrue(cond, label)
    if not cond then
        error((label or "condition") .. " failed", 2)
    end
end

local function assertAbsent(steps, macro, label)
    for i, step in ipairs(steps) do
        if step == macro then
            error((label or "absence") .. ": " .. macro .. " present at step " .. i, 2)
        end
    end
end

-- ---------------------------------------------------------------------------
-- Sandbox: a self-referential no-op stub backs every unknown global, so the
-- modules load without a real WoW client. Real stdlib falls through to _G.
-- ---------------------------------------------------------------------------

local stub = {}
setmetatable(stub, {
    __index = function()
        return stub
    end,
    __call = function()
        return stub
    end,
})

local env = setmetatable({}, {
    __index = function(_, k)
        local v = rawget(_G, k)
        if v ~= nil then
            return v
        end
        return stub
    end,
})
env._G = env

-- Locale lookups resolve to the key name itself, so string.format on them
-- never errors.
local LOCALE = setmetatable({}, {
    __index = function(_, k)
        return k
    end,
})

env.LibStub = function()
    return {
        GetLocale = function()
            return LOCALE
        end,
    }
end
env.strlower = string.lower
env.GetTime = function()
    return 0
end

local GRIPEMS = {
    Debug = function() end,
}

-- ---------------------------------------------------------------------------
-- Load the REAL modules into the sandbox. Defaults first (ActionCompiler
-- captures local D = GRIPEMS.Defaults at load), then MacroSyntax (the IF
-- compile path routes through it), then the compiler.
-- ---------------------------------------------------------------------------

local function loadModule(candidates)
    for _, path in ipairs(candidates) do
        -- loadfile is dev-harness file I/O, intentionally outside the addon WoW std.
        -- selene: allow(undefined_variable)
        local chunk = loadfile(path)
        if chunk then
            setfenv(chunk, env)
            chunk(ADDON_NAME, GRIPEMS)
            return true
        end
    end
    return false
end

assertTrue(
    loadModule({
        "Data/Defaults.lua",
        "../Data/Defaults.lua",
        "GRIP/EMS/Data/Defaults.lua",
    }),
    "could not locate Data/Defaults.lua (run from the EMS root)"
)
assertTrue(
    loadModule({
        "Engine/MacroSyntax.lua",
        "../Engine/MacroSyntax.lua",
        "GRIP/EMS/Engine/MacroSyntax.lua",
    }),
    "could not locate Engine/MacroSyntax.lua (run from the EMS root)"
)
assertTrue(
    loadModule({
        "Engine/ActionCompiler.lua",
        "../Engine/ActionCompiler.lua",
        "GRIP/EMS/Engine/ActionCompiler.lua",
    }),
    "could not locate Engine/ActionCompiler.lua (run from the EMS root)"
)

local D = GRIPEMS.Defaults
local AC = GRIPEMS.ActionCompiler
assertTrue(D ~= nil, "Defaults loaded")
assertTrue(GRIPEMS.MacroSyntax ~= nil, "MacroSyntax loaded")
assertTrue(AC ~= nil, "ActionCompiler loaded")
assertTrue(type(AC.CompileActions) == "function", "CompileActions defined")

-- ---------------------------------------------------------------------------
-- Fixtures.
-- ---------------------------------------------------------------------------

local A = "/cast Alpha"
local B = "/cast Bravo"
local C = "/cast Charlie"

local function action(macro, extra)
    local node = { type = D.ACTION_TYPE_ACTION, macro = macro }
    for k, v in pairs(extra or {}) do
        node[k] = v
    end
    return node
end

-- ---------------------------------------------------------------------------
-- Cases.
-- ---------------------------------------------------------------------------

test("T1: Sequential loop skips a disabled child", function()
    local loopNode = {
        type = D.ACTION_TYPE_LOOP,
        ["repeat"] = 2,
        stepFunction = D.STEP_SEQUENTIAL,
        children = {
            action(A),
            action(B, { disabled = true }),
            action(C),
        },
    }
    local steps = AC.CompileActions({ loopNode }, nil)
    assertEqual(4, #steps, "step count")
    assertEqual(A, steps[1], "step 1")
    assertEqual(C, steps[2], "step 2")
    assertEqual(A, steps[3], "step 3")
    assertEqual(C, steps[4], "step 4")
    assertAbsent(steps, B, "disabled child absent")
end)

test("T2: Priority loop expands the triangle over enabled children only", function()
    local loopNode = {
        type = D.ACTION_TYPE_LOOP,
        ["repeat"] = 1,
        stepFunction = D.STEP_PRIORITY,
        children = {
            action(A),
            action(B, { disabled = true }),
            action(C),
        },
    }
    local steps = AC.CompileActions({ loopNode }, nil)
    assertEqual(3, #steps, "two-child triangle step count")
    assertEqual(A, steps[1], "step 1")
    assertEqual(A, steps[2], "step 2")
    assertEqual(C, steps[3], "step 3")
    assertAbsent(steps, B, "disabled child absent from triangle")
end)

test("T3: disabled interval-bearing loop child is not interleaved", function()
    local loopNode = {
        type = D.ACTION_TYPE_LOOP,
        ["repeat"] = 1,
        stepFunction = D.STEP_SEQUENTIAL,
        children = {
            action(A),
            action(C),
            action(B, { disabled = true, interval = D.ACTION_INTERLEAVE_MIN + 1 }),
        },
    }
    local steps = AC.CompileActions({ loopNode }, nil)
    assertEqual(2, #steps, "plain two-child expansion")
    assertEqual(A, steps[1], "step 1")
    assertEqual(C, steps[2], "step 2")
    assertAbsent(steps, B, "disabled interval child not woven in")
end)

test("T4: IF true branch skips a disabled child", function()
    local ifNode = {
        type = D.ACTION_TYPE_IF,
        variable = "combat",
        children = {
            {
                action(A),
                action(B, { disabled = true }),
            },
            {},
        },
    }
    local steps = AC.CompileActions({ ifNode }, nil)
    assertEqual(1, #steps, "single-line true-branch compile")
    assertTrue(steps[1]:find("Alpha", 1, true) ~= nil, "enabled child compiled")
    assertTrue(steps[1]:find("combat", 1, true) ~= nil, "condition injected")
    assertTrue(steps[1]:find("Bravo", 1, true) == nil, "disabled child absent from IF output")
end)

test("T5: top-level disabled ACTION node is still skipped", function()
    local steps = AC.CompileActions({
        action(A),
        action(B, { disabled = true }),
        action(C),
    }, nil)
    assertEqual(2, #steps, "step count")
    assertEqual(A, steps[1], "step 1")
    assertEqual(C, steps[2], "step 2")
    assertAbsent(steps, B, "top-level disabled node absent")
end)

test("T6: all-children-disabled loop compiles to zero steps without erroring", function()
    local loopNode = {
        type = D.ACTION_TYPE_LOOP,
        ["repeat"] = 2,
        stepFunction = D.STEP_SEQUENTIAL,
        children = {
            action(A, { disabled = true }),
            action(B, { disabled = true }),
        },
    }
    local steps = AC.CompileActions({ loopNode }, nil)
    assertEqual(0, #steps, "zero steps")
end)

test("T7: malformed non-table Loop children are skipped without erroring", function()
    local loopNode = {
        type = D.ACTION_TYPE_LOOP,
        ["repeat"] = 1,
        stepFunction = D.STEP_SEQUENTIAL,
        children = { action(A), 5, true, action(C) },
    }
    local steps = AC.CompileActions({ loopNode }, nil)
    assertEqual(2, #steps, "table children only")
    assertEqual(A, steps[1], "step 1")
    assertEqual(C, steps[2], "step 2")
end)

test("T8: malformed non-table IF branch child compiles table children only", function()
    local ifNode = {
        type = D.ACTION_TYPE_IF,
        variable = "combat",
        children = {
            { action(A), 5 },
            {},
        },
    }
    local steps = AC.CompileActions({ ifNode }, nil)
    assertEqual(1, #steps, "single-line true-branch compile")
    assertTrue(steps[1]:find("Alpha", 1, true) ~= nil, "table child compiled")
    assertTrue(steps[1]:find("combat", 1, true) ~= nil, "condition injected")
end)

test("T9: malformed non-table top-level entries are skipped without erroring", function()
    local steps = AC.CompileActions({ action(A), 5, true, action(C) }, nil)
    assertEqual(2, #steps, "step count")
    assertEqual(A, steps[1], "step 1")
    assertEqual(C, steps[2], "step 2")
end)

test("T10: ValidateActions reports a malformed IF branch child, never throws", function()
    local ifNode = {
        type = D.ACTION_TYPE_IF,
        variable = "combat",
        children = {
            { action(A), 5 },
            {},
        },
    }
    local ok, errors = AC.ValidateActions({ ifNode })
    assertEqual(false, ok, "validation fails")
    local found = false
    for _, err in ipairs(errors) do
        if err:find("missing or invalid type", 1, true) then
            found = true
        end
    end
    assertTrue(found, "type error reported")
    for _, err in ipairs(errors) do
        assertTrue(err:find("no actions in either branch", 1, true) == nil, "no-actions error absent")
    end
end)

-- ---------------------------------------------------------------------------
-- Run.
-- ---------------------------------------------------------------------------

local passed = 0
local failed = 0
for _, t in ipairs(tests) do
    local ok, err = pcall(t.fn)
    if ok then
        passed = passed + 1
        print("PASS  " .. t.name)
    else
        failed = failed + 1
        print("FAIL  " .. t.name .. " -- " .. tostring(err))
    end
end
print(string.format("RESULT %d passed, %d failed", passed, failed))
os.exit(failed > 0 and 1 or 0)
